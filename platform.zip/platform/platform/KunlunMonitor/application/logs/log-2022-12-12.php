<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-12-12 02:38:48 --> Config Class Initialized
INFO - 2022-12-12 02:38:48 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:38:48 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:38:48 --> Utf8 Class Initialized
INFO - 2022-12-12 02:38:48 --> URI Class Initialized
INFO - 2022-12-12 02:38:48 --> Router Class Initialized
INFO - 2022-12-12 02:38:48 --> Output Class Initialized
INFO - 2022-12-12 02:38:48 --> Security Class Initialized
DEBUG - 2022-12-12 02:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:38:48 --> Input Class Initialized
INFO - 2022-12-12 02:38:48 --> Language Class Initialized
INFO - 2022-12-12 02:38:48 --> Loader Class Initialized
INFO - 2022-12-12 02:38:48 --> Controller Class Initialized
DEBUG - 2022-12-12 02:38:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:38:48 --> Database Driver Class Initialized
INFO - 2022-12-12 02:38:48 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:38:49 --> Database Driver Class Initialized
INFO - 2022-12-12 02:38:49 --> Model "Login_model" initialized
INFO - 2022-12-12 02:38:49 --> Final output sent to browser
DEBUG - 2022-12-12 02:38:49 --> Total execution time: 0.2010
INFO - 2022-12-12 02:38:49 --> Config Class Initialized
INFO - 2022-12-12 02:38:49 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:38:49 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:38:49 --> Utf8 Class Initialized
INFO - 2022-12-12 02:38:49 --> URI Class Initialized
INFO - 2022-12-12 02:38:49 --> Router Class Initialized
INFO - 2022-12-12 02:38:49 --> Output Class Initialized
INFO - 2022-12-12 02:38:49 --> Security Class Initialized
DEBUG - 2022-12-12 02:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:38:49 --> Input Class Initialized
INFO - 2022-12-12 02:38:49 --> Language Class Initialized
INFO - 2022-12-12 02:38:49 --> Loader Class Initialized
INFO - 2022-12-12 02:38:49 --> Controller Class Initialized
DEBUG - 2022-12-12 02:38:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:38:49 --> Database Driver Class Initialized
INFO - 2022-12-12 02:38:49 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:38:49 --> Database Driver Class Initialized
INFO - 2022-12-12 02:38:49 --> Model "Login_model" initialized
INFO - 2022-12-12 02:38:49 --> Final output sent to browser
DEBUG - 2022-12-12 02:38:49 --> Total execution time: 0.1850
INFO - 2022-12-12 02:38:56 --> Config Class Initialized
INFO - 2022-12-12 02:38:56 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:38:56 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:38:56 --> Utf8 Class Initialized
INFO - 2022-12-12 02:38:56 --> URI Class Initialized
INFO - 2022-12-12 02:38:56 --> Router Class Initialized
INFO - 2022-12-12 02:38:56 --> Output Class Initialized
INFO - 2022-12-12 02:38:56 --> Security Class Initialized
DEBUG - 2022-12-12 02:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:38:56 --> Input Class Initialized
INFO - 2022-12-12 02:38:56 --> Language Class Initialized
INFO - 2022-12-12 02:38:56 --> Loader Class Initialized
INFO - 2022-12-12 02:38:56 --> Controller Class Initialized
DEBUG - 2022-12-12 02:38:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:38:56 --> Database Driver Class Initialized
INFO - 2022-12-12 02:38:56 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:38:56 --> Final output sent to browser
DEBUG - 2022-12-12 02:38:56 --> Total execution time: 0.0582
INFO - 2022-12-12 02:38:56 --> Config Class Initialized
INFO - 2022-12-12 02:38:56 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:38:56 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:38:56 --> Utf8 Class Initialized
INFO - 2022-12-12 02:38:56 --> URI Class Initialized
INFO - 2022-12-12 02:38:56 --> Router Class Initialized
INFO - 2022-12-12 02:38:56 --> Output Class Initialized
INFO - 2022-12-12 02:38:56 --> Security Class Initialized
DEBUG - 2022-12-12 02:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:38:56 --> Input Class Initialized
INFO - 2022-12-12 02:38:56 --> Language Class Initialized
INFO - 2022-12-12 02:38:56 --> Loader Class Initialized
INFO - 2022-12-12 02:38:56 --> Controller Class Initialized
DEBUG - 2022-12-12 02:38:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:38:56 --> Database Driver Class Initialized
INFO - 2022-12-12 02:38:56 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:38:56 --> Final output sent to browser
DEBUG - 2022-12-12 02:38:56 --> Total execution time: 0.0520
INFO - 2022-12-12 02:38:59 --> Config Class Initialized
INFO - 2022-12-12 02:38:59 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:38:59 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:38:59 --> Utf8 Class Initialized
INFO - 2022-12-12 02:38:59 --> URI Class Initialized
INFO - 2022-12-12 02:38:59 --> Router Class Initialized
INFO - 2022-12-12 02:38:59 --> Output Class Initialized
INFO - 2022-12-12 02:38:59 --> Security Class Initialized
DEBUG - 2022-12-12 02:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:38:59 --> Input Class Initialized
INFO - 2022-12-12 02:38:59 --> Language Class Initialized
INFO - 2022-12-12 02:38:59 --> Loader Class Initialized
INFO - 2022-12-12 02:38:59 --> Controller Class Initialized
DEBUG - 2022-12-12 02:38:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:38:59 --> Database Driver Class Initialized
INFO - 2022-12-12 02:38:59 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:38:59 --> Database Driver Class Initialized
INFO - 2022-12-12 02:38:59 --> Model "Login_model" initialized
INFO - 2022-12-12 02:38:59 --> Final output sent to browser
DEBUG - 2022-12-12 02:38:59 --> Total execution time: 0.2499
INFO - 2022-12-12 02:38:59 --> Config Class Initialized
INFO - 2022-12-12 02:38:59 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:38:59 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:38:59 --> Utf8 Class Initialized
INFO - 2022-12-12 02:38:59 --> URI Class Initialized
INFO - 2022-12-12 02:38:59 --> Router Class Initialized
INFO - 2022-12-12 02:38:59 --> Output Class Initialized
INFO - 2022-12-12 02:38:59 --> Security Class Initialized
DEBUG - 2022-12-12 02:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:38:59 --> Input Class Initialized
INFO - 2022-12-12 02:38:59 --> Language Class Initialized
INFO - 2022-12-12 02:38:59 --> Loader Class Initialized
INFO - 2022-12-12 02:38:59 --> Controller Class Initialized
DEBUG - 2022-12-12 02:38:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:38:59 --> Database Driver Class Initialized
INFO - 2022-12-12 02:38:59 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:39:00 --> Database Driver Class Initialized
INFO - 2022-12-12 02:39:00 --> Model "Login_model" initialized
INFO - 2022-12-12 02:39:00 --> Final output sent to browser
DEBUG - 2022-12-12 02:39:00 --> Total execution time: 0.1821
INFO - 2022-12-12 02:39:03 --> Config Class Initialized
INFO - 2022-12-12 02:39:03 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:39:03 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:39:03 --> Utf8 Class Initialized
INFO - 2022-12-12 02:39:03 --> URI Class Initialized
INFO - 2022-12-12 02:39:03 --> Router Class Initialized
INFO - 2022-12-12 02:39:03 --> Output Class Initialized
INFO - 2022-12-12 02:39:03 --> Security Class Initialized
DEBUG - 2022-12-12 02:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:39:03 --> Input Class Initialized
INFO - 2022-12-12 02:39:03 --> Language Class Initialized
INFO - 2022-12-12 02:39:03 --> Loader Class Initialized
INFO - 2022-12-12 02:39:03 --> Controller Class Initialized
DEBUG - 2022-12-12 02:39:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:39:03 --> Database Driver Class Initialized
INFO - 2022-12-12 02:39:03 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:39:03 --> Final output sent to browser
DEBUG - 2022-12-12 02:39:03 --> Total execution time: 0.0722
INFO - 2022-12-12 02:39:03 --> Config Class Initialized
INFO - 2022-12-12 02:39:03 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:39:03 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:39:03 --> Utf8 Class Initialized
INFO - 2022-12-12 02:39:03 --> URI Class Initialized
INFO - 2022-12-12 02:39:03 --> Router Class Initialized
INFO - 2022-12-12 02:39:03 --> Output Class Initialized
INFO - 2022-12-12 02:39:03 --> Security Class Initialized
DEBUG - 2022-12-12 02:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:39:03 --> Input Class Initialized
INFO - 2022-12-12 02:39:03 --> Language Class Initialized
INFO - 2022-12-12 02:39:03 --> Loader Class Initialized
INFO - 2022-12-12 02:39:03 --> Controller Class Initialized
DEBUG - 2022-12-12 02:39:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:39:03 --> Database Driver Class Initialized
INFO - 2022-12-12 02:39:03 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:39:03 --> Final output sent to browser
DEBUG - 2022-12-12 02:39:03 --> Total execution time: 0.0537
INFO - 2022-12-12 02:39:05 --> Config Class Initialized
INFO - 2022-12-12 02:39:05 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:39:05 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:39:05 --> Utf8 Class Initialized
INFO - 2022-12-12 02:39:05 --> URI Class Initialized
INFO - 2022-12-12 02:39:05 --> Router Class Initialized
INFO - 2022-12-12 02:39:05 --> Output Class Initialized
INFO - 2022-12-12 02:39:05 --> Security Class Initialized
DEBUG - 2022-12-12 02:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:39:05 --> Input Class Initialized
INFO - 2022-12-12 02:39:05 --> Language Class Initialized
INFO - 2022-12-12 02:39:05 --> Loader Class Initialized
INFO - 2022-12-12 02:39:05 --> Controller Class Initialized
DEBUG - 2022-12-12 02:39:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:39:05 --> Database Driver Class Initialized
INFO - 2022-12-12 02:39:05 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:39:05 --> Config Class Initialized
INFO - 2022-12-12 02:39:05 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:39:05 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:39:05 --> Utf8 Class Initialized
INFO - 2022-12-12 02:39:05 --> URI Class Initialized
INFO - 2022-12-12 02:39:05 --> Router Class Initialized
INFO - 2022-12-12 02:39:05 --> Output Class Initialized
INFO - 2022-12-12 02:39:05 --> Security Class Initialized
DEBUG - 2022-12-12 02:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:39:05 --> Input Class Initialized
INFO - 2022-12-12 02:39:05 --> Language Class Initialized
INFO - 2022-12-12 02:39:05 --> Loader Class Initialized
INFO - 2022-12-12 02:39:05 --> Controller Class Initialized
DEBUG - 2022-12-12 02:39:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:39:05 --> Database Driver Class Initialized
INFO - 2022-12-12 02:39:05 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:39:22 --> Config Class Initialized
INFO - 2022-12-12 02:39:22 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:39:22 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:39:22 --> Utf8 Class Initialized
INFO - 2022-12-12 02:39:22 --> URI Class Initialized
INFO - 2022-12-12 02:39:22 --> Router Class Initialized
INFO - 2022-12-12 02:39:22 --> Output Class Initialized
INFO - 2022-12-12 02:39:22 --> Security Class Initialized
DEBUG - 2022-12-12 02:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:39:22 --> Input Class Initialized
INFO - 2022-12-12 02:39:22 --> Language Class Initialized
INFO - 2022-12-12 02:39:22 --> Loader Class Initialized
INFO - 2022-12-12 02:39:22 --> Controller Class Initialized
DEBUG - 2022-12-12 02:39:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:39:22 --> Database Driver Class Initialized
INFO - 2022-12-12 02:39:22 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:39:22 --> Final output sent to browser
DEBUG - 2022-12-12 02:39:22 --> Total execution time: 0.0579
INFO - 2022-12-12 02:39:22 --> Config Class Initialized
INFO - 2022-12-12 02:39:22 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:39:22 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:39:22 --> Utf8 Class Initialized
INFO - 2022-12-12 02:39:22 --> URI Class Initialized
INFO - 2022-12-12 02:39:22 --> Router Class Initialized
INFO - 2022-12-12 02:39:22 --> Output Class Initialized
INFO - 2022-12-12 02:39:22 --> Security Class Initialized
DEBUG - 2022-12-12 02:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:39:22 --> Input Class Initialized
INFO - 2022-12-12 02:39:22 --> Language Class Initialized
INFO - 2022-12-12 02:39:22 --> Loader Class Initialized
INFO - 2022-12-12 02:39:22 --> Controller Class Initialized
DEBUG - 2022-12-12 02:39:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:39:22 --> Database Driver Class Initialized
INFO - 2022-12-12 02:39:22 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:39:22 --> Final output sent to browser
DEBUG - 2022-12-12 02:39:22 --> Total execution time: 0.0571
INFO - 2022-12-12 02:54:36 --> Config Class Initialized
INFO - 2022-12-12 02:54:36 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:54:36 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:54:36 --> Utf8 Class Initialized
INFO - 2022-12-12 02:54:36 --> URI Class Initialized
INFO - 2022-12-12 02:54:36 --> Router Class Initialized
INFO - 2022-12-12 02:54:36 --> Output Class Initialized
INFO - 2022-12-12 02:54:36 --> Security Class Initialized
DEBUG - 2022-12-12 02:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:54:36 --> Input Class Initialized
INFO - 2022-12-12 02:54:36 --> Language Class Initialized
INFO - 2022-12-12 02:54:36 --> Loader Class Initialized
INFO - 2022-12-12 02:54:36 --> Controller Class Initialized
DEBUG - 2022-12-12 02:54:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:54:36 --> Database Driver Class Initialized
INFO - 2022-12-12 02:54:36 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:54:36 --> Config Class Initialized
INFO - 2022-12-12 02:54:36 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:54:36 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:54:36 --> Utf8 Class Initialized
INFO - 2022-12-12 02:54:36 --> URI Class Initialized
INFO - 2022-12-12 02:54:36 --> Router Class Initialized
INFO - 2022-12-12 02:54:36 --> Output Class Initialized
INFO - 2022-12-12 02:54:36 --> Security Class Initialized
DEBUG - 2022-12-12 02:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:54:36 --> Input Class Initialized
INFO - 2022-12-12 02:54:36 --> Language Class Initialized
INFO - 2022-12-12 02:54:36 --> Loader Class Initialized
INFO - 2022-12-12 02:54:36 --> Controller Class Initialized
DEBUG - 2022-12-12 02:54:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:54:36 --> Database Driver Class Initialized
INFO - 2022-12-12 02:54:36 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:18 --> Config Class Initialized
INFO - 2022-12-12 02:57:18 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:18 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:18 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:18 --> URI Class Initialized
INFO - 2022-12-12 02:57:18 --> Router Class Initialized
INFO - 2022-12-12 02:57:18 --> Output Class Initialized
INFO - 2022-12-12 02:57:18 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:18 --> Input Class Initialized
INFO - 2022-12-12 02:57:18 --> Language Class Initialized
INFO - 2022-12-12 02:57:18 --> Loader Class Initialized
INFO - 2022-12-12 02:57:18 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:18 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:18 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:18 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:18 --> Total execution time: 0.0611
INFO - 2022-12-12 02:57:18 --> Config Class Initialized
INFO - 2022-12-12 02:57:18 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:18 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:18 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:18 --> URI Class Initialized
INFO - 2022-12-12 02:57:18 --> Router Class Initialized
INFO - 2022-12-12 02:57:18 --> Output Class Initialized
INFO - 2022-12-12 02:57:18 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:18 --> Input Class Initialized
INFO - 2022-12-12 02:57:18 --> Language Class Initialized
INFO - 2022-12-12 02:57:18 --> Loader Class Initialized
INFO - 2022-12-12 02:57:18 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:18 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:18 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:18 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:18 --> Total execution time: 0.0537
INFO - 2022-12-12 02:57:21 --> Config Class Initialized
INFO - 2022-12-12 02:57:21 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:21 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:21 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:21 --> URI Class Initialized
INFO - 2022-12-12 02:57:21 --> Router Class Initialized
INFO - 2022-12-12 02:57:21 --> Output Class Initialized
INFO - 2022-12-12 02:57:21 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:21 --> Input Class Initialized
INFO - 2022-12-12 02:57:21 --> Language Class Initialized
INFO - 2022-12-12 02:57:21 --> Loader Class Initialized
INFO - 2022-12-12 02:57:21 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:21 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:21 --> Total execution time: 0.0224
INFO - 2022-12-12 02:57:21 --> Config Class Initialized
INFO - 2022-12-12 02:57:21 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:21 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:21 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:21 --> URI Class Initialized
INFO - 2022-12-12 02:57:21 --> Router Class Initialized
INFO - 2022-12-12 02:57:21 --> Output Class Initialized
INFO - 2022-12-12 02:57:21 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:21 --> Input Class Initialized
INFO - 2022-12-12 02:57:21 --> Language Class Initialized
INFO - 2022-12-12 02:57:21 --> Loader Class Initialized
INFO - 2022-12-12 02:57:21 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:21 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:21 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:21 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:21 --> Total execution time: 0.0503
INFO - 2022-12-12 02:57:22 --> Config Class Initialized
INFO - 2022-12-12 02:57:22 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:22 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:22 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:22 --> URI Class Initialized
INFO - 2022-12-12 02:57:22 --> Router Class Initialized
INFO - 2022-12-12 02:57:22 --> Output Class Initialized
INFO - 2022-12-12 02:57:22 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:22 --> Input Class Initialized
INFO - 2022-12-12 02:57:22 --> Language Class Initialized
INFO - 2022-12-12 02:57:22 --> Loader Class Initialized
INFO - 2022-12-12 02:57:22 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:22 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:22 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:23 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:23 --> Total execution time: 0.0413
INFO - 2022-12-12 02:57:23 --> Config Class Initialized
INFO - 2022-12-12 02:57:23 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:23 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:23 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:23 --> URI Class Initialized
INFO - 2022-12-12 02:57:23 --> Router Class Initialized
INFO - 2022-12-12 02:57:23 --> Output Class Initialized
INFO - 2022-12-12 02:57:23 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:23 --> Input Class Initialized
INFO - 2022-12-12 02:57:23 --> Language Class Initialized
INFO - 2022-12-12 02:57:23 --> Loader Class Initialized
INFO - 2022-12-12 02:57:23 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:23 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:23 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:23 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:23 --> Total execution time: 0.0609
INFO - 2022-12-12 02:57:24 --> Config Class Initialized
INFO - 2022-12-12 02:57:24 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:24 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:24 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:24 --> URI Class Initialized
INFO - 2022-12-12 02:57:24 --> Router Class Initialized
INFO - 2022-12-12 02:57:24 --> Output Class Initialized
INFO - 2022-12-12 02:57:24 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:24 --> Input Class Initialized
INFO - 2022-12-12 02:57:24 --> Language Class Initialized
INFO - 2022-12-12 02:57:24 --> Loader Class Initialized
INFO - 2022-12-12 02:57:24 --> Config Class Initialized
INFO - 2022-12-12 02:57:24 --> Hooks Class Initialized
INFO - 2022-12-12 02:57:24 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 02:57:24 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:24 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:24 --> URI Class Initialized
INFO - 2022-12-12 02:57:24 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:24 --> Router Class Initialized
INFO - 2022-12-12 02:57:24 --> Output Class Initialized
INFO - 2022-12-12 02:57:24 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:24 --> Input Class Initialized
INFO - 2022-12-12 02:57:24 --> Language Class Initialized
INFO - 2022-12-12 02:57:24 --> Loader Class Initialized
INFO - 2022-12-12 02:57:24 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:24 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:24 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:24 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:24 --> Total execution time: 0.0789
INFO - 2022-12-12 02:57:24 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:24 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:24 --> Total execution time: 0.0878
INFO - 2022-12-12 02:57:24 --> Config Class Initialized
INFO - 2022-12-12 02:57:24 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:24 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:24 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:24 --> URI Class Initialized
INFO - 2022-12-12 02:57:24 --> Router Class Initialized
INFO - 2022-12-12 02:57:24 --> Output Class Initialized
INFO - 2022-12-12 02:57:24 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:24 --> Input Class Initialized
INFO - 2022-12-12 02:57:24 --> Language Class Initialized
INFO - 2022-12-12 02:57:24 --> Loader Class Initialized
INFO - 2022-12-12 02:57:24 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:24 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:24 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:24 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:24 --> Total execution time: 0.0531
INFO - 2022-12-12 02:57:27 --> Config Class Initialized
INFO - 2022-12-12 02:57:27 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:27 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:27 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:27 --> URI Class Initialized
INFO - 2022-12-12 02:57:27 --> Router Class Initialized
INFO - 2022-12-12 02:57:27 --> Output Class Initialized
INFO - 2022-12-12 02:57:27 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:27 --> Input Class Initialized
INFO - 2022-12-12 02:57:27 --> Language Class Initialized
INFO - 2022-12-12 02:57:27 --> Loader Class Initialized
INFO - 2022-12-12 02:57:27 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:27 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:27 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:27 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:27 --> Total execution time: 0.2717
INFO - 2022-12-12 02:57:27 --> Config Class Initialized
INFO - 2022-12-12 02:57:27 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:27 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:27 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:27 --> URI Class Initialized
INFO - 2022-12-12 02:57:27 --> Router Class Initialized
INFO - 2022-12-12 02:57:27 --> Output Class Initialized
INFO - 2022-12-12 02:57:27 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:27 --> Input Class Initialized
INFO - 2022-12-12 02:57:27 --> Language Class Initialized
INFO - 2022-12-12 02:57:27 --> Loader Class Initialized
INFO - 2022-12-12 02:57:27 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:27 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:27 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:27 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:27 --> Total execution time: 0.0470
INFO - 2022-12-12 02:57:29 --> Config Class Initialized
INFO - 2022-12-12 02:57:29 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:29 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:29 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:29 --> URI Class Initialized
INFO - 2022-12-12 02:57:29 --> Router Class Initialized
INFO - 2022-12-12 02:57:29 --> Output Class Initialized
INFO - 2022-12-12 02:57:29 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:29 --> Input Class Initialized
INFO - 2022-12-12 02:57:29 --> Language Class Initialized
INFO - 2022-12-12 02:57:29 --> Loader Class Initialized
INFO - 2022-12-12 02:57:29 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:29 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:29 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:29 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:29 --> Total execution time: 0.0502
INFO - 2022-12-12 02:57:29 --> Config Class Initialized
INFO - 2022-12-12 02:57:29 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:29 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:29 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:29 --> URI Class Initialized
INFO - 2022-12-12 02:57:29 --> Router Class Initialized
INFO - 2022-12-12 02:57:29 --> Output Class Initialized
INFO - 2022-12-12 02:57:29 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:29 --> Input Class Initialized
INFO - 2022-12-12 02:57:29 --> Language Class Initialized
INFO - 2022-12-12 02:57:29 --> Loader Class Initialized
INFO - 2022-12-12 02:57:29 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:29 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:29 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:29 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:29 --> Total execution time: 0.0601
INFO - 2022-12-12 02:57:31 --> Config Class Initialized
INFO - 2022-12-12 02:57:31 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:31 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:31 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:31 --> URI Class Initialized
INFO - 2022-12-12 02:57:31 --> Router Class Initialized
INFO - 2022-12-12 02:57:31 --> Output Class Initialized
INFO - 2022-12-12 02:57:31 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:31 --> Input Class Initialized
INFO - 2022-12-12 02:57:31 --> Language Class Initialized
INFO - 2022-12-12 02:57:31 --> Loader Class Initialized
INFO - 2022-12-12 02:57:31 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:31 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:31 --> Total execution time: 0.0302
INFO - 2022-12-12 02:57:31 --> Config Class Initialized
INFO - 2022-12-12 02:57:31 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:31 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:31 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:31 --> URI Class Initialized
INFO - 2022-12-12 02:57:31 --> Router Class Initialized
INFO - 2022-12-12 02:57:31 --> Output Class Initialized
INFO - 2022-12-12 02:57:31 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:31 --> Input Class Initialized
INFO - 2022-12-12 02:57:31 --> Language Class Initialized
INFO - 2022-12-12 02:57:31 --> Loader Class Initialized
INFO - 2022-12-12 02:57:31 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:31 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:31 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:31 --> Model "PGsql_model" initialized
INFO - 2022-12-12 02:57:31 --> Model "Grafana_model" initialized
ERROR - 2022-12-12 02:57:31 --> Exception of type 'TypeError' occurred with Message: count(): Argument #1 ($value) must be of type Countable|array, null given in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Grafana.php at Line 181
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Grafana->pgsqlDashboard()
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#2 {main}
INFO - 2022-12-12 02:57:39 --> Config Class Initialized
INFO - 2022-12-12 02:57:39 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:39 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:39 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:39 --> URI Class Initialized
INFO - 2022-12-12 02:57:39 --> Router Class Initialized
INFO - 2022-12-12 02:57:39 --> Output Class Initialized
INFO - 2022-12-12 02:57:39 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:39 --> Input Class Initialized
INFO - 2022-12-12 02:57:39 --> Language Class Initialized
INFO - 2022-12-12 02:57:39 --> Loader Class Initialized
INFO - 2022-12-12 02:57:39 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:39 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:39 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:39 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:39 --> Total execution time: 0.0727
INFO - 2022-12-12 02:57:39 --> Config Class Initialized
INFO - 2022-12-12 02:57:39 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:39 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:39 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:39 --> URI Class Initialized
INFO - 2022-12-12 02:57:39 --> Router Class Initialized
INFO - 2022-12-12 02:57:39 --> Output Class Initialized
INFO - 2022-12-12 02:57:39 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:39 --> Input Class Initialized
INFO - 2022-12-12 02:57:39 --> Language Class Initialized
INFO - 2022-12-12 02:57:39 --> Loader Class Initialized
INFO - 2022-12-12 02:57:39 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:39 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:39 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:39 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:39 --> Total execution time: 0.0412
INFO - 2022-12-12 02:57:40 --> Config Class Initialized
INFO - 2022-12-12 02:57:40 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:40 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:40 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:40 --> URI Class Initialized
INFO - 2022-12-12 02:57:40 --> Router Class Initialized
INFO - 2022-12-12 02:57:40 --> Output Class Initialized
INFO - 2022-12-12 02:57:40 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:40 --> Input Class Initialized
INFO - 2022-12-12 02:57:40 --> Language Class Initialized
INFO - 2022-12-12 02:57:40 --> Loader Class Initialized
INFO - 2022-12-12 02:57:40 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:40 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:40 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:40 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:40 --> Model "Login_model" initialized
INFO - 2022-12-12 02:57:40 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:40 --> Total execution time: 0.3287
INFO - 2022-12-12 02:57:40 --> Config Class Initialized
INFO - 2022-12-12 02:57:40 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:40 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:40 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:40 --> URI Class Initialized
INFO - 2022-12-12 02:57:40 --> Router Class Initialized
INFO - 2022-12-12 02:57:40 --> Output Class Initialized
INFO - 2022-12-12 02:57:40 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:40 --> Input Class Initialized
INFO - 2022-12-12 02:57:40 --> Language Class Initialized
INFO - 2022-12-12 02:57:40 --> Loader Class Initialized
INFO - 2022-12-12 02:57:40 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:40 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:40 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:40 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:40 --> Model "Login_model" initialized
INFO - 2022-12-12 02:57:40 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:40 --> Total execution time: 0.1322
INFO - 2022-12-12 02:57:41 --> Config Class Initialized
INFO - 2022-12-12 02:57:41 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:41 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:41 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:41 --> URI Class Initialized
INFO - 2022-12-12 02:57:41 --> Router Class Initialized
INFO - 2022-12-12 02:57:41 --> Output Class Initialized
INFO - 2022-12-12 02:57:41 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:41 --> Input Class Initialized
INFO - 2022-12-12 02:57:41 --> Language Class Initialized
INFO - 2022-12-12 02:57:41 --> Loader Class Initialized
INFO - 2022-12-12 02:57:41 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:41 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:41 --> Total execution time: 0.0258
INFO - 2022-12-12 02:57:41 --> Config Class Initialized
INFO - 2022-12-12 02:57:41 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:41 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:41 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:41 --> URI Class Initialized
INFO - 2022-12-12 02:57:41 --> Router Class Initialized
INFO - 2022-12-12 02:57:41 --> Output Class Initialized
INFO - 2022-12-12 02:57:41 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:41 --> Input Class Initialized
INFO - 2022-12-12 02:57:41 --> Language Class Initialized
INFO - 2022-12-12 02:57:41 --> Loader Class Initialized
INFO - 2022-12-12 02:57:41 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:41 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:41 --> Model "Login_model" initialized
INFO - 2022-12-12 02:57:41 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:41 --> Model "Cluster_model" initialized
ERROR - 2022-12-12 02:57:41 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php 1048
ERROR - 2022-12-12 02:57:41 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 324
ERROR - 2022-12-12 02:57:41 --> Severity: 8192 --> mysqli::query(): Passing null to parameter #1 ($query) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2022-12-12 02:57:41 --> Exception of type 'ValueError' occurred with Message: mysqli::query(): Argument #1 ($query) cannot be empty in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php at Line 307
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php(307): mysqli->query('')
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(791): CI_DB_mysqli_driver->_execute(NULL)
#2 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(654): CI_DB_driver->simple_query(NULL)
#3 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\models\Cluster_model.php(21): CI_DB_driver->query(NULL)
#4 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Cluster.php(1271): Cluster_model->getList(NULL)
#5 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Cluster->getEffectCluster()
#6 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#7 {main}
INFO - 2022-12-12 02:57:44 --> Config Class Initialized
INFO - 2022-12-12 02:57:44 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:44 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:44 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:44 --> URI Class Initialized
INFO - 2022-12-12 02:57:44 --> Router Class Initialized
INFO - 2022-12-12 02:57:44 --> Output Class Initialized
INFO - 2022-12-12 02:57:44 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:44 --> Input Class Initialized
INFO - 2022-12-12 02:57:44 --> Language Class Initialized
INFO - 2022-12-12 02:57:44 --> Loader Class Initialized
INFO - 2022-12-12 02:57:44 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:44 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:44 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:44 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:44 --> Total execution time: 0.0706
INFO - 2022-12-12 02:57:44 --> Config Class Initialized
INFO - 2022-12-12 02:57:44 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:44 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:44 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:44 --> URI Class Initialized
INFO - 2022-12-12 02:57:44 --> Router Class Initialized
INFO - 2022-12-12 02:57:44 --> Output Class Initialized
INFO - 2022-12-12 02:57:44 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:44 --> Input Class Initialized
INFO - 2022-12-12 02:57:44 --> Language Class Initialized
INFO - 2022-12-12 02:57:44 --> Loader Class Initialized
INFO - 2022-12-12 02:57:44 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:44 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:44 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:44 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:44 --> Total execution time: 0.0384
INFO - 2022-12-12 02:57:45 --> Config Class Initialized
INFO - 2022-12-12 02:57:45 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:45 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:45 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:45 --> URI Class Initialized
INFO - 2022-12-12 02:57:45 --> Router Class Initialized
INFO - 2022-12-12 02:57:45 --> Output Class Initialized
INFO - 2022-12-12 02:57:45 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:45 --> Input Class Initialized
INFO - 2022-12-12 02:57:45 --> Language Class Initialized
INFO - 2022-12-12 02:57:45 --> Loader Class Initialized
INFO - 2022-12-12 02:57:45 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:45 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:45 --> Model "Login_model" initialized
INFO - 2022-12-12 02:57:45 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:45 --> Model "Cluster_model" initialized
ERROR - 2022-12-12 02:57:45 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php 1048
ERROR - 2022-12-12 02:57:45 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 324
ERROR - 2022-12-12 02:57:45 --> Severity: 8192 --> mysqli::query(): Passing null to parameter #1 ($query) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2022-12-12 02:57:45 --> Exception of type 'ValueError' occurred with Message: mysqli::query(): Argument #1 ($query) cannot be empty in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php at Line 307
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php(307): mysqli->query('')
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(791): CI_DB_mysqli_driver->_execute(NULL)
#2 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(654): CI_DB_driver->simple_query(NULL)
#3 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\models\Cluster_model.php(21): CI_DB_driver->query(NULL)
#4 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Cluster.php(1271): Cluster_model->getList(NULL)
#5 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Cluster->getEffectCluster()
#6 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#7 {main}
INFO - 2022-12-12 02:57:45 --> Config Class Initialized
INFO - 2022-12-12 02:57:45 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:45 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:45 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:45 --> URI Class Initialized
INFO - 2022-12-12 02:57:45 --> Router Class Initialized
INFO - 2022-12-12 02:57:45 --> Output Class Initialized
INFO - 2022-12-12 02:57:45 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:45 --> Input Class Initialized
INFO - 2022-12-12 02:57:45 --> Language Class Initialized
INFO - 2022-12-12 02:57:45 --> Loader Class Initialized
INFO - 2022-12-12 02:57:45 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:45 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:45 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:45 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:45 --> Model "Login_model" initialized
INFO - 2022-12-12 02:57:46 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:46 --> Total execution time: 0.3919
INFO - 2022-12-12 02:57:46 --> Config Class Initialized
INFO - 2022-12-12 02:57:46 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:46 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:46 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:46 --> URI Class Initialized
INFO - 2022-12-12 02:57:46 --> Router Class Initialized
INFO - 2022-12-12 02:57:46 --> Output Class Initialized
INFO - 2022-12-12 02:57:46 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:46 --> Input Class Initialized
INFO - 2022-12-12 02:57:46 --> Language Class Initialized
INFO - 2022-12-12 02:57:46 --> Loader Class Initialized
INFO - 2022-12-12 02:57:46 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:46 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:46 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:46 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:46 --> Model "Login_model" initialized
INFO - 2022-12-12 02:57:46 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:46 --> Total execution time: 0.1526
INFO - 2022-12-12 02:57:47 --> Config Class Initialized
INFO - 2022-12-12 02:57:47 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:47 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:47 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:47 --> URI Class Initialized
INFO - 2022-12-12 02:57:47 --> Router Class Initialized
INFO - 2022-12-12 02:57:47 --> Output Class Initialized
INFO - 2022-12-12 02:57:47 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:47 --> Input Class Initialized
INFO - 2022-12-12 02:57:47 --> Language Class Initialized
INFO - 2022-12-12 02:57:47 --> Loader Class Initialized
INFO - 2022-12-12 02:57:47 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:47 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:47 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:47 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:47 --> Total execution time: 0.0402
INFO - 2022-12-12 02:57:47 --> Config Class Initialized
INFO - 2022-12-12 02:57:47 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:47 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:47 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:47 --> URI Class Initialized
INFO - 2022-12-12 02:57:47 --> Router Class Initialized
INFO - 2022-12-12 02:57:47 --> Output Class Initialized
INFO - 2022-12-12 02:57:47 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:47 --> Input Class Initialized
INFO - 2022-12-12 02:57:47 --> Language Class Initialized
INFO - 2022-12-12 02:57:47 --> Loader Class Initialized
INFO - 2022-12-12 02:57:47 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:47 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:47 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:47 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:47 --> Total execution time: 0.0585
INFO - 2022-12-12 02:57:51 --> Config Class Initialized
INFO - 2022-12-12 02:57:51 --> Config Class Initialized
INFO - 2022-12-12 02:57:51 --> Hooks Class Initialized
INFO - 2022-12-12 02:57:51 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 02:57:51 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:51 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:51 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:51 --> URI Class Initialized
INFO - 2022-12-12 02:57:51 --> URI Class Initialized
INFO - 2022-12-12 02:57:51 --> Router Class Initialized
INFO - 2022-12-12 02:57:51 --> Router Class Initialized
INFO - 2022-12-12 02:57:51 --> Output Class Initialized
INFO - 2022-12-12 02:57:51 --> Output Class Initialized
INFO - 2022-12-12 02:57:51 --> Security Class Initialized
INFO - 2022-12-12 02:57:51 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:51 --> Input Class Initialized
DEBUG - 2022-12-12 02:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:51 --> Input Class Initialized
INFO - 2022-12-12 02:57:51 --> Language Class Initialized
INFO - 2022-12-12 02:57:51 --> Language Class Initialized
INFO - 2022-12-12 02:57:51 --> Loader Class Initialized
INFO - 2022-12-12 02:57:51 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:51 --> Final output sent to browser
INFO - 2022-12-12 02:57:51 --> Loader Class Initialized
DEBUG - 2022-12-12 02:57:51 --> Total execution time: 0.0232
INFO - 2022-12-12 02:57:51 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:51 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:51 --> Config Class Initialized
INFO - 2022-12-12 02:57:51 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:51 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:51 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:51 --> URI Class Initialized
INFO - 2022-12-12 02:57:51 --> Router Class Initialized
INFO - 2022-12-12 02:57:51 --> Output Class Initialized
INFO - 2022-12-12 02:57:51 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:51 --> Input Class Initialized
INFO - 2022-12-12 02:57:51 --> Language Class Initialized
INFO - 2022-12-12 02:57:51 --> Loader Class Initialized
INFO - 2022-12-12 02:57:51 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:51 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:51 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:51 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:51 --> Total execution time: 0.0633
INFO - 2022-12-12 02:57:51 --> Config Class Initialized
INFO - 2022-12-12 02:57:51 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:57:51 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:57:51 --> Utf8 Class Initialized
INFO - 2022-12-12 02:57:51 --> URI Class Initialized
INFO - 2022-12-12 02:57:51 --> Router Class Initialized
INFO - 2022-12-12 02:57:51 --> Output Class Initialized
INFO - 2022-12-12 02:57:51 --> Security Class Initialized
DEBUG - 2022-12-12 02:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:57:51 --> Input Class Initialized
INFO - 2022-12-12 02:57:51 --> Language Class Initialized
INFO - 2022-12-12 02:57:51 --> Loader Class Initialized
INFO - 2022-12-12 02:57:51 --> Controller Class Initialized
DEBUG - 2022-12-12 02:57:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:57:51 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:51 --> Model "Login_model" initialized
INFO - 2022-12-12 02:57:51 --> Database Driver Class Initialized
INFO - 2022-12-12 02:57:51 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:51 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:51 --> Total execution time: 0.0416
INFO - 2022-12-12 02:57:51 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:57:51 --> Final output sent to browser
DEBUG - 2022-12-12 02:57:51 --> Total execution time: 0.1304
INFO - 2022-12-12 02:58:11 --> Config Class Initialized
INFO - 2022-12-12 02:58:11 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:11 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:11 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:11 --> URI Class Initialized
INFO - 2022-12-12 02:58:11 --> Router Class Initialized
INFO - 2022-12-12 02:58:11 --> Output Class Initialized
INFO - 2022-12-12 02:58:11 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:11 --> Input Class Initialized
INFO - 2022-12-12 02:58:11 --> Language Class Initialized
INFO - 2022-12-12 02:58:11 --> Loader Class Initialized
INFO - 2022-12-12 02:58:11 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:11 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:11 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:11 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:11 --> Total execution time: 0.0657
INFO - 2022-12-12 02:58:11 --> Config Class Initialized
INFO - 2022-12-12 02:58:11 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:11 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:11 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:11 --> URI Class Initialized
INFO - 2022-12-12 02:58:11 --> Router Class Initialized
INFO - 2022-12-12 02:58:11 --> Output Class Initialized
INFO - 2022-12-12 02:58:11 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:11 --> Input Class Initialized
INFO - 2022-12-12 02:58:11 --> Language Class Initialized
INFO - 2022-12-12 02:58:11 --> Loader Class Initialized
INFO - 2022-12-12 02:58:11 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:11 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:11 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:11 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:11 --> Total execution time: 0.0534
INFO - 2022-12-12 02:58:12 --> Config Class Initialized
INFO - 2022-12-12 02:58:12 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:12 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:12 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:12 --> URI Class Initialized
INFO - 2022-12-12 02:58:12 --> Router Class Initialized
INFO - 2022-12-12 02:58:12 --> Output Class Initialized
INFO - 2022-12-12 02:58:12 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:12 --> Input Class Initialized
INFO - 2022-12-12 02:58:12 --> Language Class Initialized
INFO - 2022-12-12 02:58:12 --> Loader Class Initialized
INFO - 2022-12-12 02:58:12 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:12 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:12 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:12 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:12 --> Model "Login_model" initialized
INFO - 2022-12-12 02:58:12 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:12 --> Total execution time: 0.2629
INFO - 2022-12-12 02:58:12 --> Config Class Initialized
INFO - 2022-12-12 02:58:12 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:12 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:12 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:12 --> URI Class Initialized
INFO - 2022-12-12 02:58:12 --> Router Class Initialized
INFO - 2022-12-12 02:58:12 --> Output Class Initialized
INFO - 2022-12-12 02:58:12 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:12 --> Input Class Initialized
INFO - 2022-12-12 02:58:12 --> Language Class Initialized
INFO - 2022-12-12 02:58:12 --> Loader Class Initialized
INFO - 2022-12-12 02:58:12 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:12 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:12 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:12 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:12 --> Model "Login_model" initialized
INFO - 2022-12-12 02:58:12 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:12 --> Total execution time: 0.1377
INFO - 2022-12-12 02:58:16 --> Config Class Initialized
INFO - 2022-12-12 02:58:16 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:16 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:16 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:16 --> URI Class Initialized
INFO - 2022-12-12 02:58:16 --> Router Class Initialized
INFO - 2022-12-12 02:58:16 --> Output Class Initialized
INFO - 2022-12-12 02:58:16 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:16 --> Input Class Initialized
INFO - 2022-12-12 02:58:16 --> Language Class Initialized
INFO - 2022-12-12 02:58:16 --> Loader Class Initialized
INFO - 2022-12-12 02:58:16 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:16 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:16 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:16 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:16 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:16 --> Total execution time: 0.0597
INFO - 2022-12-12 02:58:16 --> Config Class Initialized
INFO - 2022-12-12 02:58:16 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:16 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:16 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:16 --> URI Class Initialized
INFO - 2022-12-12 02:58:16 --> Router Class Initialized
INFO - 2022-12-12 02:58:16 --> Output Class Initialized
INFO - 2022-12-12 02:58:16 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:16 --> Input Class Initialized
INFO - 2022-12-12 02:58:16 --> Language Class Initialized
INFO - 2022-12-12 02:58:16 --> Loader Class Initialized
INFO - 2022-12-12 02:58:16 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:16 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:16 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:16 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:16 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:16 --> Total execution time: 0.0527
INFO - 2022-12-12 02:58:19 --> Config Class Initialized
INFO - 2022-12-12 02:58:19 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:19 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:19 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:20 --> URI Class Initialized
INFO - 2022-12-12 02:58:20 --> Router Class Initialized
INFO - 2022-12-12 02:58:20 --> Output Class Initialized
INFO - 2022-12-12 02:58:20 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:20 --> Input Class Initialized
INFO - 2022-12-12 02:58:20 --> Language Class Initialized
INFO - 2022-12-12 02:58:20 --> Loader Class Initialized
INFO - 2022-12-12 02:58:20 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:20 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:20 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:20 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:20 --> Total execution time: 0.0508
INFO - 2022-12-12 02:58:20 --> Config Class Initialized
INFO - 2022-12-12 02:58:20 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:20 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:20 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:20 --> URI Class Initialized
INFO - 2022-12-12 02:58:20 --> Router Class Initialized
INFO - 2022-12-12 02:58:20 --> Output Class Initialized
INFO - 2022-12-12 02:58:20 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:20 --> Input Class Initialized
INFO - 2022-12-12 02:58:20 --> Language Class Initialized
INFO - 2022-12-12 02:58:20 --> Loader Class Initialized
INFO - 2022-12-12 02:58:20 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:20 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:20 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:20 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:20 --> Total execution time: 0.0412
INFO - 2022-12-12 02:58:22 --> Config Class Initialized
INFO - 2022-12-12 02:58:22 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:22 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:22 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:22 --> URI Class Initialized
INFO - 2022-12-12 02:58:22 --> Router Class Initialized
INFO - 2022-12-12 02:58:22 --> Output Class Initialized
INFO - 2022-12-12 02:58:22 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:22 --> Input Class Initialized
INFO - 2022-12-12 02:58:22 --> Language Class Initialized
INFO - 2022-12-12 02:58:22 --> Loader Class Initialized
INFO - 2022-12-12 02:58:22 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:22 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:22 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:22 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:22 --> Total execution time: 0.0567
INFO - 2022-12-12 02:58:22 --> Config Class Initialized
INFO - 2022-12-12 02:58:22 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:22 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:22 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:22 --> URI Class Initialized
INFO - 2022-12-12 02:58:22 --> Router Class Initialized
INFO - 2022-12-12 02:58:22 --> Output Class Initialized
INFO - 2022-12-12 02:58:22 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:22 --> Input Class Initialized
INFO - 2022-12-12 02:58:22 --> Language Class Initialized
INFO - 2022-12-12 02:58:22 --> Loader Class Initialized
INFO - 2022-12-12 02:58:22 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:22 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:22 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:22 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:22 --> Total execution time: 0.0545
INFO - 2022-12-12 02:58:25 --> Config Class Initialized
INFO - 2022-12-12 02:58:25 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:25 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:25 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:25 --> URI Class Initialized
INFO - 2022-12-12 02:58:25 --> Router Class Initialized
INFO - 2022-12-12 02:58:25 --> Output Class Initialized
INFO - 2022-12-12 02:58:25 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:25 --> Input Class Initialized
INFO - 2022-12-12 02:58:25 --> Language Class Initialized
INFO - 2022-12-12 02:58:25 --> Loader Class Initialized
INFO - 2022-12-12 02:58:25 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:25 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:25 --> Total execution time: 0.0227
INFO - 2022-12-12 02:58:25 --> Config Class Initialized
INFO - 2022-12-12 02:58:25 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:25 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:25 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:25 --> URI Class Initialized
INFO - 2022-12-12 02:58:25 --> Router Class Initialized
INFO - 2022-12-12 02:58:25 --> Output Class Initialized
INFO - 2022-12-12 02:58:25 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:25 --> Input Class Initialized
INFO - 2022-12-12 02:58:25 --> Language Class Initialized
INFO - 2022-12-12 02:58:25 --> Loader Class Initialized
INFO - 2022-12-12 02:58:25 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:25 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:25 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:25 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:25 --> Total execution time: 0.0426
INFO - 2022-12-12 02:58:27 --> Config Class Initialized
INFO - 2022-12-12 02:58:27 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:27 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:27 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:27 --> URI Class Initialized
INFO - 2022-12-12 02:58:27 --> Router Class Initialized
INFO - 2022-12-12 02:58:27 --> Output Class Initialized
INFO - 2022-12-12 02:58:27 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:27 --> Input Class Initialized
INFO - 2022-12-12 02:58:27 --> Language Class Initialized
INFO - 2022-12-12 02:58:27 --> Loader Class Initialized
INFO - 2022-12-12 02:58:27 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:27 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:27 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:27 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:27 --> Total execution time: 0.0683
INFO - 2022-12-12 02:58:27 --> Config Class Initialized
INFO - 2022-12-12 02:58:27 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:27 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:27 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:27 --> URI Class Initialized
INFO - 2022-12-12 02:58:27 --> Router Class Initialized
INFO - 2022-12-12 02:58:27 --> Output Class Initialized
INFO - 2022-12-12 02:58:27 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:27 --> Input Class Initialized
INFO - 2022-12-12 02:58:27 --> Language Class Initialized
INFO - 2022-12-12 02:58:27 --> Loader Class Initialized
INFO - 2022-12-12 02:58:27 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:27 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:27 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:27 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:27 --> Total execution time: 0.0414
INFO - 2022-12-12 02:58:29 --> Config Class Initialized
INFO - 2022-12-12 02:58:29 --> Config Class Initialized
INFO - 2022-12-12 02:58:29 --> Hooks Class Initialized
INFO - 2022-12-12 02:58:29 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:29 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:29 --> Utf8 Class Initialized
DEBUG - 2022-12-12 02:58:29 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:29 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:29 --> URI Class Initialized
INFO - 2022-12-12 02:58:29 --> URI Class Initialized
INFO - 2022-12-12 02:58:29 --> Router Class Initialized
INFO - 2022-12-12 02:58:29 --> Router Class Initialized
INFO - 2022-12-12 02:58:29 --> Output Class Initialized
INFO - 2022-12-12 02:58:29 --> Output Class Initialized
INFO - 2022-12-12 02:58:29 --> Security Class Initialized
INFO - 2022-12-12 02:58:29 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:29 --> Input Class Initialized
DEBUG - 2022-12-12 02:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:29 --> Language Class Initialized
INFO - 2022-12-12 02:58:29 --> Input Class Initialized
INFO - 2022-12-12 02:58:29 --> Language Class Initialized
INFO - 2022-12-12 02:58:29 --> Loader Class Initialized
INFO - 2022-12-12 02:58:29 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:29 --> Loader Class Initialized
INFO - 2022-12-12 02:58:29 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:29 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:29 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:29 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:29 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:29 --> Final output sent to browser
INFO - 2022-12-12 02:58:29 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:29 --> Total execution time: 0.0535
DEBUG - 2022-12-12 02:58:29 --> Total execution time: 0.0531
INFO - 2022-12-12 02:58:29 --> Config Class Initialized
INFO - 2022-12-12 02:58:29 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:29 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:29 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:29 --> URI Class Initialized
INFO - 2022-12-12 02:58:29 --> Router Class Initialized
INFO - 2022-12-12 02:58:29 --> Output Class Initialized
INFO - 2022-12-12 02:58:29 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:29 --> Input Class Initialized
INFO - 2022-12-12 02:58:29 --> Language Class Initialized
INFO - 2022-12-12 02:58:29 --> Loader Class Initialized
INFO - 2022-12-12 02:58:29 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:29 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:29 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:29 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:29 --> Total execution time: 0.0531
INFO - 2022-12-12 02:58:33 --> Config Class Initialized
INFO - 2022-12-12 02:58:33 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:33 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:33 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:33 --> URI Class Initialized
INFO - 2022-12-12 02:58:33 --> Router Class Initialized
INFO - 2022-12-12 02:58:33 --> Output Class Initialized
INFO - 2022-12-12 02:58:33 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:33 --> Input Class Initialized
INFO - 2022-12-12 02:58:33 --> Language Class Initialized
INFO - 2022-12-12 02:58:33 --> Loader Class Initialized
INFO - 2022-12-12 02:58:33 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:33 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:33 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:33 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:33 --> Total execution time: 0.2705
INFO - 2022-12-12 02:58:33 --> Config Class Initialized
INFO - 2022-12-12 02:58:33 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:33 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:33 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:33 --> URI Class Initialized
INFO - 2022-12-12 02:58:33 --> Router Class Initialized
INFO - 2022-12-12 02:58:33 --> Output Class Initialized
INFO - 2022-12-12 02:58:33 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:33 --> Input Class Initialized
INFO - 2022-12-12 02:58:33 --> Language Class Initialized
INFO - 2022-12-12 02:58:33 --> Loader Class Initialized
INFO - 2022-12-12 02:58:33 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:33 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:33 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:33 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:33 --> Total execution time: 0.0433
INFO - 2022-12-12 02:58:39 --> Config Class Initialized
INFO - 2022-12-12 02:58:39 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:39 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:39 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:39 --> URI Class Initialized
INFO - 2022-12-12 02:58:39 --> Router Class Initialized
INFO - 2022-12-12 02:58:39 --> Output Class Initialized
INFO - 2022-12-12 02:58:39 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:39 --> Input Class Initialized
INFO - 2022-12-12 02:58:39 --> Language Class Initialized
INFO - 2022-12-12 02:58:39 --> Loader Class Initialized
INFO - 2022-12-12 02:58:39 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:39 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:39 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:39 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:39 --> Total execution time: 0.0679
INFO - 2022-12-12 02:58:40 --> Config Class Initialized
INFO - 2022-12-12 02:58:40 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:40 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:40 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:40 --> URI Class Initialized
INFO - 2022-12-12 02:58:40 --> Router Class Initialized
INFO - 2022-12-12 02:58:40 --> Output Class Initialized
INFO - 2022-12-12 02:58:40 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:40 --> Input Class Initialized
INFO - 2022-12-12 02:58:40 --> Language Class Initialized
INFO - 2022-12-12 02:58:40 --> Loader Class Initialized
INFO - 2022-12-12 02:58:40 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:40 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:40 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:40 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:40 --> Total execution time: 0.0575
INFO - 2022-12-12 02:58:44 --> Config Class Initialized
INFO - 2022-12-12 02:58:44 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:44 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:44 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:44 --> URI Class Initialized
INFO - 2022-12-12 02:58:44 --> Router Class Initialized
INFO - 2022-12-12 02:58:44 --> Output Class Initialized
INFO - 2022-12-12 02:58:44 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:44 --> Input Class Initialized
INFO - 2022-12-12 02:58:44 --> Language Class Initialized
INFO - 2022-12-12 02:58:44 --> Loader Class Initialized
INFO - 2022-12-12 02:58:44 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:44 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:44 --> Total execution time: 0.0235
INFO - 2022-12-12 02:58:44 --> Config Class Initialized
INFO - 2022-12-12 02:58:44 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:44 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:44 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:44 --> URI Class Initialized
INFO - 2022-12-12 02:58:44 --> Router Class Initialized
INFO - 2022-12-12 02:58:44 --> Output Class Initialized
INFO - 2022-12-12 02:58:44 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:44 --> Input Class Initialized
INFO - 2022-12-12 02:58:44 --> Language Class Initialized
INFO - 2022-12-12 02:58:44 --> Loader Class Initialized
INFO - 2022-12-12 02:58:44 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:44 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:44 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:44 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:44 --> Total execution time: 0.0456
INFO - 2022-12-12 02:58:48 --> Config Class Initialized
INFO - 2022-12-12 02:58:48 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:48 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:48 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:48 --> URI Class Initialized
INFO - 2022-12-12 02:58:48 --> Router Class Initialized
INFO - 2022-12-12 02:58:48 --> Output Class Initialized
INFO - 2022-12-12 02:58:48 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:48 --> Input Class Initialized
INFO - 2022-12-12 02:58:48 --> Language Class Initialized
INFO - 2022-12-12 02:58:48 --> Loader Class Initialized
INFO - 2022-12-12 02:58:48 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:48 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:48 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:48 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:48 --> Total execution time: 0.0398
INFO - 2022-12-12 02:58:54 --> Config Class Initialized
INFO - 2022-12-12 02:58:54 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:54 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:54 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:54 --> URI Class Initialized
INFO - 2022-12-12 02:58:54 --> Router Class Initialized
INFO - 2022-12-12 02:58:54 --> Output Class Initialized
INFO - 2022-12-12 02:58:54 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:54 --> Input Class Initialized
INFO - 2022-12-12 02:58:54 --> Language Class Initialized
INFO - 2022-12-12 02:58:54 --> Loader Class Initialized
INFO - 2022-12-12 02:58:54 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:54 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:54 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:54 --> Total execution time: 0.0237
INFO - 2022-12-12 02:58:54 --> Config Class Initialized
INFO - 2022-12-12 02:58:54 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:54 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:54 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:54 --> URI Class Initialized
INFO - 2022-12-12 02:58:54 --> Router Class Initialized
INFO - 2022-12-12 02:58:54 --> Output Class Initialized
INFO - 2022-12-12 02:58:54 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:54 --> Input Class Initialized
INFO - 2022-12-12 02:58:54 --> Language Class Initialized
INFO - 2022-12-12 02:58:54 --> Loader Class Initialized
INFO - 2022-12-12 02:58:54 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:54 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:54 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:54 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:54 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:54 --> Total execution time: 0.0400
INFO - 2022-12-12 02:58:59 --> Config Class Initialized
INFO - 2022-12-12 02:58:59 --> Hooks Class Initialized
INFO - 2022-12-12 02:58:59 --> Config Class Initialized
INFO - 2022-12-12 02:58:59 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 02:58:59 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:59 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:59 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:59 --> URI Class Initialized
INFO - 2022-12-12 02:58:59 --> URI Class Initialized
INFO - 2022-12-12 02:58:59 --> Router Class Initialized
INFO - 2022-12-12 02:58:59 --> Router Class Initialized
INFO - 2022-12-12 02:58:59 --> Output Class Initialized
INFO - 2022-12-12 02:58:59 --> Output Class Initialized
INFO - 2022-12-12 02:58:59 --> Security Class Initialized
INFO - 2022-12-12 02:58:59 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:59 --> Input Class Initialized
DEBUG - 2022-12-12 02:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:59 --> Input Class Initialized
INFO - 2022-12-12 02:58:59 --> Language Class Initialized
INFO - 2022-12-12 02:58:59 --> Language Class Initialized
INFO - 2022-12-12 02:58:59 --> Loader Class Initialized
INFO - 2022-12-12 02:58:59 --> Loader Class Initialized
INFO - 2022-12-12 02:58:59 --> Controller Class Initialized
INFO - 2022-12-12 02:58:59 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 02:58:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:59 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:59 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:59 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:59 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:58:59 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:59 --> Total execution time: 0.0595
INFO - 2022-12-12 02:58:59 --> Config Class Initialized
INFO - 2022-12-12 02:58:59 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:59 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:59 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:59 --> URI Class Initialized
INFO - 2022-12-12 02:58:59 --> Router Class Initialized
INFO - 2022-12-12 02:58:59 --> Output Class Initialized
INFO - 2022-12-12 02:58:59 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:59 --> Input Class Initialized
INFO - 2022-12-12 02:58:59 --> Language Class Initialized
INFO - 2022-12-12 02:58:59 --> Loader Class Initialized
INFO - 2022-12-12 02:58:59 --> Controller Class Initialized
DEBUG - 2022-12-12 02:58:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:59 --> Config Class Initialized
INFO - 2022-12-12 02:58:59 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:59 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:58:59 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:58:59 --> Utf8 Class Initialized
INFO - 2022-12-12 02:58:59 --> URI Class Initialized
INFO - 2022-12-12 02:58:59 --> Router Class Initialized
INFO - 2022-12-12 02:58:59 --> Output Class Initialized
INFO - 2022-12-12 02:58:59 --> Security Class Initialized
DEBUG - 2022-12-12 02:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:58:59 --> Input Class Initialized
INFO - 2022-12-12 02:58:59 --> Language Class Initialized
INFO - 2022-12-12 02:58:59 --> Loader Class Initialized
INFO - 2022-12-12 02:58:59 --> Controller Class Initialized
INFO - 2022-12-12 02:58:59 --> Model "Cluster_model" initialized
DEBUG - 2022-12-12 02:58:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:58:59 --> Final output sent to browser
DEBUG - 2022-12-12 02:58:59 --> Total execution time: 0.0454
INFO - 2022-12-12 02:58:59 --> Database Driver Class Initialized
INFO - 2022-12-12 02:58:59 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:59:05 --> Config Class Initialized
INFO - 2022-12-12 02:59:05 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:59:05 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:59:05 --> Utf8 Class Initialized
INFO - 2022-12-12 02:59:05 --> URI Class Initialized
INFO - 2022-12-12 02:59:05 --> Router Class Initialized
INFO - 2022-12-12 02:59:05 --> Output Class Initialized
INFO - 2022-12-12 02:59:05 --> Security Class Initialized
DEBUG - 2022-12-12 02:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:59:05 --> Input Class Initialized
INFO - 2022-12-12 02:59:05 --> Language Class Initialized
INFO - 2022-12-12 02:59:05 --> Loader Class Initialized
INFO - 2022-12-12 02:59:05 --> Controller Class Initialized
DEBUG - 2022-12-12 02:59:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:59:05 --> Database Driver Class Initialized
INFO - 2022-12-12 02:59:05 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:59:05 --> Config Class Initialized
INFO - 2022-12-12 02:59:05 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:59:05 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:59:05 --> Utf8 Class Initialized
INFO - 2022-12-12 02:59:05 --> URI Class Initialized
INFO - 2022-12-12 02:59:05 --> Router Class Initialized
INFO - 2022-12-12 02:59:05 --> Output Class Initialized
INFO - 2022-12-12 02:59:05 --> Security Class Initialized
DEBUG - 2022-12-12 02:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:59:05 --> Input Class Initialized
INFO - 2022-12-12 02:59:05 --> Language Class Initialized
INFO - 2022-12-12 02:59:05 --> Loader Class Initialized
INFO - 2022-12-12 02:59:05 --> Controller Class Initialized
DEBUG - 2022-12-12 02:59:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:59:05 --> Database Driver Class Initialized
INFO - 2022-12-12 02:59:05 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:59:06 --> Config Class Initialized
INFO - 2022-12-12 02:59:06 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:59:06 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:59:06 --> Utf8 Class Initialized
INFO - 2022-12-12 02:59:06 --> URI Class Initialized
INFO - 2022-12-12 02:59:06 --> Router Class Initialized
INFO - 2022-12-12 02:59:06 --> Output Class Initialized
INFO - 2022-12-12 02:59:06 --> Security Class Initialized
DEBUG - 2022-12-12 02:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:59:06 --> Input Class Initialized
INFO - 2022-12-12 02:59:06 --> Language Class Initialized
INFO - 2022-12-12 02:59:06 --> Loader Class Initialized
INFO - 2022-12-12 02:59:06 --> Controller Class Initialized
DEBUG - 2022-12-12 02:59:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:59:06 --> Database Driver Class Initialized
INFO - 2022-12-12 02:59:06 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:59:06 --> Config Class Initialized
INFO - 2022-12-12 02:59:06 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:59:06 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:59:06 --> Utf8 Class Initialized
INFO - 2022-12-12 02:59:06 --> URI Class Initialized
INFO - 2022-12-12 02:59:06 --> Router Class Initialized
INFO - 2022-12-12 02:59:06 --> Output Class Initialized
INFO - 2022-12-12 02:59:06 --> Security Class Initialized
DEBUG - 2022-12-12 02:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:59:06 --> Input Class Initialized
INFO - 2022-12-12 02:59:06 --> Language Class Initialized
INFO - 2022-12-12 02:59:06 --> Loader Class Initialized
INFO - 2022-12-12 02:59:06 --> Controller Class Initialized
DEBUG - 2022-12-12 02:59:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:59:06 --> Database Driver Class Initialized
INFO - 2022-12-12 02:59:06 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:59:09 --> Config Class Initialized
INFO - 2022-12-12 02:59:09 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:59:09 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:59:09 --> Utf8 Class Initialized
INFO - 2022-12-12 02:59:09 --> URI Class Initialized
INFO - 2022-12-12 02:59:09 --> Router Class Initialized
INFO - 2022-12-12 02:59:09 --> Output Class Initialized
INFO - 2022-12-12 02:59:09 --> Security Class Initialized
DEBUG - 2022-12-12 02:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:59:09 --> Input Class Initialized
INFO - 2022-12-12 02:59:09 --> Language Class Initialized
INFO - 2022-12-12 02:59:09 --> Loader Class Initialized
INFO - 2022-12-12 02:59:09 --> Controller Class Initialized
DEBUG - 2022-12-12 02:59:09 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:59:09 --> Database Driver Class Initialized
INFO - 2022-12-12 02:59:09 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:59:14 --> Config Class Initialized
INFO - 2022-12-12 02:59:14 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:59:14 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:59:14 --> Utf8 Class Initialized
INFO - 2022-12-12 02:59:14 --> URI Class Initialized
INFO - 2022-12-12 02:59:14 --> Router Class Initialized
INFO - 2022-12-12 02:59:14 --> Output Class Initialized
INFO - 2022-12-12 02:59:14 --> Security Class Initialized
DEBUG - 2022-12-12 02:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:59:14 --> Input Class Initialized
INFO - 2022-12-12 02:59:14 --> Language Class Initialized
INFO - 2022-12-12 02:59:14 --> Loader Class Initialized
INFO - 2022-12-12 02:59:14 --> Controller Class Initialized
DEBUG - 2022-12-12 02:59:14 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:59:14 --> Database Driver Class Initialized
INFO - 2022-12-12 02:59:14 --> Model "Cluster_model" initialized
INFO - 2022-12-12 02:59:14 --> Config Class Initialized
INFO - 2022-12-12 02:59:14 --> Hooks Class Initialized
DEBUG - 2022-12-12 02:59:14 --> UTF-8 Support Enabled
INFO - 2022-12-12 02:59:14 --> Utf8 Class Initialized
INFO - 2022-12-12 02:59:14 --> URI Class Initialized
INFO - 2022-12-12 02:59:14 --> Router Class Initialized
INFO - 2022-12-12 02:59:14 --> Output Class Initialized
INFO - 2022-12-12 02:59:14 --> Security Class Initialized
DEBUG - 2022-12-12 02:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 02:59:14 --> Input Class Initialized
INFO - 2022-12-12 02:59:14 --> Language Class Initialized
INFO - 2022-12-12 02:59:14 --> Loader Class Initialized
INFO - 2022-12-12 02:59:14 --> Controller Class Initialized
DEBUG - 2022-12-12 02:59:14 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 02:59:14 --> Database Driver Class Initialized
INFO - 2022-12-12 02:59:14 --> Model "Cluster_model" initialized
INFO - 2022-12-12 08:27:15 --> Config Class Initialized
INFO - 2022-12-12 08:27:15 --> Hooks Class Initialized
DEBUG - 2022-12-12 08:27:15 --> UTF-8 Support Enabled
INFO - 2022-12-12 08:27:15 --> Utf8 Class Initialized
INFO - 2022-12-12 08:27:15 --> URI Class Initialized
INFO - 2022-12-12 08:27:15 --> Router Class Initialized
INFO - 2022-12-12 08:27:15 --> Output Class Initialized
INFO - 2022-12-12 08:27:15 --> Security Class Initialized
DEBUG - 2022-12-12 08:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 08:27:15 --> Input Class Initialized
INFO - 2022-12-12 08:27:15 --> Language Class Initialized
INFO - 2022-12-12 08:27:15 --> Loader Class Initialized
INFO - 2022-12-12 08:27:15 --> Controller Class Initialized
INFO - 2022-12-12 08:27:15 --> Helper loaded: form_helper
INFO - 2022-12-12 08:27:15 --> Helper loaded: url_helper
DEBUG - 2022-12-12 08:27:15 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 08:27:15 --> Model "Change_model" initialized
INFO - 2022-12-12 08:27:15 --> Model "Grafana_model" initialized
INFO - 2022-12-12 08:27:15 --> Final output sent to browser
DEBUG - 2022-12-12 08:27:15 --> Total execution time: 0.0949
INFO - 2022-12-12 08:27:15 --> Config Class Initialized
INFO - 2022-12-12 08:27:15 --> Hooks Class Initialized
DEBUG - 2022-12-12 08:27:15 --> UTF-8 Support Enabled
INFO - 2022-12-12 08:27:15 --> Utf8 Class Initialized
INFO - 2022-12-12 08:27:15 --> URI Class Initialized
INFO - 2022-12-12 08:27:15 --> Router Class Initialized
INFO - 2022-12-12 08:27:15 --> Output Class Initialized
INFO - 2022-12-12 08:27:15 --> Security Class Initialized
DEBUG - 2022-12-12 08:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 08:27:15 --> Input Class Initialized
INFO - 2022-12-12 08:27:15 --> Language Class Initialized
INFO - 2022-12-12 08:27:15 --> Loader Class Initialized
INFO - 2022-12-12 08:27:15 --> Controller Class Initialized
INFO - 2022-12-12 08:27:15 --> Helper loaded: form_helper
INFO - 2022-12-12 08:27:15 --> Helper loaded: url_helper
DEBUG - 2022-12-12 08:27:15 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 08:27:15 --> Final output sent to browser
DEBUG - 2022-12-12 08:27:15 --> Total execution time: 0.0200
INFO - 2022-12-12 08:27:15 --> Config Class Initialized
INFO - 2022-12-12 08:27:15 --> Hooks Class Initialized
DEBUG - 2022-12-12 08:27:15 --> UTF-8 Support Enabled
INFO - 2022-12-12 08:27:15 --> Utf8 Class Initialized
INFO - 2022-12-12 08:27:15 --> URI Class Initialized
INFO - 2022-12-12 08:27:15 --> Router Class Initialized
INFO - 2022-12-12 08:27:15 --> Output Class Initialized
INFO - 2022-12-12 08:27:15 --> Security Class Initialized
DEBUG - 2022-12-12 08:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 08:27:15 --> Input Class Initialized
INFO - 2022-12-12 08:27:15 --> Language Class Initialized
INFO - 2022-12-12 08:27:15 --> Loader Class Initialized
INFO - 2022-12-12 08:27:15 --> Controller Class Initialized
INFO - 2022-12-12 08:27:15 --> Helper loaded: form_helper
INFO - 2022-12-12 08:27:15 --> Helper loaded: url_helper
DEBUG - 2022-12-12 08:27:15 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 08:27:15 --> Database Driver Class Initialized
INFO - 2022-12-12 08:27:15 --> Model "Login_model" initialized
INFO - 2022-12-12 08:27:15 --> Final output sent to browser
DEBUG - 2022-12-12 08:27:15 --> Total execution time: 0.0432
INFO - 2022-12-12 08:27:15 --> Config Class Initialized
INFO - 2022-12-12 08:27:15 --> Hooks Class Initialized
DEBUG - 2022-12-12 08:27:15 --> UTF-8 Support Enabled
INFO - 2022-12-12 08:27:15 --> Utf8 Class Initialized
INFO - 2022-12-12 08:27:15 --> URI Class Initialized
INFO - 2022-12-12 08:27:15 --> Router Class Initialized
INFO - 2022-12-12 08:27:15 --> Output Class Initialized
INFO - 2022-12-12 08:27:15 --> Security Class Initialized
DEBUG - 2022-12-12 08:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 08:27:15 --> Input Class Initialized
INFO - 2022-12-12 08:27:15 --> Language Class Initialized
INFO - 2022-12-12 08:27:15 --> Loader Class Initialized
INFO - 2022-12-12 08:27:15 --> Controller Class Initialized
DEBUG - 2022-12-12 08:27:15 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 08:27:15 --> Database Driver Class Initialized
INFO - 2022-12-12 08:27:15 --> Model "Cluster_model" initialized
INFO - 2022-12-12 08:27:15 --> Final output sent to browser
DEBUG - 2022-12-12 08:27:15 --> Total execution time: 0.0658
INFO - 2022-12-12 08:27:15 --> Config Class Initialized
INFO - 2022-12-12 08:27:15 --> Hooks Class Initialized
DEBUG - 2022-12-12 08:27:15 --> UTF-8 Support Enabled
INFO - 2022-12-12 08:27:15 --> Utf8 Class Initialized
INFO - 2022-12-12 08:27:15 --> URI Class Initialized
INFO - 2022-12-12 08:27:15 --> Router Class Initialized
INFO - 2022-12-12 08:27:15 --> Output Class Initialized
INFO - 2022-12-12 08:27:15 --> Security Class Initialized
DEBUG - 2022-12-12 08:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 08:27:15 --> Input Class Initialized
INFO - 2022-12-12 08:27:15 --> Language Class Initialized
INFO - 2022-12-12 08:27:15 --> Loader Class Initialized
INFO - 2022-12-12 08:27:15 --> Controller Class Initialized
DEBUG - 2022-12-12 08:27:15 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 08:27:15 --> Database Driver Class Initialized
INFO - 2022-12-12 08:27:15 --> Model "Cluster_model" initialized
INFO - 2022-12-12 08:27:15 --> Final output sent to browser
DEBUG - 2022-12-12 08:27:15 --> Total execution time: 0.0458
INFO - 2022-12-12 08:27:16 --> Config Class Initialized
INFO - 2022-12-12 08:27:16 --> Hooks Class Initialized
DEBUG - 2022-12-12 08:27:16 --> UTF-8 Support Enabled
INFO - 2022-12-12 08:27:16 --> Utf8 Class Initialized
INFO - 2022-12-12 08:27:16 --> URI Class Initialized
INFO - 2022-12-12 08:27:16 --> Router Class Initialized
INFO - 2022-12-12 08:27:16 --> Output Class Initialized
INFO - 2022-12-12 08:27:16 --> Security Class Initialized
DEBUG - 2022-12-12 08:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 08:27:16 --> Input Class Initialized
INFO - 2022-12-12 08:27:16 --> Language Class Initialized
INFO - 2022-12-12 08:27:16 --> Loader Class Initialized
INFO - 2022-12-12 08:27:16 --> Controller Class Initialized
DEBUG - 2022-12-12 08:27:16 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 08:27:16 --> Database Driver Class Initialized
INFO - 2022-12-12 08:27:16 --> Model "Cluster_model" initialized
INFO - 2022-12-12 08:27:16 --> Database Driver Class Initialized
INFO - 2022-12-12 08:27:16 --> Model "Login_model" initialized
INFO - 2022-12-12 08:27:16 --> Final output sent to browser
DEBUG - 2022-12-12 08:27:16 --> Total execution time: 0.2603
INFO - 2022-12-12 08:27:16 --> Config Class Initialized
INFO - 2022-12-12 08:27:16 --> Hooks Class Initialized
DEBUG - 2022-12-12 08:27:16 --> UTF-8 Support Enabled
INFO - 2022-12-12 08:27:16 --> Utf8 Class Initialized
INFO - 2022-12-12 08:27:16 --> URI Class Initialized
INFO - 2022-12-12 08:27:16 --> Router Class Initialized
INFO - 2022-12-12 08:27:16 --> Output Class Initialized
INFO - 2022-12-12 08:27:16 --> Security Class Initialized
DEBUG - 2022-12-12 08:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 08:27:16 --> Input Class Initialized
INFO - 2022-12-12 08:27:16 --> Language Class Initialized
INFO - 2022-12-12 08:27:16 --> Loader Class Initialized
INFO - 2022-12-12 08:27:16 --> Controller Class Initialized
DEBUG - 2022-12-12 08:27:16 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 08:27:16 --> Database Driver Class Initialized
INFO - 2022-12-12 08:27:16 --> Model "Cluster_model" initialized
INFO - 2022-12-12 08:27:16 --> Database Driver Class Initialized
INFO - 2022-12-12 08:27:16 --> Model "Login_model" initialized
INFO - 2022-12-12 08:27:17 --> Final output sent to browser
DEBUG - 2022-12-12 08:27:17 --> Total execution time: 0.1540
INFO - 2022-12-12 08:28:05 --> Config Class Initialized
INFO - 2022-12-12 08:28:05 --> Hooks Class Initialized
DEBUG - 2022-12-12 08:28:05 --> UTF-8 Support Enabled
INFO - 2022-12-12 08:28:05 --> Utf8 Class Initialized
INFO - 2022-12-12 08:28:05 --> URI Class Initialized
INFO - 2022-12-12 08:28:05 --> Router Class Initialized
INFO - 2022-12-12 08:28:05 --> Output Class Initialized
INFO - 2022-12-12 08:28:05 --> Security Class Initialized
DEBUG - 2022-12-12 08:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 08:28:05 --> Input Class Initialized
INFO - 2022-12-12 08:28:05 --> Language Class Initialized
INFO - 2022-12-12 08:28:05 --> Loader Class Initialized
INFO - 2022-12-12 08:28:05 --> Controller Class Initialized
DEBUG - 2022-12-12 08:28:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 08:28:05 --> Database Driver Class Initialized
INFO - 2022-12-12 08:28:05 --> Model "Cluster_model" initialized
INFO - 2022-12-12 08:28:05 --> Config Class Initialized
INFO - 2022-12-12 08:28:05 --> Hooks Class Initialized
DEBUG - 2022-12-12 08:28:05 --> UTF-8 Support Enabled
INFO - 2022-12-12 08:28:05 --> Utf8 Class Initialized
INFO - 2022-12-12 08:28:05 --> URI Class Initialized
INFO - 2022-12-12 08:28:05 --> Router Class Initialized
INFO - 2022-12-12 08:28:05 --> Output Class Initialized
INFO - 2022-12-12 08:28:05 --> Security Class Initialized
DEBUG - 2022-12-12 08:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 08:28:05 --> Input Class Initialized
INFO - 2022-12-12 08:28:05 --> Language Class Initialized
INFO - 2022-12-12 08:28:05 --> Loader Class Initialized
INFO - 2022-12-12 08:28:05 --> Controller Class Initialized
DEBUG - 2022-12-12 08:28:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 08:28:05 --> Database Driver Class Initialized
INFO - 2022-12-12 08:28:05 --> Model "Cluster_model" initialized
INFO - 2022-12-12 08:28:11 --> Config Class Initialized
INFO - 2022-12-12 08:28:11 --> Hooks Class Initialized
DEBUG - 2022-12-12 08:28:11 --> UTF-8 Support Enabled
INFO - 2022-12-12 08:28:11 --> Utf8 Class Initialized
INFO - 2022-12-12 08:28:11 --> URI Class Initialized
INFO - 2022-12-12 08:28:11 --> Router Class Initialized
INFO - 2022-12-12 08:28:11 --> Output Class Initialized
INFO - 2022-12-12 08:28:11 --> Security Class Initialized
DEBUG - 2022-12-12 08:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 08:28:11 --> Input Class Initialized
INFO - 2022-12-12 08:28:11 --> Language Class Initialized
INFO - 2022-12-12 08:28:11 --> Loader Class Initialized
INFO - 2022-12-12 08:28:11 --> Controller Class Initialized
DEBUG - 2022-12-12 08:28:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 08:28:11 --> Database Driver Class Initialized
INFO - 2022-12-12 08:28:11 --> Model "Cluster_model" initialized
INFO - 2022-12-12 08:28:11 --> Config Class Initialized
INFO - 2022-12-12 08:28:11 --> Hooks Class Initialized
DEBUG - 2022-12-12 08:28:11 --> UTF-8 Support Enabled
INFO - 2022-12-12 08:28:11 --> Utf8 Class Initialized
INFO - 2022-12-12 08:28:11 --> URI Class Initialized
INFO - 2022-12-12 08:28:11 --> Router Class Initialized
INFO - 2022-12-12 08:28:11 --> Output Class Initialized
INFO - 2022-12-12 08:28:11 --> Security Class Initialized
DEBUG - 2022-12-12 08:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 08:28:11 --> Input Class Initialized
INFO - 2022-12-12 08:28:11 --> Language Class Initialized
INFO - 2022-12-12 08:28:11 --> Loader Class Initialized
INFO - 2022-12-12 08:28:11 --> Controller Class Initialized
DEBUG - 2022-12-12 08:28:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 08:28:12 --> Database Driver Class Initialized
INFO - 2022-12-12 08:28:12 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:05:50 --> Config Class Initialized
INFO - 2022-12-12 09:05:50 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:05:50 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:05:50 --> Utf8 Class Initialized
INFO - 2022-12-12 09:05:50 --> URI Class Initialized
INFO - 2022-12-12 09:05:50 --> Router Class Initialized
INFO - 2022-12-12 09:05:50 --> Output Class Initialized
INFO - 2022-12-12 09:05:50 --> Security Class Initialized
DEBUG - 2022-12-12 09:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:05:50 --> Input Class Initialized
INFO - 2022-12-12 09:05:50 --> Language Class Initialized
INFO - 2022-12-12 09:05:50 --> Loader Class Initialized
INFO - 2022-12-12 09:05:50 --> Controller Class Initialized
DEBUG - 2022-12-12 09:05:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:05:50 --> Database Driver Class Initialized
INFO - 2022-12-12 09:05:50 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:05:50 --> Final output sent to browser
DEBUG - 2022-12-12 09:05:50 --> Total execution time: 0.0808
INFO - 2022-12-12 09:05:50 --> Config Class Initialized
INFO - 2022-12-12 09:05:50 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:05:50 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:05:50 --> Utf8 Class Initialized
INFO - 2022-12-12 09:05:50 --> URI Class Initialized
INFO - 2022-12-12 09:05:50 --> Router Class Initialized
INFO - 2022-12-12 09:05:50 --> Output Class Initialized
INFO - 2022-12-12 09:05:50 --> Security Class Initialized
DEBUG - 2022-12-12 09:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:05:50 --> Input Class Initialized
INFO - 2022-12-12 09:05:50 --> Language Class Initialized
INFO - 2022-12-12 09:05:50 --> Loader Class Initialized
INFO - 2022-12-12 09:05:50 --> Controller Class Initialized
DEBUG - 2022-12-12 09:05:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:05:50 --> Database Driver Class Initialized
INFO - 2022-12-12 09:05:50 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:05:50 --> Final output sent to browser
DEBUG - 2022-12-12 09:05:50 --> Total execution time: 0.0672
INFO - 2022-12-12 09:05:57 --> Config Class Initialized
INFO - 2022-12-12 09:05:57 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:05:57 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:05:57 --> Utf8 Class Initialized
INFO - 2022-12-12 09:05:57 --> URI Class Initialized
INFO - 2022-12-12 09:05:57 --> Router Class Initialized
INFO - 2022-12-12 09:05:57 --> Output Class Initialized
INFO - 2022-12-12 09:05:57 --> Security Class Initialized
DEBUG - 2022-12-12 09:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:05:57 --> Input Class Initialized
INFO - 2022-12-12 09:05:57 --> Language Class Initialized
INFO - 2022-12-12 09:05:57 --> Loader Class Initialized
INFO - 2022-12-12 09:05:57 --> Controller Class Initialized
DEBUG - 2022-12-12 09:05:58 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:05:58 --> Database Driver Class Initialized
INFO - 2022-12-12 09:05:58 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:05:58 --> Final output sent to browser
DEBUG - 2022-12-12 09:05:58 --> Total execution time: 0.1162
INFO - 2022-12-12 09:05:58 --> Config Class Initialized
INFO - 2022-12-12 09:05:58 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:05:58 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:05:58 --> Utf8 Class Initialized
INFO - 2022-12-12 09:05:58 --> URI Class Initialized
INFO - 2022-12-12 09:05:58 --> Router Class Initialized
INFO - 2022-12-12 09:05:58 --> Output Class Initialized
INFO - 2022-12-12 09:05:58 --> Security Class Initialized
DEBUG - 2022-12-12 09:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:05:58 --> Input Class Initialized
INFO - 2022-12-12 09:05:58 --> Language Class Initialized
INFO - 2022-12-12 09:05:58 --> Loader Class Initialized
INFO - 2022-12-12 09:05:58 --> Controller Class Initialized
DEBUG - 2022-12-12 09:05:58 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:05:58 --> Database Driver Class Initialized
INFO - 2022-12-12 09:05:58 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:05:58 --> Final output sent to browser
DEBUG - 2022-12-12 09:05:58 --> Total execution time: 0.0824
INFO - 2022-12-12 09:06:05 --> Config Class Initialized
INFO - 2022-12-12 09:06:05 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:06:05 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:06:05 --> Utf8 Class Initialized
INFO - 2022-12-12 09:06:05 --> URI Class Initialized
INFO - 2022-12-12 09:06:05 --> Router Class Initialized
INFO - 2022-12-12 09:06:05 --> Output Class Initialized
INFO - 2022-12-12 09:06:05 --> Security Class Initialized
DEBUG - 2022-12-12 09:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:06:05 --> Input Class Initialized
INFO - 2022-12-12 09:06:05 --> Language Class Initialized
INFO - 2022-12-12 09:06:05 --> Loader Class Initialized
INFO - 2022-12-12 09:06:05 --> Controller Class Initialized
DEBUG - 2022-12-12 09:06:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:06:05 --> Database Driver Class Initialized
INFO - 2022-12-12 09:06:05 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:06:05 --> Final output sent to browser
DEBUG - 2022-12-12 09:06:05 --> Total execution time: 0.0595
INFO - 2022-12-12 09:06:05 --> Config Class Initialized
INFO - 2022-12-12 09:06:05 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:06:05 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:06:05 --> Utf8 Class Initialized
INFO - 2022-12-12 09:06:05 --> URI Class Initialized
INFO - 2022-12-12 09:06:05 --> Router Class Initialized
INFO - 2022-12-12 09:06:05 --> Output Class Initialized
INFO - 2022-12-12 09:06:05 --> Security Class Initialized
DEBUG - 2022-12-12 09:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:06:05 --> Input Class Initialized
INFO - 2022-12-12 09:06:05 --> Language Class Initialized
INFO - 2022-12-12 09:06:05 --> Loader Class Initialized
INFO - 2022-12-12 09:06:05 --> Controller Class Initialized
DEBUG - 2022-12-12 09:06:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:06:05 --> Database Driver Class Initialized
INFO - 2022-12-12 09:06:05 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:06:05 --> Final output sent to browser
DEBUG - 2022-12-12 09:06:05 --> Total execution time: 0.0711
INFO - 2022-12-12 09:18:26 --> Config Class Initialized
INFO - 2022-12-12 09:18:26 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:18:26 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:18:26 --> Utf8 Class Initialized
INFO - 2022-12-12 09:18:26 --> URI Class Initialized
INFO - 2022-12-12 09:18:26 --> Router Class Initialized
INFO - 2022-12-12 09:18:26 --> Output Class Initialized
INFO - 2022-12-12 09:18:26 --> Security Class Initialized
DEBUG - 2022-12-12 09:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:18:26 --> Input Class Initialized
INFO - 2022-12-12 09:18:26 --> Language Class Initialized
INFO - 2022-12-12 09:18:26 --> Loader Class Initialized
INFO - 2022-12-12 09:18:26 --> Controller Class Initialized
DEBUG - 2022-12-12 09:18:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:18:26 --> Final output sent to browser
DEBUG - 2022-12-12 09:18:26 --> Total execution time: 0.0228
INFO - 2022-12-12 09:18:26 --> Config Class Initialized
INFO - 2022-12-12 09:18:26 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:18:26 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:18:26 --> Utf8 Class Initialized
INFO - 2022-12-12 09:18:26 --> URI Class Initialized
INFO - 2022-12-12 09:18:26 --> Router Class Initialized
INFO - 2022-12-12 09:18:26 --> Output Class Initialized
INFO - 2022-12-12 09:18:26 --> Security Class Initialized
DEBUG - 2022-12-12 09:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:18:26 --> Input Class Initialized
INFO - 2022-12-12 09:18:26 --> Language Class Initialized
INFO - 2022-12-12 09:18:26 --> Loader Class Initialized
INFO - 2022-12-12 09:18:26 --> Controller Class Initialized
DEBUG - 2022-12-12 09:18:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:18:26 --> Database Driver Class Initialized
INFO - 2022-12-12 09:18:26 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:18:26 --> Final output sent to browser
DEBUG - 2022-12-12 09:18:26 --> Total execution time: 0.0554
INFO - 2022-12-12 09:18:28 --> Config Class Initialized
INFO - 2022-12-12 09:18:28 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:18:28 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:18:28 --> Utf8 Class Initialized
INFO - 2022-12-12 09:18:28 --> URI Class Initialized
INFO - 2022-12-12 09:18:28 --> Router Class Initialized
INFO - 2022-12-12 09:18:28 --> Output Class Initialized
INFO - 2022-12-12 09:18:28 --> Security Class Initialized
DEBUG - 2022-12-12 09:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:18:28 --> Input Class Initialized
INFO - 2022-12-12 09:18:28 --> Language Class Initialized
INFO - 2022-12-12 09:18:28 --> Loader Class Initialized
INFO - 2022-12-12 09:18:28 --> Controller Class Initialized
DEBUG - 2022-12-12 09:18:28 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:18:28 --> Database Driver Class Initialized
INFO - 2022-12-12 09:18:28 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:18:28 --> Config Class Initialized
INFO - 2022-12-12 09:18:28 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:18:28 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:18:28 --> Utf8 Class Initialized
INFO - 2022-12-12 09:18:28 --> URI Class Initialized
INFO - 2022-12-12 09:18:28 --> Router Class Initialized
INFO - 2022-12-12 09:18:28 --> Output Class Initialized
INFO - 2022-12-12 09:18:28 --> Security Class Initialized
DEBUG - 2022-12-12 09:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:18:28 --> Input Class Initialized
INFO - 2022-12-12 09:18:28 --> Language Class Initialized
INFO - 2022-12-12 09:18:28 --> Loader Class Initialized
INFO - 2022-12-12 09:18:28 --> Controller Class Initialized
DEBUG - 2022-12-12 09:18:28 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:18:28 --> Database Driver Class Initialized
INFO - 2022-12-12 09:18:28 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:33:45 --> Config Class Initialized
INFO - 2022-12-12 09:33:45 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:33:45 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:33:45 --> Utf8 Class Initialized
INFO - 2022-12-12 09:33:45 --> URI Class Initialized
INFO - 2022-12-12 09:33:45 --> Router Class Initialized
INFO - 2022-12-12 09:33:45 --> Output Class Initialized
INFO - 2022-12-12 09:33:45 --> Security Class Initialized
DEBUG - 2022-12-12 09:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:33:45 --> Input Class Initialized
INFO - 2022-12-12 09:33:45 --> Language Class Initialized
INFO - 2022-12-12 09:33:45 --> Loader Class Initialized
INFO - 2022-12-12 09:33:45 --> Controller Class Initialized
DEBUG - 2022-12-12 09:33:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:33:45 --> Final output sent to browser
DEBUG - 2022-12-12 09:33:45 --> Total execution time: 0.0256
INFO - 2022-12-12 09:33:45 --> Config Class Initialized
INFO - 2022-12-12 09:33:45 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:33:45 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:33:45 --> Utf8 Class Initialized
INFO - 2022-12-12 09:33:45 --> URI Class Initialized
INFO - 2022-12-12 09:33:45 --> Router Class Initialized
INFO - 2022-12-12 09:33:45 --> Output Class Initialized
INFO - 2022-12-12 09:33:45 --> Security Class Initialized
DEBUG - 2022-12-12 09:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:33:45 --> Input Class Initialized
INFO - 2022-12-12 09:33:45 --> Language Class Initialized
INFO - 2022-12-12 09:33:45 --> Loader Class Initialized
INFO - 2022-12-12 09:33:45 --> Controller Class Initialized
DEBUG - 2022-12-12 09:33:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:33:45 --> Database Driver Class Initialized
INFO - 2022-12-12 09:33:45 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:33:45 --> Final output sent to browser
DEBUG - 2022-12-12 09:33:45 --> Total execution time: 0.0513
INFO - 2022-12-12 09:33:46 --> Config Class Initialized
INFO - 2022-12-12 09:33:46 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:33:46 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:33:46 --> Utf8 Class Initialized
INFO - 2022-12-12 09:33:46 --> URI Class Initialized
INFO - 2022-12-12 09:33:46 --> Router Class Initialized
INFO - 2022-12-12 09:33:46 --> Output Class Initialized
INFO - 2022-12-12 09:33:46 --> Security Class Initialized
DEBUG - 2022-12-12 09:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:33:46 --> Input Class Initialized
INFO - 2022-12-12 09:33:46 --> Language Class Initialized
INFO - 2022-12-12 09:33:46 --> Loader Class Initialized
INFO - 2022-12-12 09:33:46 --> Controller Class Initialized
DEBUG - 2022-12-12 09:33:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:33:46 --> Database Driver Class Initialized
INFO - 2022-12-12 09:33:46 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:33:46 --> Final output sent to browser
DEBUG - 2022-12-12 09:33:46 --> Total execution time: 0.0355
INFO - 2022-12-12 09:33:46 --> Config Class Initialized
INFO - 2022-12-12 09:33:46 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:33:46 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:33:46 --> Utf8 Class Initialized
INFO - 2022-12-12 09:33:46 --> URI Class Initialized
INFO - 2022-12-12 09:33:46 --> Router Class Initialized
INFO - 2022-12-12 09:33:46 --> Output Class Initialized
INFO - 2022-12-12 09:33:46 --> Security Class Initialized
DEBUG - 2022-12-12 09:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:33:46 --> Input Class Initialized
INFO - 2022-12-12 09:33:46 --> Language Class Initialized
INFO - 2022-12-12 09:33:46 --> Loader Class Initialized
INFO - 2022-12-12 09:33:46 --> Controller Class Initialized
DEBUG - 2022-12-12 09:33:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:33:46 --> Database Driver Class Initialized
INFO - 2022-12-12 09:33:46 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:33:47 --> Final output sent to browser
DEBUG - 2022-12-12 09:33:47 --> Total execution time: 0.1944
INFO - 2022-12-12 09:33:49 --> Config Class Initialized
INFO - 2022-12-12 09:33:49 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:33:49 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:33:49 --> Utf8 Class Initialized
INFO - 2022-12-12 09:33:49 --> URI Class Initialized
INFO - 2022-12-12 09:33:49 --> Router Class Initialized
INFO - 2022-12-12 09:33:49 --> Output Class Initialized
INFO - 2022-12-12 09:33:49 --> Security Class Initialized
DEBUG - 2022-12-12 09:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:33:49 --> Input Class Initialized
INFO - 2022-12-12 09:33:49 --> Language Class Initialized
INFO - 2022-12-12 09:33:49 --> Loader Class Initialized
INFO - 2022-12-12 09:33:49 --> Controller Class Initialized
DEBUG - 2022-12-12 09:33:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:33:49 --> Database Driver Class Initialized
INFO - 2022-12-12 09:33:49 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:33:49 --> Final output sent to browser
DEBUG - 2022-12-12 09:33:49 --> Total execution time: 0.0381
INFO - 2022-12-12 09:33:50 --> Config Class Initialized
INFO - 2022-12-12 09:33:50 --> Hooks Class Initialized
INFO - 2022-12-12 09:33:50 --> Config Class Initialized
INFO - 2022-12-12 09:33:50 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:33:50 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:33:50 --> Utf8 Class Initialized
DEBUG - 2022-12-12 09:33:50 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:33:50 --> Utf8 Class Initialized
INFO - 2022-12-12 09:33:50 --> URI Class Initialized
INFO - 2022-12-12 09:33:50 --> URI Class Initialized
INFO - 2022-12-12 09:33:50 --> Router Class Initialized
INFO - 2022-12-12 09:33:50 --> Router Class Initialized
INFO - 2022-12-12 09:33:50 --> Output Class Initialized
INFO - 2022-12-12 09:33:50 --> Output Class Initialized
INFO - 2022-12-12 09:33:50 --> Security Class Initialized
INFO - 2022-12-12 09:33:50 --> Security Class Initialized
DEBUG - 2022-12-12 09:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:33:50 --> Input Class Initialized
DEBUG - 2022-12-12 09:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:33:50 --> Input Class Initialized
INFO - 2022-12-12 09:33:50 --> Language Class Initialized
INFO - 2022-12-12 09:33:50 --> Language Class Initialized
INFO - 2022-12-12 09:33:50 --> Loader Class Initialized
INFO - 2022-12-12 09:33:50 --> Loader Class Initialized
INFO - 2022-12-12 09:33:50 --> Controller Class Initialized
INFO - 2022-12-12 09:33:50 --> Controller Class Initialized
DEBUG - 2022-12-12 09:33:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 09:33:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:33:50 --> Database Driver Class Initialized
INFO - 2022-12-12 09:33:50 --> Database Driver Class Initialized
INFO - 2022-12-12 09:33:50 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:33:50 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:33:50 --> Final output sent to browser
DEBUG - 2022-12-12 09:33:50 --> Total execution time: 0.0600
INFO - 2022-12-12 09:33:50 --> Config Class Initialized
INFO - 2022-12-12 09:33:50 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:33:50 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:33:50 --> Utf8 Class Initialized
INFO - 2022-12-12 09:33:50 --> URI Class Initialized
INFO - 2022-12-12 09:33:50 --> Router Class Initialized
INFO - 2022-12-12 09:33:50 --> Output Class Initialized
INFO - 2022-12-12 09:33:50 --> Security Class Initialized
DEBUG - 2022-12-12 09:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:33:50 --> Input Class Initialized
INFO - 2022-12-12 09:33:50 --> Language Class Initialized
INFO - 2022-12-12 09:33:50 --> Loader Class Initialized
INFO - 2022-12-12 09:33:50 --> Controller Class Initialized
DEBUG - 2022-12-12 09:33:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:33:50 --> Database Driver Class Initialized
INFO - 2022-12-12 09:33:50 --> Config Class Initialized
INFO - 2022-12-12 09:33:50 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:33:50 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:33:50 --> Utf8 Class Initialized
INFO - 2022-12-12 09:33:50 --> URI Class Initialized
INFO - 2022-12-12 09:33:50 --> Router Class Initialized
INFO - 2022-12-12 09:33:50 --> Output Class Initialized
INFO - 2022-12-12 09:33:50 --> Security Class Initialized
DEBUG - 2022-12-12 09:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:33:50 --> Input Class Initialized
INFO - 2022-12-12 09:33:50 --> Language Class Initialized
INFO - 2022-12-12 09:33:50 --> Loader Class Initialized
INFO - 2022-12-12 09:33:50 --> Controller Class Initialized
DEBUG - 2022-12-12 09:33:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:33:50 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:33:50 --> Database Driver Class Initialized
INFO - 2022-12-12 09:33:50 --> Final output sent to browser
DEBUG - 2022-12-12 09:33:50 --> Total execution time: 0.0502
INFO - 2022-12-12 09:33:50 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:33:50 --> Config Class Initialized
INFO - 2022-12-12 09:33:50 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:33:50 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:33:50 --> Utf8 Class Initialized
INFO - 2022-12-12 09:33:50 --> URI Class Initialized
INFO - 2022-12-12 09:33:50 --> Router Class Initialized
INFO - 2022-12-12 09:33:50 --> Output Class Initialized
INFO - 2022-12-12 09:33:50 --> Security Class Initialized
DEBUG - 2022-12-12 09:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:33:50 --> Input Class Initialized
INFO - 2022-12-12 09:33:50 --> Language Class Initialized
INFO - 2022-12-12 09:33:50 --> Loader Class Initialized
INFO - 2022-12-12 09:33:50 --> Controller Class Initialized
DEBUG - 2022-12-12 09:33:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:33:50 --> Database Driver Class Initialized
INFO - 2022-12-12 09:33:50 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:33:50 --> Config Class Initialized
INFO - 2022-12-12 09:33:50 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:33:50 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:33:50 --> Utf8 Class Initialized
INFO - 2022-12-12 09:33:50 --> URI Class Initialized
INFO - 2022-12-12 09:33:50 --> Router Class Initialized
INFO - 2022-12-12 09:33:50 --> Output Class Initialized
INFO - 2022-12-12 09:33:50 --> Security Class Initialized
DEBUG - 2022-12-12 09:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:33:50 --> Input Class Initialized
INFO - 2022-12-12 09:33:50 --> Language Class Initialized
INFO - 2022-12-12 09:33:50 --> Loader Class Initialized
INFO - 2022-12-12 09:33:50 --> Controller Class Initialized
DEBUG - 2022-12-12 09:33:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:33:50 --> Database Driver Class Initialized
INFO - 2022-12-12 09:33:50 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:33:52 --> Config Class Initialized
INFO - 2022-12-12 09:33:52 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:33:52 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:33:52 --> Utf8 Class Initialized
INFO - 2022-12-12 09:33:52 --> URI Class Initialized
INFO - 2022-12-12 09:33:52 --> Router Class Initialized
INFO - 2022-12-12 09:33:52 --> Output Class Initialized
INFO - 2022-12-12 09:33:52 --> Security Class Initialized
DEBUG - 2022-12-12 09:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:33:52 --> Input Class Initialized
INFO - 2022-12-12 09:33:52 --> Language Class Initialized
INFO - 2022-12-12 09:33:52 --> Loader Class Initialized
INFO - 2022-12-12 09:33:52 --> Controller Class Initialized
DEBUG - 2022-12-12 09:33:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:33:52 --> Database Driver Class Initialized
INFO - 2022-12-12 09:33:52 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:38:38 --> Config Class Initialized
INFO - 2022-12-12 09:38:38 --> Hooks Class Initialized
INFO - 2022-12-12 09:38:38 --> Config Class Initialized
INFO - 2022-12-12 09:38:38 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:38:38 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:38:38 --> Utf8 Class Initialized
DEBUG - 2022-12-12 09:38:38 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:38:38 --> Utf8 Class Initialized
INFO - 2022-12-12 09:38:38 --> URI Class Initialized
INFO - 2022-12-12 09:38:38 --> URI Class Initialized
INFO - 2022-12-12 09:38:38 --> Router Class Initialized
INFO - 2022-12-12 09:38:38 --> Router Class Initialized
INFO - 2022-12-12 09:38:38 --> Output Class Initialized
INFO - 2022-12-12 09:38:38 --> Output Class Initialized
INFO - 2022-12-12 09:38:38 --> Security Class Initialized
INFO - 2022-12-12 09:38:38 --> Security Class Initialized
DEBUG - 2022-12-12 09:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:38:38 --> Input Class Initialized
DEBUG - 2022-12-12 09:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:38:38 --> Input Class Initialized
INFO - 2022-12-12 09:38:38 --> Language Class Initialized
INFO - 2022-12-12 09:38:38 --> Language Class Initialized
INFO - 2022-12-12 09:38:38 --> Loader Class Initialized
INFO - 2022-12-12 09:38:38 --> Loader Class Initialized
INFO - 2022-12-12 09:38:38 --> Controller Class Initialized
DEBUG - 2022-12-12 09:38:38 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:38:38 --> Controller Class Initialized
DEBUG - 2022-12-12 09:38:38 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:38:38 --> Database Driver Class Initialized
INFO - 2022-12-12 09:38:38 --> Database Driver Class Initialized
INFO - 2022-12-12 09:38:38 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:38:38 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:38:38 --> Final output sent to browser
DEBUG - 2022-12-12 09:38:38 --> Total execution time: 0.0540
INFO - 2022-12-12 09:38:38 --> Config Class Initialized
INFO - 2022-12-12 09:38:38 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:38:38 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:38:38 --> Utf8 Class Initialized
INFO - 2022-12-12 09:38:38 --> URI Class Initialized
INFO - 2022-12-12 09:38:38 --> Router Class Initialized
INFO - 2022-12-12 09:38:38 --> Output Class Initialized
INFO - 2022-12-12 09:38:38 --> Security Class Initialized
DEBUG - 2022-12-12 09:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:38:38 --> Input Class Initialized
INFO - 2022-12-12 09:38:38 --> Language Class Initialized
INFO - 2022-12-12 09:38:38 --> Loader Class Initialized
INFO - 2022-12-12 09:38:38 --> Controller Class Initialized
DEBUG - 2022-12-12 09:38:38 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:38:38 --> Database Driver Class Initialized
INFO - 2022-12-12 09:38:38 --> Config Class Initialized
INFO - 2022-12-12 09:38:38 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:38:38 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:38:38 --> Utf8 Class Initialized
INFO - 2022-12-12 09:38:38 --> URI Class Initialized
INFO - 2022-12-12 09:38:38 --> Router Class Initialized
INFO - 2022-12-12 09:38:38 --> Output Class Initialized
INFO - 2022-12-12 09:38:38 --> Security Class Initialized
DEBUG - 2022-12-12 09:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:38:38 --> Input Class Initialized
INFO - 2022-12-12 09:38:38 --> Language Class Initialized
INFO - 2022-12-12 09:38:38 --> Loader Class Initialized
INFO - 2022-12-12 09:38:38 --> Controller Class Initialized
INFO - 2022-12-12 09:38:38 --> Model "Cluster_model" initialized
DEBUG - 2022-12-12 09:38:38 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:38:38 --> Final output sent to browser
DEBUG - 2022-12-12 09:38:38 --> Total execution time: 0.0530
INFO - 2022-12-12 09:38:38 --> Database Driver Class Initialized
INFO - 2022-12-12 09:38:38 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:38:47 --> Config Class Initialized
INFO - 2022-12-12 09:38:47 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:38:47 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:38:47 --> Utf8 Class Initialized
INFO - 2022-12-12 09:38:47 --> URI Class Initialized
INFO - 2022-12-12 09:38:47 --> Router Class Initialized
INFO - 2022-12-12 09:38:47 --> Output Class Initialized
INFO - 2022-12-12 09:38:47 --> Security Class Initialized
DEBUG - 2022-12-12 09:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:38:47 --> Input Class Initialized
INFO - 2022-12-12 09:38:47 --> Language Class Initialized
INFO - 2022-12-12 09:38:47 --> Loader Class Initialized
INFO - 2022-12-12 09:38:47 --> Controller Class Initialized
DEBUG - 2022-12-12 09:38:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:38:47 --> Final output sent to browser
DEBUG - 2022-12-12 09:38:47 --> Total execution time: 0.0211
INFO - 2022-12-12 09:38:47 --> Config Class Initialized
INFO - 2022-12-12 09:38:47 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:38:47 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:38:47 --> Utf8 Class Initialized
INFO - 2022-12-12 09:38:47 --> URI Class Initialized
INFO - 2022-12-12 09:38:47 --> Router Class Initialized
INFO - 2022-12-12 09:38:47 --> Output Class Initialized
INFO - 2022-12-12 09:38:47 --> Security Class Initialized
DEBUG - 2022-12-12 09:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:38:47 --> Input Class Initialized
INFO - 2022-12-12 09:38:47 --> Language Class Initialized
INFO - 2022-12-12 09:38:47 --> Loader Class Initialized
INFO - 2022-12-12 09:38:47 --> Controller Class Initialized
DEBUG - 2022-12-12 09:38:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:38:47 --> Database Driver Class Initialized
INFO - 2022-12-12 09:38:47 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:38:47 --> Final output sent to browser
DEBUG - 2022-12-12 09:38:47 --> Total execution time: 0.0403
INFO - 2022-12-12 09:38:49 --> Config Class Initialized
INFO - 2022-12-12 09:38:49 --> Hooks Class Initialized
INFO - 2022-12-12 09:38:49 --> Config Class Initialized
INFO - 2022-12-12 09:38:49 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:38:49 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:38:49 --> Utf8 Class Initialized
DEBUG - 2022-12-12 09:38:49 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:38:49 --> Utf8 Class Initialized
INFO - 2022-12-12 09:38:49 --> URI Class Initialized
INFO - 2022-12-12 09:38:49 --> URI Class Initialized
INFO - 2022-12-12 09:38:49 --> Router Class Initialized
INFO - 2022-12-12 09:38:49 --> Router Class Initialized
INFO - 2022-12-12 09:38:49 --> Output Class Initialized
INFO - 2022-12-12 09:38:49 --> Output Class Initialized
INFO - 2022-12-12 09:38:49 --> Security Class Initialized
INFO - 2022-12-12 09:38:49 --> Security Class Initialized
DEBUG - 2022-12-12 09:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:38:49 --> Input Class Initialized
DEBUG - 2022-12-12 09:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:38:49 --> Input Class Initialized
INFO - 2022-12-12 09:38:49 --> Language Class Initialized
INFO - 2022-12-12 09:38:49 --> Language Class Initialized
INFO - 2022-12-12 09:38:49 --> Loader Class Initialized
INFO - 2022-12-12 09:38:49 --> Loader Class Initialized
INFO - 2022-12-12 09:38:49 --> Controller Class Initialized
INFO - 2022-12-12 09:38:49 --> Controller Class Initialized
DEBUG - 2022-12-12 09:38:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 09:38:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:38:49 --> Database Driver Class Initialized
INFO - 2022-12-12 09:38:49 --> Database Driver Class Initialized
INFO - 2022-12-12 09:38:49 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:38:49 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:38:49 --> Final output sent to browser
DEBUG - 2022-12-12 09:38:49 --> Total execution time: 0.0639
INFO - 2022-12-12 09:38:49 --> Config Class Initialized
INFO - 2022-12-12 09:38:49 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:38:49 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:38:49 --> Utf8 Class Initialized
INFO - 2022-12-12 09:38:49 --> URI Class Initialized
INFO - 2022-12-12 09:38:49 --> Router Class Initialized
INFO - 2022-12-12 09:38:49 --> Output Class Initialized
INFO - 2022-12-12 09:38:49 --> Security Class Initialized
INFO - 2022-12-12 09:38:49 --> Config Class Initialized
INFO - 2022-12-12 09:38:49 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:38:49 --> Input Class Initialized
INFO - 2022-12-12 09:38:49 --> Language Class Initialized
DEBUG - 2022-12-12 09:38:49 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:38:49 --> Utf8 Class Initialized
INFO - 2022-12-12 09:38:49 --> URI Class Initialized
INFO - 2022-12-12 09:38:49 --> Loader Class Initialized
INFO - 2022-12-12 09:38:49 --> Controller Class Initialized
INFO - 2022-12-12 09:38:49 --> Router Class Initialized
DEBUG - 2022-12-12 09:38:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:38:49 --> Output Class Initialized
INFO - 2022-12-12 09:38:49 --> Security Class Initialized
DEBUG - 2022-12-12 09:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:38:49 --> Input Class Initialized
INFO - 2022-12-12 09:38:49 --> Language Class Initialized
INFO - 2022-12-12 09:38:49 --> Database Driver Class Initialized
INFO - 2022-12-12 09:38:49 --> Loader Class Initialized
INFO - 2022-12-12 09:38:49 --> Controller Class Initialized
DEBUG - 2022-12-12 09:38:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:38:49 --> Database Driver Class Initialized
INFO - 2022-12-12 09:38:49 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:38:49 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:38:49 --> Final output sent to browser
DEBUG - 2022-12-12 09:38:49 --> Total execution time: 0.0537
INFO - 2022-12-12 09:56:52 --> Config Class Initialized
INFO - 2022-12-12 09:56:52 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:56:52 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:56:52 --> Utf8 Class Initialized
INFO - 2022-12-12 09:56:52 --> URI Class Initialized
INFO - 2022-12-12 09:56:52 --> Router Class Initialized
INFO - 2022-12-12 09:56:52 --> Output Class Initialized
INFO - 2022-12-12 09:56:52 --> Security Class Initialized
DEBUG - 2022-12-12 09:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:56:52 --> Input Class Initialized
INFO - 2022-12-12 09:56:52 --> Language Class Initialized
INFO - 2022-12-12 09:56:52 --> Loader Class Initialized
INFO - 2022-12-12 09:56:52 --> Controller Class Initialized
DEBUG - 2022-12-12 09:56:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:56:52 --> Database Driver Class Initialized
INFO - 2022-12-12 09:56:52 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:56:52 --> Final output sent to browser
DEBUG - 2022-12-12 09:56:52 --> Total execution time: 0.0976
INFO - 2022-12-12 09:56:52 --> Config Class Initialized
INFO - 2022-12-12 09:56:52 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:56:52 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:56:52 --> Utf8 Class Initialized
INFO - 2022-12-12 09:56:52 --> URI Class Initialized
INFO - 2022-12-12 09:56:52 --> Router Class Initialized
INFO - 2022-12-12 09:56:52 --> Output Class Initialized
INFO - 2022-12-12 09:56:52 --> Security Class Initialized
DEBUG - 2022-12-12 09:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:56:52 --> Input Class Initialized
INFO - 2022-12-12 09:56:52 --> Language Class Initialized
INFO - 2022-12-12 09:56:52 --> Loader Class Initialized
INFO - 2022-12-12 09:56:52 --> Controller Class Initialized
DEBUG - 2022-12-12 09:56:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:56:52 --> Database Driver Class Initialized
INFO - 2022-12-12 09:56:52 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:56:52 --> Final output sent to browser
DEBUG - 2022-12-12 09:56:52 --> Total execution time: 0.1042
INFO - 2022-12-12 09:57:07 --> Config Class Initialized
INFO - 2022-12-12 09:57:07 --> Hooks Class Initialized
INFO - 2022-12-12 09:57:07 --> Config Class Initialized
INFO - 2022-12-12 09:57:07 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:57:07 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:57:07 --> Utf8 Class Initialized
DEBUG - 2022-12-12 09:57:07 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:57:07 --> Utf8 Class Initialized
INFO - 2022-12-12 09:57:07 --> URI Class Initialized
INFO - 2022-12-12 09:57:07 --> URI Class Initialized
INFO - 2022-12-12 09:57:07 --> Router Class Initialized
INFO - 2022-12-12 09:57:07 --> Router Class Initialized
INFO - 2022-12-12 09:57:07 --> Output Class Initialized
INFO - 2022-12-12 09:57:07 --> Output Class Initialized
INFO - 2022-12-12 09:57:07 --> Security Class Initialized
INFO - 2022-12-12 09:57:07 --> Security Class Initialized
DEBUG - 2022-12-12 09:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:57:07 --> Input Class Initialized
DEBUG - 2022-12-12 09:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:57:07 --> Language Class Initialized
INFO - 2022-12-12 09:57:07 --> Input Class Initialized
INFO - 2022-12-12 09:57:07 --> Language Class Initialized
INFO - 2022-12-12 09:57:07 --> Loader Class Initialized
INFO - 2022-12-12 09:57:07 --> Loader Class Initialized
INFO - 2022-12-12 09:57:07 --> Controller Class Initialized
DEBUG - 2022-12-12 09:57:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:57:07 --> Controller Class Initialized
INFO - 2022-12-12 09:57:07 --> Final output sent to browser
DEBUG - 2022-12-12 09:57:07 --> Total execution time: 0.0242
DEBUG - 2022-12-12 09:57:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:57:07 --> Database Driver Class Initialized
INFO - 2022-12-12 09:57:07 --> Config Class Initialized
INFO - 2022-12-12 09:57:07 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:57:07 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:57:07 --> Utf8 Class Initialized
INFO - 2022-12-12 09:57:07 --> URI Class Initialized
INFO - 2022-12-12 09:57:07 --> Router Class Initialized
INFO - 2022-12-12 09:57:07 --> Output Class Initialized
INFO - 2022-12-12 09:57:07 --> Security Class Initialized
DEBUG - 2022-12-12 09:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:57:07 --> Input Class Initialized
INFO - 2022-12-12 09:57:07 --> Language Class Initialized
INFO - 2022-12-12 09:57:07 --> Loader Class Initialized
INFO - 2022-12-12 09:57:07 --> Controller Class Initialized
DEBUG - 2022-12-12 09:57:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:57:07 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:57:07 --> Database Driver Class Initialized
INFO - 2022-12-12 09:57:07 --> Final output sent to browser
DEBUG - 2022-12-12 09:57:07 --> Total execution time: 0.0577
INFO - 2022-12-12 09:57:07 --> Config Class Initialized
INFO - 2022-12-12 09:57:07 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:57:07 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:57:07 --> Utf8 Class Initialized
INFO - 2022-12-12 09:57:07 --> URI Class Initialized
INFO - 2022-12-12 09:57:07 --> Router Class Initialized
INFO - 2022-12-12 09:57:07 --> Output Class Initialized
INFO - 2022-12-12 09:57:07 --> Security Class Initialized
DEBUG - 2022-12-12 09:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:57:07 --> Input Class Initialized
INFO - 2022-12-12 09:57:07 --> Language Class Initialized
INFO - 2022-12-12 09:57:07 --> Loader Class Initialized
INFO - 2022-12-12 09:57:07 --> Controller Class Initialized
INFO - 2022-12-12 09:57:07 --> Model "Cluster_model" initialized
DEBUG - 2022-12-12 09:57:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:57:07 --> Final output sent to browser
DEBUG - 2022-12-12 09:57:07 --> Total execution time: 0.0573
INFO - 2022-12-12 09:57:07 --> Database Driver Class Initialized
INFO - 2022-12-12 09:57:07 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:57:07 --> Final output sent to browser
DEBUG - 2022-12-12 09:57:07 --> Total execution time: 0.0533
INFO - 2022-12-12 09:57:19 --> Config Class Initialized
INFO - 2022-12-12 09:57:19 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:57:19 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:57:19 --> Utf8 Class Initialized
INFO - 2022-12-12 09:57:19 --> URI Class Initialized
INFO - 2022-12-12 09:57:19 --> Router Class Initialized
INFO - 2022-12-12 09:57:19 --> Output Class Initialized
INFO - 2022-12-12 09:57:19 --> Security Class Initialized
DEBUG - 2022-12-12 09:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:57:19 --> Input Class Initialized
INFO - 2022-12-12 09:57:19 --> Language Class Initialized
INFO - 2022-12-12 09:57:19 --> Loader Class Initialized
INFO - 2022-12-12 09:57:19 --> Controller Class Initialized
DEBUG - 2022-12-12 09:57:19 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:57:19 --> Final output sent to browser
DEBUG - 2022-12-12 09:57:19 --> Total execution time: 0.0217
INFO - 2022-12-12 09:57:19 --> Config Class Initialized
INFO - 2022-12-12 09:57:19 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:57:19 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:57:19 --> Utf8 Class Initialized
INFO - 2022-12-12 09:57:19 --> URI Class Initialized
INFO - 2022-12-12 09:57:19 --> Router Class Initialized
INFO - 2022-12-12 09:57:19 --> Output Class Initialized
INFO - 2022-12-12 09:57:19 --> Security Class Initialized
DEBUG - 2022-12-12 09:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:57:19 --> Input Class Initialized
INFO - 2022-12-12 09:57:19 --> Language Class Initialized
INFO - 2022-12-12 09:57:19 --> Loader Class Initialized
INFO - 2022-12-12 09:57:19 --> Controller Class Initialized
DEBUG - 2022-12-12 09:57:19 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:57:19 --> Database Driver Class Initialized
INFO - 2022-12-12 09:57:19 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:57:19 --> Final output sent to browser
DEBUG - 2022-12-12 09:57:19 --> Total execution time: 0.0413
INFO - 2022-12-12 09:57:33 --> Config Class Initialized
INFO - 2022-12-12 09:57:33 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:57:33 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:57:33 --> Utf8 Class Initialized
INFO - 2022-12-12 09:57:33 --> URI Class Initialized
INFO - 2022-12-12 09:57:33 --> Router Class Initialized
INFO - 2022-12-12 09:57:33 --> Output Class Initialized
INFO - 2022-12-12 09:57:33 --> Security Class Initialized
DEBUG - 2022-12-12 09:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:57:33 --> Input Class Initialized
INFO - 2022-12-12 09:57:33 --> Language Class Initialized
INFO - 2022-12-12 09:57:33 --> Loader Class Initialized
INFO - 2022-12-12 09:57:33 --> Controller Class Initialized
DEBUG - 2022-12-12 09:57:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:57:33 --> Database Driver Class Initialized
INFO - 2022-12-12 09:57:34 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:57:34 --> Database Driver Class Initialized
INFO - 2022-12-12 09:57:34 --> Model "Login_model" initialized
INFO - 2022-12-12 09:57:34 --> Final output sent to browser
DEBUG - 2022-12-12 09:57:34 --> Total execution time: 0.3383
INFO - 2022-12-12 09:57:34 --> Config Class Initialized
INFO - 2022-12-12 09:57:34 --> Hooks Class Initialized
DEBUG - 2022-12-12 09:57:34 --> UTF-8 Support Enabled
INFO - 2022-12-12 09:57:34 --> Utf8 Class Initialized
INFO - 2022-12-12 09:57:34 --> URI Class Initialized
INFO - 2022-12-12 09:57:34 --> Router Class Initialized
INFO - 2022-12-12 09:57:34 --> Output Class Initialized
INFO - 2022-12-12 09:57:34 --> Security Class Initialized
DEBUG - 2022-12-12 09:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 09:57:34 --> Input Class Initialized
INFO - 2022-12-12 09:57:34 --> Language Class Initialized
INFO - 2022-12-12 09:57:34 --> Loader Class Initialized
INFO - 2022-12-12 09:57:34 --> Controller Class Initialized
DEBUG - 2022-12-12 09:57:34 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 09:57:34 --> Database Driver Class Initialized
INFO - 2022-12-12 09:57:34 --> Model "Cluster_model" initialized
INFO - 2022-12-12 09:57:34 --> Database Driver Class Initialized
INFO - 2022-12-12 09:57:34 --> Model "Login_model" initialized
INFO - 2022-12-12 09:57:34 --> Final output sent to browser
DEBUG - 2022-12-12 09:57:34 --> Total execution time: 0.1780
INFO - 2022-12-12 10:16:38 --> Config Class Initialized
INFO - 2022-12-12 10:16:38 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:16:38 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:16:38 --> Utf8 Class Initialized
INFO - 2022-12-12 10:16:38 --> URI Class Initialized
INFO - 2022-12-12 10:16:38 --> Router Class Initialized
INFO - 2022-12-12 10:16:38 --> Output Class Initialized
INFO - 2022-12-12 10:16:38 --> Security Class Initialized
DEBUG - 2022-12-12 10:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:16:38 --> Input Class Initialized
INFO - 2022-12-12 10:16:38 --> Language Class Initialized
INFO - 2022-12-12 10:16:38 --> Loader Class Initialized
INFO - 2022-12-12 10:16:38 --> Controller Class Initialized
DEBUG - 2022-12-12 10:16:38 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:16:38 --> Database Driver Class Initialized
INFO - 2022-12-12 10:16:38 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:16:39 --> Final output sent to browser
DEBUG - 2022-12-12 10:16:39 --> Total execution time: 0.2508
INFO - 2022-12-12 10:16:39 --> Config Class Initialized
INFO - 2022-12-12 10:16:39 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:16:39 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:16:39 --> Utf8 Class Initialized
INFO - 2022-12-12 10:16:39 --> URI Class Initialized
INFO - 2022-12-12 10:16:39 --> Router Class Initialized
INFO - 2022-12-12 10:16:39 --> Output Class Initialized
INFO - 2022-12-12 10:16:39 --> Security Class Initialized
DEBUG - 2022-12-12 10:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:16:39 --> Input Class Initialized
INFO - 2022-12-12 10:16:39 --> Language Class Initialized
INFO - 2022-12-12 10:16:39 --> Loader Class Initialized
INFO - 2022-12-12 10:16:39 --> Controller Class Initialized
DEBUG - 2022-12-12 10:16:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:16:39 --> Database Driver Class Initialized
INFO - 2022-12-12 10:16:39 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:16:39 --> Final output sent to browser
DEBUG - 2022-12-12 10:16:39 --> Total execution time: 0.0635
INFO - 2022-12-12 10:18:30 --> Config Class Initialized
INFO - 2022-12-12 10:18:30 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:18:30 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:18:30 --> Utf8 Class Initialized
INFO - 2022-12-12 10:18:30 --> URI Class Initialized
INFO - 2022-12-12 10:18:30 --> Router Class Initialized
INFO - 2022-12-12 10:18:30 --> Output Class Initialized
INFO - 2022-12-12 10:18:30 --> Security Class Initialized
DEBUG - 2022-12-12 10:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:18:30 --> Input Class Initialized
INFO - 2022-12-12 10:18:30 --> Language Class Initialized
INFO - 2022-12-12 10:18:30 --> Loader Class Initialized
INFO - 2022-12-12 10:18:30 --> Controller Class Initialized
DEBUG - 2022-12-12 10:18:30 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:18:30 --> Database Driver Class Initialized
INFO - 2022-12-12 10:18:30 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:18:30 --> Final output sent to browser
DEBUG - 2022-12-12 10:18:30 --> Total execution time: 0.0372
INFO - 2022-12-12 10:18:30 --> Config Class Initialized
INFO - 2022-12-12 10:18:30 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:18:30 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:18:30 --> Utf8 Class Initialized
INFO - 2022-12-12 10:18:30 --> URI Class Initialized
INFO - 2022-12-12 10:18:30 --> Router Class Initialized
INFO - 2022-12-12 10:18:30 --> Output Class Initialized
INFO - 2022-12-12 10:18:30 --> Security Class Initialized
DEBUG - 2022-12-12 10:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:18:30 --> Input Class Initialized
INFO - 2022-12-12 10:18:30 --> Language Class Initialized
INFO - 2022-12-12 10:18:30 --> Loader Class Initialized
INFO - 2022-12-12 10:18:30 --> Controller Class Initialized
DEBUG - 2022-12-12 10:18:30 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:18:30 --> Database Driver Class Initialized
INFO - 2022-12-12 10:18:30 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:18:30 --> Final output sent to browser
DEBUG - 2022-12-12 10:18:30 --> Total execution time: 0.0379
INFO - 2022-12-12 10:32:34 --> Config Class Initialized
INFO - 2022-12-12 10:32:34 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:32:34 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:32:34 --> Utf8 Class Initialized
INFO - 2022-12-12 10:32:34 --> URI Class Initialized
INFO - 2022-12-12 10:32:34 --> Router Class Initialized
INFO - 2022-12-12 10:32:34 --> Output Class Initialized
INFO - 2022-12-12 10:32:34 --> Security Class Initialized
DEBUG - 2022-12-12 10:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:32:34 --> Input Class Initialized
INFO - 2022-12-12 10:32:34 --> Language Class Initialized
INFO - 2022-12-12 10:32:34 --> Loader Class Initialized
INFO - 2022-12-12 10:32:34 --> Controller Class Initialized
DEBUG - 2022-12-12 10:32:34 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:32:34 --> Database Driver Class Initialized
INFO - 2022-12-12 10:32:34 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:32:34 --> Final output sent to browser
DEBUG - 2022-12-12 10:32:34 --> Total execution time: 0.3058
INFO - 2022-12-12 10:32:34 --> Config Class Initialized
INFO - 2022-12-12 10:32:34 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:32:34 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:32:34 --> Utf8 Class Initialized
INFO - 2022-12-12 10:32:34 --> URI Class Initialized
INFO - 2022-12-12 10:32:34 --> Router Class Initialized
INFO - 2022-12-12 10:32:34 --> Output Class Initialized
INFO - 2022-12-12 10:32:34 --> Security Class Initialized
DEBUG - 2022-12-12 10:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:32:34 --> Input Class Initialized
INFO - 2022-12-12 10:32:34 --> Language Class Initialized
INFO - 2022-12-12 10:32:34 --> Loader Class Initialized
INFO - 2022-12-12 10:32:34 --> Controller Class Initialized
DEBUG - 2022-12-12 10:32:34 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:32:34 --> Database Driver Class Initialized
INFO - 2022-12-12 10:32:35 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:32:35 --> Final output sent to browser
DEBUG - 2022-12-12 10:32:35 --> Total execution time: 0.4359
INFO - 2022-12-12 10:37:52 --> Config Class Initialized
INFO - 2022-12-12 10:37:52 --> Hooks Class Initialized
INFO - 2022-12-12 10:37:52 --> Config Class Initialized
INFO - 2022-12-12 10:37:52 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:37:52 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:37:52 --> Utf8 Class Initialized
DEBUG - 2022-12-12 10:37:52 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:37:52 --> Utf8 Class Initialized
INFO - 2022-12-12 10:37:52 --> URI Class Initialized
INFO - 2022-12-12 10:37:52 --> URI Class Initialized
INFO - 2022-12-12 10:37:52 --> Router Class Initialized
INFO - 2022-12-12 10:37:52 --> Router Class Initialized
INFO - 2022-12-12 10:37:52 --> Output Class Initialized
INFO - 2022-12-12 10:37:52 --> Output Class Initialized
INFO - 2022-12-12 10:37:52 --> Security Class Initialized
INFO - 2022-12-12 10:37:52 --> Security Class Initialized
DEBUG - 2022-12-12 10:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:37:52 --> Input Class Initialized
DEBUG - 2022-12-12 10:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:37:52 --> Input Class Initialized
INFO - 2022-12-12 10:37:52 --> Language Class Initialized
INFO - 2022-12-12 10:37:52 --> Language Class Initialized
INFO - 2022-12-12 10:37:52 --> Loader Class Initialized
INFO - 2022-12-12 10:37:52 --> Loader Class Initialized
INFO - 2022-12-12 10:37:52 --> Controller Class Initialized
INFO - 2022-12-12 10:37:52 --> Controller Class Initialized
DEBUG - 2022-12-12 10:37:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 10:37:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:37:52 --> Final output sent to browser
DEBUG - 2022-12-12 10:37:52 --> Total execution time: 0.0281
INFO - 2022-12-12 10:37:52 --> Database Driver Class Initialized
INFO - 2022-12-12 10:37:52 --> Config Class Initialized
INFO - 2022-12-12 10:37:52 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:37:52 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:37:52 --> Utf8 Class Initialized
INFO - 2022-12-12 10:37:52 --> URI Class Initialized
INFO - 2022-12-12 10:37:52 --> Router Class Initialized
INFO - 2022-12-12 10:37:52 --> Output Class Initialized
INFO - 2022-12-12 10:37:52 --> Security Class Initialized
DEBUG - 2022-12-12 10:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:37:52 --> Input Class Initialized
INFO - 2022-12-12 10:37:52 --> Language Class Initialized
INFO - 2022-12-12 10:37:52 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:37:52 --> Loader Class Initialized
INFO - 2022-12-12 10:37:52 --> Controller Class Initialized
INFO - 2022-12-12 10:37:52 --> Final output sent to browser
DEBUG - 2022-12-12 10:37:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 10:37:52 --> Total execution time: 0.0652
INFO - 2022-12-12 10:37:52 --> Database Driver Class Initialized
INFO - 2022-12-12 10:37:52 --> Config Class Initialized
INFO - 2022-12-12 10:37:52 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:37:52 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:37:52 --> Utf8 Class Initialized
INFO - 2022-12-12 10:37:52 --> URI Class Initialized
INFO - 2022-12-12 10:37:52 --> Router Class Initialized
INFO - 2022-12-12 10:37:52 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:37:52 --> Output Class Initialized
INFO - 2022-12-12 10:37:52 --> Security Class Initialized
DEBUG - 2022-12-12 10:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:37:52 --> Input Class Initialized
INFO - 2022-12-12 10:37:52 --> Language Class Initialized
INFO - 2022-12-12 10:37:52 --> Final output sent to browser
DEBUG - 2022-12-12 10:37:52 --> Total execution time: 0.0538
INFO - 2022-12-12 10:37:52 --> Loader Class Initialized
INFO - 2022-12-12 10:37:52 --> Controller Class Initialized
DEBUG - 2022-12-12 10:37:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:37:52 --> Database Driver Class Initialized
INFO - 2022-12-12 10:37:52 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:37:52 --> Final output sent to browser
DEBUG - 2022-12-12 10:37:52 --> Total execution time: 0.0403
INFO - 2022-12-12 10:38:00 --> Config Class Initialized
INFO - 2022-12-12 10:38:00 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:00 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:00 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:00 --> URI Class Initialized
INFO - 2022-12-12 10:38:00 --> Router Class Initialized
INFO - 2022-12-12 10:38:00 --> Output Class Initialized
INFO - 2022-12-12 10:38:00 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:00 --> Input Class Initialized
INFO - 2022-12-12 10:38:00 --> Language Class Initialized
INFO - 2022-12-12 10:38:00 --> Loader Class Initialized
INFO - 2022-12-12 10:38:00 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:00 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:00 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:00 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:00 --> Total execution time: 0.0609
INFO - 2022-12-12 10:38:00 --> Config Class Initialized
INFO - 2022-12-12 10:38:00 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:00 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:00 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:00 --> URI Class Initialized
INFO - 2022-12-12 10:38:00 --> Router Class Initialized
INFO - 2022-12-12 10:38:00 --> Output Class Initialized
INFO - 2022-12-12 10:38:00 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:00 --> Input Class Initialized
INFO - 2022-12-12 10:38:00 --> Language Class Initialized
INFO - 2022-12-12 10:38:00 --> Loader Class Initialized
INFO - 2022-12-12 10:38:00 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:00 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:00 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:00 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:00 --> Total execution time: 0.4401
INFO - 2022-12-12 10:38:02 --> Config Class Initialized
INFO - 2022-12-12 10:38:02 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:02 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:02 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:02 --> URI Class Initialized
INFO - 2022-12-12 10:38:02 --> Router Class Initialized
INFO - 2022-12-12 10:38:02 --> Output Class Initialized
INFO - 2022-12-12 10:38:02 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:02 --> Input Class Initialized
INFO - 2022-12-12 10:38:02 --> Language Class Initialized
INFO - 2022-12-12 10:38:02 --> Loader Class Initialized
INFO - 2022-12-12 10:38:02 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:02 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:02 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:02 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:02 --> Total execution time: 0.2505
INFO - 2022-12-12 10:38:02 --> Config Class Initialized
INFO - 2022-12-12 10:38:02 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:02 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:02 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:02 --> URI Class Initialized
INFO - 2022-12-12 10:38:02 --> Router Class Initialized
INFO - 2022-12-12 10:38:02 --> Output Class Initialized
INFO - 2022-12-12 10:38:02 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:02 --> Input Class Initialized
INFO - 2022-12-12 10:38:02 --> Language Class Initialized
INFO - 2022-12-12 10:38:02 --> Loader Class Initialized
INFO - 2022-12-12 10:38:02 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:02 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:02 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:02 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:02 --> Total execution time: 0.0463
INFO - 2022-12-12 10:38:04 --> Config Class Initialized
INFO - 2022-12-12 10:38:04 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:04 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:04 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:04 --> URI Class Initialized
INFO - 2022-12-12 10:38:04 --> Router Class Initialized
INFO - 2022-12-12 10:38:04 --> Output Class Initialized
INFO - 2022-12-12 10:38:04 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:04 --> Input Class Initialized
INFO - 2022-12-12 10:38:04 --> Language Class Initialized
INFO - 2022-12-12 10:38:04 --> Loader Class Initialized
INFO - 2022-12-12 10:38:04 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:04 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:04 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:04 --> Total execution time: 0.0199
INFO - 2022-12-12 10:38:04 --> Config Class Initialized
INFO - 2022-12-12 10:38:04 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:04 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:04 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:04 --> URI Class Initialized
INFO - 2022-12-12 10:38:04 --> Router Class Initialized
INFO - 2022-12-12 10:38:04 --> Output Class Initialized
INFO - 2022-12-12 10:38:04 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:04 --> Input Class Initialized
INFO - 2022-12-12 10:38:04 --> Language Class Initialized
INFO - 2022-12-12 10:38:05 --> Loader Class Initialized
INFO - 2022-12-12 10:38:05 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:05 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:05 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:05 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:05 --> Total execution time: 0.0530
INFO - 2022-12-12 10:38:07 --> Config Class Initialized
INFO - 2022-12-12 10:38:07 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:07 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:07 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:07 --> URI Class Initialized
INFO - 2022-12-12 10:38:07 --> Router Class Initialized
INFO - 2022-12-12 10:38:07 --> Output Class Initialized
INFO - 2022-12-12 10:38:07 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:07 --> Input Class Initialized
INFO - 2022-12-12 10:38:07 --> Language Class Initialized
INFO - 2022-12-12 10:38:07 --> Loader Class Initialized
INFO - 2022-12-12 10:38:07 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:07 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:12 --> Config Class Initialized
INFO - 2022-12-12 10:38:12 --> Config Class Initialized
INFO - 2022-12-12 10:38:12 --> Hooks Class Initialized
INFO - 2022-12-12 10:38:12 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 10:38:12 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:12 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:12 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:12 --> URI Class Initialized
INFO - 2022-12-12 10:38:12 --> URI Class Initialized
INFO - 2022-12-12 10:38:12 --> Router Class Initialized
INFO - 2022-12-12 10:38:12 --> Router Class Initialized
INFO - 2022-12-12 10:38:12 --> Output Class Initialized
INFO - 2022-12-12 10:38:12 --> Output Class Initialized
INFO - 2022-12-12 10:38:12 --> Security Class Initialized
INFO - 2022-12-12 10:38:12 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:12 --> Input Class Initialized
DEBUG - 2022-12-12 10:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:12 --> Input Class Initialized
INFO - 2022-12-12 10:38:12 --> Language Class Initialized
INFO - 2022-12-12 10:38:12 --> Language Class Initialized
INFO - 2022-12-12 10:38:12 --> Loader Class Initialized
INFO - 2022-12-12 10:38:12 --> Loader Class Initialized
INFO - 2022-12-12 10:38:12 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:12 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:12 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:12 --> Database Driver Class Initialized
ERROR - 2022-12-12 10:38:17 --> Exception of type 'mysqli_sql_exception' occurred with Message: 由于连接方在一段时间后没有正确答复或连接的主机没有反应，连接尝试失败。 in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php at Line 203
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php(203): mysqli->real_connect('192.168.0.128', 'pgx', 'pgx_pwd', 'kunlun_metadata...', 10016, NULL, 0)
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(401): CI_DB_mysqli_driver->db_connect(false)
#2 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB.php(216): CI_DB_driver->initialize()
#3 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\Loader.php(391): DB(Array, NULL)
#4 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\models\Cluster_model.php(9): CI_Loader->database('default', true)
#5 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\Loader.php(357): Cluster_model->__construct()
#6 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Cluster.php(494): CI_Loader->model('Cluster_model')
#7 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Cluster->getShards()
#8 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#9 {main}
INFO - 2022-12-12 10:38:18 --> Config Class Initialized
INFO - 2022-12-12 10:38:18 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:18 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:18 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:18 --> URI Class Initialized
INFO - 2022-12-12 10:38:18 --> Router Class Initialized
INFO - 2022-12-12 10:38:18 --> Output Class Initialized
INFO - 2022-12-12 10:38:18 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:18 --> Input Class Initialized
INFO - 2022-12-12 10:38:18 --> Language Class Initialized
INFO - 2022-12-12 10:38:18 --> Loader Class Initialized
INFO - 2022-12-12 10:38:18 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:18 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:18 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:18 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:18 --> Model "Login_model" initialized
INFO - 2022-12-12 10:38:18 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:18 --> Total execution time: 0.2419
INFO - 2022-12-12 10:38:18 --> Config Class Initialized
INFO - 2022-12-12 10:38:18 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:18 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:18 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:18 --> URI Class Initialized
INFO - 2022-12-12 10:38:18 --> Router Class Initialized
INFO - 2022-12-12 10:38:18 --> Output Class Initialized
INFO - 2022-12-12 10:38:18 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:18 --> Input Class Initialized
INFO - 2022-12-12 10:38:18 --> Language Class Initialized
INFO - 2022-12-12 10:38:18 --> Loader Class Initialized
INFO - 2022-12-12 10:38:18 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:18 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:18 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:18 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:19 --> Model "Login_model" initialized
INFO - 2022-12-12 10:38:19 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:19 --> Total execution time: 0.4020
INFO - 2022-12-12 10:38:19 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:19 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:19 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:19 --> Total execution time: 7.0626
INFO - 2022-12-12 10:38:24 --> Config Class Initialized
INFO - 2022-12-12 10:38:24 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:24 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:24 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:24 --> URI Class Initialized
INFO - 2022-12-12 10:38:24 --> Router Class Initialized
INFO - 2022-12-12 10:38:24 --> Output Class Initialized
INFO - 2022-12-12 10:38:24 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:24 --> Input Class Initialized
INFO - 2022-12-12 10:38:24 --> Language Class Initialized
INFO - 2022-12-12 10:38:24 --> Loader Class Initialized
INFO - 2022-12-12 10:38:24 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:24 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:25 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:25 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:25 --> Model "Login_model" initialized
INFO - 2022-12-12 10:38:25 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:25 --> Total execution time: 0.4179
INFO - 2022-12-12 10:38:25 --> Config Class Initialized
INFO - 2022-12-12 10:38:25 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:25 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:25 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:25 --> URI Class Initialized
INFO - 2022-12-12 10:38:25 --> Router Class Initialized
INFO - 2022-12-12 10:38:25 --> Output Class Initialized
INFO - 2022-12-12 10:38:25 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:25 --> Input Class Initialized
INFO - 2022-12-12 10:38:25 --> Language Class Initialized
INFO - 2022-12-12 10:38:25 --> Loader Class Initialized
INFO - 2022-12-12 10:38:25 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:25 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:25 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:25 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:25 --> Model "Login_model" initialized
INFO - 2022-12-12 10:38:25 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:25 --> Total execution time: 0.3509
INFO - 2022-12-12 10:38:35 --> Config Class Initialized
INFO - 2022-12-12 10:38:35 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:35 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:35 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:35 --> URI Class Initialized
INFO - 2022-12-12 10:38:35 --> Router Class Initialized
INFO - 2022-12-12 10:38:35 --> Output Class Initialized
INFO - 2022-12-12 10:38:35 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:35 --> Input Class Initialized
INFO - 2022-12-12 10:38:35 --> Language Class Initialized
INFO - 2022-12-12 10:38:35 --> Loader Class Initialized
INFO - 2022-12-12 10:38:35 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:35 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:35 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:35 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:35 --> Model "Login_model" initialized
INFO - 2022-12-12 10:38:35 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:35 --> Total execution time: 0.1217
INFO - 2022-12-12 10:38:49 --> Config Class Initialized
INFO - 2022-12-12 10:38:49 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:49 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:49 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:49 --> URI Class Initialized
INFO - 2022-12-12 10:38:49 --> Router Class Initialized
INFO - 2022-12-12 10:38:49 --> Output Class Initialized
INFO - 2022-12-12 10:38:49 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:49 --> Input Class Initialized
INFO - 2022-12-12 10:38:49 --> Language Class Initialized
INFO - 2022-12-12 10:38:49 --> Loader Class Initialized
INFO - 2022-12-12 10:38:49 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:49 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:49 --> Total execution time: 0.0212
INFO - 2022-12-12 10:38:49 --> Config Class Initialized
INFO - 2022-12-12 10:38:49 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:49 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:49 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:49 --> URI Class Initialized
INFO - 2022-12-12 10:38:49 --> Router Class Initialized
INFO - 2022-12-12 10:38:49 --> Output Class Initialized
INFO - 2022-12-12 10:38:49 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:49 --> Input Class Initialized
INFO - 2022-12-12 10:38:49 --> Language Class Initialized
INFO - 2022-12-12 10:38:49 --> Loader Class Initialized
INFO - 2022-12-12 10:38:49 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:49 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:49 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:49 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:49 --> Total execution time: 0.0606
INFO - 2022-12-12 10:38:59 --> Config Class Initialized
INFO - 2022-12-12 10:38:59 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:59 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:59 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:59 --> URI Class Initialized
INFO - 2022-12-12 10:38:59 --> Router Class Initialized
INFO - 2022-12-12 10:38:59 --> Output Class Initialized
INFO - 2022-12-12 10:38:59 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:59 --> Input Class Initialized
INFO - 2022-12-12 10:38:59 --> Language Class Initialized
INFO - 2022-12-12 10:38:59 --> Loader Class Initialized
INFO - 2022-12-12 10:38:59 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:59 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:59 --> Total execution time: 0.0200
INFO - 2022-12-12 10:38:59 --> Config Class Initialized
INFO - 2022-12-12 10:38:59 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:59 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:59 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:59 --> URI Class Initialized
INFO - 2022-12-12 10:38:59 --> Router Class Initialized
INFO - 2022-12-12 10:38:59 --> Output Class Initialized
INFO - 2022-12-12 10:38:59 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:59 --> Input Class Initialized
INFO - 2022-12-12 10:38:59 --> Language Class Initialized
INFO - 2022-12-12 10:38:59 --> Loader Class Initialized
INFO - 2022-12-12 10:38:59 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:59 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:59 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:59 --> Final output sent to browser
DEBUG - 2022-12-12 10:38:59 --> Total execution time: 0.0505
INFO - 2022-12-12 10:38:59 --> Config Class Initialized
INFO - 2022-12-12 10:38:59 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:59 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:59 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:59 --> URI Class Initialized
INFO - 2022-12-12 10:38:59 --> Router Class Initialized
INFO - 2022-12-12 10:38:59 --> Output Class Initialized
INFO - 2022-12-12 10:38:59 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:59 --> Input Class Initialized
INFO - 2022-12-12 10:38:59 --> Language Class Initialized
INFO - 2022-12-12 10:38:59 --> Loader Class Initialized
INFO - 2022-12-12 10:38:59 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:59 --> Database Driver Class Initialized
INFO - 2022-12-12 10:38:59 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:38:59 --> Config Class Initialized
INFO - 2022-12-12 10:38:59 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:38:59 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:38:59 --> Utf8 Class Initialized
INFO - 2022-12-12 10:38:59 --> URI Class Initialized
INFO - 2022-12-12 10:38:59 --> Router Class Initialized
INFO - 2022-12-12 10:38:59 --> Output Class Initialized
INFO - 2022-12-12 10:38:59 --> Security Class Initialized
DEBUG - 2022-12-12 10:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:38:59 --> Input Class Initialized
INFO - 2022-12-12 10:38:59 --> Language Class Initialized
INFO - 2022-12-12 10:38:59 --> Loader Class Initialized
INFO - 2022-12-12 10:38:59 --> Controller Class Initialized
DEBUG - 2022-12-12 10:38:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:38:59 --> Database Driver Class Initialized
INFO - 2022-12-12 10:39:00 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:39:01 --> Config Class Initialized
INFO - 2022-12-12 10:39:01 --> Config Class Initialized
INFO - 2022-12-12 10:39:01 --> Hooks Class Initialized
INFO - 2022-12-12 10:39:01 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 10:39:01 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:39:01 --> Utf8 Class Initialized
INFO - 2022-12-12 10:39:01 --> Utf8 Class Initialized
INFO - 2022-12-12 10:39:01 --> URI Class Initialized
INFO - 2022-12-12 10:39:01 --> URI Class Initialized
INFO - 2022-12-12 10:39:01 --> Router Class Initialized
INFO - 2022-12-12 10:39:01 --> Router Class Initialized
INFO - 2022-12-12 10:39:01 --> Output Class Initialized
INFO - 2022-12-12 10:39:01 --> Output Class Initialized
INFO - 2022-12-12 10:39:01 --> Security Class Initialized
INFO - 2022-12-12 10:39:01 --> Security Class Initialized
DEBUG - 2022-12-12 10:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:39:01 --> Input Class Initialized
DEBUG - 2022-12-12 10:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:39:01 --> Input Class Initialized
INFO - 2022-12-12 10:39:01 --> Language Class Initialized
INFO - 2022-12-12 10:39:01 --> Language Class Initialized
INFO - 2022-12-12 10:39:01 --> Loader Class Initialized
INFO - 2022-12-12 10:39:01 --> Loader Class Initialized
INFO - 2022-12-12 10:39:01 --> Controller Class Initialized
DEBUG - 2022-12-12 10:39:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:39:01 --> Controller Class Initialized
DEBUG - 2022-12-12 10:39:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:39:01 --> Database Driver Class Initialized
INFO - 2022-12-12 10:39:01 --> Database Driver Class Initialized
INFO - 2022-12-12 10:39:01 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:39:01 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:39:01 --> Final output sent to browser
DEBUG - 2022-12-12 10:39:01 --> Total execution time: 0.0491
INFO - 2022-12-12 10:39:01 --> Config Class Initialized
INFO - 2022-12-12 10:39:01 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:39:01 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:39:01 --> Utf8 Class Initialized
INFO - 2022-12-12 10:39:01 --> URI Class Initialized
INFO - 2022-12-12 10:39:01 --> Router Class Initialized
INFO - 2022-12-12 10:39:01 --> Config Class Initialized
INFO - 2022-12-12 10:39:01 --> Output Class Initialized
INFO - 2022-12-12 10:39:01 --> Hooks Class Initialized
INFO - 2022-12-12 10:39:01 --> Security Class Initialized
DEBUG - 2022-12-12 10:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:39:01 --> Input Class Initialized
DEBUG - 2022-12-12 10:39:01 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:39:01 --> Utf8 Class Initialized
INFO - 2022-12-12 10:39:01 --> Language Class Initialized
INFO - 2022-12-12 10:39:01 --> URI Class Initialized
INFO - 2022-12-12 10:39:01 --> Router Class Initialized
INFO - 2022-12-12 10:39:01 --> Loader Class Initialized
INFO - 2022-12-12 10:39:01 --> Output Class Initialized
INFO - 2022-12-12 10:39:01 --> Controller Class Initialized
DEBUG - 2022-12-12 10:39:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:39:01 --> Security Class Initialized
DEBUG - 2022-12-12 10:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:39:01 --> Input Class Initialized
INFO - 2022-12-12 10:39:01 --> Language Class Initialized
INFO - 2022-12-12 10:39:01 --> Database Driver Class Initialized
INFO - 2022-12-12 10:39:01 --> Loader Class Initialized
INFO - 2022-12-12 10:39:01 --> Controller Class Initialized
DEBUG - 2022-12-12 10:39:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:39:01 --> Database Driver Class Initialized
INFO - 2022-12-12 10:39:01 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:39:01 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:39:01 --> Final output sent to browser
DEBUG - 2022-12-12 10:39:01 --> Total execution time: 0.0509
INFO - 2022-12-12 10:55:53 --> Config Class Initialized
INFO - 2022-12-12 10:55:53 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:55:53 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:55:53 --> Utf8 Class Initialized
INFO - 2022-12-12 10:55:53 --> URI Class Initialized
INFO - 2022-12-12 10:55:53 --> Router Class Initialized
INFO - 2022-12-12 10:55:53 --> Output Class Initialized
INFO - 2022-12-12 10:55:53 --> Security Class Initialized
DEBUG - 2022-12-12 10:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:55:53 --> Input Class Initialized
INFO - 2022-12-12 10:55:53 --> Language Class Initialized
INFO - 2022-12-12 10:55:53 --> Loader Class Initialized
INFO - 2022-12-12 10:55:53 --> Controller Class Initialized
DEBUG - 2022-12-12 10:55:53 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:55:53 --> Database Driver Class Initialized
INFO - 2022-12-12 10:55:53 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:55:53 --> Config Class Initialized
INFO - 2022-12-12 10:55:53 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:55:53 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:55:53 --> Utf8 Class Initialized
INFO - 2022-12-12 10:55:53 --> URI Class Initialized
INFO - 2022-12-12 10:55:53 --> Router Class Initialized
INFO - 2022-12-12 10:55:53 --> Output Class Initialized
INFO - 2022-12-12 10:55:53 --> Security Class Initialized
DEBUG - 2022-12-12 10:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:55:53 --> Input Class Initialized
INFO - 2022-12-12 10:55:53 --> Language Class Initialized
INFO - 2022-12-12 10:55:53 --> Loader Class Initialized
INFO - 2022-12-12 10:55:53 --> Controller Class Initialized
DEBUG - 2022-12-12 10:55:53 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:55:53 --> Database Driver Class Initialized
INFO - 2022-12-12 10:55:53 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:56:48 --> Config Class Initialized
INFO - 2022-12-12 10:56:48 --> Hooks Class Initialized
INFO - 2022-12-12 10:56:48 --> Config Class Initialized
INFO - 2022-12-12 10:56:48 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 10:56:48 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:56:48 --> Utf8 Class Initialized
INFO - 2022-12-12 10:56:48 --> Utf8 Class Initialized
INFO - 2022-12-12 10:56:48 --> URI Class Initialized
INFO - 2022-12-12 10:56:48 --> URI Class Initialized
INFO - 2022-12-12 10:56:48 --> Router Class Initialized
INFO - 2022-12-12 10:56:48 --> Router Class Initialized
INFO - 2022-12-12 10:56:48 --> Output Class Initialized
INFO - 2022-12-12 10:56:48 --> Output Class Initialized
INFO - 2022-12-12 10:56:48 --> Security Class Initialized
INFO - 2022-12-12 10:56:48 --> Security Class Initialized
DEBUG - 2022-12-12 10:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-12 10:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:56:48 --> Input Class Initialized
INFO - 2022-12-12 10:56:48 --> Input Class Initialized
INFO - 2022-12-12 10:56:48 --> Language Class Initialized
INFO - 2022-12-12 10:56:48 --> Language Class Initialized
INFO - 2022-12-12 10:56:48 --> Loader Class Initialized
INFO - 2022-12-12 10:56:48 --> Loader Class Initialized
INFO - 2022-12-12 10:56:48 --> Controller Class Initialized
INFO - 2022-12-12 10:56:48 --> Controller Class Initialized
DEBUG - 2022-12-12 10:56:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 10:56:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:56:48 --> Database Driver Class Initialized
INFO - 2022-12-12 10:56:48 --> Database Driver Class Initialized
INFO - 2022-12-12 10:56:48 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:56:48 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:56:48 --> Final output sent to browser
DEBUG - 2022-12-12 10:56:48 --> Total execution time: 0.0545
INFO - 2022-12-12 10:56:48 --> Config Class Initialized
INFO - 2022-12-12 10:56:48 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:56:48 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:56:48 --> Utf8 Class Initialized
INFO - 2022-12-12 10:56:48 --> URI Class Initialized
INFO - 2022-12-12 10:56:48 --> Router Class Initialized
INFO - 2022-12-12 10:56:48 --> Output Class Initialized
INFO - 2022-12-12 10:56:48 --> Security Class Initialized
DEBUG - 2022-12-12 10:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:56:48 --> Input Class Initialized
INFO - 2022-12-12 10:56:48 --> Language Class Initialized
INFO - 2022-12-12 10:56:48 --> Loader Class Initialized
INFO - 2022-12-12 10:56:48 --> Controller Class Initialized
DEBUG - 2022-12-12 10:56:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:56:48 --> Database Driver Class Initialized
INFO - 2022-12-12 10:56:48 --> Config Class Initialized
INFO - 2022-12-12 10:56:48 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:56:48 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:56:48 --> Utf8 Class Initialized
INFO - 2022-12-12 10:56:48 --> URI Class Initialized
INFO - 2022-12-12 10:56:48 --> Router Class Initialized
INFO - 2022-12-12 10:56:48 --> Output Class Initialized
INFO - 2022-12-12 10:56:48 --> Security Class Initialized
DEBUG - 2022-12-12 10:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:56:48 --> Input Class Initialized
INFO - 2022-12-12 10:56:48 --> Language Class Initialized
INFO - 2022-12-12 10:56:48 --> Loader Class Initialized
INFO - 2022-12-12 10:56:48 --> Controller Class Initialized
DEBUG - 2022-12-12 10:56:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:56:48 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:56:48 --> Database Driver Class Initialized
INFO - 2022-12-12 10:56:48 --> Final output sent to browser
DEBUG - 2022-12-12 10:56:48 --> Total execution time: 0.0559
INFO - 2022-12-12 10:56:48 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:56:51 --> Config Class Initialized
INFO - 2022-12-12 10:56:51 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:56:51 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:56:51 --> Utf8 Class Initialized
INFO - 2022-12-12 10:56:51 --> URI Class Initialized
INFO - 2022-12-12 10:56:51 --> Router Class Initialized
INFO - 2022-12-12 10:56:51 --> Output Class Initialized
INFO - 2022-12-12 10:56:51 --> Security Class Initialized
DEBUG - 2022-12-12 10:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:56:51 --> Input Class Initialized
INFO - 2022-12-12 10:56:51 --> Language Class Initialized
INFO - 2022-12-12 10:56:51 --> Loader Class Initialized
INFO - 2022-12-12 10:56:51 --> Controller Class Initialized
DEBUG - 2022-12-12 10:56:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:56:51 --> Final output sent to browser
DEBUG - 2022-12-12 10:56:51 --> Total execution time: 0.0195
INFO - 2022-12-12 10:56:51 --> Config Class Initialized
INFO - 2022-12-12 10:56:51 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:56:51 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:56:51 --> Utf8 Class Initialized
INFO - 2022-12-12 10:56:51 --> URI Class Initialized
INFO - 2022-12-12 10:56:51 --> Router Class Initialized
INFO - 2022-12-12 10:56:51 --> Output Class Initialized
INFO - 2022-12-12 10:56:51 --> Security Class Initialized
DEBUG - 2022-12-12 10:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:56:51 --> Input Class Initialized
INFO - 2022-12-12 10:56:51 --> Language Class Initialized
INFO - 2022-12-12 10:56:51 --> Loader Class Initialized
INFO - 2022-12-12 10:56:51 --> Controller Class Initialized
DEBUG - 2022-12-12 10:56:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:56:51 --> Database Driver Class Initialized
INFO - 2022-12-12 10:56:51 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:56:51 --> Final output sent to browser
DEBUG - 2022-12-12 10:56:51 --> Total execution time: 0.0341
INFO - 2022-12-12 10:56:52 --> Config Class Initialized
INFO - 2022-12-12 10:56:52 --> Config Class Initialized
INFO - 2022-12-12 10:56:52 --> Hooks Class Initialized
INFO - 2022-12-12 10:56:52 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 10:56:52 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:56:52 --> Utf8 Class Initialized
INFO - 2022-12-12 10:56:52 --> Utf8 Class Initialized
INFO - 2022-12-12 10:56:52 --> URI Class Initialized
INFO - 2022-12-12 10:56:52 --> URI Class Initialized
INFO - 2022-12-12 10:56:52 --> Router Class Initialized
INFO - 2022-12-12 10:56:52 --> Router Class Initialized
INFO - 2022-12-12 10:56:52 --> Output Class Initialized
INFO - 2022-12-12 10:56:52 --> Output Class Initialized
INFO - 2022-12-12 10:56:52 --> Security Class Initialized
INFO - 2022-12-12 10:56:52 --> Security Class Initialized
DEBUG - 2022-12-12 10:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-12 10:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:56:52 --> Input Class Initialized
INFO - 2022-12-12 10:56:52 --> Input Class Initialized
INFO - 2022-12-12 10:56:52 --> Language Class Initialized
INFO - 2022-12-12 10:56:52 --> Language Class Initialized
INFO - 2022-12-12 10:56:52 --> Loader Class Initialized
INFO - 2022-12-12 10:56:52 --> Loader Class Initialized
INFO - 2022-12-12 10:56:52 --> Controller Class Initialized
INFO - 2022-12-12 10:56:52 --> Controller Class Initialized
DEBUG - 2022-12-12 10:56:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 10:56:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:56:52 --> Database Driver Class Initialized
INFO - 2022-12-12 10:56:52 --> Database Driver Class Initialized
INFO - 2022-12-12 10:56:52 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:56:52 --> Final output sent to browser
DEBUG - 2022-12-12 10:56:52 --> Total execution time: 0.0344
INFO - 2022-12-12 10:56:52 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:58:03 --> Config Class Initialized
INFO - 2022-12-12 10:58:03 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:58:03 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:58:03 --> Utf8 Class Initialized
INFO - 2022-12-12 10:58:03 --> URI Class Initialized
INFO - 2022-12-12 10:58:03 --> Router Class Initialized
INFO - 2022-12-12 10:58:03 --> Output Class Initialized
INFO - 2022-12-12 10:58:03 --> Security Class Initialized
DEBUG - 2022-12-12 10:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:58:03 --> Input Class Initialized
INFO - 2022-12-12 10:58:03 --> Language Class Initialized
INFO - 2022-12-12 10:58:03 --> Loader Class Initialized
INFO - 2022-12-12 10:58:03 --> Controller Class Initialized
DEBUG - 2022-12-12 10:58:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:58:03 --> Database Driver Class Initialized
INFO - 2022-12-12 10:58:03 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:58:03 --> Config Class Initialized
INFO - 2022-12-12 10:58:03 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:58:03 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:58:03 --> Utf8 Class Initialized
INFO - 2022-12-12 10:58:03 --> URI Class Initialized
INFO - 2022-12-12 10:58:03 --> Router Class Initialized
INFO - 2022-12-12 10:58:03 --> Output Class Initialized
INFO - 2022-12-12 10:58:03 --> Security Class Initialized
DEBUG - 2022-12-12 10:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:58:03 --> Input Class Initialized
INFO - 2022-12-12 10:58:03 --> Language Class Initialized
INFO - 2022-12-12 10:58:03 --> Loader Class Initialized
INFO - 2022-12-12 10:58:03 --> Controller Class Initialized
DEBUG - 2022-12-12 10:58:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:58:03 --> Database Driver Class Initialized
INFO - 2022-12-12 10:58:03 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:58:32 --> Config Class Initialized
INFO - 2022-12-12 10:58:32 --> Config Class Initialized
INFO - 2022-12-12 10:58:32 --> Hooks Class Initialized
INFO - 2022-12-12 10:58:32 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 10:58:32 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:58:32 --> Utf8 Class Initialized
INFO - 2022-12-12 10:58:32 --> Utf8 Class Initialized
INFO - 2022-12-12 10:58:32 --> URI Class Initialized
INFO - 2022-12-12 10:58:32 --> URI Class Initialized
INFO - 2022-12-12 10:58:32 --> Router Class Initialized
INFO - 2022-12-12 10:58:32 --> Router Class Initialized
INFO - 2022-12-12 10:58:32 --> Output Class Initialized
INFO - 2022-12-12 10:58:32 --> Output Class Initialized
INFO - 2022-12-12 10:58:32 --> Security Class Initialized
INFO - 2022-12-12 10:58:32 --> Security Class Initialized
DEBUG - 2022-12-12 10:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:58:32 --> Input Class Initialized
DEBUG - 2022-12-12 10:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:58:32 --> Input Class Initialized
INFO - 2022-12-12 10:58:32 --> Language Class Initialized
INFO - 2022-12-12 10:58:32 --> Language Class Initialized
INFO - 2022-12-12 10:58:32 --> Loader Class Initialized
INFO - 2022-12-12 10:58:32 --> Loader Class Initialized
INFO - 2022-12-12 10:58:32 --> Controller Class Initialized
DEBUG - 2022-12-12 10:58:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:58:32 --> Controller Class Initialized
DEBUG - 2022-12-12 10:58:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:58:32 --> Database Driver Class Initialized
INFO - 2022-12-12 10:58:32 --> Database Driver Class Initialized
INFO - 2022-12-12 10:58:33 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:58:33 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:58:33 --> Final output sent to browser
DEBUG - 2022-12-12 10:58:33 --> Total execution time: 1.3135
INFO - 2022-12-12 10:58:33 --> Config Class Initialized
INFO - 2022-12-12 10:58:33 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:58:33 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:58:33 --> Utf8 Class Initialized
INFO - 2022-12-12 10:58:33 --> URI Class Initialized
INFO - 2022-12-12 10:58:33 --> Router Class Initialized
INFO - 2022-12-12 10:58:33 --> Output Class Initialized
INFO - 2022-12-12 10:58:33 --> Security Class Initialized
DEBUG - 2022-12-12 10:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:58:33 --> Input Class Initialized
INFO - 2022-12-12 10:58:33 --> Language Class Initialized
INFO - 2022-12-12 10:58:33 --> Loader Class Initialized
INFO - 2022-12-12 10:58:33 --> Controller Class Initialized
DEBUG - 2022-12-12 10:58:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:58:33 --> Database Driver Class Initialized
INFO - 2022-12-12 10:58:33 --> Config Class Initialized
INFO - 2022-12-12 10:58:33 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:58:33 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:58:33 --> Utf8 Class Initialized
INFO - 2022-12-12 10:58:33 --> URI Class Initialized
INFO - 2022-12-12 10:58:33 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:58:33 --> Router Class Initialized
INFO - 2022-12-12 10:58:33 --> Final output sent to browser
DEBUG - 2022-12-12 10:58:33 --> Total execution time: 0.0576
INFO - 2022-12-12 10:58:33 --> Output Class Initialized
INFO - 2022-12-12 10:58:33 --> Security Class Initialized
DEBUG - 2022-12-12 10:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:58:33 --> Input Class Initialized
INFO - 2022-12-12 10:58:33 --> Language Class Initialized
INFO - 2022-12-12 10:58:33 --> Loader Class Initialized
INFO - 2022-12-12 10:58:33 --> Controller Class Initialized
DEBUG - 2022-12-12 10:58:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:58:33 --> Database Driver Class Initialized
INFO - 2022-12-12 10:58:33 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:58:36 --> Config Class Initialized
INFO - 2022-12-12 10:58:36 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:58:36 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:58:36 --> Utf8 Class Initialized
INFO - 2022-12-12 10:58:36 --> URI Class Initialized
INFO - 2022-12-12 10:58:36 --> Router Class Initialized
INFO - 2022-12-12 10:58:36 --> Output Class Initialized
INFO - 2022-12-12 10:58:36 --> Security Class Initialized
DEBUG - 2022-12-12 10:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:58:36 --> Input Class Initialized
INFO - 2022-12-12 10:58:36 --> Language Class Initialized
INFO - 2022-12-12 10:58:36 --> Loader Class Initialized
INFO - 2022-12-12 10:58:36 --> Controller Class Initialized
DEBUG - 2022-12-12 10:58:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:58:36 --> Database Driver Class Initialized
INFO - 2022-12-12 10:58:36 --> Model "Cluster_model" initialized
INFO - 2022-12-12 10:58:36 --> Config Class Initialized
INFO - 2022-12-12 10:58:36 --> Hooks Class Initialized
DEBUG - 2022-12-12 10:58:36 --> UTF-8 Support Enabled
INFO - 2022-12-12 10:58:36 --> Utf8 Class Initialized
INFO - 2022-12-12 10:58:36 --> URI Class Initialized
INFO - 2022-12-12 10:58:36 --> Router Class Initialized
INFO - 2022-12-12 10:58:36 --> Output Class Initialized
INFO - 2022-12-12 10:58:36 --> Security Class Initialized
DEBUG - 2022-12-12 10:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 10:58:36 --> Input Class Initialized
INFO - 2022-12-12 10:58:36 --> Language Class Initialized
INFO - 2022-12-12 10:58:36 --> Loader Class Initialized
INFO - 2022-12-12 10:58:36 --> Controller Class Initialized
DEBUG - 2022-12-12 10:58:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 10:58:36 --> Database Driver Class Initialized
INFO - 2022-12-12 10:58:36 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:01:34 --> Config Class Initialized
INFO - 2022-12-12 11:01:34 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:01:34 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:01:34 --> Utf8 Class Initialized
INFO - 2022-12-12 11:01:34 --> URI Class Initialized
INFO - 2022-12-12 11:01:34 --> Router Class Initialized
INFO - 2022-12-12 11:01:34 --> Output Class Initialized
INFO - 2022-12-12 11:01:34 --> Security Class Initialized
DEBUG - 2022-12-12 11:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:01:34 --> Input Class Initialized
INFO - 2022-12-12 11:01:34 --> Language Class Initialized
INFO - 2022-12-12 11:01:34 --> Loader Class Initialized
INFO - 2022-12-12 11:01:34 --> Controller Class Initialized
DEBUG - 2022-12-12 11:01:34 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:01:34 --> Database Driver Class Initialized
INFO - 2022-12-12 11:01:34 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:01:35 --> Config Class Initialized
INFO - 2022-12-12 11:01:35 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:01:35 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:01:35 --> Utf8 Class Initialized
INFO - 2022-12-12 11:01:35 --> URI Class Initialized
INFO - 2022-12-12 11:01:35 --> Router Class Initialized
INFO - 2022-12-12 11:01:35 --> Output Class Initialized
INFO - 2022-12-12 11:01:35 --> Security Class Initialized
DEBUG - 2022-12-12 11:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:01:35 --> Input Class Initialized
INFO - 2022-12-12 11:01:35 --> Language Class Initialized
INFO - 2022-12-12 11:01:35 --> Loader Class Initialized
INFO - 2022-12-12 11:01:35 --> Controller Class Initialized
DEBUG - 2022-12-12 11:01:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:01:35 --> Database Driver Class Initialized
INFO - 2022-12-12 11:01:35 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:09:20 --> Config Class Initialized
INFO - 2022-12-12 11:09:20 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:09:20 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:09:20 --> Utf8 Class Initialized
INFO - 2022-12-12 11:09:20 --> URI Class Initialized
INFO - 2022-12-12 11:09:20 --> Router Class Initialized
INFO - 2022-12-12 11:09:20 --> Output Class Initialized
INFO - 2022-12-12 11:09:20 --> Security Class Initialized
DEBUG - 2022-12-12 11:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:09:20 --> Input Class Initialized
INFO - 2022-12-12 11:09:20 --> Language Class Initialized
INFO - 2022-12-12 11:09:20 --> Loader Class Initialized
INFO - 2022-12-12 11:09:20 --> Controller Class Initialized
DEBUG - 2022-12-12 11:09:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:09:20 --> Database Driver Class Initialized
INFO - 2022-12-12 11:09:20 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:09:20 --> Config Class Initialized
INFO - 2022-12-12 11:09:20 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:09:20 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:09:20 --> Utf8 Class Initialized
INFO - 2022-12-12 11:09:20 --> URI Class Initialized
INFO - 2022-12-12 11:09:20 --> Router Class Initialized
INFO - 2022-12-12 11:09:20 --> Output Class Initialized
INFO - 2022-12-12 11:09:20 --> Security Class Initialized
DEBUG - 2022-12-12 11:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:09:20 --> Input Class Initialized
INFO - 2022-12-12 11:09:20 --> Language Class Initialized
INFO - 2022-12-12 11:09:20 --> Loader Class Initialized
INFO - 2022-12-12 11:09:20 --> Controller Class Initialized
DEBUG - 2022-12-12 11:09:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:09:20 --> Database Driver Class Initialized
INFO - 2022-12-12 11:09:20 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:09:52 --> Config Class Initialized
INFO - 2022-12-12 11:09:52 --> Hooks Class Initialized
INFO - 2022-12-12 11:09:52 --> Config Class Initialized
INFO - 2022-12-12 11:09:52 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:09:52 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:09:52 --> Utf8 Class Initialized
DEBUG - 2022-12-12 11:09:52 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:09:52 --> Utf8 Class Initialized
INFO - 2022-12-12 11:09:52 --> URI Class Initialized
INFO - 2022-12-12 11:09:52 --> URI Class Initialized
INFO - 2022-12-12 11:09:52 --> Router Class Initialized
INFO - 2022-12-12 11:09:52 --> Router Class Initialized
INFO - 2022-12-12 11:09:52 --> Output Class Initialized
INFO - 2022-12-12 11:09:52 --> Output Class Initialized
INFO - 2022-12-12 11:09:52 --> Security Class Initialized
INFO - 2022-12-12 11:09:52 --> Security Class Initialized
DEBUG - 2022-12-12 11:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:09:52 --> Input Class Initialized
DEBUG - 2022-12-12 11:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:09:52 --> Input Class Initialized
INFO - 2022-12-12 11:09:52 --> Language Class Initialized
INFO - 2022-12-12 11:09:52 --> Language Class Initialized
INFO - 2022-12-12 11:09:52 --> Loader Class Initialized
INFO - 2022-12-12 11:09:52 --> Loader Class Initialized
INFO - 2022-12-12 11:09:52 --> Controller Class Initialized
INFO - 2022-12-12 11:09:52 --> Controller Class Initialized
DEBUG - 2022-12-12 11:09:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 11:09:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:09:52 --> Database Driver Class Initialized
INFO - 2022-12-12 11:09:52 --> Database Driver Class Initialized
INFO - 2022-12-12 11:09:52 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:09:52 --> Final output sent to browser
DEBUG - 2022-12-12 11:09:52 --> Total execution time: 0.0684
INFO - 2022-12-12 11:09:52 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:09:52 --> Config Class Initialized
INFO - 2022-12-12 11:09:52 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:09:52 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:09:52 --> Utf8 Class Initialized
INFO - 2022-12-12 11:09:52 --> URI Class Initialized
INFO - 2022-12-12 11:09:52 --> Router Class Initialized
INFO - 2022-12-12 11:09:52 --> Output Class Initialized
INFO - 2022-12-12 11:09:52 --> Security Class Initialized
DEBUG - 2022-12-12 11:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:09:52 --> Input Class Initialized
INFO - 2022-12-12 11:09:52 --> Language Class Initialized
INFO - 2022-12-12 11:09:52 --> Loader Class Initialized
INFO - 2022-12-12 11:09:52 --> Controller Class Initialized
DEBUG - 2022-12-12 11:09:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:09:52 --> Database Driver Class Initialized
INFO - 2022-12-12 11:09:52 --> Config Class Initialized
INFO - 2022-12-12 11:09:52 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:09:52 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:09:52 --> Utf8 Class Initialized
INFO - 2022-12-12 11:09:52 --> URI Class Initialized
INFO - 2022-12-12 11:09:52 --> Router Class Initialized
INFO - 2022-12-12 11:09:52 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:09:52 --> Output Class Initialized
INFO - 2022-12-12 11:09:52 --> Security Class Initialized
INFO - 2022-12-12 11:09:52 --> Final output sent to browser
DEBUG - 2022-12-12 11:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-12 11:09:52 --> Total execution time: 0.0663
INFO - 2022-12-12 11:09:52 --> Input Class Initialized
INFO - 2022-12-12 11:09:52 --> Language Class Initialized
INFO - 2022-12-12 11:09:52 --> Loader Class Initialized
INFO - 2022-12-12 11:09:52 --> Controller Class Initialized
DEBUG - 2022-12-12 11:09:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:09:52 --> Database Driver Class Initialized
INFO - 2022-12-12 11:09:52 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:10:20 --> Config Class Initialized
INFO - 2022-12-12 11:10:20 --> Hooks Class Initialized
INFO - 2022-12-12 11:10:20 --> Config Class Initialized
INFO - 2022-12-12 11:10:20 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 11:10:20 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:10:20 --> Utf8 Class Initialized
INFO - 2022-12-12 11:10:20 --> Utf8 Class Initialized
INFO - 2022-12-12 11:10:20 --> URI Class Initialized
INFO - 2022-12-12 11:10:20 --> URI Class Initialized
INFO - 2022-12-12 11:10:20 --> Router Class Initialized
INFO - 2022-12-12 11:10:20 --> Router Class Initialized
INFO - 2022-12-12 11:10:20 --> Output Class Initialized
INFO - 2022-12-12 11:10:20 --> Output Class Initialized
INFO - 2022-12-12 11:10:20 --> Security Class Initialized
INFO - 2022-12-12 11:10:20 --> Security Class Initialized
DEBUG - 2022-12-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:10:20 --> Input Class Initialized
DEBUG - 2022-12-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:10:20 --> Input Class Initialized
INFO - 2022-12-12 11:10:20 --> Language Class Initialized
INFO - 2022-12-12 11:10:20 --> Language Class Initialized
INFO - 2022-12-12 11:10:20 --> Loader Class Initialized
INFO - 2022-12-12 11:10:20 --> Loader Class Initialized
INFO - 2022-12-12 11:10:20 --> Controller Class Initialized
INFO - 2022-12-12 11:10:20 --> Controller Class Initialized
DEBUG - 2022-12-12 11:10:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 11:10:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:10:20 --> Database Driver Class Initialized
INFO - 2022-12-12 11:10:20 --> Database Driver Class Initialized
INFO - 2022-12-12 11:10:20 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:10:20 --> Final output sent to browser
DEBUG - 2022-12-12 11:10:20 --> Total execution time: 0.0351
INFO - 2022-12-12 11:10:20 --> Config Class Initialized
INFO - 2022-12-12 11:10:20 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:10:20 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:10:20 --> Utf8 Class Initialized
INFO - 2022-12-12 11:10:20 --> URI Class Initialized
INFO - 2022-12-12 11:10:20 --> Router Class Initialized
INFO - 2022-12-12 11:10:20 --> Output Class Initialized
INFO - 2022-12-12 11:10:20 --> Security Class Initialized
INFO - 2022-12-12 11:10:20 --> Model "Cluster_model" initialized
DEBUG - 2022-12-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:10:20 --> Input Class Initialized
INFO - 2022-12-12 11:10:20 --> Language Class Initialized
INFO - 2022-12-12 11:10:20 --> Loader Class Initialized
INFO - 2022-12-12 11:10:20 --> Controller Class Initialized
DEBUG - 2022-12-12 11:10:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:10:20 --> Database Driver Class Initialized
INFO - 2022-12-12 11:10:20 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:10:20 --> Final output sent to browser
DEBUG - 2022-12-12 11:10:20 --> Total execution time: 0.0312
INFO - 2022-12-12 11:10:20 --> Config Class Initialized
INFO - 2022-12-12 11:10:20 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:10:20 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:10:20 --> Utf8 Class Initialized
INFO - 2022-12-12 11:10:20 --> URI Class Initialized
INFO - 2022-12-12 11:10:20 --> Router Class Initialized
INFO - 2022-12-12 11:10:20 --> Output Class Initialized
INFO - 2022-12-12 11:10:20 --> Security Class Initialized
DEBUG - 2022-12-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:10:20 --> Input Class Initialized
INFO - 2022-12-12 11:10:20 --> Language Class Initialized
INFO - 2022-12-12 11:10:20 --> Loader Class Initialized
INFO - 2022-12-12 11:10:20 --> Controller Class Initialized
DEBUG - 2022-12-12 11:10:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:10:20 --> Database Driver Class Initialized
INFO - 2022-12-12 11:10:20 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:12:23 --> Config Class Initialized
INFO - 2022-12-12 11:12:23 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:12:23 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:12:23 --> Utf8 Class Initialized
INFO - 2022-12-12 11:12:23 --> URI Class Initialized
INFO - 2022-12-12 11:12:23 --> Router Class Initialized
INFO - 2022-12-12 11:12:23 --> Output Class Initialized
INFO - 2022-12-12 11:12:23 --> Security Class Initialized
DEBUG - 2022-12-12 11:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:12:23 --> Input Class Initialized
INFO - 2022-12-12 11:12:23 --> Language Class Initialized
INFO - 2022-12-12 11:12:23 --> Loader Class Initialized
INFO - 2022-12-12 11:12:23 --> Controller Class Initialized
DEBUG - 2022-12-12 11:12:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:12:23 --> Database Driver Class Initialized
INFO - 2022-12-12 11:12:23 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:12:23 --> Final output sent to browser
DEBUG - 2022-12-12 11:12:23 --> Total execution time: 0.0590
INFO - 2022-12-12 11:12:23 --> Config Class Initialized
INFO - 2022-12-12 11:12:23 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:12:23 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:12:23 --> Utf8 Class Initialized
INFO - 2022-12-12 11:12:23 --> URI Class Initialized
INFO - 2022-12-12 11:12:23 --> Router Class Initialized
INFO - 2022-12-12 11:12:23 --> Output Class Initialized
INFO - 2022-12-12 11:12:23 --> Security Class Initialized
DEBUG - 2022-12-12 11:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:12:23 --> Input Class Initialized
INFO - 2022-12-12 11:12:23 --> Language Class Initialized
INFO - 2022-12-12 11:12:23 --> Loader Class Initialized
INFO - 2022-12-12 11:12:23 --> Controller Class Initialized
DEBUG - 2022-12-12 11:12:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:12:23 --> Database Driver Class Initialized
INFO - 2022-12-12 11:12:23 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:12:23 --> Final output sent to browser
DEBUG - 2022-12-12 11:12:23 --> Total execution time: 0.0556
INFO - 2022-12-12 11:12:25 --> Config Class Initialized
INFO - 2022-12-12 11:12:25 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:12:25 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:12:25 --> Utf8 Class Initialized
INFO - 2022-12-12 11:12:25 --> URI Class Initialized
INFO - 2022-12-12 11:12:25 --> Router Class Initialized
INFO - 2022-12-12 11:12:25 --> Output Class Initialized
INFO - 2022-12-12 11:12:25 --> Security Class Initialized
DEBUG - 2022-12-12 11:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:12:25 --> Input Class Initialized
INFO - 2022-12-12 11:12:25 --> Language Class Initialized
INFO - 2022-12-12 11:12:25 --> Loader Class Initialized
INFO - 2022-12-12 11:12:25 --> Controller Class Initialized
DEBUG - 2022-12-12 11:12:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:12:25 --> Database Driver Class Initialized
INFO - 2022-12-12 11:12:25 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:12:25 --> Final output sent to browser
DEBUG - 2022-12-12 11:12:25 --> Total execution time: 0.0531
INFO - 2022-12-12 11:12:25 --> Config Class Initialized
INFO - 2022-12-12 11:12:25 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:12:25 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:12:25 --> Utf8 Class Initialized
INFO - 2022-12-12 11:12:25 --> URI Class Initialized
INFO - 2022-12-12 11:12:25 --> Router Class Initialized
INFO - 2022-12-12 11:12:25 --> Output Class Initialized
INFO - 2022-12-12 11:12:25 --> Security Class Initialized
DEBUG - 2022-12-12 11:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:12:25 --> Input Class Initialized
INFO - 2022-12-12 11:12:25 --> Language Class Initialized
INFO - 2022-12-12 11:12:25 --> Loader Class Initialized
INFO - 2022-12-12 11:12:25 --> Controller Class Initialized
DEBUG - 2022-12-12 11:12:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:12:25 --> Database Driver Class Initialized
INFO - 2022-12-12 11:12:25 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:12:25 --> Final output sent to browser
DEBUG - 2022-12-12 11:12:25 --> Total execution time: 0.0538
INFO - 2022-12-12 11:12:33 --> Config Class Initialized
INFO - 2022-12-12 11:12:33 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:12:33 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:12:33 --> Utf8 Class Initialized
INFO - 2022-12-12 11:12:33 --> URI Class Initialized
INFO - 2022-12-12 11:12:33 --> Router Class Initialized
INFO - 2022-12-12 11:12:33 --> Output Class Initialized
INFO - 2022-12-12 11:12:33 --> Security Class Initialized
DEBUG - 2022-12-12 11:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:12:33 --> Input Class Initialized
INFO - 2022-12-12 11:12:33 --> Language Class Initialized
INFO - 2022-12-12 11:12:33 --> Loader Class Initialized
INFO - 2022-12-12 11:12:33 --> Controller Class Initialized
DEBUG - 2022-12-12 11:12:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:12:33 --> Database Driver Class Initialized
INFO - 2022-12-12 11:12:33 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:12:33 --> Final output sent to browser
DEBUG - 2022-12-12 11:12:33 --> Total execution time: 0.0539
INFO - 2022-12-12 11:12:33 --> Config Class Initialized
INFO - 2022-12-12 11:12:33 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:12:33 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:12:33 --> Utf8 Class Initialized
INFO - 2022-12-12 11:12:33 --> URI Class Initialized
INFO - 2022-12-12 11:12:33 --> Router Class Initialized
INFO - 2022-12-12 11:12:33 --> Output Class Initialized
INFO - 2022-12-12 11:12:33 --> Security Class Initialized
DEBUG - 2022-12-12 11:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:12:33 --> Input Class Initialized
INFO - 2022-12-12 11:12:33 --> Language Class Initialized
INFO - 2022-12-12 11:12:33 --> Loader Class Initialized
INFO - 2022-12-12 11:12:33 --> Controller Class Initialized
DEBUG - 2022-12-12 11:12:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:12:33 --> Database Driver Class Initialized
INFO - 2022-12-12 11:12:33 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:12:33 --> Final output sent to browser
DEBUG - 2022-12-12 11:12:33 --> Total execution time: 0.2070
INFO - 2022-12-12 11:12:36 --> Config Class Initialized
INFO - 2022-12-12 11:12:36 --> Hooks Class Initialized
INFO - 2022-12-12 11:12:36 --> Config Class Initialized
INFO - 2022-12-12 11:12:36 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:12:36 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:12:36 --> Utf8 Class Initialized
DEBUG - 2022-12-12 11:12:36 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:12:36 --> Utf8 Class Initialized
INFO - 2022-12-12 11:12:36 --> URI Class Initialized
INFO - 2022-12-12 11:12:36 --> URI Class Initialized
INFO - 2022-12-12 11:12:36 --> Router Class Initialized
INFO - 2022-12-12 11:12:36 --> Router Class Initialized
INFO - 2022-12-12 11:12:36 --> Output Class Initialized
INFO - 2022-12-12 11:12:36 --> Output Class Initialized
INFO - 2022-12-12 11:12:36 --> Security Class Initialized
INFO - 2022-12-12 11:12:36 --> Security Class Initialized
DEBUG - 2022-12-12 11:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-12 11:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:12:36 --> Input Class Initialized
INFO - 2022-12-12 11:12:36 --> Input Class Initialized
INFO - 2022-12-12 11:12:36 --> Language Class Initialized
INFO - 2022-12-12 11:12:36 --> Language Class Initialized
INFO - 2022-12-12 11:12:36 --> Loader Class Initialized
INFO - 2022-12-12 11:12:36 --> Loader Class Initialized
INFO - 2022-12-12 11:12:36 --> Controller Class Initialized
INFO - 2022-12-12 11:12:36 --> Controller Class Initialized
DEBUG - 2022-12-12 11:12:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 11:12:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:12:36 --> Database Driver Class Initialized
INFO - 2022-12-12 11:12:36 --> Database Driver Class Initialized
INFO - 2022-12-12 11:12:36 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:12:36 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:12:36 --> Final output sent to browser
DEBUG - 2022-12-12 11:12:36 --> Total execution time: 0.0522
INFO - 2022-12-12 11:12:36 --> Config Class Initialized
INFO - 2022-12-12 11:12:36 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:12:36 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:12:36 --> Utf8 Class Initialized
INFO - 2022-12-12 11:12:36 --> URI Class Initialized
INFO - 2022-12-12 11:12:36 --> Router Class Initialized
INFO - 2022-12-12 11:12:36 --> Output Class Initialized
INFO - 2022-12-12 11:12:36 --> Security Class Initialized
DEBUG - 2022-12-12 11:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:12:36 --> Input Class Initialized
INFO - 2022-12-12 11:12:36 --> Language Class Initialized
INFO - 2022-12-12 11:12:36 --> Loader Class Initialized
INFO - 2022-12-12 11:12:36 --> Controller Class Initialized
DEBUG - 2022-12-12 11:12:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:12:36 --> Database Driver Class Initialized
INFO - 2022-12-12 11:12:36 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:12:36 --> Final output sent to browser
DEBUG - 2022-12-12 11:12:36 --> Total execution time: 0.0406
INFO - 2022-12-12 11:12:36 --> Config Class Initialized
INFO - 2022-12-12 11:12:36 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:12:36 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:12:36 --> Utf8 Class Initialized
INFO - 2022-12-12 11:12:36 --> URI Class Initialized
INFO - 2022-12-12 11:12:36 --> Router Class Initialized
INFO - 2022-12-12 11:12:36 --> Output Class Initialized
INFO - 2022-12-12 11:12:36 --> Security Class Initialized
DEBUG - 2022-12-12 11:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:12:36 --> Input Class Initialized
INFO - 2022-12-12 11:12:36 --> Language Class Initialized
INFO - 2022-12-12 11:12:36 --> Loader Class Initialized
INFO - 2022-12-12 11:12:36 --> Controller Class Initialized
DEBUG - 2022-12-12 11:12:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:12:36 --> Database Driver Class Initialized
INFO - 2022-12-12 11:12:36 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:12:39 --> Config Class Initialized
INFO - 2022-12-12 11:12:39 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:12:39 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:12:39 --> Utf8 Class Initialized
INFO - 2022-12-12 11:12:39 --> URI Class Initialized
INFO - 2022-12-12 11:12:39 --> Router Class Initialized
INFO - 2022-12-12 11:12:39 --> Output Class Initialized
INFO - 2022-12-12 11:12:39 --> Security Class Initialized
DEBUG - 2022-12-12 11:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:12:39 --> Input Class Initialized
INFO - 2022-12-12 11:12:39 --> Language Class Initialized
INFO - 2022-12-12 11:12:39 --> Loader Class Initialized
INFO - 2022-12-12 11:12:39 --> Controller Class Initialized
DEBUG - 2022-12-12 11:12:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:12:39 --> Final output sent to browser
DEBUG - 2022-12-12 11:12:39 --> Total execution time: 0.0207
INFO - 2022-12-12 11:12:39 --> Config Class Initialized
INFO - 2022-12-12 11:12:39 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:12:39 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:12:39 --> Utf8 Class Initialized
INFO - 2022-12-12 11:12:39 --> URI Class Initialized
INFO - 2022-12-12 11:12:39 --> Router Class Initialized
INFO - 2022-12-12 11:12:39 --> Output Class Initialized
INFO - 2022-12-12 11:12:39 --> Security Class Initialized
DEBUG - 2022-12-12 11:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:12:39 --> Input Class Initialized
INFO - 2022-12-12 11:12:39 --> Language Class Initialized
INFO - 2022-12-12 11:12:39 --> Loader Class Initialized
INFO - 2022-12-12 11:12:39 --> Controller Class Initialized
DEBUG - 2022-12-12 11:12:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:12:39 --> Database Driver Class Initialized
INFO - 2022-12-12 11:12:39 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:12:39 --> Final output sent to browser
DEBUG - 2022-12-12 11:12:39 --> Total execution time: 0.0558
INFO - 2022-12-12 11:14:42 --> Config Class Initialized
INFO - 2022-12-12 11:14:42 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:14:42 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:14:42 --> Utf8 Class Initialized
INFO - 2022-12-12 11:14:42 --> URI Class Initialized
INFO - 2022-12-12 11:14:42 --> Router Class Initialized
INFO - 2022-12-12 11:14:42 --> Output Class Initialized
INFO - 2022-12-12 11:14:42 --> Security Class Initialized
DEBUG - 2022-12-12 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:14:42 --> Input Class Initialized
INFO - 2022-12-12 11:14:42 --> Language Class Initialized
INFO - 2022-12-12 11:14:42 --> Loader Class Initialized
INFO - 2022-12-12 11:14:42 --> Controller Class Initialized
DEBUG - 2022-12-12 11:14:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:14:42 --> Final output sent to browser
DEBUG - 2022-12-12 11:14:42 --> Total execution time: 0.0203
INFO - 2022-12-12 11:14:42 --> Config Class Initialized
INFO - 2022-12-12 11:14:42 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:14:42 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:14:42 --> Utf8 Class Initialized
INFO - 2022-12-12 11:14:42 --> URI Class Initialized
INFO - 2022-12-12 11:14:42 --> Router Class Initialized
INFO - 2022-12-12 11:14:42 --> Output Class Initialized
INFO - 2022-12-12 11:14:42 --> Security Class Initialized
DEBUG - 2022-12-12 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:14:42 --> Input Class Initialized
INFO - 2022-12-12 11:14:42 --> Language Class Initialized
INFO - 2022-12-12 11:14:42 --> Loader Class Initialized
INFO - 2022-12-12 11:14:42 --> Controller Class Initialized
DEBUG - 2022-12-12 11:14:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:14:42 --> Database Driver Class Initialized
INFO - 2022-12-12 11:14:42 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:14:42 --> Final output sent to browser
DEBUG - 2022-12-12 11:14:42 --> Total execution time: 0.0578
INFO - 2022-12-12 11:14:44 --> Config Class Initialized
INFO - 2022-12-12 11:14:44 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:14:44 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:14:44 --> Utf8 Class Initialized
INFO - 2022-12-12 11:14:44 --> URI Class Initialized
INFO - 2022-12-12 11:14:44 --> Router Class Initialized
INFO - 2022-12-12 11:14:44 --> Output Class Initialized
INFO - 2022-12-12 11:14:44 --> Security Class Initialized
DEBUG - 2022-12-12 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:14:44 --> Input Class Initialized
INFO - 2022-12-12 11:14:44 --> Language Class Initialized
INFO - 2022-12-12 11:14:44 --> Loader Class Initialized
INFO - 2022-12-12 11:14:44 --> Controller Class Initialized
DEBUG - 2022-12-12 11:14:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:14:44 --> Database Driver Class Initialized
INFO - 2022-12-12 11:14:44 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:14:44 --> Final output sent to browser
DEBUG - 2022-12-12 11:14:44 --> Total execution time: 0.0330
INFO - 2022-12-12 11:14:44 --> Config Class Initialized
INFO - 2022-12-12 11:14:44 --> Hooks Class Initialized
INFO - 2022-12-12 11:14:44 --> Config Class Initialized
INFO - 2022-12-12 11:14:44 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:14:44 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:14:44 --> Utf8 Class Initialized
DEBUG - 2022-12-12 11:14:44 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:14:44 --> URI Class Initialized
INFO - 2022-12-12 11:14:44 --> Utf8 Class Initialized
INFO - 2022-12-12 11:14:44 --> URI Class Initialized
INFO - 2022-12-12 11:14:44 --> Router Class Initialized
INFO - 2022-12-12 11:14:44 --> Router Class Initialized
INFO - 2022-12-12 11:14:44 --> Output Class Initialized
INFO - 2022-12-12 11:14:44 --> Security Class Initialized
INFO - 2022-12-12 11:14:44 --> Output Class Initialized
DEBUG - 2022-12-12 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:14:44 --> Input Class Initialized
INFO - 2022-12-12 11:14:44 --> Security Class Initialized
INFO - 2022-12-12 11:14:44 --> Language Class Initialized
DEBUG - 2022-12-12 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:14:44 --> Input Class Initialized
INFO - 2022-12-12 11:14:44 --> Language Class Initialized
INFO - 2022-12-12 11:14:44 --> Loader Class Initialized
INFO - 2022-12-12 11:14:44 --> Controller Class Initialized
INFO - 2022-12-12 11:14:44 --> Loader Class Initialized
DEBUG - 2022-12-12 11:14:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:14:44 --> Controller Class Initialized
DEBUG - 2022-12-12 11:14:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:14:44 --> Database Driver Class Initialized
INFO - 2022-12-12 11:14:44 --> Database Driver Class Initialized
INFO - 2022-12-12 11:14:44 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:14:44 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:14:44 --> Final output sent to browser
DEBUG - 2022-12-12 11:14:44 --> Total execution time: 0.0500
INFO - 2022-12-12 11:14:44 --> Config Class Initialized
INFO - 2022-12-12 11:14:44 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:14:44 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:14:44 --> Utf8 Class Initialized
INFO - 2022-12-12 11:14:44 --> URI Class Initialized
INFO - 2022-12-12 11:14:44 --> Router Class Initialized
INFO - 2022-12-12 11:14:44 --> Output Class Initialized
INFO - 2022-12-12 11:14:44 --> Security Class Initialized
DEBUG - 2022-12-12 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:14:44 --> Input Class Initialized
INFO - 2022-12-12 11:14:44 --> Language Class Initialized
INFO - 2022-12-12 11:14:44 --> Config Class Initialized
INFO - 2022-12-12 11:14:44 --> Hooks Class Initialized
INFO - 2022-12-12 11:14:44 --> Loader Class Initialized
INFO - 2022-12-12 11:14:44 --> Controller Class Initialized
DEBUG - 2022-12-12 11:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 11:14:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:14:44 --> Utf8 Class Initialized
INFO - 2022-12-12 11:14:44 --> URI Class Initialized
INFO - 2022-12-12 11:14:44 --> Router Class Initialized
INFO - 2022-12-12 11:14:44 --> Output Class Initialized
INFO - 2022-12-12 11:14:44 --> Database Driver Class Initialized
INFO - 2022-12-12 11:14:44 --> Security Class Initialized
DEBUG - 2022-12-12 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:14:44 --> Input Class Initialized
INFO - 2022-12-12 11:14:44 --> Language Class Initialized
INFO - 2022-12-12 11:14:44 --> Loader Class Initialized
INFO - 2022-12-12 11:14:44 --> Controller Class Initialized
DEBUG - 2022-12-12 11:14:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:14:44 --> Database Driver Class Initialized
INFO - 2022-12-12 11:14:44 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:14:44 --> Final output sent to browser
DEBUG - 2022-12-12 11:14:44 --> Total execution time: 0.0417
INFO - 2022-12-12 11:14:44 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:14:46 --> Config Class Initialized
INFO - 2022-12-12 11:14:46 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:14:46 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:14:46 --> Utf8 Class Initialized
INFO - 2022-12-12 11:14:46 --> URI Class Initialized
INFO - 2022-12-12 11:14:46 --> Router Class Initialized
INFO - 2022-12-12 11:14:46 --> Output Class Initialized
INFO - 2022-12-12 11:14:46 --> Security Class Initialized
DEBUG - 2022-12-12 11:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:14:46 --> Input Class Initialized
INFO - 2022-12-12 11:14:46 --> Language Class Initialized
INFO - 2022-12-12 11:14:46 --> Loader Class Initialized
INFO - 2022-12-12 11:14:46 --> Controller Class Initialized
DEBUG - 2022-12-12 11:14:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:14:46 --> Database Driver Class Initialized
INFO - 2022-12-12 11:14:46 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:14:46 --> Config Class Initialized
INFO - 2022-12-12 11:14:46 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:14:46 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:14:46 --> Utf8 Class Initialized
INFO - 2022-12-12 11:14:46 --> URI Class Initialized
INFO - 2022-12-12 11:14:46 --> Router Class Initialized
INFO - 2022-12-12 11:14:46 --> Output Class Initialized
INFO - 2022-12-12 11:14:46 --> Security Class Initialized
DEBUG - 2022-12-12 11:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:14:46 --> Input Class Initialized
INFO - 2022-12-12 11:14:46 --> Language Class Initialized
INFO - 2022-12-12 11:14:46 --> Loader Class Initialized
INFO - 2022-12-12 11:14:46 --> Controller Class Initialized
DEBUG - 2022-12-12 11:14:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:14:46 --> Database Driver Class Initialized
INFO - 2022-12-12 11:14:46 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:14:51 --> Config Class Initialized
INFO - 2022-12-12 11:14:51 --> Hooks Class Initialized
INFO - 2022-12-12 11:14:51 --> Config Class Initialized
INFO - 2022-12-12 11:14:51 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:14:51 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:14:51 --> Utf8 Class Initialized
DEBUG - 2022-12-12 11:14:51 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:14:51 --> Utf8 Class Initialized
INFO - 2022-12-12 11:14:51 --> URI Class Initialized
INFO - 2022-12-12 11:14:51 --> URI Class Initialized
INFO - 2022-12-12 11:14:51 --> Router Class Initialized
INFO - 2022-12-12 11:14:51 --> Router Class Initialized
INFO - 2022-12-12 11:14:51 --> Output Class Initialized
INFO - 2022-12-12 11:14:51 --> Output Class Initialized
INFO - 2022-12-12 11:14:51 --> Security Class Initialized
INFO - 2022-12-12 11:14:51 --> Security Class Initialized
DEBUG - 2022-12-12 11:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:14:51 --> Input Class Initialized
DEBUG - 2022-12-12 11:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:14:51 --> Language Class Initialized
INFO - 2022-12-12 11:14:51 --> Input Class Initialized
INFO - 2022-12-12 11:14:51 --> Language Class Initialized
INFO - 2022-12-12 11:14:51 --> Loader Class Initialized
INFO - 2022-12-12 11:14:51 --> Loader Class Initialized
INFO - 2022-12-12 11:14:51 --> Controller Class Initialized
INFO - 2022-12-12 11:14:51 --> Controller Class Initialized
DEBUG - 2022-12-12 11:14:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 11:14:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:14:51 --> Database Driver Class Initialized
INFO - 2022-12-12 11:14:51 --> Database Driver Class Initialized
INFO - 2022-12-12 11:14:51 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:14:51 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:14:51 --> Final output sent to browser
DEBUG - 2022-12-12 11:14:51 --> Total execution time: 0.0502
INFO - 2022-12-12 11:14:51 --> Config Class Initialized
INFO - 2022-12-12 11:14:51 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:14:51 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:14:51 --> Utf8 Class Initialized
INFO - 2022-12-12 11:14:51 --> URI Class Initialized
INFO - 2022-12-12 11:14:51 --> Router Class Initialized
INFO - 2022-12-12 11:14:51 --> Output Class Initialized
INFO - 2022-12-12 11:14:51 --> Security Class Initialized
DEBUG - 2022-12-12 11:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:14:51 --> Input Class Initialized
INFO - 2022-12-12 11:14:51 --> Language Class Initialized
INFO - 2022-12-12 11:14:51 --> Loader Class Initialized
INFO - 2022-12-12 11:14:51 --> Controller Class Initialized
DEBUG - 2022-12-12 11:14:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:14:51 --> Database Driver Class Initialized
INFO - 2022-12-12 11:14:51 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:14:51 --> Final output sent to browser
DEBUG - 2022-12-12 11:14:51 --> Total execution time: 0.0317
INFO - 2022-12-12 11:21:20 --> Config Class Initialized
INFO - 2022-12-12 11:21:20 --> Config Class Initialized
INFO - 2022-12-12 11:21:20 --> Hooks Class Initialized
INFO - 2022-12-12 11:21:20 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 11:21:20 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:21:20 --> Utf8 Class Initialized
INFO - 2022-12-12 11:21:20 --> Utf8 Class Initialized
INFO - 2022-12-12 11:21:20 --> URI Class Initialized
INFO - 2022-12-12 11:21:20 --> URI Class Initialized
INFO - 2022-12-12 11:21:20 --> Router Class Initialized
INFO - 2022-12-12 11:21:20 --> Router Class Initialized
INFO - 2022-12-12 11:21:20 --> Output Class Initialized
INFO - 2022-12-12 11:21:20 --> Output Class Initialized
INFO - 2022-12-12 11:21:20 --> Security Class Initialized
INFO - 2022-12-12 11:21:20 --> Security Class Initialized
DEBUG - 2022-12-12 11:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:21:20 --> Input Class Initialized
DEBUG - 2022-12-12 11:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:21:20 --> Input Class Initialized
INFO - 2022-12-12 11:21:20 --> Language Class Initialized
INFO - 2022-12-12 11:21:20 --> Language Class Initialized
INFO - 2022-12-12 11:21:20 --> Loader Class Initialized
INFO - 2022-12-12 11:21:20 --> Loader Class Initialized
INFO - 2022-12-12 11:21:20 --> Controller Class Initialized
INFO - 2022-12-12 11:21:20 --> Controller Class Initialized
DEBUG - 2022-12-12 11:21:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 11:21:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:21:20 --> Database Driver Class Initialized
INFO - 2022-12-12 11:21:20 --> Database Driver Class Initialized
INFO - 2022-12-12 11:21:20 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:21:20 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:21:20 --> Final output sent to browser
DEBUG - 2022-12-12 11:21:20 --> Total execution time: 0.0661
INFO - 2022-12-12 11:21:20 --> Config Class Initialized
INFO - 2022-12-12 11:21:20 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:21:20 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:21:20 --> Utf8 Class Initialized
INFO - 2022-12-12 11:21:20 --> URI Class Initialized
INFO - 2022-12-12 11:21:20 --> Router Class Initialized
INFO - 2022-12-12 11:21:20 --> Output Class Initialized
INFO - 2022-12-12 11:21:20 --> Security Class Initialized
DEBUG - 2022-12-12 11:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:21:20 --> Input Class Initialized
INFO - 2022-12-12 11:21:20 --> Language Class Initialized
INFO - 2022-12-12 11:21:20 --> Loader Class Initialized
INFO - 2022-12-12 11:21:20 --> Controller Class Initialized
DEBUG - 2022-12-12 11:21:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:21:20 --> Config Class Initialized
INFO - 2022-12-12 11:21:20 --> Database Driver Class Initialized
INFO - 2022-12-12 11:21:20 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:21:20 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:21:20 --> Utf8 Class Initialized
INFO - 2022-12-12 11:21:20 --> URI Class Initialized
INFO - 2022-12-12 11:21:20 --> Router Class Initialized
INFO - 2022-12-12 11:21:20 --> Output Class Initialized
INFO - 2022-12-12 11:21:20 --> Security Class Initialized
DEBUG - 2022-12-12 11:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:21:20 --> Input Class Initialized
INFO - 2022-12-12 11:21:20 --> Language Class Initialized
INFO - 2022-12-12 11:21:20 --> Loader Class Initialized
INFO - 2022-12-12 11:21:20 --> Controller Class Initialized
DEBUG - 2022-12-12 11:21:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:21:20 --> Database Driver Class Initialized
INFO - 2022-12-12 11:21:20 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:21:20 --> Final output sent to browser
INFO - 2022-12-12 11:21:20 --> Model "Cluster_model" initialized
DEBUG - 2022-12-12 11:21:20 --> Total execution time: 0.2629
INFO - 2022-12-12 11:25:13 --> Config Class Initialized
INFO - 2022-12-12 11:25:13 --> Config Class Initialized
INFO - 2022-12-12 11:25:13 --> Hooks Class Initialized
INFO - 2022-12-12 11:25:13 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 11:25:13 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:25:13 --> Utf8 Class Initialized
INFO - 2022-12-12 11:25:13 --> Utf8 Class Initialized
INFO - 2022-12-12 11:25:13 --> URI Class Initialized
INFO - 2022-12-12 11:25:13 --> URI Class Initialized
INFO - 2022-12-12 11:25:13 --> Router Class Initialized
INFO - 2022-12-12 11:25:13 --> Router Class Initialized
INFO - 2022-12-12 11:25:13 --> Output Class Initialized
INFO - 2022-12-12 11:25:13 --> Output Class Initialized
INFO - 2022-12-12 11:25:13 --> Security Class Initialized
INFO - 2022-12-12 11:25:13 --> Security Class Initialized
DEBUG - 2022-12-12 11:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:25:13 --> Input Class Initialized
DEBUG - 2022-12-12 11:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:25:13 --> Input Class Initialized
INFO - 2022-12-12 11:25:13 --> Language Class Initialized
INFO - 2022-12-12 11:25:13 --> Language Class Initialized
INFO - 2022-12-12 11:25:13 --> Loader Class Initialized
INFO - 2022-12-12 11:25:13 --> Loader Class Initialized
INFO - 2022-12-12 11:25:13 --> Controller Class Initialized
DEBUG - 2022-12-12 11:25:13 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:25:13 --> Controller Class Initialized
DEBUG - 2022-12-12 11:25:13 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:25:13 --> Database Driver Class Initialized
INFO - 2022-12-12 11:25:13 --> Database Driver Class Initialized
INFO - 2022-12-12 11:25:13 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:25:13 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:25:13 --> Final output sent to browser
DEBUG - 2022-12-12 11:25:13 --> Total execution time: 0.0814
INFO - 2022-12-12 11:25:13 --> Config Class Initialized
INFO - 2022-12-12 11:25:13 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:25:13 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:25:13 --> Utf8 Class Initialized
INFO - 2022-12-12 11:25:13 --> URI Class Initialized
INFO - 2022-12-12 11:25:13 --> Router Class Initialized
INFO - 2022-12-12 11:25:13 --> Output Class Initialized
INFO - 2022-12-12 11:25:13 --> Security Class Initialized
DEBUG - 2022-12-12 11:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:25:13 --> Input Class Initialized
INFO - 2022-12-12 11:25:13 --> Language Class Initialized
INFO - 2022-12-12 11:25:13 --> Loader Class Initialized
INFO - 2022-12-12 11:25:13 --> Controller Class Initialized
DEBUG - 2022-12-12 11:25:13 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:25:13 --> Config Class Initialized
INFO - 2022-12-12 11:25:13 --> Hooks Class Initialized
INFO - 2022-12-12 11:25:13 --> Database Driver Class Initialized
DEBUG - 2022-12-12 11:25:13 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:25:13 --> Utf8 Class Initialized
INFO - 2022-12-12 11:25:13 --> URI Class Initialized
INFO - 2022-12-12 11:25:13 --> Router Class Initialized
INFO - 2022-12-12 11:25:13 --> Output Class Initialized
INFO - 2022-12-12 11:25:13 --> Security Class Initialized
DEBUG - 2022-12-12 11:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:25:13 --> Input Class Initialized
INFO - 2022-12-12 11:25:13 --> Language Class Initialized
INFO - 2022-12-12 11:25:13 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:25:13 --> Final output sent to browser
INFO - 2022-12-12 11:25:13 --> Loader Class Initialized
DEBUG - 2022-12-12 11:25:13 --> Total execution time: 0.0824
INFO - 2022-12-12 11:25:13 --> Controller Class Initialized
DEBUG - 2022-12-12 11:25:13 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:25:13 --> Database Driver Class Initialized
INFO - 2022-12-12 11:25:13 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:25:46 --> Config Class Initialized
INFO - 2022-12-12 11:25:46 --> Config Class Initialized
INFO - 2022-12-12 11:25:46 --> Hooks Class Initialized
INFO - 2022-12-12 11:25:46 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 11:25:46 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:25:46 --> Utf8 Class Initialized
INFO - 2022-12-12 11:25:46 --> Utf8 Class Initialized
INFO - 2022-12-12 11:25:46 --> URI Class Initialized
INFO - 2022-12-12 11:25:46 --> URI Class Initialized
INFO - 2022-12-12 11:25:46 --> Router Class Initialized
INFO - 2022-12-12 11:25:46 --> Router Class Initialized
INFO - 2022-12-12 11:25:46 --> Output Class Initialized
INFO - 2022-12-12 11:25:46 --> Output Class Initialized
INFO - 2022-12-12 11:25:46 --> Security Class Initialized
INFO - 2022-12-12 11:25:46 --> Security Class Initialized
DEBUG - 2022-12-12 11:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:25:46 --> Input Class Initialized
DEBUG - 2022-12-12 11:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:25:46 --> Input Class Initialized
INFO - 2022-12-12 11:25:46 --> Language Class Initialized
INFO - 2022-12-12 11:25:46 --> Language Class Initialized
INFO - 2022-12-12 11:25:46 --> Loader Class Initialized
INFO - 2022-12-12 11:25:46 --> Loader Class Initialized
INFO - 2022-12-12 11:25:46 --> Controller Class Initialized
INFO - 2022-12-12 11:25:46 --> Controller Class Initialized
DEBUG - 2022-12-12 11:25:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 11:25:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:25:46 --> Database Driver Class Initialized
INFO - 2022-12-12 11:25:46 --> Database Driver Class Initialized
INFO - 2022-12-12 11:25:46 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:25:46 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:25:46 --> Final output sent to browser
DEBUG - 2022-12-12 11:25:46 --> Total execution time: 0.0680
INFO - 2022-12-12 11:25:46 --> Config Class Initialized
INFO - 2022-12-12 11:25:46 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:25:46 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:25:46 --> Utf8 Class Initialized
INFO - 2022-12-12 11:25:46 --> URI Class Initialized
INFO - 2022-12-12 11:25:46 --> Router Class Initialized
INFO - 2022-12-12 11:25:46 --> Output Class Initialized
INFO - 2022-12-12 11:25:46 --> Security Class Initialized
DEBUG - 2022-12-12 11:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:25:46 --> Input Class Initialized
INFO - 2022-12-12 11:25:46 --> Language Class Initialized
INFO - 2022-12-12 11:25:46 --> Loader Class Initialized
INFO - 2022-12-12 11:25:46 --> Controller Class Initialized
DEBUG - 2022-12-12 11:25:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:25:46 --> Database Driver Class Initialized
INFO - 2022-12-12 11:25:46 --> Config Class Initialized
INFO - 2022-12-12 11:25:46 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:25:46 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:25:46 --> Utf8 Class Initialized
INFO - 2022-12-12 11:25:46 --> URI Class Initialized
INFO - 2022-12-12 11:25:46 --> Router Class Initialized
INFO - 2022-12-12 11:25:46 --> Output Class Initialized
INFO - 2022-12-12 11:25:46 --> Security Class Initialized
DEBUG - 2022-12-12 11:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:25:46 --> Input Class Initialized
INFO - 2022-12-12 11:25:46 --> Language Class Initialized
INFO - 2022-12-12 11:25:46 --> Loader Class Initialized
INFO - 2022-12-12 11:25:46 --> Controller Class Initialized
DEBUG - 2022-12-12 11:25:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:25:46 --> Database Driver Class Initialized
INFO - 2022-12-12 11:25:46 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:25:46 --> Final output sent to browser
DEBUG - 2022-12-12 11:25:46 --> Total execution time: 0.1008
INFO - 2022-12-12 11:25:46 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:51:12 --> Config Class Initialized
INFO - 2022-12-12 11:51:12 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:51:12 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:51:12 --> Utf8 Class Initialized
INFO - 2022-12-12 11:51:12 --> URI Class Initialized
INFO - 2022-12-12 11:51:12 --> Router Class Initialized
INFO - 2022-12-12 11:51:12 --> Output Class Initialized
INFO - 2022-12-12 11:51:12 --> Security Class Initialized
DEBUG - 2022-12-12 11:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:51:12 --> Input Class Initialized
INFO - 2022-12-12 11:51:12 --> Language Class Initialized
INFO - 2022-12-12 11:51:12 --> Loader Class Initialized
INFO - 2022-12-12 11:51:12 --> Controller Class Initialized
DEBUG - 2022-12-12 11:51:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
ERROR - 2022-12-12 11:51:12 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\ClusterSetting.php at Line 215
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#2 {main}
INFO - 2022-12-12 11:51:12 --> Config Class Initialized
INFO - 2022-12-12 11:51:12 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:51:12 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:51:12 --> Utf8 Class Initialized
INFO - 2022-12-12 11:51:12 --> URI Class Initialized
INFO - 2022-12-12 11:51:12 --> Router Class Initialized
INFO - 2022-12-12 11:51:12 --> Output Class Initialized
INFO - 2022-12-12 11:51:12 --> Security Class Initialized
DEBUG - 2022-12-12 11:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:51:12 --> Input Class Initialized
INFO - 2022-12-12 11:51:12 --> Language Class Initialized
INFO - 2022-12-12 11:51:12 --> Loader Class Initialized
INFO - 2022-12-12 11:51:12 --> Controller Class Initialized
DEBUG - 2022-12-12 11:51:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:51:12 --> Database Driver Class Initialized
INFO - 2022-12-12 11:51:12 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:51:12 --> Final output sent to browser
DEBUG - 2022-12-12 11:51:12 --> Total execution time: 0.0484
INFO - 2022-12-12 11:52:28 --> Config Class Initialized
INFO - 2022-12-12 11:52:28 --> Hooks Class Initialized
INFO - 2022-12-12 11:52:28 --> Config Class Initialized
INFO - 2022-12-12 11:52:28 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:28 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:28 --> Utf8 Class Initialized
DEBUG - 2022-12-12 11:52:28 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:28 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:28 --> URI Class Initialized
INFO - 2022-12-12 11:52:28 --> URI Class Initialized
INFO - 2022-12-12 11:52:28 --> Router Class Initialized
INFO - 2022-12-12 11:52:28 --> Router Class Initialized
INFO - 2022-12-12 11:52:28 --> Output Class Initialized
INFO - 2022-12-12 11:52:28 --> Output Class Initialized
INFO - 2022-12-12 11:52:28 --> Security Class Initialized
INFO - 2022-12-12 11:52:28 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:28 --> Input Class Initialized
DEBUG - 2022-12-12 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:28 --> Input Class Initialized
INFO - 2022-12-12 11:52:28 --> Language Class Initialized
INFO - 2022-12-12 11:52:28 --> Language Class Initialized
INFO - 2022-12-12 11:52:28 --> Loader Class Initialized
INFO - 2022-12-12 11:52:28 --> Loader Class Initialized
INFO - 2022-12-12 11:52:28 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:28 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:28 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:28 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:28 --> Final output sent to browser
DEBUG - 2022-12-12 11:52:28 --> Total execution time: 0.0229
INFO - 2022-12-12 11:52:28 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:28 --> Config Class Initialized
INFO - 2022-12-12 11:52:28 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:28 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:28 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:28 --> URI Class Initialized
INFO - 2022-12-12 11:52:28 --> Router Class Initialized
INFO - 2022-12-12 11:52:28 --> Output Class Initialized
INFO - 2022-12-12 11:52:28 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:28 --> Input Class Initialized
INFO - 2022-12-12 11:52:28 --> Language Class Initialized
INFO - 2022-12-12 11:52:28 --> Loader Class Initialized
INFO - 2022-12-12 11:52:28 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:28 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:28 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:28 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:28 --> Final output sent to browser
DEBUG - 2022-12-12 11:52:28 --> Total execution time: 0.0555
INFO - 2022-12-12 11:52:28 --> Config Class Initialized
INFO - 2022-12-12 11:52:28 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:28 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:28 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:28 --> URI Class Initialized
INFO - 2022-12-12 11:52:28 --> Router Class Initialized
INFO - 2022-12-12 11:52:28 --> Output Class Initialized
INFO - 2022-12-12 11:52:28 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:28 --> Input Class Initialized
INFO - 2022-12-12 11:52:28 --> Language Class Initialized
INFO - 2022-12-12 11:52:28 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:28 --> Final output sent to browser
DEBUG - 2022-12-12 11:52:28 --> Total execution time: 0.0496
INFO - 2022-12-12 11:52:28 --> Loader Class Initialized
INFO - 2022-12-12 11:52:28 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:28 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:28 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:28 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:28 --> Final output sent to browser
DEBUG - 2022-12-12 11:52:28 --> Total execution time: 0.0356
INFO - 2022-12-12 11:52:29 --> Config Class Initialized
INFO - 2022-12-12 11:52:29 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:29 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:29 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:29 --> URI Class Initialized
INFO - 2022-12-12 11:52:29 --> Router Class Initialized
INFO - 2022-12-12 11:52:29 --> Output Class Initialized
INFO - 2022-12-12 11:52:29 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:29 --> Input Class Initialized
INFO - 2022-12-12 11:52:29 --> Language Class Initialized
INFO - 2022-12-12 11:52:29 --> Loader Class Initialized
INFO - 2022-12-12 11:52:29 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:29 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:29 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:29 --> Final output sent to browser
DEBUG - 2022-12-12 11:52:29 --> Total execution time: 0.2482
INFO - 2022-12-12 11:52:29 --> Config Class Initialized
INFO - 2022-12-12 11:52:29 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:29 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:29 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:29 --> URI Class Initialized
INFO - 2022-12-12 11:52:29 --> Router Class Initialized
INFO - 2022-12-12 11:52:29 --> Output Class Initialized
INFO - 2022-12-12 11:52:29 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:29 --> Input Class Initialized
INFO - 2022-12-12 11:52:29 --> Language Class Initialized
INFO - 2022-12-12 11:52:29 --> Loader Class Initialized
INFO - 2022-12-12 11:52:29 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:29 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:29 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:29 --> Final output sent to browser
DEBUG - 2022-12-12 11:52:29 --> Total execution time: 0.0496
INFO - 2022-12-12 11:52:36 --> Config Class Initialized
INFO - 2022-12-12 11:52:36 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:36 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:36 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:36 --> URI Class Initialized
INFO - 2022-12-12 11:52:36 --> Router Class Initialized
INFO - 2022-12-12 11:52:36 --> Output Class Initialized
INFO - 2022-12-12 11:52:36 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:36 --> Input Class Initialized
INFO - 2022-12-12 11:52:36 --> Language Class Initialized
INFO - 2022-12-12 11:52:36 --> Loader Class Initialized
INFO - 2022-12-12 11:52:36 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:36 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:36 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:36 --> Final output sent to browser
DEBUG - 2022-12-12 11:52:36 --> Total execution time: 0.0369
INFO - 2022-12-12 11:52:36 --> Config Class Initialized
INFO - 2022-12-12 11:52:36 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:36 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:36 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:36 --> URI Class Initialized
INFO - 2022-12-12 11:52:36 --> Router Class Initialized
INFO - 2022-12-12 11:52:36 --> Output Class Initialized
INFO - 2022-12-12 11:52:36 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:36 --> Input Class Initialized
INFO - 2022-12-12 11:52:36 --> Language Class Initialized
INFO - 2022-12-12 11:52:36 --> Loader Class Initialized
INFO - 2022-12-12 11:52:36 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:36 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:36 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:36 --> Final output sent to browser
DEBUG - 2022-12-12 11:52:36 --> Total execution time: 0.0508
INFO - 2022-12-12 11:52:43 --> Config Class Initialized
INFO - 2022-12-12 11:52:43 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:43 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:43 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:43 --> URI Class Initialized
INFO - 2022-12-12 11:52:43 --> Router Class Initialized
INFO - 2022-12-12 11:52:43 --> Output Class Initialized
INFO - 2022-12-12 11:52:43 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:43 --> Input Class Initialized
INFO - 2022-12-12 11:52:43 --> Language Class Initialized
INFO - 2022-12-12 11:52:43 --> Loader Class Initialized
INFO - 2022-12-12 11:52:43 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:43 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:43 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:43 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:43 --> Config Class Initialized
INFO - 2022-12-12 11:52:43 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:43 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:43 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:43 --> URI Class Initialized
INFO - 2022-12-12 11:52:43 --> Router Class Initialized
INFO - 2022-12-12 11:52:43 --> Output Class Initialized
INFO - 2022-12-12 11:52:43 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:43 --> Input Class Initialized
INFO - 2022-12-12 11:52:43 --> Language Class Initialized
INFO - 2022-12-12 11:52:43 --> Loader Class Initialized
INFO - 2022-12-12 11:52:43 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:43 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:43 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:43 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:46 --> Config Class Initialized
INFO - 2022-12-12 11:52:46 --> Config Class Initialized
INFO - 2022-12-12 11:52:46 --> Hooks Class Initialized
INFO - 2022-12-12 11:52:46 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 11:52:46 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:46 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:46 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:46 --> URI Class Initialized
INFO - 2022-12-12 11:52:46 --> URI Class Initialized
INFO - 2022-12-12 11:52:46 --> Router Class Initialized
INFO - 2022-12-12 11:52:46 --> Router Class Initialized
INFO - 2022-12-12 11:52:46 --> Output Class Initialized
INFO - 2022-12-12 11:52:46 --> Output Class Initialized
INFO - 2022-12-12 11:52:46 --> Security Class Initialized
INFO - 2022-12-12 11:52:46 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-12 11:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:46 --> Input Class Initialized
INFO - 2022-12-12 11:52:46 --> Input Class Initialized
INFO - 2022-12-12 11:52:46 --> Language Class Initialized
INFO - 2022-12-12 11:52:46 --> Language Class Initialized
INFO - 2022-12-12 11:52:46 --> Loader Class Initialized
INFO - 2022-12-12 11:52:46 --> Loader Class Initialized
INFO - 2022-12-12 11:52:46 --> Controller Class Initialized
INFO - 2022-12-12 11:52:46 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 11:52:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:46 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:46 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:46 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:46 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:46 --> Final output sent to browser
DEBUG - 2022-12-12 11:52:46 --> Total execution time: 0.0540
INFO - 2022-12-12 11:52:46 --> Config Class Initialized
INFO - 2022-12-12 11:52:46 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:46 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:46 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:46 --> URI Class Initialized
INFO - 2022-12-12 11:52:46 --> Router Class Initialized
INFO - 2022-12-12 11:52:46 --> Output Class Initialized
INFO - 2022-12-12 11:52:46 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:46 --> Input Class Initialized
INFO - 2022-12-12 11:52:46 --> Language Class Initialized
INFO - 2022-12-12 11:52:46 --> Loader Class Initialized
INFO - 2022-12-12 11:52:46 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:46 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:46 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:46 --> Final output sent to browser
DEBUG - 2022-12-12 11:52:46 --> Total execution time: 0.0521
INFO - 2022-12-12 11:52:54 --> Config Class Initialized
INFO - 2022-12-12 11:52:54 --> Config Class Initialized
INFO - 2022-12-12 11:52:54 --> Hooks Class Initialized
INFO - 2022-12-12 11:52:54 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-12 11:52:54 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:54 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:54 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:54 --> URI Class Initialized
INFO - 2022-12-12 11:52:54 --> URI Class Initialized
INFO - 2022-12-12 11:52:54 --> Router Class Initialized
INFO - 2022-12-12 11:52:54 --> Router Class Initialized
INFO - 2022-12-12 11:52:54 --> Output Class Initialized
INFO - 2022-12-12 11:52:54 --> Output Class Initialized
INFO - 2022-12-12 11:52:54 --> Security Class Initialized
INFO - 2022-12-12 11:52:54 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:54 --> Input Class Initialized
DEBUG - 2022-12-12 11:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:54 --> Input Class Initialized
INFO - 2022-12-12 11:52:54 --> Language Class Initialized
INFO - 2022-12-12 11:52:54 --> Language Class Initialized
INFO - 2022-12-12 11:52:54 --> Loader Class Initialized
INFO - 2022-12-12 11:52:54 --> Loader Class Initialized
INFO - 2022-12-12 11:52:54 --> Controller Class Initialized
INFO - 2022-12-12 11:52:54 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:54 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 11:52:54 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:54 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:54 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:54 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:54 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:54 --> Final output sent to browser
DEBUG - 2022-12-12 11:52:54 --> Total execution time: 0.0545
INFO - 2022-12-12 11:52:54 --> Config Class Initialized
INFO - 2022-12-12 11:52:54 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:54 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:54 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:54 --> URI Class Initialized
INFO - 2022-12-12 11:52:54 --> Router Class Initialized
INFO - 2022-12-12 11:52:54 --> Output Class Initialized
INFO - 2022-12-12 11:52:54 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:54 --> Input Class Initialized
INFO - 2022-12-12 11:52:54 --> Language Class Initialized
INFO - 2022-12-12 11:52:54 --> Loader Class Initialized
INFO - 2022-12-12 11:52:54 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:54 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:54 --> Database Driver Class Initialized
INFO - 2022-12-12 11:52:54 --> Config Class Initialized
INFO - 2022-12-12 11:52:54 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:52:54 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:52:54 --> Utf8 Class Initialized
INFO - 2022-12-12 11:52:54 --> URI Class Initialized
INFO - 2022-12-12 11:52:54 --> Router Class Initialized
INFO - 2022-12-12 11:52:54 --> Output Class Initialized
INFO - 2022-12-12 11:52:54 --> Security Class Initialized
DEBUG - 2022-12-12 11:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:52:54 --> Input Class Initialized
INFO - 2022-12-12 11:52:54 --> Language Class Initialized
INFO - 2022-12-12 11:52:54 --> Loader Class Initialized
INFO - 2022-12-12 11:52:54 --> Controller Class Initialized
DEBUG - 2022-12-12 11:52:54 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:52:54 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:52:54 --> Final output sent to browser
INFO - 2022-12-12 11:52:54 --> Database Driver Class Initialized
DEBUG - 2022-12-12 11:52:54 --> Total execution time: 0.0551
INFO - 2022-12-12 11:52:54 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:54:00 --> Config Class Initialized
INFO - 2022-12-12 11:54:00 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:54:00 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:54:00 --> Utf8 Class Initialized
INFO - 2022-12-12 11:54:00 --> URI Class Initialized
INFO - 2022-12-12 11:54:00 --> Router Class Initialized
INFO - 2022-12-12 11:54:00 --> Output Class Initialized
INFO - 2022-12-12 11:54:00 --> Security Class Initialized
DEBUG - 2022-12-12 11:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:54:00 --> Input Class Initialized
INFO - 2022-12-12 11:54:00 --> Language Class Initialized
INFO - 2022-12-12 11:54:00 --> Loader Class Initialized
INFO - 2022-12-12 11:54:00 --> Controller Class Initialized
DEBUG - 2022-12-12 11:54:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:54:00 --> Database Driver Class Initialized
INFO - 2022-12-12 11:54:00 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:54:00 --> Config Class Initialized
INFO - 2022-12-12 11:54:00 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:54:00 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:54:00 --> Utf8 Class Initialized
INFO - 2022-12-12 11:54:00 --> URI Class Initialized
INFO - 2022-12-12 11:54:00 --> Router Class Initialized
INFO - 2022-12-12 11:54:00 --> Output Class Initialized
INFO - 2022-12-12 11:54:00 --> Security Class Initialized
DEBUG - 2022-12-12 11:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:54:00 --> Input Class Initialized
INFO - 2022-12-12 11:54:00 --> Language Class Initialized
INFO - 2022-12-12 11:54:00 --> Loader Class Initialized
INFO - 2022-12-12 11:54:00 --> Controller Class Initialized
DEBUG - 2022-12-12 11:54:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:54:00 --> Database Driver Class Initialized
INFO - 2022-12-12 11:54:00 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:54:02 --> Config Class Initialized
INFO - 2022-12-12 11:54:02 --> Config Class Initialized
INFO - 2022-12-12 11:54:02 --> Hooks Class Initialized
INFO - 2022-12-12 11:54:02 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:54:02 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:54:02 --> Utf8 Class Initialized
DEBUG - 2022-12-12 11:54:02 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:54:02 --> Utf8 Class Initialized
INFO - 2022-12-12 11:54:02 --> URI Class Initialized
INFO - 2022-12-12 11:54:02 --> URI Class Initialized
INFO - 2022-12-12 11:54:02 --> Router Class Initialized
INFO - 2022-12-12 11:54:02 --> Router Class Initialized
INFO - 2022-12-12 11:54:02 --> Output Class Initialized
INFO - 2022-12-12 11:54:02 --> Output Class Initialized
INFO - 2022-12-12 11:54:02 --> Security Class Initialized
INFO - 2022-12-12 11:54:02 --> Security Class Initialized
DEBUG - 2022-12-12 11:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:54:02 --> Input Class Initialized
DEBUG - 2022-12-12 11:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:54:02 --> Input Class Initialized
INFO - 2022-12-12 11:54:02 --> Language Class Initialized
INFO - 2022-12-12 11:54:02 --> Language Class Initialized
INFO - 2022-12-12 11:54:02 --> Loader Class Initialized
INFO - 2022-12-12 11:54:02 --> Loader Class Initialized
INFO - 2022-12-12 11:54:02 --> Controller Class Initialized
INFO - 2022-12-12 11:54:02 --> Controller Class Initialized
DEBUG - 2022-12-12 11:54:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-12 11:54:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:54:02 --> Database Driver Class Initialized
INFO - 2022-12-12 11:54:02 --> Database Driver Class Initialized
INFO - 2022-12-12 11:54:02 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:54:02 --> Final output sent to browser
DEBUG - 2022-12-12 11:54:02 --> Total execution time: 0.0566
INFO - 2022-12-12 11:54:02 --> Config Class Initialized
INFO - 2022-12-12 11:54:02 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:54:02 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:54:02 --> Utf8 Class Initialized
INFO - 2022-12-12 11:54:02 --> URI Class Initialized
INFO - 2022-12-12 11:54:02 --> Router Class Initialized
INFO - 2022-12-12 11:54:02 --> Output Class Initialized
INFO - 2022-12-12 11:54:02 --> Security Class Initialized
DEBUG - 2022-12-12 11:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:54:02 --> Input Class Initialized
INFO - 2022-12-12 11:54:02 --> Language Class Initialized
INFO - 2022-12-12 11:54:02 --> Loader Class Initialized
INFO - 2022-12-12 11:54:02 --> Controller Class Initialized
DEBUG - 2022-12-12 11:54:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:54:02 --> Database Driver Class Initialized
INFO - 2022-12-12 11:54:02 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:54:02 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:54:02 --> Final output sent to browser
DEBUG - 2022-12-12 11:54:02 --> Total execution time: 0.0544
INFO - 2022-12-12 11:56:55 --> Config Class Initialized
INFO - 2022-12-12 11:56:55 --> Hooks Class Initialized
INFO - 2022-12-12 11:56:55 --> Config Class Initialized
INFO - 2022-12-12 11:56:55 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:56:55 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:56:55 --> Utf8 Class Initialized
DEBUG - 2022-12-12 11:56:55 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:56:55 --> Utf8 Class Initialized
INFO - 2022-12-12 11:56:55 --> URI Class Initialized
INFO - 2022-12-12 11:56:55 --> URI Class Initialized
INFO - 2022-12-12 11:56:55 --> Router Class Initialized
INFO - 2022-12-12 11:56:55 --> Router Class Initialized
INFO - 2022-12-12 11:56:55 --> Output Class Initialized
INFO - 2022-12-12 11:56:55 --> Output Class Initialized
INFO - 2022-12-12 11:56:55 --> Security Class Initialized
INFO - 2022-12-12 11:56:55 --> Security Class Initialized
DEBUG - 2022-12-12 11:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:56:55 --> Input Class Initialized
DEBUG - 2022-12-12 11:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:56:55 --> Input Class Initialized
INFO - 2022-12-12 11:56:55 --> Language Class Initialized
INFO - 2022-12-12 11:56:55 --> Language Class Initialized
INFO - 2022-12-12 11:56:55 --> Loader Class Initialized
INFO - 2022-12-12 11:56:55 --> Loader Class Initialized
INFO - 2022-12-12 11:56:55 --> Controller Class Initialized
DEBUG - 2022-12-12 11:56:55 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:56:55 --> Controller Class Initialized
DEBUG - 2022-12-12 11:56:55 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:56:55 --> Database Driver Class Initialized
INFO - 2022-12-12 11:56:55 --> Database Driver Class Initialized
INFO - 2022-12-12 11:57:02 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:57:02 --> Final output sent to browser
DEBUG - 2022-12-12 11:57:02 --> Total execution time: 7.0657
INFO - 2022-12-12 11:57:02 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:57:02 --> Config Class Initialized
INFO - 2022-12-12 11:57:02 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:57:02 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:57:02 --> Utf8 Class Initialized
INFO - 2022-12-12 11:57:02 --> URI Class Initialized
INFO - 2022-12-12 11:57:02 --> Router Class Initialized
INFO - 2022-12-12 11:57:02 --> Output Class Initialized
INFO - 2022-12-12 11:57:02 --> Security Class Initialized
DEBUG - 2022-12-12 11:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:57:02 --> Input Class Initialized
INFO - 2022-12-12 11:57:02 --> Language Class Initialized
INFO - 2022-12-12 11:57:02 --> Loader Class Initialized
INFO - 2022-12-12 11:57:02 --> Controller Class Initialized
DEBUG - 2022-12-12 11:57:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:57:02 --> Database Driver Class Initialized
INFO - 2022-12-12 11:57:02 --> Model "Cluster_model" initialized
INFO - 2022-12-12 11:57:02 --> Final output sent to browser
DEBUG - 2022-12-12 11:57:02 --> Total execution time: 0.0446
INFO - 2022-12-12 11:57:02 --> Config Class Initialized
INFO - 2022-12-12 11:57:02 --> Hooks Class Initialized
DEBUG - 2022-12-12 11:57:02 --> UTF-8 Support Enabled
INFO - 2022-12-12 11:57:02 --> Utf8 Class Initialized
INFO - 2022-12-12 11:57:02 --> URI Class Initialized
INFO - 2022-12-12 11:57:02 --> Router Class Initialized
INFO - 2022-12-12 11:57:02 --> Output Class Initialized
INFO - 2022-12-12 11:57:02 --> Security Class Initialized
DEBUG - 2022-12-12 11:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-12 11:57:02 --> Input Class Initialized
INFO - 2022-12-12 11:57:02 --> Language Class Initialized
INFO - 2022-12-12 11:57:02 --> Loader Class Initialized
INFO - 2022-12-12 11:57:02 --> Controller Class Initialized
DEBUG - 2022-12-12 11:57:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-12 11:57:02 --> Database Driver Class Initialized
INFO - 2022-12-12 11:57:02 --> Model "Cluster_model" initialized
