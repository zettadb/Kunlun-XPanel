<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-25 02:25:53 --> Config Class Initialized
INFO - 2023-05-25 02:25:53 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:25:54 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:25:54 --> Utf8 Class Initialized
INFO - 2023-05-25 02:25:54 --> URI Class Initialized
INFO - 2023-05-25 02:25:54 --> Router Class Initialized
INFO - 2023-05-25 02:25:54 --> Output Class Initialized
INFO - 2023-05-25 02:25:54 --> Security Class Initialized
DEBUG - 2023-05-25 02:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:25:54 --> Input Class Initialized
INFO - 2023-05-25 02:25:54 --> Language Class Initialized
INFO - 2023-05-25 02:25:54 --> Loader Class Initialized
INFO - 2023-05-25 02:25:54 --> Controller Class Initialized
INFO - 2023-05-25 02:25:54 --> Helper loaded: form_helper
INFO - 2023-05-25 02:25:54 --> Helper loaded: url_helper
DEBUG - 2023-05-25 02:25:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:25:54 --> Model "Change_model" initialized
INFO - 2023-05-25 02:25:54 --> Model "Grafana_model" initialized
INFO - 2023-05-25 02:25:54 --> Final output sent to browser
DEBUG - 2023-05-25 02:25:54 --> Total execution time: 0.6584
INFO - 2023-05-25 02:25:54 --> Config Class Initialized
INFO - 2023-05-25 02:25:54 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:25:54 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:25:54 --> Utf8 Class Initialized
INFO - 2023-05-25 02:25:54 --> URI Class Initialized
INFO - 2023-05-25 02:25:54 --> Router Class Initialized
INFO - 2023-05-25 02:25:54 --> Output Class Initialized
INFO - 2023-05-25 02:25:54 --> Security Class Initialized
DEBUG - 2023-05-25 02:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:25:54 --> Input Class Initialized
INFO - 2023-05-25 02:25:54 --> Language Class Initialized
INFO - 2023-05-25 02:25:54 --> Loader Class Initialized
INFO - 2023-05-25 02:25:54 --> Controller Class Initialized
INFO - 2023-05-25 02:25:54 --> Helper loaded: form_helper
INFO - 2023-05-25 02:25:54 --> Helper loaded: url_helper
DEBUG - 2023-05-25 02:25:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:25:54 --> Final output sent to browser
DEBUG - 2023-05-25 02:25:54 --> Total execution time: 0.2435
INFO - 2023-05-25 02:25:54 --> Config Class Initialized
INFO - 2023-05-25 02:25:54 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:25:54 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:25:54 --> Utf8 Class Initialized
INFO - 2023-05-25 02:25:54 --> URI Class Initialized
INFO - 2023-05-25 02:25:54 --> Router Class Initialized
INFO - 2023-05-25 02:25:54 --> Output Class Initialized
INFO - 2023-05-25 02:25:54 --> Security Class Initialized
DEBUG - 2023-05-25 02:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:25:55 --> Input Class Initialized
INFO - 2023-05-25 02:25:55 --> Language Class Initialized
INFO - 2023-05-25 02:25:55 --> Loader Class Initialized
INFO - 2023-05-25 02:25:55 --> Controller Class Initialized
INFO - 2023-05-25 02:25:55 --> Helper loaded: form_helper
INFO - 2023-05-25 02:25:55 --> Helper loaded: url_helper
DEBUG - 2023-05-25 02:25:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:25:55 --> Database Driver Class Initialized
INFO - 2023-05-25 02:25:55 --> Model "Login_model" initialized
INFO - 2023-05-25 02:25:55 --> Final output sent to browser
DEBUG - 2023-05-25 02:25:55 --> Total execution time: 0.4032
INFO - 2023-05-25 02:25:55 --> Config Class Initialized
INFO - 2023-05-25 02:25:55 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:25:55 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:25:55 --> Utf8 Class Initialized
INFO - 2023-05-25 02:25:55 --> URI Class Initialized
INFO - 2023-05-25 02:25:55 --> Router Class Initialized
INFO - 2023-05-25 02:25:55 --> Output Class Initialized
INFO - 2023-05-25 02:25:55 --> Security Class Initialized
DEBUG - 2023-05-25 02:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:25:55 --> Input Class Initialized
INFO - 2023-05-25 02:25:55 --> Language Class Initialized
INFO - 2023-05-25 02:25:55 --> Loader Class Initialized
INFO - 2023-05-25 02:25:55 --> Controller Class Initialized
DEBUG - 2023-05-25 02:25:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:25:55 --> Database Driver Class Initialized
INFO - 2023-05-25 02:25:55 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:25:55 --> Final output sent to browser
DEBUG - 2023-05-25 02:25:55 --> Total execution time: 0.2333
INFO - 2023-05-25 02:25:55 --> Config Class Initialized
INFO - 2023-05-25 02:25:55 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:25:55 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:25:55 --> Utf8 Class Initialized
INFO - 2023-05-25 02:25:55 --> URI Class Initialized
INFO - 2023-05-25 02:25:55 --> Router Class Initialized
INFO - 2023-05-25 02:25:55 --> Output Class Initialized
INFO - 2023-05-25 02:25:55 --> Security Class Initialized
DEBUG - 2023-05-25 02:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:25:55 --> Input Class Initialized
INFO - 2023-05-25 02:25:55 --> Language Class Initialized
INFO - 2023-05-25 02:25:55 --> Loader Class Initialized
INFO - 2023-05-25 02:25:55 --> Controller Class Initialized
DEBUG - 2023-05-25 02:25:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:25:55 --> Database Driver Class Initialized
INFO - 2023-05-25 02:25:55 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:25:55 --> Final output sent to browser
DEBUG - 2023-05-25 02:25:55 --> Total execution time: 0.2093
INFO - 2023-05-25 02:25:56 --> Config Class Initialized
INFO - 2023-05-25 02:25:56 --> Config Class Initialized
INFO - 2023-05-25 02:25:56 --> Hooks Class Initialized
INFO - 2023-05-25 02:25:56 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:25:56 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 02:25:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:25:56 --> Utf8 Class Initialized
INFO - 2023-05-25 02:25:56 --> Utf8 Class Initialized
INFO - 2023-05-25 02:25:56 --> URI Class Initialized
INFO - 2023-05-25 02:25:56 --> URI Class Initialized
INFO - 2023-05-25 02:25:56 --> Router Class Initialized
INFO - 2023-05-25 02:25:56 --> Router Class Initialized
INFO - 2023-05-25 02:25:56 --> Output Class Initialized
INFO - 2023-05-25 02:25:56 --> Output Class Initialized
INFO - 2023-05-25 02:25:56 --> Security Class Initialized
INFO - 2023-05-25 02:25:56 --> Security Class Initialized
DEBUG - 2023-05-25 02:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 02:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:25:56 --> Input Class Initialized
INFO - 2023-05-25 02:25:56 --> Input Class Initialized
INFO - 2023-05-25 02:25:56 --> Language Class Initialized
INFO - 2023-05-25 02:25:56 --> Language Class Initialized
INFO - 2023-05-25 02:25:56 --> Loader Class Initialized
INFO - 2023-05-25 02:25:56 --> Loader Class Initialized
INFO - 2023-05-25 02:25:56 --> Controller Class Initialized
DEBUG - 2023-05-25 02:25:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:25:56 --> Controller Class Initialized
DEBUG - 2023-05-25 02:25:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:25:56 --> Database Driver Class Initialized
INFO - 2023-05-25 02:25:56 --> Database Driver Class Initialized
INFO - 2023-05-25 02:25:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:25:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:25:56 --> Final output sent to browser
DEBUG - 2023-05-25 02:25:56 --> Total execution time: 0.2181
INFO - 2023-05-25 02:25:56 --> Database Driver Class Initialized
INFO - 2023-05-25 02:25:56 --> Model "Login_model" initialized
INFO - 2023-05-25 02:25:56 --> Config Class Initialized
INFO - 2023-05-25 02:25:56 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:25:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:25:56 --> Utf8 Class Initialized
INFO - 2023-05-25 02:25:56 --> URI Class Initialized
INFO - 2023-05-25 02:25:56 --> Router Class Initialized
INFO - 2023-05-25 02:25:56 --> Output Class Initialized
INFO - 2023-05-25 02:25:56 --> Final output sent to browser
DEBUG - 2023-05-25 02:25:56 --> Total execution time: 0.3848
INFO - 2023-05-25 02:25:56 --> Security Class Initialized
DEBUG - 2023-05-25 02:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:25:56 --> Input Class Initialized
INFO - 2023-05-25 02:25:56 --> Language Class Initialized
INFO - 2023-05-25 02:25:56 --> Config Class Initialized
INFO - 2023-05-25 02:25:56 --> Loader Class Initialized
INFO - 2023-05-25 02:25:56 --> Hooks Class Initialized
INFO - 2023-05-25 02:25:56 --> Controller Class Initialized
DEBUG - 2023-05-25 02:25:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 02:25:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:25:56 --> Utf8 Class Initialized
INFO - 2023-05-25 02:25:56 --> URI Class Initialized
INFO - 2023-05-25 02:25:56 --> Router Class Initialized
INFO - 2023-05-25 02:25:56 --> Database Driver Class Initialized
INFO - 2023-05-25 02:25:56 --> Output Class Initialized
INFO - 2023-05-25 02:25:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:25:56 --> Security Class Initialized
INFO - 2023-05-25 02:25:56 --> Final output sent to browser
DEBUG - 2023-05-25 02:25:56 --> Total execution time: 0.2737
DEBUG - 2023-05-25 02:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:25:56 --> Input Class Initialized
INFO - 2023-05-25 02:25:56 --> Language Class Initialized
INFO - 2023-05-25 02:25:56 --> Loader Class Initialized
INFO - 2023-05-25 02:25:56 --> Controller Class Initialized
DEBUG - 2023-05-25 02:25:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:25:56 --> Database Driver Class Initialized
INFO - 2023-05-25 02:25:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:25:56 --> Database Driver Class Initialized
INFO - 2023-05-25 02:25:56 --> Model "Login_model" initialized
INFO - 2023-05-25 02:25:56 --> Final output sent to browser
DEBUG - 2023-05-25 02:25:56 --> Total execution time: 0.5060
INFO - 2023-05-25 02:26:01 --> Config Class Initialized
INFO - 2023-05-25 02:26:01 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:26:01 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:26:01 --> Utf8 Class Initialized
INFO - 2023-05-25 02:26:01 --> URI Class Initialized
INFO - 2023-05-25 02:26:01 --> Router Class Initialized
INFO - 2023-05-25 02:26:01 --> Output Class Initialized
INFO - 2023-05-25 02:26:01 --> Security Class Initialized
DEBUG - 2023-05-25 02:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:26:01 --> Input Class Initialized
INFO - 2023-05-25 02:26:01 --> Language Class Initialized
INFO - 2023-05-25 02:26:01 --> Loader Class Initialized
INFO - 2023-05-25 02:26:01 --> Controller Class Initialized
DEBUG - 2023-05-25 02:26:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:26:01 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:01 --> Model "Login_model" initialized
INFO - 2023-05-25 02:26:01 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:01 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:26:01 --> Final output sent to browser
DEBUG - 2023-05-25 02:26:01 --> Total execution time: 0.2912
INFO - 2023-05-25 02:26:01 --> Config Class Initialized
INFO - 2023-05-25 02:26:01 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:26:02 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:26:02 --> Utf8 Class Initialized
INFO - 2023-05-25 02:26:02 --> URI Class Initialized
INFO - 2023-05-25 02:26:02 --> Router Class Initialized
INFO - 2023-05-25 02:26:02 --> Output Class Initialized
INFO - 2023-05-25 02:26:02 --> Security Class Initialized
DEBUG - 2023-05-25 02:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:26:02 --> Input Class Initialized
INFO - 2023-05-25 02:26:02 --> Language Class Initialized
INFO - 2023-05-25 02:26:02 --> Loader Class Initialized
INFO - 2023-05-25 02:26:02 --> Controller Class Initialized
DEBUG - 2023-05-25 02:26:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:26:02 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:02 --> Model "Login_model" initialized
INFO - 2023-05-25 02:26:02 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:02 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:26:02 --> Final output sent to browser
DEBUG - 2023-05-25 02:26:02 --> Total execution time: 0.2664
INFO - 2023-05-25 02:26:02 --> Config Class Initialized
INFO - 2023-05-25 02:26:02 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:26:02 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:26:02 --> Utf8 Class Initialized
INFO - 2023-05-25 02:26:02 --> URI Class Initialized
INFO - 2023-05-25 02:26:02 --> Router Class Initialized
INFO - 2023-05-25 02:26:02 --> Output Class Initialized
INFO - 2023-05-25 02:26:02 --> Security Class Initialized
DEBUG - 2023-05-25 02:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:26:02 --> Input Class Initialized
INFO - 2023-05-25 02:26:02 --> Language Class Initialized
INFO - 2023-05-25 02:26:02 --> Loader Class Initialized
INFO - 2023-05-25 02:26:02 --> Controller Class Initialized
DEBUG - 2023-05-25 02:26:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:26:02 --> Final output sent to browser
DEBUG - 2023-05-25 02:26:02 --> Total execution time: 0.1621
INFO - 2023-05-25 02:26:02 --> Config Class Initialized
INFO - 2023-05-25 02:26:02 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:26:02 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:26:02 --> Utf8 Class Initialized
INFO - 2023-05-25 02:26:02 --> URI Class Initialized
INFO - 2023-05-25 02:26:02 --> Router Class Initialized
INFO - 2023-05-25 02:26:02 --> Output Class Initialized
INFO - 2023-05-25 02:26:02 --> Security Class Initialized
DEBUG - 2023-05-25 02:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:26:02 --> Input Class Initialized
INFO - 2023-05-25 02:26:02 --> Language Class Initialized
INFO - 2023-05-25 02:26:02 --> Loader Class Initialized
INFO - 2023-05-25 02:26:02 --> Controller Class Initialized
DEBUG - 2023-05-25 02:26:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:26:02 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:02 --> Model "Login_model" initialized
INFO - 2023-05-25 02:26:02 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:02 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:26:02 --> Final output sent to browser
DEBUG - 2023-05-25 02:26:02 --> Total execution time: 0.2448
INFO - 2023-05-25 02:26:07 --> Config Class Initialized
INFO - 2023-05-25 02:26:07 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:26:07 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:26:07 --> Utf8 Class Initialized
INFO - 2023-05-25 02:26:07 --> URI Class Initialized
INFO - 2023-05-25 02:26:07 --> Router Class Initialized
INFO - 2023-05-25 02:26:07 --> Output Class Initialized
INFO - 2023-05-25 02:26:07 --> Security Class Initialized
DEBUG - 2023-05-25 02:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:26:07 --> Input Class Initialized
INFO - 2023-05-25 02:26:07 --> Language Class Initialized
INFO - 2023-05-25 02:26:07 --> Loader Class Initialized
INFO - 2023-05-25 02:26:07 --> Controller Class Initialized
DEBUG - 2023-05-25 02:26:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:26:07 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:07 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:26:07 --> Final output sent to browser
DEBUG - 2023-05-25 02:26:07 --> Total execution time: 0.1874
INFO - 2023-05-25 02:26:07 --> Config Class Initialized
INFO - 2023-05-25 02:26:07 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:26:07 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:26:07 --> Utf8 Class Initialized
INFO - 2023-05-25 02:26:07 --> URI Class Initialized
INFO - 2023-05-25 02:26:07 --> Router Class Initialized
INFO - 2023-05-25 02:26:07 --> Output Class Initialized
INFO - 2023-05-25 02:26:07 --> Security Class Initialized
DEBUG - 2023-05-25 02:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:26:07 --> Input Class Initialized
INFO - 2023-05-25 02:26:07 --> Language Class Initialized
INFO - 2023-05-25 02:26:07 --> Loader Class Initialized
INFO - 2023-05-25 02:26:07 --> Controller Class Initialized
DEBUG - 2023-05-25 02:26:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:26:07 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:07 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:26:07 --> Final output sent to browser
DEBUG - 2023-05-25 02:26:07 --> Total execution time: 0.2963
INFO - 2023-05-25 02:26:10 --> Config Class Initialized
INFO - 2023-05-25 02:26:10 --> Config Class Initialized
INFO - 2023-05-25 02:26:10 --> Config Class Initialized
INFO - 2023-05-25 02:26:10 --> Hooks Class Initialized
INFO - 2023-05-25 02:26:10 --> Hooks Class Initialized
INFO - 2023-05-25 02:26:10 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:26:10 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 02:26:10 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 02:26:10 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:26:10 --> Utf8 Class Initialized
INFO - 2023-05-25 02:26:10 --> Utf8 Class Initialized
INFO - 2023-05-25 02:26:10 --> Utf8 Class Initialized
INFO - 2023-05-25 02:26:10 --> URI Class Initialized
INFO - 2023-05-25 02:26:10 --> URI Class Initialized
INFO - 2023-05-25 02:26:10 --> URI Class Initialized
INFO - 2023-05-25 02:26:10 --> Router Class Initialized
INFO - 2023-05-25 02:26:10 --> Router Class Initialized
INFO - 2023-05-25 02:26:10 --> Router Class Initialized
INFO - 2023-05-25 02:26:10 --> Output Class Initialized
INFO - 2023-05-25 02:26:10 --> Output Class Initialized
INFO - 2023-05-25 02:26:10 --> Output Class Initialized
INFO - 2023-05-25 02:26:10 --> Security Class Initialized
INFO - 2023-05-25 02:26:10 --> Security Class Initialized
INFO - 2023-05-25 02:26:10 --> Security Class Initialized
DEBUG - 2023-05-25 02:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 02:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 02:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:26:10 --> Input Class Initialized
INFO - 2023-05-25 02:26:10 --> Input Class Initialized
INFO - 2023-05-25 02:26:10 --> Input Class Initialized
INFO - 2023-05-25 02:26:10 --> Language Class Initialized
INFO - 2023-05-25 02:26:10 --> Language Class Initialized
INFO - 2023-05-25 02:26:10 --> Language Class Initialized
INFO - 2023-05-25 02:26:10 --> Loader Class Initialized
INFO - 2023-05-25 02:26:10 --> Controller Class Initialized
INFO - 2023-05-25 02:26:10 --> Loader Class Initialized
DEBUG - 2023-05-25 02:26:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:26:10 --> Loader Class Initialized
INFO - 2023-05-25 02:26:10 --> Controller Class Initialized
DEBUG - 2023-05-25 02:26:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:26:10 --> Controller Class Initialized
DEBUG - 2023-05-25 02:26:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:26:10 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:10 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:10 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:26:10 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:10 --> Final output sent to browser
DEBUG - 2023-05-25 02:26:10 --> Total execution time: 0.1866
INFO - 2023-05-25 02:26:10 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:26:10 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:26:10 --> Final output sent to browser
DEBUG - 2023-05-25 02:26:10 --> Total execution time: 0.2138
INFO - 2023-05-25 02:26:10 --> Config Class Initialized
INFO - 2023-05-25 02:26:10 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:26:10 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:26:10 --> Final output sent to browser
INFO - 2023-05-25 02:26:10 --> Config Class Initialized
INFO - 2023-05-25 02:26:10 --> Utf8 Class Initialized
DEBUG - 2023-05-25 02:26:10 --> Total execution time: 0.2701
INFO - 2023-05-25 02:26:10 --> Hooks Class Initialized
INFO - 2023-05-25 02:26:10 --> URI Class Initialized
DEBUG - 2023-05-25 02:26:10 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:26:10 --> Router Class Initialized
INFO - 2023-05-25 02:26:10 --> Utf8 Class Initialized
INFO - 2023-05-25 02:26:10 --> URI Class Initialized
INFO - 2023-05-25 02:26:10 --> Output Class Initialized
INFO - 2023-05-25 02:26:10 --> Security Class Initialized
INFO - 2023-05-25 02:26:10 --> Router Class Initialized
DEBUG - 2023-05-25 02:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:26:10 --> Output Class Initialized
INFO - 2023-05-25 02:26:10 --> Input Class Initialized
INFO - 2023-05-25 02:26:10 --> Security Class Initialized
INFO - 2023-05-25 02:26:10 --> Language Class Initialized
DEBUG - 2023-05-25 02:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:26:10 --> Input Class Initialized
INFO - 2023-05-25 02:26:10 --> Loader Class Initialized
INFO - 2023-05-25 02:26:10 --> Language Class Initialized
INFO - 2023-05-25 02:26:10 --> Controller Class Initialized
INFO - 2023-05-25 02:26:10 --> Loader Class Initialized
DEBUG - 2023-05-25 02:26:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:26:10 --> Controller Class Initialized
DEBUG - 2023-05-25 02:26:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:26:10 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:10 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:26:10 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:10 --> Final output sent to browser
INFO - 2023-05-25 02:26:10 --> Model "Cluster_model" initialized
DEBUG - 2023-05-25 02:26:10 --> Total execution time: 0.2432
INFO - 2023-05-25 02:26:10 --> Final output sent to browser
DEBUG - 2023-05-25 02:26:10 --> Total execution time: 0.2252
INFO - 2023-05-25 02:26:10 --> Config Class Initialized
INFO - 2023-05-25 02:26:10 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:26:10 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:26:10 --> Utf8 Class Initialized
INFO - 2023-05-25 02:26:10 --> URI Class Initialized
INFO - 2023-05-25 02:26:10 --> Router Class Initialized
INFO - 2023-05-25 02:26:10 --> Output Class Initialized
INFO - 2023-05-25 02:26:10 --> Security Class Initialized
DEBUG - 2023-05-25 02:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:26:10 --> Input Class Initialized
INFO - 2023-05-25 02:26:10 --> Language Class Initialized
INFO - 2023-05-25 02:26:10 --> Loader Class Initialized
INFO - 2023-05-25 02:26:10 --> Controller Class Initialized
DEBUG - 2023-05-25 02:26:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:26:10 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:10 --> Model "Cluster_model" initialized
INFO - 2023-05-25 02:26:11 --> Config Class Initialized
INFO - 2023-05-25 02:26:11 --> Hooks Class Initialized
DEBUG - 2023-05-25 02:26:11 --> UTF-8 Support Enabled
INFO - 2023-05-25 02:26:11 --> Utf8 Class Initialized
INFO - 2023-05-25 02:26:11 --> URI Class Initialized
INFO - 2023-05-25 02:26:11 --> Router Class Initialized
INFO - 2023-05-25 02:26:11 --> Output Class Initialized
INFO - 2023-05-25 02:26:11 --> Security Class Initialized
DEBUG - 2023-05-25 02:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 02:26:11 --> Input Class Initialized
INFO - 2023-05-25 02:26:11 --> Language Class Initialized
INFO - 2023-05-25 02:26:11 --> Loader Class Initialized
INFO - 2023-05-25 02:26:11 --> Controller Class Initialized
DEBUG - 2023-05-25 02:26:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 02:26:11 --> Database Driver Class Initialized
INFO - 2023-05-25 02:26:11 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:12:07 --> Config Class Initialized
INFO - 2023-05-25 07:12:07 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:12:07 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:07 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:07 --> URI Class Initialized
INFO - 2023-05-25 07:12:07 --> Router Class Initialized
INFO - 2023-05-25 07:12:07 --> Output Class Initialized
INFO - 2023-05-25 07:12:07 --> Security Class Initialized
DEBUG - 2023-05-25 07:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:12:07 --> Input Class Initialized
INFO - 2023-05-25 07:12:07 --> Language Class Initialized
INFO - 2023-05-25 07:12:07 --> Loader Class Initialized
INFO - 2023-05-25 07:12:07 --> Controller Class Initialized
INFO - 2023-05-25 07:12:07 --> Helper loaded: form_helper
INFO - 2023-05-25 07:12:07 --> Helper loaded: url_helper
DEBUG - 2023-05-25 07:12:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:07 --> Model "Change_model" initialized
INFO - 2023-05-25 07:12:07 --> Model "Grafana_model" initialized
INFO - 2023-05-25 07:12:07 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:07 --> Total execution time: 0.3161
INFO - 2023-05-25 07:12:07 --> Config Class Initialized
INFO - 2023-05-25 07:12:07 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:12:07 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:07 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:07 --> URI Class Initialized
INFO - 2023-05-25 07:12:07 --> Router Class Initialized
INFO - 2023-05-25 07:12:07 --> Output Class Initialized
INFO - 2023-05-25 07:12:07 --> Security Class Initialized
DEBUG - 2023-05-25 07:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:12:07 --> Input Class Initialized
INFO - 2023-05-25 07:12:07 --> Language Class Initialized
INFO - 2023-05-25 07:12:07 --> Loader Class Initialized
INFO - 2023-05-25 07:12:07 --> Controller Class Initialized
INFO - 2023-05-25 07:12:07 --> Helper loaded: form_helper
INFO - 2023-05-25 07:12:07 --> Helper loaded: url_helper
DEBUG - 2023-05-25 07:12:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:07 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:07 --> Total execution time: 0.2182
INFO - 2023-05-25 07:12:07 --> Config Class Initialized
INFO - 2023-05-25 07:12:07 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:12:07 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:07 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:07 --> URI Class Initialized
INFO - 2023-05-25 07:12:07 --> Router Class Initialized
INFO - 2023-05-25 07:12:07 --> Output Class Initialized
INFO - 2023-05-25 07:12:07 --> Security Class Initialized
DEBUG - 2023-05-25 07:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:12:07 --> Input Class Initialized
INFO - 2023-05-25 07:12:07 --> Language Class Initialized
INFO - 2023-05-25 07:12:07 --> Loader Class Initialized
INFO - 2023-05-25 07:12:07 --> Controller Class Initialized
INFO - 2023-05-25 07:12:07 --> Helper loaded: form_helper
INFO - 2023-05-25 07:12:07 --> Helper loaded: url_helper
DEBUG - 2023-05-25 07:12:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:08 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:08 --> Model "Login_model" initialized
INFO - 2023-05-25 07:12:08 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:08 --> Total execution time: 0.3048
INFO - 2023-05-25 07:12:08 --> Config Class Initialized
INFO - 2023-05-25 07:12:08 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:12:08 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:08 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:08 --> URI Class Initialized
INFO - 2023-05-25 07:12:08 --> Router Class Initialized
INFO - 2023-05-25 07:12:08 --> Output Class Initialized
INFO - 2023-05-25 07:12:08 --> Security Class Initialized
DEBUG - 2023-05-25 07:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:12:08 --> Input Class Initialized
INFO - 2023-05-25 07:12:08 --> Language Class Initialized
INFO - 2023-05-25 07:12:08 --> Loader Class Initialized
INFO - 2023-05-25 07:12:08 --> Controller Class Initialized
DEBUG - 2023-05-25 07:12:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:08 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:08 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:12:08 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:08 --> Total execution time: 0.2303
INFO - 2023-05-25 07:12:08 --> Config Class Initialized
INFO - 2023-05-25 07:12:08 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:12:08 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:08 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:08 --> URI Class Initialized
INFO - 2023-05-25 07:12:08 --> Router Class Initialized
INFO - 2023-05-25 07:12:08 --> Output Class Initialized
INFO - 2023-05-25 07:12:08 --> Security Class Initialized
DEBUG - 2023-05-25 07:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:12:08 --> Input Class Initialized
INFO - 2023-05-25 07:12:08 --> Language Class Initialized
INFO - 2023-05-25 07:12:08 --> Loader Class Initialized
INFO - 2023-05-25 07:12:08 --> Controller Class Initialized
DEBUG - 2023-05-25 07:12:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:08 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:08 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:12:08 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:08 --> Total execution time: 0.2354
INFO - 2023-05-25 07:12:08 --> Config Class Initialized
INFO - 2023-05-25 07:12:08 --> Config Class Initialized
INFO - 2023-05-25 07:12:08 --> Hooks Class Initialized
INFO - 2023-05-25 07:12:08 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:12:08 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:12:08 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:08 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:08 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:08 --> URI Class Initialized
INFO - 2023-05-25 07:12:08 --> URI Class Initialized
INFO - 2023-05-25 07:12:08 --> Router Class Initialized
INFO - 2023-05-25 07:12:08 --> Router Class Initialized
INFO - 2023-05-25 07:12:08 --> Output Class Initialized
INFO - 2023-05-25 07:12:08 --> Output Class Initialized
INFO - 2023-05-25 07:12:08 --> Security Class Initialized
INFO - 2023-05-25 07:12:08 --> Security Class Initialized
DEBUG - 2023-05-25 07:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:12:08 --> Input Class Initialized
INFO - 2023-05-25 07:12:08 --> Input Class Initialized
INFO - 2023-05-25 07:12:08 --> Language Class Initialized
INFO - 2023-05-25 07:12:08 --> Language Class Initialized
INFO - 2023-05-25 07:12:08 --> Loader Class Initialized
INFO - 2023-05-25 07:12:08 --> Loader Class Initialized
INFO - 2023-05-25 07:12:08 --> Controller Class Initialized
DEBUG - 2023-05-25 07:12:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:08 --> Controller Class Initialized
DEBUG - 2023-05-25 07:12:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:08 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:09 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:09 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:12:09 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:12:09 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:09 --> Total execution time: 0.2393
INFO - 2023-05-25 07:12:09 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:09 --> Model "Login_model" initialized
INFO - 2023-05-25 07:12:09 --> Config Class Initialized
INFO - 2023-05-25 07:12:09 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:12:09 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:09 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:09 --> URI Class Initialized
INFO - 2023-05-25 07:12:09 --> Router Class Initialized
INFO - 2023-05-25 07:12:09 --> Output Class Initialized
INFO - 2023-05-25 07:12:09 --> Security Class Initialized
DEBUG - 2023-05-25 07:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:12:09 --> Input Class Initialized
INFO - 2023-05-25 07:12:09 --> Language Class Initialized
INFO - 2023-05-25 07:12:09 --> Loader Class Initialized
INFO - 2023-05-25 07:12:09 --> Controller Class Initialized
DEBUG - 2023-05-25 07:12:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:09 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:09 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:12:09 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:09 --> Total execution time: 0.2410
INFO - 2023-05-25 07:12:09 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:09 --> Total execution time: 0.5520
INFO - 2023-05-25 07:12:09 --> Config Class Initialized
INFO - 2023-05-25 07:12:09 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:12:09 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:09 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:09 --> URI Class Initialized
INFO - 2023-05-25 07:12:09 --> Router Class Initialized
INFO - 2023-05-25 07:12:09 --> Output Class Initialized
INFO - 2023-05-25 07:12:09 --> Security Class Initialized
DEBUG - 2023-05-25 07:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:12:09 --> Input Class Initialized
INFO - 2023-05-25 07:12:09 --> Language Class Initialized
INFO - 2023-05-25 07:12:09 --> Loader Class Initialized
INFO - 2023-05-25 07:12:09 --> Controller Class Initialized
DEBUG - 2023-05-25 07:12:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:09 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:09 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:12:09 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:09 --> Model "Login_model" initialized
INFO - 2023-05-25 07:12:09 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:09 --> Total execution time: 0.5617
INFO - 2023-05-25 07:12:28 --> Config Class Initialized
INFO - 2023-05-25 07:12:28 --> Config Class Initialized
INFO - 2023-05-25 07:12:28 --> Config Class Initialized
INFO - 2023-05-25 07:12:28 --> Hooks Class Initialized
INFO - 2023-05-25 07:12:28 --> Hooks Class Initialized
INFO - 2023-05-25 07:12:28 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:12:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:12:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:12:28 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:28 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:28 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:28 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:28 --> URI Class Initialized
INFO - 2023-05-25 07:12:28 --> URI Class Initialized
INFO - 2023-05-25 07:12:28 --> URI Class Initialized
INFO - 2023-05-25 07:12:28 --> Router Class Initialized
INFO - 2023-05-25 07:12:28 --> Router Class Initialized
INFO - 2023-05-25 07:12:28 --> Router Class Initialized
INFO - 2023-05-25 07:12:28 --> Output Class Initialized
INFO - 2023-05-25 07:12:28 --> Output Class Initialized
INFO - 2023-05-25 07:12:28 --> Output Class Initialized
INFO - 2023-05-25 07:12:28 --> Security Class Initialized
INFO - 2023-05-25 07:12:28 --> Security Class Initialized
INFO - 2023-05-25 07:12:28 --> Security Class Initialized
DEBUG - 2023-05-25 07:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:12:28 --> Input Class Initialized
INFO - 2023-05-25 07:12:28 --> Input Class Initialized
INFO - 2023-05-25 07:12:28 --> Input Class Initialized
INFO - 2023-05-25 07:12:28 --> Language Class Initialized
INFO - 2023-05-25 07:12:28 --> Language Class Initialized
INFO - 2023-05-25 07:12:28 --> Language Class Initialized
INFO - 2023-05-25 07:12:29 --> Loader Class Initialized
INFO - 2023-05-25 07:12:29 --> Loader Class Initialized
INFO - 2023-05-25 07:12:29 --> Controller Class Initialized
INFO - 2023-05-25 07:12:29 --> Controller Class Initialized
DEBUG - 2023-05-25 07:12:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:12:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:29 --> Loader Class Initialized
INFO - 2023-05-25 07:12:29 --> Controller Class Initialized
INFO - 2023-05-25 07:12:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:29 --> Database Driver Class Initialized
DEBUG - 2023-05-25 07:12:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:29 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:12:29 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:12:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:29 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:29 --> Total execution time: 0.2224
INFO - 2023-05-25 07:12:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:29 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:29 --> Total execution time: 0.2354
INFO - 2023-05-25 07:12:29 --> Model "Login_model" initialized
INFO - 2023-05-25 07:12:29 --> Final output sent to browser
INFO - 2023-05-25 07:12:29 --> Config Class Initialized
DEBUG - 2023-05-25 07:12:29 --> Total execution time: 0.2805
INFO - 2023-05-25 07:12:29 --> Hooks Class Initialized
INFO - 2023-05-25 07:12:29 --> Config Class Initialized
INFO - 2023-05-25 07:12:29 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:12:29 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:29 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:29 --> URI Class Initialized
DEBUG - 2023-05-25 07:12:29 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:29 --> Config Class Initialized
INFO - 2023-05-25 07:12:29 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:29 --> Hooks Class Initialized
INFO - 2023-05-25 07:12:29 --> URI Class Initialized
INFO - 2023-05-25 07:12:29 --> Router Class Initialized
DEBUG - 2023-05-25 07:12:29 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:29 --> Router Class Initialized
INFO - 2023-05-25 07:12:29 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:29 --> Output Class Initialized
INFO - 2023-05-25 07:12:29 --> URI Class Initialized
INFO - 2023-05-25 07:12:29 --> Security Class Initialized
INFO - 2023-05-25 07:12:29 --> Output Class Initialized
DEBUG - 2023-05-25 07:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:12:29 --> Input Class Initialized
INFO - 2023-05-25 07:12:29 --> Router Class Initialized
INFO - 2023-05-25 07:12:29 --> Security Class Initialized
DEBUG - 2023-05-25 07:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:12:29 --> Language Class Initialized
INFO - 2023-05-25 07:12:29 --> Input Class Initialized
INFO - 2023-05-25 07:12:29 --> Output Class Initialized
INFO - 2023-05-25 07:12:29 --> Language Class Initialized
INFO - 2023-05-25 07:12:29 --> Security Class Initialized
DEBUG - 2023-05-25 07:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:12:29 --> Loader Class Initialized
INFO - 2023-05-25 07:12:29 --> Input Class Initialized
INFO - 2023-05-25 07:12:29 --> Loader Class Initialized
INFO - 2023-05-25 07:12:29 --> Language Class Initialized
INFO - 2023-05-25 07:12:29 --> Controller Class Initialized
DEBUG - 2023-05-25 07:12:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:29 --> Controller Class Initialized
DEBUG - 2023-05-25 07:12:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:29 --> Loader Class Initialized
INFO - 2023-05-25 07:12:29 --> Controller Class Initialized
DEBUG - 2023-05-25 07:12:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:29 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:12:29 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:12:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:29 --> Final output sent to browser
INFO - 2023-05-25 07:12:29 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:29 --> Total execution time: 0.2860
DEBUG - 2023-05-25 07:12:29 --> Total execution time: 0.3032
INFO - 2023-05-25 07:12:29 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:12:29 --> Config Class Initialized
INFO - 2023-05-25 07:12:29 --> Final output sent to browser
INFO - 2023-05-25 07:12:29 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:12:29 --> Total execution time: 0.3165
INFO - 2023-05-25 07:12:29 --> Config Class Initialized
INFO - 2023-05-25 07:12:29 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:12:29 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:29 --> Utf8 Class Initialized
DEBUG - 2023-05-25 07:12:29 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:12:29 --> Utf8 Class Initialized
INFO - 2023-05-25 07:12:29 --> URI Class Initialized
INFO - 2023-05-25 07:12:29 --> URI Class Initialized
INFO - 2023-05-25 07:12:29 --> Router Class Initialized
INFO - 2023-05-25 07:12:29 --> Router Class Initialized
INFO - 2023-05-25 07:12:29 --> Output Class Initialized
INFO - 2023-05-25 07:12:29 --> Output Class Initialized
INFO - 2023-05-25 07:12:29 --> Security Class Initialized
INFO - 2023-05-25 07:12:29 --> Security Class Initialized
DEBUG - 2023-05-25 07:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:12:29 --> Input Class Initialized
INFO - 2023-05-25 07:12:29 --> Input Class Initialized
INFO - 2023-05-25 07:12:29 --> Language Class Initialized
INFO - 2023-05-25 07:12:29 --> Language Class Initialized
INFO - 2023-05-25 07:12:29 --> Loader Class Initialized
INFO - 2023-05-25 07:12:29 --> Loader Class Initialized
INFO - 2023-05-25 07:12:29 --> Controller Class Initialized
INFO - 2023-05-25 07:12:29 --> Controller Class Initialized
DEBUG - 2023-05-25 07:12:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:12:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:12:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:12:29 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:12:29 --> Model "Login_model" initialized
INFO - 2023-05-25 07:12:29 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:29 --> Total execution time: 0.2570
INFO - 2023-05-25 07:12:29 --> Final output sent to browser
DEBUG - 2023-05-25 07:12:29 --> Total execution time: 0.2705
INFO - 2023-05-25 07:13:28 --> Config Class Initialized
INFO - 2023-05-25 07:13:28 --> Config Class Initialized
INFO - 2023-05-25 07:13:28 --> Hooks Class Initialized
INFO - 2023-05-25 07:13:28 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:13:28 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:28 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:28 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:28 --> URI Class Initialized
INFO - 2023-05-25 07:13:28 --> URI Class Initialized
INFO - 2023-05-25 07:13:28 --> Router Class Initialized
INFO - 2023-05-25 07:13:28 --> Router Class Initialized
INFO - 2023-05-25 07:13:28 --> Output Class Initialized
INFO - 2023-05-25 07:13:28 --> Output Class Initialized
INFO - 2023-05-25 07:13:28 --> Security Class Initialized
INFO - 2023-05-25 07:13:28 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:28 --> Input Class Initialized
INFO - 2023-05-25 07:13:28 --> Input Class Initialized
INFO - 2023-05-25 07:13:28 --> Language Class Initialized
INFO - 2023-05-25 07:13:28 --> Language Class Initialized
INFO - 2023-05-25 07:13:28 --> Loader Class Initialized
INFO - 2023-05-25 07:13:28 --> Loader Class Initialized
INFO - 2023-05-25 07:13:28 --> Controller Class Initialized
INFO - 2023-05-25 07:13:28 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:13:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:29 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:29 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:29 --> Model "Login_model" initialized
INFO - 2023-05-25 07:13:29 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:29 --> Total execution time: 0.1792
INFO - 2023-05-25 07:13:29 --> Config Class Initialized
INFO - 2023-05-25 07:13:29 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:29 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:29 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:29 --> URI Class Initialized
INFO - 2023-05-25 07:13:29 --> Router Class Initialized
INFO - 2023-05-25 07:13:29 --> Output Class Initialized
INFO - 2023-05-25 07:13:29 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:29 --> Input Class Initialized
INFO - 2023-05-25 07:13:29 --> Language Class Initialized
INFO - 2023-05-25 07:13:29 --> Loader Class Initialized
INFO - 2023-05-25 07:13:29 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:29 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:29 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:29 --> Total execution time: 0.2347
INFO - 2023-05-25 07:13:38 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:38 --> Total execution time: 9.8382
INFO - 2023-05-25 07:13:38 --> Config Class Initialized
INFO - 2023-05-25 07:13:38 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:38 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:38 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:38 --> URI Class Initialized
INFO - 2023-05-25 07:13:38 --> Router Class Initialized
INFO - 2023-05-25 07:13:38 --> Output Class Initialized
INFO - 2023-05-25 07:13:38 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:38 --> Input Class Initialized
INFO - 2023-05-25 07:13:38 --> Language Class Initialized
INFO - 2023-05-25 07:13:38 --> Loader Class Initialized
INFO - 2023-05-25 07:13:38 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:38 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:38 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:38 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:38 --> Model "Login_model" initialized
INFO - 2023-05-25 07:13:41 --> Config Class Initialized
INFO - 2023-05-25 07:13:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:41 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:41 --> URI Class Initialized
INFO - 2023-05-25 07:13:41 --> Router Class Initialized
INFO - 2023-05-25 07:13:41 --> Output Class Initialized
INFO - 2023-05-25 07:13:41 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:41 --> Input Class Initialized
INFO - 2023-05-25 07:13:41 --> Language Class Initialized
INFO - 2023-05-25 07:13:41 --> Loader Class Initialized
INFO - 2023-05-25 07:13:41 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:41 --> Model "Login_model" initialized
INFO - 2023-05-25 07:13:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:41 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:41 --> Total execution time: 0.2643
INFO - 2023-05-25 07:13:41 --> Config Class Initialized
INFO - 2023-05-25 07:13:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:41 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:41 --> URI Class Initialized
INFO - 2023-05-25 07:13:41 --> Router Class Initialized
INFO - 2023-05-25 07:13:41 --> Output Class Initialized
INFO - 2023-05-25 07:13:41 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:41 --> Input Class Initialized
INFO - 2023-05-25 07:13:41 --> Language Class Initialized
INFO - 2023-05-25 07:13:41 --> Loader Class Initialized
INFO - 2023-05-25 07:13:41 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:41 --> Model "Login_model" initialized
INFO - 2023-05-25 07:13:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:41 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:41 --> Total execution time: 0.2648
INFO - 2023-05-25 07:13:41 --> Config Class Initialized
INFO - 2023-05-25 07:13:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:41 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:41 --> URI Class Initialized
INFO - 2023-05-25 07:13:41 --> Router Class Initialized
INFO - 2023-05-25 07:13:41 --> Output Class Initialized
INFO - 2023-05-25 07:13:41 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:41 --> Input Class Initialized
INFO - 2023-05-25 07:13:41 --> Language Class Initialized
INFO - 2023-05-25 07:13:41 --> Loader Class Initialized
INFO - 2023-05-25 07:13:41 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:41 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:41 --> Total execution time: 0.1515
INFO - 2023-05-25 07:13:42 --> Config Class Initialized
INFO - 2023-05-25 07:13:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:42 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:42 --> URI Class Initialized
INFO - 2023-05-25 07:13:42 --> Router Class Initialized
INFO - 2023-05-25 07:13:42 --> Output Class Initialized
INFO - 2023-05-25 07:13:42 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:42 --> Input Class Initialized
INFO - 2023-05-25 07:13:42 --> Language Class Initialized
INFO - 2023-05-25 07:13:42 --> Loader Class Initialized
INFO - 2023-05-25 07:13:42 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:42 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:42 --> Model "Login_model" initialized
INFO - 2023-05-25 07:13:42 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:42 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:42 --> Total execution time: 0.2715
INFO - 2023-05-25 07:13:44 --> Config Class Initialized
INFO - 2023-05-25 07:13:44 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:44 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:44 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:44 --> URI Class Initialized
INFO - 2023-05-25 07:13:44 --> Router Class Initialized
INFO - 2023-05-25 07:13:44 --> Output Class Initialized
INFO - 2023-05-25 07:13:44 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:44 --> Input Class Initialized
INFO - 2023-05-25 07:13:44 --> Language Class Initialized
INFO - 2023-05-25 07:13:44 --> Loader Class Initialized
INFO - 2023-05-25 07:13:44 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:44 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:44 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:44 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:44 --> Total execution time: 0.2295
INFO - 2023-05-25 07:13:44 --> Config Class Initialized
INFO - 2023-05-25 07:13:44 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:44 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:44 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:44 --> URI Class Initialized
INFO - 2023-05-25 07:13:44 --> Router Class Initialized
INFO - 2023-05-25 07:13:44 --> Output Class Initialized
INFO - 2023-05-25 07:13:44 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:44 --> Input Class Initialized
INFO - 2023-05-25 07:13:44 --> Language Class Initialized
INFO - 2023-05-25 07:13:44 --> Loader Class Initialized
INFO - 2023-05-25 07:13:44 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:44 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:44 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:44 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:44 --> Total execution time: 0.2497
INFO - 2023-05-25 07:13:46 --> Config Class Initialized
INFO - 2023-05-25 07:13:46 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:46 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:46 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:46 --> URI Class Initialized
INFO - 2023-05-25 07:13:46 --> Router Class Initialized
INFO - 2023-05-25 07:13:46 --> Output Class Initialized
INFO - 2023-05-25 07:13:46 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:46 --> Input Class Initialized
INFO - 2023-05-25 07:13:46 --> Language Class Initialized
INFO - 2023-05-25 07:13:46 --> Loader Class Initialized
INFO - 2023-05-25 07:13:46 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:46 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:46 --> Model "Login_model" initialized
INFO - 2023-05-25 07:13:46 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:46 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:46 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:46 --> Total execution time: 0.2734
INFO - 2023-05-25 07:13:46 --> Config Class Initialized
INFO - 2023-05-25 07:13:46 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:46 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:46 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:46 --> URI Class Initialized
INFO - 2023-05-25 07:13:46 --> Router Class Initialized
INFO - 2023-05-25 07:13:46 --> Output Class Initialized
INFO - 2023-05-25 07:13:46 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:46 --> Input Class Initialized
INFO - 2023-05-25 07:13:46 --> Language Class Initialized
INFO - 2023-05-25 07:13:46 --> Loader Class Initialized
INFO - 2023-05-25 07:13:46 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:46 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:46 --> Model "Login_model" initialized
INFO - 2023-05-25 07:13:46 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:46 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:46 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:46 --> Total execution time: 0.3257
INFO - 2023-05-25 07:13:48 --> Config Class Initialized
INFO - 2023-05-25 07:13:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:13:48 --> Config Class Initialized
INFO - 2023-05-25 07:13:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:48 --> Utf8 Class Initialized
DEBUG - 2023-05-25 07:13:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:48 --> URI Class Initialized
INFO - 2023-05-25 07:13:48 --> URI Class Initialized
INFO - 2023-05-25 07:13:48 --> Router Class Initialized
INFO - 2023-05-25 07:13:48 --> Router Class Initialized
INFO - 2023-05-25 07:13:48 --> Output Class Initialized
INFO - 2023-05-25 07:13:48 --> Output Class Initialized
INFO - 2023-05-25 07:13:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:48 --> Security Class Initialized
INFO - 2023-05-25 07:13:48 --> Input Class Initialized
DEBUG - 2023-05-25 07:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:48 --> Language Class Initialized
INFO - 2023-05-25 07:13:48 --> Input Class Initialized
INFO - 2023-05-25 07:13:48 --> Language Class Initialized
INFO - 2023-05-25 07:13:48 --> Loader Class Initialized
INFO - 2023-05-25 07:13:48 --> Loader Class Initialized
INFO - 2023-05-25 07:13:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:48 --> Model "Login_model" initialized
INFO - 2023-05-25 07:13:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:48 --> Total execution time: 0.2463
INFO - 2023-05-25 07:13:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:48 --> Total execution time: 0.2774
INFO - 2023-05-25 07:13:48 --> Config Class Initialized
INFO - 2023-05-25 07:13:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:13:48 --> Config Class Initialized
INFO - 2023-05-25 07:13:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:48 --> URI Class Initialized
DEBUG - 2023-05-25 07:13:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:48 --> URI Class Initialized
INFO - 2023-05-25 07:13:48 --> Router Class Initialized
INFO - 2023-05-25 07:13:48 --> Output Class Initialized
INFO - 2023-05-25 07:13:48 --> Router Class Initialized
INFO - 2023-05-25 07:13:48 --> Security Class Initialized
INFO - 2023-05-25 07:13:48 --> Output Class Initialized
DEBUG - 2023-05-25 07:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:48 --> Input Class Initialized
INFO - 2023-05-25 07:13:48 --> Security Class Initialized
INFO - 2023-05-25 07:13:48 --> Language Class Initialized
DEBUG - 2023-05-25 07:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:48 --> Input Class Initialized
INFO - 2023-05-25 07:13:48 --> Language Class Initialized
INFO - 2023-05-25 07:13:48 --> Loader Class Initialized
INFO - 2023-05-25 07:13:48 --> Controller Class Initialized
INFO - 2023-05-25 07:13:48 --> Loader Class Initialized
DEBUG - 2023-05-25 07:13:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:48 --> Final output sent to browser
INFO - 2023-05-25 07:13:48 --> Model "Cluster_model" initialized
DEBUG - 2023-05-25 07:13:48 --> Total execution time: 10.0067
INFO - 2023-05-25 07:13:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:48 --> Total execution time: 0.3006
INFO - 2023-05-25 07:13:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:48 --> Total execution time: 0.2942
INFO - 2023-05-25 07:13:48 --> Config Class Initialized
INFO - 2023-05-25 07:13:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:13:48 --> Config Class Initialized
INFO - 2023-05-25 07:13:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:13:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:48 --> URI Class Initialized
INFO - 2023-05-25 07:13:48 --> Config Class Initialized
INFO - 2023-05-25 07:13:48 --> URI Class Initialized
INFO - 2023-05-25 07:13:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:13:48 --> Config Class Initialized
INFO - 2023-05-25 07:13:48 --> Router Class Initialized
INFO - 2023-05-25 07:13:48 --> Router Class Initialized
INFO - 2023-05-25 07:13:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:13:48 --> Output Class Initialized
INFO - 2023-05-25 07:13:48 --> Output Class Initialized
DEBUG - 2023-05-25 07:13:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:48 --> Security Class Initialized
INFO - 2023-05-25 07:13:48 --> Security Class Initialized
INFO - 2023-05-25 07:13:48 --> URI Class Initialized
DEBUG - 2023-05-25 07:13:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:48 --> Utf8 Class Initialized
DEBUG - 2023-05-25 07:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:48 --> Input Class Initialized
INFO - 2023-05-25 07:13:48 --> Input Class Initialized
INFO - 2023-05-25 07:13:48 --> URI Class Initialized
INFO - 2023-05-25 07:13:48 --> Language Class Initialized
INFO - 2023-05-25 07:13:48 --> Language Class Initialized
INFO - 2023-05-25 07:13:48 --> Router Class Initialized
INFO - 2023-05-25 07:13:48 --> Router Class Initialized
INFO - 2023-05-25 07:13:48 --> Output Class Initialized
INFO - 2023-05-25 07:13:48 --> Loader Class Initialized
INFO - 2023-05-25 07:13:48 --> Output Class Initialized
INFO - 2023-05-25 07:13:48 --> Loader Class Initialized
INFO - 2023-05-25 07:13:48 --> Security Class Initialized
INFO - 2023-05-25 07:13:48 --> Security Class Initialized
INFO - 2023-05-25 07:13:48 --> Controller Class Initialized
INFO - 2023-05-25 07:13:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:48 --> Input Class Initialized
DEBUG - 2023-05-25 07:13:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:13:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:49 --> Language Class Initialized
DEBUG - 2023-05-25 07:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:49 --> Input Class Initialized
INFO - 2023-05-25 07:13:49 --> Language Class Initialized
INFO - 2023-05-25 07:13:49 --> Loader Class Initialized
INFO - 2023-05-25 07:13:49 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:49 --> Loader Class Initialized
INFO - 2023-05-25 07:13:49 --> Controller Class Initialized
INFO - 2023-05-25 07:13:49 --> Database Driver Class Initialized
DEBUG - 2023-05-25 07:13:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:49 --> Controller Class Initialized
INFO - 2023-05-25 07:13:49 --> Model "Cluster_model" initialized
DEBUG - 2023-05-25 07:13:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:49 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:49 --> Model "Login_model" initialized
INFO - 2023-05-25 07:13:49 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:49 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:49 --> Total execution time: 0.3135
INFO - 2023-05-25 07:13:49 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:49 --> Final output sent to browser
INFO - 2023-05-25 07:13:49 --> Model "Cluster_model" initialized
DEBUG - 2023-05-25 07:13:49 --> Total execution time: 0.3510
INFO - 2023-05-25 07:13:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:49 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:49 --> Total execution time: 0.3431
INFO - 2023-05-25 07:13:49 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:49 --> Total execution time: 0.3470
INFO - 2023-05-25 07:13:50 --> Config Class Initialized
INFO - 2023-05-25 07:13:50 --> Config Class Initialized
INFO - 2023-05-25 07:13:50 --> Hooks Class Initialized
INFO - 2023-05-25 07:13:50 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:50 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:13:50 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:50 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:50 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:50 --> URI Class Initialized
INFO - 2023-05-25 07:13:50 --> URI Class Initialized
INFO - 2023-05-25 07:13:50 --> Router Class Initialized
INFO - 2023-05-25 07:13:50 --> Router Class Initialized
INFO - 2023-05-25 07:13:50 --> Output Class Initialized
INFO - 2023-05-25 07:13:50 --> Output Class Initialized
INFO - 2023-05-25 07:13:50 --> Security Class Initialized
INFO - 2023-05-25 07:13:50 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:50 --> Input Class Initialized
INFO - 2023-05-25 07:13:50 --> Input Class Initialized
INFO - 2023-05-25 07:13:50 --> Language Class Initialized
INFO - 2023-05-25 07:13:50 --> Language Class Initialized
INFO - 2023-05-25 07:13:50 --> Loader Class Initialized
INFO - 2023-05-25 07:13:50 --> Loader Class Initialized
INFO - 2023-05-25 07:13:50 --> Controller Class Initialized
INFO - 2023-05-25 07:13:50 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:13:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:50 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:50 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:51 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:51 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:51 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:51 --> Total execution time: 0.4198
INFO - 2023-05-25 07:13:51 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:51 --> Total execution time: 0.4460
INFO - 2023-05-25 07:13:51 --> Config Class Initialized
INFO - 2023-05-25 07:13:51 --> Hooks Class Initialized
INFO - 2023-05-25 07:13:51 --> Config Class Initialized
INFO - 2023-05-25 07:13:51 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:51 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:51 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:51 --> URI Class Initialized
DEBUG - 2023-05-25 07:13:51 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:51 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:51 --> Router Class Initialized
INFO - 2023-05-25 07:13:51 --> URI Class Initialized
INFO - 2023-05-25 07:13:51 --> Output Class Initialized
INFO - 2023-05-25 07:13:51 --> Router Class Initialized
INFO - 2023-05-25 07:13:51 --> Security Class Initialized
INFO - 2023-05-25 07:13:51 --> Output Class Initialized
DEBUG - 2023-05-25 07:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:51 --> Input Class Initialized
INFO - 2023-05-25 07:13:51 --> Language Class Initialized
INFO - 2023-05-25 07:13:51 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:51 --> Input Class Initialized
INFO - 2023-05-25 07:13:51 --> Language Class Initialized
INFO - 2023-05-25 07:13:51 --> Loader Class Initialized
INFO - 2023-05-25 07:13:51 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:51 --> Loader Class Initialized
INFO - 2023-05-25 07:13:51 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:51 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:51 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:51 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:51 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:51 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:51 --> Total execution time: 0.3321
INFO - 2023-05-25 07:13:51 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:51 --> Total execution time: 0.4927
INFO - 2023-05-25 07:13:54 --> Config Class Initialized
INFO - 2023-05-25 07:13:54 --> Hooks Class Initialized
INFO - 2023-05-25 07:13:54 --> Config Class Initialized
INFO - 2023-05-25 07:13:54 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:54 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:54 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:54 --> URI Class Initialized
DEBUG - 2023-05-25 07:13:54 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:54 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:54 --> Router Class Initialized
INFO - 2023-05-25 07:13:54 --> URI Class Initialized
INFO - 2023-05-25 07:13:54 --> Output Class Initialized
INFO - 2023-05-25 07:13:54 --> Router Class Initialized
INFO - 2023-05-25 07:13:54 --> Security Class Initialized
INFO - 2023-05-25 07:13:54 --> Output Class Initialized
DEBUG - 2023-05-25 07:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:54 --> Input Class Initialized
INFO - 2023-05-25 07:13:54 --> Language Class Initialized
INFO - 2023-05-25 07:13:54 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:54 --> Input Class Initialized
INFO - 2023-05-25 07:13:54 --> Language Class Initialized
INFO - 2023-05-25 07:13:54 --> Loader Class Initialized
INFO - 2023-05-25 07:13:54 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:54 --> Loader Class Initialized
INFO - 2023-05-25 07:13:54 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:54 --> Final output sent to browser
INFO - 2023-05-25 07:13:54 --> Database Driver Class Initialized
DEBUG - 2023-05-25 07:13:54 --> Total execution time: 0.1826
INFO - 2023-05-25 07:13:54 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:54 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:54 --> Total execution time: 0.2265
INFO - 2023-05-25 07:13:54 --> Config Class Initialized
INFO - 2023-05-25 07:13:54 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:54 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:54 --> Config Class Initialized
INFO - 2023-05-25 07:13:54 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:54 --> Hooks Class Initialized
INFO - 2023-05-25 07:13:54 --> URI Class Initialized
DEBUG - 2023-05-25 07:13:54 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:54 --> Router Class Initialized
INFO - 2023-05-25 07:13:54 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:54 --> URI Class Initialized
INFO - 2023-05-25 07:13:54 --> Output Class Initialized
INFO - 2023-05-25 07:13:54 --> Security Class Initialized
INFO - 2023-05-25 07:13:54 --> Router Class Initialized
DEBUG - 2023-05-25 07:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:54 --> Output Class Initialized
INFO - 2023-05-25 07:13:54 --> Input Class Initialized
INFO - 2023-05-25 07:13:54 --> Language Class Initialized
INFO - 2023-05-25 07:13:54 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:54 --> Input Class Initialized
INFO - 2023-05-25 07:13:54 --> Language Class Initialized
INFO - 2023-05-25 07:13:54 --> Loader Class Initialized
INFO - 2023-05-25 07:13:54 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:54 --> Loader Class Initialized
INFO - 2023-05-25 07:13:54 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:54 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:54 --> Model "Login_model" initialized
INFO - 2023-05-25 07:13:54 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:54 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:54 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:54 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:54 --> Final output sent to browser
INFO - 2023-05-25 07:13:54 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:54 --> Total execution time: 0.2713
DEBUG - 2023-05-25 07:13:54 --> Total execution time: 0.2384
INFO - 2023-05-25 07:13:57 --> Config Class Initialized
INFO - 2023-05-25 07:13:57 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:57 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:57 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:57 --> URI Class Initialized
INFO - 2023-05-25 07:13:57 --> Router Class Initialized
INFO - 2023-05-25 07:13:57 --> Output Class Initialized
INFO - 2023-05-25 07:13:57 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:57 --> Input Class Initialized
INFO - 2023-05-25 07:13:57 --> Language Class Initialized
INFO - 2023-05-25 07:13:57 --> Loader Class Initialized
INFO - 2023-05-25 07:13:57 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:57 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:58 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:58 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:58 --> Total execution time: 0.4067
INFO - 2023-05-25 07:13:58 --> Config Class Initialized
INFO - 2023-05-25 07:13:58 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:13:58 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:13:58 --> Utf8 Class Initialized
INFO - 2023-05-25 07:13:58 --> URI Class Initialized
INFO - 2023-05-25 07:13:58 --> Router Class Initialized
INFO - 2023-05-25 07:13:58 --> Output Class Initialized
INFO - 2023-05-25 07:13:58 --> Security Class Initialized
DEBUG - 2023-05-25 07:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:13:58 --> Input Class Initialized
INFO - 2023-05-25 07:13:58 --> Language Class Initialized
INFO - 2023-05-25 07:13:58 --> Loader Class Initialized
INFO - 2023-05-25 07:13:58 --> Controller Class Initialized
DEBUG - 2023-05-25 07:13:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:13:58 --> Database Driver Class Initialized
INFO - 2023-05-25 07:13:58 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:13:58 --> Final output sent to browser
DEBUG - 2023-05-25 07:13:58 --> Total execution time: 0.2188
INFO - 2023-05-25 07:14:01 --> Config Class Initialized
INFO - 2023-05-25 07:14:01 --> Config Class Initialized
INFO - 2023-05-25 07:14:01 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:01 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:01 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:14:01 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:01 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:01 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:01 --> URI Class Initialized
INFO - 2023-05-25 07:14:01 --> URI Class Initialized
INFO - 2023-05-25 07:14:01 --> Router Class Initialized
INFO - 2023-05-25 07:14:01 --> Router Class Initialized
INFO - 2023-05-25 07:14:01 --> Output Class Initialized
INFO - 2023-05-25 07:14:01 --> Output Class Initialized
INFO - 2023-05-25 07:14:01 --> Security Class Initialized
INFO - 2023-05-25 07:14:01 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:01 --> Input Class Initialized
INFO - 2023-05-25 07:14:01 --> Input Class Initialized
INFO - 2023-05-25 07:14:01 --> Language Class Initialized
INFO - 2023-05-25 07:14:01 --> Language Class Initialized
INFO - 2023-05-25 07:14:01 --> Loader Class Initialized
INFO - 2023-05-25 07:14:01 --> Loader Class Initialized
INFO - 2023-05-25 07:14:01 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:01 --> Final output sent to browser
INFO - 2023-05-25 07:14:01 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:01 --> Total execution time: 0.1146
DEBUG - 2023-05-25 07:14:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:01 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:01 --> Config Class Initialized
INFO - 2023-05-25 07:14:01 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:01 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:01 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:01 --> Total execution time: 0.1859
DEBUG - 2023-05-25 07:14:01 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:01 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:01 --> URI Class Initialized
INFO - 2023-05-25 07:14:01 --> Router Class Initialized
INFO - 2023-05-25 07:14:01 --> Config Class Initialized
INFO - 2023-05-25 07:14:01 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:01 --> Output Class Initialized
INFO - 2023-05-25 07:14:01 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:01 --> Input Class Initialized
DEBUG - 2023-05-25 07:14:01 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:01 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:01 --> Language Class Initialized
INFO - 2023-05-25 07:14:01 --> URI Class Initialized
INFO - 2023-05-25 07:14:01 --> Loader Class Initialized
INFO - 2023-05-25 07:14:01 --> Router Class Initialized
INFO - 2023-05-25 07:14:01 --> Controller Class Initialized
INFO - 2023-05-25 07:14:01 --> Output Class Initialized
DEBUG - 2023-05-25 07:14:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:01 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:01 --> Input Class Initialized
INFO - 2023-05-25 07:14:01 --> Language Class Initialized
INFO - 2023-05-25 07:14:01 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:01 --> Loader Class Initialized
INFO - 2023-05-25 07:14:01 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:01 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:01 --> Model "Login_model" initialized
INFO - 2023-05-25 07:14:01 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:01 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:01 --> Total execution time: 0.2308
INFO - 2023-05-25 07:14:01 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:02 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:02 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:02 --> Total execution time: 0.3435
INFO - 2023-05-25 07:14:04 --> Config Class Initialized
INFO - 2023-05-25 07:14:04 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:04 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:04 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:04 --> URI Class Initialized
INFO - 2023-05-25 07:14:04 --> Router Class Initialized
INFO - 2023-05-25 07:14:04 --> Output Class Initialized
INFO - 2023-05-25 07:14:04 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:04 --> Input Class Initialized
INFO - 2023-05-25 07:14:04 --> Language Class Initialized
INFO - 2023-05-25 07:14:04 --> Loader Class Initialized
INFO - 2023-05-25 07:14:04 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:04 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:04 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:04 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:05 --> Total execution time: 0.1997
INFO - 2023-05-25 07:14:05 --> Config Class Initialized
INFO - 2023-05-25 07:14:05 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:05 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:05 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:05 --> URI Class Initialized
INFO - 2023-05-25 07:14:05 --> Router Class Initialized
INFO - 2023-05-25 07:14:05 --> Output Class Initialized
INFO - 2023-05-25 07:14:05 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:05 --> Input Class Initialized
INFO - 2023-05-25 07:14:05 --> Language Class Initialized
INFO - 2023-05-25 07:14:05 --> Loader Class Initialized
INFO - 2023-05-25 07:14:05 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:05 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:05 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:05 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:05 --> Total execution time: 0.2278
INFO - 2023-05-25 07:14:06 --> Config Class Initialized
INFO - 2023-05-25 07:14:06 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:06 --> Config Class Initialized
INFO - 2023-05-25 07:14:06 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:06 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:06 --> Utf8 Class Initialized
DEBUG - 2023-05-25 07:14:06 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:06 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:06 --> URI Class Initialized
INFO - 2023-05-25 07:14:06 --> URI Class Initialized
INFO - 2023-05-25 07:14:06 --> Router Class Initialized
INFO - 2023-05-25 07:14:06 --> Router Class Initialized
INFO - 2023-05-25 07:14:06 --> Output Class Initialized
INFO - 2023-05-25 07:14:06 --> Output Class Initialized
INFO - 2023-05-25 07:14:06 --> Security Class Initialized
INFO - 2023-05-25 07:14:06 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:06 --> Input Class Initialized
INFO - 2023-05-25 07:14:06 --> Language Class Initialized
DEBUG - 2023-05-25 07:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:06 --> Input Class Initialized
INFO - 2023-05-25 07:14:06 --> Language Class Initialized
INFO - 2023-05-25 07:14:06 --> Loader Class Initialized
INFO - 2023-05-25 07:14:06 --> Loader Class Initialized
INFO - 2023-05-25 07:14:06 --> Controller Class Initialized
INFO - 2023-05-25 07:14:06 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:14:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:06 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:06 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:06 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:06 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:06 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:06 --> Total execution time: 0.2641
INFO - 2023-05-25 07:14:06 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:06 --> Total execution time: 0.2901
INFO - 2023-05-25 07:14:06 --> Config Class Initialized
INFO - 2023-05-25 07:14:06 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:06 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:06 --> Config Class Initialized
INFO - 2023-05-25 07:14:06 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:06 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:06 --> URI Class Initialized
INFO - 2023-05-25 07:14:06 --> Router Class Initialized
DEBUG - 2023-05-25 07:14:06 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:06 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:06 --> URI Class Initialized
INFO - 2023-05-25 07:14:06 --> Output Class Initialized
INFO - 2023-05-25 07:14:06 --> Security Class Initialized
INFO - 2023-05-25 07:14:06 --> Router Class Initialized
DEBUG - 2023-05-25 07:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:06 --> Input Class Initialized
INFO - 2023-05-25 07:14:06 --> Language Class Initialized
INFO - 2023-05-25 07:14:06 --> Output Class Initialized
INFO - 2023-05-25 07:14:06 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:06 --> Input Class Initialized
INFO - 2023-05-25 07:14:06 --> Language Class Initialized
INFO - 2023-05-25 07:14:06 --> Loader Class Initialized
INFO - 2023-05-25 07:14:06 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:06 --> Loader Class Initialized
INFO - 2023-05-25 07:14:06 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:06 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:06 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:06 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:06 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:06 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:06 --> Total execution time: 0.3088
INFO - 2023-05-25 07:14:06 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:06 --> Total execution time: 0.3478
INFO - 2023-05-25 07:14:08 --> Config Class Initialized
INFO - 2023-05-25 07:14:08 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:08 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:08 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:08 --> URI Class Initialized
INFO - 2023-05-25 07:14:08 --> Router Class Initialized
INFO - 2023-05-25 07:14:08 --> Output Class Initialized
INFO - 2023-05-25 07:14:08 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:08 --> Input Class Initialized
INFO - 2023-05-25 07:14:08 --> Language Class Initialized
INFO - 2023-05-25 07:14:08 --> Loader Class Initialized
INFO - 2023-05-25 07:14:08 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:08 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:08 --> Model "Login_model" initialized
INFO - 2023-05-25 07:14:08 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:08 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:08 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:08 --> Total execution time: 0.2737
INFO - 2023-05-25 07:14:08 --> Config Class Initialized
INFO - 2023-05-25 07:14:08 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:08 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:08 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:08 --> URI Class Initialized
INFO - 2023-05-25 07:14:08 --> Router Class Initialized
INFO - 2023-05-25 07:14:08 --> Output Class Initialized
INFO - 2023-05-25 07:14:08 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:08 --> Input Class Initialized
INFO - 2023-05-25 07:14:08 --> Language Class Initialized
INFO - 2023-05-25 07:14:08 --> Loader Class Initialized
INFO - 2023-05-25 07:14:08 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:08 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:08 --> Model "Login_model" initialized
INFO - 2023-05-25 07:14:08 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:08 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:08 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:08 --> Total execution time: 0.3108
INFO - 2023-05-25 07:14:08 --> Config Class Initialized
INFO - 2023-05-25 07:14:08 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:08 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:08 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:08 --> URI Class Initialized
INFO - 2023-05-25 07:14:08 --> Router Class Initialized
INFO - 2023-05-25 07:14:08 --> Output Class Initialized
INFO - 2023-05-25 07:14:08 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:08 --> Input Class Initialized
INFO - 2023-05-25 07:14:09 --> Language Class Initialized
INFO - 2023-05-25 07:14:09 --> Loader Class Initialized
INFO - 2023-05-25 07:14:09 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:09 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:09 --> Total execution time: 0.1417
INFO - 2023-05-25 07:14:09 --> Config Class Initialized
INFO - 2023-05-25 07:14:09 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:09 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:09 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:09 --> URI Class Initialized
INFO - 2023-05-25 07:14:09 --> Router Class Initialized
INFO - 2023-05-25 07:14:09 --> Output Class Initialized
INFO - 2023-05-25 07:14:09 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:09 --> Input Class Initialized
INFO - 2023-05-25 07:14:09 --> Language Class Initialized
INFO - 2023-05-25 07:14:09 --> Loader Class Initialized
INFO - 2023-05-25 07:14:09 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:09 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:09 --> Model "Login_model" initialized
INFO - 2023-05-25 07:14:09 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:09 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:09 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:09 --> Total execution time: 0.2894
INFO - 2023-05-25 07:14:30 --> Config Class Initialized
INFO - 2023-05-25 07:14:30 --> Config Class Initialized
INFO - 2023-05-25 07:14:30 --> Config Class Initialized
INFO - 2023-05-25 07:14:30 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:30 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:30 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:31 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:14:31 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:14:31 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:31 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:31 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:31 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:31 --> URI Class Initialized
INFO - 2023-05-25 07:14:31 --> URI Class Initialized
INFO - 2023-05-25 07:14:31 --> URI Class Initialized
INFO - 2023-05-25 07:14:31 --> Router Class Initialized
INFO - 2023-05-25 07:14:31 --> Router Class Initialized
INFO - 2023-05-25 07:14:31 --> Router Class Initialized
INFO - 2023-05-25 07:14:31 --> Output Class Initialized
INFO - 2023-05-25 07:14:31 --> Output Class Initialized
INFO - 2023-05-25 07:14:31 --> Output Class Initialized
INFO - 2023-05-25 07:14:31 --> Security Class Initialized
INFO - 2023-05-25 07:14:31 --> Security Class Initialized
INFO - 2023-05-25 07:14:31 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:31 --> Input Class Initialized
INFO - 2023-05-25 07:14:31 --> Input Class Initialized
INFO - 2023-05-25 07:14:31 --> Input Class Initialized
INFO - 2023-05-25 07:14:31 --> Language Class Initialized
INFO - 2023-05-25 07:14:31 --> Language Class Initialized
INFO - 2023-05-25 07:14:31 --> Language Class Initialized
INFO - 2023-05-25 07:14:31 --> Loader Class Initialized
INFO - 2023-05-25 07:14:31 --> Loader Class Initialized
INFO - 2023-05-25 07:14:31 --> Loader Class Initialized
INFO - 2023-05-25 07:14:31 --> Controller Class Initialized
INFO - 2023-05-25 07:14:31 --> Controller Class Initialized
INFO - 2023-05-25 07:14:31 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:14:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:14:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:31 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:31 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:31 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:31 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:31 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:31 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:31 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:31 --> Total execution time: 0.2075
INFO - 2023-05-25 07:14:31 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:31 --> Total execution time: 0.2145
INFO - 2023-05-25 07:14:31 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:31 --> Total execution time: 0.2310
INFO - 2023-05-25 07:14:31 --> Config Class Initialized
INFO - 2023-05-25 07:14:31 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:31 --> Config Class Initialized
INFO - 2023-05-25 07:14:31 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:31 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:31 --> Config Class Initialized
DEBUG - 2023-05-25 07:14:31 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:31 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:31 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:31 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:31 --> URI Class Initialized
INFO - 2023-05-25 07:14:31 --> URI Class Initialized
INFO - 2023-05-25 07:14:31 --> Router Class Initialized
INFO - 2023-05-25 07:14:31 --> Router Class Initialized
DEBUG - 2023-05-25 07:14:31 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:31 --> Output Class Initialized
INFO - 2023-05-25 07:14:31 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:31 --> Output Class Initialized
INFO - 2023-05-25 07:14:31 --> Security Class Initialized
INFO - 2023-05-25 07:14:31 --> URI Class Initialized
INFO - 2023-05-25 07:14:31 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:31 --> Input Class Initialized
INFO - 2023-05-25 07:14:31 --> Input Class Initialized
INFO - 2023-05-25 07:14:31 --> Language Class Initialized
INFO - 2023-05-25 07:14:31 --> Router Class Initialized
INFO - 2023-05-25 07:14:31 --> Language Class Initialized
INFO - 2023-05-25 07:14:31 --> Output Class Initialized
INFO - 2023-05-25 07:14:31 --> Loader Class Initialized
INFO - 2023-05-25 07:14:31 --> Loader Class Initialized
INFO - 2023-05-25 07:14:31 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:31 --> Controller Class Initialized
INFO - 2023-05-25 07:14:31 --> Controller Class Initialized
INFO - 2023-05-25 07:14:31 --> Input Class Initialized
DEBUG - 2023-05-25 07:14:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:14:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:31 --> Language Class Initialized
INFO - 2023-05-25 07:14:31 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:31 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:31 --> Loader Class Initialized
INFO - 2023-05-25 07:14:31 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:31 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:31 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:31 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:31 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:31 --> Final output sent to browser
INFO - 2023-05-25 07:14:31 --> Model "Login_model" initialized
INFO - 2023-05-25 07:14:31 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:31 --> Total execution time: 0.2907
DEBUG - 2023-05-25 07:14:31 --> Total execution time: 0.2651
INFO - 2023-05-25 07:14:31 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:31 --> Total execution time: 0.3164
INFO - 2023-05-25 07:14:31 --> Config Class Initialized
INFO - 2023-05-25 07:14:31 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:31 --> Config Class Initialized
INFO - 2023-05-25 07:14:31 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:31 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:31 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:31 --> URI Class Initialized
DEBUG - 2023-05-25 07:14:31 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:31 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:31 --> Router Class Initialized
INFO - 2023-05-25 07:14:31 --> URI Class Initialized
INFO - 2023-05-25 07:14:31 --> Output Class Initialized
INFO - 2023-05-25 07:14:31 --> Router Class Initialized
INFO - 2023-05-25 07:14:31 --> Security Class Initialized
INFO - 2023-05-25 07:14:31 --> Output Class Initialized
DEBUG - 2023-05-25 07:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:31 --> Input Class Initialized
INFO - 2023-05-25 07:14:31 --> Security Class Initialized
INFO - 2023-05-25 07:14:31 --> Language Class Initialized
DEBUG - 2023-05-25 07:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:31 --> Input Class Initialized
INFO - 2023-05-25 07:14:31 --> Language Class Initialized
INFO - 2023-05-25 07:14:31 --> Loader Class Initialized
INFO - 2023-05-25 07:14:31 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:31 --> Loader Class Initialized
INFO - 2023-05-25 07:14:31 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:31 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:31 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:31 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:31 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:31 --> Final output sent to browser
INFO - 2023-05-25 07:14:31 --> Model "Login_model" initialized
DEBUG - 2023-05-25 07:14:31 --> Total execution time: 0.2768
INFO - 2023-05-25 07:14:31 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:31 --> Total execution time: 0.2726
INFO - 2023-05-25 07:14:55 --> Config Class Initialized
INFO - 2023-05-25 07:14:55 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:56 --> URI Class Initialized
INFO - 2023-05-25 07:14:56 --> Router Class Initialized
INFO - 2023-05-25 07:14:56 --> Output Class Initialized
INFO - 2023-05-25 07:14:56 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:56 --> Input Class Initialized
INFO - 2023-05-25 07:14:56 --> Language Class Initialized
INFO - 2023-05-25 07:14:56 --> Loader Class Initialized
INFO - 2023-05-25 07:14:56 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:56 --> Model "Login_model" initialized
INFO - 2023-05-25 07:14:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:56 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:56 --> Total execution time: 0.2576
INFO - 2023-05-25 07:14:56 --> Config Class Initialized
INFO - 2023-05-25 07:14:56 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:56 --> URI Class Initialized
INFO - 2023-05-25 07:14:56 --> Router Class Initialized
INFO - 2023-05-25 07:14:56 --> Output Class Initialized
INFO - 2023-05-25 07:14:56 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:56 --> Input Class Initialized
INFO - 2023-05-25 07:14:56 --> Language Class Initialized
INFO - 2023-05-25 07:14:56 --> Loader Class Initialized
INFO - 2023-05-25 07:14:56 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:56 --> Model "Login_model" initialized
INFO - 2023-05-25 07:14:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:56 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:56 --> Total execution time: 0.2934
INFO - 2023-05-25 07:14:56 --> Config Class Initialized
INFO - 2023-05-25 07:14:56 --> Config Class Initialized
INFO - 2023-05-25 07:14:56 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:56 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:56 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:14:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:56 --> URI Class Initialized
INFO - 2023-05-25 07:14:56 --> Config Class Initialized
INFO - 2023-05-25 07:14:56 --> URI Class Initialized
INFO - 2023-05-25 07:14:56 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:56 --> Router Class Initialized
INFO - 2023-05-25 07:14:56 --> Router Class Initialized
INFO - 2023-05-25 07:14:56 --> Output Class Initialized
INFO - 2023-05-25 07:14:56 --> Output Class Initialized
INFO - 2023-05-25 07:14:56 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:56 --> Security Class Initialized
INFO - 2023-05-25 07:14:56 --> Utf8 Class Initialized
DEBUG - 2023-05-25 07:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:56 --> URI Class Initialized
INFO - 2023-05-25 07:14:56 --> Input Class Initialized
INFO - 2023-05-25 07:14:56 --> Input Class Initialized
INFO - 2023-05-25 07:14:56 --> Language Class Initialized
INFO - 2023-05-25 07:14:56 --> Language Class Initialized
INFO - 2023-05-25 07:14:56 --> Router Class Initialized
INFO - 2023-05-25 07:14:56 --> Loader Class Initialized
INFO - 2023-05-25 07:14:56 --> Loader Class Initialized
INFO - 2023-05-25 07:14:56 --> Output Class Initialized
INFO - 2023-05-25 07:14:56 --> Controller Class Initialized
INFO - 2023-05-25 07:14:56 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:56 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:56 --> Input Class Initialized
INFO - 2023-05-25 07:14:56 --> Language Class Initialized
INFO - 2023-05-25 07:14:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:56 --> Loader Class Initialized
INFO - 2023-05-25 07:14:56 --> Controller Class Initialized
INFO - 2023-05-25 07:14:56 --> Model "Cluster_model" initialized
DEBUG - 2023-05-25 07:14:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:56 --> Model "Login_model" initialized
INFO - 2023-05-25 07:14:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:56 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:56 --> Total execution time: 0.2965
INFO - 2023-05-25 07:14:56 --> Final output sent to browser
INFO - 2023-05-25 07:14:56 --> Model "Cluster_model" initialized
DEBUG - 2023-05-25 07:14:56 --> Total execution time: 0.3092
INFO - 2023-05-25 07:14:56 --> Config Class Initialized
INFO - 2023-05-25 07:14:56 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:56 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:56 --> Total execution time: 0.3223
INFO - 2023-05-25 07:14:56 --> Config Class Initialized
INFO - 2023-05-25 07:14:56 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:56 --> Config Class Initialized
INFO - 2023-05-25 07:14:56 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:56 --> Utf8 Class Initialized
DEBUG - 2023-05-25 07:14:56 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:14:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:57 --> URI Class Initialized
INFO - 2023-05-25 07:14:57 --> URI Class Initialized
INFO - 2023-05-25 07:14:57 --> Config Class Initialized
INFO - 2023-05-25 07:14:57 --> URI Class Initialized
INFO - 2023-05-25 07:14:57 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:57 --> Router Class Initialized
INFO - 2023-05-25 07:14:57 --> Router Class Initialized
INFO - 2023-05-25 07:14:57 --> Router Class Initialized
INFO - 2023-05-25 07:14:57 --> Output Class Initialized
INFO - 2023-05-25 07:14:57 --> Output Class Initialized
INFO - 2023-05-25 07:14:57 --> Output Class Initialized
INFO - 2023-05-25 07:14:57 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:57 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:57 --> Security Class Initialized
INFO - 2023-05-25 07:14:57 --> Security Class Initialized
INFO - 2023-05-25 07:14:57 --> Utf8 Class Initialized
DEBUG - 2023-05-25 07:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:57 --> URI Class Initialized
INFO - 2023-05-25 07:14:57 --> Input Class Initialized
INFO - 2023-05-25 07:14:57 --> Input Class Initialized
INFO - 2023-05-25 07:14:57 --> Input Class Initialized
INFO - 2023-05-25 07:14:57 --> Language Class Initialized
INFO - 2023-05-25 07:14:57 --> Language Class Initialized
INFO - 2023-05-25 07:14:57 --> Language Class Initialized
INFO - 2023-05-25 07:14:57 --> Router Class Initialized
INFO - 2023-05-25 07:14:57 --> Loader Class Initialized
INFO - 2023-05-25 07:14:57 --> Loader Class Initialized
INFO - 2023-05-25 07:14:57 --> Loader Class Initialized
INFO - 2023-05-25 07:14:57 --> Output Class Initialized
INFO - 2023-05-25 07:14:57 --> Controller Class Initialized
INFO - 2023-05-25 07:14:57 --> Controller Class Initialized
INFO - 2023-05-25 07:14:57 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:57 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:14:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:57 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:57 --> Total execution time: 0.2010
DEBUG - 2023-05-25 07:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:57 --> Input Class Initialized
INFO - 2023-05-25 07:14:57 --> Language Class Initialized
INFO - 2023-05-25 07:14:57 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:57 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:57 --> Loader Class Initialized
INFO - 2023-05-25 07:14:57 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:57 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:57 --> Controller Class Initialized
INFO - 2023-05-25 07:14:57 --> Config Class Initialized
INFO - 2023-05-25 07:14:57 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:14:57 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:57 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:57 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:57 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:57 --> Total execution time: 0.3645
INFO - 2023-05-25 07:14:57 --> URI Class Initialized
INFO - 2023-05-25 07:14:57 --> Router Class Initialized
INFO - 2023-05-25 07:14:57 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:57 --> Total execution time: 0.3409
INFO - 2023-05-25 07:14:57 --> Output Class Initialized
INFO - 2023-05-25 07:14:57 --> Security Class Initialized
INFO - 2023-05-25 07:14:57 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:57 --> Config Class Initialized
DEBUG - 2023-05-25 07:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:57 --> Input Class Initialized
INFO - 2023-05-25 07:14:57 --> Hooks Class Initialized
INFO - 2023-05-25 07:14:57 --> Language Class Initialized
INFO - 2023-05-25 07:14:57 --> Model "Login_model" initialized
INFO - 2023-05-25 07:14:57 --> Config Class Initialized
INFO - 2023-05-25 07:14:57 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:14:57 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:57 --> Final output sent to browser
INFO - 2023-05-25 07:14:57 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:57 --> Loader Class Initialized
DEBUG - 2023-05-25 07:14:57 --> Total execution time: 0.3872
INFO - 2023-05-25 07:14:57 --> URI Class Initialized
INFO - 2023-05-25 07:14:57 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:14:57 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:14:57 --> Utf8 Class Initialized
INFO - 2023-05-25 07:14:57 --> Router Class Initialized
INFO - 2023-05-25 07:14:57 --> URI Class Initialized
INFO - 2023-05-25 07:14:57 --> Output Class Initialized
INFO - 2023-05-25 07:14:57 --> Security Class Initialized
INFO - 2023-05-25 07:14:57 --> Router Class Initialized
DEBUG - 2023-05-25 07:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:57 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:57 --> Input Class Initialized
INFO - 2023-05-25 07:14:57 --> Output Class Initialized
INFO - 2023-05-25 07:14:57 --> Language Class Initialized
INFO - 2023-05-25 07:14:57 --> Security Class Initialized
DEBUG - 2023-05-25 07:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:14:57 --> Input Class Initialized
INFO - 2023-05-25 07:14:57 --> Loader Class Initialized
INFO - 2023-05-25 07:14:57 --> Language Class Initialized
INFO - 2023-05-25 07:14:57 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:57 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:57 --> Loader Class Initialized
INFO - 2023-05-25 07:14:57 --> Controller Class Initialized
DEBUG - 2023-05-25 07:14:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:14:57 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:57 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:57 --> Total execution time: 0.4055
INFO - 2023-05-25 07:14:57 --> Model "Login_model" initialized
INFO - 2023-05-25 07:14:57 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:57 --> Database Driver Class Initialized
INFO - 2023-05-25 07:14:57 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:57 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:14:57 --> Final output sent to browser
INFO - 2023-05-25 07:14:57 --> Final output sent to browser
DEBUG - 2023-05-25 07:14:57 --> Total execution time: 0.3341
DEBUG - 2023-05-25 07:14:57 --> Total execution time: 0.3758
INFO - 2023-05-25 07:15:56 --> Config Class Initialized
INFO - 2023-05-25 07:15:56 --> Config Class Initialized
INFO - 2023-05-25 07:15:56 --> Hooks Class Initialized
INFO - 2023-05-25 07:15:56 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:15:56 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:15:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:15:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:15:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:15:56 --> URI Class Initialized
INFO - 2023-05-25 07:15:56 --> URI Class Initialized
INFO - 2023-05-25 07:15:56 --> Router Class Initialized
INFO - 2023-05-25 07:15:56 --> Router Class Initialized
INFO - 2023-05-25 07:15:56 --> Output Class Initialized
INFO - 2023-05-25 07:15:56 --> Output Class Initialized
INFO - 2023-05-25 07:15:56 --> Security Class Initialized
INFO - 2023-05-25 07:15:56 --> Security Class Initialized
DEBUG - 2023-05-25 07:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:15:56 --> Input Class Initialized
INFO - 2023-05-25 07:15:56 --> Input Class Initialized
INFO - 2023-05-25 07:15:56 --> Language Class Initialized
INFO - 2023-05-25 07:15:56 --> Language Class Initialized
INFO - 2023-05-25 07:15:56 --> Loader Class Initialized
INFO - 2023-05-25 07:15:56 --> Controller Class Initialized
INFO - 2023-05-25 07:15:56 --> Loader Class Initialized
DEBUG - 2023-05-25 07:15:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:15:56 --> Controller Class Initialized
DEBUG - 2023-05-25 07:15:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:15:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:15:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:15:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:15:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:15:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:15:56 --> Final output sent to browser
INFO - 2023-05-25 07:15:56 --> Model "Login_model" initialized
DEBUG - 2023-05-25 07:15:56 --> Total execution time: 0.1939
INFO - 2023-05-25 07:15:56 --> Config Class Initialized
INFO - 2023-05-25 07:15:56 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:15:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:15:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:15:56 --> URI Class Initialized
INFO - 2023-05-25 07:15:56 --> Router Class Initialized
INFO - 2023-05-25 07:15:56 --> Output Class Initialized
INFO - 2023-05-25 07:15:56 --> Security Class Initialized
DEBUG - 2023-05-25 07:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:15:56 --> Input Class Initialized
INFO - 2023-05-25 07:15:56 --> Language Class Initialized
INFO - 2023-05-25 07:15:56 --> Loader Class Initialized
INFO - 2023-05-25 07:15:56 --> Controller Class Initialized
DEBUG - 2023-05-25 07:15:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:15:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:15:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:15:56 --> Final output sent to browser
DEBUG - 2023-05-25 07:15:57 --> Total execution time: 0.2082
INFO - 2023-05-25 07:16:05 --> Final output sent to browser
DEBUG - 2023-05-25 07:16:05 --> Total execution time: 9.2888
INFO - 2023-05-25 07:16:05 --> Config Class Initialized
INFO - 2023-05-25 07:16:05 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:16:05 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:16:05 --> Utf8 Class Initialized
INFO - 2023-05-25 07:16:05 --> URI Class Initialized
INFO - 2023-05-25 07:16:05 --> Router Class Initialized
INFO - 2023-05-25 07:16:05 --> Output Class Initialized
INFO - 2023-05-25 07:16:05 --> Security Class Initialized
DEBUG - 2023-05-25 07:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:16:05 --> Input Class Initialized
INFO - 2023-05-25 07:16:05 --> Language Class Initialized
INFO - 2023-05-25 07:16:05 --> Loader Class Initialized
INFO - 2023-05-25 07:16:06 --> Controller Class Initialized
DEBUG - 2023-05-25 07:16:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:16:06 --> Database Driver Class Initialized
INFO - 2023-05-25 07:16:06 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:16:06 --> Database Driver Class Initialized
INFO - 2023-05-25 07:16:06 --> Model "Login_model" initialized
INFO - 2023-05-25 07:16:14 --> Final output sent to browser
DEBUG - 2023-05-25 07:16:14 --> Total execution time: 8.4145
INFO - 2023-05-25 07:16:56 --> Config Class Initialized
INFO - 2023-05-25 07:16:56 --> Hooks Class Initialized
INFO - 2023-05-25 07:16:56 --> Config Class Initialized
INFO - 2023-05-25 07:16:56 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:16:56 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:16:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:16:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:16:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:16:56 --> URI Class Initialized
INFO - 2023-05-25 07:16:56 --> URI Class Initialized
INFO - 2023-05-25 07:16:56 --> Router Class Initialized
INFO - 2023-05-25 07:16:56 --> Router Class Initialized
INFO - 2023-05-25 07:16:56 --> Output Class Initialized
INFO - 2023-05-25 07:16:56 --> Output Class Initialized
INFO - 2023-05-25 07:16:56 --> Security Class Initialized
INFO - 2023-05-25 07:16:56 --> Security Class Initialized
DEBUG - 2023-05-25 07:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:16:56 --> Input Class Initialized
INFO - 2023-05-25 07:16:56 --> Input Class Initialized
INFO - 2023-05-25 07:16:56 --> Language Class Initialized
INFO - 2023-05-25 07:16:56 --> Language Class Initialized
INFO - 2023-05-25 07:16:56 --> Loader Class Initialized
INFO - 2023-05-25 07:16:56 --> Loader Class Initialized
INFO - 2023-05-25 07:16:56 --> Controller Class Initialized
DEBUG - 2023-05-25 07:16:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:16:56 --> Controller Class Initialized
DEBUG - 2023-05-25 07:16:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:16:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:16:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:16:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:16:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:16:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:16:56 --> Model "Login_model" initialized
INFO - 2023-05-25 07:16:56 --> Final output sent to browser
DEBUG - 2023-05-25 07:16:56 --> Total execution time: 0.2042
INFO - 2023-05-25 07:16:56 --> Config Class Initialized
INFO - 2023-05-25 07:16:56 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:16:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:16:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:16:56 --> URI Class Initialized
INFO - 2023-05-25 07:16:56 --> Router Class Initialized
INFO - 2023-05-25 07:16:56 --> Output Class Initialized
INFO - 2023-05-25 07:16:56 --> Security Class Initialized
DEBUG - 2023-05-25 07:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:16:56 --> Input Class Initialized
INFO - 2023-05-25 07:16:56 --> Language Class Initialized
INFO - 2023-05-25 07:16:56 --> Loader Class Initialized
INFO - 2023-05-25 07:16:56 --> Controller Class Initialized
DEBUG - 2023-05-25 07:16:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:16:57 --> Database Driver Class Initialized
INFO - 2023-05-25 07:16:57 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:16:57 --> Final output sent to browser
DEBUG - 2023-05-25 07:16:57 --> Total execution time: 0.2782
INFO - 2023-05-25 07:17:05 --> Final output sent to browser
DEBUG - 2023-05-25 07:17:05 --> Total execution time: 9.1451
INFO - 2023-05-25 07:17:05 --> Config Class Initialized
INFO - 2023-05-25 07:17:05 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:17:05 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:17:05 --> Utf8 Class Initialized
INFO - 2023-05-25 07:17:05 --> URI Class Initialized
INFO - 2023-05-25 07:17:05 --> Router Class Initialized
INFO - 2023-05-25 07:17:05 --> Output Class Initialized
INFO - 2023-05-25 07:17:05 --> Security Class Initialized
DEBUG - 2023-05-25 07:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:17:05 --> Input Class Initialized
INFO - 2023-05-25 07:17:05 --> Language Class Initialized
INFO - 2023-05-25 07:17:05 --> Loader Class Initialized
INFO - 2023-05-25 07:17:05 --> Controller Class Initialized
DEBUG - 2023-05-25 07:17:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:17:05 --> Database Driver Class Initialized
INFO - 2023-05-25 07:17:05 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:17:06 --> Database Driver Class Initialized
INFO - 2023-05-25 07:17:06 --> Model "Login_model" initialized
INFO - 2023-05-25 07:17:15 --> Final output sent to browser
DEBUG - 2023-05-25 07:17:15 --> Total execution time: 10.0747
INFO - 2023-05-25 07:17:56 --> Config Class Initialized
INFO - 2023-05-25 07:17:56 --> Config Class Initialized
INFO - 2023-05-25 07:17:56 --> Hooks Class Initialized
INFO - 2023-05-25 07:17:56 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:17:56 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:17:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:17:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:17:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:17:56 --> URI Class Initialized
INFO - 2023-05-25 07:17:56 --> URI Class Initialized
INFO - 2023-05-25 07:17:56 --> Router Class Initialized
INFO - 2023-05-25 07:17:56 --> Router Class Initialized
INFO - 2023-05-25 07:17:56 --> Output Class Initialized
INFO - 2023-05-25 07:17:56 --> Output Class Initialized
INFO - 2023-05-25 07:17:56 --> Security Class Initialized
INFO - 2023-05-25 07:17:56 --> Security Class Initialized
DEBUG - 2023-05-25 07:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:17:56 --> Input Class Initialized
INFO - 2023-05-25 07:17:56 --> Input Class Initialized
INFO - 2023-05-25 07:17:56 --> Language Class Initialized
INFO - 2023-05-25 07:17:56 --> Language Class Initialized
INFO - 2023-05-25 07:17:56 --> Loader Class Initialized
INFO - 2023-05-25 07:17:56 --> Loader Class Initialized
INFO - 2023-05-25 07:17:56 --> Controller Class Initialized
DEBUG - 2023-05-25 07:17:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:17:56 --> Controller Class Initialized
DEBUG - 2023-05-25 07:17:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:17:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:17:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:17:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:17:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:17:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:17:56 --> Model "Login_model" initialized
INFO - 2023-05-25 07:18:07 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:07 --> Total execution time: 10.5766
INFO - 2023-05-25 07:18:07 --> Config Class Initialized
INFO - 2023-05-25 07:18:07 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:18:07 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:07 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:07 --> URI Class Initialized
INFO - 2023-05-25 07:18:07 --> Router Class Initialized
INFO - 2023-05-25 07:18:07 --> Output Class Initialized
INFO - 2023-05-25 07:18:07 --> Security Class Initialized
DEBUG - 2023-05-25 07:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:18:07 --> Input Class Initialized
INFO - 2023-05-25 07:18:07 --> Language Class Initialized
INFO - 2023-05-25 07:18:07 --> Loader Class Initialized
INFO - 2023-05-25 07:18:07 --> Controller Class Initialized
DEBUG - 2023-05-25 07:18:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:07 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:07 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:18:08 --> Config Class Initialized
INFO - 2023-05-25 07:18:08 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:18:08 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:08 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:08 --> URI Class Initialized
INFO - 2023-05-25 07:18:08 --> Router Class Initialized
INFO - 2023-05-25 07:18:08 --> Output Class Initialized
INFO - 2023-05-25 07:18:08 --> Security Class Initialized
DEBUG - 2023-05-25 07:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:18:08 --> Input Class Initialized
INFO - 2023-05-25 07:18:08 --> Language Class Initialized
INFO - 2023-05-25 07:18:08 --> Loader Class Initialized
INFO - 2023-05-25 07:18:08 --> Controller Class Initialized
DEBUG - 2023-05-25 07:18:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:08 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:08 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:18:09 --> Final output sent to browser
INFO - 2023-05-25 07:18:09 --> Config Class Initialized
INFO - 2023-05-25 07:18:09 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:18:09 --> Total execution time: 0.3217
DEBUG - 2023-05-25 07:18:09 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:09 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:09 --> URI Class Initialized
INFO - 2023-05-25 07:18:09 --> Config Class Initialized
INFO - 2023-05-25 07:18:09 --> Hooks Class Initialized
INFO - 2023-05-25 07:18:09 --> Router Class Initialized
DEBUG - 2023-05-25 07:18:09 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:09 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:09 --> Output Class Initialized
INFO - 2023-05-25 07:18:09 --> Security Class Initialized
INFO - 2023-05-25 07:18:09 --> URI Class Initialized
DEBUG - 2023-05-25 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:18:09 --> Input Class Initialized
INFO - 2023-05-25 07:18:09 --> Router Class Initialized
INFO - 2023-05-25 07:18:09 --> Language Class Initialized
INFO - 2023-05-25 07:18:09 --> Output Class Initialized
INFO - 2023-05-25 07:18:09 --> Security Class Initialized
DEBUG - 2023-05-25 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:18:09 --> Input Class Initialized
INFO - 2023-05-25 07:18:09 --> Language Class Initialized
INFO - 2023-05-25 07:18:09 --> Loader Class Initialized
INFO - 2023-05-25 07:18:09 --> Controller Class Initialized
DEBUG - 2023-05-25 07:18:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:09 --> Loader Class Initialized
INFO - 2023-05-25 07:18:09 --> Controller Class Initialized
DEBUG - 2023-05-25 07:18:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:09 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:09 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:09 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:18:09 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:18:09 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:09 --> Total execution time: 0.3230
INFO - 2023-05-25 07:18:09 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:09 --> Total execution time: 0.4148
INFO - 2023-05-25 07:18:09 --> Config Class Initialized
INFO - 2023-05-25 07:18:09 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:18:09 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:09 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:09 --> URI Class Initialized
INFO - 2023-05-25 07:18:09 --> Router Class Initialized
INFO - 2023-05-25 07:18:09 --> Output Class Initialized
INFO - 2023-05-25 07:18:09 --> Security Class Initialized
DEBUG - 2023-05-25 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:18:09 --> Input Class Initialized
INFO - 2023-05-25 07:18:09 --> Language Class Initialized
INFO - 2023-05-25 07:18:09 --> Loader Class Initialized
INFO - 2023-05-25 07:18:09 --> Controller Class Initialized
DEBUG - 2023-05-25 07:18:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:09 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:09 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:18:09 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:09 --> Total execution time: 0.2990
INFO - 2023-05-25 07:18:13 --> Config Class Initialized
INFO - 2023-05-25 07:18:13 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:18:13 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:13 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:13 --> URI Class Initialized
INFO - 2023-05-25 07:18:13 --> Router Class Initialized
INFO - 2023-05-25 07:18:13 --> Output Class Initialized
INFO - 2023-05-25 07:18:13 --> Security Class Initialized
DEBUG - 2023-05-25 07:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:18:13 --> Input Class Initialized
INFO - 2023-05-25 07:18:13 --> Language Class Initialized
INFO - 2023-05-25 07:18:13 --> Loader Class Initialized
INFO - 2023-05-25 07:18:13 --> Controller Class Initialized
DEBUG - 2023-05-25 07:18:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:13 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:13 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:18:14 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:14 --> Total execution time: 0.2011
INFO - 2023-05-25 07:18:14 --> Config Class Initialized
INFO - 2023-05-25 07:18:14 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:18:14 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:14 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:14 --> URI Class Initialized
INFO - 2023-05-25 07:18:14 --> Router Class Initialized
INFO - 2023-05-25 07:18:14 --> Output Class Initialized
INFO - 2023-05-25 07:18:14 --> Security Class Initialized
DEBUG - 2023-05-25 07:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:18:14 --> Input Class Initialized
INFO - 2023-05-25 07:18:14 --> Language Class Initialized
INFO - 2023-05-25 07:18:14 --> Loader Class Initialized
INFO - 2023-05-25 07:18:14 --> Controller Class Initialized
DEBUG - 2023-05-25 07:18:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:14 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:14 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:18:14 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:14 --> Total execution time: 0.2244
INFO - 2023-05-25 07:18:18 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:18 --> Total execution time: 11.2320
INFO - 2023-05-25 07:18:29 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:29 --> Total execution time: 32.6808
INFO - 2023-05-25 07:18:29 --> Config Class Initialized
INFO - 2023-05-25 07:18:29 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:18:29 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:29 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:29 --> URI Class Initialized
INFO - 2023-05-25 07:18:29 --> Router Class Initialized
INFO - 2023-05-25 07:18:29 --> Output Class Initialized
INFO - 2023-05-25 07:18:29 --> Security Class Initialized
DEBUG - 2023-05-25 07:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:18:29 --> Input Class Initialized
INFO - 2023-05-25 07:18:29 --> Language Class Initialized
INFO - 2023-05-25 07:18:29 --> Loader Class Initialized
INFO - 2023-05-25 07:18:29 --> Controller Class Initialized
DEBUG - 2023-05-25 07:18:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:29 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:18:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:29 --> Model "Login_model" initialized
INFO - 2023-05-25 07:18:39 --> Config Class Initialized
INFO - 2023-05-25 07:18:39 --> Config Class Initialized
INFO - 2023-05-25 07:18:39 --> Hooks Class Initialized
INFO - 2023-05-25 07:18:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:18:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:18:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:39 --> URI Class Initialized
INFO - 2023-05-25 07:18:39 --> URI Class Initialized
INFO - 2023-05-25 07:18:39 --> Config Class Initialized
INFO - 2023-05-25 07:18:39 --> Hooks Class Initialized
INFO - 2023-05-25 07:18:39 --> Router Class Initialized
INFO - 2023-05-25 07:18:39 --> Router Class Initialized
INFO - 2023-05-25 07:18:39 --> Output Class Initialized
INFO - 2023-05-25 07:18:39 --> Output Class Initialized
INFO - 2023-05-25 07:18:39 --> Security Class Initialized
INFO - 2023-05-25 07:18:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:18:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:39 --> Input Class Initialized
INFO - 2023-05-25 07:18:39 --> Input Class Initialized
INFO - 2023-05-25 07:18:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:39 --> Language Class Initialized
INFO - 2023-05-25 07:18:39 --> Language Class Initialized
INFO - 2023-05-25 07:18:39 --> URI Class Initialized
INFO - 2023-05-25 07:18:39 --> Loader Class Initialized
INFO - 2023-05-25 07:18:39 --> Router Class Initialized
INFO - 2023-05-25 07:18:39 --> Loader Class Initialized
INFO - 2023-05-25 07:18:39 --> Controller Class Initialized
INFO - 2023-05-25 07:18:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:18:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:18:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:39 --> Output Class Initialized
INFO - 2023-05-25 07:18:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:18:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:39 --> Input Class Initialized
INFO - 2023-05-25 07:18:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:39 --> Language Class Initialized
INFO - 2023-05-25 07:18:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:18:40 --> Loader Class Initialized
INFO - 2023-05-25 07:18:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:40 --> Controller Class Initialized
INFO - 2023-05-25 07:18:40 --> Final output sent to browser
INFO - 2023-05-25 07:18:40 --> Model "Login_model" initialized
DEBUG - 2023-05-25 07:18:40 --> Total execution time: 10.7717
DEBUG - 2023-05-25 07:18:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:40 --> Total execution time: 0.2845
INFO - 2023-05-25 07:18:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:40 --> Config Class Initialized
INFO - 2023-05-25 07:18:40 --> Config Class Initialized
INFO - 2023-05-25 07:18:40 --> Hooks Class Initialized
INFO - 2023-05-25 07:18:40 --> Hooks Class Initialized
INFO - 2023-05-25 07:18:40 --> Model "Cluster_model" initialized
DEBUG - 2023-05-25 07:18:40 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:18:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:40 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:40 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:40 --> URI Class Initialized
INFO - 2023-05-25 07:18:40 --> URI Class Initialized
INFO - 2023-05-25 07:18:40 --> Router Class Initialized
INFO - 2023-05-25 07:18:40 --> Router Class Initialized
INFO - 2023-05-25 07:18:40 --> Output Class Initialized
INFO - 2023-05-25 07:18:40 --> Output Class Initialized
INFO - 2023-05-25 07:18:40 --> Security Class Initialized
INFO - 2023-05-25 07:18:40 --> Security Class Initialized
DEBUG - 2023-05-25 07:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:18:40 --> Input Class Initialized
INFO - 2023-05-25 07:18:40 --> Input Class Initialized
INFO - 2023-05-25 07:18:40 --> Language Class Initialized
INFO - 2023-05-25 07:18:40 --> Language Class Initialized
INFO - 2023-05-25 07:18:40 --> Loader Class Initialized
INFO - 2023-05-25 07:18:40 --> Loader Class Initialized
INFO - 2023-05-25 07:18:40 --> Controller Class Initialized
INFO - 2023-05-25 07:18:40 --> Controller Class Initialized
DEBUG - 2023-05-25 07:18:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:18:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:18:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:40 --> Model "Login_model" initialized
INFO - 2023-05-25 07:18:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:40 --> Total execution time: 0.2570
INFO - 2023-05-25 07:18:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:40 --> Total execution time: 1.1703
INFO - 2023-05-25 07:18:40 --> Config Class Initialized
INFO - 2023-05-25 07:18:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:18:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:41 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:41 --> URI Class Initialized
INFO - 2023-05-25 07:18:41 --> Router Class Initialized
INFO - 2023-05-25 07:18:41 --> Output Class Initialized
INFO - 2023-05-25 07:18:41 --> Security Class Initialized
DEBUG - 2023-05-25 07:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:18:41 --> Input Class Initialized
INFO - 2023-05-25 07:18:41 --> Language Class Initialized
INFO - 2023-05-25 07:18:41 --> Loader Class Initialized
INFO - 2023-05-25 07:18:41 --> Controller Class Initialized
DEBUG - 2023-05-25 07:18:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:18:41 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:41 --> Total execution time: 1.8920
INFO - 2023-05-25 07:18:41 --> Config Class Initialized
INFO - 2023-05-25 07:18:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:18:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:41 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:41 --> URI Class Initialized
INFO - 2023-05-25 07:18:41 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:41 --> Total execution time: 1.7068
INFO - 2023-05-25 07:18:41 --> Router Class Initialized
INFO - 2023-05-25 07:18:41 --> Output Class Initialized
INFO - 2023-05-25 07:18:41 --> Security Class Initialized
DEBUG - 2023-05-25 07:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:18:41 --> Config Class Initialized
INFO - 2023-05-25 07:18:41 --> Input Class Initialized
INFO - 2023-05-25 07:18:41 --> Hooks Class Initialized
INFO - 2023-05-25 07:18:41 --> Language Class Initialized
DEBUG - 2023-05-25 07:18:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:18:41 --> Utf8 Class Initialized
INFO - 2023-05-25 07:18:41 --> Loader Class Initialized
INFO - 2023-05-25 07:18:41 --> URI Class Initialized
INFO - 2023-05-25 07:18:41 --> Controller Class Initialized
DEBUG - 2023-05-25 07:18:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:41 --> Router Class Initialized
INFO - 2023-05-25 07:18:41 --> Output Class Initialized
INFO - 2023-05-25 07:18:42 --> Security Class Initialized
DEBUG - 2023-05-25 07:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:18:42 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:42 --> Input Class Initialized
INFO - 2023-05-25 07:18:42 --> Language Class Initialized
INFO - 2023-05-25 07:18:42 --> Final output sent to browser
INFO - 2023-05-25 07:18:42 --> Model "Cluster_model" initialized
DEBUG - 2023-05-25 07:18:42 --> Total execution time: 1.0668
INFO - 2023-05-25 07:18:42 --> Loader Class Initialized
INFO - 2023-05-25 07:18:42 --> Controller Class Initialized
DEBUG - 2023-05-25 07:18:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:18:42 --> Database Driver Class Initialized
INFO - 2023-05-25 07:18:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:18:42 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:42 --> Total execution time: 0.5152
INFO - 2023-05-25 07:18:42 --> Final output sent to browser
DEBUG - 2023-05-25 07:18:42 --> Total execution time: 0.5448
INFO - 2023-05-25 07:19:39 --> Config Class Initialized
INFO - 2023-05-25 07:19:39 --> Config Class Initialized
INFO - 2023-05-25 07:19:39 --> Hooks Class Initialized
INFO - 2023-05-25 07:19:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:19:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:19:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:19:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:19:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:19:39 --> URI Class Initialized
INFO - 2023-05-25 07:19:39 --> URI Class Initialized
INFO - 2023-05-25 07:19:39 --> Router Class Initialized
INFO - 2023-05-25 07:19:39 --> Router Class Initialized
INFO - 2023-05-25 07:19:39 --> Output Class Initialized
INFO - 2023-05-25 07:19:39 --> Output Class Initialized
INFO - 2023-05-25 07:19:39 --> Security Class Initialized
INFO - 2023-05-25 07:19:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:19:39 --> Input Class Initialized
INFO - 2023-05-25 07:19:39 --> Input Class Initialized
INFO - 2023-05-25 07:19:39 --> Language Class Initialized
INFO - 2023-05-25 07:19:39 --> Language Class Initialized
INFO - 2023-05-25 07:19:39 --> Loader Class Initialized
INFO - 2023-05-25 07:19:39 --> Controller Class Initialized
INFO - 2023-05-25 07:19:39 --> Loader Class Initialized
DEBUG - 2023-05-25 07:19:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:19:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:19:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:19:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:19:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:19:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:19:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:19:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:19:40 --> Model "Login_model" initialized
INFO - 2023-05-25 07:19:41 --> Final output sent to browser
DEBUG - 2023-05-25 07:19:41 --> Total execution time: 1.8119
INFO - 2023-05-25 07:19:41 --> Config Class Initialized
INFO - 2023-05-25 07:19:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:19:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:19:41 --> Utf8 Class Initialized
INFO - 2023-05-25 07:19:41 --> URI Class Initialized
INFO - 2023-05-25 07:19:41 --> Router Class Initialized
INFO - 2023-05-25 07:19:41 --> Output Class Initialized
INFO - 2023-05-25 07:19:41 --> Security Class Initialized
DEBUG - 2023-05-25 07:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:19:41 --> Input Class Initialized
INFO - 2023-05-25 07:19:41 --> Language Class Initialized
INFO - 2023-05-25 07:19:41 --> Loader Class Initialized
INFO - 2023-05-25 07:19:41 --> Controller Class Initialized
DEBUG - 2023-05-25 07:19:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:19:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:19:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:19:43 --> Final output sent to browser
DEBUG - 2023-05-25 07:19:43 --> Total execution time: 1.4956
INFO - 2023-05-25 07:19:53 --> Final output sent to browser
DEBUG - 2023-05-25 07:19:53 --> Total execution time: 13.5366
INFO - 2023-05-25 07:19:53 --> Config Class Initialized
INFO - 2023-05-25 07:19:53 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:19:53 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:19:53 --> Utf8 Class Initialized
INFO - 2023-05-25 07:19:53 --> URI Class Initialized
INFO - 2023-05-25 07:19:53 --> Router Class Initialized
INFO - 2023-05-25 07:19:53 --> Output Class Initialized
INFO - 2023-05-25 07:19:53 --> Security Class Initialized
DEBUG - 2023-05-25 07:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:19:53 --> Input Class Initialized
INFO - 2023-05-25 07:19:53 --> Language Class Initialized
INFO - 2023-05-25 07:19:53 --> Loader Class Initialized
INFO - 2023-05-25 07:19:53 --> Controller Class Initialized
DEBUG - 2023-05-25 07:19:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:19:53 --> Database Driver Class Initialized
INFO - 2023-05-25 07:19:53 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:19:53 --> Database Driver Class Initialized
INFO - 2023-05-25 07:19:53 --> Model "Login_model" initialized
INFO - 2023-05-25 07:20:05 --> Final output sent to browser
DEBUG - 2023-05-25 07:20:05 --> Total execution time: 11.8983
INFO - 2023-05-25 07:20:39 --> Config Class Initialized
INFO - 2023-05-25 07:20:39 --> Config Class Initialized
INFO - 2023-05-25 07:20:39 --> Hooks Class Initialized
INFO - 2023-05-25 07:20:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:20:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:20:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:20:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:20:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:20:39 --> URI Class Initialized
INFO - 2023-05-25 07:20:39 --> URI Class Initialized
INFO - 2023-05-25 07:20:39 --> Router Class Initialized
INFO - 2023-05-25 07:20:39 --> Router Class Initialized
INFO - 2023-05-25 07:20:39 --> Output Class Initialized
INFO - 2023-05-25 07:20:39 --> Output Class Initialized
INFO - 2023-05-25 07:20:39 --> Security Class Initialized
INFO - 2023-05-25 07:20:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:20:39 --> Input Class Initialized
INFO - 2023-05-25 07:20:39 --> Input Class Initialized
INFO - 2023-05-25 07:20:39 --> Language Class Initialized
INFO - 2023-05-25 07:20:39 --> Language Class Initialized
INFO - 2023-05-25 07:20:39 --> Loader Class Initialized
INFO - 2023-05-25 07:20:39 --> Loader Class Initialized
INFO - 2023-05-25 07:20:39 --> Controller Class Initialized
INFO - 2023-05-25 07:20:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:20:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:20:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:20:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:20:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:20:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:20:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:20:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:20:39 --> Model "Login_model" initialized
INFO - 2023-05-25 07:20:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:20:40 --> Total execution time: 0.7003
INFO - 2023-05-25 07:20:40 --> Config Class Initialized
INFO - 2023-05-25 07:20:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:20:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:20:40 --> Utf8 Class Initialized
INFO - 2023-05-25 07:20:40 --> URI Class Initialized
INFO - 2023-05-25 07:20:40 --> Router Class Initialized
INFO - 2023-05-25 07:20:40 --> Output Class Initialized
INFO - 2023-05-25 07:20:40 --> Security Class Initialized
DEBUG - 2023-05-25 07:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:20:40 --> Input Class Initialized
INFO - 2023-05-25 07:20:40 --> Language Class Initialized
INFO - 2023-05-25 07:20:40 --> Loader Class Initialized
INFO - 2023-05-25 07:20:40 --> Controller Class Initialized
DEBUG - 2023-05-25 07:20:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:20:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:20:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:20:41 --> Final output sent to browser
DEBUG - 2023-05-25 07:20:41 --> Total execution time: 0.5986
INFO - 2023-05-25 07:20:51 --> Final output sent to browser
DEBUG - 2023-05-25 07:20:51 --> Total execution time: 11.6871
INFO - 2023-05-25 07:20:51 --> Config Class Initialized
INFO - 2023-05-25 07:20:51 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:20:51 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:20:51 --> Utf8 Class Initialized
INFO - 2023-05-25 07:20:51 --> URI Class Initialized
INFO - 2023-05-25 07:20:51 --> Router Class Initialized
INFO - 2023-05-25 07:20:51 --> Output Class Initialized
INFO - 2023-05-25 07:20:51 --> Security Class Initialized
DEBUG - 2023-05-25 07:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:20:51 --> Input Class Initialized
INFO - 2023-05-25 07:20:51 --> Language Class Initialized
INFO - 2023-05-25 07:20:51 --> Loader Class Initialized
INFO - 2023-05-25 07:20:51 --> Controller Class Initialized
DEBUG - 2023-05-25 07:20:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:20:51 --> Database Driver Class Initialized
INFO - 2023-05-25 07:20:51 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:20:51 --> Database Driver Class Initialized
INFO - 2023-05-25 07:20:51 --> Model "Login_model" initialized
INFO - 2023-05-25 07:21:06 --> Final output sent to browser
DEBUG - 2023-05-25 07:21:06 --> Total execution time: 14.9665
INFO - 2023-05-25 07:21:39 --> Config Class Initialized
INFO - 2023-05-25 07:21:39 --> Config Class Initialized
INFO - 2023-05-25 07:21:39 --> Hooks Class Initialized
INFO - 2023-05-25 07:21:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:21:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:21:39 --> Utf8 Class Initialized
DEBUG - 2023-05-25 07:21:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:21:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:21:39 --> URI Class Initialized
INFO - 2023-05-25 07:21:39 --> URI Class Initialized
INFO - 2023-05-25 07:21:39 --> Router Class Initialized
INFO - 2023-05-25 07:21:39 --> Router Class Initialized
INFO - 2023-05-25 07:21:39 --> Output Class Initialized
INFO - 2023-05-25 07:21:39 --> Output Class Initialized
INFO - 2023-05-25 07:21:39 --> Security Class Initialized
INFO - 2023-05-25 07:21:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:21:39 --> Input Class Initialized
INFO - 2023-05-25 07:21:39 --> Input Class Initialized
INFO - 2023-05-25 07:21:39 --> Language Class Initialized
INFO - 2023-05-25 07:21:39 --> Language Class Initialized
INFO - 2023-05-25 07:21:39 --> Loader Class Initialized
INFO - 2023-05-25 07:21:39 --> Loader Class Initialized
INFO - 2023-05-25 07:21:39 --> Controller Class Initialized
INFO - 2023-05-25 07:21:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:21:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:21:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:21:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:21:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:21:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:21:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:21:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:21:40 --> Model "Login_model" initialized
INFO - 2023-05-25 07:21:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:21:40 --> Total execution time: 0.2440
INFO - 2023-05-25 07:21:40 --> Config Class Initialized
INFO - 2023-05-25 07:21:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:21:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:21:40 --> Utf8 Class Initialized
INFO - 2023-05-25 07:21:40 --> URI Class Initialized
INFO - 2023-05-25 07:21:40 --> Router Class Initialized
INFO - 2023-05-25 07:21:40 --> Output Class Initialized
INFO - 2023-05-25 07:21:40 --> Security Class Initialized
DEBUG - 2023-05-25 07:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:21:40 --> Input Class Initialized
INFO - 2023-05-25 07:21:40 --> Language Class Initialized
INFO - 2023-05-25 07:21:40 --> Loader Class Initialized
INFO - 2023-05-25 07:21:40 --> Controller Class Initialized
DEBUG - 2023-05-25 07:21:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:21:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:21:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:21:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:21:40 --> Total execution time: 0.2787
INFO - 2023-05-25 07:21:51 --> Final output sent to browser
DEBUG - 2023-05-25 07:21:51 --> Total execution time: 11.2744
INFO - 2023-05-25 07:21:51 --> Config Class Initialized
INFO - 2023-05-25 07:21:51 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:21:51 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:21:51 --> Utf8 Class Initialized
INFO - 2023-05-25 07:21:51 --> URI Class Initialized
INFO - 2023-05-25 07:21:51 --> Router Class Initialized
INFO - 2023-05-25 07:21:51 --> Output Class Initialized
INFO - 2023-05-25 07:21:51 --> Security Class Initialized
DEBUG - 2023-05-25 07:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:21:51 --> Input Class Initialized
INFO - 2023-05-25 07:21:51 --> Language Class Initialized
INFO - 2023-05-25 07:21:51 --> Loader Class Initialized
INFO - 2023-05-25 07:21:51 --> Controller Class Initialized
DEBUG - 2023-05-25 07:21:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:21:51 --> Database Driver Class Initialized
INFO - 2023-05-25 07:21:51 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:21:51 --> Database Driver Class Initialized
INFO - 2023-05-25 07:21:51 --> Model "Login_model" initialized
INFO - 2023-05-25 07:22:02 --> Final output sent to browser
DEBUG - 2023-05-25 07:22:02 --> Total execution time: 11.3216
INFO - 2023-05-25 07:22:39 --> Config Class Initialized
INFO - 2023-05-25 07:22:39 --> Hooks Class Initialized
INFO - 2023-05-25 07:22:39 --> Config Class Initialized
DEBUG - 2023-05-25 07:22:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:22:39 --> Hooks Class Initialized
INFO - 2023-05-25 07:22:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:22:39 --> URI Class Initialized
INFO - 2023-05-25 07:22:39 --> Router Class Initialized
DEBUG - 2023-05-25 07:22:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:22:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:22:39 --> Output Class Initialized
INFO - 2023-05-25 07:22:39 --> Security Class Initialized
INFO - 2023-05-25 07:22:39 --> URI Class Initialized
DEBUG - 2023-05-25 07:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:22:39 --> Input Class Initialized
INFO - 2023-05-25 07:22:39 --> Router Class Initialized
INFO - 2023-05-25 07:22:39 --> Language Class Initialized
INFO - 2023-05-25 07:22:39 --> Output Class Initialized
INFO - 2023-05-25 07:22:39 --> Loader Class Initialized
INFO - 2023-05-25 07:22:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:22:39 --> Controller Class Initialized
INFO - 2023-05-25 07:22:39 --> Input Class Initialized
DEBUG - 2023-05-25 07:22:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:22:39 --> Language Class Initialized
INFO - 2023-05-25 07:22:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:22:40 --> Loader Class Initialized
INFO - 2023-05-25 07:22:40 --> Controller Class Initialized
INFO - 2023-05-25 07:22:40 --> Model "Cluster_model" initialized
DEBUG - 2023-05-25 07:22:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:22:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:22:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:22:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:22:40 --> Model "Login_model" initialized
INFO - 2023-05-25 07:22:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:22:40 --> Total execution time: 0.3974
INFO - 2023-05-25 07:22:40 --> Config Class Initialized
INFO - 2023-05-25 07:22:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:22:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:22:40 --> Utf8 Class Initialized
INFO - 2023-05-25 07:22:40 --> URI Class Initialized
INFO - 2023-05-25 07:22:40 --> Router Class Initialized
INFO - 2023-05-25 07:22:40 --> Output Class Initialized
INFO - 2023-05-25 07:22:40 --> Security Class Initialized
DEBUG - 2023-05-25 07:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:22:40 --> Input Class Initialized
INFO - 2023-05-25 07:22:40 --> Language Class Initialized
INFO - 2023-05-25 07:22:40 --> Loader Class Initialized
INFO - 2023-05-25 07:22:40 --> Controller Class Initialized
DEBUG - 2023-05-25 07:22:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:22:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:22:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:22:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:22:40 --> Total execution time: 0.4681
INFO - 2023-05-25 07:22:52 --> Final output sent to browser
DEBUG - 2023-05-25 07:22:52 --> Total execution time: 12.2341
INFO - 2023-05-25 07:22:52 --> Config Class Initialized
INFO - 2023-05-25 07:22:52 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:22:52 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:22:52 --> Utf8 Class Initialized
INFO - 2023-05-25 07:22:52 --> URI Class Initialized
INFO - 2023-05-25 07:22:52 --> Router Class Initialized
INFO - 2023-05-25 07:22:52 --> Output Class Initialized
INFO - 2023-05-25 07:22:52 --> Security Class Initialized
DEBUG - 2023-05-25 07:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:22:52 --> Input Class Initialized
INFO - 2023-05-25 07:22:52 --> Language Class Initialized
INFO - 2023-05-25 07:22:52 --> Loader Class Initialized
INFO - 2023-05-25 07:22:52 --> Controller Class Initialized
DEBUG - 2023-05-25 07:22:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:22:52 --> Database Driver Class Initialized
INFO - 2023-05-25 07:22:52 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:22:52 --> Database Driver Class Initialized
INFO - 2023-05-25 07:22:52 --> Model "Login_model" initialized
INFO - 2023-05-25 07:23:03 --> Final output sent to browser
DEBUG - 2023-05-25 07:23:03 --> Total execution time: 11.5550
INFO - 2023-05-25 07:23:39 --> Config Class Initialized
INFO - 2023-05-25 07:23:39 --> Config Class Initialized
INFO - 2023-05-25 07:23:39 --> Hooks Class Initialized
INFO - 2023-05-25 07:23:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:23:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:23:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:23:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:23:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:23:39 --> URI Class Initialized
INFO - 2023-05-25 07:23:39 --> URI Class Initialized
INFO - 2023-05-25 07:23:39 --> Router Class Initialized
INFO - 2023-05-25 07:23:39 --> Router Class Initialized
INFO - 2023-05-25 07:23:39 --> Output Class Initialized
INFO - 2023-05-25 07:23:39 --> Output Class Initialized
INFO - 2023-05-25 07:23:39 --> Security Class Initialized
INFO - 2023-05-25 07:23:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:23:39 --> Input Class Initialized
INFO - 2023-05-25 07:23:39 --> Input Class Initialized
INFO - 2023-05-25 07:23:39 --> Language Class Initialized
INFO - 2023-05-25 07:23:39 --> Language Class Initialized
INFO - 2023-05-25 07:23:39 --> Loader Class Initialized
INFO - 2023-05-25 07:23:39 --> Loader Class Initialized
INFO - 2023-05-25 07:23:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:23:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:23:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:23:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:23:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:23:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:23:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:23:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:23:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:23:39 --> Model "Login_model" initialized
INFO - 2023-05-25 07:23:49 --> Final output sent to browser
DEBUG - 2023-05-25 07:23:49 --> Total execution time: 9.5324
INFO - 2023-05-25 07:23:49 --> Config Class Initialized
INFO - 2023-05-25 07:23:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:23:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:23:49 --> Utf8 Class Initialized
INFO - 2023-05-25 07:23:49 --> URI Class Initialized
INFO - 2023-05-25 07:23:49 --> Router Class Initialized
INFO - 2023-05-25 07:23:49 --> Output Class Initialized
INFO - 2023-05-25 07:23:49 --> Security Class Initialized
DEBUG - 2023-05-25 07:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:23:49 --> Input Class Initialized
INFO - 2023-05-25 07:23:49 --> Language Class Initialized
INFO - 2023-05-25 07:23:49 --> Loader Class Initialized
INFO - 2023-05-25 07:23:49 --> Controller Class Initialized
DEBUG - 2023-05-25 07:23:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:23:49 --> Database Driver Class Initialized
INFO - 2023-05-25 07:23:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:23:51 --> Final output sent to browser
DEBUG - 2023-05-25 07:23:51 --> Total execution time: 2.4494
INFO - 2023-05-25 07:23:59 --> Final output sent to browser
DEBUG - 2023-05-25 07:23:59 --> Total execution time: 19.6981
INFO - 2023-05-25 07:23:59 --> Config Class Initialized
INFO - 2023-05-25 07:23:59 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:23:59 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:23:59 --> Utf8 Class Initialized
INFO - 2023-05-25 07:23:59 --> URI Class Initialized
INFO - 2023-05-25 07:23:59 --> Router Class Initialized
INFO - 2023-05-25 07:23:59 --> Output Class Initialized
INFO - 2023-05-25 07:23:59 --> Security Class Initialized
DEBUG - 2023-05-25 07:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:23:59 --> Input Class Initialized
INFO - 2023-05-25 07:23:59 --> Language Class Initialized
INFO - 2023-05-25 07:23:59 --> Loader Class Initialized
INFO - 2023-05-25 07:23:59 --> Controller Class Initialized
DEBUG - 2023-05-25 07:23:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:23:59 --> Database Driver Class Initialized
INFO - 2023-05-25 07:23:59 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:23:59 --> Database Driver Class Initialized
INFO - 2023-05-25 07:23:59 --> Model "Login_model" initialized
INFO - 2023-05-25 07:24:13 --> Final output sent to browser
DEBUG - 2023-05-25 07:24:13 --> Total execution time: 13.5988
INFO - 2023-05-25 07:24:40 --> Config Class Initialized
INFO - 2023-05-25 07:24:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:24:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:24:40 --> Utf8 Class Initialized
INFO - 2023-05-25 07:24:40 --> URI Class Initialized
INFO - 2023-05-25 07:24:40 --> Router Class Initialized
INFO - 2023-05-25 07:24:40 --> Output Class Initialized
INFO - 2023-05-25 07:24:40 --> Security Class Initialized
DEBUG - 2023-05-25 07:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:24:40 --> Input Class Initialized
INFO - 2023-05-25 07:24:40 --> Language Class Initialized
INFO - 2023-05-25 07:24:40 --> Loader Class Initialized
INFO - 2023-05-25 07:24:40 --> Controller Class Initialized
DEBUG - 2023-05-25 07:24:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:24:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:24:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:24:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:24:40 --> Total execution time: 0.7079
INFO - 2023-05-25 07:24:40 --> Config Class Initialized
INFO - 2023-05-25 07:24:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:24:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:24:40 --> Utf8 Class Initialized
INFO - 2023-05-25 07:24:40 --> URI Class Initialized
INFO - 2023-05-25 07:24:41 --> Router Class Initialized
INFO - 2023-05-25 07:24:41 --> Output Class Initialized
INFO - 2023-05-25 07:24:41 --> Security Class Initialized
DEBUG - 2023-05-25 07:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:24:41 --> Input Class Initialized
INFO - 2023-05-25 07:24:41 --> Language Class Initialized
INFO - 2023-05-25 07:24:41 --> Loader Class Initialized
INFO - 2023-05-25 07:24:41 --> Controller Class Initialized
DEBUG - 2023-05-25 07:24:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:24:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:24:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:24:41 --> Config Class Initialized
INFO - 2023-05-25 07:24:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:24:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:24:41 --> Utf8 Class Initialized
INFO - 2023-05-25 07:24:41 --> URI Class Initialized
INFO - 2023-05-25 07:24:41 --> Router Class Initialized
INFO - 2023-05-25 07:24:41 --> Output Class Initialized
INFO - 2023-05-25 07:24:41 --> Security Class Initialized
DEBUG - 2023-05-25 07:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:24:41 --> Input Class Initialized
INFO - 2023-05-25 07:24:41 --> Language Class Initialized
INFO - 2023-05-25 07:24:41 --> Loader Class Initialized
INFO - 2023-05-25 07:24:41 --> Controller Class Initialized
DEBUG - 2023-05-25 07:24:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:24:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:24:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:24:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:24:41 --> Model "Login_model" initialized
INFO - 2023-05-25 07:24:41 --> Final output sent to browser
DEBUG - 2023-05-25 07:24:41 --> Total execution time: 0.5482
INFO - 2023-05-25 07:24:51 --> Final output sent to browser
DEBUG - 2023-05-25 07:24:51 --> Total execution time: 10.6937
INFO - 2023-05-25 07:24:51 --> Config Class Initialized
INFO - 2023-05-25 07:24:51 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:24:51 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:24:51 --> Utf8 Class Initialized
INFO - 2023-05-25 07:24:51 --> URI Class Initialized
INFO - 2023-05-25 07:24:51 --> Router Class Initialized
INFO - 2023-05-25 07:24:51 --> Output Class Initialized
INFO - 2023-05-25 07:24:51 --> Security Class Initialized
DEBUG - 2023-05-25 07:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:24:51 --> Input Class Initialized
INFO - 2023-05-25 07:24:51 --> Language Class Initialized
INFO - 2023-05-25 07:24:52 --> Loader Class Initialized
INFO - 2023-05-25 07:24:52 --> Controller Class Initialized
DEBUG - 2023-05-25 07:24:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:24:52 --> Database Driver Class Initialized
INFO - 2023-05-25 07:24:52 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:24:52 --> Database Driver Class Initialized
INFO - 2023-05-25 07:24:52 --> Model "Login_model" initialized
INFO - 2023-05-25 07:25:02 --> Final output sent to browser
DEBUG - 2023-05-25 07:25:02 --> Total execution time: 10.3735
INFO - 2023-05-25 07:26:39 --> Config Class Initialized
INFO - 2023-05-25 07:26:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:26:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:26:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:26:39 --> URI Class Initialized
INFO - 2023-05-25 07:26:39 --> Router Class Initialized
INFO - 2023-05-25 07:26:39 --> Output Class Initialized
INFO - 2023-05-25 07:26:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:26:39 --> Input Class Initialized
INFO - 2023-05-25 07:26:39 --> Language Class Initialized
INFO - 2023-05-25 07:26:39 --> Loader Class Initialized
INFO - 2023-05-25 07:26:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:26:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:26:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:26:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:26:39 --> Final output sent to browser
DEBUG - 2023-05-25 07:26:39 --> Total execution time: 0.3629
INFO - 2023-05-25 07:26:39 --> Config Class Initialized
INFO - 2023-05-25 07:26:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:26:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:26:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:26:39 --> URI Class Initialized
INFO - 2023-05-25 07:26:39 --> Router Class Initialized
INFO - 2023-05-25 07:26:39 --> Output Class Initialized
INFO - 2023-05-25 07:26:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:26:39 --> Input Class Initialized
INFO - 2023-05-25 07:26:39 --> Language Class Initialized
INFO - 2023-05-25 07:26:39 --> Loader Class Initialized
INFO - 2023-05-25 07:26:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:26:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:26:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:26:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:26:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:26:40 --> Total execution time: 0.4216
INFO - 2023-05-25 07:27:39 --> Config Class Initialized
INFO - 2023-05-25 07:27:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:27:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:27:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:27:39 --> URI Class Initialized
INFO - 2023-05-25 07:27:39 --> Router Class Initialized
INFO - 2023-05-25 07:27:39 --> Output Class Initialized
INFO - 2023-05-25 07:27:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:27:39 --> Input Class Initialized
INFO - 2023-05-25 07:27:39 --> Language Class Initialized
INFO - 2023-05-25 07:27:39 --> Loader Class Initialized
INFO - 2023-05-25 07:27:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:27:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:27:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:27:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:27:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:27:39 --> Model "Login_model" initialized
INFO - 2023-05-25 07:27:53 --> Final output sent to browser
DEBUG - 2023-05-25 07:27:53 --> Total execution time: 14.4830
INFO - 2023-05-25 07:27:53 --> Config Class Initialized
INFO - 2023-05-25 07:27:53 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:27:53 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:27:53 --> Utf8 Class Initialized
INFO - 2023-05-25 07:27:53 --> URI Class Initialized
INFO - 2023-05-25 07:27:53 --> Router Class Initialized
INFO - 2023-05-25 07:27:53 --> Output Class Initialized
INFO - 2023-05-25 07:27:53 --> Security Class Initialized
DEBUG - 2023-05-25 07:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:27:53 --> Input Class Initialized
INFO - 2023-05-25 07:27:53 --> Language Class Initialized
INFO - 2023-05-25 07:27:53 --> Loader Class Initialized
INFO - 2023-05-25 07:27:53 --> Controller Class Initialized
DEBUG - 2023-05-25 07:27:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:27:54 --> Database Driver Class Initialized
INFO - 2023-05-25 07:27:54 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:27:54 --> Database Driver Class Initialized
INFO - 2023-05-25 07:27:54 --> Model "Login_model" initialized
INFO - 2023-05-25 07:28:05 --> Final output sent to browser
DEBUG - 2023-05-25 07:28:05 --> Total execution time: 12.0798
INFO - 2023-05-25 07:28:39 --> Config Class Initialized
INFO - 2023-05-25 07:28:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:28:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:28:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:28:39 --> URI Class Initialized
INFO - 2023-05-25 07:28:39 --> Router Class Initialized
INFO - 2023-05-25 07:28:39 --> Output Class Initialized
INFO - 2023-05-25 07:28:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:28:39 --> Input Class Initialized
INFO - 2023-05-25 07:28:39 --> Language Class Initialized
INFO - 2023-05-25 07:28:39 --> Loader Class Initialized
INFO - 2023-05-25 07:28:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:28:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:28:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:28:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:28:39 --> Final output sent to browser
DEBUG - 2023-05-25 07:28:39 --> Total execution time: 0.2114
INFO - 2023-05-25 07:28:39 --> Config Class Initialized
INFO - 2023-05-25 07:28:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:28:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:28:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:28:39 --> URI Class Initialized
INFO - 2023-05-25 07:28:39 --> Router Class Initialized
INFO - 2023-05-25 07:28:39 --> Output Class Initialized
INFO - 2023-05-25 07:28:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:28:39 --> Input Class Initialized
INFO - 2023-05-25 07:28:39 --> Language Class Initialized
INFO - 2023-05-25 07:28:39 --> Loader Class Initialized
INFO - 2023-05-25 07:28:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:28:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:28:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:28:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:28:39 --> Final output sent to browser
DEBUG - 2023-05-25 07:28:39 --> Total execution time: 0.2007
INFO - 2023-05-25 07:29:39 --> Config Class Initialized
INFO - 2023-05-25 07:29:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:29:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:29:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:29:39 --> URI Class Initialized
INFO - 2023-05-25 07:29:39 --> Router Class Initialized
INFO - 2023-05-25 07:29:39 --> Output Class Initialized
INFO - 2023-05-25 07:29:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:29:39 --> Input Class Initialized
INFO - 2023-05-25 07:29:39 --> Language Class Initialized
INFO - 2023-05-25 07:29:39 --> Loader Class Initialized
INFO - 2023-05-25 07:29:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:29:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:29:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:29:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:29:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:29:39 --> Model "Login_model" initialized
INFO - 2023-05-25 07:30:05 --> Final output sent to browser
DEBUG - 2023-05-25 07:30:05 --> Total execution time: 26.3301
INFO - 2023-05-25 07:30:05 --> Config Class Initialized
INFO - 2023-05-25 07:30:05 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:30:05 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:30:05 --> Utf8 Class Initialized
INFO - 2023-05-25 07:30:05 --> URI Class Initialized
INFO - 2023-05-25 07:30:05 --> Router Class Initialized
INFO - 2023-05-25 07:30:05 --> Output Class Initialized
INFO - 2023-05-25 07:30:05 --> Security Class Initialized
DEBUG - 2023-05-25 07:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:30:05 --> Input Class Initialized
INFO - 2023-05-25 07:30:05 --> Language Class Initialized
INFO - 2023-05-25 07:30:05 --> Loader Class Initialized
INFO - 2023-05-25 07:30:05 --> Controller Class Initialized
DEBUG - 2023-05-25 07:30:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:30:05 --> Database Driver Class Initialized
INFO - 2023-05-25 07:30:05 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:30:05 --> Database Driver Class Initialized
INFO - 2023-05-25 07:30:06 --> Model "Login_model" initialized
INFO - 2023-05-25 07:30:28 --> Final output sent to browser
DEBUG - 2023-05-25 07:30:28 --> Total execution time: 23.3302
INFO - 2023-05-25 07:30:39 --> Config Class Initialized
INFO - 2023-05-25 07:30:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:30:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:30:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:30:40 --> URI Class Initialized
INFO - 2023-05-25 07:30:40 --> Router Class Initialized
INFO - 2023-05-25 07:30:40 --> Output Class Initialized
INFO - 2023-05-25 07:30:40 --> Security Class Initialized
DEBUG - 2023-05-25 07:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:30:40 --> Input Class Initialized
INFO - 2023-05-25 07:30:40 --> Language Class Initialized
INFO - 2023-05-25 07:30:40 --> Loader Class Initialized
INFO - 2023-05-25 07:30:40 --> Controller Class Initialized
DEBUG - 2023-05-25 07:30:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:30:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:30:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:30:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:30:40 --> Total execution time: 1.0530
INFO - 2023-05-25 07:30:40 --> Config Class Initialized
INFO - 2023-05-25 07:30:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:30:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:30:41 --> Utf8 Class Initialized
INFO - 2023-05-25 07:30:41 --> URI Class Initialized
INFO - 2023-05-25 07:30:41 --> Router Class Initialized
INFO - 2023-05-25 07:30:41 --> Output Class Initialized
INFO - 2023-05-25 07:30:42 --> Security Class Initialized
DEBUG - 2023-05-25 07:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:30:42 --> Input Class Initialized
INFO - 2023-05-25 07:30:42 --> Language Class Initialized
INFO - 2023-05-25 07:30:43 --> Loader Class Initialized
INFO - 2023-05-25 07:30:43 --> Controller Class Initialized
DEBUG - 2023-05-25 07:30:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:30:43 --> Database Driver Class Initialized
INFO - 2023-05-25 07:30:43 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:30:49 --> Final output sent to browser
DEBUG - 2023-05-25 07:30:49 --> Total execution time: 8.6512
INFO - 2023-05-25 07:31:13 --> Config Class Initialized
INFO - 2023-05-25 07:31:13 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:13 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:13 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:13 --> URI Class Initialized
INFO - 2023-05-25 07:31:13 --> Router Class Initialized
INFO - 2023-05-25 07:31:13 --> Output Class Initialized
INFO - 2023-05-25 07:31:13 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:13 --> Input Class Initialized
INFO - 2023-05-25 07:31:13 --> Language Class Initialized
INFO - 2023-05-25 07:31:13 --> Loader Class Initialized
INFO - 2023-05-25 07:31:13 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:13 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:13 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:31:13 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:13 --> Model "Login_model" initialized
INFO - 2023-05-25 07:31:15 --> Config Class Initialized
INFO - 2023-05-25 07:31:15 --> Config Class Initialized
INFO - 2023-05-25 07:31:15 --> Hooks Class Initialized
INFO - 2023-05-25 07:31:15 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:15 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:31:15 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:15 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:15 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:15 --> URI Class Initialized
INFO - 2023-05-25 07:31:15 --> URI Class Initialized
INFO - 2023-05-25 07:31:15 --> Router Class Initialized
INFO - 2023-05-25 07:31:15 --> Router Class Initialized
INFO - 2023-05-25 07:31:15 --> Output Class Initialized
INFO - 2023-05-25 07:31:15 --> Output Class Initialized
INFO - 2023-05-25 07:31:15 --> Security Class Initialized
INFO - 2023-05-25 07:31:15 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:15 --> Input Class Initialized
INFO - 2023-05-25 07:31:15 --> Input Class Initialized
INFO - 2023-05-25 07:31:15 --> Language Class Initialized
INFO - 2023-05-25 07:31:15 --> Language Class Initialized
INFO - 2023-05-25 07:31:15 --> Loader Class Initialized
INFO - 2023-05-25 07:31:15 --> Loader Class Initialized
INFO - 2023-05-25 07:31:15 --> Controller Class Initialized
INFO - 2023-05-25 07:31:15 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:31:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:15 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:15 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:15 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:31:15 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:31:16 --> Config Class Initialized
INFO - 2023-05-25 07:31:16 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:16 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:16 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:16 --> URI Class Initialized
INFO - 2023-05-25 07:31:16 --> Router Class Initialized
INFO - 2023-05-25 07:31:16 --> Output Class Initialized
INFO - 2023-05-25 07:31:16 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:16 --> Input Class Initialized
INFO - 2023-05-25 07:31:16 --> Language Class Initialized
INFO - 2023-05-25 07:31:16 --> Loader Class Initialized
INFO - 2023-05-25 07:31:16 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:16 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:16 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:16 --> Model "Login_model" initialized
INFO - 2023-05-25 07:31:16 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:16 --> Total execution time: 0.2766
INFO - 2023-05-25 07:31:16 --> Config Class Initialized
INFO - 2023-05-25 07:31:16 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:16 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:16 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:16 --> URI Class Initialized
INFO - 2023-05-25 07:31:16 --> Router Class Initialized
INFO - 2023-05-25 07:31:16 --> Output Class Initialized
INFO - 2023-05-25 07:31:16 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:16 --> Input Class Initialized
INFO - 2023-05-25 07:31:16 --> Language Class Initialized
INFO - 2023-05-25 07:31:16 --> Loader Class Initialized
INFO - 2023-05-25 07:31:16 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:16 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:16 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:31:17 --> Config Class Initialized
INFO - 2023-05-25 07:31:17 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:17 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:17 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:17 --> URI Class Initialized
INFO - 2023-05-25 07:31:17 --> Router Class Initialized
INFO - 2023-05-25 07:31:17 --> Output Class Initialized
INFO - 2023-05-25 07:31:17 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:17 --> Input Class Initialized
INFO - 2023-05-25 07:31:17 --> Language Class Initialized
INFO - 2023-05-25 07:31:17 --> Loader Class Initialized
INFO - 2023-05-25 07:31:17 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:17 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:17 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:17 --> Model "Login_model" initialized
INFO - 2023-05-25 07:31:17 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:17 --> Total execution time: 0.2497
INFO - 2023-05-25 07:31:19 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:19 --> Total execution time: 3.9637
INFO - 2023-05-25 07:31:19 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:19 --> Total execution time: 3.9716
INFO - 2023-05-25 07:31:19 --> Config Class Initialized
INFO - 2023-05-25 07:31:19 --> Hooks Class Initialized
INFO - 2023-05-25 07:31:19 --> Config Class Initialized
INFO - 2023-05-25 07:31:19 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:19 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:19 --> Utf8 Class Initialized
DEBUG - 2023-05-25 07:31:19 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:19 --> URI Class Initialized
INFO - 2023-05-25 07:31:19 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:19 --> URI Class Initialized
INFO - 2023-05-25 07:31:19 --> Router Class Initialized
INFO - 2023-05-25 07:31:19 --> Router Class Initialized
INFO - 2023-05-25 07:31:19 --> Output Class Initialized
INFO - 2023-05-25 07:31:19 --> Output Class Initialized
INFO - 2023-05-25 07:31:19 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:19 --> Security Class Initialized
INFO - 2023-05-25 07:31:19 --> Input Class Initialized
INFO - 2023-05-25 07:31:19 --> Language Class Initialized
DEBUG - 2023-05-25 07:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:19 --> Input Class Initialized
INFO - 2023-05-25 07:31:19 --> Language Class Initialized
INFO - 2023-05-25 07:31:19 --> Config Class Initialized
INFO - 2023-05-25 07:31:19 --> Hooks Class Initialized
INFO - 2023-05-25 07:31:19 --> Loader Class Initialized
INFO - 2023-05-25 07:31:19 --> Loader Class Initialized
INFO - 2023-05-25 07:31:19 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:19 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:19 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:19 --> Utf8 Class Initialized
DEBUG - 2023-05-25 07:31:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:19 --> URI Class Initialized
INFO - 2023-05-25 07:31:19 --> Router Class Initialized
INFO - 2023-05-25 07:31:19 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:19 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:19 --> Output Class Initialized
INFO - 2023-05-25 07:31:19 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:19 --> Input Class Initialized
INFO - 2023-05-25 07:31:19 --> Language Class Initialized
INFO - 2023-05-25 07:31:19 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:31:19 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:31:19 --> Loader Class Initialized
INFO - 2023-05-25 07:31:19 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:19 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:19 --> Total execution time: 0.2010
INFO - 2023-05-25 07:31:19 --> Config Class Initialized
INFO - 2023-05-25 07:31:19 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:19 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:19 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:19 --> URI Class Initialized
INFO - 2023-05-25 07:31:19 --> Router Class Initialized
INFO - 2023-05-25 07:31:19 --> Output Class Initialized
INFO - 2023-05-25 07:31:19 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:19 --> Input Class Initialized
INFO - 2023-05-25 07:31:19 --> Language Class Initialized
INFO - 2023-05-25 07:31:19 --> Loader Class Initialized
INFO - 2023-05-25 07:31:19 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:19 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:19 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:31:19 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:19 --> Total execution time: 0.2195
INFO - 2023-05-25 07:31:22 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:22 --> Total execution time: 6.6319
INFO - 2023-05-25 07:31:22 --> Config Class Initialized
INFO - 2023-05-25 07:31:22 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:22 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:22 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:22 --> URI Class Initialized
INFO - 2023-05-25 07:31:23 --> Router Class Initialized
INFO - 2023-05-25 07:31:23 --> Output Class Initialized
INFO - 2023-05-25 07:31:23 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:23 --> Input Class Initialized
INFO - 2023-05-25 07:31:23 --> Language Class Initialized
INFO - 2023-05-25 07:31:23 --> Loader Class Initialized
INFO - 2023-05-25 07:31:23 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:23 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:23 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:31:24 --> Config Class Initialized
INFO - 2023-05-25 07:31:24 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:24 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:24 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:24 --> URI Class Initialized
INFO - 2023-05-25 07:31:24 --> Router Class Initialized
INFO - 2023-05-25 07:31:24 --> Output Class Initialized
INFO - 2023-05-25 07:31:24 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:24 --> Input Class Initialized
INFO - 2023-05-25 07:31:24 --> Language Class Initialized
INFO - 2023-05-25 07:31:24 --> Loader Class Initialized
INFO - 2023-05-25 07:31:24 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:24 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:24 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:31:25 --> Final output sent to browser
INFO - 2023-05-25 07:31:25 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:25 --> Total execution time: 6.2680
DEBUG - 2023-05-25 07:31:25 --> Total execution time: 6.2653
INFO - 2023-05-25 07:31:25 --> Config Class Initialized
INFO - 2023-05-25 07:31:25 --> Config Class Initialized
INFO - 2023-05-25 07:31:25 --> Hooks Class Initialized
INFO - 2023-05-25 07:31:25 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:25 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:31:25 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:25 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:25 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:25 --> URI Class Initialized
INFO - 2023-05-25 07:31:25 --> URI Class Initialized
INFO - 2023-05-25 07:31:25 --> Router Class Initialized
INFO - 2023-05-25 07:31:25 --> Router Class Initialized
INFO - 2023-05-25 07:31:25 --> Output Class Initialized
INFO - 2023-05-25 07:31:25 --> Output Class Initialized
INFO - 2023-05-25 07:31:25 --> Security Class Initialized
INFO - 2023-05-25 07:31:25 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:25 --> Input Class Initialized
INFO - 2023-05-25 07:31:25 --> Input Class Initialized
INFO - 2023-05-25 07:31:25 --> Language Class Initialized
INFO - 2023-05-25 07:31:25 --> Language Class Initialized
INFO - 2023-05-25 07:31:25 --> Loader Class Initialized
INFO - 2023-05-25 07:31:25 --> Loader Class Initialized
INFO - 2023-05-25 07:31:25 --> Controller Class Initialized
INFO - 2023-05-25 07:31:25 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:31:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:25 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:31:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:25 --> Model "Login_model" initialized
INFO - 2023-05-25 07:31:25 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:25 --> Total execution time: 0.2211
INFO - 2023-05-25 07:31:25 --> Config Class Initialized
INFO - 2023-05-25 07:31:25 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:25 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:25 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:25 --> URI Class Initialized
INFO - 2023-05-25 07:31:25 --> Router Class Initialized
INFO - 2023-05-25 07:31:25 --> Output Class Initialized
INFO - 2023-05-25 07:31:26 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:26 --> Input Class Initialized
INFO - 2023-05-25 07:31:26 --> Language Class Initialized
INFO - 2023-05-25 07:31:26 --> Loader Class Initialized
INFO - 2023-05-25 07:31:26 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:26 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:26 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:26 --> Model "Login_model" initialized
INFO - 2023-05-25 07:31:26 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:26 --> Total execution time: 0.2839
INFO - 2023-05-25 07:31:27 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:27 --> Total execution time: 4.6556
INFO - 2023-05-25 07:31:27 --> Config Class Initialized
INFO - 2023-05-25 07:31:27 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:27 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:27 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:27 --> URI Class Initialized
INFO - 2023-05-25 07:31:27 --> Router Class Initialized
INFO - 2023-05-25 07:31:27 --> Output Class Initialized
INFO - 2023-05-25 07:31:27 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:27 --> Input Class Initialized
INFO - 2023-05-25 07:31:27 --> Language Class Initialized
INFO - 2023-05-25 07:31:27 --> Loader Class Initialized
INFO - 2023-05-25 07:31:27 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:27 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:27 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:31:30 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:30 --> Total execution time: 5.8960
INFO - 2023-05-25 07:31:30 --> Config Class Initialized
INFO - 2023-05-25 07:31:30 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:30 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:30 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:30 --> URI Class Initialized
INFO - 2023-05-25 07:31:30 --> Router Class Initialized
INFO - 2023-05-25 07:31:30 --> Output Class Initialized
INFO - 2023-05-25 07:31:30 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:30 --> Input Class Initialized
INFO - 2023-05-25 07:31:30 --> Language Class Initialized
INFO - 2023-05-25 07:31:30 --> Loader Class Initialized
INFO - 2023-05-25 07:31:30 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:30 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:30 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:31:30 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:30 --> Total execution time: 5.1864
INFO - 2023-05-25 07:31:30 --> Config Class Initialized
INFO - 2023-05-25 07:31:30 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:31:30 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:31:30 --> Utf8 Class Initialized
INFO - 2023-05-25 07:31:30 --> URI Class Initialized
INFO - 2023-05-25 07:31:30 --> Router Class Initialized
INFO - 2023-05-25 07:31:30 --> Output Class Initialized
INFO - 2023-05-25 07:31:30 --> Security Class Initialized
DEBUG - 2023-05-25 07:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:31:30 --> Input Class Initialized
INFO - 2023-05-25 07:31:30 --> Language Class Initialized
INFO - 2023-05-25 07:31:30 --> Loader Class Initialized
INFO - 2023-05-25 07:31:30 --> Controller Class Initialized
DEBUG - 2023-05-25 07:31:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:31:31 --> Database Driver Class Initialized
INFO - 2023-05-25 07:31:31 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:31:31 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:31 --> Total execution time: 18.0823
INFO - 2023-05-25 07:31:33 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:33 --> Total execution time: 5.9785
INFO - 2023-05-25 07:31:35 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:35 --> Total execution time: 5.2009
INFO - 2023-05-25 07:31:36 --> Final output sent to browser
DEBUG - 2023-05-25 07:31:36 --> Total execution time: 5.4861
INFO - 2023-05-25 07:32:24 --> Config Class Initialized
INFO - 2023-05-25 07:32:24 --> Config Class Initialized
INFO - 2023-05-25 07:32:24 --> Hooks Class Initialized
INFO - 2023-05-25 07:32:24 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:32:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:32:24 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:32:24 --> Utf8 Class Initialized
INFO - 2023-05-25 07:32:24 --> Utf8 Class Initialized
INFO - 2023-05-25 07:32:24 --> URI Class Initialized
INFO - 2023-05-25 07:32:24 --> URI Class Initialized
INFO - 2023-05-25 07:32:24 --> Router Class Initialized
INFO - 2023-05-25 07:32:24 --> Router Class Initialized
INFO - 2023-05-25 07:32:24 --> Output Class Initialized
INFO - 2023-05-25 07:32:24 --> Output Class Initialized
INFO - 2023-05-25 07:32:24 --> Security Class Initialized
INFO - 2023-05-25 07:32:24 --> Security Class Initialized
DEBUG - 2023-05-25 07:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:32:24 --> Input Class Initialized
INFO - 2023-05-25 07:32:24 --> Input Class Initialized
INFO - 2023-05-25 07:32:24 --> Language Class Initialized
INFO - 2023-05-25 07:32:24 --> Language Class Initialized
INFO - 2023-05-25 07:32:24 --> Loader Class Initialized
INFO - 2023-05-25 07:32:24 --> Loader Class Initialized
INFO - 2023-05-25 07:32:24 --> Controller Class Initialized
DEBUG - 2023-05-25 07:32:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:32:24 --> Controller Class Initialized
DEBUG - 2023-05-25 07:32:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:32:24 --> Database Driver Class Initialized
INFO - 2023-05-25 07:32:24 --> Database Driver Class Initialized
INFO - 2023-05-25 07:32:24 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:32:24 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:32:24 --> Database Driver Class Initialized
INFO - 2023-05-25 07:32:24 --> Model "Login_model" initialized
INFO - 2023-05-25 07:32:27 --> Final output sent to browser
DEBUG - 2023-05-25 07:32:27 --> Total execution time: 2.9940
INFO - 2023-05-25 07:32:27 --> Config Class Initialized
INFO - 2023-05-25 07:32:27 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:32:27 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:32:27 --> Utf8 Class Initialized
INFO - 2023-05-25 07:32:27 --> URI Class Initialized
INFO - 2023-05-25 07:32:27 --> Router Class Initialized
INFO - 2023-05-25 07:32:27 --> Output Class Initialized
INFO - 2023-05-25 07:32:27 --> Security Class Initialized
DEBUG - 2023-05-25 07:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:32:27 --> Input Class Initialized
INFO - 2023-05-25 07:32:27 --> Language Class Initialized
INFO - 2023-05-25 07:32:27 --> Loader Class Initialized
INFO - 2023-05-25 07:32:27 --> Controller Class Initialized
DEBUG - 2023-05-25 07:32:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:32:27 --> Database Driver Class Initialized
INFO - 2023-05-25 07:32:27 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:32:30 --> Final output sent to browser
DEBUG - 2023-05-25 07:32:30 --> Total execution time: 2.5032
INFO - 2023-05-25 07:32:39 --> Final output sent to browser
DEBUG - 2023-05-25 07:32:39 --> Total execution time: 15.0598
INFO - 2023-05-25 07:32:39 --> Config Class Initialized
INFO - 2023-05-25 07:32:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:32:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:32:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:32:39 --> URI Class Initialized
INFO - 2023-05-25 07:32:39 --> Router Class Initialized
INFO - 2023-05-25 07:32:39 --> Output Class Initialized
INFO - 2023-05-25 07:32:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:32:39 --> Input Class Initialized
INFO - 2023-05-25 07:32:39 --> Language Class Initialized
INFO - 2023-05-25 07:32:39 --> Loader Class Initialized
INFO - 2023-05-25 07:32:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:32:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:32:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:32:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:32:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:32:39 --> Model "Login_model" initialized
INFO - 2023-05-25 07:32:47 --> Final output sent to browser
DEBUG - 2023-05-25 07:32:47 --> Total execution time: 8.2108
INFO - 2023-05-25 07:33:24 --> Config Class Initialized
INFO - 2023-05-25 07:33:24 --> Config Class Initialized
INFO - 2023-05-25 07:33:24 --> Hooks Class Initialized
INFO - 2023-05-25 07:33:24 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:33:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:33:24 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:33:24 --> Utf8 Class Initialized
INFO - 2023-05-25 07:33:24 --> Utf8 Class Initialized
INFO - 2023-05-25 07:33:24 --> URI Class Initialized
INFO - 2023-05-25 07:33:24 --> URI Class Initialized
INFO - 2023-05-25 07:33:24 --> Router Class Initialized
INFO - 2023-05-25 07:33:24 --> Router Class Initialized
INFO - 2023-05-25 07:33:24 --> Output Class Initialized
INFO - 2023-05-25 07:33:24 --> Output Class Initialized
INFO - 2023-05-25 07:33:24 --> Security Class Initialized
INFO - 2023-05-25 07:33:24 --> Security Class Initialized
DEBUG - 2023-05-25 07:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:33:24 --> Input Class Initialized
INFO - 2023-05-25 07:33:24 --> Input Class Initialized
INFO - 2023-05-25 07:33:24 --> Language Class Initialized
INFO - 2023-05-25 07:33:24 --> Language Class Initialized
INFO - 2023-05-25 07:33:24 --> Loader Class Initialized
INFO - 2023-05-25 07:33:24 --> Loader Class Initialized
INFO - 2023-05-25 07:33:24 --> Controller Class Initialized
INFO - 2023-05-25 07:33:24 --> Controller Class Initialized
DEBUG - 2023-05-25 07:33:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:33:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:33:24 --> Database Driver Class Initialized
INFO - 2023-05-25 07:33:24 --> Database Driver Class Initialized
INFO - 2023-05-25 07:33:24 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:33:24 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:33:24 --> Database Driver Class Initialized
INFO - 2023-05-25 07:33:24 --> Model "Login_model" initialized
INFO - 2023-05-25 07:33:24 --> Final output sent to browser
DEBUG - 2023-05-25 07:33:24 --> Total execution time: 0.2451
INFO - 2023-05-25 07:33:24 --> Config Class Initialized
INFO - 2023-05-25 07:33:24 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:33:24 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:33:24 --> Utf8 Class Initialized
INFO - 2023-05-25 07:33:24 --> URI Class Initialized
INFO - 2023-05-25 07:33:24 --> Router Class Initialized
INFO - 2023-05-25 07:33:24 --> Output Class Initialized
INFO - 2023-05-25 07:33:24 --> Security Class Initialized
DEBUG - 2023-05-25 07:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:33:24 --> Input Class Initialized
INFO - 2023-05-25 07:33:24 --> Language Class Initialized
INFO - 2023-05-25 07:33:24 --> Loader Class Initialized
INFO - 2023-05-25 07:33:24 --> Controller Class Initialized
DEBUG - 2023-05-25 07:33:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:33:24 --> Database Driver Class Initialized
INFO - 2023-05-25 07:33:25 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:33:25 --> Final output sent to browser
DEBUG - 2023-05-25 07:33:25 --> Total execution time: 0.2483
INFO - 2023-05-25 07:33:33 --> Final output sent to browser
DEBUG - 2023-05-25 07:33:33 --> Total execution time: 8.9502
INFO - 2023-05-25 07:33:33 --> Config Class Initialized
INFO - 2023-05-25 07:33:33 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:33:33 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:33:33 --> Utf8 Class Initialized
INFO - 2023-05-25 07:33:33 --> URI Class Initialized
INFO - 2023-05-25 07:33:33 --> Router Class Initialized
INFO - 2023-05-25 07:33:33 --> Output Class Initialized
INFO - 2023-05-25 07:33:33 --> Security Class Initialized
DEBUG - 2023-05-25 07:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:33:33 --> Input Class Initialized
INFO - 2023-05-25 07:33:33 --> Language Class Initialized
INFO - 2023-05-25 07:33:33 --> Loader Class Initialized
INFO - 2023-05-25 07:33:33 --> Controller Class Initialized
DEBUG - 2023-05-25 07:33:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:33:33 --> Database Driver Class Initialized
INFO - 2023-05-25 07:33:33 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:33:33 --> Database Driver Class Initialized
INFO - 2023-05-25 07:33:33 --> Model "Login_model" initialized
INFO - 2023-05-25 07:33:42 --> Final output sent to browser
DEBUG - 2023-05-25 07:33:42 --> Total execution time: 9.0515
INFO - 2023-05-25 07:34:24 --> Config Class Initialized
INFO - 2023-05-25 07:34:24 --> Config Class Initialized
INFO - 2023-05-25 07:34:24 --> Hooks Class Initialized
INFO - 2023-05-25 07:34:24 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:34:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:34:24 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:34:24 --> Utf8 Class Initialized
INFO - 2023-05-25 07:34:24 --> Utf8 Class Initialized
INFO - 2023-05-25 07:34:24 --> URI Class Initialized
INFO - 2023-05-25 07:34:24 --> URI Class Initialized
INFO - 2023-05-25 07:34:24 --> Router Class Initialized
INFO - 2023-05-25 07:34:24 --> Router Class Initialized
INFO - 2023-05-25 07:34:24 --> Output Class Initialized
INFO - 2023-05-25 07:34:24 --> Output Class Initialized
INFO - 2023-05-25 07:34:24 --> Security Class Initialized
INFO - 2023-05-25 07:34:24 --> Security Class Initialized
DEBUG - 2023-05-25 07:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:34:24 --> Input Class Initialized
INFO - 2023-05-25 07:34:24 --> Input Class Initialized
INFO - 2023-05-25 07:34:24 --> Language Class Initialized
INFO - 2023-05-25 07:34:24 --> Language Class Initialized
INFO - 2023-05-25 07:34:25 --> Loader Class Initialized
INFO - 2023-05-25 07:34:25 --> Loader Class Initialized
INFO - 2023-05-25 07:34:25 --> Controller Class Initialized
INFO - 2023-05-25 07:34:25 --> Controller Class Initialized
DEBUG - 2023-05-25 07:34:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:34:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:34:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:34:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:34:25 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:34:25 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:34:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:34:25 --> Model "Login_model" initialized
INFO - 2023-05-25 07:34:25 --> Final output sent to browser
DEBUG - 2023-05-25 07:34:25 --> Total execution time: 0.9236
INFO - 2023-05-25 07:34:25 --> Config Class Initialized
INFO - 2023-05-25 07:34:25 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:34:25 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:34:25 --> Utf8 Class Initialized
INFO - 2023-05-25 07:34:25 --> URI Class Initialized
INFO - 2023-05-25 07:34:25 --> Router Class Initialized
INFO - 2023-05-25 07:34:25 --> Output Class Initialized
INFO - 2023-05-25 07:34:25 --> Security Class Initialized
DEBUG - 2023-05-25 07:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:34:25 --> Input Class Initialized
INFO - 2023-05-25 07:34:25 --> Language Class Initialized
INFO - 2023-05-25 07:34:25 --> Loader Class Initialized
INFO - 2023-05-25 07:34:25 --> Controller Class Initialized
DEBUG - 2023-05-25 07:34:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:34:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:34:25 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:34:26 --> Final output sent to browser
DEBUG - 2023-05-25 07:34:26 --> Total execution time: 0.9591
INFO - 2023-05-25 07:34:36 --> Final output sent to browser
DEBUG - 2023-05-25 07:34:36 --> Total execution time: 11.4179
INFO - 2023-05-25 07:34:36 --> Config Class Initialized
INFO - 2023-05-25 07:34:36 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:34:36 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:34:36 --> Utf8 Class Initialized
INFO - 2023-05-25 07:34:36 --> URI Class Initialized
INFO - 2023-05-25 07:34:36 --> Router Class Initialized
INFO - 2023-05-25 07:34:36 --> Output Class Initialized
INFO - 2023-05-25 07:34:36 --> Security Class Initialized
DEBUG - 2023-05-25 07:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:34:36 --> Input Class Initialized
INFO - 2023-05-25 07:34:36 --> Language Class Initialized
INFO - 2023-05-25 07:34:36 --> Loader Class Initialized
INFO - 2023-05-25 07:34:36 --> Controller Class Initialized
DEBUG - 2023-05-25 07:34:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:34:36 --> Database Driver Class Initialized
INFO - 2023-05-25 07:34:36 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:34:36 --> Database Driver Class Initialized
INFO - 2023-05-25 07:34:36 --> Model "Login_model" initialized
INFO - 2023-05-25 07:35:11 --> Final output sent to browser
DEBUG - 2023-05-25 07:35:11 --> Total execution time: 34.8574
INFO - 2023-05-25 07:35:25 --> Config Class Initialized
INFO - 2023-05-25 07:35:25 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:35:25 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:35:25 --> Utf8 Class Initialized
INFO - 2023-05-25 07:35:25 --> URI Class Initialized
INFO - 2023-05-25 07:35:25 --> Router Class Initialized
INFO - 2023-05-25 07:35:25 --> Output Class Initialized
INFO - 2023-05-25 07:35:25 --> Security Class Initialized
DEBUG - 2023-05-25 07:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:35:25 --> Input Class Initialized
INFO - 2023-05-25 07:35:25 --> Language Class Initialized
INFO - 2023-05-25 07:35:25 --> Loader Class Initialized
INFO - 2023-05-25 07:35:25 --> Controller Class Initialized
DEBUG - 2023-05-25 07:35:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:35:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:35:25 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:35:25 --> Final output sent to browser
DEBUG - 2023-05-25 07:35:25 --> Total execution time: 0.7570
INFO - 2023-05-25 07:35:26 --> Config Class Initialized
INFO - 2023-05-25 07:35:26 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:35:26 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:35:26 --> Utf8 Class Initialized
INFO - 2023-05-25 07:35:26 --> URI Class Initialized
INFO - 2023-05-25 07:35:26 --> Router Class Initialized
INFO - 2023-05-25 07:35:26 --> Output Class Initialized
INFO - 2023-05-25 07:35:26 --> Security Class Initialized
DEBUG - 2023-05-25 07:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:35:26 --> Input Class Initialized
INFO - 2023-05-25 07:35:26 --> Language Class Initialized
INFO - 2023-05-25 07:35:26 --> Loader Class Initialized
INFO - 2023-05-25 07:35:26 --> Controller Class Initialized
DEBUG - 2023-05-25 07:35:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:35:26 --> Config Class Initialized
INFO - 2023-05-25 07:35:26 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:35:26 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:35:26 --> Utf8 Class Initialized
INFO - 2023-05-25 07:35:26 --> Database Driver Class Initialized
INFO - 2023-05-25 07:35:26 --> URI Class Initialized
INFO - 2023-05-25 07:35:26 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:35:26 --> Router Class Initialized
INFO - 2023-05-25 07:35:26 --> Output Class Initialized
INFO - 2023-05-25 07:35:26 --> Security Class Initialized
DEBUG - 2023-05-25 07:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:35:26 --> Input Class Initialized
INFO - 2023-05-25 07:35:26 --> Language Class Initialized
INFO - 2023-05-25 07:35:26 --> Final output sent to browser
DEBUG - 2023-05-25 07:35:26 --> Total execution time: 0.3122
INFO - 2023-05-25 07:35:26 --> Loader Class Initialized
INFO - 2023-05-25 07:35:26 --> Controller Class Initialized
DEBUG - 2023-05-25 07:35:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:35:26 --> Database Driver Class Initialized
INFO - 2023-05-25 07:35:26 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:35:26 --> Database Driver Class Initialized
INFO - 2023-05-25 07:35:26 --> Model "Login_model" initialized
INFO - 2023-05-25 07:35:41 --> Final output sent to browser
DEBUG - 2023-05-25 07:35:41 --> Total execution time: 15.7659
INFO - 2023-05-25 07:35:41 --> Config Class Initialized
INFO - 2023-05-25 07:35:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:35:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:35:42 --> Utf8 Class Initialized
INFO - 2023-05-25 07:35:42 --> URI Class Initialized
INFO - 2023-05-25 07:35:42 --> Router Class Initialized
INFO - 2023-05-25 07:35:42 --> Output Class Initialized
INFO - 2023-05-25 07:35:42 --> Security Class Initialized
DEBUG - 2023-05-25 07:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:35:42 --> Input Class Initialized
INFO - 2023-05-25 07:35:42 --> Language Class Initialized
INFO - 2023-05-25 07:35:42 --> Loader Class Initialized
INFO - 2023-05-25 07:35:42 --> Controller Class Initialized
DEBUG - 2023-05-25 07:35:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:35:42 --> Database Driver Class Initialized
INFO - 2023-05-25 07:35:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:35:42 --> Database Driver Class Initialized
INFO - 2023-05-25 07:35:42 --> Model "Login_model" initialized
INFO - 2023-05-25 07:35:57 --> Final output sent to browser
DEBUG - 2023-05-25 07:35:57 --> Total execution time: 15.8659
INFO - 2023-05-25 07:36:24 --> Config Class Initialized
INFO - 2023-05-25 07:36:24 --> Hooks Class Initialized
INFO - 2023-05-25 07:36:24 --> Config Class Initialized
INFO - 2023-05-25 07:36:24 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:36:24 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:36:24 --> Utf8 Class Initialized
DEBUG - 2023-05-25 07:36:24 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:36:24 --> URI Class Initialized
INFO - 2023-05-25 07:36:24 --> Utf8 Class Initialized
INFO - 2023-05-25 07:36:24 --> URI Class Initialized
INFO - 2023-05-25 07:36:24 --> Router Class Initialized
INFO - 2023-05-25 07:36:24 --> Output Class Initialized
INFO - 2023-05-25 07:36:24 --> Router Class Initialized
INFO - 2023-05-25 07:36:24 --> Security Class Initialized
INFO - 2023-05-25 07:36:24 --> Output Class Initialized
DEBUG - 2023-05-25 07:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:36:24 --> Input Class Initialized
INFO - 2023-05-25 07:36:24 --> Security Class Initialized
INFO - 2023-05-25 07:36:24 --> Language Class Initialized
DEBUG - 2023-05-25 07:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:36:24 --> Input Class Initialized
INFO - 2023-05-25 07:36:24 --> Language Class Initialized
INFO - 2023-05-25 07:36:24 --> Loader Class Initialized
INFO - 2023-05-25 07:36:24 --> Controller Class Initialized
DEBUG - 2023-05-25 07:36:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:36:25 --> Loader Class Initialized
INFO - 2023-05-25 07:36:25 --> Controller Class Initialized
DEBUG - 2023-05-25 07:36:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:36:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:36:25 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:36:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:36:25 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:36:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:36:25 --> Model "Login_model" initialized
INFO - 2023-05-25 07:36:29 --> Final output sent to browser
DEBUG - 2023-05-25 07:36:29 --> Total execution time: 5.0372
INFO - 2023-05-25 07:36:29 --> Config Class Initialized
INFO - 2023-05-25 07:36:29 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:36:29 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:36:29 --> Utf8 Class Initialized
INFO - 2023-05-25 07:36:30 --> URI Class Initialized
INFO - 2023-05-25 07:36:30 --> Router Class Initialized
INFO - 2023-05-25 07:36:30 --> Output Class Initialized
INFO - 2023-05-25 07:36:30 --> Security Class Initialized
DEBUG - 2023-05-25 07:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:36:30 --> Input Class Initialized
INFO - 2023-05-25 07:36:30 --> Language Class Initialized
INFO - 2023-05-25 07:36:30 --> Loader Class Initialized
INFO - 2023-05-25 07:36:30 --> Controller Class Initialized
DEBUG - 2023-05-25 07:36:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:36:30 --> Database Driver Class Initialized
INFO - 2023-05-25 07:36:30 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:36:33 --> Final output sent to browser
DEBUG - 2023-05-25 07:36:33 --> Total execution time: 3.7177
INFO - 2023-05-25 07:36:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:36:40 --> Total execution time: 15.8560
INFO - 2023-05-25 07:36:40 --> Config Class Initialized
INFO - 2023-05-25 07:36:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:36:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:36:40 --> Utf8 Class Initialized
INFO - 2023-05-25 07:36:40 --> URI Class Initialized
INFO - 2023-05-25 07:36:40 --> Router Class Initialized
INFO - 2023-05-25 07:36:40 --> Output Class Initialized
INFO - 2023-05-25 07:36:40 --> Security Class Initialized
DEBUG - 2023-05-25 07:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:36:40 --> Input Class Initialized
INFO - 2023-05-25 07:36:40 --> Language Class Initialized
INFO - 2023-05-25 07:36:40 --> Loader Class Initialized
INFO - 2023-05-25 07:36:40 --> Controller Class Initialized
DEBUG - 2023-05-25 07:36:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:36:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:36:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:36:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:36:40 --> Model "Login_model" initialized
INFO - 2023-05-25 07:36:56 --> Final output sent to browser
DEBUG - 2023-05-25 07:36:56 --> Total execution time: 16.0416
INFO - 2023-05-25 07:37:25 --> Config Class Initialized
INFO - 2023-05-25 07:37:25 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:37:25 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:37:25 --> Utf8 Class Initialized
INFO - 2023-05-25 07:37:25 --> URI Class Initialized
INFO - 2023-05-25 07:37:25 --> Router Class Initialized
INFO - 2023-05-25 07:37:25 --> Output Class Initialized
INFO - 2023-05-25 07:37:25 --> Security Class Initialized
DEBUG - 2023-05-25 07:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:37:25 --> Input Class Initialized
INFO - 2023-05-25 07:37:25 --> Language Class Initialized
INFO - 2023-05-25 07:37:25 --> Loader Class Initialized
INFO - 2023-05-25 07:37:25 --> Controller Class Initialized
DEBUG - 2023-05-25 07:37:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:37:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:37:25 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:37:25 --> Final output sent to browser
DEBUG - 2023-05-25 07:37:25 --> Total execution time: 0.3150
INFO - 2023-05-25 07:37:25 --> Config Class Initialized
INFO - 2023-05-25 07:37:25 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:37:25 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:37:25 --> Utf8 Class Initialized
INFO - 2023-05-25 07:37:25 --> URI Class Initialized
INFO - 2023-05-25 07:37:25 --> Router Class Initialized
INFO - 2023-05-25 07:37:25 --> Output Class Initialized
INFO - 2023-05-25 07:37:25 --> Security Class Initialized
DEBUG - 2023-05-25 07:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:37:25 --> Input Class Initialized
INFO - 2023-05-25 07:37:25 --> Language Class Initialized
INFO - 2023-05-25 07:37:25 --> Loader Class Initialized
INFO - 2023-05-25 07:37:25 --> Controller Class Initialized
DEBUG - 2023-05-25 07:37:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:37:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:37:25 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:37:25 --> Final output sent to browser
DEBUG - 2023-05-25 07:37:25 --> Total execution time: 0.3729
INFO - 2023-05-25 07:37:26 --> Config Class Initialized
INFO - 2023-05-25 07:37:26 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:37:26 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:37:26 --> Utf8 Class Initialized
INFO - 2023-05-25 07:37:26 --> URI Class Initialized
INFO - 2023-05-25 07:37:26 --> Router Class Initialized
INFO - 2023-05-25 07:37:26 --> Output Class Initialized
INFO - 2023-05-25 07:37:26 --> Security Class Initialized
DEBUG - 2023-05-25 07:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:37:26 --> Input Class Initialized
INFO - 2023-05-25 07:37:26 --> Language Class Initialized
INFO - 2023-05-25 07:37:26 --> Loader Class Initialized
INFO - 2023-05-25 07:37:26 --> Controller Class Initialized
DEBUG - 2023-05-25 07:37:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:37:26 --> Database Driver Class Initialized
INFO - 2023-05-25 07:37:26 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:37:26 --> Database Driver Class Initialized
INFO - 2023-05-25 07:37:26 --> Model "Login_model" initialized
INFO - 2023-05-25 07:37:34 --> Final output sent to browser
DEBUG - 2023-05-25 07:37:34 --> Total execution time: 8.3836
INFO - 2023-05-25 07:37:34 --> Config Class Initialized
INFO - 2023-05-25 07:37:34 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:37:34 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:37:34 --> Utf8 Class Initialized
INFO - 2023-05-25 07:37:34 --> URI Class Initialized
INFO - 2023-05-25 07:37:34 --> Router Class Initialized
INFO - 2023-05-25 07:37:34 --> Output Class Initialized
INFO - 2023-05-25 07:37:34 --> Security Class Initialized
DEBUG - 2023-05-25 07:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:37:34 --> Input Class Initialized
INFO - 2023-05-25 07:37:34 --> Language Class Initialized
INFO - 2023-05-25 07:37:34 --> Loader Class Initialized
INFO - 2023-05-25 07:37:34 --> Controller Class Initialized
DEBUG - 2023-05-25 07:37:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:37:34 --> Database Driver Class Initialized
INFO - 2023-05-25 07:37:34 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:37:34 --> Database Driver Class Initialized
INFO - 2023-05-25 07:37:34 --> Model "Login_model" initialized
INFO - 2023-05-25 07:37:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:37:40 --> Total execution time: 6.2262
INFO - 2023-05-25 07:38:25 --> Config Class Initialized
INFO - 2023-05-25 07:38:25 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:38:25 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:38:25 --> Utf8 Class Initialized
INFO - 2023-05-25 07:38:25 --> URI Class Initialized
INFO - 2023-05-25 07:38:25 --> Router Class Initialized
INFO - 2023-05-25 07:38:25 --> Output Class Initialized
INFO - 2023-05-25 07:38:25 --> Security Class Initialized
DEBUG - 2023-05-25 07:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:38:25 --> Input Class Initialized
INFO - 2023-05-25 07:38:25 --> Language Class Initialized
INFO - 2023-05-25 07:38:25 --> Loader Class Initialized
INFO - 2023-05-25 07:38:25 --> Controller Class Initialized
DEBUG - 2023-05-25 07:38:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:38:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:38:25 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:38:25 --> Final output sent to browser
DEBUG - 2023-05-25 07:38:25 --> Total execution time: 0.2549
INFO - 2023-05-25 07:38:25 --> Config Class Initialized
INFO - 2023-05-25 07:38:25 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:38:25 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:38:25 --> Utf8 Class Initialized
INFO - 2023-05-25 07:38:25 --> URI Class Initialized
INFO - 2023-05-25 07:38:25 --> Router Class Initialized
INFO - 2023-05-25 07:38:25 --> Output Class Initialized
INFO - 2023-05-25 07:38:25 --> Security Class Initialized
DEBUG - 2023-05-25 07:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:38:25 --> Input Class Initialized
INFO - 2023-05-25 07:38:25 --> Language Class Initialized
INFO - 2023-05-25 07:38:25 --> Loader Class Initialized
INFO - 2023-05-25 07:38:25 --> Controller Class Initialized
DEBUG - 2023-05-25 07:38:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:38:25 --> Database Driver Class Initialized
INFO - 2023-05-25 07:38:25 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:38:25 --> Final output sent to browser
DEBUG - 2023-05-25 07:38:25 --> Total execution time: 0.2775
INFO - 2023-05-25 07:38:26 --> Config Class Initialized
INFO - 2023-05-25 07:38:26 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:38:26 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:38:26 --> Utf8 Class Initialized
INFO - 2023-05-25 07:38:26 --> URI Class Initialized
INFO - 2023-05-25 07:38:26 --> Router Class Initialized
INFO - 2023-05-25 07:38:26 --> Output Class Initialized
INFO - 2023-05-25 07:38:26 --> Security Class Initialized
DEBUG - 2023-05-25 07:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:38:26 --> Input Class Initialized
INFO - 2023-05-25 07:38:26 --> Language Class Initialized
INFO - 2023-05-25 07:38:26 --> Loader Class Initialized
INFO - 2023-05-25 07:38:26 --> Controller Class Initialized
DEBUG - 2023-05-25 07:38:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:38:26 --> Database Driver Class Initialized
INFO - 2023-05-25 07:38:26 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:38:26 --> Database Driver Class Initialized
INFO - 2023-05-25 07:38:26 --> Model "Login_model" initialized
INFO - 2023-05-25 07:38:36 --> Final output sent to browser
DEBUG - 2023-05-25 07:38:36 --> Total execution time: 10.5777
INFO - 2023-05-25 07:38:36 --> Config Class Initialized
INFO - 2023-05-25 07:38:36 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:38:36 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:38:36 --> Utf8 Class Initialized
INFO - 2023-05-25 07:38:36 --> URI Class Initialized
INFO - 2023-05-25 07:38:36 --> Router Class Initialized
INFO - 2023-05-25 07:38:36 --> Output Class Initialized
INFO - 2023-05-25 07:38:36 --> Security Class Initialized
DEBUG - 2023-05-25 07:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:38:36 --> Input Class Initialized
INFO - 2023-05-25 07:38:36 --> Language Class Initialized
INFO - 2023-05-25 07:38:36 --> Loader Class Initialized
INFO - 2023-05-25 07:38:36 --> Controller Class Initialized
DEBUG - 2023-05-25 07:38:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:38:36 --> Database Driver Class Initialized
INFO - 2023-05-25 07:38:36 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:38:36 --> Database Driver Class Initialized
INFO - 2023-05-25 07:38:37 --> Model "Login_model" initialized
INFO - 2023-05-25 07:38:46 --> Final output sent to browser
DEBUG - 2023-05-25 07:38:46 --> Total execution time: 9.9113
INFO - 2023-05-25 07:39:27 --> Config Class Initialized
INFO - 2023-05-25 07:39:27 --> Config Class Initialized
INFO - 2023-05-25 07:39:27 --> Hooks Class Initialized
INFO - 2023-05-25 07:39:27 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:39:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:39:27 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:39:27 --> Utf8 Class Initialized
INFO - 2023-05-25 07:39:27 --> Utf8 Class Initialized
INFO - 2023-05-25 07:39:27 --> URI Class Initialized
INFO - 2023-05-25 07:39:27 --> URI Class Initialized
INFO - 2023-05-25 07:39:27 --> Router Class Initialized
INFO - 2023-05-25 07:39:27 --> Router Class Initialized
INFO - 2023-05-25 07:39:27 --> Output Class Initialized
INFO - 2023-05-25 07:39:27 --> Output Class Initialized
INFO - 2023-05-25 07:39:27 --> Security Class Initialized
INFO - 2023-05-25 07:39:27 --> Security Class Initialized
DEBUG - 2023-05-25 07:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:39:27 --> Input Class Initialized
INFO - 2023-05-25 07:39:27 --> Input Class Initialized
INFO - 2023-05-25 07:39:28 --> Language Class Initialized
INFO - 2023-05-25 07:39:28 --> Language Class Initialized
INFO - 2023-05-25 07:39:28 --> Loader Class Initialized
INFO - 2023-05-25 07:39:28 --> Loader Class Initialized
INFO - 2023-05-25 07:39:28 --> Controller Class Initialized
DEBUG - 2023-05-25 07:39:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:39:28 --> Controller Class Initialized
DEBUG - 2023-05-25 07:39:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:39:28 --> Database Driver Class Initialized
INFO - 2023-05-25 07:39:28 --> Database Driver Class Initialized
INFO - 2023-05-25 07:39:28 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:39:28 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:39:28 --> Database Driver Class Initialized
INFO - 2023-05-25 07:39:28 --> Model "Login_model" initialized
INFO - 2023-05-25 07:39:29 --> Final output sent to browser
DEBUG - 2023-05-25 07:39:29 --> Total execution time: 1.1642
INFO - 2023-05-25 07:39:29 --> Config Class Initialized
INFO - 2023-05-25 07:39:29 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:39:29 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:39:29 --> Utf8 Class Initialized
INFO - 2023-05-25 07:39:29 --> URI Class Initialized
INFO - 2023-05-25 07:39:29 --> Router Class Initialized
INFO - 2023-05-25 07:39:29 --> Output Class Initialized
INFO - 2023-05-25 07:39:29 --> Security Class Initialized
DEBUG - 2023-05-25 07:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:39:29 --> Input Class Initialized
INFO - 2023-05-25 07:39:29 --> Language Class Initialized
INFO - 2023-05-25 07:39:29 --> Loader Class Initialized
INFO - 2023-05-25 07:39:29 --> Controller Class Initialized
DEBUG - 2023-05-25 07:39:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:39:29 --> Database Driver Class Initialized
INFO - 2023-05-25 07:39:31 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:39:34 --> Config Class Initialized
INFO - 2023-05-25 07:39:34 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:39:34 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:39:34 --> Utf8 Class Initialized
INFO - 2023-05-25 07:39:34 --> URI Class Initialized
INFO - 2023-05-25 07:39:34 --> Router Class Initialized
INFO - 2023-05-25 07:39:34 --> Output Class Initialized
INFO - 2023-05-25 07:39:34 --> Security Class Initialized
DEBUG - 2023-05-25 07:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:39:34 --> Input Class Initialized
INFO - 2023-05-25 07:39:34 --> Language Class Initialized
INFO - 2023-05-25 07:39:34 --> Loader Class Initialized
INFO - 2023-05-25 07:39:34 --> Controller Class Initialized
DEBUG - 2023-05-25 07:39:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:39:34 --> Database Driver Class Initialized
INFO - 2023-05-25 07:39:36 --> Final output sent to browser
DEBUG - 2023-05-25 07:39:36 --> Total execution time: 6.9682
INFO - 2023-05-25 07:39:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:39:42 --> Final output sent to browser
DEBUG - 2023-05-25 07:39:42 --> Total execution time: 8.0876
INFO - 2023-05-25 07:39:42 --> Config Class Initialized
INFO - 2023-05-25 07:39:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:39:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:39:42 --> Utf8 Class Initialized
INFO - 2023-05-25 07:39:42 --> URI Class Initialized
INFO - 2023-05-25 07:39:42 --> Router Class Initialized
INFO - 2023-05-25 07:39:42 --> Output Class Initialized
INFO - 2023-05-25 07:39:42 --> Security Class Initialized
DEBUG - 2023-05-25 07:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:39:42 --> Input Class Initialized
INFO - 2023-05-25 07:39:42 --> Language Class Initialized
INFO - 2023-05-25 07:39:42 --> Loader Class Initialized
INFO - 2023-05-25 07:39:42 --> Controller Class Initialized
DEBUG - 2023-05-25 07:39:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:39:42 --> Database Driver Class Initialized
INFO - 2023-05-25 07:39:44 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:39:45 --> Database Driver Class Initialized
INFO - 2023-05-25 07:39:46 --> Model "Login_model" initialized
INFO - 2023-05-25 07:39:46 --> Final output sent to browser
DEBUG - 2023-05-25 07:39:46 --> Total execution time: 3.7518
INFO - 2023-05-25 07:39:46 --> Config Class Initialized
INFO - 2023-05-25 07:39:46 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:39:46 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:39:46 --> Utf8 Class Initialized
INFO - 2023-05-25 07:39:46 --> URI Class Initialized
INFO - 2023-05-25 07:39:46 --> Router Class Initialized
INFO - 2023-05-25 07:39:46 --> Output Class Initialized
INFO - 2023-05-25 07:39:46 --> Security Class Initialized
DEBUG - 2023-05-25 07:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:39:46 --> Input Class Initialized
INFO - 2023-05-25 07:39:46 --> Language Class Initialized
INFO - 2023-05-25 07:39:46 --> Loader Class Initialized
INFO - 2023-05-25 07:39:46 --> Controller Class Initialized
DEBUG - 2023-05-25 07:39:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:39:46 --> Database Driver Class Initialized
INFO - 2023-05-25 07:39:46 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:39:50 --> Final output sent to browser
DEBUG - 2023-05-25 07:39:50 --> Total execution time: 3.5612
INFO - 2023-05-25 07:39:50 --> Config Class Initialized
INFO - 2023-05-25 07:39:50 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:39:50 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:39:50 --> Utf8 Class Initialized
INFO - 2023-05-25 07:39:50 --> URI Class Initialized
INFO - 2023-05-25 07:39:50 --> Router Class Initialized
INFO - 2023-05-25 07:39:50 --> Output Class Initialized
INFO - 2023-05-25 07:39:50 --> Security Class Initialized
DEBUG - 2023-05-25 07:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:39:50 --> Input Class Initialized
INFO - 2023-05-25 07:39:50 --> Language Class Initialized
INFO - 2023-05-25 07:39:50 --> Loader Class Initialized
INFO - 2023-05-25 07:39:50 --> Controller Class Initialized
DEBUG - 2023-05-25 07:39:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:39:50 --> Database Driver Class Initialized
INFO - 2023-05-25 07:39:54 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:39:54 --> Final output sent to browser
DEBUG - 2023-05-25 07:39:54 --> Total execution time: 4.7048
INFO - 2023-05-25 07:39:58 --> Final output sent to browser
DEBUG - 2023-05-25 07:39:58 --> Total execution time: 31.0712
INFO - 2023-05-25 07:39:59 --> Config Class Initialized
INFO - 2023-05-25 07:39:59 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:39:59 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:39:59 --> Utf8 Class Initialized
INFO - 2023-05-25 07:39:59 --> URI Class Initialized
INFO - 2023-05-25 07:39:59 --> Router Class Initialized
INFO - 2023-05-25 07:39:59 --> Output Class Initialized
INFO - 2023-05-25 07:39:59 --> Security Class Initialized
DEBUG - 2023-05-25 07:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:39:59 --> Input Class Initialized
INFO - 2023-05-25 07:39:59 --> Language Class Initialized
INFO - 2023-05-25 07:39:59 --> Loader Class Initialized
INFO - 2023-05-25 07:39:59 --> Controller Class Initialized
DEBUG - 2023-05-25 07:39:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:39:59 --> Database Driver Class Initialized
INFO - 2023-05-25 07:39:59 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:39:59 --> Database Driver Class Initialized
INFO - 2023-05-25 07:39:59 --> Model "Login_model" initialized
INFO - 2023-05-25 07:40:11 --> Final output sent to browser
DEBUG - 2023-05-25 07:40:11 --> Total execution time: 12.7601
INFO - 2023-05-25 07:40:24 --> Config Class Initialized
INFO - 2023-05-25 07:40:24 --> Config Class Initialized
INFO - 2023-05-25 07:40:24 --> Hooks Class Initialized
INFO - 2023-05-25 07:40:24 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:40:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:40:24 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:40:24 --> Utf8 Class Initialized
INFO - 2023-05-25 07:40:24 --> Utf8 Class Initialized
INFO - 2023-05-25 07:40:24 --> URI Class Initialized
INFO - 2023-05-25 07:40:24 --> URI Class Initialized
INFO - 2023-05-25 07:40:24 --> Router Class Initialized
INFO - 2023-05-25 07:40:24 --> Router Class Initialized
INFO - 2023-05-25 07:40:24 --> Output Class Initialized
INFO - 2023-05-25 07:40:24 --> Output Class Initialized
INFO - 2023-05-25 07:40:24 --> Security Class Initialized
INFO - 2023-05-25 07:40:24 --> Security Class Initialized
DEBUG - 2023-05-25 07:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:40:24 --> Input Class Initialized
INFO - 2023-05-25 07:40:24 --> Input Class Initialized
INFO - 2023-05-25 07:40:24 --> Language Class Initialized
INFO - 2023-05-25 07:40:24 --> Language Class Initialized
INFO - 2023-05-25 07:40:24 --> Loader Class Initialized
INFO - 2023-05-25 07:40:24 --> Controller Class Initialized
INFO - 2023-05-25 07:40:24 --> Loader Class Initialized
DEBUG - 2023-05-25 07:40:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:40:24 --> Controller Class Initialized
DEBUG - 2023-05-25 07:40:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:40:24 --> Database Driver Class Initialized
INFO - 2023-05-25 07:40:24 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:40:24 --> Database Driver Class Initialized
INFO - 2023-05-25 07:40:24 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:40:24 --> Database Driver Class Initialized
INFO - 2023-05-25 07:40:24 --> Model "Login_model" initialized
INFO - 2023-05-25 07:40:27 --> Final output sent to browser
DEBUG - 2023-05-25 07:40:27 --> Total execution time: 3.0831
INFO - 2023-05-25 07:40:27 --> Config Class Initialized
INFO - 2023-05-25 07:40:27 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:40:27 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:40:27 --> Utf8 Class Initialized
INFO - 2023-05-25 07:40:27 --> URI Class Initialized
INFO - 2023-05-25 07:40:27 --> Router Class Initialized
INFO - 2023-05-25 07:40:27 --> Output Class Initialized
INFO - 2023-05-25 07:40:27 --> Security Class Initialized
DEBUG - 2023-05-25 07:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:40:27 --> Input Class Initialized
INFO - 2023-05-25 07:40:27 --> Language Class Initialized
INFO - 2023-05-25 07:40:27 --> Loader Class Initialized
INFO - 2023-05-25 07:40:27 --> Controller Class Initialized
DEBUG - 2023-05-25 07:40:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:40:27 --> Database Driver Class Initialized
INFO - 2023-05-25 07:40:28 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:40:29 --> Final output sent to browser
DEBUG - 2023-05-25 07:40:29 --> Total execution time: 1.6527
INFO - 2023-05-25 07:40:38 --> Final output sent to browser
DEBUG - 2023-05-25 07:40:38 --> Total execution time: 14.1905
INFO - 2023-05-25 07:40:38 --> Config Class Initialized
INFO - 2023-05-25 07:40:38 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:40:38 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:40:38 --> Utf8 Class Initialized
INFO - 2023-05-25 07:40:38 --> URI Class Initialized
INFO - 2023-05-25 07:40:38 --> Router Class Initialized
INFO - 2023-05-25 07:40:38 --> Output Class Initialized
INFO - 2023-05-25 07:40:38 --> Security Class Initialized
DEBUG - 2023-05-25 07:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:40:38 --> Input Class Initialized
INFO - 2023-05-25 07:40:38 --> Language Class Initialized
INFO - 2023-05-25 07:40:38 --> Loader Class Initialized
INFO - 2023-05-25 07:40:38 --> Controller Class Initialized
DEBUG - 2023-05-25 07:40:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:40:38 --> Database Driver Class Initialized
INFO - 2023-05-25 07:40:38 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:40:38 --> Database Driver Class Initialized
INFO - 2023-05-25 07:40:38 --> Model "Login_model" initialized
INFO - 2023-05-25 07:40:59 --> Final output sent to browser
DEBUG - 2023-05-25 07:40:59 --> Total execution time: 21.2155
INFO - 2023-05-25 07:41:25 --> Config Class Initialized
INFO - 2023-05-25 07:41:25 --> Config Class Initialized
INFO - 2023-05-25 07:41:25 --> Hooks Class Initialized
INFO - 2023-05-25 07:41:25 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:41:25 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:41:25 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:41:25 --> Utf8 Class Initialized
INFO - 2023-05-25 07:41:25 --> Utf8 Class Initialized
INFO - 2023-05-25 07:41:25 --> URI Class Initialized
INFO - 2023-05-25 07:41:25 --> URI Class Initialized
INFO - 2023-05-25 07:41:25 --> Router Class Initialized
INFO - 2023-05-25 07:41:25 --> Router Class Initialized
INFO - 2023-05-25 07:41:25 --> Output Class Initialized
INFO - 2023-05-25 07:41:25 --> Output Class Initialized
INFO - 2023-05-25 07:41:25 --> Security Class Initialized
INFO - 2023-05-25 07:41:25 --> Security Class Initialized
DEBUG - 2023-05-25 07:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:41:25 --> Input Class Initialized
INFO - 2023-05-25 07:41:25 --> Input Class Initialized
INFO - 2023-05-25 07:41:25 --> Language Class Initialized
INFO - 2023-05-25 07:41:25 --> Language Class Initialized
INFO - 2023-05-25 07:41:25 --> Loader Class Initialized
INFO - 2023-05-25 07:41:25 --> Loader Class Initialized
INFO - 2023-05-25 07:41:26 --> Controller Class Initialized
INFO - 2023-05-25 07:41:26 --> Controller Class Initialized
DEBUG - 2023-05-25 07:41:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:41:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:41:26 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:26 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:26 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:41:26 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:41:26 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:26 --> Final output sent to browser
DEBUG - 2023-05-25 07:41:26 --> Total execution time: 1.3922
INFO - 2023-05-25 07:41:26 --> Model "Login_model" initialized
INFO - 2023-05-25 07:41:27 --> Config Class Initialized
INFO - 2023-05-25 07:41:27 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:41:27 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:41:27 --> Utf8 Class Initialized
INFO - 2023-05-25 07:41:27 --> URI Class Initialized
INFO - 2023-05-25 07:41:27 --> Router Class Initialized
INFO - 2023-05-25 07:41:27 --> Output Class Initialized
INFO - 2023-05-25 07:41:27 --> Security Class Initialized
DEBUG - 2023-05-25 07:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:41:27 --> Input Class Initialized
INFO - 2023-05-25 07:41:27 --> Language Class Initialized
INFO - 2023-05-25 07:41:27 --> Loader Class Initialized
INFO - 2023-05-25 07:41:27 --> Controller Class Initialized
DEBUG - 2023-05-25 07:41:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:41:28 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:28 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:41:28 --> Final output sent to browser
DEBUG - 2023-05-25 07:41:28 --> Total execution time: 1.6473
INFO - 2023-05-25 07:41:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:41:40 --> Total execution time: 15.3901
INFO - 2023-05-25 07:41:40 --> Config Class Initialized
INFO - 2023-05-25 07:41:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:41:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:41:40 --> Utf8 Class Initialized
INFO - 2023-05-25 07:41:40 --> URI Class Initialized
INFO - 2023-05-25 07:41:40 --> Router Class Initialized
INFO - 2023-05-25 07:41:40 --> Output Class Initialized
INFO - 2023-05-25 07:41:41 --> Security Class Initialized
DEBUG - 2023-05-25 07:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:41:41 --> Input Class Initialized
INFO - 2023-05-25 07:41:41 --> Language Class Initialized
INFO - 2023-05-25 07:41:41 --> Loader Class Initialized
INFO - 2023-05-25 07:41:41 --> Controller Class Initialized
DEBUG - 2023-05-25 07:41:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:41:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:41:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:41 --> Model "Login_model" initialized
INFO - 2023-05-25 07:41:48 --> Config Class Initialized
INFO - 2023-05-25 07:41:48 --> Config Class Initialized
INFO - 2023-05-25 07:41:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:41:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:41:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:41:48 --> Utf8 Class Initialized
DEBUG - 2023-05-25 07:41:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:41:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:41:48 --> URI Class Initialized
INFO - 2023-05-25 07:41:48 --> URI Class Initialized
INFO - 2023-05-25 07:41:48 --> Router Class Initialized
INFO - 2023-05-25 07:41:48 --> Output Class Initialized
INFO - 2023-05-25 07:41:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:41:48 --> Router Class Initialized
INFO - 2023-05-25 07:41:48 --> Input Class Initialized
INFO - 2023-05-25 07:41:48 --> Language Class Initialized
INFO - 2023-05-25 07:41:48 --> Output Class Initialized
INFO - 2023-05-25 07:41:48 --> Loader Class Initialized
INFO - 2023-05-25 07:41:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:41:48 --> Config Class Initialized
INFO - 2023-05-25 07:41:48 --> Input Class Initialized
INFO - 2023-05-25 07:41:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:41:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:41:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:41:48 --> Language Class Initialized
INFO - 2023-05-25 07:41:48 --> Database Driver Class Initialized
DEBUG - 2023-05-25 07:41:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:41:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:41:48 --> Loader Class Initialized
INFO - 2023-05-25 07:41:48 --> URI Class Initialized
INFO - 2023-05-25 07:41:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:41:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:41:48 --> Router Class Initialized
INFO - 2023-05-25 07:41:48 --> Model "Login_model" initialized
INFO - 2023-05-25 07:41:48 --> Output Class Initialized
INFO - 2023-05-25 07:41:49 --> Final output sent to browser
DEBUG - 2023-05-25 07:41:49 --> Total execution time: 0.7010
INFO - 2023-05-25 07:41:49 --> Security Class Initialized
DEBUG - 2023-05-25 07:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:41:49 --> Input Class Initialized
INFO - 2023-05-25 07:41:49 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:49 --> Language Class Initialized
INFO - 2023-05-25 07:41:49 --> Loader Class Initialized
INFO - 2023-05-25 07:41:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:41:49 --> Controller Class Initialized
INFO - 2023-05-25 07:41:49 --> Config Class Initialized
INFO - 2023-05-25 07:41:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:41:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:41:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:41:49 --> Utf8 Class Initialized
INFO - 2023-05-25 07:41:49 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:49 --> URI Class Initialized
INFO - 2023-05-25 07:41:49 --> Router Class Initialized
INFO - 2023-05-25 07:41:49 --> Output Class Initialized
INFO - 2023-05-25 07:41:49 --> Security Class Initialized
INFO - 2023-05-25 07:41:49 --> Final output sent to browser
DEBUG - 2023-05-25 07:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:41:49 --> Total execution time: 1.4539
INFO - 2023-05-25 07:41:49 --> Input Class Initialized
INFO - 2023-05-25 07:41:49 --> Language Class Initialized
INFO - 2023-05-25 07:41:49 --> Loader Class Initialized
INFO - 2023-05-25 07:41:49 --> Controller Class Initialized
DEBUG - 2023-05-25 07:41:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:41:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:41:49 --> Config Class Initialized
INFO - 2023-05-25 07:41:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:41:50 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:41:50 --> Utf8 Class Initialized
INFO - 2023-05-25 07:41:50 --> Final output sent to browser
INFO - 2023-05-25 07:41:50 --> URI Class Initialized
DEBUG - 2023-05-25 07:41:50 --> Total execution time: 1.3644
INFO - 2023-05-25 07:41:50 --> Router Class Initialized
INFO - 2023-05-25 07:41:50 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:50 --> Config Class Initialized
INFO - 2023-05-25 07:41:50 --> Output Class Initialized
INFO - 2023-05-25 07:41:50 --> Hooks Class Initialized
INFO - 2023-05-25 07:41:50 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:41:50 --> Security Class Initialized
DEBUG - 2023-05-25 07:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:41:50 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:41:50 --> Utf8 Class Initialized
INFO - 2023-05-25 07:41:50 --> Input Class Initialized
INFO - 2023-05-25 07:41:50 --> URI Class Initialized
INFO - 2023-05-25 07:41:50 --> Language Class Initialized
INFO - 2023-05-25 07:41:50 --> Config Class Initialized
INFO - 2023-05-25 07:41:50 --> Final output sent to browser
DEBUG - 2023-05-25 07:41:50 --> Total execution time: 1.2842
INFO - 2023-05-25 07:41:50 --> Hooks Class Initialized
INFO - 2023-05-25 07:41:50 --> Router Class Initialized
INFO - 2023-05-25 07:41:50 --> Loader Class Initialized
INFO - 2023-05-25 07:41:50 --> Output Class Initialized
DEBUG - 2023-05-25 07:41:50 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:41:50 --> Utf8 Class Initialized
INFO - 2023-05-25 07:41:50 --> Controller Class Initialized
DEBUG - 2023-05-25 07:41:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:41:50 --> URI Class Initialized
INFO - 2023-05-25 07:41:50 --> Security Class Initialized
INFO - 2023-05-25 07:41:50 --> Router Class Initialized
DEBUG - 2023-05-25 07:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:41:50 --> Input Class Initialized
INFO - 2023-05-25 07:41:50 --> Config Class Initialized
INFO - 2023-05-25 07:41:50 --> Output Class Initialized
INFO - 2023-05-25 07:41:50 --> Hooks Class Initialized
INFO - 2023-05-25 07:41:50 --> Language Class Initialized
INFO - 2023-05-25 07:41:50 --> Security Class Initialized
INFO - 2023-05-25 07:41:50 --> Database Driver Class Initialized
DEBUG - 2023-05-25 07:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:41:50 --> Input Class Initialized
INFO - 2023-05-25 07:41:50 --> Language Class Initialized
DEBUG - 2023-05-25 07:41:51 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:41:51 --> Utf8 Class Initialized
INFO - 2023-05-25 07:41:51 --> Loader Class Initialized
INFO - 2023-05-25 07:41:51 --> URI Class Initialized
INFO - 2023-05-25 07:41:51 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:51 --> Router Class Initialized
INFO - 2023-05-25 07:41:51 --> Loader Class Initialized
INFO - 2023-05-25 07:41:51 --> Model "Login_model" initialized
INFO - 2023-05-25 07:41:51 --> Controller Class Initialized
INFO - 2023-05-25 07:41:51 --> Controller Class Initialized
INFO - 2023-05-25 07:41:51 --> Output Class Initialized
DEBUG - 2023-05-25 07:41:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:41:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:41:51 --> Final output sent to browser
DEBUG - 2023-05-25 07:41:51 --> Total execution time: 1.4688
INFO - 2023-05-25 07:41:51 --> Security Class Initialized
DEBUG - 2023-05-25 07:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:41:51 --> Input Class Initialized
INFO - 2023-05-25 07:41:51 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:51 --> Language Class Initialized
INFO - 2023-05-25 07:41:51 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:51 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:41:51 --> Loader Class Initialized
INFO - 2023-05-25 07:41:51 --> Controller Class Initialized
INFO - 2023-05-25 07:41:51 --> Model "Cluster_model" initialized
DEBUG - 2023-05-25 07:41:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:41:51 --> Final output sent to browser
DEBUG - 2023-05-25 07:41:51 --> Total execution time: 1.1322
INFO - 2023-05-25 07:41:51 --> Database Driver Class Initialized
INFO - 2023-05-25 07:41:51 --> Final output sent to browser
DEBUG - 2023-05-25 07:41:51 --> Total execution time: 1.5562
INFO - 2023-05-25 07:41:51 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:41:52 --> Final output sent to browser
DEBUG - 2023-05-25 07:41:52 --> Total execution time: 1.6079
INFO - 2023-05-25 07:41:53 --> Final output sent to browser
DEBUG - 2023-05-25 07:41:53 --> Total execution time: 12.5056
INFO - 2023-05-25 07:42:48 --> Config Class Initialized
INFO - 2023-05-25 07:42:48 --> Config Class Initialized
INFO - 2023-05-25 07:42:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:42:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:42:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:42:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:42:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:42:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:42:48 --> URI Class Initialized
INFO - 2023-05-25 07:42:48 --> URI Class Initialized
INFO - 2023-05-25 07:42:48 --> Router Class Initialized
INFO - 2023-05-25 07:42:48 --> Router Class Initialized
INFO - 2023-05-25 07:42:48 --> Output Class Initialized
INFO - 2023-05-25 07:42:48 --> Output Class Initialized
INFO - 2023-05-25 07:42:48 --> Security Class Initialized
INFO - 2023-05-25 07:42:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:42:48 --> Input Class Initialized
INFO - 2023-05-25 07:42:48 --> Input Class Initialized
INFO - 2023-05-25 07:42:48 --> Language Class Initialized
INFO - 2023-05-25 07:42:48 --> Language Class Initialized
INFO - 2023-05-25 07:42:48 --> Loader Class Initialized
INFO - 2023-05-25 07:42:48 --> Loader Class Initialized
INFO - 2023-05-25 07:42:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:42:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:42:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:42:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:42:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:42:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:42:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:42:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:42:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:42:48 --> Model "Login_model" initialized
INFO - 2023-05-25 07:42:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:42:48 --> Total execution time: 0.2939
INFO - 2023-05-25 07:42:48 --> Config Class Initialized
INFO - 2023-05-25 07:42:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:42:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:42:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:42:48 --> URI Class Initialized
INFO - 2023-05-25 07:42:48 --> Router Class Initialized
INFO - 2023-05-25 07:42:48 --> Output Class Initialized
INFO - 2023-05-25 07:42:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:42:48 --> Input Class Initialized
INFO - 2023-05-25 07:42:48 --> Language Class Initialized
INFO - 2023-05-25 07:42:48 --> Loader Class Initialized
INFO - 2023-05-25 07:42:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:42:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:42:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:42:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:42:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:42:48 --> Total execution time: 0.2884
INFO - 2023-05-25 07:42:59 --> Final output sent to browser
DEBUG - 2023-05-25 07:42:59 --> Total execution time: 11.7131
INFO - 2023-05-25 07:42:59 --> Config Class Initialized
INFO - 2023-05-25 07:42:59 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:42:59 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:42:59 --> Utf8 Class Initialized
INFO - 2023-05-25 07:42:59 --> URI Class Initialized
INFO - 2023-05-25 07:42:59 --> Router Class Initialized
INFO - 2023-05-25 07:42:59 --> Output Class Initialized
INFO - 2023-05-25 07:42:59 --> Security Class Initialized
DEBUG - 2023-05-25 07:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:43:00 --> Input Class Initialized
INFO - 2023-05-25 07:43:00 --> Language Class Initialized
INFO - 2023-05-25 07:43:00 --> Loader Class Initialized
INFO - 2023-05-25 07:43:00 --> Controller Class Initialized
DEBUG - 2023-05-25 07:43:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:43:00 --> Database Driver Class Initialized
INFO - 2023-05-25 07:43:00 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:43:00 --> Database Driver Class Initialized
INFO - 2023-05-25 07:43:00 --> Model "Login_model" initialized
INFO - 2023-05-25 07:43:10 --> Final output sent to browser
DEBUG - 2023-05-25 07:43:10 --> Total execution time: 10.1955
INFO - 2023-05-25 07:43:48 --> Config Class Initialized
INFO - 2023-05-25 07:43:48 --> Config Class Initialized
INFO - 2023-05-25 07:43:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:43:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:43:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:43:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:43:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:43:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:43:48 --> URI Class Initialized
INFO - 2023-05-25 07:43:48 --> URI Class Initialized
INFO - 2023-05-25 07:43:48 --> Router Class Initialized
INFO - 2023-05-25 07:43:48 --> Router Class Initialized
INFO - 2023-05-25 07:43:48 --> Output Class Initialized
INFO - 2023-05-25 07:43:48 --> Output Class Initialized
INFO - 2023-05-25 07:43:48 --> Security Class Initialized
INFO - 2023-05-25 07:43:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:43:48 --> Input Class Initialized
INFO - 2023-05-25 07:43:48 --> Input Class Initialized
INFO - 2023-05-25 07:43:48 --> Language Class Initialized
INFO - 2023-05-25 07:43:48 --> Language Class Initialized
INFO - 2023-05-25 07:43:48 --> Loader Class Initialized
INFO - 2023-05-25 07:43:48 --> Loader Class Initialized
INFO - 2023-05-25 07:43:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:43:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:43:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:43:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:43:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:43:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:43:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:43:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:43:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:43:48 --> Model "Login_model" initialized
INFO - 2023-05-25 07:43:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:43:48 --> Total execution time: 0.2756
INFO - 2023-05-25 07:43:48 --> Config Class Initialized
INFO - 2023-05-25 07:43:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:43:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:43:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:43:48 --> URI Class Initialized
INFO - 2023-05-25 07:43:48 --> Router Class Initialized
INFO - 2023-05-25 07:43:48 --> Output Class Initialized
INFO - 2023-05-25 07:43:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:43:48 --> Input Class Initialized
INFO - 2023-05-25 07:43:48 --> Language Class Initialized
INFO - 2023-05-25 07:43:48 --> Loader Class Initialized
INFO - 2023-05-25 07:43:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:43:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:43:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:43:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:43:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:43:48 --> Total execution time: 0.3452
INFO - 2023-05-25 07:43:57 --> Final output sent to browser
DEBUG - 2023-05-25 07:43:57 --> Total execution time: 9.6480
INFO - 2023-05-25 07:43:57 --> Config Class Initialized
INFO - 2023-05-25 07:43:57 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:43:57 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:43:57 --> Utf8 Class Initialized
INFO - 2023-05-25 07:43:57 --> URI Class Initialized
INFO - 2023-05-25 07:43:57 --> Router Class Initialized
INFO - 2023-05-25 07:43:57 --> Output Class Initialized
INFO - 2023-05-25 07:43:57 --> Security Class Initialized
DEBUG - 2023-05-25 07:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:43:57 --> Input Class Initialized
INFO - 2023-05-25 07:43:57 --> Language Class Initialized
INFO - 2023-05-25 07:43:58 --> Loader Class Initialized
INFO - 2023-05-25 07:43:58 --> Controller Class Initialized
DEBUG - 2023-05-25 07:43:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:43:58 --> Database Driver Class Initialized
INFO - 2023-05-25 07:43:58 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:43:58 --> Database Driver Class Initialized
INFO - 2023-05-25 07:43:58 --> Model "Login_model" initialized
INFO - 2023-05-25 07:44:07 --> Final output sent to browser
DEBUG - 2023-05-25 07:44:07 --> Total execution time: 9.6064
INFO - 2023-05-25 07:44:48 --> Config Class Initialized
INFO - 2023-05-25 07:44:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:44:48 --> Config Class Initialized
INFO - 2023-05-25 07:44:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:44:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:44:48 --> Utf8 Class Initialized
DEBUG - 2023-05-25 07:44:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:44:48 --> URI Class Initialized
INFO - 2023-05-25 07:44:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:44:48 --> URI Class Initialized
INFO - 2023-05-25 07:44:48 --> Router Class Initialized
INFO - 2023-05-25 07:44:48 --> Router Class Initialized
INFO - 2023-05-25 07:44:48 --> Output Class Initialized
INFO - 2023-05-25 07:44:48 --> Output Class Initialized
INFO - 2023-05-25 07:44:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:44:48 --> Security Class Initialized
INFO - 2023-05-25 07:44:48 --> Input Class Initialized
DEBUG - 2023-05-25 07:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:44:48 --> Language Class Initialized
INFO - 2023-05-25 07:44:48 --> Input Class Initialized
INFO - 2023-05-25 07:44:48 --> Language Class Initialized
INFO - 2023-05-25 07:44:48 --> Loader Class Initialized
INFO - 2023-05-25 07:44:48 --> Controller Class Initialized
INFO - 2023-05-25 07:44:48 --> Loader Class Initialized
DEBUG - 2023-05-25 07:44:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:44:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:44:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:44:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:44:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:44:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:44:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:44:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:44:48 --> Model "Login_model" initialized
INFO - 2023-05-25 07:44:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:44:48 --> Total execution time: 0.3031
INFO - 2023-05-25 07:44:48 --> Config Class Initialized
INFO - 2023-05-25 07:44:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:44:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:44:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:44:48 --> URI Class Initialized
INFO - 2023-05-25 07:44:48 --> Router Class Initialized
INFO - 2023-05-25 07:44:48 --> Output Class Initialized
INFO - 2023-05-25 07:44:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:44:48 --> Input Class Initialized
INFO - 2023-05-25 07:44:48 --> Language Class Initialized
INFO - 2023-05-25 07:44:48 --> Loader Class Initialized
INFO - 2023-05-25 07:44:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:44:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:44:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:44:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:44:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:44:48 --> Total execution time: 0.2282
INFO - 2023-05-25 07:44:56 --> Final output sent to browser
DEBUG - 2023-05-25 07:44:56 --> Total execution time: 8.2965
INFO - 2023-05-25 07:44:56 --> Config Class Initialized
INFO - 2023-05-25 07:44:56 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:44:56 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:44:56 --> Utf8 Class Initialized
INFO - 2023-05-25 07:44:56 --> URI Class Initialized
INFO - 2023-05-25 07:44:56 --> Router Class Initialized
INFO - 2023-05-25 07:44:56 --> Output Class Initialized
INFO - 2023-05-25 07:44:56 --> Security Class Initialized
DEBUG - 2023-05-25 07:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:44:56 --> Input Class Initialized
INFO - 2023-05-25 07:44:56 --> Language Class Initialized
INFO - 2023-05-25 07:44:56 --> Loader Class Initialized
INFO - 2023-05-25 07:44:56 --> Controller Class Initialized
DEBUG - 2023-05-25 07:44:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:44:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:44:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:44:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:44:56 --> Model "Login_model" initialized
INFO - 2023-05-25 07:45:05 --> Final output sent to browser
DEBUG - 2023-05-25 07:45:05 --> Total execution time: 9.1616
INFO - 2023-05-25 07:45:48 --> Config Class Initialized
INFO - 2023-05-25 07:45:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:45:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:45:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:45:48 --> URI Class Initialized
INFO - 2023-05-25 07:45:48 --> Router Class Initialized
INFO - 2023-05-25 07:45:48 --> Output Class Initialized
INFO - 2023-05-25 07:45:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:45:48 --> Input Class Initialized
INFO - 2023-05-25 07:45:48 --> Language Class Initialized
INFO - 2023-05-25 07:45:48 --> Loader Class Initialized
INFO - 2023-05-25 07:45:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:45:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:45:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:45:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:45:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:45:48 --> Total execution time: 0.3096
INFO - 2023-05-25 07:45:48 --> Config Class Initialized
INFO - 2023-05-25 07:45:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:45:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:45:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:45:48 --> URI Class Initialized
INFO - 2023-05-25 07:45:48 --> Router Class Initialized
INFO - 2023-05-25 07:45:48 --> Output Class Initialized
INFO - 2023-05-25 07:45:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:45:48 --> Input Class Initialized
INFO - 2023-05-25 07:45:48 --> Language Class Initialized
INFO - 2023-05-25 07:45:48 --> Loader Class Initialized
INFO - 2023-05-25 07:45:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:45:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:45:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:45:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:45:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:45:48 --> Total execution time: 0.3713
INFO - 2023-05-25 07:45:49 --> Config Class Initialized
INFO - 2023-05-25 07:45:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:45:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:45:49 --> Utf8 Class Initialized
INFO - 2023-05-25 07:45:49 --> URI Class Initialized
INFO - 2023-05-25 07:45:49 --> Router Class Initialized
INFO - 2023-05-25 07:45:49 --> Output Class Initialized
INFO - 2023-05-25 07:45:49 --> Security Class Initialized
DEBUG - 2023-05-25 07:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:45:49 --> Input Class Initialized
INFO - 2023-05-25 07:45:49 --> Language Class Initialized
INFO - 2023-05-25 07:45:49 --> Loader Class Initialized
INFO - 2023-05-25 07:45:49 --> Controller Class Initialized
DEBUG - 2023-05-25 07:45:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:45:49 --> Database Driver Class Initialized
INFO - 2023-05-25 07:45:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:45:49 --> Database Driver Class Initialized
INFO - 2023-05-25 07:45:49 --> Model "Login_model" initialized
INFO - 2023-05-25 07:46:00 --> Final output sent to browser
DEBUG - 2023-05-25 07:46:00 --> Total execution time: 11.4612
INFO - 2023-05-25 07:46:00 --> Config Class Initialized
INFO - 2023-05-25 07:46:00 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:46:00 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:46:00 --> Utf8 Class Initialized
INFO - 2023-05-25 07:46:00 --> URI Class Initialized
INFO - 2023-05-25 07:46:00 --> Router Class Initialized
INFO - 2023-05-25 07:46:00 --> Output Class Initialized
INFO - 2023-05-25 07:46:00 --> Security Class Initialized
DEBUG - 2023-05-25 07:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:46:00 --> Input Class Initialized
INFO - 2023-05-25 07:46:00 --> Language Class Initialized
INFO - 2023-05-25 07:46:00 --> Loader Class Initialized
INFO - 2023-05-25 07:46:00 --> Controller Class Initialized
DEBUG - 2023-05-25 07:46:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:46:00 --> Database Driver Class Initialized
INFO - 2023-05-25 07:46:00 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:46:00 --> Database Driver Class Initialized
INFO - 2023-05-25 07:46:00 --> Model "Login_model" initialized
INFO - 2023-05-25 07:46:09 --> Final output sent to browser
DEBUG - 2023-05-25 07:46:09 --> Total execution time: 9.2971
INFO - 2023-05-25 07:47:38 --> Config Class Initialized
INFO - 2023-05-25 07:47:38 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:47:38 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:47:38 --> Utf8 Class Initialized
INFO - 2023-05-25 07:47:38 --> URI Class Initialized
INFO - 2023-05-25 07:47:38 --> Router Class Initialized
INFO - 2023-05-25 07:47:38 --> Output Class Initialized
INFO - 2023-05-25 07:47:38 --> Security Class Initialized
DEBUG - 2023-05-25 07:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:47:38 --> Input Class Initialized
INFO - 2023-05-25 07:47:38 --> Language Class Initialized
INFO - 2023-05-25 07:47:38 --> Loader Class Initialized
INFO - 2023-05-25 07:47:38 --> Controller Class Initialized
DEBUG - 2023-05-25 07:47:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:47:38 --> Database Driver Class Initialized
INFO - 2023-05-25 07:47:38 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:47:38 --> Final output sent to browser
DEBUG - 2023-05-25 07:47:38 --> Total execution time: 0.3359
INFO - 2023-05-25 07:47:38 --> Config Class Initialized
INFO - 2023-05-25 07:47:38 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:47:38 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:47:38 --> Utf8 Class Initialized
INFO - 2023-05-25 07:47:38 --> URI Class Initialized
INFO - 2023-05-25 07:47:38 --> Router Class Initialized
INFO - 2023-05-25 07:47:38 --> Output Class Initialized
INFO - 2023-05-25 07:47:38 --> Security Class Initialized
DEBUG - 2023-05-25 07:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:47:38 --> Input Class Initialized
INFO - 2023-05-25 07:47:38 --> Language Class Initialized
INFO - 2023-05-25 07:47:38 --> Loader Class Initialized
INFO - 2023-05-25 07:47:38 --> Controller Class Initialized
DEBUG - 2023-05-25 07:47:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:47:38 --> Database Driver Class Initialized
INFO - 2023-05-25 07:47:38 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:47:39 --> Final output sent to browser
DEBUG - 2023-05-25 07:47:39 --> Total execution time: 0.4733
INFO - 2023-05-25 07:47:39 --> Config Class Initialized
INFO - 2023-05-25 07:47:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:47:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:47:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:47:39 --> URI Class Initialized
INFO - 2023-05-25 07:47:39 --> Router Class Initialized
INFO - 2023-05-25 07:47:39 --> Output Class Initialized
INFO - 2023-05-25 07:47:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:47:39 --> Input Class Initialized
INFO - 2023-05-25 07:47:39 --> Language Class Initialized
INFO - 2023-05-25 07:47:39 --> Loader Class Initialized
INFO - 2023-05-25 07:47:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:47:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:47:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:47:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:47:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:47:39 --> Model "Login_model" initialized
INFO - 2023-05-25 07:47:49 --> Final output sent to browser
DEBUG - 2023-05-25 07:47:49 --> Total execution time: 10.6255
INFO - 2023-05-25 07:47:49 --> Config Class Initialized
INFO - 2023-05-25 07:47:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:47:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:47:49 --> Utf8 Class Initialized
INFO - 2023-05-25 07:47:49 --> URI Class Initialized
INFO - 2023-05-25 07:47:49 --> Router Class Initialized
INFO - 2023-05-25 07:47:49 --> Output Class Initialized
INFO - 2023-05-25 07:47:49 --> Security Class Initialized
DEBUG - 2023-05-25 07:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:47:49 --> Input Class Initialized
INFO - 2023-05-25 07:47:49 --> Language Class Initialized
INFO - 2023-05-25 07:47:49 --> Loader Class Initialized
INFO - 2023-05-25 07:47:49 --> Controller Class Initialized
DEBUG - 2023-05-25 07:47:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:47:50 --> Database Driver Class Initialized
INFO - 2023-05-25 07:47:50 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:47:50 --> Database Driver Class Initialized
INFO - 2023-05-25 07:47:50 --> Model "Login_model" initialized
INFO - 2023-05-25 07:47:59 --> Final output sent to browser
DEBUG - 2023-05-25 07:47:59 --> Total execution time: 9.6298
INFO - 2023-05-25 07:48:39 --> Config Class Initialized
INFO - 2023-05-25 07:48:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:48:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:48:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:48:39 --> URI Class Initialized
INFO - 2023-05-25 07:48:39 --> Router Class Initialized
INFO - 2023-05-25 07:48:39 --> Output Class Initialized
INFO - 2023-05-25 07:48:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:48:39 --> Input Class Initialized
INFO - 2023-05-25 07:48:39 --> Language Class Initialized
INFO - 2023-05-25 07:48:39 --> Loader Class Initialized
INFO - 2023-05-25 07:48:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:48:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:48:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:48:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:48:39 --> Final output sent to browser
DEBUG - 2023-05-25 07:48:39 --> Total execution time: 0.6175
INFO - 2023-05-25 07:48:39 --> Config Class Initialized
INFO - 2023-05-25 07:48:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:48:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:48:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:48:39 --> URI Class Initialized
INFO - 2023-05-25 07:48:39 --> Router Class Initialized
INFO - 2023-05-25 07:48:39 --> Output Class Initialized
INFO - 2023-05-25 07:48:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:48:39 --> Input Class Initialized
INFO - 2023-05-25 07:48:39 --> Language Class Initialized
INFO - 2023-05-25 07:48:39 --> Loader Class Initialized
INFO - 2023-05-25 07:48:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:48:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:48:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:48:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:48:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:48:40 --> Total execution time: 0.3812
INFO - 2023-05-25 07:49:39 --> Config Class Initialized
INFO - 2023-05-25 07:49:39 --> Config Class Initialized
INFO - 2023-05-25 07:49:39 --> Hooks Class Initialized
INFO - 2023-05-25 07:49:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:49:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:49:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:49:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:49:39 --> URI Class Initialized
INFO - 2023-05-25 07:49:39 --> URI Class Initialized
INFO - 2023-05-25 07:49:39 --> Router Class Initialized
INFO - 2023-05-25 07:49:39 --> Router Class Initialized
INFO - 2023-05-25 07:49:39 --> Output Class Initialized
INFO - 2023-05-25 07:49:39 --> Output Class Initialized
INFO - 2023-05-25 07:49:39 --> Security Class Initialized
INFO - 2023-05-25 07:49:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:49:39 --> Input Class Initialized
INFO - 2023-05-25 07:49:39 --> Input Class Initialized
INFO - 2023-05-25 07:49:39 --> Language Class Initialized
INFO - 2023-05-25 07:49:39 --> Language Class Initialized
INFO - 2023-05-25 07:49:39 --> Loader Class Initialized
INFO - 2023-05-25 07:49:39 --> Loader Class Initialized
INFO - 2023-05-25 07:49:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:49:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:49:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:49:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:49:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:49:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:49:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:49:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:49:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:49:39 --> Model "Login_model" initialized
INFO - 2023-05-25 07:49:39 --> Final output sent to browser
DEBUG - 2023-05-25 07:49:39 --> Total execution time: 0.3407
INFO - 2023-05-25 07:49:39 --> Config Class Initialized
INFO - 2023-05-25 07:49:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:49:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:49:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:49:39 --> URI Class Initialized
INFO - 2023-05-25 07:49:39 --> Router Class Initialized
INFO - 2023-05-25 07:49:39 --> Output Class Initialized
INFO - 2023-05-25 07:49:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:49:39 --> Input Class Initialized
INFO - 2023-05-25 07:49:39 --> Language Class Initialized
INFO - 2023-05-25 07:49:39 --> Loader Class Initialized
INFO - 2023-05-25 07:49:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:49:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:49:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:49:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:49:39 --> Final output sent to browser
DEBUG - 2023-05-25 07:49:39 --> Total execution time: 0.2599
INFO - 2023-05-25 07:49:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:49:48 --> Total execution time: 9.4346
INFO - 2023-05-25 07:49:48 --> Config Class Initialized
INFO - 2023-05-25 07:49:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:49:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:49:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:49:48 --> URI Class Initialized
INFO - 2023-05-25 07:49:48 --> Router Class Initialized
INFO - 2023-05-25 07:49:48 --> Output Class Initialized
INFO - 2023-05-25 07:49:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:49:48 --> Input Class Initialized
INFO - 2023-05-25 07:49:48 --> Language Class Initialized
INFO - 2023-05-25 07:49:48 --> Loader Class Initialized
INFO - 2023-05-25 07:49:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:49:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:49:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:49:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:49:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:49:48 --> Model "Login_model" initialized
INFO - 2023-05-25 07:49:59 --> Final output sent to browser
DEBUG - 2023-05-25 07:49:59 --> Total execution time: 10.6858
INFO - 2023-05-25 07:50:39 --> Config Class Initialized
INFO - 2023-05-25 07:50:39 --> Config Class Initialized
INFO - 2023-05-25 07:50:39 --> Hooks Class Initialized
INFO - 2023-05-25 07:50:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:50:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:50:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:50:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:50:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:50:39 --> URI Class Initialized
INFO - 2023-05-25 07:50:39 --> URI Class Initialized
INFO - 2023-05-25 07:50:39 --> Router Class Initialized
INFO - 2023-05-25 07:50:39 --> Router Class Initialized
INFO - 2023-05-25 07:50:39 --> Output Class Initialized
INFO - 2023-05-25 07:50:39 --> Output Class Initialized
INFO - 2023-05-25 07:50:39 --> Security Class Initialized
INFO - 2023-05-25 07:50:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:50:39 --> Input Class Initialized
INFO - 2023-05-25 07:50:39 --> Input Class Initialized
INFO - 2023-05-25 07:50:39 --> Language Class Initialized
INFO - 2023-05-25 07:50:39 --> Language Class Initialized
INFO - 2023-05-25 07:50:39 --> Loader Class Initialized
INFO - 2023-05-25 07:50:39 --> Loader Class Initialized
INFO - 2023-05-25 07:50:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:50:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:50:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:50:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:50:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:50:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:50:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:50:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:50:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:50:39 --> Model "Login_model" initialized
INFO - 2023-05-25 07:50:39 --> Final output sent to browser
DEBUG - 2023-05-25 07:50:39 --> Total execution time: 0.2452
INFO - 2023-05-25 07:50:39 --> Config Class Initialized
INFO - 2023-05-25 07:50:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:50:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:50:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:50:39 --> URI Class Initialized
INFO - 2023-05-25 07:50:39 --> Router Class Initialized
INFO - 2023-05-25 07:50:39 --> Output Class Initialized
INFO - 2023-05-25 07:50:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:50:39 --> Input Class Initialized
INFO - 2023-05-25 07:50:39 --> Language Class Initialized
INFO - 2023-05-25 07:50:39 --> Loader Class Initialized
INFO - 2023-05-25 07:50:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:50:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:50:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:50:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:50:39 --> Final output sent to browser
DEBUG - 2023-05-25 07:50:39 --> Total execution time: 0.2724
INFO - 2023-05-25 07:50:50 --> Final output sent to browser
DEBUG - 2023-05-25 07:50:50 --> Total execution time: 11.0276
INFO - 2023-05-25 07:50:50 --> Config Class Initialized
INFO - 2023-05-25 07:50:50 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:50:50 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:50:50 --> Utf8 Class Initialized
INFO - 2023-05-25 07:50:50 --> URI Class Initialized
INFO - 2023-05-25 07:50:50 --> Router Class Initialized
INFO - 2023-05-25 07:50:50 --> Output Class Initialized
INFO - 2023-05-25 07:50:50 --> Security Class Initialized
DEBUG - 2023-05-25 07:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:50:50 --> Input Class Initialized
INFO - 2023-05-25 07:50:50 --> Language Class Initialized
INFO - 2023-05-25 07:50:50 --> Loader Class Initialized
INFO - 2023-05-25 07:50:50 --> Controller Class Initialized
DEBUG - 2023-05-25 07:50:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:50:50 --> Database Driver Class Initialized
INFO - 2023-05-25 07:50:50 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:50:50 --> Database Driver Class Initialized
INFO - 2023-05-25 07:50:50 --> Model "Login_model" initialized
INFO - 2023-05-25 07:51:00 --> Final output sent to browser
DEBUG - 2023-05-25 07:51:00 --> Total execution time: 10.5237
INFO - 2023-05-25 07:51:39 --> Config Class Initialized
INFO - 2023-05-25 07:51:39 --> Config Class Initialized
INFO - 2023-05-25 07:51:39 --> Hooks Class Initialized
INFO - 2023-05-25 07:51:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:51:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:51:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:51:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:51:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:51:39 --> URI Class Initialized
INFO - 2023-05-25 07:51:39 --> URI Class Initialized
INFO - 2023-05-25 07:51:39 --> Router Class Initialized
INFO - 2023-05-25 07:51:39 --> Router Class Initialized
INFO - 2023-05-25 07:51:39 --> Output Class Initialized
INFO - 2023-05-25 07:51:39 --> Output Class Initialized
INFO - 2023-05-25 07:51:39 --> Security Class Initialized
INFO - 2023-05-25 07:51:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:51:39 --> Input Class Initialized
INFO - 2023-05-25 07:51:39 --> Input Class Initialized
INFO - 2023-05-25 07:51:39 --> Language Class Initialized
INFO - 2023-05-25 07:51:39 --> Language Class Initialized
INFO - 2023-05-25 07:51:39 --> Loader Class Initialized
INFO - 2023-05-25 07:51:39 --> Loader Class Initialized
INFO - 2023-05-25 07:51:39 --> Controller Class Initialized
INFO - 2023-05-25 07:51:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:51:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:51:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:51:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:51:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:51:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:51:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:51:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:51:39 --> Model "Login_model" initialized
INFO - 2023-05-25 07:51:39 --> Final output sent to browser
DEBUG - 2023-05-25 07:51:39 --> Total execution time: 0.3787
INFO - 2023-05-25 07:51:39 --> Config Class Initialized
INFO - 2023-05-25 07:51:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:51:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:51:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:51:39 --> URI Class Initialized
INFO - 2023-05-25 07:51:39 --> Router Class Initialized
INFO - 2023-05-25 07:51:39 --> Output Class Initialized
INFO - 2023-05-25 07:51:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:51:39 --> Input Class Initialized
INFO - 2023-05-25 07:51:39 --> Language Class Initialized
INFO - 2023-05-25 07:51:39 --> Loader Class Initialized
INFO - 2023-05-25 07:51:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:51:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:51:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:51:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:51:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:51:40 --> Total execution time: 0.4602
INFO - 2023-05-25 07:51:45 --> Final output sent to browser
DEBUG - 2023-05-25 07:51:45 --> Total execution time: 6.6334
INFO - 2023-05-25 07:51:45 --> Config Class Initialized
INFO - 2023-05-25 07:51:45 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:51:45 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:51:45 --> Utf8 Class Initialized
INFO - 2023-05-25 07:51:45 --> URI Class Initialized
INFO - 2023-05-25 07:51:45 --> Router Class Initialized
INFO - 2023-05-25 07:51:45 --> Output Class Initialized
INFO - 2023-05-25 07:51:45 --> Security Class Initialized
DEBUG - 2023-05-25 07:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:51:45 --> Input Class Initialized
INFO - 2023-05-25 07:51:45 --> Language Class Initialized
INFO - 2023-05-25 07:51:45 --> Loader Class Initialized
INFO - 2023-05-25 07:51:45 --> Controller Class Initialized
DEBUG - 2023-05-25 07:51:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:51:46 --> Database Driver Class Initialized
INFO - 2023-05-25 07:51:46 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:51:46 --> Database Driver Class Initialized
INFO - 2023-05-25 07:51:46 --> Model "Login_model" initialized
INFO - 2023-05-25 07:51:58 --> Final output sent to browser
DEBUG - 2023-05-25 07:51:58 --> Total execution time: 12.2651
INFO - 2023-05-25 07:52:39 --> Config Class Initialized
INFO - 2023-05-25 07:52:39 --> Hooks Class Initialized
INFO - 2023-05-25 07:52:39 --> Config Class Initialized
INFO - 2023-05-25 07:52:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:52:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:52:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:52:39 --> URI Class Initialized
DEBUG - 2023-05-25 07:52:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:52:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:52:39 --> URI Class Initialized
INFO - 2023-05-25 07:52:39 --> Router Class Initialized
INFO - 2023-05-25 07:52:39 --> Router Class Initialized
INFO - 2023-05-25 07:52:39 --> Output Class Initialized
INFO - 2023-05-25 07:52:39 --> Output Class Initialized
INFO - 2023-05-25 07:52:39 --> Security Class Initialized
INFO - 2023-05-25 07:52:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:52:39 --> Input Class Initialized
DEBUG - 2023-05-25 07:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:52:39 --> Language Class Initialized
INFO - 2023-05-25 07:52:39 --> Input Class Initialized
INFO - 2023-05-25 07:52:39 --> Language Class Initialized
INFO - 2023-05-25 07:52:39 --> Loader Class Initialized
INFO - 2023-05-25 07:52:39 --> Loader Class Initialized
INFO - 2023-05-25 07:52:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:52:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:52:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:52:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:52:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:52:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:52:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:52:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:52:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:52:39 --> Model "Login_model" initialized
INFO - 2023-05-25 07:52:39 --> Final output sent to browser
DEBUG - 2023-05-25 07:52:39 --> Total execution time: 0.2648
INFO - 2023-05-25 07:52:39 --> Config Class Initialized
INFO - 2023-05-25 07:52:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:52:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:52:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:52:39 --> URI Class Initialized
INFO - 2023-05-25 07:52:39 --> Router Class Initialized
INFO - 2023-05-25 07:52:39 --> Output Class Initialized
INFO - 2023-05-25 07:52:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:52:39 --> Input Class Initialized
INFO - 2023-05-25 07:52:39 --> Language Class Initialized
INFO - 2023-05-25 07:52:39 --> Loader Class Initialized
INFO - 2023-05-25 07:52:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:52:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:52:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:52:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:52:39 --> Final output sent to browser
DEBUG - 2023-05-25 07:52:39 --> Total execution time: 0.3220
INFO - 2023-05-25 07:52:51 --> Final output sent to browser
DEBUG - 2023-05-25 07:52:51 --> Total execution time: 12.0694
INFO - 2023-05-25 07:52:51 --> Config Class Initialized
INFO - 2023-05-25 07:52:51 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:52:51 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:52:51 --> Utf8 Class Initialized
INFO - 2023-05-25 07:52:51 --> URI Class Initialized
INFO - 2023-05-25 07:52:51 --> Router Class Initialized
INFO - 2023-05-25 07:52:51 --> Output Class Initialized
INFO - 2023-05-25 07:52:51 --> Security Class Initialized
DEBUG - 2023-05-25 07:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:52:51 --> Input Class Initialized
INFO - 2023-05-25 07:52:51 --> Language Class Initialized
INFO - 2023-05-25 07:52:51 --> Loader Class Initialized
INFO - 2023-05-25 07:52:51 --> Controller Class Initialized
DEBUG - 2023-05-25 07:52:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:52:51 --> Database Driver Class Initialized
INFO - 2023-05-25 07:52:51 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:52:51 --> Database Driver Class Initialized
INFO - 2023-05-25 07:52:51 --> Model "Login_model" initialized
INFO - 2023-05-25 07:53:02 --> Final output sent to browser
DEBUG - 2023-05-25 07:53:02 --> Total execution time: 11.0697
INFO - 2023-05-25 07:53:40 --> Config Class Initialized
INFO - 2023-05-25 07:53:40 --> Config Class Initialized
INFO - 2023-05-25 07:53:40 --> Hooks Class Initialized
INFO - 2023-05-25 07:53:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:53:40 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:53:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:53:40 --> Utf8 Class Initialized
INFO - 2023-05-25 07:53:40 --> Utf8 Class Initialized
INFO - 2023-05-25 07:53:40 --> URI Class Initialized
INFO - 2023-05-25 07:53:40 --> URI Class Initialized
INFO - 2023-05-25 07:53:40 --> Router Class Initialized
INFO - 2023-05-25 07:53:40 --> Router Class Initialized
INFO - 2023-05-25 07:53:40 --> Output Class Initialized
INFO - 2023-05-25 07:53:40 --> Output Class Initialized
INFO - 2023-05-25 07:53:40 --> Security Class Initialized
INFO - 2023-05-25 07:53:40 --> Security Class Initialized
DEBUG - 2023-05-25 07:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:53:40 --> Input Class Initialized
INFO - 2023-05-25 07:53:40 --> Input Class Initialized
INFO - 2023-05-25 07:53:40 --> Language Class Initialized
INFO - 2023-05-25 07:53:40 --> Language Class Initialized
INFO - 2023-05-25 07:53:40 --> Loader Class Initialized
INFO - 2023-05-25 07:53:40 --> Controller Class Initialized
INFO - 2023-05-25 07:53:40 --> Loader Class Initialized
DEBUG - 2023-05-25 07:53:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:53:40 --> Controller Class Initialized
DEBUG - 2023-05-25 07:53:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:53:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:53:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:53:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:53:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:53:41 --> Database Driver Class Initialized
INFO - 2023-05-25 07:53:41 --> Final output sent to browser
INFO - 2023-05-25 07:53:41 --> Model "Login_model" initialized
DEBUG - 2023-05-25 07:53:41 --> Total execution time: 1.0798
INFO - 2023-05-25 07:53:41 --> Config Class Initialized
INFO - 2023-05-25 07:53:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:53:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:53:41 --> Utf8 Class Initialized
INFO - 2023-05-25 07:53:41 --> URI Class Initialized
INFO - 2023-05-25 07:53:41 --> Router Class Initialized
INFO - 2023-05-25 07:53:41 --> Output Class Initialized
INFO - 2023-05-25 07:53:42 --> Security Class Initialized
DEBUG - 2023-05-25 07:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:53:42 --> Input Class Initialized
INFO - 2023-05-25 07:53:42 --> Language Class Initialized
INFO - 2023-05-25 07:53:42 --> Loader Class Initialized
INFO - 2023-05-25 07:53:42 --> Controller Class Initialized
DEBUG - 2023-05-25 07:53:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:53:42 --> Database Driver Class Initialized
INFO - 2023-05-25 07:53:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:53:42 --> Final output sent to browser
DEBUG - 2023-05-25 07:53:42 --> Total execution time: 0.8289
INFO - 2023-05-25 07:53:52 --> Final output sent to browser
DEBUG - 2023-05-25 07:53:52 --> Total execution time: 12.0976
INFO - 2023-05-25 07:53:52 --> Config Class Initialized
INFO - 2023-05-25 07:53:52 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:53:52 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:53:52 --> Utf8 Class Initialized
INFO - 2023-05-25 07:53:52 --> URI Class Initialized
INFO - 2023-05-25 07:53:52 --> Router Class Initialized
INFO - 2023-05-25 07:53:52 --> Output Class Initialized
INFO - 2023-05-25 07:53:52 --> Security Class Initialized
DEBUG - 2023-05-25 07:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:53:52 --> Input Class Initialized
INFO - 2023-05-25 07:53:52 --> Language Class Initialized
INFO - 2023-05-25 07:53:52 --> Loader Class Initialized
INFO - 2023-05-25 07:53:52 --> Controller Class Initialized
DEBUG - 2023-05-25 07:53:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:53:52 --> Database Driver Class Initialized
INFO - 2023-05-25 07:53:52 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:53:52 --> Database Driver Class Initialized
INFO - 2023-05-25 07:53:52 --> Model "Login_model" initialized
INFO - 2023-05-25 07:54:03 --> Final output sent to browser
DEBUG - 2023-05-25 07:54:03 --> Total execution time: 11.2463
INFO - 2023-05-25 07:54:39 --> Config Class Initialized
INFO - 2023-05-25 07:54:39 --> Config Class Initialized
INFO - 2023-05-25 07:54:39 --> Hooks Class Initialized
INFO - 2023-05-25 07:54:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:54:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:54:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:54:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:54:39 --> Utf8 Class Initialized
INFO - 2023-05-25 07:54:39 --> URI Class Initialized
INFO - 2023-05-25 07:54:39 --> URI Class Initialized
INFO - 2023-05-25 07:54:39 --> Router Class Initialized
INFO - 2023-05-25 07:54:39 --> Router Class Initialized
INFO - 2023-05-25 07:54:39 --> Output Class Initialized
INFO - 2023-05-25 07:54:39 --> Output Class Initialized
INFO - 2023-05-25 07:54:39 --> Security Class Initialized
INFO - 2023-05-25 07:54:39 --> Security Class Initialized
DEBUG - 2023-05-25 07:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:54:39 --> Input Class Initialized
INFO - 2023-05-25 07:54:39 --> Input Class Initialized
INFO - 2023-05-25 07:54:39 --> Language Class Initialized
INFO - 2023-05-25 07:54:39 --> Language Class Initialized
INFO - 2023-05-25 07:54:39 --> Loader Class Initialized
INFO - 2023-05-25 07:54:39 --> Loader Class Initialized
INFO - 2023-05-25 07:54:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:54:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:54:39 --> Controller Class Initialized
DEBUG - 2023-05-25 07:54:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:54:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:54:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:54:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:54:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:54:39 --> Database Driver Class Initialized
INFO - 2023-05-25 07:54:39 --> Model "Login_model" initialized
INFO - 2023-05-25 07:54:40 --> Final output sent to browser
DEBUG - 2023-05-25 07:54:40 --> Total execution time: 0.9004
INFO - 2023-05-25 07:54:40 --> Config Class Initialized
INFO - 2023-05-25 07:54:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:54:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:54:40 --> Utf8 Class Initialized
INFO - 2023-05-25 07:54:40 --> URI Class Initialized
INFO - 2023-05-25 07:54:40 --> Router Class Initialized
INFO - 2023-05-25 07:54:40 --> Output Class Initialized
INFO - 2023-05-25 07:54:40 --> Security Class Initialized
DEBUG - 2023-05-25 07:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:54:40 --> Input Class Initialized
INFO - 2023-05-25 07:54:40 --> Language Class Initialized
INFO - 2023-05-25 07:54:40 --> Loader Class Initialized
INFO - 2023-05-25 07:54:40 --> Controller Class Initialized
DEBUG - 2023-05-25 07:54:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:54:40 --> Database Driver Class Initialized
INFO - 2023-05-25 07:54:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:54:41 --> Final output sent to browser
DEBUG - 2023-05-25 07:54:41 --> Total execution time: 1.0220
INFO - 2023-05-25 07:54:50 --> Final output sent to browser
DEBUG - 2023-05-25 07:54:50 --> Total execution time: 10.8408
INFO - 2023-05-25 07:54:50 --> Config Class Initialized
INFO - 2023-05-25 07:54:50 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:54:50 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:54:50 --> Utf8 Class Initialized
INFO - 2023-05-25 07:54:50 --> URI Class Initialized
INFO - 2023-05-25 07:54:50 --> Router Class Initialized
INFO - 2023-05-25 07:54:50 --> Output Class Initialized
INFO - 2023-05-25 07:54:50 --> Security Class Initialized
DEBUG - 2023-05-25 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:54:50 --> Input Class Initialized
INFO - 2023-05-25 07:54:50 --> Language Class Initialized
INFO - 2023-05-25 07:54:50 --> Loader Class Initialized
INFO - 2023-05-25 07:54:50 --> Controller Class Initialized
DEBUG - 2023-05-25 07:54:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:54:50 --> Database Driver Class Initialized
INFO - 2023-05-25 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:54:50 --> Database Driver Class Initialized
INFO - 2023-05-25 07:54:50 --> Model "Login_model" initialized
INFO - 2023-05-25 07:54:54 --> Config Class Initialized
INFO - 2023-05-25 07:54:54 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:54:54 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:54:54 --> Utf8 Class Initialized
INFO - 2023-05-25 07:54:54 --> URI Class Initialized
INFO - 2023-05-25 07:54:54 --> Router Class Initialized
INFO - 2023-05-25 07:54:54 --> Output Class Initialized
INFO - 2023-05-25 07:54:54 --> Security Class Initialized
DEBUG - 2023-05-25 07:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:54:54 --> Input Class Initialized
INFO - 2023-05-25 07:54:54 --> Language Class Initialized
INFO - 2023-05-25 07:54:54 --> Loader Class Initialized
INFO - 2023-05-25 07:54:54 --> Controller Class Initialized
DEBUG - 2023-05-25 07:54:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:54:54 --> Database Driver Class Initialized
INFO - 2023-05-25 07:54:54 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:54:55 --> Final output sent to browser
DEBUG - 2023-05-25 07:54:55 --> Total execution time: 0.8391
INFO - 2023-05-25 07:54:55 --> Config Class Initialized
INFO - 2023-05-25 07:54:55 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:54:55 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:54:55 --> Utf8 Class Initialized
INFO - 2023-05-25 07:54:55 --> URI Class Initialized
INFO - 2023-05-25 07:54:55 --> Router Class Initialized
INFO - 2023-05-25 07:54:55 --> Output Class Initialized
INFO - 2023-05-25 07:54:55 --> Security Class Initialized
DEBUG - 2023-05-25 07:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:54:55 --> Input Class Initialized
INFO - 2023-05-25 07:54:56 --> Language Class Initialized
INFO - 2023-05-25 07:54:56 --> Loader Class Initialized
INFO - 2023-05-25 07:54:56 --> Controller Class Initialized
DEBUG - 2023-05-25 07:54:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:54:56 --> Database Driver Class Initialized
INFO - 2023-05-25 07:54:56 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:54:56 --> Final output sent to browser
DEBUG - 2023-05-25 07:54:56 --> Total execution time: 1.1118
INFO - 2023-05-25 07:55:00 --> Final output sent to browser
DEBUG - 2023-05-25 07:55:00 --> Total execution time: 10.7675
INFO - 2023-05-25 07:55:00 --> Config Class Initialized
INFO - 2023-05-25 07:55:00 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:55:00 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:55:00 --> Utf8 Class Initialized
INFO - 2023-05-25 07:55:00 --> URI Class Initialized
INFO - 2023-05-25 07:55:00 --> Router Class Initialized
INFO - 2023-05-25 07:55:00 --> Output Class Initialized
INFO - 2023-05-25 07:55:00 --> Security Class Initialized
DEBUG - 2023-05-25 07:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:55:00 --> Input Class Initialized
INFO - 2023-05-25 07:55:00 --> Language Class Initialized
INFO - 2023-05-25 07:55:01 --> Loader Class Initialized
INFO - 2023-05-25 07:55:01 --> Controller Class Initialized
DEBUG - 2023-05-25 07:55:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:55:01 --> Database Driver Class Initialized
INFO - 2023-05-25 07:55:01 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:55:01 --> Database Driver Class Initialized
INFO - 2023-05-25 07:55:01 --> Model "Login_model" initialized
INFO - 2023-05-25 07:55:10 --> Final output sent to browser
DEBUG - 2023-05-25 07:55:10 --> Total execution time: 10.0390
INFO - 2023-05-25 07:55:10 --> Config Class Initialized
INFO - 2023-05-25 07:55:10 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:55:10 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:55:10 --> Utf8 Class Initialized
INFO - 2023-05-25 07:55:10 --> URI Class Initialized
INFO - 2023-05-25 07:55:10 --> Router Class Initialized
INFO - 2023-05-25 07:55:11 --> Output Class Initialized
INFO - 2023-05-25 07:55:11 --> Security Class Initialized
DEBUG - 2023-05-25 07:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:55:11 --> Input Class Initialized
INFO - 2023-05-25 07:55:11 --> Language Class Initialized
INFO - 2023-05-25 07:55:11 --> Loader Class Initialized
INFO - 2023-05-25 07:55:11 --> Controller Class Initialized
DEBUG - 2023-05-25 07:55:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:55:11 --> Database Driver Class Initialized
INFO - 2023-05-25 07:55:11 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:55:11 --> Database Driver Class Initialized
INFO - 2023-05-25 07:55:11 --> Model "Login_model" initialized
INFO - 2023-05-25 07:55:21 --> Final output sent to browser
DEBUG - 2023-05-25 07:55:21 --> Total execution time: 10.7579
INFO - 2023-05-25 07:55:48 --> Config Class Initialized
INFO - 2023-05-25 07:55:48 --> Config Class Initialized
INFO - 2023-05-25 07:55:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:55:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:55:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:55:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:55:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:55:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:55:48 --> URI Class Initialized
INFO - 2023-05-25 07:55:48 --> URI Class Initialized
INFO - 2023-05-25 07:55:48 --> Router Class Initialized
INFO - 2023-05-25 07:55:48 --> Router Class Initialized
INFO - 2023-05-25 07:55:48 --> Output Class Initialized
INFO - 2023-05-25 07:55:48 --> Output Class Initialized
INFO - 2023-05-25 07:55:48 --> Security Class Initialized
INFO - 2023-05-25 07:55:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:55:48 --> Input Class Initialized
INFO - 2023-05-25 07:55:48 --> Input Class Initialized
INFO - 2023-05-25 07:55:48 --> Language Class Initialized
INFO - 2023-05-25 07:55:48 --> Language Class Initialized
INFO - 2023-05-25 07:55:48 --> Loader Class Initialized
INFO - 2023-05-25 07:55:48 --> Loader Class Initialized
INFO - 2023-05-25 07:55:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:55:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:55:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:55:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:55:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:55:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:55:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:55:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:55:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:55:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:55:48 --> Total execution time: 0.1795
INFO - 2023-05-25 07:55:48 --> Model "Login_model" initialized
INFO - 2023-05-25 07:55:48 --> Config Class Initialized
INFO - 2023-05-25 07:55:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:55:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:55:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:55:48 --> URI Class Initialized
INFO - 2023-05-25 07:55:48 --> Router Class Initialized
INFO - 2023-05-25 07:55:48 --> Output Class Initialized
INFO - 2023-05-25 07:55:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:55:48 --> Input Class Initialized
INFO - 2023-05-25 07:55:48 --> Language Class Initialized
INFO - 2023-05-25 07:55:48 --> Loader Class Initialized
INFO - 2023-05-25 07:55:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:55:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:55:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:55:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:55:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:55:48 --> Total execution time: 0.2567
INFO - 2023-05-25 07:55:58 --> Final output sent to browser
DEBUG - 2023-05-25 07:55:58 --> Total execution time: 9.9970
INFO - 2023-05-25 07:55:58 --> Config Class Initialized
INFO - 2023-05-25 07:55:58 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:55:58 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:55:58 --> Utf8 Class Initialized
INFO - 2023-05-25 07:55:58 --> URI Class Initialized
INFO - 2023-05-25 07:55:58 --> Router Class Initialized
INFO - 2023-05-25 07:55:58 --> Output Class Initialized
INFO - 2023-05-25 07:55:58 --> Security Class Initialized
DEBUG - 2023-05-25 07:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:55:58 --> Input Class Initialized
INFO - 2023-05-25 07:55:58 --> Language Class Initialized
INFO - 2023-05-25 07:55:58 --> Loader Class Initialized
INFO - 2023-05-25 07:55:58 --> Controller Class Initialized
DEBUG - 2023-05-25 07:55:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:55:58 --> Database Driver Class Initialized
INFO - 2023-05-25 07:55:58 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:55:58 --> Database Driver Class Initialized
INFO - 2023-05-25 07:55:58 --> Model "Login_model" initialized
INFO - 2023-05-25 07:56:08 --> Final output sent to browser
DEBUG - 2023-05-25 07:56:08 --> Total execution time: 10.5727
INFO - 2023-05-25 07:56:48 --> Config Class Initialized
INFO - 2023-05-25 07:56:48 --> Config Class Initialized
INFO - 2023-05-25 07:56:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:56:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:56:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:56:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:56:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:56:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:56:48 --> URI Class Initialized
INFO - 2023-05-25 07:56:48 --> URI Class Initialized
INFO - 2023-05-25 07:56:48 --> Router Class Initialized
INFO - 2023-05-25 07:56:48 --> Router Class Initialized
INFO - 2023-05-25 07:56:48 --> Output Class Initialized
INFO - 2023-05-25 07:56:48 --> Output Class Initialized
INFO - 2023-05-25 07:56:48 --> Security Class Initialized
INFO - 2023-05-25 07:56:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:56:48 --> Input Class Initialized
INFO - 2023-05-25 07:56:48 --> Input Class Initialized
INFO - 2023-05-25 07:56:48 --> Language Class Initialized
INFO - 2023-05-25 07:56:48 --> Language Class Initialized
INFO - 2023-05-25 07:56:48 --> Loader Class Initialized
INFO - 2023-05-25 07:56:48 --> Loader Class Initialized
INFO - 2023-05-25 07:56:48 --> Controller Class Initialized
INFO - 2023-05-25 07:56:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:56:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:56:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:56:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:56:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:56:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:56:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:56:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:56:48 --> Model "Login_model" initialized
INFO - 2023-05-25 07:56:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:56:48 --> Total execution time: 0.2734
INFO - 2023-05-25 07:56:48 --> Config Class Initialized
INFO - 2023-05-25 07:56:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:56:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:56:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:56:48 --> URI Class Initialized
INFO - 2023-05-25 07:56:48 --> Router Class Initialized
INFO - 2023-05-25 07:56:48 --> Output Class Initialized
INFO - 2023-05-25 07:56:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:56:48 --> Input Class Initialized
INFO - 2023-05-25 07:56:48 --> Language Class Initialized
INFO - 2023-05-25 07:56:48 --> Loader Class Initialized
INFO - 2023-05-25 07:56:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:56:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:56:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:56:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:56:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:56:48 --> Total execution time: 0.2614
INFO - 2023-05-25 07:56:58 --> Final output sent to browser
DEBUG - 2023-05-25 07:56:58 --> Total execution time: 10.1257
INFO - 2023-05-25 07:56:58 --> Config Class Initialized
INFO - 2023-05-25 07:56:58 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:56:58 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:56:58 --> Utf8 Class Initialized
INFO - 2023-05-25 07:56:58 --> URI Class Initialized
INFO - 2023-05-25 07:56:58 --> Router Class Initialized
INFO - 2023-05-25 07:56:58 --> Output Class Initialized
INFO - 2023-05-25 07:56:58 --> Security Class Initialized
DEBUG - 2023-05-25 07:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:56:58 --> Input Class Initialized
INFO - 2023-05-25 07:56:58 --> Language Class Initialized
INFO - 2023-05-25 07:56:58 --> Loader Class Initialized
INFO - 2023-05-25 07:56:58 --> Controller Class Initialized
DEBUG - 2023-05-25 07:56:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:56:58 --> Database Driver Class Initialized
INFO - 2023-05-25 07:56:58 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:56:58 --> Database Driver Class Initialized
INFO - 2023-05-25 07:56:58 --> Model "Login_model" initialized
INFO - 2023-05-25 07:57:07 --> Final output sent to browser
DEBUG - 2023-05-25 07:57:07 --> Total execution time: 9.2287
INFO - 2023-05-25 07:57:48 --> Config Class Initialized
INFO - 2023-05-25 07:57:48 --> Config Class Initialized
INFO - 2023-05-25 07:57:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:57:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:57:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:57:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:57:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:57:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:57:48 --> URI Class Initialized
INFO - 2023-05-25 07:57:48 --> URI Class Initialized
INFO - 2023-05-25 07:57:48 --> Router Class Initialized
INFO - 2023-05-25 07:57:48 --> Router Class Initialized
INFO - 2023-05-25 07:57:48 --> Output Class Initialized
INFO - 2023-05-25 07:57:48 --> Output Class Initialized
INFO - 2023-05-25 07:57:48 --> Security Class Initialized
INFO - 2023-05-25 07:57:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:57:48 --> Input Class Initialized
INFO - 2023-05-25 07:57:48 --> Input Class Initialized
INFO - 2023-05-25 07:57:48 --> Language Class Initialized
INFO - 2023-05-25 07:57:48 --> Language Class Initialized
INFO - 2023-05-25 07:57:48 --> Loader Class Initialized
INFO - 2023-05-25 07:57:48 --> Controller Class Initialized
INFO - 2023-05-25 07:57:48 --> Loader Class Initialized
DEBUG - 2023-05-25 07:57:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:57:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:57:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:57:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:57:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:57:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:57:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:57:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:57:48 --> Model "Login_model" initialized
INFO - 2023-05-25 07:57:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:57:48 --> Total execution time: 0.6318
INFO - 2023-05-25 07:57:48 --> Config Class Initialized
INFO - 2023-05-25 07:57:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:57:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:57:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:57:48 --> URI Class Initialized
INFO - 2023-05-25 07:57:48 --> Router Class Initialized
INFO - 2023-05-25 07:57:48 --> Output Class Initialized
INFO - 2023-05-25 07:57:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:57:48 --> Input Class Initialized
INFO - 2023-05-25 07:57:48 --> Language Class Initialized
INFO - 2023-05-25 07:57:48 --> Loader Class Initialized
INFO - 2023-05-25 07:57:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:57:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:57:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:57:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:57:49 --> Final output sent to browser
DEBUG - 2023-05-25 07:57:49 --> Total execution time: 0.6019
INFO - 2023-05-25 07:58:00 --> Final output sent to browser
DEBUG - 2023-05-25 07:58:00 --> Total execution time: 12.8376
INFO - 2023-05-25 07:58:01 --> Config Class Initialized
INFO - 2023-05-25 07:58:01 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:58:01 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:58:01 --> Utf8 Class Initialized
INFO - 2023-05-25 07:58:01 --> URI Class Initialized
INFO - 2023-05-25 07:58:01 --> Router Class Initialized
INFO - 2023-05-25 07:58:01 --> Output Class Initialized
INFO - 2023-05-25 07:58:01 --> Security Class Initialized
DEBUG - 2023-05-25 07:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:58:01 --> Input Class Initialized
INFO - 2023-05-25 07:58:01 --> Language Class Initialized
INFO - 2023-05-25 07:58:01 --> Loader Class Initialized
INFO - 2023-05-25 07:58:01 --> Controller Class Initialized
DEBUG - 2023-05-25 07:58:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:58:01 --> Database Driver Class Initialized
INFO - 2023-05-25 07:58:01 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:58:01 --> Database Driver Class Initialized
INFO - 2023-05-25 07:58:01 --> Model "Login_model" initialized
INFO - 2023-05-25 07:58:13 --> Final output sent to browser
DEBUG - 2023-05-25 07:58:13 --> Total execution time: 12.4062
INFO - 2023-05-25 07:58:48 --> Config Class Initialized
INFO - 2023-05-25 07:58:48 --> Config Class Initialized
INFO - 2023-05-25 07:58:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:58:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:58:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:58:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:58:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:58:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:58:48 --> URI Class Initialized
INFO - 2023-05-25 07:58:48 --> URI Class Initialized
INFO - 2023-05-25 07:58:48 --> Router Class Initialized
INFO - 2023-05-25 07:58:48 --> Router Class Initialized
INFO - 2023-05-25 07:58:48 --> Output Class Initialized
INFO - 2023-05-25 07:58:48 --> Output Class Initialized
INFO - 2023-05-25 07:58:48 --> Security Class Initialized
INFO - 2023-05-25 07:58:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:58:48 --> Input Class Initialized
INFO - 2023-05-25 07:58:48 --> Input Class Initialized
INFO - 2023-05-25 07:58:48 --> Language Class Initialized
INFO - 2023-05-25 07:58:48 --> Language Class Initialized
INFO - 2023-05-25 07:58:48 --> Loader Class Initialized
INFO - 2023-05-25 07:58:48 --> Controller Class Initialized
INFO - 2023-05-25 07:58:48 --> Loader Class Initialized
DEBUG - 2023-05-25 07:58:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:58:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:58:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:58:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:58:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:58:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:58:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:58:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:58:48 --> Final output sent to browser
INFO - 2023-05-25 07:58:48 --> Model "Login_model" initialized
DEBUG - 2023-05-25 07:58:48 --> Total execution time: 0.1873
INFO - 2023-05-25 07:58:48 --> Config Class Initialized
INFO - 2023-05-25 07:58:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:58:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:58:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:58:48 --> URI Class Initialized
INFO - 2023-05-25 07:58:48 --> Router Class Initialized
INFO - 2023-05-25 07:58:48 --> Output Class Initialized
INFO - 2023-05-25 07:58:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:58:48 --> Input Class Initialized
INFO - 2023-05-25 07:58:48 --> Language Class Initialized
INFO - 2023-05-25 07:58:48 --> Loader Class Initialized
INFO - 2023-05-25 07:58:48 --> Controller Class Initialized
DEBUG - 2023-05-25 07:58:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:58:48 --> Database Driver Class Initialized
INFO - 2023-05-25 07:58:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:58:48 --> Final output sent to browser
DEBUG - 2023-05-25 07:58:48 --> Total execution time: 0.2209
INFO - 2023-05-25 07:58:57 --> Final output sent to browser
DEBUG - 2023-05-25 07:58:57 --> Total execution time: 9.4989
INFO - 2023-05-25 07:58:57 --> Config Class Initialized
INFO - 2023-05-25 07:58:57 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:58:57 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:58:57 --> Utf8 Class Initialized
INFO - 2023-05-25 07:58:57 --> URI Class Initialized
INFO - 2023-05-25 07:58:57 --> Router Class Initialized
INFO - 2023-05-25 07:58:57 --> Output Class Initialized
INFO - 2023-05-25 07:58:57 --> Security Class Initialized
DEBUG - 2023-05-25 07:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:58:57 --> Input Class Initialized
INFO - 2023-05-25 07:58:57 --> Language Class Initialized
INFO - 2023-05-25 07:58:57 --> Loader Class Initialized
INFO - 2023-05-25 07:58:57 --> Controller Class Initialized
DEBUG - 2023-05-25 07:58:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:58:57 --> Database Driver Class Initialized
INFO - 2023-05-25 07:58:57 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:58:57 --> Database Driver Class Initialized
INFO - 2023-05-25 07:58:57 --> Model "Login_model" initialized
INFO - 2023-05-25 07:59:06 --> Final output sent to browser
DEBUG - 2023-05-25 07:59:06 --> Total execution time: 9.2321
INFO - 2023-05-25 07:59:48 --> Config Class Initialized
INFO - 2023-05-25 07:59:48 --> Config Class Initialized
INFO - 2023-05-25 07:59:48 --> Hooks Class Initialized
INFO - 2023-05-25 07:59:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:59:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 07:59:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:59:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:59:48 --> Utf8 Class Initialized
INFO - 2023-05-25 07:59:48 --> URI Class Initialized
INFO - 2023-05-25 07:59:48 --> URI Class Initialized
INFO - 2023-05-25 07:59:48 --> Router Class Initialized
INFO - 2023-05-25 07:59:48 --> Router Class Initialized
INFO - 2023-05-25 07:59:48 --> Output Class Initialized
INFO - 2023-05-25 07:59:48 --> Output Class Initialized
INFO - 2023-05-25 07:59:48 --> Security Class Initialized
INFO - 2023-05-25 07:59:48 --> Security Class Initialized
DEBUG - 2023-05-25 07:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 07:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:59:48 --> Input Class Initialized
INFO - 2023-05-25 07:59:48 --> Input Class Initialized
INFO - 2023-05-25 07:59:48 --> Language Class Initialized
INFO - 2023-05-25 07:59:48 --> Language Class Initialized
INFO - 2023-05-25 07:59:48 --> Loader Class Initialized
INFO - 2023-05-25 07:59:49 --> Loader Class Initialized
INFO - 2023-05-25 07:59:49 --> Controller Class Initialized
INFO - 2023-05-25 07:59:49 --> Controller Class Initialized
DEBUG - 2023-05-25 07:59:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 07:59:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:59:50 --> Database Driver Class Initialized
INFO - 2023-05-25 07:59:50 --> Database Driver Class Initialized
INFO - 2023-05-25 07:59:50 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:59:50 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:59:50 --> Database Driver Class Initialized
INFO - 2023-05-25 07:59:50 --> Model "Login_model" initialized
INFO - 2023-05-25 07:59:50 --> Final output sent to browser
DEBUG - 2023-05-25 07:59:50 --> Total execution time: 2.1368
INFO - 2023-05-25 07:59:50 --> Config Class Initialized
INFO - 2023-05-25 07:59:51 --> Hooks Class Initialized
DEBUG - 2023-05-25 07:59:51 --> UTF-8 Support Enabled
INFO - 2023-05-25 07:59:51 --> Utf8 Class Initialized
INFO - 2023-05-25 07:59:51 --> URI Class Initialized
INFO - 2023-05-25 07:59:51 --> Router Class Initialized
INFO - 2023-05-25 07:59:51 --> Output Class Initialized
INFO - 2023-05-25 07:59:51 --> Security Class Initialized
DEBUG - 2023-05-25 07:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 07:59:51 --> Input Class Initialized
INFO - 2023-05-25 07:59:51 --> Language Class Initialized
INFO - 2023-05-25 07:59:52 --> Loader Class Initialized
INFO - 2023-05-25 07:59:52 --> Controller Class Initialized
DEBUG - 2023-05-25 07:59:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 07:59:52 --> Database Driver Class Initialized
INFO - 2023-05-25 07:59:52 --> Model "Cluster_model" initialized
INFO - 2023-05-25 07:59:52 --> Final output sent to browser
DEBUG - 2023-05-25 07:59:52 --> Total execution time: 1.9149
INFO - 2023-05-25 08:00:04 --> Final output sent to browser
DEBUG - 2023-05-25 08:00:04 --> Total execution time: 15.5549
INFO - 2023-05-25 08:00:04 --> Config Class Initialized
INFO - 2023-05-25 08:00:04 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:00:04 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:00:04 --> Utf8 Class Initialized
INFO - 2023-05-25 08:00:04 --> URI Class Initialized
INFO - 2023-05-25 08:00:04 --> Router Class Initialized
INFO - 2023-05-25 08:00:04 --> Output Class Initialized
INFO - 2023-05-25 08:00:04 --> Security Class Initialized
DEBUG - 2023-05-25 08:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:00:04 --> Input Class Initialized
INFO - 2023-05-25 08:00:04 --> Language Class Initialized
INFO - 2023-05-25 08:00:04 --> Loader Class Initialized
INFO - 2023-05-25 08:00:04 --> Controller Class Initialized
DEBUG - 2023-05-25 08:00:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:00:04 --> Database Driver Class Initialized
INFO - 2023-05-25 08:00:04 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:00:04 --> Database Driver Class Initialized
INFO - 2023-05-25 08:00:04 --> Model "Login_model" initialized
INFO - 2023-05-25 08:00:10 --> Final output sent to browser
DEBUG - 2023-05-25 08:00:10 --> Total execution time: 6.0166
INFO - 2023-05-25 08:00:48 --> Config Class Initialized
INFO - 2023-05-25 08:00:48 --> Config Class Initialized
INFO - 2023-05-25 08:00:48 --> Hooks Class Initialized
INFO - 2023-05-25 08:00:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:00:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:00:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:00:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:00:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:00:48 --> URI Class Initialized
INFO - 2023-05-25 08:00:48 --> URI Class Initialized
INFO - 2023-05-25 08:00:48 --> Router Class Initialized
INFO - 2023-05-25 08:00:48 --> Router Class Initialized
INFO - 2023-05-25 08:00:48 --> Output Class Initialized
INFO - 2023-05-25 08:00:48 --> Output Class Initialized
INFO - 2023-05-25 08:00:48 --> Security Class Initialized
INFO - 2023-05-25 08:00:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:00:48 --> Input Class Initialized
INFO - 2023-05-25 08:00:48 --> Input Class Initialized
INFO - 2023-05-25 08:00:48 --> Language Class Initialized
INFO - 2023-05-25 08:00:48 --> Language Class Initialized
INFO - 2023-05-25 08:00:48 --> Loader Class Initialized
INFO - 2023-05-25 08:00:48 --> Loader Class Initialized
INFO - 2023-05-25 08:00:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:00:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:00:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:00:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:00:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:00:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:00:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:00:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:00:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:00:48 --> Model "Login_model" initialized
INFO - 2023-05-25 08:00:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:00:48 --> Total execution time: 0.7996
INFO - 2023-05-25 08:00:49 --> Config Class Initialized
INFO - 2023-05-25 08:00:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:00:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:00:49 --> Utf8 Class Initialized
INFO - 2023-05-25 08:00:49 --> URI Class Initialized
INFO - 2023-05-25 08:00:49 --> Router Class Initialized
INFO - 2023-05-25 08:00:49 --> Output Class Initialized
INFO - 2023-05-25 08:00:49 --> Security Class Initialized
DEBUG - 2023-05-25 08:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:00:49 --> Input Class Initialized
INFO - 2023-05-25 08:00:49 --> Language Class Initialized
INFO - 2023-05-25 08:00:49 --> Loader Class Initialized
INFO - 2023-05-25 08:00:49 --> Controller Class Initialized
DEBUG - 2023-05-25 08:00:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:00:49 --> Database Driver Class Initialized
INFO - 2023-05-25 08:00:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:00:49 --> Final output sent to browser
DEBUG - 2023-05-25 08:00:49 --> Total execution time: 0.6611
INFO - 2023-05-25 08:00:57 --> Final output sent to browser
DEBUG - 2023-05-25 08:00:57 --> Total execution time: 9.7885
INFO - 2023-05-25 08:00:57 --> Config Class Initialized
INFO - 2023-05-25 08:00:57 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:00:57 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:00:57 --> Utf8 Class Initialized
INFO - 2023-05-25 08:00:58 --> URI Class Initialized
INFO - 2023-05-25 08:00:58 --> Router Class Initialized
INFO - 2023-05-25 08:00:58 --> Output Class Initialized
INFO - 2023-05-25 08:00:58 --> Security Class Initialized
DEBUG - 2023-05-25 08:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:00:58 --> Input Class Initialized
INFO - 2023-05-25 08:00:58 --> Language Class Initialized
INFO - 2023-05-25 08:00:58 --> Loader Class Initialized
INFO - 2023-05-25 08:00:58 --> Controller Class Initialized
DEBUG - 2023-05-25 08:00:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:00:58 --> Database Driver Class Initialized
INFO - 2023-05-25 08:00:58 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:00:58 --> Database Driver Class Initialized
INFO - 2023-05-25 08:00:58 --> Model "Login_model" initialized
INFO - 2023-05-25 08:01:12 --> Final output sent to browser
DEBUG - 2023-05-25 08:01:12 --> Total execution time: 14.5639
INFO - 2023-05-25 08:01:48 --> Config Class Initialized
INFO - 2023-05-25 08:01:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:01:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:01:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:01:48 --> URI Class Initialized
INFO - 2023-05-25 08:01:48 --> Router Class Initialized
INFO - 2023-05-25 08:01:48 --> Output Class Initialized
INFO - 2023-05-25 08:01:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:01:48 --> Input Class Initialized
INFO - 2023-05-25 08:01:48 --> Language Class Initialized
INFO - 2023-05-25 08:01:48 --> Loader Class Initialized
INFO - 2023-05-25 08:01:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:01:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:01:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:01:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:01:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:01:48 --> Total execution time: 0.4194
INFO - 2023-05-25 08:01:48 --> Config Class Initialized
INFO - 2023-05-25 08:01:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:01:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:01:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:01:48 --> URI Class Initialized
INFO - 2023-05-25 08:01:48 --> Router Class Initialized
INFO - 2023-05-25 08:01:48 --> Output Class Initialized
INFO - 2023-05-25 08:01:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:01:48 --> Input Class Initialized
INFO - 2023-05-25 08:01:48 --> Language Class Initialized
INFO - 2023-05-25 08:01:48 --> Loader Class Initialized
INFO - 2023-05-25 08:01:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:01:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:01:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:01:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:01:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:01:48 --> Total execution time: 0.2353
INFO - 2023-05-25 08:01:49 --> Config Class Initialized
INFO - 2023-05-25 08:01:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:01:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:01:49 --> Utf8 Class Initialized
INFO - 2023-05-25 08:01:49 --> URI Class Initialized
INFO - 2023-05-25 08:01:49 --> Router Class Initialized
INFO - 2023-05-25 08:01:49 --> Output Class Initialized
INFO - 2023-05-25 08:01:49 --> Security Class Initialized
DEBUG - 2023-05-25 08:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:01:49 --> Input Class Initialized
INFO - 2023-05-25 08:01:49 --> Language Class Initialized
INFO - 2023-05-25 08:01:49 --> Loader Class Initialized
INFO - 2023-05-25 08:01:49 --> Controller Class Initialized
DEBUG - 2023-05-25 08:01:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:01:49 --> Database Driver Class Initialized
INFO - 2023-05-25 08:01:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:01:49 --> Database Driver Class Initialized
INFO - 2023-05-25 08:01:49 --> Model "Login_model" initialized
INFO - 2023-05-25 08:01:59 --> Final output sent to browser
DEBUG - 2023-05-25 08:02:00 --> Total execution time: 10.8087
INFO - 2023-05-25 08:02:00 --> Config Class Initialized
INFO - 2023-05-25 08:02:00 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:02:00 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:02:00 --> Utf8 Class Initialized
INFO - 2023-05-25 08:02:00 --> URI Class Initialized
INFO - 2023-05-25 08:02:00 --> Router Class Initialized
INFO - 2023-05-25 08:02:00 --> Output Class Initialized
INFO - 2023-05-25 08:02:00 --> Security Class Initialized
DEBUG - 2023-05-25 08:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:02:00 --> Input Class Initialized
INFO - 2023-05-25 08:02:00 --> Language Class Initialized
INFO - 2023-05-25 08:02:00 --> Loader Class Initialized
INFO - 2023-05-25 08:02:00 --> Controller Class Initialized
DEBUG - 2023-05-25 08:02:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:02:00 --> Database Driver Class Initialized
INFO - 2023-05-25 08:02:00 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:02:00 --> Database Driver Class Initialized
INFO - 2023-05-25 08:02:00 --> Model "Login_model" initialized
INFO - 2023-05-25 08:02:07 --> Final output sent to browser
DEBUG - 2023-05-25 08:02:07 --> Total execution time: 7.4700
INFO - 2023-05-25 08:03:39 --> Config Class Initialized
INFO - 2023-05-25 08:03:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:03:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:03:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:03:39 --> URI Class Initialized
INFO - 2023-05-25 08:03:39 --> Router Class Initialized
INFO - 2023-05-25 08:03:39 --> Output Class Initialized
INFO - 2023-05-25 08:03:39 --> Security Class Initialized
DEBUG - 2023-05-25 08:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:03:39 --> Input Class Initialized
INFO - 2023-05-25 08:03:39 --> Language Class Initialized
INFO - 2023-05-25 08:03:39 --> Loader Class Initialized
INFO - 2023-05-25 08:03:39 --> Controller Class Initialized
DEBUG - 2023-05-25 08:03:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:03:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:03:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:03:39 --> Final output sent to browser
DEBUG - 2023-05-25 08:03:39 --> Total execution time: 0.2263
INFO - 2023-05-25 08:03:39 --> Config Class Initialized
INFO - 2023-05-25 08:03:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:03:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:03:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:03:39 --> URI Class Initialized
INFO - 2023-05-25 08:03:39 --> Router Class Initialized
INFO - 2023-05-25 08:03:39 --> Output Class Initialized
INFO - 2023-05-25 08:03:39 --> Security Class Initialized
DEBUG - 2023-05-25 08:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:03:39 --> Input Class Initialized
INFO - 2023-05-25 08:03:39 --> Language Class Initialized
INFO - 2023-05-25 08:03:39 --> Loader Class Initialized
INFO - 2023-05-25 08:03:39 --> Controller Class Initialized
DEBUG - 2023-05-25 08:03:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:03:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:03:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:03:39 --> Final output sent to browser
DEBUG - 2023-05-25 08:03:39 --> Total execution time: 0.2649
INFO - 2023-05-25 08:04:39 --> Config Class Initialized
INFO - 2023-05-25 08:04:39 --> Config Class Initialized
INFO - 2023-05-25 08:04:39 --> Hooks Class Initialized
INFO - 2023-05-25 08:04:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:04:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:04:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:04:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:04:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:04:39 --> URI Class Initialized
INFO - 2023-05-25 08:04:39 --> URI Class Initialized
INFO - 2023-05-25 08:04:39 --> Router Class Initialized
INFO - 2023-05-25 08:04:39 --> Router Class Initialized
INFO - 2023-05-25 08:04:39 --> Output Class Initialized
INFO - 2023-05-25 08:04:39 --> Output Class Initialized
INFO - 2023-05-25 08:04:39 --> Security Class Initialized
INFO - 2023-05-25 08:04:39 --> Security Class Initialized
DEBUG - 2023-05-25 08:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:04:39 --> Input Class Initialized
INFO - 2023-05-25 08:04:39 --> Input Class Initialized
INFO - 2023-05-25 08:04:39 --> Language Class Initialized
INFO - 2023-05-25 08:04:39 --> Language Class Initialized
INFO - 2023-05-25 08:04:39 --> Loader Class Initialized
INFO - 2023-05-25 08:04:39 --> Loader Class Initialized
INFO - 2023-05-25 08:04:39 --> Controller Class Initialized
DEBUG - 2023-05-25 08:04:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:04:39 --> Controller Class Initialized
DEBUG - 2023-05-25 08:04:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:04:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:04:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:04:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:04:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:04:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:04:39 --> Model "Login_model" initialized
INFO - 2023-05-25 08:04:41 --> Final output sent to browser
DEBUG - 2023-05-25 08:04:41 --> Total execution time: 2.3320
INFO - 2023-05-25 08:04:41 --> Config Class Initialized
INFO - 2023-05-25 08:04:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:04:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:04:41 --> Utf8 Class Initialized
INFO - 2023-05-25 08:04:41 --> URI Class Initialized
INFO - 2023-05-25 08:04:41 --> Router Class Initialized
INFO - 2023-05-25 08:04:41 --> Output Class Initialized
INFO - 2023-05-25 08:04:41 --> Security Class Initialized
DEBUG - 2023-05-25 08:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:04:41 --> Input Class Initialized
INFO - 2023-05-25 08:04:41 --> Language Class Initialized
INFO - 2023-05-25 08:04:41 --> Loader Class Initialized
INFO - 2023-05-25 08:04:41 --> Controller Class Initialized
DEBUG - 2023-05-25 08:04:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:04:41 --> Database Driver Class Initialized
INFO - 2023-05-25 08:04:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:04:43 --> Final output sent to browser
DEBUG - 2023-05-25 08:04:43 --> Total execution time: 1.6524
INFO - 2023-05-25 08:04:51 --> Final output sent to browser
DEBUG - 2023-05-25 08:04:51 --> Total execution time: 12.2547
INFO - 2023-05-25 08:04:51 --> Config Class Initialized
INFO - 2023-05-25 08:04:51 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:04:51 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:04:51 --> Utf8 Class Initialized
INFO - 2023-05-25 08:04:51 --> URI Class Initialized
INFO - 2023-05-25 08:04:51 --> Router Class Initialized
INFO - 2023-05-25 08:04:51 --> Output Class Initialized
INFO - 2023-05-25 08:04:51 --> Security Class Initialized
DEBUG - 2023-05-25 08:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:04:51 --> Input Class Initialized
INFO - 2023-05-25 08:04:51 --> Language Class Initialized
INFO - 2023-05-25 08:04:51 --> Loader Class Initialized
INFO - 2023-05-25 08:04:51 --> Controller Class Initialized
DEBUG - 2023-05-25 08:04:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:04:51 --> Database Driver Class Initialized
INFO - 2023-05-25 08:04:51 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:04:51 --> Database Driver Class Initialized
INFO - 2023-05-25 08:04:51 --> Model "Login_model" initialized
INFO - 2023-05-25 08:05:02 --> Config Class Initialized
INFO - 2023-05-25 08:05:02 --> Config Class Initialized
INFO - 2023-05-25 08:05:02 --> Hooks Class Initialized
INFO - 2023-05-25 08:05:02 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:05:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:05:02 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:05:02 --> Utf8 Class Initialized
INFO - 2023-05-25 08:05:02 --> Utf8 Class Initialized
INFO - 2023-05-25 08:05:02 --> URI Class Initialized
INFO - 2023-05-25 08:05:02 --> URI Class Initialized
INFO - 2023-05-25 08:05:02 --> Router Class Initialized
INFO - 2023-05-25 08:05:02 --> Router Class Initialized
INFO - 2023-05-25 08:05:02 --> Output Class Initialized
INFO - 2023-05-25 08:05:02 --> Output Class Initialized
INFO - 2023-05-25 08:05:02 --> Security Class Initialized
INFO - 2023-05-25 08:05:02 --> Security Class Initialized
DEBUG - 2023-05-25 08:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:05:02 --> Input Class Initialized
INFO - 2023-05-25 08:05:02 --> Input Class Initialized
INFO - 2023-05-25 08:05:02 --> Language Class Initialized
INFO - 2023-05-25 08:05:02 --> Language Class Initialized
INFO - 2023-05-25 08:05:02 --> Loader Class Initialized
INFO - 2023-05-25 08:05:02 --> Loader Class Initialized
INFO - 2023-05-25 08:05:02 --> Controller Class Initialized
DEBUG - 2023-05-25 08:05:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:05:02 --> Controller Class Initialized
DEBUG - 2023-05-25 08:05:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:05:02 --> Database Driver Class Initialized
INFO - 2023-05-25 08:05:02 --> Database Driver Class Initialized
INFO - 2023-05-25 08:05:02 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:05:02 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:05:02 --> Database Driver Class Initialized
INFO - 2023-05-25 08:05:02 --> Model "Login_model" initialized
INFO - 2023-05-25 08:05:03 --> Config Class Initialized
INFO - 2023-05-25 08:05:03 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:05:03 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:05:03 --> Utf8 Class Initialized
INFO - 2023-05-25 08:05:03 --> URI Class Initialized
INFO - 2023-05-25 08:05:03 --> Router Class Initialized
INFO - 2023-05-25 08:05:03 --> Output Class Initialized
INFO - 2023-05-25 08:05:03 --> Security Class Initialized
DEBUG - 2023-05-25 08:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:05:03 --> Input Class Initialized
INFO - 2023-05-25 08:05:03 --> Language Class Initialized
INFO - 2023-05-25 08:05:03 --> Loader Class Initialized
INFO - 2023-05-25 08:05:03 --> Controller Class Initialized
DEBUG - 2023-05-25 08:05:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:05:03 --> Database Driver Class Initialized
INFO - 2023-05-25 08:05:03 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:05:03 --> Database Driver Class Initialized
INFO - 2023-05-25 08:05:03 --> Model "Login_model" initialized
INFO - 2023-05-25 08:05:03 --> Final output sent to browser
DEBUG - 2023-05-25 08:05:03 --> Total execution time: 11.9195
INFO - 2023-05-25 08:05:08 --> Final output sent to browser
DEBUG - 2023-05-25 08:05:08 --> Total execution time: 5.6461
INFO - 2023-05-25 08:05:08 --> Config Class Initialized
INFO - 2023-05-25 08:05:08 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:05:08 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:05:08 --> Utf8 Class Initialized
INFO - 2023-05-25 08:05:08 --> URI Class Initialized
INFO - 2023-05-25 08:05:08 --> Router Class Initialized
INFO - 2023-05-25 08:05:08 --> Output Class Initialized
INFO - 2023-05-25 08:05:08 --> Security Class Initialized
DEBUG - 2023-05-25 08:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:05:08 --> Input Class Initialized
INFO - 2023-05-25 08:05:08 --> Language Class Initialized
INFO - 2023-05-25 08:05:08 --> Loader Class Initialized
INFO - 2023-05-25 08:05:08 --> Controller Class Initialized
DEBUG - 2023-05-25 08:05:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:05:08 --> Database Driver Class Initialized
INFO - 2023-05-25 08:05:08 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:05:12 --> Final output sent to browser
DEBUG - 2023-05-25 08:05:12 --> Total execution time: 4.5649
INFO - 2023-05-25 08:05:26 --> Final output sent to browser
DEBUG - 2023-05-25 08:05:26 --> Total execution time: 23.3325
INFO - 2023-05-25 08:05:26 --> Final output sent to browser
DEBUG - 2023-05-25 08:05:26 --> Total execution time: 24.4328
INFO - 2023-05-25 08:05:27 --> Config Class Initialized
INFO - 2023-05-25 08:05:27 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:05:27 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:05:27 --> Utf8 Class Initialized
INFO - 2023-05-25 08:05:27 --> URI Class Initialized
INFO - 2023-05-25 08:05:27 --> Router Class Initialized
INFO - 2023-05-25 08:05:27 --> Output Class Initialized
INFO - 2023-05-25 08:05:27 --> Security Class Initialized
DEBUG - 2023-05-25 08:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:05:27 --> Input Class Initialized
INFO - 2023-05-25 08:05:28 --> Language Class Initialized
INFO - 2023-05-25 08:05:28 --> Loader Class Initialized
INFO - 2023-05-25 08:05:28 --> Controller Class Initialized
DEBUG - 2023-05-25 08:05:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:05:28 --> Database Driver Class Initialized
INFO - 2023-05-25 08:05:29 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:05:29 --> Database Driver Class Initialized
INFO - 2023-05-25 08:05:29 --> Model "Login_model" initialized
INFO - 2023-05-25 08:05:47 --> Config Class Initialized
INFO - 2023-05-25 08:05:47 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:05:47 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:05:47 --> Utf8 Class Initialized
INFO - 2023-05-25 08:05:47 --> URI Class Initialized
INFO - 2023-05-25 08:05:47 --> Router Class Initialized
INFO - 2023-05-25 08:05:47 --> Output Class Initialized
INFO - 2023-05-25 08:05:47 --> Security Class Initialized
DEBUG - 2023-05-25 08:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:05:47 --> Input Class Initialized
INFO - 2023-05-25 08:05:47 --> Language Class Initialized
INFO - 2023-05-25 08:05:47 --> Loader Class Initialized
INFO - 2023-05-25 08:05:47 --> Controller Class Initialized
DEBUG - 2023-05-25 08:05:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:05:47 --> Database Driver Class Initialized
INFO - 2023-05-25 08:05:47 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:05:47 --> Database Driver Class Initialized
INFO - 2023-05-25 08:05:47 --> Model "Login_model" initialized
INFO - 2023-05-25 08:05:48 --> Config Class Initialized
INFO - 2023-05-25 08:05:48 --> Config Class Initialized
INFO - 2023-05-25 08:05:48 --> Hooks Class Initialized
INFO - 2023-05-25 08:05:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:05:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:05:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:05:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:05:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:05:48 --> URI Class Initialized
INFO - 2023-05-25 08:05:48 --> URI Class Initialized
INFO - 2023-05-25 08:05:48 --> Router Class Initialized
INFO - 2023-05-25 08:05:48 --> Router Class Initialized
INFO - 2023-05-25 08:05:48 --> Output Class Initialized
INFO - 2023-05-25 08:05:48 --> Output Class Initialized
INFO - 2023-05-25 08:05:48 --> Security Class Initialized
INFO - 2023-05-25 08:05:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:05:49 --> Input Class Initialized
INFO - 2023-05-25 08:05:49 --> Input Class Initialized
INFO - 2023-05-25 08:05:49 --> Language Class Initialized
INFO - 2023-05-25 08:05:49 --> Language Class Initialized
INFO - 2023-05-25 08:05:49 --> Loader Class Initialized
INFO - 2023-05-25 08:05:49 --> Controller Class Initialized
INFO - 2023-05-25 08:05:49 --> Loader Class Initialized
DEBUG - 2023-05-25 08:05:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:05:49 --> Controller Class Initialized
DEBUG - 2023-05-25 08:05:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:05:49 --> Database Driver Class Initialized
INFO - 2023-05-25 08:05:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:05:49 --> Database Driver Class Initialized
INFO - 2023-05-25 08:05:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:05:49 --> Final output sent to browser
INFO - 2023-05-25 08:05:49 --> Database Driver Class Initialized
DEBUG - 2023-05-25 08:05:49 --> Total execution time: 1.0683
INFO - 2023-05-25 08:05:49 --> Model "Login_model" initialized
INFO - 2023-05-25 08:05:49 --> Config Class Initialized
INFO - 2023-05-25 08:05:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:05:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:05:49 --> Utf8 Class Initialized
INFO - 2023-05-25 08:05:49 --> URI Class Initialized
INFO - 2023-05-25 08:05:49 --> Router Class Initialized
INFO - 2023-05-25 08:05:49 --> Output Class Initialized
INFO - 2023-05-25 08:05:49 --> Security Class Initialized
DEBUG - 2023-05-25 08:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:05:49 --> Input Class Initialized
INFO - 2023-05-25 08:05:49 --> Language Class Initialized
INFO - 2023-05-25 08:05:49 --> Loader Class Initialized
INFO - 2023-05-25 08:05:49 --> Controller Class Initialized
DEBUG - 2023-05-25 08:05:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:05:49 --> Database Driver Class Initialized
INFO - 2023-05-25 08:05:50 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:05:50 --> Final output sent to browser
DEBUG - 2023-05-25 08:05:50 --> Total execution time: 0.7123
INFO - 2023-05-25 08:05:50 --> Final output sent to browser
DEBUG - 2023-05-25 08:05:50 --> Total execution time: 23.9477
INFO - 2023-05-25 08:06:00 --> Final output sent to browser
DEBUG - 2023-05-25 08:06:00 --> Total execution time: 13.5525
INFO - 2023-05-25 08:06:01 --> Final output sent to browser
DEBUG - 2023-05-25 08:06:01 --> Total execution time: 13.3146
INFO - 2023-05-25 08:06:01 --> Config Class Initialized
INFO - 2023-05-25 08:06:01 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:06:01 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:06:01 --> Utf8 Class Initialized
INFO - 2023-05-25 08:06:01 --> URI Class Initialized
INFO - 2023-05-25 08:06:01 --> Router Class Initialized
INFO - 2023-05-25 08:06:01 --> Output Class Initialized
INFO - 2023-05-25 08:06:01 --> Security Class Initialized
DEBUG - 2023-05-25 08:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:06:01 --> Input Class Initialized
INFO - 2023-05-25 08:06:01 --> Language Class Initialized
INFO - 2023-05-25 08:06:01 --> Loader Class Initialized
INFO - 2023-05-25 08:06:01 --> Controller Class Initialized
DEBUG - 2023-05-25 08:06:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:06:01 --> Database Driver Class Initialized
INFO - 2023-05-25 08:06:01 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:06:01 --> Database Driver Class Initialized
INFO - 2023-05-25 08:06:01 --> Model "Login_model" initialized
INFO - 2023-05-25 08:06:11 --> Final output sent to browser
DEBUG - 2023-05-25 08:06:11 --> Total execution time: 9.7124
INFO - 2023-05-25 08:06:48 --> Config Class Initialized
INFO - 2023-05-25 08:06:48 --> Config Class Initialized
INFO - 2023-05-25 08:06:48 --> Hooks Class Initialized
INFO - 2023-05-25 08:06:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:06:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:06:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:06:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:06:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:06:48 --> URI Class Initialized
INFO - 2023-05-25 08:06:48 --> URI Class Initialized
INFO - 2023-05-25 08:06:48 --> Router Class Initialized
INFO - 2023-05-25 08:06:48 --> Router Class Initialized
INFO - 2023-05-25 08:06:48 --> Output Class Initialized
INFO - 2023-05-25 08:06:48 --> Output Class Initialized
INFO - 2023-05-25 08:06:48 --> Security Class Initialized
INFO - 2023-05-25 08:06:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:06:48 --> Input Class Initialized
INFO - 2023-05-25 08:06:48 --> Input Class Initialized
INFO - 2023-05-25 08:06:48 --> Language Class Initialized
INFO - 2023-05-25 08:06:48 --> Language Class Initialized
INFO - 2023-05-25 08:06:48 --> Loader Class Initialized
INFO - 2023-05-25 08:06:48 --> Loader Class Initialized
INFO - 2023-05-25 08:06:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:06:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:06:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:06:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:06:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:06:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:06:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:06:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:06:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:06:48 --> Model "Login_model" initialized
INFO - 2023-05-25 08:06:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:06:48 --> Total execution time: 0.2181
INFO - 2023-05-25 08:06:48 --> Config Class Initialized
INFO - 2023-05-25 08:06:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:06:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:06:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:06:48 --> URI Class Initialized
INFO - 2023-05-25 08:06:48 --> Router Class Initialized
INFO - 2023-05-25 08:06:48 --> Output Class Initialized
INFO - 2023-05-25 08:06:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:06:48 --> Input Class Initialized
INFO - 2023-05-25 08:06:48 --> Language Class Initialized
INFO - 2023-05-25 08:06:48 --> Loader Class Initialized
INFO - 2023-05-25 08:06:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:06:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:06:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:06:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:06:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:06:48 --> Total execution time: 0.2366
INFO - 2023-05-25 08:06:58 --> Final output sent to browser
DEBUG - 2023-05-25 08:06:58 --> Total execution time: 10.2195
INFO - 2023-05-25 08:06:58 --> Config Class Initialized
INFO - 2023-05-25 08:06:58 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:06:58 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:06:58 --> Utf8 Class Initialized
INFO - 2023-05-25 08:06:58 --> URI Class Initialized
INFO - 2023-05-25 08:06:58 --> Router Class Initialized
INFO - 2023-05-25 08:06:58 --> Output Class Initialized
INFO - 2023-05-25 08:06:58 --> Security Class Initialized
DEBUG - 2023-05-25 08:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:06:58 --> Input Class Initialized
INFO - 2023-05-25 08:06:58 --> Language Class Initialized
INFO - 2023-05-25 08:06:58 --> Loader Class Initialized
INFO - 2023-05-25 08:06:58 --> Controller Class Initialized
DEBUG - 2023-05-25 08:06:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:06:58 --> Database Driver Class Initialized
INFO - 2023-05-25 08:06:58 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:06:58 --> Database Driver Class Initialized
INFO - 2023-05-25 08:06:58 --> Model "Login_model" initialized
INFO - 2023-05-25 08:07:09 --> Final output sent to browser
DEBUG - 2023-05-25 08:07:09 --> Total execution time: 11.5861
INFO - 2023-05-25 08:07:48 --> Config Class Initialized
INFO - 2023-05-25 08:07:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:07:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:07:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:07:48 --> URI Class Initialized
INFO - 2023-05-25 08:07:48 --> Router Class Initialized
INFO - 2023-05-25 08:07:48 --> Output Class Initialized
INFO - 2023-05-25 08:07:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:07:48 --> Input Class Initialized
INFO - 2023-05-25 08:07:48 --> Language Class Initialized
INFO - 2023-05-25 08:07:48 --> Loader Class Initialized
INFO - 2023-05-25 08:07:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:07:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:07:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:07:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:07:49 --> Config Class Initialized
INFO - 2023-05-25 08:07:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:07:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:07:49 --> Utf8 Class Initialized
INFO - 2023-05-25 08:07:49 --> URI Class Initialized
INFO - 2023-05-25 08:07:49 --> Router Class Initialized
INFO - 2023-05-25 08:07:49 --> Output Class Initialized
INFO - 2023-05-25 08:07:49 --> Security Class Initialized
DEBUG - 2023-05-25 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:07:49 --> Input Class Initialized
INFO - 2023-05-25 08:07:49 --> Language Class Initialized
INFO - 2023-05-25 08:07:49 --> Loader Class Initialized
INFO - 2023-05-25 08:07:49 --> Controller Class Initialized
DEBUG - 2023-05-25 08:07:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:07:49 --> Database Driver Class Initialized
INFO - 2023-05-25 08:07:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:07:49 --> Database Driver Class Initialized
INFO - 2023-05-25 08:07:49 --> Model "Login_model" initialized
INFO - 2023-05-25 08:07:49 --> Final output sent to browser
DEBUG - 2023-05-25 08:07:49 --> Total execution time: 1.4201
INFO - 2023-05-25 08:07:49 --> Config Class Initialized
INFO - 2023-05-25 08:07:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:07:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:07:49 --> Utf8 Class Initialized
INFO - 2023-05-25 08:07:49 --> URI Class Initialized
INFO - 2023-05-25 08:07:49 --> Router Class Initialized
INFO - 2023-05-25 08:07:49 --> Output Class Initialized
INFO - 2023-05-25 08:07:49 --> Security Class Initialized
DEBUG - 2023-05-25 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:07:49 --> Input Class Initialized
INFO - 2023-05-25 08:07:49 --> Language Class Initialized
INFO - 2023-05-25 08:07:49 --> Loader Class Initialized
INFO - 2023-05-25 08:07:49 --> Controller Class Initialized
DEBUG - 2023-05-25 08:07:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:07:49 --> Database Driver Class Initialized
INFO - 2023-05-25 08:07:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:07:50 --> Final output sent to browser
DEBUG - 2023-05-25 08:07:50 --> Total execution time: 0.8403
INFO - 2023-05-25 08:08:01 --> Final output sent to browser
DEBUG - 2023-05-25 08:08:01 --> Total execution time: 12.4865
INFO - 2023-05-25 08:08:01 --> Config Class Initialized
INFO - 2023-05-25 08:08:01 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:08:01 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:08:01 --> Utf8 Class Initialized
INFO - 2023-05-25 08:08:01 --> URI Class Initialized
INFO - 2023-05-25 08:08:01 --> Router Class Initialized
INFO - 2023-05-25 08:08:01 --> Output Class Initialized
INFO - 2023-05-25 08:08:01 --> Security Class Initialized
DEBUG - 2023-05-25 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:08:01 --> Input Class Initialized
INFO - 2023-05-25 08:08:01 --> Language Class Initialized
INFO - 2023-05-25 08:08:01 --> Loader Class Initialized
INFO - 2023-05-25 08:08:01 --> Controller Class Initialized
DEBUG - 2023-05-25 08:08:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:08:01 --> Database Driver Class Initialized
INFO - 2023-05-25 08:08:01 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:08:01 --> Database Driver Class Initialized
INFO - 2023-05-25 08:08:01 --> Model "Login_model" initialized
INFO - 2023-05-25 08:08:14 --> Final output sent to browser
DEBUG - 2023-05-25 08:08:14 --> Total execution time: 12.4943
INFO - 2023-05-25 08:09:39 --> Config Class Initialized
INFO - 2023-05-25 08:09:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:09:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:09:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:09:39 --> URI Class Initialized
INFO - 2023-05-25 08:09:39 --> Router Class Initialized
INFO - 2023-05-25 08:09:39 --> Output Class Initialized
INFO - 2023-05-25 08:09:39 --> Security Class Initialized
DEBUG - 2023-05-25 08:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:09:39 --> Input Class Initialized
INFO - 2023-05-25 08:09:39 --> Language Class Initialized
INFO - 2023-05-25 08:09:39 --> Loader Class Initialized
INFO - 2023-05-25 08:09:39 --> Controller Class Initialized
DEBUG - 2023-05-25 08:09:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:09:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:09:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:09:52 --> Final output sent to browser
DEBUG - 2023-05-25 08:09:52 --> Total execution time: 13.0516
INFO - 2023-05-25 08:09:52 --> Config Class Initialized
INFO - 2023-05-25 08:09:52 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:09:52 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:09:52 --> Utf8 Class Initialized
INFO - 2023-05-25 08:09:52 --> URI Class Initialized
INFO - 2023-05-25 08:09:52 --> Router Class Initialized
INFO - 2023-05-25 08:09:52 --> Output Class Initialized
INFO - 2023-05-25 08:09:52 --> Security Class Initialized
DEBUG - 2023-05-25 08:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:09:52 --> Input Class Initialized
INFO - 2023-05-25 08:09:52 --> Language Class Initialized
INFO - 2023-05-25 08:09:52 --> Loader Class Initialized
INFO - 2023-05-25 08:09:52 --> Controller Class Initialized
DEBUG - 2023-05-25 08:09:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:09:52 --> Database Driver Class Initialized
INFO - 2023-05-25 08:09:52 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:09:54 --> Final output sent to browser
DEBUG - 2023-05-25 08:09:54 --> Total execution time: 1.9627
INFO - 2023-05-25 08:10:39 --> Config Class Initialized
INFO - 2023-05-25 08:10:39 --> Config Class Initialized
INFO - 2023-05-25 08:10:39 --> Hooks Class Initialized
INFO - 2023-05-25 08:10:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:10:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:10:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:10:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:10:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:10:39 --> URI Class Initialized
INFO - 2023-05-25 08:10:39 --> URI Class Initialized
INFO - 2023-05-25 08:10:39 --> Router Class Initialized
INFO - 2023-05-25 08:10:39 --> Router Class Initialized
INFO - 2023-05-25 08:10:39 --> Output Class Initialized
INFO - 2023-05-25 08:10:39 --> Output Class Initialized
INFO - 2023-05-25 08:10:39 --> Security Class Initialized
INFO - 2023-05-25 08:10:39 --> Security Class Initialized
DEBUG - 2023-05-25 08:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:10:39 --> Input Class Initialized
INFO - 2023-05-25 08:10:39 --> Input Class Initialized
INFO - 2023-05-25 08:10:39 --> Language Class Initialized
INFO - 2023-05-25 08:10:39 --> Language Class Initialized
INFO - 2023-05-25 08:10:39 --> Loader Class Initialized
INFO - 2023-05-25 08:10:39 --> Loader Class Initialized
INFO - 2023-05-25 08:10:39 --> Controller Class Initialized
INFO - 2023-05-25 08:10:39 --> Controller Class Initialized
DEBUG - 2023-05-25 08:10:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 08:10:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:10:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:10:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:10:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:10:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:10:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:10:39 --> Model "Login_model" initialized
INFO - 2023-05-25 08:10:49 --> Final output sent to browser
DEBUG - 2023-05-25 08:10:49 --> Total execution time: 10.8061
INFO - 2023-05-25 08:10:50 --> Config Class Initialized
INFO - 2023-05-25 08:10:50 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:10:50 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:10:50 --> Utf8 Class Initialized
INFO - 2023-05-25 08:10:50 --> URI Class Initialized
INFO - 2023-05-25 08:10:50 --> Router Class Initialized
INFO - 2023-05-25 08:10:50 --> Output Class Initialized
INFO - 2023-05-25 08:10:50 --> Security Class Initialized
DEBUG - 2023-05-25 08:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:10:50 --> Input Class Initialized
INFO - 2023-05-25 08:10:50 --> Language Class Initialized
INFO - 2023-05-25 08:10:50 --> Loader Class Initialized
INFO - 2023-05-25 08:10:50 --> Controller Class Initialized
DEBUG - 2023-05-25 08:10:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:10:50 --> Database Driver Class Initialized
INFO - 2023-05-25 08:10:50 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:10:52 --> Final output sent to browser
DEBUG - 2023-05-25 08:10:52 --> Total execution time: 2.2023
INFO - 2023-05-25 08:10:57 --> Final output sent to browser
DEBUG - 2023-05-25 08:10:57 --> Total execution time: 18.2680
INFO - 2023-05-25 08:10:57 --> Config Class Initialized
INFO - 2023-05-25 08:10:57 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:10:57 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:10:57 --> Utf8 Class Initialized
INFO - 2023-05-25 08:10:57 --> URI Class Initialized
INFO - 2023-05-25 08:10:57 --> Router Class Initialized
INFO - 2023-05-25 08:10:57 --> Output Class Initialized
INFO - 2023-05-25 08:10:57 --> Security Class Initialized
DEBUG - 2023-05-25 08:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:10:57 --> Input Class Initialized
INFO - 2023-05-25 08:10:57 --> Language Class Initialized
INFO - 2023-05-25 08:10:57 --> Loader Class Initialized
INFO - 2023-05-25 08:10:57 --> Controller Class Initialized
DEBUG - 2023-05-25 08:10:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:10:57 --> Database Driver Class Initialized
INFO - 2023-05-25 08:10:57 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:10:57 --> Database Driver Class Initialized
INFO - 2023-05-25 08:10:57 --> Model "Login_model" initialized
INFO - 2023-05-25 08:11:06 --> Final output sent to browser
DEBUG - 2023-05-25 08:11:06 --> Total execution time: 8.6356
INFO - 2023-05-25 08:11:39 --> Config Class Initialized
INFO - 2023-05-25 08:11:39 --> Config Class Initialized
INFO - 2023-05-25 08:11:39 --> Hooks Class Initialized
INFO - 2023-05-25 08:11:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:11:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:11:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:11:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:11:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:11:39 --> URI Class Initialized
INFO - 2023-05-25 08:11:39 --> URI Class Initialized
INFO - 2023-05-25 08:11:39 --> Router Class Initialized
INFO - 2023-05-25 08:11:39 --> Router Class Initialized
INFO - 2023-05-25 08:11:39 --> Output Class Initialized
INFO - 2023-05-25 08:11:39 --> Output Class Initialized
INFO - 2023-05-25 08:11:39 --> Security Class Initialized
INFO - 2023-05-25 08:11:39 --> Security Class Initialized
DEBUG - 2023-05-25 08:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:11:39 --> Input Class Initialized
INFO - 2023-05-25 08:11:39 --> Input Class Initialized
INFO - 2023-05-25 08:11:39 --> Language Class Initialized
INFO - 2023-05-25 08:11:39 --> Language Class Initialized
INFO - 2023-05-25 08:11:39 --> Loader Class Initialized
INFO - 2023-05-25 08:11:39 --> Loader Class Initialized
INFO - 2023-05-25 08:11:39 --> Controller Class Initialized
DEBUG - 2023-05-25 08:11:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:11:39 --> Controller Class Initialized
DEBUG - 2023-05-25 08:11:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:11:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:11:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:11:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:11:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:11:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:11:39 --> Model "Login_model" initialized
INFO - 2023-05-25 08:11:39 --> Final output sent to browser
DEBUG - 2023-05-25 08:11:39 --> Total execution time: 0.5804
INFO - 2023-05-25 08:11:39 --> Config Class Initialized
INFO - 2023-05-25 08:11:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:11:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:11:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:11:39 --> URI Class Initialized
INFO - 2023-05-25 08:11:39 --> Router Class Initialized
INFO - 2023-05-25 08:11:39 --> Output Class Initialized
INFO - 2023-05-25 08:11:39 --> Security Class Initialized
DEBUG - 2023-05-25 08:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:11:39 --> Input Class Initialized
INFO - 2023-05-25 08:11:39 --> Language Class Initialized
INFO - 2023-05-25 08:11:39 --> Loader Class Initialized
INFO - 2023-05-25 08:11:39 --> Controller Class Initialized
DEBUG - 2023-05-25 08:11:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:11:40 --> Database Driver Class Initialized
INFO - 2023-05-25 08:11:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:11:40 --> Final output sent to browser
DEBUG - 2023-05-25 08:11:40 --> Total execution time: 0.2765
INFO - 2023-05-25 08:11:47 --> Final output sent to browser
DEBUG - 2023-05-25 08:11:47 --> Total execution time: 8.6196
INFO - 2023-05-25 08:11:47 --> Config Class Initialized
INFO - 2023-05-25 08:11:47 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:11:47 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:11:47 --> Utf8 Class Initialized
INFO - 2023-05-25 08:11:47 --> URI Class Initialized
INFO - 2023-05-25 08:11:47 --> Router Class Initialized
INFO - 2023-05-25 08:11:47 --> Output Class Initialized
INFO - 2023-05-25 08:11:47 --> Security Class Initialized
DEBUG - 2023-05-25 08:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:11:47 --> Input Class Initialized
INFO - 2023-05-25 08:11:47 --> Language Class Initialized
INFO - 2023-05-25 08:11:47 --> Loader Class Initialized
INFO - 2023-05-25 08:11:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:11:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:11:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:11:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:11:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:11:48 --> Model "Login_model" initialized
INFO - 2023-05-25 08:11:56 --> Final output sent to browser
DEBUG - 2023-05-25 08:11:56 --> Total execution time: 8.9206
INFO - 2023-05-25 08:12:39 --> Config Class Initialized
INFO - 2023-05-25 08:12:39 --> Config Class Initialized
INFO - 2023-05-25 08:12:39 --> Hooks Class Initialized
INFO - 2023-05-25 08:12:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:12:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:12:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:12:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:12:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:12:39 --> URI Class Initialized
INFO - 2023-05-25 08:12:39 --> URI Class Initialized
INFO - 2023-05-25 08:12:39 --> Router Class Initialized
INFO - 2023-05-25 08:12:39 --> Router Class Initialized
INFO - 2023-05-25 08:12:39 --> Output Class Initialized
INFO - 2023-05-25 08:12:39 --> Output Class Initialized
INFO - 2023-05-25 08:12:39 --> Security Class Initialized
INFO - 2023-05-25 08:12:39 --> Security Class Initialized
DEBUG - 2023-05-25 08:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:12:39 --> Input Class Initialized
INFO - 2023-05-25 08:12:39 --> Input Class Initialized
INFO - 2023-05-25 08:12:39 --> Language Class Initialized
INFO - 2023-05-25 08:12:39 --> Language Class Initialized
INFO - 2023-05-25 08:12:39 --> Loader Class Initialized
INFO - 2023-05-25 08:12:39 --> Loader Class Initialized
INFO - 2023-05-25 08:12:39 --> Controller Class Initialized
INFO - 2023-05-25 08:12:39 --> Controller Class Initialized
DEBUG - 2023-05-25 08:12:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 08:12:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:12:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:12:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:12:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:12:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:12:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:12:39 --> Model "Login_model" initialized
INFO - 2023-05-25 08:12:40 --> Final output sent to browser
DEBUG - 2023-05-25 08:12:40 --> Total execution time: 0.9052
INFO - 2023-05-25 08:12:40 --> Config Class Initialized
INFO - 2023-05-25 08:12:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:12:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:12:40 --> Utf8 Class Initialized
INFO - 2023-05-25 08:12:40 --> URI Class Initialized
INFO - 2023-05-25 08:12:40 --> Router Class Initialized
INFO - 2023-05-25 08:12:40 --> Output Class Initialized
INFO - 2023-05-25 08:12:40 --> Security Class Initialized
DEBUG - 2023-05-25 08:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:12:40 --> Input Class Initialized
INFO - 2023-05-25 08:12:40 --> Language Class Initialized
INFO - 2023-05-25 08:12:40 --> Loader Class Initialized
INFO - 2023-05-25 08:12:40 --> Controller Class Initialized
DEBUG - 2023-05-25 08:12:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:12:40 --> Database Driver Class Initialized
INFO - 2023-05-25 08:12:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:12:40 --> Final output sent to browser
DEBUG - 2023-05-25 08:12:40 --> Total execution time: 0.5886
INFO - 2023-05-25 08:12:50 --> Final output sent to browser
DEBUG - 2023-05-25 08:12:50 --> Total execution time: 11.7721
INFO - 2023-05-25 08:12:50 --> Config Class Initialized
INFO - 2023-05-25 08:12:50 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:12:51 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:12:51 --> Utf8 Class Initialized
INFO - 2023-05-25 08:12:51 --> URI Class Initialized
INFO - 2023-05-25 08:12:51 --> Router Class Initialized
INFO - 2023-05-25 08:12:51 --> Output Class Initialized
INFO - 2023-05-25 08:12:51 --> Security Class Initialized
DEBUG - 2023-05-25 08:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:12:51 --> Input Class Initialized
INFO - 2023-05-25 08:12:51 --> Language Class Initialized
INFO - 2023-05-25 08:12:51 --> Loader Class Initialized
INFO - 2023-05-25 08:12:51 --> Controller Class Initialized
DEBUG - 2023-05-25 08:12:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:12:51 --> Database Driver Class Initialized
INFO - 2023-05-25 08:12:51 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:12:51 --> Database Driver Class Initialized
INFO - 2023-05-25 08:12:51 --> Model "Login_model" initialized
INFO - 2023-05-25 08:13:01 --> Final output sent to browser
DEBUG - 2023-05-25 08:13:01 --> Total execution time: 10.9890
INFO - 2023-05-25 08:13:39 --> Config Class Initialized
INFO - 2023-05-25 08:13:39 --> Config Class Initialized
INFO - 2023-05-25 08:13:39 --> Hooks Class Initialized
INFO - 2023-05-25 08:13:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:13:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:13:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:13:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:13:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:13:39 --> URI Class Initialized
INFO - 2023-05-25 08:13:39 --> URI Class Initialized
INFO - 2023-05-25 08:13:39 --> Router Class Initialized
INFO - 2023-05-25 08:13:39 --> Router Class Initialized
INFO - 2023-05-25 08:13:39 --> Output Class Initialized
INFO - 2023-05-25 08:13:39 --> Output Class Initialized
INFO - 2023-05-25 08:13:39 --> Security Class Initialized
INFO - 2023-05-25 08:13:39 --> Security Class Initialized
DEBUG - 2023-05-25 08:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:13:39 --> Input Class Initialized
INFO - 2023-05-25 08:13:39 --> Input Class Initialized
INFO - 2023-05-25 08:13:39 --> Language Class Initialized
INFO - 2023-05-25 08:13:39 --> Language Class Initialized
INFO - 2023-05-25 08:13:39 --> Loader Class Initialized
INFO - 2023-05-25 08:13:39 --> Loader Class Initialized
INFO - 2023-05-25 08:13:39 --> Controller Class Initialized
INFO - 2023-05-25 08:13:39 --> Controller Class Initialized
DEBUG - 2023-05-25 08:13:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 08:13:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:13:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:13:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:13:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:13:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:13:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:13:39 --> Model "Login_model" initialized
INFO - 2023-05-25 08:13:43 --> Final output sent to browser
DEBUG - 2023-05-25 08:13:43 --> Total execution time: 4.7113
INFO - 2023-05-25 08:13:43 --> Config Class Initialized
INFO - 2023-05-25 08:13:43 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:13:43 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:13:43 --> Utf8 Class Initialized
INFO - 2023-05-25 08:13:43 --> URI Class Initialized
INFO - 2023-05-25 08:13:43 --> Router Class Initialized
INFO - 2023-05-25 08:13:44 --> Output Class Initialized
INFO - 2023-05-25 08:13:44 --> Security Class Initialized
DEBUG - 2023-05-25 08:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:13:44 --> Input Class Initialized
INFO - 2023-05-25 08:13:44 --> Language Class Initialized
INFO - 2023-05-25 08:13:44 --> Loader Class Initialized
INFO - 2023-05-25 08:13:44 --> Controller Class Initialized
DEBUG - 2023-05-25 08:13:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:13:44 --> Database Driver Class Initialized
INFO - 2023-05-25 08:13:44 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:13:44 --> Final output sent to browser
DEBUG - 2023-05-25 08:13:44 --> Total execution time: 0.8373
INFO - 2023-05-25 08:13:55 --> Final output sent to browser
DEBUG - 2023-05-25 08:13:55 --> Total execution time: 16.1656
INFO - 2023-05-25 08:13:55 --> Config Class Initialized
INFO - 2023-05-25 08:13:55 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:13:55 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:13:55 --> Utf8 Class Initialized
INFO - 2023-05-25 08:13:55 --> URI Class Initialized
INFO - 2023-05-25 08:13:55 --> Router Class Initialized
INFO - 2023-05-25 08:13:55 --> Output Class Initialized
INFO - 2023-05-25 08:13:55 --> Security Class Initialized
DEBUG - 2023-05-25 08:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:13:55 --> Input Class Initialized
INFO - 2023-05-25 08:13:55 --> Language Class Initialized
INFO - 2023-05-25 08:13:55 --> Loader Class Initialized
INFO - 2023-05-25 08:13:55 --> Controller Class Initialized
DEBUG - 2023-05-25 08:13:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:13:55 --> Database Driver Class Initialized
INFO - 2023-05-25 08:13:55 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:13:55 --> Database Driver Class Initialized
INFO - 2023-05-25 08:13:55 --> Model "Login_model" initialized
INFO - 2023-05-25 08:14:07 --> Final output sent to browser
DEBUG - 2023-05-25 08:14:07 --> Total execution time: 11.9741
INFO - 2023-05-25 08:14:39 --> Config Class Initialized
INFO - 2023-05-25 08:14:39 --> Config Class Initialized
INFO - 2023-05-25 08:14:39 --> Hooks Class Initialized
INFO - 2023-05-25 08:14:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:14:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:14:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:14:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:14:39 --> Utf8 Class Initialized
INFO - 2023-05-25 08:14:39 --> URI Class Initialized
INFO - 2023-05-25 08:14:39 --> URI Class Initialized
INFO - 2023-05-25 08:14:39 --> Router Class Initialized
INFO - 2023-05-25 08:14:39 --> Router Class Initialized
INFO - 2023-05-25 08:14:39 --> Output Class Initialized
INFO - 2023-05-25 08:14:39 --> Output Class Initialized
INFO - 2023-05-25 08:14:39 --> Security Class Initialized
INFO - 2023-05-25 08:14:39 --> Security Class Initialized
DEBUG - 2023-05-25 08:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:14:39 --> Input Class Initialized
INFO - 2023-05-25 08:14:39 --> Input Class Initialized
INFO - 2023-05-25 08:14:39 --> Language Class Initialized
INFO - 2023-05-25 08:14:39 --> Language Class Initialized
INFO - 2023-05-25 08:14:39 --> Loader Class Initialized
INFO - 2023-05-25 08:14:39 --> Loader Class Initialized
INFO - 2023-05-25 08:14:39 --> Controller Class Initialized
INFO - 2023-05-25 08:14:39 --> Controller Class Initialized
DEBUG - 2023-05-25 08:14:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 08:14:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:14:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:14:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:14:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:14:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:14:39 --> Database Driver Class Initialized
INFO - 2023-05-25 08:14:39 --> Model "Login_model" initialized
INFO - 2023-05-25 08:14:40 --> Final output sent to browser
DEBUG - 2023-05-25 08:14:40 --> Total execution time: 0.9092
INFO - 2023-05-25 08:14:40 --> Config Class Initialized
INFO - 2023-05-25 08:14:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:14:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:14:40 --> Utf8 Class Initialized
INFO - 2023-05-25 08:14:40 --> URI Class Initialized
INFO - 2023-05-25 08:14:40 --> Router Class Initialized
INFO - 2023-05-25 08:14:40 --> Output Class Initialized
INFO - 2023-05-25 08:14:40 --> Security Class Initialized
DEBUG - 2023-05-25 08:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:14:40 --> Input Class Initialized
INFO - 2023-05-25 08:14:40 --> Language Class Initialized
INFO - 2023-05-25 08:14:40 --> Loader Class Initialized
INFO - 2023-05-25 08:14:40 --> Controller Class Initialized
DEBUG - 2023-05-25 08:14:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:14:41 --> Database Driver Class Initialized
INFO - 2023-05-25 08:14:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:14:41 --> Final output sent to browser
DEBUG - 2023-05-25 08:14:41 --> Total execution time: 0.9679
INFO - 2023-05-25 08:14:41 --> Config Class Initialized
INFO - 2023-05-25 08:14:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:14:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:14:41 --> Utf8 Class Initialized
INFO - 2023-05-25 08:14:41 --> URI Class Initialized
INFO - 2023-05-25 08:14:41 --> Router Class Initialized
INFO - 2023-05-25 08:14:41 --> Output Class Initialized
INFO - 2023-05-25 08:14:41 --> Security Class Initialized
DEBUG - 2023-05-25 08:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:14:41 --> Input Class Initialized
INFO - 2023-05-25 08:14:41 --> Language Class Initialized
INFO - 2023-05-25 08:14:41 --> Loader Class Initialized
INFO - 2023-05-25 08:14:41 --> Controller Class Initialized
DEBUG - 2023-05-25 08:14:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:14:41 --> Database Driver Class Initialized
INFO - 2023-05-25 08:14:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:14:41 --> Database Driver Class Initialized
INFO - 2023-05-25 08:14:41 --> Model "Login_model" initialized
INFO - 2023-05-25 08:14:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:14:48 --> Total execution time: 8.7464
INFO - 2023-05-25 08:14:48 --> Config Class Initialized
INFO - 2023-05-25 08:14:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:14:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:14:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:14:48 --> URI Class Initialized
INFO - 2023-05-25 08:14:48 --> Router Class Initialized
INFO - 2023-05-25 08:14:48 --> Output Class Initialized
INFO - 2023-05-25 08:14:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:14:48 --> Input Class Initialized
INFO - 2023-05-25 08:14:48 --> Language Class Initialized
INFO - 2023-05-25 08:14:48 --> Loader Class Initialized
INFO - 2023-05-25 08:14:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:14:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:14:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:14:48 --> Config Class Initialized
INFO - 2023-05-25 08:14:48 --> Hooks Class Initialized
INFO - 2023-05-25 08:14:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:14:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:14:48 --> Model "Login_model" initialized
DEBUG - 2023-05-25 08:14:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:14:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:14:48 --> URI Class Initialized
INFO - 2023-05-25 08:14:48 --> Router Class Initialized
INFO - 2023-05-25 08:14:48 --> Output Class Initialized
INFO - 2023-05-25 08:14:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:14:48 --> Input Class Initialized
INFO - 2023-05-25 08:14:48 --> Language Class Initialized
INFO - 2023-05-25 08:14:48 --> Loader Class Initialized
INFO - 2023-05-25 08:14:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:14:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:14:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:14:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:14:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:14:48 --> Total execution time: 0.3299
INFO - 2023-05-25 08:14:48 --> Config Class Initialized
INFO - 2023-05-25 08:14:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:14:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:14:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:14:48 --> URI Class Initialized
INFO - 2023-05-25 08:14:48 --> Router Class Initialized
INFO - 2023-05-25 08:14:48 --> Output Class Initialized
INFO - 2023-05-25 08:14:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:14:48 --> Input Class Initialized
INFO - 2023-05-25 08:14:48 --> Language Class Initialized
INFO - 2023-05-25 08:14:48 --> Loader Class Initialized
INFO - 2023-05-25 08:14:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:14:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:14:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:14:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:14:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:14:48 --> Total execution time: 0.2210
INFO - 2023-05-25 08:14:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:14:48 --> Total execution time: 7.3202
INFO - 2023-05-25 08:14:58 --> Final output sent to browser
DEBUG - 2023-05-25 08:14:58 --> Total execution time: 10.2982
INFO - 2023-05-25 08:14:58 --> Config Class Initialized
INFO - 2023-05-25 08:14:58 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:14:58 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:14:58 --> Utf8 Class Initialized
INFO - 2023-05-25 08:14:58 --> URI Class Initialized
INFO - 2023-05-25 08:14:58 --> Router Class Initialized
INFO - 2023-05-25 08:14:58 --> Output Class Initialized
INFO - 2023-05-25 08:14:58 --> Security Class Initialized
DEBUG - 2023-05-25 08:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:14:58 --> Input Class Initialized
INFO - 2023-05-25 08:14:58 --> Language Class Initialized
INFO - 2023-05-25 08:14:58 --> Loader Class Initialized
INFO - 2023-05-25 08:14:58 --> Controller Class Initialized
DEBUG - 2023-05-25 08:14:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:14:58 --> Database Driver Class Initialized
INFO - 2023-05-25 08:14:58 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:14:58 --> Database Driver Class Initialized
INFO - 2023-05-25 08:14:58 --> Model "Login_model" initialized
INFO - 2023-05-25 08:15:10 --> Config Class Initialized
INFO - 2023-05-25 08:15:10 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:15:10 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:15:10 --> Utf8 Class Initialized
INFO - 2023-05-25 08:15:10 --> URI Class Initialized
INFO - 2023-05-25 08:15:10 --> Router Class Initialized
INFO - 2023-05-25 08:15:10 --> Output Class Initialized
INFO - 2023-05-25 08:15:10 --> Security Class Initialized
DEBUG - 2023-05-25 08:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:15:10 --> Input Class Initialized
INFO - 2023-05-25 08:15:10 --> Language Class Initialized
INFO - 2023-05-25 08:15:10 --> Loader Class Initialized
INFO - 2023-05-25 08:15:10 --> Controller Class Initialized
DEBUG - 2023-05-25 08:15:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:15:10 --> Database Driver Class Initialized
INFO - 2023-05-25 08:15:10 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:15:10 --> Database Driver Class Initialized
INFO - 2023-05-25 08:15:10 --> Model "Login_model" initialized
INFO - 2023-05-25 08:15:13 --> Final output sent to browser
DEBUG - 2023-05-25 08:15:13 --> Total execution time: 15.2148
INFO - 2023-05-25 08:15:25 --> Final output sent to browser
DEBUG - 2023-05-25 08:15:25 --> Total execution time: 15.1453
INFO - 2023-05-25 08:15:48 --> Config Class Initialized
INFO - 2023-05-25 08:15:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:15:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:15:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:15:48 --> URI Class Initialized
INFO - 2023-05-25 08:15:48 --> Router Class Initialized
INFO - 2023-05-25 08:15:48 --> Output Class Initialized
INFO - 2023-05-25 08:15:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:15:48 --> Input Class Initialized
INFO - 2023-05-25 08:15:48 --> Language Class Initialized
INFO - 2023-05-25 08:15:48 --> Loader Class Initialized
INFO - 2023-05-25 08:15:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:15:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:15:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:15:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:15:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:15:48 --> Total execution time: 0.2069
INFO - 2023-05-25 08:15:48 --> Config Class Initialized
INFO - 2023-05-25 08:15:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:15:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:15:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:15:48 --> URI Class Initialized
INFO - 2023-05-25 08:15:48 --> Router Class Initialized
INFO - 2023-05-25 08:15:48 --> Output Class Initialized
INFO - 2023-05-25 08:15:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:15:48 --> Input Class Initialized
INFO - 2023-05-25 08:15:48 --> Language Class Initialized
INFO - 2023-05-25 08:15:48 --> Loader Class Initialized
INFO - 2023-05-25 08:15:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:15:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:15:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:15:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:15:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:15:48 --> Total execution time: 0.3060
INFO - 2023-05-25 08:15:49 --> Config Class Initialized
INFO - 2023-05-25 08:15:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:15:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:15:49 --> Utf8 Class Initialized
INFO - 2023-05-25 08:15:49 --> URI Class Initialized
INFO - 2023-05-25 08:15:49 --> Router Class Initialized
INFO - 2023-05-25 08:15:49 --> Output Class Initialized
INFO - 2023-05-25 08:15:49 --> Security Class Initialized
DEBUG - 2023-05-25 08:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:15:49 --> Input Class Initialized
INFO - 2023-05-25 08:15:49 --> Language Class Initialized
INFO - 2023-05-25 08:15:49 --> Loader Class Initialized
INFO - 2023-05-25 08:15:49 --> Controller Class Initialized
DEBUG - 2023-05-25 08:15:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:15:49 --> Database Driver Class Initialized
INFO - 2023-05-25 08:15:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:15:49 --> Database Driver Class Initialized
INFO - 2023-05-25 08:15:49 --> Model "Login_model" initialized
INFO - 2023-05-25 08:16:00 --> Final output sent to browser
DEBUG - 2023-05-25 08:16:00 --> Total execution time: 11.0221
INFO - 2023-05-25 08:16:00 --> Config Class Initialized
INFO - 2023-05-25 08:16:00 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:16:00 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:16:00 --> Utf8 Class Initialized
INFO - 2023-05-25 08:16:00 --> URI Class Initialized
INFO - 2023-05-25 08:16:00 --> Router Class Initialized
INFO - 2023-05-25 08:16:00 --> Output Class Initialized
INFO - 2023-05-25 08:16:00 --> Security Class Initialized
DEBUG - 2023-05-25 08:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:16:00 --> Input Class Initialized
INFO - 2023-05-25 08:16:00 --> Language Class Initialized
INFO - 2023-05-25 08:16:00 --> Loader Class Initialized
INFO - 2023-05-25 08:16:00 --> Controller Class Initialized
DEBUG - 2023-05-25 08:16:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:16:00 --> Database Driver Class Initialized
INFO - 2023-05-25 08:16:00 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:16:00 --> Database Driver Class Initialized
INFO - 2023-05-25 08:16:00 --> Model "Login_model" initialized
INFO - 2023-05-25 08:16:12 --> Final output sent to browser
DEBUG - 2023-05-25 08:16:12 --> Total execution time: 11.8219
INFO - 2023-05-25 08:16:48 --> Config Class Initialized
INFO - 2023-05-25 08:16:48 --> Config Class Initialized
INFO - 2023-05-25 08:16:48 --> Hooks Class Initialized
INFO - 2023-05-25 08:16:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:16:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:16:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:16:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:16:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:16:48 --> URI Class Initialized
INFO - 2023-05-25 08:16:48 --> URI Class Initialized
INFO - 2023-05-25 08:16:48 --> Router Class Initialized
INFO - 2023-05-25 08:16:48 --> Router Class Initialized
INFO - 2023-05-25 08:16:48 --> Output Class Initialized
INFO - 2023-05-25 08:16:48 --> Output Class Initialized
INFO - 2023-05-25 08:16:48 --> Security Class Initialized
INFO - 2023-05-25 08:16:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:16:48 --> Input Class Initialized
INFO - 2023-05-25 08:16:48 --> Input Class Initialized
INFO - 2023-05-25 08:16:48 --> Language Class Initialized
INFO - 2023-05-25 08:16:48 --> Language Class Initialized
INFO - 2023-05-25 08:16:48 --> Loader Class Initialized
INFO - 2023-05-25 08:16:48 --> Loader Class Initialized
INFO - 2023-05-25 08:16:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:16:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:16:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:16:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:16:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:16:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:16:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:16:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:16:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:16:48 --> Model "Login_model" initialized
INFO - 2023-05-25 08:16:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:16:48 --> Total execution time: 0.6209
INFO - 2023-05-25 08:16:48 --> Config Class Initialized
INFO - 2023-05-25 08:16:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:16:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:16:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:16:48 --> URI Class Initialized
INFO - 2023-05-25 08:16:48 --> Router Class Initialized
INFO - 2023-05-25 08:16:48 --> Output Class Initialized
INFO - 2023-05-25 08:16:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:16:48 --> Input Class Initialized
INFO - 2023-05-25 08:16:48 --> Language Class Initialized
INFO - 2023-05-25 08:16:48 --> Loader Class Initialized
INFO - 2023-05-25 08:16:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:16:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:16:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:16:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:16:49 --> Final output sent to browser
DEBUG - 2023-05-25 08:16:49 --> Total execution time: 0.6864
INFO - 2023-05-25 08:16:58 --> Final output sent to browser
DEBUG - 2023-05-25 08:16:58 --> Total execution time: 10.2897
INFO - 2023-05-25 08:16:58 --> Config Class Initialized
INFO - 2023-05-25 08:16:58 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:16:58 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:16:58 --> Utf8 Class Initialized
INFO - 2023-05-25 08:16:58 --> URI Class Initialized
INFO - 2023-05-25 08:16:58 --> Router Class Initialized
INFO - 2023-05-25 08:16:58 --> Output Class Initialized
INFO - 2023-05-25 08:16:58 --> Security Class Initialized
DEBUG - 2023-05-25 08:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:16:58 --> Input Class Initialized
INFO - 2023-05-25 08:16:58 --> Language Class Initialized
INFO - 2023-05-25 08:16:58 --> Loader Class Initialized
INFO - 2023-05-25 08:16:58 --> Controller Class Initialized
DEBUG - 2023-05-25 08:16:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:16:58 --> Database Driver Class Initialized
INFO - 2023-05-25 08:16:58 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:16:58 --> Database Driver Class Initialized
INFO - 2023-05-25 08:16:58 --> Model "Login_model" initialized
INFO - 2023-05-25 08:17:10 --> Final output sent to browser
DEBUG - 2023-05-25 08:17:10 --> Total execution time: 11.7105
INFO - 2023-05-25 08:17:48 --> Config Class Initialized
INFO - 2023-05-25 08:17:48 --> Config Class Initialized
INFO - 2023-05-25 08:17:48 --> Hooks Class Initialized
INFO - 2023-05-25 08:17:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:17:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:17:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:17:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:17:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:17:48 --> URI Class Initialized
INFO - 2023-05-25 08:17:48 --> URI Class Initialized
INFO - 2023-05-25 08:17:48 --> Router Class Initialized
INFO - 2023-05-25 08:17:48 --> Router Class Initialized
INFO - 2023-05-25 08:17:48 --> Output Class Initialized
INFO - 2023-05-25 08:17:48 --> Output Class Initialized
INFO - 2023-05-25 08:17:48 --> Security Class Initialized
INFO - 2023-05-25 08:17:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:17:48 --> Input Class Initialized
INFO - 2023-05-25 08:17:48 --> Input Class Initialized
INFO - 2023-05-25 08:17:48 --> Language Class Initialized
INFO - 2023-05-25 08:17:48 --> Language Class Initialized
INFO - 2023-05-25 08:17:48 --> Loader Class Initialized
INFO - 2023-05-25 08:17:48 --> Loader Class Initialized
INFO - 2023-05-25 08:17:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:17:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:17:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:17:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:17:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:17:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:17:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:17:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:17:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:17:48 --> Model "Login_model" initialized
INFO - 2023-05-25 08:17:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:17:48 --> Total execution time: 0.7060
INFO - 2023-05-25 08:17:48 --> Config Class Initialized
INFO - 2023-05-25 08:17:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:17:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:17:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:17:48 --> URI Class Initialized
INFO - 2023-05-25 08:17:48 --> Router Class Initialized
INFO - 2023-05-25 08:17:48 --> Output Class Initialized
INFO - 2023-05-25 08:17:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:17:48 --> Input Class Initialized
INFO - 2023-05-25 08:17:48 --> Language Class Initialized
INFO - 2023-05-25 08:17:48 --> Loader Class Initialized
INFO - 2023-05-25 08:17:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:17:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:17:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:17:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:17:49 --> Final output sent to browser
DEBUG - 2023-05-25 08:17:49 --> Total execution time: 0.7162
INFO - 2023-05-25 08:18:00 --> Final output sent to browser
DEBUG - 2023-05-25 08:18:00 --> Total execution time: 12.0132
INFO - 2023-05-25 08:18:00 --> Config Class Initialized
INFO - 2023-05-25 08:18:00 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:18:00 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:18:00 --> Utf8 Class Initialized
INFO - 2023-05-25 08:18:00 --> URI Class Initialized
INFO - 2023-05-25 08:18:00 --> Router Class Initialized
INFO - 2023-05-25 08:18:00 --> Output Class Initialized
INFO - 2023-05-25 08:18:00 --> Security Class Initialized
DEBUG - 2023-05-25 08:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:18:00 --> Input Class Initialized
INFO - 2023-05-25 08:18:00 --> Language Class Initialized
INFO - 2023-05-25 08:18:00 --> Loader Class Initialized
INFO - 2023-05-25 08:18:00 --> Controller Class Initialized
DEBUG - 2023-05-25 08:18:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:18:00 --> Database Driver Class Initialized
INFO - 2023-05-25 08:18:00 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:18:00 --> Database Driver Class Initialized
INFO - 2023-05-25 08:18:00 --> Model "Login_model" initialized
INFO - 2023-05-25 08:18:15 --> Final output sent to browser
DEBUG - 2023-05-25 08:18:15 --> Total execution time: 15.3292
INFO - 2023-05-25 08:18:48 --> Config Class Initialized
INFO - 2023-05-25 08:18:48 --> Config Class Initialized
INFO - 2023-05-25 08:18:48 --> Hooks Class Initialized
INFO - 2023-05-25 08:18:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:18:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:18:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:18:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:18:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:18:48 --> URI Class Initialized
INFO - 2023-05-25 08:18:48 --> URI Class Initialized
INFO - 2023-05-25 08:18:48 --> Router Class Initialized
INFO - 2023-05-25 08:18:48 --> Router Class Initialized
INFO - 2023-05-25 08:18:48 --> Output Class Initialized
INFO - 2023-05-25 08:18:48 --> Output Class Initialized
INFO - 2023-05-25 08:18:48 --> Security Class Initialized
INFO - 2023-05-25 08:18:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:18:48 --> Input Class Initialized
INFO - 2023-05-25 08:18:48 --> Input Class Initialized
INFO - 2023-05-25 08:18:48 --> Language Class Initialized
INFO - 2023-05-25 08:18:48 --> Language Class Initialized
INFO - 2023-05-25 08:18:48 --> Loader Class Initialized
INFO - 2023-05-25 08:18:48 --> Loader Class Initialized
INFO - 2023-05-25 08:18:48 --> Controller Class Initialized
INFO - 2023-05-25 08:18:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:18:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 08:18:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:18:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:18:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:18:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:18:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:18:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:18:48 --> Model "Login_model" initialized
INFO - 2023-05-25 08:18:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:18:48 --> Total execution time: 0.2271
INFO - 2023-05-25 08:18:48 --> Config Class Initialized
INFO - 2023-05-25 08:18:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:18:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:18:48 --> Utf8 Class Initialized
INFO - 2023-05-25 08:18:48 --> URI Class Initialized
INFO - 2023-05-25 08:18:48 --> Router Class Initialized
INFO - 2023-05-25 08:18:48 --> Output Class Initialized
INFO - 2023-05-25 08:18:48 --> Security Class Initialized
DEBUG - 2023-05-25 08:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:18:48 --> Input Class Initialized
INFO - 2023-05-25 08:18:48 --> Language Class Initialized
INFO - 2023-05-25 08:18:48 --> Loader Class Initialized
INFO - 2023-05-25 08:18:48 --> Controller Class Initialized
DEBUG - 2023-05-25 08:18:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:18:48 --> Database Driver Class Initialized
INFO - 2023-05-25 08:18:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:18:48 --> Final output sent to browser
DEBUG - 2023-05-25 08:18:48 --> Total execution time: 0.2414
INFO - 2023-05-25 08:18:57 --> Final output sent to browser
DEBUG - 2023-05-25 08:18:57 --> Total execution time: 9.7375
INFO - 2023-05-25 08:18:57 --> Config Class Initialized
INFO - 2023-05-25 08:18:57 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:18:57 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:18:57 --> Utf8 Class Initialized
INFO - 2023-05-25 08:18:57 --> URI Class Initialized
INFO - 2023-05-25 08:18:57 --> Router Class Initialized
INFO - 2023-05-25 08:18:57 --> Output Class Initialized
INFO - 2023-05-25 08:18:57 --> Security Class Initialized
DEBUG - 2023-05-25 08:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:18:57 --> Input Class Initialized
INFO - 2023-05-25 08:18:57 --> Language Class Initialized
INFO - 2023-05-25 08:18:57 --> Loader Class Initialized
INFO - 2023-05-25 08:18:58 --> Controller Class Initialized
DEBUG - 2023-05-25 08:18:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:18:58 --> Database Driver Class Initialized
INFO - 2023-05-25 08:18:58 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:18:58 --> Database Driver Class Initialized
INFO - 2023-05-25 08:18:58 --> Model "Login_model" initialized
INFO - 2023-05-25 08:19:04 --> Config Class Initialized
INFO - 2023-05-25 08:19:04 --> Config Class Initialized
INFO - 2023-05-25 08:19:04 --> Hooks Class Initialized
INFO - 2023-05-25 08:19:04 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:19:04 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:19:04 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:19:04 --> Utf8 Class Initialized
INFO - 2023-05-25 08:19:04 --> Utf8 Class Initialized
INFO - 2023-05-25 08:19:04 --> URI Class Initialized
INFO - 2023-05-25 08:19:04 --> URI Class Initialized
INFO - 2023-05-25 08:19:04 --> Router Class Initialized
INFO - 2023-05-25 08:19:04 --> Router Class Initialized
INFO - 2023-05-25 08:19:04 --> Output Class Initialized
INFO - 2023-05-25 08:19:04 --> Output Class Initialized
INFO - 2023-05-25 08:19:04 --> Security Class Initialized
INFO - 2023-05-25 08:19:04 --> Security Class Initialized
DEBUG - 2023-05-25 08:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 08:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:19:04 --> Input Class Initialized
INFO - 2023-05-25 08:19:04 --> Input Class Initialized
INFO - 2023-05-25 08:19:04 --> Language Class Initialized
INFO - 2023-05-25 08:19:04 --> Language Class Initialized
INFO - 2023-05-25 08:19:04 --> Loader Class Initialized
INFO - 2023-05-25 08:19:04 --> Loader Class Initialized
INFO - 2023-05-25 08:19:04 --> Controller Class Initialized
DEBUG - 2023-05-25 08:19:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:19:05 --> Controller Class Initialized
DEBUG - 2023-05-25 08:19:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:19:05 --> Database Driver Class Initialized
INFO - 2023-05-25 08:19:05 --> Config Class Initialized
INFO - 2023-05-25 08:19:05 --> Hooks Class Initialized
INFO - 2023-05-25 08:19:05 --> Database Driver Class Initialized
INFO - 2023-05-25 08:19:05 --> Database Driver Class Initialized
DEBUG - 2023-05-25 08:19:05 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:19:05 --> Utf8 Class Initialized
INFO - 2023-05-25 08:19:05 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:19:05 --> URI Class Initialized
INFO - 2023-05-25 08:19:05 --> Model "Login_model" initialized
INFO - 2023-05-25 08:19:05 --> Router Class Initialized
INFO - 2023-05-25 08:19:05 --> Output Class Initialized
INFO - 2023-05-25 08:19:05 --> Security Class Initialized
DEBUG - 2023-05-25 08:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:19:05 --> Input Class Initialized
INFO - 2023-05-25 08:19:05 --> Language Class Initialized
INFO - 2023-05-25 08:19:05 --> Final output sent to browser
DEBUG - 2023-05-25 08:19:05 --> Total execution time: 1.5737
INFO - 2023-05-25 08:19:05 --> Final output sent to browser
DEBUG - 2023-05-25 08:19:05 --> Total execution time: 1.6115
INFO - 2023-05-25 08:19:05 --> Loader Class Initialized
INFO - 2023-05-25 08:19:05 --> Controller Class Initialized
INFO - 2023-05-25 08:19:05 --> Config Class Initialized
INFO - 2023-05-25 08:19:05 --> Config Class Initialized
INFO - 2023-05-25 08:19:05 --> Hooks Class Initialized
INFO - 2023-05-25 08:19:05 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:19:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 08:19:05 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:19:05 --> Utf8 Class Initialized
DEBUG - 2023-05-25 08:19:06 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:19:06 --> URI Class Initialized
INFO - 2023-05-25 08:19:06 --> Utf8 Class Initialized
INFO - 2023-05-25 08:19:06 --> URI Class Initialized
INFO - 2023-05-25 08:19:06 --> Router Class Initialized
INFO - 2023-05-25 08:19:06 --> Output Class Initialized
INFO - 2023-05-25 08:19:06 --> Security Class Initialized
INFO - 2023-05-25 08:19:06 --> Config Class Initialized
INFO - 2023-05-25 08:19:06 --> Hooks Class Initialized
INFO - 2023-05-25 08:19:06 --> Router Class Initialized
DEBUG - 2023-05-25 08:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:19:06 --> Input Class Initialized
INFO - 2023-05-25 08:19:06 --> Database Driver Class Initialized
INFO - 2023-05-25 08:19:06 --> Language Class Initialized
DEBUG - 2023-05-25 08:19:06 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:19:06 --> Utf8 Class Initialized
INFO - 2023-05-25 08:19:06 --> Output Class Initialized
INFO - 2023-05-25 08:19:06 --> URI Class Initialized
INFO - 2023-05-25 08:19:06 --> Loader Class Initialized
INFO - 2023-05-25 08:19:06 --> Security Class Initialized
INFO - 2023-05-25 08:19:06 --> Controller Class Initialized
INFO - 2023-05-25 08:19:06 --> Router Class Initialized
DEBUG - 2023-05-25 08:19:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 08:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:19:06 --> Input Class Initialized
INFO - 2023-05-25 08:19:06 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:19:06 --> Language Class Initialized
INFO - 2023-05-25 08:19:06 --> Output Class Initialized
INFO - 2023-05-25 08:19:06 --> Security Class Initialized
INFO - 2023-05-25 08:19:06 --> Database Driver Class Initialized
INFO - 2023-05-25 08:19:06 --> Loader Class Initialized
DEBUG - 2023-05-25 08:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:19:06 --> Input Class Initialized
INFO - 2023-05-25 08:19:06 --> Controller Class Initialized
INFO - 2023-05-25 08:19:06 --> Language Class Initialized
DEBUG - 2023-05-25 08:19:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:19:06 --> Database Driver Class Initialized
INFO - 2023-05-25 08:19:06 --> Final output sent to browser
DEBUG - 2023-05-25 08:19:06 --> Total execution time: 1.7885
INFO - 2023-05-25 08:19:07 --> Loader Class Initialized
INFO - 2023-05-25 08:19:07 --> Model "Login_model" initialized
INFO - 2023-05-25 08:19:07 --> Database Driver Class Initialized
INFO - 2023-05-25 08:19:07 --> Final output sent to browser
INFO - 2023-05-25 08:19:07 --> Controller Class Initialized
DEBUG - 2023-05-25 08:19:07 --> Total execution time: 1.3693
INFO - 2023-05-25 08:19:07 --> Config Class Initialized
INFO - 2023-05-25 08:19:07 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:19:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:19:07 --> Model "Cluster_model" initialized
DEBUG - 2023-05-25 08:19:07 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:19:07 --> Utf8 Class Initialized
INFO - 2023-05-25 08:19:07 --> URI Class Initialized
INFO - 2023-05-25 08:19:07 --> Router Class Initialized
INFO - 2023-05-25 08:19:07 --> Final output sent to browser
INFO - 2023-05-25 08:19:07 --> Database Driver Class Initialized
DEBUG - 2023-05-25 08:19:07 --> Total execution time: 1.5800
INFO - 2023-05-25 08:19:07 --> Output Class Initialized
INFO - 2023-05-25 08:19:07 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:19:07 --> Security Class Initialized
DEBUG - 2023-05-25 08:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:19:07 --> Input Class Initialized
INFO - 2023-05-25 08:19:07 --> Language Class Initialized
INFO - 2023-05-25 08:19:07 --> Loader Class Initialized
INFO - 2023-05-25 08:19:07 --> Config Class Initialized
INFO - 2023-05-25 08:19:07 --> Hooks Class Initialized
INFO - 2023-05-25 08:19:07 --> Controller Class Initialized
DEBUG - 2023-05-25 08:19:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:19:07 --> Final output sent to browser
DEBUG - 2023-05-25 08:19:07 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 08:19:07 --> Total execution time: 1.8054
INFO - 2023-05-25 08:19:07 --> Utf8 Class Initialized
INFO - 2023-05-25 08:19:07 --> URI Class Initialized
INFO - 2023-05-25 08:19:07 --> Database Driver Class Initialized
INFO - 2023-05-25 08:19:08 --> Router Class Initialized
INFO - 2023-05-25 08:19:08 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:19:08 --> Output Class Initialized
INFO - 2023-05-25 08:19:08 --> Security Class Initialized
INFO - 2023-05-25 08:19:08 --> Final output sent to browser
DEBUG - 2023-05-25 08:19:08 --> Total execution time: 1.0469
DEBUG - 2023-05-25 08:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:19:08 --> Input Class Initialized
INFO - 2023-05-25 08:19:08 --> Language Class Initialized
INFO - 2023-05-25 08:19:08 --> Loader Class Initialized
INFO - 2023-05-25 08:19:08 --> Controller Class Initialized
DEBUG - 2023-05-25 08:19:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:19:08 --> Database Driver Class Initialized
INFO - 2023-05-25 08:19:08 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:19:08 --> Final output sent to browser
DEBUG - 2023-05-25 08:19:08 --> Total execution time: 0.9235
INFO - 2023-05-25 08:19:10 --> Final output sent to browser
DEBUG - 2023-05-25 08:19:10 --> Total execution time: 12.7640
INFO - 2023-05-25 08:19:17 --> Config Class Initialized
INFO - 2023-05-25 08:19:17 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:19:17 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:19:17 --> Utf8 Class Initialized
INFO - 2023-05-25 08:19:17 --> URI Class Initialized
INFO - 2023-05-25 08:19:17 --> Router Class Initialized
INFO - 2023-05-25 08:19:17 --> Output Class Initialized
INFO - 2023-05-25 08:19:17 --> Security Class Initialized
DEBUG - 2023-05-25 08:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:19:17 --> Input Class Initialized
INFO - 2023-05-25 08:19:17 --> Language Class Initialized
INFO - 2023-05-25 08:19:17 --> Loader Class Initialized
INFO - 2023-05-25 08:19:17 --> Controller Class Initialized
DEBUG - 2023-05-25 08:19:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:19:17 --> Database Driver Class Initialized
INFO - 2023-05-25 08:19:17 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:19:17 --> Final output sent to browser
DEBUG - 2023-05-25 08:19:17 --> Total execution time: 0.1921
INFO - 2023-05-25 08:19:17 --> Config Class Initialized
INFO - 2023-05-25 08:19:17 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:19:17 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:19:17 --> Utf8 Class Initialized
INFO - 2023-05-25 08:19:17 --> URI Class Initialized
INFO - 2023-05-25 08:19:17 --> Router Class Initialized
INFO - 2023-05-25 08:19:17 --> Output Class Initialized
INFO - 2023-05-25 08:19:17 --> Security Class Initialized
DEBUG - 2023-05-25 08:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:19:17 --> Input Class Initialized
INFO - 2023-05-25 08:19:17 --> Language Class Initialized
INFO - 2023-05-25 08:19:17 --> Loader Class Initialized
INFO - 2023-05-25 08:19:17 --> Controller Class Initialized
DEBUG - 2023-05-25 08:19:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:19:17 --> Database Driver Class Initialized
INFO - 2023-05-25 08:19:17 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:19:17 --> Final output sent to browser
DEBUG - 2023-05-25 08:19:17 --> Total execution time: 0.2029
INFO - 2023-05-25 08:58:49 --> Config Class Initialized
INFO - 2023-05-25 08:58:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:58:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:58:49 --> Utf8 Class Initialized
INFO - 2023-05-25 08:58:49 --> URI Class Initialized
INFO - 2023-05-25 08:58:49 --> Router Class Initialized
INFO - 2023-05-25 08:58:49 --> Output Class Initialized
INFO - 2023-05-25 08:58:49 --> Security Class Initialized
DEBUG - 2023-05-25 08:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:58:49 --> Input Class Initialized
INFO - 2023-05-25 08:58:49 --> Language Class Initialized
INFO - 2023-05-25 08:58:49 --> Loader Class Initialized
INFO - 2023-05-25 08:58:49 --> Controller Class Initialized
DEBUG - 2023-05-25 08:58:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:58:49 --> Database Driver Class Initialized
INFO - 2023-05-25 08:58:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:58:50 --> Final output sent to browser
DEBUG - 2023-05-25 08:58:50 --> Total execution time: 0.7256
INFO - 2023-05-25 08:58:50 --> Config Class Initialized
INFO - 2023-05-25 08:58:50 --> Hooks Class Initialized
DEBUG - 2023-05-25 08:58:50 --> UTF-8 Support Enabled
INFO - 2023-05-25 08:58:50 --> Utf8 Class Initialized
INFO - 2023-05-25 08:58:50 --> URI Class Initialized
INFO - 2023-05-25 08:58:50 --> Router Class Initialized
INFO - 2023-05-25 08:58:50 --> Output Class Initialized
INFO - 2023-05-25 08:58:50 --> Security Class Initialized
DEBUG - 2023-05-25 08:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 08:58:50 --> Input Class Initialized
INFO - 2023-05-25 08:58:50 --> Language Class Initialized
INFO - 2023-05-25 08:58:50 --> Loader Class Initialized
INFO - 2023-05-25 08:58:50 --> Controller Class Initialized
DEBUG - 2023-05-25 08:58:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 08:58:50 --> Database Driver Class Initialized
INFO - 2023-05-25 08:58:50 --> Model "Cluster_model" initialized
INFO - 2023-05-25 08:58:50 --> Final output sent to browser
DEBUG - 2023-05-25 08:58:50 --> Total execution time: 0.7624
INFO - 2023-05-25 09:11:58 --> Config Class Initialized
INFO - 2023-05-25 09:11:58 --> Hooks Class Initialized
DEBUG - 2023-05-25 09:11:58 --> UTF-8 Support Enabled
INFO - 2023-05-25 09:11:58 --> Utf8 Class Initialized
INFO - 2023-05-25 09:11:58 --> URI Class Initialized
INFO - 2023-05-25 09:11:58 --> Router Class Initialized
INFO - 2023-05-25 09:11:58 --> Output Class Initialized
INFO - 2023-05-25 09:11:58 --> Security Class Initialized
DEBUG - 2023-05-25 09:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 09:11:59 --> Input Class Initialized
INFO - 2023-05-25 09:11:59 --> Language Class Initialized
INFO - 2023-05-25 09:11:59 --> Loader Class Initialized
INFO - 2023-05-25 09:11:59 --> Controller Class Initialized
DEBUG - 2023-05-25 09:11:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 09:11:59 --> Final output sent to browser
DEBUG - 2023-05-25 09:11:59 --> Total execution time: 0.2345
INFO - 2023-05-25 09:11:59 --> Config Class Initialized
INFO - 2023-05-25 09:11:59 --> Hooks Class Initialized
DEBUG - 2023-05-25 09:11:59 --> UTF-8 Support Enabled
INFO - 2023-05-25 09:11:59 --> Utf8 Class Initialized
INFO - 2023-05-25 09:11:59 --> URI Class Initialized
INFO - 2023-05-25 09:11:59 --> Router Class Initialized
INFO - 2023-05-25 09:11:59 --> Output Class Initialized
INFO - 2023-05-25 09:11:59 --> Security Class Initialized
DEBUG - 2023-05-25 09:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 09:11:59 --> Input Class Initialized
INFO - 2023-05-25 09:11:59 --> Language Class Initialized
INFO - 2023-05-25 09:11:59 --> Loader Class Initialized
INFO - 2023-05-25 09:11:59 --> Controller Class Initialized
DEBUG - 2023-05-25 09:11:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 09:11:59 --> Database Driver Class Initialized
INFO - 2023-05-25 09:11:59 --> Model "Cluster_model" initialized
INFO - 2023-05-25 09:11:59 --> Final output sent to browser
DEBUG - 2023-05-25 09:11:59 --> Total execution time: 0.2843
INFO - 2023-05-25 09:12:00 --> Config Class Initialized
INFO - 2023-05-25 09:12:00 --> Config Class Initialized
INFO - 2023-05-25 09:12:00 --> Config Class Initialized
INFO - 2023-05-25 09:12:00 --> Hooks Class Initialized
INFO - 2023-05-25 09:12:00 --> Hooks Class Initialized
INFO - 2023-05-25 09:12:00 --> Hooks Class Initialized
DEBUG - 2023-05-25 09:12:01 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 09:12:01 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 09:12:01 --> UTF-8 Support Enabled
INFO - 2023-05-25 09:12:01 --> Utf8 Class Initialized
INFO - 2023-05-25 09:12:01 --> Utf8 Class Initialized
INFO - 2023-05-25 09:12:01 --> Utf8 Class Initialized
INFO - 2023-05-25 09:12:01 --> URI Class Initialized
INFO - 2023-05-25 09:12:01 --> URI Class Initialized
INFO - 2023-05-25 09:12:01 --> URI Class Initialized
INFO - 2023-05-25 09:12:01 --> Router Class Initialized
INFO - 2023-05-25 09:12:01 --> Router Class Initialized
INFO - 2023-05-25 09:12:01 --> Router Class Initialized
INFO - 2023-05-25 09:12:01 --> Output Class Initialized
INFO - 2023-05-25 09:12:01 --> Output Class Initialized
INFO - 2023-05-25 09:12:01 --> Output Class Initialized
INFO - 2023-05-25 09:12:01 --> Security Class Initialized
INFO - 2023-05-25 09:12:01 --> Security Class Initialized
INFO - 2023-05-25 09:12:01 --> Security Class Initialized
DEBUG - 2023-05-25 09:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 09:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 09:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 09:12:01 --> Input Class Initialized
INFO - 2023-05-25 09:12:01 --> Input Class Initialized
INFO - 2023-05-25 09:12:01 --> Input Class Initialized
INFO - 2023-05-25 09:12:01 --> Language Class Initialized
INFO - 2023-05-25 09:12:01 --> Language Class Initialized
INFO - 2023-05-25 09:12:01 --> Language Class Initialized
INFO - 2023-05-25 09:12:01 --> Loader Class Initialized
INFO - 2023-05-25 09:12:01 --> Loader Class Initialized
INFO - 2023-05-25 09:12:01 --> Controller Class Initialized
INFO - 2023-05-25 09:12:01 --> Controller Class Initialized
DEBUG - 2023-05-25 09:12:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 09:12:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 09:12:01 --> Loader Class Initialized
INFO - 2023-05-25 09:12:01 --> Controller Class Initialized
INFO - 2023-05-25 09:12:01 --> Database Driver Class Initialized
DEBUG - 2023-05-25 09:12:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 09:12:01 --> Database Driver Class Initialized
INFO - 2023-05-25 09:12:01 --> Database Driver Class Initialized
INFO - 2023-05-25 09:12:01 --> Model "Cluster_model" initialized
INFO - 2023-05-25 09:12:01 --> Model "Cluster_model" initialized
INFO - 2023-05-25 09:12:01 --> Model "Cluster_model" initialized
INFO - 2023-05-25 09:12:01 --> Final output sent to browser
INFO - 2023-05-25 09:12:01 --> Final output sent to browser
DEBUG - 2023-05-25 09:12:01 --> Total execution time: 0.3150
DEBUG - 2023-05-25 09:12:01 --> Total execution time: 0.3175
INFO - 2023-05-25 09:12:01 --> Final output sent to browser
DEBUG - 2023-05-25 09:12:01 --> Total execution time: 0.3353
INFO - 2023-05-25 09:12:01 --> Config Class Initialized
INFO - 2023-05-25 09:12:01 --> Config Class Initialized
INFO - 2023-05-25 09:12:01 --> Hooks Class Initialized
INFO - 2023-05-25 09:12:01 --> Hooks Class Initialized
DEBUG - 2023-05-25 09:12:01 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 09:12:01 --> UTF-8 Support Enabled
INFO - 2023-05-25 09:12:01 --> Utf8 Class Initialized
INFO - 2023-05-25 09:12:01 --> Utf8 Class Initialized
INFO - 2023-05-25 09:12:01 --> URI Class Initialized
INFO - 2023-05-25 09:12:01 --> URI Class Initialized
INFO - 2023-05-25 09:12:01 --> Router Class Initialized
INFO - 2023-05-25 09:12:01 --> Router Class Initialized
INFO - 2023-05-25 09:12:01 --> Output Class Initialized
INFO - 2023-05-25 09:12:01 --> Output Class Initialized
INFO - 2023-05-25 09:12:01 --> Security Class Initialized
INFO - 2023-05-25 09:12:01 --> Config Class Initialized
INFO - 2023-05-25 09:12:01 --> Security Class Initialized
INFO - 2023-05-25 09:12:01 --> Hooks Class Initialized
DEBUG - 2023-05-25 09:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 09:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 09:12:01 --> Input Class Initialized
INFO - 2023-05-25 09:12:01 --> Input Class Initialized
INFO - 2023-05-25 09:12:01 --> Language Class Initialized
INFO - 2023-05-25 09:12:01 --> Language Class Initialized
INFO - 2023-05-25 09:12:01 --> Loader Class Initialized
DEBUG - 2023-05-25 09:12:01 --> UTF-8 Support Enabled
INFO - 2023-05-25 09:12:01 --> Utf8 Class Initialized
INFO - 2023-05-25 09:12:01 --> Controller Class Initialized
INFO - 2023-05-25 09:12:01 --> Loader Class Initialized
DEBUG - 2023-05-25 09:12:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 09:12:01 --> Controller Class Initialized
INFO - 2023-05-25 09:12:01 --> URI Class Initialized
DEBUG - 2023-05-25 09:12:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 09:12:01 --> Router Class Initialized
INFO - 2023-05-25 09:12:01 --> Database Driver Class Initialized
INFO - 2023-05-25 09:12:01 --> Output Class Initialized
INFO - 2023-05-25 09:12:01 --> Database Driver Class Initialized
INFO - 2023-05-25 09:12:01 --> Security Class Initialized
DEBUG - 2023-05-25 09:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 09:12:01 --> Input Class Initialized
INFO - 2023-05-25 09:12:01 --> Language Class Initialized
INFO - 2023-05-25 09:12:01 --> Loader Class Initialized
INFO - 2023-05-25 09:12:01 --> Controller Class Initialized
DEBUG - 2023-05-25 09:12:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 09:12:01 --> Database Driver Class Initialized
INFO - 2023-05-25 09:12:01 --> Model "Cluster_model" initialized
INFO - 2023-05-25 09:12:01 --> Model "Cluster_model" initialized
INFO - 2023-05-25 09:12:01 --> Model "Cluster_model" initialized
INFO - 2023-05-25 09:12:01 --> Final output sent to browser
DEBUG - 2023-05-25 09:12:01 --> Total execution time: 0.4745
INFO - 2023-05-25 09:12:01 --> Final output sent to browser
DEBUG - 2023-05-25 09:12:01 --> Total execution time: 0.4787
INFO - 2023-05-25 09:12:01 --> Config Class Initialized
INFO - 2023-05-25 09:12:01 --> Hooks Class Initialized
DEBUG - 2023-05-25 09:12:01 --> UTF-8 Support Enabled
INFO - 2023-05-25 09:12:01 --> Utf8 Class Initialized
INFO - 2023-05-25 09:12:01 --> URI Class Initialized
INFO - 2023-05-25 09:12:01 --> Router Class Initialized
INFO - 2023-05-25 09:12:01 --> Output Class Initialized
INFO - 2023-05-25 09:12:01 --> Security Class Initialized
DEBUG - 2023-05-25 09:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 09:12:02 --> Input Class Initialized
INFO - 2023-05-25 09:12:02 --> Language Class Initialized
INFO - 2023-05-25 09:12:02 --> Loader Class Initialized
INFO - 2023-05-25 09:12:02 --> Controller Class Initialized
DEBUG - 2023-05-25 09:12:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 09:12:02 --> Final output sent to browser
DEBUG - 2023-05-25 09:12:02 --> Total execution time: 0.7554
INFO - 2023-05-25 09:12:02 --> Database Driver Class Initialized
INFO - 2023-05-25 09:12:02 --> Model "Cluster_model" initialized
INFO - 2023-05-25 09:12:02 --> Config Class Initialized
INFO - 2023-05-25 09:12:02 --> Hooks Class Initialized
DEBUG - 2023-05-25 09:12:02 --> UTF-8 Support Enabled
INFO - 2023-05-25 09:12:02 --> Utf8 Class Initialized
INFO - 2023-05-25 09:12:02 --> URI Class Initialized
INFO - 2023-05-25 09:12:02 --> Router Class Initialized
INFO - 2023-05-25 09:12:02 --> Output Class Initialized
INFO - 2023-05-25 09:12:02 --> Security Class Initialized
DEBUG - 2023-05-25 09:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 09:12:02 --> Input Class Initialized
INFO - 2023-05-25 09:12:02 --> Language Class Initialized
INFO - 2023-05-25 09:12:02 --> Loader Class Initialized
INFO - 2023-05-25 09:12:02 --> Controller Class Initialized
DEBUG - 2023-05-25 09:12:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 09:12:02 --> Database Driver Class Initialized
INFO - 2023-05-25 09:12:02 --> Model "Cluster_model" initialized
INFO - 2023-05-25 09:51:30 --> Config Class Initialized
INFO - 2023-05-25 09:51:30 --> Hooks Class Initialized
DEBUG - 2023-05-25 09:51:30 --> UTF-8 Support Enabled
INFO - 2023-05-25 09:51:30 --> Utf8 Class Initialized
INFO - 2023-05-25 09:51:30 --> URI Class Initialized
INFO - 2023-05-25 09:51:30 --> Router Class Initialized
INFO - 2023-05-25 09:51:30 --> Output Class Initialized
INFO - 2023-05-25 09:51:30 --> Security Class Initialized
DEBUG - 2023-05-25 09:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 09:51:30 --> Input Class Initialized
INFO - 2023-05-25 09:51:30 --> Language Class Initialized
INFO - 2023-05-25 09:51:30 --> Loader Class Initialized
INFO - 2023-05-25 09:51:30 --> Controller Class Initialized
DEBUG - 2023-05-25 09:51:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 09:51:30 --> Database Driver Class Initialized
INFO - 2023-05-25 09:51:30 --> Model "Cluster_model" initialized
INFO - 2023-05-25 09:51:30 --> Final output sent to browser
DEBUG - 2023-05-25 09:51:30 --> Total execution time: 0.8420
INFO - 2023-05-25 09:51:30 --> Config Class Initialized
INFO - 2023-05-25 09:51:30 --> Hooks Class Initialized
DEBUG - 2023-05-25 09:51:30 --> UTF-8 Support Enabled
INFO - 2023-05-25 09:51:30 --> Utf8 Class Initialized
INFO - 2023-05-25 09:51:30 --> URI Class Initialized
INFO - 2023-05-25 09:51:30 --> Router Class Initialized
INFO - 2023-05-25 09:51:30 --> Output Class Initialized
INFO - 2023-05-25 09:51:30 --> Security Class Initialized
DEBUG - 2023-05-25 09:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 09:51:31 --> Input Class Initialized
INFO - 2023-05-25 09:51:31 --> Language Class Initialized
INFO - 2023-05-25 09:51:31 --> Loader Class Initialized
INFO - 2023-05-25 09:51:31 --> Controller Class Initialized
DEBUG - 2023-05-25 09:51:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 09:51:31 --> Database Driver Class Initialized
INFO - 2023-05-25 09:51:31 --> Model "Cluster_model" initialized
INFO - 2023-05-25 09:51:31 --> Final output sent to browser
DEBUG - 2023-05-25 09:51:31 --> Total execution time: 0.8895
INFO - 2023-05-25 10:12:02 --> Config Class Initialized
INFO - 2023-05-25 10:12:02 --> Config Class Initialized
INFO - 2023-05-25 10:12:02 --> Hooks Class Initialized
INFO - 2023-05-25 10:12:02 --> Hooks Class Initialized
INFO - 2023-05-25 10:12:02 --> Config Class Initialized
INFO - 2023-05-25 10:12:02 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 10:12:02 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:12:02 --> Utf8 Class Initialized
INFO - 2023-05-25 10:12:02 --> Utf8 Class Initialized
INFO - 2023-05-25 10:12:02 --> URI Class Initialized
INFO - 2023-05-25 10:12:02 --> URI Class Initialized
INFO - 2023-05-25 10:12:02 --> Router Class Initialized
INFO - 2023-05-25 10:12:02 --> Router Class Initialized
DEBUG - 2023-05-25 10:12:02 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:12:02 --> Output Class Initialized
INFO - 2023-05-25 10:12:02 --> Output Class Initialized
INFO - 2023-05-25 10:12:02 --> Utf8 Class Initialized
INFO - 2023-05-25 10:12:02 --> Security Class Initialized
INFO - 2023-05-25 10:12:02 --> Security Class Initialized
INFO - 2023-05-25 10:12:02 --> URI Class Initialized
DEBUG - 2023-05-25 10:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 10:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:12:02 --> Input Class Initialized
INFO - 2023-05-25 10:12:02 --> Input Class Initialized
INFO - 2023-05-25 10:12:02 --> Language Class Initialized
INFO - 2023-05-25 10:12:02 --> Language Class Initialized
INFO - 2023-05-25 10:12:02 --> Router Class Initialized
INFO - 2023-05-25 10:12:02 --> Output Class Initialized
INFO - 2023-05-25 10:12:02 --> Loader Class Initialized
INFO - 2023-05-25 10:12:02 --> Loader Class Initialized
INFO - 2023-05-25 10:12:02 --> Controller Class Initialized
INFO - 2023-05-25 10:12:02 --> Controller Class Initialized
INFO - 2023-05-25 10:12:02 --> Security Class Initialized
DEBUG - 2023-05-25 10:12:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 10:12:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 10:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:12:02 --> Input Class Initialized
INFO - 2023-05-25 10:12:02 --> Language Class Initialized
INFO - 2023-05-25 10:12:02 --> Database Driver Class Initialized
INFO - 2023-05-25 10:12:02 --> Database Driver Class Initialized
INFO - 2023-05-25 10:12:02 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:12:02 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:12:02 --> Final output sent to browser
INFO - 2023-05-25 10:12:02 --> Final output sent to browser
DEBUG - 2023-05-25 10:12:02 --> Total execution time: 0.3737
DEBUG - 2023-05-25 10:12:02 --> Total execution time: 0.3720
INFO - 2023-05-25 10:12:02 --> Loader Class Initialized
INFO - 2023-05-25 10:12:02 --> Controller Class Initialized
DEBUG - 2023-05-25 10:12:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:12:02 --> Config Class Initialized
INFO - 2023-05-25 10:12:02 --> Config Class Initialized
INFO - 2023-05-25 10:12:02 --> Hooks Class Initialized
INFO - 2023-05-25 10:12:02 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 10:12:02 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:12:02 --> Utf8 Class Initialized
INFO - 2023-05-25 10:12:02 --> Utf8 Class Initialized
INFO - 2023-05-25 10:12:02 --> URI Class Initialized
INFO - 2023-05-25 10:12:02 --> URI Class Initialized
INFO - 2023-05-25 10:12:03 --> Database Driver Class Initialized
INFO - 2023-05-25 10:12:03 --> Router Class Initialized
INFO - 2023-05-25 10:12:03 --> Router Class Initialized
INFO - 2023-05-25 10:12:03 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:12:03 --> Output Class Initialized
INFO - 2023-05-25 10:12:03 --> Final output sent to browser
INFO - 2023-05-25 10:12:03 --> Output Class Initialized
DEBUG - 2023-05-25 10:12:03 --> Total execution time: 0.5723
INFO - 2023-05-25 10:12:03 --> Security Class Initialized
INFO - 2023-05-25 10:12:03 --> Security Class Initialized
DEBUG - 2023-05-25 10:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 10:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:12:03 --> Input Class Initialized
INFO - 2023-05-25 10:12:03 --> Input Class Initialized
INFO - 2023-05-25 10:12:03 --> Language Class Initialized
INFO - 2023-05-25 10:12:03 --> Language Class Initialized
INFO - 2023-05-25 10:12:03 --> Loader Class Initialized
INFO - 2023-05-25 10:12:03 --> Loader Class Initialized
INFO - 2023-05-25 10:12:03 --> Controller Class Initialized
INFO - 2023-05-25 10:12:03 --> Controller Class Initialized
DEBUG - 2023-05-25 10:12:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 10:12:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:12:03 --> Config Class Initialized
INFO - 2023-05-25 10:12:03 --> Hooks Class Initialized
INFO - 2023-05-25 10:12:03 --> Database Driver Class Initialized
INFO - 2023-05-25 10:12:03 --> Database Driver Class Initialized
INFO - 2023-05-25 10:12:03 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:12:03 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:12:03 --> Final output sent to browser
INFO - 2023-05-25 10:12:03 --> Final output sent to browser
DEBUG - 2023-05-25 10:12:03 --> Total execution time: 0.3350
DEBUG - 2023-05-25 10:12:03 --> Total execution time: 0.3357
DEBUG - 2023-05-25 10:12:03 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:12:03 --> Utf8 Class Initialized
INFO - 2023-05-25 10:12:03 --> URI Class Initialized
INFO - 2023-05-25 10:12:03 --> Router Class Initialized
INFO - 2023-05-25 10:12:03 --> Output Class Initialized
INFO - 2023-05-25 10:12:03 --> Config Class Initialized
INFO - 2023-05-25 10:12:03 --> Hooks Class Initialized
INFO - 2023-05-25 10:12:03 --> Security Class Initialized
DEBUG - 2023-05-25 10:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:12:03 --> Input Class Initialized
DEBUG - 2023-05-25 10:12:03 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:12:03 --> Utf8 Class Initialized
INFO - 2023-05-25 10:12:03 --> URI Class Initialized
INFO - 2023-05-25 10:12:03 --> Language Class Initialized
INFO - 2023-05-25 10:12:03 --> Router Class Initialized
INFO - 2023-05-25 10:12:03 --> Output Class Initialized
INFO - 2023-05-25 10:12:03 --> Security Class Initialized
INFO - 2023-05-25 10:12:03 --> Loader Class Initialized
DEBUG - 2023-05-25 10:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:12:03 --> Input Class Initialized
INFO - 2023-05-25 10:12:03 --> Controller Class Initialized
INFO - 2023-05-25 10:12:03 --> Language Class Initialized
DEBUG - 2023-05-25 10:12:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:12:03 --> Loader Class Initialized
INFO - 2023-05-25 10:12:03 --> Controller Class Initialized
DEBUG - 2023-05-25 10:12:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:12:03 --> Database Driver Class Initialized
INFO - 2023-05-25 10:12:03 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:12:03 --> Database Driver Class Initialized
INFO - 2023-05-25 10:12:03 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:12:04 --> Final output sent to browser
DEBUG - 2023-05-25 10:12:04 --> Total execution time: 1.4058
INFO - 2023-05-25 10:12:04 --> Config Class Initialized
INFO - 2023-05-25 10:12:04 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:12:04 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:12:04 --> Utf8 Class Initialized
INFO - 2023-05-25 10:12:04 --> URI Class Initialized
INFO - 2023-05-25 10:12:04 --> Router Class Initialized
INFO - 2023-05-25 10:12:04 --> Output Class Initialized
INFO - 2023-05-25 10:12:04 --> Security Class Initialized
DEBUG - 2023-05-25 10:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:12:04 --> Input Class Initialized
INFO - 2023-05-25 10:12:04 --> Language Class Initialized
INFO - 2023-05-25 10:12:04 --> Loader Class Initialized
INFO - 2023-05-25 10:12:04 --> Controller Class Initialized
DEBUG - 2023-05-25 10:12:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:12:04 --> Database Driver Class Initialized
INFO - 2023-05-25 10:12:04 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:15:31 --> Config Class Initialized
INFO - 2023-05-25 10:15:31 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:15:31 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:15:31 --> Utf8 Class Initialized
INFO - 2023-05-25 10:15:31 --> URI Class Initialized
INFO - 2023-05-25 10:15:31 --> Router Class Initialized
INFO - 2023-05-25 10:15:31 --> Output Class Initialized
INFO - 2023-05-25 10:15:31 --> Security Class Initialized
DEBUG - 2023-05-25 10:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:15:31 --> Input Class Initialized
INFO - 2023-05-25 10:15:31 --> Language Class Initialized
INFO - 2023-05-25 10:15:31 --> Loader Class Initialized
INFO - 2023-05-25 10:15:31 --> Controller Class Initialized
DEBUG - 2023-05-25 10:15:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:15:31 --> Final output sent to browser
DEBUG - 2023-05-25 10:15:31 --> Total execution time: 0.1624
INFO - 2023-05-25 10:15:31 --> Config Class Initialized
INFO - 2023-05-25 10:15:31 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:15:31 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:15:31 --> Utf8 Class Initialized
INFO - 2023-05-25 10:15:31 --> URI Class Initialized
INFO - 2023-05-25 10:15:31 --> Router Class Initialized
INFO - 2023-05-25 10:15:31 --> Output Class Initialized
INFO - 2023-05-25 10:15:31 --> Security Class Initialized
DEBUG - 2023-05-25 10:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:15:31 --> Input Class Initialized
INFO - 2023-05-25 10:15:31 --> Language Class Initialized
INFO - 2023-05-25 10:15:31 --> Loader Class Initialized
INFO - 2023-05-25 10:15:32 --> Controller Class Initialized
DEBUG - 2023-05-25 10:15:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:15:32 --> Database Driver Class Initialized
INFO - 2023-05-25 10:15:32 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:15:32 --> Final output sent to browser
DEBUG - 2023-05-25 10:15:32 --> Total execution time: 0.2594
INFO - 2023-05-25 10:16:26 --> Config Class Initialized
INFO - 2023-05-25 10:16:26 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:16:26 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:16:26 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:26 --> URI Class Initialized
INFO - 2023-05-25 10:16:26 --> Router Class Initialized
INFO - 2023-05-25 10:16:26 --> Output Class Initialized
INFO - 2023-05-25 10:16:26 --> Security Class Initialized
DEBUG - 2023-05-25 10:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:16:26 --> Input Class Initialized
INFO - 2023-05-25 10:16:26 --> Language Class Initialized
INFO - 2023-05-25 10:16:26 --> Loader Class Initialized
INFO - 2023-05-25 10:16:26 --> Controller Class Initialized
INFO - 2023-05-25 10:16:26 --> Helper loaded: form_helper
INFO - 2023-05-25 10:16:26 --> Helper loaded: url_helper
DEBUG - 2023-05-25 10:16:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:26 --> Model "Change_model" initialized
INFO - 2023-05-25 10:16:26 --> Model "Grafana_model" initialized
INFO - 2023-05-25 10:16:26 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:26 --> Total execution time: 0.3115
INFO - 2023-05-25 10:16:26 --> Config Class Initialized
INFO - 2023-05-25 10:16:26 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:16:27 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:16:27 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:27 --> URI Class Initialized
INFO - 2023-05-25 10:16:27 --> Router Class Initialized
INFO - 2023-05-25 10:16:27 --> Output Class Initialized
INFO - 2023-05-25 10:16:27 --> Security Class Initialized
DEBUG - 2023-05-25 10:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:16:27 --> Input Class Initialized
INFO - 2023-05-25 10:16:27 --> Language Class Initialized
INFO - 2023-05-25 10:16:27 --> Loader Class Initialized
INFO - 2023-05-25 10:16:27 --> Controller Class Initialized
INFO - 2023-05-25 10:16:27 --> Helper loaded: form_helper
INFO - 2023-05-25 10:16:27 --> Helper loaded: url_helper
DEBUG - 2023-05-25 10:16:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:27 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:27 --> Total execution time: 0.1678
INFO - 2023-05-25 10:16:27 --> Config Class Initialized
INFO - 2023-05-25 10:16:27 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:16:27 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:16:27 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:27 --> URI Class Initialized
INFO - 2023-05-25 10:16:27 --> Router Class Initialized
INFO - 2023-05-25 10:16:27 --> Output Class Initialized
INFO - 2023-05-25 10:16:27 --> Security Class Initialized
DEBUG - 2023-05-25 10:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:16:27 --> Input Class Initialized
INFO - 2023-05-25 10:16:27 --> Language Class Initialized
INFO - 2023-05-25 10:16:27 --> Loader Class Initialized
INFO - 2023-05-25 10:16:27 --> Controller Class Initialized
INFO - 2023-05-25 10:16:27 --> Helper loaded: form_helper
INFO - 2023-05-25 10:16:27 --> Helper loaded: url_helper
DEBUG - 2023-05-25 10:16:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:27 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:27 --> Model "Login_model" initialized
INFO - 2023-05-25 10:16:27 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:27 --> Total execution time: 0.4043
INFO - 2023-05-25 10:16:27 --> Config Class Initialized
INFO - 2023-05-25 10:16:27 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:16:27 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:16:27 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:27 --> URI Class Initialized
INFO - 2023-05-25 10:16:27 --> Router Class Initialized
INFO - 2023-05-25 10:16:27 --> Output Class Initialized
INFO - 2023-05-25 10:16:27 --> Security Class Initialized
DEBUG - 2023-05-25 10:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:16:27 --> Input Class Initialized
INFO - 2023-05-25 10:16:27 --> Language Class Initialized
INFO - 2023-05-25 10:16:27 --> Loader Class Initialized
INFO - 2023-05-25 10:16:27 --> Controller Class Initialized
DEBUG - 2023-05-25 10:16:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:27 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:27 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:16:27 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:27 --> Total execution time: 0.2598
INFO - 2023-05-25 10:16:27 --> Config Class Initialized
INFO - 2023-05-25 10:16:27 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:16:27 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:16:27 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:27 --> URI Class Initialized
INFO - 2023-05-25 10:16:27 --> Router Class Initialized
INFO - 2023-05-25 10:16:27 --> Output Class Initialized
INFO - 2023-05-25 10:16:27 --> Security Class Initialized
DEBUG - 2023-05-25 10:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:16:28 --> Input Class Initialized
INFO - 2023-05-25 10:16:28 --> Language Class Initialized
INFO - 2023-05-25 10:16:28 --> Loader Class Initialized
INFO - 2023-05-25 10:16:28 --> Controller Class Initialized
DEBUG - 2023-05-25 10:16:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:28 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:28 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:16:28 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:28 --> Total execution time: 0.1937
INFO - 2023-05-25 10:16:28 --> Config Class Initialized
INFO - 2023-05-25 10:16:28 --> Config Class Initialized
INFO - 2023-05-25 10:16:28 --> Hooks Class Initialized
INFO - 2023-05-25 10:16:28 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:16:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 10:16:28 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:16:28 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:28 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:28 --> URI Class Initialized
INFO - 2023-05-25 10:16:28 --> URI Class Initialized
INFO - 2023-05-25 10:16:28 --> Router Class Initialized
INFO - 2023-05-25 10:16:28 --> Router Class Initialized
INFO - 2023-05-25 10:16:28 --> Output Class Initialized
INFO - 2023-05-25 10:16:28 --> Output Class Initialized
INFO - 2023-05-25 10:16:28 --> Security Class Initialized
INFO - 2023-05-25 10:16:28 --> Security Class Initialized
DEBUG - 2023-05-25 10:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 10:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:16:28 --> Input Class Initialized
INFO - 2023-05-25 10:16:28 --> Input Class Initialized
INFO - 2023-05-25 10:16:28 --> Language Class Initialized
INFO - 2023-05-25 10:16:28 --> Language Class Initialized
INFO - 2023-05-25 10:16:28 --> Loader Class Initialized
INFO - 2023-05-25 10:16:28 --> Loader Class Initialized
INFO - 2023-05-25 10:16:28 --> Controller Class Initialized
DEBUG - 2023-05-25 10:16:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:28 --> Controller Class Initialized
DEBUG - 2023-05-25 10:16:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:28 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:28 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:28 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:16:28 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:16:28 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:28 --> Total execution time: 0.2458
INFO - 2023-05-25 10:16:28 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:28 --> Config Class Initialized
INFO - 2023-05-25 10:16:28 --> Model "Login_model" initialized
INFO - 2023-05-25 10:16:28 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:16:28 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:16:28 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:28 --> URI Class Initialized
INFO - 2023-05-25 10:16:28 --> Router Class Initialized
INFO - 2023-05-25 10:16:28 --> Output Class Initialized
INFO - 2023-05-25 10:16:28 --> Security Class Initialized
DEBUG - 2023-05-25 10:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:16:28 --> Input Class Initialized
INFO - 2023-05-25 10:16:28 --> Language Class Initialized
INFO - 2023-05-25 10:16:28 --> Loader Class Initialized
INFO - 2023-05-25 10:16:28 --> Controller Class Initialized
DEBUG - 2023-05-25 10:16:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:28 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:28 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:16:28 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:28 --> Total execution time: 0.2506
INFO - 2023-05-25 10:16:29 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:29 --> Total execution time: 0.6763
INFO - 2023-05-25 10:16:29 --> Config Class Initialized
INFO - 2023-05-25 10:16:29 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:16:29 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:16:29 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:29 --> URI Class Initialized
INFO - 2023-05-25 10:16:29 --> Router Class Initialized
INFO - 2023-05-25 10:16:29 --> Output Class Initialized
INFO - 2023-05-25 10:16:29 --> Security Class Initialized
DEBUG - 2023-05-25 10:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:16:29 --> Input Class Initialized
INFO - 2023-05-25 10:16:29 --> Language Class Initialized
INFO - 2023-05-25 10:16:29 --> Loader Class Initialized
INFO - 2023-05-25 10:16:29 --> Controller Class Initialized
DEBUG - 2023-05-25 10:16:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:29 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:29 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:16:29 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:29 --> Model "Login_model" initialized
INFO - 2023-05-25 10:16:29 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:29 --> Total execution time: 0.5788
INFO - 2023-05-25 10:16:41 --> Config Class Initialized
INFO - 2023-05-25 10:16:41 --> Config Class Initialized
INFO - 2023-05-25 10:16:41 --> Config Class Initialized
INFO - 2023-05-25 10:16:41 --> Hooks Class Initialized
INFO - 2023-05-25 10:16:41 --> Hooks Class Initialized
INFO - 2023-05-25 10:16:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:16:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 10:16:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 10:16:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:16:41 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:41 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:41 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:41 --> URI Class Initialized
INFO - 2023-05-25 10:16:41 --> URI Class Initialized
INFO - 2023-05-25 10:16:41 --> URI Class Initialized
INFO - 2023-05-25 10:16:41 --> Router Class Initialized
INFO - 2023-05-25 10:16:41 --> Router Class Initialized
INFO - 2023-05-25 10:16:41 --> Router Class Initialized
INFO - 2023-05-25 10:16:41 --> Output Class Initialized
INFO - 2023-05-25 10:16:41 --> Output Class Initialized
INFO - 2023-05-25 10:16:41 --> Output Class Initialized
INFO - 2023-05-25 10:16:41 --> Security Class Initialized
INFO - 2023-05-25 10:16:41 --> Security Class Initialized
INFO - 2023-05-25 10:16:41 --> Security Class Initialized
DEBUG - 2023-05-25 10:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 10:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 10:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:16:41 --> Input Class Initialized
INFO - 2023-05-25 10:16:41 --> Input Class Initialized
INFO - 2023-05-25 10:16:41 --> Input Class Initialized
INFO - 2023-05-25 10:16:41 --> Language Class Initialized
INFO - 2023-05-25 10:16:41 --> Language Class Initialized
INFO - 2023-05-25 10:16:41 --> Language Class Initialized
INFO - 2023-05-25 10:16:42 --> Loader Class Initialized
INFO - 2023-05-25 10:16:42 --> Loader Class Initialized
INFO - 2023-05-25 10:16:42 --> Loader Class Initialized
INFO - 2023-05-25 10:16:42 --> Controller Class Initialized
INFO - 2023-05-25 10:16:42 --> Controller Class Initialized
INFO - 2023-05-25 10:16:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:16:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 10:16:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 10:16:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:16:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:16:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:42 --> Model "Login_model" initialized
INFO - 2023-05-25 10:16:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:42 --> Total execution time: 0.2278
INFO - 2023-05-25 10:16:42 --> Final output sent to browser
INFO - 2023-05-25 10:16:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:42 --> Total execution time: 0.2385
DEBUG - 2023-05-25 10:16:42 --> Total execution time: 0.2423
INFO - 2023-05-25 10:16:42 --> Config Class Initialized
INFO - 2023-05-25 10:16:42 --> Config Class Initialized
INFO - 2023-05-25 10:16:42 --> Config Class Initialized
INFO - 2023-05-25 10:16:42 --> Hooks Class Initialized
INFO - 2023-05-25 10:16:42 --> Hooks Class Initialized
INFO - 2023-05-25 10:16:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:16:42 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 10:16:42 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 10:16:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:16:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:42 --> URI Class Initialized
INFO - 2023-05-25 10:16:42 --> URI Class Initialized
INFO - 2023-05-25 10:16:42 --> URI Class Initialized
INFO - 2023-05-25 10:16:42 --> Config Class Initialized
INFO - 2023-05-25 10:16:42 --> Hooks Class Initialized
INFO - 2023-05-25 10:16:42 --> Router Class Initialized
INFO - 2023-05-25 10:16:42 --> Router Class Initialized
INFO - 2023-05-25 10:16:42 --> Router Class Initialized
INFO - 2023-05-25 10:16:42 --> Output Class Initialized
INFO - 2023-05-25 10:16:42 --> Output Class Initialized
INFO - 2023-05-25 10:16:42 --> Output Class Initialized
INFO - 2023-05-25 10:16:42 --> Security Class Initialized
INFO - 2023-05-25 10:16:42 --> Security Class Initialized
INFO - 2023-05-25 10:16:42 --> Security Class Initialized
DEBUG - 2023-05-25 10:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 10:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 10:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 10:16:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:16:42 --> Input Class Initialized
INFO - 2023-05-25 10:16:42 --> Input Class Initialized
INFO - 2023-05-25 10:16:42 --> Input Class Initialized
INFO - 2023-05-25 10:16:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:42 --> Language Class Initialized
INFO - 2023-05-25 10:16:42 --> Language Class Initialized
INFO - 2023-05-25 10:16:42 --> Language Class Initialized
INFO - 2023-05-25 10:16:42 --> URI Class Initialized
INFO - 2023-05-25 10:16:42 --> Loader Class Initialized
INFO - 2023-05-25 10:16:42 --> Loader Class Initialized
INFO - 2023-05-25 10:16:42 --> Loader Class Initialized
INFO - 2023-05-25 10:16:42 --> Router Class Initialized
INFO - 2023-05-25 10:16:42 --> Controller Class Initialized
INFO - 2023-05-25 10:16:42 --> Controller Class Initialized
INFO - 2023-05-25 10:16:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:16:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 10:16:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:42 --> Output Class Initialized
DEBUG - 2023-05-25 10:16:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:42 --> Security Class Initialized
DEBUG - 2023-05-25 10:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:16:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:42 --> Input Class Initialized
INFO - 2023-05-25 10:16:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:42 --> Language Class Initialized
INFO - 2023-05-25 10:16:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:16:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:16:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:16:42 --> Loader Class Initialized
INFO - 2023-05-25 10:16:42 --> Controller Class Initialized
INFO - 2023-05-25 10:16:42 --> Final output sent to browser
INFO - 2023-05-25 10:16:42 --> Final output sent to browser
INFO - 2023-05-25 10:16:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:42 --> Total execution time: 0.2790
DEBUG - 2023-05-25 10:16:42 --> Total execution time: 0.2687
DEBUG - 2023-05-25 10:16:42 --> Total execution time: 0.2635
DEBUG - 2023-05-25 10:16:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:42 --> Config Class Initialized
INFO - 2023-05-25 10:16:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:16:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:16:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:16:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:42 --> URI Class Initialized
INFO - 2023-05-25 10:16:42 --> Router Class Initialized
INFO - 2023-05-25 10:16:42 --> Model "Login_model" initialized
INFO - 2023-05-25 10:16:42 --> Output Class Initialized
INFO - 2023-05-25 10:16:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:42 --> Total execution time: 0.3892
INFO - 2023-05-25 10:16:42 --> Security Class Initialized
DEBUG - 2023-05-25 10:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:16:42 --> Input Class Initialized
INFO - 2023-05-25 10:16:42 --> Language Class Initialized
INFO - 2023-05-25 10:16:42 --> Loader Class Initialized
INFO - 2023-05-25 10:16:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:16:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:16:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:16:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:16:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:16:42 --> Total execution time: 0.2696
INFO - 2023-05-25 10:17:42 --> Config Class Initialized
INFO - 2023-05-25 10:17:42 --> Config Class Initialized
INFO - 2023-05-25 10:17:42 --> Hooks Class Initialized
INFO - 2023-05-25 10:17:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:17:42 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 10:17:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:17:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:17:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:17:42 --> URI Class Initialized
INFO - 2023-05-25 10:17:42 --> URI Class Initialized
INFO - 2023-05-25 10:17:42 --> Router Class Initialized
INFO - 2023-05-25 10:17:42 --> Router Class Initialized
INFO - 2023-05-25 10:17:42 --> Output Class Initialized
INFO - 2023-05-25 10:17:42 --> Output Class Initialized
INFO - 2023-05-25 10:17:42 --> Security Class Initialized
INFO - 2023-05-25 10:17:42 --> Security Class Initialized
DEBUG - 2023-05-25 10:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 10:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:17:42 --> Input Class Initialized
INFO - 2023-05-25 10:17:42 --> Input Class Initialized
INFO - 2023-05-25 10:17:42 --> Language Class Initialized
INFO - 2023-05-25 10:17:42 --> Language Class Initialized
INFO - 2023-05-25 10:17:42 --> Loader Class Initialized
INFO - 2023-05-25 10:17:42 --> Loader Class Initialized
INFO - 2023-05-25 10:17:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:17:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:17:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:17:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:17:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:17:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:17:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:17:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:17:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:17:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:17:42 --> Total execution time: 0.1747
INFO - 2023-05-25 10:17:42 --> Model "Login_model" initialized
INFO - 2023-05-25 10:17:42 --> Config Class Initialized
INFO - 2023-05-25 10:17:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:17:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:17:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:17:42 --> URI Class Initialized
INFO - 2023-05-25 10:17:42 --> Router Class Initialized
INFO - 2023-05-25 10:17:42 --> Output Class Initialized
INFO - 2023-05-25 10:17:42 --> Security Class Initialized
DEBUG - 2023-05-25 10:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:17:42 --> Input Class Initialized
INFO - 2023-05-25 10:17:42 --> Language Class Initialized
INFO - 2023-05-25 10:17:42 --> Loader Class Initialized
INFO - 2023-05-25 10:17:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:17:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:17:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:17:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:17:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:17:42 --> Total execution time: 0.2620
INFO - 2023-05-25 10:17:50 --> Final output sent to browser
DEBUG - 2023-05-25 10:17:50 --> Total execution time: 8.0672
INFO - 2023-05-25 10:17:50 --> Config Class Initialized
INFO - 2023-05-25 10:17:50 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:17:50 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:17:50 --> Utf8 Class Initialized
INFO - 2023-05-25 10:17:50 --> URI Class Initialized
INFO - 2023-05-25 10:17:50 --> Router Class Initialized
INFO - 2023-05-25 10:17:50 --> Output Class Initialized
INFO - 2023-05-25 10:17:50 --> Security Class Initialized
DEBUG - 2023-05-25 10:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:17:50 --> Input Class Initialized
INFO - 2023-05-25 10:17:50 --> Language Class Initialized
INFO - 2023-05-25 10:17:50 --> Loader Class Initialized
INFO - 2023-05-25 10:17:50 --> Controller Class Initialized
DEBUG - 2023-05-25 10:17:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:17:50 --> Database Driver Class Initialized
INFO - 2023-05-25 10:17:50 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:17:50 --> Database Driver Class Initialized
INFO - 2023-05-25 10:17:50 --> Model "Login_model" initialized
INFO - 2023-05-25 10:18:00 --> Final output sent to browser
DEBUG - 2023-05-25 10:18:00 --> Total execution time: 10.4769
INFO - 2023-05-25 10:18:41 --> Config Class Initialized
INFO - 2023-05-25 10:18:41 --> Config Class Initialized
INFO - 2023-05-25 10:18:41 --> Hooks Class Initialized
INFO - 2023-05-25 10:18:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:18:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 10:18:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:18:41 --> Utf8 Class Initialized
INFO - 2023-05-25 10:18:41 --> Utf8 Class Initialized
INFO - 2023-05-25 10:18:41 --> URI Class Initialized
INFO - 2023-05-25 10:18:41 --> URI Class Initialized
INFO - 2023-05-25 10:18:41 --> Router Class Initialized
INFO - 2023-05-25 10:18:41 --> Router Class Initialized
INFO - 2023-05-25 10:18:41 --> Output Class Initialized
INFO - 2023-05-25 10:18:41 --> Output Class Initialized
INFO - 2023-05-25 10:18:41 --> Security Class Initialized
INFO - 2023-05-25 10:18:41 --> Security Class Initialized
DEBUG - 2023-05-25 10:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 10:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:18:41 --> Input Class Initialized
INFO - 2023-05-25 10:18:41 --> Input Class Initialized
INFO - 2023-05-25 10:18:41 --> Language Class Initialized
INFO - 2023-05-25 10:18:41 --> Language Class Initialized
INFO - 2023-05-25 10:18:41 --> Loader Class Initialized
INFO - 2023-05-25 10:18:42 --> Controller Class Initialized
INFO - 2023-05-25 10:18:42 --> Loader Class Initialized
DEBUG - 2023-05-25 10:18:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:18:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:18:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:18:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:18:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:18:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:18:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:18:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:18:42 --> Model "Login_model" initialized
INFO - 2023-05-25 10:18:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:18:42 --> Total execution time: 0.5052
INFO - 2023-05-25 10:18:42 --> Config Class Initialized
INFO - 2023-05-25 10:18:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:18:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:18:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:18:42 --> URI Class Initialized
INFO - 2023-05-25 10:18:42 --> Router Class Initialized
INFO - 2023-05-25 10:18:42 --> Output Class Initialized
INFO - 2023-05-25 10:18:42 --> Security Class Initialized
DEBUG - 2023-05-25 10:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:18:42 --> Input Class Initialized
INFO - 2023-05-25 10:18:42 --> Language Class Initialized
INFO - 2023-05-25 10:18:42 --> Loader Class Initialized
INFO - 2023-05-25 10:18:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:18:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:18:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:18:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:18:43 --> Final output sent to browser
DEBUG - 2023-05-25 10:18:43 --> Total execution time: 0.5497
INFO - 2023-05-25 10:18:50 --> Final output sent to browser
DEBUG - 2023-05-25 10:18:50 --> Total execution time: 8.4236
INFO - 2023-05-25 10:18:50 --> Config Class Initialized
INFO - 2023-05-25 10:18:50 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:18:50 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:18:50 --> Utf8 Class Initialized
INFO - 2023-05-25 10:18:50 --> URI Class Initialized
INFO - 2023-05-25 10:18:50 --> Router Class Initialized
INFO - 2023-05-25 10:18:50 --> Output Class Initialized
INFO - 2023-05-25 10:18:50 --> Security Class Initialized
DEBUG - 2023-05-25 10:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:18:50 --> Input Class Initialized
INFO - 2023-05-25 10:18:50 --> Language Class Initialized
INFO - 2023-05-25 10:18:50 --> Loader Class Initialized
INFO - 2023-05-25 10:18:50 --> Controller Class Initialized
DEBUG - 2023-05-25 10:18:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:18:50 --> Database Driver Class Initialized
INFO - 2023-05-25 10:18:50 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:18:50 --> Database Driver Class Initialized
INFO - 2023-05-25 10:18:50 --> Model "Login_model" initialized
INFO - 2023-05-25 10:18:59 --> Final output sent to browser
DEBUG - 2023-05-25 10:18:59 --> Total execution time: 8.6697
INFO - 2023-05-25 10:19:41 --> Config Class Initialized
INFO - 2023-05-25 10:19:41 --> Config Class Initialized
INFO - 2023-05-25 10:19:41 --> Hooks Class Initialized
INFO - 2023-05-25 10:19:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:19:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 10:19:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:19:41 --> Utf8 Class Initialized
INFO - 2023-05-25 10:19:41 --> Utf8 Class Initialized
INFO - 2023-05-25 10:19:41 --> URI Class Initialized
INFO - 2023-05-25 10:19:41 --> URI Class Initialized
INFO - 2023-05-25 10:19:41 --> Router Class Initialized
INFO - 2023-05-25 10:19:41 --> Router Class Initialized
INFO - 2023-05-25 10:19:41 --> Output Class Initialized
INFO - 2023-05-25 10:19:41 --> Output Class Initialized
INFO - 2023-05-25 10:19:41 --> Security Class Initialized
INFO - 2023-05-25 10:19:41 --> Security Class Initialized
DEBUG - 2023-05-25 10:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 10:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:19:41 --> Input Class Initialized
INFO - 2023-05-25 10:19:41 --> Input Class Initialized
INFO - 2023-05-25 10:19:41 --> Language Class Initialized
INFO - 2023-05-25 10:19:41 --> Language Class Initialized
INFO - 2023-05-25 10:19:42 --> Loader Class Initialized
INFO - 2023-05-25 10:19:42 --> Loader Class Initialized
INFO - 2023-05-25 10:19:42 --> Controller Class Initialized
INFO - 2023-05-25 10:19:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:19:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-25 10:19:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:19:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:19:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:19:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:19:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:19:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:19:42 --> Model "Login_model" initialized
INFO - 2023-05-25 10:19:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:19:42 --> Total execution time: 0.3343
INFO - 2023-05-25 10:19:42 --> Config Class Initialized
INFO - 2023-05-25 10:19:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:19:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:19:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:19:42 --> URI Class Initialized
INFO - 2023-05-25 10:19:42 --> Router Class Initialized
INFO - 2023-05-25 10:19:42 --> Output Class Initialized
INFO - 2023-05-25 10:19:42 --> Security Class Initialized
DEBUG - 2023-05-25 10:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:19:42 --> Input Class Initialized
INFO - 2023-05-25 10:19:42 --> Language Class Initialized
INFO - 2023-05-25 10:19:42 --> Loader Class Initialized
INFO - 2023-05-25 10:19:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:19:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:19:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:19:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:19:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:19:42 --> Total execution time: 0.3783
INFO - 2023-05-25 10:19:50 --> Final output sent to browser
DEBUG - 2023-05-25 10:19:50 --> Total execution time: 8.9853
INFO - 2023-05-25 10:19:50 --> Config Class Initialized
INFO - 2023-05-25 10:19:50 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:19:50 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:19:50 --> Utf8 Class Initialized
INFO - 2023-05-25 10:19:50 --> URI Class Initialized
INFO - 2023-05-25 10:19:50 --> Router Class Initialized
INFO - 2023-05-25 10:19:50 --> Output Class Initialized
INFO - 2023-05-25 10:19:51 --> Security Class Initialized
DEBUG - 2023-05-25 10:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:19:51 --> Input Class Initialized
INFO - 2023-05-25 10:19:51 --> Language Class Initialized
INFO - 2023-05-25 10:19:51 --> Loader Class Initialized
INFO - 2023-05-25 10:19:51 --> Controller Class Initialized
DEBUG - 2023-05-25 10:19:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:19:51 --> Database Driver Class Initialized
INFO - 2023-05-25 10:19:51 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:19:51 --> Database Driver Class Initialized
INFO - 2023-05-25 10:19:51 --> Model "Login_model" initialized
INFO - 2023-05-25 10:19:59 --> Final output sent to browser
DEBUG - 2023-05-25 10:19:59 --> Total execution time: 8.9002
INFO - 2023-05-25 10:20:41 --> Config Class Initialized
INFO - 2023-05-25 10:20:41 --> Config Class Initialized
INFO - 2023-05-25 10:20:41 --> Hooks Class Initialized
INFO - 2023-05-25 10:20:41 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:20:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-25 10:20:41 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:20:41 --> Utf8 Class Initialized
INFO - 2023-05-25 10:20:41 --> Utf8 Class Initialized
INFO - 2023-05-25 10:20:41 --> URI Class Initialized
INFO - 2023-05-25 10:20:41 --> URI Class Initialized
INFO - 2023-05-25 10:20:41 --> Router Class Initialized
INFO - 2023-05-25 10:20:41 --> Router Class Initialized
INFO - 2023-05-25 10:20:41 --> Output Class Initialized
INFO - 2023-05-25 10:20:41 --> Output Class Initialized
INFO - 2023-05-25 10:20:41 --> Security Class Initialized
INFO - 2023-05-25 10:20:41 --> Security Class Initialized
DEBUG - 2023-05-25 10:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-25 10:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:20:41 --> Input Class Initialized
INFO - 2023-05-25 10:20:41 --> Input Class Initialized
INFO - 2023-05-25 10:20:41 --> Language Class Initialized
INFO - 2023-05-25 10:20:41 --> Language Class Initialized
INFO - 2023-05-25 10:20:41 --> Loader Class Initialized
INFO - 2023-05-25 10:20:41 --> Loader Class Initialized
INFO - 2023-05-25 10:20:41 --> Controller Class Initialized
DEBUG - 2023-05-25 10:20:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:20:41 --> Controller Class Initialized
DEBUG - 2023-05-25 10:20:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:20:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:20:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:20:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:20:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:20:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:20:42 --> Model "Login_model" initialized
INFO - 2023-05-25 10:20:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:20:42 --> Total execution time: 0.2616
INFO - 2023-05-25 10:20:42 --> Config Class Initialized
INFO - 2023-05-25 10:20:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:20:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:20:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:20:42 --> URI Class Initialized
INFO - 2023-05-25 10:20:42 --> Router Class Initialized
INFO - 2023-05-25 10:20:42 --> Output Class Initialized
INFO - 2023-05-25 10:20:42 --> Security Class Initialized
DEBUG - 2023-05-25 10:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:20:42 --> Input Class Initialized
INFO - 2023-05-25 10:20:42 --> Language Class Initialized
INFO - 2023-05-25 10:20:42 --> Loader Class Initialized
INFO - 2023-05-25 10:20:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:20:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:20:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:20:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:20:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:20:42 --> Total execution time: 0.2190
INFO - 2023-05-25 10:20:51 --> Final output sent to browser
DEBUG - 2023-05-25 10:20:51 --> Total execution time: 9.9371
INFO - 2023-05-25 10:20:51 --> Config Class Initialized
INFO - 2023-05-25 10:20:51 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:20:51 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:20:51 --> Utf8 Class Initialized
INFO - 2023-05-25 10:20:51 --> URI Class Initialized
INFO - 2023-05-25 10:20:51 --> Router Class Initialized
INFO - 2023-05-25 10:20:51 --> Output Class Initialized
INFO - 2023-05-25 10:20:51 --> Security Class Initialized
DEBUG - 2023-05-25 10:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:20:51 --> Input Class Initialized
INFO - 2023-05-25 10:20:52 --> Language Class Initialized
INFO - 2023-05-25 10:20:52 --> Loader Class Initialized
INFO - 2023-05-25 10:20:52 --> Controller Class Initialized
DEBUG - 2023-05-25 10:20:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:20:52 --> Database Driver Class Initialized
INFO - 2023-05-25 10:20:52 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:20:52 --> Database Driver Class Initialized
INFO - 2023-05-25 10:20:52 --> Model "Login_model" initialized
INFO - 2023-05-25 10:21:02 --> Final output sent to browser
DEBUG - 2023-05-25 10:21:02 --> Total execution time: 10.2810
INFO - 2023-05-25 10:21:42 --> Config Class Initialized
INFO - 2023-05-25 10:21:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:21:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:21:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:21:42 --> URI Class Initialized
INFO - 2023-05-25 10:21:42 --> Router Class Initialized
INFO - 2023-05-25 10:21:42 --> Output Class Initialized
INFO - 2023-05-25 10:21:42 --> Security Class Initialized
DEBUG - 2023-05-25 10:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:21:42 --> Input Class Initialized
INFO - 2023-05-25 10:21:42 --> Language Class Initialized
INFO - 2023-05-25 10:21:42 --> Loader Class Initialized
INFO - 2023-05-25 10:21:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:21:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:21:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:21:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:21:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:21:42 --> Total execution time: 0.4068
INFO - 2023-05-25 10:21:42 --> Config Class Initialized
INFO - 2023-05-25 10:21:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:21:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:21:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:21:42 --> URI Class Initialized
INFO - 2023-05-25 10:21:42 --> Router Class Initialized
INFO - 2023-05-25 10:21:42 --> Output Class Initialized
INFO - 2023-05-25 10:21:42 --> Security Class Initialized
DEBUG - 2023-05-25 10:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:21:42 --> Input Class Initialized
INFO - 2023-05-25 10:21:42 --> Language Class Initialized
INFO - 2023-05-25 10:21:42 --> Loader Class Initialized
INFO - 2023-05-25 10:21:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:21:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:21:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:21:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:21:43 --> Final output sent to browser
DEBUG - 2023-05-25 10:21:43 --> Total execution time: 0.3674
INFO - 2023-05-25 10:21:43 --> Config Class Initialized
INFO - 2023-05-25 10:21:43 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:21:43 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:21:43 --> Utf8 Class Initialized
INFO - 2023-05-25 10:21:43 --> URI Class Initialized
INFO - 2023-05-25 10:21:43 --> Router Class Initialized
INFO - 2023-05-25 10:21:43 --> Output Class Initialized
INFO - 2023-05-25 10:21:43 --> Security Class Initialized
DEBUG - 2023-05-25 10:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:21:43 --> Input Class Initialized
INFO - 2023-05-25 10:21:43 --> Language Class Initialized
INFO - 2023-05-25 10:21:43 --> Loader Class Initialized
INFO - 2023-05-25 10:21:43 --> Controller Class Initialized
DEBUG - 2023-05-25 10:21:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:21:43 --> Database Driver Class Initialized
INFO - 2023-05-25 10:21:43 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:21:43 --> Database Driver Class Initialized
INFO - 2023-05-25 10:21:43 --> Model "Login_model" initialized
INFO - 2023-05-25 10:21:53 --> Final output sent to browser
DEBUG - 2023-05-25 10:21:53 --> Total execution time: 10.5162
INFO - 2023-05-25 10:21:53 --> Config Class Initialized
INFO - 2023-05-25 10:21:53 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:21:53 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:21:53 --> Utf8 Class Initialized
INFO - 2023-05-25 10:21:53 --> URI Class Initialized
INFO - 2023-05-25 10:21:53 --> Router Class Initialized
INFO - 2023-05-25 10:21:53 --> Output Class Initialized
INFO - 2023-05-25 10:21:53 --> Security Class Initialized
DEBUG - 2023-05-25 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:21:53 --> Input Class Initialized
INFO - 2023-05-25 10:21:53 --> Language Class Initialized
INFO - 2023-05-25 10:21:53 --> Loader Class Initialized
INFO - 2023-05-25 10:21:53 --> Controller Class Initialized
DEBUG - 2023-05-25 10:21:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:21:53 --> Database Driver Class Initialized
INFO - 2023-05-25 10:21:54 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:21:54 --> Database Driver Class Initialized
INFO - 2023-05-25 10:21:54 --> Model "Login_model" initialized
INFO - 2023-05-25 10:22:04 --> Final output sent to browser
DEBUG - 2023-05-25 10:22:04 --> Total execution time: 10.3243
INFO - 2023-05-25 10:23:39 --> Config Class Initialized
INFO - 2023-05-25 10:23:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:23:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:23:39 --> Utf8 Class Initialized
INFO - 2023-05-25 10:23:39 --> URI Class Initialized
INFO - 2023-05-25 10:23:39 --> Router Class Initialized
INFO - 2023-05-25 10:23:39 --> Output Class Initialized
INFO - 2023-05-25 10:23:39 --> Security Class Initialized
DEBUG - 2023-05-25 10:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:23:39 --> Input Class Initialized
INFO - 2023-05-25 10:23:39 --> Language Class Initialized
INFO - 2023-05-25 10:23:39 --> Loader Class Initialized
INFO - 2023-05-25 10:23:39 --> Controller Class Initialized
DEBUG - 2023-05-25 10:23:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:23:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:23:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:23:39 --> Final output sent to browser
DEBUG - 2023-05-25 10:23:39 --> Total execution time: 0.3091
INFO - 2023-05-25 10:23:39 --> Config Class Initialized
INFO - 2023-05-25 10:23:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:23:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:23:39 --> Utf8 Class Initialized
INFO - 2023-05-25 10:23:39 --> URI Class Initialized
INFO - 2023-05-25 10:23:39 --> Router Class Initialized
INFO - 2023-05-25 10:23:39 --> Output Class Initialized
INFO - 2023-05-25 10:23:39 --> Security Class Initialized
DEBUG - 2023-05-25 10:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:23:39 --> Input Class Initialized
INFO - 2023-05-25 10:23:39 --> Language Class Initialized
INFO - 2023-05-25 10:23:39 --> Loader Class Initialized
INFO - 2023-05-25 10:23:39 --> Controller Class Initialized
DEBUG - 2023-05-25 10:23:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:23:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:23:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:23:40 --> Final output sent to browser
DEBUG - 2023-05-25 10:23:40 --> Total execution time: 0.5177
INFO - 2023-05-25 10:24:39 --> Config Class Initialized
INFO - 2023-05-25 10:24:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:24:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:24:39 --> Utf8 Class Initialized
INFO - 2023-05-25 10:24:39 --> URI Class Initialized
INFO - 2023-05-25 10:24:39 --> Router Class Initialized
INFO - 2023-05-25 10:24:39 --> Output Class Initialized
INFO - 2023-05-25 10:24:39 --> Security Class Initialized
DEBUG - 2023-05-25 10:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:24:39 --> Input Class Initialized
INFO - 2023-05-25 10:24:39 --> Language Class Initialized
INFO - 2023-05-25 10:24:39 --> Loader Class Initialized
INFO - 2023-05-25 10:24:39 --> Controller Class Initialized
DEBUG - 2023-05-25 10:24:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:24:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:24:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:24:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:24:39 --> Model "Login_model" initialized
INFO - 2023-05-25 10:24:47 --> Final output sent to browser
DEBUG - 2023-05-25 10:24:47 --> Total execution time: 8.1390
INFO - 2023-05-25 10:24:47 --> Config Class Initialized
INFO - 2023-05-25 10:24:47 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:24:47 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:24:47 --> Utf8 Class Initialized
INFO - 2023-05-25 10:24:47 --> URI Class Initialized
INFO - 2023-05-25 10:24:47 --> Router Class Initialized
INFO - 2023-05-25 10:24:47 --> Output Class Initialized
INFO - 2023-05-25 10:24:47 --> Security Class Initialized
DEBUG - 2023-05-25 10:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:24:47 --> Input Class Initialized
INFO - 2023-05-25 10:24:47 --> Language Class Initialized
INFO - 2023-05-25 10:24:47 --> Loader Class Initialized
INFO - 2023-05-25 10:24:47 --> Controller Class Initialized
DEBUG - 2023-05-25 10:24:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:24:47 --> Database Driver Class Initialized
INFO - 2023-05-25 10:24:47 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:24:47 --> Database Driver Class Initialized
INFO - 2023-05-25 10:24:47 --> Model "Login_model" initialized
INFO - 2023-05-25 10:24:48 --> Config Class Initialized
INFO - 2023-05-25 10:24:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:24:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:24:48 --> Utf8 Class Initialized
INFO - 2023-05-25 10:24:48 --> URI Class Initialized
INFO - 2023-05-25 10:24:49 --> Router Class Initialized
INFO - 2023-05-25 10:24:49 --> Output Class Initialized
INFO - 2023-05-25 10:24:49 --> Security Class Initialized
DEBUG - 2023-05-25 10:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:24:49 --> Input Class Initialized
INFO - 2023-05-25 10:24:49 --> Language Class Initialized
INFO - 2023-05-25 10:24:49 --> Loader Class Initialized
INFO - 2023-05-25 10:24:49 --> Controller Class Initialized
DEBUG - 2023-05-25 10:24:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:24:49 --> Database Driver Class Initialized
INFO - 2023-05-25 10:24:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:24:49 --> Final output sent to browser
DEBUG - 2023-05-25 10:24:49 --> Total execution time: 0.2294
INFO - 2023-05-25 10:24:49 --> Config Class Initialized
INFO - 2023-05-25 10:24:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:24:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:24:49 --> Utf8 Class Initialized
INFO - 2023-05-25 10:24:49 --> URI Class Initialized
INFO - 2023-05-25 10:24:49 --> Router Class Initialized
INFO - 2023-05-25 10:24:49 --> Output Class Initialized
INFO - 2023-05-25 10:24:49 --> Security Class Initialized
DEBUG - 2023-05-25 10:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:24:49 --> Input Class Initialized
INFO - 2023-05-25 10:24:49 --> Language Class Initialized
INFO - 2023-05-25 10:24:49 --> Loader Class Initialized
INFO - 2023-05-25 10:24:49 --> Controller Class Initialized
DEBUG - 2023-05-25 10:24:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:24:49 --> Database Driver Class Initialized
INFO - 2023-05-25 10:24:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:24:49 --> Final output sent to browser
DEBUG - 2023-05-25 10:24:49 --> Total execution time: 0.2540
INFO - 2023-05-25 10:24:57 --> Final output sent to browser
DEBUG - 2023-05-25 10:24:57 --> Total execution time: 9.9969
INFO - 2023-05-25 10:24:57 --> Config Class Initialized
INFO - 2023-05-25 10:24:57 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:24:57 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:24:57 --> Utf8 Class Initialized
INFO - 2023-05-25 10:24:57 --> URI Class Initialized
INFO - 2023-05-25 10:24:57 --> Router Class Initialized
INFO - 2023-05-25 10:24:57 --> Output Class Initialized
INFO - 2023-05-25 10:24:57 --> Security Class Initialized
DEBUG - 2023-05-25 10:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:24:57 --> Input Class Initialized
INFO - 2023-05-25 10:24:57 --> Language Class Initialized
INFO - 2023-05-25 10:24:57 --> Loader Class Initialized
INFO - 2023-05-25 10:24:57 --> Controller Class Initialized
DEBUG - 2023-05-25 10:24:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:24:57 --> Database Driver Class Initialized
INFO - 2023-05-25 10:24:57 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:24:57 --> Database Driver Class Initialized
INFO - 2023-05-25 10:24:57 --> Model "Login_model" initialized
INFO - 2023-05-25 10:25:05 --> Final output sent to browser
DEBUG - 2023-05-25 10:25:05 --> Total execution time: 8.0441
INFO - 2023-05-25 10:25:42 --> Config Class Initialized
INFO - 2023-05-25 10:25:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:25:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:25:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:25:42 --> URI Class Initialized
INFO - 2023-05-25 10:25:42 --> Router Class Initialized
INFO - 2023-05-25 10:25:42 --> Output Class Initialized
INFO - 2023-05-25 10:25:42 --> Security Class Initialized
DEBUG - 2023-05-25 10:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:25:42 --> Input Class Initialized
INFO - 2023-05-25 10:25:42 --> Language Class Initialized
INFO - 2023-05-25 10:25:42 --> Loader Class Initialized
INFO - 2023-05-25 10:25:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:25:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:25:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:25:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:25:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:25:42 --> Total execution time: 0.2544
INFO - 2023-05-25 10:25:42 --> Config Class Initialized
INFO - 2023-05-25 10:25:42 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:25:42 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:25:42 --> Utf8 Class Initialized
INFO - 2023-05-25 10:25:42 --> URI Class Initialized
INFO - 2023-05-25 10:25:42 --> Router Class Initialized
INFO - 2023-05-25 10:25:42 --> Output Class Initialized
INFO - 2023-05-25 10:25:42 --> Security Class Initialized
DEBUG - 2023-05-25 10:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:25:42 --> Input Class Initialized
INFO - 2023-05-25 10:25:42 --> Language Class Initialized
INFO - 2023-05-25 10:25:42 --> Loader Class Initialized
INFO - 2023-05-25 10:25:42 --> Controller Class Initialized
DEBUG - 2023-05-25 10:25:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:25:42 --> Database Driver Class Initialized
INFO - 2023-05-25 10:25:42 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:25:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:25:42 --> Total execution time: 0.2553
INFO - 2023-05-25 10:25:43 --> Config Class Initialized
INFO - 2023-05-25 10:25:43 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:25:43 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:25:43 --> Utf8 Class Initialized
INFO - 2023-05-25 10:25:43 --> URI Class Initialized
INFO - 2023-05-25 10:25:43 --> Router Class Initialized
INFO - 2023-05-25 10:25:43 --> Output Class Initialized
INFO - 2023-05-25 10:25:43 --> Security Class Initialized
DEBUG - 2023-05-25 10:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:25:43 --> Input Class Initialized
INFO - 2023-05-25 10:25:43 --> Language Class Initialized
INFO - 2023-05-25 10:25:43 --> Loader Class Initialized
INFO - 2023-05-25 10:25:43 --> Controller Class Initialized
DEBUG - 2023-05-25 10:25:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:25:43 --> Database Driver Class Initialized
INFO - 2023-05-25 10:25:43 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:25:43 --> Database Driver Class Initialized
INFO - 2023-05-25 10:25:43 --> Model "Login_model" initialized
INFO - 2023-05-25 10:25:51 --> Final output sent to browser
DEBUG - 2023-05-25 10:25:51 --> Total execution time: 8.2701
INFO - 2023-05-25 10:25:51 --> Config Class Initialized
INFO - 2023-05-25 10:25:51 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:25:51 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:25:51 --> Utf8 Class Initialized
INFO - 2023-05-25 10:25:51 --> URI Class Initialized
INFO - 2023-05-25 10:25:51 --> Router Class Initialized
INFO - 2023-05-25 10:25:51 --> Output Class Initialized
INFO - 2023-05-25 10:25:51 --> Security Class Initialized
DEBUG - 2023-05-25 10:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:25:51 --> Input Class Initialized
INFO - 2023-05-25 10:25:51 --> Language Class Initialized
INFO - 2023-05-25 10:25:51 --> Loader Class Initialized
INFO - 2023-05-25 10:25:51 --> Controller Class Initialized
DEBUG - 2023-05-25 10:25:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:25:51 --> Database Driver Class Initialized
INFO - 2023-05-25 10:25:51 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:25:51 --> Database Driver Class Initialized
INFO - 2023-05-25 10:25:51 --> Model "Login_model" initialized
INFO - 2023-05-25 10:26:02 --> Final output sent to browser
DEBUG - 2023-05-25 10:26:02 --> Total execution time: 10.5919
INFO - 2023-05-25 10:27:39 --> Config Class Initialized
INFO - 2023-05-25 10:27:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:27:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:27:39 --> Utf8 Class Initialized
INFO - 2023-05-25 10:27:39 --> URI Class Initialized
INFO - 2023-05-25 10:27:39 --> Router Class Initialized
INFO - 2023-05-25 10:27:39 --> Output Class Initialized
INFO - 2023-05-25 10:27:39 --> Security Class Initialized
DEBUG - 2023-05-25 10:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:27:39 --> Input Class Initialized
INFO - 2023-05-25 10:27:39 --> Language Class Initialized
INFO - 2023-05-25 10:27:39 --> Loader Class Initialized
INFO - 2023-05-25 10:27:39 --> Controller Class Initialized
DEBUG - 2023-05-25 10:27:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:27:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:27:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:27:39 --> Final output sent to browser
DEBUG - 2023-05-25 10:27:39 --> Total execution time: 0.2299
INFO - 2023-05-25 10:27:39 --> Config Class Initialized
INFO - 2023-05-25 10:27:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:27:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:27:39 --> Utf8 Class Initialized
INFO - 2023-05-25 10:27:39 --> URI Class Initialized
INFO - 2023-05-25 10:27:39 --> Router Class Initialized
INFO - 2023-05-25 10:27:39 --> Output Class Initialized
INFO - 2023-05-25 10:27:39 --> Security Class Initialized
DEBUG - 2023-05-25 10:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:27:39 --> Input Class Initialized
INFO - 2023-05-25 10:27:39 --> Language Class Initialized
INFO - 2023-05-25 10:27:39 --> Loader Class Initialized
INFO - 2023-05-25 10:27:39 --> Controller Class Initialized
DEBUG - 2023-05-25 10:27:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:27:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:27:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:27:39 --> Final output sent to browser
DEBUG - 2023-05-25 10:27:39 --> Total execution time: 0.2641
INFO - 2023-05-25 10:28:39 --> Config Class Initialized
INFO - 2023-05-25 10:28:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:28:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:28:39 --> Utf8 Class Initialized
INFO - 2023-05-25 10:28:39 --> URI Class Initialized
INFO - 2023-05-25 10:28:39 --> Router Class Initialized
INFO - 2023-05-25 10:28:39 --> Output Class Initialized
INFO - 2023-05-25 10:28:39 --> Security Class Initialized
DEBUG - 2023-05-25 10:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:28:39 --> Input Class Initialized
INFO - 2023-05-25 10:28:39 --> Language Class Initialized
INFO - 2023-05-25 10:28:39 --> Loader Class Initialized
INFO - 2023-05-25 10:28:39 --> Controller Class Initialized
DEBUG - 2023-05-25 10:28:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:28:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:28:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:28:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:28:39 --> Model "Login_model" initialized
INFO - 2023-05-25 10:28:49 --> Final output sent to browser
DEBUG - 2023-05-25 10:28:49 --> Total execution time: 10.5767
INFO - 2023-05-25 10:28:49 --> Config Class Initialized
INFO - 2023-05-25 10:28:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:28:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:28:49 --> Utf8 Class Initialized
INFO - 2023-05-25 10:28:49 --> URI Class Initialized
INFO - 2023-05-25 10:28:49 --> Router Class Initialized
INFO - 2023-05-25 10:28:49 --> Output Class Initialized
INFO - 2023-05-25 10:28:49 --> Security Class Initialized
DEBUG - 2023-05-25 10:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:28:49 --> Input Class Initialized
INFO - 2023-05-25 10:28:49 --> Language Class Initialized
INFO - 2023-05-25 10:28:49 --> Loader Class Initialized
INFO - 2023-05-25 10:28:49 --> Controller Class Initialized
DEBUG - 2023-05-25 10:28:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:28:49 --> Database Driver Class Initialized
INFO - 2023-05-25 10:28:50 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:28:50 --> Database Driver Class Initialized
INFO - 2023-05-25 10:28:50 --> Model "Login_model" initialized
INFO - 2023-05-25 10:28:59 --> Final output sent to browser
DEBUG - 2023-05-25 10:28:59 --> Total execution time: 10.0193
INFO - 2023-05-25 10:29:39 --> Config Class Initialized
INFO - 2023-05-25 10:29:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:29:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:29:39 --> Utf8 Class Initialized
INFO - 2023-05-25 10:29:39 --> URI Class Initialized
INFO - 2023-05-25 10:29:39 --> Router Class Initialized
INFO - 2023-05-25 10:29:39 --> Output Class Initialized
INFO - 2023-05-25 10:29:39 --> Security Class Initialized
DEBUG - 2023-05-25 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:29:39 --> Input Class Initialized
INFO - 2023-05-25 10:29:39 --> Language Class Initialized
INFO - 2023-05-25 10:29:39 --> Loader Class Initialized
INFO - 2023-05-25 10:29:39 --> Controller Class Initialized
DEBUG - 2023-05-25 10:29:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:29:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:29:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:29:49 --> Final output sent to browser
DEBUG - 2023-05-25 10:29:49 --> Total execution time: 10.6183
INFO - 2023-05-25 10:29:49 --> Config Class Initialized
INFO - 2023-05-25 10:29:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:29:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:29:49 --> Utf8 Class Initialized
INFO - 2023-05-25 10:29:49 --> URI Class Initialized
INFO - 2023-05-25 10:29:49 --> Router Class Initialized
INFO - 2023-05-25 10:29:49 --> Output Class Initialized
INFO - 2023-05-25 10:29:49 --> Security Class Initialized
DEBUG - 2023-05-25 10:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:29:49 --> Input Class Initialized
INFO - 2023-05-25 10:29:49 --> Language Class Initialized
INFO - 2023-05-25 10:29:49 --> Loader Class Initialized
INFO - 2023-05-25 10:29:49 --> Controller Class Initialized
DEBUG - 2023-05-25 10:29:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:29:49 --> Database Driver Class Initialized
INFO - 2023-05-25 10:29:50 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:30:01 --> Final output sent to browser
DEBUG - 2023-05-25 10:30:01 --> Total execution time: 11.9684
INFO - 2023-05-25 10:30:39 --> Config Class Initialized
INFO - 2023-05-25 10:30:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:30:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:30:39 --> Utf8 Class Initialized
INFO - 2023-05-25 10:30:39 --> URI Class Initialized
INFO - 2023-05-25 10:30:39 --> Router Class Initialized
INFO - 2023-05-25 10:30:39 --> Output Class Initialized
INFO - 2023-05-25 10:30:39 --> Security Class Initialized
DEBUG - 2023-05-25 10:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:30:39 --> Input Class Initialized
INFO - 2023-05-25 10:30:39 --> Language Class Initialized
INFO - 2023-05-25 10:30:39 --> Loader Class Initialized
INFO - 2023-05-25 10:30:39 --> Controller Class Initialized
DEBUG - 2023-05-25 10:30:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:30:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:30:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:30:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:30:39 --> Model "Login_model" initialized
INFO - 2023-05-25 10:30:48 --> Final output sent to browser
DEBUG - 2023-05-25 10:30:48 --> Total execution time: 9.3026
INFO - 2023-05-25 10:30:48 --> Config Class Initialized
INFO - 2023-05-25 10:30:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:30:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:30:48 --> Utf8 Class Initialized
INFO - 2023-05-25 10:30:48 --> URI Class Initialized
INFO - 2023-05-25 10:30:48 --> Router Class Initialized
INFO - 2023-05-25 10:30:48 --> Output Class Initialized
INFO - 2023-05-25 10:30:48 --> Security Class Initialized
DEBUG - 2023-05-25 10:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:30:48 --> Input Class Initialized
INFO - 2023-05-25 10:30:48 --> Language Class Initialized
INFO - 2023-05-25 10:30:48 --> Loader Class Initialized
INFO - 2023-05-25 10:30:48 --> Controller Class Initialized
DEBUG - 2023-05-25 10:30:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:30:48 --> Database Driver Class Initialized
INFO - 2023-05-25 10:30:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:30:48 --> Database Driver Class Initialized
INFO - 2023-05-25 10:30:48 --> Model "Login_model" initialized
INFO - 2023-05-25 10:30:58 --> Final output sent to browser
DEBUG - 2023-05-25 10:30:58 --> Total execution time: 10.0150
INFO - 2023-05-25 10:31:39 --> Config Class Initialized
INFO - 2023-05-25 10:31:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:31:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:31:39 --> Utf8 Class Initialized
INFO - 2023-05-25 10:31:39 --> URI Class Initialized
INFO - 2023-05-25 10:31:39 --> Router Class Initialized
INFO - 2023-05-25 10:31:39 --> Output Class Initialized
INFO - 2023-05-25 10:31:39 --> Security Class Initialized
DEBUG - 2023-05-25 10:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:31:39 --> Input Class Initialized
INFO - 2023-05-25 10:31:39 --> Language Class Initialized
INFO - 2023-05-25 10:31:39 --> Loader Class Initialized
INFO - 2023-05-25 10:31:39 --> Controller Class Initialized
DEBUG - 2023-05-25 10:31:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:31:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:31:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:31:39 --> Final output sent to browser
DEBUG - 2023-05-25 10:31:39 --> Total execution time: 0.2737
INFO - 2023-05-25 10:31:39 --> Config Class Initialized
INFO - 2023-05-25 10:31:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:31:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:31:39 --> Utf8 Class Initialized
INFO - 2023-05-25 10:31:39 --> URI Class Initialized
INFO - 2023-05-25 10:31:39 --> Router Class Initialized
INFO - 2023-05-25 10:31:39 --> Output Class Initialized
INFO - 2023-05-25 10:31:39 --> Security Class Initialized
DEBUG - 2023-05-25 10:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:31:39 --> Input Class Initialized
INFO - 2023-05-25 10:31:39 --> Language Class Initialized
INFO - 2023-05-25 10:31:39 --> Loader Class Initialized
INFO - 2023-05-25 10:31:39 --> Controller Class Initialized
DEBUG - 2023-05-25 10:31:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:31:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:31:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:31:40 --> Final output sent to browser
DEBUG - 2023-05-25 10:31:40 --> Total execution time: 0.5127
INFO - 2023-05-25 10:32:40 --> Config Class Initialized
INFO - 2023-05-25 10:32:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:32:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:32:40 --> Utf8 Class Initialized
INFO - 2023-05-25 10:32:40 --> URI Class Initialized
INFO - 2023-05-25 10:32:40 --> Router Class Initialized
INFO - 2023-05-25 10:32:40 --> Output Class Initialized
INFO - 2023-05-25 10:32:40 --> Security Class Initialized
DEBUG - 2023-05-25 10:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:32:40 --> Input Class Initialized
INFO - 2023-05-25 10:32:40 --> Language Class Initialized
INFO - 2023-05-25 10:32:40 --> Loader Class Initialized
INFO - 2023-05-25 10:32:40 --> Controller Class Initialized
DEBUG - 2023-05-25 10:32:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:32:40 --> Database Driver Class Initialized
INFO - 2023-05-25 10:32:41 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:32:41 --> Database Driver Class Initialized
INFO - 2023-05-25 10:32:41 --> Model "Login_model" initialized
INFO - 2023-05-25 10:32:47 --> Final output sent to browser
DEBUG - 2023-05-25 10:32:47 --> Total execution time: 7.4073
INFO - 2023-05-25 10:32:47 --> Config Class Initialized
INFO - 2023-05-25 10:32:47 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:32:47 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:32:47 --> Utf8 Class Initialized
INFO - 2023-05-25 10:32:47 --> URI Class Initialized
INFO - 2023-05-25 10:32:47 --> Router Class Initialized
INFO - 2023-05-25 10:32:47 --> Output Class Initialized
INFO - 2023-05-25 10:32:47 --> Security Class Initialized
DEBUG - 2023-05-25 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:32:47 --> Input Class Initialized
INFO - 2023-05-25 10:32:47 --> Language Class Initialized
INFO - 2023-05-25 10:32:47 --> Loader Class Initialized
INFO - 2023-05-25 10:32:47 --> Controller Class Initialized
DEBUG - 2023-05-25 10:32:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:32:47 --> Database Driver Class Initialized
INFO - 2023-05-25 10:32:47 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:32:47 --> Database Driver Class Initialized
INFO - 2023-05-25 10:32:47 --> Model "Login_model" initialized
INFO - 2023-05-25 10:32:56 --> Final output sent to browser
DEBUG - 2023-05-25 10:32:56 --> Total execution time: 9.3070
INFO - 2023-05-25 10:33:39 --> Config Class Initialized
INFO - 2023-05-25 10:33:39 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:33:39 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:33:39 --> Utf8 Class Initialized
INFO - 2023-05-25 10:33:39 --> URI Class Initialized
INFO - 2023-05-25 10:33:39 --> Router Class Initialized
INFO - 2023-05-25 10:33:39 --> Output Class Initialized
INFO - 2023-05-25 10:33:39 --> Security Class Initialized
DEBUG - 2023-05-25 10:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:33:39 --> Input Class Initialized
INFO - 2023-05-25 10:33:39 --> Language Class Initialized
INFO - 2023-05-25 10:33:39 --> Loader Class Initialized
INFO - 2023-05-25 10:33:39 --> Controller Class Initialized
DEBUG - 2023-05-25 10:33:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:33:39 --> Database Driver Class Initialized
INFO - 2023-05-25 10:33:39 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:33:39 --> Final output sent to browser
DEBUG - 2023-05-25 10:33:39 --> Total execution time: 0.8066
INFO - 2023-05-25 10:33:40 --> Config Class Initialized
INFO - 2023-05-25 10:33:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:33:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:33:40 --> Utf8 Class Initialized
INFO - 2023-05-25 10:33:40 --> URI Class Initialized
INFO - 2023-05-25 10:33:40 --> Router Class Initialized
INFO - 2023-05-25 10:33:40 --> Output Class Initialized
INFO - 2023-05-25 10:33:40 --> Security Class Initialized
DEBUG - 2023-05-25 10:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:33:40 --> Input Class Initialized
INFO - 2023-05-25 10:33:40 --> Language Class Initialized
INFO - 2023-05-25 10:33:40 --> Loader Class Initialized
INFO - 2023-05-25 10:33:40 --> Controller Class Initialized
DEBUG - 2023-05-25 10:33:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:33:40 --> Database Driver Class Initialized
INFO - 2023-05-25 10:33:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:33:42 --> Final output sent to browser
DEBUG - 2023-05-25 10:33:42 --> Total execution time: 2.1610
INFO - 2023-05-25 10:34:16 --> Config Class Initialized
INFO - 2023-05-25 10:34:16 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:16 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:16 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:16 --> URI Class Initialized
INFO - 2023-05-25 10:34:16 --> Router Class Initialized
INFO - 2023-05-25 10:34:16 --> Output Class Initialized
INFO - 2023-05-25 10:34:16 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:16 --> Input Class Initialized
INFO - 2023-05-25 10:34:16 --> Language Class Initialized
INFO - 2023-05-25 10:34:16 --> Loader Class Initialized
INFO - 2023-05-25 10:34:16 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:16 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:16 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:34:16 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:16 --> Model "Login_model" initialized
INFO - 2023-05-25 10:34:18 --> Config Class Initialized
INFO - 2023-05-25 10:34:18 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:18 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:18 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:18 --> URI Class Initialized
INFO - 2023-05-25 10:34:18 --> Router Class Initialized
INFO - 2023-05-25 10:34:18 --> Output Class Initialized
INFO - 2023-05-25 10:34:18 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:18 --> Input Class Initialized
INFO - 2023-05-25 10:34:18 --> Language Class Initialized
INFO - 2023-05-25 10:34:18 --> Loader Class Initialized
INFO - 2023-05-25 10:34:18 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:18 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:18 --> Model "Login_model" initialized
INFO - 2023-05-25 10:34:18 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:18 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:34:18 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:18 --> Total execution time: 0.5534
INFO - 2023-05-25 10:34:18 --> Config Class Initialized
INFO - 2023-05-25 10:34:18 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:18 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:18 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:18 --> URI Class Initialized
INFO - 2023-05-25 10:34:18 --> Router Class Initialized
INFO - 2023-05-25 10:34:18 --> Output Class Initialized
INFO - 2023-05-25 10:34:18 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:18 --> Input Class Initialized
INFO - 2023-05-25 10:34:18 --> Language Class Initialized
INFO - 2023-05-25 10:34:18 --> Loader Class Initialized
INFO - 2023-05-25 10:34:18 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:18 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:18 --> Model "Login_model" initialized
INFO - 2023-05-25 10:34:18 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:18 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:34:18 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:18 --> Total execution time: 0.3006
INFO - 2023-05-25 10:34:18 --> Config Class Initialized
INFO - 2023-05-25 10:34:18 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:19 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:19 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:19 --> URI Class Initialized
INFO - 2023-05-25 10:34:19 --> Router Class Initialized
INFO - 2023-05-25 10:34:19 --> Output Class Initialized
INFO - 2023-05-25 10:34:19 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:19 --> Input Class Initialized
INFO - 2023-05-25 10:34:19 --> Language Class Initialized
INFO - 2023-05-25 10:34:19 --> Loader Class Initialized
INFO - 2023-05-25 10:34:19 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:19 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:19 --> Total execution time: 0.1986
INFO - 2023-05-25 10:34:19 --> Config Class Initialized
INFO - 2023-05-25 10:34:19 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:19 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:19 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:19 --> URI Class Initialized
INFO - 2023-05-25 10:34:19 --> Router Class Initialized
INFO - 2023-05-25 10:34:19 --> Output Class Initialized
INFO - 2023-05-25 10:34:19 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:19 --> Input Class Initialized
INFO - 2023-05-25 10:34:19 --> Language Class Initialized
INFO - 2023-05-25 10:34:19 --> Loader Class Initialized
INFO - 2023-05-25 10:34:19 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:19 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:19 --> Model "Login_model" initialized
INFO - 2023-05-25 10:34:19 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:19 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:34:19 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:19 --> Total execution time: 0.3063
INFO - 2023-05-25 10:34:23 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:23 --> Total execution time: 7.2909
INFO - 2023-05-25 10:34:23 --> Config Class Initialized
INFO - 2023-05-25 10:34:23 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:23 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:23 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:23 --> URI Class Initialized
INFO - 2023-05-25 10:34:23 --> Router Class Initialized
INFO - 2023-05-25 10:34:23 --> Output Class Initialized
INFO - 2023-05-25 10:34:23 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:23 --> Input Class Initialized
INFO - 2023-05-25 10:34:23 --> Language Class Initialized
INFO - 2023-05-25 10:34:23 --> Loader Class Initialized
INFO - 2023-05-25 10:34:23 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:23 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:23 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:34:23 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:23 --> Model "Login_model" initialized
INFO - 2023-05-25 10:34:34 --> Config Class Initialized
INFO - 2023-05-25 10:34:34 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:34 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:34 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:34 --> URI Class Initialized
INFO - 2023-05-25 10:34:34 --> Router Class Initialized
INFO - 2023-05-25 10:34:34 --> Output Class Initialized
INFO - 2023-05-25 10:34:34 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:34 --> Input Class Initialized
INFO - 2023-05-25 10:34:34 --> Language Class Initialized
INFO - 2023-05-25 10:34:34 --> Loader Class Initialized
INFO - 2023-05-25 10:34:34 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:34 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:34 --> Model "Login_model" initialized
INFO - 2023-05-25 10:34:34 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:34 --> Total execution time: 0.2122
INFO - 2023-05-25 10:34:34 --> Config Class Initialized
INFO - 2023-05-25 10:34:34 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:34 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:34 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:34 --> URI Class Initialized
INFO - 2023-05-25 10:34:34 --> Router Class Initialized
INFO - 2023-05-25 10:34:34 --> Output Class Initialized
INFO - 2023-05-25 10:34:34 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:34 --> Input Class Initialized
INFO - 2023-05-25 10:34:34 --> Language Class Initialized
INFO - 2023-05-25 10:34:34 --> Loader Class Initialized
INFO - 2023-05-25 10:34:34 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:34 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:34 --> Model "Login_model" initialized
INFO - 2023-05-25 10:34:34 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:34 --> Total execution time: 0.2056
INFO - 2023-05-25 10:34:34 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:34 --> Total execution time: 11.0163
INFO - 2023-05-25 10:34:37 --> Config Class Initialized
INFO - 2023-05-25 10:34:37 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:37 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:37 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:37 --> URI Class Initialized
INFO - 2023-05-25 10:34:37 --> Router Class Initialized
INFO - 2023-05-25 10:34:37 --> Output Class Initialized
INFO - 2023-05-25 10:34:37 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:37 --> Input Class Initialized
INFO - 2023-05-25 10:34:37 --> Language Class Initialized
INFO - 2023-05-25 10:34:37 --> Loader Class Initialized
INFO - 2023-05-25 10:34:37 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:37 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:37 --> Total execution time: 0.1255
INFO - 2023-05-25 10:34:37 --> Config Class Initialized
INFO - 2023-05-25 10:34:37 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:37 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:37 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:37 --> URI Class Initialized
INFO - 2023-05-25 10:34:37 --> Router Class Initialized
INFO - 2023-05-25 10:34:37 --> Output Class Initialized
INFO - 2023-05-25 10:34:37 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:37 --> Input Class Initialized
INFO - 2023-05-25 10:34:37 --> Language Class Initialized
INFO - 2023-05-25 10:34:37 --> Loader Class Initialized
INFO - 2023-05-25 10:34:37 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:37 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:37 --> Model "Login_model" initialized
INFO - 2023-05-25 10:34:37 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:37 --> Total execution time: 0.1749
INFO - 2023-05-25 10:34:37 --> Config Class Initialized
INFO - 2023-05-25 10:34:37 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:38 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:38 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:38 --> URI Class Initialized
INFO - 2023-05-25 10:34:38 --> Router Class Initialized
INFO - 2023-05-25 10:34:38 --> Output Class Initialized
INFO - 2023-05-25 10:34:38 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:38 --> Input Class Initialized
INFO - 2023-05-25 10:34:38 --> Language Class Initialized
INFO - 2023-05-25 10:34:38 --> Loader Class Initialized
INFO - 2023-05-25 10:34:38 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:38 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:38 --> Total execution time: 0.1628
INFO - 2023-05-25 10:34:38 --> Config Class Initialized
INFO - 2023-05-25 10:34:38 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:38 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:38 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:38 --> URI Class Initialized
INFO - 2023-05-25 10:34:38 --> Router Class Initialized
INFO - 2023-05-25 10:34:38 --> Output Class Initialized
INFO - 2023-05-25 10:34:38 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:38 --> Input Class Initialized
INFO - 2023-05-25 10:34:38 --> Language Class Initialized
INFO - 2023-05-25 10:34:38 --> Loader Class Initialized
INFO - 2023-05-25 10:34:38 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:38 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:38 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:34:38 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:38 --> Total execution time: 0.2332
INFO - 2023-05-25 10:34:40 --> Config Class Initialized
INFO - 2023-05-25 10:34:40 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:40 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:40 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:40 --> URI Class Initialized
INFO - 2023-05-25 10:34:40 --> Router Class Initialized
INFO - 2023-05-25 10:34:40 --> Output Class Initialized
INFO - 2023-05-25 10:34:40 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:40 --> Input Class Initialized
INFO - 2023-05-25 10:34:40 --> Language Class Initialized
INFO - 2023-05-25 10:34:40 --> Loader Class Initialized
INFO - 2023-05-25 10:34:40 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:40 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:40 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:34:40 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:40 --> Total execution time: 0.2233
INFO - 2023-05-25 10:34:43 --> Config Class Initialized
INFO - 2023-05-25 10:34:43 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:43 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:43 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:43 --> URI Class Initialized
INFO - 2023-05-25 10:34:43 --> Router Class Initialized
INFO - 2023-05-25 10:34:43 --> Output Class Initialized
INFO - 2023-05-25 10:34:43 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:43 --> Input Class Initialized
INFO - 2023-05-25 10:34:43 --> Language Class Initialized
INFO - 2023-05-25 10:34:43 --> Loader Class Initialized
INFO - 2023-05-25 10:34:43 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:43 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:43 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:34:43 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:43 --> Total execution time: 0.1950
INFO - 2023-05-25 10:34:43 --> Config Class Initialized
INFO - 2023-05-25 10:34:43 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:43 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:43 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:43 --> URI Class Initialized
INFO - 2023-05-25 10:34:43 --> Router Class Initialized
INFO - 2023-05-25 10:34:43 --> Output Class Initialized
INFO - 2023-05-25 10:34:43 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:43 --> Input Class Initialized
INFO - 2023-05-25 10:34:43 --> Language Class Initialized
INFO - 2023-05-25 10:34:43 --> Loader Class Initialized
INFO - 2023-05-25 10:34:43 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:43 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:43 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:34:43 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:43 --> Total execution time: 0.2161
INFO - 2023-05-25 10:34:43 --> Config Class Initialized
INFO - 2023-05-25 10:34:43 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:43 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:43 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:43 --> URI Class Initialized
INFO - 2023-05-25 10:34:43 --> Router Class Initialized
INFO - 2023-05-25 10:34:43 --> Output Class Initialized
INFO - 2023-05-25 10:34:43 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:43 --> Input Class Initialized
INFO - 2023-05-25 10:34:43 --> Language Class Initialized
INFO - 2023-05-25 10:34:43 --> Loader Class Initialized
INFO - 2023-05-25 10:34:43 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:43 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:43 --> Total execution time: 0.1317
INFO - 2023-05-25 10:34:43 --> Config Class Initialized
INFO - 2023-05-25 10:34:43 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:43 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:43 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:43 --> URI Class Initialized
INFO - 2023-05-25 10:34:43 --> Router Class Initialized
INFO - 2023-05-25 10:34:43 --> Output Class Initialized
INFO - 2023-05-25 10:34:43 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:43 --> Input Class Initialized
INFO - 2023-05-25 10:34:43 --> Language Class Initialized
INFO - 2023-05-25 10:34:43 --> Loader Class Initialized
INFO - 2023-05-25 10:34:43 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:43 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:43 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:34:43 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:43 --> Total execution time: 0.1812
INFO - 2023-05-25 10:34:48 --> Config Class Initialized
INFO - 2023-05-25 10:34:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:48 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:48 --> URI Class Initialized
INFO - 2023-05-25 10:34:48 --> Router Class Initialized
INFO - 2023-05-25 10:34:48 --> Output Class Initialized
INFO - 2023-05-25 10:34:48 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:48 --> Input Class Initialized
INFO - 2023-05-25 10:34:48 --> Language Class Initialized
INFO - 2023-05-25 10:34:48 --> Loader Class Initialized
INFO - 2023-05-25 10:34:48 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:48 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:48 --> Model "Login_model" initialized
INFO - 2023-05-25 10:34:48 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:34:48 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:48 --> Total execution time: 0.2409
INFO - 2023-05-25 10:34:48 --> Config Class Initialized
INFO - 2023-05-25 10:34:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:48 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:48 --> URI Class Initialized
INFO - 2023-05-25 10:34:48 --> Router Class Initialized
INFO - 2023-05-25 10:34:48 --> Output Class Initialized
INFO - 2023-05-25 10:34:48 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:48 --> Input Class Initialized
INFO - 2023-05-25 10:34:48 --> Language Class Initialized
INFO - 2023-05-25 10:34:48 --> Loader Class Initialized
INFO - 2023-05-25 10:34:48 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:48 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:48 --> Model "Login_model" initialized
INFO - 2023-05-25 10:34:48 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:48 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:34:48 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:48 --> Total execution time: 0.2088
INFO - 2023-05-25 10:34:48 --> Config Class Initialized
INFO - 2023-05-25 10:34:48 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:48 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:48 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:48 --> URI Class Initialized
INFO - 2023-05-25 10:34:48 --> Router Class Initialized
INFO - 2023-05-25 10:34:48 --> Output Class Initialized
INFO - 2023-05-25 10:34:48 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:49 --> Input Class Initialized
INFO - 2023-05-25 10:34:49 --> Language Class Initialized
INFO - 2023-05-25 10:34:49 --> Loader Class Initialized
INFO - 2023-05-25 10:34:49 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:49 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:49 --> Total execution time: 0.1365
INFO - 2023-05-25 10:34:49 --> Config Class Initialized
INFO - 2023-05-25 10:34:49 --> Hooks Class Initialized
DEBUG - 2023-05-25 10:34:49 --> UTF-8 Support Enabled
INFO - 2023-05-25 10:34:49 --> Utf8 Class Initialized
INFO - 2023-05-25 10:34:49 --> URI Class Initialized
INFO - 2023-05-25 10:34:49 --> Router Class Initialized
INFO - 2023-05-25 10:34:49 --> Output Class Initialized
INFO - 2023-05-25 10:34:49 --> Security Class Initialized
DEBUG - 2023-05-25 10:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-25 10:34:49 --> Input Class Initialized
INFO - 2023-05-25 10:34:49 --> Language Class Initialized
INFO - 2023-05-25 10:34:49 --> Loader Class Initialized
INFO - 2023-05-25 10:34:49 --> Controller Class Initialized
DEBUG - 2023-05-25 10:34:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-25 10:34:49 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:49 --> Model "Login_model" initialized
INFO - 2023-05-25 10:34:49 --> Database Driver Class Initialized
INFO - 2023-05-25 10:34:49 --> Model "Cluster_model" initialized
INFO - 2023-05-25 10:34:49 --> Final output sent to browser
DEBUG - 2023-05-25 10:34:49 --> Total execution time: 0.2263
