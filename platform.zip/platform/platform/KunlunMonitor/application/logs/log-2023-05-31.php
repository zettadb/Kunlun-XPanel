<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-31 02:08:00 --> Config Class Initialized
INFO - 2023-05-31 02:08:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:00 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:00 --> URI Class Initialized
INFO - 2023-05-31 02:08:00 --> Router Class Initialized
INFO - 2023-05-31 02:08:00 --> Output Class Initialized
INFO - 2023-05-31 02:08:00 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:00 --> Input Class Initialized
INFO - 2023-05-31 02:08:00 --> Language Class Initialized
INFO - 2023-05-31 02:08:00 --> Loader Class Initialized
INFO - 2023-05-31 02:08:00 --> Controller Class Initialized
INFO - 2023-05-31 02:08:00 --> Helper loaded: form_helper
INFO - 2023-05-31 02:08:00 --> Helper loaded: url_helper
DEBUG - 2023-05-31 02:08:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:00 --> Model "Change_model" initialized
INFO - 2023-05-31 02:08:00 --> Model "Grafana_model" initialized
INFO - 2023-05-31 02:08:01 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:01 --> Total execution time: 0.3729
INFO - 2023-05-31 02:08:01 --> Config Class Initialized
INFO - 2023-05-31 02:08:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:01 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:01 --> URI Class Initialized
INFO - 2023-05-31 02:08:01 --> Router Class Initialized
INFO - 2023-05-31 02:08:01 --> Output Class Initialized
INFO - 2023-05-31 02:08:01 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:01 --> Input Class Initialized
INFO - 2023-05-31 02:08:01 --> Language Class Initialized
INFO - 2023-05-31 02:08:01 --> Loader Class Initialized
INFO - 2023-05-31 02:08:01 --> Controller Class Initialized
INFO - 2023-05-31 02:08:01 --> Helper loaded: form_helper
INFO - 2023-05-31 02:08:01 --> Helper loaded: url_helper
DEBUG - 2023-05-31 02:08:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:01 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:01 --> Total execution time: 0.1880
INFO - 2023-05-31 02:08:01 --> Config Class Initialized
INFO - 2023-05-31 02:08:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:01 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:01 --> URI Class Initialized
INFO - 2023-05-31 02:08:01 --> Router Class Initialized
INFO - 2023-05-31 02:08:01 --> Output Class Initialized
INFO - 2023-05-31 02:08:01 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:01 --> Input Class Initialized
INFO - 2023-05-31 02:08:01 --> Language Class Initialized
INFO - 2023-05-31 02:08:01 --> Loader Class Initialized
INFO - 2023-05-31 02:08:01 --> Controller Class Initialized
INFO - 2023-05-31 02:08:01 --> Helper loaded: form_helper
INFO - 2023-05-31 02:08:01 --> Helper loaded: url_helper
DEBUG - 2023-05-31 02:08:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:01 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:01 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:01 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:01 --> Total execution time: 0.3548
INFO - 2023-05-31 02:08:01 --> Config Class Initialized
INFO - 2023-05-31 02:08:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:01 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:01 --> URI Class Initialized
INFO - 2023-05-31 02:08:01 --> Router Class Initialized
INFO - 2023-05-31 02:08:01 --> Output Class Initialized
INFO - 2023-05-31 02:08:01 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:01 --> Input Class Initialized
INFO - 2023-05-31 02:08:01 --> Language Class Initialized
INFO - 2023-05-31 02:08:01 --> Loader Class Initialized
INFO - 2023-05-31 02:08:01 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:01 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:01 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:01 --> Total execution time: 0.2628
INFO - 2023-05-31 02:08:02 --> Config Class Initialized
INFO - 2023-05-31 02:08:02 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:02 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:02 --> URI Class Initialized
INFO - 2023-05-31 02:08:02 --> Router Class Initialized
INFO - 2023-05-31 02:08:02 --> Output Class Initialized
INFO - 2023-05-31 02:08:02 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:02 --> Input Class Initialized
INFO - 2023-05-31 02:08:02 --> Language Class Initialized
INFO - 2023-05-31 02:08:02 --> Loader Class Initialized
INFO - 2023-05-31 02:08:02 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:02 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:02 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:02 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:02 --> Total execution time: 0.1804
INFO - 2023-05-31 02:08:02 --> Config Class Initialized
INFO - 2023-05-31 02:08:02 --> Config Class Initialized
INFO - 2023-05-31 02:08:02 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:02 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:08:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:02 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:02 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:02 --> URI Class Initialized
INFO - 2023-05-31 02:08:02 --> URI Class Initialized
INFO - 2023-05-31 02:08:02 --> Router Class Initialized
INFO - 2023-05-31 02:08:02 --> Router Class Initialized
INFO - 2023-05-31 02:08:02 --> Output Class Initialized
INFO - 2023-05-31 02:08:02 --> Output Class Initialized
INFO - 2023-05-31 02:08:02 --> Security Class Initialized
INFO - 2023-05-31 02:08:02 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:02 --> Input Class Initialized
INFO - 2023-05-31 02:08:02 --> Input Class Initialized
INFO - 2023-05-31 02:08:02 --> Language Class Initialized
INFO - 2023-05-31 02:08:02 --> Language Class Initialized
INFO - 2023-05-31 02:08:02 --> Loader Class Initialized
INFO - 2023-05-31 02:08:02 --> Loader Class Initialized
INFO - 2023-05-31 02:08:02 --> Controller Class Initialized
INFO - 2023-05-31 02:08:02 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 02:08:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:02 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:02 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:02 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:02 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:02 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:02 --> Total execution time: 0.1784
INFO - 2023-05-31 02:08:02 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:02 --> Config Class Initialized
INFO - 2023-05-31 02:08:02 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:02 --> Model "Login_model" initialized
DEBUG - 2023-05-31 02:08:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:02 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:02 --> URI Class Initialized
INFO - 2023-05-31 02:08:02 --> Router Class Initialized
INFO - 2023-05-31 02:08:02 --> Output Class Initialized
INFO - 2023-05-31 02:08:02 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:02 --> Input Class Initialized
INFO - 2023-05-31 02:08:02 --> Language Class Initialized
INFO - 2023-05-31 02:08:02 --> Loader Class Initialized
INFO - 2023-05-31 02:08:02 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:02 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:02 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:02 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:02 --> Total execution time: 0.4320
INFO - 2023-05-31 02:08:02 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:02 --> Total execution time: 0.2260
INFO - 2023-05-31 02:08:02 --> Config Class Initialized
INFO - 2023-05-31 02:08:02 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:02 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:02 --> URI Class Initialized
INFO - 2023-05-31 02:08:02 --> Router Class Initialized
INFO - 2023-05-31 02:08:02 --> Output Class Initialized
INFO - 2023-05-31 02:08:02 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:02 --> Input Class Initialized
INFO - 2023-05-31 02:08:02 --> Language Class Initialized
INFO - 2023-05-31 02:08:02 --> Loader Class Initialized
INFO - 2023-05-31 02:08:02 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:02 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:03 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:03 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:03 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:03 --> Total execution time: 0.4055
INFO - 2023-05-31 02:08:09 --> Config Class Initialized
INFO - 2023-05-31 02:08:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:09 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:09 --> URI Class Initialized
INFO - 2023-05-31 02:08:09 --> Router Class Initialized
INFO - 2023-05-31 02:08:09 --> Output Class Initialized
INFO - 2023-05-31 02:08:09 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:09 --> Input Class Initialized
INFO - 2023-05-31 02:08:09 --> Language Class Initialized
INFO - 2023-05-31 02:08:10 --> Loader Class Initialized
INFO - 2023-05-31 02:08:10 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:10 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:10 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:10 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:10 --> Total execution time: 0.1871
INFO - 2023-05-31 02:08:10 --> Config Class Initialized
INFO - 2023-05-31 02:08:10 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:10 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:10 --> URI Class Initialized
INFO - 2023-05-31 02:08:10 --> Router Class Initialized
INFO - 2023-05-31 02:08:10 --> Output Class Initialized
INFO - 2023-05-31 02:08:10 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:10 --> Input Class Initialized
INFO - 2023-05-31 02:08:10 --> Language Class Initialized
INFO - 2023-05-31 02:08:10 --> Loader Class Initialized
INFO - 2023-05-31 02:08:10 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:10 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:10 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:10 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:10 --> Total execution time: 0.2048
INFO - 2023-05-31 02:08:11 --> Config Class Initialized
INFO - 2023-05-31 02:08:11 --> Config Class Initialized
INFO - 2023-05-31 02:08:11 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:11 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:08:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:11 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:11 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:11 --> URI Class Initialized
INFO - 2023-05-31 02:08:11 --> URI Class Initialized
INFO - 2023-05-31 02:08:11 --> Router Class Initialized
INFO - 2023-05-31 02:08:11 --> Router Class Initialized
INFO - 2023-05-31 02:08:11 --> Output Class Initialized
INFO - 2023-05-31 02:08:11 --> Output Class Initialized
INFO - 2023-05-31 02:08:11 --> Security Class Initialized
INFO - 2023-05-31 02:08:11 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:11 --> Input Class Initialized
INFO - 2023-05-31 02:08:11 --> Input Class Initialized
INFO - 2023-05-31 02:08:11 --> Language Class Initialized
INFO - 2023-05-31 02:08:11 --> Language Class Initialized
INFO - 2023-05-31 02:08:11 --> Loader Class Initialized
INFO - 2023-05-31 02:08:11 --> Loader Class Initialized
INFO - 2023-05-31 02:08:11 --> Controller Class Initialized
INFO - 2023-05-31 02:08:11 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 02:08:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:11 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:11 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:11 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:11 --> Total execution time: 0.5716
INFO - 2023-05-31 02:08:11 --> Config Class Initialized
INFO - 2023-05-31 02:08:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:11 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:11 --> URI Class Initialized
INFO - 2023-05-31 02:08:11 --> Router Class Initialized
INFO - 2023-05-31 02:08:11 --> Output Class Initialized
INFO - 2023-05-31 02:08:11 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:11 --> Input Class Initialized
INFO - 2023-05-31 02:08:11 --> Language Class Initialized
INFO - 2023-05-31 02:08:11 --> Loader Class Initialized
INFO - 2023-05-31 02:08:11 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:11 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:12 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:12 --> Total execution time: 0.9341
INFO - 2023-05-31 02:08:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:12 --> Config Class Initialized
INFO - 2023-05-31 02:08:12 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:12 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:12 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:12 --> URI Class Initialized
INFO - 2023-05-31 02:08:12 --> Router Class Initialized
INFO - 2023-05-31 02:08:12 --> Output Class Initialized
INFO - 2023-05-31 02:08:12 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:12 --> Input Class Initialized
INFO - 2023-05-31 02:08:12 --> Language Class Initialized
INFO - 2023-05-31 02:08:12 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:12 --> Total execution time: 0.4705
INFO - 2023-05-31 02:08:12 --> Loader Class Initialized
INFO - 2023-05-31 02:08:12 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:12 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:12 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:12 --> Total execution time: 0.6511
INFO - 2023-05-31 02:08:13 --> Config Class Initialized
INFO - 2023-05-31 02:08:13 --> Config Class Initialized
INFO - 2023-05-31 02:08:13 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:13 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:08:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:13 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:13 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:13 --> URI Class Initialized
INFO - 2023-05-31 02:08:13 --> URI Class Initialized
INFO - 2023-05-31 02:08:13 --> Router Class Initialized
INFO - 2023-05-31 02:08:13 --> Router Class Initialized
INFO - 2023-05-31 02:08:13 --> Output Class Initialized
INFO - 2023-05-31 02:08:13 --> Output Class Initialized
INFO - 2023-05-31 02:08:13 --> Security Class Initialized
INFO - 2023-05-31 02:08:13 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:13 --> Input Class Initialized
INFO - 2023-05-31 02:08:13 --> Input Class Initialized
INFO - 2023-05-31 02:08:14 --> Language Class Initialized
INFO - 2023-05-31 02:08:14 --> Language Class Initialized
INFO - 2023-05-31 02:08:14 --> Loader Class Initialized
INFO - 2023-05-31 02:08:14 --> Loader Class Initialized
INFO - 2023-05-31 02:08:14 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:14 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:14 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:14 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:14 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:14 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:14 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:14 --> Total execution time: 0.2371
INFO - 2023-05-31 02:08:14 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:14 --> Config Class Initialized
INFO - 2023-05-31 02:08:14 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:14 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:14 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:14 --> URI Class Initialized
INFO - 2023-05-31 02:08:14 --> Router Class Initialized
INFO - 2023-05-31 02:08:14 --> Output Class Initialized
INFO - 2023-05-31 02:08:14 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:14 --> Input Class Initialized
INFO - 2023-05-31 02:08:14 --> Language Class Initialized
INFO - 2023-05-31 02:08:14 --> Loader Class Initialized
INFO - 2023-05-31 02:08:14 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:14 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:14 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:14 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:14 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:14 --> Total execution time: 0.2176
INFO - 2023-05-31 02:08:14 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:14 --> Total execution time: 1.0329
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:15 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:15 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:15 --> Utf8 Class Initialized
DEBUG - 2023-05-31 02:08:15 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:08:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:15 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:15 --> URI Class Initialized
INFO - 2023-05-31 02:08:15 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:15 --> URI Class Initialized
INFO - 2023-05-31 02:08:15 --> URI Class Initialized
INFO - 2023-05-31 02:08:15 --> Router Class Initialized
INFO - 2023-05-31 02:08:15 --> Router Class Initialized
INFO - 2023-05-31 02:08:15 --> Router Class Initialized
INFO - 2023-05-31 02:08:15 --> Output Class Initialized
INFO - 2023-05-31 02:08:15 --> Output Class Initialized
INFO - 2023-05-31 02:08:15 --> Output Class Initialized
INFO - 2023-05-31 02:08:15 --> Security Class Initialized
INFO - 2023-05-31 02:08:15 --> Security Class Initialized
INFO - 2023-05-31 02:08:15 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:15 --> Input Class Initialized
INFO - 2023-05-31 02:08:15 --> Input Class Initialized
INFO - 2023-05-31 02:08:15 --> Input Class Initialized
INFO - 2023-05-31 02:08:15 --> Language Class Initialized
INFO - 2023-05-31 02:08:15 --> Language Class Initialized
INFO - 2023-05-31 02:08:15 --> Language Class Initialized
INFO - 2023-05-31 02:08:15 --> Loader Class Initialized
INFO - 2023-05-31 02:08:15 --> Loader Class Initialized
INFO - 2023-05-31 02:08:15 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:15 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:15 --> Loader Class Initialized
INFO - 2023-05-31 02:08:15 --> Controller Class Initialized
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:15 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:15 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
DEBUG - 2023-05-31 02:08:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:15 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:15 --> URI Class Initialized
INFO - 2023-05-31 02:08:15 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:15 --> Total execution time: 0.5505
INFO - 2023-05-31 02:08:15 --> Router Class Initialized
INFO - 2023-05-31 02:08:15 --> Final output sent to browser
INFO - 2023-05-31 02:08:15 --> Output Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Total execution time: 0.5663
INFO - 2023-05-31 02:08:15 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:15 --> Input Class Initialized
INFO - 2023-05-31 02:08:15 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:15 --> Language Class Initialized
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:15 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:15 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:15 --> URI Class Initialized
DEBUG - 2023-05-31 02:08:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:15 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:15 --> Loader Class Initialized
INFO - 2023-05-31 02:08:15 --> Router Class Initialized
INFO - 2023-05-31 02:08:15 --> URI Class Initialized
INFO - 2023-05-31 02:08:15 --> Controller Class Initialized
INFO - 2023-05-31 02:08:15 --> Output Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:15 --> Router Class Initialized
INFO - 2023-05-31 02:08:15 --> Security Class Initialized
INFO - 2023-05-31 02:08:15 --> Output Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:15 --> Input Class Initialized
INFO - 2023-05-31 02:08:15 --> Security Class Initialized
INFO - 2023-05-31 02:08:15 --> Language Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:15 --> Input Class Initialized
INFO - 2023-05-31 02:08:15 --> Language Class Initialized
INFO - 2023-05-31 02:08:15 --> Loader Class Initialized
INFO - 2023-05-31 02:08:15 --> Controller Class Initialized
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:15 --> Loader Class Initialized
INFO - 2023-05-31 02:08:15 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:15 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:15 --> Total execution time: 0.9666
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:16 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:16 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:16 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:16 --> URI Class Initialized
INFO - 2023-05-31 02:08:16 --> Final output sent to browser
INFO - 2023-05-31 02:08:16 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:16 --> Total execution time: 0.4379
DEBUG - 2023-05-31 02:08:16 --> Total execution time: 0.5463
INFO - 2023-05-31 02:08:16 --> Router Class Initialized
INFO - 2023-05-31 02:08:16 --> Output Class Initialized
INFO - 2023-05-31 02:08:16 --> Security Class Initialized
INFO - 2023-05-31 02:08:16 --> Config Class Initialized
DEBUG - 2023-05-31 02:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:16 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:16 --> Input Class Initialized
INFO - 2023-05-31 02:08:16 --> Config Class Initialized
INFO - 2023-05-31 02:08:16 --> Language Class Initialized
INFO - 2023-05-31 02:08:16 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:16 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:16 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:16 --> Loader Class Initialized
DEBUG - 2023-05-31 02:08:16 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:16 --> URI Class Initialized
INFO - 2023-05-31 02:08:16 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:16 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:16 --> URI Class Initialized
INFO - 2023-05-31 02:08:16 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:16 --> Total execution time: 0.5203
INFO - 2023-05-31 02:08:16 --> Router Class Initialized
INFO - 2023-05-31 02:08:16 --> Router Class Initialized
INFO - 2023-05-31 02:08:16 --> Output Class Initialized
INFO - 2023-05-31 02:08:16 --> Security Class Initialized
INFO - 2023-05-31 02:08:16 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:16 --> Output Class Initialized
DEBUG - 2023-05-31 02:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:16 --> Input Class Initialized
INFO - 2023-05-31 02:08:16 --> Security Class Initialized
INFO - 2023-05-31 02:08:16 --> Language Class Initialized
DEBUG - 2023-05-31 02:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:16 --> Input Class Initialized
INFO - 2023-05-31 02:08:16 --> Language Class Initialized
INFO - 2023-05-31 02:08:16 --> Loader Class Initialized
INFO - 2023-05-31 02:08:16 --> Controller Class Initialized
INFO - 2023-05-31 02:08:16 --> Loader Class Initialized
DEBUG - 2023-05-31 02:08:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:16 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:16 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:16 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:16 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:16 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:16 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:16 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:16 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:16 --> Total execution time: 0.3963
INFO - 2023-05-31 02:08:16 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:16 --> Total execution time: 0.4234
INFO - 2023-05-31 02:08:16 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:16 --> Total execution time: 0.4412
INFO - 2023-05-31 02:08:25 --> Config Class Initialized
INFO - 2023-05-31 02:08:25 --> Config Class Initialized
INFO - 2023-05-31 02:08:25 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:25 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:25 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:08:25 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:25 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:25 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:25 --> URI Class Initialized
INFO - 2023-05-31 02:08:25 --> URI Class Initialized
INFO - 2023-05-31 02:08:25 --> Router Class Initialized
INFO - 2023-05-31 02:08:25 --> Router Class Initialized
INFO - 2023-05-31 02:08:25 --> Output Class Initialized
INFO - 2023-05-31 02:08:25 --> Output Class Initialized
INFO - 2023-05-31 02:08:25 --> Security Class Initialized
INFO - 2023-05-31 02:08:25 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:25 --> Input Class Initialized
INFO - 2023-05-31 02:08:25 --> Input Class Initialized
INFO - 2023-05-31 02:08:25 --> Language Class Initialized
INFO - 2023-05-31 02:08:25 --> Language Class Initialized
INFO - 2023-05-31 02:08:25 --> Loader Class Initialized
INFO - 2023-05-31 02:08:25 --> Loader Class Initialized
INFO - 2023-05-31 02:08:25 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:25 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:25 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:25 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:25 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:25 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:25 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:25 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:25 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:25 --> Total execution time: 0.1844
INFO - 2023-05-31 02:08:25 --> Config Class Initialized
INFO - 2023-05-31 02:08:25 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:25 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:25 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:25 --> URI Class Initialized
INFO - 2023-05-31 02:08:25 --> Router Class Initialized
INFO - 2023-05-31 02:08:25 --> Output Class Initialized
INFO - 2023-05-31 02:08:25 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:25 --> Input Class Initialized
INFO - 2023-05-31 02:08:25 --> Language Class Initialized
INFO - 2023-05-31 02:08:25 --> Loader Class Initialized
INFO - 2023-05-31 02:08:25 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:25 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:25 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:25 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:25 --> Total execution time: 0.2079
INFO - 2023-05-31 02:08:35 --> Config Class Initialized
INFO - 2023-05-31 02:08:35 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:35 --> Config Class Initialized
INFO - 2023-05-31 02:08:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:35 --> Utf8 Class Initialized
DEBUG - 2023-05-31 02:08:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:35 --> URI Class Initialized
INFO - 2023-05-31 02:08:35 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:35 --> URI Class Initialized
INFO - 2023-05-31 02:08:35 --> Router Class Initialized
INFO - 2023-05-31 02:08:35 --> Router Class Initialized
INFO - 2023-05-31 02:08:35 --> Output Class Initialized
INFO - 2023-05-31 02:08:35 --> Output Class Initialized
INFO - 2023-05-31 02:08:35 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:35 --> Security Class Initialized
INFO - 2023-05-31 02:08:35 --> Input Class Initialized
DEBUG - 2023-05-31 02:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:35 --> Language Class Initialized
INFO - 2023-05-31 02:08:35 --> Input Class Initialized
INFO - 2023-05-31 02:08:35 --> Language Class Initialized
INFO - 2023-05-31 02:08:35 --> Loader Class Initialized
INFO - 2023-05-31 02:08:35 --> Loader Class Initialized
INFO - 2023-05-31 02:08:35 --> Controller Class Initialized
INFO - 2023-05-31 02:08:35 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 02:08:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:35 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:35 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:35 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:35 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:35 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:35 --> Total execution time: 0.2175
INFO - 2023-05-31 02:08:35 --> Config Class Initialized
INFO - 2023-05-31 02:08:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:35 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:35 --> URI Class Initialized
INFO - 2023-05-31 02:08:35 --> Router Class Initialized
INFO - 2023-05-31 02:08:35 --> Output Class Initialized
INFO - 2023-05-31 02:08:35 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:35 --> Input Class Initialized
INFO - 2023-05-31 02:08:35 --> Language Class Initialized
INFO - 2023-05-31 02:08:35 --> Loader Class Initialized
INFO - 2023-05-31 02:08:35 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:35 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:35 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:35 --> Total execution time: 0.2082
INFO - 2023-05-31 02:08:36 --> Config Class Initialized
INFO - 2023-05-31 02:08:36 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:36 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:36 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:36 --> URI Class Initialized
INFO - 2023-05-31 02:08:36 --> Router Class Initialized
INFO - 2023-05-31 02:08:36 --> Output Class Initialized
INFO - 2023-05-31 02:08:36 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:36 --> Input Class Initialized
INFO - 2023-05-31 02:08:36 --> Language Class Initialized
INFO - 2023-05-31 02:08:36 --> Loader Class Initialized
INFO - 2023-05-31 02:08:36 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:36 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:36 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:36 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:36 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:36 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:36 --> Total execution time: 0.4444
INFO - 2023-05-31 02:08:36 --> Config Class Initialized
INFO - 2023-05-31 02:08:36 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:36 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:36 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:36 --> URI Class Initialized
INFO - 2023-05-31 02:08:36 --> Router Class Initialized
INFO - 2023-05-31 02:08:36 --> Output Class Initialized
INFO - 2023-05-31 02:08:36 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:36 --> Input Class Initialized
INFO - 2023-05-31 02:08:36 --> Language Class Initialized
INFO - 2023-05-31 02:08:36 --> Loader Class Initialized
INFO - 2023-05-31 02:08:36 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:36 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:36 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:36 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:36 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:36 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:36 --> Total execution time: 0.2203
INFO - 2023-05-31 02:08:37 --> Config Class Initialized
INFO - 2023-05-31 02:08:37 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:37 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:37 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:37 --> URI Class Initialized
INFO - 2023-05-31 02:08:37 --> Router Class Initialized
INFO - 2023-05-31 02:08:37 --> Output Class Initialized
INFO - 2023-05-31 02:08:37 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:37 --> Input Class Initialized
INFO - 2023-05-31 02:08:37 --> Language Class Initialized
INFO - 2023-05-31 02:08:37 --> Loader Class Initialized
INFO - 2023-05-31 02:08:37 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:37 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:37 --> Total execution time: 0.1253
INFO - 2023-05-31 02:08:37 --> Config Class Initialized
INFO - 2023-05-31 02:08:37 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:37 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:37 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:37 --> URI Class Initialized
INFO - 2023-05-31 02:08:37 --> Router Class Initialized
INFO - 2023-05-31 02:08:37 --> Output Class Initialized
INFO - 2023-05-31 02:08:37 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:37 --> Input Class Initialized
INFO - 2023-05-31 02:08:37 --> Language Class Initialized
INFO - 2023-05-31 02:08:37 --> Loader Class Initialized
INFO - 2023-05-31 02:08:37 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:37 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:37 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:37 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:37 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:37 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:37 --> Total execution time: 0.2059
INFO - 2023-05-31 02:08:38 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:38 --> Total execution time: 13.2683
INFO - 2023-05-31 02:08:38 --> Config Class Initialized
INFO - 2023-05-31 02:08:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:38 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:38 --> URI Class Initialized
INFO - 2023-05-31 02:08:38 --> Router Class Initialized
INFO - 2023-05-31 02:08:38 --> Output Class Initialized
INFO - 2023-05-31 02:08:38 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:38 --> Input Class Initialized
INFO - 2023-05-31 02:08:38 --> Language Class Initialized
INFO - 2023-05-31 02:08:38 --> Loader Class Initialized
INFO - 2023-05-31 02:08:38 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:38 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:38 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:38 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:45 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:45 --> Total execution time: 10.5979
INFO - 2023-05-31 02:08:50 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:50 --> Total execution time: 11.7752
INFO - 2023-05-31 02:08:50 --> Config Class Initialized
INFO - 2023-05-31 02:08:50 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:50 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:50 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:50 --> URI Class Initialized
INFO - 2023-05-31 02:08:50 --> Router Class Initialized
INFO - 2023-05-31 02:08:50 --> Output Class Initialized
INFO - 2023-05-31 02:08:50 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:50 --> Input Class Initialized
INFO - 2023-05-31 02:08:50 --> Language Class Initialized
INFO - 2023-05-31 02:08:50 --> Loader Class Initialized
INFO - 2023-05-31 02:08:50 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:50 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:50 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:50 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:50 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:53 --> Config Class Initialized
INFO - 2023-05-31 02:08:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:53 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:53 --> URI Class Initialized
INFO - 2023-05-31 02:08:54 --> Router Class Initialized
INFO - 2023-05-31 02:08:54 --> Output Class Initialized
INFO - 2023-05-31 02:08:54 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:54 --> Input Class Initialized
INFO - 2023-05-31 02:08:54 --> Language Class Initialized
INFO - 2023-05-31 02:08:54 --> Loader Class Initialized
INFO - 2023-05-31 02:08:54 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:54 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:54 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:54 --> Total execution time: 0.2868
INFO - 2023-05-31 02:08:54 --> Config Class Initialized
INFO - 2023-05-31 02:08:54 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:54 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:54 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:54 --> URI Class Initialized
INFO - 2023-05-31 02:08:54 --> Router Class Initialized
INFO - 2023-05-31 02:08:54 --> Output Class Initialized
INFO - 2023-05-31 02:08:54 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:54 --> Input Class Initialized
INFO - 2023-05-31 02:08:54 --> Language Class Initialized
INFO - 2023-05-31 02:08:54 --> Loader Class Initialized
INFO - 2023-05-31 02:08:54 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:54 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:54 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:54 --> Total execution time: 0.2055
INFO - 2023-05-31 02:08:57 --> Config Class Initialized
INFO - 2023-05-31 02:08:57 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:57 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:57 --> URI Class Initialized
INFO - 2023-05-31 02:08:57 --> Router Class Initialized
INFO - 2023-05-31 02:08:57 --> Output Class Initialized
INFO - 2023-05-31 02:08:57 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:57 --> Input Class Initialized
INFO - 2023-05-31 02:08:57 --> Language Class Initialized
INFO - 2023-05-31 02:08:57 --> Loader Class Initialized
INFO - 2023-05-31 02:08:57 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:57 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:57 --> Total execution time: 0.1511
INFO - 2023-05-31 02:08:58 --> Config Class Initialized
INFO - 2023-05-31 02:08:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:58 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:58 --> URI Class Initialized
INFO - 2023-05-31 02:08:58 --> Router Class Initialized
INFO - 2023-05-31 02:08:58 --> Output Class Initialized
INFO - 2023-05-31 02:08:58 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:58 --> Input Class Initialized
INFO - 2023-05-31 02:08:58 --> Language Class Initialized
INFO - 2023-05-31 02:08:58 --> Loader Class Initialized
INFO - 2023-05-31 02:08:58 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:58 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:58 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:58 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:58 --> Total execution time: 0.1748
INFO - 2023-05-31 02:08:59 --> Config Class Initialized
INFO - 2023-05-31 02:08:59 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:59 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:59 --> URI Class Initialized
INFO - 2023-05-31 02:08:59 --> Router Class Initialized
INFO - 2023-05-31 02:08:59 --> Output Class Initialized
INFO - 2023-05-31 02:08:59 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:59 --> Input Class Initialized
INFO - 2023-05-31 02:08:59 --> Language Class Initialized
INFO - 2023-05-31 02:08:59 --> Loader Class Initialized
INFO - 2023-05-31 02:08:59 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:59 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:59 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:59 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:59 --> Total execution time: 0.1831
INFO - 2023-05-31 02:08:59 --> Config Class Initialized
INFO - 2023-05-31 02:08:59 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:59 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:59 --> URI Class Initialized
INFO - 2023-05-31 02:08:59 --> Router Class Initialized
INFO - 2023-05-31 02:08:59 --> Output Class Initialized
INFO - 2023-05-31 02:08:59 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:59 --> Input Class Initialized
INFO - 2023-05-31 02:08:59 --> Language Class Initialized
INFO - 2023-05-31 02:09:00 --> Loader Class Initialized
INFO - 2023-05-31 02:09:00 --> Controller Class Initialized
DEBUG - 2023-05-31 02:09:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:09:00 --> Database Driver Class Initialized
INFO - 2023-05-31 02:09:00 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:09:00 --> Final output sent to browser
DEBUG - 2023-05-31 02:09:00 --> Total execution time: 0.2016
INFO - 2023-05-31 02:09:08 --> Final output sent to browser
DEBUG - 2023-05-31 02:09:08 --> Total execution time: 18.5106
INFO - 2023-05-31 02:11:53 --> Config Class Initialized
INFO - 2023-05-31 02:11:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:11:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:11:53 --> Utf8 Class Initialized
INFO - 2023-05-31 02:11:53 --> URI Class Initialized
INFO - 2023-05-31 02:11:53 --> Router Class Initialized
INFO - 2023-05-31 02:11:53 --> Output Class Initialized
INFO - 2023-05-31 02:11:53 --> Security Class Initialized
DEBUG - 2023-05-31 02:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:11:53 --> Input Class Initialized
INFO - 2023-05-31 02:11:53 --> Language Class Initialized
INFO - 2023-05-31 02:11:53 --> Loader Class Initialized
INFO - 2023-05-31 02:11:53 --> Controller Class Initialized
DEBUG - 2023-05-31 02:11:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:11:53 --> Database Driver Class Initialized
INFO - 2023-05-31 02:11:53 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:11:53 --> Final output sent to browser
DEBUG - 2023-05-31 02:11:53 --> Total execution time: 0.2682
INFO - 2023-05-31 02:11:54 --> Config Class Initialized
INFO - 2023-05-31 02:11:54 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:11:54 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:11:54 --> Utf8 Class Initialized
INFO - 2023-05-31 02:11:54 --> URI Class Initialized
INFO - 2023-05-31 02:11:54 --> Router Class Initialized
INFO - 2023-05-31 02:11:54 --> Output Class Initialized
INFO - 2023-05-31 02:11:54 --> Security Class Initialized
DEBUG - 2023-05-31 02:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:11:54 --> Input Class Initialized
INFO - 2023-05-31 02:11:54 --> Language Class Initialized
INFO - 2023-05-31 02:11:54 --> Loader Class Initialized
INFO - 2023-05-31 02:11:54 --> Controller Class Initialized
DEBUG - 2023-05-31 02:11:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:11:54 --> Database Driver Class Initialized
INFO - 2023-05-31 02:11:54 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:11:54 --> Final output sent to browser
DEBUG - 2023-05-31 02:11:54 --> Total execution time: 0.3612
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:14:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:14:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:27 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:27 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:27 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:27 --> URI Class Initialized
INFO - 2023-05-31 02:14:27 --> URI Class Initialized
INFO - 2023-05-31 02:14:27 --> URI Class Initialized
INFO - 2023-05-31 02:14:27 --> Router Class Initialized
INFO - 2023-05-31 02:14:27 --> Router Class Initialized
INFO - 2023-05-31 02:14:27 --> Router Class Initialized
INFO - 2023-05-31 02:14:27 --> Output Class Initialized
INFO - 2023-05-31 02:14:27 --> Output Class Initialized
INFO - 2023-05-31 02:14:27 --> Output Class Initialized
INFO - 2023-05-31 02:14:27 --> Security Class Initialized
INFO - 2023-05-31 02:14:27 --> Security Class Initialized
INFO - 2023-05-31 02:14:27 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:27 --> Input Class Initialized
INFO - 2023-05-31 02:14:27 --> Input Class Initialized
INFO - 2023-05-31 02:14:27 --> Input Class Initialized
INFO - 2023-05-31 02:14:27 --> Language Class Initialized
INFO - 2023-05-31 02:14:27 --> Language Class Initialized
INFO - 2023-05-31 02:14:27 --> Language Class Initialized
INFO - 2023-05-31 02:14:27 --> Loader Class Initialized
INFO - 2023-05-31 02:14:27 --> Loader Class Initialized
INFO - 2023-05-31 02:14:27 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:27 --> Controller Class Initialized
INFO - 2023-05-31 02:14:27 --> Loader Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:27 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:27 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:27 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:27 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:27 --> Total execution time: 0.1938
INFO - 2023-05-31 02:14:27 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:27 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:27 --> Total execution time: 0.2039
INFO - 2023-05-31 02:14:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:27 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:27 --> Total execution time: 0.2328
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:14:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:27 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:27 --> URI Class Initialized
INFO - 2023-05-31 02:14:27 --> URI Class Initialized
INFO - 2023-05-31 02:14:27 --> Router Class Initialized
INFO - 2023-05-31 02:14:27 --> Router Class Initialized
INFO - 2023-05-31 02:14:27 --> Output Class Initialized
INFO - 2023-05-31 02:14:27 --> Output Class Initialized
INFO - 2023-05-31 02:14:27 --> Security Class Initialized
INFO - 2023-05-31 02:14:27 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:27 --> Utf8 Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:27 --> Input Class Initialized
INFO - 2023-05-31 02:14:27 --> Input Class Initialized
INFO - 2023-05-31 02:14:27 --> Language Class Initialized
INFO - 2023-05-31 02:14:27 --> URI Class Initialized
INFO - 2023-05-31 02:14:27 --> Language Class Initialized
INFO - 2023-05-31 02:14:27 --> Router Class Initialized
INFO - 2023-05-31 02:14:27 --> Loader Class Initialized
INFO - 2023-05-31 02:14:27 --> Output Class Initialized
INFO - 2023-05-31 02:14:27 --> Loader Class Initialized
INFO - 2023-05-31 02:14:27 --> Controller Class Initialized
INFO - 2023-05-31 02:14:27 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:27 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:27 --> Input Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:27 --> Language Class Initialized
INFO - 2023-05-31 02:14:27 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:27 --> Loader Class Initialized
INFO - 2023-05-31 02:14:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:27 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:27 --> Controller Class Initialized
INFO - 2023-05-31 02:14:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:27 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 02:14:27 --> Total execution time: 0.2112
INFO - 2023-05-31 02:14:27 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:27 --> Total execution time: 0.2421
INFO - 2023-05-31 02:14:27 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:27 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:27 --> Total execution time: 0.2542
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:28 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:28 --> URI Class Initialized
INFO - 2023-05-31 02:14:28 --> Router Class Initialized
INFO - 2023-05-31 02:14:28 --> Output Class Initialized
INFO - 2023-05-31 02:14:28 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:28 --> Input Class Initialized
INFO - 2023-05-31 02:14:28 --> Language Class Initialized
INFO - 2023-05-31 02:14:28 --> Loader Class Initialized
INFO - 2023-05-31 02:14:28 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:28 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:28 --> Config Class Initialized
INFO - 2023-05-31 02:14:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:28 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:28 --> URI Class Initialized
INFO - 2023-05-31 02:14:28 --> Router Class Initialized
INFO - 2023-05-31 02:14:28 --> Output Class Initialized
INFO - 2023-05-31 02:14:28 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:28 --> Input Class Initialized
INFO - 2023-05-31 02:14:28 --> Language Class Initialized
INFO - 2023-05-31 02:14:28 --> Loader Class Initialized
INFO - 2023-05-31 02:14:28 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:28 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:29 --> Config Class Initialized
INFO - 2023-05-31 02:14:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:29 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:29 --> URI Class Initialized
INFO - 2023-05-31 02:14:29 --> Router Class Initialized
INFO - 2023-05-31 02:14:29 --> Output Class Initialized
INFO - 2023-05-31 02:14:29 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:29 --> Input Class Initialized
INFO - 2023-05-31 02:14:29 --> Language Class Initialized
INFO - 2023-05-31 02:14:29 --> Loader Class Initialized
INFO - 2023-05-31 02:14:29 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:29 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:29 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:29 --> Total execution time: 0.2139
INFO - 2023-05-31 02:14:29 --> Config Class Initialized
INFO - 2023-05-31 02:14:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:29 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:29 --> URI Class Initialized
INFO - 2023-05-31 02:14:29 --> Router Class Initialized
INFO - 2023-05-31 02:14:29 --> Output Class Initialized
INFO - 2023-05-31 02:14:29 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:29 --> Input Class Initialized
INFO - 2023-05-31 02:14:29 --> Language Class Initialized
INFO - 2023-05-31 02:14:29 --> Loader Class Initialized
INFO - 2023-05-31 02:14:29 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:29 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:29 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:29 --> Total execution time: 0.1835
INFO - 2023-05-31 02:14:34 --> Config Class Initialized
INFO - 2023-05-31 02:14:34 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:34 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:34 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:34 --> URI Class Initialized
INFO - 2023-05-31 02:14:34 --> Router Class Initialized
INFO - 2023-05-31 02:14:34 --> Output Class Initialized
INFO - 2023-05-31 02:14:34 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:34 --> Input Class Initialized
INFO - 2023-05-31 02:14:34 --> Language Class Initialized
INFO - 2023-05-31 02:14:34 --> Loader Class Initialized
INFO - 2023-05-31 02:14:34 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:34 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:34 --> Total execution time: 0.1488
INFO - 2023-05-31 02:14:35 --> Config Class Initialized
INFO - 2023-05-31 02:14:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:35 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:35 --> URI Class Initialized
INFO - 2023-05-31 02:14:35 --> Router Class Initialized
INFO - 2023-05-31 02:14:35 --> Output Class Initialized
INFO - 2023-05-31 02:14:35 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:35 --> Input Class Initialized
INFO - 2023-05-31 02:14:35 --> Language Class Initialized
INFO - 2023-05-31 02:14:35 --> Loader Class Initialized
INFO - 2023-05-31 02:14:35 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:35 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:35 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:35 --> Total execution time: 0.1932
INFO - 2023-05-31 02:14:38 --> Config Class Initialized
INFO - 2023-05-31 02:14:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:38 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:38 --> URI Class Initialized
INFO - 2023-05-31 02:14:38 --> Router Class Initialized
INFO - 2023-05-31 02:14:38 --> Output Class Initialized
INFO - 2023-05-31 02:14:38 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:38 --> Input Class Initialized
INFO - 2023-05-31 02:14:38 --> Language Class Initialized
INFO - 2023-05-31 02:14:38 --> Loader Class Initialized
INFO - 2023-05-31 02:14:38 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:38 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:38 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:38 --> Total execution time: 0.1904
INFO - 2023-05-31 02:14:38 --> Config Class Initialized
INFO - 2023-05-31 02:14:38 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:38 --> Config Class Initialized
DEBUG - 2023-05-31 02:14:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:38 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:38 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:38 --> URI Class Initialized
DEBUG - 2023-05-31 02:14:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:38 --> Router Class Initialized
INFO - 2023-05-31 02:14:38 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:38 --> URI Class Initialized
INFO - 2023-05-31 02:14:38 --> Output Class Initialized
INFO - 2023-05-31 02:14:38 --> Security Class Initialized
INFO - 2023-05-31 02:14:38 --> Router Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:38 --> Input Class Initialized
INFO - 2023-05-31 02:14:38 --> Output Class Initialized
INFO - 2023-05-31 02:14:38 --> Language Class Initialized
INFO - 2023-05-31 02:14:38 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:38 --> Input Class Initialized
INFO - 2023-05-31 02:14:38 --> Language Class Initialized
INFO - 2023-05-31 02:14:38 --> Loader Class Initialized
INFO - 2023-05-31 02:14:38 --> Loader Class Initialized
INFO - 2023-05-31 02:14:38 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:38 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:38 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:38 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:38 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:38 --> Total execution time: 0.2047
INFO - 2023-05-31 02:14:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:38 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:38 --> Total execution time: 0.1917
INFO - 2023-05-31 02:14:38 --> Config Class Initialized
INFO - 2023-05-31 02:14:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:38 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:38 --> URI Class Initialized
INFO - 2023-05-31 02:14:38 --> Router Class Initialized
INFO - 2023-05-31 02:14:38 --> Output Class Initialized
INFO - 2023-05-31 02:14:38 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:38 --> Input Class Initialized
INFO - 2023-05-31 02:14:38 --> Language Class Initialized
INFO - 2023-05-31 02:14:38 --> Loader Class Initialized
INFO - 2023-05-31 02:14:38 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:38 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:38 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:38 --> Total execution time: 0.1909
INFO - 2023-05-31 02:14:44 --> Config Class Initialized
INFO - 2023-05-31 02:14:44 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:44 --> Config Class Initialized
INFO - 2023-05-31 02:14:44 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:44 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:44 --> URI Class Initialized
DEBUG - 2023-05-31 02:14:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:44 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:44 --> Router Class Initialized
INFO - 2023-05-31 02:14:44 --> URI Class Initialized
INFO - 2023-05-31 02:14:44 --> Output Class Initialized
INFO - 2023-05-31 02:14:44 --> Router Class Initialized
INFO - 2023-05-31 02:14:44 --> Security Class Initialized
INFO - 2023-05-31 02:14:44 --> Output Class Initialized
DEBUG - 2023-05-31 02:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:44 --> Input Class Initialized
INFO - 2023-05-31 02:14:44 --> Security Class Initialized
INFO - 2023-05-31 02:14:44 --> Language Class Initialized
DEBUG - 2023-05-31 02:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:44 --> Input Class Initialized
INFO - 2023-05-31 02:14:44 --> Language Class Initialized
INFO - 2023-05-31 02:14:44 --> Loader Class Initialized
INFO - 2023-05-31 02:14:44 --> Loader Class Initialized
INFO - 2023-05-31 02:14:44 --> Controller Class Initialized
INFO - 2023-05-31 02:14:44 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 02:14:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:44 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:44 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:44 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:44 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:44 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:44 --> Total execution time: 0.1827
INFO - 2023-05-31 02:14:44 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:44 --> Model "Login_model" initialized
INFO - 2023-05-31 02:14:44 --> Config Class Initialized
INFO - 2023-05-31 02:14:44 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:44 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:44 --> URI Class Initialized
INFO - 2023-05-31 02:14:44 --> Router Class Initialized
INFO - 2023-05-31 02:14:44 --> Output Class Initialized
INFO - 2023-05-31 02:14:44 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:44 --> Input Class Initialized
INFO - 2023-05-31 02:14:44 --> Language Class Initialized
INFO - 2023-05-31 02:14:44 --> Loader Class Initialized
INFO - 2023-05-31 02:14:44 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:44 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:44 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:44 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:44 --> Total execution time: 0.1860
INFO - 2023-05-31 02:14:45 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:45 --> Total execution time: 0.6973
INFO - 2023-05-31 02:14:45 --> Config Class Initialized
INFO - 2023-05-31 02:14:45 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:45 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:45 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:45 --> URI Class Initialized
INFO - 2023-05-31 02:14:45 --> Router Class Initialized
INFO - 2023-05-31 02:14:45 --> Output Class Initialized
INFO - 2023-05-31 02:14:45 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:45 --> Input Class Initialized
INFO - 2023-05-31 02:14:45 --> Language Class Initialized
INFO - 2023-05-31 02:14:45 --> Loader Class Initialized
INFO - 2023-05-31 02:14:45 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:45 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:45 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:45 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:45 --> Model "Login_model" initialized
INFO - 2023-05-31 02:14:45 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:45 --> Total execution time: 0.3247
INFO - 2023-05-31 02:14:47 --> Config Class Initialized
INFO - 2023-05-31 02:14:47 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:47 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:47 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:47 --> URI Class Initialized
INFO - 2023-05-31 02:14:47 --> Router Class Initialized
INFO - 2023-05-31 02:14:47 --> Output Class Initialized
INFO - 2023-05-31 02:14:47 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:47 --> Input Class Initialized
INFO - 2023-05-31 02:14:47 --> Language Class Initialized
INFO - 2023-05-31 02:14:47 --> Loader Class Initialized
INFO - 2023-05-31 02:14:47 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:47 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:47 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:47 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:47 --> Total execution time: 0.1739
INFO - 2023-05-31 02:14:47 --> Config Class Initialized
INFO - 2023-05-31 02:14:47 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:47 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:47 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:47 --> URI Class Initialized
INFO - 2023-05-31 02:14:47 --> Router Class Initialized
INFO - 2023-05-31 02:14:47 --> Output Class Initialized
INFO - 2023-05-31 02:14:47 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:47 --> Input Class Initialized
INFO - 2023-05-31 02:14:47 --> Language Class Initialized
INFO - 2023-05-31 02:14:47 --> Loader Class Initialized
INFO - 2023-05-31 02:14:47 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:47 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:47 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:47 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:47 --> Total execution time: 0.1957
INFO - 2023-05-31 02:14:49 --> Config Class Initialized
INFO - 2023-05-31 02:14:49 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:49 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:49 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:49 --> URI Class Initialized
INFO - 2023-05-31 02:14:49 --> Router Class Initialized
INFO - 2023-05-31 02:14:49 --> Output Class Initialized
INFO - 2023-05-31 02:14:49 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:49 --> Input Class Initialized
INFO - 2023-05-31 02:14:49 --> Language Class Initialized
INFO - 2023-05-31 02:14:49 --> Loader Class Initialized
INFO - 2023-05-31 02:14:49 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:49 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:49 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:49 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:49 --> Total execution time: 0.1642
INFO - 2023-05-31 02:14:49 --> Config Class Initialized
INFO - 2023-05-31 02:14:49 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:49 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:49 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:49 --> URI Class Initialized
INFO - 2023-05-31 02:14:49 --> Router Class Initialized
INFO - 2023-05-31 02:14:49 --> Output Class Initialized
INFO - 2023-05-31 02:14:49 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:49 --> Input Class Initialized
INFO - 2023-05-31 02:14:49 --> Language Class Initialized
INFO - 2023-05-31 02:14:49 --> Loader Class Initialized
INFO - 2023-05-31 02:14:49 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:49 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:49 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:49 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:49 --> Total execution time: 0.1713
INFO - 2023-05-31 02:15:00 --> Config Class Initialized
INFO - 2023-05-31 02:15:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:15:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:15:00 --> Utf8 Class Initialized
INFO - 2023-05-31 02:15:00 --> URI Class Initialized
INFO - 2023-05-31 02:15:00 --> Router Class Initialized
INFO - 2023-05-31 02:15:00 --> Output Class Initialized
INFO - 2023-05-31 02:15:00 --> Security Class Initialized
DEBUG - 2023-05-31 02:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:15:00 --> Input Class Initialized
INFO - 2023-05-31 02:15:00 --> Language Class Initialized
INFO - 2023-05-31 02:15:00 --> Loader Class Initialized
INFO - 2023-05-31 02:15:00 --> Controller Class Initialized
DEBUG - 2023-05-31 02:15:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:15:00 --> Database Driver Class Initialized
INFO - 2023-05-31 02:15:00 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:15:00 --> Final output sent to browser
DEBUG - 2023-05-31 02:15:00 --> Total execution time: 0.1743
INFO - 2023-05-31 02:15:00 --> Config Class Initialized
INFO - 2023-05-31 02:15:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:15:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:15:00 --> Utf8 Class Initialized
INFO - 2023-05-31 02:15:00 --> URI Class Initialized
INFO - 2023-05-31 02:15:00 --> Router Class Initialized
INFO - 2023-05-31 02:15:00 --> Output Class Initialized
INFO - 2023-05-31 02:15:00 --> Security Class Initialized
DEBUG - 2023-05-31 02:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:15:00 --> Input Class Initialized
INFO - 2023-05-31 02:15:00 --> Language Class Initialized
INFO - 2023-05-31 02:15:00 --> Loader Class Initialized
INFO - 2023-05-31 02:15:00 --> Controller Class Initialized
DEBUG - 2023-05-31 02:15:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:15:00 --> Database Driver Class Initialized
INFO - 2023-05-31 02:15:00 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 02:15:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'lock wait timeout = 4556' at line 1 - Invalid query: set global innodb lock wait timeout = 4556
INFO - 2023-05-31 02:15:00 --> Language file loaded: language/english/db_lang.php
