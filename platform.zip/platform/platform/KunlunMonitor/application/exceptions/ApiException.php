<?php


class ApiException extends Exception
{
}
