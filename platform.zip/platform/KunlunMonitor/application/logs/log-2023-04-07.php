<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-07 02:02:40 --> Config Class Initialized
INFO - 2023-04-07 02:02:40 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:40 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:40 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:40 --> URI Class Initialized
INFO - 2023-04-07 02:02:40 --> Router Class Initialized
INFO - 2023-04-07 02:02:40 --> Output Class Initialized
INFO - 2023-04-07 02:02:40 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:40 --> Input Class Initialized
INFO - 2023-04-07 02:02:40 --> Language Class Initialized
INFO - 2023-04-07 02:02:40 --> Loader Class Initialized
INFO - 2023-04-07 02:02:40 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:40 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:40 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:40 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:40 --> Model "Login_model" initialized
INFO - 2023-04-07 02:02:40 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:40 --> Total execution time: 0.2179
INFO - 2023-04-07 02:02:40 --> Config Class Initialized
INFO - 2023-04-07 02:02:40 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:40 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:40 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:40 --> URI Class Initialized
INFO - 2023-04-07 02:02:40 --> Router Class Initialized
INFO - 2023-04-07 02:02:40 --> Output Class Initialized
INFO - 2023-04-07 02:02:40 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:40 --> Input Class Initialized
INFO - 2023-04-07 02:02:40 --> Language Class Initialized
INFO - 2023-04-07 02:02:40 --> Loader Class Initialized
INFO - 2023-04-07 02:02:40 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:40 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:40 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:40 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:40 --> Model "Login_model" initialized
INFO - 2023-04-07 02:02:40 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:40 --> Total execution time: 0.1115
INFO - 2023-04-07 02:02:47 --> Config Class Initialized
INFO - 2023-04-07 02:02:47 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:47 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:47 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:47 --> URI Class Initialized
INFO - 2023-04-07 02:02:47 --> Router Class Initialized
INFO - 2023-04-07 02:02:47 --> Output Class Initialized
INFO - 2023-04-07 02:02:47 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:47 --> Input Class Initialized
INFO - 2023-04-07 02:02:47 --> Language Class Initialized
INFO - 2023-04-07 02:02:47 --> Loader Class Initialized
INFO - 2023-04-07 02:02:47 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:47 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:47 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:47 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:47 --> Total execution time: 0.0646
INFO - 2023-04-07 02:02:47 --> Config Class Initialized
INFO - 2023-04-07 02:02:47 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:47 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:47 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:47 --> URI Class Initialized
INFO - 2023-04-07 02:02:47 --> Router Class Initialized
INFO - 2023-04-07 02:02:47 --> Output Class Initialized
INFO - 2023-04-07 02:02:47 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:47 --> Input Class Initialized
INFO - 2023-04-07 02:02:47 --> Language Class Initialized
INFO - 2023-04-07 02:02:47 --> Loader Class Initialized
INFO - 2023-04-07 02:02:47 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:47 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:47 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:47 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:47 --> Total execution time: 0.0140
INFO - 2023-04-07 02:02:48 --> Config Class Initialized
INFO - 2023-04-07 02:02:48 --> Config Class Initialized
INFO - 2023-04-07 02:02:48 --> Hooks Class Initialized
INFO - 2023-04-07 02:02:48 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-07 02:02:48 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:48 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:48 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:48 --> URI Class Initialized
INFO - 2023-04-07 02:02:48 --> URI Class Initialized
INFO - 2023-04-07 02:02:48 --> Router Class Initialized
INFO - 2023-04-07 02:02:48 --> Router Class Initialized
INFO - 2023-04-07 02:02:48 --> Output Class Initialized
INFO - 2023-04-07 02:02:48 --> Output Class Initialized
INFO - 2023-04-07 02:02:48 --> Security Class Initialized
INFO - 2023-04-07 02:02:48 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-07 02:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:48 --> Input Class Initialized
INFO - 2023-04-07 02:02:48 --> Input Class Initialized
INFO - 2023-04-07 02:02:48 --> Language Class Initialized
INFO - 2023-04-07 02:02:48 --> Language Class Initialized
INFO - 2023-04-07 02:02:48 --> Loader Class Initialized
INFO - 2023-04-07 02:02:48 --> Loader Class Initialized
INFO - 2023-04-07 02:02:48 --> Controller Class Initialized
INFO - 2023-04-07 02:02:48 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-07 02:02:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:48 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:48 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:48 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:48 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:48 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:48 --> Total execution time: 0.0124
INFO - 2023-04-07 02:02:48 --> Final output sent to browser
INFO - 2023-04-07 02:02:48 --> Config Class Initialized
DEBUG - 2023-04-07 02:02:48 --> Total execution time: 0.0146
INFO - 2023-04-07 02:02:48 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:48 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:48 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:48 --> URI Class Initialized
INFO - 2023-04-07 02:02:48 --> Router Class Initialized
INFO - 2023-04-07 02:02:48 --> Config Class Initialized
INFO - 2023-04-07 02:02:48 --> Hooks Class Initialized
INFO - 2023-04-07 02:02:48 --> Output Class Initialized
DEBUG - 2023-04-07 02:02:48 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:48 --> Security Class Initialized
INFO - 2023-04-07 02:02:48 --> Utf8 Class Initialized
DEBUG - 2023-04-07 02:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:48 --> URI Class Initialized
INFO - 2023-04-07 02:02:48 --> Input Class Initialized
INFO - 2023-04-07 02:02:48 --> Router Class Initialized
INFO - 2023-04-07 02:02:48 --> Language Class Initialized
INFO - 2023-04-07 02:02:48 --> Output Class Initialized
INFO - 2023-04-07 02:02:48 --> Loader Class Initialized
INFO - 2023-04-07 02:02:48 --> Security Class Initialized
INFO - 2023-04-07 02:02:48 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-07 02:02:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:48 --> Input Class Initialized
INFO - 2023-04-07 02:02:48 --> Language Class Initialized
INFO - 2023-04-07 02:02:48 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:48 --> Loader Class Initialized
INFO - 2023-04-07 02:02:48 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:48 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:48 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:48 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:48 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:48 --> Total execution time: 0.0524
INFO - 2023-04-07 02:02:48 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:48 --> Total execution time: 0.0548
INFO - 2023-04-07 02:02:49 --> Config Class Initialized
INFO - 2023-04-07 02:02:49 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:49 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:49 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:49 --> URI Class Initialized
INFO - 2023-04-07 02:02:49 --> Router Class Initialized
INFO - 2023-04-07 02:02:49 --> Output Class Initialized
INFO - 2023-04-07 02:02:49 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:49 --> Input Class Initialized
INFO - 2023-04-07 02:02:49 --> Language Class Initialized
INFO - 2023-04-07 02:02:49 --> Loader Class Initialized
INFO - 2023-04-07 02:02:49 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:49 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:49 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:49 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:49 --> Total execution time: 0.0276
INFO - 2023-04-07 02:02:49 --> Config Class Initialized
INFO - 2023-04-07 02:02:49 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:49 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:49 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:49 --> URI Class Initialized
INFO - 2023-04-07 02:02:49 --> Router Class Initialized
INFO - 2023-04-07 02:02:49 --> Output Class Initialized
INFO - 2023-04-07 02:02:49 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:49 --> Input Class Initialized
INFO - 2023-04-07 02:02:49 --> Language Class Initialized
INFO - 2023-04-07 02:02:49 --> Loader Class Initialized
INFO - 2023-04-07 02:02:49 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:49 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:49 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:49 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:49 --> Total execution time: 0.0191
INFO - 2023-04-07 02:02:52 --> Config Class Initialized
INFO - 2023-04-07 02:02:52 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:52 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:52 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:52 --> URI Class Initialized
INFO - 2023-04-07 02:02:52 --> Router Class Initialized
INFO - 2023-04-07 02:02:52 --> Output Class Initialized
INFO - 2023-04-07 02:02:52 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:52 --> Input Class Initialized
INFO - 2023-04-07 02:02:52 --> Language Class Initialized
INFO - 2023-04-07 02:02:52 --> Loader Class Initialized
INFO - 2023-04-07 02:02:52 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:52 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:52 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:52 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:52 --> Total execution time: 0.0214
INFO - 2023-04-07 02:02:54 --> Config Class Initialized
INFO - 2023-04-07 02:02:54 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:54 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:54 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:54 --> URI Class Initialized
INFO - 2023-04-07 02:02:54 --> Router Class Initialized
INFO - 2023-04-07 02:02:54 --> Output Class Initialized
INFO - 2023-04-07 02:02:54 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:54 --> Input Class Initialized
INFO - 2023-04-07 02:02:54 --> Language Class Initialized
INFO - 2023-04-07 02:02:54 --> Loader Class Initialized
INFO - 2023-04-07 02:02:54 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:54 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:54 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:54 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:54 --> Total execution time: 0.0127
INFO - 2023-04-07 02:02:54 --> Config Class Initialized
INFO - 2023-04-07 02:02:54 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:54 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:54 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:54 --> URI Class Initialized
INFO - 2023-04-07 02:02:54 --> Router Class Initialized
INFO - 2023-04-07 02:02:54 --> Output Class Initialized
INFO - 2023-04-07 02:02:54 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:54 --> Input Class Initialized
INFO - 2023-04-07 02:02:54 --> Language Class Initialized
INFO - 2023-04-07 02:02:54 --> Loader Class Initialized
INFO - 2023-04-07 02:02:54 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:54 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:54 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:54 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:54 --> Total execution time: 0.0878
INFO - 2023-04-07 02:02:57 --> Config Class Initialized
INFO - 2023-04-07 02:02:57 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:57 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:57 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:57 --> URI Class Initialized
INFO - 2023-04-07 02:02:57 --> Router Class Initialized
INFO - 2023-04-07 02:02:57 --> Output Class Initialized
INFO - 2023-04-07 02:02:57 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:57 --> Input Class Initialized
INFO - 2023-04-07 02:02:57 --> Language Class Initialized
INFO - 2023-04-07 02:02:57 --> Loader Class Initialized
INFO - 2023-04-07 02:02:57 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:57 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:57 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:57 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:57 --> Total execution time: 0.0258
INFO - 2023-04-07 02:02:57 --> Config Class Initialized
INFO - 2023-04-07 02:02:57 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:57 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:57 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:57 --> URI Class Initialized
INFO - 2023-04-07 02:02:57 --> Router Class Initialized
INFO - 2023-04-07 02:02:57 --> Output Class Initialized
INFO - 2023-04-07 02:02:57 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:57 --> Input Class Initialized
INFO - 2023-04-07 02:02:57 --> Language Class Initialized
INFO - 2023-04-07 02:02:57 --> Loader Class Initialized
INFO - 2023-04-07 02:02:57 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:57 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:57 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:57 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:57 --> Total execution time: 0.0215
INFO - 2023-04-07 02:02:58 --> Config Class Initialized
INFO - 2023-04-07 02:02:58 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:58 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:58 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:58 --> URI Class Initialized
INFO - 2023-04-07 02:02:58 --> Router Class Initialized
INFO - 2023-04-07 02:02:58 --> Output Class Initialized
INFO - 2023-04-07 02:02:58 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:58 --> Input Class Initialized
INFO - 2023-04-07 02:02:58 --> Language Class Initialized
INFO - 2023-04-07 02:02:58 --> Loader Class Initialized
INFO - 2023-04-07 02:02:58 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:58 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:58 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:58 --> Total execution time: 0.0516
INFO - 2023-04-07 02:02:58 --> Config Class Initialized
INFO - 2023-04-07 02:02:58 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:02:58 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:02:58 --> Utf8 Class Initialized
INFO - 2023-04-07 02:02:58 --> URI Class Initialized
INFO - 2023-04-07 02:02:58 --> Router Class Initialized
INFO - 2023-04-07 02:02:58 --> Output Class Initialized
INFO - 2023-04-07 02:02:58 --> Security Class Initialized
DEBUG - 2023-04-07 02:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:02:58 --> Input Class Initialized
INFO - 2023-04-07 02:02:58 --> Language Class Initialized
INFO - 2023-04-07 02:02:58 --> Loader Class Initialized
INFO - 2023-04-07 02:02:58 --> Controller Class Initialized
DEBUG - 2023-04-07 02:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:02:58 --> Database Driver Class Initialized
INFO - 2023-04-07 02:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:02:58 --> Final output sent to browser
DEBUG - 2023-04-07 02:02:58 --> Total execution time: 0.0416
INFO - 2023-04-07 02:03:02 --> Config Class Initialized
INFO - 2023-04-07 02:03:02 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:02 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:02 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:02 --> URI Class Initialized
INFO - 2023-04-07 02:03:02 --> Router Class Initialized
INFO - 2023-04-07 02:03:02 --> Output Class Initialized
INFO - 2023-04-07 02:03:02 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:02 --> Input Class Initialized
INFO - 2023-04-07 02:03:02 --> Language Class Initialized
INFO - 2023-04-07 02:03:02 --> Loader Class Initialized
INFO - 2023-04-07 02:03:02 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:02 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:02 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:02 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:02 --> Total execution time: 0.0159
INFO - 2023-04-07 02:03:02 --> Config Class Initialized
INFO - 2023-04-07 02:03:02 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:02 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:02 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:02 --> URI Class Initialized
INFO - 2023-04-07 02:03:02 --> Router Class Initialized
INFO - 2023-04-07 02:03:02 --> Output Class Initialized
INFO - 2023-04-07 02:03:02 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:02 --> Input Class Initialized
INFO - 2023-04-07 02:03:02 --> Language Class Initialized
INFO - 2023-04-07 02:03:02 --> Loader Class Initialized
INFO - 2023-04-07 02:03:02 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:02 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:02 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:02 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:02 --> Total execution time: 0.0134
INFO - 2023-04-07 02:03:03 --> Config Class Initialized
INFO - 2023-04-07 02:03:03 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:03 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:03 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:03 --> URI Class Initialized
INFO - 2023-04-07 02:03:03 --> Router Class Initialized
INFO - 2023-04-07 02:03:03 --> Output Class Initialized
INFO - 2023-04-07 02:03:03 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:03 --> Input Class Initialized
INFO - 2023-04-07 02:03:03 --> Language Class Initialized
INFO - 2023-04-07 02:03:03 --> Loader Class Initialized
INFO - 2023-04-07 02:03:03 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:03 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:03 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:03 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:03 --> Total execution time: 0.0156
INFO - 2023-04-07 02:03:03 --> Config Class Initialized
INFO - 2023-04-07 02:03:03 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:03 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:03 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:03 --> URI Class Initialized
INFO - 2023-04-07 02:03:03 --> Router Class Initialized
INFO - 2023-04-07 02:03:03 --> Output Class Initialized
INFO - 2023-04-07 02:03:03 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:03 --> Input Class Initialized
INFO - 2023-04-07 02:03:03 --> Language Class Initialized
INFO - 2023-04-07 02:03:03 --> Loader Class Initialized
INFO - 2023-04-07 02:03:03 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:03 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:03 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:03 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:03 --> Total execution time: 0.0110
INFO - 2023-04-07 02:03:03 --> Config Class Initialized
INFO - 2023-04-07 02:03:03 --> Config Class Initialized
INFO - 2023-04-07 02:03:03 --> Hooks Class Initialized
INFO - 2023-04-07 02:03:03 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-07 02:03:03 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:03 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:03 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:03 --> URI Class Initialized
INFO - 2023-04-07 02:03:03 --> URI Class Initialized
INFO - 2023-04-07 02:03:03 --> Router Class Initialized
INFO - 2023-04-07 02:03:03 --> Router Class Initialized
INFO - 2023-04-07 02:03:03 --> Output Class Initialized
INFO - 2023-04-07 02:03:03 --> Output Class Initialized
INFO - 2023-04-07 02:03:03 --> Security Class Initialized
INFO - 2023-04-07 02:03:03 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-07 02:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:03 --> Input Class Initialized
INFO - 2023-04-07 02:03:03 --> Input Class Initialized
INFO - 2023-04-07 02:03:03 --> Language Class Initialized
INFO - 2023-04-07 02:03:03 --> Language Class Initialized
INFO - 2023-04-07 02:03:03 --> Loader Class Initialized
INFO - 2023-04-07 02:03:03 --> Loader Class Initialized
INFO - 2023-04-07 02:03:03 --> Controller Class Initialized
INFO - 2023-04-07 02:03:03 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-07 02:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:03 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:03 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:03 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:03 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:03 --> Final output sent to browser
INFO - 2023-04-07 02:03:03 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:03 --> Total execution time: 0.0344
DEBUG - 2023-04-07 02:03:03 --> Total execution time: 0.0344
INFO - 2023-04-07 02:03:03 --> Config Class Initialized
INFO - 2023-04-07 02:03:03 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:03 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:03 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:03 --> URI Class Initialized
INFO - 2023-04-07 02:03:03 --> Router Class Initialized
INFO - 2023-04-07 02:03:03 --> Output Class Initialized
INFO - 2023-04-07 02:03:03 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:03 --> Input Class Initialized
INFO - 2023-04-07 02:03:03 --> Language Class Initialized
INFO - 2023-04-07 02:03:03 --> Loader Class Initialized
INFO - 2023-04-07 02:03:03 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:03 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:03 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:03 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:03 --> Total execution time: 0.0108
INFO - 2023-04-07 02:03:04 --> Config Class Initialized
INFO - 2023-04-07 02:03:04 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:04 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:04 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:04 --> URI Class Initialized
INFO - 2023-04-07 02:03:04 --> Router Class Initialized
INFO - 2023-04-07 02:03:04 --> Output Class Initialized
INFO - 2023-04-07 02:03:04 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:04 --> Input Class Initialized
INFO - 2023-04-07 02:03:04 --> Language Class Initialized
INFO - 2023-04-07 02:03:04 --> Loader Class Initialized
INFO - 2023-04-07 02:03:04 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:04 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:04 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:04 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:04 --> Total execution time: 0.0215
INFO - 2023-04-07 02:03:04 --> Config Class Initialized
INFO - 2023-04-07 02:03:04 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:04 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:04 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:04 --> URI Class Initialized
INFO - 2023-04-07 02:03:04 --> Router Class Initialized
INFO - 2023-04-07 02:03:04 --> Output Class Initialized
INFO - 2023-04-07 02:03:04 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:04 --> Input Class Initialized
INFO - 2023-04-07 02:03:04 --> Language Class Initialized
INFO - 2023-04-07 02:03:04 --> Loader Class Initialized
INFO - 2023-04-07 02:03:04 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:04 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:04 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:04 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:04 --> Total execution time: 0.0178
INFO - 2023-04-07 02:03:04 --> Config Class Initialized
INFO - 2023-04-07 02:03:04 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:04 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:04 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:04 --> URI Class Initialized
INFO - 2023-04-07 02:03:04 --> Router Class Initialized
INFO - 2023-04-07 02:03:04 --> Output Class Initialized
INFO - 2023-04-07 02:03:04 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:04 --> Input Class Initialized
INFO - 2023-04-07 02:03:04 --> Language Class Initialized
INFO - 2023-04-07 02:03:04 --> Loader Class Initialized
INFO - 2023-04-07 02:03:04 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:04 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:04 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:04 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:04 --> Total execution time: 0.0172
INFO - 2023-04-07 02:03:04 --> Config Class Initialized
INFO - 2023-04-07 02:03:04 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:04 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:04 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:04 --> URI Class Initialized
INFO - 2023-04-07 02:03:04 --> Router Class Initialized
INFO - 2023-04-07 02:03:04 --> Output Class Initialized
INFO - 2023-04-07 02:03:04 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:04 --> Input Class Initialized
INFO - 2023-04-07 02:03:04 --> Language Class Initialized
INFO - 2023-04-07 02:03:04 --> Loader Class Initialized
INFO - 2023-04-07 02:03:04 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:04 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:05 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:05 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:05 --> Total execution time: 0.0112
INFO - 2023-04-07 02:03:22 --> Config Class Initialized
INFO - 2023-04-07 02:03:22 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:22 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:22 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:22 --> URI Class Initialized
INFO - 2023-04-07 02:03:22 --> Router Class Initialized
INFO - 2023-04-07 02:03:22 --> Output Class Initialized
INFO - 2023-04-07 02:03:22 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:22 --> Input Class Initialized
INFO - 2023-04-07 02:03:22 --> Language Class Initialized
INFO - 2023-04-07 02:03:22 --> Loader Class Initialized
INFO - 2023-04-07 02:03:22 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:22 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:22 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:22 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:22 --> Total execution time: 0.0146
INFO - 2023-04-07 02:03:22 --> Config Class Initialized
INFO - 2023-04-07 02:03:22 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:22 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:22 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:22 --> URI Class Initialized
INFO - 2023-04-07 02:03:22 --> Router Class Initialized
INFO - 2023-04-07 02:03:22 --> Output Class Initialized
INFO - 2023-04-07 02:03:22 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:22 --> Input Class Initialized
INFO - 2023-04-07 02:03:22 --> Language Class Initialized
INFO - 2023-04-07 02:03:22 --> Loader Class Initialized
INFO - 2023-04-07 02:03:22 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:22 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:22 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:22 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:22 --> Total execution time: 0.0096
INFO - 2023-04-07 02:03:23 --> Config Class Initialized
INFO - 2023-04-07 02:03:23 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:23 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:23 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:23 --> URI Class Initialized
INFO - 2023-04-07 02:03:23 --> Router Class Initialized
INFO - 2023-04-07 02:03:23 --> Output Class Initialized
INFO - 2023-04-07 02:03:23 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:23 --> Input Class Initialized
INFO - 2023-04-07 02:03:23 --> Language Class Initialized
INFO - 2023-04-07 02:03:23 --> Loader Class Initialized
INFO - 2023-04-07 02:03:23 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:23 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:23 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:23 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:23 --> Total execution time: 0.0170
INFO - 2023-04-07 02:03:23 --> Config Class Initialized
INFO - 2023-04-07 02:03:23 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:23 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:23 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:23 --> URI Class Initialized
INFO - 2023-04-07 02:03:23 --> Router Class Initialized
INFO - 2023-04-07 02:03:23 --> Output Class Initialized
INFO - 2023-04-07 02:03:23 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:23 --> Input Class Initialized
INFO - 2023-04-07 02:03:23 --> Language Class Initialized
INFO - 2023-04-07 02:03:23 --> Loader Class Initialized
INFO - 2023-04-07 02:03:23 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:23 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:23 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:23 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:23 --> Total execution time: 0.0122
INFO - 2023-04-07 02:03:24 --> Config Class Initialized
INFO - 2023-04-07 02:03:24 --> Config Class Initialized
INFO - 2023-04-07 02:03:24 --> Hooks Class Initialized
INFO - 2023-04-07 02:03:24 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:24 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:24 --> Utf8 Class Initialized
DEBUG - 2023-04-07 02:03:24 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:24 --> URI Class Initialized
INFO - 2023-04-07 02:03:24 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:24 --> Router Class Initialized
INFO - 2023-04-07 02:03:24 --> URI Class Initialized
INFO - 2023-04-07 02:03:24 --> Output Class Initialized
INFO - 2023-04-07 02:03:24 --> Router Class Initialized
INFO - 2023-04-07 02:03:24 --> Security Class Initialized
INFO - 2023-04-07 02:03:24 --> Output Class Initialized
DEBUG - 2023-04-07 02:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:24 --> Security Class Initialized
INFO - 2023-04-07 02:03:24 --> Input Class Initialized
INFO - 2023-04-07 02:03:24 --> Language Class Initialized
DEBUG - 2023-04-07 02:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:24 --> Input Class Initialized
INFO - 2023-04-07 02:03:24 --> Loader Class Initialized
INFO - 2023-04-07 02:03:24 --> Language Class Initialized
INFO - 2023-04-07 02:03:24 --> Controller Class Initialized
INFO - 2023-04-07 02:03:24 --> Loader Class Initialized
DEBUG - 2023-04-07 02:03:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:24 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:24 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:24 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:24 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:24 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:24 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:24 --> Total execution time: 0.0156
INFO - 2023-04-07 02:03:24 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:24 --> Total execution time: 0.0173
INFO - 2023-04-07 02:03:24 --> Config Class Initialized
INFO - 2023-04-07 02:03:24 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:24 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:24 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:24 --> URI Class Initialized
INFO - 2023-04-07 02:03:24 --> Router Class Initialized
INFO - 2023-04-07 02:03:24 --> Output Class Initialized
INFO - 2023-04-07 02:03:24 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:24 --> Input Class Initialized
INFO - 2023-04-07 02:03:24 --> Language Class Initialized
INFO - 2023-04-07 02:03:24 --> Loader Class Initialized
INFO - 2023-04-07 02:03:24 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:24 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:24 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:24 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:24 --> Total execution time: 0.0103
INFO - 2023-04-07 02:03:25 --> Config Class Initialized
INFO - 2023-04-07 02:03:25 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:25 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:25 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:25 --> URI Class Initialized
INFO - 2023-04-07 02:03:25 --> Router Class Initialized
INFO - 2023-04-07 02:03:25 --> Output Class Initialized
INFO - 2023-04-07 02:03:25 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:25 --> Input Class Initialized
INFO - 2023-04-07 02:03:25 --> Language Class Initialized
INFO - 2023-04-07 02:03:25 --> Loader Class Initialized
INFO - 2023-04-07 02:03:25 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:25 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:25 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:25 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:25 --> Total execution time: 0.0200
INFO - 2023-04-07 02:03:25 --> Config Class Initialized
INFO - 2023-04-07 02:03:25 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:25 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:25 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:25 --> URI Class Initialized
INFO - 2023-04-07 02:03:25 --> Router Class Initialized
INFO - 2023-04-07 02:03:25 --> Output Class Initialized
INFO - 2023-04-07 02:03:25 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:25 --> Input Class Initialized
INFO - 2023-04-07 02:03:25 --> Language Class Initialized
INFO - 2023-04-07 02:03:25 --> Loader Class Initialized
INFO - 2023-04-07 02:03:25 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:25 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:25 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:25 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:25 --> Total execution time: 0.0196
INFO - 2023-04-07 02:03:26 --> Config Class Initialized
INFO - 2023-04-07 02:03:26 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:03:26 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:03:26 --> Utf8 Class Initialized
INFO - 2023-04-07 02:03:26 --> URI Class Initialized
INFO - 2023-04-07 02:03:26 --> Router Class Initialized
INFO - 2023-04-07 02:03:26 --> Output Class Initialized
INFO - 2023-04-07 02:03:26 --> Security Class Initialized
DEBUG - 2023-04-07 02:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:03:26 --> Input Class Initialized
INFO - 2023-04-07 02:03:26 --> Language Class Initialized
INFO - 2023-04-07 02:03:26 --> Loader Class Initialized
INFO - 2023-04-07 02:03:26 --> Controller Class Initialized
DEBUG - 2023-04-07 02:03:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:03:26 --> Database Driver Class Initialized
INFO - 2023-04-07 02:03:26 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:03:26 --> Final output sent to browser
DEBUG - 2023-04-07 02:03:26 --> Total execution time: 0.0127
INFO - 2023-04-07 02:04:32 --> Config Class Initialized
INFO - 2023-04-07 02:04:32 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:04:32 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:04:32 --> Utf8 Class Initialized
INFO - 2023-04-07 02:04:32 --> URI Class Initialized
INFO - 2023-04-07 02:04:32 --> Router Class Initialized
INFO - 2023-04-07 02:04:32 --> Output Class Initialized
INFO - 2023-04-07 02:04:32 --> Security Class Initialized
DEBUG - 2023-04-07 02:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:04:32 --> Input Class Initialized
INFO - 2023-04-07 02:04:32 --> Language Class Initialized
INFO - 2023-04-07 02:04:32 --> Loader Class Initialized
INFO - 2023-04-07 02:04:32 --> Controller Class Initialized
DEBUG - 2023-04-07 02:04:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:04:32 --> Database Driver Class Initialized
INFO - 2023-04-07 02:04:32 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:04:32 --> Final output sent to browser
DEBUG - 2023-04-07 02:04:32 --> Total execution time: 0.0194
INFO - 2023-04-07 02:04:32 --> Config Class Initialized
INFO - 2023-04-07 02:04:32 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:04:32 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:04:32 --> Utf8 Class Initialized
INFO - 2023-04-07 02:04:32 --> URI Class Initialized
INFO - 2023-04-07 02:04:32 --> Router Class Initialized
INFO - 2023-04-07 02:04:32 --> Output Class Initialized
INFO - 2023-04-07 02:04:32 --> Security Class Initialized
DEBUG - 2023-04-07 02:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:04:32 --> Input Class Initialized
INFO - 2023-04-07 02:04:32 --> Language Class Initialized
INFO - 2023-04-07 02:04:32 --> Loader Class Initialized
INFO - 2023-04-07 02:04:32 --> Controller Class Initialized
DEBUG - 2023-04-07 02:04:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:04:32 --> Database Driver Class Initialized
INFO - 2023-04-07 02:04:32 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:04:32 --> Final output sent to browser
DEBUG - 2023-04-07 02:04:32 --> Total execution time: 0.0559
INFO - 2023-04-07 02:04:34 --> Config Class Initialized
INFO - 2023-04-07 02:04:34 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:04:34 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:04:34 --> Utf8 Class Initialized
INFO - 2023-04-07 02:04:34 --> URI Class Initialized
INFO - 2023-04-07 02:04:34 --> Router Class Initialized
INFO - 2023-04-07 02:04:34 --> Output Class Initialized
INFO - 2023-04-07 02:04:34 --> Security Class Initialized
DEBUG - 2023-04-07 02:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:04:34 --> Input Class Initialized
INFO - 2023-04-07 02:04:34 --> Language Class Initialized
INFO - 2023-04-07 02:04:34 --> Loader Class Initialized
INFO - 2023-04-07 02:04:34 --> Controller Class Initialized
DEBUG - 2023-04-07 02:04:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:04:34 --> Database Driver Class Initialized
INFO - 2023-04-07 02:04:34 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:04:34 --> Final output sent to browser
DEBUG - 2023-04-07 02:04:34 --> Total execution time: 0.0186
INFO - 2023-04-07 02:04:34 --> Config Class Initialized
INFO - 2023-04-07 02:04:34 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:04:34 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:04:34 --> Utf8 Class Initialized
INFO - 2023-04-07 02:04:34 --> URI Class Initialized
INFO - 2023-04-07 02:04:34 --> Router Class Initialized
INFO - 2023-04-07 02:04:34 --> Output Class Initialized
INFO - 2023-04-07 02:04:34 --> Security Class Initialized
DEBUG - 2023-04-07 02:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:04:34 --> Input Class Initialized
INFO - 2023-04-07 02:04:34 --> Language Class Initialized
INFO - 2023-04-07 02:04:34 --> Loader Class Initialized
INFO - 2023-04-07 02:04:34 --> Controller Class Initialized
DEBUG - 2023-04-07 02:04:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:04:34 --> Database Driver Class Initialized
INFO - 2023-04-07 02:04:34 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:04:34 --> Final output sent to browser
DEBUG - 2023-04-07 02:04:34 --> Total execution time: 0.0538
INFO - 2023-04-07 02:05:31 --> Config Class Initialized
INFO - 2023-04-07 02:05:31 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:05:31 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:05:31 --> Utf8 Class Initialized
INFO - 2023-04-07 02:05:31 --> URI Class Initialized
INFO - 2023-04-07 02:05:31 --> Router Class Initialized
INFO - 2023-04-07 02:05:31 --> Output Class Initialized
INFO - 2023-04-07 02:05:31 --> Security Class Initialized
DEBUG - 2023-04-07 02:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:05:31 --> Input Class Initialized
INFO - 2023-04-07 02:05:31 --> Language Class Initialized
INFO - 2023-04-07 02:05:31 --> Loader Class Initialized
INFO - 2023-04-07 02:05:31 --> Controller Class Initialized
DEBUG - 2023-04-07 02:05:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:05:31 --> Database Driver Class Initialized
INFO - 2023-04-07 02:05:31 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:05:31 --> Final output sent to browser
DEBUG - 2023-04-07 02:05:31 --> Total execution time: 0.0447
INFO - 2023-04-07 02:05:31 --> Config Class Initialized
INFO - 2023-04-07 02:05:31 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:05:31 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:05:31 --> Utf8 Class Initialized
INFO - 2023-04-07 02:05:31 --> URI Class Initialized
INFO - 2023-04-07 02:05:31 --> Router Class Initialized
INFO - 2023-04-07 02:05:31 --> Output Class Initialized
INFO - 2023-04-07 02:05:31 --> Security Class Initialized
DEBUG - 2023-04-07 02:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:05:31 --> Input Class Initialized
INFO - 2023-04-07 02:05:31 --> Language Class Initialized
INFO - 2023-04-07 02:05:31 --> Loader Class Initialized
INFO - 2023-04-07 02:05:31 --> Controller Class Initialized
DEBUG - 2023-04-07 02:05:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:05:31 --> Database Driver Class Initialized
INFO - 2023-04-07 02:05:31 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:05:31 --> Final output sent to browser
DEBUG - 2023-04-07 02:05:31 --> Total execution time: 0.4493
INFO - 2023-04-07 02:05:34 --> Config Class Initialized
INFO - 2023-04-07 02:05:34 --> Config Class Initialized
INFO - 2023-04-07 02:05:34 --> Hooks Class Initialized
INFO - 2023-04-07 02:05:34 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:05:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-07 02:05:34 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:05:34 --> Utf8 Class Initialized
INFO - 2023-04-07 02:05:34 --> Utf8 Class Initialized
INFO - 2023-04-07 02:05:34 --> URI Class Initialized
INFO - 2023-04-07 02:05:34 --> URI Class Initialized
INFO - 2023-04-07 02:05:34 --> Router Class Initialized
INFO - 2023-04-07 02:05:34 --> Router Class Initialized
INFO - 2023-04-07 02:05:34 --> Output Class Initialized
INFO - 2023-04-07 02:05:34 --> Output Class Initialized
INFO - 2023-04-07 02:05:34 --> Security Class Initialized
INFO - 2023-04-07 02:05:34 --> Security Class Initialized
DEBUG - 2023-04-07 02:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-07 02:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:05:34 --> Input Class Initialized
INFO - 2023-04-07 02:05:34 --> Input Class Initialized
INFO - 2023-04-07 02:05:34 --> Language Class Initialized
INFO - 2023-04-07 02:05:34 --> Language Class Initialized
INFO - 2023-04-07 02:05:34 --> Loader Class Initialized
INFO - 2023-04-07 02:05:34 --> Controller Class Initialized
DEBUG - 2023-04-07 02:05:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:05:34 --> Database Driver Class Initialized
INFO - 2023-04-07 02:05:34 --> Loader Class Initialized
INFO - 2023-04-07 02:05:34 --> Controller Class Initialized
DEBUG - 2023-04-07 02:05:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:05:34 --> Final output sent to browser
DEBUG - 2023-04-07 02:05:34 --> Total execution time: 0.0061
INFO - 2023-04-07 02:05:34 --> Config Class Initialized
INFO - 2023-04-07 02:05:34 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:05:34 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:05:34 --> Utf8 Class Initialized
INFO - 2023-04-07 02:05:34 --> URI Class Initialized
INFO - 2023-04-07 02:05:34 --> Router Class Initialized
INFO - 2023-04-07 02:05:34 --> Output Class Initialized
INFO - 2023-04-07 02:05:34 --> Security Class Initialized
DEBUG - 2023-04-07 02:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:05:34 --> Input Class Initialized
INFO - 2023-04-07 02:05:34 --> Language Class Initialized
INFO - 2023-04-07 02:05:34 --> Loader Class Initialized
INFO - 2023-04-07 02:05:34 --> Controller Class Initialized
DEBUG - 2023-04-07 02:05:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:05:34 --> Database Driver Class Initialized
INFO - 2023-04-07 02:05:34 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:05:34 --> Model "Login_model" initialized
INFO - 2023-04-07 02:05:34 --> Database Driver Class Initialized
INFO - 2023-04-07 02:05:34 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:05:34 --> Final output sent to browser
DEBUG - 2023-04-07 02:05:34 --> Total execution time: 0.0287
INFO - 2023-04-07 02:05:34 --> Final output sent to browser
DEBUG - 2023-04-07 02:05:34 --> Total execution time: 0.0372
INFO - 2023-04-07 02:05:34 --> Config Class Initialized
INFO - 2023-04-07 02:05:34 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:05:34 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:05:34 --> Utf8 Class Initialized
INFO - 2023-04-07 02:05:34 --> URI Class Initialized
INFO - 2023-04-07 02:05:34 --> Router Class Initialized
INFO - 2023-04-07 02:05:34 --> Output Class Initialized
INFO - 2023-04-07 02:05:34 --> Security Class Initialized
DEBUG - 2023-04-07 02:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:05:34 --> Input Class Initialized
INFO - 2023-04-07 02:05:34 --> Language Class Initialized
INFO - 2023-04-07 02:05:34 --> Loader Class Initialized
INFO - 2023-04-07 02:05:34 --> Controller Class Initialized
DEBUG - 2023-04-07 02:05:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:05:34 --> Database Driver Class Initialized
INFO - 2023-04-07 02:05:34 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:05:34 --> Final output sent to browser
DEBUG - 2023-04-07 02:05:34 --> Total execution time: 0.0666
INFO - 2023-04-07 02:05:37 --> Config Class Initialized
INFO - 2023-04-07 02:05:37 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:05:37 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:05:37 --> Utf8 Class Initialized
INFO - 2023-04-07 02:05:37 --> URI Class Initialized
INFO - 2023-04-07 02:05:37 --> Router Class Initialized
INFO - 2023-04-07 02:05:37 --> Output Class Initialized
INFO - 2023-04-07 02:05:37 --> Security Class Initialized
DEBUG - 2023-04-07 02:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:05:37 --> Input Class Initialized
INFO - 2023-04-07 02:05:37 --> Language Class Initialized
INFO - 2023-04-07 02:05:37 --> Loader Class Initialized
INFO - 2023-04-07 02:05:37 --> Controller Class Initialized
DEBUG - 2023-04-07 02:05:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:05:37 --> Database Driver Class Initialized
INFO - 2023-04-07 02:05:37 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:05:37 --> Database Driver Class Initialized
INFO - 2023-04-07 02:05:37 --> Model "Login_model" initialized
INFO - 2023-04-07 02:05:37 --> Final output sent to browser
DEBUG - 2023-04-07 02:05:37 --> Total execution time: 0.0617
INFO - 2023-04-07 02:05:37 --> Config Class Initialized
INFO - 2023-04-07 02:05:37 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:05:37 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:05:37 --> Utf8 Class Initialized
INFO - 2023-04-07 02:05:37 --> URI Class Initialized
INFO - 2023-04-07 02:05:37 --> Router Class Initialized
INFO - 2023-04-07 02:05:37 --> Output Class Initialized
INFO - 2023-04-07 02:05:37 --> Security Class Initialized
DEBUG - 2023-04-07 02:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:05:37 --> Input Class Initialized
INFO - 2023-04-07 02:05:37 --> Language Class Initialized
INFO - 2023-04-07 02:05:37 --> Loader Class Initialized
INFO - 2023-04-07 02:05:37 --> Controller Class Initialized
DEBUG - 2023-04-07 02:05:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:05:37 --> Database Driver Class Initialized
INFO - 2023-04-07 02:05:38 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:05:38 --> Database Driver Class Initialized
INFO - 2023-04-07 02:05:38 --> Model "Login_model" initialized
INFO - 2023-04-07 02:05:38 --> Final output sent to browser
DEBUG - 2023-04-07 02:05:38 --> Total execution time: 0.0976
INFO - 2023-04-07 02:05:43 --> Config Class Initialized
INFO - 2023-04-07 02:05:43 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:05:43 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:05:43 --> Utf8 Class Initialized
INFO - 2023-04-07 02:05:43 --> URI Class Initialized
INFO - 2023-04-07 02:05:43 --> Router Class Initialized
INFO - 2023-04-07 02:05:43 --> Output Class Initialized
INFO - 2023-04-07 02:05:43 --> Security Class Initialized
DEBUG - 2023-04-07 02:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:05:43 --> Input Class Initialized
INFO - 2023-04-07 02:05:43 --> Language Class Initialized
INFO - 2023-04-07 02:05:43 --> Loader Class Initialized
INFO - 2023-04-07 02:05:43 --> Controller Class Initialized
DEBUG - 2023-04-07 02:05:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:05:43 --> Database Driver Class Initialized
INFO - 2023-04-07 02:05:43 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:05:43 --> Final output sent to browser
DEBUG - 2023-04-07 02:05:43 --> Total execution time: 0.0144
INFO - 2023-04-07 02:05:43 --> Config Class Initialized
INFO - 2023-04-07 02:05:43 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:05:43 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:05:43 --> Utf8 Class Initialized
INFO - 2023-04-07 02:05:43 --> URI Class Initialized
INFO - 2023-04-07 02:05:43 --> Router Class Initialized
INFO - 2023-04-07 02:05:43 --> Output Class Initialized
INFO - 2023-04-07 02:05:43 --> Security Class Initialized
DEBUG - 2023-04-07 02:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:05:43 --> Input Class Initialized
INFO - 2023-04-07 02:05:43 --> Language Class Initialized
INFO - 2023-04-07 02:05:43 --> Loader Class Initialized
INFO - 2023-04-07 02:05:43 --> Controller Class Initialized
DEBUG - 2023-04-07 02:05:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:05:43 --> Database Driver Class Initialized
INFO - 2023-04-07 02:05:43 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:05:43 --> Final output sent to browser
DEBUG - 2023-04-07 02:05:43 --> Total execution time: 0.0555
INFO - 2023-04-07 02:19:19 --> Config Class Initialized
INFO - 2023-04-07 02:19:19 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:19 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:19 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:19 --> URI Class Initialized
INFO - 2023-04-07 02:19:19 --> Router Class Initialized
INFO - 2023-04-07 02:19:19 --> Output Class Initialized
INFO - 2023-04-07 02:19:19 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:19 --> Input Class Initialized
INFO - 2023-04-07 02:19:19 --> Language Class Initialized
INFO - 2023-04-07 02:19:19 --> Loader Class Initialized
INFO - 2023-04-07 02:19:19 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:19 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:19 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:19 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:19 --> Total execution time: 0.1007
INFO - 2023-04-07 02:19:19 --> Config Class Initialized
INFO - 2023-04-07 02:19:19 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:19 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:19 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:19 --> URI Class Initialized
INFO - 2023-04-07 02:19:19 --> Router Class Initialized
INFO - 2023-04-07 02:19:19 --> Output Class Initialized
INFO - 2023-04-07 02:19:19 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:19 --> Input Class Initialized
INFO - 2023-04-07 02:19:19 --> Language Class Initialized
INFO - 2023-04-07 02:19:19 --> Loader Class Initialized
INFO - 2023-04-07 02:19:19 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:19 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:19 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:19 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:19 --> Total execution time: 0.0950
INFO - 2023-04-07 02:19:21 --> Config Class Initialized
INFO - 2023-04-07 02:19:21 --> Config Class Initialized
INFO - 2023-04-07 02:19:21 --> Hooks Class Initialized
INFO - 2023-04-07 02:19:21 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-07 02:19:21 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:21 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:21 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:21 --> URI Class Initialized
INFO - 2023-04-07 02:19:21 --> URI Class Initialized
INFO - 2023-04-07 02:19:21 --> Router Class Initialized
INFO - 2023-04-07 02:19:21 --> Router Class Initialized
INFO - 2023-04-07 02:19:21 --> Output Class Initialized
INFO - 2023-04-07 02:19:21 --> Output Class Initialized
INFO - 2023-04-07 02:19:21 --> Security Class Initialized
INFO - 2023-04-07 02:19:21 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-07 02:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:21 --> Input Class Initialized
INFO - 2023-04-07 02:19:21 --> Input Class Initialized
INFO - 2023-04-07 02:19:21 --> Language Class Initialized
INFO - 2023-04-07 02:19:21 --> Language Class Initialized
INFO - 2023-04-07 02:19:21 --> Loader Class Initialized
INFO - 2023-04-07 02:19:21 --> Loader Class Initialized
INFO - 2023-04-07 02:19:21 --> Controller Class Initialized
INFO - 2023-04-07 02:19:21 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-07 02:19:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:21 --> Final output sent to browser
INFO - 2023-04-07 02:19:21 --> Database Driver Class Initialized
DEBUG - 2023-04-07 02:19:21 --> Total execution time: 0.0284
INFO - 2023-04-07 02:19:21 --> Config Class Initialized
INFO - 2023-04-07 02:19:21 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:21 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:21 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:21 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:21 --> URI Class Initialized
INFO - 2023-04-07 02:19:21 --> Router Class Initialized
INFO - 2023-04-07 02:19:21 --> Output Class Initialized
INFO - 2023-04-07 02:19:21 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:21 --> Input Class Initialized
INFO - 2023-04-07 02:19:21 --> Language Class Initialized
INFO - 2023-04-07 02:19:21 --> Loader Class Initialized
INFO - 2023-04-07 02:19:21 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:21 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:21 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:21 --> Total execution time: 0.0801
INFO - 2023-04-07 02:19:21 --> Config Class Initialized
INFO - 2023-04-07 02:19:21 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:21 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:21 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:21 --> URI Class Initialized
INFO - 2023-04-07 02:19:21 --> Router Class Initialized
INFO - 2023-04-07 02:19:21 --> Output Class Initialized
INFO - 2023-04-07 02:19:21 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:21 --> Input Class Initialized
INFO - 2023-04-07 02:19:21 --> Language Class Initialized
INFO - 2023-04-07 02:19:21 --> Loader Class Initialized
INFO - 2023-04-07 02:19:21 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:21 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:21 --> Model "Login_model" initialized
INFO - 2023-04-07 02:19:21 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:21 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:21 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:21 --> Total execution time: 0.0157
INFO - 2023-04-07 02:19:21 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:21 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:21 --> Total execution time: 0.0673
INFO - 2023-04-07 02:19:25 --> Config Class Initialized
INFO - 2023-04-07 02:19:25 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:25 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:25 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:25 --> URI Class Initialized
INFO - 2023-04-07 02:19:25 --> Router Class Initialized
INFO - 2023-04-07 02:19:25 --> Output Class Initialized
INFO - 2023-04-07 02:19:25 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:25 --> Input Class Initialized
INFO - 2023-04-07 02:19:25 --> Language Class Initialized
INFO - 2023-04-07 02:19:25 --> Loader Class Initialized
INFO - 2023-04-07 02:19:25 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:25 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:25 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:25 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:25 --> Model "Login_model" initialized
INFO - 2023-04-07 02:19:25 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:25 --> Total execution time: 0.0682
INFO - 2023-04-07 02:19:25 --> Config Class Initialized
INFO - 2023-04-07 02:19:25 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:25 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:25 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:25 --> URI Class Initialized
INFO - 2023-04-07 02:19:25 --> Router Class Initialized
INFO - 2023-04-07 02:19:25 --> Output Class Initialized
INFO - 2023-04-07 02:19:25 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:25 --> Input Class Initialized
INFO - 2023-04-07 02:19:25 --> Language Class Initialized
INFO - 2023-04-07 02:19:25 --> Loader Class Initialized
INFO - 2023-04-07 02:19:25 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:25 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:25 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:25 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:25 --> Model "Login_model" initialized
INFO - 2023-04-07 02:19:25 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:25 --> Total execution time: 0.0650
INFO - 2023-04-07 02:19:26 --> Config Class Initialized
INFO - 2023-04-07 02:19:26 --> Config Class Initialized
INFO - 2023-04-07 02:19:26 --> Hooks Class Initialized
INFO - 2023-04-07 02:19:26 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-07 02:19:26 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:26 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:26 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:26 --> URI Class Initialized
INFO - 2023-04-07 02:19:26 --> URI Class Initialized
INFO - 2023-04-07 02:19:26 --> Router Class Initialized
INFO - 2023-04-07 02:19:26 --> Router Class Initialized
INFO - 2023-04-07 02:19:26 --> Output Class Initialized
INFO - 2023-04-07 02:19:26 --> Output Class Initialized
INFO - 2023-04-07 02:19:26 --> Security Class Initialized
INFO - 2023-04-07 02:19:26 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-07 02:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:26 --> Input Class Initialized
INFO - 2023-04-07 02:19:26 --> Input Class Initialized
INFO - 2023-04-07 02:19:26 --> Language Class Initialized
INFO - 2023-04-07 02:19:26 --> Language Class Initialized
INFO - 2023-04-07 02:19:26 --> Loader Class Initialized
INFO - 2023-04-07 02:19:26 --> Loader Class Initialized
INFO - 2023-04-07 02:19:26 --> Controller Class Initialized
INFO - 2023-04-07 02:19:26 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-07 02:19:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:26 --> Final output sent to browser
INFO - 2023-04-07 02:19:26 --> Database Driver Class Initialized
DEBUG - 2023-04-07 02:19:26 --> Total execution time: 0.0049
INFO - 2023-04-07 02:19:26 --> Config Class Initialized
INFO - 2023-04-07 02:19:26 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:26 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:26 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:26 --> URI Class Initialized
INFO - 2023-04-07 02:19:26 --> Router Class Initialized
INFO - 2023-04-07 02:19:26 --> Output Class Initialized
INFO - 2023-04-07 02:19:26 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:26 --> Input Class Initialized
INFO - 2023-04-07 02:19:26 --> Language Class Initialized
INFO - 2023-04-07 02:19:26 --> Loader Class Initialized
INFO - 2023-04-07 02:19:26 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:26 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:26 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:26 --> Model "Login_model" initialized
INFO - 2023-04-07 02:19:26 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:26 --> Total execution time: 0.0250
INFO - 2023-04-07 02:19:26 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:26 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:26 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:26 --> Total execution time: 0.0356
INFO - 2023-04-07 02:19:28 --> Config Class Initialized
INFO - 2023-04-07 02:19:28 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:28 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:28 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:28 --> URI Class Initialized
INFO - 2023-04-07 02:19:28 --> Router Class Initialized
INFO - 2023-04-07 02:19:28 --> Output Class Initialized
INFO - 2023-04-07 02:19:28 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:28 --> Input Class Initialized
INFO - 2023-04-07 02:19:28 --> Language Class Initialized
INFO - 2023-04-07 02:19:28 --> Loader Class Initialized
INFO - 2023-04-07 02:19:28 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:28 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:28 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:28 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:28 --> Total execution time: 0.0165
INFO - 2023-04-07 02:19:28 --> Config Class Initialized
INFO - 2023-04-07 02:19:28 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:28 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:28 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:28 --> URI Class Initialized
INFO - 2023-04-07 02:19:28 --> Router Class Initialized
INFO - 2023-04-07 02:19:28 --> Output Class Initialized
INFO - 2023-04-07 02:19:28 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:28 --> Input Class Initialized
INFO - 2023-04-07 02:19:28 --> Language Class Initialized
INFO - 2023-04-07 02:19:28 --> Loader Class Initialized
INFO - 2023-04-07 02:19:28 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:28 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:28 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:28 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:28 --> Total execution time: 0.0527
INFO - 2023-04-07 02:19:30 --> Config Class Initialized
INFO - 2023-04-07 02:19:30 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:30 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:30 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:30 --> URI Class Initialized
INFO - 2023-04-07 02:19:30 --> Router Class Initialized
INFO - 2023-04-07 02:19:30 --> Output Class Initialized
INFO - 2023-04-07 02:19:30 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:30 --> Input Class Initialized
INFO - 2023-04-07 02:19:30 --> Language Class Initialized
INFO - 2023-04-07 02:19:30 --> Loader Class Initialized
INFO - 2023-04-07 02:19:30 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:30 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:30 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:31 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:31 --> Total execution time: 0.0618
INFO - 2023-04-07 02:19:31 --> Config Class Initialized
INFO - 2023-04-07 02:19:31 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:31 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:31 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:31 --> URI Class Initialized
INFO - 2023-04-07 02:19:31 --> Router Class Initialized
INFO - 2023-04-07 02:19:31 --> Output Class Initialized
INFO - 2023-04-07 02:19:31 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:31 --> Input Class Initialized
INFO - 2023-04-07 02:19:31 --> Language Class Initialized
INFO - 2023-04-07 02:19:31 --> Loader Class Initialized
INFO - 2023-04-07 02:19:31 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:31 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:31 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:31 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:31 --> Total execution time: 0.1751
INFO - 2023-04-07 02:19:35 --> Config Class Initialized
INFO - 2023-04-07 02:19:35 --> Config Class Initialized
INFO - 2023-04-07 02:19:35 --> Hooks Class Initialized
INFO - 2023-04-07 02:19:35 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-07 02:19:35 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:35 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:35 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:35 --> URI Class Initialized
INFO - 2023-04-07 02:19:35 --> URI Class Initialized
INFO - 2023-04-07 02:19:35 --> Router Class Initialized
INFO - 2023-04-07 02:19:35 --> Router Class Initialized
INFO - 2023-04-07 02:19:35 --> Output Class Initialized
INFO - 2023-04-07 02:19:35 --> Output Class Initialized
INFO - 2023-04-07 02:19:35 --> Security Class Initialized
INFO - 2023-04-07 02:19:35 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-07 02:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:35 --> Input Class Initialized
INFO - 2023-04-07 02:19:35 --> Input Class Initialized
INFO - 2023-04-07 02:19:35 --> Language Class Initialized
INFO - 2023-04-07 02:19:35 --> Language Class Initialized
INFO - 2023-04-07 02:19:35 --> Loader Class Initialized
INFO - 2023-04-07 02:19:35 --> Loader Class Initialized
INFO - 2023-04-07 02:19:35 --> Controller Class Initialized
INFO - 2023-04-07 02:19:35 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-07 02:19:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:35 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:35 --> Total execution time: 0.0046
INFO - 2023-04-07 02:19:35 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:35 --> Config Class Initialized
INFO - 2023-04-07 02:19:35 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:35 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:35 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:35 --> URI Class Initialized
INFO - 2023-04-07 02:19:35 --> Router Class Initialized
INFO - 2023-04-07 02:19:35 --> Output Class Initialized
INFO - 2023-04-07 02:19:35 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:35 --> Input Class Initialized
INFO - 2023-04-07 02:19:35 --> Language Class Initialized
INFO - 2023-04-07 02:19:35 --> Loader Class Initialized
INFO - 2023-04-07 02:19:35 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:35 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:35 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:35 --> Model "Login_model" initialized
INFO - 2023-04-07 02:19:35 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:35 --> Total execution time: 0.0231
INFO - 2023-04-07 02:19:35 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:35 --> Config Class Initialized
INFO - 2023-04-07 02:19:35 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:35 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:35 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:35 --> URI Class Initialized
INFO - 2023-04-07 02:19:35 --> Router Class Initialized
INFO - 2023-04-07 02:19:35 --> Output Class Initialized
INFO - 2023-04-07 02:19:35 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:35 --> Input Class Initialized
INFO - 2023-04-07 02:19:35 --> Language Class Initialized
INFO - 2023-04-07 02:19:35 --> Loader Class Initialized
INFO - 2023-04-07 02:19:35 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:35 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:35 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:35 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:35 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:35 --> Total execution time: 0.0320
INFO - 2023-04-07 02:19:35 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:35 --> Total execution time: 0.0177
INFO - 2023-04-07 02:19:37 --> Config Class Initialized
INFO - 2023-04-07 02:19:37 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:37 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:37 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:37 --> URI Class Initialized
INFO - 2023-04-07 02:19:37 --> Router Class Initialized
INFO - 2023-04-07 02:19:37 --> Output Class Initialized
INFO - 2023-04-07 02:19:37 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:37 --> Input Class Initialized
INFO - 2023-04-07 02:19:37 --> Language Class Initialized
INFO - 2023-04-07 02:19:37 --> Loader Class Initialized
INFO - 2023-04-07 02:19:37 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:37 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:37 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:37 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:37 --> Total execution time: 0.0632
INFO - 2023-04-07 02:19:37 --> Config Class Initialized
INFO - 2023-04-07 02:19:37 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:19:37 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:19:37 --> Utf8 Class Initialized
INFO - 2023-04-07 02:19:37 --> URI Class Initialized
INFO - 2023-04-07 02:19:37 --> Router Class Initialized
INFO - 2023-04-07 02:19:37 --> Output Class Initialized
INFO - 2023-04-07 02:19:37 --> Security Class Initialized
DEBUG - 2023-04-07 02:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:19:37 --> Input Class Initialized
INFO - 2023-04-07 02:19:37 --> Language Class Initialized
INFO - 2023-04-07 02:19:37 --> Loader Class Initialized
INFO - 2023-04-07 02:19:37 --> Controller Class Initialized
DEBUG - 2023-04-07 02:19:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:19:37 --> Database Driver Class Initialized
INFO - 2023-04-07 02:19:37 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:19:37 --> Final output sent to browser
DEBUG - 2023-04-07 02:19:37 --> Total execution time: 0.0652
INFO - 2023-04-07 02:23:53 --> Config Class Initialized
INFO - 2023-04-07 02:23:53 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:23:53 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:23:53 --> Utf8 Class Initialized
INFO - 2023-04-07 02:23:53 --> URI Class Initialized
INFO - 2023-04-07 02:23:53 --> Router Class Initialized
INFO - 2023-04-07 02:23:53 --> Output Class Initialized
INFO - 2023-04-07 02:23:53 --> Security Class Initialized
DEBUG - 2023-04-07 02:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:23:53 --> Input Class Initialized
INFO - 2023-04-07 02:23:53 --> Language Class Initialized
INFO - 2023-04-07 02:23:53 --> Loader Class Initialized
INFO - 2023-04-07 02:23:53 --> Controller Class Initialized
DEBUG - 2023-04-07 02:23:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:23:53 --> Database Driver Class Initialized
INFO - 2023-04-07 02:23:53 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:23:53 --> Final output sent to browser
DEBUG - 2023-04-07 02:23:53 --> Total execution time: 0.0462
INFO - 2023-04-07 02:23:53 --> Config Class Initialized
INFO - 2023-04-07 02:23:53 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:23:53 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:23:53 --> Utf8 Class Initialized
INFO - 2023-04-07 02:23:53 --> URI Class Initialized
INFO - 2023-04-07 02:23:53 --> Router Class Initialized
INFO - 2023-04-07 02:23:53 --> Output Class Initialized
INFO - 2023-04-07 02:23:53 --> Security Class Initialized
DEBUG - 2023-04-07 02:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:23:53 --> Input Class Initialized
INFO - 2023-04-07 02:23:53 --> Language Class Initialized
INFO - 2023-04-07 02:23:53 --> Loader Class Initialized
INFO - 2023-04-07 02:23:53 --> Controller Class Initialized
DEBUG - 2023-04-07 02:23:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:23:53 --> Database Driver Class Initialized
INFO - 2023-04-07 02:23:53 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:23:53 --> Final output sent to browser
DEBUG - 2023-04-07 02:23:53 --> Total execution time: 0.0472
INFO - 2023-04-07 02:23:56 --> Config Class Initialized
INFO - 2023-04-07 02:23:56 --> Config Class Initialized
INFO - 2023-04-07 02:23:56 --> Hooks Class Initialized
INFO - 2023-04-07 02:23:56 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:23:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-07 02:23:56 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:23:56 --> Utf8 Class Initialized
INFO - 2023-04-07 02:23:56 --> Utf8 Class Initialized
INFO - 2023-04-07 02:23:56 --> URI Class Initialized
INFO - 2023-04-07 02:23:56 --> URI Class Initialized
INFO - 2023-04-07 02:23:56 --> Router Class Initialized
INFO - 2023-04-07 02:23:56 --> Router Class Initialized
INFO - 2023-04-07 02:23:56 --> Output Class Initialized
INFO - 2023-04-07 02:23:56 --> Output Class Initialized
INFO - 2023-04-07 02:23:56 --> Security Class Initialized
INFO - 2023-04-07 02:23:56 --> Security Class Initialized
DEBUG - 2023-04-07 02:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-07 02:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:23:56 --> Input Class Initialized
INFO - 2023-04-07 02:23:56 --> Input Class Initialized
INFO - 2023-04-07 02:23:56 --> Language Class Initialized
INFO - 2023-04-07 02:23:56 --> Language Class Initialized
INFO - 2023-04-07 02:23:56 --> Loader Class Initialized
INFO - 2023-04-07 02:23:56 --> Loader Class Initialized
INFO - 2023-04-07 02:23:56 --> Controller Class Initialized
INFO - 2023-04-07 02:23:56 --> Controller Class Initialized
DEBUG - 2023-04-07 02:23:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-07 02:23:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:23:56 --> Database Driver Class Initialized
INFO - 2023-04-07 02:23:56 --> Final output sent to browser
DEBUG - 2023-04-07 02:23:56 --> Total execution time: 0.0057
INFO - 2023-04-07 02:23:56 --> Config Class Initialized
INFO - 2023-04-07 02:23:56 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:23:56 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:23:56 --> Utf8 Class Initialized
INFO - 2023-04-07 02:23:56 --> URI Class Initialized
INFO - 2023-04-07 02:23:56 --> Router Class Initialized
INFO - 2023-04-07 02:23:56 --> Output Class Initialized
INFO - 2023-04-07 02:23:56 --> Security Class Initialized
DEBUG - 2023-04-07 02:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:23:56 --> Input Class Initialized
INFO - 2023-04-07 02:23:56 --> Language Class Initialized
INFO - 2023-04-07 02:23:56 --> Loader Class Initialized
INFO - 2023-04-07 02:23:56 --> Controller Class Initialized
DEBUG - 2023-04-07 02:23:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:23:56 --> Database Driver Class Initialized
INFO - 2023-04-07 02:23:56 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:23:56 --> Model "Login_model" initialized
INFO - 2023-04-07 02:23:56 --> Database Driver Class Initialized
INFO - 2023-04-07 02:23:56 --> Final output sent to browser
DEBUG - 2023-04-07 02:23:56 --> Total execution time: 0.0222
INFO - 2023-04-07 02:23:56 --> Config Class Initialized
INFO - 2023-04-07 02:23:56 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:23:56 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:23:56 --> Utf8 Class Initialized
INFO - 2023-04-07 02:23:56 --> URI Class Initialized
INFO - 2023-04-07 02:23:56 --> Router Class Initialized
INFO - 2023-04-07 02:23:56 --> Output Class Initialized
INFO - 2023-04-07 02:23:56 --> Security Class Initialized
DEBUG - 2023-04-07 02:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:23:56 --> Input Class Initialized
INFO - 2023-04-07 02:23:56 --> Language Class Initialized
INFO - 2023-04-07 02:23:56 --> Loader Class Initialized
INFO - 2023-04-07 02:23:56 --> Controller Class Initialized
DEBUG - 2023-04-07 02:23:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:23:56 --> Database Driver Class Initialized
INFO - 2023-04-07 02:23:56 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:23:56 --> Final output sent to browser
DEBUG - 2023-04-07 02:23:56 --> Total execution time: 0.0266
INFO - 2023-04-07 02:23:56 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:23:56 --> Final output sent to browser
DEBUG - 2023-04-07 02:23:56 --> Total execution time: 0.0629
INFO - 2023-04-07 02:23:59 --> Config Class Initialized
INFO - 2023-04-07 02:23:59 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:23:59 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:23:59 --> Utf8 Class Initialized
INFO - 2023-04-07 02:23:59 --> URI Class Initialized
INFO - 2023-04-07 02:23:59 --> Router Class Initialized
INFO - 2023-04-07 02:23:59 --> Output Class Initialized
INFO - 2023-04-07 02:23:59 --> Security Class Initialized
DEBUG - 2023-04-07 02:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:23:59 --> Input Class Initialized
INFO - 2023-04-07 02:23:59 --> Language Class Initialized
INFO - 2023-04-07 02:23:59 --> Loader Class Initialized
INFO - 2023-04-07 02:23:59 --> Controller Class Initialized
DEBUG - 2023-04-07 02:23:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:23:59 --> Database Driver Class Initialized
INFO - 2023-04-07 02:23:59 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:23:59 --> Database Driver Class Initialized
INFO - 2023-04-07 02:23:59 --> Model "Login_model" initialized
INFO - 2023-04-07 02:23:59 --> Final output sent to browser
DEBUG - 2023-04-07 02:23:59 --> Total execution time: 0.0555
INFO - 2023-04-07 02:23:59 --> Config Class Initialized
INFO - 2023-04-07 02:23:59 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:23:59 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:23:59 --> Utf8 Class Initialized
INFO - 2023-04-07 02:23:59 --> URI Class Initialized
INFO - 2023-04-07 02:23:59 --> Router Class Initialized
INFO - 2023-04-07 02:23:59 --> Output Class Initialized
INFO - 2023-04-07 02:23:59 --> Security Class Initialized
DEBUG - 2023-04-07 02:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:23:59 --> Input Class Initialized
INFO - 2023-04-07 02:23:59 --> Language Class Initialized
INFO - 2023-04-07 02:23:59 --> Loader Class Initialized
INFO - 2023-04-07 02:23:59 --> Controller Class Initialized
DEBUG - 2023-04-07 02:23:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:23:59 --> Database Driver Class Initialized
INFO - 2023-04-07 02:23:59 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:23:59 --> Database Driver Class Initialized
INFO - 2023-04-07 02:23:59 --> Model "Login_model" initialized
INFO - 2023-04-07 02:23:59 --> Final output sent to browser
DEBUG - 2023-04-07 02:23:59 --> Total execution time: 0.0582
INFO - 2023-04-07 02:32:08 --> Config Class Initialized
INFO - 2023-04-07 02:32:08 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:32:08 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:32:08 --> Utf8 Class Initialized
INFO - 2023-04-07 02:32:08 --> URI Class Initialized
INFO - 2023-04-07 02:32:08 --> Router Class Initialized
INFO - 2023-04-07 02:32:08 --> Output Class Initialized
INFO - 2023-04-07 02:32:08 --> Security Class Initialized
DEBUG - 2023-04-07 02:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:32:08 --> Input Class Initialized
INFO - 2023-04-07 02:32:08 --> Language Class Initialized
INFO - 2023-04-07 02:32:08 --> Loader Class Initialized
INFO - 2023-04-07 02:32:08 --> Controller Class Initialized
INFO - 2023-04-07 02:32:08 --> Helper loaded: form_helper
INFO - 2023-04-07 02:32:08 --> Helper loaded: url_helper
DEBUG - 2023-04-07 02:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:32:08 --> Model "Change_model" initialized
INFO - 2023-04-07 02:32:08 --> Model "Grafana_model" initialized
INFO - 2023-04-07 02:32:08 --> Final output sent to browser
DEBUG - 2023-04-07 02:32:08 --> Total execution time: 0.0463
INFO - 2023-04-07 02:32:08 --> Config Class Initialized
INFO - 2023-04-07 02:32:08 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:32:08 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:32:08 --> Utf8 Class Initialized
INFO - 2023-04-07 02:32:08 --> URI Class Initialized
INFO - 2023-04-07 02:32:08 --> Router Class Initialized
INFO - 2023-04-07 02:32:08 --> Output Class Initialized
INFO - 2023-04-07 02:32:08 --> Security Class Initialized
DEBUG - 2023-04-07 02:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:32:08 --> Input Class Initialized
INFO - 2023-04-07 02:32:08 --> Language Class Initialized
INFO - 2023-04-07 02:32:08 --> Loader Class Initialized
INFO - 2023-04-07 02:32:08 --> Controller Class Initialized
INFO - 2023-04-07 02:32:08 --> Helper loaded: form_helper
INFO - 2023-04-07 02:32:08 --> Helper loaded: url_helper
DEBUG - 2023-04-07 02:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:32:08 --> Final output sent to browser
DEBUG - 2023-04-07 02:32:08 --> Total execution time: 0.0036
INFO - 2023-04-07 02:32:08 --> Config Class Initialized
INFO - 2023-04-07 02:32:08 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:32:08 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:32:08 --> Utf8 Class Initialized
INFO - 2023-04-07 02:32:08 --> URI Class Initialized
INFO - 2023-04-07 02:32:08 --> Router Class Initialized
INFO - 2023-04-07 02:32:08 --> Output Class Initialized
INFO - 2023-04-07 02:32:08 --> Security Class Initialized
DEBUG - 2023-04-07 02:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:32:08 --> Input Class Initialized
INFO - 2023-04-07 02:32:08 --> Language Class Initialized
INFO - 2023-04-07 02:32:08 --> Loader Class Initialized
INFO - 2023-04-07 02:32:08 --> Controller Class Initialized
INFO - 2023-04-07 02:32:08 --> Helper loaded: form_helper
INFO - 2023-04-07 02:32:08 --> Helper loaded: url_helper
DEBUG - 2023-04-07 02:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:32:08 --> Database Driver Class Initialized
INFO - 2023-04-07 02:32:08 --> Model "Login_model" initialized
INFO - 2023-04-07 02:32:08 --> Final output sent to browser
DEBUG - 2023-04-07 02:32:08 --> Total execution time: 0.0230
INFO - 2023-04-07 02:32:08 --> Config Class Initialized
INFO - 2023-04-07 02:32:08 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:32:08 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:32:08 --> Utf8 Class Initialized
INFO - 2023-04-07 02:32:08 --> URI Class Initialized
INFO - 2023-04-07 02:32:08 --> Router Class Initialized
INFO - 2023-04-07 02:32:08 --> Output Class Initialized
INFO - 2023-04-07 02:32:08 --> Security Class Initialized
DEBUG - 2023-04-07 02:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:32:08 --> Input Class Initialized
INFO - 2023-04-07 02:32:08 --> Language Class Initialized
INFO - 2023-04-07 02:32:08 --> Loader Class Initialized
INFO - 2023-04-07 02:32:08 --> Controller Class Initialized
DEBUG - 2023-04-07 02:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:32:08 --> Database Driver Class Initialized
INFO - 2023-04-07 02:32:08 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:32:08 --> Final output sent to browser
DEBUG - 2023-04-07 02:32:08 --> Total execution time: 0.0121
INFO - 2023-04-07 02:32:08 --> Config Class Initialized
INFO - 2023-04-07 02:32:08 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:32:08 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:32:08 --> Utf8 Class Initialized
INFO - 2023-04-07 02:32:08 --> URI Class Initialized
INFO - 2023-04-07 02:32:08 --> Router Class Initialized
INFO - 2023-04-07 02:32:08 --> Output Class Initialized
INFO - 2023-04-07 02:32:08 --> Security Class Initialized
DEBUG - 2023-04-07 02:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:32:08 --> Input Class Initialized
INFO - 2023-04-07 02:32:08 --> Language Class Initialized
INFO - 2023-04-07 02:32:08 --> Loader Class Initialized
INFO - 2023-04-07 02:32:08 --> Controller Class Initialized
DEBUG - 2023-04-07 02:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:32:08 --> Database Driver Class Initialized
INFO - 2023-04-07 02:32:08 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:32:08 --> Final output sent to browser
DEBUG - 2023-04-07 02:32:08 --> Total execution time: 0.0132
INFO - 2023-04-07 02:32:09 --> Config Class Initialized
INFO - 2023-04-07 02:32:09 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:32:09 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:32:09 --> Utf8 Class Initialized
INFO - 2023-04-07 02:32:09 --> URI Class Initialized
INFO - 2023-04-07 02:32:09 --> Router Class Initialized
INFO - 2023-04-07 02:32:09 --> Output Class Initialized
INFO - 2023-04-07 02:32:09 --> Security Class Initialized
DEBUG - 2023-04-07 02:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:32:09 --> Input Class Initialized
INFO - 2023-04-07 02:32:09 --> Language Class Initialized
INFO - 2023-04-07 02:32:09 --> Loader Class Initialized
INFO - 2023-04-07 02:32:09 --> Controller Class Initialized
DEBUG - 2023-04-07 02:32:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:32:09 --> Database Driver Class Initialized
INFO - 2023-04-07 02:32:09 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:32:09 --> Database Driver Class Initialized
INFO - 2023-04-07 02:32:09 --> Model "Login_model" initialized
INFO - 2023-04-07 02:32:09 --> Final output sent to browser
DEBUG - 2023-04-07 02:32:09 --> Total execution time: 0.0717
INFO - 2023-04-07 02:32:09 --> Config Class Initialized
INFO - 2023-04-07 02:32:09 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:32:09 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:32:09 --> Utf8 Class Initialized
INFO - 2023-04-07 02:32:09 --> URI Class Initialized
INFO - 2023-04-07 02:32:09 --> Router Class Initialized
INFO - 2023-04-07 02:32:09 --> Output Class Initialized
INFO - 2023-04-07 02:32:09 --> Security Class Initialized
DEBUG - 2023-04-07 02:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:32:09 --> Input Class Initialized
INFO - 2023-04-07 02:32:09 --> Language Class Initialized
INFO - 2023-04-07 02:32:09 --> Loader Class Initialized
INFO - 2023-04-07 02:32:09 --> Controller Class Initialized
DEBUG - 2023-04-07 02:32:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:32:09 --> Database Driver Class Initialized
INFO - 2023-04-07 02:32:09 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:32:09 --> Database Driver Class Initialized
INFO - 2023-04-07 02:32:09 --> Model "Login_model" initialized
INFO - 2023-04-07 02:32:09 --> Final output sent to browser
DEBUG - 2023-04-07 02:32:09 --> Total execution time: 0.0671
INFO - 2023-04-07 02:32:12 --> Config Class Initialized
INFO - 2023-04-07 02:32:12 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:32:12 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:32:12 --> Utf8 Class Initialized
INFO - 2023-04-07 02:32:12 --> URI Class Initialized
INFO - 2023-04-07 02:32:12 --> Router Class Initialized
INFO - 2023-04-07 02:32:12 --> Output Class Initialized
INFO - 2023-04-07 02:32:12 --> Security Class Initialized
DEBUG - 2023-04-07 02:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:32:12 --> Input Class Initialized
INFO - 2023-04-07 02:32:12 --> Language Class Initialized
INFO - 2023-04-07 02:32:12 --> Loader Class Initialized
INFO - 2023-04-07 02:32:12 --> Controller Class Initialized
DEBUG - 2023-04-07 02:32:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:32:12 --> Database Driver Class Initialized
INFO - 2023-04-07 02:32:12 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:32:12 --> Final output sent to browser
DEBUG - 2023-04-07 02:32:12 --> Total execution time: 0.0218
INFO - 2023-04-07 02:32:12 --> Config Class Initialized
INFO - 2023-04-07 02:32:12 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:32:12 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:32:12 --> Utf8 Class Initialized
INFO - 2023-04-07 02:32:12 --> URI Class Initialized
INFO - 2023-04-07 02:32:12 --> Router Class Initialized
INFO - 2023-04-07 02:32:12 --> Output Class Initialized
INFO - 2023-04-07 02:32:12 --> Security Class Initialized
DEBUG - 2023-04-07 02:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:32:12 --> Input Class Initialized
INFO - 2023-04-07 02:32:12 --> Language Class Initialized
INFO - 2023-04-07 02:32:12 --> Loader Class Initialized
INFO - 2023-04-07 02:32:12 --> Controller Class Initialized
DEBUG - 2023-04-07 02:32:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:32:12 --> Database Driver Class Initialized
INFO - 2023-04-07 02:32:12 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:32:12 --> Final output sent to browser
DEBUG - 2023-04-07 02:32:12 --> Total execution time: 0.0111
INFO - 2023-04-07 02:34:50 --> Config Class Initialized
INFO - 2023-04-07 02:34:50 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:34:50 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:34:50 --> Utf8 Class Initialized
INFO - 2023-04-07 02:34:50 --> URI Class Initialized
INFO - 2023-04-07 02:34:50 --> Router Class Initialized
INFO - 2023-04-07 02:34:50 --> Output Class Initialized
INFO - 2023-04-07 02:34:50 --> Security Class Initialized
DEBUG - 2023-04-07 02:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:34:50 --> Input Class Initialized
INFO - 2023-04-07 02:34:50 --> Language Class Initialized
INFO - 2023-04-07 02:34:50 --> Loader Class Initialized
INFO - 2023-04-07 02:34:50 --> Controller Class Initialized
DEBUG - 2023-04-07 02:34:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:34:50 --> Database Driver Class Initialized
INFO - 2023-04-07 02:34:50 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:34:50 --> Final output sent to browser
DEBUG - 2023-04-07 02:34:50 --> Total execution time: 0.0434
INFO - 2023-04-07 02:34:50 --> Config Class Initialized
INFO - 2023-04-07 02:34:50 --> Hooks Class Initialized
DEBUG - 2023-04-07 02:34:50 --> UTF-8 Support Enabled
INFO - 2023-04-07 02:34:50 --> Utf8 Class Initialized
INFO - 2023-04-07 02:34:50 --> URI Class Initialized
INFO - 2023-04-07 02:34:50 --> Router Class Initialized
INFO - 2023-04-07 02:34:50 --> Output Class Initialized
INFO - 2023-04-07 02:34:50 --> Security Class Initialized
DEBUG - 2023-04-07 02:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 02:34:50 --> Input Class Initialized
INFO - 2023-04-07 02:34:50 --> Language Class Initialized
INFO - 2023-04-07 02:34:50 --> Loader Class Initialized
INFO - 2023-04-07 02:34:50 --> Controller Class Initialized
DEBUG - 2023-04-07 02:34:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 02:34:50 --> Database Driver Class Initialized
INFO - 2023-04-07 02:34:50 --> Model "Cluster_model" initialized
INFO - 2023-04-07 02:34:50 --> Final output sent to browser
DEBUG - 2023-04-07 02:34:50 --> Total execution time: 0.0458
INFO - 2023-04-07 03:33:47 --> Config Class Initialized
INFO - 2023-04-07 03:33:47 --> Hooks Class Initialized
DEBUG - 2023-04-07 03:33:47 --> UTF-8 Support Enabled
INFO - 2023-04-07 03:33:47 --> Utf8 Class Initialized
INFO - 2023-04-07 03:33:47 --> URI Class Initialized
INFO - 2023-04-07 03:33:47 --> Router Class Initialized
INFO - 2023-04-07 03:33:47 --> Output Class Initialized
INFO - 2023-04-07 03:33:47 --> Security Class Initialized
DEBUG - 2023-04-07 03:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 03:33:47 --> Input Class Initialized
INFO - 2023-04-07 03:33:47 --> Language Class Initialized
INFO - 2023-04-07 03:33:47 --> Loader Class Initialized
INFO - 2023-04-07 03:33:47 --> Controller Class Initialized
DEBUG - 2023-04-07 03:33:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 03:33:47 --> Database Driver Class Initialized
INFO - 2023-04-07 03:33:47 --> Model "Cluster_model" initialized
INFO - 2023-04-07 03:33:47 --> Final output sent to browser
DEBUG - 2023-04-07 03:33:47 --> Total execution time: 0.0181
INFO - 2023-04-07 03:33:47 --> Config Class Initialized
INFO - 2023-04-07 03:33:47 --> Hooks Class Initialized
DEBUG - 2023-04-07 03:33:47 --> UTF-8 Support Enabled
INFO - 2023-04-07 03:33:47 --> Utf8 Class Initialized
INFO - 2023-04-07 03:33:47 --> URI Class Initialized
INFO - 2023-04-07 03:33:47 --> Router Class Initialized
INFO - 2023-04-07 03:33:47 --> Output Class Initialized
INFO - 2023-04-07 03:33:47 --> Security Class Initialized
DEBUG - 2023-04-07 03:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 03:33:47 --> Input Class Initialized
INFO - 2023-04-07 03:33:47 --> Language Class Initialized
INFO - 2023-04-07 03:33:47 --> Loader Class Initialized
INFO - 2023-04-07 03:33:47 --> Controller Class Initialized
DEBUG - 2023-04-07 03:33:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 03:33:47 --> Database Driver Class Initialized
INFO - 2023-04-07 03:33:47 --> Model "Cluster_model" initialized
INFO - 2023-04-07 03:33:47 --> Final output sent to browser
DEBUG - 2023-04-07 03:33:47 --> Total execution time: 0.0543
INFO - 2023-04-07 03:33:50 --> Config Class Initialized
INFO - 2023-04-07 03:33:50 --> Hooks Class Initialized
DEBUG - 2023-04-07 03:33:50 --> UTF-8 Support Enabled
INFO - 2023-04-07 03:33:50 --> Utf8 Class Initialized
INFO - 2023-04-07 03:33:50 --> URI Class Initialized
INFO - 2023-04-07 03:33:50 --> Router Class Initialized
INFO - 2023-04-07 03:33:50 --> Output Class Initialized
INFO - 2023-04-07 03:33:50 --> Security Class Initialized
DEBUG - 2023-04-07 03:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 03:33:50 --> Input Class Initialized
INFO - 2023-04-07 03:33:50 --> Language Class Initialized
INFO - 2023-04-07 03:33:50 --> Loader Class Initialized
INFO - 2023-04-07 03:33:50 --> Controller Class Initialized
DEBUG - 2023-04-07 03:33:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 03:33:50 --> Database Driver Class Initialized
INFO - 2023-04-07 03:33:50 --> Model "Cluster_model" initialized
INFO - 2023-04-07 03:33:50 --> Final output sent to browser
DEBUG - 2023-04-07 03:33:50 --> Total execution time: 0.0679
INFO - 2023-04-07 03:33:50 --> Config Class Initialized
INFO - 2023-04-07 03:33:50 --> Hooks Class Initialized
DEBUG - 2023-04-07 03:33:50 --> UTF-8 Support Enabled
INFO - 2023-04-07 03:33:50 --> Utf8 Class Initialized
INFO - 2023-04-07 03:33:50 --> URI Class Initialized
INFO - 2023-04-07 03:33:50 --> Router Class Initialized
INFO - 2023-04-07 03:33:50 --> Output Class Initialized
INFO - 2023-04-07 03:33:50 --> Security Class Initialized
DEBUG - 2023-04-07 03:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 03:33:50 --> Input Class Initialized
INFO - 2023-04-07 03:33:50 --> Language Class Initialized
INFO - 2023-04-07 03:33:50 --> Loader Class Initialized
INFO - 2023-04-07 03:33:50 --> Controller Class Initialized
DEBUG - 2023-04-07 03:33:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 03:33:50 --> Database Driver Class Initialized
INFO - 2023-04-07 03:33:50 --> Model "Cluster_model" initialized
INFO - 2023-04-07 03:33:50 --> Final output sent to browser
DEBUG - 2023-04-07 03:33:50 --> Total execution time: 0.0831
INFO - 2023-04-07 05:47:52 --> Config Class Initialized
INFO - 2023-04-07 05:47:52 --> Hooks Class Initialized
DEBUG - 2023-04-07 05:47:52 --> UTF-8 Support Enabled
INFO - 2023-04-07 05:47:52 --> Utf8 Class Initialized
INFO - 2023-04-07 05:47:52 --> URI Class Initialized
INFO - 2023-04-07 05:47:52 --> Router Class Initialized
INFO - 2023-04-07 05:47:52 --> Output Class Initialized
INFO - 2023-04-07 05:47:52 --> Security Class Initialized
DEBUG - 2023-04-07 05:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 05:47:52 --> Input Class Initialized
INFO - 2023-04-07 05:47:52 --> Language Class Initialized
INFO - 2023-04-07 05:47:52 --> Loader Class Initialized
INFO - 2023-04-07 05:47:52 --> Controller Class Initialized
DEBUG - 2023-04-07 05:47:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 05:47:52 --> Database Driver Class Initialized
INFO - 2023-04-07 05:47:52 --> Model "Cluster_model" initialized
INFO - 2023-04-07 05:47:52 --> Final output sent to browser
DEBUG - 2023-04-07 05:47:52 --> Total execution time: 0.0641
INFO - 2023-04-07 05:47:52 --> Config Class Initialized
INFO - 2023-04-07 05:47:52 --> Hooks Class Initialized
DEBUG - 2023-04-07 05:47:52 --> UTF-8 Support Enabled
INFO - 2023-04-07 05:47:52 --> Utf8 Class Initialized
INFO - 2023-04-07 05:47:52 --> URI Class Initialized
INFO - 2023-04-07 05:47:52 --> Router Class Initialized
INFO - 2023-04-07 05:47:52 --> Output Class Initialized
INFO - 2023-04-07 05:47:52 --> Security Class Initialized
DEBUG - 2023-04-07 05:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 05:47:52 --> Input Class Initialized
INFO - 2023-04-07 05:47:52 --> Language Class Initialized
INFO - 2023-04-07 05:47:52 --> Loader Class Initialized
INFO - 2023-04-07 05:47:52 --> Controller Class Initialized
DEBUG - 2023-04-07 05:47:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 05:47:52 --> Database Driver Class Initialized
INFO - 2023-04-07 05:47:52 --> Model "Cluster_model" initialized
INFO - 2023-04-07 05:47:52 --> Final output sent to browser
DEBUG - 2023-04-07 05:47:52 --> Total execution time: 0.0784
INFO - 2023-04-07 05:47:54 --> Config Class Initialized
INFO - 2023-04-07 05:47:54 --> Config Class Initialized
INFO - 2023-04-07 05:47:54 --> Hooks Class Initialized
INFO - 2023-04-07 05:47:54 --> Hooks Class Initialized
DEBUG - 2023-04-07 05:47:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-07 05:47:54 --> UTF-8 Support Enabled
INFO - 2023-04-07 05:47:54 --> Utf8 Class Initialized
INFO - 2023-04-07 05:47:54 --> Utf8 Class Initialized
INFO - 2023-04-07 05:47:54 --> URI Class Initialized
INFO - 2023-04-07 05:47:54 --> Router Class Initialized
INFO - 2023-04-07 05:47:54 --> Output Class Initialized
INFO - 2023-04-07 05:47:54 --> Security Class Initialized
DEBUG - 2023-04-07 05:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 05:47:54 --> Input Class Initialized
INFO - 2023-04-07 05:47:54 --> Language Class Initialized
INFO - 2023-04-07 05:47:54 --> Loader Class Initialized
INFO - 2023-04-07 05:47:54 --> Controller Class Initialized
DEBUG - 2023-04-07 05:47:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 05:47:54 --> Database Driver Class Initialized
INFO - 2023-04-07 05:47:54 --> URI Class Initialized
INFO - 2023-04-07 05:47:54 --> Model "Cluster_model" initialized
INFO - 2023-04-07 05:47:55 --> Router Class Initialized
INFO - 2023-04-07 05:47:55 --> Output Class Initialized
INFO - 2023-04-07 05:47:55 --> Security Class Initialized
DEBUG - 2023-04-07 05:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 05:47:55 --> Input Class Initialized
INFO - 2023-04-07 05:47:55 --> Language Class Initialized
INFO - 2023-04-07 05:47:55 --> Loader Class Initialized
INFO - 2023-04-07 05:47:55 --> Controller Class Initialized
DEBUG - 2023-04-07 05:47:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 05:47:55 --> Final output sent to browser
DEBUG - 2023-04-07 05:47:55 --> Total execution time: 0.3915
INFO - 2023-04-07 05:47:55 --> Config Class Initialized
INFO - 2023-04-07 05:47:55 --> Final output sent to browser
DEBUG - 2023-04-07 05:47:55 --> Total execution time: 0.3954
INFO - 2023-04-07 05:47:55 --> Hooks Class Initialized
DEBUG - 2023-04-07 05:47:55 --> UTF-8 Support Enabled
INFO - 2023-04-07 05:47:55 --> Utf8 Class Initialized
INFO - 2023-04-07 05:47:55 --> URI Class Initialized
INFO - 2023-04-07 05:47:55 --> Router Class Initialized
INFO - 2023-04-07 05:47:55 --> Output Class Initialized
INFO - 2023-04-07 05:47:55 --> Config Class Initialized
INFO - 2023-04-07 05:47:55 --> Security Class Initialized
INFO - 2023-04-07 05:47:55 --> Hooks Class Initialized
DEBUG - 2023-04-07 05:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 05:47:55 --> Input Class Initialized
DEBUG - 2023-04-07 05:47:55 --> UTF-8 Support Enabled
INFO - 2023-04-07 05:47:55 --> Language Class Initialized
INFO - 2023-04-07 05:47:55 --> Utf8 Class Initialized
INFO - 2023-04-07 05:47:55 --> URI Class Initialized
INFO - 2023-04-07 05:47:55 --> Loader Class Initialized
INFO - 2023-04-07 05:47:55 --> Router Class Initialized
INFO - 2023-04-07 05:47:55 --> Output Class Initialized
INFO - 2023-04-07 05:47:55 --> Controller Class Initialized
INFO - 2023-04-07 05:47:55 --> Security Class Initialized
DEBUG - 2023-04-07 05:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-07 05:47:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 05:47:55 --> Input Class Initialized
INFO - 2023-04-07 05:47:55 --> Language Class Initialized
INFO - 2023-04-07 05:47:55 --> Loader Class Initialized
INFO - 2023-04-07 05:47:55 --> Controller Class Initialized
INFO - 2023-04-07 05:47:55 --> Database Driver Class Initialized
DEBUG - 2023-04-07 05:47:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 05:47:55 --> Database Driver Class Initialized
INFO - 2023-04-07 05:47:55 --> Model "Login_model" initialized
INFO - 2023-04-07 05:47:55 --> Model "Cluster_model" initialized
INFO - 2023-04-07 05:47:55 --> Database Driver Class Initialized
INFO - 2023-04-07 05:47:55 --> Final output sent to browser
DEBUG - 2023-04-07 05:47:55 --> Total execution time: 0.0633
INFO - 2023-04-07 05:47:55 --> Model "Cluster_model" initialized
INFO - 2023-04-07 05:47:55 --> Final output sent to browser
DEBUG - 2023-04-07 05:47:55 --> Total execution time: 0.1131
INFO - 2023-04-07 05:47:57 --> Config Class Initialized
INFO - 2023-04-07 05:47:57 --> Hooks Class Initialized
DEBUG - 2023-04-07 05:47:57 --> UTF-8 Support Enabled
INFO - 2023-04-07 05:47:57 --> Utf8 Class Initialized
INFO - 2023-04-07 05:47:57 --> URI Class Initialized
INFO - 2023-04-07 05:47:57 --> Router Class Initialized
INFO - 2023-04-07 05:47:57 --> Output Class Initialized
INFO - 2023-04-07 05:47:57 --> Security Class Initialized
DEBUG - 2023-04-07 05:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 05:47:57 --> Input Class Initialized
INFO - 2023-04-07 05:47:57 --> Language Class Initialized
INFO - 2023-04-07 05:47:57 --> Loader Class Initialized
INFO - 2023-04-07 05:47:57 --> Controller Class Initialized
DEBUG - 2023-04-07 05:47:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 05:47:57 --> Database Driver Class Initialized
INFO - 2023-04-07 05:47:57 --> Model "Cluster_model" initialized
INFO - 2023-04-07 05:47:57 --> Final output sent to browser
DEBUG - 2023-04-07 05:47:57 --> Total execution time: 0.0167
INFO - 2023-04-07 05:47:57 --> Config Class Initialized
INFO - 2023-04-07 05:47:57 --> Hooks Class Initialized
DEBUG - 2023-04-07 05:47:57 --> UTF-8 Support Enabled
INFO - 2023-04-07 05:47:57 --> Utf8 Class Initialized
INFO - 2023-04-07 05:47:57 --> URI Class Initialized
INFO - 2023-04-07 05:47:57 --> Router Class Initialized
INFO - 2023-04-07 05:47:57 --> Output Class Initialized
INFO - 2023-04-07 05:47:57 --> Security Class Initialized
DEBUG - 2023-04-07 05:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 05:47:57 --> Input Class Initialized
INFO - 2023-04-07 05:47:57 --> Language Class Initialized
INFO - 2023-04-07 05:47:57 --> Loader Class Initialized
INFO - 2023-04-07 05:47:57 --> Controller Class Initialized
DEBUG - 2023-04-07 05:47:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 05:47:57 --> Database Driver Class Initialized
INFO - 2023-04-07 05:47:57 --> Model "Cluster_model" initialized
INFO - 2023-04-07 05:47:57 --> Final output sent to browser
DEBUG - 2023-04-07 05:47:57 --> Total execution time: 0.0128
INFO - 2023-04-07 07:30:40 --> Config Class Initialized
INFO - 2023-04-07 07:30:40 --> Config Class Initialized
INFO - 2023-04-07 07:30:40 --> Hooks Class Initialized
INFO - 2023-04-07 07:30:40 --> Hooks Class Initialized
DEBUG - 2023-04-07 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-07 07:30:40 --> UTF-8 Support Enabled
INFO - 2023-04-07 07:30:40 --> Utf8 Class Initialized
INFO - 2023-04-07 07:30:40 --> Utf8 Class Initialized
INFO - 2023-04-07 07:30:40 --> URI Class Initialized
INFO - 2023-04-07 07:30:40 --> URI Class Initialized
INFO - 2023-04-07 07:30:40 --> Router Class Initialized
INFO - 2023-04-07 07:30:40 --> Router Class Initialized
INFO - 2023-04-07 07:30:40 --> Output Class Initialized
INFO - 2023-04-07 07:30:40 --> Output Class Initialized
INFO - 2023-04-07 07:30:40 --> Security Class Initialized
INFO - 2023-04-07 07:30:40 --> Security Class Initialized
DEBUG - 2023-04-07 07:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-07 07:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 07:30:40 --> Input Class Initialized
INFO - 2023-04-07 07:30:40 --> Input Class Initialized
INFO - 2023-04-07 07:30:40 --> Language Class Initialized
INFO - 2023-04-07 07:30:40 --> Language Class Initialized
INFO - 2023-04-07 07:30:40 --> Loader Class Initialized
INFO - 2023-04-07 07:30:40 --> Loader Class Initialized
INFO - 2023-04-07 07:30:40 --> Controller Class Initialized
INFO - 2023-04-07 07:30:40 --> Controller Class Initialized
DEBUG - 2023-04-07 07:30:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-07 07:30:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 07:30:40 --> Final output sent to browser
DEBUG - 2023-04-07 07:30:40 --> Total execution time: 0.0061
INFO - 2023-04-07 07:30:40 --> Database Driver Class Initialized
INFO - 2023-04-07 07:30:40 --> Model "Cluster_model" initialized
INFO - 2023-04-07 07:30:40 --> Config Class Initialized
INFO - 2023-04-07 07:30:40 --> Hooks Class Initialized
DEBUG - 2023-04-07 07:30:40 --> UTF-8 Support Enabled
INFO - 2023-04-07 07:30:40 --> Utf8 Class Initialized
INFO - 2023-04-07 07:30:40 --> URI Class Initialized
INFO - 2023-04-07 07:30:40 --> Router Class Initialized
INFO - 2023-04-07 07:30:40 --> Output Class Initialized
INFO - 2023-04-07 07:30:40 --> Security Class Initialized
DEBUG - 2023-04-07 07:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 07:30:40 --> Input Class Initialized
INFO - 2023-04-07 07:30:40 --> Language Class Initialized
INFO - 2023-04-07 07:30:40 --> Loader Class Initialized
INFO - 2023-04-07 07:30:40 --> Controller Class Initialized
DEBUG - 2023-04-07 07:30:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 07:30:40 --> Database Driver Class Initialized
INFO - 2023-04-07 07:30:40 --> Final output sent to browser
DEBUG - 2023-04-07 07:30:40 --> Total execution time: 0.0599
INFO - 2023-04-07 07:30:40 --> Model "Login_model" initialized
INFO - 2023-04-07 07:30:40 --> Config Class Initialized
INFO - 2023-04-07 07:30:40 --> Hooks Class Initialized
DEBUG - 2023-04-07 07:30:40 --> UTF-8 Support Enabled
INFO - 2023-04-07 07:30:40 --> Utf8 Class Initialized
INFO - 2023-04-07 07:30:40 --> URI Class Initialized
INFO - 2023-04-07 07:30:40 --> Router Class Initialized
INFO - 2023-04-07 07:30:40 --> Output Class Initialized
INFO - 2023-04-07 07:30:40 --> Security Class Initialized
DEBUG - 2023-04-07 07:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 07:30:40 --> Input Class Initialized
INFO - 2023-04-07 07:30:40 --> Language Class Initialized
INFO - 2023-04-07 07:30:40 --> Loader Class Initialized
INFO - 2023-04-07 07:30:40 --> Controller Class Initialized
DEBUG - 2023-04-07 07:30:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 07:30:40 --> Database Driver Class Initialized
INFO - 2023-04-07 07:30:40 --> Database Driver Class Initialized
INFO - 2023-04-07 07:30:40 --> Model "Cluster_model" initialized
INFO - 2023-04-07 07:30:40 --> Final output sent to browser
DEBUG - 2023-04-07 07:30:40 --> Total execution time: 0.0257
INFO - 2023-04-07 07:30:40 --> Model "Cluster_model" initialized
INFO - 2023-04-07 07:30:40 --> Final output sent to browser
DEBUG - 2023-04-07 07:30:40 --> Total execution time: 0.0182
INFO - 2023-04-07 07:32:20 --> Config Class Initialized
INFO - 2023-04-07 07:32:20 --> Hooks Class Initialized
DEBUG - 2023-04-07 07:32:20 --> UTF-8 Support Enabled
INFO - 2023-04-07 07:32:20 --> Utf8 Class Initialized
INFO - 2023-04-07 07:32:20 --> URI Class Initialized
INFO - 2023-04-07 07:32:20 --> Router Class Initialized
INFO - 2023-04-07 07:32:20 --> Output Class Initialized
INFO - 2023-04-07 07:32:20 --> Security Class Initialized
DEBUG - 2023-04-07 07:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 07:32:20 --> Input Class Initialized
INFO - 2023-04-07 07:32:20 --> Language Class Initialized
INFO - 2023-04-07 07:32:20 --> Loader Class Initialized
INFO - 2023-04-07 07:32:20 --> Controller Class Initialized
DEBUG - 2023-04-07 07:32:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 07:32:20 --> Database Driver Class Initialized
INFO - 2023-04-07 07:32:20 --> Model "Cluster_model" initialized
INFO - 2023-04-07 07:32:20 --> Final output sent to browser
DEBUG - 2023-04-07 07:32:20 --> Total execution time: 0.0642
INFO - 2023-04-07 07:32:20 --> Config Class Initialized
INFO - 2023-04-07 07:32:20 --> Hooks Class Initialized
DEBUG - 2023-04-07 07:32:20 --> UTF-8 Support Enabled
INFO - 2023-04-07 07:32:20 --> Utf8 Class Initialized
INFO - 2023-04-07 07:32:20 --> URI Class Initialized
INFO - 2023-04-07 07:32:20 --> Router Class Initialized
INFO - 2023-04-07 07:32:20 --> Output Class Initialized
INFO - 2023-04-07 07:32:20 --> Security Class Initialized
DEBUG - 2023-04-07 07:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 07:32:20 --> Input Class Initialized
INFO - 2023-04-07 07:32:20 --> Language Class Initialized
INFO - 2023-04-07 07:32:20 --> Loader Class Initialized
INFO - 2023-04-07 07:32:20 --> Controller Class Initialized
DEBUG - 2023-04-07 07:32:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 07:32:20 --> Database Driver Class Initialized
INFO - 2023-04-07 07:32:20 --> Model "Cluster_model" initialized
INFO - 2023-04-07 07:32:20 --> Final output sent to browser
DEBUG - 2023-04-07 07:32:20 --> Total execution time: 0.1007
INFO - 2023-04-07 07:42:07 --> Config Class Initialized
INFO - 2023-04-07 07:42:07 --> Hooks Class Initialized
DEBUG - 2023-04-07 07:42:07 --> UTF-8 Support Enabled
INFO - 2023-04-07 07:42:07 --> Utf8 Class Initialized
INFO - 2023-04-07 07:42:07 --> URI Class Initialized
INFO - 2023-04-07 07:42:07 --> Router Class Initialized
INFO - 2023-04-07 07:42:07 --> Output Class Initialized
INFO - 2023-04-07 07:42:07 --> Security Class Initialized
DEBUG - 2023-04-07 07:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 07:42:07 --> Input Class Initialized
INFO - 2023-04-07 07:42:07 --> Language Class Initialized
INFO - 2023-04-07 07:42:07 --> Loader Class Initialized
INFO - 2023-04-07 07:42:07 --> Controller Class Initialized
DEBUG - 2023-04-07 07:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 07:42:07 --> Final output sent to browser
DEBUG - 2023-04-07 07:42:07 --> Total execution time: 0.0450
INFO - 2023-04-07 07:42:07 --> Config Class Initialized
INFO - 2023-04-07 07:42:07 --> Hooks Class Initialized
DEBUG - 2023-04-07 07:42:07 --> UTF-8 Support Enabled
INFO - 2023-04-07 07:42:07 --> Utf8 Class Initialized
INFO - 2023-04-07 07:42:07 --> URI Class Initialized
INFO - 2023-04-07 07:42:07 --> Router Class Initialized
INFO - 2023-04-07 07:42:07 --> Output Class Initialized
INFO - 2023-04-07 07:42:07 --> Security Class Initialized
DEBUG - 2023-04-07 07:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 07:42:07 --> Input Class Initialized
INFO - 2023-04-07 07:42:07 --> Language Class Initialized
INFO - 2023-04-07 07:42:07 --> Loader Class Initialized
INFO - 2023-04-07 07:42:07 --> Controller Class Initialized
DEBUG - 2023-04-07 07:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 07:42:07 --> Database Driver Class Initialized
INFO - 2023-04-07 07:42:08 --> Model "Cluster_model" initialized
INFO - 2023-04-07 07:42:08 --> Final output sent to browser
DEBUG - 2023-04-07 07:42:08 --> Total execution time: 0.0174
INFO - 2023-04-07 08:13:02 --> Config Class Initialized
INFO - 2023-04-07 08:13:02 --> Hooks Class Initialized
DEBUG - 2023-04-07 08:13:02 --> UTF-8 Support Enabled
INFO - 2023-04-07 08:13:02 --> Utf8 Class Initialized
INFO - 2023-04-07 08:13:02 --> URI Class Initialized
INFO - 2023-04-07 08:13:02 --> Router Class Initialized
INFO - 2023-04-07 08:13:02 --> Output Class Initialized
INFO - 2023-04-07 08:13:02 --> Security Class Initialized
DEBUG - 2023-04-07 08:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 08:13:02 --> Input Class Initialized
INFO - 2023-04-07 08:13:02 --> Language Class Initialized
INFO - 2023-04-07 08:13:02 --> Loader Class Initialized
INFO - 2023-04-07 08:13:02 --> Controller Class Initialized
DEBUG - 2023-04-07 08:13:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 08:13:02 --> Database Driver Class Initialized
INFO - 2023-04-07 08:13:02 --> Model "Cluster_model" initialized
INFO - 2023-04-07 08:13:03 --> Final output sent to browser
DEBUG - 2023-04-07 08:13:03 --> Total execution time: 0.1310
INFO - 2023-04-07 08:13:03 --> Config Class Initialized
INFO - 2023-04-07 08:13:03 --> Hooks Class Initialized
DEBUG - 2023-04-07 08:13:03 --> UTF-8 Support Enabled
INFO - 2023-04-07 08:13:03 --> Utf8 Class Initialized
INFO - 2023-04-07 08:13:03 --> URI Class Initialized
INFO - 2023-04-07 08:13:03 --> Router Class Initialized
INFO - 2023-04-07 08:13:03 --> Output Class Initialized
INFO - 2023-04-07 08:13:03 --> Security Class Initialized
DEBUG - 2023-04-07 08:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 08:13:03 --> Input Class Initialized
INFO - 2023-04-07 08:13:03 --> Language Class Initialized
INFO - 2023-04-07 08:13:03 --> Loader Class Initialized
INFO - 2023-04-07 08:13:03 --> Controller Class Initialized
DEBUG - 2023-04-07 08:13:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 08:13:03 --> Database Driver Class Initialized
INFO - 2023-04-07 08:13:03 --> Model "Cluster_model" initialized
INFO - 2023-04-07 08:13:03 --> Final output sent to browser
DEBUG - 2023-04-07 08:13:03 --> Total execution time: 0.1185
INFO - 2023-04-07 09:52:54 --> Config Class Initialized
INFO - 2023-04-07 09:52:54 --> Hooks Class Initialized
DEBUG - 2023-04-07 09:52:54 --> UTF-8 Support Enabled
INFO - 2023-04-07 09:52:54 --> Utf8 Class Initialized
INFO - 2023-04-07 09:52:54 --> URI Class Initialized
INFO - 2023-04-07 09:52:54 --> Router Class Initialized
INFO - 2023-04-07 09:52:54 --> Output Class Initialized
INFO - 2023-04-07 09:52:54 --> Security Class Initialized
DEBUG - 2023-04-07 09:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 09:52:54 --> Input Class Initialized
INFO - 2023-04-07 09:52:54 --> Language Class Initialized
INFO - 2023-04-07 09:52:54 --> Loader Class Initialized
INFO - 2023-04-07 09:52:54 --> Controller Class Initialized
DEBUG - 2023-04-07 09:52:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 09:52:54 --> Final output sent to browser
DEBUG - 2023-04-07 09:52:54 --> Total execution time: 0.0040
INFO - 2023-04-07 09:52:54 --> Config Class Initialized
INFO - 2023-04-07 09:52:54 --> Hooks Class Initialized
DEBUG - 2023-04-07 09:52:54 --> UTF-8 Support Enabled
INFO - 2023-04-07 09:52:54 --> Utf8 Class Initialized
INFO - 2023-04-07 09:52:54 --> URI Class Initialized
INFO - 2023-04-07 09:52:54 --> Router Class Initialized
INFO - 2023-04-07 09:52:54 --> Output Class Initialized
INFO - 2023-04-07 09:52:54 --> Security Class Initialized
DEBUG - 2023-04-07 09:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 09:52:54 --> Input Class Initialized
INFO - 2023-04-07 09:52:54 --> Language Class Initialized
INFO - 2023-04-07 09:52:54 --> Loader Class Initialized
INFO - 2023-04-07 09:52:54 --> Controller Class Initialized
DEBUG - 2023-04-07 09:52:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 09:52:54 --> Database Driver Class Initialized
INFO - 2023-04-07 09:52:54 --> Model "Cluster_model" initialized
INFO - 2023-04-07 09:52:54 --> Final output sent to browser
DEBUG - 2023-04-07 09:52:54 --> Total execution time: 0.0631
INFO - 2023-04-07 09:52:56 --> Config Class Initialized
INFO - 2023-04-07 09:52:56 --> Hooks Class Initialized
DEBUG - 2023-04-07 09:52:56 --> UTF-8 Support Enabled
INFO - 2023-04-07 09:52:56 --> Utf8 Class Initialized
INFO - 2023-04-07 09:52:56 --> URI Class Initialized
INFO - 2023-04-07 09:52:56 --> Router Class Initialized
INFO - 2023-04-07 09:52:56 --> Output Class Initialized
INFO - 2023-04-07 09:52:56 --> Security Class Initialized
DEBUG - 2023-04-07 09:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 09:52:56 --> Input Class Initialized
INFO - 2023-04-07 09:52:56 --> Language Class Initialized
INFO - 2023-04-07 09:52:56 --> Loader Class Initialized
INFO - 2023-04-07 09:52:56 --> Controller Class Initialized
DEBUG - 2023-04-07 09:52:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 09:52:56 --> Database Driver Class Initialized
INFO - 2023-04-07 09:52:56 --> Model "Cluster_model" initialized
INFO - 2023-04-07 09:52:57 --> Final output sent to browser
DEBUG - 2023-04-07 09:52:57 --> Total execution time: 0.6545
INFO - 2023-04-07 09:52:57 --> Config Class Initialized
INFO - 2023-04-07 09:52:57 --> Hooks Class Initialized
DEBUG - 2023-04-07 09:52:57 --> UTF-8 Support Enabled
INFO - 2023-04-07 09:52:57 --> Utf8 Class Initialized
INFO - 2023-04-07 09:52:57 --> URI Class Initialized
INFO - 2023-04-07 09:52:57 --> Router Class Initialized
INFO - 2023-04-07 09:52:57 --> Output Class Initialized
INFO - 2023-04-07 09:52:57 --> Security Class Initialized
DEBUG - 2023-04-07 09:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 09:52:57 --> Input Class Initialized
INFO - 2023-04-07 09:52:57 --> Language Class Initialized
INFO - 2023-04-07 09:52:57 --> Loader Class Initialized
INFO - 2023-04-07 09:52:57 --> Controller Class Initialized
DEBUG - 2023-04-07 09:52:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 09:52:57 --> Database Driver Class Initialized
INFO - 2023-04-07 09:52:57 --> Model "Cluster_model" initialized
INFO - 2023-04-07 09:52:57 --> Final output sent to browser
DEBUG - 2023-04-07 09:52:57 --> Total execution time: 0.3802
INFO - 2023-04-07 10:42:34 --> Config Class Initialized
INFO - 2023-04-07 10:42:34 --> Hooks Class Initialized
DEBUG - 2023-04-07 10:42:34 --> UTF-8 Support Enabled
INFO - 2023-04-07 10:42:34 --> Utf8 Class Initialized
INFO - 2023-04-07 10:42:34 --> URI Class Initialized
INFO - 2023-04-07 10:42:34 --> Router Class Initialized
INFO - 2023-04-07 10:42:34 --> Output Class Initialized
INFO - 2023-04-07 10:42:34 --> Security Class Initialized
DEBUG - 2023-04-07 10:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 10:42:34 --> Input Class Initialized
INFO - 2023-04-07 10:42:34 --> Language Class Initialized
INFO - 2023-04-07 10:42:34 --> Loader Class Initialized
INFO - 2023-04-07 10:42:34 --> Controller Class Initialized
DEBUG - 2023-04-07 10:42:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 10:42:34 --> Database Driver Class Initialized
INFO - 2023-04-07 10:42:34 --> Model "Cluster_model" initialized
INFO - 2023-04-07 10:42:34 --> Final output sent to browser
DEBUG - 2023-04-07 10:42:34 --> Total execution time: 0.3810
INFO - 2023-04-07 10:42:34 --> Config Class Initialized
INFO - 2023-04-07 10:42:34 --> Hooks Class Initialized
DEBUG - 2023-04-07 10:42:34 --> UTF-8 Support Enabled
INFO - 2023-04-07 10:42:34 --> Utf8 Class Initialized
INFO - 2023-04-07 10:42:34 --> URI Class Initialized
INFO - 2023-04-07 10:42:34 --> Router Class Initialized
INFO - 2023-04-07 10:42:34 --> Output Class Initialized
INFO - 2023-04-07 10:42:34 --> Security Class Initialized
DEBUG - 2023-04-07 10:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 10:42:34 --> Input Class Initialized
INFO - 2023-04-07 10:42:34 --> Language Class Initialized
INFO - 2023-04-07 10:42:34 --> Loader Class Initialized
INFO - 2023-04-07 10:42:34 --> Controller Class Initialized
DEBUG - 2023-04-07 10:42:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 10:42:34 --> Database Driver Class Initialized
INFO - 2023-04-07 10:42:34 --> Model "Cluster_model" initialized
INFO - 2023-04-07 10:42:34 --> Final output sent to browser
DEBUG - 2023-04-07 10:42:34 --> Total execution time: 0.0689
INFO - 2023-04-07 10:42:47 --> Config Class Initialized
INFO - 2023-04-07 10:42:47 --> Hooks Class Initialized
DEBUG - 2023-04-07 10:42:47 --> UTF-8 Support Enabled
INFO - 2023-04-07 10:42:47 --> Utf8 Class Initialized
INFO - 2023-04-07 10:42:47 --> URI Class Initialized
INFO - 2023-04-07 10:42:47 --> Router Class Initialized
INFO - 2023-04-07 10:42:47 --> Output Class Initialized
INFO - 2023-04-07 10:42:47 --> Security Class Initialized
DEBUG - 2023-04-07 10:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 10:42:47 --> Input Class Initialized
INFO - 2023-04-07 10:42:47 --> Language Class Initialized
INFO - 2023-04-07 10:42:47 --> Loader Class Initialized
INFO - 2023-04-07 10:42:47 --> Controller Class Initialized
DEBUG - 2023-04-07 10:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 10:42:47 --> Database Driver Class Initialized
INFO - 2023-04-07 10:42:47 --> Model "Cluster_model" initialized
INFO - 2023-04-07 10:42:47 --> Final output sent to browser
DEBUG - 2023-04-07 10:42:47 --> Total execution time: 0.6270
INFO - 2023-04-07 10:42:47 --> Config Class Initialized
INFO - 2023-04-07 10:42:47 --> Hooks Class Initialized
DEBUG - 2023-04-07 10:42:47 --> UTF-8 Support Enabled
INFO - 2023-04-07 10:42:47 --> Utf8 Class Initialized
INFO - 2023-04-07 10:42:47 --> URI Class Initialized
INFO - 2023-04-07 10:42:47 --> Router Class Initialized
INFO - 2023-04-07 10:42:47 --> Output Class Initialized
INFO - 2023-04-07 10:42:47 --> Security Class Initialized
DEBUG - 2023-04-07 10:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-07 10:42:48 --> Input Class Initialized
INFO - 2023-04-07 10:42:48 --> Language Class Initialized
INFO - 2023-04-07 10:42:48 --> Loader Class Initialized
INFO - 2023-04-07 10:42:48 --> Controller Class Initialized
DEBUG - 2023-04-07 10:42:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-07 10:42:48 --> Database Driver Class Initialized
INFO - 2023-04-07 10:42:48 --> Model "Cluster_model" initialized
INFO - 2023-04-07 10:42:48 --> Final output sent to browser
DEBUG - 2023-04-07 10:42:48 --> Total execution time: 0.7563
