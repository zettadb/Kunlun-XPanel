<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-12-09 02:33:37 --> Config Class Initialized
INFO - 2022-12-09 02:33:37 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:33:37 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:33:37 --> Utf8 Class Initialized
INFO - 2022-12-09 02:33:37 --> URI Class Initialized
INFO - 2022-12-09 02:33:37 --> Router Class Initialized
INFO - 2022-12-09 02:33:37 --> Output Class Initialized
INFO - 2022-12-09 02:33:37 --> Security Class Initialized
DEBUG - 2022-12-09 02:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:33:37 --> Input Class Initialized
INFO - 2022-12-09 02:33:37 --> Language Class Initialized
INFO - 2022-12-09 02:33:37 --> Loader Class Initialized
INFO - 2022-12-09 02:33:37 --> Controller Class Initialized
DEBUG - 2022-12-09 02:33:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:33:37 --> Database Driver Class Initialized
INFO - 2022-12-09 02:33:37 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:33:37 --> Final output sent to browser
DEBUG - 2022-12-09 02:33:37 --> Total execution time: 0.1024
INFO - 2022-12-09 02:33:37 --> Config Class Initialized
INFO - 2022-12-09 02:33:37 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:33:37 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:33:37 --> Utf8 Class Initialized
INFO - 2022-12-09 02:33:37 --> URI Class Initialized
INFO - 2022-12-09 02:33:37 --> Router Class Initialized
INFO - 2022-12-09 02:33:37 --> Output Class Initialized
INFO - 2022-12-09 02:33:37 --> Security Class Initialized
DEBUG - 2022-12-09 02:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:33:37 --> Input Class Initialized
INFO - 2022-12-09 02:33:37 --> Language Class Initialized
INFO - 2022-12-09 02:33:37 --> Loader Class Initialized
INFO - 2022-12-09 02:33:37 --> Controller Class Initialized
DEBUG - 2022-12-09 02:33:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:33:37 --> Database Driver Class Initialized
INFO - 2022-12-09 02:33:37 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:33:37 --> Final output sent to browser
DEBUG - 2022-12-09 02:33:37 --> Total execution time: 0.0763
INFO - 2022-12-09 02:34:48 --> Config Class Initialized
INFO - 2022-12-09 02:34:48 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:34:48 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:34:48 --> Utf8 Class Initialized
INFO - 2022-12-09 02:34:48 --> URI Class Initialized
INFO - 2022-12-09 02:34:48 --> Router Class Initialized
INFO - 2022-12-09 02:34:48 --> Output Class Initialized
INFO - 2022-12-09 02:34:48 --> Security Class Initialized
DEBUG - 2022-12-09 02:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:34:48 --> Input Class Initialized
INFO - 2022-12-09 02:34:48 --> Language Class Initialized
INFO - 2022-12-09 02:34:48 --> Loader Class Initialized
INFO - 2022-12-09 02:34:48 --> Controller Class Initialized
DEBUG - 2022-12-09 02:34:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:34:48 --> Database Driver Class Initialized
INFO - 2022-12-09 02:34:48 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:34:48 --> Final output sent to browser
DEBUG - 2022-12-09 02:34:48 --> Total execution time: 0.0896
INFO - 2022-12-09 02:34:48 --> Config Class Initialized
INFO - 2022-12-09 02:34:48 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:34:48 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:34:48 --> Utf8 Class Initialized
INFO - 2022-12-09 02:34:48 --> URI Class Initialized
INFO - 2022-12-09 02:34:48 --> Router Class Initialized
INFO - 2022-12-09 02:34:48 --> Output Class Initialized
INFO - 2022-12-09 02:34:48 --> Security Class Initialized
DEBUG - 2022-12-09 02:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:34:48 --> Input Class Initialized
INFO - 2022-12-09 02:34:48 --> Language Class Initialized
INFO - 2022-12-09 02:34:48 --> Loader Class Initialized
INFO - 2022-12-09 02:34:48 --> Controller Class Initialized
DEBUG - 2022-12-09 02:34:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:34:48 --> Database Driver Class Initialized
INFO - 2022-12-09 02:34:48 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:34:48 --> Final output sent to browser
DEBUG - 2022-12-09 02:34:48 --> Total execution time: 0.0835
INFO - 2022-12-09 02:34:52 --> Config Class Initialized
INFO - 2022-12-09 02:34:52 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:34:52 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:34:52 --> Utf8 Class Initialized
INFO - 2022-12-09 02:34:52 --> URI Class Initialized
INFO - 2022-12-09 02:34:52 --> Router Class Initialized
INFO - 2022-12-09 02:34:52 --> Output Class Initialized
INFO - 2022-12-09 02:34:52 --> Security Class Initialized
DEBUG - 2022-12-09 02:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:34:52 --> Input Class Initialized
INFO - 2022-12-09 02:34:52 --> Language Class Initialized
INFO - 2022-12-09 02:34:52 --> Loader Class Initialized
INFO - 2022-12-09 02:34:52 --> Controller Class Initialized
DEBUG - 2022-12-09 02:34:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:34:52 --> Database Driver Class Initialized
INFO - 2022-12-09 02:34:52 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:34:52 --> Final output sent to browser
DEBUG - 2022-12-09 02:34:52 --> Total execution time: 0.0758
INFO - 2022-12-09 02:34:52 --> Config Class Initialized
INFO - 2022-12-09 02:34:52 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:34:52 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:34:52 --> Utf8 Class Initialized
INFO - 2022-12-09 02:34:52 --> URI Class Initialized
INFO - 2022-12-09 02:34:52 --> Router Class Initialized
INFO - 2022-12-09 02:34:52 --> Output Class Initialized
INFO - 2022-12-09 02:34:52 --> Security Class Initialized
DEBUG - 2022-12-09 02:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:34:52 --> Input Class Initialized
INFO - 2022-12-09 02:34:52 --> Language Class Initialized
INFO - 2022-12-09 02:34:52 --> Loader Class Initialized
INFO - 2022-12-09 02:34:52 --> Controller Class Initialized
DEBUG - 2022-12-09 02:34:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:34:52 --> Database Driver Class Initialized
INFO - 2022-12-09 02:34:52 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:34:52 --> Final output sent to browser
DEBUG - 2022-12-09 02:34:52 --> Total execution time: 0.0787
INFO - 2022-12-09 02:37:00 --> Config Class Initialized
INFO - 2022-12-09 02:37:00 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:37:00 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:37:00 --> Utf8 Class Initialized
INFO - 2022-12-09 02:37:00 --> URI Class Initialized
INFO - 2022-12-09 02:37:00 --> Router Class Initialized
INFO - 2022-12-09 02:37:00 --> Output Class Initialized
INFO - 2022-12-09 02:37:00 --> Security Class Initialized
DEBUG - 2022-12-09 02:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:37:00 --> Input Class Initialized
INFO - 2022-12-09 02:37:00 --> Language Class Initialized
INFO - 2022-12-09 02:37:00 --> Loader Class Initialized
INFO - 2022-12-09 02:37:00 --> Controller Class Initialized
DEBUG - 2022-12-09 02:37:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:37:00 --> Database Driver Class Initialized
INFO - 2022-12-09 02:37:00 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:37:00 --> Final output sent to browser
DEBUG - 2022-12-09 02:37:00 --> Total execution time: 0.0804
INFO - 2022-12-09 02:37:00 --> Config Class Initialized
INFO - 2022-12-09 02:37:00 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:37:00 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:37:00 --> Utf8 Class Initialized
INFO - 2022-12-09 02:37:00 --> URI Class Initialized
INFO - 2022-12-09 02:37:00 --> Router Class Initialized
INFO - 2022-12-09 02:37:00 --> Output Class Initialized
INFO - 2022-12-09 02:37:00 --> Security Class Initialized
DEBUG - 2022-12-09 02:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:37:00 --> Input Class Initialized
INFO - 2022-12-09 02:37:00 --> Language Class Initialized
INFO - 2022-12-09 02:37:00 --> Loader Class Initialized
INFO - 2022-12-09 02:37:00 --> Controller Class Initialized
DEBUG - 2022-12-09 02:37:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:37:00 --> Database Driver Class Initialized
INFO - 2022-12-09 02:37:00 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:37:00 --> Final output sent to browser
DEBUG - 2022-12-09 02:37:00 --> Total execution time: 0.0778
INFO - 2022-12-09 02:40:26 --> Config Class Initialized
INFO - 2022-12-09 02:40:26 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:40:26 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:40:26 --> Utf8 Class Initialized
INFO - 2022-12-09 02:40:26 --> URI Class Initialized
INFO - 2022-12-09 02:40:26 --> Router Class Initialized
INFO - 2022-12-09 02:40:26 --> Output Class Initialized
INFO - 2022-12-09 02:40:26 --> Security Class Initialized
DEBUG - 2022-12-09 02:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:40:26 --> Input Class Initialized
INFO - 2022-12-09 02:40:26 --> Language Class Initialized
INFO - 2022-12-09 02:40:26 --> Loader Class Initialized
INFO - 2022-12-09 02:40:26 --> Controller Class Initialized
DEBUG - 2022-12-09 02:40:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:40:26 --> Database Driver Class Initialized
INFO - 2022-12-09 02:40:26 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:40:26 --> Final output sent to browser
DEBUG - 2022-12-09 02:40:26 --> Total execution time: 0.1098
INFO - 2022-12-09 02:40:26 --> Config Class Initialized
INFO - 2022-12-09 02:40:26 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:40:26 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:40:26 --> Utf8 Class Initialized
INFO - 2022-12-09 02:40:26 --> URI Class Initialized
INFO - 2022-12-09 02:40:26 --> Router Class Initialized
INFO - 2022-12-09 02:40:26 --> Output Class Initialized
INFO - 2022-12-09 02:40:26 --> Security Class Initialized
DEBUG - 2022-12-09 02:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:40:26 --> Input Class Initialized
INFO - 2022-12-09 02:40:26 --> Language Class Initialized
INFO - 2022-12-09 02:40:26 --> Loader Class Initialized
INFO - 2022-12-09 02:40:26 --> Controller Class Initialized
DEBUG - 2022-12-09 02:40:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:40:26 --> Database Driver Class Initialized
INFO - 2022-12-09 02:40:26 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:40:26 --> Final output sent to browser
DEBUG - 2022-12-09 02:40:26 --> Total execution time: 0.0809
INFO - 2022-12-09 02:42:18 --> Config Class Initialized
INFO - 2022-12-09 02:42:18 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:42:18 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:42:18 --> Utf8 Class Initialized
INFO - 2022-12-09 02:42:18 --> URI Class Initialized
INFO - 2022-12-09 02:42:18 --> Router Class Initialized
INFO - 2022-12-09 02:42:18 --> Output Class Initialized
INFO - 2022-12-09 02:42:18 --> Security Class Initialized
DEBUG - 2022-12-09 02:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:42:18 --> Input Class Initialized
INFO - 2022-12-09 02:42:18 --> Language Class Initialized
INFO - 2022-12-09 02:42:18 --> Loader Class Initialized
INFO - 2022-12-09 02:42:18 --> Controller Class Initialized
DEBUG - 2022-12-09 02:42:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:42:18 --> Database Driver Class Initialized
INFO - 2022-12-09 02:42:18 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:42:18 --> Final output sent to browser
DEBUG - 2022-12-09 02:42:18 --> Total execution time: 0.0595
INFO - 2022-12-09 02:42:18 --> Config Class Initialized
INFO - 2022-12-09 02:42:18 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:42:18 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:42:18 --> Utf8 Class Initialized
INFO - 2022-12-09 02:42:18 --> URI Class Initialized
INFO - 2022-12-09 02:42:18 --> Router Class Initialized
INFO - 2022-12-09 02:42:18 --> Output Class Initialized
INFO - 2022-12-09 02:42:18 --> Security Class Initialized
DEBUG - 2022-12-09 02:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:42:18 --> Input Class Initialized
INFO - 2022-12-09 02:42:18 --> Language Class Initialized
INFO - 2022-12-09 02:42:18 --> Loader Class Initialized
INFO - 2022-12-09 02:42:18 --> Controller Class Initialized
DEBUG - 2022-12-09 02:42:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:42:18 --> Database Driver Class Initialized
INFO - 2022-12-09 02:42:18 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:42:18 --> Final output sent to browser
DEBUG - 2022-12-09 02:42:18 --> Total execution time: 0.0690
INFO - 2022-12-09 02:44:56 --> Config Class Initialized
INFO - 2022-12-09 02:44:56 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:44:56 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:44:56 --> Utf8 Class Initialized
INFO - 2022-12-09 02:44:56 --> URI Class Initialized
INFO - 2022-12-09 02:44:56 --> Router Class Initialized
INFO - 2022-12-09 02:44:56 --> Output Class Initialized
INFO - 2022-12-09 02:44:56 --> Security Class Initialized
DEBUG - 2022-12-09 02:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:44:56 --> Input Class Initialized
INFO - 2022-12-09 02:44:56 --> Language Class Initialized
INFO - 2022-12-09 02:44:56 --> Loader Class Initialized
INFO - 2022-12-09 02:44:56 --> Controller Class Initialized
DEBUG - 2022-12-09 02:44:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:44:56 --> Database Driver Class Initialized
INFO - 2022-12-09 02:44:56 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:44:56 --> Final output sent to browser
DEBUG - 2022-12-09 02:44:56 --> Total execution time: 0.0974
INFO - 2022-12-09 02:44:56 --> Config Class Initialized
INFO - 2022-12-09 02:44:56 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:44:56 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:44:56 --> Utf8 Class Initialized
INFO - 2022-12-09 02:44:56 --> URI Class Initialized
INFO - 2022-12-09 02:44:56 --> Router Class Initialized
INFO - 2022-12-09 02:44:56 --> Output Class Initialized
INFO - 2022-12-09 02:44:56 --> Security Class Initialized
DEBUG - 2022-12-09 02:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:44:56 --> Input Class Initialized
INFO - 2022-12-09 02:44:56 --> Language Class Initialized
INFO - 2022-12-09 02:44:56 --> Loader Class Initialized
INFO - 2022-12-09 02:44:56 --> Controller Class Initialized
DEBUG - 2022-12-09 02:44:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:44:56 --> Database Driver Class Initialized
INFO - 2022-12-09 02:44:56 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:44:56 --> Final output sent to browser
DEBUG - 2022-12-09 02:44:56 --> Total execution time: 0.0795
INFO - 2022-12-09 02:48:25 --> Config Class Initialized
INFO - 2022-12-09 02:48:25 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:48:25 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:48:25 --> Utf8 Class Initialized
INFO - 2022-12-09 02:48:25 --> URI Class Initialized
INFO - 2022-12-09 02:48:25 --> Router Class Initialized
INFO - 2022-12-09 02:48:25 --> Output Class Initialized
INFO - 2022-12-09 02:48:25 --> Security Class Initialized
DEBUG - 2022-12-09 02:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:48:25 --> Input Class Initialized
INFO - 2022-12-09 02:48:25 --> Language Class Initialized
INFO - 2022-12-09 02:48:25 --> Loader Class Initialized
INFO - 2022-12-09 02:48:25 --> Controller Class Initialized
DEBUG - 2022-12-09 02:48:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:48:25 --> Database Driver Class Initialized
INFO - 2022-12-09 02:48:25 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:48:25 --> Final output sent to browser
DEBUG - 2022-12-09 02:48:25 --> Total execution time: 0.1041
INFO - 2022-12-09 02:48:25 --> Config Class Initialized
INFO - 2022-12-09 02:48:25 --> Hooks Class Initialized
DEBUG - 2022-12-09 02:48:25 --> UTF-8 Support Enabled
INFO - 2022-12-09 02:48:25 --> Utf8 Class Initialized
INFO - 2022-12-09 02:48:25 --> URI Class Initialized
INFO - 2022-12-09 02:48:25 --> Router Class Initialized
INFO - 2022-12-09 02:48:25 --> Output Class Initialized
INFO - 2022-12-09 02:48:25 --> Security Class Initialized
DEBUG - 2022-12-09 02:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 02:48:25 --> Input Class Initialized
INFO - 2022-12-09 02:48:25 --> Language Class Initialized
INFO - 2022-12-09 02:48:25 --> Loader Class Initialized
INFO - 2022-12-09 02:48:25 --> Controller Class Initialized
DEBUG - 2022-12-09 02:48:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 02:48:25 --> Database Driver Class Initialized
INFO - 2022-12-09 02:48:25 --> Model "Cluster_model" initialized
INFO - 2022-12-09 02:48:25 --> Final output sent to browser
DEBUG - 2022-12-09 02:48:25 --> Total execution time: 0.1015
INFO - 2022-12-09 03:09:54 --> Config Class Initialized
INFO - 2022-12-09 03:09:54 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:09:54 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:09:54 --> Utf8 Class Initialized
INFO - 2022-12-09 03:09:54 --> URI Class Initialized
INFO - 2022-12-09 03:09:54 --> Router Class Initialized
INFO - 2022-12-09 03:09:54 --> Output Class Initialized
INFO - 2022-12-09 03:09:54 --> Security Class Initialized
DEBUG - 2022-12-09 03:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:09:54 --> Input Class Initialized
INFO - 2022-12-09 03:09:54 --> Language Class Initialized
INFO - 2022-12-09 03:09:54 --> Loader Class Initialized
INFO - 2022-12-09 03:09:54 --> Controller Class Initialized
DEBUG - 2022-12-09 03:09:54 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:09:54 --> Database Driver Class Initialized
INFO - 2022-12-09 03:09:54 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:09:54 --> Final output sent to browser
DEBUG - 2022-12-09 03:09:54 --> Total execution time: 0.0548
INFO - 2022-12-09 03:09:54 --> Config Class Initialized
INFO - 2022-12-09 03:09:54 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:09:54 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:09:54 --> Utf8 Class Initialized
INFO - 2022-12-09 03:09:54 --> URI Class Initialized
INFO - 2022-12-09 03:09:54 --> Router Class Initialized
INFO - 2022-12-09 03:09:54 --> Output Class Initialized
INFO - 2022-12-09 03:09:54 --> Security Class Initialized
DEBUG - 2022-12-09 03:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:09:54 --> Input Class Initialized
INFO - 2022-12-09 03:09:54 --> Language Class Initialized
INFO - 2022-12-09 03:09:54 --> Loader Class Initialized
INFO - 2022-12-09 03:09:54 --> Controller Class Initialized
DEBUG - 2022-12-09 03:09:54 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:09:54 --> Database Driver Class Initialized
INFO - 2022-12-09 03:09:54 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:09:54 --> Final output sent to browser
DEBUG - 2022-12-09 03:09:54 --> Total execution time: 0.0527
INFO - 2022-12-09 03:10:03 --> Config Class Initialized
INFO - 2022-12-09 03:10:03 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:10:03 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:03 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:03 --> URI Class Initialized
INFO - 2022-12-09 03:10:03 --> Router Class Initialized
INFO - 2022-12-09 03:10:03 --> Output Class Initialized
INFO - 2022-12-09 03:10:03 --> Security Class Initialized
DEBUG - 2022-12-09 03:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:03 --> Input Class Initialized
INFO - 2022-12-09 03:10:03 --> Language Class Initialized
INFO - 2022-12-09 03:10:03 --> Loader Class Initialized
INFO - 2022-12-09 03:10:03 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:03 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:03 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:10:03 --> Final output sent to browser
DEBUG - 2022-12-09 03:10:03 --> Total execution time: 0.0370
INFO - 2022-12-09 03:10:03 --> Config Class Initialized
INFO - 2022-12-09 03:10:03 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:10:03 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:03 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:03 --> URI Class Initialized
INFO - 2022-12-09 03:10:03 --> Router Class Initialized
INFO - 2022-12-09 03:10:03 --> Output Class Initialized
INFO - 2022-12-09 03:10:03 --> Security Class Initialized
DEBUG - 2022-12-09 03:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:03 --> Input Class Initialized
INFO - 2022-12-09 03:10:03 --> Language Class Initialized
INFO - 2022-12-09 03:10:03 --> Loader Class Initialized
INFO - 2022-12-09 03:10:03 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:03 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:03 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:10:03 --> Final output sent to browser
DEBUG - 2022-12-09 03:10:03 --> Total execution time: 0.0547
INFO - 2022-12-09 03:10:25 --> Config Class Initialized
INFO - 2022-12-09 03:10:25 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:10:25 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:25 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:25 --> URI Class Initialized
INFO - 2022-12-09 03:10:25 --> Router Class Initialized
INFO - 2022-12-09 03:10:25 --> Output Class Initialized
INFO - 2022-12-09 03:10:25 --> Security Class Initialized
DEBUG - 2022-12-09 03:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:25 --> Input Class Initialized
INFO - 2022-12-09 03:10:25 --> Language Class Initialized
INFO - 2022-12-09 03:10:25 --> Loader Class Initialized
INFO - 2022-12-09 03:10:25 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:25 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:25 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:10:25 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:25 --> Model "Login_model" initialized
INFO - 2022-12-09 03:10:25 --> Final output sent to browser
DEBUG - 2022-12-09 03:10:25 --> Total execution time: 0.1594
INFO - 2022-12-09 03:10:25 --> Config Class Initialized
INFO - 2022-12-09 03:10:25 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:10:25 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:25 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:25 --> URI Class Initialized
INFO - 2022-12-09 03:10:25 --> Router Class Initialized
INFO - 2022-12-09 03:10:25 --> Output Class Initialized
INFO - 2022-12-09 03:10:25 --> Security Class Initialized
DEBUG - 2022-12-09 03:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:25 --> Input Class Initialized
INFO - 2022-12-09 03:10:25 --> Language Class Initialized
INFO - 2022-12-09 03:10:25 --> Loader Class Initialized
INFO - 2022-12-09 03:10:25 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:25 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:25 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:10:25 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:25 --> Model "Login_model" initialized
INFO - 2022-12-09 03:10:25 --> Final output sent to browser
DEBUG - 2022-12-09 03:10:25 --> Total execution time: 0.2020
INFO - 2022-12-09 03:10:31 --> Config Class Initialized
INFO - 2022-12-09 03:10:31 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:10:31 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:31 --> Config Class Initialized
INFO - 2022-12-09 03:10:31 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:31 --> Hooks Class Initialized
INFO - 2022-12-09 03:10:31 --> URI Class Initialized
INFO - 2022-12-09 03:10:31 --> Router Class Initialized
DEBUG - 2022-12-09 03:10:31 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:31 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:31 --> Output Class Initialized
INFO - 2022-12-09 03:10:31 --> URI Class Initialized
INFO - 2022-12-09 03:10:31 --> Security Class Initialized
DEBUG - 2022-12-09 03:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:31 --> Router Class Initialized
INFO - 2022-12-09 03:10:31 --> Input Class Initialized
INFO - 2022-12-09 03:10:31 --> Language Class Initialized
INFO - 2022-12-09 03:10:31 --> Output Class Initialized
INFO - 2022-12-09 03:10:31 --> Security Class Initialized
INFO - 2022-12-09 03:10:31 --> Loader Class Initialized
DEBUG - 2022-12-09 03:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:31 --> Input Class Initialized
INFO - 2022-12-09 03:10:31 --> Language Class Initialized
INFO - 2022-12-09 03:10:31 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:31 --> Loader Class Initialized
INFO - 2022-12-09 03:10:31 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:31 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:31 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:31 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:10:31 --> Final output sent to browser
DEBUG - 2022-12-09 03:10:31 --> Total execution time: 0.0429
INFO - 2022-12-09 03:10:31 --> Config Class Initialized
INFO - 2022-12-09 03:10:31 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:10:31 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:31 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:31 --> URI Class Initialized
INFO - 2022-12-09 03:10:31 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:10:31 --> Router Class Initialized
INFO - 2022-12-09 03:10:31 --> Output Class Initialized
INFO - 2022-12-09 03:10:31 --> Security Class Initialized
DEBUG - 2022-12-09 03:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:31 --> Input Class Initialized
INFO - 2022-12-09 03:10:31 --> Language Class Initialized
INFO - 2022-12-09 03:10:31 --> Loader Class Initialized
INFO - 2022-12-09 03:10:31 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:31 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:31 --> Config Class Initialized
INFO - 2022-12-09 03:10:31 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:10:31 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:31 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:31 --> URI Class Initialized
INFO - 2022-12-09 03:10:31 --> Router Class Initialized
INFO - 2022-12-09 03:10:31 --> Output Class Initialized
INFO - 2022-12-09 03:10:31 --> Security Class Initialized
DEBUG - 2022-12-09 03:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:31 --> Input Class Initialized
INFO - 2022-12-09 03:10:31 --> Language Class Initialized
INFO - 2022-12-09 03:10:31 --> Loader Class Initialized
INFO - 2022-12-09 03:10:31 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:31 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:31 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:10:31 --> Final output sent to browser
DEBUG - 2022-12-09 03:10:31 --> Total execution time: 0.0571
INFO - 2022-12-09 03:10:31 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:10:31 --> Config Class Initialized
INFO - 2022-12-09 03:10:31 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:10:31 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:31 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:31 --> URI Class Initialized
INFO - 2022-12-09 03:10:31 --> Router Class Initialized
INFO - 2022-12-09 03:10:31 --> Output Class Initialized
INFO - 2022-12-09 03:10:31 --> Security Class Initialized
DEBUG - 2022-12-09 03:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:31 --> Input Class Initialized
INFO - 2022-12-09 03:10:31 --> Language Class Initialized
INFO - 2022-12-09 03:10:31 --> Loader Class Initialized
INFO - 2022-12-09 03:10:31 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:31 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:31 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:10:31 --> Config Class Initialized
INFO - 2022-12-09 03:10:31 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:10:31 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:31 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:31 --> URI Class Initialized
INFO - 2022-12-09 03:10:31 --> Router Class Initialized
INFO - 2022-12-09 03:10:31 --> Output Class Initialized
INFO - 2022-12-09 03:10:31 --> Security Class Initialized
DEBUG - 2022-12-09 03:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:31 --> Input Class Initialized
INFO - 2022-12-09 03:10:31 --> Language Class Initialized
INFO - 2022-12-09 03:10:31 --> Loader Class Initialized
INFO - 2022-12-09 03:10:31 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:31 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:31 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:10:45 --> Config Class Initialized
INFO - 2022-12-09 03:10:45 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:10:45 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:45 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:45 --> URI Class Initialized
INFO - 2022-12-09 03:10:45 --> Router Class Initialized
INFO - 2022-12-09 03:10:45 --> Output Class Initialized
INFO - 2022-12-09 03:10:45 --> Security Class Initialized
DEBUG - 2022-12-09 03:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:45 --> Input Class Initialized
INFO - 2022-12-09 03:10:45 --> Language Class Initialized
INFO - 2022-12-09 03:10:45 --> Loader Class Initialized
INFO - 2022-12-09 03:10:45 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:45 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:45 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:10:45 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:45 --> Model "Login_model" initialized
INFO - 2022-12-09 03:10:45 --> Final output sent to browser
DEBUG - 2022-12-09 03:10:45 --> Total execution time: 0.1176
INFO - 2022-12-09 03:10:45 --> Config Class Initialized
INFO - 2022-12-09 03:10:45 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:10:45 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:45 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:45 --> URI Class Initialized
INFO - 2022-12-09 03:10:45 --> Router Class Initialized
INFO - 2022-12-09 03:10:45 --> Output Class Initialized
INFO - 2022-12-09 03:10:45 --> Security Class Initialized
DEBUG - 2022-12-09 03:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:45 --> Input Class Initialized
INFO - 2022-12-09 03:10:45 --> Language Class Initialized
INFO - 2022-12-09 03:10:45 --> Loader Class Initialized
INFO - 2022-12-09 03:10:45 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:45 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:45 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:10:45 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:45 --> Model "Login_model" initialized
INFO - 2022-12-09 03:10:45 --> Final output sent to browser
DEBUG - 2022-12-09 03:10:45 --> Total execution time: 0.2512
INFO - 2022-12-09 03:10:56 --> Config Class Initialized
INFO - 2022-12-09 03:10:56 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:10:56 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:56 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:56 --> URI Class Initialized
INFO - 2022-12-09 03:10:56 --> Router Class Initialized
INFO - 2022-12-09 03:10:56 --> Output Class Initialized
INFO - 2022-12-09 03:10:56 --> Security Class Initialized
DEBUG - 2022-12-09 03:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:56 --> Input Class Initialized
INFO - 2022-12-09 03:10:56 --> Language Class Initialized
INFO - 2022-12-09 03:10:56 --> Loader Class Initialized
INFO - 2022-12-09 03:10:56 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:56 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:56 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:10:56 --> Config Class Initialized
INFO - 2022-12-09 03:10:56 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:10:56 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:10:56 --> Utf8 Class Initialized
INFO - 2022-12-09 03:10:56 --> URI Class Initialized
INFO - 2022-12-09 03:10:56 --> Router Class Initialized
INFO - 2022-12-09 03:10:56 --> Output Class Initialized
INFO - 2022-12-09 03:10:56 --> Security Class Initialized
DEBUG - 2022-12-09 03:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:10:56 --> Input Class Initialized
INFO - 2022-12-09 03:10:56 --> Language Class Initialized
INFO - 2022-12-09 03:10:56 --> Loader Class Initialized
INFO - 2022-12-09 03:10:56 --> Controller Class Initialized
DEBUG - 2022-12-09 03:10:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:10:56 --> Database Driver Class Initialized
INFO - 2022-12-09 03:10:56 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:11:06 --> Config Class Initialized
INFO - 2022-12-09 03:11:06 --> Hooks Class Initialized
INFO - 2022-12-09 03:11:06 --> Config Class Initialized
INFO - 2022-12-09 03:11:06 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:11:06 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:11:06 --> Utf8 Class Initialized
DEBUG - 2022-12-09 03:11:06 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:11:06 --> Utf8 Class Initialized
INFO - 2022-12-09 03:11:06 --> URI Class Initialized
INFO - 2022-12-09 03:11:06 --> URI Class Initialized
INFO - 2022-12-09 03:11:06 --> Router Class Initialized
INFO - 2022-12-09 03:11:06 --> Router Class Initialized
INFO - 2022-12-09 03:11:06 --> Output Class Initialized
INFO - 2022-12-09 03:11:06 --> Output Class Initialized
INFO - 2022-12-09 03:11:06 --> Security Class Initialized
INFO - 2022-12-09 03:11:06 --> Security Class Initialized
DEBUG - 2022-12-09 03:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:11:06 --> Input Class Initialized
DEBUG - 2022-12-09 03:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:11:06 --> Input Class Initialized
INFO - 2022-12-09 03:11:06 --> Language Class Initialized
INFO - 2022-12-09 03:11:06 --> Language Class Initialized
INFO - 2022-12-09 03:11:06 --> Loader Class Initialized
INFO - 2022-12-09 03:11:06 --> Loader Class Initialized
INFO - 2022-12-09 03:11:06 --> Controller Class Initialized
INFO - 2022-12-09 03:11:06 --> Controller Class Initialized
DEBUG - 2022-12-09 03:11:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-09 03:11:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:11:06 --> Database Driver Class Initialized
INFO - 2022-12-09 03:11:06 --> Database Driver Class Initialized
INFO - 2022-12-09 03:11:06 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:11:06 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:11:06 --> Final output sent to browser
DEBUG - 2022-12-09 03:11:06 --> Total execution time: 0.0491
INFO - 2022-12-09 03:11:06 --> Config Class Initialized
INFO - 2022-12-09 03:11:06 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:11:06 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:11:06 --> Utf8 Class Initialized
INFO - 2022-12-09 03:11:06 --> URI Class Initialized
INFO - 2022-12-09 03:11:06 --> Router Class Initialized
INFO - 2022-12-09 03:11:06 --> Output Class Initialized
INFO - 2022-12-09 03:11:06 --> Security Class Initialized
DEBUG - 2022-12-09 03:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:11:06 --> Input Class Initialized
INFO - 2022-12-09 03:11:06 --> Language Class Initialized
INFO - 2022-12-09 03:11:06 --> Loader Class Initialized
INFO - 2022-12-09 03:11:06 --> Controller Class Initialized
DEBUG - 2022-12-09 03:11:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:11:06 --> Config Class Initialized
INFO - 2022-12-09 03:11:06 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:11:06 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:11:06 --> Database Driver Class Initialized
INFO - 2022-12-09 03:11:06 --> Utf8 Class Initialized
INFO - 2022-12-09 03:11:06 --> URI Class Initialized
INFO - 2022-12-09 03:11:06 --> Router Class Initialized
INFO - 2022-12-09 03:11:06 --> Output Class Initialized
INFO - 2022-12-09 03:11:06 --> Security Class Initialized
INFO - 2022-12-09 03:11:06 --> Model "Cluster_model" initialized
DEBUG - 2022-12-09 03:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:11:06 --> Input Class Initialized
INFO - 2022-12-09 03:11:06 --> Language Class Initialized
INFO - 2022-12-09 03:11:06 --> Final output sent to browser
DEBUG - 2022-12-09 03:11:06 --> Total execution time: 0.0365
INFO - 2022-12-09 03:11:06 --> Loader Class Initialized
INFO - 2022-12-09 03:11:06 --> Controller Class Initialized
DEBUG - 2022-12-09 03:11:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:11:06 --> Database Driver Class Initialized
INFO - 2022-12-09 03:11:06 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:11:08 --> Config Class Initialized
INFO - 2022-12-09 03:11:08 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:11:08 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:11:08 --> Utf8 Class Initialized
INFO - 2022-12-09 03:11:08 --> URI Class Initialized
INFO - 2022-12-09 03:11:08 --> Router Class Initialized
INFO - 2022-12-09 03:11:08 --> Output Class Initialized
INFO - 2022-12-09 03:11:08 --> Security Class Initialized
DEBUG - 2022-12-09 03:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:11:08 --> Input Class Initialized
INFO - 2022-12-09 03:11:08 --> Language Class Initialized
INFO - 2022-12-09 03:11:08 --> Loader Class Initialized
INFO - 2022-12-09 03:11:08 --> Controller Class Initialized
DEBUG - 2022-12-09 03:11:08 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:11:08 --> Database Driver Class Initialized
INFO - 2022-12-09 03:11:08 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:11:08 --> Config Class Initialized
INFO - 2022-12-09 03:11:08 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:11:08 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:11:08 --> Utf8 Class Initialized
INFO - 2022-12-09 03:11:08 --> URI Class Initialized
INFO - 2022-12-09 03:11:08 --> Router Class Initialized
INFO - 2022-12-09 03:11:08 --> Output Class Initialized
INFO - 2022-12-09 03:11:08 --> Security Class Initialized
DEBUG - 2022-12-09 03:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:11:08 --> Input Class Initialized
INFO - 2022-12-09 03:11:08 --> Language Class Initialized
INFO - 2022-12-09 03:11:08 --> Loader Class Initialized
INFO - 2022-12-09 03:11:08 --> Controller Class Initialized
DEBUG - 2022-12-09 03:11:08 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:11:08 --> Database Driver Class Initialized
INFO - 2022-12-09 03:11:08 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:11:27 --> Config Class Initialized
INFO - 2022-12-09 03:11:27 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:11:27 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:11:27 --> Utf8 Class Initialized
INFO - 2022-12-09 03:11:27 --> URI Class Initialized
INFO - 2022-12-09 03:11:27 --> Router Class Initialized
INFO - 2022-12-09 03:11:27 --> Output Class Initialized
INFO - 2022-12-09 03:11:27 --> Security Class Initialized
DEBUG - 2022-12-09 03:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:11:27 --> Input Class Initialized
INFO - 2022-12-09 03:11:27 --> Language Class Initialized
INFO - 2022-12-09 03:11:27 --> Loader Class Initialized
INFO - 2022-12-09 03:11:27 --> Controller Class Initialized
DEBUG - 2022-12-09 03:11:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:11:27 --> Database Driver Class Initialized
INFO - 2022-12-09 03:11:27 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:11:27 --> Config Class Initialized
INFO - 2022-12-09 03:11:27 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:11:27 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:11:27 --> Utf8 Class Initialized
INFO - 2022-12-09 03:11:27 --> URI Class Initialized
INFO - 2022-12-09 03:11:27 --> Router Class Initialized
INFO - 2022-12-09 03:11:27 --> Output Class Initialized
INFO - 2022-12-09 03:11:27 --> Security Class Initialized
DEBUG - 2022-12-09 03:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:11:27 --> Input Class Initialized
INFO - 2022-12-09 03:11:27 --> Language Class Initialized
INFO - 2022-12-09 03:11:27 --> Loader Class Initialized
INFO - 2022-12-09 03:11:27 --> Controller Class Initialized
DEBUG - 2022-12-09 03:11:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:11:27 --> Database Driver Class Initialized
INFO - 2022-12-09 03:11:27 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:12:01 --> Config Class Initialized
INFO - 2022-12-09 03:12:01 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:12:01 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:12:01 --> Utf8 Class Initialized
INFO - 2022-12-09 03:12:01 --> URI Class Initialized
INFO - 2022-12-09 03:12:01 --> Router Class Initialized
INFO - 2022-12-09 03:12:01 --> Output Class Initialized
INFO - 2022-12-09 03:12:01 --> Security Class Initialized
DEBUG - 2022-12-09 03:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:12:01 --> Input Class Initialized
INFO - 2022-12-09 03:12:01 --> Language Class Initialized
INFO - 2022-12-09 03:12:01 --> Loader Class Initialized
INFO - 2022-12-09 03:12:01 --> Controller Class Initialized
DEBUG - 2022-12-09 03:12:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:12:01 --> Database Driver Class Initialized
INFO - 2022-12-09 03:12:01 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:12:01 --> Config Class Initialized
INFO - 2022-12-09 03:12:01 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:12:01 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:12:01 --> Utf8 Class Initialized
INFO - 2022-12-09 03:12:01 --> URI Class Initialized
INFO - 2022-12-09 03:12:01 --> Router Class Initialized
INFO - 2022-12-09 03:12:01 --> Output Class Initialized
INFO - 2022-12-09 03:12:01 --> Security Class Initialized
DEBUG - 2022-12-09 03:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:12:01 --> Input Class Initialized
INFO - 2022-12-09 03:12:01 --> Language Class Initialized
INFO - 2022-12-09 03:12:01 --> Loader Class Initialized
INFO - 2022-12-09 03:12:01 --> Controller Class Initialized
DEBUG - 2022-12-09 03:12:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:12:01 --> Database Driver Class Initialized
INFO - 2022-12-09 03:12:01 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:12:05 --> Config Class Initialized
INFO - 2022-12-09 03:12:05 --> Config Class Initialized
INFO - 2022-12-09 03:12:05 --> Hooks Class Initialized
INFO - 2022-12-09 03:12:05 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-09 03:12:05 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:12:05 --> Utf8 Class Initialized
INFO - 2022-12-09 03:12:05 --> Utf8 Class Initialized
INFO - 2022-12-09 03:12:05 --> URI Class Initialized
INFO - 2022-12-09 03:12:05 --> URI Class Initialized
INFO - 2022-12-09 03:12:05 --> Router Class Initialized
INFO - 2022-12-09 03:12:05 --> Router Class Initialized
INFO - 2022-12-09 03:12:05 --> Output Class Initialized
INFO - 2022-12-09 03:12:05 --> Output Class Initialized
INFO - 2022-12-09 03:12:05 --> Security Class Initialized
INFO - 2022-12-09 03:12:05 --> Security Class Initialized
DEBUG - 2022-12-09 03:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:12:05 --> Input Class Initialized
DEBUG - 2022-12-09 03:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:12:05 --> Input Class Initialized
INFO - 2022-12-09 03:12:05 --> Language Class Initialized
INFO - 2022-12-09 03:12:05 --> Language Class Initialized
INFO - 2022-12-09 03:12:05 --> Loader Class Initialized
INFO - 2022-12-09 03:12:05 --> Loader Class Initialized
INFO - 2022-12-09 03:12:05 --> Controller Class Initialized
INFO - 2022-12-09 03:12:05 --> Controller Class Initialized
DEBUG - 2022-12-09 03:12:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-09 03:12:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:12:05 --> Database Driver Class Initialized
INFO - 2022-12-09 03:12:05 --> Database Driver Class Initialized
INFO - 2022-12-09 03:12:05 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:12:05 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:12:05 --> Final output sent to browser
DEBUG - 2022-12-09 03:12:05 --> Total execution time: 0.0961
INFO - 2022-12-09 03:12:05 --> Config Class Initialized
INFO - 2022-12-09 03:12:05 --> Hooks Class Initialized
INFO - 2022-12-09 03:12:05 --> Config Class Initialized
INFO - 2022-12-09 03:12:05 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:12:05 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:12:05 --> Utf8 Class Initialized
INFO - 2022-12-09 03:12:05 --> URI Class Initialized
DEBUG - 2022-12-09 03:12:05 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:12:05 --> Utf8 Class Initialized
INFO - 2022-12-09 03:12:05 --> URI Class Initialized
INFO - 2022-12-09 03:12:05 --> Router Class Initialized
INFO - 2022-12-09 03:12:05 --> Router Class Initialized
INFO - 2022-12-09 03:12:05 --> Output Class Initialized
INFO - 2022-12-09 03:12:05 --> Output Class Initialized
INFO - 2022-12-09 03:12:05 --> Security Class Initialized
INFO - 2022-12-09 03:12:05 --> Security Class Initialized
DEBUG - 2022-12-09 03:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:12:05 --> Input Class Initialized
DEBUG - 2022-12-09 03:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:12:05 --> Language Class Initialized
INFO - 2022-12-09 03:12:05 --> Input Class Initialized
INFO - 2022-12-09 03:12:05 --> Language Class Initialized
INFO - 2022-12-09 03:12:05 --> Loader Class Initialized
INFO - 2022-12-09 03:12:05 --> Loader Class Initialized
INFO - 2022-12-09 03:12:05 --> Controller Class Initialized
DEBUG - 2022-12-09 03:12:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:12:05 --> Controller Class Initialized
DEBUG - 2022-12-09 03:12:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:12:05 --> Database Driver Class Initialized
INFO - 2022-12-09 03:12:05 --> Database Driver Class Initialized
INFO - 2022-12-09 03:12:05 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:12:05 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:12:05 --> Final output sent to browser
DEBUG - 2022-12-09 03:12:05 --> Total execution time: 0.0577
INFO - 2022-12-09 03:12:15 --> Config Class Initialized
INFO - 2022-12-09 03:12:15 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:12:15 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:12:15 --> Utf8 Class Initialized
INFO - 2022-12-09 03:12:15 --> URI Class Initialized
INFO - 2022-12-09 03:12:15 --> Router Class Initialized
INFO - 2022-12-09 03:12:15 --> Output Class Initialized
INFO - 2022-12-09 03:12:15 --> Security Class Initialized
DEBUG - 2022-12-09 03:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:12:15 --> Input Class Initialized
INFO - 2022-12-09 03:12:15 --> Language Class Initialized
INFO - 2022-12-09 03:12:15 --> Loader Class Initialized
INFO - 2022-12-09 03:12:15 --> Controller Class Initialized
DEBUG - 2022-12-09 03:12:15 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:12:15 --> Database Driver Class Initialized
INFO - 2022-12-09 03:12:15 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:12:15 --> Database Driver Class Initialized
INFO - 2022-12-09 03:12:15 --> Model "Login_model" initialized
INFO - 2022-12-09 03:12:15 --> Final output sent to browser
DEBUG - 2022-12-09 03:12:15 --> Total execution time: 0.1185
INFO - 2022-12-09 03:12:15 --> Config Class Initialized
INFO - 2022-12-09 03:12:15 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:12:15 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:12:15 --> Utf8 Class Initialized
INFO - 2022-12-09 03:12:15 --> URI Class Initialized
INFO - 2022-12-09 03:12:15 --> Router Class Initialized
INFO - 2022-12-09 03:12:15 --> Output Class Initialized
INFO - 2022-12-09 03:12:15 --> Security Class Initialized
DEBUG - 2022-12-09 03:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:12:15 --> Input Class Initialized
INFO - 2022-12-09 03:12:15 --> Language Class Initialized
INFO - 2022-12-09 03:12:15 --> Loader Class Initialized
INFO - 2022-12-09 03:12:15 --> Controller Class Initialized
DEBUG - 2022-12-09 03:12:15 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:12:16 --> Database Driver Class Initialized
INFO - 2022-12-09 03:12:16 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:12:16 --> Database Driver Class Initialized
INFO - 2022-12-09 03:12:16 --> Model "Login_model" initialized
INFO - 2022-12-09 03:12:16 --> Final output sent to browser
DEBUG - 2022-12-09 03:12:16 --> Total execution time: 0.2344
INFO - 2022-12-09 03:39:41 --> Config Class Initialized
INFO - 2022-12-09 03:39:41 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:39:41 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:39:41 --> Utf8 Class Initialized
INFO - 2022-12-09 03:39:41 --> URI Class Initialized
INFO - 2022-12-09 03:39:41 --> Router Class Initialized
INFO - 2022-12-09 03:39:41 --> Output Class Initialized
INFO - 2022-12-09 03:39:41 --> Security Class Initialized
DEBUG - 2022-12-09 03:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:39:41 --> Input Class Initialized
INFO - 2022-12-09 03:39:41 --> Language Class Initialized
INFO - 2022-12-09 03:39:41 --> Loader Class Initialized
INFO - 2022-12-09 03:39:41 --> Controller Class Initialized
DEBUG - 2022-12-09 03:39:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:39:41 --> Database Driver Class Initialized
INFO - 2022-12-09 03:39:41 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:39:41 --> Final output sent to browser
DEBUG - 2022-12-09 03:39:41 --> Total execution time: 0.0704
INFO - 2022-12-09 03:39:41 --> Config Class Initialized
INFO - 2022-12-09 03:39:41 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:39:41 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:39:41 --> Utf8 Class Initialized
INFO - 2022-12-09 03:39:41 --> URI Class Initialized
INFO - 2022-12-09 03:39:41 --> Router Class Initialized
INFO - 2022-12-09 03:39:41 --> Output Class Initialized
INFO - 2022-12-09 03:39:41 --> Security Class Initialized
DEBUG - 2022-12-09 03:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:39:41 --> Input Class Initialized
INFO - 2022-12-09 03:39:41 --> Language Class Initialized
INFO - 2022-12-09 03:39:41 --> Loader Class Initialized
INFO - 2022-12-09 03:39:41 --> Controller Class Initialized
DEBUG - 2022-12-09 03:39:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:39:41 --> Database Driver Class Initialized
INFO - 2022-12-09 03:39:41 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:39:41 --> Final output sent to browser
DEBUG - 2022-12-09 03:39:41 --> Total execution time: 0.0737
INFO - 2022-12-09 03:39:43 --> Config Class Initialized
INFO - 2022-12-09 03:39:43 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:39:43 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:39:43 --> Utf8 Class Initialized
INFO - 2022-12-09 03:39:43 --> URI Class Initialized
INFO - 2022-12-09 03:39:43 --> Router Class Initialized
INFO - 2022-12-09 03:39:43 --> Output Class Initialized
INFO - 2022-12-09 03:39:43 --> Security Class Initialized
DEBUG - 2022-12-09 03:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:39:43 --> Input Class Initialized
INFO - 2022-12-09 03:39:43 --> Language Class Initialized
INFO - 2022-12-09 03:39:43 --> Loader Class Initialized
INFO - 2022-12-09 03:39:43 --> Controller Class Initialized
DEBUG - 2022-12-09 03:39:43 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:39:43 --> Final output sent to browser
DEBUG - 2022-12-09 03:39:43 --> Total execution time: 0.0395
INFO - 2022-12-09 03:39:43 --> Config Class Initialized
INFO - 2022-12-09 03:39:43 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:39:43 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:39:43 --> Utf8 Class Initialized
INFO - 2022-12-09 03:39:43 --> URI Class Initialized
INFO - 2022-12-09 03:39:43 --> Router Class Initialized
INFO - 2022-12-09 03:39:43 --> Output Class Initialized
INFO - 2022-12-09 03:39:43 --> Security Class Initialized
DEBUG - 2022-12-09 03:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:39:43 --> Input Class Initialized
INFO - 2022-12-09 03:39:43 --> Language Class Initialized
INFO - 2022-12-09 03:39:43 --> Loader Class Initialized
INFO - 2022-12-09 03:39:43 --> Controller Class Initialized
DEBUG - 2022-12-09 03:39:43 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:39:43 --> Database Driver Class Initialized
INFO - 2022-12-09 03:39:43 --> Model "Login_model" initialized
INFO - 2022-12-09 03:39:43 --> Database Driver Class Initialized
INFO - 2022-12-09 03:39:43 --> Model "Cluster_model" initialized
ERROR - 2022-12-09 03:39:43 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php 1048
ERROR - 2022-12-09 03:39:43 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 324
ERROR - 2022-12-09 03:39:43 --> Severity: 8192 --> mysqli::query(): Passing null to parameter #1 ($query) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2022-12-09 03:39:43 --> Exception of type 'ValueError' occurred with Message: mysqli::query(): Argument #1 ($query) cannot be empty in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php at Line 307
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php(307): mysqli->query('')
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(791): CI_DB_mysqli_driver->_execute(NULL)
#2 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(654): CI_DB_driver->simple_query(NULL)
#3 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\models\Cluster_model.php(21): CI_DB_driver->query(NULL)
#4 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Cluster.php(1271): Cluster_model->getList(NULL)
#5 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Cluster->getEffectCluster()
#6 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#7 {main}
INFO - 2022-12-09 03:39:57 --> Config Class Initialized
INFO - 2022-12-09 03:39:57 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:39:57 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:39:57 --> Utf8 Class Initialized
INFO - 2022-12-09 03:39:57 --> URI Class Initialized
INFO - 2022-12-09 03:39:57 --> Router Class Initialized
INFO - 2022-12-09 03:39:57 --> Output Class Initialized
INFO - 2022-12-09 03:39:57 --> Security Class Initialized
DEBUG - 2022-12-09 03:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:39:57 --> Input Class Initialized
INFO - 2022-12-09 03:39:57 --> Language Class Initialized
INFO - 2022-12-09 03:39:57 --> Loader Class Initialized
INFO - 2022-12-09 03:39:57 --> Controller Class Initialized
DEBUG - 2022-12-09 03:39:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:39:57 --> Database Driver Class Initialized
INFO - 2022-12-09 03:39:57 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:39:57 --> Final output sent to browser
DEBUG - 2022-12-09 03:39:57 --> Total execution time: 0.0819
INFO - 2022-12-09 03:39:57 --> Config Class Initialized
INFO - 2022-12-09 03:39:57 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:39:57 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:39:57 --> Utf8 Class Initialized
INFO - 2022-12-09 03:39:57 --> URI Class Initialized
INFO - 2022-12-09 03:39:57 --> Router Class Initialized
INFO - 2022-12-09 03:39:57 --> Output Class Initialized
INFO - 2022-12-09 03:39:57 --> Security Class Initialized
DEBUG - 2022-12-09 03:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:39:57 --> Input Class Initialized
INFO - 2022-12-09 03:39:57 --> Language Class Initialized
INFO - 2022-12-09 03:39:57 --> Loader Class Initialized
INFO - 2022-12-09 03:39:57 --> Controller Class Initialized
DEBUG - 2022-12-09 03:39:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:39:57 --> Database Driver Class Initialized
INFO - 2022-12-09 03:39:57 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:39:57 --> Final output sent to browser
DEBUG - 2022-12-09 03:39:57 --> Total execution time: 0.0672
INFO - 2022-12-09 03:40:02 --> Config Class Initialized
INFO - 2022-12-09 03:40:02 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:40:02 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:40:02 --> Utf8 Class Initialized
INFO - 2022-12-09 03:40:02 --> URI Class Initialized
INFO - 2022-12-09 03:40:02 --> Router Class Initialized
INFO - 2022-12-09 03:40:02 --> Output Class Initialized
INFO - 2022-12-09 03:40:02 --> Security Class Initialized
DEBUG - 2022-12-09 03:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:40:02 --> Input Class Initialized
INFO - 2022-12-09 03:40:02 --> Language Class Initialized
INFO - 2022-12-09 03:40:02 --> Loader Class Initialized
INFO - 2022-12-09 03:40:02 --> Controller Class Initialized
DEBUG - 2022-12-09 03:40:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:40:02 --> Database Driver Class Initialized
INFO - 2022-12-09 03:40:02 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:40:02 --> Database Driver Class Initialized
INFO - 2022-12-09 03:40:02 --> Model "Login_model" initialized
INFO - 2022-12-09 03:40:02 --> Final output sent to browser
DEBUG - 2022-12-09 03:40:02 --> Total execution time: 0.1120
INFO - 2022-12-09 03:40:02 --> Config Class Initialized
INFO - 2022-12-09 03:40:02 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:40:02 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:40:02 --> Utf8 Class Initialized
INFO - 2022-12-09 03:40:02 --> URI Class Initialized
INFO - 2022-12-09 03:40:02 --> Router Class Initialized
INFO - 2022-12-09 03:40:02 --> Output Class Initialized
INFO - 2022-12-09 03:40:02 --> Security Class Initialized
DEBUG - 2022-12-09 03:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:40:02 --> Input Class Initialized
INFO - 2022-12-09 03:40:02 --> Language Class Initialized
INFO - 2022-12-09 03:40:02 --> Loader Class Initialized
INFO - 2022-12-09 03:40:02 --> Controller Class Initialized
DEBUG - 2022-12-09 03:40:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:40:02 --> Database Driver Class Initialized
INFO - 2022-12-09 03:40:02 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:40:03 --> Database Driver Class Initialized
INFO - 2022-12-09 03:40:03 --> Model "Login_model" initialized
INFO - 2022-12-09 03:40:03 --> Final output sent to browser
DEBUG - 2022-12-09 03:40:03 --> Total execution time: 0.7316
INFO - 2022-12-09 03:40:13 --> Config Class Initialized
INFO - 2022-12-09 03:40:13 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:40:13 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:40:13 --> Utf8 Class Initialized
INFO - 2022-12-09 03:40:13 --> URI Class Initialized
INFO - 2022-12-09 03:40:13 --> Router Class Initialized
INFO - 2022-12-09 03:40:13 --> Output Class Initialized
INFO - 2022-12-09 03:40:13 --> Security Class Initialized
DEBUG - 2022-12-09 03:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:40:13 --> Input Class Initialized
INFO - 2022-12-09 03:40:13 --> Language Class Initialized
INFO - 2022-12-09 03:40:13 --> Loader Class Initialized
INFO - 2022-12-09 03:40:13 --> Controller Class Initialized
DEBUG - 2022-12-09 03:40:13 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:40:13 --> Database Driver Class Initialized
INFO - 2022-12-09 03:40:13 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:40:13 --> Database Driver Class Initialized
INFO - 2022-12-09 03:40:13 --> Model "Login_model" initialized
INFO - 2022-12-09 03:40:13 --> Final output sent to browser
DEBUG - 2022-12-09 03:40:13 --> Total execution time: 0.2631
INFO - 2022-12-09 03:40:13 --> Config Class Initialized
INFO - 2022-12-09 03:40:13 --> Hooks Class Initialized
DEBUG - 2022-12-09 03:40:13 --> UTF-8 Support Enabled
INFO - 2022-12-09 03:40:13 --> Utf8 Class Initialized
INFO - 2022-12-09 03:40:13 --> URI Class Initialized
INFO - 2022-12-09 03:40:13 --> Router Class Initialized
INFO - 2022-12-09 03:40:13 --> Output Class Initialized
INFO - 2022-12-09 03:40:13 --> Security Class Initialized
DEBUG - 2022-12-09 03:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 03:40:13 --> Input Class Initialized
INFO - 2022-12-09 03:40:14 --> Language Class Initialized
INFO - 2022-12-09 03:40:14 --> Loader Class Initialized
INFO - 2022-12-09 03:40:14 --> Controller Class Initialized
DEBUG - 2022-12-09 03:40:14 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 03:40:14 --> Database Driver Class Initialized
INFO - 2022-12-09 03:40:14 --> Model "Cluster_model" initialized
INFO - 2022-12-09 03:40:14 --> Database Driver Class Initialized
INFO - 2022-12-09 03:40:14 --> Model "Login_model" initialized
INFO - 2022-12-09 03:40:14 --> Final output sent to browser
DEBUG - 2022-12-09 03:40:14 --> Total execution time: 0.2057
INFO - 2022-12-09 07:01:49 --> Config Class Initialized
INFO - 2022-12-09 07:01:49 --> Config Class Initialized
INFO - 2022-12-09 07:01:49 --> Hooks Class Initialized
INFO - 2022-12-09 07:01:49 --> Hooks Class Initialized
DEBUG - 2022-12-09 07:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-09 07:01:49 --> UTF-8 Support Enabled
INFO - 2022-12-09 07:01:49 --> Utf8 Class Initialized
INFO - 2022-12-09 07:01:49 --> Utf8 Class Initialized
INFO - 2022-12-09 07:01:49 --> URI Class Initialized
INFO - 2022-12-09 07:01:49 --> URI Class Initialized
INFO - 2022-12-09 07:01:49 --> Router Class Initialized
INFO - 2022-12-09 07:01:49 --> Router Class Initialized
INFO - 2022-12-09 07:01:49 --> Output Class Initialized
INFO - 2022-12-09 07:01:49 --> Output Class Initialized
INFO - 2022-12-09 07:01:49 --> Security Class Initialized
INFO - 2022-12-09 07:01:49 --> Security Class Initialized
DEBUG - 2022-12-09 07:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-09 07:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 07:01:49 --> Input Class Initialized
INFO - 2022-12-09 07:01:49 --> Input Class Initialized
INFO - 2022-12-09 07:01:49 --> Language Class Initialized
INFO - 2022-12-09 07:01:49 --> Language Class Initialized
INFO - 2022-12-09 07:01:49 --> Loader Class Initialized
INFO - 2022-12-09 07:01:49 --> Loader Class Initialized
INFO - 2022-12-09 07:01:49 --> Controller Class Initialized
INFO - 2022-12-09 07:01:49 --> Controller Class Initialized
DEBUG - 2022-12-09 07:01:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-09 07:01:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 07:01:49 --> Final output sent to browser
DEBUG - 2022-12-09 07:01:49 --> Total execution time: 0.0598
INFO - 2022-12-09 07:01:49 --> Database Driver Class Initialized
INFO - 2022-12-09 07:01:49 --> Config Class Initialized
INFO - 2022-12-09 07:01:49 --> Hooks Class Initialized
DEBUG - 2022-12-09 07:01:49 --> UTF-8 Support Enabled
INFO - 2022-12-09 07:01:49 --> Utf8 Class Initialized
INFO - 2022-12-09 07:01:49 --> URI Class Initialized
INFO - 2022-12-09 07:01:49 --> Router Class Initialized
INFO - 2022-12-09 07:01:49 --> Output Class Initialized
INFO - 2022-12-09 07:01:49 --> Security Class Initialized
DEBUG - 2022-12-09 07:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 07:01:49 --> Input Class Initialized
INFO - 2022-12-09 07:01:49 --> Language Class Initialized
INFO - 2022-12-09 07:01:49 --> Loader Class Initialized
INFO - 2022-12-09 07:01:49 --> Controller Class Initialized
DEBUG - 2022-12-09 07:01:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 07:01:49 --> Database Driver Class Initialized
INFO - 2022-12-09 07:01:49 --> Model "Cluster_model" initialized
INFO - 2022-12-09 07:01:49 --> Final output sent to browser
DEBUG - 2022-12-09 07:01:49 --> Total execution time: 0.1251
INFO - 2022-12-09 07:01:49 --> Config Class Initialized
INFO - 2022-12-09 07:01:49 --> Hooks Class Initialized
DEBUG - 2022-12-09 07:01:49 --> UTF-8 Support Enabled
INFO - 2022-12-09 07:01:49 --> Utf8 Class Initialized
INFO - 2022-12-09 07:01:49 --> URI Class Initialized
INFO - 2022-12-09 07:01:49 --> Router Class Initialized
INFO - 2022-12-09 07:01:49 --> Output Class Initialized
INFO - 2022-12-09 07:01:49 --> Security Class Initialized
DEBUG - 2022-12-09 07:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 07:01:49 --> Input Class Initialized
INFO - 2022-12-09 07:01:49 --> Language Class Initialized
INFO - 2022-12-09 07:01:50 --> Model "Cluster_model" initialized
INFO - 2022-12-09 07:01:50 --> Final output sent to browser
INFO - 2022-12-09 07:01:50 --> Loader Class Initialized
DEBUG - 2022-12-09 07:01:50 --> Total execution time: 0.0955
INFO - 2022-12-09 07:01:50 --> Controller Class Initialized
DEBUG - 2022-12-09 07:01:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 07:01:50 --> Database Driver Class Initialized
INFO - 2022-12-09 07:01:50 --> Model "Cluster_model" initialized
INFO - 2022-12-09 07:01:50 --> Final output sent to browser
DEBUG - 2022-12-09 07:01:50 --> Total execution time: 0.0948
INFO - 2022-12-09 07:01:51 --> Config Class Initialized
INFO - 2022-12-09 07:01:51 --> Hooks Class Initialized
DEBUG - 2022-12-09 07:01:51 --> UTF-8 Support Enabled
INFO - 2022-12-09 07:01:51 --> Utf8 Class Initialized
INFO - 2022-12-09 07:01:51 --> URI Class Initialized
INFO - 2022-12-09 07:01:51 --> Router Class Initialized
INFO - 2022-12-09 07:01:51 --> Output Class Initialized
INFO - 2022-12-09 07:01:51 --> Security Class Initialized
DEBUG - 2022-12-09 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 07:01:51 --> Input Class Initialized
INFO - 2022-12-09 07:01:51 --> Language Class Initialized
INFO - 2022-12-09 07:01:51 --> Loader Class Initialized
INFO - 2022-12-09 07:01:51 --> Controller Class Initialized
DEBUG - 2022-12-09 07:01:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 07:01:51 --> Database Driver Class Initialized
INFO - 2022-12-09 07:01:51 --> Model "Cluster_model" initialized
INFO - 2022-12-09 07:01:51 --> Final output sent to browser
DEBUG - 2022-12-09 07:01:51 --> Total execution time: 0.0697
INFO - 2022-12-09 07:01:51 --> Config Class Initialized
INFO - 2022-12-09 07:01:51 --> Hooks Class Initialized
DEBUG - 2022-12-09 07:01:51 --> UTF-8 Support Enabled
INFO - 2022-12-09 07:01:51 --> Utf8 Class Initialized
INFO - 2022-12-09 07:01:51 --> URI Class Initialized
INFO - 2022-12-09 07:01:51 --> Router Class Initialized
INFO - 2022-12-09 07:01:51 --> Output Class Initialized
INFO - 2022-12-09 07:01:51 --> Security Class Initialized
DEBUG - 2022-12-09 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 07:01:51 --> Input Class Initialized
INFO - 2022-12-09 07:01:51 --> Language Class Initialized
INFO - 2022-12-09 07:01:51 --> Loader Class Initialized
INFO - 2022-12-09 07:01:51 --> Controller Class Initialized
DEBUG - 2022-12-09 07:01:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 07:01:51 --> Database Driver Class Initialized
INFO - 2022-12-09 07:01:51 --> Model "Cluster_model" initialized
INFO - 2022-12-09 07:01:51 --> Final output sent to browser
DEBUG - 2022-12-09 07:01:51 --> Total execution time: 0.0632
INFO - 2022-12-09 07:01:51 --> Config Class Initialized
INFO - 2022-12-09 07:01:51 --> Hooks Class Initialized
DEBUG - 2022-12-09 07:01:51 --> UTF-8 Support Enabled
INFO - 2022-12-09 07:01:51 --> Utf8 Class Initialized
INFO - 2022-12-09 07:01:51 --> URI Class Initialized
INFO - 2022-12-09 07:01:51 --> Router Class Initialized
INFO - 2022-12-09 07:01:51 --> Output Class Initialized
INFO - 2022-12-09 07:01:51 --> Security Class Initialized
DEBUG - 2022-12-09 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 07:01:51 --> Input Class Initialized
INFO - 2022-12-09 07:01:51 --> Language Class Initialized
INFO - 2022-12-09 07:01:51 --> Loader Class Initialized
INFO - 2022-12-09 07:01:51 --> Controller Class Initialized
DEBUG - 2022-12-09 07:01:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 07:01:51 --> Database Driver Class Initialized
INFO - 2022-12-09 07:01:51 --> Model "Cluster_model" initialized
INFO - 2022-12-09 07:01:51 --> Final output sent to browser
DEBUG - 2022-12-09 07:01:51 --> Total execution time: 0.0760
INFO - 2022-12-09 07:01:51 --> Config Class Initialized
INFO - 2022-12-09 07:01:51 --> Hooks Class Initialized
DEBUG - 2022-12-09 07:01:51 --> UTF-8 Support Enabled
INFO - 2022-12-09 07:01:51 --> Utf8 Class Initialized
INFO - 2022-12-09 07:01:51 --> URI Class Initialized
INFO - 2022-12-09 07:01:51 --> Router Class Initialized
INFO - 2022-12-09 07:01:51 --> Output Class Initialized
INFO - 2022-12-09 07:01:51 --> Security Class Initialized
DEBUG - 2022-12-09 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 07:01:51 --> Input Class Initialized
INFO - 2022-12-09 07:01:51 --> Language Class Initialized
INFO - 2022-12-09 07:01:51 --> Loader Class Initialized
INFO - 2022-12-09 07:01:51 --> Controller Class Initialized
DEBUG - 2022-12-09 07:01:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 07:01:51 --> Database Driver Class Initialized
INFO - 2022-12-09 07:01:51 --> Model "Cluster_model" initialized
INFO - 2022-12-09 07:01:51 --> Final output sent to browser
DEBUG - 2022-12-09 07:01:51 --> Total execution time: 0.0518
INFO - 2022-12-09 09:18:52 --> Config Class Initialized
INFO - 2022-12-09 09:18:52 --> Hooks Class Initialized
DEBUG - 2022-12-09 09:18:52 --> UTF-8 Support Enabled
INFO - 2022-12-09 09:18:52 --> Utf8 Class Initialized
INFO - 2022-12-09 09:18:52 --> URI Class Initialized
INFO - 2022-12-09 09:18:52 --> Router Class Initialized
INFO - 2022-12-09 09:18:52 --> Output Class Initialized
INFO - 2022-12-09 09:18:52 --> Security Class Initialized
DEBUG - 2022-12-09 09:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 09:18:52 --> Input Class Initialized
INFO - 2022-12-09 09:18:52 --> Language Class Initialized
INFO - 2022-12-09 09:18:52 --> Loader Class Initialized
INFO - 2022-12-09 09:18:52 --> Controller Class Initialized
DEBUG - 2022-12-09 09:18:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 09:18:52 --> Database Driver Class Initialized
INFO - 2022-12-09 09:18:52 --> Model "Cluster_model" initialized
INFO - 2022-12-09 09:18:52 --> Database Driver Class Initialized
INFO - 2022-12-09 09:18:52 --> Model "Login_model" initialized
INFO - 2022-12-09 09:18:52 --> Final output sent to browser
DEBUG - 2022-12-09 09:18:52 --> Total execution time: 0.2063
INFO - 2022-12-09 09:18:52 --> Config Class Initialized
INFO - 2022-12-09 09:18:52 --> Hooks Class Initialized
DEBUG - 2022-12-09 09:18:52 --> UTF-8 Support Enabled
INFO - 2022-12-09 09:18:52 --> Utf8 Class Initialized
INFO - 2022-12-09 09:18:52 --> URI Class Initialized
INFO - 2022-12-09 09:18:52 --> Router Class Initialized
INFO - 2022-12-09 09:18:52 --> Output Class Initialized
INFO - 2022-12-09 09:18:52 --> Security Class Initialized
DEBUG - 2022-12-09 09:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 09:18:52 --> Input Class Initialized
INFO - 2022-12-09 09:18:52 --> Language Class Initialized
INFO - 2022-12-09 09:18:52 --> Loader Class Initialized
INFO - 2022-12-09 09:18:52 --> Controller Class Initialized
DEBUG - 2022-12-09 09:18:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 09:18:52 --> Database Driver Class Initialized
INFO - 2022-12-09 09:18:52 --> Model "Cluster_model" initialized
INFO - 2022-12-09 09:18:52 --> Database Driver Class Initialized
INFO - 2022-12-09 09:18:52 --> Model "Login_model" initialized
INFO - 2022-12-09 09:18:52 --> Final output sent to browser
DEBUG - 2022-12-09 09:18:52 --> Total execution time: 0.1474
INFO - 2022-12-09 11:36:17 --> Config Class Initialized
INFO - 2022-12-09 11:36:17 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:17 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:17 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:17 --> URI Class Initialized
INFO - 2022-12-09 11:36:17 --> Router Class Initialized
INFO - 2022-12-09 11:36:17 --> Output Class Initialized
INFO - 2022-12-09 11:36:17 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:17 --> Input Class Initialized
INFO - 2022-12-09 11:36:17 --> Language Class Initialized
INFO - 2022-12-09 11:36:17 --> Loader Class Initialized
INFO - 2022-12-09 11:36:17 --> Controller Class Initialized
INFO - 2022-12-09 11:36:17 --> Helper loaded: form_helper
INFO - 2022-12-09 11:36:17 --> Helper loaded: url_helper
DEBUG - 2022-12-09 11:36:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:17 --> Model "Change_model" initialized
INFO - 2022-12-09 11:36:17 --> Model "Grafana_model" initialized
INFO - 2022-12-09 11:36:17 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:17 --> Total execution time: 0.0655
INFO - 2022-12-09 11:36:17 --> Config Class Initialized
INFO - 2022-12-09 11:36:17 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:17 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:17 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:17 --> URI Class Initialized
INFO - 2022-12-09 11:36:17 --> Router Class Initialized
INFO - 2022-12-09 11:36:17 --> Output Class Initialized
INFO - 2022-12-09 11:36:17 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:17 --> Input Class Initialized
INFO - 2022-12-09 11:36:17 --> Language Class Initialized
INFO - 2022-12-09 11:36:17 --> Loader Class Initialized
INFO - 2022-12-09 11:36:17 --> Controller Class Initialized
INFO - 2022-12-09 11:36:17 --> Helper loaded: form_helper
INFO - 2022-12-09 11:36:17 --> Helper loaded: url_helper
DEBUG - 2022-12-09 11:36:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:17 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:17 --> Total execution time: 0.0238
INFO - 2022-12-09 11:36:17 --> Config Class Initialized
INFO - 2022-12-09 11:36:17 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:17 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:17 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:17 --> URI Class Initialized
INFO - 2022-12-09 11:36:17 --> Router Class Initialized
INFO - 2022-12-09 11:36:17 --> Output Class Initialized
INFO - 2022-12-09 11:36:17 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:17 --> Input Class Initialized
INFO - 2022-12-09 11:36:17 --> Language Class Initialized
INFO - 2022-12-09 11:36:17 --> Loader Class Initialized
INFO - 2022-12-09 11:36:17 --> Controller Class Initialized
INFO - 2022-12-09 11:36:17 --> Helper loaded: form_helper
INFO - 2022-12-09 11:36:17 --> Helper loaded: url_helper
DEBUG - 2022-12-09 11:36:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:17 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:17 --> Model "Login_model" initialized
INFO - 2022-12-09 11:36:17 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:17 --> Total execution time: 0.1441
INFO - 2022-12-09 11:36:17 --> Config Class Initialized
INFO - 2022-12-09 11:36:17 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:17 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:17 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:17 --> URI Class Initialized
INFO - 2022-12-09 11:36:17 --> Router Class Initialized
INFO - 2022-12-09 11:36:17 --> Output Class Initialized
INFO - 2022-12-09 11:36:17 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:17 --> Input Class Initialized
INFO - 2022-12-09 11:36:17 --> Language Class Initialized
INFO - 2022-12-09 11:36:17 --> Loader Class Initialized
INFO - 2022-12-09 11:36:17 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:17 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:17 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:17 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:17 --> Total execution time: 0.0564
INFO - 2022-12-09 11:36:17 --> Config Class Initialized
INFO - 2022-12-09 11:36:17 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:18 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:18 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:18 --> URI Class Initialized
INFO - 2022-12-09 11:36:18 --> Router Class Initialized
INFO - 2022-12-09 11:36:18 --> Output Class Initialized
INFO - 2022-12-09 11:36:18 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:18 --> Input Class Initialized
INFO - 2022-12-09 11:36:18 --> Language Class Initialized
INFO - 2022-12-09 11:36:18 --> Loader Class Initialized
INFO - 2022-12-09 11:36:18 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:18 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:18 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:18 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:18 --> Total execution time: 0.0635
INFO - 2022-12-09 11:36:18 --> Config Class Initialized
INFO - 2022-12-09 11:36:18 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:18 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:18 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:18 --> URI Class Initialized
INFO - 2022-12-09 11:36:18 --> Router Class Initialized
INFO - 2022-12-09 11:36:18 --> Output Class Initialized
INFO - 2022-12-09 11:36:18 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:18 --> Input Class Initialized
INFO - 2022-12-09 11:36:18 --> Language Class Initialized
INFO - 2022-12-09 11:36:18 --> Loader Class Initialized
INFO - 2022-12-09 11:36:18 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:18 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:18 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:18 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:18 --> Model "Login_model" initialized
INFO - 2022-12-09 11:36:18 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:18 --> Total execution time: 0.1262
INFO - 2022-12-09 11:36:18 --> Config Class Initialized
INFO - 2022-12-09 11:36:18 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:18 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:18 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:18 --> URI Class Initialized
INFO - 2022-12-09 11:36:18 --> Router Class Initialized
INFO - 2022-12-09 11:36:18 --> Output Class Initialized
INFO - 2022-12-09 11:36:18 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:18 --> Input Class Initialized
INFO - 2022-12-09 11:36:18 --> Language Class Initialized
INFO - 2022-12-09 11:36:18 --> Loader Class Initialized
INFO - 2022-12-09 11:36:18 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:18 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:18 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:18 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:18 --> Model "Login_model" initialized
INFO - 2022-12-09 11:36:18 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:18 --> Total execution time: 0.1564
INFO - 2022-12-09 11:36:22 --> Config Class Initialized
INFO - 2022-12-09 11:36:22 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:22 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:22 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:22 --> URI Class Initialized
INFO - 2022-12-09 11:36:22 --> Router Class Initialized
INFO - 2022-12-09 11:36:22 --> Output Class Initialized
INFO - 2022-12-09 11:36:22 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:22 --> Input Class Initialized
INFO - 2022-12-09 11:36:22 --> Language Class Initialized
INFO - 2022-12-09 11:36:22 --> Loader Class Initialized
INFO - 2022-12-09 11:36:22 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:22 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:22 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:22 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:22 --> Total execution time: 0.0507
INFO - 2022-12-09 11:36:22 --> Config Class Initialized
INFO - 2022-12-09 11:36:22 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:22 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:22 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:22 --> URI Class Initialized
INFO - 2022-12-09 11:36:22 --> Router Class Initialized
INFO - 2022-12-09 11:36:22 --> Output Class Initialized
INFO - 2022-12-09 11:36:22 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:22 --> Input Class Initialized
INFO - 2022-12-09 11:36:22 --> Language Class Initialized
INFO - 2022-12-09 11:36:22 --> Loader Class Initialized
INFO - 2022-12-09 11:36:22 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:22 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:22 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:22 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:22 --> Total execution time: 0.0524
INFO - 2022-12-09 11:36:26 --> Config Class Initialized
INFO - 2022-12-09 11:36:26 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:26 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:26 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:26 --> URI Class Initialized
INFO - 2022-12-09 11:36:26 --> Router Class Initialized
INFO - 2022-12-09 11:36:26 --> Output Class Initialized
INFO - 2022-12-09 11:36:26 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:26 --> Input Class Initialized
INFO - 2022-12-09 11:36:26 --> Language Class Initialized
INFO - 2022-12-09 11:36:26 --> Loader Class Initialized
INFO - 2022-12-09 11:36:26 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:26 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:26 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:26 --> Config Class Initialized
INFO - 2022-12-09 11:36:26 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:26 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:26 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:26 --> URI Class Initialized
INFO - 2022-12-09 11:36:26 --> Router Class Initialized
INFO - 2022-12-09 11:36:26 --> Output Class Initialized
INFO - 2022-12-09 11:36:26 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:26 --> Input Class Initialized
INFO - 2022-12-09 11:36:26 --> Language Class Initialized
INFO - 2022-12-09 11:36:26 --> Loader Class Initialized
INFO - 2022-12-09 11:36:26 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:26 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:26 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:27 --> Config Class Initialized
INFO - 2022-12-09 11:36:27 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:27 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:27 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:27 --> URI Class Initialized
INFO - 2022-12-09 11:36:27 --> Router Class Initialized
INFO - 2022-12-09 11:36:27 --> Output Class Initialized
INFO - 2022-12-09 11:36:27 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:27 --> Input Class Initialized
INFO - 2022-12-09 11:36:27 --> Language Class Initialized
INFO - 2022-12-09 11:36:27 --> Loader Class Initialized
INFO - 2022-12-09 11:36:27 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:27 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:27 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:27 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:27 --> Total execution time: 0.0384
INFO - 2022-12-09 11:36:42 --> Config Class Initialized
INFO - 2022-12-09 11:36:42 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:42 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:42 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:42 --> URI Class Initialized
INFO - 2022-12-09 11:36:42 --> Router Class Initialized
INFO - 2022-12-09 11:36:42 --> Output Class Initialized
INFO - 2022-12-09 11:36:42 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:42 --> Input Class Initialized
INFO - 2022-12-09 11:36:42 --> Language Class Initialized
INFO - 2022-12-09 11:36:42 --> Loader Class Initialized
INFO - 2022-12-09 11:36:42 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:42 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:42 --> Total execution time: 0.0227
INFO - 2022-12-09 11:36:42 --> Config Class Initialized
INFO - 2022-12-09 11:36:42 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:42 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:42 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:42 --> URI Class Initialized
INFO - 2022-12-09 11:36:42 --> Router Class Initialized
INFO - 2022-12-09 11:36:42 --> Output Class Initialized
INFO - 2022-12-09 11:36:42 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:42 --> Input Class Initialized
INFO - 2022-12-09 11:36:42 --> Language Class Initialized
INFO - 2022-12-09 11:36:42 --> Loader Class Initialized
INFO - 2022-12-09 11:36:42 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:42 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:42 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:42 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:42 --> Total execution time: 0.0380
INFO - 2022-12-09 11:36:43 --> Config Class Initialized
INFO - 2022-12-09 11:36:43 --> Hooks Class Initialized
INFO - 2022-12-09 11:36:43 --> Config Class Initialized
INFO - 2022-12-09 11:36:43 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:43 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:43 --> Utf8 Class Initialized
DEBUG - 2022-12-09 11:36:43 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:43 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:43 --> URI Class Initialized
INFO - 2022-12-09 11:36:43 --> URI Class Initialized
INFO - 2022-12-09 11:36:43 --> Router Class Initialized
INFO - 2022-12-09 11:36:43 --> Router Class Initialized
INFO - 2022-12-09 11:36:43 --> Output Class Initialized
INFO - 2022-12-09 11:36:43 --> Output Class Initialized
INFO - 2022-12-09 11:36:43 --> Security Class Initialized
INFO - 2022-12-09 11:36:43 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:43 --> Input Class Initialized
DEBUG - 2022-12-09 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:43 --> Language Class Initialized
INFO - 2022-12-09 11:36:43 --> Input Class Initialized
INFO - 2022-12-09 11:36:43 --> Language Class Initialized
INFO - 2022-12-09 11:36:43 --> Loader Class Initialized
INFO - 2022-12-09 11:36:43 --> Loader Class Initialized
INFO - 2022-12-09 11:36:43 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:43 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:43 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:43 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:43 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:43 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:43 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:43 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:43 --> Final output sent to browser
INFO - 2022-12-09 11:36:43 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:43 --> Total execution time: 0.0613
DEBUG - 2022-12-09 11:36:43 --> Total execution time: 0.0607
INFO - 2022-12-09 11:36:43 --> Config Class Initialized
INFO - 2022-12-09 11:36:43 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:43 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:43 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:43 --> URI Class Initialized
INFO - 2022-12-09 11:36:43 --> Router Class Initialized
INFO - 2022-12-09 11:36:43 --> Output Class Initialized
INFO - 2022-12-09 11:36:43 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:43 --> Input Class Initialized
INFO - 2022-12-09 11:36:43 --> Language Class Initialized
INFO - 2022-12-09 11:36:43 --> Loader Class Initialized
INFO - 2022-12-09 11:36:43 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:43 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:43 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:43 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:43 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:43 --> Total execution time: 0.0525
INFO - 2022-12-09 11:36:45 --> Config Class Initialized
INFO - 2022-12-09 11:36:45 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:45 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:45 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:45 --> URI Class Initialized
INFO - 2022-12-09 11:36:45 --> Router Class Initialized
INFO - 2022-12-09 11:36:45 --> Output Class Initialized
INFO - 2022-12-09 11:36:45 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:45 --> Input Class Initialized
INFO - 2022-12-09 11:36:45 --> Language Class Initialized
INFO - 2022-12-09 11:36:45 --> Loader Class Initialized
INFO - 2022-12-09 11:36:45 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:45 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:45 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:45 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:45 --> Total execution time: 0.0683
INFO - 2022-12-09 11:36:45 --> Config Class Initialized
INFO - 2022-12-09 11:36:45 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:45 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:45 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:45 --> URI Class Initialized
INFO - 2022-12-09 11:36:45 --> Router Class Initialized
INFO - 2022-12-09 11:36:45 --> Output Class Initialized
INFO - 2022-12-09 11:36:45 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:45 --> Input Class Initialized
INFO - 2022-12-09 11:36:45 --> Language Class Initialized
INFO - 2022-12-09 11:36:45 --> Loader Class Initialized
INFO - 2022-12-09 11:36:45 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:45 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:45 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:45 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:45 --> Total execution time: 0.1718
INFO - 2022-12-09 11:36:50 --> Config Class Initialized
INFO - 2022-12-09 11:36:50 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:50 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:50 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:50 --> URI Class Initialized
INFO - 2022-12-09 11:36:50 --> Router Class Initialized
INFO - 2022-12-09 11:36:50 --> Output Class Initialized
INFO - 2022-12-09 11:36:50 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:50 --> Input Class Initialized
INFO - 2022-12-09 11:36:50 --> Language Class Initialized
INFO - 2022-12-09 11:36:50 --> Loader Class Initialized
INFO - 2022-12-09 11:36:50 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:50 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:53 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:53 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:53 --> Total execution time: 3.0517
INFO - 2022-12-09 11:36:53 --> Config Class Initialized
INFO - 2022-12-09 11:36:53 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:36:53 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:36:53 --> Utf8 Class Initialized
INFO - 2022-12-09 11:36:53 --> URI Class Initialized
INFO - 2022-12-09 11:36:53 --> Router Class Initialized
INFO - 2022-12-09 11:36:53 --> Output Class Initialized
INFO - 2022-12-09 11:36:53 --> Security Class Initialized
DEBUG - 2022-12-09 11:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:36:53 --> Input Class Initialized
INFO - 2022-12-09 11:36:53 --> Language Class Initialized
INFO - 2022-12-09 11:36:53 --> Loader Class Initialized
INFO - 2022-12-09 11:36:53 --> Controller Class Initialized
DEBUG - 2022-12-09 11:36:53 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:36:53 --> Database Driver Class Initialized
INFO - 2022-12-09 11:36:53 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:36:53 --> Final output sent to browser
DEBUG - 2022-12-09 11:36:53 --> Total execution time: 0.2019
INFO - 2022-12-09 11:38:13 --> Config Class Initialized
INFO - 2022-12-09 11:38:13 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:13 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:13 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:13 --> URI Class Initialized
INFO - 2022-12-09 11:38:13 --> Router Class Initialized
INFO - 2022-12-09 11:38:13 --> Output Class Initialized
INFO - 2022-12-09 11:38:13 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:13 --> Input Class Initialized
INFO - 2022-12-09 11:38:13 --> Language Class Initialized
INFO - 2022-12-09 11:38:13 --> Loader Class Initialized
INFO - 2022-12-09 11:38:13 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:13 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:13 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:13 --> Total execution time: 0.0230
INFO - 2022-12-09 11:38:13 --> Config Class Initialized
INFO - 2022-12-09 11:38:13 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:13 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:13 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:13 --> URI Class Initialized
INFO - 2022-12-09 11:38:13 --> Router Class Initialized
INFO - 2022-12-09 11:38:13 --> Output Class Initialized
INFO - 2022-12-09 11:38:13 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:13 --> Input Class Initialized
INFO - 2022-12-09 11:38:13 --> Language Class Initialized
INFO - 2022-12-09 11:38:13 --> Loader Class Initialized
INFO - 2022-12-09 11:38:13 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:13 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:13 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:13 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:13 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:13 --> Total execution time: 0.0367
INFO - 2022-12-09 11:38:14 --> Config Class Initialized
INFO - 2022-12-09 11:38:14 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:14 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:14 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:14 --> URI Class Initialized
INFO - 2022-12-09 11:38:14 --> Router Class Initialized
INFO - 2022-12-09 11:38:14 --> Output Class Initialized
INFO - 2022-12-09 11:38:14 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:14 --> Input Class Initialized
INFO - 2022-12-09 11:38:14 --> Language Class Initialized
INFO - 2022-12-09 11:38:14 --> Loader Class Initialized
INFO - 2022-12-09 11:38:14 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:14 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:14 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:14 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:14 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:14 --> Total execution time: 0.0462
INFO - 2022-12-09 11:38:15 --> Config Class Initialized
INFO - 2022-12-09 11:38:15 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:15 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:15 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:15 --> URI Class Initialized
INFO - 2022-12-09 11:38:15 --> Router Class Initialized
INFO - 2022-12-09 11:38:15 --> Output Class Initialized
INFO - 2022-12-09 11:38:15 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:15 --> Input Class Initialized
INFO - 2022-12-09 11:38:15 --> Language Class Initialized
INFO - 2022-12-09 11:38:15 --> Loader Class Initialized
INFO - 2022-12-09 11:38:15 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:15 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:15 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:15 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:15 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:15 --> Total execution time: 0.0417
INFO - 2022-12-09 11:38:15 --> Config Class Initialized
INFO - 2022-12-09 11:38:15 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:15 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:15 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:15 --> URI Class Initialized
INFO - 2022-12-09 11:38:15 --> Router Class Initialized
INFO - 2022-12-09 11:38:15 --> Output Class Initialized
INFO - 2022-12-09 11:38:15 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:15 --> Input Class Initialized
INFO - 2022-12-09 11:38:15 --> Language Class Initialized
INFO - 2022-12-09 11:38:15 --> Loader Class Initialized
INFO - 2022-12-09 11:38:15 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:15 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:15 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:15 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:15 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:15 --> Total execution time: 0.0508
INFO - 2022-12-09 11:38:17 --> Config Class Initialized
INFO - 2022-12-09 11:38:17 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:17 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:17 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:17 --> URI Class Initialized
INFO - 2022-12-09 11:38:17 --> Router Class Initialized
INFO - 2022-12-09 11:38:17 --> Output Class Initialized
INFO - 2022-12-09 11:38:17 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:17 --> Input Class Initialized
INFO - 2022-12-09 11:38:17 --> Language Class Initialized
INFO - 2022-12-09 11:38:17 --> Loader Class Initialized
INFO - 2022-12-09 11:38:17 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:17 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:17 --> Total execution time: 0.0216
INFO - 2022-12-09 11:38:17 --> Config Class Initialized
INFO - 2022-12-09 11:38:17 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:17 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:17 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:17 --> URI Class Initialized
INFO - 2022-12-09 11:38:17 --> Router Class Initialized
INFO - 2022-12-09 11:38:17 --> Output Class Initialized
INFO - 2022-12-09 11:38:17 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:17 --> Input Class Initialized
INFO - 2022-12-09 11:38:17 --> Language Class Initialized
INFO - 2022-12-09 11:38:17 --> Loader Class Initialized
INFO - 2022-12-09 11:38:17 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:17 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:17 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:17 --> Model "PGsql_model" initialized
INFO - 2022-12-09 11:38:17 --> Model "Grafana_model" initialized
ERROR - 2022-12-09 11:38:17 --> Exception of type 'TypeError' occurred with Message: count(): Argument #1 ($value) must be of type Countable|array, null given in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Grafana.php at Line 181
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Grafana->pgsqlDashboard()
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#2 {main}
INFO - 2022-12-09 11:38:23 --> Config Class Initialized
INFO - 2022-12-09 11:38:23 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:23 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:23 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:23 --> URI Class Initialized
INFO - 2022-12-09 11:38:23 --> Router Class Initialized
INFO - 2022-12-09 11:38:23 --> Output Class Initialized
INFO - 2022-12-09 11:38:23 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:23 --> Input Class Initialized
INFO - 2022-12-09 11:38:23 --> Language Class Initialized
INFO - 2022-12-09 11:38:23 --> Loader Class Initialized
INFO - 2022-12-09 11:38:23 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:23 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:23 --> Total execution time: 0.0234
INFO - 2022-12-09 11:38:23 --> Config Class Initialized
INFO - 2022-12-09 11:38:23 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:23 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:23 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:23 --> URI Class Initialized
INFO - 2022-12-09 11:38:23 --> Router Class Initialized
INFO - 2022-12-09 11:38:23 --> Output Class Initialized
INFO - 2022-12-09 11:38:23 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:23 --> Input Class Initialized
INFO - 2022-12-09 11:38:23 --> Language Class Initialized
INFO - 2022-12-09 11:38:23 --> Loader Class Initialized
INFO - 2022-12-09 11:38:23 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:23 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:23 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:23 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:23 --> Total execution time: 0.0411
INFO - 2022-12-09 11:38:25 --> Config Class Initialized
INFO - 2022-12-09 11:38:25 --> Config Class Initialized
INFO - 2022-12-09 11:38:25 --> Hooks Class Initialized
INFO - 2022-12-09 11:38:25 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-09 11:38:25 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:25 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:25 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:25 --> URI Class Initialized
INFO - 2022-12-09 11:38:25 --> URI Class Initialized
INFO - 2022-12-09 11:38:25 --> Router Class Initialized
INFO - 2022-12-09 11:38:25 --> Router Class Initialized
INFO - 2022-12-09 11:38:25 --> Output Class Initialized
INFO - 2022-12-09 11:38:25 --> Output Class Initialized
INFO - 2022-12-09 11:38:25 --> Security Class Initialized
INFO - 2022-12-09 11:38:25 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-09 11:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:25 --> Input Class Initialized
INFO - 2022-12-09 11:38:25 --> Input Class Initialized
INFO - 2022-12-09 11:38:25 --> Language Class Initialized
INFO - 2022-12-09 11:38:25 --> Language Class Initialized
INFO - 2022-12-09 11:38:25 --> Loader Class Initialized
INFO - 2022-12-09 11:38:25 --> Loader Class Initialized
INFO - 2022-12-09 11:38:25 --> Controller Class Initialized
INFO - 2022-12-09 11:38:25 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-09 11:38:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:25 --> Final output sent to browser
INFO - 2022-12-09 11:38:25 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:25 --> Total execution time: 0.0286
DEBUG - 2022-12-09 11:38:25 --> Total execution time: 0.0289
INFO - 2022-12-09 11:38:25 --> Config Class Initialized
INFO - 2022-12-09 11:38:25 --> Hooks Class Initialized
INFO - 2022-12-09 11:38:25 --> Config Class Initialized
INFO - 2022-12-09 11:38:25 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:25 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:25 --> Utf8 Class Initialized
DEBUG - 2022-12-09 11:38:25 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:25 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:25 --> URI Class Initialized
INFO - 2022-12-09 11:38:25 --> URI Class Initialized
INFO - 2022-12-09 11:38:25 --> Router Class Initialized
INFO - 2022-12-09 11:38:25 --> Router Class Initialized
INFO - 2022-12-09 11:38:25 --> Output Class Initialized
INFO - 2022-12-09 11:38:25 --> Output Class Initialized
INFO - 2022-12-09 11:38:25 --> Security Class Initialized
INFO - 2022-12-09 11:38:25 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-09 11:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:25 --> Input Class Initialized
INFO - 2022-12-09 11:38:25 --> Input Class Initialized
INFO - 2022-12-09 11:38:25 --> Language Class Initialized
INFO - 2022-12-09 11:38:25 --> Language Class Initialized
INFO - 2022-12-09 11:38:25 --> Loader Class Initialized
INFO - 2022-12-09 11:38:25 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:25 --> Loader Class Initialized
INFO - 2022-12-09 11:38:25 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:25 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:25 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:25 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:25 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:25 --> Final output sent to browser
INFO - 2022-12-09 11:38:25 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:25 --> Total execution time: 0.0573
DEBUG - 2022-12-09 11:38:25 --> Total execution time: 0.0575
INFO - 2022-12-09 11:38:29 --> Config Class Initialized
INFO - 2022-12-09 11:38:29 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:29 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:29 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:29 --> URI Class Initialized
INFO - 2022-12-09 11:38:29 --> Router Class Initialized
INFO - 2022-12-09 11:38:29 --> Output Class Initialized
INFO - 2022-12-09 11:38:29 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:29 --> Input Class Initialized
INFO - 2022-12-09 11:38:29 --> Language Class Initialized
INFO - 2022-12-09 11:38:29 --> Loader Class Initialized
INFO - 2022-12-09 11:38:29 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:29 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:29 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:29 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:29 --> Total execution time: 0.0488
INFO - 2022-12-09 11:38:29 --> Config Class Initialized
INFO - 2022-12-09 11:38:29 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:29 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:29 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:29 --> URI Class Initialized
INFO - 2022-12-09 11:38:29 --> Router Class Initialized
INFO - 2022-12-09 11:38:29 --> Output Class Initialized
INFO - 2022-12-09 11:38:29 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:29 --> Input Class Initialized
INFO - 2022-12-09 11:38:29 --> Language Class Initialized
INFO - 2022-12-09 11:38:29 --> Loader Class Initialized
INFO - 2022-12-09 11:38:29 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:29 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:29 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:29 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:29 --> Total execution time: 0.0527
INFO - 2022-12-09 11:38:32 --> Config Class Initialized
INFO - 2022-12-09 11:38:32 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:32 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:32 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:32 --> URI Class Initialized
INFO - 2022-12-09 11:38:32 --> Router Class Initialized
INFO - 2022-12-09 11:38:32 --> Output Class Initialized
INFO - 2022-12-09 11:38:32 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:32 --> Input Class Initialized
INFO - 2022-12-09 11:38:32 --> Language Class Initialized
INFO - 2022-12-09 11:38:32 --> Loader Class Initialized
INFO - 2022-12-09 11:38:32 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:32 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:32 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:32 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:32 --> Total execution time: 0.0552
INFO - 2022-12-09 11:38:32 --> Config Class Initialized
INFO - 2022-12-09 11:38:32 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:32 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:32 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:32 --> URI Class Initialized
INFO - 2022-12-09 11:38:32 --> Router Class Initialized
INFO - 2022-12-09 11:38:32 --> Output Class Initialized
INFO - 2022-12-09 11:38:32 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:32 --> Input Class Initialized
INFO - 2022-12-09 11:38:32 --> Language Class Initialized
INFO - 2022-12-09 11:38:32 --> Loader Class Initialized
INFO - 2022-12-09 11:38:32 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:32 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:32 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:32 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:32 --> Total execution time: 0.0381
INFO - 2022-12-09 11:38:36 --> Config Class Initialized
INFO - 2022-12-09 11:38:36 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:36 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:36 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:36 --> URI Class Initialized
INFO - 2022-12-09 11:38:36 --> Router Class Initialized
INFO - 2022-12-09 11:38:36 --> Output Class Initialized
INFO - 2022-12-09 11:38:36 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:36 --> Input Class Initialized
INFO - 2022-12-09 11:38:36 --> Language Class Initialized
INFO - 2022-12-09 11:38:36 --> Loader Class Initialized
INFO - 2022-12-09 11:38:36 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:36 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:36 --> Total execution time: 0.0327
INFO - 2022-12-09 11:38:36 --> Config Class Initialized
INFO - 2022-12-09 11:38:36 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:36 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:36 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:36 --> URI Class Initialized
INFO - 2022-12-09 11:38:36 --> Router Class Initialized
INFO - 2022-12-09 11:38:36 --> Output Class Initialized
INFO - 2022-12-09 11:38:36 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:36 --> Input Class Initialized
INFO - 2022-12-09 11:38:36 --> Language Class Initialized
INFO - 2022-12-09 11:38:36 --> Loader Class Initialized
INFO - 2022-12-09 11:38:36 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:36 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:36 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:36 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:36 --> Total execution time: 0.0453
INFO - 2022-12-09 11:38:38 --> Config Class Initialized
INFO - 2022-12-09 11:38:38 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:38 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:38 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:38 --> URI Class Initialized
INFO - 2022-12-09 11:38:38 --> Router Class Initialized
INFO - 2022-12-09 11:38:38 --> Output Class Initialized
INFO - 2022-12-09 11:38:38 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:38 --> Input Class Initialized
INFO - 2022-12-09 11:38:38 --> Language Class Initialized
INFO - 2022-12-09 11:38:38 --> Loader Class Initialized
INFO - 2022-12-09 11:38:38 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:38 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:38 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:38 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:38 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:38 --> Total execution time: 0.0684
INFO - 2022-12-09 11:38:38 --> Config Class Initialized
INFO - 2022-12-09 11:38:38 --> Hooks Class Initialized
DEBUG - 2022-12-09 11:38:38 --> UTF-8 Support Enabled
INFO - 2022-12-09 11:38:38 --> Utf8 Class Initialized
INFO - 2022-12-09 11:38:38 --> URI Class Initialized
INFO - 2022-12-09 11:38:38 --> Router Class Initialized
INFO - 2022-12-09 11:38:38 --> Output Class Initialized
INFO - 2022-12-09 11:38:38 --> Security Class Initialized
DEBUG - 2022-12-09 11:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-09 11:38:38 --> Input Class Initialized
INFO - 2022-12-09 11:38:38 --> Language Class Initialized
INFO - 2022-12-09 11:38:38 --> Loader Class Initialized
INFO - 2022-12-09 11:38:38 --> Controller Class Initialized
DEBUG - 2022-12-09 11:38:38 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-09 11:38:38 --> Database Driver Class Initialized
INFO - 2022-12-09 11:38:38 --> Model "Cluster_model" initialized
INFO - 2022-12-09 11:38:38 --> Final output sent to browser
DEBUG - 2022-12-09 11:38:38 --> Total execution time: 0.2201
