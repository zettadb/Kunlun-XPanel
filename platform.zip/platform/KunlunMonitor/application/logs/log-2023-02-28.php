<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-02-28 03:32:05 --> Config Class Initialized
INFO - 2023-02-28 03:32:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:32:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:32:05 --> Utf8 Class Initialized
INFO - 2023-02-28 03:32:05 --> URI Class Initialized
INFO - 2023-02-28 03:32:05 --> Router Class Initialized
INFO - 2023-02-28 03:32:05 --> Output Class Initialized
INFO - 2023-02-28 03:32:05 --> Security Class Initialized
DEBUG - 2023-02-28 03:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:32:05 --> Input Class Initialized
INFO - 2023-02-28 03:32:05 --> Language Class Initialized
INFO - 2023-02-28 03:32:05 --> Loader Class Initialized
INFO - 2023-02-28 03:32:05 --> Controller Class Initialized
INFO - 2023-02-28 03:32:05 --> Helper loaded: form_helper
INFO - 2023-02-28 03:32:05 --> Helper loaded: url_helper
DEBUG - 2023-02-28 03:32:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:32:05 --> Final output sent to browser
DEBUG - 2023-02-28 03:32:05 --> Total execution time: 0.0074
INFO - 2023-02-28 03:32:05 --> Config Class Initialized
INFO - 2023-02-28 03:32:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:32:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:32:05 --> Utf8 Class Initialized
INFO - 2023-02-28 03:32:05 --> URI Class Initialized
INFO - 2023-02-28 03:32:05 --> Router Class Initialized
INFO - 2023-02-28 03:32:05 --> Output Class Initialized
INFO - 2023-02-28 03:32:05 --> Security Class Initialized
DEBUG - 2023-02-28 03:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:32:05 --> Input Class Initialized
INFO - 2023-02-28 03:32:05 --> Language Class Initialized
INFO - 2023-02-28 03:32:05 --> Loader Class Initialized
INFO - 2023-02-28 03:32:05 --> Controller Class Initialized
INFO - 2023-02-28 03:32:05 --> Helper loaded: form_helper
INFO - 2023-02-28 03:32:05 --> Helper loaded: url_helper
DEBUG - 2023-02-28 03:32:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:32:05 --> Final output sent to browser
DEBUG - 2023-02-28 03:32:05 --> Total execution time: 0.0032
INFO - 2023-02-28 03:32:07 --> Config Class Initialized
INFO - 2023-02-28 03:32:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:32:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:32:07 --> Utf8 Class Initialized
INFO - 2023-02-28 03:32:07 --> URI Class Initialized
INFO - 2023-02-28 03:32:07 --> Router Class Initialized
INFO - 2023-02-28 03:32:07 --> Output Class Initialized
INFO - 2023-02-28 03:32:07 --> Security Class Initialized
DEBUG - 2023-02-28 03:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:32:07 --> Input Class Initialized
INFO - 2023-02-28 03:32:07 --> Language Class Initialized
INFO - 2023-02-28 03:32:07 --> Loader Class Initialized
INFO - 2023-02-28 03:32:07 --> Controller Class Initialized
INFO - 2023-02-28 03:32:07 --> Helper loaded: form_helper
INFO - 2023-02-28 03:32:07 --> Helper loaded: url_helper
DEBUG - 2023-02-28 03:32:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:32:07 --> Final output sent to browser
DEBUG - 2023-02-28 03:32:07 --> Total execution time: 0.0054
INFO - 2023-02-28 03:32:07 --> Config Class Initialized
INFO - 2023-02-28 03:32:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:32:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:32:07 --> Utf8 Class Initialized
INFO - 2023-02-28 03:32:07 --> URI Class Initialized
INFO - 2023-02-28 03:32:07 --> Router Class Initialized
INFO - 2023-02-28 03:32:07 --> Output Class Initialized
INFO - 2023-02-28 03:32:07 --> Security Class Initialized
DEBUG - 2023-02-28 03:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:32:07 --> Input Class Initialized
INFO - 2023-02-28 03:32:07 --> Language Class Initialized
INFO - 2023-02-28 03:32:07 --> Loader Class Initialized
INFO - 2023-02-28 03:32:07 --> Controller Class Initialized
INFO - 2023-02-28 03:32:07 --> Helper loaded: form_helper
INFO - 2023-02-28 03:32:07 --> Helper loaded: url_helper
DEBUG - 2023-02-28 03:32:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:32:07 --> Final output sent to browser
DEBUG - 2023-02-28 03:32:07 --> Total execution time: 0.0018
INFO - 2023-02-28 03:32:13 --> Config Class Initialized
INFO - 2023-02-28 03:32:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:32:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:32:13 --> Utf8 Class Initialized
INFO - 2023-02-28 03:32:13 --> URI Class Initialized
INFO - 2023-02-28 03:32:13 --> Router Class Initialized
INFO - 2023-02-28 03:32:13 --> Output Class Initialized
INFO - 2023-02-28 03:32:13 --> Security Class Initialized
DEBUG - 2023-02-28 03:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:32:13 --> Input Class Initialized
INFO - 2023-02-28 03:32:13 --> Language Class Initialized
INFO - 2023-02-28 03:32:13 --> Loader Class Initialized
INFO - 2023-02-28 03:32:13 --> Controller Class Initialized
INFO - 2023-02-28 03:32:13 --> Helper loaded: form_helper
INFO - 2023-02-28 03:32:13 --> Helper loaded: url_helper
DEBUG - 2023-02-28 03:32:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:32:13 --> Final output sent to browser
DEBUG - 2023-02-28 03:32:13 --> Total execution time: 0.0050
INFO - 2023-02-28 03:32:13 --> Config Class Initialized
INFO - 2023-02-28 03:32:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:32:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:32:13 --> Utf8 Class Initialized
INFO - 2023-02-28 03:32:13 --> URI Class Initialized
INFO - 2023-02-28 03:32:13 --> Router Class Initialized
INFO - 2023-02-28 03:32:13 --> Output Class Initialized
INFO - 2023-02-28 03:32:13 --> Security Class Initialized
DEBUG - 2023-02-28 03:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:32:13 --> Input Class Initialized
INFO - 2023-02-28 03:32:13 --> Language Class Initialized
INFO - 2023-02-28 03:32:13 --> Loader Class Initialized
INFO - 2023-02-28 03:32:13 --> Controller Class Initialized
INFO - 2023-02-28 03:32:13 --> Helper loaded: form_helper
INFO - 2023-02-28 03:32:13 --> Helper loaded: url_helper
DEBUG - 2023-02-28 03:32:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:32:13 --> Final output sent to browser
DEBUG - 2023-02-28 03:32:13 --> Total execution time: 0.0035
INFO - 2023-02-28 03:34:15 --> Config Class Initialized
INFO - 2023-02-28 03:34:15 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:34:15 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:34:15 --> Utf8 Class Initialized
INFO - 2023-02-28 03:34:15 --> URI Class Initialized
INFO - 2023-02-28 03:34:15 --> Router Class Initialized
INFO - 2023-02-28 03:34:15 --> Output Class Initialized
INFO - 2023-02-28 03:34:15 --> Security Class Initialized
DEBUG - 2023-02-28 03:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:34:15 --> Input Class Initialized
INFO - 2023-02-28 03:34:15 --> Language Class Initialized
INFO - 2023-02-28 03:34:15 --> Loader Class Initialized
INFO - 2023-02-28 03:34:15 --> Controller Class Initialized
DEBUG - 2023-02-28 03:34:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:34:15 --> Database Driver Class Initialized
INFO - 2023-02-28 03:34:15 --> Final output sent to browser
DEBUG - 2023-02-28 03:34:15 --> Total execution time: 0.0215
INFO - 2023-02-28 03:34:15 --> Config Class Initialized
INFO - 2023-02-28 03:34:15 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:34:15 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:34:15 --> Utf8 Class Initialized
INFO - 2023-02-28 03:34:15 --> URI Class Initialized
INFO - 2023-02-28 03:34:15 --> Router Class Initialized
INFO - 2023-02-28 03:34:15 --> Output Class Initialized
INFO - 2023-02-28 03:34:15 --> Security Class Initialized
DEBUG - 2023-02-28 03:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:34:15 --> Input Class Initialized
INFO - 2023-02-28 03:34:15 --> Language Class Initialized
INFO - 2023-02-28 03:34:15 --> Loader Class Initialized
INFO - 2023-02-28 03:34:15 --> Controller Class Initialized
DEBUG - 2023-02-28 03:34:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:34:15 --> Database Driver Class Initialized
INFO - 2023-02-28 03:34:15 --> Final output sent to browser
DEBUG - 2023-02-28 03:34:15 --> Total execution time: 0.0118
INFO - 2023-02-28 03:34:31 --> Config Class Initialized
INFO - 2023-02-28 03:34:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:34:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:34:31 --> Utf8 Class Initialized
INFO - 2023-02-28 03:34:31 --> URI Class Initialized
INFO - 2023-02-28 03:34:31 --> Router Class Initialized
INFO - 2023-02-28 03:34:31 --> Output Class Initialized
INFO - 2023-02-28 03:34:31 --> Security Class Initialized
DEBUG - 2023-02-28 03:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:34:31 --> Input Class Initialized
INFO - 2023-02-28 03:34:31 --> Language Class Initialized
INFO - 2023-02-28 03:34:31 --> Loader Class Initialized
INFO - 2023-02-28 03:34:31 --> Controller Class Initialized
DEBUG - 2023-02-28 03:34:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:34:31 --> Database Driver Class Initialized
INFO - 2023-02-28 03:34:31 --> Final output sent to browser
DEBUG - 2023-02-28 03:34:31 --> Total execution time: 0.0131
INFO - 2023-02-28 03:34:31 --> Config Class Initialized
INFO - 2023-02-28 03:34:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:34:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:34:31 --> Utf8 Class Initialized
INFO - 2023-02-28 03:34:31 --> URI Class Initialized
INFO - 2023-02-28 03:34:31 --> Router Class Initialized
INFO - 2023-02-28 03:34:31 --> Output Class Initialized
INFO - 2023-02-28 03:34:31 --> Security Class Initialized
DEBUG - 2023-02-28 03:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:34:31 --> Input Class Initialized
INFO - 2023-02-28 03:34:31 --> Language Class Initialized
INFO - 2023-02-28 03:34:31 --> Loader Class Initialized
INFO - 2023-02-28 03:34:31 --> Controller Class Initialized
DEBUG - 2023-02-28 03:34:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:34:31 --> Database Driver Class Initialized
INFO - 2023-02-28 03:34:31 --> Final output sent to browser
DEBUG - 2023-02-28 03:34:31 --> Total execution time: 0.0084
INFO - 2023-02-28 03:39:15 --> Config Class Initialized
INFO - 2023-02-28 03:39:15 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:39:15 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:39:15 --> Utf8 Class Initialized
INFO - 2023-02-28 03:39:15 --> URI Class Initialized
INFO - 2023-02-28 03:39:15 --> Router Class Initialized
INFO - 2023-02-28 03:39:15 --> Output Class Initialized
INFO - 2023-02-28 03:39:15 --> Security Class Initialized
DEBUG - 2023-02-28 03:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:39:15 --> Input Class Initialized
INFO - 2023-02-28 03:39:15 --> Language Class Initialized
INFO - 2023-02-28 03:39:15 --> Loader Class Initialized
INFO - 2023-02-28 03:39:15 --> Controller Class Initialized
DEBUG - 2023-02-28 03:39:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:39:15 --> Database Driver Class Initialized
INFO - 2023-02-28 03:39:15 --> Final output sent to browser
DEBUG - 2023-02-28 03:39:15 --> Total execution time: 0.0122
INFO - 2023-02-28 03:39:15 --> Config Class Initialized
INFO - 2023-02-28 03:39:15 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:39:15 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:39:15 --> Utf8 Class Initialized
INFO - 2023-02-28 03:39:15 --> URI Class Initialized
INFO - 2023-02-28 03:39:15 --> Router Class Initialized
INFO - 2023-02-28 03:39:15 --> Output Class Initialized
INFO - 2023-02-28 03:39:15 --> Security Class Initialized
DEBUG - 2023-02-28 03:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:39:15 --> Input Class Initialized
INFO - 2023-02-28 03:39:15 --> Language Class Initialized
INFO - 2023-02-28 03:39:15 --> Loader Class Initialized
INFO - 2023-02-28 03:39:15 --> Controller Class Initialized
DEBUG - 2023-02-28 03:39:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:39:15 --> Database Driver Class Initialized
INFO - 2023-02-28 03:39:15 --> Final output sent to browser
DEBUG - 2023-02-28 03:39:15 --> Total execution time: 0.0089
INFO - 2023-02-28 03:41:51 --> Config Class Initialized
INFO - 2023-02-28 03:41:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:41:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:41:51 --> Utf8 Class Initialized
INFO - 2023-02-28 03:41:51 --> URI Class Initialized
INFO - 2023-02-28 03:41:51 --> Router Class Initialized
INFO - 2023-02-28 03:41:51 --> Output Class Initialized
INFO - 2023-02-28 03:41:51 --> Security Class Initialized
DEBUG - 2023-02-28 03:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:41:51 --> Input Class Initialized
INFO - 2023-02-28 03:41:51 --> Language Class Initialized
INFO - 2023-02-28 03:41:51 --> Loader Class Initialized
INFO - 2023-02-28 03:41:51 --> Controller Class Initialized
DEBUG - 2023-02-28 03:41:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:41:51 --> Database Driver Class Initialized
INFO - 2023-02-28 03:41:51 --> Final output sent to browser
DEBUG - 2023-02-28 03:41:51 --> Total execution time: 0.0167
INFO - 2023-02-28 03:41:51 --> Config Class Initialized
INFO - 2023-02-28 03:41:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:41:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:41:51 --> Utf8 Class Initialized
INFO - 2023-02-28 03:41:51 --> URI Class Initialized
INFO - 2023-02-28 03:41:51 --> Router Class Initialized
INFO - 2023-02-28 03:41:51 --> Output Class Initialized
INFO - 2023-02-28 03:41:51 --> Security Class Initialized
DEBUG - 2023-02-28 03:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:41:51 --> Input Class Initialized
INFO - 2023-02-28 03:41:51 --> Language Class Initialized
INFO - 2023-02-28 03:41:51 --> Loader Class Initialized
INFO - 2023-02-28 03:41:51 --> Controller Class Initialized
DEBUG - 2023-02-28 03:41:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:41:51 --> Database Driver Class Initialized
INFO - 2023-02-28 03:41:51 --> Final output sent to browser
DEBUG - 2023-02-28 03:41:51 --> Total execution time: 0.0095
INFO - 2023-02-28 03:42:04 --> Config Class Initialized
INFO - 2023-02-28 03:42:04 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:42:04 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:42:04 --> Utf8 Class Initialized
INFO - 2023-02-28 03:42:04 --> URI Class Initialized
INFO - 2023-02-28 03:42:04 --> Router Class Initialized
INFO - 2023-02-28 03:42:04 --> Output Class Initialized
INFO - 2023-02-28 03:42:04 --> Security Class Initialized
DEBUG - 2023-02-28 03:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:42:04 --> Input Class Initialized
INFO - 2023-02-28 03:42:04 --> Language Class Initialized
INFO - 2023-02-28 03:42:04 --> Loader Class Initialized
INFO - 2023-02-28 03:42:04 --> Controller Class Initialized
DEBUG - 2023-02-28 03:42:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:42:04 --> Database Driver Class Initialized
INFO - 2023-02-28 03:42:04 --> Final output sent to browser
DEBUG - 2023-02-28 03:42:04 --> Total execution time: 0.0109
INFO - 2023-02-28 03:42:04 --> Config Class Initialized
INFO - 2023-02-28 03:42:04 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:42:04 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:42:04 --> Utf8 Class Initialized
INFO - 2023-02-28 03:42:04 --> URI Class Initialized
INFO - 2023-02-28 03:42:04 --> Router Class Initialized
INFO - 2023-02-28 03:42:04 --> Output Class Initialized
INFO - 2023-02-28 03:42:04 --> Security Class Initialized
DEBUG - 2023-02-28 03:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:42:04 --> Input Class Initialized
INFO - 2023-02-28 03:42:04 --> Language Class Initialized
INFO - 2023-02-28 03:42:04 --> Loader Class Initialized
INFO - 2023-02-28 03:42:04 --> Controller Class Initialized
DEBUG - 2023-02-28 03:42:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:42:04 --> Database Driver Class Initialized
INFO - 2023-02-28 03:42:04 --> Final output sent to browser
DEBUG - 2023-02-28 03:42:04 --> Total execution time: 0.0078
INFO - 2023-02-28 03:42:07 --> Config Class Initialized
INFO - 2023-02-28 03:42:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:42:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:42:07 --> Utf8 Class Initialized
INFO - 2023-02-28 03:42:07 --> URI Class Initialized
INFO - 2023-02-28 03:42:07 --> Router Class Initialized
INFO - 2023-02-28 03:42:07 --> Output Class Initialized
INFO - 2023-02-28 03:42:07 --> Security Class Initialized
DEBUG - 2023-02-28 03:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:42:07 --> Input Class Initialized
INFO - 2023-02-28 03:42:07 --> Language Class Initialized
INFO - 2023-02-28 03:42:07 --> Loader Class Initialized
INFO - 2023-02-28 03:42:07 --> Controller Class Initialized
DEBUG - 2023-02-28 03:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:42:07 --> Database Driver Class Initialized
INFO - 2023-02-28 03:42:07 --> Final output sent to browser
DEBUG - 2023-02-28 03:42:07 --> Total execution time: 0.0150
INFO - 2023-02-28 03:42:07 --> Config Class Initialized
INFO - 2023-02-28 03:42:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:42:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:42:07 --> Utf8 Class Initialized
INFO - 2023-02-28 03:42:07 --> URI Class Initialized
INFO - 2023-02-28 03:42:07 --> Router Class Initialized
INFO - 2023-02-28 03:42:07 --> Output Class Initialized
INFO - 2023-02-28 03:42:07 --> Security Class Initialized
DEBUG - 2023-02-28 03:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:42:07 --> Input Class Initialized
INFO - 2023-02-28 03:42:07 --> Language Class Initialized
INFO - 2023-02-28 03:42:07 --> Loader Class Initialized
INFO - 2023-02-28 03:42:07 --> Controller Class Initialized
DEBUG - 2023-02-28 03:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:42:07 --> Database Driver Class Initialized
INFO - 2023-02-28 03:42:07 --> Final output sent to browser
DEBUG - 2023-02-28 03:42:07 --> Total execution time: 0.0650
INFO - 2023-02-28 03:42:07 --> Config Class Initialized
INFO - 2023-02-28 03:42:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:42:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:42:07 --> Utf8 Class Initialized
INFO - 2023-02-28 03:42:07 --> URI Class Initialized
INFO - 2023-02-28 03:42:07 --> Router Class Initialized
INFO - 2023-02-28 03:42:07 --> Output Class Initialized
INFO - 2023-02-28 03:42:07 --> Security Class Initialized
DEBUG - 2023-02-28 03:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:42:07 --> Input Class Initialized
INFO - 2023-02-28 03:42:07 --> Language Class Initialized
INFO - 2023-02-28 03:42:07 --> Loader Class Initialized
INFO - 2023-02-28 03:42:07 --> Controller Class Initialized
DEBUG - 2023-02-28 03:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:42:07 --> Database Driver Class Initialized
INFO - 2023-02-28 03:42:07 --> Final output sent to browser
DEBUG - 2023-02-28 03:42:07 --> Total execution time: 0.0228
INFO - 2023-02-28 03:42:07 --> Config Class Initialized
INFO - 2023-02-28 03:42:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:42:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:42:07 --> Utf8 Class Initialized
INFO - 2023-02-28 03:42:07 --> URI Class Initialized
INFO - 2023-02-28 03:42:07 --> Router Class Initialized
INFO - 2023-02-28 03:42:07 --> Output Class Initialized
INFO - 2023-02-28 03:42:07 --> Security Class Initialized
DEBUG - 2023-02-28 03:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:42:07 --> Input Class Initialized
INFO - 2023-02-28 03:42:07 --> Language Class Initialized
INFO - 2023-02-28 03:42:07 --> Loader Class Initialized
INFO - 2023-02-28 03:42:07 --> Controller Class Initialized
DEBUG - 2023-02-28 03:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:42:07 --> Database Driver Class Initialized
INFO - 2023-02-28 03:42:07 --> Final output sent to browser
DEBUG - 2023-02-28 03:42:07 --> Total execution time: 0.0120
INFO - 2023-02-28 03:42:07 --> Config Class Initialized
INFO - 2023-02-28 03:42:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:42:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:42:07 --> Utf8 Class Initialized
INFO - 2023-02-28 03:42:07 --> URI Class Initialized
INFO - 2023-02-28 03:42:07 --> Router Class Initialized
INFO - 2023-02-28 03:42:07 --> Output Class Initialized
INFO - 2023-02-28 03:42:07 --> Security Class Initialized
DEBUG - 2023-02-28 03:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:42:07 --> Input Class Initialized
INFO - 2023-02-28 03:42:07 --> Language Class Initialized
INFO - 2023-02-28 03:42:07 --> Loader Class Initialized
INFO - 2023-02-28 03:42:07 --> Controller Class Initialized
DEBUG - 2023-02-28 03:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:42:07 --> Database Driver Class Initialized
INFO - 2023-02-28 03:42:07 --> Final output sent to browser
DEBUG - 2023-02-28 03:42:07 --> Total execution time: 0.0114
INFO - 2023-02-28 03:42:07 --> Config Class Initialized
INFO - 2023-02-28 03:42:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:42:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:42:07 --> Utf8 Class Initialized
INFO - 2023-02-28 03:42:07 --> URI Class Initialized
INFO - 2023-02-28 03:42:07 --> Router Class Initialized
INFO - 2023-02-28 03:42:07 --> Output Class Initialized
INFO - 2023-02-28 03:42:07 --> Security Class Initialized
DEBUG - 2023-02-28 03:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:42:07 --> Input Class Initialized
INFO - 2023-02-28 03:42:07 --> Language Class Initialized
INFO - 2023-02-28 03:42:07 --> Loader Class Initialized
INFO - 2023-02-28 03:42:07 --> Controller Class Initialized
DEBUG - 2023-02-28 03:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:42:07 --> Database Driver Class Initialized
INFO - 2023-02-28 03:42:07 --> Final output sent to browser
DEBUG - 2023-02-28 03:42:07 --> Total execution time: 0.0091
INFO - 2023-02-28 03:42:08 --> Config Class Initialized
INFO - 2023-02-28 03:42:08 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:42:08 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:42:08 --> Utf8 Class Initialized
INFO - 2023-02-28 03:42:08 --> URI Class Initialized
INFO - 2023-02-28 03:42:08 --> Router Class Initialized
INFO - 2023-02-28 03:42:08 --> Output Class Initialized
INFO - 2023-02-28 03:42:08 --> Security Class Initialized
DEBUG - 2023-02-28 03:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:42:08 --> Input Class Initialized
INFO - 2023-02-28 03:42:08 --> Language Class Initialized
INFO - 2023-02-28 03:42:08 --> Loader Class Initialized
INFO - 2023-02-28 03:42:08 --> Controller Class Initialized
DEBUG - 2023-02-28 03:42:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:42:08 --> Database Driver Class Initialized
INFO - 2023-02-28 03:42:08 --> Final output sent to browser
DEBUG - 2023-02-28 03:42:08 --> Total execution time: 0.0120
INFO - 2023-02-28 03:42:08 --> Config Class Initialized
INFO - 2023-02-28 03:42:08 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:42:08 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:42:08 --> Utf8 Class Initialized
INFO - 2023-02-28 03:42:08 --> URI Class Initialized
INFO - 2023-02-28 03:42:08 --> Router Class Initialized
INFO - 2023-02-28 03:42:08 --> Output Class Initialized
INFO - 2023-02-28 03:42:08 --> Security Class Initialized
DEBUG - 2023-02-28 03:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:42:08 --> Input Class Initialized
INFO - 2023-02-28 03:42:08 --> Language Class Initialized
INFO - 2023-02-28 03:42:08 --> Loader Class Initialized
INFO - 2023-02-28 03:42:08 --> Controller Class Initialized
DEBUG - 2023-02-28 03:42:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:42:08 --> Database Driver Class Initialized
INFO - 2023-02-28 03:42:08 --> Final output sent to browser
DEBUG - 2023-02-28 03:42:08 --> Total execution time: 0.0099
INFO - 2023-02-28 03:42:08 --> Config Class Initialized
INFO - 2023-02-28 03:42:08 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:42:08 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:42:08 --> Utf8 Class Initialized
INFO - 2023-02-28 03:42:08 --> URI Class Initialized
INFO - 2023-02-28 03:42:08 --> Router Class Initialized
INFO - 2023-02-28 03:42:08 --> Output Class Initialized
INFO - 2023-02-28 03:42:08 --> Security Class Initialized
DEBUG - 2023-02-28 03:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:42:08 --> Input Class Initialized
INFO - 2023-02-28 03:42:08 --> Language Class Initialized
INFO - 2023-02-28 03:42:08 --> Loader Class Initialized
INFO - 2023-02-28 03:42:08 --> Controller Class Initialized
DEBUG - 2023-02-28 03:42:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:42:08 --> Database Driver Class Initialized
INFO - 2023-02-28 03:42:08 --> Final output sent to browser
DEBUG - 2023-02-28 03:42:08 --> Total execution time: 0.0167
INFO - 2023-02-28 03:42:08 --> Config Class Initialized
INFO - 2023-02-28 03:42:08 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:42:08 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:42:08 --> Utf8 Class Initialized
INFO - 2023-02-28 03:42:08 --> URI Class Initialized
INFO - 2023-02-28 03:42:08 --> Router Class Initialized
INFO - 2023-02-28 03:42:08 --> Output Class Initialized
INFO - 2023-02-28 03:42:08 --> Security Class Initialized
DEBUG - 2023-02-28 03:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:42:08 --> Input Class Initialized
INFO - 2023-02-28 03:42:08 --> Language Class Initialized
INFO - 2023-02-28 03:42:08 --> Loader Class Initialized
INFO - 2023-02-28 03:42:08 --> Controller Class Initialized
DEBUG - 2023-02-28 03:42:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:42:08 --> Database Driver Class Initialized
INFO - 2023-02-28 03:42:08 --> Final output sent to browser
DEBUG - 2023-02-28 03:42:08 --> Total execution time: 0.0129
INFO - 2023-02-28 03:44:47 --> Config Class Initialized
INFO - 2023-02-28 03:44:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:44:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:44:47 --> Utf8 Class Initialized
INFO - 2023-02-28 03:44:47 --> URI Class Initialized
INFO - 2023-02-28 03:44:47 --> Router Class Initialized
INFO - 2023-02-28 03:44:47 --> Output Class Initialized
INFO - 2023-02-28 03:44:47 --> Security Class Initialized
DEBUG - 2023-02-28 03:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:44:47 --> Input Class Initialized
INFO - 2023-02-28 03:44:47 --> Language Class Initialized
INFO - 2023-02-28 03:44:47 --> Loader Class Initialized
INFO - 2023-02-28 03:44:47 --> Controller Class Initialized
DEBUG - 2023-02-28 03:44:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:44:47 --> Database Driver Class Initialized
INFO - 2023-02-28 03:44:47 --> Final output sent to browser
DEBUG - 2023-02-28 03:44:47 --> Total execution time: 0.0176
INFO - 2023-02-28 03:44:47 --> Config Class Initialized
INFO - 2023-02-28 03:44:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:44:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:44:47 --> Utf8 Class Initialized
INFO - 2023-02-28 03:44:47 --> URI Class Initialized
INFO - 2023-02-28 03:44:47 --> Router Class Initialized
INFO - 2023-02-28 03:44:47 --> Output Class Initialized
INFO - 2023-02-28 03:44:47 --> Security Class Initialized
DEBUG - 2023-02-28 03:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:44:47 --> Input Class Initialized
INFO - 2023-02-28 03:44:47 --> Language Class Initialized
INFO - 2023-02-28 03:44:47 --> Loader Class Initialized
INFO - 2023-02-28 03:44:47 --> Controller Class Initialized
DEBUG - 2023-02-28 03:44:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:44:47 --> Database Driver Class Initialized
INFO - 2023-02-28 03:44:47 --> Final output sent to browser
DEBUG - 2023-02-28 03:44:47 --> Total execution time: 0.0113
INFO - 2023-02-28 03:47:28 --> Config Class Initialized
INFO - 2023-02-28 03:47:28 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:47:28 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:47:28 --> Utf8 Class Initialized
INFO - 2023-02-28 03:47:28 --> URI Class Initialized
INFO - 2023-02-28 03:47:28 --> Router Class Initialized
INFO - 2023-02-28 03:47:28 --> Output Class Initialized
INFO - 2023-02-28 03:47:28 --> Security Class Initialized
DEBUG - 2023-02-28 03:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:47:28 --> Input Class Initialized
INFO - 2023-02-28 03:47:28 --> Language Class Initialized
INFO - 2023-02-28 03:47:28 --> Loader Class Initialized
INFO - 2023-02-28 03:47:28 --> Controller Class Initialized
DEBUG - 2023-02-28 03:47:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:47:28 --> Database Driver Class Initialized
INFO - 2023-02-28 03:47:28 --> Final output sent to browser
DEBUG - 2023-02-28 03:47:28 --> Total execution time: 0.0113
INFO - 2023-02-28 03:47:28 --> Config Class Initialized
INFO - 2023-02-28 03:47:28 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:47:28 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:47:28 --> Utf8 Class Initialized
INFO - 2023-02-28 03:47:28 --> URI Class Initialized
INFO - 2023-02-28 03:47:28 --> Router Class Initialized
INFO - 2023-02-28 03:47:28 --> Output Class Initialized
INFO - 2023-02-28 03:47:28 --> Security Class Initialized
DEBUG - 2023-02-28 03:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:47:28 --> Input Class Initialized
INFO - 2023-02-28 03:47:28 --> Language Class Initialized
INFO - 2023-02-28 03:47:28 --> Loader Class Initialized
INFO - 2023-02-28 03:47:28 --> Controller Class Initialized
DEBUG - 2023-02-28 03:47:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:47:28 --> Database Driver Class Initialized
INFO - 2023-02-28 03:47:28 --> Final output sent to browser
DEBUG - 2023-02-28 03:47:28 --> Total execution time: 0.0082
INFO - 2023-02-28 03:53:15 --> Config Class Initialized
INFO - 2023-02-28 03:53:15 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:53:15 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:53:15 --> Utf8 Class Initialized
INFO - 2023-02-28 03:53:15 --> URI Class Initialized
INFO - 2023-02-28 03:53:15 --> Router Class Initialized
INFO - 2023-02-28 03:53:15 --> Output Class Initialized
INFO - 2023-02-28 03:53:15 --> Security Class Initialized
DEBUG - 2023-02-28 03:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:53:15 --> Input Class Initialized
INFO - 2023-02-28 03:53:15 --> Language Class Initialized
INFO - 2023-02-28 03:53:15 --> Loader Class Initialized
INFO - 2023-02-28 03:53:15 --> Controller Class Initialized
DEBUG - 2023-02-28 03:53:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:53:15 --> Database Driver Class Initialized
INFO - 2023-02-28 03:53:15 --> Final output sent to browser
DEBUG - 2023-02-28 03:53:15 --> Total execution time: 0.0159
INFO - 2023-02-28 03:53:15 --> Config Class Initialized
INFO - 2023-02-28 03:53:15 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:53:15 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:53:15 --> Utf8 Class Initialized
INFO - 2023-02-28 03:53:15 --> URI Class Initialized
INFO - 2023-02-28 03:53:15 --> Router Class Initialized
INFO - 2023-02-28 03:53:15 --> Output Class Initialized
INFO - 2023-02-28 03:53:15 --> Security Class Initialized
DEBUG - 2023-02-28 03:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:53:15 --> Input Class Initialized
INFO - 2023-02-28 03:53:15 --> Language Class Initialized
INFO - 2023-02-28 03:53:15 --> Loader Class Initialized
INFO - 2023-02-28 03:53:15 --> Controller Class Initialized
DEBUG - 2023-02-28 03:53:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:53:15 --> Database Driver Class Initialized
INFO - 2023-02-28 03:53:15 --> Final output sent to browser
DEBUG - 2023-02-28 03:53:15 --> Total execution time: 0.0193
INFO - 2023-02-28 03:58:13 --> Config Class Initialized
INFO - 2023-02-28 03:58:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:58:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:58:13 --> Utf8 Class Initialized
INFO - 2023-02-28 03:58:13 --> URI Class Initialized
INFO - 2023-02-28 03:58:13 --> Router Class Initialized
INFO - 2023-02-28 03:58:13 --> Output Class Initialized
INFO - 2023-02-28 03:58:13 --> Security Class Initialized
DEBUG - 2023-02-28 03:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:58:13 --> Input Class Initialized
INFO - 2023-02-28 03:58:13 --> Language Class Initialized
INFO - 2023-02-28 03:58:13 --> Loader Class Initialized
INFO - 2023-02-28 03:58:13 --> Controller Class Initialized
DEBUG - 2023-02-28 03:58:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:58:13 --> Database Driver Class Initialized
INFO - 2023-02-28 03:58:13 --> Final output sent to browser
DEBUG - 2023-02-28 03:58:13 --> Total execution time: 0.0132
INFO - 2023-02-28 03:58:13 --> Config Class Initialized
INFO - 2023-02-28 03:58:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:58:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:58:13 --> Utf8 Class Initialized
INFO - 2023-02-28 03:58:13 --> URI Class Initialized
INFO - 2023-02-28 03:58:13 --> Router Class Initialized
INFO - 2023-02-28 03:58:13 --> Output Class Initialized
INFO - 2023-02-28 03:58:13 --> Security Class Initialized
DEBUG - 2023-02-28 03:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:58:13 --> Input Class Initialized
INFO - 2023-02-28 03:58:13 --> Language Class Initialized
INFO - 2023-02-28 03:58:13 --> Loader Class Initialized
INFO - 2023-02-28 03:58:13 --> Controller Class Initialized
DEBUG - 2023-02-28 03:58:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:58:13 --> Database Driver Class Initialized
INFO - 2023-02-28 03:58:13 --> Final output sent to browser
DEBUG - 2023-02-28 03:58:13 --> Total execution time: 0.0085
INFO - 2023-02-28 03:58:58 --> Config Class Initialized
INFO - 2023-02-28 03:58:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:58:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:58:58 --> Utf8 Class Initialized
INFO - 2023-02-28 03:58:58 --> URI Class Initialized
INFO - 2023-02-28 03:58:58 --> Router Class Initialized
INFO - 2023-02-28 03:58:58 --> Output Class Initialized
INFO - 2023-02-28 03:58:58 --> Security Class Initialized
DEBUG - 2023-02-28 03:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:58:58 --> Input Class Initialized
INFO - 2023-02-28 03:58:58 --> Language Class Initialized
INFO - 2023-02-28 03:58:58 --> Loader Class Initialized
INFO - 2023-02-28 03:58:58 --> Controller Class Initialized
DEBUG - 2023-02-28 03:58:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:58:58 --> Database Driver Class Initialized
INFO - 2023-02-28 03:58:58 --> Final output sent to browser
DEBUG - 2023-02-28 03:58:58 --> Total execution time: 0.0220
INFO - 2023-02-28 03:58:58 --> Config Class Initialized
INFO - 2023-02-28 03:58:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:58:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:58:58 --> Utf8 Class Initialized
INFO - 2023-02-28 03:58:58 --> URI Class Initialized
INFO - 2023-02-28 03:58:58 --> Router Class Initialized
INFO - 2023-02-28 03:58:58 --> Output Class Initialized
INFO - 2023-02-28 03:58:58 --> Security Class Initialized
DEBUG - 2023-02-28 03:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:58:58 --> Input Class Initialized
INFO - 2023-02-28 03:58:58 --> Language Class Initialized
INFO - 2023-02-28 03:58:58 --> Loader Class Initialized
INFO - 2023-02-28 03:58:58 --> Controller Class Initialized
DEBUG - 2023-02-28 03:58:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:58:58 --> Database Driver Class Initialized
INFO - 2023-02-28 03:58:58 --> Final output sent to browser
DEBUG - 2023-02-28 03:58:58 --> Total execution time: 0.0930
INFO - 2023-02-28 03:59:39 --> Config Class Initialized
INFO - 2023-02-28 03:59:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:59:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:59:39 --> Utf8 Class Initialized
INFO - 2023-02-28 03:59:39 --> URI Class Initialized
INFO - 2023-02-28 03:59:39 --> Router Class Initialized
INFO - 2023-02-28 03:59:39 --> Output Class Initialized
INFO - 2023-02-28 03:59:39 --> Security Class Initialized
DEBUG - 2023-02-28 03:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:59:39 --> Input Class Initialized
INFO - 2023-02-28 03:59:39 --> Language Class Initialized
INFO - 2023-02-28 03:59:39 --> Loader Class Initialized
INFO - 2023-02-28 03:59:39 --> Controller Class Initialized
DEBUG - 2023-02-28 03:59:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:59:39 --> Database Driver Class Initialized
INFO - 2023-02-28 03:59:39 --> Final output sent to browser
DEBUG - 2023-02-28 03:59:39 --> Total execution time: 0.0109
INFO - 2023-02-28 03:59:39 --> Config Class Initialized
INFO - 2023-02-28 03:59:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:59:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:59:39 --> Utf8 Class Initialized
INFO - 2023-02-28 03:59:39 --> URI Class Initialized
INFO - 2023-02-28 03:59:39 --> Router Class Initialized
INFO - 2023-02-28 03:59:39 --> Output Class Initialized
INFO - 2023-02-28 03:59:39 --> Security Class Initialized
DEBUG - 2023-02-28 03:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:59:39 --> Input Class Initialized
INFO - 2023-02-28 03:59:39 --> Language Class Initialized
INFO - 2023-02-28 03:59:39 --> Loader Class Initialized
INFO - 2023-02-28 03:59:39 --> Controller Class Initialized
DEBUG - 2023-02-28 03:59:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:59:39 --> Database Driver Class Initialized
INFO - 2023-02-28 03:59:39 --> Final output sent to browser
DEBUG - 2023-02-28 03:59:39 --> Total execution time: 0.0165
INFO - 2023-02-28 03:59:48 --> Config Class Initialized
INFO - 2023-02-28 03:59:48 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:59:48 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:59:48 --> Utf8 Class Initialized
INFO - 2023-02-28 03:59:48 --> URI Class Initialized
INFO - 2023-02-28 03:59:48 --> Router Class Initialized
INFO - 2023-02-28 03:59:48 --> Output Class Initialized
INFO - 2023-02-28 03:59:48 --> Security Class Initialized
DEBUG - 2023-02-28 03:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:59:48 --> Input Class Initialized
INFO - 2023-02-28 03:59:48 --> Language Class Initialized
INFO - 2023-02-28 03:59:48 --> Loader Class Initialized
INFO - 2023-02-28 03:59:48 --> Controller Class Initialized
DEBUG - 2023-02-28 03:59:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:59:48 --> Database Driver Class Initialized
INFO - 2023-02-28 03:59:48 --> Final output sent to browser
DEBUG - 2023-02-28 03:59:48 --> Total execution time: 0.0113
INFO - 2023-02-28 03:59:48 --> Config Class Initialized
INFO - 2023-02-28 03:59:48 --> Hooks Class Initialized
DEBUG - 2023-02-28 03:59:48 --> UTF-8 Support Enabled
INFO - 2023-02-28 03:59:48 --> Utf8 Class Initialized
INFO - 2023-02-28 03:59:48 --> URI Class Initialized
INFO - 2023-02-28 03:59:48 --> Router Class Initialized
INFO - 2023-02-28 03:59:48 --> Output Class Initialized
INFO - 2023-02-28 03:59:48 --> Security Class Initialized
DEBUG - 2023-02-28 03:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 03:59:48 --> Input Class Initialized
INFO - 2023-02-28 03:59:48 --> Language Class Initialized
INFO - 2023-02-28 03:59:48 --> Loader Class Initialized
INFO - 2023-02-28 03:59:48 --> Controller Class Initialized
DEBUG - 2023-02-28 03:59:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 03:59:48 --> Database Driver Class Initialized
INFO - 2023-02-28 03:59:49 --> Final output sent to browser
DEBUG - 2023-02-28 03:59:49 --> Total execution time: 0.9895
INFO - 2023-02-28 04:00:40 --> Config Class Initialized
INFO - 2023-02-28 04:00:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:00:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:00:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:00:40 --> URI Class Initialized
INFO - 2023-02-28 04:00:40 --> Router Class Initialized
INFO - 2023-02-28 04:00:40 --> Output Class Initialized
INFO - 2023-02-28 04:00:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:00:40 --> Input Class Initialized
INFO - 2023-02-28 04:00:40 --> Language Class Initialized
INFO - 2023-02-28 04:00:40 --> Loader Class Initialized
INFO - 2023-02-28 04:00:40 --> Controller Class Initialized
INFO - 2023-02-28 04:00:40 --> Helper loaded: form_helper
INFO - 2023-02-28 04:00:40 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:00:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:00:40 --> Model "Change_model" initialized
INFO - 2023-02-28 04:00:40 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:00:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:00:40 --> Total execution time: 0.0313
INFO - 2023-02-28 04:00:40 --> Config Class Initialized
INFO - 2023-02-28 04:00:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:00:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:00:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:00:40 --> URI Class Initialized
INFO - 2023-02-28 04:00:40 --> Router Class Initialized
INFO - 2023-02-28 04:00:40 --> Output Class Initialized
INFO - 2023-02-28 04:00:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:00:40 --> Input Class Initialized
INFO - 2023-02-28 04:00:40 --> Language Class Initialized
INFO - 2023-02-28 04:00:40 --> Loader Class Initialized
INFO - 2023-02-28 04:00:40 --> Controller Class Initialized
INFO - 2023-02-28 04:00:40 --> Helper loaded: form_helper
INFO - 2023-02-28 04:00:40 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:00:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:00:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:00:40 --> Total execution time: 0.0422
INFO - 2023-02-28 04:00:40 --> Config Class Initialized
INFO - 2023-02-28 04:00:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:00:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:00:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:00:40 --> URI Class Initialized
INFO - 2023-02-28 04:00:40 --> Router Class Initialized
INFO - 2023-02-28 04:00:40 --> Output Class Initialized
INFO - 2023-02-28 04:00:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:00:40 --> Input Class Initialized
INFO - 2023-02-28 04:00:40 --> Language Class Initialized
INFO - 2023-02-28 04:00:40 --> Loader Class Initialized
INFO - 2023-02-28 04:00:40 --> Controller Class Initialized
INFO - 2023-02-28 04:00:40 --> Helper loaded: form_helper
INFO - 2023-02-28 04:00:40 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:00:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:00:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:00:40 --> Model "Login_model" initialized
INFO - 2023-02-28 04:00:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:00:40 --> Total execution time: 0.0157
INFO - 2023-02-28 04:00:45 --> Config Class Initialized
INFO - 2023-02-28 04:00:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:00:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:00:45 --> Utf8 Class Initialized
INFO - 2023-02-28 04:00:45 --> URI Class Initialized
INFO - 2023-02-28 04:00:45 --> Router Class Initialized
INFO - 2023-02-28 04:00:45 --> Output Class Initialized
INFO - 2023-02-28 04:00:45 --> Security Class Initialized
DEBUG - 2023-02-28 04:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:00:45 --> Input Class Initialized
INFO - 2023-02-28 04:00:45 --> Language Class Initialized
INFO - 2023-02-28 04:00:45 --> Loader Class Initialized
INFO - 2023-02-28 04:00:45 --> Controller Class Initialized
INFO - 2023-02-28 04:00:45 --> Helper loaded: form_helper
INFO - 2023-02-28 04:00:45 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:00:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:00:45 --> Model "Change_model" initialized
INFO - 2023-02-28 04:00:45 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:00:45 --> Final output sent to browser
DEBUG - 2023-02-28 04:00:45 --> Total execution time: 0.0240
INFO - 2023-02-28 04:00:45 --> Config Class Initialized
INFO - 2023-02-28 04:00:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:00:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:00:45 --> Utf8 Class Initialized
INFO - 2023-02-28 04:00:45 --> URI Class Initialized
INFO - 2023-02-28 04:00:45 --> Router Class Initialized
INFO - 2023-02-28 04:00:45 --> Output Class Initialized
INFO - 2023-02-28 04:00:45 --> Security Class Initialized
DEBUG - 2023-02-28 04:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:00:45 --> Input Class Initialized
INFO - 2023-02-28 04:00:45 --> Language Class Initialized
INFO - 2023-02-28 04:00:45 --> Loader Class Initialized
INFO - 2023-02-28 04:00:45 --> Controller Class Initialized
INFO - 2023-02-28 04:00:45 --> Helper loaded: form_helper
INFO - 2023-02-28 04:00:45 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:00:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:00:45 --> Final output sent to browser
DEBUG - 2023-02-28 04:00:45 --> Total execution time: 0.0038
INFO - 2023-02-28 04:00:45 --> Config Class Initialized
INFO - 2023-02-28 04:00:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:00:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:00:45 --> Utf8 Class Initialized
INFO - 2023-02-28 04:00:45 --> URI Class Initialized
INFO - 2023-02-28 04:00:45 --> Router Class Initialized
INFO - 2023-02-28 04:00:45 --> Output Class Initialized
INFO - 2023-02-28 04:00:45 --> Security Class Initialized
DEBUG - 2023-02-28 04:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:00:45 --> Input Class Initialized
INFO - 2023-02-28 04:00:45 --> Language Class Initialized
INFO - 2023-02-28 04:00:45 --> Loader Class Initialized
INFO - 2023-02-28 04:00:45 --> Controller Class Initialized
INFO - 2023-02-28 04:00:45 --> Helper loaded: form_helper
INFO - 2023-02-28 04:00:45 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:00:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:00:45 --> Database Driver Class Initialized
INFO - 2023-02-28 04:00:45 --> Model "Login_model" initialized
INFO - 2023-02-28 04:00:45 --> Final output sent to browser
DEBUG - 2023-02-28 04:00:45 --> Total execution time: 0.0147
INFO - 2023-02-28 04:00:45 --> Config Class Initialized
INFO - 2023-02-28 04:00:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:00:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:00:45 --> Utf8 Class Initialized
INFO - 2023-02-28 04:00:45 --> URI Class Initialized
INFO - 2023-02-28 04:00:45 --> Router Class Initialized
INFO - 2023-02-28 04:00:45 --> Output Class Initialized
INFO - 2023-02-28 04:00:45 --> Security Class Initialized
DEBUG - 2023-02-28 04:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:00:45 --> Input Class Initialized
INFO - 2023-02-28 04:00:45 --> Language Class Initialized
INFO - 2023-02-28 04:00:45 --> Loader Class Initialized
INFO - 2023-02-28 04:00:45 --> Controller Class Initialized
DEBUG - 2023-02-28 04:00:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:00:45 --> Database Driver Class Initialized
INFO - 2023-02-28 04:00:45 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:00:45 --> Final output sent to browser
DEBUG - 2023-02-28 04:00:45 --> Total execution time: 0.0135
INFO - 2023-02-28 04:00:45 --> Config Class Initialized
INFO - 2023-02-28 04:00:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:00:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:00:45 --> Utf8 Class Initialized
INFO - 2023-02-28 04:00:45 --> URI Class Initialized
INFO - 2023-02-28 04:00:45 --> Router Class Initialized
INFO - 2023-02-28 04:00:45 --> Output Class Initialized
INFO - 2023-02-28 04:00:45 --> Security Class Initialized
DEBUG - 2023-02-28 04:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:00:45 --> Input Class Initialized
INFO - 2023-02-28 04:00:45 --> Language Class Initialized
INFO - 2023-02-28 04:00:45 --> Loader Class Initialized
INFO - 2023-02-28 04:00:45 --> Controller Class Initialized
DEBUG - 2023-02-28 04:00:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:00:45 --> Database Driver Class Initialized
INFO - 2023-02-28 04:00:45 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:00:45 --> Final output sent to browser
DEBUG - 2023-02-28 04:00:45 --> Total execution time: 0.0125
INFO - 2023-02-28 04:00:46 --> Config Class Initialized
INFO - 2023-02-28 04:00:46 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:00:46 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:00:46 --> Utf8 Class Initialized
INFO - 2023-02-28 04:00:46 --> URI Class Initialized
INFO - 2023-02-28 04:00:46 --> Router Class Initialized
INFO - 2023-02-28 04:00:46 --> Output Class Initialized
INFO - 2023-02-28 04:00:46 --> Security Class Initialized
DEBUG - 2023-02-28 04:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:00:46 --> Input Class Initialized
INFO - 2023-02-28 04:00:46 --> Language Class Initialized
INFO - 2023-02-28 04:00:46 --> Loader Class Initialized
INFO - 2023-02-28 04:00:46 --> Controller Class Initialized
DEBUG - 2023-02-28 04:00:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:00:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:00:46 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:00:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:00:46 --> Model "Login_model" initialized
INFO - 2023-02-28 04:00:46 --> Final output sent to browser
DEBUG - 2023-02-28 04:00:46 --> Total execution time: 0.0691
INFO - 2023-02-28 04:00:46 --> Config Class Initialized
INFO - 2023-02-28 04:00:46 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:00:46 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:00:46 --> Utf8 Class Initialized
INFO - 2023-02-28 04:00:46 --> URI Class Initialized
INFO - 2023-02-28 04:00:46 --> Router Class Initialized
INFO - 2023-02-28 04:00:46 --> Output Class Initialized
INFO - 2023-02-28 04:00:46 --> Security Class Initialized
DEBUG - 2023-02-28 04:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:00:46 --> Input Class Initialized
INFO - 2023-02-28 04:00:46 --> Language Class Initialized
INFO - 2023-02-28 04:00:46 --> Loader Class Initialized
INFO - 2023-02-28 04:00:46 --> Controller Class Initialized
DEBUG - 2023-02-28 04:00:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:00:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:00:46 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:00:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:00:46 --> Model "Login_model" initialized
INFO - 2023-02-28 04:00:46 --> Final output sent to browser
DEBUG - 2023-02-28 04:00:46 --> Total execution time: 0.0867
INFO - 2023-02-28 04:00:49 --> Config Class Initialized
INFO - 2023-02-28 04:00:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:00:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:00:49 --> Utf8 Class Initialized
INFO - 2023-02-28 04:00:49 --> URI Class Initialized
INFO - 2023-02-28 04:00:49 --> Router Class Initialized
INFO - 2023-02-28 04:00:49 --> Output Class Initialized
INFO - 2023-02-28 04:00:49 --> Security Class Initialized
DEBUG - 2023-02-28 04:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:00:49 --> Input Class Initialized
INFO - 2023-02-28 04:00:49 --> Language Class Initialized
INFO - 2023-02-28 04:00:49 --> Loader Class Initialized
INFO - 2023-02-28 04:00:49 --> Controller Class Initialized
DEBUG - 2023-02-28 04:00:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:00:49 --> Database Driver Class Initialized
INFO - 2023-02-28 04:00:49 --> Database Driver Class Initialized
INFO - 2023-02-28 04:00:49 --> Model "Login_model" initialized
INFO - 2023-02-28 04:00:49 --> Final output sent to browser
DEBUG - 2023-02-28 04:00:49 --> Total execution time: 0.0473
INFO - 2023-02-28 04:00:49 --> Config Class Initialized
INFO - 2023-02-28 04:00:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:00:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:00:49 --> Utf8 Class Initialized
INFO - 2023-02-28 04:00:49 --> URI Class Initialized
INFO - 2023-02-28 04:00:49 --> Router Class Initialized
INFO - 2023-02-28 04:00:49 --> Output Class Initialized
INFO - 2023-02-28 04:00:49 --> Security Class Initialized
DEBUG - 2023-02-28 04:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:00:49 --> Input Class Initialized
INFO - 2023-02-28 04:00:49 --> Language Class Initialized
INFO - 2023-02-28 04:00:49 --> Loader Class Initialized
INFO - 2023-02-28 04:00:49 --> Controller Class Initialized
DEBUG - 2023-02-28 04:00:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:00:49 --> Database Driver Class Initialized
INFO - 2023-02-28 04:00:49 --> Database Driver Class Initialized
INFO - 2023-02-28 04:00:49 --> Model "Login_model" initialized
INFO - 2023-02-28 04:00:49 --> Final output sent to browser
DEBUG - 2023-02-28 04:00:49 --> Total execution time: 0.0599
INFO - 2023-02-28 04:01:27 --> Config Class Initialized
INFO - 2023-02-28 04:01:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:01:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:01:27 --> Utf8 Class Initialized
INFO - 2023-02-28 04:01:27 --> URI Class Initialized
INFO - 2023-02-28 04:01:27 --> Router Class Initialized
INFO - 2023-02-28 04:01:27 --> Output Class Initialized
INFO - 2023-02-28 04:01:27 --> Security Class Initialized
DEBUG - 2023-02-28 04:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:01:27 --> Input Class Initialized
INFO - 2023-02-28 04:01:27 --> Language Class Initialized
INFO - 2023-02-28 04:01:27 --> Loader Class Initialized
INFO - 2023-02-28 04:01:27 --> Controller Class Initialized
DEBUG - 2023-02-28 04:01:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:01:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:01:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:01:27 --> Model "Login_model" initialized
INFO - 2023-02-28 04:01:27 --> Final output sent to browser
DEBUG - 2023-02-28 04:01:27 --> Total execution time: 0.0276
INFO - 2023-02-28 04:01:27 --> Config Class Initialized
INFO - 2023-02-28 04:01:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:01:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:01:27 --> Utf8 Class Initialized
INFO - 2023-02-28 04:01:27 --> URI Class Initialized
INFO - 2023-02-28 04:01:27 --> Router Class Initialized
INFO - 2023-02-28 04:01:27 --> Output Class Initialized
INFO - 2023-02-28 04:01:27 --> Security Class Initialized
DEBUG - 2023-02-28 04:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:01:27 --> Input Class Initialized
INFO - 2023-02-28 04:01:27 --> Language Class Initialized
INFO - 2023-02-28 04:01:27 --> Loader Class Initialized
INFO - 2023-02-28 04:01:27 --> Controller Class Initialized
DEBUG - 2023-02-28 04:01:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:01:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:01:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:01:27 --> Model "Login_model" initialized
INFO - 2023-02-28 04:01:27 --> Final output sent to browser
DEBUG - 2023-02-28 04:01:27 --> Total execution time: 0.0631
INFO - 2023-02-28 04:01:30 --> Config Class Initialized
INFO - 2023-02-28 04:01:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:01:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:01:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:01:30 --> URI Class Initialized
INFO - 2023-02-28 04:01:30 --> Router Class Initialized
INFO - 2023-02-28 04:01:30 --> Output Class Initialized
INFO - 2023-02-28 04:01:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:01:30 --> Input Class Initialized
INFO - 2023-02-28 04:01:30 --> Language Class Initialized
INFO - 2023-02-28 04:01:30 --> Loader Class Initialized
INFO - 2023-02-28 04:01:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:01:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:01:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:01:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:01:30 --> Model "Login_model" initialized
INFO - 2023-02-28 04:01:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:01:30 --> Total execution time: 0.0716
INFO - 2023-02-28 04:01:30 --> Config Class Initialized
INFO - 2023-02-28 04:01:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:01:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:01:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:01:30 --> URI Class Initialized
INFO - 2023-02-28 04:01:30 --> Router Class Initialized
INFO - 2023-02-28 04:01:30 --> Output Class Initialized
INFO - 2023-02-28 04:01:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:01:30 --> Input Class Initialized
INFO - 2023-02-28 04:01:30 --> Language Class Initialized
INFO - 2023-02-28 04:01:30 --> Loader Class Initialized
INFO - 2023-02-28 04:01:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:01:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:01:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:01:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:01:30 --> Model "Login_model" initialized
INFO - 2023-02-28 04:01:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:01:30 --> Total execution time: 0.0239
INFO - 2023-02-28 04:01:57 --> Config Class Initialized
INFO - 2023-02-28 04:01:57 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:01:57 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:01:57 --> Utf8 Class Initialized
INFO - 2023-02-28 04:01:57 --> URI Class Initialized
INFO - 2023-02-28 04:01:57 --> Router Class Initialized
INFO - 2023-02-28 04:01:57 --> Output Class Initialized
INFO - 2023-02-28 04:01:57 --> Security Class Initialized
DEBUG - 2023-02-28 04:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:01:57 --> Input Class Initialized
INFO - 2023-02-28 04:01:57 --> Language Class Initialized
INFO - 2023-02-28 04:01:57 --> Loader Class Initialized
INFO - 2023-02-28 04:01:57 --> Controller Class Initialized
DEBUG - 2023-02-28 04:01:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:01:57 --> Database Driver Class Initialized
INFO - 2023-02-28 04:01:57 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:01:57 --> Final output sent to browser
DEBUG - 2023-02-28 04:01:57 --> Total execution time: 0.0440
INFO - 2023-02-28 04:01:57 --> Config Class Initialized
INFO - 2023-02-28 04:01:57 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:01:57 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:01:57 --> Utf8 Class Initialized
INFO - 2023-02-28 04:01:57 --> URI Class Initialized
INFO - 2023-02-28 04:01:57 --> Router Class Initialized
INFO - 2023-02-28 04:01:57 --> Output Class Initialized
INFO - 2023-02-28 04:01:57 --> Security Class Initialized
DEBUG - 2023-02-28 04:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:01:57 --> Input Class Initialized
INFO - 2023-02-28 04:01:57 --> Language Class Initialized
INFO - 2023-02-28 04:01:57 --> Loader Class Initialized
INFO - 2023-02-28 04:01:57 --> Controller Class Initialized
DEBUG - 2023-02-28 04:01:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:01:57 --> Database Driver Class Initialized
INFO - 2023-02-28 04:01:57 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:01:57 --> Final output sent to browser
DEBUG - 2023-02-28 04:01:57 --> Total execution time: 0.0909
INFO - 2023-02-28 04:01:59 --> Config Class Initialized
INFO - 2023-02-28 04:01:59 --> Config Class Initialized
INFO - 2023-02-28 04:01:59 --> Hooks Class Initialized
INFO - 2023-02-28 04:01:59 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:01:59 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:01:59 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:01:59 --> Utf8 Class Initialized
INFO - 2023-02-28 04:01:59 --> Utf8 Class Initialized
INFO - 2023-02-28 04:01:59 --> URI Class Initialized
INFO - 2023-02-28 04:01:59 --> URI Class Initialized
INFO - 2023-02-28 04:01:59 --> Router Class Initialized
INFO - 2023-02-28 04:01:59 --> Router Class Initialized
INFO - 2023-02-28 04:01:59 --> Output Class Initialized
INFO - 2023-02-28 04:01:59 --> Output Class Initialized
INFO - 2023-02-28 04:01:59 --> Security Class Initialized
INFO - 2023-02-28 04:01:59 --> Security Class Initialized
DEBUG - 2023-02-28 04:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:01:59 --> Input Class Initialized
INFO - 2023-02-28 04:01:59 --> Input Class Initialized
INFO - 2023-02-28 04:01:59 --> Language Class Initialized
INFO - 2023-02-28 04:01:59 --> Language Class Initialized
INFO - 2023-02-28 04:01:59 --> Loader Class Initialized
INFO - 2023-02-28 04:01:59 --> Loader Class Initialized
INFO - 2023-02-28 04:01:59 --> Controller Class Initialized
INFO - 2023-02-28 04:01:59 --> Controller Class Initialized
DEBUG - 2023-02-28 04:01:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:01:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:01:59 --> Final output sent to browser
INFO - 2023-02-28 04:01:59 --> Database Driver Class Initialized
DEBUG - 2023-02-28 04:01:59 --> Total execution time: 0.0208
INFO - 2023-02-28 04:01:59 --> Config Class Initialized
INFO - 2023-02-28 04:01:59 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:01:59 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:01:59 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:01:59 --> Utf8 Class Initialized
INFO - 2023-02-28 04:01:59 --> URI Class Initialized
INFO - 2023-02-28 04:01:59 --> Router Class Initialized
INFO - 2023-02-28 04:01:59 --> Output Class Initialized
INFO - 2023-02-28 04:01:59 --> Security Class Initialized
DEBUG - 2023-02-28 04:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:01:59 --> Input Class Initialized
INFO - 2023-02-28 04:01:59 --> Language Class Initialized
INFO - 2023-02-28 04:01:59 --> Loader Class Initialized
INFO - 2023-02-28 04:01:59 --> Controller Class Initialized
DEBUG - 2023-02-28 04:01:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:01:59 --> Database Driver Class Initialized
INFO - 2023-02-28 04:01:59 --> Final output sent to browser
DEBUG - 2023-02-28 04:01:59 --> Total execution time: 0.0673
INFO - 2023-02-28 04:01:59 --> Config Class Initialized
INFO - 2023-02-28 04:01:59 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:01:59 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:01:59 --> Utf8 Class Initialized
INFO - 2023-02-28 04:01:59 --> URI Class Initialized
INFO - 2023-02-28 04:01:59 --> Router Class Initialized
INFO - 2023-02-28 04:01:59 --> Output Class Initialized
INFO - 2023-02-28 04:01:59 --> Security Class Initialized
DEBUG - 2023-02-28 04:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:01:59 --> Input Class Initialized
INFO - 2023-02-28 04:01:59 --> Language Class Initialized
INFO - 2023-02-28 04:01:59 --> Loader Class Initialized
INFO - 2023-02-28 04:01:59 --> Controller Class Initialized
DEBUG - 2023-02-28 04:01:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:01:59 --> Database Driver Class Initialized
INFO - 2023-02-28 04:01:59 --> Model "Login_model" initialized
INFO - 2023-02-28 04:01:59 --> Database Driver Class Initialized
INFO - 2023-02-28 04:01:59 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:01:59 --> Final output sent to browser
DEBUG - 2023-02-28 04:01:59 --> Total execution time: 0.0193
INFO - 2023-02-28 04:01:59 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:01:59 --> Final output sent to browser
DEBUG - 2023-02-28 04:01:59 --> Total execution time: 0.1101
INFO - 2023-02-28 04:02:04 --> Config Class Initialized
INFO - 2023-02-28 04:02:04 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:02:04 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:02:04 --> Utf8 Class Initialized
INFO - 2023-02-28 04:02:04 --> URI Class Initialized
INFO - 2023-02-28 04:02:04 --> Router Class Initialized
INFO - 2023-02-28 04:02:04 --> Output Class Initialized
INFO - 2023-02-28 04:02:04 --> Security Class Initialized
DEBUG - 2023-02-28 04:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:02:04 --> Input Class Initialized
INFO - 2023-02-28 04:02:04 --> Language Class Initialized
INFO - 2023-02-28 04:02:04 --> Loader Class Initialized
INFO - 2023-02-28 04:02:04 --> Controller Class Initialized
DEBUG - 2023-02-28 04:02:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:02:04 --> Database Driver Class Initialized
INFO - 2023-02-28 04:02:04 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:02:04 --> Final output sent to browser
DEBUG - 2023-02-28 04:02:04 --> Total execution time: 0.0505
INFO - 2023-02-28 04:02:04 --> Config Class Initialized
INFO - 2023-02-28 04:02:04 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:02:04 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:02:04 --> Utf8 Class Initialized
INFO - 2023-02-28 04:02:04 --> URI Class Initialized
INFO - 2023-02-28 04:02:04 --> Router Class Initialized
INFO - 2023-02-28 04:02:04 --> Output Class Initialized
INFO - 2023-02-28 04:02:04 --> Security Class Initialized
DEBUG - 2023-02-28 04:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:02:04 --> Input Class Initialized
INFO - 2023-02-28 04:02:04 --> Language Class Initialized
INFO - 2023-02-28 04:02:04 --> Loader Class Initialized
INFO - 2023-02-28 04:02:04 --> Controller Class Initialized
DEBUG - 2023-02-28 04:02:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:02:04 --> Database Driver Class Initialized
INFO - 2023-02-28 04:02:04 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:02:04 --> Final output sent to browser
DEBUG - 2023-02-28 04:02:04 --> Total execution time: 0.0549
INFO - 2023-02-28 04:03:10 --> Config Class Initialized
INFO - 2023-02-28 04:03:10 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:10 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:10 --> URI Class Initialized
INFO - 2023-02-28 04:03:10 --> Router Class Initialized
INFO - 2023-02-28 04:03:10 --> Output Class Initialized
INFO - 2023-02-28 04:03:10 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:10 --> Input Class Initialized
INFO - 2023-02-28 04:03:10 --> Language Class Initialized
INFO - 2023-02-28 04:03:10 --> Loader Class Initialized
INFO - 2023-02-28 04:03:10 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:10 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:10 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:10 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:10 --> Total execution time: 0.0192
INFO - 2023-02-28 04:03:10 --> Config Class Initialized
INFO - 2023-02-28 04:03:10 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:10 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:10 --> URI Class Initialized
INFO - 2023-02-28 04:03:10 --> Router Class Initialized
INFO - 2023-02-28 04:03:10 --> Output Class Initialized
INFO - 2023-02-28 04:03:10 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:10 --> Input Class Initialized
INFO - 2023-02-28 04:03:10 --> Language Class Initialized
INFO - 2023-02-28 04:03:10 --> Loader Class Initialized
INFO - 2023-02-28 04:03:10 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:10 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:10 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:10 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:10 --> Total execution time: 0.0129
INFO - 2023-02-28 04:03:13 --> Config Class Initialized
INFO - 2023-02-28 04:03:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:13 --> URI Class Initialized
INFO - 2023-02-28 04:03:13 --> Router Class Initialized
INFO - 2023-02-28 04:03:13 --> Output Class Initialized
INFO - 2023-02-28 04:03:13 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:13 --> Input Class Initialized
INFO - 2023-02-28 04:03:13 --> Language Class Initialized
INFO - 2023-02-28 04:03:13 --> Loader Class Initialized
INFO - 2023-02-28 04:03:13 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:13 --> Total execution time: 0.0482
INFO - 2023-02-28 04:03:13 --> Config Class Initialized
INFO - 2023-02-28 04:03:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:13 --> URI Class Initialized
INFO - 2023-02-28 04:03:13 --> Router Class Initialized
INFO - 2023-02-28 04:03:13 --> Output Class Initialized
INFO - 2023-02-28 04:03:13 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:13 --> Input Class Initialized
INFO - 2023-02-28 04:03:13 --> Language Class Initialized
INFO - 2023-02-28 04:03:13 --> Loader Class Initialized
INFO - 2023-02-28 04:03:13 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:13 --> Total execution time: 0.0445
INFO - 2023-02-28 04:03:19 --> Config Class Initialized
INFO - 2023-02-28 04:03:19 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:19 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:19 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:19 --> URI Class Initialized
INFO - 2023-02-28 04:03:19 --> Router Class Initialized
INFO - 2023-02-28 04:03:19 --> Output Class Initialized
INFO - 2023-02-28 04:03:19 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:19 --> Input Class Initialized
INFO - 2023-02-28 04:03:19 --> Language Class Initialized
INFO - 2023-02-28 04:03:19 --> Loader Class Initialized
INFO - 2023-02-28 04:03:19 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:19 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:19 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:19 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:19 --> Total execution time: 0.0503
INFO - 2023-02-28 04:03:19 --> Config Class Initialized
INFO - 2023-02-28 04:03:19 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:19 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:19 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:19 --> URI Class Initialized
INFO - 2023-02-28 04:03:19 --> Router Class Initialized
INFO - 2023-02-28 04:03:19 --> Output Class Initialized
INFO - 2023-02-28 04:03:19 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:19 --> Input Class Initialized
INFO - 2023-02-28 04:03:19 --> Language Class Initialized
INFO - 2023-02-28 04:03:19 --> Loader Class Initialized
INFO - 2023-02-28 04:03:19 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:19 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:19 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:19 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:19 --> Total execution time: 0.0428
INFO - 2023-02-28 04:03:30 --> Config Class Initialized
INFO - 2023-02-28 04:03:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:30 --> URI Class Initialized
INFO - 2023-02-28 04:03:30 --> Router Class Initialized
INFO - 2023-02-28 04:03:30 --> Output Class Initialized
INFO - 2023-02-28 04:03:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:30 --> Input Class Initialized
INFO - 2023-02-28 04:03:30 --> Language Class Initialized
INFO - 2023-02-28 04:03:30 --> Loader Class Initialized
INFO - 2023-02-28 04:03:30 --> Controller Class Initialized
INFO - 2023-02-28 04:03:30 --> Helper loaded: form_helper
INFO - 2023-02-28 04:03:30 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:03:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:30 --> Model "Change_model" initialized
INFO - 2023-02-28 04:03:30 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:03:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:30 --> Total execution time: 0.0276
INFO - 2023-02-28 04:03:30 --> Config Class Initialized
INFO - 2023-02-28 04:03:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:30 --> URI Class Initialized
INFO - 2023-02-28 04:03:30 --> Router Class Initialized
INFO - 2023-02-28 04:03:30 --> Output Class Initialized
INFO - 2023-02-28 04:03:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:30 --> Input Class Initialized
INFO - 2023-02-28 04:03:30 --> Language Class Initialized
INFO - 2023-02-28 04:03:30 --> Loader Class Initialized
INFO - 2023-02-28 04:03:30 --> Controller Class Initialized
INFO - 2023-02-28 04:03:30 --> Helper loaded: form_helper
INFO - 2023-02-28 04:03:30 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:03:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:30 --> Total execution time: 0.0028
INFO - 2023-02-28 04:03:30 --> Config Class Initialized
INFO - 2023-02-28 04:03:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:30 --> URI Class Initialized
INFO - 2023-02-28 04:03:30 --> Router Class Initialized
INFO - 2023-02-28 04:03:30 --> Output Class Initialized
INFO - 2023-02-28 04:03:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:30 --> Input Class Initialized
INFO - 2023-02-28 04:03:30 --> Language Class Initialized
INFO - 2023-02-28 04:03:30 --> Loader Class Initialized
INFO - 2023-02-28 04:03:30 --> Controller Class Initialized
INFO - 2023-02-28 04:03:30 --> Helper loaded: form_helper
INFO - 2023-02-28 04:03:30 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:03:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:30 --> Model "Login_model" initialized
INFO - 2023-02-28 04:03:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:30 --> Total execution time: 0.0161
INFO - 2023-02-28 04:03:30 --> Config Class Initialized
INFO - 2023-02-28 04:03:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:30 --> URI Class Initialized
INFO - 2023-02-28 04:03:30 --> Router Class Initialized
INFO - 2023-02-28 04:03:30 --> Output Class Initialized
INFO - 2023-02-28 04:03:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:30 --> Input Class Initialized
INFO - 2023-02-28 04:03:30 --> Language Class Initialized
INFO - 2023-02-28 04:03:30 --> Loader Class Initialized
INFO - 2023-02-28 04:03:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:30 --> Total execution time: 0.0146
INFO - 2023-02-28 04:03:30 --> Config Class Initialized
INFO - 2023-02-28 04:03:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:30 --> URI Class Initialized
INFO - 2023-02-28 04:03:30 --> Router Class Initialized
INFO - 2023-02-28 04:03:30 --> Output Class Initialized
INFO - 2023-02-28 04:03:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:30 --> Input Class Initialized
INFO - 2023-02-28 04:03:30 --> Language Class Initialized
INFO - 2023-02-28 04:03:30 --> Loader Class Initialized
INFO - 2023-02-28 04:03:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:30 --> Total execution time: 0.0147
INFO - 2023-02-28 04:03:30 --> Config Class Initialized
INFO - 2023-02-28 04:03:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:30 --> URI Class Initialized
INFO - 2023-02-28 04:03:30 --> Router Class Initialized
INFO - 2023-02-28 04:03:30 --> Output Class Initialized
INFO - 2023-02-28 04:03:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:30 --> Input Class Initialized
INFO - 2023-02-28 04:03:30 --> Language Class Initialized
INFO - 2023-02-28 04:03:30 --> Loader Class Initialized
INFO - 2023-02-28 04:03:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:30 --> Model "Login_model" initialized
INFO - 2023-02-28 04:03:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:30 --> Total execution time: 0.0838
INFO - 2023-02-28 04:03:30 --> Config Class Initialized
INFO - 2023-02-28 04:03:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:30 --> URI Class Initialized
INFO - 2023-02-28 04:03:30 --> Router Class Initialized
INFO - 2023-02-28 04:03:30 --> Output Class Initialized
INFO - 2023-02-28 04:03:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:30 --> Input Class Initialized
INFO - 2023-02-28 04:03:30 --> Language Class Initialized
INFO - 2023-02-28 04:03:30 --> Loader Class Initialized
INFO - 2023-02-28 04:03:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:30 --> Model "Login_model" initialized
INFO - 2023-02-28 04:03:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:30 --> Total execution time: 0.1169
INFO - 2023-02-28 04:03:35 --> Config Class Initialized
INFO - 2023-02-28 04:03:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:35 --> URI Class Initialized
INFO - 2023-02-28 04:03:35 --> Router Class Initialized
INFO - 2023-02-28 04:03:35 --> Output Class Initialized
INFO - 2023-02-28 04:03:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:35 --> Input Class Initialized
INFO - 2023-02-28 04:03:35 --> Language Class Initialized
INFO - 2023-02-28 04:03:35 --> Loader Class Initialized
INFO - 2023-02-28 04:03:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:35 --> Total execution time: 0.0480
INFO - 2023-02-28 04:03:35 --> Config Class Initialized
INFO - 2023-02-28 04:03:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:35 --> URI Class Initialized
INFO - 2023-02-28 04:03:35 --> Router Class Initialized
INFO - 2023-02-28 04:03:35 --> Output Class Initialized
INFO - 2023-02-28 04:03:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:35 --> Input Class Initialized
INFO - 2023-02-28 04:03:35 --> Language Class Initialized
INFO - 2023-02-28 04:03:35 --> Loader Class Initialized
INFO - 2023-02-28 04:03:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:35 --> Total execution time: 0.0457
INFO - 2023-02-28 04:03:40 --> Config Class Initialized
INFO - 2023-02-28 04:03:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:40 --> URI Class Initialized
INFO - 2023-02-28 04:03:40 --> Router Class Initialized
INFO - 2023-02-28 04:03:40 --> Output Class Initialized
INFO - 2023-02-28 04:03:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:40 --> Input Class Initialized
INFO - 2023-02-28 04:03:40 --> Language Class Initialized
INFO - 2023-02-28 04:03:40 --> Loader Class Initialized
INFO - 2023-02-28 04:03:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:40 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:40 --> Total execution time: 0.0544
INFO - 2023-02-28 04:03:40 --> Config Class Initialized
INFO - 2023-02-28 04:03:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:40 --> URI Class Initialized
INFO - 2023-02-28 04:03:40 --> Router Class Initialized
INFO - 2023-02-28 04:03:40 --> Output Class Initialized
INFO - 2023-02-28 04:03:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:40 --> Input Class Initialized
INFO - 2023-02-28 04:03:40 --> Language Class Initialized
INFO - 2023-02-28 04:03:40 --> Loader Class Initialized
INFO - 2023-02-28 04:03:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:40 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:40 --> Total execution time: 0.0886
INFO - 2023-02-28 04:03:43 --> Config Class Initialized
INFO - 2023-02-28 04:03:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:43 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:43 --> URI Class Initialized
INFO - 2023-02-28 04:03:43 --> Router Class Initialized
INFO - 2023-02-28 04:03:43 --> Output Class Initialized
INFO - 2023-02-28 04:03:43 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:43 --> Input Class Initialized
INFO - 2023-02-28 04:03:43 --> Language Class Initialized
INFO - 2023-02-28 04:03:43 --> Loader Class Initialized
INFO - 2023-02-28 04:03:43 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:43 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:43 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:43 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:43 --> Total execution time: 0.0518
INFO - 2023-02-28 04:03:43 --> Config Class Initialized
INFO - 2023-02-28 04:03:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:43 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:43 --> URI Class Initialized
INFO - 2023-02-28 04:03:43 --> Router Class Initialized
INFO - 2023-02-28 04:03:43 --> Output Class Initialized
INFO - 2023-02-28 04:03:43 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:43 --> Input Class Initialized
INFO - 2023-02-28 04:03:43 --> Language Class Initialized
INFO - 2023-02-28 04:03:43 --> Loader Class Initialized
INFO - 2023-02-28 04:03:43 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:43 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:43 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:43 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:43 --> Total execution time: 0.0931
INFO - 2023-02-28 04:03:45 --> Config Class Initialized
INFO - 2023-02-28 04:03:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:45 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:45 --> URI Class Initialized
INFO - 2023-02-28 04:03:45 --> Router Class Initialized
INFO - 2023-02-28 04:03:45 --> Output Class Initialized
INFO - 2023-02-28 04:03:45 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:45 --> Input Class Initialized
INFO - 2023-02-28 04:03:45 --> Language Class Initialized
INFO - 2023-02-28 04:03:45 --> Loader Class Initialized
INFO - 2023-02-28 04:03:45 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:45 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:45 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:45 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:45 --> Total execution time: 0.0504
INFO - 2023-02-28 04:03:45 --> Config Class Initialized
INFO - 2023-02-28 04:03:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:45 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:45 --> URI Class Initialized
INFO - 2023-02-28 04:03:45 --> Router Class Initialized
INFO - 2023-02-28 04:03:45 --> Output Class Initialized
INFO - 2023-02-28 04:03:45 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:45 --> Input Class Initialized
INFO - 2023-02-28 04:03:45 --> Language Class Initialized
INFO - 2023-02-28 04:03:45 --> Loader Class Initialized
INFO - 2023-02-28 04:03:45 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:45 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:45 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:45 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:45 --> Total execution time: 0.0417
INFO - 2023-02-28 04:03:49 --> Config Class Initialized
INFO - 2023-02-28 04:03:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:49 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:49 --> URI Class Initialized
INFO - 2023-02-28 04:03:49 --> Router Class Initialized
INFO - 2023-02-28 04:03:49 --> Output Class Initialized
INFO - 2023-02-28 04:03:49 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:49 --> Input Class Initialized
INFO - 2023-02-28 04:03:49 --> Language Class Initialized
INFO - 2023-02-28 04:03:49 --> Loader Class Initialized
INFO - 2023-02-28 04:03:49 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:49 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:49 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:50 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:50 --> Total execution time: 0.1596
INFO - 2023-02-28 04:03:50 --> Config Class Initialized
INFO - 2023-02-28 04:03:50 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:50 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:50 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:50 --> URI Class Initialized
INFO - 2023-02-28 04:03:50 --> Router Class Initialized
INFO - 2023-02-28 04:03:50 --> Output Class Initialized
INFO - 2023-02-28 04:03:50 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:50 --> Input Class Initialized
INFO - 2023-02-28 04:03:50 --> Language Class Initialized
INFO - 2023-02-28 04:03:50 --> Loader Class Initialized
INFO - 2023-02-28 04:03:50 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:50 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:50 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:50 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:50 --> Total execution time: 0.2067
INFO - 2023-02-28 04:03:57 --> Config Class Initialized
INFO - 2023-02-28 04:03:57 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:57 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:57 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:57 --> URI Class Initialized
INFO - 2023-02-28 04:03:57 --> Router Class Initialized
INFO - 2023-02-28 04:03:57 --> Output Class Initialized
INFO - 2023-02-28 04:03:57 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:57 --> Input Class Initialized
INFO - 2023-02-28 04:03:57 --> Language Class Initialized
INFO - 2023-02-28 04:03:57 --> Loader Class Initialized
INFO - 2023-02-28 04:03:57 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:57 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:57 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:57 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:57 --> Model "Login_model" initialized
INFO - 2023-02-28 04:03:57 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:57 --> Total execution time: 0.0437
INFO - 2023-02-28 04:03:57 --> Config Class Initialized
INFO - 2023-02-28 04:03:57 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:03:57 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:03:57 --> Utf8 Class Initialized
INFO - 2023-02-28 04:03:57 --> URI Class Initialized
INFO - 2023-02-28 04:03:57 --> Router Class Initialized
INFO - 2023-02-28 04:03:57 --> Output Class Initialized
INFO - 2023-02-28 04:03:57 --> Security Class Initialized
DEBUG - 2023-02-28 04:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:03:57 --> Input Class Initialized
INFO - 2023-02-28 04:03:57 --> Language Class Initialized
INFO - 2023-02-28 04:03:57 --> Loader Class Initialized
INFO - 2023-02-28 04:03:57 --> Controller Class Initialized
DEBUG - 2023-02-28 04:03:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:03:57 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:57 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:03:57 --> Database Driver Class Initialized
INFO - 2023-02-28 04:03:57 --> Model "Login_model" initialized
INFO - 2023-02-28 04:03:57 --> Final output sent to browser
DEBUG - 2023-02-28 04:03:57 --> Total execution time: 0.0404
INFO - 2023-02-28 04:04:07 --> Config Class Initialized
INFO - 2023-02-28 04:04:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:04:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:04:07 --> Utf8 Class Initialized
INFO - 2023-02-28 04:04:07 --> URI Class Initialized
INFO - 2023-02-28 04:04:07 --> Router Class Initialized
INFO - 2023-02-28 04:04:07 --> Output Class Initialized
INFO - 2023-02-28 04:04:07 --> Security Class Initialized
DEBUG - 2023-02-28 04:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:04:07 --> Input Class Initialized
INFO - 2023-02-28 04:04:07 --> Language Class Initialized
INFO - 2023-02-28 04:04:07 --> Loader Class Initialized
INFO - 2023-02-28 04:04:07 --> Controller Class Initialized
DEBUG - 2023-02-28 04:04:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:04:07 --> Final output sent to browser
DEBUG - 2023-02-28 04:04:07 --> Total execution time: 0.0038
INFO - 2023-02-28 04:04:07 --> Config Class Initialized
INFO - 2023-02-28 04:04:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:04:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:04:07 --> Utf8 Class Initialized
INFO - 2023-02-28 04:04:07 --> URI Class Initialized
INFO - 2023-02-28 04:04:07 --> Router Class Initialized
INFO - 2023-02-28 04:04:07 --> Output Class Initialized
INFO - 2023-02-28 04:04:07 --> Security Class Initialized
DEBUG - 2023-02-28 04:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:04:07 --> Input Class Initialized
INFO - 2023-02-28 04:04:07 --> Language Class Initialized
INFO - 2023-02-28 04:04:07 --> Loader Class Initialized
INFO - 2023-02-28 04:04:07 --> Controller Class Initialized
DEBUG - 2023-02-28 04:04:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:04:07 --> Database Driver Class Initialized
INFO - 2023-02-28 04:04:07 --> Model "Login_model" initialized
INFO - 2023-02-28 04:04:07 --> Database Driver Class Initialized
INFO - 2023-02-28 04:04:07 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:04:07 --> Query error:  - Invalid query: 
INFO - 2023-02-28 04:04:07 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:04:08 --> Config Class Initialized
INFO - 2023-02-28 04:04:08 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:04:08 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:04:08 --> Utf8 Class Initialized
INFO - 2023-02-28 04:04:08 --> URI Class Initialized
INFO - 2023-02-28 04:04:08 --> Router Class Initialized
INFO - 2023-02-28 04:04:08 --> Output Class Initialized
INFO - 2023-02-28 04:04:08 --> Security Class Initialized
DEBUG - 2023-02-28 04:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:04:08 --> Input Class Initialized
INFO - 2023-02-28 04:04:08 --> Language Class Initialized
INFO - 2023-02-28 04:04:08 --> Loader Class Initialized
INFO - 2023-02-28 04:04:08 --> Controller Class Initialized
DEBUG - 2023-02-28 04:04:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:04:08 --> Database Driver Class Initialized
INFO - 2023-02-28 04:04:08 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:04:08 --> Database Driver Class Initialized
INFO - 2023-02-28 04:04:08 --> Model "Login_model" initialized
INFO - 2023-02-28 04:04:08 --> Final output sent to browser
DEBUG - 2023-02-28 04:04:08 --> Total execution time: 0.0409
INFO - 2023-02-28 04:04:08 --> Config Class Initialized
INFO - 2023-02-28 04:04:08 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:04:08 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:04:08 --> Utf8 Class Initialized
INFO - 2023-02-28 04:04:08 --> URI Class Initialized
INFO - 2023-02-28 04:04:08 --> Router Class Initialized
INFO - 2023-02-28 04:04:08 --> Output Class Initialized
INFO - 2023-02-28 04:04:08 --> Security Class Initialized
DEBUG - 2023-02-28 04:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:04:08 --> Input Class Initialized
INFO - 2023-02-28 04:04:08 --> Language Class Initialized
INFO - 2023-02-28 04:04:08 --> Loader Class Initialized
INFO - 2023-02-28 04:04:08 --> Controller Class Initialized
DEBUG - 2023-02-28 04:04:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:04:08 --> Database Driver Class Initialized
INFO - 2023-02-28 04:04:08 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:04:08 --> Database Driver Class Initialized
INFO - 2023-02-28 04:04:08 --> Model "Login_model" initialized
INFO - 2023-02-28 04:04:08 --> Final output sent to browser
DEBUG - 2023-02-28 04:04:08 --> Total execution time: 0.0390
INFO - 2023-02-28 04:04:10 --> Config Class Initialized
INFO - 2023-02-28 04:04:10 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:04:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:04:10 --> Utf8 Class Initialized
INFO - 2023-02-28 04:04:10 --> URI Class Initialized
INFO - 2023-02-28 04:04:10 --> Router Class Initialized
INFO - 2023-02-28 04:04:10 --> Output Class Initialized
INFO - 2023-02-28 04:04:10 --> Security Class Initialized
DEBUG - 2023-02-28 04:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:04:10 --> Input Class Initialized
INFO - 2023-02-28 04:04:10 --> Language Class Initialized
INFO - 2023-02-28 04:04:10 --> Loader Class Initialized
INFO - 2023-02-28 04:04:10 --> Controller Class Initialized
DEBUG - 2023-02-28 04:04:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:04:10 --> Database Driver Class Initialized
INFO - 2023-02-28 04:04:10 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:04:10 --> Final output sent to browser
DEBUG - 2023-02-28 04:04:10 --> Total execution time: 0.0579
INFO - 2023-02-28 04:04:10 --> Config Class Initialized
INFO - 2023-02-28 04:04:10 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:04:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:04:10 --> Utf8 Class Initialized
INFO - 2023-02-28 04:04:10 --> URI Class Initialized
INFO - 2023-02-28 04:04:10 --> Router Class Initialized
INFO - 2023-02-28 04:04:10 --> Output Class Initialized
INFO - 2023-02-28 04:04:10 --> Security Class Initialized
DEBUG - 2023-02-28 04:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:04:10 --> Input Class Initialized
INFO - 2023-02-28 04:04:10 --> Language Class Initialized
INFO - 2023-02-28 04:04:10 --> Loader Class Initialized
INFO - 2023-02-28 04:04:10 --> Controller Class Initialized
DEBUG - 2023-02-28 04:04:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:04:10 --> Database Driver Class Initialized
INFO - 2023-02-28 04:04:10 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:04:10 --> Final output sent to browser
DEBUG - 2023-02-28 04:04:10 --> Total execution time: 0.0552
INFO - 2023-02-28 04:04:13 --> Config Class Initialized
INFO - 2023-02-28 04:04:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:04:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:04:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:04:13 --> URI Class Initialized
INFO - 2023-02-28 04:04:13 --> Router Class Initialized
INFO - 2023-02-28 04:04:13 --> Output Class Initialized
INFO - 2023-02-28 04:04:13 --> Security Class Initialized
DEBUG - 2023-02-28 04:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:04:13 --> Input Class Initialized
INFO - 2023-02-28 04:04:13 --> Language Class Initialized
INFO - 2023-02-28 04:04:13 --> Loader Class Initialized
INFO - 2023-02-28 04:04:13 --> Controller Class Initialized
DEBUG - 2023-02-28 04:04:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:04:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:04:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:04:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:04:13 --> Total execution time: 0.0175
INFO - 2023-02-28 04:04:13 --> Config Class Initialized
INFO - 2023-02-28 04:04:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:04:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:04:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:04:13 --> URI Class Initialized
INFO - 2023-02-28 04:04:13 --> Router Class Initialized
INFO - 2023-02-28 04:04:13 --> Output Class Initialized
INFO - 2023-02-28 04:04:13 --> Security Class Initialized
DEBUG - 2023-02-28 04:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:04:13 --> Input Class Initialized
INFO - 2023-02-28 04:04:13 --> Language Class Initialized
INFO - 2023-02-28 04:04:13 --> Loader Class Initialized
INFO - 2023-02-28 04:04:13 --> Controller Class Initialized
DEBUG - 2023-02-28 04:04:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:04:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:04:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:04:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:04:13 --> Total execution time: 0.0343
INFO - 2023-02-28 04:26:39 --> Config Class Initialized
INFO - 2023-02-28 04:26:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:39 --> URI Class Initialized
INFO - 2023-02-28 04:26:39 --> Router Class Initialized
INFO - 2023-02-28 04:26:39 --> Output Class Initialized
INFO - 2023-02-28 04:26:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:39 --> Input Class Initialized
INFO - 2023-02-28 04:26:39 --> Language Class Initialized
INFO - 2023-02-28 04:26:39 --> Loader Class Initialized
INFO - 2023-02-28 04:26:39 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:39 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:40 --> Model "Login_model" initialized
INFO - 2023-02-28 04:26:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:40 --> Total execution time: 0.1306
INFO - 2023-02-28 04:26:40 --> Config Class Initialized
INFO - 2023-02-28 04:26:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:40 --> URI Class Initialized
INFO - 2023-02-28 04:26:40 --> Router Class Initialized
INFO - 2023-02-28 04:26:40 --> Output Class Initialized
INFO - 2023-02-28 04:26:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:40 --> Input Class Initialized
INFO - 2023-02-28 04:26:40 --> Language Class Initialized
INFO - 2023-02-28 04:26:40 --> Loader Class Initialized
INFO - 2023-02-28 04:26:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:40 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:40 --> Model "Login_model" initialized
INFO - 2023-02-28 04:26:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:40 --> Total execution time: 0.0396
INFO - 2023-02-28 04:26:44 --> Config Class Initialized
INFO - 2023-02-28 04:26:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:44 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:44 --> URI Class Initialized
INFO - 2023-02-28 04:26:44 --> Router Class Initialized
INFO - 2023-02-28 04:26:44 --> Output Class Initialized
INFO - 2023-02-28 04:26:44 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:44 --> Input Class Initialized
INFO - 2023-02-28 04:26:44 --> Language Class Initialized
INFO - 2023-02-28 04:26:44 --> Loader Class Initialized
INFO - 2023-02-28 04:26:44 --> Controller Class Initialized
INFO - 2023-02-28 04:26:44 --> Helper loaded: form_helper
INFO - 2023-02-28 04:26:44 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:44 --> Model "Change_model" initialized
INFO - 2023-02-28 04:26:44 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:26:44 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:44 --> Total execution time: 0.0278
INFO - 2023-02-28 04:26:44 --> Config Class Initialized
INFO - 2023-02-28 04:26:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:44 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:44 --> URI Class Initialized
INFO - 2023-02-28 04:26:44 --> Router Class Initialized
INFO - 2023-02-28 04:26:44 --> Output Class Initialized
INFO - 2023-02-28 04:26:44 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:44 --> Input Class Initialized
INFO - 2023-02-28 04:26:44 --> Language Class Initialized
INFO - 2023-02-28 04:26:44 --> Loader Class Initialized
INFO - 2023-02-28 04:26:44 --> Controller Class Initialized
INFO - 2023-02-28 04:26:44 --> Helper loaded: form_helper
INFO - 2023-02-28 04:26:44 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:44 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:44 --> Total execution time: 0.0019
INFO - 2023-02-28 04:26:44 --> Config Class Initialized
INFO - 2023-02-28 04:26:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:44 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:44 --> URI Class Initialized
INFO - 2023-02-28 04:26:44 --> Router Class Initialized
INFO - 2023-02-28 04:26:44 --> Output Class Initialized
INFO - 2023-02-28 04:26:44 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:44 --> Input Class Initialized
INFO - 2023-02-28 04:26:44 --> Language Class Initialized
INFO - 2023-02-28 04:26:44 --> Loader Class Initialized
INFO - 2023-02-28 04:26:44 --> Controller Class Initialized
INFO - 2023-02-28 04:26:44 --> Helper loaded: form_helper
INFO - 2023-02-28 04:26:44 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:44 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:44 --> Model "Login_model" initialized
INFO - 2023-02-28 04:26:44 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:44 --> Total execution time: 0.0158
INFO - 2023-02-28 04:26:44 --> Config Class Initialized
INFO - 2023-02-28 04:26:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:44 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:44 --> URI Class Initialized
INFO - 2023-02-28 04:26:44 --> Router Class Initialized
INFO - 2023-02-28 04:26:44 --> Output Class Initialized
INFO - 2023-02-28 04:26:44 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:44 --> Input Class Initialized
INFO - 2023-02-28 04:26:44 --> Language Class Initialized
INFO - 2023-02-28 04:26:44 --> Loader Class Initialized
INFO - 2023-02-28 04:26:44 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:44 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:44 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:44 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:44 --> Total execution time: 0.0134
INFO - 2023-02-28 04:26:44 --> Config Class Initialized
INFO - 2023-02-28 04:26:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:44 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:44 --> URI Class Initialized
INFO - 2023-02-28 04:26:44 --> Router Class Initialized
INFO - 2023-02-28 04:26:44 --> Output Class Initialized
INFO - 2023-02-28 04:26:44 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:44 --> Input Class Initialized
INFO - 2023-02-28 04:26:44 --> Language Class Initialized
INFO - 2023-02-28 04:26:44 --> Loader Class Initialized
INFO - 2023-02-28 04:26:44 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:44 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:44 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:44 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:44 --> Total execution time: 0.0126
INFO - 2023-02-28 04:26:44 --> Config Class Initialized
INFO - 2023-02-28 04:26:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:44 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:44 --> URI Class Initialized
INFO - 2023-02-28 04:26:44 --> Router Class Initialized
INFO - 2023-02-28 04:26:44 --> Output Class Initialized
INFO - 2023-02-28 04:26:44 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:44 --> Input Class Initialized
INFO - 2023-02-28 04:26:44 --> Language Class Initialized
INFO - 2023-02-28 04:26:44 --> Loader Class Initialized
INFO - 2023-02-28 04:26:44 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:44 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:44 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:44 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:44 --> Model "Login_model" initialized
INFO - 2023-02-28 04:26:44 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:44 --> Total execution time: 0.0972
INFO - 2023-02-28 04:26:44 --> Config Class Initialized
INFO - 2023-02-28 04:26:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:44 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:44 --> URI Class Initialized
INFO - 2023-02-28 04:26:44 --> Router Class Initialized
INFO - 2023-02-28 04:26:44 --> Output Class Initialized
INFO - 2023-02-28 04:26:44 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:44 --> Input Class Initialized
INFO - 2023-02-28 04:26:44 --> Language Class Initialized
INFO - 2023-02-28 04:26:44 --> Loader Class Initialized
INFO - 2023-02-28 04:26:44 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:44 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:44 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:44 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:44 --> Model "Login_model" initialized
INFO - 2023-02-28 04:26:44 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:44 --> Total execution time: 0.0455
INFO - 2023-02-28 04:26:48 --> Config Class Initialized
INFO - 2023-02-28 04:26:48 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:48 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:48 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:48 --> URI Class Initialized
INFO - 2023-02-28 04:26:48 --> Router Class Initialized
INFO - 2023-02-28 04:26:48 --> Output Class Initialized
INFO - 2023-02-28 04:26:48 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:48 --> Input Class Initialized
INFO - 2023-02-28 04:26:48 --> Language Class Initialized
INFO - 2023-02-28 04:26:48 --> Loader Class Initialized
INFO - 2023-02-28 04:26:48 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:48 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:48 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:48 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:48 --> Total execution time: 0.0887
INFO - 2023-02-28 04:26:48 --> Config Class Initialized
INFO - 2023-02-28 04:26:48 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:48 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:48 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:48 --> URI Class Initialized
INFO - 2023-02-28 04:26:48 --> Router Class Initialized
INFO - 2023-02-28 04:26:48 --> Output Class Initialized
INFO - 2023-02-28 04:26:48 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:48 --> Input Class Initialized
INFO - 2023-02-28 04:26:48 --> Language Class Initialized
INFO - 2023-02-28 04:26:48 --> Loader Class Initialized
INFO - 2023-02-28 04:26:48 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:48 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:48 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:48 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:48 --> Total execution time: 0.0435
INFO - 2023-02-28 04:26:53 --> Config Class Initialized
INFO - 2023-02-28 04:26:53 --> Config Class Initialized
INFO - 2023-02-28 04:26:53 --> Hooks Class Initialized
INFO - 2023-02-28 04:26:53 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:53 --> Utf8 Class Initialized
DEBUG - 2023-02-28 04:26:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:53 --> URI Class Initialized
INFO - 2023-02-28 04:26:53 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:53 --> URI Class Initialized
INFO - 2023-02-28 04:26:53 --> Router Class Initialized
INFO - 2023-02-28 04:26:53 --> Router Class Initialized
INFO - 2023-02-28 04:26:53 --> Output Class Initialized
INFO - 2023-02-28 04:26:53 --> Output Class Initialized
INFO - 2023-02-28 04:26:53 --> Security Class Initialized
INFO - 2023-02-28 04:26:53 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:53 --> Input Class Initialized
INFO - 2023-02-28 04:26:53 --> Input Class Initialized
INFO - 2023-02-28 04:26:53 --> Language Class Initialized
INFO - 2023-02-28 04:26:53 --> Language Class Initialized
INFO - 2023-02-28 04:26:53 --> Loader Class Initialized
INFO - 2023-02-28 04:26:53 --> Loader Class Initialized
INFO - 2023-02-28 04:26:53 --> Controller Class Initialized
INFO - 2023-02-28 04:26:53 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:26:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:53 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:53 --> Total execution time: 0.0046
INFO - 2023-02-28 04:26:53 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:53 --> Config Class Initialized
INFO - 2023-02-28 04:26:53 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:53 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:53 --> URI Class Initialized
INFO - 2023-02-28 04:26:53 --> Router Class Initialized
INFO - 2023-02-28 04:26:53 --> Output Class Initialized
INFO - 2023-02-28 04:26:53 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:53 --> Input Class Initialized
INFO - 2023-02-28 04:26:53 --> Language Class Initialized
INFO - 2023-02-28 04:26:53 --> Loader Class Initialized
INFO - 2023-02-28 04:26:53 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:53 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:53 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:53 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:53 --> Total execution time: 0.0179
INFO - 2023-02-28 04:26:53 --> Model "Login_model" initialized
INFO - 2023-02-28 04:26:53 --> Config Class Initialized
INFO - 2023-02-28 04:26:53 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:53 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:53 --> URI Class Initialized
INFO - 2023-02-28 04:26:53 --> Router Class Initialized
INFO - 2023-02-28 04:26:53 --> Output Class Initialized
INFO - 2023-02-28 04:26:53 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:53 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:53 --> Input Class Initialized
INFO - 2023-02-28 04:26:53 --> Language Class Initialized
INFO - 2023-02-28 04:26:53 --> Loader Class Initialized
INFO - 2023-02-28 04:26:53 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:53 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:53 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:53 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:53 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:53 --> Total execution time: 0.0239
INFO - 2023-02-28 04:26:53 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:53 --> Total execution time: 0.0128
INFO - 2023-02-28 04:26:56 --> Config Class Initialized
INFO - 2023-02-28 04:26:56 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:56 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:56 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:56 --> URI Class Initialized
INFO - 2023-02-28 04:26:56 --> Router Class Initialized
INFO - 2023-02-28 04:26:56 --> Output Class Initialized
INFO - 2023-02-28 04:26:56 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:56 --> Input Class Initialized
INFO - 2023-02-28 04:26:56 --> Language Class Initialized
INFO - 2023-02-28 04:26:56 --> Loader Class Initialized
INFO - 2023-02-28 04:26:56 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:56 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:56 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:56 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:56 --> Total execution time: 0.0138
INFO - 2023-02-28 04:26:56 --> Config Class Initialized
INFO - 2023-02-28 04:26:56 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:56 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:56 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:56 --> URI Class Initialized
INFO - 2023-02-28 04:26:56 --> Router Class Initialized
INFO - 2023-02-28 04:26:56 --> Output Class Initialized
INFO - 2023-02-28 04:26:56 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:56 --> Input Class Initialized
INFO - 2023-02-28 04:26:56 --> Language Class Initialized
INFO - 2023-02-28 04:26:56 --> Loader Class Initialized
INFO - 2023-02-28 04:26:56 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:56 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:56 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:56 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:56 --> Total execution time: 0.0113
INFO - 2023-02-28 04:26:57 --> Config Class Initialized
INFO - 2023-02-28 04:26:57 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:57 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:57 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:57 --> URI Class Initialized
INFO - 2023-02-28 04:26:57 --> Router Class Initialized
INFO - 2023-02-28 04:26:57 --> Output Class Initialized
INFO - 2023-02-28 04:26:57 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:57 --> Input Class Initialized
INFO - 2023-02-28 04:26:57 --> Language Class Initialized
INFO - 2023-02-28 04:26:57 --> Loader Class Initialized
INFO - 2023-02-28 04:26:57 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:57 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:57 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:57 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:57 --> Total execution time: 0.0429
INFO - 2023-02-28 04:26:57 --> Config Class Initialized
INFO - 2023-02-28 04:26:57 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:26:57 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:26:57 --> Utf8 Class Initialized
INFO - 2023-02-28 04:26:57 --> URI Class Initialized
INFO - 2023-02-28 04:26:57 --> Router Class Initialized
INFO - 2023-02-28 04:26:57 --> Output Class Initialized
INFO - 2023-02-28 04:26:57 --> Security Class Initialized
DEBUG - 2023-02-28 04:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:26:57 --> Input Class Initialized
INFO - 2023-02-28 04:26:57 --> Language Class Initialized
INFO - 2023-02-28 04:26:57 --> Loader Class Initialized
INFO - 2023-02-28 04:26:57 --> Controller Class Initialized
DEBUG - 2023-02-28 04:26:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:26:57 --> Database Driver Class Initialized
INFO - 2023-02-28 04:26:57 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:26:57 --> Final output sent to browser
DEBUG - 2023-02-28 04:26:57 --> Total execution time: 0.0419
INFO - 2023-02-28 04:27:01 --> Config Class Initialized
INFO - 2023-02-28 04:27:01 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:27:01 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:27:01 --> Utf8 Class Initialized
INFO - 2023-02-28 04:27:01 --> URI Class Initialized
INFO - 2023-02-28 04:27:01 --> Router Class Initialized
INFO - 2023-02-28 04:27:01 --> Output Class Initialized
INFO - 2023-02-28 04:27:01 --> Security Class Initialized
DEBUG - 2023-02-28 04:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:27:01 --> Input Class Initialized
INFO - 2023-02-28 04:27:01 --> Language Class Initialized
INFO - 2023-02-28 04:27:01 --> Loader Class Initialized
INFO - 2023-02-28 04:27:01 --> Controller Class Initialized
DEBUG - 2023-02-28 04:27:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:27:01 --> Database Driver Class Initialized
INFO - 2023-02-28 04:27:01 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:27:01 --> Final output sent to browser
DEBUG - 2023-02-28 04:27:01 --> Total execution time: 0.0440
INFO - 2023-02-28 04:27:01 --> Config Class Initialized
INFO - 2023-02-28 04:27:01 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:27:01 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:27:01 --> Utf8 Class Initialized
INFO - 2023-02-28 04:27:01 --> URI Class Initialized
INFO - 2023-02-28 04:27:01 --> Router Class Initialized
INFO - 2023-02-28 04:27:01 --> Output Class Initialized
INFO - 2023-02-28 04:27:01 --> Security Class Initialized
DEBUG - 2023-02-28 04:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:27:01 --> Input Class Initialized
INFO - 2023-02-28 04:27:01 --> Language Class Initialized
INFO - 2023-02-28 04:27:01 --> Loader Class Initialized
INFO - 2023-02-28 04:27:01 --> Controller Class Initialized
DEBUG - 2023-02-28 04:27:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:27:01 --> Database Driver Class Initialized
INFO - 2023-02-28 04:27:01 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:27:01 --> Final output sent to browser
DEBUG - 2023-02-28 04:27:01 --> Total execution time: 0.0373
INFO - 2023-02-28 04:29:58 --> Config Class Initialized
INFO - 2023-02-28 04:29:58 --> Config Class Initialized
INFO - 2023-02-28 04:29:58 --> Hooks Class Initialized
INFO - 2023-02-28 04:29:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:29:58 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:29:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:29:58 --> Utf8 Class Initialized
INFO - 2023-02-28 04:29:58 --> Utf8 Class Initialized
INFO - 2023-02-28 04:29:58 --> URI Class Initialized
INFO - 2023-02-28 04:29:58 --> URI Class Initialized
INFO - 2023-02-28 04:29:58 --> Router Class Initialized
INFO - 2023-02-28 04:29:58 --> Router Class Initialized
INFO - 2023-02-28 04:29:58 --> Output Class Initialized
INFO - 2023-02-28 04:29:58 --> Output Class Initialized
INFO - 2023-02-28 04:29:58 --> Security Class Initialized
INFO - 2023-02-28 04:29:58 --> Security Class Initialized
DEBUG - 2023-02-28 04:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:29:58 --> Input Class Initialized
INFO - 2023-02-28 04:29:58 --> Input Class Initialized
INFO - 2023-02-28 04:29:58 --> Language Class Initialized
INFO - 2023-02-28 04:29:58 --> Language Class Initialized
INFO - 2023-02-28 04:29:58 --> Loader Class Initialized
INFO - 2023-02-28 04:29:58 --> Loader Class Initialized
INFO - 2023-02-28 04:29:58 --> Controller Class Initialized
INFO - 2023-02-28 04:29:58 --> Controller Class Initialized
DEBUG - 2023-02-28 04:29:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:29:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:29:58 --> Final output sent to browser
DEBUG - 2023-02-28 04:29:58 --> Total execution time: 0.0045
INFO - 2023-02-28 04:29:58 --> Database Driver Class Initialized
INFO - 2023-02-28 04:29:58 --> Config Class Initialized
INFO - 2023-02-28 04:29:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:29:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:29:58 --> Utf8 Class Initialized
INFO - 2023-02-28 04:29:58 --> URI Class Initialized
INFO - 2023-02-28 04:29:58 --> Router Class Initialized
INFO - 2023-02-28 04:29:58 --> Output Class Initialized
INFO - 2023-02-28 04:29:58 --> Security Class Initialized
DEBUG - 2023-02-28 04:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:29:58 --> Input Class Initialized
INFO - 2023-02-28 04:29:58 --> Language Class Initialized
INFO - 2023-02-28 04:29:58 --> Loader Class Initialized
INFO - 2023-02-28 04:29:58 --> Controller Class Initialized
DEBUG - 2023-02-28 04:29:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:29:58 --> Database Driver Class Initialized
INFO - 2023-02-28 04:29:58 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:29:58 --> Final output sent to browser
DEBUG - 2023-02-28 04:29:58 --> Total execution time: 0.0165
INFO - 2023-02-28 04:29:58 --> Model "Login_model" initialized
INFO - 2023-02-28 04:29:58 --> Config Class Initialized
INFO - 2023-02-28 04:29:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:29:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:29:58 --> Utf8 Class Initialized
INFO - 2023-02-28 04:29:58 --> URI Class Initialized
INFO - 2023-02-28 04:29:58 --> Router Class Initialized
INFO - 2023-02-28 04:29:58 --> Output Class Initialized
INFO - 2023-02-28 04:29:58 --> Security Class Initialized
DEBUG - 2023-02-28 04:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:29:58 --> Input Class Initialized
INFO - 2023-02-28 04:29:58 --> Language Class Initialized
INFO - 2023-02-28 04:29:58 --> Loader Class Initialized
INFO - 2023-02-28 04:29:58 --> Controller Class Initialized
DEBUG - 2023-02-28 04:29:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:29:58 --> Database Driver Class Initialized
INFO - 2023-02-28 04:29:58 --> Database Driver Class Initialized
INFO - 2023-02-28 04:29:58 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:29:58 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:29:58 --> Final output sent to browser
DEBUG - 2023-02-28 04:29:58 --> Total execution time: 0.0240
INFO - 2023-02-28 04:29:58 --> Final output sent to browser
DEBUG - 2023-02-28 04:29:58 --> Total execution time: 0.0152
INFO - 2023-02-28 04:30:01 --> Config Class Initialized
INFO - 2023-02-28 04:30:01 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:30:01 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:30:01 --> Utf8 Class Initialized
INFO - 2023-02-28 04:30:01 --> URI Class Initialized
INFO - 2023-02-28 04:30:01 --> Router Class Initialized
INFO - 2023-02-28 04:30:01 --> Output Class Initialized
INFO - 2023-02-28 04:30:01 --> Security Class Initialized
DEBUG - 2023-02-28 04:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:30:01 --> Input Class Initialized
INFO - 2023-02-28 04:30:01 --> Language Class Initialized
INFO - 2023-02-28 04:30:01 --> Loader Class Initialized
INFO - 2023-02-28 04:30:01 --> Controller Class Initialized
DEBUG - 2023-02-28 04:30:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:30:01 --> Database Driver Class Initialized
INFO - 2023-02-28 04:30:01 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:30:01 --> Database Driver Class Initialized
INFO - 2023-02-28 04:30:01 --> Model "Login_model" initialized
INFO - 2023-02-28 04:30:01 --> Final output sent to browser
DEBUG - 2023-02-28 04:30:01 --> Total execution time: 0.0682
INFO - 2023-02-28 04:30:01 --> Config Class Initialized
INFO - 2023-02-28 04:30:01 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:30:01 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:30:01 --> Utf8 Class Initialized
INFO - 2023-02-28 04:30:01 --> URI Class Initialized
INFO - 2023-02-28 04:30:01 --> Router Class Initialized
INFO - 2023-02-28 04:30:01 --> Output Class Initialized
INFO - 2023-02-28 04:30:01 --> Security Class Initialized
DEBUG - 2023-02-28 04:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:30:01 --> Input Class Initialized
INFO - 2023-02-28 04:30:01 --> Language Class Initialized
INFO - 2023-02-28 04:30:01 --> Loader Class Initialized
INFO - 2023-02-28 04:30:01 --> Controller Class Initialized
DEBUG - 2023-02-28 04:30:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:30:01 --> Database Driver Class Initialized
INFO - 2023-02-28 04:30:01 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:30:01 --> Database Driver Class Initialized
INFO - 2023-02-28 04:30:01 --> Model "Login_model" initialized
INFO - 2023-02-28 04:30:01 --> Final output sent to browser
DEBUG - 2023-02-28 04:30:01 --> Total execution time: 0.0475
INFO - 2023-02-28 04:31:54 --> Config Class Initialized
INFO - 2023-02-28 04:31:54 --> Hooks Class Initialized
INFO - 2023-02-28 04:31:54 --> Config Class Initialized
INFO - 2023-02-28 04:31:54 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:31:54 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:31:54 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:31:54 --> Utf8 Class Initialized
INFO - 2023-02-28 04:31:54 --> Utf8 Class Initialized
INFO - 2023-02-28 04:31:54 --> URI Class Initialized
INFO - 2023-02-28 04:31:54 --> URI Class Initialized
INFO - 2023-02-28 04:31:54 --> Router Class Initialized
INFO - 2023-02-28 04:31:54 --> Router Class Initialized
INFO - 2023-02-28 04:31:54 --> Output Class Initialized
INFO - 2023-02-28 04:31:54 --> Output Class Initialized
INFO - 2023-02-28 04:31:54 --> Security Class Initialized
INFO - 2023-02-28 04:31:54 --> Security Class Initialized
DEBUG - 2023-02-28 04:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:31:54 --> Input Class Initialized
INFO - 2023-02-28 04:31:54 --> Input Class Initialized
INFO - 2023-02-28 04:31:54 --> Language Class Initialized
INFO - 2023-02-28 04:31:54 --> Language Class Initialized
INFO - 2023-02-28 04:31:54 --> Loader Class Initialized
INFO - 2023-02-28 04:31:54 --> Loader Class Initialized
INFO - 2023-02-28 04:31:54 --> Controller Class Initialized
INFO - 2023-02-28 04:31:54 --> Controller Class Initialized
DEBUG - 2023-02-28 04:31:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:31:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:31:54 --> Final output sent to browser
DEBUG - 2023-02-28 04:31:54 --> Total execution time: 0.0048
INFO - 2023-02-28 04:31:54 --> Database Driver Class Initialized
INFO - 2023-02-28 04:31:54 --> Config Class Initialized
INFO - 2023-02-28 04:31:54 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:31:54 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:31:54 --> Utf8 Class Initialized
INFO - 2023-02-28 04:31:54 --> URI Class Initialized
INFO - 2023-02-28 04:31:54 --> Router Class Initialized
INFO - 2023-02-28 04:31:54 --> Output Class Initialized
INFO - 2023-02-28 04:31:54 --> Security Class Initialized
DEBUG - 2023-02-28 04:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:31:54 --> Input Class Initialized
INFO - 2023-02-28 04:31:54 --> Language Class Initialized
INFO - 2023-02-28 04:31:54 --> Loader Class Initialized
INFO - 2023-02-28 04:31:54 --> Controller Class Initialized
DEBUG - 2023-02-28 04:31:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:31:54 --> Database Driver Class Initialized
INFO - 2023-02-28 04:31:54 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:31:54 --> Final output sent to browser
DEBUG - 2023-02-28 04:31:54 --> Total execution time: 0.0172
INFO - 2023-02-28 04:31:54 --> Config Class Initialized
INFO - 2023-02-28 04:31:54 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:31:54 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:31:54 --> Utf8 Class Initialized
INFO - 2023-02-28 04:31:54 --> URI Class Initialized
INFO - 2023-02-28 04:31:54 --> Router Class Initialized
INFO - 2023-02-28 04:31:54 --> Output Class Initialized
INFO - 2023-02-28 04:31:54 --> Security Class Initialized
DEBUG - 2023-02-28 04:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:31:54 --> Input Class Initialized
INFO - 2023-02-28 04:31:54 --> Language Class Initialized
INFO - 2023-02-28 04:31:54 --> Loader Class Initialized
INFO - 2023-02-28 04:31:54 --> Controller Class Initialized
DEBUG - 2023-02-28 04:31:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:31:54 --> Database Driver Class Initialized
INFO - 2023-02-28 04:31:54 --> Model "Login_model" initialized
INFO - 2023-02-28 04:31:54 --> Database Driver Class Initialized
INFO - 2023-02-28 04:31:54 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:31:54 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:31:54 --> Final output sent to browser
DEBUG - 2023-02-28 04:31:54 --> Total execution time: 0.0143
INFO - 2023-02-28 04:31:54 --> Final output sent to browser
DEBUG - 2023-02-28 04:31:54 --> Total execution time: 0.0272
INFO - 2023-02-28 04:31:56 --> Config Class Initialized
INFO - 2023-02-28 04:31:56 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:31:56 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:31:56 --> Utf8 Class Initialized
INFO - 2023-02-28 04:31:56 --> URI Class Initialized
INFO - 2023-02-28 04:31:56 --> Router Class Initialized
INFO - 2023-02-28 04:31:56 --> Output Class Initialized
INFO - 2023-02-28 04:31:56 --> Security Class Initialized
DEBUG - 2023-02-28 04:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:31:56 --> Input Class Initialized
INFO - 2023-02-28 04:31:56 --> Language Class Initialized
INFO - 2023-02-28 04:31:56 --> Loader Class Initialized
INFO - 2023-02-28 04:31:56 --> Controller Class Initialized
DEBUG - 2023-02-28 04:31:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:31:56 --> Database Driver Class Initialized
INFO - 2023-02-28 04:31:56 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:31:56 --> Final output sent to browser
DEBUG - 2023-02-28 04:31:56 --> Total execution time: 0.0433
INFO - 2023-02-28 04:31:56 --> Config Class Initialized
INFO - 2023-02-28 04:31:56 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:31:56 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:31:56 --> Utf8 Class Initialized
INFO - 2023-02-28 04:31:56 --> URI Class Initialized
INFO - 2023-02-28 04:31:56 --> Router Class Initialized
INFO - 2023-02-28 04:31:56 --> Output Class Initialized
INFO - 2023-02-28 04:31:56 --> Security Class Initialized
DEBUG - 2023-02-28 04:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:31:56 --> Input Class Initialized
INFO - 2023-02-28 04:31:56 --> Language Class Initialized
INFO - 2023-02-28 04:31:56 --> Loader Class Initialized
INFO - 2023-02-28 04:31:56 --> Controller Class Initialized
DEBUG - 2023-02-28 04:31:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:31:56 --> Database Driver Class Initialized
INFO - 2023-02-28 04:31:56 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:31:57 --> Final output sent to browser
DEBUG - 2023-02-28 04:31:57 --> Total execution time: 0.0387
INFO - 2023-02-28 04:31:58 --> Config Class Initialized
INFO - 2023-02-28 04:31:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:31:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:31:58 --> Utf8 Class Initialized
INFO - 2023-02-28 04:31:58 --> URI Class Initialized
INFO - 2023-02-28 04:31:58 --> Router Class Initialized
INFO - 2023-02-28 04:31:58 --> Output Class Initialized
INFO - 2023-02-28 04:31:58 --> Security Class Initialized
DEBUG - 2023-02-28 04:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:31:58 --> Input Class Initialized
INFO - 2023-02-28 04:31:58 --> Language Class Initialized
INFO - 2023-02-28 04:31:58 --> Loader Class Initialized
INFO - 2023-02-28 04:31:58 --> Controller Class Initialized
DEBUG - 2023-02-28 04:31:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:31:58 --> Database Driver Class Initialized
INFO - 2023-02-28 04:31:58 --> Database Driver Class Initialized
INFO - 2023-02-28 04:31:58 --> Model "Login_model" initialized
INFO - 2023-02-28 04:31:58 --> Final output sent to browser
DEBUG - 2023-02-28 04:31:58 --> Total execution time: 0.0227
INFO - 2023-02-28 04:31:58 --> Config Class Initialized
INFO - 2023-02-28 04:31:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:31:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:31:58 --> Utf8 Class Initialized
INFO - 2023-02-28 04:31:58 --> URI Class Initialized
INFO - 2023-02-28 04:31:58 --> Router Class Initialized
INFO - 2023-02-28 04:31:58 --> Output Class Initialized
INFO - 2023-02-28 04:31:58 --> Security Class Initialized
DEBUG - 2023-02-28 04:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:31:58 --> Input Class Initialized
INFO - 2023-02-28 04:31:58 --> Language Class Initialized
INFO - 2023-02-28 04:31:58 --> Loader Class Initialized
INFO - 2023-02-28 04:31:58 --> Controller Class Initialized
DEBUG - 2023-02-28 04:31:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:31:58 --> Database Driver Class Initialized
INFO - 2023-02-28 04:31:58 --> Database Driver Class Initialized
INFO - 2023-02-28 04:31:58 --> Model "Login_model" initialized
INFO - 2023-02-28 04:31:58 --> Final output sent to browser
DEBUG - 2023-02-28 04:31:58 --> Total execution time: 0.0248
INFO - 2023-02-28 04:32:01 --> Config Class Initialized
INFO - 2023-02-28 04:32:01 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:01 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:01 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:01 --> URI Class Initialized
INFO - 2023-02-28 04:32:01 --> Router Class Initialized
INFO - 2023-02-28 04:32:01 --> Output Class Initialized
INFO - 2023-02-28 04:32:01 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:01 --> Input Class Initialized
INFO - 2023-02-28 04:32:01 --> Language Class Initialized
INFO - 2023-02-28 04:32:01 --> Loader Class Initialized
INFO - 2023-02-28 04:32:01 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:01 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:01 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:01 --> Model "Login_model" initialized
INFO - 2023-02-28 04:32:01 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:01 --> Total execution time: 0.0232
INFO - 2023-02-28 04:32:01 --> Config Class Initialized
INFO - 2023-02-28 04:32:01 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:01 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:01 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:01 --> URI Class Initialized
INFO - 2023-02-28 04:32:01 --> Router Class Initialized
INFO - 2023-02-28 04:32:01 --> Output Class Initialized
INFO - 2023-02-28 04:32:01 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:01 --> Input Class Initialized
INFO - 2023-02-28 04:32:01 --> Language Class Initialized
INFO - 2023-02-28 04:32:01 --> Loader Class Initialized
INFO - 2023-02-28 04:32:01 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:01 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:01 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:01 --> Model "Login_model" initialized
INFO - 2023-02-28 04:32:01 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:01 --> Total execution time: 0.0195
INFO - 2023-02-28 04:32:07 --> Config Class Initialized
INFO - 2023-02-28 04:32:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:07 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:07 --> URI Class Initialized
INFO - 2023-02-28 04:32:07 --> Router Class Initialized
INFO - 2023-02-28 04:32:07 --> Output Class Initialized
INFO - 2023-02-28 04:32:07 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:07 --> Input Class Initialized
INFO - 2023-02-28 04:32:07 --> Language Class Initialized
INFO - 2023-02-28 04:32:07 --> Loader Class Initialized
INFO - 2023-02-28 04:32:07 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:07 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:07 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:07 --> Model "Login_model" initialized
INFO - 2023-02-28 04:32:07 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:07 --> Total execution time: 0.0214
INFO - 2023-02-28 04:32:07 --> Config Class Initialized
INFO - 2023-02-28 04:32:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:07 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:07 --> URI Class Initialized
INFO - 2023-02-28 04:32:07 --> Router Class Initialized
INFO - 2023-02-28 04:32:07 --> Output Class Initialized
INFO - 2023-02-28 04:32:07 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:07 --> Input Class Initialized
INFO - 2023-02-28 04:32:07 --> Language Class Initialized
INFO - 2023-02-28 04:32:07 --> Loader Class Initialized
INFO - 2023-02-28 04:32:07 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:07 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:07 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:07 --> Model "Login_model" initialized
INFO - 2023-02-28 04:32:07 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:07 --> Total execution time: 0.0668
INFO - 2023-02-28 04:32:12 --> Config Class Initialized
INFO - 2023-02-28 04:32:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:12 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:12 --> URI Class Initialized
INFO - 2023-02-28 04:32:12 --> Router Class Initialized
INFO - 2023-02-28 04:32:12 --> Output Class Initialized
INFO - 2023-02-28 04:32:12 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:12 --> Input Class Initialized
INFO - 2023-02-28 04:32:12 --> Language Class Initialized
INFO - 2023-02-28 04:32:12 --> Loader Class Initialized
INFO - 2023-02-28 04:32:12 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:12 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:12 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:12 --> Model "Login_model" initialized
INFO - 2023-02-28 04:32:12 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:12 --> Total execution time: 0.0267
INFO - 2023-02-28 04:32:24 --> Config Class Initialized
INFO - 2023-02-28 04:32:24 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:24 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:24 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:24 --> URI Class Initialized
INFO - 2023-02-28 04:32:24 --> Router Class Initialized
INFO - 2023-02-28 04:32:24 --> Output Class Initialized
INFO - 2023-02-28 04:32:24 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:24 --> Input Class Initialized
INFO - 2023-02-28 04:32:24 --> Language Class Initialized
INFO - 2023-02-28 04:32:24 --> Loader Class Initialized
INFO - 2023-02-28 04:32:24 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:24 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:24 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:32:24 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:24 --> Total execution time: 0.0485
INFO - 2023-02-28 04:32:24 --> Config Class Initialized
INFO - 2023-02-28 04:32:24 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:24 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:24 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:24 --> URI Class Initialized
INFO - 2023-02-28 04:32:24 --> Router Class Initialized
INFO - 2023-02-28 04:32:24 --> Output Class Initialized
INFO - 2023-02-28 04:32:24 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:24 --> Input Class Initialized
INFO - 2023-02-28 04:32:24 --> Language Class Initialized
INFO - 2023-02-28 04:32:24 --> Loader Class Initialized
INFO - 2023-02-28 04:32:24 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:24 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:24 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:32:24 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:24 --> Total execution time: 0.0599
INFO - 2023-02-28 04:32:25 --> Config Class Initialized
INFO - 2023-02-28 04:32:25 --> Config Class Initialized
INFO - 2023-02-28 04:32:25 --> Hooks Class Initialized
INFO - 2023-02-28 04:32:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:25 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:32:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:25 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:25 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:25 --> URI Class Initialized
INFO - 2023-02-28 04:32:25 --> URI Class Initialized
INFO - 2023-02-28 04:32:25 --> Router Class Initialized
INFO - 2023-02-28 04:32:25 --> Router Class Initialized
INFO - 2023-02-28 04:32:25 --> Output Class Initialized
INFO - 2023-02-28 04:32:25 --> Output Class Initialized
INFO - 2023-02-28 04:32:25 --> Security Class Initialized
INFO - 2023-02-28 04:32:25 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:25 --> Input Class Initialized
INFO - 2023-02-28 04:32:25 --> Input Class Initialized
INFO - 2023-02-28 04:32:25 --> Language Class Initialized
INFO - 2023-02-28 04:32:25 --> Language Class Initialized
INFO - 2023-02-28 04:32:25 --> Loader Class Initialized
INFO - 2023-02-28 04:32:25 --> Loader Class Initialized
INFO - 2023-02-28 04:32:25 --> Controller Class Initialized
INFO - 2023-02-28 04:32:25 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:32:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:25 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:25 --> Total execution time: 0.0047
INFO - 2023-02-28 04:32:25 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:25 --> Config Class Initialized
INFO - 2023-02-28 04:32:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:25 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:25 --> URI Class Initialized
INFO - 2023-02-28 04:32:25 --> Router Class Initialized
INFO - 2023-02-28 04:32:25 --> Output Class Initialized
INFO - 2023-02-28 04:32:25 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:25 --> Input Class Initialized
INFO - 2023-02-28 04:32:25 --> Language Class Initialized
INFO - 2023-02-28 04:32:25 --> Loader Class Initialized
INFO - 2023-02-28 04:32:25 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:25 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:25 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:32:25 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:25 --> Total execution time: 0.0145
INFO - 2023-02-28 04:32:25 --> Model "Login_model" initialized
INFO - 2023-02-28 04:32:25 --> Config Class Initialized
INFO - 2023-02-28 04:32:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:25 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:25 --> URI Class Initialized
INFO - 2023-02-28 04:32:25 --> Router Class Initialized
INFO - 2023-02-28 04:32:25 --> Output Class Initialized
INFO - 2023-02-28 04:32:25 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:25 --> Input Class Initialized
INFO - 2023-02-28 04:32:25 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:25 --> Language Class Initialized
INFO - 2023-02-28 04:32:25 --> Loader Class Initialized
INFO - 2023-02-28 04:32:25 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:25 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:25 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:32:25 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:32:25 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:25 --> Total execution time: 0.0185
INFO - 2023-02-28 04:32:25 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:25 --> Total execution time: 0.0127
INFO - 2023-02-28 04:32:27 --> Config Class Initialized
INFO - 2023-02-28 04:32:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:27 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:27 --> URI Class Initialized
INFO - 2023-02-28 04:32:27 --> Router Class Initialized
INFO - 2023-02-28 04:32:27 --> Output Class Initialized
INFO - 2023-02-28 04:32:27 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:27 --> Input Class Initialized
INFO - 2023-02-28 04:32:27 --> Language Class Initialized
INFO - 2023-02-28 04:32:27 --> Loader Class Initialized
INFO - 2023-02-28 04:32:27 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:27 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:32:27 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:27 --> Total execution time: 0.0452
INFO - 2023-02-28 04:32:28 --> Config Class Initialized
INFO - 2023-02-28 04:32:28 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:28 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:28 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:28 --> URI Class Initialized
INFO - 2023-02-28 04:32:28 --> Router Class Initialized
INFO - 2023-02-28 04:32:28 --> Output Class Initialized
INFO - 2023-02-28 04:32:28 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:28 --> Input Class Initialized
INFO - 2023-02-28 04:32:28 --> Language Class Initialized
INFO - 2023-02-28 04:32:28 --> Loader Class Initialized
INFO - 2023-02-28 04:32:28 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:28 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:28 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:32:28 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:28 --> Total execution time: 0.0147
INFO - 2023-02-28 04:32:28 --> Config Class Initialized
INFO - 2023-02-28 04:32:28 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:28 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:28 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:28 --> URI Class Initialized
INFO - 2023-02-28 04:32:28 --> Router Class Initialized
INFO - 2023-02-28 04:32:28 --> Output Class Initialized
INFO - 2023-02-28 04:32:28 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:28 --> Input Class Initialized
INFO - 2023-02-28 04:32:28 --> Language Class Initialized
INFO - 2023-02-28 04:32:28 --> Loader Class Initialized
INFO - 2023-02-28 04:32:28 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:28 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:28 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:32:28 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:28 --> Total execution time: 0.0115
INFO - 2023-02-28 04:32:30 --> Config Class Initialized
INFO - 2023-02-28 04:32:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:30 --> URI Class Initialized
INFO - 2023-02-28 04:32:30 --> Router Class Initialized
INFO - 2023-02-28 04:32:30 --> Output Class Initialized
INFO - 2023-02-28 04:32:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:30 --> Input Class Initialized
INFO - 2023-02-28 04:32:30 --> Language Class Initialized
INFO - 2023-02-28 04:32:30 --> Loader Class Initialized
INFO - 2023-02-28 04:32:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:32:31 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:31 --> Total execution time: 0.0411
INFO - 2023-02-28 04:32:31 --> Config Class Initialized
INFO - 2023-02-28 04:32:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:31 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:31 --> URI Class Initialized
INFO - 2023-02-28 04:32:31 --> Router Class Initialized
INFO - 2023-02-28 04:32:31 --> Output Class Initialized
INFO - 2023-02-28 04:32:31 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:31 --> Input Class Initialized
INFO - 2023-02-28 04:32:31 --> Language Class Initialized
INFO - 2023-02-28 04:32:31 --> Loader Class Initialized
INFO - 2023-02-28 04:32:31 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:31 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:31 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:32:31 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:31 --> Total execution time: 0.0376
INFO - 2023-02-28 04:32:33 --> Config Class Initialized
INFO - 2023-02-28 04:32:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:33 --> URI Class Initialized
INFO - 2023-02-28 04:32:33 --> Config Class Initialized
INFO - 2023-02-28 04:32:33 --> Router Class Initialized
INFO - 2023-02-28 04:32:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:33 --> URI Class Initialized
INFO - 2023-02-28 04:32:33 --> Router Class Initialized
INFO - 2023-02-28 04:32:33 --> Output Class Initialized
INFO - 2023-02-28 04:32:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:33 --> Input Class Initialized
INFO - 2023-02-28 04:32:33 --> Output Class Initialized
INFO - 2023-02-28 04:32:33 --> Language Class Initialized
INFO - 2023-02-28 04:32:33 --> Loader Class Initialized
INFO - 2023-02-28 04:32:33 --> Security Class Initialized
INFO - 2023-02-28 04:32:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:32:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:33 --> Final output sent to browser
INFO - 2023-02-28 04:32:33 --> Input Class Initialized
INFO - 2023-02-28 04:32:33 --> Language Class Initialized
DEBUG - 2023-02-28 04:32:33 --> Total execution time: 0.0426
INFO - 2023-02-28 04:32:33 --> Loader Class Initialized
INFO - 2023-02-28 04:32:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:33 --> Config Class Initialized
INFO - 2023-02-28 04:32:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:33 --> URI Class Initialized
INFO - 2023-02-28 04:32:33 --> Router Class Initialized
INFO - 2023-02-28 04:32:33 --> Output Class Initialized
INFO - 2023-02-28 04:32:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:33 --> Input Class Initialized
INFO - 2023-02-28 04:32:33 --> Language Class Initialized
INFO - 2023-02-28 04:32:33 --> Loader Class Initialized
INFO - 2023-02-28 04:32:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:32:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:33 --> Total execution time: 0.0592
INFO - 2023-02-28 04:32:33 --> Model "Login_model" initialized
INFO - 2023-02-28 04:32:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:33 --> Config Class Initialized
INFO - 2023-02-28 04:32:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:32:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:32:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:32:33 --> URI Class Initialized
INFO - 2023-02-28 04:32:33 --> Router Class Initialized
INFO - 2023-02-28 04:32:33 --> Output Class Initialized
INFO - 2023-02-28 04:32:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:32:33 --> Input Class Initialized
INFO - 2023-02-28 04:32:33 --> Language Class Initialized
INFO - 2023-02-28 04:32:33 --> Loader Class Initialized
INFO - 2023-02-28 04:32:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:32:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:32:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:32:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:32:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:33 --> Total execution time: 0.1039
INFO - 2023-02-28 04:32:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:32:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:32:33 --> Total execution time: 0.0579
INFO - 2023-02-28 04:37:03 --> Config Class Initialized
INFO - 2023-02-28 04:37:03 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:03 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:03 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:03 --> URI Class Initialized
INFO - 2023-02-28 04:37:03 --> Router Class Initialized
INFO - 2023-02-28 04:37:03 --> Output Class Initialized
INFO - 2023-02-28 04:37:03 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:03 --> Input Class Initialized
INFO - 2023-02-28 04:37:03 --> Language Class Initialized
INFO - 2023-02-28 04:37:03 --> Loader Class Initialized
INFO - 2023-02-28 04:37:03 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:03 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:03 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:03 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:03 --> Total execution time: 0.0466
INFO - 2023-02-28 04:37:03 --> Config Class Initialized
INFO - 2023-02-28 04:37:03 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:03 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:03 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:03 --> URI Class Initialized
INFO - 2023-02-28 04:37:03 --> Router Class Initialized
INFO - 2023-02-28 04:37:03 --> Output Class Initialized
INFO - 2023-02-28 04:37:03 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:03 --> Input Class Initialized
INFO - 2023-02-28 04:37:03 --> Language Class Initialized
INFO - 2023-02-28 04:37:03 --> Loader Class Initialized
INFO - 2023-02-28 04:37:03 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:03 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:03 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:03 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:03 --> Total execution time: 0.0392
INFO - 2023-02-28 04:37:06 --> Config Class Initialized
INFO - 2023-02-28 04:37:06 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:06 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:06 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:06 --> URI Class Initialized
INFO - 2023-02-28 04:37:06 --> Router Class Initialized
INFO - 2023-02-28 04:37:06 --> Output Class Initialized
INFO - 2023-02-28 04:37:06 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:06 --> Input Class Initialized
INFO - 2023-02-28 04:37:06 --> Language Class Initialized
INFO - 2023-02-28 04:37:06 --> Loader Class Initialized
INFO - 2023-02-28 04:37:06 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:06 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:06 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:06 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:06 --> Total execution time: 0.0179
INFO - 2023-02-28 04:37:06 --> Config Class Initialized
INFO - 2023-02-28 04:37:06 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:06 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:06 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:06 --> URI Class Initialized
INFO - 2023-02-28 04:37:06 --> Router Class Initialized
INFO - 2023-02-28 04:37:06 --> Output Class Initialized
INFO - 2023-02-28 04:37:06 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:06 --> Input Class Initialized
INFO - 2023-02-28 04:37:06 --> Language Class Initialized
INFO - 2023-02-28 04:37:06 --> Loader Class Initialized
INFO - 2023-02-28 04:37:06 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:06 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:06 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:06 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:06 --> Total execution time: 0.0112
INFO - 2023-02-28 04:37:09 --> Config Class Initialized
INFO - 2023-02-28 04:37:09 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:09 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:09 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:09 --> URI Class Initialized
INFO - 2023-02-28 04:37:09 --> Router Class Initialized
INFO - 2023-02-28 04:37:09 --> Output Class Initialized
INFO - 2023-02-28 04:37:09 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:09 --> Input Class Initialized
INFO - 2023-02-28 04:37:09 --> Language Class Initialized
INFO - 2023-02-28 04:37:09 --> Loader Class Initialized
INFO - 2023-02-28 04:37:09 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:09 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:09 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:09 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:09 --> Total execution time: 0.0439
INFO - 2023-02-28 04:37:09 --> Config Class Initialized
INFO - 2023-02-28 04:37:09 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:09 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:09 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:09 --> URI Class Initialized
INFO - 2023-02-28 04:37:09 --> Router Class Initialized
INFO - 2023-02-28 04:37:09 --> Output Class Initialized
INFO - 2023-02-28 04:37:09 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:09 --> Input Class Initialized
INFO - 2023-02-28 04:37:09 --> Language Class Initialized
INFO - 2023-02-28 04:37:09 --> Loader Class Initialized
INFO - 2023-02-28 04:37:09 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:09 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:09 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:09 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:09 --> Total execution time: 0.0510
INFO - 2023-02-28 04:37:10 --> Config Class Initialized
INFO - 2023-02-28 04:37:10 --> Config Class Initialized
INFO - 2023-02-28 04:37:10 --> Hooks Class Initialized
INFO - 2023-02-28 04:37:10 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:10 --> Utf8 Class Initialized
DEBUG - 2023-02-28 04:37:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:10 --> URI Class Initialized
INFO - 2023-02-28 04:37:10 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:10 --> Router Class Initialized
INFO - 2023-02-28 04:37:10 --> URI Class Initialized
INFO - 2023-02-28 04:37:10 --> Output Class Initialized
INFO - 2023-02-28 04:37:10 --> Router Class Initialized
INFO - 2023-02-28 04:37:10 --> Security Class Initialized
INFO - 2023-02-28 04:37:10 --> Output Class Initialized
DEBUG - 2023-02-28 04:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:10 --> Security Class Initialized
INFO - 2023-02-28 04:37:10 --> Input Class Initialized
DEBUG - 2023-02-28 04:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:10 --> Language Class Initialized
INFO - 2023-02-28 04:37:10 --> Input Class Initialized
INFO - 2023-02-28 04:37:10 --> Language Class Initialized
INFO - 2023-02-28 04:37:10 --> Loader Class Initialized
INFO - 2023-02-28 04:37:10 --> Controller Class Initialized
INFO - 2023-02-28 04:37:10 --> Loader Class Initialized
DEBUG - 2023-02-28 04:37:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:10 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:10 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:10 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:10 --> Total execution time: 0.0042
INFO - 2023-02-28 04:37:10 --> Config Class Initialized
INFO - 2023-02-28 04:37:10 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:10 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:10 --> URI Class Initialized
INFO - 2023-02-28 04:37:10 --> Router Class Initialized
INFO - 2023-02-28 04:37:10 --> Output Class Initialized
INFO - 2023-02-28 04:37:10 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:10 --> Input Class Initialized
INFO - 2023-02-28 04:37:10 --> Language Class Initialized
INFO - 2023-02-28 04:37:10 --> Loader Class Initialized
INFO - 2023-02-28 04:37:10 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:10 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:10 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:10 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:10 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:10 --> Total execution time: 0.0166
INFO - 2023-02-28 04:37:10 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:10 --> Config Class Initialized
INFO - 2023-02-28 04:37:10 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:10 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:10 --> URI Class Initialized
INFO - 2023-02-28 04:37:10 --> Router Class Initialized
INFO - 2023-02-28 04:37:10 --> Output Class Initialized
INFO - 2023-02-28 04:37:10 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:10 --> Input Class Initialized
INFO - 2023-02-28 04:37:10 --> Language Class Initialized
INFO - 2023-02-28 04:37:10 --> Loader Class Initialized
INFO - 2023-02-28 04:37:10 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:10 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:10 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:10 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:10 --> Total execution time: 0.0190
INFO - 2023-02-28 04:37:10 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:10 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:10 --> Total execution time: 0.0539
INFO - 2023-02-28 04:37:25 --> Config Class Initialized
INFO - 2023-02-28 04:37:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:25 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:25 --> URI Class Initialized
INFO - 2023-02-28 04:37:25 --> Router Class Initialized
INFO - 2023-02-28 04:37:25 --> Output Class Initialized
INFO - 2023-02-28 04:37:25 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:25 --> Input Class Initialized
INFO - 2023-02-28 04:37:25 --> Language Class Initialized
INFO - 2023-02-28 04:37:25 --> Loader Class Initialized
INFO - 2023-02-28 04:37:25 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:25 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:25 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:25 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:25 --> Total execution time: 0.0178
INFO - 2023-02-28 04:37:25 --> Config Class Initialized
INFO - 2023-02-28 04:37:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:25 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:25 --> URI Class Initialized
INFO - 2023-02-28 04:37:25 --> Router Class Initialized
INFO - 2023-02-28 04:37:25 --> Output Class Initialized
INFO - 2023-02-28 04:37:25 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:25 --> Input Class Initialized
INFO - 2023-02-28 04:37:25 --> Language Class Initialized
INFO - 2023-02-28 04:37:25 --> Loader Class Initialized
INFO - 2023-02-28 04:37:25 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:25 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:25 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:25 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:25 --> Total execution time: 0.0113
INFO - 2023-02-28 04:37:28 --> Config Class Initialized
INFO - 2023-02-28 04:37:28 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:28 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:28 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:28 --> URI Class Initialized
INFO - 2023-02-28 04:37:28 --> Router Class Initialized
INFO - 2023-02-28 04:37:28 --> Output Class Initialized
INFO - 2023-02-28 04:37:28 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:28 --> Input Class Initialized
INFO - 2023-02-28 04:37:28 --> Language Class Initialized
INFO - 2023-02-28 04:37:28 --> Loader Class Initialized
INFO - 2023-02-28 04:37:28 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:28 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:28 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:28 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:28 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:28 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:28 --> Total execution time: 0.0601
INFO - 2023-02-28 04:37:28 --> Config Class Initialized
INFO - 2023-02-28 04:37:28 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:28 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:28 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:28 --> URI Class Initialized
INFO - 2023-02-28 04:37:28 --> Router Class Initialized
INFO - 2023-02-28 04:37:28 --> Output Class Initialized
INFO - 2023-02-28 04:37:28 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:28 --> Input Class Initialized
INFO - 2023-02-28 04:37:28 --> Language Class Initialized
INFO - 2023-02-28 04:37:28 --> Loader Class Initialized
INFO - 2023-02-28 04:37:28 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:28 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:29 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:29 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:29 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:29 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:29 --> Total execution time: 0.0346
INFO - 2023-02-28 04:37:30 --> Config Class Initialized
INFO - 2023-02-28 04:37:30 --> Config Class Initialized
INFO - 2023-02-28 04:37:30 --> Hooks Class Initialized
INFO - 2023-02-28 04:37:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:30 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:37:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:30 --> URI Class Initialized
INFO - 2023-02-28 04:37:30 --> URI Class Initialized
INFO - 2023-02-28 04:37:30 --> Router Class Initialized
INFO - 2023-02-28 04:37:30 --> Router Class Initialized
INFO - 2023-02-28 04:37:30 --> Output Class Initialized
INFO - 2023-02-28 04:37:30 --> Output Class Initialized
INFO - 2023-02-28 04:37:30 --> Security Class Initialized
INFO - 2023-02-28 04:37:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:30 --> Input Class Initialized
INFO - 2023-02-28 04:37:30 --> Language Class Initialized
INFO - 2023-02-28 04:37:30 --> Input Class Initialized
INFO - 2023-02-28 04:37:30 --> Language Class Initialized
INFO - 2023-02-28 04:37:30 --> Loader Class Initialized
INFO - 2023-02-28 04:37:30 --> Controller Class Initialized
INFO - 2023-02-28 04:37:30 --> Loader Class Initialized
DEBUG - 2023-02-28 04:37:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:30 --> Total execution time: 0.0042
INFO - 2023-02-28 04:37:30 --> Config Class Initialized
INFO - 2023-02-28 04:37:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:30 --> URI Class Initialized
INFO - 2023-02-28 04:37:30 --> Router Class Initialized
INFO - 2023-02-28 04:37:30 --> Output Class Initialized
INFO - 2023-02-28 04:37:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:30 --> Input Class Initialized
INFO - 2023-02-28 04:37:30 --> Language Class Initialized
INFO - 2023-02-28 04:37:30 --> Loader Class Initialized
INFO - 2023-02-28 04:37:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:30 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:30 --> Total execution time: 0.0158
INFO - 2023-02-28 04:37:30 --> Config Class Initialized
INFO - 2023-02-28 04:37:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:30 --> URI Class Initialized
INFO - 2023-02-28 04:37:30 --> Router Class Initialized
INFO - 2023-02-28 04:37:30 --> Output Class Initialized
INFO - 2023-02-28 04:37:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:30 --> Input Class Initialized
INFO - 2023-02-28 04:37:30 --> Language Class Initialized
INFO - 2023-02-28 04:37:30 --> Loader Class Initialized
INFO - 2023-02-28 04:37:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:30 --> Total execution time: 0.0198
INFO - 2023-02-28 04:37:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:30 --> Total execution time: 0.0541
INFO - 2023-02-28 04:37:34 --> Config Class Initialized
INFO - 2023-02-28 04:37:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:34 --> URI Class Initialized
INFO - 2023-02-28 04:37:34 --> Router Class Initialized
INFO - 2023-02-28 04:37:34 --> Output Class Initialized
INFO - 2023-02-28 04:37:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:34 --> Input Class Initialized
INFO - 2023-02-28 04:37:34 --> Language Class Initialized
INFO - 2023-02-28 04:37:34 --> Loader Class Initialized
INFO - 2023-02-28 04:37:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:34 --> Total execution time: 0.0454
INFO - 2023-02-28 04:37:34 --> Config Class Initialized
INFO - 2023-02-28 04:37:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:34 --> URI Class Initialized
INFO - 2023-02-28 04:37:34 --> Router Class Initialized
INFO - 2023-02-28 04:37:34 --> Output Class Initialized
INFO - 2023-02-28 04:37:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:34 --> Input Class Initialized
INFO - 2023-02-28 04:37:34 --> Language Class Initialized
INFO - 2023-02-28 04:37:34 --> Loader Class Initialized
INFO - 2023-02-28 04:37:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:34 --> Total execution time: 0.0429
INFO - 2023-02-28 04:37:38 --> Config Class Initialized
INFO - 2023-02-28 04:37:38 --> Config Class Initialized
INFO - 2023-02-28 04:37:38 --> Hooks Class Initialized
INFO - 2023-02-28 04:37:38 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:38 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:38 --> Utf8 Class Initialized
DEBUG - 2023-02-28 04:37:38 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:38 --> URI Class Initialized
INFO - 2023-02-28 04:37:38 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:38 --> Router Class Initialized
INFO - 2023-02-28 04:37:38 --> URI Class Initialized
INFO - 2023-02-28 04:37:38 --> Output Class Initialized
INFO - 2023-02-28 04:37:38 --> Router Class Initialized
INFO - 2023-02-28 04:37:38 --> Security Class Initialized
INFO - 2023-02-28 04:37:38 --> Output Class Initialized
DEBUG - 2023-02-28 04:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:38 --> Security Class Initialized
INFO - 2023-02-28 04:37:38 --> Input Class Initialized
DEBUG - 2023-02-28 04:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:38 --> Language Class Initialized
INFO - 2023-02-28 04:37:38 --> Input Class Initialized
INFO - 2023-02-28 04:37:38 --> Loader Class Initialized
INFO - 2023-02-28 04:37:38 --> Language Class Initialized
INFO - 2023-02-28 04:37:38 --> Controller Class Initialized
INFO - 2023-02-28 04:37:38 --> Loader Class Initialized
DEBUG - 2023-02-28 04:37:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:38 --> Controller Class Initialized
INFO - 2023-02-28 04:37:38 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:37:38 --> Total execution time: 0.0043
INFO - 2023-02-28 04:37:38 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:38 --> Config Class Initialized
INFO - 2023-02-28 04:37:38 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:38 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:38 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:38 --> URI Class Initialized
INFO - 2023-02-28 04:37:38 --> Router Class Initialized
INFO - 2023-02-28 04:37:38 --> Output Class Initialized
INFO - 2023-02-28 04:37:38 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:38 --> Input Class Initialized
INFO - 2023-02-28 04:37:38 --> Language Class Initialized
INFO - 2023-02-28 04:37:38 --> Loader Class Initialized
INFO - 2023-02-28 04:37:38 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:38 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:38 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:38 --> Final output sent to browser
INFO - 2023-02-28 04:37:38 --> Model "Login_model" initialized
DEBUG - 2023-02-28 04:37:38 --> Total execution time: 0.0141
INFO - 2023-02-28 04:37:38 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:38 --> Config Class Initialized
INFO - 2023-02-28 04:37:38 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:38 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:38 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:38 --> URI Class Initialized
INFO - 2023-02-28 04:37:38 --> Router Class Initialized
INFO - 2023-02-28 04:37:38 --> Output Class Initialized
INFO - 2023-02-28 04:37:38 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:38 --> Input Class Initialized
INFO - 2023-02-28 04:37:38 --> Language Class Initialized
INFO - 2023-02-28 04:37:38 --> Loader Class Initialized
INFO - 2023-02-28 04:37:38 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:38 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:38 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:38 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:38 --> Total execution time: 0.0208
INFO - 2023-02-28 04:37:38 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:38 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:38 --> Total execution time: 0.0540
INFO - 2023-02-28 04:37:40 --> Config Class Initialized
INFO - 2023-02-28 04:37:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:40 --> URI Class Initialized
INFO - 2023-02-28 04:37:40 --> Router Class Initialized
INFO - 2023-02-28 04:37:40 --> Output Class Initialized
INFO - 2023-02-28 04:37:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:40 --> Input Class Initialized
INFO - 2023-02-28 04:37:40 --> Language Class Initialized
INFO - 2023-02-28 04:37:40 --> Loader Class Initialized
INFO - 2023-02-28 04:37:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:40 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:40 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:40 --> Total execution time: 0.0562
INFO - 2023-02-28 04:37:40 --> Config Class Initialized
INFO - 2023-02-28 04:37:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:40 --> URI Class Initialized
INFO - 2023-02-28 04:37:40 --> Router Class Initialized
INFO - 2023-02-28 04:37:40 --> Output Class Initialized
INFO - 2023-02-28 04:37:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:40 --> Input Class Initialized
INFO - 2023-02-28 04:37:40 --> Language Class Initialized
INFO - 2023-02-28 04:37:40 --> Loader Class Initialized
INFO - 2023-02-28 04:37:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:40 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:40 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:40 --> Total execution time: 0.0408
INFO - 2023-02-28 04:37:43 --> Config Class Initialized
INFO - 2023-02-28 04:37:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:43 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:43 --> URI Class Initialized
INFO - 2023-02-28 04:37:43 --> Router Class Initialized
INFO - 2023-02-28 04:37:43 --> Output Class Initialized
INFO - 2023-02-28 04:37:43 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:43 --> Input Class Initialized
INFO - 2023-02-28 04:37:43 --> Language Class Initialized
INFO - 2023-02-28 04:37:43 --> Loader Class Initialized
INFO - 2023-02-28 04:37:43 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:43 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:43 --> Total execution time: 0.0043
INFO - 2023-02-28 04:37:43 --> Config Class Initialized
INFO - 2023-02-28 04:37:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:43 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:43 --> URI Class Initialized
INFO - 2023-02-28 04:37:43 --> Router Class Initialized
INFO - 2023-02-28 04:37:43 --> Output Class Initialized
INFO - 2023-02-28 04:37:43 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:43 --> Input Class Initialized
INFO - 2023-02-28 04:37:43 --> Language Class Initialized
INFO - 2023-02-28 04:37:43 --> Loader Class Initialized
INFO - 2023-02-28 04:37:43 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:43 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:43 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:43 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:43 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:43 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:43 --> Total execution time: 0.0234
INFO - 2023-02-28 04:37:43 --> Config Class Initialized
INFO - 2023-02-28 04:37:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:43 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:43 --> URI Class Initialized
INFO - 2023-02-28 04:37:43 --> Router Class Initialized
INFO - 2023-02-28 04:37:43 --> Output Class Initialized
INFO - 2023-02-28 04:37:43 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:43 --> Input Class Initialized
INFO - 2023-02-28 04:37:43 --> Language Class Initialized
INFO - 2023-02-28 04:37:43 --> Loader Class Initialized
INFO - 2023-02-28 04:37:43 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:43 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:43 --> Total execution time: 0.0415
INFO - 2023-02-28 04:37:43 --> Config Class Initialized
INFO - 2023-02-28 04:37:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:43 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:43 --> URI Class Initialized
INFO - 2023-02-28 04:37:43 --> Router Class Initialized
INFO - 2023-02-28 04:37:43 --> Output Class Initialized
INFO - 2023-02-28 04:37:43 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:43 --> Input Class Initialized
INFO - 2023-02-28 04:37:43 --> Language Class Initialized
INFO - 2023-02-28 04:37:43 --> Loader Class Initialized
INFO - 2023-02-28 04:37:43 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:43 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:43 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:43 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:43 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:43 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:43 --> Total execution time: 0.0216
INFO - 2023-02-28 04:37:43 --> Config Class Initialized
INFO - 2023-02-28 04:37:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:43 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:43 --> URI Class Initialized
INFO - 2023-02-28 04:37:43 --> Router Class Initialized
INFO - 2023-02-28 04:37:43 --> Output Class Initialized
INFO - 2023-02-28 04:37:43 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:43 --> Input Class Initialized
INFO - 2023-02-28 04:37:43 --> Language Class Initialized
INFO - 2023-02-28 04:37:43 --> Loader Class Initialized
INFO - 2023-02-28 04:37:43 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:43 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:43 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:43 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:43 --> Total execution time: 0.0538
INFO - 2023-02-28 04:37:43 --> Config Class Initialized
INFO - 2023-02-28 04:37:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:43 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:43 --> URI Class Initialized
INFO - 2023-02-28 04:37:43 --> Router Class Initialized
INFO - 2023-02-28 04:37:43 --> Output Class Initialized
INFO - 2023-02-28 04:37:43 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:43 --> Input Class Initialized
INFO - 2023-02-28 04:37:43 --> Language Class Initialized
INFO - 2023-02-28 04:37:43 --> Loader Class Initialized
INFO - 2023-02-28 04:37:43 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:43 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:43 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:43 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:43 --> Total execution time: 0.0617
INFO - 2023-02-28 04:37:44 --> Config Class Initialized
INFO - 2023-02-28 04:37:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:44 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:44 --> URI Class Initialized
INFO - 2023-02-28 04:37:44 --> Router Class Initialized
INFO - 2023-02-28 04:37:44 --> Output Class Initialized
INFO - 2023-02-28 04:37:44 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:44 --> Input Class Initialized
INFO - 2023-02-28 04:37:44 --> Language Class Initialized
INFO - 2023-02-28 04:37:44 --> Loader Class Initialized
INFO - 2023-02-28 04:37:44 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:44 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:44 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:44 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:44 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:44 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:44 --> Total execution time: 0.0374
INFO - 2023-02-28 04:37:44 --> Config Class Initialized
INFO - 2023-02-28 04:37:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:44 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:44 --> URI Class Initialized
INFO - 2023-02-28 04:37:44 --> Router Class Initialized
INFO - 2023-02-28 04:37:44 --> Output Class Initialized
INFO - 2023-02-28 04:37:44 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:44 --> Input Class Initialized
INFO - 2023-02-28 04:37:44 --> Language Class Initialized
INFO - 2023-02-28 04:37:44 --> Loader Class Initialized
INFO - 2023-02-28 04:37:44 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:44 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:44 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:44 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:44 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:44 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:44 --> Total execution time: 0.0192
INFO - 2023-02-28 04:37:45 --> Config Class Initialized
INFO - 2023-02-28 04:37:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:45 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:45 --> URI Class Initialized
INFO - 2023-02-28 04:37:45 --> Router Class Initialized
INFO - 2023-02-28 04:37:45 --> Output Class Initialized
INFO - 2023-02-28 04:37:45 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:45 --> Input Class Initialized
INFO - 2023-02-28 04:37:45 --> Language Class Initialized
INFO - 2023-02-28 04:37:45 --> Loader Class Initialized
INFO - 2023-02-28 04:37:45 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:45 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:45 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:45 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:45 --> Total execution time: 0.0194
INFO - 2023-02-28 04:37:46 --> Config Class Initialized
INFO - 2023-02-28 04:37:46 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:46 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:46 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:46 --> URI Class Initialized
INFO - 2023-02-28 04:37:46 --> Router Class Initialized
INFO - 2023-02-28 04:37:46 --> Output Class Initialized
INFO - 2023-02-28 04:37:46 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:46 --> Input Class Initialized
INFO - 2023-02-28 04:37:46 --> Language Class Initialized
INFO - 2023-02-28 04:37:46 --> Loader Class Initialized
INFO - 2023-02-28 04:37:46 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:46 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:46 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:46 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:46 --> Total execution time: 0.0239
INFO - 2023-02-28 04:37:46 --> Config Class Initialized
INFO - 2023-02-28 04:37:46 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:46 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:46 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:46 --> URI Class Initialized
INFO - 2023-02-28 04:37:46 --> Router Class Initialized
INFO - 2023-02-28 04:37:46 --> Output Class Initialized
INFO - 2023-02-28 04:37:46 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:46 --> Input Class Initialized
INFO - 2023-02-28 04:37:46 --> Language Class Initialized
INFO - 2023-02-28 04:37:46 --> Loader Class Initialized
INFO - 2023-02-28 04:37:46 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:46 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:46 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:46 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:46 --> Total execution time: 0.0195
INFO - 2023-02-28 04:37:46 --> Config Class Initialized
INFO - 2023-02-28 04:37:46 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:46 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:46 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:46 --> URI Class Initialized
INFO - 2023-02-28 04:37:46 --> Router Class Initialized
INFO - 2023-02-28 04:37:46 --> Output Class Initialized
INFO - 2023-02-28 04:37:46 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:46 --> Input Class Initialized
INFO - 2023-02-28 04:37:46 --> Language Class Initialized
INFO - 2023-02-28 04:37:46 --> Loader Class Initialized
INFO - 2023-02-28 04:37:46 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:46 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:46 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:46 --> Total execution time: 0.0160
INFO - 2023-02-28 04:37:46 --> Config Class Initialized
INFO - 2023-02-28 04:37:46 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:46 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:46 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:46 --> URI Class Initialized
INFO - 2023-02-28 04:37:46 --> Router Class Initialized
INFO - 2023-02-28 04:37:46 --> Output Class Initialized
INFO - 2023-02-28 04:37:46 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:46 --> Input Class Initialized
INFO - 2023-02-28 04:37:46 --> Language Class Initialized
INFO - 2023-02-28 04:37:46 --> Loader Class Initialized
INFO - 2023-02-28 04:37:46 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:46 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:46 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:46 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:46 --> Total execution time: 0.0203
INFO - 2023-02-28 04:37:46 --> Config Class Initialized
INFO - 2023-02-28 04:37:46 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:46 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:46 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:46 --> URI Class Initialized
INFO - 2023-02-28 04:37:46 --> Router Class Initialized
INFO - 2023-02-28 04:37:46 --> Output Class Initialized
INFO - 2023-02-28 04:37:46 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:46 --> Input Class Initialized
INFO - 2023-02-28 04:37:46 --> Language Class Initialized
INFO - 2023-02-28 04:37:46 --> Loader Class Initialized
INFO - 2023-02-28 04:37:46 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:46 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:46 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:46 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:46 --> Total execution time: 0.0230
INFO - 2023-02-28 04:37:47 --> Config Class Initialized
INFO - 2023-02-28 04:37:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:47 --> URI Class Initialized
INFO - 2023-02-28 04:37:47 --> Router Class Initialized
INFO - 2023-02-28 04:37:47 --> Output Class Initialized
INFO - 2023-02-28 04:37:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:47 --> Input Class Initialized
INFO - 2023-02-28 04:37:47 --> Language Class Initialized
INFO - 2023-02-28 04:37:47 --> Loader Class Initialized
INFO - 2023-02-28 04:37:47 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:47 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:47 --> Total execution time: 0.0684
INFO - 2023-02-28 04:37:47 --> Config Class Initialized
INFO - 2023-02-28 04:37:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:47 --> URI Class Initialized
INFO - 2023-02-28 04:37:47 --> Router Class Initialized
INFO - 2023-02-28 04:37:47 --> Output Class Initialized
INFO - 2023-02-28 04:37:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:47 --> Input Class Initialized
INFO - 2023-02-28 04:37:47 --> Language Class Initialized
INFO - 2023-02-28 04:37:47 --> Loader Class Initialized
INFO - 2023-02-28 04:37:47 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:47 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:47 --> Total execution time: 0.0439
INFO - 2023-02-28 04:37:48 --> Config Class Initialized
INFO - 2023-02-28 04:37:48 --> Config Class Initialized
INFO - 2023-02-28 04:37:48 --> Hooks Class Initialized
INFO - 2023-02-28 04:37:48 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:37:48 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:48 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:48 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:48 --> URI Class Initialized
INFO - 2023-02-28 04:37:48 --> URI Class Initialized
INFO - 2023-02-28 04:37:48 --> Router Class Initialized
INFO - 2023-02-28 04:37:48 --> Router Class Initialized
INFO - 2023-02-28 04:37:48 --> Output Class Initialized
INFO - 2023-02-28 04:37:48 --> Output Class Initialized
INFO - 2023-02-28 04:37:48 --> Security Class Initialized
INFO - 2023-02-28 04:37:48 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:48 --> Input Class Initialized
INFO - 2023-02-28 04:37:48 --> Input Class Initialized
INFO - 2023-02-28 04:37:48 --> Language Class Initialized
INFO - 2023-02-28 04:37:48 --> Language Class Initialized
INFO - 2023-02-28 04:37:48 --> Loader Class Initialized
INFO - 2023-02-28 04:37:48 --> Loader Class Initialized
INFO - 2023-02-28 04:37:48 --> Controller Class Initialized
INFO - 2023-02-28 04:37:48 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:48 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:48 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:48 --> Total execution time: 0.0045
INFO - 2023-02-28 04:37:48 --> Config Class Initialized
INFO - 2023-02-28 04:37:48 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:48 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:48 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:48 --> URI Class Initialized
INFO - 2023-02-28 04:37:48 --> Router Class Initialized
INFO - 2023-02-28 04:37:48 --> Output Class Initialized
INFO - 2023-02-28 04:37:48 --> Security Class Initialized
DEBUG - 2023-02-28 04:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:48 --> Input Class Initialized
INFO - 2023-02-28 04:37:48 --> Language Class Initialized
INFO - 2023-02-28 04:37:48 --> Loader Class Initialized
INFO - 2023-02-28 04:37:48 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:48 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:48 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:48 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:48 --> Total execution time: 0.0152
INFO - 2023-02-28 04:37:48 --> Model "Login_model" initialized
INFO - 2023-02-28 04:37:48 --> Config Class Initialized
INFO - 2023-02-28 04:37:48 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:37:48 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:37:48 --> Utf8 Class Initialized
INFO - 2023-02-28 04:37:48 --> URI Class Initialized
INFO - 2023-02-28 04:37:48 --> Router Class Initialized
INFO - 2023-02-28 04:37:48 --> Output Class Initialized
INFO - 2023-02-28 04:37:48 --> Security Class Initialized
INFO - 2023-02-28 04:37:48 --> Database Driver Class Initialized
DEBUG - 2023-02-28 04:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:37:48 --> Input Class Initialized
INFO - 2023-02-28 04:37:48 --> Language Class Initialized
INFO - 2023-02-28 04:37:48 --> Loader Class Initialized
INFO - 2023-02-28 04:37:48 --> Controller Class Initialized
DEBUG - 2023-02-28 04:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:37:48 --> Database Driver Class Initialized
INFO - 2023-02-28 04:37:48 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:49 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:49 --> Total execution time: 0.0224
INFO - 2023-02-28 04:37:49 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:37:49 --> Final output sent to browser
DEBUG - 2023-02-28 04:37:49 --> Total execution time: 0.0560
INFO - 2023-02-28 04:38:06 --> Config Class Initialized
INFO - 2023-02-28 04:38:06 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:38:06 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:38:06 --> Utf8 Class Initialized
INFO - 2023-02-28 04:38:06 --> URI Class Initialized
INFO - 2023-02-28 04:38:06 --> Router Class Initialized
INFO - 2023-02-28 04:38:06 --> Output Class Initialized
INFO - 2023-02-28 04:38:06 --> Security Class Initialized
DEBUG - 2023-02-28 04:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:38:06 --> Input Class Initialized
INFO - 2023-02-28 04:38:06 --> Language Class Initialized
INFO - 2023-02-28 04:38:06 --> Loader Class Initialized
INFO - 2023-02-28 04:38:06 --> Controller Class Initialized
DEBUG - 2023-02-28 04:38:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:38:06 --> Database Driver Class Initialized
INFO - 2023-02-28 04:38:06 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:38:06 --> Final output sent to browser
DEBUG - 2023-02-28 04:38:06 --> Total execution time: 0.0442
INFO - 2023-02-28 04:38:06 --> Config Class Initialized
INFO - 2023-02-28 04:38:06 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:38:06 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:38:06 --> Utf8 Class Initialized
INFO - 2023-02-28 04:38:06 --> URI Class Initialized
INFO - 2023-02-28 04:38:06 --> Router Class Initialized
INFO - 2023-02-28 04:38:06 --> Output Class Initialized
INFO - 2023-02-28 04:38:06 --> Security Class Initialized
DEBUG - 2023-02-28 04:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:38:06 --> Input Class Initialized
INFO - 2023-02-28 04:38:06 --> Language Class Initialized
INFO - 2023-02-28 04:38:06 --> Loader Class Initialized
INFO - 2023-02-28 04:38:06 --> Controller Class Initialized
DEBUG - 2023-02-28 04:38:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:38:06 --> Database Driver Class Initialized
INFO - 2023-02-28 04:38:06 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:38:06 --> Final output sent to browser
DEBUG - 2023-02-28 04:38:06 --> Total execution time: 0.0402
INFO - 2023-02-28 04:38:20 --> Config Class Initialized
INFO - 2023-02-28 04:38:20 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:38:20 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:38:20 --> Utf8 Class Initialized
INFO - 2023-02-28 04:38:20 --> URI Class Initialized
INFO - 2023-02-28 04:38:20 --> Router Class Initialized
INFO - 2023-02-28 04:38:20 --> Output Class Initialized
INFO - 2023-02-28 04:38:20 --> Security Class Initialized
DEBUG - 2023-02-28 04:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:38:20 --> Input Class Initialized
INFO - 2023-02-28 04:38:20 --> Language Class Initialized
INFO - 2023-02-28 04:38:20 --> Loader Class Initialized
INFO - 2023-02-28 04:38:20 --> Controller Class Initialized
INFO - 2023-02-28 04:38:20 --> Helper loaded: form_helper
INFO - 2023-02-28 04:38:20 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:38:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:38:20 --> Model "Change_model" initialized
INFO - 2023-02-28 04:38:20 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:38:20 --> Final output sent to browser
DEBUG - 2023-02-28 04:38:20 --> Total execution time: 0.0218
INFO - 2023-02-28 04:38:20 --> Config Class Initialized
INFO - 2023-02-28 04:38:20 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:38:20 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:38:20 --> Utf8 Class Initialized
INFO - 2023-02-28 04:38:20 --> URI Class Initialized
INFO - 2023-02-28 04:38:20 --> Router Class Initialized
INFO - 2023-02-28 04:38:20 --> Output Class Initialized
INFO - 2023-02-28 04:38:20 --> Security Class Initialized
DEBUG - 2023-02-28 04:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:38:20 --> Input Class Initialized
INFO - 2023-02-28 04:38:20 --> Language Class Initialized
INFO - 2023-02-28 04:38:20 --> Loader Class Initialized
INFO - 2023-02-28 04:38:20 --> Controller Class Initialized
INFO - 2023-02-28 04:38:20 --> Helper loaded: form_helper
INFO - 2023-02-28 04:38:20 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:38:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:38:20 --> Final output sent to browser
DEBUG - 2023-02-28 04:38:20 --> Total execution time: 0.0021
INFO - 2023-02-28 04:38:20 --> Config Class Initialized
INFO - 2023-02-28 04:38:20 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:38:20 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:38:20 --> Utf8 Class Initialized
INFO - 2023-02-28 04:38:20 --> URI Class Initialized
INFO - 2023-02-28 04:38:20 --> Router Class Initialized
INFO - 2023-02-28 04:38:20 --> Output Class Initialized
INFO - 2023-02-28 04:38:20 --> Security Class Initialized
DEBUG - 2023-02-28 04:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:38:20 --> Input Class Initialized
INFO - 2023-02-28 04:38:20 --> Language Class Initialized
INFO - 2023-02-28 04:38:20 --> Loader Class Initialized
INFO - 2023-02-28 04:38:20 --> Controller Class Initialized
INFO - 2023-02-28 04:38:20 --> Helper loaded: form_helper
INFO - 2023-02-28 04:38:20 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:38:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:38:20 --> Database Driver Class Initialized
INFO - 2023-02-28 04:38:20 --> Model "Login_model" initialized
INFO - 2023-02-28 04:38:20 --> Final output sent to browser
DEBUG - 2023-02-28 04:38:20 --> Total execution time: 0.0145
INFO - 2023-02-28 04:38:20 --> Config Class Initialized
INFO - 2023-02-28 04:38:20 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:38:20 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:38:20 --> Utf8 Class Initialized
INFO - 2023-02-28 04:38:20 --> URI Class Initialized
INFO - 2023-02-28 04:38:20 --> Router Class Initialized
INFO - 2023-02-28 04:38:20 --> Output Class Initialized
INFO - 2023-02-28 04:38:20 --> Security Class Initialized
DEBUG - 2023-02-28 04:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:38:20 --> Input Class Initialized
INFO - 2023-02-28 04:38:20 --> Language Class Initialized
INFO - 2023-02-28 04:38:20 --> Loader Class Initialized
INFO - 2023-02-28 04:38:20 --> Controller Class Initialized
DEBUG - 2023-02-28 04:38:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:38:20 --> Database Driver Class Initialized
INFO - 2023-02-28 04:38:20 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:38:20 --> Final output sent to browser
DEBUG - 2023-02-28 04:38:20 --> Total execution time: 0.0114
INFO - 2023-02-28 04:38:20 --> Config Class Initialized
INFO - 2023-02-28 04:38:20 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:38:20 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:38:20 --> Utf8 Class Initialized
INFO - 2023-02-28 04:38:20 --> URI Class Initialized
INFO - 2023-02-28 04:38:20 --> Router Class Initialized
INFO - 2023-02-28 04:38:20 --> Output Class Initialized
INFO - 2023-02-28 04:38:20 --> Security Class Initialized
DEBUG - 2023-02-28 04:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:38:20 --> Input Class Initialized
INFO - 2023-02-28 04:38:20 --> Language Class Initialized
INFO - 2023-02-28 04:38:20 --> Loader Class Initialized
INFO - 2023-02-28 04:38:20 --> Controller Class Initialized
DEBUG - 2023-02-28 04:38:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:38:20 --> Database Driver Class Initialized
INFO - 2023-02-28 04:38:20 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:38:20 --> Final output sent to browser
DEBUG - 2023-02-28 04:38:20 --> Total execution time: 0.0114
INFO - 2023-02-28 04:38:21 --> Config Class Initialized
INFO - 2023-02-28 04:38:21 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:38:21 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:38:21 --> Utf8 Class Initialized
INFO - 2023-02-28 04:38:21 --> URI Class Initialized
INFO - 2023-02-28 04:38:21 --> Router Class Initialized
INFO - 2023-02-28 04:38:21 --> Output Class Initialized
INFO - 2023-02-28 04:38:21 --> Security Class Initialized
DEBUG - 2023-02-28 04:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:38:21 --> Input Class Initialized
INFO - 2023-02-28 04:38:21 --> Language Class Initialized
INFO - 2023-02-28 04:38:21 --> Loader Class Initialized
INFO - 2023-02-28 04:38:21 --> Controller Class Initialized
DEBUG - 2023-02-28 04:38:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:38:21 --> Database Driver Class Initialized
INFO - 2023-02-28 04:38:21 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:38:21 --> Database Driver Class Initialized
INFO - 2023-02-28 04:38:21 --> Model "Login_model" initialized
INFO - 2023-02-28 04:38:21 --> Final output sent to browser
DEBUG - 2023-02-28 04:38:21 --> Total execution time: 0.1004
INFO - 2023-02-28 04:38:21 --> Config Class Initialized
INFO - 2023-02-28 04:38:21 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:38:21 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:38:21 --> Utf8 Class Initialized
INFO - 2023-02-28 04:38:21 --> URI Class Initialized
INFO - 2023-02-28 04:38:21 --> Router Class Initialized
INFO - 2023-02-28 04:38:21 --> Output Class Initialized
INFO - 2023-02-28 04:38:21 --> Security Class Initialized
DEBUG - 2023-02-28 04:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:38:21 --> Input Class Initialized
INFO - 2023-02-28 04:38:21 --> Language Class Initialized
INFO - 2023-02-28 04:38:21 --> Loader Class Initialized
INFO - 2023-02-28 04:38:21 --> Controller Class Initialized
DEBUG - 2023-02-28 04:38:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:38:21 --> Database Driver Class Initialized
INFO - 2023-02-28 04:38:21 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:38:21 --> Database Driver Class Initialized
INFO - 2023-02-28 04:38:21 --> Model "Login_model" initialized
INFO - 2023-02-28 04:38:21 --> Final output sent to browser
DEBUG - 2023-02-28 04:38:21 --> Total execution time: 0.0361
INFO - 2023-02-28 04:39:52 --> Config Class Initialized
INFO - 2023-02-28 04:39:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:39:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:39:53 --> Utf8 Class Initialized
INFO - 2023-02-28 04:39:53 --> URI Class Initialized
INFO - 2023-02-28 04:39:53 --> Router Class Initialized
INFO - 2023-02-28 04:39:53 --> Output Class Initialized
INFO - 2023-02-28 04:39:53 --> Security Class Initialized
DEBUG - 2023-02-28 04:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:39:53 --> Input Class Initialized
INFO - 2023-02-28 04:39:53 --> Language Class Initialized
INFO - 2023-02-28 04:39:53 --> Loader Class Initialized
INFO - 2023-02-28 04:39:53 --> Controller Class Initialized
INFO - 2023-02-28 04:39:53 --> Helper loaded: form_helper
INFO - 2023-02-28 04:39:53 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:39:53 --> Model "Change_model" initialized
INFO - 2023-02-28 04:39:53 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:39:53 --> Final output sent to browser
DEBUG - 2023-02-28 04:39:53 --> Total execution time: 0.0236
INFO - 2023-02-28 04:39:53 --> Config Class Initialized
INFO - 2023-02-28 04:39:53 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:39:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:39:53 --> Utf8 Class Initialized
INFO - 2023-02-28 04:39:53 --> URI Class Initialized
INFO - 2023-02-28 04:39:53 --> Router Class Initialized
INFO - 2023-02-28 04:39:53 --> Output Class Initialized
INFO - 2023-02-28 04:39:53 --> Security Class Initialized
DEBUG - 2023-02-28 04:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:39:53 --> Input Class Initialized
INFO - 2023-02-28 04:39:53 --> Language Class Initialized
INFO - 2023-02-28 04:39:53 --> Loader Class Initialized
INFO - 2023-02-28 04:39:53 --> Controller Class Initialized
INFO - 2023-02-28 04:39:53 --> Helper loaded: form_helper
INFO - 2023-02-28 04:39:53 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:39:53 --> Final output sent to browser
DEBUG - 2023-02-28 04:39:53 --> Total execution time: 0.0020
INFO - 2023-02-28 04:39:53 --> Config Class Initialized
INFO - 2023-02-28 04:39:53 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:39:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:39:53 --> Utf8 Class Initialized
INFO - 2023-02-28 04:39:53 --> URI Class Initialized
INFO - 2023-02-28 04:39:53 --> Router Class Initialized
INFO - 2023-02-28 04:39:53 --> Output Class Initialized
INFO - 2023-02-28 04:39:53 --> Security Class Initialized
DEBUG - 2023-02-28 04:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:39:53 --> Input Class Initialized
INFO - 2023-02-28 04:39:53 --> Language Class Initialized
INFO - 2023-02-28 04:39:53 --> Loader Class Initialized
INFO - 2023-02-28 04:39:53 --> Controller Class Initialized
INFO - 2023-02-28 04:39:53 --> Helper loaded: form_helper
INFO - 2023-02-28 04:39:53 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:39:53 --> Database Driver Class Initialized
INFO - 2023-02-28 04:39:53 --> Model "Login_model" initialized
INFO - 2023-02-28 04:39:53 --> Final output sent to browser
DEBUG - 2023-02-28 04:39:53 --> Total execution time: 0.0138
INFO - 2023-02-28 04:39:53 --> Config Class Initialized
INFO - 2023-02-28 04:39:53 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:39:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:39:53 --> Utf8 Class Initialized
INFO - 2023-02-28 04:39:53 --> URI Class Initialized
INFO - 2023-02-28 04:39:53 --> Router Class Initialized
INFO - 2023-02-28 04:39:53 --> Output Class Initialized
INFO - 2023-02-28 04:39:53 --> Security Class Initialized
DEBUG - 2023-02-28 04:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:39:53 --> Input Class Initialized
INFO - 2023-02-28 04:39:53 --> Language Class Initialized
INFO - 2023-02-28 04:39:53 --> Loader Class Initialized
INFO - 2023-02-28 04:39:53 --> Controller Class Initialized
DEBUG - 2023-02-28 04:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:39:53 --> Database Driver Class Initialized
INFO - 2023-02-28 04:39:53 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:39:53 --> Final output sent to browser
DEBUG - 2023-02-28 04:39:53 --> Total execution time: 0.0513
INFO - 2023-02-28 04:39:53 --> Config Class Initialized
INFO - 2023-02-28 04:39:53 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:39:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:39:53 --> Utf8 Class Initialized
INFO - 2023-02-28 04:39:53 --> URI Class Initialized
INFO - 2023-02-28 04:39:53 --> Router Class Initialized
INFO - 2023-02-28 04:39:53 --> Output Class Initialized
INFO - 2023-02-28 04:39:53 --> Security Class Initialized
DEBUG - 2023-02-28 04:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:39:53 --> Input Class Initialized
INFO - 2023-02-28 04:39:53 --> Language Class Initialized
INFO - 2023-02-28 04:39:53 --> Loader Class Initialized
INFO - 2023-02-28 04:39:53 --> Controller Class Initialized
DEBUG - 2023-02-28 04:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:39:53 --> Database Driver Class Initialized
INFO - 2023-02-28 04:39:53 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:39:53 --> Final output sent to browser
DEBUG - 2023-02-28 04:39:53 --> Total execution time: 0.0148
INFO - 2023-02-28 04:39:53 --> Config Class Initialized
INFO - 2023-02-28 04:39:53 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:39:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:39:53 --> Utf8 Class Initialized
INFO - 2023-02-28 04:39:53 --> URI Class Initialized
INFO - 2023-02-28 04:39:53 --> Router Class Initialized
INFO - 2023-02-28 04:39:53 --> Output Class Initialized
INFO - 2023-02-28 04:39:53 --> Security Class Initialized
DEBUG - 2023-02-28 04:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:39:53 --> Input Class Initialized
INFO - 2023-02-28 04:39:53 --> Language Class Initialized
INFO - 2023-02-28 04:39:53 --> Loader Class Initialized
INFO - 2023-02-28 04:39:53 --> Controller Class Initialized
DEBUG - 2023-02-28 04:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:39:53 --> Database Driver Class Initialized
INFO - 2023-02-28 04:39:53 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:39:53 --> Database Driver Class Initialized
INFO - 2023-02-28 04:39:53 --> Model "Login_model" initialized
INFO - 2023-02-28 04:39:53 --> Final output sent to browser
DEBUG - 2023-02-28 04:39:53 --> Total execution time: 0.0800
INFO - 2023-02-28 04:39:53 --> Config Class Initialized
INFO - 2023-02-28 04:39:53 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:39:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:39:53 --> Utf8 Class Initialized
INFO - 2023-02-28 04:39:53 --> URI Class Initialized
INFO - 2023-02-28 04:39:53 --> Router Class Initialized
INFO - 2023-02-28 04:39:53 --> Output Class Initialized
INFO - 2023-02-28 04:39:53 --> Security Class Initialized
DEBUG - 2023-02-28 04:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:39:53 --> Input Class Initialized
INFO - 2023-02-28 04:39:53 --> Language Class Initialized
INFO - 2023-02-28 04:39:53 --> Loader Class Initialized
INFO - 2023-02-28 04:39:53 --> Controller Class Initialized
DEBUG - 2023-02-28 04:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:39:53 --> Database Driver Class Initialized
INFO - 2023-02-28 04:39:53 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:39:53 --> Database Driver Class Initialized
INFO - 2023-02-28 04:39:53 --> Model "Login_model" initialized
INFO - 2023-02-28 04:39:53 --> Final output sent to browser
DEBUG - 2023-02-28 04:39:53 --> Total execution time: 0.0346
INFO - 2023-02-28 04:39:59 --> Config Class Initialized
INFO - 2023-02-28 04:39:59 --> Config Class Initialized
INFO - 2023-02-28 04:39:59 --> Hooks Class Initialized
INFO - 2023-02-28 04:39:59 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:39:59 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:39:59 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:39:59 --> Utf8 Class Initialized
INFO - 2023-02-28 04:39:59 --> Utf8 Class Initialized
INFO - 2023-02-28 04:39:59 --> URI Class Initialized
INFO - 2023-02-28 04:39:59 --> URI Class Initialized
INFO - 2023-02-28 04:39:59 --> Router Class Initialized
INFO - 2023-02-28 04:39:59 --> Router Class Initialized
INFO - 2023-02-28 04:39:59 --> Output Class Initialized
INFO - 2023-02-28 04:39:59 --> Output Class Initialized
INFO - 2023-02-28 04:39:59 --> Security Class Initialized
INFO - 2023-02-28 04:39:59 --> Security Class Initialized
DEBUG - 2023-02-28 04:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:39:59 --> Input Class Initialized
INFO - 2023-02-28 04:39:59 --> Input Class Initialized
INFO - 2023-02-28 04:39:59 --> Language Class Initialized
INFO - 2023-02-28 04:39:59 --> Language Class Initialized
INFO - 2023-02-28 04:39:59 --> Loader Class Initialized
INFO - 2023-02-28 04:39:59 --> Loader Class Initialized
INFO - 2023-02-28 04:39:59 --> Controller Class Initialized
INFO - 2023-02-28 04:39:59 --> Controller Class Initialized
DEBUG - 2023-02-28 04:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:39:59 --> Final output sent to browser
DEBUG - 2023-02-28 04:39:59 --> Total execution time: 0.0049
INFO - 2023-02-28 04:39:59 --> Database Driver Class Initialized
INFO - 2023-02-28 04:39:59 --> Config Class Initialized
INFO - 2023-02-28 04:39:59 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:39:59 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:39:59 --> Utf8 Class Initialized
INFO - 2023-02-28 04:39:59 --> URI Class Initialized
INFO - 2023-02-28 04:39:59 --> Router Class Initialized
INFO - 2023-02-28 04:39:59 --> Output Class Initialized
INFO - 2023-02-28 04:39:59 --> Security Class Initialized
DEBUG - 2023-02-28 04:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:39:59 --> Input Class Initialized
INFO - 2023-02-28 04:39:59 --> Language Class Initialized
INFO - 2023-02-28 04:39:59 --> Loader Class Initialized
INFO - 2023-02-28 04:39:59 --> Controller Class Initialized
DEBUG - 2023-02-28 04:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:39:59 --> Database Driver Class Initialized
INFO - 2023-02-28 04:39:59 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:39:59 --> Model "Login_model" initialized
INFO - 2023-02-28 04:39:59 --> Final output sent to browser
DEBUG - 2023-02-28 04:39:59 --> Total execution time: 0.0171
INFO - 2023-02-28 04:39:59 --> Database Driver Class Initialized
INFO - 2023-02-28 04:39:59 --> Config Class Initialized
INFO - 2023-02-28 04:39:59 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:39:59 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:39:59 --> Utf8 Class Initialized
INFO - 2023-02-28 04:39:59 --> URI Class Initialized
INFO - 2023-02-28 04:39:59 --> Router Class Initialized
INFO - 2023-02-28 04:39:59 --> Output Class Initialized
INFO - 2023-02-28 04:39:59 --> Security Class Initialized
DEBUG - 2023-02-28 04:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:39:59 --> Input Class Initialized
INFO - 2023-02-28 04:39:59 --> Language Class Initialized
INFO - 2023-02-28 04:39:59 --> Loader Class Initialized
INFO - 2023-02-28 04:39:59 --> Controller Class Initialized
DEBUG - 2023-02-28 04:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:39:59 --> Database Driver Class Initialized
INFO - 2023-02-28 04:39:59 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:39:59 --> Final output sent to browser
DEBUG - 2023-02-28 04:39:59 --> Total execution time: 0.0187
INFO - 2023-02-28 04:39:59 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:39:59 --> Final output sent to browser
DEBUG - 2023-02-28 04:39:59 --> Total execution time: 0.0519
INFO - 2023-02-28 04:40:02 --> Config Class Initialized
INFO - 2023-02-28 04:40:02 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:02 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:02 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:02 --> URI Class Initialized
INFO - 2023-02-28 04:40:02 --> Router Class Initialized
INFO - 2023-02-28 04:40:02 --> Output Class Initialized
INFO - 2023-02-28 04:40:02 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:02 --> Input Class Initialized
INFO - 2023-02-28 04:40:02 --> Language Class Initialized
INFO - 2023-02-28 04:40:02 --> Loader Class Initialized
INFO - 2023-02-28 04:40:02 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:02 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:02 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:02 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:02 --> Total execution time: 0.0496
INFO - 2023-02-28 04:40:02 --> Config Class Initialized
INFO - 2023-02-28 04:40:02 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:02 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:02 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:02 --> URI Class Initialized
INFO - 2023-02-28 04:40:02 --> Router Class Initialized
INFO - 2023-02-28 04:40:02 --> Output Class Initialized
INFO - 2023-02-28 04:40:02 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:02 --> Input Class Initialized
INFO - 2023-02-28 04:40:02 --> Language Class Initialized
INFO - 2023-02-28 04:40:02 --> Loader Class Initialized
INFO - 2023-02-28 04:40:02 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:02 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:02 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:02 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:02 --> Total execution time: 0.0450
INFO - 2023-02-28 04:40:05 --> Config Class Initialized
INFO - 2023-02-28 04:40:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:05 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:05 --> URI Class Initialized
INFO - 2023-02-28 04:40:05 --> Router Class Initialized
INFO - 2023-02-28 04:40:05 --> Output Class Initialized
INFO - 2023-02-28 04:40:05 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:05 --> Input Class Initialized
INFO - 2023-02-28 04:40:05 --> Language Class Initialized
INFO - 2023-02-28 04:40:05 --> Loader Class Initialized
INFO - 2023-02-28 04:40:05 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:05 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:05 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:05 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:05 --> Total execution time: 0.0151
INFO - 2023-02-28 04:40:05 --> Config Class Initialized
INFO - 2023-02-28 04:40:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:05 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:05 --> URI Class Initialized
INFO - 2023-02-28 04:40:05 --> Router Class Initialized
INFO - 2023-02-28 04:40:05 --> Output Class Initialized
INFO - 2023-02-28 04:40:05 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:05 --> Input Class Initialized
INFO - 2023-02-28 04:40:05 --> Language Class Initialized
INFO - 2023-02-28 04:40:05 --> Loader Class Initialized
INFO - 2023-02-28 04:40:05 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:05 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:05 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:05 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:05 --> Total execution time: 0.0110
INFO - 2023-02-28 04:40:10 --> Config Class Initialized
INFO - 2023-02-28 04:40:10 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:10 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:10 --> URI Class Initialized
INFO - 2023-02-28 04:40:10 --> Router Class Initialized
INFO - 2023-02-28 04:40:10 --> Output Class Initialized
INFO - 2023-02-28 04:40:10 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:10 --> Input Class Initialized
INFO - 2023-02-28 04:40:10 --> Language Class Initialized
INFO - 2023-02-28 04:40:10 --> Loader Class Initialized
INFO - 2023-02-28 04:40:10 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:10 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:10 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:10 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:10 --> Total execution time: 0.0474
INFO - 2023-02-28 04:40:10 --> Config Class Initialized
INFO - 2023-02-28 04:40:10 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:10 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:10 --> URI Class Initialized
INFO - 2023-02-28 04:40:10 --> Router Class Initialized
INFO - 2023-02-28 04:40:10 --> Output Class Initialized
INFO - 2023-02-28 04:40:10 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:10 --> Input Class Initialized
INFO - 2023-02-28 04:40:10 --> Language Class Initialized
INFO - 2023-02-28 04:40:10 --> Loader Class Initialized
INFO - 2023-02-28 04:40:10 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:10 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:10 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:10 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:10 --> Total execution time: 0.0445
INFO - 2023-02-28 04:40:12 --> Config Class Initialized
INFO - 2023-02-28 04:40:12 --> Config Class Initialized
INFO - 2023-02-28 04:40:12 --> Hooks Class Initialized
INFO - 2023-02-28 04:40:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:12 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:40:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:12 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:12 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:12 --> URI Class Initialized
INFO - 2023-02-28 04:40:12 --> URI Class Initialized
INFO - 2023-02-28 04:40:12 --> Router Class Initialized
INFO - 2023-02-28 04:40:12 --> Router Class Initialized
INFO - 2023-02-28 04:40:12 --> Output Class Initialized
INFO - 2023-02-28 04:40:12 --> Output Class Initialized
INFO - 2023-02-28 04:40:12 --> Security Class Initialized
INFO - 2023-02-28 04:40:12 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:12 --> Input Class Initialized
INFO - 2023-02-28 04:40:12 --> Input Class Initialized
INFO - 2023-02-28 04:40:12 --> Language Class Initialized
INFO - 2023-02-28 04:40:12 --> Language Class Initialized
INFO - 2023-02-28 04:40:12 --> Loader Class Initialized
INFO - 2023-02-28 04:40:12 --> Loader Class Initialized
INFO - 2023-02-28 04:40:12 --> Controller Class Initialized
INFO - 2023-02-28 04:40:12 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:40:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:12 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:12 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:12 --> Total execution time: 0.0043
INFO - 2023-02-28 04:40:12 --> Config Class Initialized
INFO - 2023-02-28 04:40:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:12 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:12 --> URI Class Initialized
INFO - 2023-02-28 04:40:12 --> Router Class Initialized
INFO - 2023-02-28 04:40:12 --> Output Class Initialized
INFO - 2023-02-28 04:40:12 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:12 --> Input Class Initialized
INFO - 2023-02-28 04:40:12 --> Language Class Initialized
INFO - 2023-02-28 04:40:12 --> Loader Class Initialized
INFO - 2023-02-28 04:40:12 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:12 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:12 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:12 --> Model "Login_model" initialized
INFO - 2023-02-28 04:40:12 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:12 --> Total execution time: 0.0166
INFO - 2023-02-28 04:40:12 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:12 --> Config Class Initialized
INFO - 2023-02-28 04:40:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:12 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:12 --> URI Class Initialized
INFO - 2023-02-28 04:40:12 --> Router Class Initialized
INFO - 2023-02-28 04:40:12 --> Output Class Initialized
INFO - 2023-02-28 04:40:12 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:12 --> Input Class Initialized
INFO - 2023-02-28 04:40:12 --> Language Class Initialized
INFO - 2023-02-28 04:40:12 --> Loader Class Initialized
INFO - 2023-02-28 04:40:12 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:12 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:12 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:12 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:12 --> Total execution time: 0.0214
INFO - 2023-02-28 04:40:12 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:12 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:12 --> Total execution time: 0.0563
INFO - 2023-02-28 04:40:24 --> Config Class Initialized
INFO - 2023-02-28 04:40:24 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:24 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:24 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:24 --> URI Class Initialized
INFO - 2023-02-28 04:40:24 --> Router Class Initialized
INFO - 2023-02-28 04:40:24 --> Output Class Initialized
INFO - 2023-02-28 04:40:24 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:24 --> Input Class Initialized
INFO - 2023-02-28 04:40:24 --> Language Class Initialized
INFO - 2023-02-28 04:40:24 --> Loader Class Initialized
INFO - 2023-02-28 04:40:24 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:24 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:24 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:24 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:24 --> Model "Login_model" initialized
INFO - 2023-02-28 04:40:24 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:24 --> Total execution time: 0.0513
INFO - 2023-02-28 04:40:24 --> Config Class Initialized
INFO - 2023-02-28 04:40:24 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:24 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:24 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:24 --> URI Class Initialized
INFO - 2023-02-28 04:40:24 --> Router Class Initialized
INFO - 2023-02-28 04:40:24 --> Output Class Initialized
INFO - 2023-02-28 04:40:24 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:24 --> Input Class Initialized
INFO - 2023-02-28 04:40:24 --> Language Class Initialized
INFO - 2023-02-28 04:40:24 --> Loader Class Initialized
INFO - 2023-02-28 04:40:24 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:24 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:24 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:24 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:24 --> Model "Login_model" initialized
INFO - 2023-02-28 04:40:25 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:25 --> Total execution time: 0.0426
INFO - 2023-02-28 04:40:35 --> Config Class Initialized
INFO - 2023-02-28 04:40:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:35 --> URI Class Initialized
INFO - 2023-02-28 04:40:35 --> Router Class Initialized
INFO - 2023-02-28 04:40:35 --> Output Class Initialized
INFO - 2023-02-28 04:40:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:35 --> Input Class Initialized
INFO - 2023-02-28 04:40:35 --> Language Class Initialized
INFO - 2023-02-28 04:40:35 --> Loader Class Initialized
INFO - 2023-02-28 04:40:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:35 --> Total execution time: 0.0464
INFO - 2023-02-28 04:40:35 --> Config Class Initialized
INFO - 2023-02-28 04:40:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:35 --> URI Class Initialized
INFO - 2023-02-28 04:40:35 --> Router Class Initialized
INFO - 2023-02-28 04:40:35 --> Output Class Initialized
INFO - 2023-02-28 04:40:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:35 --> Input Class Initialized
INFO - 2023-02-28 04:40:35 --> Language Class Initialized
INFO - 2023-02-28 04:40:35 --> Loader Class Initialized
INFO - 2023-02-28 04:40:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:35 --> Total execution time: 0.0459
INFO - 2023-02-28 04:40:38 --> Config Class Initialized
INFO - 2023-02-28 04:40:38 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:38 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:38 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:38 --> URI Class Initialized
INFO - 2023-02-28 04:40:38 --> Router Class Initialized
INFO - 2023-02-28 04:40:38 --> Output Class Initialized
INFO - 2023-02-28 04:40:38 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:38 --> Input Class Initialized
INFO - 2023-02-28 04:40:38 --> Language Class Initialized
INFO - 2023-02-28 04:40:38 --> Loader Class Initialized
INFO - 2023-02-28 04:40:38 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:38 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:38 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:38 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:38 --> Total execution time: 0.0460
INFO - 2023-02-28 04:40:38 --> Config Class Initialized
INFO - 2023-02-28 04:40:38 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:38 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:38 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:38 --> URI Class Initialized
INFO - 2023-02-28 04:40:38 --> Router Class Initialized
INFO - 2023-02-28 04:40:38 --> Output Class Initialized
INFO - 2023-02-28 04:40:38 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:38 --> Input Class Initialized
INFO - 2023-02-28 04:40:38 --> Language Class Initialized
INFO - 2023-02-28 04:40:38 --> Loader Class Initialized
INFO - 2023-02-28 04:40:38 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:38 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:38 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:38 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:38 --> Total execution time: 0.0109
INFO - 2023-02-28 04:40:40 --> Config Class Initialized
INFO - 2023-02-28 04:40:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:40 --> Config Class Initialized
INFO - 2023-02-28 04:40:40 --> URI Class Initialized
INFO - 2023-02-28 04:40:40 --> Hooks Class Initialized
INFO - 2023-02-28 04:40:40 --> Router Class Initialized
DEBUG - 2023-02-28 04:40:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:40 --> Output Class Initialized
INFO - 2023-02-28 04:40:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:40 --> Input Class Initialized
INFO - 2023-02-28 04:40:40 --> Language Class Initialized
INFO - 2023-02-28 04:40:40 --> Loader Class Initialized
INFO - 2023-02-28 04:40:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:40 --> URI Class Initialized
INFO - 2023-02-28 04:40:40 --> Router Class Initialized
INFO - 2023-02-28 04:40:40 --> Output Class Initialized
INFO - 2023-02-28 04:40:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:40 --> Input Class Initialized
INFO - 2023-02-28 04:40:40 --> Language Class Initialized
INFO - 2023-02-28 04:40:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:40 --> Total execution time: 0.0577
INFO - 2023-02-28 04:40:40 --> Loader Class Initialized
INFO - 2023-02-28 04:40:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:40 --> Config Class Initialized
INFO - 2023-02-28 04:40:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:40 --> URI Class Initialized
INFO - 2023-02-28 04:40:40 --> Router Class Initialized
INFO - 2023-02-28 04:40:40 --> Output Class Initialized
INFO - 2023-02-28 04:40:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:40 --> Input Class Initialized
INFO - 2023-02-28 04:40:40 --> Language Class Initialized
INFO - 2023-02-28 04:40:40 --> Loader Class Initialized
INFO - 2023-02-28 04:40:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:40 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:40 --> Model "Login_model" initialized
INFO - 2023-02-28 04:40:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:40 --> Total execution time: 0.0552
INFO - 2023-02-28 04:40:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:40 --> Config Class Initialized
INFO - 2023-02-28 04:40:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:40 --> URI Class Initialized
INFO - 2023-02-28 04:40:40 --> Router Class Initialized
INFO - 2023-02-28 04:40:40 --> Output Class Initialized
INFO - 2023-02-28 04:40:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:40 --> Input Class Initialized
INFO - 2023-02-28 04:40:40 --> Language Class Initialized
INFO - 2023-02-28 04:40:40 --> Loader Class Initialized
INFO - 2023-02-28 04:40:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:40 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:40 --> Total execution time: 0.0226
INFO - 2023-02-28 04:40:40 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:40 --> Total execution time: 0.0525
INFO - 2023-02-28 04:40:43 --> Config Class Initialized
INFO - 2023-02-28 04:40:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:43 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:43 --> URI Class Initialized
INFO - 2023-02-28 04:40:43 --> Router Class Initialized
INFO - 2023-02-28 04:40:43 --> Output Class Initialized
INFO - 2023-02-28 04:40:43 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:43 --> Input Class Initialized
INFO - 2023-02-28 04:40:43 --> Language Class Initialized
INFO - 2023-02-28 04:40:43 --> Loader Class Initialized
INFO - 2023-02-28 04:40:43 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:43 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:43 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:43 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:43 --> Total execution time: 0.0182
INFO - 2023-02-28 04:40:47 --> Config Class Initialized
INFO - 2023-02-28 04:40:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:47 --> URI Class Initialized
INFO - 2023-02-28 04:40:47 --> Router Class Initialized
INFO - 2023-02-28 04:40:47 --> Output Class Initialized
INFO - 2023-02-28 04:40:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:47 --> Input Class Initialized
INFO - 2023-02-28 04:40:47 --> Language Class Initialized
INFO - 2023-02-28 04:40:47 --> Loader Class Initialized
INFO - 2023-02-28 04:40:47 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:47 --> Total execution time: 0.1211
INFO - 2023-02-28 04:40:47 --> Config Class Initialized
INFO - 2023-02-28 04:40:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:47 --> URI Class Initialized
INFO - 2023-02-28 04:40:47 --> Router Class Initialized
INFO - 2023-02-28 04:40:47 --> Output Class Initialized
INFO - 2023-02-28 04:40:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:47 --> Input Class Initialized
INFO - 2023-02-28 04:40:47 --> Language Class Initialized
INFO - 2023-02-28 04:40:47 --> Loader Class Initialized
INFO - 2023-02-28 04:40:47 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:47 --> Total execution time: 0.1120
INFO - 2023-02-28 04:40:49 --> Config Class Initialized
INFO - 2023-02-28 04:40:49 --> Hooks Class Initialized
INFO - 2023-02-28 04:40:49 --> Config Class Initialized
INFO - 2023-02-28 04:40:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:49 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:40:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:49 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:49 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:49 --> URI Class Initialized
INFO - 2023-02-28 04:40:49 --> URI Class Initialized
INFO - 2023-02-28 04:40:49 --> Router Class Initialized
INFO - 2023-02-28 04:40:49 --> Router Class Initialized
INFO - 2023-02-28 04:40:49 --> Output Class Initialized
INFO - 2023-02-28 04:40:49 --> Output Class Initialized
INFO - 2023-02-28 04:40:49 --> Security Class Initialized
INFO - 2023-02-28 04:40:49 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:49 --> Input Class Initialized
INFO - 2023-02-28 04:40:49 --> Input Class Initialized
INFO - 2023-02-28 04:40:49 --> Language Class Initialized
INFO - 2023-02-28 04:40:49 --> Language Class Initialized
INFO - 2023-02-28 04:40:49 --> Loader Class Initialized
INFO - 2023-02-28 04:40:49 --> Loader Class Initialized
INFO - 2023-02-28 04:40:49 --> Controller Class Initialized
INFO - 2023-02-28 04:40:49 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:40:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:49 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:49 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:49 --> Total execution time: 0.0047
INFO - 2023-02-28 04:40:49 --> Config Class Initialized
INFO - 2023-02-28 04:40:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:49 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:49 --> URI Class Initialized
INFO - 2023-02-28 04:40:49 --> Router Class Initialized
INFO - 2023-02-28 04:40:49 --> Output Class Initialized
INFO - 2023-02-28 04:40:49 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:49 --> Input Class Initialized
INFO - 2023-02-28 04:40:49 --> Language Class Initialized
INFO - 2023-02-28 04:40:49 --> Loader Class Initialized
INFO - 2023-02-28 04:40:49 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:49 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:49 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:49 --> Model "Login_model" initialized
INFO - 2023-02-28 04:40:49 --> Final output sent to browser
INFO - 2023-02-28 04:40:49 --> Database Driver Class Initialized
DEBUG - 2023-02-28 04:40:49 --> Total execution time: 0.0299
INFO - 2023-02-28 04:40:49 --> Config Class Initialized
INFO - 2023-02-28 04:40:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:49 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:49 --> URI Class Initialized
INFO - 2023-02-28 04:40:49 --> Router Class Initialized
INFO - 2023-02-28 04:40:49 --> Output Class Initialized
INFO - 2023-02-28 04:40:49 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:49 --> Input Class Initialized
INFO - 2023-02-28 04:40:49 --> Language Class Initialized
INFO - 2023-02-28 04:40:49 --> Loader Class Initialized
INFO - 2023-02-28 04:40:49 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:49 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:49 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:49 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:49 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:49 --> Total execution time: 0.0469
INFO - 2023-02-28 04:40:49 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:49 --> Total execution time: 0.0330
INFO - 2023-02-28 04:40:57 --> Config Class Initialized
INFO - 2023-02-28 04:40:57 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:57 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:57 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:57 --> URI Class Initialized
INFO - 2023-02-28 04:40:57 --> Router Class Initialized
INFO - 2023-02-28 04:40:57 --> Output Class Initialized
INFO - 2023-02-28 04:40:57 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:57 --> Input Class Initialized
INFO - 2023-02-28 04:40:57 --> Language Class Initialized
INFO - 2023-02-28 04:40:57 --> Loader Class Initialized
INFO - 2023-02-28 04:40:57 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:57 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:57 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:57 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:57 --> Total execution time: 0.0530
INFO - 2023-02-28 04:40:57 --> Config Class Initialized
INFO - 2023-02-28 04:40:57 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:40:57 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:40:57 --> Utf8 Class Initialized
INFO - 2023-02-28 04:40:57 --> URI Class Initialized
INFO - 2023-02-28 04:40:57 --> Router Class Initialized
INFO - 2023-02-28 04:40:57 --> Output Class Initialized
INFO - 2023-02-28 04:40:57 --> Security Class Initialized
DEBUG - 2023-02-28 04:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:40:57 --> Input Class Initialized
INFO - 2023-02-28 04:40:57 --> Language Class Initialized
INFO - 2023-02-28 04:40:57 --> Loader Class Initialized
INFO - 2023-02-28 04:40:57 --> Controller Class Initialized
DEBUG - 2023-02-28 04:40:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:40:57 --> Database Driver Class Initialized
INFO - 2023-02-28 04:40:57 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:40:58 --> Final output sent to browser
DEBUG - 2023-02-28 04:40:58 --> Total execution time: 0.0560
INFO - 2023-02-28 04:41:12 --> Config Class Initialized
INFO - 2023-02-28 04:41:12 --> Config Class Initialized
INFO - 2023-02-28 04:41:12 --> Hooks Class Initialized
INFO - 2023-02-28 04:41:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:41:12 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:41:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:12 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:12 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:12 --> URI Class Initialized
INFO - 2023-02-28 04:41:12 --> URI Class Initialized
INFO - 2023-02-28 04:41:12 --> Router Class Initialized
INFO - 2023-02-28 04:41:12 --> Router Class Initialized
INFO - 2023-02-28 04:41:12 --> Output Class Initialized
INFO - 2023-02-28 04:41:12 --> Output Class Initialized
INFO - 2023-02-28 04:41:12 --> Security Class Initialized
INFO - 2023-02-28 04:41:12 --> Security Class Initialized
DEBUG - 2023-02-28 04:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:12 --> Input Class Initialized
INFO - 2023-02-28 04:41:12 --> Input Class Initialized
INFO - 2023-02-28 04:41:12 --> Language Class Initialized
INFO - 2023-02-28 04:41:12 --> Language Class Initialized
INFO - 2023-02-28 04:41:12 --> Loader Class Initialized
INFO - 2023-02-28 04:41:12 --> Loader Class Initialized
INFO - 2023-02-28 04:41:12 --> Controller Class Initialized
INFO - 2023-02-28 04:41:12 --> Controller Class Initialized
DEBUG - 2023-02-28 04:41:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:41:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:12 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:12 --> Total execution time: 0.0047
INFO - 2023-02-28 04:41:12 --> Database Driver Class Initialized
INFO - 2023-02-28 04:41:12 --> Config Class Initialized
INFO - 2023-02-28 04:41:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:41:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:12 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:12 --> URI Class Initialized
INFO - 2023-02-28 04:41:12 --> Router Class Initialized
INFO - 2023-02-28 04:41:12 --> Output Class Initialized
INFO - 2023-02-28 04:41:12 --> Security Class Initialized
DEBUG - 2023-02-28 04:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:12 --> Input Class Initialized
INFO - 2023-02-28 04:41:12 --> Language Class Initialized
INFO - 2023-02-28 04:41:12 --> Loader Class Initialized
INFO - 2023-02-28 04:41:12 --> Controller Class Initialized
DEBUG - 2023-02-28 04:41:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:12 --> Database Driver Class Initialized
INFO - 2023-02-28 04:41:12 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:41:12 --> Model "Login_model" initialized
INFO - 2023-02-28 04:41:12 --> Final output sent to browser
INFO - 2023-02-28 04:41:12 --> Database Driver Class Initialized
DEBUG - 2023-02-28 04:41:12 --> Total execution time: 0.0274
INFO - 2023-02-28 04:41:12 --> Config Class Initialized
INFO - 2023-02-28 04:41:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:41:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:12 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:12 --> URI Class Initialized
INFO - 2023-02-28 04:41:12 --> Router Class Initialized
INFO - 2023-02-28 04:41:12 --> Output Class Initialized
INFO - 2023-02-28 04:41:12 --> Security Class Initialized
DEBUG - 2023-02-28 04:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:12 --> Input Class Initialized
INFO - 2023-02-28 04:41:12 --> Language Class Initialized
INFO - 2023-02-28 04:41:12 --> Loader Class Initialized
INFO - 2023-02-28 04:41:12 --> Controller Class Initialized
DEBUG - 2023-02-28 04:41:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:12 --> Database Driver Class Initialized
INFO - 2023-02-28 04:41:12 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:41:12 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:12 --> Total execution time: 0.0339
INFO - 2023-02-28 04:41:12 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:41:12 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:12 --> Total execution time: 0.0631
INFO - 2023-02-28 04:41:31 --> Config Class Initialized
INFO - 2023-02-28 04:41:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:41:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:31 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:31 --> URI Class Initialized
INFO - 2023-02-28 04:41:31 --> Router Class Initialized
INFO - 2023-02-28 04:41:31 --> Output Class Initialized
INFO - 2023-02-28 04:41:31 --> Security Class Initialized
DEBUG - 2023-02-28 04:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:31 --> Input Class Initialized
INFO - 2023-02-28 04:41:31 --> Language Class Initialized
INFO - 2023-02-28 04:41:31 --> Loader Class Initialized
INFO - 2023-02-28 04:41:31 --> Controller Class Initialized
DEBUG - 2023-02-28 04:41:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:31 --> Database Driver Class Initialized
INFO - 2023-02-28 04:41:31 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:41:31 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:31 --> Total execution time: 0.0568
INFO - 2023-02-28 04:41:31 --> Config Class Initialized
INFO - 2023-02-28 04:41:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:41:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:31 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:31 --> URI Class Initialized
INFO - 2023-02-28 04:41:31 --> Router Class Initialized
INFO - 2023-02-28 04:41:31 --> Output Class Initialized
INFO - 2023-02-28 04:41:31 --> Security Class Initialized
DEBUG - 2023-02-28 04:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:31 --> Input Class Initialized
INFO - 2023-02-28 04:41:31 --> Language Class Initialized
INFO - 2023-02-28 04:41:31 --> Loader Class Initialized
INFO - 2023-02-28 04:41:31 --> Controller Class Initialized
DEBUG - 2023-02-28 04:41:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:31 --> Database Driver Class Initialized
INFO - 2023-02-28 04:41:31 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:41:31 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:31 --> Total execution time: 0.0476
INFO - 2023-02-28 04:41:33 --> Config Class Initialized
INFO - 2023-02-28 04:41:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:41:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:33 --> URI Class Initialized
INFO - 2023-02-28 04:41:33 --> Router Class Initialized
INFO - 2023-02-28 04:41:33 --> Output Class Initialized
INFO - 2023-02-28 04:41:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:33 --> Input Class Initialized
INFO - 2023-02-28 04:41:33 --> Language Class Initialized
INFO - 2023-02-28 04:41:33 --> Loader Class Initialized
INFO - 2023-02-28 04:41:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:41:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:41:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:41:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:33 --> Total execution time: 0.0223
INFO - 2023-02-28 04:41:33 --> Config Class Initialized
INFO - 2023-02-28 04:41:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:41:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:33 --> URI Class Initialized
INFO - 2023-02-28 04:41:33 --> Router Class Initialized
INFO - 2023-02-28 04:41:33 --> Output Class Initialized
INFO - 2023-02-28 04:41:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:33 --> Input Class Initialized
INFO - 2023-02-28 04:41:33 --> Language Class Initialized
INFO - 2023-02-28 04:41:33 --> Loader Class Initialized
INFO - 2023-02-28 04:41:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:41:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:41:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:41:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:33 --> Total execution time: 0.0120
INFO - 2023-02-28 04:41:35 --> Config Class Initialized
INFO - 2023-02-28 04:41:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:41:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:35 --> URI Class Initialized
INFO - 2023-02-28 04:41:35 --> Router Class Initialized
INFO - 2023-02-28 04:41:35 --> Output Class Initialized
INFO - 2023-02-28 04:41:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:35 --> Input Class Initialized
INFO - 2023-02-28 04:41:35 --> Language Class Initialized
INFO - 2023-02-28 04:41:35 --> Loader Class Initialized
INFO - 2023-02-28 04:41:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:41:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:41:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:41:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:35 --> Total execution time: 0.0510
INFO - 2023-02-28 04:41:35 --> Config Class Initialized
INFO - 2023-02-28 04:41:35 --> Config Class Initialized
INFO - 2023-02-28 04:41:35 --> Hooks Class Initialized
INFO - 2023-02-28 04:41:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:41:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:35 --> Utf8 Class Initialized
DEBUG - 2023-02-28 04:41:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:35 --> URI Class Initialized
INFO - 2023-02-28 04:41:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:35 --> Router Class Initialized
INFO - 2023-02-28 04:41:35 --> URI Class Initialized
INFO - 2023-02-28 04:41:35 --> Output Class Initialized
INFO - 2023-02-28 04:41:35 --> Router Class Initialized
INFO - 2023-02-28 04:41:35 --> Security Class Initialized
INFO - 2023-02-28 04:41:35 --> Output Class Initialized
DEBUG - 2023-02-28 04:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:35 --> Security Class Initialized
INFO - 2023-02-28 04:41:35 --> Input Class Initialized
DEBUG - 2023-02-28 04:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:35 --> Language Class Initialized
INFO - 2023-02-28 04:41:35 --> Input Class Initialized
INFO - 2023-02-28 04:41:35 --> Loader Class Initialized
INFO - 2023-02-28 04:41:35 --> Language Class Initialized
INFO - 2023-02-28 04:41:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:41:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:35 --> Loader Class Initialized
INFO - 2023-02-28 04:41:35 --> Controller Class Initialized
INFO - 2023-02-28 04:41:35 --> Database Driver Class Initialized
DEBUG - 2023-02-28 04:41:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:35 --> Total execution time: 0.0056
INFO - 2023-02-28 04:41:35 --> Config Class Initialized
INFO - 2023-02-28 04:41:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:41:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:35 --> URI Class Initialized
INFO - 2023-02-28 04:41:35 --> Router Class Initialized
INFO - 2023-02-28 04:41:35 --> Output Class Initialized
INFO - 2023-02-28 04:41:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:35 --> Input Class Initialized
INFO - 2023-02-28 04:41:35 --> Language Class Initialized
INFO - 2023-02-28 04:41:35 --> Loader Class Initialized
INFO - 2023-02-28 04:41:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:41:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:41:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:41:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:35 --> Total execution time: 0.0182
INFO - 2023-02-28 04:41:35 --> Model "Login_model" initialized
INFO - 2023-02-28 04:41:35 --> Config Class Initialized
INFO - 2023-02-28 04:41:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:41:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:35 --> URI Class Initialized
INFO - 2023-02-28 04:41:35 --> Router Class Initialized
INFO - 2023-02-28 04:41:35 --> Output Class Initialized
INFO - 2023-02-28 04:41:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:35 --> Input Class Initialized
INFO - 2023-02-28 04:41:35 --> Language Class Initialized
INFO - 2023-02-28 04:41:35 --> Loader Class Initialized
INFO - 2023-02-28 04:41:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:41:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:41:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:41:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:41:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:41:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:35 --> Total execution time: 0.0222
INFO - 2023-02-28 04:41:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:35 --> Total execution time: 0.0146
INFO - 2023-02-28 04:41:58 --> Config Class Initialized
INFO - 2023-02-28 04:41:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:41:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:58 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:58 --> URI Class Initialized
INFO - 2023-02-28 04:41:58 --> Router Class Initialized
INFO - 2023-02-28 04:41:58 --> Output Class Initialized
INFO - 2023-02-28 04:41:58 --> Security Class Initialized
DEBUG - 2023-02-28 04:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:58 --> Input Class Initialized
INFO - 2023-02-28 04:41:58 --> Language Class Initialized
INFO - 2023-02-28 04:41:58 --> Loader Class Initialized
INFO - 2023-02-28 04:41:58 --> Controller Class Initialized
DEBUG - 2023-02-28 04:41:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:58 --> Database Driver Class Initialized
INFO - 2023-02-28 04:41:58 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:41:58 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:58 --> Total execution time: 0.0475
INFO - 2023-02-28 04:41:58 --> Config Class Initialized
INFO - 2023-02-28 04:41:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:41:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:41:58 --> Utf8 Class Initialized
INFO - 2023-02-28 04:41:58 --> URI Class Initialized
INFO - 2023-02-28 04:41:58 --> Router Class Initialized
INFO - 2023-02-28 04:41:58 --> Output Class Initialized
INFO - 2023-02-28 04:41:58 --> Security Class Initialized
DEBUG - 2023-02-28 04:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:41:58 --> Input Class Initialized
INFO - 2023-02-28 04:41:58 --> Language Class Initialized
INFO - 2023-02-28 04:41:58 --> Loader Class Initialized
INFO - 2023-02-28 04:41:58 --> Controller Class Initialized
DEBUG - 2023-02-28 04:41:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:41:58 --> Database Driver Class Initialized
INFO - 2023-02-28 04:41:58 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:41:59 --> Final output sent to browser
DEBUG - 2023-02-28 04:41:59 --> Total execution time: 0.0490
INFO - 2023-02-28 04:42:00 --> Config Class Initialized
INFO - 2023-02-28 04:42:00 --> Config Class Initialized
INFO - 2023-02-28 04:42:00 --> Hooks Class Initialized
INFO - 2023-02-28 04:42:00 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:00 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:42:00 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:00 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:00 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:00 --> URI Class Initialized
INFO - 2023-02-28 04:42:00 --> URI Class Initialized
INFO - 2023-02-28 04:42:00 --> Router Class Initialized
INFO - 2023-02-28 04:42:00 --> Router Class Initialized
INFO - 2023-02-28 04:42:00 --> Output Class Initialized
INFO - 2023-02-28 04:42:00 --> Output Class Initialized
INFO - 2023-02-28 04:42:00 --> Security Class Initialized
INFO - 2023-02-28 04:42:00 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:00 --> Input Class Initialized
INFO - 2023-02-28 04:42:00 --> Input Class Initialized
INFO - 2023-02-28 04:42:00 --> Language Class Initialized
INFO - 2023-02-28 04:42:00 --> Language Class Initialized
INFO - 2023-02-28 04:42:00 --> Loader Class Initialized
INFO - 2023-02-28 04:42:00 --> Loader Class Initialized
INFO - 2023-02-28 04:42:00 --> Controller Class Initialized
INFO - 2023-02-28 04:42:00 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:42:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:00 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:00 --> Total execution time: 0.0040
INFO - 2023-02-28 04:42:00 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:00 --> Config Class Initialized
INFO - 2023-02-28 04:42:00 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:00 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:00 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:00 --> URI Class Initialized
INFO - 2023-02-28 04:42:00 --> Router Class Initialized
INFO - 2023-02-28 04:42:00 --> Output Class Initialized
INFO - 2023-02-28 04:42:00 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:00 --> Input Class Initialized
INFO - 2023-02-28 04:42:00 --> Language Class Initialized
INFO - 2023-02-28 04:42:00 --> Loader Class Initialized
INFO - 2023-02-28 04:42:00 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:00 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:00 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:00 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:00 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:00 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:00 --> Total execution time: 0.0193
INFO - 2023-02-28 04:42:00 --> Config Class Initialized
INFO - 2023-02-28 04:42:00 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:00 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:00 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:00 --> URI Class Initialized
INFO - 2023-02-28 04:42:00 --> Router Class Initialized
INFO - 2023-02-28 04:42:00 --> Output Class Initialized
INFO - 2023-02-28 04:42:00 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:00 --> Input Class Initialized
INFO - 2023-02-28 04:42:00 --> Language Class Initialized
INFO - 2023-02-28 04:42:00 --> Loader Class Initialized
INFO - 2023-02-28 04:42:00 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:00 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:00 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:00 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:00 --> Total execution time: 0.0214
INFO - 2023-02-28 04:42:00 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:00 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:00 --> Total execution time: 0.0533
INFO - 2023-02-28 04:42:03 --> Config Class Initialized
INFO - 2023-02-28 04:42:03 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:03 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:03 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:03 --> URI Class Initialized
INFO - 2023-02-28 04:42:03 --> Router Class Initialized
INFO - 2023-02-28 04:42:03 --> Output Class Initialized
INFO - 2023-02-28 04:42:03 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:03 --> Input Class Initialized
INFO - 2023-02-28 04:42:03 --> Language Class Initialized
INFO - 2023-02-28 04:42:03 --> Loader Class Initialized
INFO - 2023-02-28 04:42:03 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:03 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:03 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:03 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:03 --> Total execution time: 0.0140
INFO - 2023-02-28 04:42:03 --> Config Class Initialized
INFO - 2023-02-28 04:42:03 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:03 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:03 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:03 --> URI Class Initialized
INFO - 2023-02-28 04:42:03 --> Router Class Initialized
INFO - 2023-02-28 04:42:03 --> Output Class Initialized
INFO - 2023-02-28 04:42:03 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:03 --> Input Class Initialized
INFO - 2023-02-28 04:42:03 --> Language Class Initialized
INFO - 2023-02-28 04:42:03 --> Loader Class Initialized
INFO - 2023-02-28 04:42:03 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:03 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:03 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:03 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:03 --> Total execution time: 0.0505
INFO - 2023-02-28 04:42:06 --> Config Class Initialized
INFO - 2023-02-28 04:42:06 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:06 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:06 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:06 --> URI Class Initialized
INFO - 2023-02-28 04:42:06 --> Router Class Initialized
INFO - 2023-02-28 04:42:06 --> Output Class Initialized
INFO - 2023-02-28 04:42:06 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:06 --> Input Class Initialized
INFO - 2023-02-28 04:42:06 --> Language Class Initialized
INFO - 2023-02-28 04:42:06 --> Loader Class Initialized
INFO - 2023-02-28 04:42:06 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:06 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:06 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:06 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:06 --> Total execution time: 0.0758
INFO - 2023-02-28 04:42:06 --> Config Class Initialized
INFO - 2023-02-28 04:42:06 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:06 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:06 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:06 --> URI Class Initialized
INFO - 2023-02-28 04:42:06 --> Router Class Initialized
INFO - 2023-02-28 04:42:06 --> Output Class Initialized
INFO - 2023-02-28 04:42:06 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:06 --> Input Class Initialized
INFO - 2023-02-28 04:42:06 --> Language Class Initialized
INFO - 2023-02-28 04:42:06 --> Loader Class Initialized
INFO - 2023-02-28 04:42:06 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:06 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:06 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:06 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:06 --> Total execution time: 0.0548
INFO - 2023-02-28 04:42:13 --> Config Class Initialized
INFO - 2023-02-28 04:42:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:13 --> URI Class Initialized
INFO - 2023-02-28 04:42:13 --> Router Class Initialized
INFO - 2023-02-28 04:42:13 --> Output Class Initialized
INFO - 2023-02-28 04:42:13 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:13 --> Input Class Initialized
INFO - 2023-02-28 04:42:13 --> Language Class Initialized
INFO - 2023-02-28 04:42:13 --> Loader Class Initialized
INFO - 2023-02-28 04:42:13 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:13 --> Total execution time: 0.0477
INFO - 2023-02-28 04:42:13 --> Config Class Initialized
INFO - 2023-02-28 04:42:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:13 --> URI Class Initialized
INFO - 2023-02-28 04:42:13 --> Router Class Initialized
INFO - 2023-02-28 04:42:13 --> Output Class Initialized
INFO - 2023-02-28 04:42:13 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:13 --> Input Class Initialized
INFO - 2023-02-28 04:42:13 --> Language Class Initialized
INFO - 2023-02-28 04:42:13 --> Loader Class Initialized
INFO - 2023-02-28 04:42:13 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:13 --> Total execution time: 0.0357
INFO - 2023-02-28 04:42:13 --> Config Class Initialized
INFO - 2023-02-28 04:42:13 --> Config Class Initialized
INFO - 2023-02-28 04:42:13 --> Hooks Class Initialized
INFO - 2023-02-28 04:42:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:42:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:13 --> URI Class Initialized
INFO - 2023-02-28 04:42:13 --> URI Class Initialized
INFO - 2023-02-28 04:42:13 --> Router Class Initialized
INFO - 2023-02-28 04:42:13 --> Router Class Initialized
INFO - 2023-02-28 04:42:13 --> Output Class Initialized
INFO - 2023-02-28 04:42:13 --> Output Class Initialized
INFO - 2023-02-28 04:42:13 --> Security Class Initialized
INFO - 2023-02-28 04:42:13 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:13 --> Input Class Initialized
INFO - 2023-02-28 04:42:13 --> Input Class Initialized
INFO - 2023-02-28 04:42:13 --> Language Class Initialized
INFO - 2023-02-28 04:42:13 --> Language Class Initialized
INFO - 2023-02-28 04:42:13 --> Loader Class Initialized
INFO - 2023-02-28 04:42:13 --> Loader Class Initialized
INFO - 2023-02-28 04:42:13 --> Controller Class Initialized
INFO - 2023-02-28 04:42:13 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:42:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:13 --> Total execution time: 0.0043
INFO - 2023-02-28 04:42:13 --> Config Class Initialized
INFO - 2023-02-28 04:42:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:13 --> URI Class Initialized
INFO - 2023-02-28 04:42:13 --> Router Class Initialized
INFO - 2023-02-28 04:42:13 --> Output Class Initialized
INFO - 2023-02-28 04:42:13 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:13 --> Input Class Initialized
INFO - 2023-02-28 04:42:13 --> Language Class Initialized
INFO - 2023-02-28 04:42:13 --> Loader Class Initialized
INFO - 2023-02-28 04:42:13 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:13 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:13 --> Total execution time: 0.0164
INFO - 2023-02-28 04:42:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:13 --> Config Class Initialized
INFO - 2023-02-28 04:42:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:13 --> URI Class Initialized
INFO - 2023-02-28 04:42:13 --> Router Class Initialized
INFO - 2023-02-28 04:42:13 --> Output Class Initialized
INFO - 2023-02-28 04:42:13 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:13 --> Input Class Initialized
INFO - 2023-02-28 04:42:13 --> Language Class Initialized
INFO - 2023-02-28 04:42:13 --> Loader Class Initialized
INFO - 2023-02-28 04:42:13 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:13 --> Total execution time: 0.0202
INFO - 2023-02-28 04:42:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:13 --> Total execution time: 0.0126
INFO - 2023-02-28 04:42:16 --> Config Class Initialized
INFO - 2023-02-28 04:42:16 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:16 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:16 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:16 --> URI Class Initialized
INFO - 2023-02-28 04:42:16 --> Router Class Initialized
INFO - 2023-02-28 04:42:16 --> Output Class Initialized
INFO - 2023-02-28 04:42:16 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:16 --> Input Class Initialized
INFO - 2023-02-28 04:42:16 --> Language Class Initialized
INFO - 2023-02-28 04:42:16 --> Loader Class Initialized
INFO - 2023-02-28 04:42:16 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:16 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:16 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:16 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:16 --> Total execution time: 0.1497
INFO - 2023-02-28 04:42:21 --> Config Class Initialized
INFO - 2023-02-28 04:42:21 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:21 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:21 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:21 --> URI Class Initialized
INFO - 2023-02-28 04:42:21 --> Router Class Initialized
INFO - 2023-02-28 04:42:21 --> Output Class Initialized
INFO - 2023-02-28 04:42:21 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:21 --> Input Class Initialized
INFO - 2023-02-28 04:42:21 --> Language Class Initialized
INFO - 2023-02-28 04:42:21 --> Loader Class Initialized
INFO - 2023-02-28 04:42:21 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:21 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:21 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:21 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:21 --> Total execution time: 0.0166
INFO - 2023-02-28 04:42:21 --> Config Class Initialized
INFO - 2023-02-28 04:42:21 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:21 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:21 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:21 --> URI Class Initialized
INFO - 2023-02-28 04:42:21 --> Router Class Initialized
INFO - 2023-02-28 04:42:21 --> Output Class Initialized
INFO - 2023-02-28 04:42:21 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:21 --> Input Class Initialized
INFO - 2023-02-28 04:42:21 --> Language Class Initialized
INFO - 2023-02-28 04:42:21 --> Loader Class Initialized
INFO - 2023-02-28 04:42:21 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:21 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:21 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:21 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:21 --> Total execution time: 0.0123
INFO - 2023-02-28 04:42:23 --> Config Class Initialized
INFO - 2023-02-28 04:42:23 --> Config Class Initialized
INFO - 2023-02-28 04:42:23 --> Hooks Class Initialized
INFO - 2023-02-28 04:42:23 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:23 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:23 --> Utf8 Class Initialized
DEBUG - 2023-02-28 04:42:23 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:23 --> URI Class Initialized
INFO - 2023-02-28 04:42:23 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:23 --> Router Class Initialized
INFO - 2023-02-28 04:42:23 --> URI Class Initialized
INFO - 2023-02-28 04:42:23 --> Output Class Initialized
INFO - 2023-02-28 04:42:23 --> Router Class Initialized
INFO - 2023-02-28 04:42:23 --> Security Class Initialized
INFO - 2023-02-28 04:42:23 --> Output Class Initialized
DEBUG - 2023-02-28 04:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:23 --> Security Class Initialized
INFO - 2023-02-28 04:42:23 --> Input Class Initialized
DEBUG - 2023-02-28 04:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:23 --> Language Class Initialized
INFO - 2023-02-28 04:42:23 --> Input Class Initialized
INFO - 2023-02-28 04:42:23 --> Language Class Initialized
INFO - 2023-02-28 04:42:23 --> Loader Class Initialized
INFO - 2023-02-28 04:42:23 --> Loader Class Initialized
INFO - 2023-02-28 04:42:23 --> Controller Class Initialized
INFO - 2023-02-28 04:42:23 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:42:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:23 --> Final output sent to browser
INFO - 2023-02-28 04:42:23 --> Database Driver Class Initialized
DEBUG - 2023-02-28 04:42:23 --> Total execution time: 0.0050
INFO - 2023-02-28 04:42:23 --> Config Class Initialized
INFO - 2023-02-28 04:42:23 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:23 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:23 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:23 --> URI Class Initialized
INFO - 2023-02-28 04:42:23 --> Router Class Initialized
INFO - 2023-02-28 04:42:23 --> Output Class Initialized
INFO - 2023-02-28 04:42:23 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:23 --> Input Class Initialized
INFO - 2023-02-28 04:42:23 --> Language Class Initialized
INFO - 2023-02-28 04:42:23 --> Loader Class Initialized
INFO - 2023-02-28 04:42:23 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:23 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:23 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:23 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:23 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:23 --> Total execution time: 0.0171
INFO - 2023-02-28 04:42:23 --> Config Class Initialized
INFO - 2023-02-28 04:42:23 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:23 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:24 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:24 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:24 --> URI Class Initialized
INFO - 2023-02-28 04:42:24 --> Router Class Initialized
INFO - 2023-02-28 04:42:24 --> Output Class Initialized
INFO - 2023-02-28 04:42:24 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:24 --> Input Class Initialized
INFO - 2023-02-28 04:42:24 --> Language Class Initialized
INFO - 2023-02-28 04:42:24 --> Loader Class Initialized
INFO - 2023-02-28 04:42:24 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:24 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:24 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:24 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:24 --> Total execution time: 0.0213
INFO - 2023-02-28 04:42:24 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:24 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:24 --> Total execution time: 0.0556
INFO - 2023-02-28 04:42:25 --> Config Class Initialized
INFO - 2023-02-28 04:42:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:25 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:25 --> URI Class Initialized
INFO - 2023-02-28 04:42:25 --> Router Class Initialized
INFO - 2023-02-28 04:42:25 --> Output Class Initialized
INFO - 2023-02-28 04:42:25 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:25 --> Input Class Initialized
INFO - 2023-02-28 04:42:25 --> Language Class Initialized
INFO - 2023-02-28 04:42:25 --> Loader Class Initialized
INFO - 2023-02-28 04:42:25 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:25 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:25 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:25 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:25 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:25 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:25 --> Total execution time: 0.0425
INFO - 2023-02-28 04:42:25 --> Config Class Initialized
INFO - 2023-02-28 04:42:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:25 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:25 --> URI Class Initialized
INFO - 2023-02-28 04:42:25 --> Router Class Initialized
INFO - 2023-02-28 04:42:25 --> Output Class Initialized
INFO - 2023-02-28 04:42:25 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:25 --> Input Class Initialized
INFO - 2023-02-28 04:42:25 --> Language Class Initialized
INFO - 2023-02-28 04:42:25 --> Loader Class Initialized
INFO - 2023-02-28 04:42:25 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:25 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:25 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:25 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:25 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:25 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:25 --> Total execution time: 0.0374
INFO - 2023-02-28 04:42:28 --> Config Class Initialized
INFO - 2023-02-28 04:42:28 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:28 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:28 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:28 --> URI Class Initialized
INFO - 2023-02-28 04:42:28 --> Router Class Initialized
INFO - 2023-02-28 04:42:28 --> Output Class Initialized
INFO - 2023-02-28 04:42:28 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:28 --> Input Class Initialized
INFO - 2023-02-28 04:42:28 --> Language Class Initialized
INFO - 2023-02-28 04:42:28 --> Loader Class Initialized
INFO - 2023-02-28 04:42:28 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:28 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:28 --> Total execution time: 0.0091
INFO - 2023-02-28 04:42:28 --> Config Class Initialized
INFO - 2023-02-28 04:42:28 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:28 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:28 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:28 --> URI Class Initialized
INFO - 2023-02-28 04:42:28 --> Router Class Initialized
INFO - 2023-02-28 04:42:28 --> Output Class Initialized
INFO - 2023-02-28 04:42:28 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:28 --> Input Class Initialized
INFO - 2023-02-28 04:42:28 --> Language Class Initialized
INFO - 2023-02-28 04:42:28 --> Loader Class Initialized
INFO - 2023-02-28 04:42:28 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:28 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:28 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:28 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:28 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:28 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:28 --> Total execution time: 0.0230
INFO - 2023-02-28 04:42:28 --> Config Class Initialized
INFO - 2023-02-28 04:42:28 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:28 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:28 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:28 --> URI Class Initialized
INFO - 2023-02-28 04:42:28 --> Router Class Initialized
INFO - 2023-02-28 04:42:28 --> Output Class Initialized
INFO - 2023-02-28 04:42:28 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:28 --> Input Class Initialized
INFO - 2023-02-28 04:42:28 --> Language Class Initialized
INFO - 2023-02-28 04:42:28 --> Loader Class Initialized
INFO - 2023-02-28 04:42:28 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:28 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:28 --> Total execution time: 0.0018
INFO - 2023-02-28 04:42:28 --> Config Class Initialized
INFO - 2023-02-28 04:42:28 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:28 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:28 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:28 --> URI Class Initialized
INFO - 2023-02-28 04:42:28 --> Router Class Initialized
INFO - 2023-02-28 04:42:28 --> Output Class Initialized
INFO - 2023-02-28 04:42:28 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:28 --> Input Class Initialized
INFO - 2023-02-28 04:42:28 --> Language Class Initialized
INFO - 2023-02-28 04:42:28 --> Loader Class Initialized
INFO - 2023-02-28 04:42:28 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:28 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:28 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:28 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:28 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:28 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:28 --> Total execution time: 0.0180
INFO - 2023-02-28 04:42:29 --> Config Class Initialized
INFO - 2023-02-28 04:42:29 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:29 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:29 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:29 --> URI Class Initialized
INFO - 2023-02-28 04:42:29 --> Router Class Initialized
INFO - 2023-02-28 04:42:29 --> Output Class Initialized
INFO - 2023-02-28 04:42:29 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:29 --> Input Class Initialized
INFO - 2023-02-28 04:42:29 --> Language Class Initialized
INFO - 2023-02-28 04:42:29 --> Loader Class Initialized
INFO - 2023-02-28 04:42:29 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:29 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:29 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:29 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:29 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:30 --> Total execution time: 0.0453
INFO - 2023-02-28 04:42:30 --> Config Class Initialized
INFO - 2023-02-28 04:42:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:30 --> URI Class Initialized
INFO - 2023-02-28 04:42:30 --> Router Class Initialized
INFO - 2023-02-28 04:42:30 --> Output Class Initialized
INFO - 2023-02-28 04:42:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:30 --> Input Class Initialized
INFO - 2023-02-28 04:42:30 --> Language Class Initialized
INFO - 2023-02-28 04:42:30 --> Loader Class Initialized
INFO - 2023-02-28 04:42:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:30 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:30 --> Total execution time: 0.0227
INFO - 2023-02-28 04:42:30 --> Config Class Initialized
INFO - 2023-02-28 04:42:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:30 --> URI Class Initialized
INFO - 2023-02-28 04:42:30 --> Router Class Initialized
INFO - 2023-02-28 04:42:30 --> Output Class Initialized
INFO - 2023-02-28 04:42:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:30 --> Input Class Initialized
INFO - 2023-02-28 04:42:30 --> Language Class Initialized
INFO - 2023-02-28 04:42:30 --> Loader Class Initialized
INFO - 2023-02-28 04:42:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:30 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:30 --> Total execution time: 0.0545
INFO - 2023-02-28 04:42:32 --> Config Class Initialized
INFO - 2023-02-28 04:42:32 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:32 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:32 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:32 --> URI Class Initialized
INFO - 2023-02-28 04:42:32 --> Router Class Initialized
INFO - 2023-02-28 04:42:32 --> Output Class Initialized
INFO - 2023-02-28 04:42:32 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:32 --> Input Class Initialized
INFO - 2023-02-28 04:42:32 --> Language Class Initialized
INFO - 2023-02-28 04:42:32 --> Loader Class Initialized
INFO - 2023-02-28 04:42:32 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:32 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:32 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:32 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:32 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:32 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:32 --> Total execution time: 0.0478
INFO - 2023-02-28 04:42:32 --> Config Class Initialized
INFO - 2023-02-28 04:42:32 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:32 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:32 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:32 --> URI Class Initialized
INFO - 2023-02-28 04:42:32 --> Router Class Initialized
INFO - 2023-02-28 04:42:32 --> Output Class Initialized
INFO - 2023-02-28 04:42:32 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:32 --> Input Class Initialized
INFO - 2023-02-28 04:42:32 --> Language Class Initialized
INFO - 2023-02-28 04:42:32 --> Loader Class Initialized
INFO - 2023-02-28 04:42:32 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:32 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:32 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:32 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:32 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:32 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:32 --> Total execution time: 0.0378
INFO - 2023-02-28 04:42:33 --> Config Class Initialized
INFO - 2023-02-28 04:42:33 --> Config Class Initialized
INFO - 2023-02-28 04:42:33 --> Hooks Class Initialized
INFO - 2023-02-28 04:42:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:33 --> Utf8 Class Initialized
DEBUG - 2023-02-28 04:42:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:33 --> URI Class Initialized
INFO - 2023-02-28 04:42:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:33 --> Router Class Initialized
INFO - 2023-02-28 04:42:33 --> URI Class Initialized
INFO - 2023-02-28 04:42:33 --> Output Class Initialized
INFO - 2023-02-28 04:42:33 --> Router Class Initialized
INFO - 2023-02-28 04:42:33 --> Security Class Initialized
INFO - 2023-02-28 04:42:33 --> Output Class Initialized
DEBUG - 2023-02-28 04:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:33 --> Security Class Initialized
INFO - 2023-02-28 04:42:33 --> Input Class Initialized
DEBUG - 2023-02-28 04:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:33 --> Language Class Initialized
INFO - 2023-02-28 04:42:33 --> Input Class Initialized
INFO - 2023-02-28 04:42:33 --> Language Class Initialized
INFO - 2023-02-28 04:42:33 --> Loader Class Initialized
INFO - 2023-02-28 04:42:33 --> Controller Class Initialized
INFO - 2023-02-28 04:42:33 --> Loader Class Initialized
DEBUG - 2023-02-28 04:42:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:33 --> Total execution time: 0.0046
INFO - 2023-02-28 04:42:33 --> Config Class Initialized
INFO - 2023-02-28 04:42:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:33 --> URI Class Initialized
INFO - 2023-02-28 04:42:33 --> Router Class Initialized
INFO - 2023-02-28 04:42:33 --> Output Class Initialized
INFO - 2023-02-28 04:42:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:33 --> Input Class Initialized
INFO - 2023-02-28 04:42:33 --> Language Class Initialized
INFO - 2023-02-28 04:42:33 --> Loader Class Initialized
INFO - 2023-02-28 04:42:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:33 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:33 --> Total execution time: 0.0215
INFO - 2023-02-28 04:42:33 --> Config Class Initialized
INFO - 2023-02-28 04:42:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:33 --> URI Class Initialized
INFO - 2023-02-28 04:42:33 --> Router Class Initialized
INFO - 2023-02-28 04:42:33 --> Output Class Initialized
INFO - 2023-02-28 04:42:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:33 --> Input Class Initialized
INFO - 2023-02-28 04:42:33 --> Language Class Initialized
INFO - 2023-02-28 04:42:33 --> Loader Class Initialized
INFO - 2023-02-28 04:42:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:33 --> Total execution time: 0.0237
INFO - 2023-02-28 04:42:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:33 --> Total execution time: 0.0544
INFO - 2023-02-28 04:42:35 --> Config Class Initialized
INFO - 2023-02-28 04:42:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:35 --> URI Class Initialized
INFO - 2023-02-28 04:42:35 --> Router Class Initialized
INFO - 2023-02-28 04:42:35 --> Output Class Initialized
INFO - 2023-02-28 04:42:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:35 --> Input Class Initialized
INFO - 2023-02-28 04:42:35 --> Language Class Initialized
INFO - 2023-02-28 04:42:35 --> Loader Class Initialized
INFO - 2023-02-28 04:42:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:35 --> Total execution time: 0.0893
INFO - 2023-02-28 04:42:35 --> Config Class Initialized
INFO - 2023-02-28 04:42:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:35 --> URI Class Initialized
INFO - 2023-02-28 04:42:35 --> Router Class Initialized
INFO - 2023-02-28 04:42:35 --> Output Class Initialized
INFO - 2023-02-28 04:42:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:35 --> Input Class Initialized
INFO - 2023-02-28 04:42:35 --> Language Class Initialized
INFO - 2023-02-28 04:42:35 --> Loader Class Initialized
INFO - 2023-02-28 04:42:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:35 --> Total execution time: 0.0427
INFO - 2023-02-28 04:42:39 --> Config Class Initialized
INFO - 2023-02-28 04:42:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:39 --> URI Class Initialized
INFO - 2023-02-28 04:42:39 --> Router Class Initialized
INFO - 2023-02-28 04:42:39 --> Output Class Initialized
INFO - 2023-02-28 04:42:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:39 --> Input Class Initialized
INFO - 2023-02-28 04:42:39 --> Language Class Initialized
INFO - 2023-02-28 04:42:39 --> Loader Class Initialized
INFO - 2023-02-28 04:42:39 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:39 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:39 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:39 --> Total execution time: 0.0154
INFO - 2023-02-28 04:42:39 --> Config Class Initialized
INFO - 2023-02-28 04:42:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:39 --> URI Class Initialized
INFO - 2023-02-28 04:42:39 --> Router Class Initialized
INFO - 2023-02-28 04:42:39 --> Output Class Initialized
INFO - 2023-02-28 04:42:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:39 --> Input Class Initialized
INFO - 2023-02-28 04:42:39 --> Language Class Initialized
INFO - 2023-02-28 04:42:39 --> Loader Class Initialized
INFO - 2023-02-28 04:42:39 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:39 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:39 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:39 --> Total execution time: 0.0119
INFO - 2023-02-28 04:42:51 --> Config Class Initialized
INFO - 2023-02-28 04:42:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:51 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:51 --> URI Class Initialized
INFO - 2023-02-28 04:42:51 --> Router Class Initialized
INFO - 2023-02-28 04:42:51 --> Output Class Initialized
INFO - 2023-02-28 04:42:51 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:51 --> Input Class Initialized
INFO - 2023-02-28 04:42:51 --> Language Class Initialized
INFO - 2023-02-28 04:42:51 --> Loader Class Initialized
INFO - 2023-02-28 04:42:51 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:51 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:51 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:51 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:51 --> Total execution time: 0.0622
INFO - 2023-02-28 04:42:51 --> Config Class Initialized
INFO - 2023-02-28 04:42:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:51 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:51 --> URI Class Initialized
INFO - 2023-02-28 04:42:51 --> Router Class Initialized
INFO - 2023-02-28 04:42:51 --> Output Class Initialized
INFO - 2023-02-28 04:42:51 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:51 --> Input Class Initialized
INFO - 2023-02-28 04:42:51 --> Language Class Initialized
INFO - 2023-02-28 04:42:51 --> Loader Class Initialized
INFO - 2023-02-28 04:42:51 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:51 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:51 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:51 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:51 --> Total execution time: 0.0573
INFO - 2023-02-28 04:42:52 --> Config Class Initialized
INFO - 2023-02-28 04:42:52 --> Config Class Initialized
INFO - 2023-02-28 04:42:52 --> Hooks Class Initialized
INFO - 2023-02-28 04:42:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:52 --> Utf8 Class Initialized
DEBUG - 2023-02-28 04:42:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:52 --> URI Class Initialized
INFO - 2023-02-28 04:42:52 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:52 --> Router Class Initialized
INFO - 2023-02-28 04:42:52 --> URI Class Initialized
INFO - 2023-02-28 04:42:52 --> Output Class Initialized
INFO - 2023-02-28 04:42:52 --> Router Class Initialized
INFO - 2023-02-28 04:42:52 --> Security Class Initialized
INFO - 2023-02-28 04:42:52 --> Output Class Initialized
DEBUG - 2023-02-28 04:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:52 --> Security Class Initialized
INFO - 2023-02-28 04:42:52 --> Input Class Initialized
DEBUG - 2023-02-28 04:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:52 --> Language Class Initialized
INFO - 2023-02-28 04:42:52 --> Input Class Initialized
INFO - 2023-02-28 04:42:52 --> Language Class Initialized
INFO - 2023-02-28 04:42:52 --> Loader Class Initialized
INFO - 2023-02-28 04:42:52 --> Loader Class Initialized
INFO - 2023-02-28 04:42:52 --> Controller Class Initialized
INFO - 2023-02-28 04:42:52 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:52 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:52 --> Total execution time: 0.0044
INFO - 2023-02-28 04:42:52 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:52 --> Config Class Initialized
INFO - 2023-02-28 04:42:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:52 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:52 --> URI Class Initialized
INFO - 2023-02-28 04:42:52 --> Router Class Initialized
INFO - 2023-02-28 04:42:52 --> Output Class Initialized
INFO - 2023-02-28 04:42:52 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:52 --> Input Class Initialized
INFO - 2023-02-28 04:42:52 --> Language Class Initialized
INFO - 2023-02-28 04:42:52 --> Loader Class Initialized
INFO - 2023-02-28 04:42:52 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:52 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:52 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:52 --> Model "Login_model" initialized
INFO - 2023-02-28 04:42:52 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:52 --> Total execution time: 0.0165
INFO - 2023-02-28 04:42:52 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:52 --> Config Class Initialized
INFO - 2023-02-28 04:42:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:42:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:42:52 --> Utf8 Class Initialized
INFO - 2023-02-28 04:42:52 --> URI Class Initialized
INFO - 2023-02-28 04:42:52 --> Router Class Initialized
INFO - 2023-02-28 04:42:52 --> Output Class Initialized
INFO - 2023-02-28 04:42:52 --> Security Class Initialized
DEBUG - 2023-02-28 04:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:42:52 --> Input Class Initialized
INFO - 2023-02-28 04:42:52 --> Language Class Initialized
INFO - 2023-02-28 04:42:52 --> Loader Class Initialized
INFO - 2023-02-28 04:42:52 --> Controller Class Initialized
DEBUG - 2023-02-28 04:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:42:52 --> Database Driver Class Initialized
INFO - 2023-02-28 04:42:52 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:52 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:52 --> Total execution time: 0.0223
INFO - 2023-02-28 04:42:52 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:42:52 --> Final output sent to browser
DEBUG - 2023-02-28 04:42:52 --> Total execution time: 0.0595
INFO - 2023-02-28 04:43:36 --> Config Class Initialized
INFO - 2023-02-28 04:43:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:43:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:43:36 --> Utf8 Class Initialized
INFO - 2023-02-28 04:43:36 --> URI Class Initialized
INFO - 2023-02-28 04:43:36 --> Router Class Initialized
INFO - 2023-02-28 04:43:36 --> Output Class Initialized
INFO - 2023-02-28 04:43:36 --> Security Class Initialized
DEBUG - 2023-02-28 04:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:43:36 --> Input Class Initialized
INFO - 2023-02-28 04:43:36 --> Language Class Initialized
INFO - 2023-02-28 04:43:36 --> Loader Class Initialized
INFO - 2023-02-28 04:43:36 --> Controller Class Initialized
DEBUG - 2023-02-28 04:43:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:43:36 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:36 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:43:36 --> Final output sent to browser
DEBUG - 2023-02-28 04:43:36 --> Total execution time: 0.0487
INFO - 2023-02-28 04:43:36 --> Config Class Initialized
INFO - 2023-02-28 04:43:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:43:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:43:36 --> Utf8 Class Initialized
INFO - 2023-02-28 04:43:36 --> URI Class Initialized
INFO - 2023-02-28 04:43:36 --> Router Class Initialized
INFO - 2023-02-28 04:43:36 --> Output Class Initialized
INFO - 2023-02-28 04:43:36 --> Security Class Initialized
DEBUG - 2023-02-28 04:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:43:36 --> Input Class Initialized
INFO - 2023-02-28 04:43:36 --> Language Class Initialized
INFO - 2023-02-28 04:43:36 --> Loader Class Initialized
INFO - 2023-02-28 04:43:36 --> Controller Class Initialized
DEBUG - 2023-02-28 04:43:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:43:36 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:36 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:43:36 --> Final output sent to browser
DEBUG - 2023-02-28 04:43:36 --> Total execution time: 0.0506
INFO - 2023-02-28 04:43:39 --> Config Class Initialized
INFO - 2023-02-28 04:43:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:43:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:43:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:43:39 --> URI Class Initialized
INFO - 2023-02-28 04:43:39 --> Router Class Initialized
INFO - 2023-02-28 04:43:39 --> Output Class Initialized
INFO - 2023-02-28 04:43:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:43:39 --> Input Class Initialized
INFO - 2023-02-28 04:43:39 --> Language Class Initialized
INFO - 2023-02-28 04:43:39 --> Loader Class Initialized
INFO - 2023-02-28 04:43:39 --> Controller Class Initialized
DEBUG - 2023-02-28 04:43:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:43:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:39 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:43:39 --> Final output sent to browser
DEBUG - 2023-02-28 04:43:39 --> Total execution time: 0.0627
INFO - 2023-02-28 04:43:39 --> Config Class Initialized
INFO - 2023-02-28 04:43:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:43:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:43:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:43:39 --> URI Class Initialized
INFO - 2023-02-28 04:43:39 --> Router Class Initialized
INFO - 2023-02-28 04:43:39 --> Output Class Initialized
INFO - 2023-02-28 04:43:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:43:39 --> Input Class Initialized
INFO - 2023-02-28 04:43:39 --> Language Class Initialized
INFO - 2023-02-28 04:43:39 --> Loader Class Initialized
INFO - 2023-02-28 04:43:39 --> Controller Class Initialized
DEBUG - 2023-02-28 04:43:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:43:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:39 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:43:39 --> Final output sent to browser
DEBUG - 2023-02-28 04:43:39 --> Total execution time: 0.0266
INFO - 2023-02-28 04:43:41 --> Config Class Initialized
INFO - 2023-02-28 04:43:41 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:43:41 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:43:41 --> Utf8 Class Initialized
INFO - 2023-02-28 04:43:41 --> URI Class Initialized
INFO - 2023-02-28 04:43:41 --> Router Class Initialized
INFO - 2023-02-28 04:43:41 --> Output Class Initialized
INFO - 2023-02-28 04:43:41 --> Security Class Initialized
DEBUG - 2023-02-28 04:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:43:41 --> Input Class Initialized
INFO - 2023-02-28 04:43:41 --> Language Class Initialized
INFO - 2023-02-28 04:43:41 --> Loader Class Initialized
INFO - 2023-02-28 04:43:41 --> Controller Class Initialized
DEBUG - 2023-02-28 04:43:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:43:41 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:41 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:43:41 --> Final output sent to browser
DEBUG - 2023-02-28 04:43:41 --> Total execution time: 0.0489
INFO - 2023-02-28 04:43:41 --> Config Class Initialized
INFO - 2023-02-28 04:43:41 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:43:41 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:43:41 --> Utf8 Class Initialized
INFO - 2023-02-28 04:43:41 --> URI Class Initialized
INFO - 2023-02-28 04:43:41 --> Router Class Initialized
INFO - 2023-02-28 04:43:41 --> Output Class Initialized
INFO - 2023-02-28 04:43:41 --> Security Class Initialized
DEBUG - 2023-02-28 04:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:43:41 --> Input Class Initialized
INFO - 2023-02-28 04:43:41 --> Language Class Initialized
INFO - 2023-02-28 04:43:41 --> Loader Class Initialized
INFO - 2023-02-28 04:43:41 --> Controller Class Initialized
DEBUG - 2023-02-28 04:43:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:43:41 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:41 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:43:41 --> Final output sent to browser
DEBUG - 2023-02-28 04:43:41 --> Total execution time: 0.1005
INFO - 2023-02-28 04:43:42 --> Config Class Initialized
INFO - 2023-02-28 04:43:42 --> Config Class Initialized
INFO - 2023-02-28 04:43:42 --> Hooks Class Initialized
INFO - 2023-02-28 04:43:42 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:43:42 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:43:42 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:43:42 --> Utf8 Class Initialized
INFO - 2023-02-28 04:43:42 --> Utf8 Class Initialized
INFO - 2023-02-28 04:43:42 --> URI Class Initialized
INFO - 2023-02-28 04:43:42 --> URI Class Initialized
INFO - 2023-02-28 04:43:42 --> Router Class Initialized
INFO - 2023-02-28 04:43:42 --> Router Class Initialized
INFO - 2023-02-28 04:43:42 --> Output Class Initialized
INFO - 2023-02-28 04:43:42 --> Output Class Initialized
INFO - 2023-02-28 04:43:42 --> Security Class Initialized
INFO - 2023-02-28 04:43:42 --> Security Class Initialized
DEBUG - 2023-02-28 04:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:43:42 --> Input Class Initialized
INFO - 2023-02-28 04:43:42 --> Input Class Initialized
INFO - 2023-02-28 04:43:42 --> Language Class Initialized
INFO - 2023-02-28 04:43:42 --> Language Class Initialized
INFO - 2023-02-28 04:43:42 --> Loader Class Initialized
INFO - 2023-02-28 04:43:42 --> Loader Class Initialized
INFO - 2023-02-28 04:43:42 --> Controller Class Initialized
INFO - 2023-02-28 04:43:42 --> Controller Class Initialized
DEBUG - 2023-02-28 04:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:43:42 --> Final output sent to browser
DEBUG - 2023-02-28 04:43:42 --> Total execution time: 0.0045
INFO - 2023-02-28 04:43:42 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:42 --> Config Class Initialized
INFO - 2023-02-28 04:43:42 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:43:42 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:43:42 --> Utf8 Class Initialized
INFO - 2023-02-28 04:43:42 --> URI Class Initialized
INFO - 2023-02-28 04:43:42 --> Router Class Initialized
INFO - 2023-02-28 04:43:42 --> Output Class Initialized
INFO - 2023-02-28 04:43:42 --> Security Class Initialized
DEBUG - 2023-02-28 04:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:43:42 --> Input Class Initialized
INFO - 2023-02-28 04:43:42 --> Language Class Initialized
INFO - 2023-02-28 04:43:42 --> Loader Class Initialized
INFO - 2023-02-28 04:43:42 --> Controller Class Initialized
DEBUG - 2023-02-28 04:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:43:42 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:42 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:43:42 --> Model "Login_model" initialized
INFO - 2023-02-28 04:43:42 --> Final output sent to browser
DEBUG - 2023-02-28 04:43:42 --> Total execution time: 0.0155
INFO - 2023-02-28 04:43:42 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:42 --> Config Class Initialized
INFO - 2023-02-28 04:43:42 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:43:42 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:43:42 --> Utf8 Class Initialized
INFO - 2023-02-28 04:43:42 --> URI Class Initialized
INFO - 2023-02-28 04:43:42 --> Router Class Initialized
INFO - 2023-02-28 04:43:42 --> Output Class Initialized
INFO - 2023-02-28 04:43:42 --> Security Class Initialized
DEBUG - 2023-02-28 04:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:43:42 --> Input Class Initialized
INFO - 2023-02-28 04:43:42 --> Language Class Initialized
INFO - 2023-02-28 04:43:42 --> Loader Class Initialized
INFO - 2023-02-28 04:43:42 --> Controller Class Initialized
DEBUG - 2023-02-28 04:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:43:42 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:42 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:43:42 --> Final output sent to browser
DEBUG - 2023-02-28 04:43:42 --> Total execution time: 0.0198
INFO - 2023-02-28 04:43:42 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:43:42 --> Final output sent to browser
DEBUG - 2023-02-28 04:43:42 --> Total execution time: 0.0143
INFO - 2023-02-28 04:43:43 --> Config Class Initialized
INFO - 2023-02-28 04:43:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:43:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:43:43 --> Utf8 Class Initialized
INFO - 2023-02-28 04:43:43 --> URI Class Initialized
INFO - 2023-02-28 04:43:43 --> Router Class Initialized
INFO - 2023-02-28 04:43:43 --> Output Class Initialized
INFO - 2023-02-28 04:43:43 --> Security Class Initialized
DEBUG - 2023-02-28 04:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:43:43 --> Input Class Initialized
INFO - 2023-02-28 04:43:43 --> Language Class Initialized
INFO - 2023-02-28 04:43:43 --> Loader Class Initialized
INFO - 2023-02-28 04:43:43 --> Controller Class Initialized
DEBUG - 2023-02-28 04:43:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:43:43 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:43 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:43:43 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:43 --> Model "Login_model" initialized
INFO - 2023-02-28 04:43:43 --> Final output sent to browser
DEBUG - 2023-02-28 04:43:43 --> Total execution time: 0.1035
INFO - 2023-02-28 04:43:43 --> Config Class Initialized
INFO - 2023-02-28 04:43:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:43:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:43:43 --> Utf8 Class Initialized
INFO - 2023-02-28 04:43:43 --> URI Class Initialized
INFO - 2023-02-28 04:43:43 --> Router Class Initialized
INFO - 2023-02-28 04:43:43 --> Output Class Initialized
INFO - 2023-02-28 04:43:43 --> Security Class Initialized
DEBUG - 2023-02-28 04:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:43:43 --> Input Class Initialized
INFO - 2023-02-28 04:43:43 --> Language Class Initialized
INFO - 2023-02-28 04:43:43 --> Loader Class Initialized
INFO - 2023-02-28 04:43:43 --> Controller Class Initialized
DEBUG - 2023-02-28 04:43:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:43:43 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:43 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:43:43 --> Database Driver Class Initialized
INFO - 2023-02-28 04:43:43 --> Model "Login_model" initialized
INFO - 2023-02-28 04:43:43 --> Final output sent to browser
DEBUG - 2023-02-28 04:43:43 --> Total execution time: 0.0666
INFO - 2023-02-28 04:44:18 --> Config Class Initialized
INFO - 2023-02-28 04:44:18 --> Config Class Initialized
INFO - 2023-02-28 04:44:18 --> Hooks Class Initialized
INFO - 2023-02-28 04:44:18 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:44:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:44:18 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:44:18 --> Utf8 Class Initialized
INFO - 2023-02-28 04:44:18 --> Utf8 Class Initialized
INFO - 2023-02-28 04:44:18 --> URI Class Initialized
INFO - 2023-02-28 04:44:18 --> URI Class Initialized
INFO - 2023-02-28 04:44:18 --> Router Class Initialized
INFO - 2023-02-28 04:44:18 --> Router Class Initialized
INFO - 2023-02-28 04:44:18 --> Output Class Initialized
INFO - 2023-02-28 04:44:18 --> Output Class Initialized
INFO - 2023-02-28 04:44:18 --> Security Class Initialized
INFO - 2023-02-28 04:44:18 --> Security Class Initialized
DEBUG - 2023-02-28 04:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:44:18 --> Input Class Initialized
INFO - 2023-02-28 04:44:18 --> Input Class Initialized
INFO - 2023-02-28 04:44:18 --> Language Class Initialized
INFO - 2023-02-28 04:44:18 --> Language Class Initialized
INFO - 2023-02-28 04:44:18 --> Loader Class Initialized
INFO - 2023-02-28 04:44:18 --> Loader Class Initialized
INFO - 2023-02-28 04:44:18 --> Controller Class Initialized
INFO - 2023-02-28 04:44:18 --> Controller Class Initialized
DEBUG - 2023-02-28 04:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:44:18 --> Final output sent to browser
DEBUG - 2023-02-28 04:44:18 --> Total execution time: 0.0044
INFO - 2023-02-28 04:44:18 --> Database Driver Class Initialized
INFO - 2023-02-28 04:44:18 --> Config Class Initialized
INFO - 2023-02-28 04:44:18 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:44:18 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:44:18 --> Utf8 Class Initialized
INFO - 2023-02-28 04:44:18 --> URI Class Initialized
INFO - 2023-02-28 04:44:18 --> Router Class Initialized
INFO - 2023-02-28 04:44:18 --> Output Class Initialized
INFO - 2023-02-28 04:44:18 --> Security Class Initialized
DEBUG - 2023-02-28 04:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:44:18 --> Input Class Initialized
INFO - 2023-02-28 04:44:18 --> Language Class Initialized
INFO - 2023-02-28 04:44:18 --> Loader Class Initialized
INFO - 2023-02-28 04:44:18 --> Controller Class Initialized
DEBUG - 2023-02-28 04:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:44:18 --> Database Driver Class Initialized
INFO - 2023-02-28 04:44:18 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:44:18 --> Model "Login_model" initialized
INFO - 2023-02-28 04:44:18 --> Final output sent to browser
INFO - 2023-02-28 04:44:18 --> Database Driver Class Initialized
DEBUG - 2023-02-28 04:44:18 --> Total execution time: 0.0172
INFO - 2023-02-28 04:44:18 --> Config Class Initialized
INFO - 2023-02-28 04:44:18 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:44:18 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:44:18 --> Utf8 Class Initialized
INFO - 2023-02-28 04:44:18 --> URI Class Initialized
INFO - 2023-02-28 04:44:18 --> Router Class Initialized
INFO - 2023-02-28 04:44:18 --> Output Class Initialized
INFO - 2023-02-28 04:44:18 --> Security Class Initialized
DEBUG - 2023-02-28 04:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:44:18 --> Input Class Initialized
INFO - 2023-02-28 04:44:18 --> Language Class Initialized
INFO - 2023-02-28 04:44:18 --> Loader Class Initialized
INFO - 2023-02-28 04:44:18 --> Controller Class Initialized
DEBUG - 2023-02-28 04:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:44:18 --> Database Driver Class Initialized
INFO - 2023-02-28 04:44:18 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:44:18 --> Final output sent to browser
DEBUG - 2023-02-28 04:44:18 --> Total execution time: 0.0227
INFO - 2023-02-28 04:44:18 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:44:18 --> Final output sent to browser
DEBUG - 2023-02-28 04:44:18 --> Total execution time: 0.0564
INFO - 2023-02-28 04:44:21 --> Config Class Initialized
INFO - 2023-02-28 04:44:21 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:44:21 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:44:21 --> Utf8 Class Initialized
INFO - 2023-02-28 04:44:21 --> URI Class Initialized
INFO - 2023-02-28 04:44:21 --> Router Class Initialized
INFO - 2023-02-28 04:44:21 --> Output Class Initialized
INFO - 2023-02-28 04:44:21 --> Security Class Initialized
DEBUG - 2023-02-28 04:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:44:21 --> Input Class Initialized
INFO - 2023-02-28 04:44:21 --> Language Class Initialized
INFO - 2023-02-28 04:44:21 --> Loader Class Initialized
INFO - 2023-02-28 04:44:21 --> Controller Class Initialized
DEBUG - 2023-02-28 04:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:44:21 --> Database Driver Class Initialized
INFO - 2023-02-28 04:44:21 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:44:21 --> Final output sent to browser
DEBUG - 2023-02-28 04:44:21 --> Total execution time: 0.0235
INFO - 2023-02-28 04:44:21 --> Config Class Initialized
INFO - 2023-02-28 04:44:21 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:44:21 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:44:21 --> Utf8 Class Initialized
INFO - 2023-02-28 04:44:21 --> URI Class Initialized
INFO - 2023-02-28 04:44:21 --> Router Class Initialized
INFO - 2023-02-28 04:44:21 --> Output Class Initialized
INFO - 2023-02-28 04:44:21 --> Security Class Initialized
DEBUG - 2023-02-28 04:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:44:21 --> Input Class Initialized
INFO - 2023-02-28 04:44:21 --> Language Class Initialized
INFO - 2023-02-28 04:44:21 --> Loader Class Initialized
INFO - 2023-02-28 04:44:21 --> Controller Class Initialized
DEBUG - 2023-02-28 04:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:44:21 --> Database Driver Class Initialized
INFO - 2023-02-28 04:44:21 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:44:21 --> Final output sent to browser
DEBUG - 2023-02-28 04:44:21 --> Total execution time: 0.0359
INFO - 2023-02-28 04:44:30 --> Config Class Initialized
INFO - 2023-02-28 04:44:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:44:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:44:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:44:30 --> URI Class Initialized
INFO - 2023-02-28 04:44:30 --> Router Class Initialized
INFO - 2023-02-28 04:44:30 --> Output Class Initialized
INFO - 2023-02-28 04:44:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:44:30 --> Input Class Initialized
INFO - 2023-02-28 04:44:30 --> Language Class Initialized
INFO - 2023-02-28 04:44:30 --> Loader Class Initialized
INFO - 2023-02-28 04:44:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:44:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:44:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:44:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:44:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:44:30 --> Total execution time: 0.0667
INFO - 2023-02-28 04:44:30 --> Config Class Initialized
INFO - 2023-02-28 04:44:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:44:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:44:30 --> Utf8 Class Initialized
INFO - 2023-02-28 04:44:30 --> URI Class Initialized
INFO - 2023-02-28 04:44:30 --> Router Class Initialized
INFO - 2023-02-28 04:44:30 --> Output Class Initialized
INFO - 2023-02-28 04:44:30 --> Security Class Initialized
DEBUG - 2023-02-28 04:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:44:30 --> Input Class Initialized
INFO - 2023-02-28 04:44:30 --> Language Class Initialized
INFO - 2023-02-28 04:44:30 --> Loader Class Initialized
INFO - 2023-02-28 04:44:30 --> Controller Class Initialized
DEBUG - 2023-02-28 04:44:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:44:30 --> Database Driver Class Initialized
INFO - 2023-02-28 04:44:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:44:30 --> Final output sent to browser
DEBUG - 2023-02-28 04:44:30 --> Total execution time: 0.0520
INFO - 2023-02-28 04:44:32 --> Config Class Initialized
INFO - 2023-02-28 04:44:32 --> Config Class Initialized
INFO - 2023-02-28 04:44:32 --> Hooks Class Initialized
INFO - 2023-02-28 04:44:32 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:44:32 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:44:32 --> Utf8 Class Initialized
DEBUG - 2023-02-28 04:44:32 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:44:32 --> URI Class Initialized
INFO - 2023-02-28 04:44:32 --> Utf8 Class Initialized
INFO - 2023-02-28 04:44:32 --> Router Class Initialized
INFO - 2023-02-28 04:44:32 --> URI Class Initialized
INFO - 2023-02-28 04:44:32 --> Output Class Initialized
INFO - 2023-02-28 04:44:32 --> Router Class Initialized
INFO - 2023-02-28 04:44:32 --> Security Class Initialized
INFO - 2023-02-28 04:44:32 --> Output Class Initialized
DEBUG - 2023-02-28 04:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:44:32 --> Security Class Initialized
INFO - 2023-02-28 04:44:32 --> Input Class Initialized
DEBUG - 2023-02-28 04:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:44:32 --> Language Class Initialized
INFO - 2023-02-28 04:44:32 --> Input Class Initialized
INFO - 2023-02-28 04:44:32 --> Language Class Initialized
INFO - 2023-02-28 04:44:32 --> Loader Class Initialized
INFO - 2023-02-28 04:44:32 --> Loader Class Initialized
INFO - 2023-02-28 04:44:32 --> Controller Class Initialized
INFO - 2023-02-28 04:44:32 --> Controller Class Initialized
DEBUG - 2023-02-28 04:44:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:44:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:44:32 --> Database Driver Class Initialized
INFO - 2023-02-28 04:44:32 --> Final output sent to browser
DEBUG - 2023-02-28 04:44:32 --> Total execution time: 0.0045
INFO - 2023-02-28 04:44:32 --> Config Class Initialized
INFO - 2023-02-28 04:44:32 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:44:32 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:44:32 --> Utf8 Class Initialized
INFO - 2023-02-28 04:44:32 --> URI Class Initialized
INFO - 2023-02-28 04:44:32 --> Router Class Initialized
INFO - 2023-02-28 04:44:32 --> Output Class Initialized
INFO - 2023-02-28 04:44:32 --> Security Class Initialized
DEBUG - 2023-02-28 04:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:44:32 --> Input Class Initialized
INFO - 2023-02-28 04:44:32 --> Language Class Initialized
INFO - 2023-02-28 04:44:32 --> Loader Class Initialized
INFO - 2023-02-28 04:44:32 --> Controller Class Initialized
DEBUG - 2023-02-28 04:44:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:44:32 --> Database Driver Class Initialized
INFO - 2023-02-28 04:44:32 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:44:32 --> Final output sent to browser
DEBUG - 2023-02-28 04:44:32 --> Total execution time: 0.0223
INFO - 2023-02-28 04:44:32 --> Config Class Initialized
INFO - 2023-02-28 04:44:32 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:44:32 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:44:32 --> Utf8 Class Initialized
INFO - 2023-02-28 04:44:32 --> URI Class Initialized
INFO - 2023-02-28 04:44:32 --> Router Class Initialized
INFO - 2023-02-28 04:44:32 --> Output Class Initialized
INFO - 2023-02-28 04:44:32 --> Security Class Initialized
DEBUG - 2023-02-28 04:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:44:32 --> Input Class Initialized
INFO - 2023-02-28 04:44:32 --> Language Class Initialized
INFO - 2023-02-28 04:44:32 --> Loader Class Initialized
INFO - 2023-02-28 04:44:32 --> Controller Class Initialized
DEBUG - 2023-02-28 04:44:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:44:32 --> Database Driver Class Initialized
INFO - 2023-02-28 04:44:32 --> Model "Login_model" initialized
INFO - 2023-02-28 04:44:32 --> Database Driver Class Initialized
INFO - 2023-02-28 04:44:32 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:44:32 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:44:32 --> Final output sent to browser
DEBUG - 2023-02-28 04:44:32 --> Total execution time: 0.0206
INFO - 2023-02-28 04:44:32 --> Final output sent to browser
DEBUG - 2023-02-28 04:44:32 --> Total execution time: 0.0437
INFO - 2023-02-28 04:44:34 --> Config Class Initialized
INFO - 2023-02-28 04:44:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:44:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:44:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:44:34 --> URI Class Initialized
INFO - 2023-02-28 04:44:34 --> Router Class Initialized
INFO - 2023-02-28 04:44:34 --> Output Class Initialized
INFO - 2023-02-28 04:44:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:44:34 --> Input Class Initialized
INFO - 2023-02-28 04:44:34 --> Language Class Initialized
INFO - 2023-02-28 04:44:34 --> Loader Class Initialized
INFO - 2023-02-28 04:44:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:44:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:44:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:44:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:44:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:44:34 --> Total execution time: 0.0178
INFO - 2023-02-28 04:44:34 --> Config Class Initialized
INFO - 2023-02-28 04:44:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:44:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:44:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:44:34 --> URI Class Initialized
INFO - 2023-02-28 04:44:34 --> Router Class Initialized
INFO - 2023-02-28 04:44:34 --> Output Class Initialized
INFO - 2023-02-28 04:44:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:44:34 --> Input Class Initialized
INFO - 2023-02-28 04:44:34 --> Language Class Initialized
INFO - 2023-02-28 04:44:34 --> Loader Class Initialized
INFO - 2023-02-28 04:44:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:44:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:44:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:44:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:44:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:44:34 --> Total execution time: 0.0180
INFO - 2023-02-28 04:45:34 --> Config Class Initialized
INFO - 2023-02-28 04:45:34 --> Config Class Initialized
INFO - 2023-02-28 04:45:34 --> Hooks Class Initialized
INFO - 2023-02-28 04:45:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:45:34 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:45:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:45:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:45:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:45:34 --> URI Class Initialized
INFO - 2023-02-28 04:45:34 --> URI Class Initialized
INFO - 2023-02-28 04:45:34 --> Router Class Initialized
INFO - 2023-02-28 04:45:34 --> Router Class Initialized
INFO - 2023-02-28 04:45:34 --> Output Class Initialized
INFO - 2023-02-28 04:45:34 --> Output Class Initialized
INFO - 2023-02-28 04:45:34 --> Security Class Initialized
INFO - 2023-02-28 04:45:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:45:34 --> Input Class Initialized
INFO - 2023-02-28 04:45:34 --> Input Class Initialized
INFO - 2023-02-28 04:45:34 --> Language Class Initialized
INFO - 2023-02-28 04:45:34 --> Language Class Initialized
INFO - 2023-02-28 04:45:34 --> Loader Class Initialized
INFO - 2023-02-28 04:45:34 --> Loader Class Initialized
INFO - 2023-02-28 04:45:34 --> Controller Class Initialized
INFO - 2023-02-28 04:45:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:45:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:45:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:45:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:45:35 --> Model "Login_model" initialized
INFO - 2023-02-28 04:45:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:45:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:45:35 --> Total execution time: 0.0634
INFO - 2023-02-28 04:45:35 --> Config Class Initialized
INFO - 2023-02-28 04:45:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:45:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:45:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:45:35 --> URI Class Initialized
INFO - 2023-02-28 04:45:35 --> Router Class Initialized
INFO - 2023-02-28 04:45:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:45:35 --> Output Class Initialized
INFO - 2023-02-28 04:45:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:45:35 --> Input Class Initialized
INFO - 2023-02-28 04:45:35 --> Language Class Initialized
INFO - 2023-02-28 04:45:35 --> Loader Class Initialized
INFO - 2023-02-28 04:45:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:45:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:45:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:45:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:45:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:45:35 --> Total execution time: 0.0211
INFO - 2023-02-28 04:45:36 --> Final output sent to browser
DEBUG - 2023-02-28 04:45:36 --> Total execution time: 1.0939
INFO - 2023-02-28 04:45:36 --> Config Class Initialized
INFO - 2023-02-28 04:45:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:45:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:45:36 --> Utf8 Class Initialized
INFO - 2023-02-28 04:45:36 --> URI Class Initialized
INFO - 2023-02-28 04:45:36 --> Router Class Initialized
INFO - 2023-02-28 04:45:36 --> Output Class Initialized
INFO - 2023-02-28 04:45:36 --> Security Class Initialized
DEBUG - 2023-02-28 04:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:45:36 --> Input Class Initialized
INFO - 2023-02-28 04:45:36 --> Language Class Initialized
INFO - 2023-02-28 04:45:36 --> Loader Class Initialized
INFO - 2023-02-28 04:45:36 --> Controller Class Initialized
DEBUG - 2023-02-28 04:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:45:36 --> Database Driver Class Initialized
INFO - 2023-02-28 04:45:36 --> Model "Login_model" initialized
INFO - 2023-02-28 04:45:36 --> Database Driver Class Initialized
INFO - 2023-02-28 04:45:36 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:45:37 --> Final output sent to browser
DEBUG - 2023-02-28 04:45:37 --> Total execution time: 1.2971
INFO - 2023-02-28 04:46:34 --> Config Class Initialized
INFO - 2023-02-28 04:46:34 --> Config Class Initialized
INFO - 2023-02-28 04:46:34 --> Hooks Class Initialized
INFO - 2023-02-28 04:46:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:46:34 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:46:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:46:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:46:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:46:34 --> URI Class Initialized
INFO - 2023-02-28 04:46:34 --> URI Class Initialized
INFO - 2023-02-28 04:46:34 --> Router Class Initialized
INFO - 2023-02-28 04:46:34 --> Router Class Initialized
INFO - 2023-02-28 04:46:34 --> Output Class Initialized
INFO - 2023-02-28 04:46:34 --> Output Class Initialized
INFO - 2023-02-28 04:46:34 --> Security Class Initialized
INFO - 2023-02-28 04:46:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:46:34 --> Input Class Initialized
INFO - 2023-02-28 04:46:34 --> Input Class Initialized
INFO - 2023-02-28 04:46:34 --> Language Class Initialized
INFO - 2023-02-28 04:46:34 --> Language Class Initialized
INFO - 2023-02-28 04:46:34 --> Loader Class Initialized
INFO - 2023-02-28 04:46:34 --> Loader Class Initialized
INFO - 2023-02-28 04:46:34 --> Controller Class Initialized
INFO - 2023-02-28 04:46:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:46:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:46:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:46:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:46:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:46:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:46:34 --> Model "Login_model" initialized
INFO - 2023-02-28 04:46:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:46:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:46:34 --> Total execution time: 0.0248
INFO - 2023-02-28 04:46:34 --> Config Class Initialized
INFO - 2023-02-28 04:46:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:46:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:46:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:46:34 --> URI Class Initialized
INFO - 2023-02-28 04:46:34 --> Router Class Initialized
INFO - 2023-02-28 04:46:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:46:34 --> Output Class Initialized
INFO - 2023-02-28 04:46:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:46:34 --> Input Class Initialized
INFO - 2023-02-28 04:46:34 --> Language Class Initialized
INFO - 2023-02-28 04:46:34 --> Loader Class Initialized
INFO - 2023-02-28 04:46:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:46:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:46:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:46:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:46:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:46:34 --> Total execution time: 0.0197
INFO - 2023-02-28 04:46:36 --> Final output sent to browser
DEBUG - 2023-02-28 04:46:36 --> Total execution time: 1.0996
INFO - 2023-02-28 04:46:36 --> Config Class Initialized
INFO - 2023-02-28 04:46:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:46:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:46:36 --> Utf8 Class Initialized
INFO - 2023-02-28 04:46:36 --> URI Class Initialized
INFO - 2023-02-28 04:46:36 --> Router Class Initialized
INFO - 2023-02-28 04:46:36 --> Output Class Initialized
INFO - 2023-02-28 04:46:36 --> Security Class Initialized
DEBUG - 2023-02-28 04:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:46:36 --> Input Class Initialized
INFO - 2023-02-28 04:46:36 --> Language Class Initialized
INFO - 2023-02-28 04:46:36 --> Loader Class Initialized
INFO - 2023-02-28 04:46:36 --> Controller Class Initialized
DEBUG - 2023-02-28 04:46:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:46:36 --> Database Driver Class Initialized
INFO - 2023-02-28 04:46:36 --> Model "Login_model" initialized
INFO - 2023-02-28 04:46:36 --> Database Driver Class Initialized
INFO - 2023-02-28 04:46:36 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:46:37 --> Final output sent to browser
DEBUG - 2023-02-28 04:46:37 --> Total execution time: 1.0369
INFO - 2023-02-28 04:47:34 --> Config Class Initialized
INFO - 2023-02-28 04:47:34 --> Config Class Initialized
INFO - 2023-02-28 04:47:34 --> Hooks Class Initialized
INFO - 2023-02-28 04:47:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:47:34 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:47:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:47:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:47:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:47:34 --> URI Class Initialized
INFO - 2023-02-28 04:47:34 --> URI Class Initialized
INFO - 2023-02-28 04:47:34 --> Router Class Initialized
INFO - 2023-02-28 04:47:34 --> Router Class Initialized
INFO - 2023-02-28 04:47:34 --> Output Class Initialized
INFO - 2023-02-28 04:47:34 --> Output Class Initialized
INFO - 2023-02-28 04:47:34 --> Security Class Initialized
INFO - 2023-02-28 04:47:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:47:34 --> Input Class Initialized
INFO - 2023-02-28 04:47:34 --> Input Class Initialized
INFO - 2023-02-28 04:47:34 --> Language Class Initialized
INFO - 2023-02-28 04:47:34 --> Language Class Initialized
INFO - 2023-02-28 04:47:34 --> Loader Class Initialized
INFO - 2023-02-28 04:47:34 --> Loader Class Initialized
INFO - 2023-02-28 04:47:34 --> Controller Class Initialized
INFO - 2023-02-28 04:47:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:47:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:47:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:47:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:47:34 --> Model "Login_model" initialized
INFO - 2023-02-28 04:47:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:47:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:47:34 --> Total execution time: 0.0227
INFO - 2023-02-28 04:47:34 --> Config Class Initialized
INFO - 2023-02-28 04:47:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:47:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:47:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:47:34 --> URI Class Initialized
INFO - 2023-02-28 04:47:34 --> Router Class Initialized
INFO - 2023-02-28 04:47:34 --> Output Class Initialized
INFO - 2023-02-28 04:47:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:47:34 --> Input Class Initialized
INFO - 2023-02-28 04:47:34 --> Language Class Initialized
INFO - 2023-02-28 04:47:34 --> Loader Class Initialized
INFO - 2023-02-28 04:47:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:47:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:47:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:47:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:47:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:47:34 --> Total execution time: 0.0153
INFO - 2023-02-28 04:47:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:47:35 --> Total execution time: 1.0458
INFO - 2023-02-28 04:47:35 --> Config Class Initialized
INFO - 2023-02-28 04:47:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:47:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:47:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:47:35 --> URI Class Initialized
INFO - 2023-02-28 04:47:35 --> Router Class Initialized
INFO - 2023-02-28 04:47:35 --> Output Class Initialized
INFO - 2023-02-28 04:47:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:47:35 --> Input Class Initialized
INFO - 2023-02-28 04:47:35 --> Language Class Initialized
INFO - 2023-02-28 04:47:35 --> Loader Class Initialized
INFO - 2023-02-28 04:47:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:47:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:47:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:47:36 --> Model "Login_model" initialized
INFO - 2023-02-28 04:47:36 --> Database Driver Class Initialized
INFO - 2023-02-28 04:47:36 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:47:37 --> Final output sent to browser
DEBUG - 2023-02-28 04:47:37 --> Total execution time: 1.1074
INFO - 2023-02-28 04:48:03 --> Config Class Initialized
INFO - 2023-02-28 04:48:03 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:03 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:03 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:03 --> URI Class Initialized
INFO - 2023-02-28 04:48:03 --> Router Class Initialized
INFO - 2023-02-28 04:48:03 --> Output Class Initialized
INFO - 2023-02-28 04:48:03 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:03 --> Input Class Initialized
INFO - 2023-02-28 04:48:03 --> Language Class Initialized
INFO - 2023-02-28 04:48:03 --> Loader Class Initialized
INFO - 2023-02-28 04:48:03 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:03 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:03 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:03 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:03 --> Total execution time: 0.0173
INFO - 2023-02-28 04:48:03 --> Config Class Initialized
INFO - 2023-02-28 04:48:03 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:03 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:03 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:03 --> URI Class Initialized
INFO - 2023-02-28 04:48:03 --> Router Class Initialized
INFO - 2023-02-28 04:48:03 --> Output Class Initialized
INFO - 2023-02-28 04:48:03 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:03 --> Input Class Initialized
INFO - 2023-02-28 04:48:03 --> Language Class Initialized
INFO - 2023-02-28 04:48:03 --> Loader Class Initialized
INFO - 2023-02-28 04:48:03 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:03 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:03 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:03 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:03 --> Total execution time: 0.0171
INFO - 2023-02-28 04:48:05 --> Config Class Initialized
INFO - 2023-02-28 04:48:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:05 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:05 --> URI Class Initialized
INFO - 2023-02-28 04:48:05 --> Router Class Initialized
INFO - 2023-02-28 04:48:05 --> Output Class Initialized
INFO - 2023-02-28 04:48:05 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:05 --> Input Class Initialized
INFO - 2023-02-28 04:48:05 --> Language Class Initialized
INFO - 2023-02-28 04:48:05 --> Loader Class Initialized
INFO - 2023-02-28 04:48:05 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:05 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:05 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:05 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:05 --> Total execution time: 0.1343
INFO - 2023-02-28 04:48:05 --> Config Class Initialized
INFO - 2023-02-28 04:48:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:05 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:05 --> URI Class Initialized
INFO - 2023-02-28 04:48:05 --> Router Class Initialized
INFO - 2023-02-28 04:48:05 --> Output Class Initialized
INFO - 2023-02-28 04:48:05 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:05 --> Input Class Initialized
INFO - 2023-02-28 04:48:05 --> Language Class Initialized
INFO - 2023-02-28 04:48:05 --> Loader Class Initialized
INFO - 2023-02-28 04:48:05 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:05 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:05 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:05 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:05 --> Total execution time: 0.0432
INFO - 2023-02-28 04:48:27 --> Config Class Initialized
INFO - 2023-02-28 04:48:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:27 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:27 --> URI Class Initialized
INFO - 2023-02-28 04:48:27 --> Router Class Initialized
INFO - 2023-02-28 04:48:27 --> Output Class Initialized
INFO - 2023-02-28 04:48:27 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:27 --> Input Class Initialized
INFO - 2023-02-28 04:48:27 --> Language Class Initialized
INFO - 2023-02-28 04:48:27 --> Loader Class Initialized
INFO - 2023-02-28 04:48:27 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:27 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:27 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:27 --> Total execution time: 0.0191
INFO - 2023-02-28 04:48:27 --> Config Class Initialized
INFO - 2023-02-28 04:48:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:27 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:27 --> URI Class Initialized
INFO - 2023-02-28 04:48:27 --> Router Class Initialized
INFO - 2023-02-28 04:48:27 --> Output Class Initialized
INFO - 2023-02-28 04:48:27 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:27 --> Input Class Initialized
INFO - 2023-02-28 04:48:27 --> Language Class Initialized
INFO - 2023-02-28 04:48:27 --> Loader Class Initialized
INFO - 2023-02-28 04:48:27 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:27 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:27 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:27 --> Total execution time: 0.0182
INFO - 2023-02-28 04:48:31 --> Config Class Initialized
INFO - 2023-02-28 04:48:31 --> Config Class Initialized
INFO - 2023-02-28 04:48:31 --> Hooks Class Initialized
INFO - 2023-02-28 04:48:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:31 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:48:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:31 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:31 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:31 --> URI Class Initialized
INFO - 2023-02-28 04:48:31 --> URI Class Initialized
INFO - 2023-02-28 04:48:31 --> Router Class Initialized
INFO - 2023-02-28 04:48:31 --> Router Class Initialized
INFO - 2023-02-28 04:48:31 --> Output Class Initialized
INFO - 2023-02-28 04:48:31 --> Output Class Initialized
INFO - 2023-02-28 04:48:31 --> Security Class Initialized
INFO - 2023-02-28 04:48:31 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:31 --> Input Class Initialized
INFO - 2023-02-28 04:48:31 --> Input Class Initialized
INFO - 2023-02-28 04:48:31 --> Language Class Initialized
INFO - 2023-02-28 04:48:31 --> Language Class Initialized
INFO - 2023-02-28 04:48:31 --> Loader Class Initialized
INFO - 2023-02-28 04:48:31 --> Loader Class Initialized
INFO - 2023-02-28 04:48:31 --> Controller Class Initialized
INFO - 2023-02-28 04:48:31 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:48:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:31 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:31 --> Total execution time: 0.0320
INFO - 2023-02-28 04:48:31 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:31 --> Config Class Initialized
INFO - 2023-02-28 04:48:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:31 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:31 --> URI Class Initialized
INFO - 2023-02-28 04:48:31 --> Router Class Initialized
INFO - 2023-02-28 04:48:31 --> Output Class Initialized
INFO - 2023-02-28 04:48:31 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:31 --> Input Class Initialized
INFO - 2023-02-28 04:48:31 --> Language Class Initialized
INFO - 2023-02-28 04:48:31 --> Loader Class Initialized
INFO - 2023-02-28 04:48:31 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:31 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:31 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:31 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:31 --> Total execution time: 0.0518
INFO - 2023-02-28 04:48:31 --> Config Class Initialized
INFO - 2023-02-28 04:48:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:31 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:31 --> URI Class Initialized
INFO - 2023-02-28 04:48:31 --> Router Class Initialized
INFO - 2023-02-28 04:48:31 --> Output Class Initialized
INFO - 2023-02-28 04:48:31 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:31 --> Input Class Initialized
INFO - 2023-02-28 04:48:31 --> Language Class Initialized
INFO - 2023-02-28 04:48:31 --> Loader Class Initialized
INFO - 2023-02-28 04:48:31 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:31 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:31 --> Model "Login_model" initialized
INFO - 2023-02-28 04:48:31 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:31 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:31 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:31 --> Total execution time: 0.0190
INFO - 2023-02-28 04:48:31 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:31 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:31 --> Total execution time: 0.0436
INFO - 2023-02-28 04:48:32 --> Config Class Initialized
INFO - 2023-02-28 04:48:32 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:32 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:32 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:32 --> URI Class Initialized
INFO - 2023-02-28 04:48:32 --> Router Class Initialized
INFO - 2023-02-28 04:48:32 --> Output Class Initialized
INFO - 2023-02-28 04:48:32 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:32 --> Input Class Initialized
INFO - 2023-02-28 04:48:32 --> Language Class Initialized
INFO - 2023-02-28 04:48:32 --> Loader Class Initialized
INFO - 2023-02-28 04:48:32 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:32 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:32 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:32 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:32 --> Total execution time: 0.0470
INFO - 2023-02-28 04:48:32 --> Config Class Initialized
INFO - 2023-02-28 04:48:32 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:32 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:32 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:32 --> URI Class Initialized
INFO - 2023-02-28 04:48:32 --> Router Class Initialized
INFO - 2023-02-28 04:48:32 --> Output Class Initialized
INFO - 2023-02-28 04:48:32 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:32 --> Input Class Initialized
INFO - 2023-02-28 04:48:32 --> Language Class Initialized
INFO - 2023-02-28 04:48:32 --> Loader Class Initialized
INFO - 2023-02-28 04:48:32 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:32 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:32 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:32 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:32 --> Total execution time: 0.0394
INFO - 2023-02-28 04:48:36 --> Config Class Initialized
INFO - 2023-02-28 04:48:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:36 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:36 --> URI Class Initialized
INFO - 2023-02-28 04:48:36 --> Router Class Initialized
INFO - 2023-02-28 04:48:36 --> Output Class Initialized
INFO - 2023-02-28 04:48:36 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:36 --> Input Class Initialized
INFO - 2023-02-28 04:48:36 --> Language Class Initialized
INFO - 2023-02-28 04:48:36 --> Loader Class Initialized
INFO - 2023-02-28 04:48:36 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:36 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:36 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:36 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:36 --> Total execution time: 0.0250
INFO - 2023-02-28 04:48:36 --> Config Class Initialized
INFO - 2023-02-28 04:48:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:36 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:36 --> URI Class Initialized
INFO - 2023-02-28 04:48:36 --> Router Class Initialized
INFO - 2023-02-28 04:48:36 --> Output Class Initialized
INFO - 2023-02-28 04:48:36 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:36 --> Input Class Initialized
INFO - 2023-02-28 04:48:36 --> Language Class Initialized
INFO - 2023-02-28 04:48:36 --> Loader Class Initialized
INFO - 2023-02-28 04:48:36 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:36 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:36 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:36 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:36 --> Total execution time: 0.0191
INFO - 2023-02-28 04:48:37 --> Config Class Initialized
INFO - 2023-02-28 04:48:37 --> Config Class Initialized
INFO - 2023-02-28 04:48:37 --> Hooks Class Initialized
INFO - 2023-02-28 04:48:37 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:37 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 04:48:37 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:37 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:37 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:37 --> URI Class Initialized
INFO - 2023-02-28 04:48:37 --> URI Class Initialized
INFO - 2023-02-28 04:48:37 --> Router Class Initialized
INFO - 2023-02-28 04:48:37 --> Router Class Initialized
INFO - 2023-02-28 04:48:37 --> Output Class Initialized
INFO - 2023-02-28 04:48:37 --> Output Class Initialized
INFO - 2023-02-28 04:48:37 --> Security Class Initialized
INFO - 2023-02-28 04:48:37 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 04:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:37 --> Input Class Initialized
INFO - 2023-02-28 04:48:37 --> Input Class Initialized
INFO - 2023-02-28 04:48:37 --> Language Class Initialized
INFO - 2023-02-28 04:48:37 --> Language Class Initialized
INFO - 2023-02-28 04:48:37 --> Loader Class Initialized
INFO - 2023-02-28 04:48:37 --> Loader Class Initialized
INFO - 2023-02-28 04:48:37 --> Controller Class Initialized
INFO - 2023-02-28 04:48:37 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 04:48:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:37 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:37 --> Total execution time: 0.0040
INFO - 2023-02-28 04:48:37 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:37 --> Config Class Initialized
INFO - 2023-02-28 04:48:37 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:37 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:37 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:37 --> URI Class Initialized
INFO - 2023-02-28 04:48:37 --> Router Class Initialized
INFO - 2023-02-28 04:48:37 --> Output Class Initialized
INFO - 2023-02-28 04:48:37 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:37 --> Input Class Initialized
INFO - 2023-02-28 04:48:37 --> Language Class Initialized
INFO - 2023-02-28 04:48:37 --> Loader Class Initialized
INFO - 2023-02-28 04:48:37 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:37 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:37 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:37 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:37 --> Total execution time: 0.0128
INFO - 2023-02-28 04:48:37 --> Model "Login_model" initialized
INFO - 2023-02-28 04:48:37 --> Config Class Initialized
INFO - 2023-02-28 04:48:37 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:37 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:37 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:37 --> URI Class Initialized
INFO - 2023-02-28 04:48:37 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:37 --> Router Class Initialized
INFO - 2023-02-28 04:48:37 --> Output Class Initialized
INFO - 2023-02-28 04:48:37 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:37 --> Input Class Initialized
INFO - 2023-02-28 04:48:37 --> Language Class Initialized
INFO - 2023-02-28 04:48:37 --> Loader Class Initialized
INFO - 2023-02-28 04:48:37 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:37 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:37 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:37 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:37 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:37 --> Total execution time: 0.0189
INFO - 2023-02-28 04:48:37 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:37 --> Total execution time: 0.0144
INFO - 2023-02-28 04:48:40 --> Config Class Initialized
INFO - 2023-02-28 04:48:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:40 --> URI Class Initialized
INFO - 2023-02-28 04:48:40 --> Router Class Initialized
INFO - 2023-02-28 04:48:40 --> Output Class Initialized
INFO - 2023-02-28 04:48:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:40 --> Input Class Initialized
INFO - 2023-02-28 04:48:40 --> Language Class Initialized
INFO - 2023-02-28 04:48:40 --> Loader Class Initialized
INFO - 2023-02-28 04:48:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:40 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:40 --> Model "Login_model" initialized
INFO - 2023-02-28 04:48:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:40 --> Total execution time: 0.0517
INFO - 2023-02-28 04:48:40 --> Config Class Initialized
INFO - 2023-02-28 04:48:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:40 --> URI Class Initialized
INFO - 2023-02-28 04:48:40 --> Router Class Initialized
INFO - 2023-02-28 04:48:40 --> Output Class Initialized
INFO - 2023-02-28 04:48:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:40 --> Input Class Initialized
INFO - 2023-02-28 04:48:40 --> Language Class Initialized
INFO - 2023-02-28 04:48:40 --> Loader Class Initialized
INFO - 2023-02-28 04:48:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:40 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:40 --> Model "Login_model" initialized
INFO - 2023-02-28 04:48:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:40 --> Total execution time: 0.0526
INFO - 2023-02-28 04:48:45 --> Config Class Initialized
INFO - 2023-02-28 04:48:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:45 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:45 --> URI Class Initialized
INFO - 2023-02-28 04:48:45 --> Router Class Initialized
INFO - 2023-02-28 04:48:45 --> Output Class Initialized
INFO - 2023-02-28 04:48:45 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:45 --> Input Class Initialized
INFO - 2023-02-28 04:48:45 --> Language Class Initialized
INFO - 2023-02-28 04:48:45 --> Loader Class Initialized
INFO - 2023-02-28 04:48:45 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:45 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:45 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:45 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:45 --> Total execution time: 0.0154
INFO - 2023-02-28 04:48:45 --> Config Class Initialized
INFO - 2023-02-28 04:48:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:45 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:45 --> URI Class Initialized
INFO - 2023-02-28 04:48:45 --> Router Class Initialized
INFO - 2023-02-28 04:48:45 --> Output Class Initialized
INFO - 2023-02-28 04:48:45 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:45 --> Input Class Initialized
INFO - 2023-02-28 04:48:45 --> Language Class Initialized
INFO - 2023-02-28 04:48:45 --> Loader Class Initialized
INFO - 2023-02-28 04:48:45 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:45 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:45 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:45 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:45 --> Total execution time: 0.0152
INFO - 2023-02-28 04:48:48 --> Config Class Initialized
INFO - 2023-02-28 04:48:48 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:48 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:48 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:48 --> URI Class Initialized
INFO - 2023-02-28 04:48:48 --> Router Class Initialized
INFO - 2023-02-28 04:48:48 --> Output Class Initialized
INFO - 2023-02-28 04:48:48 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:48 --> Input Class Initialized
INFO - 2023-02-28 04:48:48 --> Language Class Initialized
INFO - 2023-02-28 04:48:48 --> Loader Class Initialized
INFO - 2023-02-28 04:48:48 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:48 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:48 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:48 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:48 --> Total execution time: 0.0631
INFO - 2023-02-28 04:48:48 --> Config Class Initialized
INFO - 2023-02-28 04:48:48 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:48 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:48 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:48 --> URI Class Initialized
INFO - 2023-02-28 04:48:48 --> Router Class Initialized
INFO - 2023-02-28 04:48:48 --> Output Class Initialized
INFO - 2023-02-28 04:48:48 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:48 --> Input Class Initialized
INFO - 2023-02-28 04:48:48 --> Language Class Initialized
INFO - 2023-02-28 04:48:48 --> Loader Class Initialized
INFO - 2023-02-28 04:48:48 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:48 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:48 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:48 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:48 --> Total execution time: 0.0467
INFO - 2023-02-28 04:48:49 --> Config Class Initialized
INFO - 2023-02-28 04:48:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:49 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:49 --> URI Class Initialized
INFO - 2023-02-28 04:48:49 --> Router Class Initialized
INFO - 2023-02-28 04:48:49 --> Output Class Initialized
INFO - 2023-02-28 04:48:49 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:49 --> Input Class Initialized
INFO - 2023-02-28 04:48:49 --> Language Class Initialized
INFO - 2023-02-28 04:48:49 --> Loader Class Initialized
INFO - 2023-02-28 04:48:49 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:49 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:49 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:49 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:49 --> Model "Login_model" initialized
INFO - 2023-02-28 04:48:49 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:49 --> Total execution time: 0.0407
INFO - 2023-02-28 04:48:49 --> Config Class Initialized
INFO - 2023-02-28 04:48:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:48:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:48:49 --> Utf8 Class Initialized
INFO - 2023-02-28 04:48:49 --> URI Class Initialized
INFO - 2023-02-28 04:48:49 --> Router Class Initialized
INFO - 2023-02-28 04:48:49 --> Output Class Initialized
INFO - 2023-02-28 04:48:49 --> Security Class Initialized
DEBUG - 2023-02-28 04:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:48:49 --> Input Class Initialized
INFO - 2023-02-28 04:48:49 --> Language Class Initialized
INFO - 2023-02-28 04:48:49 --> Loader Class Initialized
INFO - 2023-02-28 04:48:49 --> Controller Class Initialized
DEBUG - 2023-02-28 04:48:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:48:49 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:49 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:48:49 --> Database Driver Class Initialized
INFO - 2023-02-28 04:48:49 --> Model "Login_model" initialized
INFO - 2023-02-28 04:48:49 --> Final output sent to browser
DEBUG - 2023-02-28 04:48:49 --> Total execution time: 0.0370
INFO - 2023-02-28 04:52:33 --> Config Class Initialized
INFO - 2023-02-28 04:52:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:33 --> URI Class Initialized
INFO - 2023-02-28 04:52:33 --> Router Class Initialized
INFO - 2023-02-28 04:52:33 --> Output Class Initialized
INFO - 2023-02-28 04:52:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:33 --> Input Class Initialized
INFO - 2023-02-28 04:52:33 --> Language Class Initialized
INFO - 2023-02-28 04:52:33 --> Loader Class Initialized
INFO - 2023-02-28 04:52:33 --> Controller Class Initialized
INFO - 2023-02-28 04:52:33 --> Helper loaded: form_helper
INFO - 2023-02-28 04:52:33 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:33 --> Model "Change_model" initialized
INFO - 2023-02-28 04:52:33 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:52:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:33 --> Total execution time: 0.0452
INFO - 2023-02-28 04:52:33 --> Config Class Initialized
INFO - 2023-02-28 04:52:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:33 --> URI Class Initialized
INFO - 2023-02-28 04:52:33 --> Router Class Initialized
INFO - 2023-02-28 04:52:33 --> Output Class Initialized
INFO - 2023-02-28 04:52:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:33 --> Input Class Initialized
INFO - 2023-02-28 04:52:33 --> Language Class Initialized
INFO - 2023-02-28 04:52:33 --> Loader Class Initialized
INFO - 2023-02-28 04:52:33 --> Controller Class Initialized
INFO - 2023-02-28 04:52:33 --> Helper loaded: form_helper
INFO - 2023-02-28 04:52:33 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:33 --> Total execution time: 0.0021
INFO - 2023-02-28 04:52:33 --> Config Class Initialized
INFO - 2023-02-28 04:52:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:33 --> URI Class Initialized
INFO - 2023-02-28 04:52:33 --> Router Class Initialized
INFO - 2023-02-28 04:52:33 --> Output Class Initialized
INFO - 2023-02-28 04:52:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:33 --> Input Class Initialized
INFO - 2023-02-28 04:52:33 --> Language Class Initialized
INFO - 2023-02-28 04:52:33 --> Loader Class Initialized
INFO - 2023-02-28 04:52:33 --> Controller Class Initialized
INFO - 2023-02-28 04:52:33 --> Helper loaded: form_helper
INFO - 2023-02-28 04:52:33 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:33 --> Model "Login_model" initialized
INFO - 2023-02-28 04:52:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:33 --> Total execution time: 0.0218
INFO - 2023-02-28 04:52:33 --> Config Class Initialized
INFO - 2023-02-28 04:52:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:33 --> URI Class Initialized
INFO - 2023-02-28 04:52:33 --> Router Class Initialized
INFO - 2023-02-28 04:52:33 --> Output Class Initialized
INFO - 2023-02-28 04:52:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:33 --> Input Class Initialized
INFO - 2023-02-28 04:52:33 --> Language Class Initialized
INFO - 2023-02-28 04:52:33 --> Loader Class Initialized
INFO - 2023-02-28 04:52:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:52:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:33 --> Total execution time: 0.0178
INFO - 2023-02-28 04:52:33 --> Config Class Initialized
INFO - 2023-02-28 04:52:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:33 --> URI Class Initialized
INFO - 2023-02-28 04:52:33 --> Router Class Initialized
INFO - 2023-02-28 04:52:33 --> Output Class Initialized
INFO - 2023-02-28 04:52:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:33 --> Input Class Initialized
INFO - 2023-02-28 04:52:33 --> Language Class Initialized
INFO - 2023-02-28 04:52:33 --> Loader Class Initialized
INFO - 2023-02-28 04:52:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:52:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:33 --> Total execution time: 0.0126
INFO - 2023-02-28 04:52:33 --> Config Class Initialized
INFO - 2023-02-28 04:52:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:33 --> URI Class Initialized
INFO - 2023-02-28 04:52:33 --> Router Class Initialized
INFO - 2023-02-28 04:52:33 --> Output Class Initialized
INFO - 2023-02-28 04:52:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:33 --> Input Class Initialized
INFO - 2023-02-28 04:52:33 --> Language Class Initialized
INFO - 2023-02-28 04:52:33 --> Loader Class Initialized
INFO - 2023-02-28 04:52:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:52:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:34 --> Model "Login_model" initialized
INFO - 2023-02-28 04:52:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:34 --> Total execution time: 0.1104
INFO - 2023-02-28 04:52:34 --> Config Class Initialized
INFO - 2023-02-28 04:52:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:34 --> URI Class Initialized
INFO - 2023-02-28 04:52:34 --> Router Class Initialized
INFO - 2023-02-28 04:52:34 --> Output Class Initialized
INFO - 2023-02-28 04:52:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:34 --> Input Class Initialized
INFO - 2023-02-28 04:52:34 --> Language Class Initialized
INFO - 2023-02-28 04:52:34 --> Loader Class Initialized
INFO - 2023-02-28 04:52:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:52:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:34 --> Model "Login_model" initialized
INFO - 2023-02-28 04:52:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:34 --> Total execution time: 0.0469
INFO - 2023-02-28 04:52:39 --> Config Class Initialized
INFO - 2023-02-28 04:52:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:39 --> URI Class Initialized
INFO - 2023-02-28 04:52:39 --> Router Class Initialized
INFO - 2023-02-28 04:52:39 --> Output Class Initialized
INFO - 2023-02-28 04:52:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:39 --> Input Class Initialized
INFO - 2023-02-28 04:52:39 --> Language Class Initialized
INFO - 2023-02-28 04:52:39 --> Loader Class Initialized
INFO - 2023-02-28 04:52:39 --> Controller Class Initialized
INFO - 2023-02-28 04:52:39 --> Helper loaded: form_helper
INFO - 2023-02-28 04:52:39 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:52:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:39 --> Model "Change_model" initialized
INFO - 2023-02-28 04:52:39 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:52:39 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:39 --> Total execution time: 0.0257
INFO - 2023-02-28 04:52:39 --> Config Class Initialized
INFO - 2023-02-28 04:52:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:39 --> URI Class Initialized
INFO - 2023-02-28 04:52:39 --> Router Class Initialized
INFO - 2023-02-28 04:52:39 --> Output Class Initialized
INFO - 2023-02-28 04:52:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:39 --> Input Class Initialized
INFO - 2023-02-28 04:52:39 --> Language Class Initialized
INFO - 2023-02-28 04:52:39 --> Loader Class Initialized
INFO - 2023-02-28 04:52:39 --> Controller Class Initialized
INFO - 2023-02-28 04:52:39 --> Helper loaded: form_helper
INFO - 2023-02-28 04:52:39 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:52:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:39 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:39 --> Total execution time: 0.0032
INFO - 2023-02-28 04:52:39 --> Config Class Initialized
INFO - 2023-02-28 04:52:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:39 --> URI Class Initialized
INFO - 2023-02-28 04:52:39 --> Router Class Initialized
INFO - 2023-02-28 04:52:39 --> Output Class Initialized
INFO - 2023-02-28 04:52:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:39 --> Input Class Initialized
INFO - 2023-02-28 04:52:39 --> Language Class Initialized
INFO - 2023-02-28 04:52:39 --> Loader Class Initialized
INFO - 2023-02-28 04:52:39 --> Controller Class Initialized
INFO - 2023-02-28 04:52:39 --> Helper loaded: form_helper
INFO - 2023-02-28 04:52:39 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:52:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:39 --> Model "Login_model" initialized
INFO - 2023-02-28 04:52:39 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:39 --> Total execution time: 0.0184
INFO - 2023-02-28 04:52:39 --> Config Class Initialized
INFO - 2023-02-28 04:52:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:39 --> URI Class Initialized
INFO - 2023-02-28 04:52:39 --> Router Class Initialized
INFO - 2023-02-28 04:52:39 --> Output Class Initialized
INFO - 2023-02-28 04:52:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:39 --> Input Class Initialized
INFO - 2023-02-28 04:52:39 --> Language Class Initialized
INFO - 2023-02-28 04:52:39 --> Loader Class Initialized
INFO - 2023-02-28 04:52:39 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:39 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:52:39 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:39 --> Total execution time: 0.0134
INFO - 2023-02-28 04:52:39 --> Config Class Initialized
INFO - 2023-02-28 04:52:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:39 --> URI Class Initialized
INFO - 2023-02-28 04:52:39 --> Router Class Initialized
INFO - 2023-02-28 04:52:39 --> Output Class Initialized
INFO - 2023-02-28 04:52:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:39 --> Input Class Initialized
INFO - 2023-02-28 04:52:39 --> Language Class Initialized
INFO - 2023-02-28 04:52:39 --> Loader Class Initialized
INFO - 2023-02-28 04:52:39 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:39 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:52:39 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:39 --> Total execution time: 0.0126
INFO - 2023-02-28 04:52:39 --> Config Class Initialized
INFO - 2023-02-28 04:52:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:39 --> URI Class Initialized
INFO - 2023-02-28 04:52:39 --> Router Class Initialized
INFO - 2023-02-28 04:52:39 --> Output Class Initialized
INFO - 2023-02-28 04:52:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:39 --> Input Class Initialized
INFO - 2023-02-28 04:52:39 --> Language Class Initialized
INFO - 2023-02-28 04:52:39 --> Loader Class Initialized
INFO - 2023-02-28 04:52:39 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:39 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:52:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:39 --> Model "Login_model" initialized
INFO - 2023-02-28 04:52:39 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:39 --> Total execution time: 0.0866
INFO - 2023-02-28 04:52:39 --> Config Class Initialized
INFO - 2023-02-28 04:52:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:39 --> URI Class Initialized
INFO - 2023-02-28 04:52:39 --> Router Class Initialized
INFO - 2023-02-28 04:52:39 --> Output Class Initialized
INFO - 2023-02-28 04:52:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:39 --> Input Class Initialized
INFO - 2023-02-28 04:52:39 --> Language Class Initialized
INFO - 2023-02-28 04:52:39 --> Loader Class Initialized
INFO - 2023-02-28 04:52:39 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:39 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:52:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:39 --> Model "Login_model" initialized
INFO - 2023-02-28 04:52:39 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:39 --> Total execution time: 0.0782
INFO - 2023-02-28 04:52:47 --> Config Class Initialized
INFO - 2023-02-28 04:52:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:47 --> URI Class Initialized
INFO - 2023-02-28 04:52:47 --> Router Class Initialized
INFO - 2023-02-28 04:52:47 --> Output Class Initialized
INFO - 2023-02-28 04:52:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:47 --> Input Class Initialized
INFO - 2023-02-28 04:52:47 --> Language Class Initialized
INFO - 2023-02-28 04:52:47 --> Loader Class Initialized
INFO - 2023-02-28 04:52:47 --> Controller Class Initialized
INFO - 2023-02-28 04:52:47 --> Helper loaded: form_helper
INFO - 2023-02-28 04:52:47 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:52:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:47 --> Model "Change_model" initialized
INFO - 2023-02-28 04:52:47 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:52:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:47 --> Total execution time: 0.0296
INFO - 2023-02-28 04:52:47 --> Config Class Initialized
INFO - 2023-02-28 04:52:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:47 --> URI Class Initialized
INFO - 2023-02-28 04:52:47 --> Router Class Initialized
INFO - 2023-02-28 04:52:47 --> Output Class Initialized
INFO - 2023-02-28 04:52:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:47 --> Input Class Initialized
INFO - 2023-02-28 04:52:47 --> Language Class Initialized
INFO - 2023-02-28 04:52:47 --> Loader Class Initialized
INFO - 2023-02-28 04:52:47 --> Controller Class Initialized
INFO - 2023-02-28 04:52:47 --> Helper loaded: form_helper
INFO - 2023-02-28 04:52:47 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:52:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:47 --> Total execution time: 0.0026
INFO - 2023-02-28 04:52:47 --> Config Class Initialized
INFO - 2023-02-28 04:52:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:47 --> URI Class Initialized
INFO - 2023-02-28 04:52:47 --> Router Class Initialized
INFO - 2023-02-28 04:52:47 --> Output Class Initialized
INFO - 2023-02-28 04:52:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:47 --> Input Class Initialized
INFO - 2023-02-28 04:52:47 --> Language Class Initialized
INFO - 2023-02-28 04:52:47 --> Loader Class Initialized
INFO - 2023-02-28 04:52:47 --> Controller Class Initialized
INFO - 2023-02-28 04:52:47 --> Helper loaded: form_helper
INFO - 2023-02-28 04:52:47 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:52:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:47 --> Model "Login_model" initialized
INFO - 2023-02-28 04:52:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:47 --> Total execution time: 0.0133
INFO - 2023-02-28 04:52:47 --> Config Class Initialized
INFO - 2023-02-28 04:52:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:47 --> URI Class Initialized
INFO - 2023-02-28 04:52:47 --> Router Class Initialized
INFO - 2023-02-28 04:52:47 --> Output Class Initialized
INFO - 2023-02-28 04:52:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:47 --> Input Class Initialized
INFO - 2023-02-28 04:52:47 --> Language Class Initialized
INFO - 2023-02-28 04:52:47 --> Loader Class Initialized
INFO - 2023-02-28 04:52:47 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:52:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:47 --> Total execution time: 0.0147
INFO - 2023-02-28 04:52:47 --> Config Class Initialized
INFO - 2023-02-28 04:52:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:47 --> URI Class Initialized
INFO - 2023-02-28 04:52:47 --> Router Class Initialized
INFO - 2023-02-28 04:52:47 --> Output Class Initialized
INFO - 2023-02-28 04:52:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:47 --> Input Class Initialized
INFO - 2023-02-28 04:52:47 --> Language Class Initialized
INFO - 2023-02-28 04:52:47 --> Loader Class Initialized
INFO - 2023-02-28 04:52:47 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:52:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:47 --> Total execution time: 0.0190
INFO - 2023-02-28 04:52:47 --> Config Class Initialized
INFO - 2023-02-28 04:52:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:47 --> URI Class Initialized
INFO - 2023-02-28 04:52:47 --> Router Class Initialized
INFO - 2023-02-28 04:52:47 --> Output Class Initialized
INFO - 2023-02-28 04:52:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:47 --> Input Class Initialized
INFO - 2023-02-28 04:52:47 --> Language Class Initialized
INFO - 2023-02-28 04:52:47 --> Loader Class Initialized
INFO - 2023-02-28 04:52:47 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:52:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:47 --> Model "Login_model" initialized
INFO - 2023-02-28 04:52:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:47 --> Total execution time: 0.1326
INFO - 2023-02-28 04:52:47 --> Config Class Initialized
INFO - 2023-02-28 04:52:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:47 --> URI Class Initialized
INFO - 2023-02-28 04:52:47 --> Router Class Initialized
INFO - 2023-02-28 04:52:47 --> Output Class Initialized
INFO - 2023-02-28 04:52:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:47 --> Input Class Initialized
INFO - 2023-02-28 04:52:47 --> Language Class Initialized
INFO - 2023-02-28 04:52:47 --> Loader Class Initialized
INFO - 2023-02-28 04:52:47 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:52:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:47 --> Model "Login_model" initialized
INFO - 2023-02-28 04:52:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:47 --> Total execution time: 0.0581
INFO - 2023-02-28 04:52:50 --> Config Class Initialized
INFO - 2023-02-28 04:52:50 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:50 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:50 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:50 --> URI Class Initialized
INFO - 2023-02-28 04:52:50 --> Router Class Initialized
INFO - 2023-02-28 04:52:50 --> Output Class Initialized
INFO - 2023-02-28 04:52:50 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:50 --> Input Class Initialized
INFO - 2023-02-28 04:52:50 --> Language Class Initialized
INFO - 2023-02-28 04:52:50 --> Loader Class Initialized
INFO - 2023-02-28 04:52:50 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:50 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:50 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:50 --> Model "Login_model" initialized
INFO - 2023-02-28 04:52:50 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:50 --> Total execution time: 0.0296
INFO - 2023-02-28 04:52:50 --> Config Class Initialized
INFO - 2023-02-28 04:52:50 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:52:50 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:52:50 --> Utf8 Class Initialized
INFO - 2023-02-28 04:52:50 --> URI Class Initialized
INFO - 2023-02-28 04:52:50 --> Router Class Initialized
INFO - 2023-02-28 04:52:50 --> Output Class Initialized
INFO - 2023-02-28 04:52:50 --> Security Class Initialized
DEBUG - 2023-02-28 04:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:52:50 --> Input Class Initialized
INFO - 2023-02-28 04:52:50 --> Language Class Initialized
INFO - 2023-02-28 04:52:50 --> Loader Class Initialized
INFO - 2023-02-28 04:52:50 --> Controller Class Initialized
DEBUG - 2023-02-28 04:52:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:52:50 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:50 --> Database Driver Class Initialized
INFO - 2023-02-28 04:52:50 --> Model "Login_model" initialized
INFO - 2023-02-28 04:52:50 --> Final output sent to browser
DEBUG - 2023-02-28 04:52:50 --> Total execution time: 0.0228
INFO - 2023-02-28 04:53:16 --> Config Class Initialized
INFO - 2023-02-28 04:53:16 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:16 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:16 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:16 --> URI Class Initialized
INFO - 2023-02-28 04:53:16 --> Router Class Initialized
INFO - 2023-02-28 04:53:16 --> Output Class Initialized
INFO - 2023-02-28 04:53:16 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:16 --> Input Class Initialized
INFO - 2023-02-28 04:53:16 --> Language Class Initialized
INFO - 2023-02-28 04:53:16 --> Loader Class Initialized
INFO - 2023-02-28 04:53:16 --> Controller Class Initialized
INFO - 2023-02-28 04:53:16 --> Helper loaded: form_helper
INFO - 2023-02-28 04:53:16 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:53:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:16 --> Model "Change_model" initialized
INFO - 2023-02-28 04:53:16 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:53:16 --> Final output sent to browser
DEBUG - 2023-02-28 04:53:16 --> Total execution time: 0.0458
INFO - 2023-02-28 04:53:16 --> Config Class Initialized
INFO - 2023-02-28 04:53:16 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:16 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:16 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:16 --> URI Class Initialized
INFO - 2023-02-28 04:53:16 --> Router Class Initialized
INFO - 2023-02-28 04:53:16 --> Output Class Initialized
INFO - 2023-02-28 04:53:16 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:16 --> Input Class Initialized
INFO - 2023-02-28 04:53:16 --> Language Class Initialized
INFO - 2023-02-28 04:53:16 --> Loader Class Initialized
INFO - 2023-02-28 04:53:16 --> Controller Class Initialized
INFO - 2023-02-28 04:53:16 --> Helper loaded: form_helper
INFO - 2023-02-28 04:53:16 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:53:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:16 --> Final output sent to browser
DEBUG - 2023-02-28 04:53:16 --> Total execution time: 0.0021
INFO - 2023-02-28 04:53:16 --> Config Class Initialized
INFO - 2023-02-28 04:53:16 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:16 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:16 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:16 --> URI Class Initialized
INFO - 2023-02-28 04:53:16 --> Router Class Initialized
INFO - 2023-02-28 04:53:16 --> Output Class Initialized
INFO - 2023-02-28 04:53:16 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:16 --> Input Class Initialized
INFO - 2023-02-28 04:53:16 --> Language Class Initialized
INFO - 2023-02-28 04:53:16 --> Loader Class Initialized
INFO - 2023-02-28 04:53:16 --> Controller Class Initialized
INFO - 2023-02-28 04:53:16 --> Helper loaded: form_helper
INFO - 2023-02-28 04:53:16 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:53:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:16 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:16 --> Model "Login_model" initialized
INFO - 2023-02-28 04:53:16 --> Final output sent to browser
DEBUG - 2023-02-28 04:53:16 --> Total execution time: 0.0243
INFO - 2023-02-28 04:53:16 --> Config Class Initialized
INFO - 2023-02-28 04:53:16 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:16 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:16 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:16 --> URI Class Initialized
INFO - 2023-02-28 04:53:16 --> Router Class Initialized
INFO - 2023-02-28 04:53:16 --> Output Class Initialized
INFO - 2023-02-28 04:53:16 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:16 --> Input Class Initialized
INFO - 2023-02-28 04:53:16 --> Language Class Initialized
INFO - 2023-02-28 04:53:16 --> Loader Class Initialized
INFO - 2023-02-28 04:53:16 --> Controller Class Initialized
INFO - 2023-02-28 04:53:16 --> Helper loaded: form_helper
INFO - 2023-02-28 04:53:16 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:53:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:16 --> Model "Change_model" initialized
INFO - 2023-02-28 04:53:16 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:53:16 --> Final output sent to browser
DEBUG - 2023-02-28 04:53:16 --> Total execution time: 0.0398
INFO - 2023-02-28 04:53:16 --> Config Class Initialized
INFO - 2023-02-28 04:53:16 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:16 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:16 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:16 --> URI Class Initialized
INFO - 2023-02-28 04:53:16 --> Router Class Initialized
INFO - 2023-02-28 04:53:16 --> Output Class Initialized
INFO - 2023-02-28 04:53:16 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:16 --> Input Class Initialized
INFO - 2023-02-28 04:53:16 --> Language Class Initialized
INFO - 2023-02-28 04:53:16 --> Loader Class Initialized
INFO - 2023-02-28 04:53:16 --> Controller Class Initialized
INFO - 2023-02-28 04:53:16 --> Helper loaded: form_helper
INFO - 2023-02-28 04:53:16 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:53:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:16 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:16 --> Model "Login_model" initialized
INFO - 2023-02-28 04:53:16 --> Final output sent to browser
DEBUG - 2023-02-28 04:53:16 --> Total execution time: 0.0122
INFO - 2023-02-28 04:53:25 --> Config Class Initialized
INFO - 2023-02-28 04:53:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:25 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:25 --> URI Class Initialized
INFO - 2023-02-28 04:53:25 --> Router Class Initialized
INFO - 2023-02-28 04:53:25 --> Output Class Initialized
INFO - 2023-02-28 04:53:25 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:25 --> Input Class Initialized
INFO - 2023-02-28 04:53:25 --> Language Class Initialized
INFO - 2023-02-28 04:53:25 --> Loader Class Initialized
INFO - 2023-02-28 04:53:25 --> Controller Class Initialized
INFO - 2023-02-28 04:53:25 --> Helper loaded: form_helper
INFO - 2023-02-28 04:53:25 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:53:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:25 --> Model "Change_model" initialized
INFO - 2023-02-28 04:53:25 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:53:25 --> Final output sent to browser
DEBUG - 2023-02-28 04:53:25 --> Total execution time: 0.0245
INFO - 2023-02-28 04:53:25 --> Config Class Initialized
INFO - 2023-02-28 04:53:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:25 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:25 --> URI Class Initialized
INFO - 2023-02-28 04:53:25 --> Router Class Initialized
INFO - 2023-02-28 04:53:25 --> Output Class Initialized
INFO - 2023-02-28 04:53:25 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:25 --> Input Class Initialized
INFO - 2023-02-28 04:53:25 --> Language Class Initialized
INFO - 2023-02-28 04:53:25 --> Loader Class Initialized
INFO - 2023-02-28 04:53:25 --> Controller Class Initialized
INFO - 2023-02-28 04:53:25 --> Helper loaded: form_helper
INFO - 2023-02-28 04:53:25 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:53:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:25 --> Final output sent to browser
DEBUG - 2023-02-28 04:53:25 --> Total execution time: 0.0029
INFO - 2023-02-28 04:53:25 --> Config Class Initialized
INFO - 2023-02-28 04:53:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:25 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:25 --> URI Class Initialized
INFO - 2023-02-28 04:53:25 --> Router Class Initialized
INFO - 2023-02-28 04:53:25 --> Output Class Initialized
INFO - 2023-02-28 04:53:25 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:25 --> Input Class Initialized
INFO - 2023-02-28 04:53:25 --> Language Class Initialized
INFO - 2023-02-28 04:53:25 --> Loader Class Initialized
INFO - 2023-02-28 04:53:25 --> Controller Class Initialized
INFO - 2023-02-28 04:53:25 --> Helper loaded: form_helper
INFO - 2023-02-28 04:53:25 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:53:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:25 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:25 --> Model "Login_model" initialized
INFO - 2023-02-28 04:53:25 --> Final output sent to browser
DEBUG - 2023-02-28 04:53:25 --> Total execution time: 0.0116
INFO - 2023-02-28 04:53:25 --> Config Class Initialized
INFO - 2023-02-28 04:53:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:25 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:25 --> URI Class Initialized
INFO - 2023-02-28 04:53:25 --> Router Class Initialized
INFO - 2023-02-28 04:53:25 --> Output Class Initialized
INFO - 2023-02-28 04:53:25 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:25 --> Input Class Initialized
INFO - 2023-02-28 04:53:25 --> Language Class Initialized
INFO - 2023-02-28 04:53:25 --> Loader Class Initialized
INFO - 2023-02-28 04:53:25 --> Controller Class Initialized
DEBUG - 2023-02-28 04:53:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:25 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:26 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:53:26 --> Final output sent to browser
DEBUG - 2023-02-28 04:53:26 --> Total execution time: 0.0128
INFO - 2023-02-28 04:53:26 --> Config Class Initialized
INFO - 2023-02-28 04:53:26 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:26 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:26 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:26 --> URI Class Initialized
INFO - 2023-02-28 04:53:26 --> Router Class Initialized
INFO - 2023-02-28 04:53:26 --> Output Class Initialized
INFO - 2023-02-28 04:53:26 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:26 --> Input Class Initialized
INFO - 2023-02-28 04:53:26 --> Language Class Initialized
INFO - 2023-02-28 04:53:26 --> Loader Class Initialized
INFO - 2023-02-28 04:53:26 --> Controller Class Initialized
DEBUG - 2023-02-28 04:53:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:26 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:26 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:53:26 --> Final output sent to browser
DEBUG - 2023-02-28 04:53:26 --> Total execution time: 0.0102
INFO - 2023-02-28 04:53:26 --> Config Class Initialized
INFO - 2023-02-28 04:53:26 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:26 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:26 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:26 --> URI Class Initialized
INFO - 2023-02-28 04:53:26 --> Router Class Initialized
INFO - 2023-02-28 04:53:26 --> Output Class Initialized
INFO - 2023-02-28 04:53:26 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:26 --> Input Class Initialized
INFO - 2023-02-28 04:53:26 --> Language Class Initialized
INFO - 2023-02-28 04:53:26 --> Loader Class Initialized
INFO - 2023-02-28 04:53:26 --> Controller Class Initialized
DEBUG - 2023-02-28 04:53:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:26 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:26 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:53:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by id desc limit 10 offset 0' at line 1 - Invalid query:  order by id desc limit 10 offset 0
INFO - 2023-02-28 04:53:26 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:53:29 --> Config Class Initialized
INFO - 2023-02-28 04:53:29 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:29 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:29 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:29 --> URI Class Initialized
INFO - 2023-02-28 04:53:29 --> Router Class Initialized
INFO - 2023-02-28 04:53:29 --> Output Class Initialized
INFO - 2023-02-28 04:53:29 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:29 --> Input Class Initialized
INFO - 2023-02-28 04:53:29 --> Language Class Initialized
INFO - 2023-02-28 04:53:29 --> Loader Class Initialized
INFO - 2023-02-28 04:53:29 --> Controller Class Initialized
DEBUG - 2023-02-28 04:53:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:29 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:29 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:53:29 --> Final output sent to browser
DEBUG - 2023-02-28 04:53:29 --> Total execution time: 0.0488
INFO - 2023-02-28 04:53:29 --> Config Class Initialized
INFO - 2023-02-28 04:53:29 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:29 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:29 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:29 --> URI Class Initialized
INFO - 2023-02-28 04:53:29 --> Router Class Initialized
INFO - 2023-02-28 04:53:29 --> Output Class Initialized
INFO - 2023-02-28 04:53:29 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:29 --> Input Class Initialized
INFO - 2023-02-28 04:53:29 --> Language Class Initialized
INFO - 2023-02-28 04:53:29 --> Loader Class Initialized
INFO - 2023-02-28 04:53:29 --> Controller Class Initialized
DEBUG - 2023-02-28 04:53:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:29 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:29 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:53:29 --> Final output sent to browser
DEBUG - 2023-02-28 04:53:29 --> Total execution time: 0.0435
INFO - 2023-02-28 04:53:33 --> Config Class Initialized
INFO - 2023-02-28 04:53:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:33 --> URI Class Initialized
INFO - 2023-02-28 04:53:33 --> Router Class Initialized
INFO - 2023-02-28 04:53:33 --> Output Class Initialized
INFO - 2023-02-28 04:53:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:33 --> Input Class Initialized
INFO - 2023-02-28 04:53:33 --> Language Class Initialized
INFO - 2023-02-28 04:53:33 --> Loader Class Initialized
INFO - 2023-02-28 04:53:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:53:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:33 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:53:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by id desc limit 10 offset 0' at line 1 - Invalid query:  order by id desc limit 10 offset 0
INFO - 2023-02-28 04:53:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:53:34 --> Config Class Initialized
INFO - 2023-02-28 04:53:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:34 --> URI Class Initialized
INFO - 2023-02-28 04:53:34 --> Router Class Initialized
INFO - 2023-02-28 04:53:34 --> Output Class Initialized
INFO - 2023-02-28 04:53:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:34 --> Input Class Initialized
INFO - 2023-02-28 04:53:34 --> Language Class Initialized
INFO - 2023-02-28 04:53:34 --> Loader Class Initialized
INFO - 2023-02-28 04:53:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:53:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:53:34 --> Total execution time: 0.0034
INFO - 2023-02-28 04:53:34 --> Config Class Initialized
INFO - 2023-02-28 04:53:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:34 --> URI Class Initialized
INFO - 2023-02-28 04:53:34 --> Router Class Initialized
INFO - 2023-02-28 04:53:34 --> Output Class Initialized
INFO - 2023-02-28 04:53:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:34 --> Input Class Initialized
INFO - 2023-02-28 04:53:34 --> Language Class Initialized
INFO - 2023-02-28 04:53:34 --> Loader Class Initialized
INFO - 2023-02-28 04:53:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:53:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:34 --> Model "Login_model" initialized
INFO - 2023-02-28 04:53:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:34 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:53:34 --> Query error:  - Invalid query: 
INFO - 2023-02-28 04:53:34 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:53:35 --> Config Class Initialized
INFO - 2023-02-28 04:53:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:35 --> URI Class Initialized
INFO - 2023-02-28 04:53:35 --> Router Class Initialized
INFO - 2023-02-28 04:53:35 --> Output Class Initialized
INFO - 2023-02-28 04:53:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:35 --> Input Class Initialized
INFO - 2023-02-28 04:53:35 --> Language Class Initialized
INFO - 2023-02-28 04:53:35 --> Loader Class Initialized
INFO - 2023-02-28 04:53:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:53:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:35 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:53:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by id desc limit  offset 0' at line 1 - Invalid query:  order by id desc limit  offset 0
INFO - 2023-02-28 04:53:35 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:53:36 --> Config Class Initialized
INFO - 2023-02-28 04:53:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:36 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:36 --> URI Class Initialized
INFO - 2023-02-28 04:53:36 --> Router Class Initialized
INFO - 2023-02-28 04:53:36 --> Output Class Initialized
INFO - 2023-02-28 04:53:36 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:36 --> Input Class Initialized
INFO - 2023-02-28 04:53:36 --> Language Class Initialized
INFO - 2023-02-28 04:53:36 --> Loader Class Initialized
INFO - 2023-02-28 04:53:36 --> Controller Class Initialized
DEBUG - 2023-02-28 04:53:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:36 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:36 --> Model "Login_model" initialized
INFO - 2023-02-28 04:53:36 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:36 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:53:36 --> Query error:  - Invalid query: 
INFO - 2023-02-28 04:53:36 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:53:37 --> Config Class Initialized
INFO - 2023-02-28 04:53:37 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:37 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:37 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:37 --> URI Class Initialized
INFO - 2023-02-28 04:53:37 --> Router Class Initialized
INFO - 2023-02-28 04:53:37 --> Output Class Initialized
INFO - 2023-02-28 04:53:37 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:37 --> Input Class Initialized
INFO - 2023-02-28 04:53:37 --> Language Class Initialized
INFO - 2023-02-28 04:53:37 --> Loader Class Initialized
INFO - 2023-02-28 04:53:37 --> Controller Class Initialized
DEBUG - 2023-02-28 04:53:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:37 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:37 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:53:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by id desc limit 10 offset 0' at line 1 - Invalid query:  order by id desc limit 10 offset 0
INFO - 2023-02-28 04:53:37 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:53:46 --> Config Class Initialized
INFO - 2023-02-28 04:53:46 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:46 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:46 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:46 --> URI Class Initialized
INFO - 2023-02-28 04:53:46 --> Router Class Initialized
INFO - 2023-02-28 04:53:46 --> Output Class Initialized
INFO - 2023-02-28 04:53:46 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:46 --> Input Class Initialized
INFO - 2023-02-28 04:53:46 --> Language Class Initialized
INFO - 2023-02-28 04:53:46 --> Loader Class Initialized
INFO - 2023-02-28 04:53:46 --> Controller Class Initialized
DEBUG - 2023-02-28 04:53:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:46 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:53:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by id desc limit 10 offset 0' at line 1 - Invalid query:  order by id desc limit 10 offset 0
INFO - 2023-02-28 04:53:46 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:53:53 --> Config Class Initialized
INFO - 2023-02-28 04:53:53 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:53:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:53:53 --> Utf8 Class Initialized
INFO - 2023-02-28 04:53:53 --> URI Class Initialized
INFO - 2023-02-28 04:53:53 --> Router Class Initialized
INFO - 2023-02-28 04:53:53 --> Output Class Initialized
INFO - 2023-02-28 04:53:53 --> Security Class Initialized
DEBUG - 2023-02-28 04:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:53:53 --> Input Class Initialized
INFO - 2023-02-28 04:53:53 --> Language Class Initialized
INFO - 2023-02-28 04:53:53 --> Loader Class Initialized
INFO - 2023-02-28 04:53:53 --> Controller Class Initialized
DEBUG - 2023-02-28 04:53:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:53:53 --> Database Driver Class Initialized
INFO - 2023-02-28 04:53:53 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:53:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by id desc limit 10 offset 0' at line 1 - Invalid query:  order by id desc limit 10 offset 0
INFO - 2023-02-28 04:53:53 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:54:08 --> Config Class Initialized
INFO - 2023-02-28 04:54:08 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:54:08 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:54:08 --> Utf8 Class Initialized
INFO - 2023-02-28 04:54:08 --> URI Class Initialized
INFO - 2023-02-28 04:54:08 --> Router Class Initialized
INFO - 2023-02-28 04:54:08 --> Output Class Initialized
INFO - 2023-02-28 04:54:08 --> Security Class Initialized
DEBUG - 2023-02-28 04:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:54:08 --> Input Class Initialized
INFO - 2023-02-28 04:54:08 --> Language Class Initialized
INFO - 2023-02-28 04:54:08 --> Loader Class Initialized
INFO - 2023-02-28 04:54:08 --> Controller Class Initialized
DEBUG - 2023-02-28 04:54:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:54:08 --> Database Driver Class Initialized
INFO - 2023-02-28 04:54:08 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:54:08 --> Database Driver Class Initialized
INFO - 2023-02-28 04:54:08 --> Model "Login_model" initialized
INFO - 2023-02-28 04:54:08 --> Final output sent to browser
DEBUG - 2023-02-28 04:54:08 --> Total execution time: 0.0852
INFO - 2023-02-28 04:55:13 --> Config Class Initialized
INFO - 2023-02-28 04:55:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:13 --> URI Class Initialized
INFO - 2023-02-28 04:55:13 --> Router Class Initialized
INFO - 2023-02-28 04:55:13 --> Output Class Initialized
INFO - 2023-02-28 04:55:13 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:13 --> Input Class Initialized
INFO - 2023-02-28 04:55:13 --> Language Class Initialized
INFO - 2023-02-28 04:55:13 --> Loader Class Initialized
INFO - 2023-02-28 04:55:13 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:13 --> Model "Login_model" initialized
INFO - 2023-02-28 04:55:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:13 --> Total execution time: 0.0821
INFO - 2023-02-28 04:55:13 --> Config Class Initialized
INFO - 2023-02-28 04:55:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:13 --> URI Class Initialized
INFO - 2023-02-28 04:55:13 --> Router Class Initialized
INFO - 2023-02-28 04:55:13 --> Output Class Initialized
INFO - 2023-02-28 04:55:13 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:13 --> Input Class Initialized
INFO - 2023-02-28 04:55:13 --> Language Class Initialized
INFO - 2023-02-28 04:55:13 --> Loader Class Initialized
INFO - 2023-02-28 04:55:13 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:13 --> Model "Login_model" initialized
INFO - 2023-02-28 04:55:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:13 --> Total execution time: 0.0761
INFO - 2023-02-28 04:55:19 --> Config Class Initialized
INFO - 2023-02-28 04:55:19 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:19 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:19 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:19 --> URI Class Initialized
INFO - 2023-02-28 04:55:19 --> Router Class Initialized
INFO - 2023-02-28 04:55:19 --> Output Class Initialized
INFO - 2023-02-28 04:55:19 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:19 --> Input Class Initialized
INFO - 2023-02-28 04:55:19 --> Language Class Initialized
INFO - 2023-02-28 04:55:19 --> Loader Class Initialized
INFO - 2023-02-28 04:55:19 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:19 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:19 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:19 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:19 --> Model "Login_model" initialized
INFO - 2023-02-28 04:55:19 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:19 --> Total execution time: 0.1201
INFO - 2023-02-28 04:55:19 --> Config Class Initialized
INFO - 2023-02-28 04:55:19 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:19 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:19 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:19 --> URI Class Initialized
INFO - 2023-02-28 04:55:19 --> Router Class Initialized
INFO - 2023-02-28 04:55:19 --> Output Class Initialized
INFO - 2023-02-28 04:55:19 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:19 --> Input Class Initialized
INFO - 2023-02-28 04:55:19 --> Language Class Initialized
INFO - 2023-02-28 04:55:19 --> Loader Class Initialized
INFO - 2023-02-28 04:55:19 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:19 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:19 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:19 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:19 --> Model "Login_model" initialized
INFO - 2023-02-28 04:55:19 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:19 --> Total execution time: 0.0461
INFO - 2023-02-28 04:55:34 --> Config Class Initialized
INFO - 2023-02-28 04:55:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:34 --> URI Class Initialized
INFO - 2023-02-28 04:55:34 --> Router Class Initialized
INFO - 2023-02-28 04:55:34 --> Output Class Initialized
INFO - 2023-02-28 04:55:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:34 --> Input Class Initialized
INFO - 2023-02-28 04:55:34 --> Language Class Initialized
INFO - 2023-02-28 04:55:34 --> Loader Class Initialized
INFO - 2023-02-28 04:55:34 --> Controller Class Initialized
INFO - 2023-02-28 04:55:34 --> Helper loaded: form_helper
INFO - 2023-02-28 04:55:34 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:55:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:34 --> Model "Change_model" initialized
INFO - 2023-02-28 04:55:34 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:55:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:34 --> Total execution time: 0.0255
INFO - 2023-02-28 04:55:34 --> Config Class Initialized
INFO - 2023-02-28 04:55:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:34 --> URI Class Initialized
INFO - 2023-02-28 04:55:34 --> Router Class Initialized
INFO - 2023-02-28 04:55:34 --> Output Class Initialized
INFO - 2023-02-28 04:55:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:34 --> Input Class Initialized
INFO - 2023-02-28 04:55:34 --> Language Class Initialized
INFO - 2023-02-28 04:55:34 --> Loader Class Initialized
INFO - 2023-02-28 04:55:34 --> Controller Class Initialized
INFO - 2023-02-28 04:55:34 --> Helper loaded: form_helper
INFO - 2023-02-28 04:55:34 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:55:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:34 --> Total execution time: 0.0018
INFO - 2023-02-28 04:55:34 --> Config Class Initialized
INFO - 2023-02-28 04:55:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:34 --> URI Class Initialized
INFO - 2023-02-28 04:55:34 --> Router Class Initialized
INFO - 2023-02-28 04:55:34 --> Output Class Initialized
INFO - 2023-02-28 04:55:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:34 --> Input Class Initialized
INFO - 2023-02-28 04:55:34 --> Language Class Initialized
INFO - 2023-02-28 04:55:34 --> Loader Class Initialized
INFO - 2023-02-28 04:55:34 --> Controller Class Initialized
INFO - 2023-02-28 04:55:34 --> Helper loaded: form_helper
INFO - 2023-02-28 04:55:34 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:55:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:34 --> Model "Login_model" initialized
INFO - 2023-02-28 04:55:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:34 --> Total execution time: 0.0214
INFO - 2023-02-28 04:55:34 --> Config Class Initialized
INFO - 2023-02-28 04:55:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:34 --> URI Class Initialized
INFO - 2023-02-28 04:55:34 --> Router Class Initialized
INFO - 2023-02-28 04:55:34 --> Output Class Initialized
INFO - 2023-02-28 04:55:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:34 --> Input Class Initialized
INFO - 2023-02-28 04:55:34 --> Language Class Initialized
INFO - 2023-02-28 04:55:34 --> Loader Class Initialized
INFO - 2023-02-28 04:55:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:34 --> Total execution time: 0.0135
INFO - 2023-02-28 04:55:34 --> Config Class Initialized
INFO - 2023-02-28 04:55:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:34 --> URI Class Initialized
INFO - 2023-02-28 04:55:34 --> Router Class Initialized
INFO - 2023-02-28 04:55:34 --> Output Class Initialized
INFO - 2023-02-28 04:55:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:34 --> Input Class Initialized
INFO - 2023-02-28 04:55:34 --> Language Class Initialized
INFO - 2023-02-28 04:55:34 --> Loader Class Initialized
INFO - 2023-02-28 04:55:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:34 --> Total execution time: 0.0116
INFO - 2023-02-28 04:55:34 --> Config Class Initialized
INFO - 2023-02-28 04:55:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:34 --> URI Class Initialized
INFO - 2023-02-28 04:55:34 --> Router Class Initialized
INFO - 2023-02-28 04:55:34 --> Output Class Initialized
INFO - 2023-02-28 04:55:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:34 --> Input Class Initialized
INFO - 2023-02-28 04:55:34 --> Language Class Initialized
INFO - 2023-02-28 04:55:34 --> Loader Class Initialized
INFO - 2023-02-28 04:55:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:34 --> Model "Login_model" initialized
INFO - 2023-02-28 04:55:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:34 --> Total execution time: 0.0814
INFO - 2023-02-28 04:55:34 --> Config Class Initialized
INFO - 2023-02-28 04:55:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:34 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:34 --> URI Class Initialized
INFO - 2023-02-28 04:55:34 --> Router Class Initialized
INFO - 2023-02-28 04:55:34 --> Output Class Initialized
INFO - 2023-02-28 04:55:34 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:34 --> Input Class Initialized
INFO - 2023-02-28 04:55:34 --> Language Class Initialized
INFO - 2023-02-28 04:55:34 --> Loader Class Initialized
INFO - 2023-02-28 04:55:34 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:34 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:34 --> Model "Login_model" initialized
INFO - 2023-02-28 04:55:34 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:34 --> Total execution time: 0.0389
INFO - 2023-02-28 04:55:40 --> Config Class Initialized
INFO - 2023-02-28 04:55:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:40 --> URI Class Initialized
INFO - 2023-02-28 04:55:40 --> Router Class Initialized
INFO - 2023-02-28 04:55:40 --> Output Class Initialized
INFO - 2023-02-28 04:55:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:40 --> Input Class Initialized
INFO - 2023-02-28 04:55:40 --> Language Class Initialized
INFO - 2023-02-28 04:55:40 --> Loader Class Initialized
INFO - 2023-02-28 04:55:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:41 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:41 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:41 --> Total execution time: 0.0136
INFO - 2023-02-28 04:55:41 --> Config Class Initialized
INFO - 2023-02-28 04:55:41 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:41 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:41 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:41 --> URI Class Initialized
INFO - 2023-02-28 04:55:41 --> Router Class Initialized
INFO - 2023-02-28 04:55:41 --> Output Class Initialized
INFO - 2023-02-28 04:55:41 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:41 --> Input Class Initialized
INFO - 2023-02-28 04:55:41 --> Language Class Initialized
INFO - 2023-02-28 04:55:41 --> Loader Class Initialized
INFO - 2023-02-28 04:55:41 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:41 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:41 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:41 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:41 --> Total execution time: 0.0120
INFO - 2023-02-28 04:55:42 --> Config Class Initialized
INFO - 2023-02-28 04:55:42 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:42 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:42 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:42 --> URI Class Initialized
INFO - 2023-02-28 04:55:42 --> Router Class Initialized
INFO - 2023-02-28 04:55:42 --> Output Class Initialized
INFO - 2023-02-28 04:55:42 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:42 --> Input Class Initialized
INFO - 2023-02-28 04:55:42 --> Language Class Initialized
INFO - 2023-02-28 04:55:42 --> Loader Class Initialized
INFO - 2023-02-28 04:55:42 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:42 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:42 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:42 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:42 --> Total execution time: 0.0646
INFO - 2023-02-28 04:55:42 --> Config Class Initialized
INFO - 2023-02-28 04:55:42 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:42 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:42 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:42 --> URI Class Initialized
INFO - 2023-02-28 04:55:42 --> Router Class Initialized
INFO - 2023-02-28 04:55:42 --> Output Class Initialized
INFO - 2023-02-28 04:55:42 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:42 --> Input Class Initialized
INFO - 2023-02-28 04:55:42 --> Language Class Initialized
INFO - 2023-02-28 04:55:42 --> Loader Class Initialized
INFO - 2023-02-28 04:55:42 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:42 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:42 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:43 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:43 --> Total execution time: 0.0474
INFO - 2023-02-28 04:55:46 --> Config Class Initialized
INFO - 2023-02-28 04:55:46 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:46 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:46 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:46 --> URI Class Initialized
INFO - 2023-02-28 04:55:46 --> Router Class Initialized
INFO - 2023-02-28 04:55:46 --> Output Class Initialized
INFO - 2023-02-28 04:55:46 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:46 --> Input Class Initialized
INFO - 2023-02-28 04:55:46 --> Language Class Initialized
INFO - 2023-02-28 04:55:46 --> Loader Class Initialized
INFO - 2023-02-28 04:55:46 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:46 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:46 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:46 --> Total execution time: 0.0181
INFO - 2023-02-28 04:55:46 --> Config Class Initialized
INFO - 2023-02-28 04:55:46 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:46 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:46 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:46 --> URI Class Initialized
INFO - 2023-02-28 04:55:46 --> Router Class Initialized
INFO - 2023-02-28 04:55:46 --> Output Class Initialized
INFO - 2023-02-28 04:55:46 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:46 --> Input Class Initialized
INFO - 2023-02-28 04:55:46 --> Language Class Initialized
INFO - 2023-02-28 04:55:46 --> Loader Class Initialized
INFO - 2023-02-28 04:55:46 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:46 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:46 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:46 --> Total execution time: 0.0146
INFO - 2023-02-28 04:55:47 --> Config Class Initialized
INFO - 2023-02-28 04:55:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:47 --> URI Class Initialized
INFO - 2023-02-28 04:55:47 --> Router Class Initialized
INFO - 2023-02-28 04:55:47 --> Output Class Initialized
INFO - 2023-02-28 04:55:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:47 --> Input Class Initialized
INFO - 2023-02-28 04:55:47 --> Language Class Initialized
INFO - 2023-02-28 04:55:47 --> Loader Class Initialized
INFO - 2023-02-28 04:55:47 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:47 --> Model "Login_model" initialized
INFO - 2023-02-28 04:55:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:47 --> Total execution time: 0.0495
INFO - 2023-02-28 04:55:47 --> Config Class Initialized
INFO - 2023-02-28 04:55:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:55:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:55:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:55:47 --> URI Class Initialized
INFO - 2023-02-28 04:55:47 --> Router Class Initialized
INFO - 2023-02-28 04:55:47 --> Output Class Initialized
INFO - 2023-02-28 04:55:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:55:47 --> Input Class Initialized
INFO - 2023-02-28 04:55:47 --> Language Class Initialized
INFO - 2023-02-28 04:55:47 --> Loader Class Initialized
INFO - 2023-02-28 04:55:47 --> Controller Class Initialized
DEBUG - 2023-02-28 04:55:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:55:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:55:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:55:47 --> Model "Login_model" initialized
INFO - 2023-02-28 04:55:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:55:47 --> Total execution time: 0.0594
INFO - 2023-02-28 04:56:13 --> Config Class Initialized
INFO - 2023-02-28 04:56:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:13 --> URI Class Initialized
INFO - 2023-02-28 04:56:13 --> Router Class Initialized
INFO - 2023-02-28 04:56:13 --> Output Class Initialized
INFO - 2023-02-28 04:56:13 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:13 --> Input Class Initialized
INFO - 2023-02-28 04:56:13 --> Language Class Initialized
INFO - 2023-02-28 04:56:13 --> Loader Class Initialized
INFO - 2023-02-28 04:56:13 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:13 --> Total execution time: 0.0457
INFO - 2023-02-28 04:56:13 --> Config Class Initialized
INFO - 2023-02-28 04:56:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:13 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:13 --> URI Class Initialized
INFO - 2023-02-28 04:56:13 --> Router Class Initialized
INFO - 2023-02-28 04:56:13 --> Output Class Initialized
INFO - 2023-02-28 04:56:13 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:13 --> Input Class Initialized
INFO - 2023-02-28 04:56:13 --> Language Class Initialized
INFO - 2023-02-28 04:56:13 --> Loader Class Initialized
INFO - 2023-02-28 04:56:13 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:13 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:13 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:13 --> Total execution time: 0.0397
INFO - 2023-02-28 04:56:27 --> Config Class Initialized
INFO - 2023-02-28 04:56:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:27 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:27 --> URI Class Initialized
INFO - 2023-02-28 04:56:27 --> Router Class Initialized
INFO - 2023-02-28 04:56:27 --> Output Class Initialized
INFO - 2023-02-28 04:56:27 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:27 --> Input Class Initialized
INFO - 2023-02-28 04:56:27 --> Language Class Initialized
INFO - 2023-02-28 04:56:27 --> Loader Class Initialized
INFO - 2023-02-28 04:56:27 --> Controller Class Initialized
INFO - 2023-02-28 04:56:27 --> Helper loaded: form_helper
INFO - 2023-02-28 04:56:27 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:56:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:27 --> Model "Change_model" initialized
INFO - 2023-02-28 04:56:27 --> Model "Grafana_model" initialized
INFO - 2023-02-28 04:56:27 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:27 --> Total execution time: 0.0275
INFO - 2023-02-28 04:56:27 --> Config Class Initialized
INFO - 2023-02-28 04:56:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:27 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:27 --> URI Class Initialized
INFO - 2023-02-28 04:56:27 --> Router Class Initialized
INFO - 2023-02-28 04:56:27 --> Output Class Initialized
INFO - 2023-02-28 04:56:27 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:27 --> Input Class Initialized
INFO - 2023-02-28 04:56:27 --> Language Class Initialized
INFO - 2023-02-28 04:56:27 --> Loader Class Initialized
INFO - 2023-02-28 04:56:27 --> Controller Class Initialized
INFO - 2023-02-28 04:56:27 --> Helper loaded: form_helper
INFO - 2023-02-28 04:56:27 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:56:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:27 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:27 --> Total execution time: 0.0039
INFO - 2023-02-28 04:56:27 --> Config Class Initialized
INFO - 2023-02-28 04:56:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:27 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:27 --> URI Class Initialized
INFO - 2023-02-28 04:56:27 --> Router Class Initialized
INFO - 2023-02-28 04:56:27 --> Output Class Initialized
INFO - 2023-02-28 04:56:27 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:27 --> Input Class Initialized
INFO - 2023-02-28 04:56:27 --> Language Class Initialized
INFO - 2023-02-28 04:56:27 --> Loader Class Initialized
INFO - 2023-02-28 04:56:27 --> Controller Class Initialized
INFO - 2023-02-28 04:56:27 --> Helper loaded: form_helper
INFO - 2023-02-28 04:56:27 --> Helper loaded: url_helper
DEBUG - 2023-02-28 04:56:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:27 --> Model "Login_model" initialized
INFO - 2023-02-28 04:56:27 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:27 --> Total execution time: 0.0162
INFO - 2023-02-28 04:56:27 --> Config Class Initialized
INFO - 2023-02-28 04:56:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:27 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:27 --> URI Class Initialized
INFO - 2023-02-28 04:56:27 --> Router Class Initialized
INFO - 2023-02-28 04:56:27 --> Output Class Initialized
INFO - 2023-02-28 04:56:27 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:27 --> Input Class Initialized
INFO - 2023-02-28 04:56:27 --> Language Class Initialized
INFO - 2023-02-28 04:56:27 --> Loader Class Initialized
INFO - 2023-02-28 04:56:27 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:27 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:27 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:27 --> Total execution time: 0.0141
INFO - 2023-02-28 04:56:27 --> Config Class Initialized
INFO - 2023-02-28 04:56:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:27 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:27 --> URI Class Initialized
INFO - 2023-02-28 04:56:27 --> Router Class Initialized
INFO - 2023-02-28 04:56:27 --> Output Class Initialized
INFO - 2023-02-28 04:56:27 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:27 --> Input Class Initialized
INFO - 2023-02-28 04:56:27 --> Language Class Initialized
INFO - 2023-02-28 04:56:27 --> Loader Class Initialized
INFO - 2023-02-28 04:56:27 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:27 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:27 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:27 --> Total execution time: 0.0126
INFO - 2023-02-28 04:56:27 --> Config Class Initialized
INFO - 2023-02-28 04:56:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:27 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:27 --> URI Class Initialized
INFO - 2023-02-28 04:56:27 --> Router Class Initialized
INFO - 2023-02-28 04:56:27 --> Output Class Initialized
INFO - 2023-02-28 04:56:27 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:27 --> Input Class Initialized
INFO - 2023-02-28 04:56:27 --> Language Class Initialized
INFO - 2023-02-28 04:56:27 --> Loader Class Initialized
INFO - 2023-02-28 04:56:27 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:27 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:27 --> Model "Login_model" initialized
INFO - 2023-02-28 04:56:27 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:27 --> Total execution time: 0.0877
INFO - 2023-02-28 04:56:27 --> Config Class Initialized
INFO - 2023-02-28 04:56:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:27 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:27 --> URI Class Initialized
INFO - 2023-02-28 04:56:27 --> Router Class Initialized
INFO - 2023-02-28 04:56:27 --> Output Class Initialized
INFO - 2023-02-28 04:56:27 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:27 --> Input Class Initialized
INFO - 2023-02-28 04:56:27 --> Language Class Initialized
INFO - 2023-02-28 04:56:27 --> Loader Class Initialized
INFO - 2023-02-28 04:56:27 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:27 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:27 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:28 --> Model "Login_model" initialized
INFO - 2023-02-28 04:56:28 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:28 --> Total execution time: 0.0436
INFO - 2023-02-28 04:56:31 --> Config Class Initialized
INFO - 2023-02-28 04:56:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:31 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:31 --> URI Class Initialized
INFO - 2023-02-28 04:56:31 --> Router Class Initialized
INFO - 2023-02-28 04:56:31 --> Output Class Initialized
INFO - 2023-02-28 04:56:31 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:31 --> Input Class Initialized
INFO - 2023-02-28 04:56:31 --> Language Class Initialized
INFO - 2023-02-28 04:56:31 --> Loader Class Initialized
INFO - 2023-02-28 04:56:31 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:31 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:31 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:31 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:31 --> Total execution time: 0.0472
INFO - 2023-02-28 04:56:31 --> Config Class Initialized
INFO - 2023-02-28 04:56:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:31 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:31 --> URI Class Initialized
INFO - 2023-02-28 04:56:31 --> Router Class Initialized
INFO - 2023-02-28 04:56:31 --> Output Class Initialized
INFO - 2023-02-28 04:56:31 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:31 --> Input Class Initialized
INFO - 2023-02-28 04:56:31 --> Language Class Initialized
INFO - 2023-02-28 04:56:31 --> Loader Class Initialized
INFO - 2023-02-28 04:56:31 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:31 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:31 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:31 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:31 --> Total execution time: 0.0450
INFO - 2023-02-28 04:56:33 --> Config Class Initialized
INFO - 2023-02-28 04:56:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:33 --> URI Class Initialized
INFO - 2023-02-28 04:56:33 --> Router Class Initialized
INFO - 2023-02-28 04:56:33 --> Output Class Initialized
INFO - 2023-02-28 04:56:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:33 --> Input Class Initialized
INFO - 2023-02-28 04:56:33 --> Language Class Initialized
INFO - 2023-02-28 04:56:33 --> Loader Class Initialized
INFO - 2023-02-28 04:56:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:33 --> Total execution time: 0.0147
INFO - 2023-02-28 04:56:33 --> Config Class Initialized
INFO - 2023-02-28 04:56:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:33 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:33 --> URI Class Initialized
INFO - 2023-02-28 04:56:33 --> Router Class Initialized
INFO - 2023-02-28 04:56:33 --> Output Class Initialized
INFO - 2023-02-28 04:56:33 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:33 --> Input Class Initialized
INFO - 2023-02-28 04:56:33 --> Language Class Initialized
INFO - 2023-02-28 04:56:33 --> Loader Class Initialized
INFO - 2023-02-28 04:56:33 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:33 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:33 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:33 --> Total execution time: 0.0105
INFO - 2023-02-28 04:56:35 --> Config Class Initialized
INFO - 2023-02-28 04:56:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:35 --> URI Class Initialized
INFO - 2023-02-28 04:56:35 --> Router Class Initialized
INFO - 2023-02-28 04:56:35 --> Output Class Initialized
INFO - 2023-02-28 04:56:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:35 --> Input Class Initialized
INFO - 2023-02-28 04:56:35 --> Language Class Initialized
INFO - 2023-02-28 04:56:35 --> Loader Class Initialized
INFO - 2023-02-28 04:56:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:35 --> Model "Login_model" initialized
INFO - 2023-02-28 04:56:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:35 --> Total execution time: 0.0468
INFO - 2023-02-28 04:56:35 --> Config Class Initialized
INFO - 2023-02-28 04:56:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:35 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:35 --> URI Class Initialized
INFO - 2023-02-28 04:56:35 --> Router Class Initialized
INFO - 2023-02-28 04:56:35 --> Output Class Initialized
INFO - 2023-02-28 04:56:35 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:35 --> Input Class Initialized
INFO - 2023-02-28 04:56:35 --> Language Class Initialized
INFO - 2023-02-28 04:56:35 --> Loader Class Initialized
INFO - 2023-02-28 04:56:35 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:35 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:35 --> Model "Login_model" initialized
INFO - 2023-02-28 04:56:35 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:35 --> Total execution time: 0.0397
INFO - 2023-02-28 04:56:36 --> Config Class Initialized
INFO - 2023-02-28 04:56:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:36 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:36 --> URI Class Initialized
INFO - 2023-02-28 04:56:36 --> Router Class Initialized
INFO - 2023-02-28 04:56:36 --> Output Class Initialized
INFO - 2023-02-28 04:56:36 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:36 --> Input Class Initialized
INFO - 2023-02-28 04:56:36 --> Language Class Initialized
INFO - 2023-02-28 04:56:36 --> Loader Class Initialized
INFO - 2023-02-28 04:56:36 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:36 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:36 --> Total execution time: 0.0036
INFO - 2023-02-28 04:56:36 --> Config Class Initialized
INFO - 2023-02-28 04:56:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:36 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:36 --> URI Class Initialized
INFO - 2023-02-28 04:56:36 --> Router Class Initialized
INFO - 2023-02-28 04:56:36 --> Output Class Initialized
INFO - 2023-02-28 04:56:36 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:36 --> Input Class Initialized
INFO - 2023-02-28 04:56:36 --> Language Class Initialized
INFO - 2023-02-28 04:56:36 --> Loader Class Initialized
INFO - 2023-02-28 04:56:36 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:36 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:36 --> Model "Login_model" initialized
INFO - 2023-02-28 04:56:36 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:36 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:56:36 --> Query error:  - Invalid query: 
INFO - 2023-02-28 04:56:36 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:56:37 --> Config Class Initialized
INFO - 2023-02-28 04:56:37 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:37 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:37 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:37 --> URI Class Initialized
INFO - 2023-02-28 04:56:37 --> Router Class Initialized
INFO - 2023-02-28 04:56:37 --> Output Class Initialized
INFO - 2023-02-28 04:56:37 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:37 --> Input Class Initialized
INFO - 2023-02-28 04:56:37 --> Language Class Initialized
INFO - 2023-02-28 04:56:37 --> Loader Class Initialized
INFO - 2023-02-28 04:56:37 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:37 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:37 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:56:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by id desc limit  offset 0' at line 1 - Invalid query:  order by id desc limit  offset 0
INFO - 2023-02-28 04:56:37 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:56:39 --> Config Class Initialized
INFO - 2023-02-28 04:56:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:39 --> URI Class Initialized
INFO - 2023-02-28 04:56:39 --> Router Class Initialized
INFO - 2023-02-28 04:56:39 --> Output Class Initialized
INFO - 2023-02-28 04:56:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:39 --> Input Class Initialized
INFO - 2023-02-28 04:56:39 --> Language Class Initialized
INFO - 2023-02-28 04:56:39 --> Loader Class Initialized
INFO - 2023-02-28 04:56:39 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:39 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:39 --> Total execution time: 0.0037
INFO - 2023-02-28 04:56:39 --> Config Class Initialized
INFO - 2023-02-28 04:56:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:39 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:39 --> URI Class Initialized
INFO - 2023-02-28 04:56:39 --> Router Class Initialized
INFO - 2023-02-28 04:56:39 --> Output Class Initialized
INFO - 2023-02-28 04:56:39 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:39 --> Input Class Initialized
INFO - 2023-02-28 04:56:39 --> Language Class Initialized
INFO - 2023-02-28 04:56:39 --> Loader Class Initialized
INFO - 2023-02-28 04:56:39 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:39 --> Model "Login_model" initialized
INFO - 2023-02-28 04:56:39 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:39 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:56:39 --> Query error:  - Invalid query: 
INFO - 2023-02-28 04:56:39 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:56:40 --> Config Class Initialized
INFO - 2023-02-28 04:56:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:40 --> URI Class Initialized
INFO - 2023-02-28 04:56:40 --> Router Class Initialized
INFO - 2023-02-28 04:56:40 --> Output Class Initialized
INFO - 2023-02-28 04:56:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:40 --> Input Class Initialized
INFO - 2023-02-28 04:56:40 --> Language Class Initialized
INFO - 2023-02-28 04:56:40 --> Loader Class Initialized
INFO - 2023-02-28 04:56:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:40 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:40 --> Model "Login_model" initialized
INFO - 2023-02-28 04:56:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:40 --> Total execution time: 0.0490
INFO - 2023-02-28 04:56:40 --> Config Class Initialized
INFO - 2023-02-28 04:56:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:40 --> URI Class Initialized
INFO - 2023-02-28 04:56:40 --> Router Class Initialized
INFO - 2023-02-28 04:56:40 --> Output Class Initialized
INFO - 2023-02-28 04:56:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:40 --> Input Class Initialized
INFO - 2023-02-28 04:56:40 --> Language Class Initialized
INFO - 2023-02-28 04:56:40 --> Loader Class Initialized
INFO - 2023-02-28 04:56:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:40 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:40 --> Model "Login_model" initialized
INFO - 2023-02-28 04:56:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:40 --> Total execution time: 0.0374
INFO - 2023-02-28 04:56:40 --> Config Class Initialized
INFO - 2023-02-28 04:56:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:40 --> URI Class Initialized
INFO - 2023-02-28 04:56:40 --> Router Class Initialized
INFO - 2023-02-28 04:56:40 --> Output Class Initialized
INFO - 2023-02-28 04:56:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:40 --> Input Class Initialized
INFO - 2023-02-28 04:56:40 --> Language Class Initialized
INFO - 2023-02-28 04:56:40 --> Loader Class Initialized
INFO - 2023-02-28 04:56:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:40 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:40 --> Total execution time: 0.0035
INFO - 2023-02-28 04:56:40 --> Config Class Initialized
INFO - 2023-02-28 04:56:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:40 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:40 --> URI Class Initialized
INFO - 2023-02-28 04:56:40 --> Router Class Initialized
INFO - 2023-02-28 04:56:40 --> Output Class Initialized
INFO - 2023-02-28 04:56:40 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:40 --> Input Class Initialized
INFO - 2023-02-28 04:56:40 --> Language Class Initialized
INFO - 2023-02-28 04:56:40 --> Loader Class Initialized
INFO - 2023-02-28 04:56:40 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:40 --> Model "Login_model" initialized
INFO - 2023-02-28 04:56:40 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:40 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:56:40 --> Query error:  - Invalid query: 
INFO - 2023-02-28 04:56:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:56:41 --> Config Class Initialized
INFO - 2023-02-28 04:56:41 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:41 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:41 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:41 --> URI Class Initialized
INFO - 2023-02-28 04:56:41 --> Router Class Initialized
INFO - 2023-02-28 04:56:41 --> Output Class Initialized
INFO - 2023-02-28 04:56:41 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:41 --> Input Class Initialized
INFO - 2023-02-28 04:56:41 --> Language Class Initialized
INFO - 2023-02-28 04:56:41 --> Loader Class Initialized
INFO - 2023-02-28 04:56:41 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:41 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:41 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:56:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by id desc limit  offset 0' at line 1 - Invalid query:  order by id desc limit  offset 0
INFO - 2023-02-28 04:56:41 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:56:44 --> Config Class Initialized
INFO - 2023-02-28 04:56:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:44 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:44 --> URI Class Initialized
INFO - 2023-02-28 04:56:44 --> Router Class Initialized
INFO - 2023-02-28 04:56:44 --> Output Class Initialized
INFO - 2023-02-28 04:56:44 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:44 --> Input Class Initialized
INFO - 2023-02-28 04:56:44 --> Language Class Initialized
INFO - 2023-02-28 04:56:44 --> Loader Class Initialized
INFO - 2023-02-28 04:56:44 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:44 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:44 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:44 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:44 --> Total execution time: 0.0497
INFO - 2023-02-28 04:56:44 --> Config Class Initialized
INFO - 2023-02-28 04:56:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:44 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:44 --> URI Class Initialized
INFO - 2023-02-28 04:56:44 --> Router Class Initialized
INFO - 2023-02-28 04:56:44 --> Output Class Initialized
INFO - 2023-02-28 04:56:44 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:44 --> Input Class Initialized
INFO - 2023-02-28 04:56:44 --> Language Class Initialized
INFO - 2023-02-28 04:56:44 --> Loader Class Initialized
INFO - 2023-02-28 04:56:44 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:44 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:44 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:44 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:44 --> Total execution time: 0.0385
INFO - 2023-02-28 04:56:46 --> Config Class Initialized
INFO - 2023-02-28 04:56:46 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:46 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:46 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:46 --> URI Class Initialized
INFO - 2023-02-28 04:56:46 --> Router Class Initialized
INFO - 2023-02-28 04:56:46 --> Output Class Initialized
INFO - 2023-02-28 04:56:46 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:46 --> Input Class Initialized
INFO - 2023-02-28 04:56:46 --> Language Class Initialized
INFO - 2023-02-28 04:56:46 --> Loader Class Initialized
INFO - 2023-02-28 04:56:46 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:46 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:46 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:56:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0' at line 1 - Invalid query: select id,alarm_type as job_type,status,job_info,handle_time,handler_name from cluster_alarm_info where id is not null order by id desc limit  offset 0
INFO - 2023-02-28 04:56:46 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:56:47 --> Config Class Initialized
INFO - 2023-02-28 04:56:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:47 --> URI Class Initialized
INFO - 2023-02-28 04:56:47 --> Router Class Initialized
INFO - 2023-02-28 04:56:47 --> Output Class Initialized
INFO - 2023-02-28 04:56:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:47 --> Input Class Initialized
INFO - 2023-02-28 04:56:47 --> Language Class Initialized
INFO - 2023-02-28 04:56:47 --> Loader Class Initialized
INFO - 2023-02-28 04:56:47 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:47 --> Total execution time: 0.0156
INFO - 2023-02-28 04:56:47 --> Config Class Initialized
INFO - 2023-02-28 04:56:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:47 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:47 --> URI Class Initialized
INFO - 2023-02-28 04:56:47 --> Router Class Initialized
INFO - 2023-02-28 04:56:47 --> Output Class Initialized
INFO - 2023-02-28 04:56:47 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:47 --> Input Class Initialized
INFO - 2023-02-28 04:56:47 --> Language Class Initialized
INFO - 2023-02-28 04:56:47 --> Loader Class Initialized
INFO - 2023-02-28 04:56:47 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:47 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:47 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:47 --> Total execution time: 0.0514
INFO - 2023-02-28 04:56:49 --> Config Class Initialized
INFO - 2023-02-28 04:56:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:49 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:49 --> URI Class Initialized
INFO - 2023-02-28 04:56:49 --> Router Class Initialized
INFO - 2023-02-28 04:56:49 --> Output Class Initialized
INFO - 2023-02-28 04:56:49 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:49 --> Input Class Initialized
INFO - 2023-02-28 04:56:49 --> Language Class Initialized
INFO - 2023-02-28 04:56:49 --> Loader Class Initialized
INFO - 2023-02-28 04:56:49 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:49 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:49 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 04:56:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0' at line 1 - Invalid query: select id,alarm_type as job_type,status,job_info,handle_time,handler_name from cluster_alarm_info where id is not null order by id desc limit  offset 0
INFO - 2023-02-28 04:56:49 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 04:56:50 --> Config Class Initialized
INFO - 2023-02-28 04:56:50 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:50 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:50 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:50 --> URI Class Initialized
INFO - 2023-02-28 04:56:50 --> Router Class Initialized
INFO - 2023-02-28 04:56:50 --> Output Class Initialized
INFO - 2023-02-28 04:56:50 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:50 --> Input Class Initialized
INFO - 2023-02-28 04:56:50 --> Language Class Initialized
INFO - 2023-02-28 04:56:50 --> Loader Class Initialized
INFO - 2023-02-28 04:56:50 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:50 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:51 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:51 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:51 --> Total execution time: 0.0174
INFO - 2023-02-28 04:56:51 --> Config Class Initialized
INFO - 2023-02-28 04:56:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:51 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:51 --> URI Class Initialized
INFO - 2023-02-28 04:56:51 --> Router Class Initialized
INFO - 2023-02-28 04:56:51 --> Output Class Initialized
INFO - 2023-02-28 04:56:51 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:51 --> Input Class Initialized
INFO - 2023-02-28 04:56:51 --> Language Class Initialized
INFO - 2023-02-28 04:56:51 --> Loader Class Initialized
INFO - 2023-02-28 04:56:51 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:51 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:51 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:51 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:51 --> Total execution time: 0.0121
INFO - 2023-02-28 04:56:54 --> Config Class Initialized
INFO - 2023-02-28 04:56:54 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:54 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:54 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:54 --> URI Class Initialized
INFO - 2023-02-28 04:56:54 --> Router Class Initialized
INFO - 2023-02-28 04:56:54 --> Output Class Initialized
INFO - 2023-02-28 04:56:54 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:54 --> Input Class Initialized
INFO - 2023-02-28 04:56:54 --> Language Class Initialized
INFO - 2023-02-28 04:56:54 --> Loader Class Initialized
INFO - 2023-02-28 04:56:54 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:54 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:54 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:54 --> Model "Login_model" initialized
ERROR - 2023-02-28 04:56:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0' at line 1 - Invalid query: select id, name as username,email,phone_number,wechat_number,update_time,pg_dsn,pid,main_user,user_tag from kunlun_user where pid=11 order by id desc limit  offset 0
INFO - 2023-02-28 04:56:54 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:54 --> Total execution time: 0.0244
INFO - 2023-02-28 04:56:54 --> Config Class Initialized
INFO - 2023-02-28 04:56:54 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:54 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:54 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:54 --> URI Class Initialized
INFO - 2023-02-28 04:56:54 --> Router Class Initialized
INFO - 2023-02-28 04:56:54 --> Output Class Initialized
INFO - 2023-02-28 04:56:54 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:54 --> Input Class Initialized
INFO - 2023-02-28 04:56:54 --> Language Class Initialized
INFO - 2023-02-28 04:56:54 --> Loader Class Initialized
INFO - 2023-02-28 04:56:54 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:54 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:54 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:54 --> Model "Login_model" initialized
ERROR - 2023-02-28 04:56:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0' at line 1 - Invalid query: select id, name as username,email,phone_number,wechat_number,update_time,pg_dsn,pid,main_user,user_tag from kunlun_user where pid=11 order by id desc limit  offset 0
INFO - 2023-02-28 04:56:54 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:54 --> Total execution time: 0.0203
INFO - 2023-02-28 04:56:57 --> Config Class Initialized
INFO - 2023-02-28 04:56:57 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:57 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:57 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:57 --> URI Class Initialized
INFO - 2023-02-28 04:56:57 --> Router Class Initialized
INFO - 2023-02-28 04:56:57 --> Output Class Initialized
INFO - 2023-02-28 04:56:57 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:57 --> Input Class Initialized
INFO - 2023-02-28 04:56:57 --> Language Class Initialized
INFO - 2023-02-28 04:56:57 --> Loader Class Initialized
INFO - 2023-02-28 04:56:57 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:57 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:57 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:57 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:57 --> Total execution time: 0.0172
INFO - 2023-02-28 04:56:57 --> Config Class Initialized
INFO - 2023-02-28 04:56:57 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:57 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:57 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:57 --> URI Class Initialized
INFO - 2023-02-28 04:56:57 --> Router Class Initialized
INFO - 2023-02-28 04:56:57 --> Output Class Initialized
INFO - 2023-02-28 04:56:57 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:57 --> Input Class Initialized
INFO - 2023-02-28 04:56:57 --> Language Class Initialized
INFO - 2023-02-28 04:56:57 --> Loader Class Initialized
INFO - 2023-02-28 04:56:57 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:57 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:57 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:57 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:57 --> Total execution time: 0.0129
INFO - 2023-02-28 04:56:59 --> Config Class Initialized
INFO - 2023-02-28 04:56:59 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:59 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:59 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:59 --> URI Class Initialized
INFO - 2023-02-28 04:56:59 --> Router Class Initialized
INFO - 2023-02-28 04:56:59 --> Output Class Initialized
INFO - 2023-02-28 04:56:59 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:59 --> Input Class Initialized
INFO - 2023-02-28 04:56:59 --> Language Class Initialized
INFO - 2023-02-28 04:56:59 --> Loader Class Initialized
INFO - 2023-02-28 04:56:59 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:59 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:59 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:59 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:59 --> Total execution time: 0.0680
INFO - 2023-02-28 04:56:59 --> Config Class Initialized
INFO - 2023-02-28 04:56:59 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:56:59 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:56:59 --> Utf8 Class Initialized
INFO - 2023-02-28 04:56:59 --> URI Class Initialized
INFO - 2023-02-28 04:56:59 --> Router Class Initialized
INFO - 2023-02-28 04:56:59 --> Output Class Initialized
INFO - 2023-02-28 04:56:59 --> Security Class Initialized
DEBUG - 2023-02-28 04:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:56:59 --> Input Class Initialized
INFO - 2023-02-28 04:56:59 --> Language Class Initialized
INFO - 2023-02-28 04:56:59 --> Loader Class Initialized
INFO - 2023-02-28 04:56:59 --> Controller Class Initialized
DEBUG - 2023-02-28 04:56:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:56:59 --> Database Driver Class Initialized
INFO - 2023-02-28 04:56:59 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:56:59 --> Final output sent to browser
DEBUG - 2023-02-28 04:56:59 --> Total execution time: 0.0115
INFO - 2023-02-28 04:57:00 --> Config Class Initialized
INFO - 2023-02-28 04:57:00 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:57:00 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:57:00 --> Utf8 Class Initialized
INFO - 2023-02-28 04:57:00 --> URI Class Initialized
INFO - 2023-02-28 04:57:00 --> Router Class Initialized
INFO - 2023-02-28 04:57:00 --> Output Class Initialized
INFO - 2023-02-28 04:57:00 --> Security Class Initialized
DEBUG - 2023-02-28 04:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:57:00 --> Input Class Initialized
INFO - 2023-02-28 04:57:00 --> Language Class Initialized
INFO - 2023-02-28 04:57:00 --> Loader Class Initialized
INFO - 2023-02-28 04:57:00 --> Controller Class Initialized
DEBUG - 2023-02-28 04:57:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:57:00 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:00 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:57:00 --> Final output sent to browser
DEBUG - 2023-02-28 04:57:00 --> Total execution time: 0.0562
INFO - 2023-02-28 04:57:00 --> Config Class Initialized
INFO - 2023-02-28 04:57:00 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:57:00 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:57:00 --> Utf8 Class Initialized
INFO - 2023-02-28 04:57:00 --> URI Class Initialized
INFO - 2023-02-28 04:57:00 --> Router Class Initialized
INFO - 2023-02-28 04:57:00 --> Output Class Initialized
INFO - 2023-02-28 04:57:00 --> Security Class Initialized
DEBUG - 2023-02-28 04:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:57:00 --> Input Class Initialized
INFO - 2023-02-28 04:57:00 --> Language Class Initialized
INFO - 2023-02-28 04:57:00 --> Loader Class Initialized
INFO - 2023-02-28 04:57:00 --> Controller Class Initialized
DEBUG - 2023-02-28 04:57:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:57:00 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:00 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:57:00 --> Final output sent to browser
DEBUG - 2023-02-28 04:57:00 --> Total execution time: 0.0490
INFO - 2023-02-28 04:57:00 --> Config Class Initialized
INFO - 2023-02-28 04:57:00 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:57:00 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:57:00 --> Utf8 Class Initialized
INFO - 2023-02-28 04:57:00 --> URI Class Initialized
INFO - 2023-02-28 04:57:00 --> Router Class Initialized
INFO - 2023-02-28 04:57:00 --> Output Class Initialized
INFO - 2023-02-28 04:57:00 --> Security Class Initialized
DEBUG - 2023-02-28 04:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:57:00 --> Input Class Initialized
INFO - 2023-02-28 04:57:00 --> Language Class Initialized
INFO - 2023-02-28 04:57:00 --> Loader Class Initialized
INFO - 2023-02-28 04:57:00 --> Controller Class Initialized
DEBUG - 2023-02-28 04:57:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:57:00 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:00 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:57:00 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:00 --> Model "Login_model" initialized
INFO - 2023-02-28 04:57:00 --> Final output sent to browser
DEBUG - 2023-02-28 04:57:00 --> Total execution time: 0.0445
INFO - 2023-02-28 04:57:00 --> Config Class Initialized
INFO - 2023-02-28 04:57:00 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:57:00 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:57:00 --> Utf8 Class Initialized
INFO - 2023-02-28 04:57:00 --> URI Class Initialized
INFO - 2023-02-28 04:57:00 --> Router Class Initialized
INFO - 2023-02-28 04:57:00 --> Output Class Initialized
INFO - 2023-02-28 04:57:00 --> Security Class Initialized
DEBUG - 2023-02-28 04:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:57:00 --> Input Class Initialized
INFO - 2023-02-28 04:57:00 --> Language Class Initialized
INFO - 2023-02-28 04:57:00 --> Loader Class Initialized
INFO - 2023-02-28 04:57:00 --> Controller Class Initialized
DEBUG - 2023-02-28 04:57:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:57:00 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:00 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:57:00 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:00 --> Model "Login_model" initialized
INFO - 2023-02-28 04:57:00 --> Final output sent to browser
DEBUG - 2023-02-28 04:57:00 --> Total execution time: 0.0351
INFO - 2023-02-28 04:57:02 --> Config Class Initialized
INFO - 2023-02-28 04:57:02 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:57:02 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:57:02 --> Utf8 Class Initialized
INFO - 2023-02-28 04:57:02 --> URI Class Initialized
INFO - 2023-02-28 04:57:02 --> Router Class Initialized
INFO - 2023-02-28 04:57:02 --> Output Class Initialized
INFO - 2023-02-28 04:57:02 --> Security Class Initialized
DEBUG - 2023-02-28 04:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:57:02 --> Input Class Initialized
INFO - 2023-02-28 04:57:02 --> Language Class Initialized
INFO - 2023-02-28 04:57:02 --> Loader Class Initialized
INFO - 2023-02-28 04:57:02 --> Controller Class Initialized
DEBUG - 2023-02-28 04:57:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:57:02 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:02 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:02 --> Model "Login_model" initialized
ERROR - 2023-02-28 04:57:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0' at line 1 - Invalid query: select id, name as username,email,phone_number,wechat_number,update_time,pg_dsn,pid,main_user,user_tag from kunlun_user where pid=11 order by id desc limit  offset 0
INFO - 2023-02-28 04:57:02 --> Final output sent to browser
DEBUG - 2023-02-28 04:57:02 --> Total execution time: 0.0271
INFO - 2023-02-28 04:57:02 --> Config Class Initialized
INFO - 2023-02-28 04:57:02 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:57:02 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:57:02 --> Utf8 Class Initialized
INFO - 2023-02-28 04:57:02 --> URI Class Initialized
INFO - 2023-02-28 04:57:02 --> Router Class Initialized
INFO - 2023-02-28 04:57:02 --> Output Class Initialized
INFO - 2023-02-28 04:57:02 --> Security Class Initialized
DEBUG - 2023-02-28 04:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:57:02 --> Input Class Initialized
INFO - 2023-02-28 04:57:02 --> Language Class Initialized
INFO - 2023-02-28 04:57:02 --> Loader Class Initialized
INFO - 2023-02-28 04:57:02 --> Controller Class Initialized
DEBUG - 2023-02-28 04:57:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:57:02 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:02 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:02 --> Model "Login_model" initialized
ERROR - 2023-02-28 04:57:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0' at line 1 - Invalid query: select id, name as username,email,phone_number,wechat_number,update_time,pg_dsn,pid,main_user,user_tag from kunlun_user where pid=11 order by id desc limit  offset 0
INFO - 2023-02-28 04:57:02 --> Final output sent to browser
DEBUG - 2023-02-28 04:57:02 --> Total execution time: 0.0193
INFO - 2023-02-28 04:57:02 --> Config Class Initialized
INFO - 2023-02-28 04:57:02 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:57:02 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:57:02 --> Utf8 Class Initialized
INFO - 2023-02-28 04:57:02 --> URI Class Initialized
INFO - 2023-02-28 04:57:02 --> Router Class Initialized
INFO - 2023-02-28 04:57:02 --> Output Class Initialized
INFO - 2023-02-28 04:57:02 --> Security Class Initialized
DEBUG - 2023-02-28 04:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:57:02 --> Input Class Initialized
INFO - 2023-02-28 04:57:02 --> Language Class Initialized
INFO - 2023-02-28 04:57:02 --> Loader Class Initialized
INFO - 2023-02-28 04:57:02 --> Controller Class Initialized
DEBUG - 2023-02-28 04:57:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:57:02 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:02 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:57:02 --> Final output sent to browser
DEBUG - 2023-02-28 04:57:02 --> Total execution time: 0.0207
INFO - 2023-02-28 04:57:02 --> Config Class Initialized
INFO - 2023-02-28 04:57:02 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:57:02 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:57:02 --> Utf8 Class Initialized
INFO - 2023-02-28 04:57:02 --> URI Class Initialized
INFO - 2023-02-28 04:57:02 --> Router Class Initialized
INFO - 2023-02-28 04:57:02 --> Output Class Initialized
INFO - 2023-02-28 04:57:02 --> Security Class Initialized
DEBUG - 2023-02-28 04:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:57:02 --> Input Class Initialized
INFO - 2023-02-28 04:57:02 --> Language Class Initialized
INFO - 2023-02-28 04:57:02 --> Loader Class Initialized
INFO - 2023-02-28 04:57:02 --> Controller Class Initialized
DEBUG - 2023-02-28 04:57:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:57:02 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:02 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:57:02 --> Final output sent to browser
DEBUG - 2023-02-28 04:57:02 --> Total execution time: 0.0114
INFO - 2023-02-28 04:57:03 --> Config Class Initialized
INFO - 2023-02-28 04:57:03 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:57:03 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:57:03 --> Utf8 Class Initialized
INFO - 2023-02-28 04:57:03 --> URI Class Initialized
INFO - 2023-02-28 04:57:03 --> Router Class Initialized
INFO - 2023-02-28 04:57:03 --> Output Class Initialized
INFO - 2023-02-28 04:57:03 --> Security Class Initialized
DEBUG - 2023-02-28 04:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:57:03 --> Input Class Initialized
INFO - 2023-02-28 04:57:03 --> Language Class Initialized
INFO - 2023-02-28 04:57:03 --> Loader Class Initialized
INFO - 2023-02-28 04:57:03 --> Controller Class Initialized
DEBUG - 2023-02-28 04:57:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:57:03 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:03 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:57:03 --> Final output sent to browser
DEBUG - 2023-02-28 04:57:03 --> Total execution time: 0.0184
INFO - 2023-02-28 04:57:03 --> Config Class Initialized
INFO - 2023-02-28 04:57:03 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:57:03 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:57:03 --> Utf8 Class Initialized
INFO - 2023-02-28 04:57:03 --> URI Class Initialized
INFO - 2023-02-28 04:57:03 --> Router Class Initialized
INFO - 2023-02-28 04:57:03 --> Output Class Initialized
INFO - 2023-02-28 04:57:03 --> Security Class Initialized
DEBUG - 2023-02-28 04:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:57:03 --> Input Class Initialized
INFO - 2023-02-28 04:57:03 --> Language Class Initialized
INFO - 2023-02-28 04:57:03 --> Loader Class Initialized
INFO - 2023-02-28 04:57:03 --> Controller Class Initialized
DEBUG - 2023-02-28 04:57:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:57:03 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:03 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:57:03 --> Final output sent to browser
DEBUG - 2023-02-28 04:57:03 --> Total execution time: 0.0155
INFO - 2023-02-28 04:57:04 --> Config Class Initialized
INFO - 2023-02-28 04:57:04 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:57:04 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:57:04 --> Utf8 Class Initialized
INFO - 2023-02-28 04:57:04 --> URI Class Initialized
INFO - 2023-02-28 04:57:04 --> Router Class Initialized
INFO - 2023-02-28 04:57:04 --> Output Class Initialized
INFO - 2023-02-28 04:57:04 --> Security Class Initialized
DEBUG - 2023-02-28 04:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:57:04 --> Input Class Initialized
INFO - 2023-02-28 04:57:04 --> Language Class Initialized
INFO - 2023-02-28 04:57:04 --> Loader Class Initialized
INFO - 2023-02-28 04:57:04 --> Controller Class Initialized
DEBUG - 2023-02-28 04:57:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:57:04 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:04 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:57:04 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:04 --> Model "Login_model" initialized
INFO - 2023-02-28 04:57:04 --> Final output sent to browser
DEBUG - 2023-02-28 04:57:04 --> Total execution time: 0.0449
INFO - 2023-02-28 04:57:04 --> Config Class Initialized
INFO - 2023-02-28 04:57:04 --> Hooks Class Initialized
DEBUG - 2023-02-28 04:57:04 --> UTF-8 Support Enabled
INFO - 2023-02-28 04:57:04 --> Utf8 Class Initialized
INFO - 2023-02-28 04:57:04 --> URI Class Initialized
INFO - 2023-02-28 04:57:04 --> Router Class Initialized
INFO - 2023-02-28 04:57:04 --> Output Class Initialized
INFO - 2023-02-28 04:57:04 --> Security Class Initialized
DEBUG - 2023-02-28 04:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 04:57:04 --> Input Class Initialized
INFO - 2023-02-28 04:57:04 --> Language Class Initialized
INFO - 2023-02-28 04:57:04 --> Loader Class Initialized
INFO - 2023-02-28 04:57:04 --> Controller Class Initialized
DEBUG - 2023-02-28 04:57:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 04:57:04 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:04 --> Model "Cluster_model" initialized
INFO - 2023-02-28 04:57:04 --> Database Driver Class Initialized
INFO - 2023-02-28 04:57:04 --> Model "Login_model" initialized
INFO - 2023-02-28 04:57:04 --> Final output sent to browser
DEBUG - 2023-02-28 04:57:04 --> Total execution time: 0.0380
INFO - 2023-02-28 05:35:28 --> Config Class Initialized
INFO - 2023-02-28 05:35:28 --> Hooks Class Initialized
DEBUG - 2023-02-28 05:35:28 --> UTF-8 Support Enabled
INFO - 2023-02-28 05:35:28 --> Utf8 Class Initialized
INFO - 2023-02-28 05:35:28 --> URI Class Initialized
INFO - 2023-02-28 05:35:28 --> Router Class Initialized
INFO - 2023-02-28 05:35:28 --> Output Class Initialized
INFO - 2023-02-28 05:35:28 --> Security Class Initialized
DEBUG - 2023-02-28 05:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 05:35:28 --> Input Class Initialized
INFO - 2023-02-28 05:35:28 --> Language Class Initialized
INFO - 2023-02-28 05:35:28 --> Loader Class Initialized
INFO - 2023-02-28 05:35:28 --> Controller Class Initialized
DEBUG - 2023-02-28 05:35:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 05:35:28 --> Database Driver Class Initialized
INFO - 2023-02-28 05:35:28 --> Model "Cluster_model" initialized
INFO - 2023-02-28 05:35:28 --> Final output sent to browser
DEBUG - 2023-02-28 05:35:28 --> Total execution time: 0.0472
INFO - 2023-02-28 05:35:28 --> Config Class Initialized
INFO - 2023-02-28 05:35:28 --> Hooks Class Initialized
DEBUG - 2023-02-28 05:35:28 --> UTF-8 Support Enabled
INFO - 2023-02-28 05:35:28 --> Utf8 Class Initialized
INFO - 2023-02-28 05:35:28 --> URI Class Initialized
INFO - 2023-02-28 05:35:28 --> Router Class Initialized
INFO - 2023-02-28 05:35:28 --> Output Class Initialized
INFO - 2023-02-28 05:35:28 --> Security Class Initialized
DEBUG - 2023-02-28 05:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 05:35:28 --> Input Class Initialized
INFO - 2023-02-28 05:35:28 --> Language Class Initialized
INFO - 2023-02-28 05:35:28 --> Loader Class Initialized
INFO - 2023-02-28 05:35:28 --> Controller Class Initialized
DEBUG - 2023-02-28 05:35:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 05:35:28 --> Database Driver Class Initialized
INFO - 2023-02-28 05:35:28 --> Model "Cluster_model" initialized
INFO - 2023-02-28 05:35:28 --> Final output sent to browser
DEBUG - 2023-02-28 05:35:28 --> Total execution time: 0.0440
INFO - 2023-02-28 05:35:30 --> Config Class Initialized
INFO - 2023-02-28 05:35:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 05:35:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 05:35:30 --> Utf8 Class Initialized
INFO - 2023-02-28 05:35:30 --> URI Class Initialized
INFO - 2023-02-28 05:35:30 --> Router Class Initialized
INFO - 2023-02-28 05:35:30 --> Output Class Initialized
INFO - 2023-02-28 05:35:30 --> Security Class Initialized
DEBUG - 2023-02-28 05:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 05:35:30 --> Input Class Initialized
INFO - 2023-02-28 05:35:30 --> Language Class Initialized
INFO - 2023-02-28 05:35:30 --> Loader Class Initialized
INFO - 2023-02-28 05:35:30 --> Controller Class Initialized
DEBUG - 2023-02-28 05:35:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 05:35:30 --> Database Driver Class Initialized
INFO - 2023-02-28 05:35:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 05:35:30 --> Final output sent to browser
DEBUG - 2023-02-28 05:35:30 --> Total execution time: 0.0201
INFO - 2023-02-28 05:35:30 --> Config Class Initialized
INFO - 2023-02-28 05:35:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 05:35:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 05:35:30 --> Utf8 Class Initialized
INFO - 2023-02-28 05:35:30 --> URI Class Initialized
INFO - 2023-02-28 05:35:30 --> Router Class Initialized
INFO - 2023-02-28 05:35:30 --> Output Class Initialized
INFO - 2023-02-28 05:35:30 --> Security Class Initialized
DEBUG - 2023-02-28 05:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 05:35:30 --> Input Class Initialized
INFO - 2023-02-28 05:35:30 --> Language Class Initialized
INFO - 2023-02-28 05:35:30 --> Loader Class Initialized
INFO - 2023-02-28 05:35:30 --> Controller Class Initialized
DEBUG - 2023-02-28 05:35:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 05:35:30 --> Database Driver Class Initialized
INFO - 2023-02-28 05:35:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 05:35:30 --> Final output sent to browser
DEBUG - 2023-02-28 05:35:30 --> Total execution time: 0.0215
INFO - 2023-02-28 05:35:35 --> Config Class Initialized
INFO - 2023-02-28 05:35:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 05:35:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 05:35:35 --> Utf8 Class Initialized
INFO - 2023-02-28 05:35:35 --> URI Class Initialized
INFO - 2023-02-28 05:35:35 --> Router Class Initialized
INFO - 2023-02-28 05:35:35 --> Output Class Initialized
INFO - 2023-02-28 05:35:35 --> Security Class Initialized
DEBUG - 2023-02-28 05:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 05:35:35 --> Input Class Initialized
INFO - 2023-02-28 05:35:35 --> Language Class Initialized
INFO - 2023-02-28 05:35:35 --> Loader Class Initialized
INFO - 2023-02-28 05:35:35 --> Controller Class Initialized
DEBUG - 2023-02-28 05:35:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 05:35:35 --> Database Driver Class Initialized
INFO - 2023-02-28 05:35:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 05:35:35 --> Database Driver Class Initialized
INFO - 2023-02-28 05:35:35 --> Model "Login_model" initialized
INFO - 2023-02-28 05:35:35 --> Final output sent to browser
DEBUG - 2023-02-28 05:35:35 --> Total execution time: 0.0423
INFO - 2023-02-28 05:35:35 --> Config Class Initialized
INFO - 2023-02-28 05:35:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 05:35:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 05:35:35 --> Utf8 Class Initialized
INFO - 2023-02-28 05:35:35 --> URI Class Initialized
INFO - 2023-02-28 05:35:35 --> Router Class Initialized
INFO - 2023-02-28 05:35:35 --> Output Class Initialized
INFO - 2023-02-28 05:35:35 --> Security Class Initialized
DEBUG - 2023-02-28 05:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 05:35:35 --> Input Class Initialized
INFO - 2023-02-28 05:35:35 --> Language Class Initialized
INFO - 2023-02-28 05:35:35 --> Loader Class Initialized
INFO - 2023-02-28 05:35:35 --> Controller Class Initialized
DEBUG - 2023-02-28 05:35:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 05:35:35 --> Database Driver Class Initialized
INFO - 2023-02-28 05:35:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 05:35:35 --> Database Driver Class Initialized
INFO - 2023-02-28 05:35:35 --> Model "Login_model" initialized
INFO - 2023-02-28 05:35:35 --> Final output sent to browser
DEBUG - 2023-02-28 05:35:35 --> Total execution time: 0.0417
INFO - 2023-02-28 05:35:36 --> Config Class Initialized
INFO - 2023-02-28 05:35:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 05:35:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 05:35:36 --> Utf8 Class Initialized
INFO - 2023-02-28 05:35:36 --> URI Class Initialized
INFO - 2023-02-28 05:35:36 --> Router Class Initialized
INFO - 2023-02-28 05:35:36 --> Output Class Initialized
INFO - 2023-02-28 05:35:36 --> Security Class Initialized
DEBUG - 2023-02-28 05:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 05:35:36 --> Input Class Initialized
INFO - 2023-02-28 05:35:36 --> Language Class Initialized
INFO - 2023-02-28 05:35:36 --> Loader Class Initialized
INFO - 2023-02-28 05:35:36 --> Controller Class Initialized
DEBUG - 2023-02-28 05:35:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 05:35:36 --> Database Driver Class Initialized
INFO - 2023-02-28 05:35:36 --> Model "Cluster_model" initialized
INFO - 2023-02-28 05:35:36 --> Final output sent to browser
DEBUG - 2023-02-28 05:35:36 --> Total execution time: 0.0226
INFO - 2023-02-28 05:35:36 --> Config Class Initialized
INFO - 2023-02-28 05:35:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 05:35:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 05:35:36 --> Utf8 Class Initialized
INFO - 2023-02-28 05:35:36 --> URI Class Initialized
INFO - 2023-02-28 05:35:36 --> Router Class Initialized
INFO - 2023-02-28 05:35:36 --> Output Class Initialized
INFO - 2023-02-28 05:35:36 --> Security Class Initialized
DEBUG - 2023-02-28 05:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 05:35:36 --> Input Class Initialized
INFO - 2023-02-28 05:35:36 --> Language Class Initialized
INFO - 2023-02-28 05:35:36 --> Loader Class Initialized
INFO - 2023-02-28 05:35:36 --> Controller Class Initialized
DEBUG - 2023-02-28 05:35:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 05:35:36 --> Database Driver Class Initialized
INFO - 2023-02-28 05:35:36 --> Model "Cluster_model" initialized
INFO - 2023-02-28 05:35:36 --> Final output sent to browser
DEBUG - 2023-02-28 05:35:36 --> Total execution time: 0.0212
INFO - 2023-02-28 05:36:59 --> Config Class Initialized
INFO - 2023-02-28 05:36:59 --> Hooks Class Initialized
DEBUG - 2023-02-28 05:36:59 --> UTF-8 Support Enabled
INFO - 2023-02-28 05:36:59 --> Utf8 Class Initialized
INFO - 2023-02-28 05:36:59 --> URI Class Initialized
INFO - 2023-02-28 05:36:59 --> Router Class Initialized
INFO - 2023-02-28 05:36:59 --> Output Class Initialized
INFO - 2023-02-28 05:36:59 --> Security Class Initialized
DEBUG - 2023-02-28 05:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 05:36:59 --> Input Class Initialized
INFO - 2023-02-28 05:36:59 --> Language Class Initialized
INFO - 2023-02-28 05:36:59 --> Loader Class Initialized
INFO - 2023-02-28 05:36:59 --> Controller Class Initialized
DEBUG - 2023-02-28 05:36:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 05:36:59 --> Database Driver Class Initialized
INFO - 2023-02-28 05:36:59 --> Model "Cluster_model" initialized
INFO - 2023-02-28 05:36:59 --> Final output sent to browser
DEBUG - 2023-02-28 05:36:59 --> Total execution time: 0.0447
INFO - 2023-02-28 05:36:59 --> Config Class Initialized
INFO - 2023-02-28 05:36:59 --> Hooks Class Initialized
DEBUG - 2023-02-28 05:36:59 --> UTF-8 Support Enabled
INFO - 2023-02-28 05:36:59 --> Utf8 Class Initialized
INFO - 2023-02-28 05:36:59 --> URI Class Initialized
INFO - 2023-02-28 05:36:59 --> Router Class Initialized
INFO - 2023-02-28 05:36:59 --> Output Class Initialized
INFO - 2023-02-28 05:36:59 --> Security Class Initialized
DEBUG - 2023-02-28 05:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 05:36:59 --> Input Class Initialized
INFO - 2023-02-28 05:36:59 --> Language Class Initialized
INFO - 2023-02-28 05:36:59 --> Loader Class Initialized
INFO - 2023-02-28 05:36:59 --> Controller Class Initialized
DEBUG - 2023-02-28 05:36:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 05:36:59 --> Database Driver Class Initialized
INFO - 2023-02-28 05:36:59 --> Model "Cluster_model" initialized
INFO - 2023-02-28 05:36:59 --> Final output sent to browser
DEBUG - 2023-02-28 05:36:59 --> Total execution time: 0.0433
INFO - 2023-02-28 05:37:02 --> Config Class Initialized
INFO - 2023-02-28 05:37:02 --> Hooks Class Initialized
DEBUG - 2023-02-28 05:37:02 --> UTF-8 Support Enabled
INFO - 2023-02-28 05:37:02 --> Utf8 Class Initialized
INFO - 2023-02-28 05:37:02 --> URI Class Initialized
INFO - 2023-02-28 05:37:02 --> Router Class Initialized
INFO - 2023-02-28 05:37:02 --> Output Class Initialized
INFO - 2023-02-28 05:37:02 --> Security Class Initialized
DEBUG - 2023-02-28 05:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 05:37:02 --> Input Class Initialized
INFO - 2023-02-28 05:37:02 --> Language Class Initialized
INFO - 2023-02-28 05:37:02 --> Loader Class Initialized
INFO - 2023-02-28 05:37:02 --> Controller Class Initialized
DEBUG - 2023-02-28 05:37:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 05:37:02 --> Database Driver Class Initialized
INFO - 2023-02-28 05:37:02 --> Model "Cluster_model" initialized
INFO - 2023-02-28 05:37:02 --> Final output sent to browser
DEBUG - 2023-02-28 05:37:02 --> Total execution time: 0.0161
INFO - 2023-02-28 05:37:02 --> Config Class Initialized
INFO - 2023-02-28 05:37:02 --> Hooks Class Initialized
DEBUG - 2023-02-28 05:37:02 --> UTF-8 Support Enabled
INFO - 2023-02-28 05:37:02 --> Utf8 Class Initialized
INFO - 2023-02-28 05:37:02 --> URI Class Initialized
INFO - 2023-02-28 05:37:02 --> Router Class Initialized
INFO - 2023-02-28 05:37:02 --> Output Class Initialized
INFO - 2023-02-28 05:37:02 --> Security Class Initialized
DEBUG - 2023-02-28 05:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 05:37:02 --> Input Class Initialized
INFO - 2023-02-28 05:37:02 --> Language Class Initialized
INFO - 2023-02-28 05:37:02 --> Loader Class Initialized
INFO - 2023-02-28 05:37:02 --> Controller Class Initialized
DEBUG - 2023-02-28 05:37:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 05:37:02 --> Database Driver Class Initialized
INFO - 2023-02-28 05:37:02 --> Model "Cluster_model" initialized
INFO - 2023-02-28 05:37:02 --> Final output sent to browser
DEBUG - 2023-02-28 05:37:02 --> Total execution time: 0.0125
INFO - 2023-02-28 08:06:51 --> Config Class Initialized
INFO - 2023-02-28 08:06:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:06:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:06:51 --> Utf8 Class Initialized
INFO - 2023-02-28 08:06:51 --> URI Class Initialized
INFO - 2023-02-28 08:06:51 --> Router Class Initialized
INFO - 2023-02-28 08:06:51 --> Output Class Initialized
INFO - 2023-02-28 08:06:51 --> Security Class Initialized
DEBUG - 2023-02-28 08:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:06:51 --> Input Class Initialized
INFO - 2023-02-28 08:06:51 --> Language Class Initialized
INFO - 2023-02-28 08:06:51 --> Loader Class Initialized
INFO - 2023-02-28 08:06:51 --> Controller Class Initialized
DEBUG - 2023-02-28 08:06:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:06:51 --> Database Driver Class Initialized
INFO - 2023-02-28 08:06:51 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:06:51 --> Final output sent to browser
DEBUG - 2023-02-28 08:06:51 --> Total execution time: 0.0976
INFO - 2023-02-28 08:06:51 --> Config Class Initialized
INFO - 2023-02-28 08:06:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:06:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:06:51 --> Utf8 Class Initialized
INFO - 2023-02-28 08:06:51 --> URI Class Initialized
INFO - 2023-02-28 08:06:51 --> Router Class Initialized
INFO - 2023-02-28 08:06:51 --> Output Class Initialized
INFO - 2023-02-28 08:06:51 --> Security Class Initialized
DEBUG - 2023-02-28 08:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:06:51 --> Input Class Initialized
INFO - 2023-02-28 08:06:51 --> Language Class Initialized
INFO - 2023-02-28 08:06:51 --> Loader Class Initialized
INFO - 2023-02-28 08:06:51 --> Controller Class Initialized
DEBUG - 2023-02-28 08:06:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:06:51 --> Database Driver Class Initialized
INFO - 2023-02-28 08:06:51 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:06:51 --> Final output sent to browser
DEBUG - 2023-02-28 08:06:51 --> Total execution time: 0.0932
INFO - 2023-02-28 08:13:18 --> Config Class Initialized
INFO - 2023-02-28 08:13:18 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:13:18 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:13:18 --> Utf8 Class Initialized
INFO - 2023-02-28 08:13:18 --> URI Class Initialized
INFO - 2023-02-28 08:13:18 --> Router Class Initialized
INFO - 2023-02-28 08:13:18 --> Output Class Initialized
INFO - 2023-02-28 08:13:19 --> Security Class Initialized
DEBUG - 2023-02-28 08:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:13:19 --> Input Class Initialized
INFO - 2023-02-28 08:13:19 --> Language Class Initialized
INFO - 2023-02-28 08:13:19 --> Loader Class Initialized
INFO - 2023-02-28 08:13:19 --> Controller Class Initialized
DEBUG - 2023-02-28 08:13:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:13:19 --> Database Driver Class Initialized
INFO - 2023-02-28 08:13:19 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:13:19 --> Final output sent to browser
DEBUG - 2023-02-28 08:13:19 --> Total execution time: 0.1014
INFO - 2023-02-28 08:13:19 --> Config Class Initialized
INFO - 2023-02-28 08:13:19 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:13:19 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:13:19 --> Utf8 Class Initialized
INFO - 2023-02-28 08:13:19 --> URI Class Initialized
INFO - 2023-02-28 08:13:19 --> Router Class Initialized
INFO - 2023-02-28 08:13:19 --> Output Class Initialized
INFO - 2023-02-28 08:13:19 --> Security Class Initialized
DEBUG - 2023-02-28 08:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:13:19 --> Input Class Initialized
INFO - 2023-02-28 08:13:19 --> Language Class Initialized
INFO - 2023-02-28 08:13:19 --> Loader Class Initialized
INFO - 2023-02-28 08:13:19 --> Controller Class Initialized
DEBUG - 2023-02-28 08:13:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:13:19 --> Database Driver Class Initialized
INFO - 2023-02-28 08:13:19 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:13:19 --> Final output sent to browser
DEBUG - 2023-02-28 08:13:19 --> Total execution time: 0.0131
INFO - 2023-02-28 08:31:49 --> Config Class Initialized
INFO - 2023-02-28 08:31:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:49 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:49 --> URI Class Initialized
INFO - 2023-02-28 08:31:49 --> Router Class Initialized
INFO - 2023-02-28 08:31:49 --> Output Class Initialized
INFO - 2023-02-28 08:31:49 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:49 --> Input Class Initialized
INFO - 2023-02-28 08:31:49 --> Language Class Initialized
INFO - 2023-02-28 08:31:49 --> Loader Class Initialized
INFO - 2023-02-28 08:31:49 --> Controller Class Initialized
INFO - 2023-02-28 08:31:49 --> Helper loaded: form_helper
INFO - 2023-02-28 08:31:49 --> Helper loaded: url_helper
DEBUG - 2023-02-28 08:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:49 --> Model "Change_model" initialized
INFO - 2023-02-28 08:31:49 --> Model "Grafana_model" initialized
INFO - 2023-02-28 08:31:49 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:49 --> Total execution time: 0.0259
INFO - 2023-02-28 08:31:49 --> Config Class Initialized
INFO - 2023-02-28 08:31:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:49 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:49 --> URI Class Initialized
INFO - 2023-02-28 08:31:49 --> Router Class Initialized
INFO - 2023-02-28 08:31:49 --> Output Class Initialized
INFO - 2023-02-28 08:31:49 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:49 --> Input Class Initialized
INFO - 2023-02-28 08:31:49 --> Language Class Initialized
INFO - 2023-02-28 08:31:49 --> Loader Class Initialized
INFO - 2023-02-28 08:31:49 --> Controller Class Initialized
INFO - 2023-02-28 08:31:49 --> Helper loaded: form_helper
INFO - 2023-02-28 08:31:49 --> Helper loaded: url_helper
DEBUG - 2023-02-28 08:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:49 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:49 --> Total execution time: 0.0025
INFO - 2023-02-28 08:31:49 --> Config Class Initialized
INFO - 2023-02-28 08:31:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:49 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:49 --> URI Class Initialized
INFO - 2023-02-28 08:31:49 --> Router Class Initialized
INFO - 2023-02-28 08:31:49 --> Output Class Initialized
INFO - 2023-02-28 08:31:49 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:49 --> Input Class Initialized
INFO - 2023-02-28 08:31:49 --> Language Class Initialized
INFO - 2023-02-28 08:31:49 --> Loader Class Initialized
INFO - 2023-02-28 08:31:49 --> Controller Class Initialized
INFO - 2023-02-28 08:31:49 --> Helper loaded: form_helper
INFO - 2023-02-28 08:31:49 --> Helper loaded: url_helper
DEBUG - 2023-02-28 08:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:49 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:49 --> Model "Login_model" initialized
INFO - 2023-02-28 08:31:49 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:49 --> Total execution time: 0.0672
INFO - 2023-02-28 08:31:49 --> Config Class Initialized
INFO - 2023-02-28 08:31:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:49 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:49 --> URI Class Initialized
INFO - 2023-02-28 08:31:49 --> Router Class Initialized
INFO - 2023-02-28 08:31:49 --> Output Class Initialized
INFO - 2023-02-28 08:31:49 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:49 --> Input Class Initialized
INFO - 2023-02-28 08:31:49 --> Language Class Initialized
INFO - 2023-02-28 08:31:49 --> Loader Class Initialized
INFO - 2023-02-28 08:31:49 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:49 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:49 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:31:49 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:49 --> Total execution time: 0.0152
INFO - 2023-02-28 08:31:49 --> Config Class Initialized
INFO - 2023-02-28 08:31:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:49 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:49 --> URI Class Initialized
INFO - 2023-02-28 08:31:49 --> Router Class Initialized
INFO - 2023-02-28 08:31:49 --> Output Class Initialized
INFO - 2023-02-28 08:31:49 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:49 --> Input Class Initialized
INFO - 2023-02-28 08:31:49 --> Language Class Initialized
INFO - 2023-02-28 08:31:49 --> Loader Class Initialized
INFO - 2023-02-28 08:31:49 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:49 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:49 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:31:49 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:49 --> Total execution time: 0.0139
INFO - 2023-02-28 08:31:49 --> Config Class Initialized
INFO - 2023-02-28 08:31:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:49 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:49 --> URI Class Initialized
INFO - 2023-02-28 08:31:49 --> Router Class Initialized
INFO - 2023-02-28 08:31:49 --> Output Class Initialized
INFO - 2023-02-28 08:31:49 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:49 --> Input Class Initialized
INFO - 2023-02-28 08:31:49 --> Language Class Initialized
INFO - 2023-02-28 08:31:49 --> Loader Class Initialized
INFO - 2023-02-28 08:31:49 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:49 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:49 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:31:49 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:49 --> Model "Login_model" initialized
INFO - 2023-02-28 08:31:49 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:49 --> Total execution time: 0.0405
INFO - 2023-02-28 08:31:49 --> Config Class Initialized
INFO - 2023-02-28 08:31:49 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:49 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:49 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:49 --> URI Class Initialized
INFO - 2023-02-28 08:31:49 --> Router Class Initialized
INFO - 2023-02-28 08:31:49 --> Output Class Initialized
INFO - 2023-02-28 08:31:49 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:49 --> Input Class Initialized
INFO - 2023-02-28 08:31:49 --> Language Class Initialized
INFO - 2023-02-28 08:31:49 --> Loader Class Initialized
INFO - 2023-02-28 08:31:49 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:49 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:49 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:31:49 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:49 --> Model "Login_model" initialized
INFO - 2023-02-28 08:31:49 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:49 --> Total execution time: 0.0772
INFO - 2023-02-28 08:31:51 --> Config Class Initialized
INFO - 2023-02-28 08:31:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:51 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:51 --> URI Class Initialized
INFO - 2023-02-28 08:31:51 --> Router Class Initialized
INFO - 2023-02-28 08:31:51 --> Output Class Initialized
INFO - 2023-02-28 08:31:51 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:51 --> Input Class Initialized
INFO - 2023-02-28 08:31:51 --> Language Class Initialized
INFO - 2023-02-28 08:31:51 --> Loader Class Initialized
INFO - 2023-02-28 08:31:51 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:51 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:51 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:31:51 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:51 --> Total execution time: 0.0482
INFO - 2023-02-28 08:31:51 --> Config Class Initialized
INFO - 2023-02-28 08:31:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:51 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:51 --> URI Class Initialized
INFO - 2023-02-28 08:31:51 --> Router Class Initialized
INFO - 2023-02-28 08:31:51 --> Output Class Initialized
INFO - 2023-02-28 08:31:51 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:51 --> Input Class Initialized
INFO - 2023-02-28 08:31:51 --> Language Class Initialized
INFO - 2023-02-28 08:31:51 --> Loader Class Initialized
INFO - 2023-02-28 08:31:51 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:51 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:51 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:31:51 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:51 --> Total execution time: 0.0374
INFO - 2023-02-28 08:31:53 --> Config Class Initialized
INFO - 2023-02-28 08:31:53 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:53 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:53 --> URI Class Initialized
INFO - 2023-02-28 08:31:53 --> Router Class Initialized
INFO - 2023-02-28 08:31:53 --> Output Class Initialized
INFO - 2023-02-28 08:31:53 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:53 --> Input Class Initialized
INFO - 2023-02-28 08:31:53 --> Language Class Initialized
INFO - 2023-02-28 08:31:53 --> Loader Class Initialized
INFO - 2023-02-28 08:31:53 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:53 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:53 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:31:53 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:53 --> Total execution time: 0.0163
INFO - 2023-02-28 08:31:53 --> Config Class Initialized
INFO - 2023-02-28 08:31:53 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:53 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:53 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:53 --> URI Class Initialized
INFO - 2023-02-28 08:31:53 --> Router Class Initialized
INFO - 2023-02-28 08:31:53 --> Output Class Initialized
INFO - 2023-02-28 08:31:53 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:53 --> Input Class Initialized
INFO - 2023-02-28 08:31:53 --> Language Class Initialized
INFO - 2023-02-28 08:31:53 --> Loader Class Initialized
INFO - 2023-02-28 08:31:53 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:53 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:53 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:31:53 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:53 --> Total execution time: 0.0114
INFO - 2023-02-28 08:31:55 --> Config Class Initialized
INFO - 2023-02-28 08:31:55 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:55 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:55 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:55 --> URI Class Initialized
INFO - 2023-02-28 08:31:55 --> Router Class Initialized
INFO - 2023-02-28 08:31:55 --> Output Class Initialized
INFO - 2023-02-28 08:31:55 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:55 --> Input Class Initialized
INFO - 2023-02-28 08:31:55 --> Language Class Initialized
INFO - 2023-02-28 08:31:55 --> Loader Class Initialized
INFO - 2023-02-28 08:31:55 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:55 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:55 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:31:55 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:55 --> Total execution time: 0.0454
INFO - 2023-02-28 08:31:56 --> Config Class Initialized
INFO - 2023-02-28 08:31:56 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:56 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:56 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:56 --> URI Class Initialized
INFO - 2023-02-28 08:31:56 --> Router Class Initialized
INFO - 2023-02-28 08:31:56 --> Output Class Initialized
INFO - 2023-02-28 08:31:56 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:56 --> Input Class Initialized
INFO - 2023-02-28 08:31:56 --> Language Class Initialized
INFO - 2023-02-28 08:31:56 --> Loader Class Initialized
INFO - 2023-02-28 08:31:56 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:56 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:56 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:31:56 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:56 --> Model "Login_model" initialized
INFO - 2023-02-28 08:31:56 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:56 --> Total execution time: 0.0411
INFO - 2023-02-28 08:31:56 --> Config Class Initialized
INFO - 2023-02-28 08:31:56 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:56 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:56 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:56 --> URI Class Initialized
INFO - 2023-02-28 08:31:56 --> Router Class Initialized
INFO - 2023-02-28 08:31:56 --> Output Class Initialized
INFO - 2023-02-28 08:31:56 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:56 --> Input Class Initialized
INFO - 2023-02-28 08:31:56 --> Language Class Initialized
INFO - 2023-02-28 08:31:56 --> Loader Class Initialized
INFO - 2023-02-28 08:31:56 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:56 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:56 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:31:56 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:56 --> Model "Login_model" initialized
INFO - 2023-02-28 08:31:56 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:56 --> Total execution time: 0.0378
INFO - 2023-02-28 08:31:58 --> Config Class Initialized
INFO - 2023-02-28 08:31:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:58 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:58 --> URI Class Initialized
INFO - 2023-02-28 08:31:58 --> Router Class Initialized
INFO - 2023-02-28 08:31:58 --> Output Class Initialized
INFO - 2023-02-28 08:31:58 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:58 --> Input Class Initialized
INFO - 2023-02-28 08:31:58 --> Language Class Initialized
INFO - 2023-02-28 08:31:58 --> Loader Class Initialized
INFO - 2023-02-28 08:31:58 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:58 --> Final output sent to browser
DEBUG - 2023-02-28 08:31:58 --> Total execution time: 0.0018
INFO - 2023-02-28 08:31:58 --> Config Class Initialized
INFO - 2023-02-28 08:31:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:58 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:58 --> URI Class Initialized
INFO - 2023-02-28 08:31:58 --> Router Class Initialized
INFO - 2023-02-28 08:31:58 --> Output Class Initialized
INFO - 2023-02-28 08:31:58 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:58 --> Input Class Initialized
INFO - 2023-02-28 08:31:58 --> Language Class Initialized
INFO - 2023-02-28 08:31:58 --> Loader Class Initialized
INFO - 2023-02-28 08:31:58 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:58 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:58 --> Model "Login_model" initialized
INFO - 2023-02-28 08:31:58 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:58 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 08:31:58 --> Query error:  - Invalid query: 
INFO - 2023-02-28 08:31:58 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 08:31:58 --> Config Class Initialized
INFO - 2023-02-28 08:31:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:58 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:58 --> URI Class Initialized
INFO - 2023-02-28 08:31:58 --> Router Class Initialized
INFO - 2023-02-28 08:31:58 --> Output Class Initialized
INFO - 2023-02-28 08:31:58 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:58 --> Input Class Initialized
INFO - 2023-02-28 08:31:58 --> Language Class Initialized
INFO - 2023-02-28 08:31:58 --> Loader Class Initialized
INFO - 2023-02-28 08:31:58 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:58 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:58 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 08:31:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by id desc limit  offset 0' at line 1 - Invalid query:  order by id desc limit  offset 0
INFO - 2023-02-28 08:31:58 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 08:31:59 --> Config Class Initialized
INFO - 2023-02-28 08:31:59 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:31:59 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:31:59 --> Utf8 Class Initialized
INFO - 2023-02-28 08:31:59 --> URI Class Initialized
INFO - 2023-02-28 08:31:59 --> Router Class Initialized
INFO - 2023-02-28 08:31:59 --> Output Class Initialized
INFO - 2023-02-28 08:31:59 --> Security Class Initialized
DEBUG - 2023-02-28 08:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:31:59 --> Input Class Initialized
INFO - 2023-02-28 08:31:59 --> Language Class Initialized
INFO - 2023-02-28 08:31:59 --> Loader Class Initialized
INFO - 2023-02-28 08:31:59 --> Controller Class Initialized
DEBUG - 2023-02-28 08:31:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:31:59 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:59 --> Model "Login_model" initialized
INFO - 2023-02-28 08:31:59 --> Database Driver Class Initialized
INFO - 2023-02-28 08:31:59 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 08:31:59 --> Query error:  - Invalid query: 
INFO - 2023-02-28 08:31:59 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 08:32:00 --> Config Class Initialized
INFO - 2023-02-28 08:32:00 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:32:00 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:32:00 --> Utf8 Class Initialized
INFO - 2023-02-28 08:32:00 --> URI Class Initialized
INFO - 2023-02-28 08:32:00 --> Router Class Initialized
INFO - 2023-02-28 08:32:00 --> Output Class Initialized
INFO - 2023-02-28 08:32:00 --> Security Class Initialized
DEBUG - 2023-02-28 08:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:32:00 --> Input Class Initialized
INFO - 2023-02-28 08:32:00 --> Language Class Initialized
INFO - 2023-02-28 08:32:00 --> Loader Class Initialized
INFO - 2023-02-28 08:32:00 --> Controller Class Initialized
DEBUG - 2023-02-28 08:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:32:00 --> Database Driver Class Initialized
INFO - 2023-02-28 08:32:00 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:32:00 --> Database Driver Class Initialized
INFO - 2023-02-28 08:32:00 --> Model "Login_model" initialized
INFO - 2023-02-28 08:32:00 --> Final output sent to browser
DEBUG - 2023-02-28 08:32:00 --> Total execution time: 0.0404
INFO - 2023-02-28 08:32:14 --> Config Class Initialized
INFO - 2023-02-28 08:32:14 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:32:14 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:32:14 --> Utf8 Class Initialized
INFO - 2023-02-28 08:32:14 --> URI Class Initialized
INFO - 2023-02-28 08:32:14 --> Router Class Initialized
INFO - 2023-02-28 08:32:14 --> Output Class Initialized
INFO - 2023-02-28 08:32:14 --> Security Class Initialized
DEBUG - 2023-02-28 08:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:32:14 --> Input Class Initialized
INFO - 2023-02-28 08:32:14 --> Language Class Initialized
INFO - 2023-02-28 08:32:14 --> Loader Class Initialized
INFO - 2023-02-28 08:32:14 --> Controller Class Initialized
DEBUG - 2023-02-28 08:32:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:32:14 --> Database Driver Class Initialized
INFO - 2023-02-28 08:32:14 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:32:14 --> Database Driver Class Initialized
INFO - 2023-02-28 08:32:14 --> Model "Login_model" initialized
INFO - 2023-02-28 08:32:14 --> Final output sent to browser
DEBUG - 2023-02-28 08:32:14 --> Total execution time: 0.1920
INFO - 2023-02-28 08:32:14 --> Config Class Initialized
INFO - 2023-02-28 08:32:14 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:32:14 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:32:14 --> Utf8 Class Initialized
INFO - 2023-02-28 08:32:14 --> URI Class Initialized
INFO - 2023-02-28 08:32:14 --> Router Class Initialized
INFO - 2023-02-28 08:32:14 --> Output Class Initialized
INFO - 2023-02-28 08:32:14 --> Security Class Initialized
DEBUG - 2023-02-28 08:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:32:14 --> Input Class Initialized
INFO - 2023-02-28 08:32:14 --> Language Class Initialized
INFO - 2023-02-28 08:32:14 --> Loader Class Initialized
INFO - 2023-02-28 08:32:14 --> Controller Class Initialized
DEBUG - 2023-02-28 08:32:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:32:14 --> Database Driver Class Initialized
INFO - 2023-02-28 08:32:14 --> Model "Cluster_model" initialized
INFO - 2023-02-28 08:32:14 --> Database Driver Class Initialized
INFO - 2023-02-28 08:32:14 --> Model "Login_model" initialized
INFO - 2023-02-28 08:32:14 --> Final output sent to browser
DEBUG - 2023-02-28 08:32:14 --> Total execution time: 0.0436
INFO - 2023-02-28 08:32:17 --> Config Class Initialized
INFO - 2023-02-28 08:32:17 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:32:17 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:32:17 --> Utf8 Class Initialized
INFO - 2023-02-28 08:32:17 --> URI Class Initialized
INFO - 2023-02-28 08:32:17 --> Router Class Initialized
INFO - 2023-02-28 08:32:17 --> Output Class Initialized
INFO - 2023-02-28 08:32:17 --> Security Class Initialized
DEBUG - 2023-02-28 08:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:32:17 --> Input Class Initialized
INFO - 2023-02-28 08:32:17 --> Language Class Initialized
INFO - 2023-02-28 08:32:17 --> Loader Class Initialized
INFO - 2023-02-28 08:32:17 --> Controller Class Initialized
INFO - 2023-02-28 08:32:17 --> Helper loaded: form_helper
INFO - 2023-02-28 08:32:17 --> Helper loaded: url_helper
DEBUG - 2023-02-28 08:32:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:32:17 --> Model "Change_model" initialized
INFO - 2023-02-28 08:32:17 --> Model "Grafana_model" initialized
INFO - 2023-02-28 08:32:17 --> Final output sent to browser
DEBUG - 2023-02-28 08:32:17 --> Total execution time: 0.0291
INFO - 2023-02-28 08:32:17 --> Config Class Initialized
INFO - 2023-02-28 08:32:17 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:32:17 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:32:17 --> Utf8 Class Initialized
INFO - 2023-02-28 08:32:17 --> URI Class Initialized
INFO - 2023-02-28 08:32:17 --> Router Class Initialized
INFO - 2023-02-28 08:32:17 --> Output Class Initialized
INFO - 2023-02-28 08:32:17 --> Security Class Initialized
DEBUG - 2023-02-28 08:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:32:17 --> Input Class Initialized
INFO - 2023-02-28 08:32:17 --> Language Class Initialized
INFO - 2023-02-28 08:32:17 --> Loader Class Initialized
INFO - 2023-02-28 08:32:17 --> Controller Class Initialized
INFO - 2023-02-28 08:32:17 --> Helper loaded: form_helper
INFO - 2023-02-28 08:32:17 --> Helper loaded: url_helper
DEBUG - 2023-02-28 08:32:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:32:17 --> Final output sent to browser
DEBUG - 2023-02-28 08:32:17 --> Total execution time: 0.0028
INFO - 2023-02-28 08:32:17 --> Config Class Initialized
INFO - 2023-02-28 08:32:17 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:32:17 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:32:17 --> Utf8 Class Initialized
INFO - 2023-02-28 08:32:17 --> URI Class Initialized
INFO - 2023-02-28 08:32:17 --> Router Class Initialized
INFO - 2023-02-28 08:32:17 --> Output Class Initialized
INFO - 2023-02-28 08:32:17 --> Security Class Initialized
DEBUG - 2023-02-28 08:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:32:17 --> Input Class Initialized
INFO - 2023-02-28 08:32:17 --> Language Class Initialized
INFO - 2023-02-28 08:32:17 --> Loader Class Initialized
INFO - 2023-02-28 08:32:17 --> Controller Class Initialized
INFO - 2023-02-28 08:32:17 --> Helper loaded: form_helper
INFO - 2023-02-28 08:32:17 --> Helper loaded: url_helper
DEBUG - 2023-02-28 08:32:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:32:17 --> Database Driver Class Initialized
INFO - 2023-02-28 08:32:18 --> Model "Login_model" initialized
INFO - 2023-02-28 08:32:18 --> Final output sent to browser
DEBUG - 2023-02-28 08:32:18 --> Total execution time: 0.0145
INFO - 2023-02-28 08:38:13 --> Config Class Initialized
INFO - 2023-02-28 08:38:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:38:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:38:13 --> Utf8 Class Initialized
INFO - 2023-02-28 08:38:13 --> URI Class Initialized
INFO - 2023-02-28 08:38:13 --> Router Class Initialized
INFO - 2023-02-28 08:38:13 --> Output Class Initialized
INFO - 2023-02-28 08:38:13 --> Security Class Initialized
DEBUG - 2023-02-28 08:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:38:13 --> Input Class Initialized
INFO - 2023-02-28 08:38:13 --> Language Class Initialized
INFO - 2023-02-28 08:38:13 --> Loader Class Initialized
INFO - 2023-02-28 08:38:13 --> Controller Class Initialized
INFO - 2023-02-28 08:38:13 --> Helper loaded: form_helper
INFO - 2023-02-28 08:38:13 --> Helper loaded: url_helper
DEBUG - 2023-02-28 08:38:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:38:13 --> Model "Change_model" initialized
INFO - 2023-02-28 08:38:13 --> Model "Grafana_model" initialized
INFO - 2023-02-28 08:38:13 --> Final output sent to browser
DEBUG - 2023-02-28 08:38:13 --> Total execution time: 0.0637
INFO - 2023-02-28 08:38:13 --> Config Class Initialized
INFO - 2023-02-28 08:38:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:38:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:38:13 --> Utf8 Class Initialized
INFO - 2023-02-28 08:38:13 --> URI Class Initialized
INFO - 2023-02-28 08:38:13 --> Router Class Initialized
INFO - 2023-02-28 08:38:13 --> Output Class Initialized
INFO - 2023-02-28 08:38:13 --> Security Class Initialized
DEBUG - 2023-02-28 08:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:38:13 --> Input Class Initialized
INFO - 2023-02-28 08:38:13 --> Language Class Initialized
INFO - 2023-02-28 08:38:13 --> Loader Class Initialized
INFO - 2023-02-28 08:38:13 --> Controller Class Initialized
INFO - 2023-02-28 08:38:13 --> Helper loaded: form_helper
INFO - 2023-02-28 08:38:13 --> Helper loaded: url_helper
DEBUG - 2023-02-28 08:38:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:38:13 --> Final output sent to browser
DEBUG - 2023-02-28 08:38:13 --> Total execution time: 0.0025
INFO - 2023-02-28 08:38:13 --> Config Class Initialized
INFO - 2023-02-28 08:38:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 08:38:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 08:38:13 --> Utf8 Class Initialized
INFO - 2023-02-28 08:38:13 --> URI Class Initialized
INFO - 2023-02-28 08:38:13 --> Router Class Initialized
INFO - 2023-02-28 08:38:13 --> Output Class Initialized
INFO - 2023-02-28 08:38:13 --> Security Class Initialized
DEBUG - 2023-02-28 08:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 08:38:13 --> Input Class Initialized
INFO - 2023-02-28 08:38:13 --> Language Class Initialized
INFO - 2023-02-28 08:38:13 --> Loader Class Initialized
INFO - 2023-02-28 08:38:13 --> Controller Class Initialized
INFO - 2023-02-28 08:38:13 --> Helper loaded: form_helper
INFO - 2023-02-28 08:38:13 --> Helper loaded: url_helper
DEBUG - 2023-02-28 08:38:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 08:38:13 --> Database Driver Class Initialized
INFO - 2023-02-28 08:38:13 --> Model "Login_model" initialized
INFO - 2023-02-28 08:38:13 --> Final output sent to browser
DEBUG - 2023-02-28 08:38:13 --> Total execution time: 0.0120
INFO - 2023-02-28 09:29:30 --> Config Class Initialized
INFO - 2023-02-28 09:29:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:29:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:29:30 --> Utf8 Class Initialized
INFO - 2023-02-28 09:29:30 --> URI Class Initialized
INFO - 2023-02-28 09:29:30 --> Router Class Initialized
INFO - 2023-02-28 09:29:30 --> Output Class Initialized
INFO - 2023-02-28 09:29:30 --> Security Class Initialized
DEBUG - 2023-02-28 09:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:29:30 --> Input Class Initialized
INFO - 2023-02-28 09:29:30 --> Language Class Initialized
ERROR - 2023-02-28 09:29:30 --> 404 Page Not Found: user/User/getVcode
INFO - 2023-02-28 09:30:43 --> Config Class Initialized
INFO - 2023-02-28 09:30:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:30:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:30:43 --> Utf8 Class Initialized
INFO - 2023-02-28 09:30:43 --> URI Class Initialized
INFO - 2023-02-28 09:30:43 --> Router Class Initialized
INFO - 2023-02-28 09:30:43 --> Output Class Initialized
INFO - 2023-02-28 09:30:43 --> Security Class Initialized
DEBUG - 2023-02-28 09:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:30:43 --> Input Class Initialized
INFO - 2023-02-28 09:30:43 --> Language Class Initialized
INFO - 2023-02-28 09:30:43 --> Loader Class Initialized
INFO - 2023-02-28 09:30:43 --> Controller Class Initialized
DEBUG - 2023-02-28 09:30:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:30:43 --> Database Driver Class Initialized
INFO - 2023-02-28 09:30:43 --> Final output sent to browser
DEBUG - 2023-02-28 09:30:43 --> Total execution time: 0.0149
INFO - 2023-02-28 09:30:43 --> Config Class Initialized
INFO - 2023-02-28 09:30:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:30:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:30:43 --> Utf8 Class Initialized
INFO - 2023-02-28 09:30:43 --> URI Class Initialized
INFO - 2023-02-28 09:30:43 --> Router Class Initialized
INFO - 2023-02-28 09:30:43 --> Output Class Initialized
INFO - 2023-02-28 09:30:43 --> Security Class Initialized
DEBUG - 2023-02-28 09:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:30:43 --> Input Class Initialized
INFO - 2023-02-28 09:30:43 --> Language Class Initialized
INFO - 2023-02-28 09:30:43 --> Loader Class Initialized
INFO - 2023-02-28 09:30:43 --> Controller Class Initialized
DEBUG - 2023-02-28 09:30:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:30:43 --> Database Driver Class Initialized
INFO - 2023-02-28 09:30:43 --> Final output sent to browser
DEBUG - 2023-02-28 09:30:43 --> Total execution time: 0.0083
INFO - 2023-02-28 09:43:12 --> Config Class Initialized
INFO - 2023-02-28 09:43:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:43:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:43:12 --> Utf8 Class Initialized
INFO - 2023-02-28 09:43:12 --> URI Class Initialized
INFO - 2023-02-28 09:43:12 --> Router Class Initialized
INFO - 2023-02-28 09:43:12 --> Output Class Initialized
INFO - 2023-02-28 09:43:12 --> Security Class Initialized
DEBUG - 2023-02-28 09:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:43:12 --> Input Class Initialized
INFO - 2023-02-28 09:43:12 --> Language Class Initialized
INFO - 2023-02-28 09:43:12 --> Loader Class Initialized
INFO - 2023-02-28 09:43:12 --> Controller Class Initialized
INFO - 2023-02-28 09:43:12 --> Helper loaded: form_helper
INFO - 2023-02-28 09:43:12 --> Helper loaded: url_helper
DEBUG - 2023-02-28 09:43:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:43:12 --> Model "Change_model" initialized
INFO - 2023-02-28 09:43:12 --> Model "Grafana_model" initialized
INFO - 2023-02-28 09:43:12 --> Final output sent to browser
DEBUG - 2023-02-28 09:43:12 --> Total execution time: 0.0339
INFO - 2023-02-28 09:43:12 --> Config Class Initialized
INFO - 2023-02-28 09:43:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:43:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:43:12 --> Utf8 Class Initialized
INFO - 2023-02-28 09:43:12 --> URI Class Initialized
INFO - 2023-02-28 09:43:12 --> Router Class Initialized
INFO - 2023-02-28 09:43:12 --> Output Class Initialized
INFO - 2023-02-28 09:43:12 --> Security Class Initialized
DEBUG - 2023-02-28 09:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:43:12 --> Input Class Initialized
INFO - 2023-02-28 09:43:12 --> Language Class Initialized
INFO - 2023-02-28 09:43:12 --> Loader Class Initialized
INFO - 2023-02-28 09:43:12 --> Controller Class Initialized
INFO - 2023-02-28 09:43:12 --> Helper loaded: form_helper
INFO - 2023-02-28 09:43:12 --> Helper loaded: url_helper
DEBUG - 2023-02-28 09:43:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:43:12 --> Final output sent to browser
DEBUG - 2023-02-28 09:43:12 --> Total execution time: 0.0027
INFO - 2023-02-28 09:43:12 --> Config Class Initialized
INFO - 2023-02-28 09:43:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:43:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:43:12 --> Utf8 Class Initialized
INFO - 2023-02-28 09:43:12 --> URI Class Initialized
INFO - 2023-02-28 09:43:12 --> Router Class Initialized
INFO - 2023-02-28 09:43:12 --> Output Class Initialized
INFO - 2023-02-28 09:43:12 --> Security Class Initialized
DEBUG - 2023-02-28 09:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:43:12 --> Input Class Initialized
INFO - 2023-02-28 09:43:12 --> Language Class Initialized
INFO - 2023-02-28 09:43:12 --> Loader Class Initialized
INFO - 2023-02-28 09:43:12 --> Controller Class Initialized
INFO - 2023-02-28 09:43:12 --> Helper loaded: form_helper
INFO - 2023-02-28 09:43:12 --> Helper loaded: url_helper
DEBUG - 2023-02-28 09:43:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:43:12 --> Database Driver Class Initialized
INFO - 2023-02-28 09:43:12 --> Model "Login_model" initialized
INFO - 2023-02-28 09:43:12 --> Final output sent to browser
DEBUG - 2023-02-28 09:43:12 --> Total execution time: 0.0155
INFO - 2023-02-28 09:43:17 --> Config Class Initialized
INFO - 2023-02-28 09:43:17 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:43:17 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:43:17 --> Utf8 Class Initialized
INFO - 2023-02-28 09:43:17 --> URI Class Initialized
INFO - 2023-02-28 09:43:17 --> Router Class Initialized
INFO - 2023-02-28 09:43:17 --> Output Class Initialized
INFO - 2023-02-28 09:43:17 --> Security Class Initialized
DEBUG - 2023-02-28 09:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:43:17 --> Input Class Initialized
INFO - 2023-02-28 09:43:17 --> Language Class Initialized
INFO - 2023-02-28 09:43:17 --> Loader Class Initialized
INFO - 2023-02-28 09:43:17 --> Controller Class Initialized
INFO - 2023-02-28 09:43:17 --> Helper loaded: form_helper
INFO - 2023-02-28 09:43:17 --> Helper loaded: url_helper
DEBUG - 2023-02-28 09:43:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:43:17 --> Model "Change_model" initialized
INFO - 2023-02-28 09:43:17 --> Model "Grafana_model" initialized
INFO - 2023-02-28 09:43:17 --> Final output sent to browser
DEBUG - 2023-02-28 09:43:17 --> Total execution time: 0.0343
INFO - 2023-02-28 09:43:17 --> Config Class Initialized
INFO - 2023-02-28 09:43:17 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:43:17 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:43:17 --> Utf8 Class Initialized
INFO - 2023-02-28 09:43:17 --> URI Class Initialized
INFO - 2023-02-28 09:43:17 --> Router Class Initialized
INFO - 2023-02-28 09:43:17 --> Output Class Initialized
INFO - 2023-02-28 09:43:17 --> Security Class Initialized
DEBUG - 2023-02-28 09:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:43:17 --> Input Class Initialized
INFO - 2023-02-28 09:43:17 --> Language Class Initialized
INFO - 2023-02-28 09:43:17 --> Loader Class Initialized
INFO - 2023-02-28 09:43:17 --> Controller Class Initialized
INFO - 2023-02-28 09:43:17 --> Helper loaded: form_helper
INFO - 2023-02-28 09:43:17 --> Helper loaded: url_helper
DEBUG - 2023-02-28 09:43:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:43:17 --> Database Driver Class Initialized
INFO - 2023-02-28 09:43:17 --> Model "Login_model" initialized
INFO - 2023-02-28 09:43:17 --> Final output sent to browser
DEBUG - 2023-02-28 09:43:17 --> Total execution time: 0.0639
INFO - 2023-02-28 09:45:12 --> Config Class Initialized
INFO - 2023-02-28 09:45:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:12 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:12 --> URI Class Initialized
INFO - 2023-02-28 09:45:12 --> Router Class Initialized
INFO - 2023-02-28 09:45:12 --> Output Class Initialized
INFO - 2023-02-28 09:45:12 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:12 --> Input Class Initialized
INFO - 2023-02-28 09:45:12 --> Language Class Initialized
INFO - 2023-02-28 09:45:12 --> Loader Class Initialized
INFO - 2023-02-28 09:45:12 --> Controller Class Initialized
INFO - 2023-02-28 09:45:12 --> Helper loaded: form_helper
INFO - 2023-02-28 09:45:12 --> Helper loaded: url_helper
DEBUG - 2023-02-28 09:45:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:12 --> Model "Change_model" initialized
INFO - 2023-02-28 09:45:12 --> Model "Grafana_model" initialized
INFO - 2023-02-28 09:45:12 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:12 --> Total execution time: 0.0252
INFO - 2023-02-28 09:45:12 --> Config Class Initialized
INFO - 2023-02-28 09:45:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:12 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:12 --> URI Class Initialized
INFO - 2023-02-28 09:45:12 --> Router Class Initialized
INFO - 2023-02-28 09:45:12 --> Output Class Initialized
INFO - 2023-02-28 09:45:12 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:12 --> Input Class Initialized
INFO - 2023-02-28 09:45:12 --> Language Class Initialized
INFO - 2023-02-28 09:45:12 --> Loader Class Initialized
INFO - 2023-02-28 09:45:12 --> Controller Class Initialized
INFO - 2023-02-28 09:45:12 --> Helper loaded: form_helper
INFO - 2023-02-28 09:45:12 --> Helper loaded: url_helper
DEBUG - 2023-02-28 09:45:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:12 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:12 --> Total execution time: 0.0439
INFO - 2023-02-28 09:45:12 --> Config Class Initialized
INFO - 2023-02-28 09:45:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:12 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:12 --> URI Class Initialized
INFO - 2023-02-28 09:45:12 --> Router Class Initialized
INFO - 2023-02-28 09:45:12 --> Output Class Initialized
INFO - 2023-02-28 09:45:12 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:12 --> Input Class Initialized
INFO - 2023-02-28 09:45:12 --> Language Class Initialized
INFO - 2023-02-28 09:45:12 --> Loader Class Initialized
INFO - 2023-02-28 09:45:12 --> Controller Class Initialized
INFO - 2023-02-28 09:45:12 --> Helper loaded: form_helper
INFO - 2023-02-28 09:45:12 --> Helper loaded: url_helper
DEBUG - 2023-02-28 09:45:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:12 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:12 --> Model "Login_model" initialized
INFO - 2023-02-28 09:45:12 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:12 --> Total execution time: 0.0165
INFO - 2023-02-28 09:45:35 --> Config Class Initialized
INFO - 2023-02-28 09:45:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:35 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:35 --> URI Class Initialized
INFO - 2023-02-28 09:45:35 --> Router Class Initialized
INFO - 2023-02-28 09:45:35 --> Output Class Initialized
INFO - 2023-02-28 09:45:35 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:35 --> Input Class Initialized
INFO - 2023-02-28 09:45:35 --> Language Class Initialized
INFO - 2023-02-28 09:45:35 --> Loader Class Initialized
INFO - 2023-02-28 09:45:35 --> Controller Class Initialized
INFO - 2023-02-28 09:45:35 --> Helper loaded: form_helper
INFO - 2023-02-28 09:45:35 --> Helper loaded: url_helper
DEBUG - 2023-02-28 09:45:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:35 --> Model "Change_model" initialized
INFO - 2023-02-28 09:45:35 --> Model "Grafana_model" initialized
INFO - 2023-02-28 09:45:35 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:35 --> Total execution time: 0.0201
INFO - 2023-02-28 09:45:35 --> Config Class Initialized
INFO - 2023-02-28 09:45:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:35 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:35 --> URI Class Initialized
INFO - 2023-02-28 09:45:35 --> Router Class Initialized
INFO - 2023-02-28 09:45:35 --> Output Class Initialized
INFO - 2023-02-28 09:45:35 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:35 --> Input Class Initialized
INFO - 2023-02-28 09:45:35 --> Language Class Initialized
INFO - 2023-02-28 09:45:35 --> Loader Class Initialized
INFO - 2023-02-28 09:45:35 --> Controller Class Initialized
INFO - 2023-02-28 09:45:35 --> Helper loaded: form_helper
INFO - 2023-02-28 09:45:35 --> Helper loaded: url_helper
DEBUG - 2023-02-28 09:45:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:35 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:35 --> Total execution time: 0.0020
INFO - 2023-02-28 09:45:35 --> Config Class Initialized
INFO - 2023-02-28 09:45:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:35 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:35 --> URI Class Initialized
INFO - 2023-02-28 09:45:35 --> Router Class Initialized
INFO - 2023-02-28 09:45:35 --> Output Class Initialized
INFO - 2023-02-28 09:45:35 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:35 --> Input Class Initialized
INFO - 2023-02-28 09:45:35 --> Language Class Initialized
INFO - 2023-02-28 09:45:35 --> Loader Class Initialized
INFO - 2023-02-28 09:45:35 --> Controller Class Initialized
INFO - 2023-02-28 09:45:35 --> Helper loaded: form_helper
INFO - 2023-02-28 09:45:35 --> Helper loaded: url_helper
DEBUG - 2023-02-28 09:45:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:35 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:35 --> Model "Login_model" initialized
INFO - 2023-02-28 09:45:35 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:35 --> Total execution time: 0.0165
INFO - 2023-02-28 09:45:35 --> Config Class Initialized
INFO - 2023-02-28 09:45:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:35 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:35 --> URI Class Initialized
INFO - 2023-02-28 09:45:35 --> Router Class Initialized
INFO - 2023-02-28 09:45:35 --> Output Class Initialized
INFO - 2023-02-28 09:45:35 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:35 --> Input Class Initialized
INFO - 2023-02-28 09:45:35 --> Language Class Initialized
INFO - 2023-02-28 09:45:35 --> Loader Class Initialized
INFO - 2023-02-28 09:45:35 --> Controller Class Initialized
DEBUG - 2023-02-28 09:45:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:35 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 09:45:35 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:35 --> Total execution time: 0.0127
INFO - 2023-02-28 09:45:35 --> Config Class Initialized
INFO - 2023-02-28 09:45:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:35 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:35 --> URI Class Initialized
INFO - 2023-02-28 09:45:35 --> Router Class Initialized
INFO - 2023-02-28 09:45:35 --> Output Class Initialized
INFO - 2023-02-28 09:45:35 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:35 --> Input Class Initialized
INFO - 2023-02-28 09:45:35 --> Language Class Initialized
INFO - 2023-02-28 09:45:35 --> Loader Class Initialized
INFO - 2023-02-28 09:45:35 --> Controller Class Initialized
DEBUG - 2023-02-28 09:45:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:35 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:35 --> Model "Cluster_model" initialized
INFO - 2023-02-28 09:45:35 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:35 --> Total execution time: 0.0112
INFO - 2023-02-28 09:45:36 --> Config Class Initialized
INFO - 2023-02-28 09:45:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:36 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:36 --> URI Class Initialized
INFO - 2023-02-28 09:45:36 --> Router Class Initialized
INFO - 2023-02-28 09:45:36 --> Output Class Initialized
INFO - 2023-02-28 09:45:36 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:36 --> Input Class Initialized
INFO - 2023-02-28 09:45:36 --> Language Class Initialized
INFO - 2023-02-28 09:45:36 --> Loader Class Initialized
INFO - 2023-02-28 09:45:36 --> Controller Class Initialized
DEBUG - 2023-02-28 09:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:36 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:36 --> Model "Cluster_model" initialized
INFO - 2023-02-28 09:45:36 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:36 --> Model "Login_model" initialized
INFO - 2023-02-28 09:45:36 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:36 --> Total execution time: 0.0803
INFO - 2023-02-28 09:45:36 --> Config Class Initialized
INFO - 2023-02-28 09:45:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:36 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:36 --> URI Class Initialized
INFO - 2023-02-28 09:45:36 --> Router Class Initialized
INFO - 2023-02-28 09:45:36 --> Output Class Initialized
INFO - 2023-02-28 09:45:36 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:36 --> Input Class Initialized
INFO - 2023-02-28 09:45:36 --> Language Class Initialized
INFO - 2023-02-28 09:45:36 --> Loader Class Initialized
INFO - 2023-02-28 09:45:36 --> Controller Class Initialized
DEBUG - 2023-02-28 09:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:36 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:36 --> Model "Cluster_model" initialized
INFO - 2023-02-28 09:45:36 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:36 --> Model "Login_model" initialized
INFO - 2023-02-28 09:45:36 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:36 --> Total execution time: 0.0881
INFO - 2023-02-28 09:45:39 --> Config Class Initialized
INFO - 2023-02-28 09:45:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:39 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:39 --> URI Class Initialized
INFO - 2023-02-28 09:45:39 --> Router Class Initialized
INFO - 2023-02-28 09:45:39 --> Output Class Initialized
INFO - 2023-02-28 09:45:39 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:39 --> Input Class Initialized
INFO - 2023-02-28 09:45:39 --> Language Class Initialized
INFO - 2023-02-28 09:45:39 --> Loader Class Initialized
INFO - 2023-02-28 09:45:39 --> Controller Class Initialized
DEBUG - 2023-02-28 09:45:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:39 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:39 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:39 --> Model "Login_model" initialized
INFO - 2023-02-28 09:45:39 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:39 --> Total execution time: 0.0263
INFO - 2023-02-28 09:45:39 --> Config Class Initialized
INFO - 2023-02-28 09:45:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:39 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:39 --> URI Class Initialized
INFO - 2023-02-28 09:45:39 --> Router Class Initialized
INFO - 2023-02-28 09:45:39 --> Output Class Initialized
INFO - 2023-02-28 09:45:39 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:39 --> Input Class Initialized
INFO - 2023-02-28 09:45:39 --> Language Class Initialized
INFO - 2023-02-28 09:45:39 --> Loader Class Initialized
INFO - 2023-02-28 09:45:39 --> Controller Class Initialized
DEBUG - 2023-02-28 09:45:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:39 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:39 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:39 --> Model "Login_model" initialized
INFO - 2023-02-28 09:45:39 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:39 --> Total execution time: 0.0634
INFO - 2023-02-28 09:45:51 --> Config Class Initialized
INFO - 2023-02-28 09:45:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:51 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:51 --> URI Class Initialized
INFO - 2023-02-28 09:45:51 --> Router Class Initialized
INFO - 2023-02-28 09:45:51 --> Output Class Initialized
INFO - 2023-02-28 09:45:51 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:51 --> Input Class Initialized
INFO - 2023-02-28 09:45:51 --> Language Class Initialized
INFO - 2023-02-28 09:45:51 --> Loader Class Initialized
INFO - 2023-02-28 09:45:51 --> Controller Class Initialized
DEBUG - 2023-02-28 09:45:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:51 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:51 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:51 --> Model "Login_model" initialized
INFO - 2023-02-28 09:45:51 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:51 --> Total execution time: 0.0210
INFO - 2023-02-28 09:45:51 --> Config Class Initialized
INFO - 2023-02-28 09:45:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:45:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:45:51 --> Utf8 Class Initialized
INFO - 2023-02-28 09:45:51 --> URI Class Initialized
INFO - 2023-02-28 09:45:51 --> Router Class Initialized
INFO - 2023-02-28 09:45:51 --> Output Class Initialized
INFO - 2023-02-28 09:45:51 --> Security Class Initialized
DEBUG - 2023-02-28 09:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:45:51 --> Input Class Initialized
INFO - 2023-02-28 09:45:51 --> Language Class Initialized
INFO - 2023-02-28 09:45:51 --> Loader Class Initialized
INFO - 2023-02-28 09:45:51 --> Controller Class Initialized
DEBUG - 2023-02-28 09:45:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:45:51 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:51 --> Database Driver Class Initialized
INFO - 2023-02-28 09:45:51 --> Model "Login_model" initialized
INFO - 2023-02-28 09:45:51 --> Final output sent to browser
DEBUG - 2023-02-28 09:45:51 --> Total execution time: 0.0646
INFO - 2023-02-28 09:46:01 --> Config Class Initialized
INFO - 2023-02-28 09:46:01 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:01 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:01 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:01 --> URI Class Initialized
INFO - 2023-02-28 09:46:01 --> Router Class Initialized
INFO - 2023-02-28 09:46:01 --> Output Class Initialized
INFO - 2023-02-28 09:46:01 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:01 --> Input Class Initialized
INFO - 2023-02-28 09:46:01 --> Language Class Initialized
INFO - 2023-02-28 09:46:01 --> Loader Class Initialized
INFO - 2023-02-28 09:46:01 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:01 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:01 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:01 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:01 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:01 --> Total execution time: 0.0212
INFO - 2023-02-28 09:46:01 --> Config Class Initialized
INFO - 2023-02-28 09:46:01 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:01 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:01 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:01 --> URI Class Initialized
INFO - 2023-02-28 09:46:01 --> Router Class Initialized
INFO - 2023-02-28 09:46:01 --> Output Class Initialized
INFO - 2023-02-28 09:46:01 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:01 --> Input Class Initialized
INFO - 2023-02-28 09:46:01 --> Language Class Initialized
INFO - 2023-02-28 09:46:01 --> Loader Class Initialized
INFO - 2023-02-28 09:46:01 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:01 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:01 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:01 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:01 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:01 --> Total execution time: 0.0614
INFO - 2023-02-28 09:46:07 --> Config Class Initialized
INFO - 2023-02-28 09:46:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:07 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:07 --> URI Class Initialized
INFO - 2023-02-28 09:46:07 --> Router Class Initialized
INFO - 2023-02-28 09:46:07 --> Output Class Initialized
INFO - 2023-02-28 09:46:07 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:07 --> Input Class Initialized
INFO - 2023-02-28 09:46:07 --> Language Class Initialized
INFO - 2023-02-28 09:46:07 --> Loader Class Initialized
INFO - 2023-02-28 09:46:07 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:07 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:07 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:07 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:07 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:07 --> Total execution time: 0.0204
INFO - 2023-02-28 09:46:07 --> Config Class Initialized
INFO - 2023-02-28 09:46:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:07 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:07 --> URI Class Initialized
INFO - 2023-02-28 09:46:07 --> Router Class Initialized
INFO - 2023-02-28 09:46:07 --> Output Class Initialized
INFO - 2023-02-28 09:46:07 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:07 --> Input Class Initialized
INFO - 2023-02-28 09:46:07 --> Language Class Initialized
INFO - 2023-02-28 09:46:07 --> Loader Class Initialized
INFO - 2023-02-28 09:46:07 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:07 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:07 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:07 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:07 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:07 --> Total execution time: 0.0590
INFO - 2023-02-28 09:46:13 --> Config Class Initialized
INFO - 2023-02-28 09:46:13 --> Config Class Initialized
INFO - 2023-02-28 09:46:13 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:13 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:13 --> Config Class Initialized
INFO - 2023-02-28 09:46:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:13 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 09:46:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:13 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:13 --> Utf8 Class Initialized
DEBUG - 2023-02-28 09:46:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:13 --> URI Class Initialized
INFO - 2023-02-28 09:46:13 --> URI Class Initialized
INFO - 2023-02-28 09:46:13 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:13 --> Router Class Initialized
INFO - 2023-02-28 09:46:13 --> Router Class Initialized
INFO - 2023-02-28 09:46:13 --> URI Class Initialized
INFO - 2023-02-28 09:46:13 --> Output Class Initialized
INFO - 2023-02-28 09:46:13 --> Output Class Initialized
INFO - 2023-02-28 09:46:13 --> Router Class Initialized
INFO - 2023-02-28 09:46:13 --> Security Class Initialized
INFO - 2023-02-28 09:46:13 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:13 --> Output Class Initialized
INFO - 2023-02-28 09:46:13 --> Input Class Initialized
INFO - 2023-02-28 09:46:13 --> Language Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:13 --> Security Class Initialized
INFO - 2023-02-28 09:46:13 --> Input Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:13 --> Language Class Initialized
INFO - 2023-02-28 09:46:13 --> Loader Class Initialized
INFO - 2023-02-28 09:46:13 --> Input Class Initialized
INFO - 2023-02-28 09:46:13 --> Controller Class Initialized
INFO - 2023-02-28 09:46:13 --> Loader Class Initialized
INFO - 2023-02-28 09:46:13 --> Language Class Initialized
INFO - 2023-02-28 09:46:13 --> Controller Class Initialized
INFO - 2023-02-28 09:46:13 --> Loader Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 09:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:13 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:13 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:13 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:13 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:13 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:13 --> Final output sent to browser
INFO - 2023-02-28 09:46:13 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:13 --> Total execution time: 0.0160
DEBUG - 2023-02-28 09:46:13 --> Total execution time: 0.0152
INFO - 2023-02-28 09:46:13 --> Config Class Initialized
INFO - 2023-02-28 09:46:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:13 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:13 --> URI Class Initialized
INFO - 2023-02-28 09:46:13 --> Config Class Initialized
INFO - 2023-02-28 09:46:13 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:13 --> Total execution time: 0.0264
INFO - 2023-02-28 09:46:13 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:13 --> Router Class Initialized
DEBUG - 2023-02-28 09:46:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:13 --> Output Class Initialized
INFO - 2023-02-28 09:46:13 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:13 --> Security Class Initialized
INFO - 2023-02-28 09:46:13 --> URI Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:13 --> Router Class Initialized
INFO - 2023-02-28 09:46:13 --> Config Class Initialized
INFO - 2023-02-28 09:46:13 --> Input Class Initialized
INFO - 2023-02-28 09:46:13 --> Output Class Initialized
INFO - 2023-02-28 09:46:13 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:13 --> Language Class Initialized
INFO - 2023-02-28 09:46:13 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:13 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 09:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:13 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:13 --> Loader Class Initialized
INFO - 2023-02-28 09:46:13 --> Input Class Initialized
INFO - 2023-02-28 09:46:13 --> URI Class Initialized
INFO - 2023-02-28 09:46:13 --> Controller Class Initialized
INFO - 2023-02-28 09:46:13 --> Router Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:13 --> Language Class Initialized
INFO - 2023-02-28 09:46:13 --> Output Class Initialized
INFO - 2023-02-28 09:46:13 --> Final output sent to browser
INFO - 2023-02-28 09:46:13 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Total execution time: 0.0817
INFO - 2023-02-28 09:46:13 --> Loader Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:13 --> Controller Class Initialized
INFO - 2023-02-28 09:46:13 --> Input Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:13 --> Language Class Initialized
INFO - 2023-02-28 09:46:13 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:13 --> Loader Class Initialized
INFO - 2023-02-28 09:46:13 --> Config Class Initialized
INFO - 2023-02-28 09:46:13 --> Controller Class Initialized
INFO - 2023-02-28 09:46:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 09:46:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:13 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:13 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:13 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:13 --> URI Class Initialized
INFO - 2023-02-28 09:46:13 --> Router Class Initialized
INFO - 2023-02-28 09:46:13 --> Output Class Initialized
INFO - 2023-02-28 09:46:13 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:13 --> Input Class Initialized
INFO - 2023-02-28 09:46:13 --> Language Class Initialized
INFO - 2023-02-28 09:46:13 --> Loader Class Initialized
INFO - 2023-02-28 09:46:13 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:13 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:13 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:13 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:13 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:13 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:13 --> Total execution time: 0.1367
INFO - 2023-02-28 09:46:13 --> Config Class Initialized
INFO - 2023-02-28 09:46:13 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:13 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:13 --> Total execution time: 0.0644
INFO - 2023-02-28 09:46:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:13 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:13 --> URI Class Initialized
INFO - 2023-02-28 09:46:13 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:13 --> Total execution time: 0.1428
INFO - 2023-02-28 09:46:13 --> Router Class Initialized
INFO - 2023-02-28 09:46:13 --> Output Class Initialized
INFO - 2023-02-28 09:46:13 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:13 --> Input Class Initialized
INFO - 2023-02-28 09:46:13 --> Language Class Initialized
INFO - 2023-02-28 09:46:13 --> Loader Class Initialized
INFO - 2023-02-28 09:46:13 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:13 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:13 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:13 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:13 --> Model "Cluster_model" initialized
INFO - 2023-02-28 09:46:13 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:13 --> Total execution time: 0.1425
INFO - 2023-02-28 09:46:17 --> Config Class Initialized
INFO - 2023-02-28 09:46:17 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:17 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:17 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:17 --> URI Class Initialized
INFO - 2023-02-28 09:46:17 --> Router Class Initialized
INFO - 2023-02-28 09:46:17 --> Output Class Initialized
INFO - 2023-02-28 09:46:17 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:17 --> Input Class Initialized
INFO - 2023-02-28 09:46:17 --> Language Class Initialized
INFO - 2023-02-28 09:46:17 --> Loader Class Initialized
INFO - 2023-02-28 09:46:17 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:17 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:17 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:17 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:17 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:17 --> Total execution time: 0.0381
INFO - 2023-02-28 09:46:17 --> Config Class Initialized
INFO - 2023-02-28 09:46:17 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:17 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:17 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:17 --> URI Class Initialized
INFO - 2023-02-28 09:46:17 --> Router Class Initialized
INFO - 2023-02-28 09:46:17 --> Output Class Initialized
INFO - 2023-02-28 09:46:17 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:17 --> Input Class Initialized
INFO - 2023-02-28 09:46:17 --> Language Class Initialized
INFO - 2023-02-28 09:46:17 --> Loader Class Initialized
INFO - 2023-02-28 09:46:17 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:17 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:17 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:17 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:17 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:17 --> Total execution time: 0.0224
INFO - 2023-02-28 09:46:20 --> Config Class Initialized
INFO - 2023-02-28 09:46:20 --> Config Class Initialized
INFO - 2023-02-28 09:46:20 --> Config Class Initialized
INFO - 2023-02-28 09:46:20 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:20 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:20 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:20 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 09:46:20 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 09:46:20 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:20 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:20 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:20 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:20 --> URI Class Initialized
INFO - 2023-02-28 09:46:20 --> URI Class Initialized
INFO - 2023-02-28 09:46:20 --> URI Class Initialized
INFO - 2023-02-28 09:46:20 --> Router Class Initialized
INFO - 2023-02-28 09:46:20 --> Router Class Initialized
INFO - 2023-02-28 09:46:20 --> Router Class Initialized
INFO - 2023-02-28 09:46:20 --> Output Class Initialized
INFO - 2023-02-28 09:46:20 --> Output Class Initialized
INFO - 2023-02-28 09:46:20 --> Security Class Initialized
INFO - 2023-02-28 09:46:20 --> Output Class Initialized
INFO - 2023-02-28 09:46:20 --> Security Class Initialized
INFO - 2023-02-28 09:46:20 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:20 --> Input Class Initialized
DEBUG - 2023-02-28 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:20 --> Input Class Initialized
INFO - 2023-02-28 09:46:20 --> Input Class Initialized
INFO - 2023-02-28 09:46:20 --> Language Class Initialized
INFO - 2023-02-28 09:46:20 --> Language Class Initialized
INFO - 2023-02-28 09:46:20 --> Language Class Initialized
INFO - 2023-02-28 09:46:20 --> Loader Class Initialized
INFO - 2023-02-28 09:46:20 --> Loader Class Initialized
INFO - 2023-02-28 09:46:20 --> Loader Class Initialized
INFO - 2023-02-28 09:46:20 --> Controller Class Initialized
INFO - 2023-02-28 09:46:20 --> Controller Class Initialized
INFO - 2023-02-28 09:46:20 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 09:46:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 09:46:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:20 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:20 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:20 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:20 --> Final output sent to browser
INFO - 2023-02-28 09:46:20 --> Model "Login_model" initialized
DEBUG - 2023-02-28 09:46:20 --> Total execution time: 0.0137
INFO - 2023-02-28 09:46:20 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:20 --> Total execution time: 0.0137
INFO - 2023-02-28 09:46:20 --> Config Class Initialized
INFO - 2023-02-28 09:46:20 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:20 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:20 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:20 --> URI Class Initialized
INFO - 2023-02-28 09:46:20 --> Router Class Initialized
INFO - 2023-02-28 09:46:20 --> Output Class Initialized
INFO - 2023-02-28 09:46:20 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:20 --> Input Class Initialized
INFO - 2023-02-28 09:46:20 --> Language Class Initialized
INFO - 2023-02-28 09:46:20 --> Config Class Initialized
INFO - 2023-02-28 09:46:20 --> Loader Class Initialized
INFO - 2023-02-28 09:46:20 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:20 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:20 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 09:46:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:20 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:20 --> Final output sent to browser
INFO - 2023-02-28 09:46:20 --> URI Class Initialized
DEBUG - 2023-02-28 09:46:20 --> Total execution time: 0.0029
INFO - 2023-02-28 09:46:20 --> Router Class Initialized
INFO - 2023-02-28 09:46:20 --> Output Class Initialized
INFO - 2023-02-28 09:46:20 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:20 --> Config Class Initialized
INFO - 2023-02-28 09:46:20 --> Input Class Initialized
INFO - 2023-02-28 09:46:20 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:20 --> Language Class Initialized
DEBUG - 2023-02-28 09:46:20 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:20 --> Loader Class Initialized
INFO - 2023-02-28 09:46:20 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:20 --> Controller Class Initialized
INFO - 2023-02-28 09:46:20 --> URI Class Initialized
DEBUG - 2023-02-28 09:46:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:20 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:20 --> Router Class Initialized
INFO - 2023-02-28 09:46:20 --> Output Class Initialized
INFO - 2023-02-28 09:46:20 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:20 --> Input Class Initialized
INFO - 2023-02-28 09:46:20 --> Language Class Initialized
INFO - 2023-02-28 09:46:20 --> Loader Class Initialized
INFO - 2023-02-28 09:46:20 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:20 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:20 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:20 --> Total execution time: 0.0231
INFO - 2023-02-28 09:46:20 --> Config Class Initialized
INFO - 2023-02-28 09:46:20 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:20 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:20 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:20 --> URI Class Initialized
INFO - 2023-02-28 09:46:20 --> Router Class Initialized
INFO - 2023-02-28 09:46:20 --> Output Class Initialized
INFO - 2023-02-28 09:46:20 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:20 --> Input Class Initialized
INFO - 2023-02-28 09:46:20 --> Language Class Initialized
INFO - 2023-02-28 09:46:20 --> Loader Class Initialized
INFO - 2023-02-28 09:46:20 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:20 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:20 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:20 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:20 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:20 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:20 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:20 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:20 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:20 --> Total execution time: 0.0206
INFO - 2023-02-28 09:46:20 --> Config Class Initialized
INFO - 2023-02-28 09:46:20 --> Final output sent to browser
INFO - 2023-02-28 09:46:20 --> Model "Cluster_model" initialized
INFO - 2023-02-28 09:46:20 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:20 --> Total execution time: 0.0206
DEBUG - 2023-02-28 09:46:20 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:20 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:20 --> URI Class Initialized
INFO - 2023-02-28 09:46:20 --> Router Class Initialized
INFO - 2023-02-28 09:46:20 --> Output Class Initialized
INFO - 2023-02-28 09:46:20 --> Security Class Initialized
INFO - 2023-02-28 09:46:20 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:20 --> Total execution time: 0.0551
DEBUG - 2023-02-28 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:20 --> Input Class Initialized
INFO - 2023-02-28 09:46:20 --> Language Class Initialized
INFO - 2023-02-28 09:46:20 --> Loader Class Initialized
INFO - 2023-02-28 09:46:20 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:20 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:20 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:20 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:20 --> Total execution time: 0.1388
INFO - 2023-02-28 09:46:25 --> Config Class Initialized
INFO - 2023-02-28 09:46:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:25 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:25 --> URI Class Initialized
INFO - 2023-02-28 09:46:25 --> Router Class Initialized
INFO - 2023-02-28 09:46:26 --> Output Class Initialized
INFO - 2023-02-28 09:46:26 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:26 --> Input Class Initialized
INFO - 2023-02-28 09:46:26 --> Language Class Initialized
INFO - 2023-02-28 09:46:26 --> Loader Class Initialized
INFO - 2023-02-28 09:46:26 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:26 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:26 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:26 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:26 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:26 --> Total execution time: 0.0235
INFO - 2023-02-28 09:46:26 --> Config Class Initialized
INFO - 2023-02-28 09:46:26 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:26 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:26 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:26 --> URI Class Initialized
INFO - 2023-02-28 09:46:26 --> Router Class Initialized
INFO - 2023-02-28 09:46:26 --> Output Class Initialized
INFO - 2023-02-28 09:46:26 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:26 --> Input Class Initialized
INFO - 2023-02-28 09:46:26 --> Language Class Initialized
INFO - 2023-02-28 09:46:26 --> Loader Class Initialized
INFO - 2023-02-28 09:46:26 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:26 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:26 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:26 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:26 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:26 --> Total execution time: 0.0189
INFO - 2023-02-28 09:46:33 --> Config Class Initialized
INFO - 2023-02-28 09:46:33 --> Config Class Initialized
INFO - 2023-02-28 09:46:33 --> Config Class Initialized
INFO - 2023-02-28 09:46:33 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:33 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:33 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 09:46:33 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 09:46:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:33 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:33 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:33 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:33 --> URI Class Initialized
INFO - 2023-02-28 09:46:33 --> URI Class Initialized
INFO - 2023-02-28 09:46:33 --> URI Class Initialized
INFO - 2023-02-28 09:46:33 --> Router Class Initialized
INFO - 2023-02-28 09:46:33 --> Router Class Initialized
INFO - 2023-02-28 09:46:33 --> Router Class Initialized
INFO - 2023-02-28 09:46:33 --> Output Class Initialized
INFO - 2023-02-28 09:46:33 --> Output Class Initialized
INFO - 2023-02-28 09:46:33 --> Output Class Initialized
INFO - 2023-02-28 09:46:33 --> Security Class Initialized
INFO - 2023-02-28 09:46:33 --> Security Class Initialized
INFO - 2023-02-28 09:46:33 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 09:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:33 --> Input Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:33 --> Language Class Initialized
INFO - 2023-02-28 09:46:33 --> Input Class Initialized
INFO - 2023-02-28 09:46:33 --> Input Class Initialized
INFO - 2023-02-28 09:46:33 --> Language Class Initialized
INFO - 2023-02-28 09:46:33 --> Language Class Initialized
INFO - 2023-02-28 09:46:33 --> Loader Class Initialized
INFO - 2023-02-28 09:46:33 --> Loader Class Initialized
INFO - 2023-02-28 09:46:33 --> Loader Class Initialized
INFO - 2023-02-28 09:46:33 --> Controller Class Initialized
INFO - 2023-02-28 09:46:33 --> Controller Class Initialized
INFO - 2023-02-28 09:46:33 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 09:46:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 09:46:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:33 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:33 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:33 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:33 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:33 --> Total execution time: 0.0165
INFO - 2023-02-28 09:46:33 --> Config Class Initialized
INFO - 2023-02-28 09:46:33 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:33 --> Model "Login_model" initialized
DEBUG - 2023-02-28 09:46:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:33 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:33 --> URI Class Initialized
INFO - 2023-02-28 09:46:33 --> Router Class Initialized
INFO - 2023-02-28 09:46:33 --> Output Class Initialized
INFO - 2023-02-28 09:46:33 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:33 --> Input Class Initialized
INFO - 2023-02-28 09:46:33 --> Language Class Initialized
INFO - 2023-02-28 09:46:33 --> Final output sent to browser
INFO - 2023-02-28 09:46:33 --> Loader Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Total execution time: 0.0196
INFO - 2023-02-28 09:46:33 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:33 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:33 --> Total execution time: 0.0026
INFO - 2023-02-28 09:46:33 --> Config Class Initialized
INFO - 2023-02-28 09:46:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:33 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:33 --> URI Class Initialized
INFO - 2023-02-28 09:46:33 --> Router Class Initialized
INFO - 2023-02-28 09:46:33 --> Output Class Initialized
INFO - 2023-02-28 09:46:33 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:33 --> Input Class Initialized
INFO - 2023-02-28 09:46:33 --> Language Class Initialized
INFO - 2023-02-28 09:46:33 --> Config Class Initialized
INFO - 2023-02-28 09:46:33 --> Loader Class Initialized
INFO - 2023-02-28 09:46:33 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:33 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 09:46:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:33 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:33 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:33 --> URI Class Initialized
INFO - 2023-02-28 09:46:33 --> Router Class Initialized
INFO - 2023-02-28 09:46:33 --> Output Class Initialized
INFO - 2023-02-28 09:46:33 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:33 --> Input Class Initialized
INFO - 2023-02-28 09:46:33 --> Language Class Initialized
INFO - 2023-02-28 09:46:33 --> Loader Class Initialized
INFO - 2023-02-28 09:46:33 --> Config Class Initialized
INFO - 2023-02-28 09:46:33 --> Controller Class Initialized
INFO - 2023-02-28 09:46:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:33 --> Database Driver Class Initialized
DEBUG - 2023-02-28 09:46:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:33 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:33 --> URI Class Initialized
INFO - 2023-02-28 09:46:33 --> Router Class Initialized
INFO - 2023-02-28 09:46:33 --> Output Class Initialized
INFO - 2023-02-28 09:46:33 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:33 --> Input Class Initialized
INFO - 2023-02-28 09:46:33 --> Language Class Initialized
INFO - 2023-02-28 09:46:33 --> Loader Class Initialized
INFO - 2023-02-28 09:46:33 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:33 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:33 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:33 --> Final output sent to browser
INFO - 2023-02-28 09:46:33 --> Database Driver Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Total execution time: 0.0390
INFO - 2023-02-28 09:46:33 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:33 --> Config Class Initialized
INFO - 2023-02-28 09:46:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:33 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:33 --> URI Class Initialized
INFO - 2023-02-28 09:46:33 --> Router Class Initialized
INFO - 2023-02-28 09:46:33 --> Output Class Initialized
INFO - 2023-02-28 09:46:33 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:33 --> Input Class Initialized
INFO - 2023-02-28 09:46:33 --> Language Class Initialized
INFO - 2023-02-28 09:46:33 --> Loader Class Initialized
INFO - 2023-02-28 09:46:33 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:33 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:33 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 09:46:33 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:33 --> Total execution time: 0.0301
INFO - 2023-02-28 09:46:33 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:33 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:33 --> Total execution time: 0.0301
INFO - 2023-02-28 09:46:33 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:33 --> Total execution time: 0.0583
INFO - 2023-02-28 09:46:33 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:34 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:34 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:34 --> Total execution time: 0.1745
INFO - 2023-02-28 09:46:37 --> Config Class Initialized
INFO - 2023-02-28 09:46:37 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:37 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:37 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:37 --> URI Class Initialized
INFO - 2023-02-28 09:46:37 --> Router Class Initialized
INFO - 2023-02-28 09:46:37 --> Output Class Initialized
INFO - 2023-02-28 09:46:37 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:37 --> Input Class Initialized
INFO - 2023-02-28 09:46:37 --> Language Class Initialized
INFO - 2023-02-28 09:46:37 --> Loader Class Initialized
INFO - 2023-02-28 09:46:37 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:37 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:37 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:37 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:37 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:37 --> Total execution time: 0.0225
INFO - 2023-02-28 09:46:37 --> Config Class Initialized
INFO - 2023-02-28 09:46:37 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:37 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:37 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:37 --> URI Class Initialized
INFO - 2023-02-28 09:46:37 --> Router Class Initialized
INFO - 2023-02-28 09:46:37 --> Output Class Initialized
INFO - 2023-02-28 09:46:37 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:37 --> Input Class Initialized
INFO - 2023-02-28 09:46:37 --> Language Class Initialized
INFO - 2023-02-28 09:46:37 --> Loader Class Initialized
INFO - 2023-02-28 09:46:37 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:37 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:37 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:37 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:37 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:37 --> Total execution time: 0.0191
INFO - 2023-02-28 09:46:40 --> Config Class Initialized
INFO - 2023-02-28 09:46:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:40 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:40 --> URI Class Initialized
INFO - 2023-02-28 09:46:40 --> Router Class Initialized
INFO - 2023-02-28 09:46:40 --> Output Class Initialized
INFO - 2023-02-28 09:46:40 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:40 --> Input Class Initialized
INFO - 2023-02-28 09:46:40 --> Language Class Initialized
INFO - 2023-02-28 09:46:40 --> Loader Class Initialized
INFO - 2023-02-28 09:46:40 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:40 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:40 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:40 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:40 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:40 --> Total execution time: 0.0339
INFO - 2023-02-28 09:46:40 --> Config Class Initialized
INFO - 2023-02-28 09:46:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:40 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:40 --> URI Class Initialized
INFO - 2023-02-28 09:46:40 --> Router Class Initialized
INFO - 2023-02-28 09:46:40 --> Output Class Initialized
INFO - 2023-02-28 09:46:40 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:40 --> Input Class Initialized
INFO - 2023-02-28 09:46:40 --> Language Class Initialized
INFO - 2023-02-28 09:46:40 --> Loader Class Initialized
INFO - 2023-02-28 09:46:40 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:40 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:40 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:40 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:40 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:40 --> Total execution time: 0.0191
INFO - 2023-02-28 09:46:50 --> Config Class Initialized
INFO - 2023-02-28 09:46:50 --> Config Class Initialized
INFO - 2023-02-28 09:46:50 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:50 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:50 --> Config Class Initialized
INFO - 2023-02-28 09:46:50 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:50 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 09:46:50 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:50 --> Utf8 Class Initialized
DEBUG - 2023-02-28 09:46:50 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:50 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:50 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:50 --> URI Class Initialized
INFO - 2023-02-28 09:46:50 --> URI Class Initialized
INFO - 2023-02-28 09:46:50 --> URI Class Initialized
INFO - 2023-02-28 09:46:50 --> Router Class Initialized
INFO - 2023-02-28 09:46:50 --> Router Class Initialized
INFO - 2023-02-28 09:46:50 --> Router Class Initialized
INFO - 2023-02-28 09:46:50 --> Output Class Initialized
INFO - 2023-02-28 09:46:50 --> Output Class Initialized
INFO - 2023-02-28 09:46:50 --> Output Class Initialized
INFO - 2023-02-28 09:46:50 --> Security Class Initialized
INFO - 2023-02-28 09:46:50 --> Security Class Initialized
INFO - 2023-02-28 09:46:50 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 09:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 09:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:50 --> Input Class Initialized
INFO - 2023-02-28 09:46:50 --> Input Class Initialized
INFO - 2023-02-28 09:46:50 --> Input Class Initialized
INFO - 2023-02-28 09:46:50 --> Language Class Initialized
INFO - 2023-02-28 09:46:50 --> Language Class Initialized
INFO - 2023-02-28 09:46:50 --> Language Class Initialized
INFO - 2023-02-28 09:46:50 --> Loader Class Initialized
INFO - 2023-02-28 09:46:50 --> Loader Class Initialized
INFO - 2023-02-28 09:46:50 --> Loader Class Initialized
INFO - 2023-02-28 09:46:50 --> Controller Class Initialized
INFO - 2023-02-28 09:46:50 --> Controller Class Initialized
INFO - 2023-02-28 09:46:50 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 09:46:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 09:46:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:50 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:50 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:50 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:50 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:50 --> Final output sent to browser
INFO - 2023-02-28 09:46:50 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:50 --> Total execution time: 0.0152
DEBUG - 2023-02-28 09:46:50 --> Total execution time: 0.0154
INFO - 2023-02-28 09:46:50 --> Config Class Initialized
INFO - 2023-02-28 09:46:50 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:50 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:50 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:50 --> URI Class Initialized
INFO - 2023-02-28 09:46:50 --> Router Class Initialized
INFO - 2023-02-28 09:46:50 --> Output Class Initialized
INFO - 2023-02-28 09:46:50 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:50 --> Input Class Initialized
INFO - 2023-02-28 09:46:50 --> Language Class Initialized
INFO - 2023-02-28 09:46:50 --> Config Class Initialized
INFO - 2023-02-28 09:46:50 --> Loader Class Initialized
INFO - 2023-02-28 09:46:50 --> Hooks Class Initialized
INFO - 2023-02-28 09:46:50 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:50 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 09:46:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:50 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:50 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:50 --> Total execution time: 0.0023
INFO - 2023-02-28 09:46:50 --> URI Class Initialized
INFO - 2023-02-28 09:46:50 --> Router Class Initialized
INFO - 2023-02-28 09:46:50 --> Output Class Initialized
INFO - 2023-02-28 09:46:50 --> Config Class Initialized
INFO - 2023-02-28 09:46:50 --> Security Class Initialized
INFO - 2023-02-28 09:46:50 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 09:46:50 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:50 --> Input Class Initialized
INFO - 2023-02-28 09:46:50 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:50 --> Language Class Initialized
INFO - 2023-02-28 09:46:50 --> URI Class Initialized
INFO - 2023-02-28 09:46:50 --> Loader Class Initialized
INFO - 2023-02-28 09:46:50 --> Router Class Initialized
INFO - 2023-02-28 09:46:50 --> Controller Class Initialized
INFO - 2023-02-28 09:46:50 --> Output Class Initialized
DEBUG - 2023-02-28 09:46:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:50 --> Security Class Initialized
INFO - 2023-02-28 09:46:50 --> Database Driver Class Initialized
DEBUG - 2023-02-28 09:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:50 --> Input Class Initialized
INFO - 2023-02-28 09:46:50 --> Language Class Initialized
INFO - 2023-02-28 09:46:50 --> Loader Class Initialized
INFO - 2023-02-28 09:46:50 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:50 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:50 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:50 --> Total execution time: 0.0223
INFO - 2023-02-28 09:46:50 --> Config Class Initialized
INFO - 2023-02-28 09:46:50 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:50 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:50 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:50 --> URI Class Initialized
INFO - 2023-02-28 09:46:50 --> Router Class Initialized
INFO - 2023-02-28 09:46:50 --> Output Class Initialized
INFO - 2023-02-28 09:46:50 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:50 --> Input Class Initialized
INFO - 2023-02-28 09:46:50 --> Language Class Initialized
INFO - 2023-02-28 09:46:50 --> Loader Class Initialized
INFO - 2023-02-28 09:46:50 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:50 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:50 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:50 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:50 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:50 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:50 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:50 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:50 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:50 --> Total execution time: 0.0218
INFO - 2023-02-28 09:46:50 --> Config Class Initialized
INFO - 2023-02-28 09:46:50 --> Final output sent to browser
INFO - 2023-02-28 09:46:50 --> Model "Cluster_model" initialized
DEBUG - 2023-02-28 09:46:50 --> Total execution time: 0.0217
INFO - 2023-02-28 09:46:50 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:46:50 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:46:50 --> Utf8 Class Initialized
INFO - 2023-02-28 09:46:50 --> URI Class Initialized
INFO - 2023-02-28 09:46:50 --> Router Class Initialized
INFO - 2023-02-28 09:46:50 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:50 --> Total execution time: 0.0609
INFO - 2023-02-28 09:46:50 --> Output Class Initialized
INFO - 2023-02-28 09:46:50 --> Security Class Initialized
DEBUG - 2023-02-28 09:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:46:50 --> Input Class Initialized
INFO - 2023-02-28 09:46:50 --> Language Class Initialized
INFO - 2023-02-28 09:46:50 --> Loader Class Initialized
INFO - 2023-02-28 09:46:50 --> Controller Class Initialized
DEBUG - 2023-02-28 09:46:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:46:50 --> Database Driver Class Initialized
INFO - 2023-02-28 09:46:50 --> Model "Login_model" initialized
INFO - 2023-02-28 09:46:50 --> Final output sent to browser
DEBUG - 2023-02-28 09:46:50 --> Total execution time: 0.1380
INFO - 2023-02-28 09:47:26 --> Config Class Initialized
INFO - 2023-02-28 09:47:26 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:47:26 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:47:26 --> Utf8 Class Initialized
INFO - 2023-02-28 09:47:26 --> URI Class Initialized
INFO - 2023-02-28 09:47:26 --> Router Class Initialized
INFO - 2023-02-28 09:47:26 --> Output Class Initialized
INFO - 2023-02-28 09:47:26 --> Security Class Initialized
DEBUG - 2023-02-28 09:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:47:26 --> Input Class Initialized
INFO - 2023-02-28 09:47:26 --> Language Class Initialized
INFO - 2023-02-28 09:47:26 --> Loader Class Initialized
INFO - 2023-02-28 09:47:26 --> Controller Class Initialized
DEBUG - 2023-02-28 09:47:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:47:26 --> Final output sent to browser
DEBUG - 2023-02-28 09:47:26 --> Total execution time: 0.0039
INFO - 2023-02-28 09:47:26 --> Config Class Initialized
INFO - 2023-02-28 09:47:26 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:47:26 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:47:26 --> Utf8 Class Initialized
INFO - 2023-02-28 09:47:26 --> URI Class Initialized
INFO - 2023-02-28 09:47:26 --> Router Class Initialized
INFO - 2023-02-28 09:47:26 --> Output Class Initialized
INFO - 2023-02-28 09:47:26 --> Security Class Initialized
DEBUG - 2023-02-28 09:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:47:26 --> Input Class Initialized
INFO - 2023-02-28 09:47:26 --> Language Class Initialized
INFO - 2023-02-28 09:47:26 --> Loader Class Initialized
INFO - 2023-02-28 09:47:26 --> Controller Class Initialized
DEBUG - 2023-02-28 09:47:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:47:26 --> Database Driver Class Initialized
INFO - 2023-02-28 09:47:26 --> Model "Login_model" initialized
INFO - 2023-02-28 09:47:26 --> Final output sent to browser
DEBUG - 2023-02-28 09:47:26 --> Total execution time: 0.0174
INFO - 2023-02-28 09:47:26 --> Config Class Initialized
INFO - 2023-02-28 09:47:26 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:47:26 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:47:26 --> Utf8 Class Initialized
INFO - 2023-02-28 09:47:26 --> URI Class Initialized
INFO - 2023-02-28 09:47:26 --> Router Class Initialized
INFO - 2023-02-28 09:47:26 --> Output Class Initialized
INFO - 2023-02-28 09:47:26 --> Security Class Initialized
DEBUG - 2023-02-28 09:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:47:26 --> Input Class Initialized
INFO - 2023-02-28 09:47:26 --> Language Class Initialized
INFO - 2023-02-28 09:47:26 --> Loader Class Initialized
INFO - 2023-02-28 09:47:26 --> Controller Class Initialized
DEBUG - 2023-02-28 09:47:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:47:26 --> Database Driver Class Initialized
INFO - 2023-02-28 09:47:26 --> Model "Login_model" initialized
INFO - 2023-02-28 09:47:26 --> Final output sent to browser
DEBUG - 2023-02-28 09:47:26 --> Total execution time: 0.0652
INFO - 2023-02-28 09:47:26 --> Config Class Initialized
INFO - 2023-02-28 09:47:26 --> Hooks Class Initialized
DEBUG - 2023-02-28 09:47:26 --> UTF-8 Support Enabled
INFO - 2023-02-28 09:47:26 --> Utf8 Class Initialized
INFO - 2023-02-28 09:47:26 --> URI Class Initialized
INFO - 2023-02-28 09:47:26 --> Router Class Initialized
INFO - 2023-02-28 09:47:26 --> Output Class Initialized
INFO - 2023-02-28 09:47:26 --> Security Class Initialized
DEBUG - 2023-02-28 09:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 09:47:26 --> Input Class Initialized
INFO - 2023-02-28 09:47:26 --> Language Class Initialized
INFO - 2023-02-28 09:47:26 --> Loader Class Initialized
INFO - 2023-02-28 09:47:26 --> Controller Class Initialized
DEBUG - 2023-02-28 09:47:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 09:47:26 --> Database Driver Class Initialized
INFO - 2023-02-28 09:47:26 --> Model "Login_model" initialized
INFO - 2023-02-28 09:47:26 --> Final output sent to browser
DEBUG - 2023-02-28 09:47:26 --> Total execution time: 0.0195
INFO - 2023-02-28 10:11:52 --> Config Class Initialized
INFO - 2023-02-28 10:11:52 --> Hooks Class Initialized
INFO - 2023-02-28 10:11:52 --> Config Class Initialized
INFO - 2023-02-28 10:11:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:11:52 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:11:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:11:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:11:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:11:52 --> URI Class Initialized
INFO - 2023-02-28 10:11:52 --> URI Class Initialized
INFO - 2023-02-28 10:11:52 --> Router Class Initialized
INFO - 2023-02-28 10:11:52 --> Router Class Initialized
INFO - 2023-02-28 10:11:52 --> Output Class Initialized
INFO - 2023-02-28 10:11:52 --> Output Class Initialized
INFO - 2023-02-28 10:11:52 --> Security Class Initialized
INFO - 2023-02-28 10:11:52 --> Security Class Initialized
DEBUG - 2023-02-28 10:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:11:52 --> Input Class Initialized
INFO - 2023-02-28 10:11:52 --> Input Class Initialized
INFO - 2023-02-28 10:11:52 --> Language Class Initialized
INFO - 2023-02-28 10:11:52 --> Language Class Initialized
INFO - 2023-02-28 10:11:52 --> Loader Class Initialized
INFO - 2023-02-28 10:11:52 --> Loader Class Initialized
INFO - 2023-02-28 10:11:52 --> Controller Class Initialized
INFO - 2023-02-28 10:11:52 --> Controller Class Initialized
DEBUG - 2023-02-28 10:11:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:11:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:11:52 --> Final output sent to browser
DEBUG - 2023-02-28 10:11:52 --> Total execution time: 0.0501
INFO - 2023-02-28 10:11:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:11:52 --> Config Class Initialized
INFO - 2023-02-28 10:11:52 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:11:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:11:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:11:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:11:52 --> URI Class Initialized
INFO - 2023-02-28 10:11:52 --> Router Class Initialized
INFO - 2023-02-28 10:11:52 --> Output Class Initialized
INFO - 2023-02-28 10:11:52 --> Security Class Initialized
DEBUG - 2023-02-28 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:11:52 --> Input Class Initialized
INFO - 2023-02-28 10:11:52 --> Language Class Initialized
INFO - 2023-02-28 10:11:52 --> Loader Class Initialized
INFO - 2023-02-28 10:11:52 --> Controller Class Initialized
DEBUG - 2023-02-28 10:11:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:11:52 --> Final output sent to browser
DEBUG - 2023-02-28 10:11:52 --> Total execution time: 0.0622
INFO - 2023-02-28 10:11:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:11:52 --> Config Class Initialized
INFO - 2023-02-28 10:11:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:11:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:11:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:11:52 --> URI Class Initialized
INFO - 2023-02-28 10:11:52 --> Router Class Initialized
INFO - 2023-02-28 10:11:52 --> Output Class Initialized
INFO - 2023-02-28 10:11:52 --> Security Class Initialized
DEBUG - 2023-02-28 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:11:52 --> Input Class Initialized
INFO - 2023-02-28 10:11:52 --> Language Class Initialized
INFO - 2023-02-28 10:11:52 --> Loader Class Initialized
INFO - 2023-02-28 10:11:52 --> Controller Class Initialized
DEBUG - 2023-02-28 10:11:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:11:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:11:52 --> Model "Login_model" initialized
INFO - 2023-02-28 10:11:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:11:52 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:11:52 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:11:52 --> Final output sent to browser
DEBUG - 2023-02-28 10:11:52 --> Total execution time: 0.0685
INFO - 2023-02-28 10:11:52 --> Final output sent to browser
DEBUG - 2023-02-28 10:11:52 --> Total execution time: 0.0231
INFO - 2023-02-28 10:11:57 --> Config Class Initialized
INFO - 2023-02-28 10:11:57 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:11:57 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:11:57 --> Utf8 Class Initialized
INFO - 2023-02-28 10:11:57 --> URI Class Initialized
INFO - 2023-02-28 10:11:57 --> Router Class Initialized
INFO - 2023-02-28 10:11:57 --> Output Class Initialized
INFO - 2023-02-28 10:11:57 --> Security Class Initialized
DEBUG - 2023-02-28 10:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:11:57 --> Input Class Initialized
INFO - 2023-02-28 10:11:57 --> Language Class Initialized
INFO - 2023-02-28 10:11:57 --> Loader Class Initialized
INFO - 2023-02-28 10:11:57 --> Controller Class Initialized
DEBUG - 2023-02-28 10:11:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:11:57 --> Database Driver Class Initialized
INFO - 2023-02-28 10:11:57 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:11:57 --> Database Driver Class Initialized
INFO - 2023-02-28 10:11:57 --> Model "Login_model" initialized
INFO - 2023-02-28 10:11:57 --> Final output sent to browser
DEBUG - 2023-02-28 10:11:57 --> Total execution time: 0.1460
INFO - 2023-02-28 10:11:57 --> Config Class Initialized
INFO - 2023-02-28 10:11:57 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:11:57 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:11:57 --> Utf8 Class Initialized
INFO - 2023-02-28 10:11:57 --> URI Class Initialized
INFO - 2023-02-28 10:11:57 --> Router Class Initialized
INFO - 2023-02-28 10:11:57 --> Output Class Initialized
INFO - 2023-02-28 10:11:57 --> Security Class Initialized
DEBUG - 2023-02-28 10:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:11:57 --> Input Class Initialized
INFO - 2023-02-28 10:11:57 --> Language Class Initialized
INFO - 2023-02-28 10:11:57 --> Loader Class Initialized
INFO - 2023-02-28 10:11:57 --> Controller Class Initialized
DEBUG - 2023-02-28 10:11:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:11:57 --> Database Driver Class Initialized
INFO - 2023-02-28 10:11:57 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:11:57 --> Database Driver Class Initialized
INFO - 2023-02-28 10:11:57 --> Model "Login_model" initialized
INFO - 2023-02-28 10:11:57 --> Final output sent to browser
DEBUG - 2023-02-28 10:11:57 --> Total execution time: 0.0812
INFO - 2023-02-28 10:32:58 --> Config Class Initialized
INFO - 2023-02-28 10:32:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:32:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:32:58 --> Utf8 Class Initialized
INFO - 2023-02-28 10:32:58 --> URI Class Initialized
INFO - 2023-02-28 10:32:58 --> Router Class Initialized
INFO - 2023-02-28 10:32:58 --> Output Class Initialized
INFO - 2023-02-28 10:32:58 --> Security Class Initialized
DEBUG - 2023-02-28 10:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:32:58 --> Input Class Initialized
INFO - 2023-02-28 10:32:58 --> Language Class Initialized
INFO - 2023-02-28 10:32:58 --> Loader Class Initialized
INFO - 2023-02-28 10:32:58 --> Controller Class Initialized
INFO - 2023-02-28 10:32:58 --> Helper loaded: form_helper
INFO - 2023-02-28 10:32:58 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:32:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:32:58 --> Model "Change_model" initialized
INFO - 2023-02-28 10:32:58 --> Model "Grafana_model" initialized
INFO - 2023-02-28 10:32:58 --> Final output sent to browser
DEBUG - 2023-02-28 10:32:58 --> Total execution time: 0.0869
INFO - 2023-02-28 10:32:58 --> Config Class Initialized
INFO - 2023-02-28 10:32:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:32:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:32:58 --> Utf8 Class Initialized
INFO - 2023-02-28 10:32:58 --> URI Class Initialized
INFO - 2023-02-28 10:32:58 --> Router Class Initialized
INFO - 2023-02-28 10:32:58 --> Output Class Initialized
INFO - 2023-02-28 10:32:58 --> Security Class Initialized
DEBUG - 2023-02-28 10:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:32:58 --> Input Class Initialized
INFO - 2023-02-28 10:32:58 --> Language Class Initialized
INFO - 2023-02-28 10:32:58 --> Loader Class Initialized
INFO - 2023-02-28 10:32:58 --> Controller Class Initialized
INFO - 2023-02-28 10:32:58 --> Helper loaded: form_helper
INFO - 2023-02-28 10:32:58 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:32:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:32:58 --> Final output sent to browser
DEBUG - 2023-02-28 10:32:58 --> Total execution time: 0.0445
INFO - 2023-02-28 10:32:58 --> Config Class Initialized
INFO - 2023-02-28 10:32:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:32:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:32:58 --> Utf8 Class Initialized
INFO - 2023-02-28 10:32:58 --> URI Class Initialized
INFO - 2023-02-28 10:32:58 --> Router Class Initialized
INFO - 2023-02-28 10:32:58 --> Output Class Initialized
INFO - 2023-02-28 10:32:58 --> Security Class Initialized
DEBUG - 2023-02-28 10:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:32:58 --> Input Class Initialized
INFO - 2023-02-28 10:32:58 --> Language Class Initialized
INFO - 2023-02-28 10:32:58 --> Loader Class Initialized
INFO - 2023-02-28 10:32:58 --> Controller Class Initialized
INFO - 2023-02-28 10:32:58 --> Helper loaded: form_helper
INFO - 2023-02-28 10:32:58 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:32:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:32:58 --> Database Driver Class Initialized
INFO - 2023-02-28 10:32:58 --> Model "Login_model" initialized
INFO - 2023-02-28 10:32:58 --> Final output sent to browser
DEBUG - 2023-02-28 10:32:58 --> Total execution time: 0.0158
INFO - 2023-02-28 10:32:58 --> Config Class Initialized
INFO - 2023-02-28 10:32:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:32:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:32:58 --> Utf8 Class Initialized
INFO - 2023-02-28 10:32:58 --> URI Class Initialized
INFO - 2023-02-28 10:32:58 --> Router Class Initialized
INFO - 2023-02-28 10:32:58 --> Output Class Initialized
INFO - 2023-02-28 10:32:58 --> Security Class Initialized
DEBUG - 2023-02-28 10:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:32:58 --> Input Class Initialized
INFO - 2023-02-28 10:32:58 --> Language Class Initialized
INFO - 2023-02-28 10:32:58 --> Loader Class Initialized
INFO - 2023-02-28 10:32:58 --> Controller Class Initialized
DEBUG - 2023-02-28 10:32:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:32:58 --> Database Driver Class Initialized
INFO - 2023-02-28 10:32:58 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:32:58 --> Final output sent to browser
DEBUG - 2023-02-28 10:32:58 --> Total execution time: 0.0457
INFO - 2023-02-28 10:32:58 --> Config Class Initialized
INFO - 2023-02-28 10:32:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:32:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:32:58 --> Utf8 Class Initialized
INFO - 2023-02-28 10:32:58 --> URI Class Initialized
INFO - 2023-02-28 10:32:58 --> Router Class Initialized
INFO - 2023-02-28 10:32:58 --> Output Class Initialized
INFO - 2023-02-28 10:32:58 --> Security Class Initialized
DEBUG - 2023-02-28 10:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:32:58 --> Input Class Initialized
INFO - 2023-02-28 10:32:58 --> Language Class Initialized
INFO - 2023-02-28 10:32:58 --> Loader Class Initialized
INFO - 2023-02-28 10:32:58 --> Controller Class Initialized
DEBUG - 2023-02-28 10:32:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:32:58 --> Database Driver Class Initialized
INFO - 2023-02-28 10:32:58 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:32:58 --> Final output sent to browser
DEBUG - 2023-02-28 10:32:58 --> Total execution time: 0.0396
INFO - 2023-02-28 10:32:58 --> Config Class Initialized
INFO - 2023-02-28 10:32:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:32:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:32:58 --> Utf8 Class Initialized
INFO - 2023-02-28 10:32:58 --> URI Class Initialized
INFO - 2023-02-28 10:32:58 --> Router Class Initialized
INFO - 2023-02-28 10:32:58 --> Output Class Initialized
INFO - 2023-02-28 10:32:58 --> Security Class Initialized
DEBUG - 2023-02-28 10:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:32:58 --> Input Class Initialized
INFO - 2023-02-28 10:32:58 --> Language Class Initialized
INFO - 2023-02-28 10:32:58 --> Loader Class Initialized
INFO - 2023-02-28 10:32:58 --> Controller Class Initialized
DEBUG - 2023-02-28 10:32:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:32:58 --> Database Driver Class Initialized
INFO - 2023-02-28 10:32:58 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:32:58 --> Database Driver Class Initialized
INFO - 2023-02-28 10:32:58 --> Model "Login_model" initialized
INFO - 2023-02-28 10:32:58 --> Final output sent to browser
DEBUG - 2023-02-28 10:32:58 --> Total execution time: 0.0805
INFO - 2023-02-28 10:32:58 --> Config Class Initialized
INFO - 2023-02-28 10:32:58 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:32:58 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:32:58 --> Utf8 Class Initialized
INFO - 2023-02-28 10:32:58 --> URI Class Initialized
INFO - 2023-02-28 10:32:58 --> Router Class Initialized
INFO - 2023-02-28 10:32:58 --> Output Class Initialized
INFO - 2023-02-28 10:32:58 --> Security Class Initialized
DEBUG - 2023-02-28 10:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:32:58 --> Input Class Initialized
INFO - 2023-02-28 10:32:58 --> Language Class Initialized
INFO - 2023-02-28 10:32:58 --> Loader Class Initialized
INFO - 2023-02-28 10:32:58 --> Controller Class Initialized
DEBUG - 2023-02-28 10:32:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:32:58 --> Database Driver Class Initialized
INFO - 2023-02-28 10:32:58 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:32:58 --> Database Driver Class Initialized
INFO - 2023-02-28 10:32:58 --> Model "Login_model" initialized
INFO - 2023-02-28 10:32:58 --> Final output sent to browser
DEBUG - 2023-02-28 10:32:58 --> Total execution time: 0.0815
INFO - 2023-02-28 10:33:01 --> Config Class Initialized
INFO - 2023-02-28 10:33:01 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:01 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:01 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:01 --> URI Class Initialized
INFO - 2023-02-28 10:33:01 --> Router Class Initialized
INFO - 2023-02-28 10:33:01 --> Output Class Initialized
INFO - 2023-02-28 10:33:01 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:01 --> Input Class Initialized
INFO - 2023-02-28 10:33:01 --> Language Class Initialized
INFO - 2023-02-28 10:33:01 --> Loader Class Initialized
INFO - 2023-02-28 10:33:01 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:01 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:01 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:33:01 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:01 --> Total execution time: 0.0381
INFO - 2023-02-28 10:33:01 --> Config Class Initialized
INFO - 2023-02-28 10:33:01 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:01 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:01 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:01 --> URI Class Initialized
INFO - 2023-02-28 10:33:01 --> Router Class Initialized
INFO - 2023-02-28 10:33:01 --> Output Class Initialized
INFO - 2023-02-28 10:33:01 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:01 --> Input Class Initialized
INFO - 2023-02-28 10:33:01 --> Language Class Initialized
INFO - 2023-02-28 10:33:01 --> Loader Class Initialized
INFO - 2023-02-28 10:33:01 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:01 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:01 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:33:01 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:01 --> Total execution time: 0.0553
INFO - 2023-02-28 10:33:02 --> Config Class Initialized
INFO - 2023-02-28 10:33:02 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:02 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:02 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:02 --> URI Class Initialized
INFO - 2023-02-28 10:33:02 --> Router Class Initialized
INFO - 2023-02-28 10:33:02 --> Output Class Initialized
INFO - 2023-02-28 10:33:02 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:02 --> Input Class Initialized
INFO - 2023-02-28 10:33:02 --> Language Class Initialized
INFO - 2023-02-28 10:33:02 --> Loader Class Initialized
INFO - 2023-02-28 10:33:02 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:02 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:02 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:33:02 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:02 --> Total execution time: 0.0151
INFO - 2023-02-28 10:33:02 --> Config Class Initialized
INFO - 2023-02-28 10:33:02 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:02 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:02 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:02 --> URI Class Initialized
INFO - 2023-02-28 10:33:02 --> Router Class Initialized
INFO - 2023-02-28 10:33:02 --> Output Class Initialized
INFO - 2023-02-28 10:33:02 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:02 --> Input Class Initialized
INFO - 2023-02-28 10:33:02 --> Language Class Initialized
INFO - 2023-02-28 10:33:02 --> Loader Class Initialized
INFO - 2023-02-28 10:33:02 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:02 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:02 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:33:02 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:02 --> Total execution time: 0.0548
INFO - 2023-02-28 10:33:03 --> Config Class Initialized
INFO - 2023-02-28 10:33:03 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:03 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:03 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:03 --> URI Class Initialized
INFO - 2023-02-28 10:33:03 --> Router Class Initialized
INFO - 2023-02-28 10:33:03 --> Output Class Initialized
INFO - 2023-02-28 10:33:03 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:03 --> Input Class Initialized
INFO - 2023-02-28 10:33:03 --> Language Class Initialized
INFO - 2023-02-28 10:33:03 --> Loader Class Initialized
INFO - 2023-02-28 10:33:03 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:03 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:03 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:03 --> Model "Login_model" initialized
INFO - 2023-02-28 10:33:03 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:03 --> Total execution time: 0.0239
INFO - 2023-02-28 10:33:04 --> Config Class Initialized
INFO - 2023-02-28 10:33:04 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:04 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:04 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:04 --> URI Class Initialized
INFO - 2023-02-28 10:33:04 --> Router Class Initialized
INFO - 2023-02-28 10:33:04 --> Output Class Initialized
INFO - 2023-02-28 10:33:04 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:04 --> Input Class Initialized
INFO - 2023-02-28 10:33:04 --> Language Class Initialized
INFO - 2023-02-28 10:33:04 --> Loader Class Initialized
INFO - 2023-02-28 10:33:04 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:04 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:04 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:04 --> Model "Login_model" initialized
INFO - 2023-02-28 10:33:04 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:04 --> Total execution time: 0.0603
INFO - 2023-02-28 10:33:25 --> Config Class Initialized
INFO - 2023-02-28 10:33:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:25 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:25 --> URI Class Initialized
INFO - 2023-02-28 10:33:25 --> Router Class Initialized
INFO - 2023-02-28 10:33:25 --> Output Class Initialized
INFO - 2023-02-28 10:33:25 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:25 --> Input Class Initialized
INFO - 2023-02-28 10:33:25 --> Language Class Initialized
INFO - 2023-02-28 10:33:25 --> Loader Class Initialized
INFO - 2023-02-28 10:33:25 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:25 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:25 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:25 --> Total execution time: 0.0104
INFO - 2023-02-28 10:33:25 --> Config Class Initialized
INFO - 2023-02-28 10:33:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:25 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:25 --> URI Class Initialized
INFO - 2023-02-28 10:33:25 --> Router Class Initialized
INFO - 2023-02-28 10:33:25 --> Output Class Initialized
INFO - 2023-02-28 10:33:25 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:25 --> Input Class Initialized
INFO - 2023-02-28 10:33:25 --> Language Class Initialized
INFO - 2023-02-28 10:33:25 --> Loader Class Initialized
INFO - 2023-02-28 10:33:25 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:25 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:25 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:25 --> Model "Login_model" initialized
INFO - 2023-02-28 10:33:25 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:25 --> Total execution time: 0.0226
INFO - 2023-02-28 10:33:44 --> Config Class Initialized
INFO - 2023-02-28 10:33:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:44 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:44 --> URI Class Initialized
INFO - 2023-02-28 10:33:44 --> Router Class Initialized
INFO - 2023-02-28 10:33:44 --> Output Class Initialized
INFO - 2023-02-28 10:33:44 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:44 --> Input Class Initialized
INFO - 2023-02-28 10:33:44 --> Language Class Initialized
INFO - 2023-02-28 10:33:44 --> Loader Class Initialized
INFO - 2023-02-28 10:33:44 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:44 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:44 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:44 --> Total execution time: 0.0145
INFO - 2023-02-28 10:33:44 --> Config Class Initialized
INFO - 2023-02-28 10:33:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:44 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:44 --> URI Class Initialized
INFO - 2023-02-28 10:33:44 --> Router Class Initialized
INFO - 2023-02-28 10:33:44 --> Output Class Initialized
INFO - 2023-02-28 10:33:44 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:44 --> Input Class Initialized
INFO - 2023-02-28 10:33:44 --> Language Class Initialized
INFO - 2023-02-28 10:33:44 --> Loader Class Initialized
INFO - 2023-02-28 10:33:44 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:44 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:44 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:44 --> Model "Login_model" initialized
INFO - 2023-02-28 10:33:44 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:44 --> Total execution time: 0.0190
INFO - 2023-02-28 10:33:52 --> Config Class Initialized
INFO - 2023-02-28 10:33:52 --> Config Class Initialized
INFO - 2023-02-28 10:33:52 --> Hooks Class Initialized
INFO - 2023-02-28 10:33:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:52 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:33:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:52 --> URI Class Initialized
INFO - 2023-02-28 10:33:52 --> URI Class Initialized
INFO - 2023-02-28 10:33:52 --> Router Class Initialized
INFO - 2023-02-28 10:33:52 --> Router Class Initialized
INFO - 2023-02-28 10:33:52 --> Output Class Initialized
INFO - 2023-02-28 10:33:52 --> Output Class Initialized
INFO - 2023-02-28 10:33:52 --> Security Class Initialized
INFO - 2023-02-28 10:33:52 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 10:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:52 --> Input Class Initialized
INFO - 2023-02-28 10:33:52 --> Input Class Initialized
INFO - 2023-02-28 10:33:52 --> Language Class Initialized
INFO - 2023-02-28 10:33:52 --> Language Class Initialized
INFO - 2023-02-28 10:33:52 --> Loader Class Initialized
INFO - 2023-02-28 10:33:52 --> Loader Class Initialized
INFO - 2023-02-28 10:33:52 --> Controller Class Initialized
INFO - 2023-02-28 10:33:52 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:33:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:52 --> Final output sent to browser
INFO - 2023-02-28 10:33:52 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:52 --> Total execution time: 0.0142
DEBUG - 2023-02-28 10:33:52 --> Total execution time: 0.0142
INFO - 2023-02-28 10:33:52 --> Config Class Initialized
INFO - 2023-02-28 10:33:52 --> Config Class Initialized
INFO - 2023-02-28 10:33:52 --> Hooks Class Initialized
INFO - 2023-02-28 10:33:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:52 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:33:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:52 --> URI Class Initialized
INFO - 2023-02-28 10:33:52 --> URI Class Initialized
INFO - 2023-02-28 10:33:52 --> Router Class Initialized
INFO - 2023-02-28 10:33:52 --> Router Class Initialized
INFO - 2023-02-28 10:33:52 --> Output Class Initialized
INFO - 2023-02-28 10:33:52 --> Output Class Initialized
INFO - 2023-02-28 10:33:52 --> Security Class Initialized
INFO - 2023-02-28 10:33:52 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 10:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:52 --> Input Class Initialized
INFO - 2023-02-28 10:33:52 --> Input Class Initialized
INFO - 2023-02-28 10:33:52 --> Language Class Initialized
INFO - 2023-02-28 10:33:52 --> Language Class Initialized
INFO - 2023-02-28 10:33:52 --> Loader Class Initialized
INFO - 2023-02-28 10:33:52 --> Loader Class Initialized
INFO - 2023-02-28 10:33:52 --> Controller Class Initialized
INFO - 2023-02-28 10:33:52 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:33:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:52 --> Model "Login_model" initialized
INFO - 2023-02-28 10:33:52 --> Model "Login_model" initialized
INFO - 2023-02-28 10:33:52 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:52 --> Total execution time: 0.0260
INFO - 2023-02-28 10:33:52 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:52 --> Total execution time: 0.0285
INFO - 2023-02-28 10:33:52 --> Config Class Initialized
INFO - 2023-02-28 10:33:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:52 --> URI Class Initialized
INFO - 2023-02-28 10:33:52 --> Router Class Initialized
INFO - 2023-02-28 10:33:52 --> Output Class Initialized
INFO - 2023-02-28 10:33:52 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:52 --> Input Class Initialized
INFO - 2023-02-28 10:33:52 --> Language Class Initialized
INFO - 2023-02-28 10:33:52 --> Loader Class Initialized
INFO - 2023-02-28 10:33:52 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:52 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:52 --> Total execution time: 0.0085
INFO - 2023-02-28 10:33:52 --> Config Class Initialized
INFO - 2023-02-28 10:33:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:33:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:33:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:33:52 --> URI Class Initialized
INFO - 2023-02-28 10:33:52 --> Router Class Initialized
INFO - 2023-02-28 10:33:52 --> Output Class Initialized
INFO - 2023-02-28 10:33:52 --> Security Class Initialized
DEBUG - 2023-02-28 10:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:33:52 --> Input Class Initialized
INFO - 2023-02-28 10:33:52 --> Language Class Initialized
INFO - 2023-02-28 10:33:52 --> Loader Class Initialized
INFO - 2023-02-28 10:33:52 --> Controller Class Initialized
DEBUG - 2023-02-28 10:33:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:33:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:33:53 --> Final output sent to browser
DEBUG - 2023-02-28 10:33:53 --> Total execution time: 0.3637
INFO - 2023-02-28 10:34:22 --> Config Class Initialized
INFO - 2023-02-28 10:34:22 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:34:22 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:34:22 --> Utf8 Class Initialized
INFO - 2023-02-28 10:34:22 --> URI Class Initialized
INFO - 2023-02-28 10:34:22 --> Router Class Initialized
INFO - 2023-02-28 10:34:22 --> Output Class Initialized
INFO - 2023-02-28 10:34:22 --> Security Class Initialized
DEBUG - 2023-02-28 10:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:34:22 --> Input Class Initialized
INFO - 2023-02-28 10:34:22 --> Language Class Initialized
INFO - 2023-02-28 10:34:22 --> Loader Class Initialized
INFO - 2023-02-28 10:34:22 --> Controller Class Initialized
DEBUG - 2023-02-28 10:34:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:34:22 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:22 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:22 --> Model "Login_model" initialized
INFO - 2023-02-28 10:34:22 --> Final output sent to browser
DEBUG - 2023-02-28 10:34:22 --> Total execution time: 0.1158
INFO - 2023-02-28 10:34:22 --> Config Class Initialized
INFO - 2023-02-28 10:34:22 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:34:22 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:34:22 --> Utf8 Class Initialized
INFO - 2023-02-28 10:34:22 --> URI Class Initialized
INFO - 2023-02-28 10:34:22 --> Router Class Initialized
INFO - 2023-02-28 10:34:22 --> Output Class Initialized
INFO - 2023-02-28 10:34:22 --> Security Class Initialized
DEBUG - 2023-02-28 10:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:34:22 --> Input Class Initialized
INFO - 2023-02-28 10:34:22 --> Language Class Initialized
INFO - 2023-02-28 10:34:22 --> Loader Class Initialized
INFO - 2023-02-28 10:34:22 --> Controller Class Initialized
DEBUG - 2023-02-28 10:34:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:34:22 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:22 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:22 --> Model "Login_model" initialized
INFO - 2023-02-28 10:34:22 --> Final output sent to browser
DEBUG - 2023-02-28 10:34:22 --> Total execution time: 0.0297
INFO - 2023-02-28 10:34:30 --> Config Class Initialized
INFO - 2023-02-28 10:34:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:34:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:34:30 --> Utf8 Class Initialized
INFO - 2023-02-28 10:34:30 --> URI Class Initialized
INFO - 2023-02-28 10:34:30 --> Router Class Initialized
INFO - 2023-02-28 10:34:30 --> Output Class Initialized
INFO - 2023-02-28 10:34:30 --> Security Class Initialized
DEBUG - 2023-02-28 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:34:30 --> Input Class Initialized
INFO - 2023-02-28 10:34:30 --> Language Class Initialized
INFO - 2023-02-28 10:34:30 --> Loader Class Initialized
INFO - 2023-02-28 10:34:30 --> Controller Class Initialized
DEBUG - 2023-02-28 10:34:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:34:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:30 --> Final output sent to browser
DEBUG - 2023-02-28 10:34:30 --> Total execution time: 0.0172
INFO - 2023-02-28 10:34:30 --> Config Class Initialized
INFO - 2023-02-28 10:34:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:34:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:34:30 --> Utf8 Class Initialized
INFO - 2023-02-28 10:34:30 --> URI Class Initialized
INFO - 2023-02-28 10:34:30 --> Router Class Initialized
INFO - 2023-02-28 10:34:30 --> Output Class Initialized
INFO - 2023-02-28 10:34:30 --> Security Class Initialized
DEBUG - 2023-02-28 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:34:30 --> Input Class Initialized
INFO - 2023-02-28 10:34:30 --> Language Class Initialized
INFO - 2023-02-28 10:34:30 --> Loader Class Initialized
INFO - 2023-02-28 10:34:30 --> Controller Class Initialized
DEBUG - 2023-02-28 10:34:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:34:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:30 --> Model "Login_model" initialized
INFO - 2023-02-28 10:34:30 --> Final output sent to browser
DEBUG - 2023-02-28 10:34:30 --> Total execution time: 0.0346
INFO - 2023-02-28 10:34:30 --> Config Class Initialized
INFO - 2023-02-28 10:34:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:34:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:34:30 --> Utf8 Class Initialized
INFO - 2023-02-28 10:34:30 --> URI Class Initialized
INFO - 2023-02-28 10:34:30 --> Router Class Initialized
INFO - 2023-02-28 10:34:30 --> Output Class Initialized
INFO - 2023-02-28 10:34:30 --> Security Class Initialized
DEBUG - 2023-02-28 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:34:30 --> Input Class Initialized
INFO - 2023-02-28 10:34:30 --> Language Class Initialized
INFO - 2023-02-28 10:34:30 --> Loader Class Initialized
INFO - 2023-02-28 10:34:30 --> Controller Class Initialized
DEBUG - 2023-02-28 10:34:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:34:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:30 --> Model "Login_model" initialized
INFO - 2023-02-28 10:34:30 --> Final output sent to browser
DEBUG - 2023-02-28 10:34:30 --> Total execution time: 0.1055
INFO - 2023-02-28 10:34:30 --> Config Class Initialized
INFO - 2023-02-28 10:34:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:34:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:34:30 --> Utf8 Class Initialized
INFO - 2023-02-28 10:34:30 --> URI Class Initialized
INFO - 2023-02-28 10:34:30 --> Router Class Initialized
INFO - 2023-02-28 10:34:30 --> Output Class Initialized
INFO - 2023-02-28 10:34:30 --> Security Class Initialized
DEBUG - 2023-02-28 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:34:30 --> Input Class Initialized
INFO - 2023-02-28 10:34:30 --> Language Class Initialized
INFO - 2023-02-28 10:34:30 --> Loader Class Initialized
INFO - 2023-02-28 10:34:30 --> Controller Class Initialized
DEBUG - 2023-02-28 10:34:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:34:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:30 --> Model "Login_model" initialized
INFO - 2023-02-28 10:34:30 --> Final output sent to browser
DEBUG - 2023-02-28 10:34:30 --> Total execution time: 0.0226
INFO - 2023-02-28 10:34:34 --> Config Class Initialized
INFO - 2023-02-28 10:34:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:34:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:34:34 --> Utf8 Class Initialized
INFO - 2023-02-28 10:34:34 --> URI Class Initialized
INFO - 2023-02-28 10:34:34 --> Router Class Initialized
INFO - 2023-02-28 10:34:34 --> Output Class Initialized
INFO - 2023-02-28 10:34:34 --> Security Class Initialized
DEBUG - 2023-02-28 10:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:34:34 --> Input Class Initialized
INFO - 2023-02-28 10:34:34 --> Language Class Initialized
INFO - 2023-02-28 10:34:34 --> Loader Class Initialized
INFO - 2023-02-28 10:34:34 --> Controller Class Initialized
DEBUG - 2023-02-28 10:34:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:34:34 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:34:34 --> Final output sent to browser
DEBUG - 2023-02-28 10:34:34 --> Total execution time: 0.0519
INFO - 2023-02-28 10:34:34 --> Config Class Initialized
INFO - 2023-02-28 10:34:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:34:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:34:34 --> Utf8 Class Initialized
INFO - 2023-02-28 10:34:34 --> URI Class Initialized
INFO - 2023-02-28 10:34:34 --> Router Class Initialized
INFO - 2023-02-28 10:34:34 --> Output Class Initialized
INFO - 2023-02-28 10:34:34 --> Security Class Initialized
DEBUG - 2023-02-28 10:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:34:34 --> Input Class Initialized
INFO - 2023-02-28 10:34:34 --> Language Class Initialized
INFO - 2023-02-28 10:34:34 --> Loader Class Initialized
INFO - 2023-02-28 10:34:34 --> Controller Class Initialized
DEBUG - 2023-02-28 10:34:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:34:34 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:34 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:34:34 --> Final output sent to browser
DEBUG - 2023-02-28 10:34:34 --> Total execution time: 0.0123
INFO - 2023-02-28 10:34:36 --> Config Class Initialized
INFO - 2023-02-28 10:34:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:34:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:34:36 --> Utf8 Class Initialized
INFO - 2023-02-28 10:34:36 --> URI Class Initialized
INFO - 2023-02-28 10:34:36 --> Router Class Initialized
INFO - 2023-02-28 10:34:36 --> Output Class Initialized
INFO - 2023-02-28 10:34:36 --> Security Class Initialized
DEBUG - 2023-02-28 10:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:34:36 --> Input Class Initialized
INFO - 2023-02-28 10:34:36 --> Language Class Initialized
INFO - 2023-02-28 10:34:36 --> Loader Class Initialized
INFO - 2023-02-28 10:34:36 --> Controller Class Initialized
DEBUG - 2023-02-28 10:34:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:34:36 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:36 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:36 --> Model "Login_model" initialized
INFO - 2023-02-28 10:34:36 --> Final output sent to browser
DEBUG - 2023-02-28 10:34:36 --> Total execution time: 0.1738
INFO - 2023-02-28 10:34:36 --> Config Class Initialized
INFO - 2023-02-28 10:34:36 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:34:36 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:34:36 --> Utf8 Class Initialized
INFO - 2023-02-28 10:34:36 --> URI Class Initialized
INFO - 2023-02-28 10:34:36 --> Router Class Initialized
INFO - 2023-02-28 10:34:36 --> Output Class Initialized
INFO - 2023-02-28 10:34:36 --> Security Class Initialized
DEBUG - 2023-02-28 10:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:34:36 --> Input Class Initialized
INFO - 2023-02-28 10:34:36 --> Language Class Initialized
INFO - 2023-02-28 10:34:36 --> Loader Class Initialized
INFO - 2023-02-28 10:34:36 --> Controller Class Initialized
DEBUG - 2023-02-28 10:34:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:34:36 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:36 --> Database Driver Class Initialized
INFO - 2023-02-28 10:34:36 --> Model "Login_model" initialized
INFO - 2023-02-28 10:34:36 --> Final output sent to browser
DEBUG - 2023-02-28 10:34:36 --> Total execution time: 0.0227
INFO - 2023-02-28 10:41:34 --> Config Class Initialized
INFO - 2023-02-28 10:41:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:41:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:41:34 --> Utf8 Class Initialized
INFO - 2023-02-28 10:41:34 --> URI Class Initialized
INFO - 2023-02-28 10:41:34 --> Router Class Initialized
INFO - 2023-02-28 10:41:34 --> Output Class Initialized
INFO - 2023-02-28 10:41:34 --> Security Class Initialized
DEBUG - 2023-02-28 10:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:41:34 --> Input Class Initialized
INFO - 2023-02-28 10:41:34 --> Language Class Initialized
INFO - 2023-02-28 10:41:34 --> Loader Class Initialized
INFO - 2023-02-28 10:41:34 --> Controller Class Initialized
DEBUG - 2023-02-28 10:41:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:41:34 --> Database Driver Class Initialized
INFO - 2023-02-28 10:41:34 --> Final output sent to browser
DEBUG - 2023-02-28 10:41:34 --> Total execution time: 0.0144
INFO - 2023-02-28 10:41:34 --> Config Class Initialized
INFO - 2023-02-28 10:41:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:41:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:41:34 --> Utf8 Class Initialized
INFO - 2023-02-28 10:41:34 --> URI Class Initialized
INFO - 2023-02-28 10:41:34 --> Router Class Initialized
INFO - 2023-02-28 10:41:34 --> Output Class Initialized
INFO - 2023-02-28 10:41:34 --> Security Class Initialized
DEBUG - 2023-02-28 10:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:41:34 --> Input Class Initialized
INFO - 2023-02-28 10:41:34 --> Language Class Initialized
INFO - 2023-02-28 10:41:34 --> Loader Class Initialized
INFO - 2023-02-28 10:41:34 --> Controller Class Initialized
DEBUG - 2023-02-28 10:41:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:41:34 --> Database Driver Class Initialized
INFO - 2023-02-28 10:41:34 --> Database Driver Class Initialized
INFO - 2023-02-28 10:41:34 --> Model "Login_model" initialized
INFO - 2023-02-28 10:41:34 --> Final output sent to browser
DEBUG - 2023-02-28 10:41:34 --> Total execution time: 0.0250
INFO - 2023-02-28 10:41:37 --> Config Class Initialized
INFO - 2023-02-28 10:41:37 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:41:37 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:41:37 --> Utf8 Class Initialized
INFO - 2023-02-28 10:41:37 --> URI Class Initialized
INFO - 2023-02-28 10:41:37 --> Router Class Initialized
INFO - 2023-02-28 10:41:37 --> Output Class Initialized
INFO - 2023-02-28 10:41:37 --> Security Class Initialized
DEBUG - 2023-02-28 10:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:41:37 --> Input Class Initialized
INFO - 2023-02-28 10:41:37 --> Language Class Initialized
INFO - 2023-02-28 10:41:37 --> Loader Class Initialized
INFO - 2023-02-28 10:41:37 --> Controller Class Initialized
DEBUG - 2023-02-28 10:41:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:41:37 --> Database Driver Class Initialized
INFO - 2023-02-28 10:41:37 --> Database Driver Class Initialized
INFO - 2023-02-28 10:41:37 --> Model "Login_model" initialized
INFO - 2023-02-28 10:41:37 --> Final output sent to browser
DEBUG - 2023-02-28 10:41:37 --> Total execution time: 0.0719
INFO - 2023-02-28 10:41:59 --> Config Class Initialized
INFO - 2023-02-28 10:41:59 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:41:59 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:41:59 --> Utf8 Class Initialized
INFO - 2023-02-28 10:41:59 --> URI Class Initialized
INFO - 2023-02-28 10:41:59 --> Router Class Initialized
INFO - 2023-02-28 10:41:59 --> Output Class Initialized
INFO - 2023-02-28 10:41:59 --> Security Class Initialized
DEBUG - 2023-02-28 10:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:41:59 --> Input Class Initialized
INFO - 2023-02-28 10:41:59 --> Language Class Initialized
INFO - 2023-02-28 10:41:59 --> Loader Class Initialized
INFO - 2023-02-28 10:41:59 --> Controller Class Initialized
DEBUG - 2023-02-28 10:41:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:41:59 --> Database Driver Class Initialized
INFO - 2023-02-28 10:41:59 --> Final output sent to browser
DEBUG - 2023-02-28 10:41:59 --> Total execution time: 0.0152
INFO - 2023-02-28 10:41:59 --> Config Class Initialized
INFO - 2023-02-28 10:41:59 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:41:59 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:41:59 --> Utf8 Class Initialized
INFO - 2023-02-28 10:41:59 --> URI Class Initialized
INFO - 2023-02-28 10:41:59 --> Router Class Initialized
INFO - 2023-02-28 10:41:59 --> Output Class Initialized
INFO - 2023-02-28 10:41:59 --> Security Class Initialized
DEBUG - 2023-02-28 10:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:41:59 --> Input Class Initialized
INFO - 2023-02-28 10:41:59 --> Language Class Initialized
INFO - 2023-02-28 10:41:59 --> Loader Class Initialized
INFO - 2023-02-28 10:41:59 --> Controller Class Initialized
DEBUG - 2023-02-28 10:41:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:41:59 --> Database Driver Class Initialized
INFO - 2023-02-28 10:41:59 --> Database Driver Class Initialized
INFO - 2023-02-28 10:41:59 --> Model "Login_model" initialized
INFO - 2023-02-28 10:41:59 --> Final output sent to browser
DEBUG - 2023-02-28 10:41:59 --> Total execution time: 0.0168
INFO - 2023-02-28 10:42:09 --> Config Class Initialized
INFO - 2023-02-28 10:42:09 --> Config Class Initialized
INFO - 2023-02-28 10:42:09 --> Hooks Class Initialized
INFO - 2023-02-28 10:42:09 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:42:09 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:42:09 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:42:09 --> Utf8 Class Initialized
INFO - 2023-02-28 10:42:09 --> Utf8 Class Initialized
INFO - 2023-02-28 10:42:09 --> URI Class Initialized
INFO - 2023-02-28 10:42:09 --> URI Class Initialized
INFO - 2023-02-28 10:42:09 --> Router Class Initialized
INFO - 2023-02-28 10:42:09 --> Router Class Initialized
INFO - 2023-02-28 10:42:09 --> Output Class Initialized
INFO - 2023-02-28 10:42:09 --> Output Class Initialized
INFO - 2023-02-28 10:42:09 --> Security Class Initialized
INFO - 2023-02-28 10:42:09 --> Security Class Initialized
DEBUG - 2023-02-28 10:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 10:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:42:09 --> Input Class Initialized
INFO - 2023-02-28 10:42:09 --> Input Class Initialized
INFO - 2023-02-28 10:42:09 --> Language Class Initialized
INFO - 2023-02-28 10:42:09 --> Language Class Initialized
INFO - 2023-02-28 10:42:09 --> Loader Class Initialized
INFO - 2023-02-28 10:42:09 --> Loader Class Initialized
INFO - 2023-02-28 10:42:09 --> Controller Class Initialized
INFO - 2023-02-28 10:42:09 --> Controller Class Initialized
DEBUG - 2023-02-28 10:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:42:09 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:09 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:09 --> Final output sent to browser
INFO - 2023-02-28 10:42:09 --> Final output sent to browser
DEBUG - 2023-02-28 10:42:09 --> Total execution time: 0.0136
DEBUG - 2023-02-28 10:42:09 --> Total execution time: 0.0136
INFO - 2023-02-28 10:42:09 --> Config Class Initialized
INFO - 2023-02-28 10:42:09 --> Config Class Initialized
INFO - 2023-02-28 10:42:09 --> Hooks Class Initialized
INFO - 2023-02-28 10:42:09 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:42:09 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:42:09 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:42:09 --> Utf8 Class Initialized
INFO - 2023-02-28 10:42:09 --> Utf8 Class Initialized
INFO - 2023-02-28 10:42:09 --> URI Class Initialized
INFO - 2023-02-28 10:42:09 --> URI Class Initialized
INFO - 2023-02-28 10:42:09 --> Router Class Initialized
INFO - 2023-02-28 10:42:09 --> Router Class Initialized
INFO - 2023-02-28 10:42:09 --> Output Class Initialized
INFO - 2023-02-28 10:42:09 --> Output Class Initialized
INFO - 2023-02-28 10:42:09 --> Security Class Initialized
INFO - 2023-02-28 10:42:09 --> Security Class Initialized
DEBUG - 2023-02-28 10:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 10:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:42:09 --> Input Class Initialized
INFO - 2023-02-28 10:42:09 --> Input Class Initialized
INFO - 2023-02-28 10:42:09 --> Language Class Initialized
INFO - 2023-02-28 10:42:09 --> Language Class Initialized
INFO - 2023-02-28 10:42:09 --> Loader Class Initialized
INFO - 2023-02-28 10:42:09 --> Loader Class Initialized
INFO - 2023-02-28 10:42:09 --> Controller Class Initialized
INFO - 2023-02-28 10:42:09 --> Controller Class Initialized
DEBUG - 2023-02-28 10:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:42:09 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:09 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:09 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:09 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:09 --> Model "Login_model" initialized
INFO - 2023-02-28 10:42:09 --> Model "Login_model" initialized
INFO - 2023-02-28 10:42:09 --> Final output sent to browser
INFO - 2023-02-28 10:42:09 --> Final output sent to browser
DEBUG - 2023-02-28 10:42:09 --> Total execution time: 0.0213
DEBUG - 2023-02-28 10:42:09 --> Total execution time: 0.0213
INFO - 2023-02-28 10:42:09 --> Config Class Initialized
INFO - 2023-02-28 10:42:09 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:42:09 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:42:09 --> Utf8 Class Initialized
INFO - 2023-02-28 10:42:09 --> URI Class Initialized
INFO - 2023-02-28 10:42:09 --> Router Class Initialized
INFO - 2023-02-28 10:42:09 --> Output Class Initialized
INFO - 2023-02-28 10:42:09 --> Security Class Initialized
DEBUG - 2023-02-28 10:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:42:09 --> Input Class Initialized
INFO - 2023-02-28 10:42:09 --> Language Class Initialized
INFO - 2023-02-28 10:42:09 --> Loader Class Initialized
INFO - 2023-02-28 10:42:09 --> Controller Class Initialized
DEBUG - 2023-02-28 10:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:42:09 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:09 --> Final output sent to browser
DEBUG - 2023-02-28 10:42:09 --> Total execution time: 0.0100
INFO - 2023-02-28 10:42:09 --> Config Class Initialized
INFO - 2023-02-28 10:42:09 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:42:09 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:42:09 --> Utf8 Class Initialized
INFO - 2023-02-28 10:42:09 --> URI Class Initialized
INFO - 2023-02-28 10:42:09 --> Router Class Initialized
INFO - 2023-02-28 10:42:09 --> Output Class Initialized
INFO - 2023-02-28 10:42:09 --> Security Class Initialized
DEBUG - 2023-02-28 10:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:42:09 --> Input Class Initialized
INFO - 2023-02-28 10:42:09 --> Language Class Initialized
INFO - 2023-02-28 10:42:09 --> Loader Class Initialized
INFO - 2023-02-28 10:42:09 --> Controller Class Initialized
DEBUG - 2023-02-28 10:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:42:09 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:10 --> Final output sent to browser
DEBUG - 2023-02-28 10:42:10 --> Total execution time: 1.0124
INFO - 2023-02-28 10:42:10 --> Config Class Initialized
INFO - 2023-02-28 10:42:10 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:42:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:42:10 --> Utf8 Class Initialized
INFO - 2023-02-28 10:42:10 --> URI Class Initialized
INFO - 2023-02-28 10:42:10 --> Router Class Initialized
INFO - 2023-02-28 10:42:10 --> Output Class Initialized
INFO - 2023-02-28 10:42:10 --> Security Class Initialized
DEBUG - 2023-02-28 10:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:42:10 --> Input Class Initialized
INFO - 2023-02-28 10:42:10 --> Language Class Initialized
INFO - 2023-02-28 10:42:10 --> Loader Class Initialized
INFO - 2023-02-28 10:42:10 --> Controller Class Initialized
DEBUG - 2023-02-28 10:42:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:42:10 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:10 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:10 --> Model "Login_model" initialized
INFO - 2023-02-28 10:42:10 --> Final output sent to browser
DEBUG - 2023-02-28 10:42:10 --> Total execution time: 0.0304
INFO - 2023-02-28 10:42:10 --> Config Class Initialized
INFO - 2023-02-28 10:42:10 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:42:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:42:10 --> Utf8 Class Initialized
INFO - 2023-02-28 10:42:10 --> URI Class Initialized
INFO - 2023-02-28 10:42:10 --> Router Class Initialized
INFO - 2023-02-28 10:42:10 --> Output Class Initialized
INFO - 2023-02-28 10:42:10 --> Security Class Initialized
DEBUG - 2023-02-28 10:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:42:10 --> Input Class Initialized
INFO - 2023-02-28 10:42:10 --> Language Class Initialized
INFO - 2023-02-28 10:42:10 --> Loader Class Initialized
INFO - 2023-02-28 10:42:10 --> Controller Class Initialized
DEBUG - 2023-02-28 10:42:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:42:10 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:10 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:10 --> Model "Login_model" initialized
INFO - 2023-02-28 10:42:10 --> Final output sent to browser
DEBUG - 2023-02-28 10:42:10 --> Total execution time: 0.0259
INFO - 2023-02-28 10:42:44 --> Config Class Initialized
INFO - 2023-02-28 10:42:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:42:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:42:44 --> Utf8 Class Initialized
INFO - 2023-02-28 10:42:44 --> URI Class Initialized
INFO - 2023-02-28 10:42:44 --> Router Class Initialized
INFO - 2023-02-28 10:42:44 --> Output Class Initialized
INFO - 2023-02-28 10:42:44 --> Security Class Initialized
DEBUG - 2023-02-28 10:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:42:44 --> Input Class Initialized
INFO - 2023-02-28 10:42:44 --> Language Class Initialized
INFO - 2023-02-28 10:42:44 --> Loader Class Initialized
INFO - 2023-02-28 10:42:44 --> Controller Class Initialized
INFO - 2023-02-28 10:42:44 --> Helper loaded: form_helper
INFO - 2023-02-28 10:42:44 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:42:44 --> Model "Change_model" initialized
INFO - 2023-02-28 10:42:44 --> Model "Grafana_model" initialized
INFO - 2023-02-28 10:42:44 --> Final output sent to browser
DEBUG - 2023-02-28 10:42:44 --> Total execution time: 0.0276
INFO - 2023-02-28 10:42:44 --> Config Class Initialized
INFO - 2023-02-28 10:42:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:42:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:42:44 --> Utf8 Class Initialized
INFO - 2023-02-28 10:42:44 --> URI Class Initialized
INFO - 2023-02-28 10:42:44 --> Router Class Initialized
INFO - 2023-02-28 10:42:44 --> Output Class Initialized
INFO - 2023-02-28 10:42:44 --> Security Class Initialized
DEBUG - 2023-02-28 10:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:42:44 --> Input Class Initialized
INFO - 2023-02-28 10:42:44 --> Language Class Initialized
INFO - 2023-02-28 10:42:44 --> Loader Class Initialized
INFO - 2023-02-28 10:42:44 --> Controller Class Initialized
INFO - 2023-02-28 10:42:44 --> Helper loaded: form_helper
INFO - 2023-02-28 10:42:44 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:42:44 --> Final output sent to browser
DEBUG - 2023-02-28 10:42:44 --> Total execution time: 0.0019
INFO - 2023-02-28 10:42:44 --> Config Class Initialized
INFO - 2023-02-28 10:42:44 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:42:44 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:42:44 --> Utf8 Class Initialized
INFO - 2023-02-28 10:42:44 --> URI Class Initialized
INFO - 2023-02-28 10:42:44 --> Router Class Initialized
INFO - 2023-02-28 10:42:44 --> Output Class Initialized
INFO - 2023-02-28 10:42:44 --> Security Class Initialized
DEBUG - 2023-02-28 10:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:42:44 --> Input Class Initialized
INFO - 2023-02-28 10:42:44 --> Language Class Initialized
INFO - 2023-02-28 10:42:44 --> Loader Class Initialized
INFO - 2023-02-28 10:42:44 --> Controller Class Initialized
INFO - 2023-02-28 10:42:44 --> Helper loaded: form_helper
INFO - 2023-02-28 10:42:44 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:42:44 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:44 --> Model "Login_model" initialized
INFO - 2023-02-28 10:42:44 --> Final output sent to browser
DEBUG - 2023-02-28 10:42:44 --> Total execution time: 0.0196
INFO - 2023-02-28 10:42:47 --> Config Class Initialized
INFO - 2023-02-28 10:42:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:42:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:42:47 --> Utf8 Class Initialized
INFO - 2023-02-28 10:42:47 --> URI Class Initialized
INFO - 2023-02-28 10:42:47 --> Router Class Initialized
INFO - 2023-02-28 10:42:47 --> Output Class Initialized
INFO - 2023-02-28 10:42:47 --> Security Class Initialized
DEBUG - 2023-02-28 10:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:42:47 --> Input Class Initialized
INFO - 2023-02-28 10:42:47 --> Language Class Initialized
INFO - 2023-02-28 10:42:47 --> Loader Class Initialized
INFO - 2023-02-28 10:42:47 --> Controller Class Initialized
INFO - 2023-02-28 10:42:47 --> Helper loaded: form_helper
INFO - 2023-02-28 10:42:47 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:42:47 --> Model "Change_model" initialized
INFO - 2023-02-28 10:42:47 --> Model "Grafana_model" initialized
INFO - 2023-02-28 10:42:47 --> Final output sent to browser
DEBUG - 2023-02-28 10:42:47 --> Total execution time: 0.0263
INFO - 2023-02-28 10:42:47 --> Config Class Initialized
INFO - 2023-02-28 10:42:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:42:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:42:47 --> Utf8 Class Initialized
INFO - 2023-02-28 10:42:47 --> URI Class Initialized
INFO - 2023-02-28 10:42:47 --> Router Class Initialized
INFO - 2023-02-28 10:42:47 --> Output Class Initialized
INFO - 2023-02-28 10:42:47 --> Security Class Initialized
DEBUG - 2023-02-28 10:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:42:47 --> Input Class Initialized
INFO - 2023-02-28 10:42:47 --> Language Class Initialized
INFO - 2023-02-28 10:42:47 --> Loader Class Initialized
INFO - 2023-02-28 10:42:47 --> Controller Class Initialized
INFO - 2023-02-28 10:42:47 --> Helper loaded: form_helper
INFO - 2023-02-28 10:42:47 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:42:47 --> Database Driver Class Initialized
INFO - 2023-02-28 10:42:47 --> Model "Login_model" initialized
INFO - 2023-02-28 10:42:47 --> Final output sent to browser
DEBUG - 2023-02-28 10:42:47 --> Total execution time: 0.0183
INFO - 2023-02-28 10:46:24 --> Config Class Initialized
INFO - 2023-02-28 10:46:24 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:24 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:24 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:24 --> URI Class Initialized
INFO - 2023-02-28 10:46:24 --> Router Class Initialized
INFO - 2023-02-28 10:46:24 --> Output Class Initialized
INFO - 2023-02-28 10:46:24 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:24 --> Input Class Initialized
INFO - 2023-02-28 10:46:24 --> Language Class Initialized
INFO - 2023-02-28 10:46:24 --> Loader Class Initialized
INFO - 2023-02-28 10:46:24 --> Controller Class Initialized
INFO - 2023-02-28 10:46:24 --> Helper loaded: form_helper
INFO - 2023-02-28 10:46:24 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:46:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:24 --> Model "Change_model" initialized
INFO - 2023-02-28 10:46:24 --> Model "Grafana_model" initialized
INFO - 2023-02-28 10:46:24 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:24 --> Total execution time: 0.0230
INFO - 2023-02-28 10:46:24 --> Config Class Initialized
INFO - 2023-02-28 10:46:24 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:24 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:24 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:24 --> URI Class Initialized
INFO - 2023-02-28 10:46:24 --> Router Class Initialized
INFO - 2023-02-28 10:46:24 --> Output Class Initialized
INFO - 2023-02-28 10:46:24 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:24 --> Input Class Initialized
INFO - 2023-02-28 10:46:24 --> Language Class Initialized
INFO - 2023-02-28 10:46:24 --> Loader Class Initialized
INFO - 2023-02-28 10:46:24 --> Controller Class Initialized
INFO - 2023-02-28 10:46:24 --> Helper loaded: form_helper
INFO - 2023-02-28 10:46:24 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:46:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:24 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:24 --> Total execution time: 0.0036
INFO - 2023-02-28 10:46:24 --> Config Class Initialized
INFO - 2023-02-28 10:46:24 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:24 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:24 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:24 --> URI Class Initialized
INFO - 2023-02-28 10:46:24 --> Router Class Initialized
INFO - 2023-02-28 10:46:24 --> Output Class Initialized
INFO - 2023-02-28 10:46:24 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:24 --> Input Class Initialized
INFO - 2023-02-28 10:46:24 --> Language Class Initialized
INFO - 2023-02-28 10:46:24 --> Loader Class Initialized
INFO - 2023-02-28 10:46:24 --> Controller Class Initialized
INFO - 2023-02-28 10:46:24 --> Helper loaded: form_helper
INFO - 2023-02-28 10:46:24 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:46:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:24 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:24 --> Model "Login_model" initialized
INFO - 2023-02-28 10:46:24 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:24 --> Total execution time: 0.0171
INFO - 2023-02-28 10:46:24 --> Config Class Initialized
INFO - 2023-02-28 10:46:24 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:24 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:24 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:24 --> URI Class Initialized
INFO - 2023-02-28 10:46:24 --> Router Class Initialized
INFO - 2023-02-28 10:46:24 --> Output Class Initialized
INFO - 2023-02-28 10:46:24 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:24 --> Input Class Initialized
INFO - 2023-02-28 10:46:24 --> Language Class Initialized
INFO - 2023-02-28 10:46:24 --> Loader Class Initialized
INFO - 2023-02-28 10:46:24 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:24 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:24 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:24 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:24 --> Total execution time: 0.0127
INFO - 2023-02-28 10:46:24 --> Config Class Initialized
INFO - 2023-02-28 10:46:24 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:24 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:24 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:24 --> URI Class Initialized
INFO - 2023-02-28 10:46:24 --> Router Class Initialized
INFO - 2023-02-28 10:46:24 --> Output Class Initialized
INFO - 2023-02-28 10:46:24 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:24 --> Input Class Initialized
INFO - 2023-02-28 10:46:24 --> Language Class Initialized
INFO - 2023-02-28 10:46:24 --> Loader Class Initialized
INFO - 2023-02-28 10:46:24 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:24 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:24 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:24 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:24 --> Total execution time: 0.0126
INFO - 2023-02-28 10:46:25 --> Config Class Initialized
INFO - 2023-02-28 10:46:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:25 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:25 --> URI Class Initialized
INFO - 2023-02-28 10:46:25 --> Router Class Initialized
INFO - 2023-02-28 10:46:25 --> Output Class Initialized
INFO - 2023-02-28 10:46:25 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:25 --> Input Class Initialized
INFO - 2023-02-28 10:46:25 --> Language Class Initialized
INFO - 2023-02-28 10:46:25 --> Loader Class Initialized
INFO - 2023-02-28 10:46:25 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:25 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:25 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:25 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:25 --> Model "Login_model" initialized
INFO - 2023-02-28 10:46:25 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:25 --> Total execution time: 0.0915
INFO - 2023-02-28 10:46:25 --> Config Class Initialized
INFO - 2023-02-28 10:46:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:25 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:25 --> URI Class Initialized
INFO - 2023-02-28 10:46:25 --> Router Class Initialized
INFO - 2023-02-28 10:46:25 --> Output Class Initialized
INFO - 2023-02-28 10:46:25 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:25 --> Input Class Initialized
INFO - 2023-02-28 10:46:25 --> Language Class Initialized
INFO - 2023-02-28 10:46:25 --> Loader Class Initialized
INFO - 2023-02-28 10:46:25 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:25 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:25 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:25 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:25 --> Model "Login_model" initialized
INFO - 2023-02-28 10:46:25 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:25 --> Total execution time: 0.0795
INFO - 2023-02-28 10:46:31 --> Config Class Initialized
INFO - 2023-02-28 10:46:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:31 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:31 --> URI Class Initialized
INFO - 2023-02-28 10:46:31 --> Router Class Initialized
INFO - 2023-02-28 10:46:31 --> Output Class Initialized
INFO - 2023-02-28 10:46:31 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:31 --> Input Class Initialized
INFO - 2023-02-28 10:46:31 --> Language Class Initialized
INFO - 2023-02-28 10:46:31 --> Loader Class Initialized
INFO - 2023-02-28 10:46:31 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:31 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:31 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:31 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:31 --> Total execution time: 0.0182
INFO - 2023-02-28 10:46:31 --> Config Class Initialized
INFO - 2023-02-28 10:46:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:31 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:31 --> URI Class Initialized
INFO - 2023-02-28 10:46:31 --> Router Class Initialized
INFO - 2023-02-28 10:46:31 --> Output Class Initialized
INFO - 2023-02-28 10:46:31 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:31 --> Input Class Initialized
INFO - 2023-02-28 10:46:31 --> Language Class Initialized
INFO - 2023-02-28 10:46:31 --> Loader Class Initialized
INFO - 2023-02-28 10:46:31 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:31 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:31 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:31 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:31 --> Total execution time: 0.0142
INFO - 2023-02-28 10:46:33 --> Config Class Initialized
INFO - 2023-02-28 10:46:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:33 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:33 --> URI Class Initialized
INFO - 2023-02-28 10:46:33 --> Router Class Initialized
INFO - 2023-02-28 10:46:33 --> Output Class Initialized
INFO - 2023-02-28 10:46:33 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:33 --> Input Class Initialized
INFO - 2023-02-28 10:46:33 --> Language Class Initialized
INFO - 2023-02-28 10:46:33 --> Loader Class Initialized
INFO - 2023-02-28 10:46:33 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:33 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:33 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:33 --> Total execution time: 0.0128
INFO - 2023-02-28 10:46:33 --> Config Class Initialized
INFO - 2023-02-28 10:46:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:33 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:33 --> URI Class Initialized
INFO - 2023-02-28 10:46:33 --> Router Class Initialized
INFO - 2023-02-28 10:46:33 --> Output Class Initialized
INFO - 2023-02-28 10:46:33 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:33 --> Input Class Initialized
INFO - 2023-02-28 10:46:33 --> Language Class Initialized
INFO - 2023-02-28 10:46:33 --> Loader Class Initialized
INFO - 2023-02-28 10:46:33 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:33 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:33 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:33 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:33 --> Total execution time: 0.0556
INFO - 2023-02-28 10:46:38 --> Config Class Initialized
INFO - 2023-02-28 10:46:38 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:38 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:38 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:38 --> URI Class Initialized
INFO - 2023-02-28 10:46:38 --> Router Class Initialized
INFO - 2023-02-28 10:46:38 --> Output Class Initialized
INFO - 2023-02-28 10:46:38 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:38 --> Input Class Initialized
INFO - 2023-02-28 10:46:38 --> Language Class Initialized
INFO - 2023-02-28 10:46:38 --> Loader Class Initialized
INFO - 2023-02-28 10:46:38 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:38 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:38 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:38 --> Model "Login_model" initialized
INFO - 2023-02-28 10:46:38 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:38 --> Total execution time: 0.0217
INFO - 2023-02-28 10:46:38 --> Config Class Initialized
INFO - 2023-02-28 10:46:38 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:38 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:38 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:38 --> URI Class Initialized
INFO - 2023-02-28 10:46:38 --> Router Class Initialized
INFO - 2023-02-28 10:46:38 --> Output Class Initialized
INFO - 2023-02-28 10:46:38 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:38 --> Input Class Initialized
INFO - 2023-02-28 10:46:38 --> Language Class Initialized
INFO - 2023-02-28 10:46:38 --> Loader Class Initialized
INFO - 2023-02-28 10:46:38 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:38 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:38 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:38 --> Model "Login_model" initialized
INFO - 2023-02-28 10:46:38 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:38 --> Total execution time: 0.0719
INFO - 2023-02-28 10:46:39 --> Config Class Initialized
INFO - 2023-02-28 10:46:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:39 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:39 --> URI Class Initialized
INFO - 2023-02-28 10:46:39 --> Router Class Initialized
INFO - 2023-02-28 10:46:39 --> Output Class Initialized
INFO - 2023-02-28 10:46:39 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:39 --> Input Class Initialized
INFO - 2023-02-28 10:46:39 --> Language Class Initialized
INFO - 2023-02-28 10:46:39 --> Loader Class Initialized
INFO - 2023-02-28 10:46:39 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:39 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:39 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:39 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:39 --> Total execution time: 0.0454
INFO - 2023-02-28 10:46:39 --> Config Class Initialized
INFO - 2023-02-28 10:46:39 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:39 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:39 --> URI Class Initialized
INFO - 2023-02-28 10:46:39 --> Router Class Initialized
INFO - 2023-02-28 10:46:39 --> Output Class Initialized
INFO - 2023-02-28 10:46:39 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:39 --> Input Class Initialized
INFO - 2023-02-28 10:46:39 --> Language Class Initialized
INFO - 2023-02-28 10:46:39 --> Loader Class Initialized
INFO - 2023-02-28 10:46:39 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:39 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:39 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:39 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:39 --> Total execution time: 0.0161
INFO - 2023-02-28 10:46:42 --> Config Class Initialized
INFO - 2023-02-28 10:46:42 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:42 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:42 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:42 --> URI Class Initialized
INFO - 2023-02-28 10:46:42 --> Router Class Initialized
INFO - 2023-02-28 10:46:42 --> Output Class Initialized
INFO - 2023-02-28 10:46:42 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:42 --> Input Class Initialized
INFO - 2023-02-28 10:46:42 --> Language Class Initialized
INFO - 2023-02-28 10:46:42 --> Loader Class Initialized
INFO - 2023-02-28 10:46:42 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:42 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:42 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:42 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:42 --> Total execution time: 0.0142
INFO - 2023-02-28 10:46:42 --> Config Class Initialized
INFO - 2023-02-28 10:46:42 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:42 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:42 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:42 --> URI Class Initialized
INFO - 2023-02-28 10:46:42 --> Router Class Initialized
INFO - 2023-02-28 10:46:42 --> Output Class Initialized
INFO - 2023-02-28 10:46:42 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:42 --> Input Class Initialized
INFO - 2023-02-28 10:46:42 --> Language Class Initialized
INFO - 2023-02-28 10:46:42 --> Loader Class Initialized
INFO - 2023-02-28 10:46:42 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:42 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:42 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:42 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:42 --> Total execution time: 0.0551
INFO - 2023-02-28 10:46:43 --> Config Class Initialized
INFO - 2023-02-28 10:46:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:43 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:43 --> URI Class Initialized
INFO - 2023-02-28 10:46:43 --> Router Class Initialized
INFO - 2023-02-28 10:46:43 --> Output Class Initialized
INFO - 2023-02-28 10:46:43 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:43 --> Input Class Initialized
INFO - 2023-02-28 10:46:43 --> Language Class Initialized
INFO - 2023-02-28 10:46:43 --> Loader Class Initialized
INFO - 2023-02-28 10:46:43 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:43 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:43 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:43 --> Total execution time: 0.0428
INFO - 2023-02-28 10:46:43 --> Config Class Initialized
INFO - 2023-02-28 10:46:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:43 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:43 --> URI Class Initialized
INFO - 2023-02-28 10:46:43 --> Router Class Initialized
INFO - 2023-02-28 10:46:43 --> Output Class Initialized
INFO - 2023-02-28 10:46:43 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:43 --> Input Class Initialized
INFO - 2023-02-28 10:46:43 --> Language Class Initialized
INFO - 2023-02-28 10:46:43 --> Loader Class Initialized
INFO - 2023-02-28 10:46:43 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:43 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:43 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:43 --> Total execution time: 0.1030
INFO - 2023-02-28 10:46:45 --> Config Class Initialized
INFO - 2023-02-28 10:46:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:45 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:45 --> URI Class Initialized
INFO - 2023-02-28 10:46:45 --> Router Class Initialized
INFO - 2023-02-28 10:46:45 --> Output Class Initialized
INFO - 2023-02-28 10:46:45 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:45 --> Input Class Initialized
INFO - 2023-02-28 10:46:45 --> Language Class Initialized
INFO - 2023-02-28 10:46:45 --> Loader Class Initialized
INFO - 2023-02-28 10:46:45 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:45 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:45 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:45 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:45 --> Model "Login_model" initialized
INFO - 2023-02-28 10:46:45 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:45 --> Total execution time: 0.0725
INFO - 2023-02-28 10:46:45 --> Config Class Initialized
INFO - 2023-02-28 10:46:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:45 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:45 --> URI Class Initialized
INFO - 2023-02-28 10:46:45 --> Router Class Initialized
INFO - 2023-02-28 10:46:45 --> Output Class Initialized
INFO - 2023-02-28 10:46:45 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:45 --> Input Class Initialized
INFO - 2023-02-28 10:46:45 --> Language Class Initialized
INFO - 2023-02-28 10:46:45 --> Loader Class Initialized
INFO - 2023-02-28 10:46:45 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:45 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:45 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:45 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:45 --> Model "Login_model" initialized
INFO - 2023-02-28 10:46:45 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:45 --> Total execution time: 0.0852
INFO - 2023-02-28 10:46:46 --> Config Class Initialized
INFO - 2023-02-28 10:46:46 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:46 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:46 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:46 --> URI Class Initialized
INFO - 2023-02-28 10:46:46 --> Router Class Initialized
INFO - 2023-02-28 10:46:46 --> Output Class Initialized
INFO - 2023-02-28 10:46:46 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:46 --> Input Class Initialized
INFO - 2023-02-28 10:46:46 --> Language Class Initialized
INFO - 2023-02-28 10:46:46 --> Loader Class Initialized
INFO - 2023-02-28 10:46:46 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:46 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:46 --> Total execution time: 0.0052
INFO - 2023-02-28 10:46:46 --> Config Class Initialized
INFO - 2023-02-28 10:46:46 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:46 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:46 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:46 --> URI Class Initialized
INFO - 2023-02-28 10:46:46 --> Router Class Initialized
INFO - 2023-02-28 10:46:46 --> Output Class Initialized
INFO - 2023-02-28 10:46:46 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:46 --> Input Class Initialized
INFO - 2023-02-28 10:46:46 --> Language Class Initialized
INFO - 2023-02-28 10:46:46 --> Loader Class Initialized
INFO - 2023-02-28 10:46:46 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:46 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:46 --> Model "Login_model" initialized
INFO - 2023-02-28 10:46:46 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:46 --> Model "Cluster_model" initialized
ERROR - 2023-02-28 10:46:46 --> Query error:  - Invalid query: 
INFO - 2023-02-28 10:46:46 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-28 10:46:47 --> Config Class Initialized
INFO - 2023-02-28 10:46:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:47 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:47 --> URI Class Initialized
INFO - 2023-02-28 10:46:47 --> Router Class Initialized
INFO - 2023-02-28 10:46:47 --> Output Class Initialized
INFO - 2023-02-28 10:46:47 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:47 --> Input Class Initialized
INFO - 2023-02-28 10:46:47 --> Language Class Initialized
INFO - 2023-02-28 10:46:47 --> Loader Class Initialized
INFO - 2023-02-28 10:46:47 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:47 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:47 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:47 --> Total execution time: 0.0153
INFO - 2023-02-28 10:46:47 --> Config Class Initialized
INFO - 2023-02-28 10:46:47 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:47 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:47 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:47 --> URI Class Initialized
INFO - 2023-02-28 10:46:47 --> Router Class Initialized
INFO - 2023-02-28 10:46:47 --> Output Class Initialized
INFO - 2023-02-28 10:46:47 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:47 --> Input Class Initialized
INFO - 2023-02-28 10:46:47 --> Language Class Initialized
INFO - 2023-02-28 10:46:47 --> Loader Class Initialized
INFO - 2023-02-28 10:46:47 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:47 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:47 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:47 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:47 --> Total execution time: 0.0579
INFO - 2023-02-28 10:46:51 --> Config Class Initialized
INFO - 2023-02-28 10:46:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:51 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:51 --> URI Class Initialized
INFO - 2023-02-28 10:46:51 --> Router Class Initialized
INFO - 2023-02-28 10:46:51 --> Output Class Initialized
INFO - 2023-02-28 10:46:51 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:51 --> Input Class Initialized
INFO - 2023-02-28 10:46:51 --> Language Class Initialized
INFO - 2023-02-28 10:46:51 --> Loader Class Initialized
INFO - 2023-02-28 10:46:51 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:51 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:51 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:51 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:51 --> Total execution time: 0.0431
INFO - 2023-02-28 10:46:51 --> Config Class Initialized
INFO - 2023-02-28 10:46:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:51 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:51 --> URI Class Initialized
INFO - 2023-02-28 10:46:51 --> Router Class Initialized
INFO - 2023-02-28 10:46:51 --> Output Class Initialized
INFO - 2023-02-28 10:46:51 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:51 --> Input Class Initialized
INFO - 2023-02-28 10:46:51 --> Language Class Initialized
INFO - 2023-02-28 10:46:51 --> Loader Class Initialized
INFO - 2023-02-28 10:46:51 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:51 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:51 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:51 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:51 --> Total execution time: 0.0389
INFO - 2023-02-28 10:46:52 --> Config Class Initialized
INFO - 2023-02-28 10:46:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:52 --> URI Class Initialized
INFO - 2023-02-28 10:46:52 --> Router Class Initialized
INFO - 2023-02-28 10:46:52 --> Output Class Initialized
INFO - 2023-02-28 10:46:52 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:52 --> Input Class Initialized
INFO - 2023-02-28 10:46:52 --> Language Class Initialized
INFO - 2023-02-28 10:46:52 --> Loader Class Initialized
INFO - 2023-02-28 10:46:52 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:52 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:52 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:52 --> Total execution time: 0.0175
INFO - 2023-02-28 10:46:52 --> Config Class Initialized
INFO - 2023-02-28 10:46:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:46:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:46:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:46:52 --> URI Class Initialized
INFO - 2023-02-28 10:46:52 --> Router Class Initialized
INFO - 2023-02-28 10:46:52 --> Output Class Initialized
INFO - 2023-02-28 10:46:52 --> Security Class Initialized
DEBUG - 2023-02-28 10:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:46:52 --> Input Class Initialized
INFO - 2023-02-28 10:46:52 --> Language Class Initialized
INFO - 2023-02-28 10:46:52 --> Loader Class Initialized
INFO - 2023-02-28 10:46:52 --> Controller Class Initialized
DEBUG - 2023-02-28 10:46:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:46:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:46:52 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:46:52 --> Final output sent to browser
DEBUG - 2023-02-28 10:46:52 --> Total execution time: 0.0112
INFO - 2023-02-28 10:49:05 --> Config Class Initialized
INFO - 2023-02-28 10:49:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:49:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:49:05 --> Utf8 Class Initialized
INFO - 2023-02-28 10:49:05 --> URI Class Initialized
INFO - 2023-02-28 10:49:05 --> Router Class Initialized
INFO - 2023-02-28 10:49:05 --> Output Class Initialized
INFO - 2023-02-28 10:49:05 --> Security Class Initialized
DEBUG - 2023-02-28 10:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:49:05 --> Input Class Initialized
INFO - 2023-02-28 10:49:05 --> Language Class Initialized
INFO - 2023-02-28 10:49:05 --> Loader Class Initialized
INFO - 2023-02-28 10:49:05 --> Controller Class Initialized
DEBUG - 2023-02-28 10:49:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:49:05 --> Database Driver Class Initialized
INFO - 2023-02-28 10:49:05 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:49:05 --> Final output sent to browser
DEBUG - 2023-02-28 10:49:05 --> Total execution time: 0.0506
INFO - 2023-02-28 10:49:05 --> Config Class Initialized
INFO - 2023-02-28 10:49:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:49:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:49:05 --> Utf8 Class Initialized
INFO - 2023-02-28 10:49:05 --> URI Class Initialized
INFO - 2023-02-28 10:49:05 --> Router Class Initialized
INFO - 2023-02-28 10:49:05 --> Output Class Initialized
INFO - 2023-02-28 10:49:05 --> Security Class Initialized
DEBUG - 2023-02-28 10:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:49:05 --> Input Class Initialized
INFO - 2023-02-28 10:49:05 --> Language Class Initialized
INFO - 2023-02-28 10:49:05 --> Loader Class Initialized
INFO - 2023-02-28 10:49:05 --> Controller Class Initialized
DEBUG - 2023-02-28 10:49:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:49:05 --> Database Driver Class Initialized
INFO - 2023-02-28 10:49:05 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:49:05 --> Final output sent to browser
DEBUG - 2023-02-28 10:49:05 --> Total execution time: 0.0445
INFO - 2023-02-28 10:49:07 --> Config Class Initialized
INFO - 2023-02-28 10:49:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:49:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:49:07 --> Utf8 Class Initialized
INFO - 2023-02-28 10:49:07 --> URI Class Initialized
INFO - 2023-02-28 10:49:07 --> Router Class Initialized
INFO - 2023-02-28 10:49:07 --> Output Class Initialized
INFO - 2023-02-28 10:49:07 --> Security Class Initialized
DEBUG - 2023-02-28 10:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:49:07 --> Input Class Initialized
INFO - 2023-02-28 10:49:07 --> Language Class Initialized
INFO - 2023-02-28 10:49:07 --> Loader Class Initialized
INFO - 2023-02-28 10:49:07 --> Controller Class Initialized
DEBUG - 2023-02-28 10:49:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:49:07 --> Database Driver Class Initialized
INFO - 2023-02-28 10:49:07 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:49:07 --> Final output sent to browser
DEBUG - 2023-02-28 10:49:07 --> Total execution time: 0.0148
INFO - 2023-02-28 10:49:07 --> Config Class Initialized
INFO - 2023-02-28 10:49:07 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:49:07 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:49:07 --> Utf8 Class Initialized
INFO - 2023-02-28 10:49:07 --> URI Class Initialized
INFO - 2023-02-28 10:49:07 --> Router Class Initialized
INFO - 2023-02-28 10:49:07 --> Output Class Initialized
INFO - 2023-02-28 10:49:07 --> Security Class Initialized
DEBUG - 2023-02-28 10:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:49:07 --> Input Class Initialized
INFO - 2023-02-28 10:49:07 --> Language Class Initialized
INFO - 2023-02-28 10:49:07 --> Loader Class Initialized
INFO - 2023-02-28 10:49:07 --> Controller Class Initialized
DEBUG - 2023-02-28 10:49:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:49:07 --> Database Driver Class Initialized
INFO - 2023-02-28 10:49:07 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:49:07 --> Final output sent to browser
DEBUG - 2023-02-28 10:49:07 --> Total execution time: 0.0106
INFO - 2023-02-28 10:49:08 --> Config Class Initialized
INFO - 2023-02-28 10:49:08 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:49:08 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:49:08 --> Utf8 Class Initialized
INFO - 2023-02-28 10:49:08 --> URI Class Initialized
INFO - 2023-02-28 10:49:08 --> Router Class Initialized
INFO - 2023-02-28 10:49:08 --> Output Class Initialized
INFO - 2023-02-28 10:49:08 --> Security Class Initialized
DEBUG - 2023-02-28 10:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:49:08 --> Input Class Initialized
INFO - 2023-02-28 10:49:08 --> Language Class Initialized
INFO - 2023-02-28 10:49:08 --> Loader Class Initialized
INFO - 2023-02-28 10:49:08 --> Controller Class Initialized
DEBUG - 2023-02-28 10:49:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:49:08 --> Database Driver Class Initialized
INFO - 2023-02-28 10:49:08 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:49:08 --> Database Driver Class Initialized
INFO - 2023-02-28 10:49:08 --> Model "Login_model" initialized
INFO - 2023-02-28 10:49:09 --> Final output sent to browser
DEBUG - 2023-02-28 10:49:09 --> Total execution time: 0.0399
INFO - 2023-02-28 10:49:09 --> Config Class Initialized
INFO - 2023-02-28 10:49:09 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:49:09 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:49:09 --> Utf8 Class Initialized
INFO - 2023-02-28 10:49:09 --> URI Class Initialized
INFO - 2023-02-28 10:49:09 --> Router Class Initialized
INFO - 2023-02-28 10:49:09 --> Output Class Initialized
INFO - 2023-02-28 10:49:09 --> Security Class Initialized
DEBUG - 2023-02-28 10:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:49:09 --> Input Class Initialized
INFO - 2023-02-28 10:49:09 --> Language Class Initialized
INFO - 2023-02-28 10:49:09 --> Loader Class Initialized
INFO - 2023-02-28 10:49:09 --> Controller Class Initialized
DEBUG - 2023-02-28 10:49:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:49:09 --> Database Driver Class Initialized
INFO - 2023-02-28 10:49:09 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:49:09 --> Database Driver Class Initialized
INFO - 2023-02-28 10:49:09 --> Model "Login_model" initialized
INFO - 2023-02-28 10:49:09 --> Final output sent to browser
DEBUG - 2023-02-28 10:49:09 --> Total execution time: 0.0367
INFO - 2023-02-28 10:49:16 --> Config Class Initialized
INFO - 2023-02-28 10:49:16 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:49:16 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:49:16 --> Utf8 Class Initialized
INFO - 2023-02-28 10:49:16 --> URI Class Initialized
INFO - 2023-02-28 10:49:16 --> Router Class Initialized
INFO - 2023-02-28 10:49:16 --> Output Class Initialized
INFO - 2023-02-28 10:49:16 --> Security Class Initialized
DEBUG - 2023-02-28 10:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:49:16 --> Input Class Initialized
INFO - 2023-02-28 10:49:16 --> Language Class Initialized
INFO - 2023-02-28 10:49:16 --> Loader Class Initialized
INFO - 2023-02-28 10:49:16 --> Controller Class Initialized
DEBUG - 2023-02-28 10:49:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:49:16 --> Database Driver Class Initialized
INFO - 2023-02-28 10:49:16 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:49:16 --> Final output sent to browser
DEBUG - 2023-02-28 10:49:16 --> Total execution time: 0.0337
INFO - 2023-02-28 10:49:16 --> Config Class Initialized
INFO - 2023-02-28 10:49:16 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:49:16 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:49:16 --> Utf8 Class Initialized
INFO - 2023-02-28 10:49:16 --> URI Class Initialized
INFO - 2023-02-28 10:49:16 --> Router Class Initialized
INFO - 2023-02-28 10:49:16 --> Output Class Initialized
INFO - 2023-02-28 10:49:16 --> Security Class Initialized
DEBUG - 2023-02-28 10:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:49:16 --> Input Class Initialized
INFO - 2023-02-28 10:49:16 --> Language Class Initialized
INFO - 2023-02-28 10:49:16 --> Loader Class Initialized
INFO - 2023-02-28 10:49:16 --> Controller Class Initialized
DEBUG - 2023-02-28 10:49:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:49:16 --> Database Driver Class Initialized
INFO - 2023-02-28 10:49:16 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:49:16 --> Final output sent to browser
DEBUG - 2023-02-28 10:49:16 --> Total execution time: 0.0129
INFO - 2023-02-28 10:49:19 --> Config Class Initialized
INFO - 2023-02-28 10:49:19 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:49:19 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:49:19 --> Utf8 Class Initialized
INFO - 2023-02-28 10:49:19 --> URI Class Initialized
INFO - 2023-02-28 10:49:19 --> Router Class Initialized
INFO - 2023-02-28 10:49:19 --> Output Class Initialized
INFO - 2023-02-28 10:49:19 --> Security Class Initialized
DEBUG - 2023-02-28 10:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:49:19 --> Input Class Initialized
INFO - 2023-02-28 10:49:19 --> Language Class Initialized
INFO - 2023-02-28 10:49:19 --> Loader Class Initialized
INFO - 2023-02-28 10:49:19 --> Controller Class Initialized
DEBUG - 2023-02-28 10:49:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:49:19 --> Database Driver Class Initialized
INFO - 2023-02-28 10:49:19 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:49:19 --> Final output sent to browser
DEBUG - 2023-02-28 10:49:19 --> Total execution time: 0.0434
INFO - 2023-02-28 10:49:19 --> Config Class Initialized
INFO - 2023-02-28 10:49:19 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:49:19 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:49:19 --> Utf8 Class Initialized
INFO - 2023-02-28 10:49:19 --> URI Class Initialized
INFO - 2023-02-28 10:49:19 --> Router Class Initialized
INFO - 2023-02-28 10:49:19 --> Output Class Initialized
INFO - 2023-02-28 10:49:19 --> Security Class Initialized
DEBUG - 2023-02-28 10:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:49:19 --> Input Class Initialized
INFO - 2023-02-28 10:49:19 --> Language Class Initialized
INFO - 2023-02-28 10:49:19 --> Loader Class Initialized
INFO - 2023-02-28 10:49:19 --> Controller Class Initialized
DEBUG - 2023-02-28 10:49:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:49:19 --> Database Driver Class Initialized
INFO - 2023-02-28 10:49:19 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:49:19 --> Final output sent to browser
DEBUG - 2023-02-28 10:49:19 --> Total execution time: 0.0397
INFO - 2023-02-28 10:50:23 --> Config Class Initialized
INFO - 2023-02-28 10:50:23 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:23 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:23 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:23 --> URI Class Initialized
INFO - 2023-02-28 10:50:23 --> Router Class Initialized
INFO - 2023-02-28 10:50:23 --> Output Class Initialized
INFO - 2023-02-28 10:50:23 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:23 --> Input Class Initialized
INFO - 2023-02-28 10:50:23 --> Language Class Initialized
INFO - 2023-02-28 10:50:23 --> Loader Class Initialized
INFO - 2023-02-28 10:50:23 --> Controller Class Initialized
DEBUG - 2023-02-28 10:50:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:23 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:23 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:50:23 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:23 --> Total execution time: 0.0489
INFO - 2023-02-28 10:50:23 --> Config Class Initialized
INFO - 2023-02-28 10:50:23 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:23 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:23 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:23 --> URI Class Initialized
INFO - 2023-02-28 10:50:23 --> Router Class Initialized
INFO - 2023-02-28 10:50:23 --> Output Class Initialized
INFO - 2023-02-28 10:50:23 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:23 --> Input Class Initialized
INFO - 2023-02-28 10:50:23 --> Language Class Initialized
INFO - 2023-02-28 10:50:23 --> Loader Class Initialized
INFO - 2023-02-28 10:50:23 --> Controller Class Initialized
DEBUG - 2023-02-28 10:50:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:23 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:23 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:50:23 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:23 --> Total execution time: 0.0421
INFO - 2023-02-28 10:50:27 --> Config Class Initialized
INFO - 2023-02-28 10:50:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:27 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:27 --> URI Class Initialized
INFO - 2023-02-28 10:50:27 --> Router Class Initialized
INFO - 2023-02-28 10:50:27 --> Output Class Initialized
INFO - 2023-02-28 10:50:27 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:27 --> Input Class Initialized
INFO - 2023-02-28 10:50:27 --> Language Class Initialized
INFO - 2023-02-28 10:50:27 --> Loader Class Initialized
INFO - 2023-02-28 10:50:27 --> Controller Class Initialized
INFO - 2023-02-28 10:50:27 --> Helper loaded: form_helper
INFO - 2023-02-28 10:50:27 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:50:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:27 --> Model "Change_model" initialized
INFO - 2023-02-28 10:50:27 --> Model "Grafana_model" initialized
INFO - 2023-02-28 10:50:27 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:27 --> Total execution time: 0.0261
INFO - 2023-02-28 10:50:27 --> Config Class Initialized
INFO - 2023-02-28 10:50:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:27 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:27 --> URI Class Initialized
INFO - 2023-02-28 10:50:27 --> Router Class Initialized
INFO - 2023-02-28 10:50:27 --> Output Class Initialized
INFO - 2023-02-28 10:50:27 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:27 --> Input Class Initialized
INFO - 2023-02-28 10:50:27 --> Language Class Initialized
INFO - 2023-02-28 10:50:27 --> Loader Class Initialized
INFO - 2023-02-28 10:50:27 --> Controller Class Initialized
INFO - 2023-02-28 10:50:27 --> Helper loaded: form_helper
INFO - 2023-02-28 10:50:27 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:50:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:27 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:27 --> Total execution time: 0.0017
INFO - 2023-02-28 10:50:27 --> Config Class Initialized
INFO - 2023-02-28 10:50:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:27 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:27 --> URI Class Initialized
INFO - 2023-02-28 10:50:27 --> Router Class Initialized
INFO - 2023-02-28 10:50:27 --> Output Class Initialized
INFO - 2023-02-28 10:50:27 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:27 --> Input Class Initialized
INFO - 2023-02-28 10:50:27 --> Language Class Initialized
INFO - 2023-02-28 10:50:27 --> Loader Class Initialized
INFO - 2023-02-28 10:50:27 --> Controller Class Initialized
INFO - 2023-02-28 10:50:27 --> Helper loaded: form_helper
INFO - 2023-02-28 10:50:27 --> Helper loaded: url_helper
DEBUG - 2023-02-28 10:50:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:27 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:27 --> Model "Login_model" initialized
INFO - 2023-02-28 10:50:27 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:27 --> Total execution time: 0.0190
INFO - 2023-02-28 10:50:27 --> Config Class Initialized
INFO - 2023-02-28 10:50:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:27 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:27 --> URI Class Initialized
INFO - 2023-02-28 10:50:27 --> Router Class Initialized
INFO - 2023-02-28 10:50:27 --> Output Class Initialized
INFO - 2023-02-28 10:50:27 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:27 --> Input Class Initialized
INFO - 2023-02-28 10:50:27 --> Language Class Initialized
INFO - 2023-02-28 10:50:27 --> Loader Class Initialized
INFO - 2023-02-28 10:50:27 --> Controller Class Initialized
DEBUG - 2023-02-28 10:50:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:27 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:27 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:50:27 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:27 --> Total execution time: 0.0140
INFO - 2023-02-28 10:50:27 --> Config Class Initialized
INFO - 2023-02-28 10:50:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:27 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:27 --> URI Class Initialized
INFO - 2023-02-28 10:50:27 --> Router Class Initialized
INFO - 2023-02-28 10:50:27 --> Output Class Initialized
INFO - 2023-02-28 10:50:27 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:27 --> Input Class Initialized
INFO - 2023-02-28 10:50:27 --> Language Class Initialized
INFO - 2023-02-28 10:50:27 --> Loader Class Initialized
INFO - 2023-02-28 10:50:27 --> Controller Class Initialized
DEBUG - 2023-02-28 10:50:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:27 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:27 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:50:27 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:27 --> Total execution time: 0.0169
INFO - 2023-02-28 10:50:27 --> Config Class Initialized
INFO - 2023-02-28 10:50:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:27 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:27 --> URI Class Initialized
INFO - 2023-02-28 10:50:27 --> Router Class Initialized
INFO - 2023-02-28 10:50:27 --> Output Class Initialized
INFO - 2023-02-28 10:50:27 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:27 --> Input Class Initialized
INFO - 2023-02-28 10:50:27 --> Language Class Initialized
INFO - 2023-02-28 10:50:27 --> Loader Class Initialized
INFO - 2023-02-28 10:50:27 --> Controller Class Initialized
DEBUG - 2023-02-28 10:50:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:27 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:27 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:50:27 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:27 --> Model "Login_model" initialized
INFO - 2023-02-28 10:50:27 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:27 --> Total execution time: 0.0421
INFO - 2023-02-28 10:50:27 --> Config Class Initialized
INFO - 2023-02-28 10:50:27 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:27 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:27 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:27 --> URI Class Initialized
INFO - 2023-02-28 10:50:27 --> Router Class Initialized
INFO - 2023-02-28 10:50:27 --> Output Class Initialized
INFO - 2023-02-28 10:50:27 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:27 --> Input Class Initialized
INFO - 2023-02-28 10:50:27 --> Language Class Initialized
INFO - 2023-02-28 10:50:27 --> Loader Class Initialized
INFO - 2023-02-28 10:50:27 --> Controller Class Initialized
DEBUG - 2023-02-28 10:50:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:27 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:27 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:50:27 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:27 --> Model "Login_model" initialized
INFO - 2023-02-28 10:50:27 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:27 --> Total execution time: 0.0837
INFO - 2023-02-28 10:50:30 --> Config Class Initialized
INFO - 2023-02-28 10:50:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:30 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:30 --> URI Class Initialized
INFO - 2023-02-28 10:50:30 --> Router Class Initialized
INFO - 2023-02-28 10:50:30 --> Output Class Initialized
INFO - 2023-02-28 10:50:30 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:30 --> Input Class Initialized
INFO - 2023-02-28 10:50:30 --> Language Class Initialized
INFO - 2023-02-28 10:50:30 --> Loader Class Initialized
INFO - 2023-02-28 10:50:30 --> Controller Class Initialized
DEBUG - 2023-02-28 10:50:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:50:30 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:30 --> Total execution time: 0.0141
INFO - 2023-02-28 10:50:30 --> Config Class Initialized
INFO - 2023-02-28 10:50:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:30 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:30 --> URI Class Initialized
INFO - 2023-02-28 10:50:30 --> Router Class Initialized
INFO - 2023-02-28 10:50:30 --> Output Class Initialized
INFO - 2023-02-28 10:50:30 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:30 --> Input Class Initialized
INFO - 2023-02-28 10:50:30 --> Language Class Initialized
INFO - 2023-02-28 10:50:30 --> Loader Class Initialized
INFO - 2023-02-28 10:50:30 --> Controller Class Initialized
DEBUG - 2023-02-28 10:50:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:30 --> Model "Cluster_model" initialized
INFO - 2023-02-28 10:50:30 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:30 --> Total execution time: 0.0127
INFO - 2023-02-28 10:50:31 --> Config Class Initialized
INFO - 2023-02-28 10:50:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:31 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:31 --> URI Class Initialized
INFO - 2023-02-28 10:50:31 --> Router Class Initialized
INFO - 2023-02-28 10:50:31 --> Output Class Initialized
INFO - 2023-02-28 10:50:31 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:31 --> Input Class Initialized
INFO - 2023-02-28 10:50:31 --> Language Class Initialized
INFO - 2023-02-28 10:50:31 --> Loader Class Initialized
INFO - 2023-02-28 10:50:31 --> Controller Class Initialized
DEBUG - 2023-02-28 10:50:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:31 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:31 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:31 --> Model "Login_model" initialized
INFO - 2023-02-28 10:50:31 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:31 --> Total execution time: 0.0255
INFO - 2023-02-28 10:50:31 --> Config Class Initialized
INFO - 2023-02-28 10:50:31 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:31 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:31 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:31 --> URI Class Initialized
INFO - 2023-02-28 10:50:31 --> Router Class Initialized
INFO - 2023-02-28 10:50:31 --> Output Class Initialized
INFO - 2023-02-28 10:50:31 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:31 --> Input Class Initialized
INFO - 2023-02-28 10:50:31 --> Language Class Initialized
INFO - 2023-02-28 10:50:31 --> Loader Class Initialized
INFO - 2023-02-28 10:50:31 --> Controller Class Initialized
DEBUG - 2023-02-28 10:50:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:31 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:31 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:31 --> Model "Login_model" initialized
INFO - 2023-02-28 10:50:31 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:31 --> Total execution time: 0.0212
INFO - 2023-02-28 10:50:41 --> Config Class Initialized
INFO - 2023-02-28 10:50:41 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:41 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:41 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:41 --> URI Class Initialized
INFO - 2023-02-28 10:50:41 --> Router Class Initialized
INFO - 2023-02-28 10:50:41 --> Output Class Initialized
INFO - 2023-02-28 10:50:41 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:41 --> Input Class Initialized
INFO - 2023-02-28 10:50:41 --> Language Class Initialized
INFO - 2023-02-28 10:50:41 --> Loader Class Initialized
INFO - 2023-02-28 10:50:41 --> Controller Class Initialized
DEBUG - 2023-02-28 10:50:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:41 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:41 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:41 --> Total execution time: 0.0167
INFO - 2023-02-28 10:50:41 --> Config Class Initialized
INFO - 2023-02-28 10:50:41 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:50:41 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:50:41 --> Utf8 Class Initialized
INFO - 2023-02-28 10:50:41 --> URI Class Initialized
INFO - 2023-02-28 10:50:41 --> Router Class Initialized
INFO - 2023-02-28 10:50:41 --> Output Class Initialized
INFO - 2023-02-28 10:50:41 --> Security Class Initialized
DEBUG - 2023-02-28 10:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:50:41 --> Input Class Initialized
INFO - 2023-02-28 10:50:41 --> Language Class Initialized
INFO - 2023-02-28 10:50:41 --> Loader Class Initialized
INFO - 2023-02-28 10:50:41 --> Controller Class Initialized
DEBUG - 2023-02-28 10:50:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:50:41 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:41 --> Database Driver Class Initialized
INFO - 2023-02-28 10:50:41 --> Model "Login_model" initialized
INFO - 2023-02-28 10:50:41 --> Final output sent to browser
DEBUG - 2023-02-28 10:50:41 --> Total execution time: 0.0184
INFO - 2023-02-28 10:51:05 --> Config Class Initialized
INFO - 2023-02-28 10:51:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:51:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:51:05 --> Utf8 Class Initialized
INFO - 2023-02-28 10:51:05 --> URI Class Initialized
INFO - 2023-02-28 10:51:05 --> Router Class Initialized
INFO - 2023-02-28 10:51:05 --> Output Class Initialized
INFO - 2023-02-28 10:51:05 --> Security Class Initialized
DEBUG - 2023-02-28 10:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:51:05 --> Input Class Initialized
INFO - 2023-02-28 10:51:05 --> Language Class Initialized
INFO - 2023-02-28 10:51:05 --> Loader Class Initialized
INFO - 2023-02-28 10:51:05 --> Controller Class Initialized
DEBUG - 2023-02-28 10:51:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:51:05 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:05 --> Final output sent to browser
DEBUG - 2023-02-28 10:51:05 --> Total execution time: 0.0131
INFO - 2023-02-28 10:51:05 --> Config Class Initialized
INFO - 2023-02-28 10:51:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:51:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:51:05 --> Utf8 Class Initialized
INFO - 2023-02-28 10:51:05 --> URI Class Initialized
INFO - 2023-02-28 10:51:05 --> Router Class Initialized
INFO - 2023-02-28 10:51:05 --> Output Class Initialized
INFO - 2023-02-28 10:51:05 --> Security Class Initialized
DEBUG - 2023-02-28 10:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:51:05 --> Input Class Initialized
INFO - 2023-02-28 10:51:05 --> Language Class Initialized
INFO - 2023-02-28 10:51:05 --> Loader Class Initialized
INFO - 2023-02-28 10:51:05 --> Controller Class Initialized
DEBUG - 2023-02-28 10:51:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:51:05 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:06 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:06 --> Model "Login_model" initialized
INFO - 2023-02-28 10:51:06 --> Final output sent to browser
DEBUG - 2023-02-28 10:51:06 --> Total execution time: 0.0185
INFO - 2023-02-28 10:51:12 --> Config Class Initialized
INFO - 2023-02-28 10:51:12 --> Config Class Initialized
INFO - 2023-02-28 10:51:12 --> Hooks Class Initialized
INFO - 2023-02-28 10:51:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:51:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:51:12 --> Utf8 Class Initialized
INFO - 2023-02-28 10:51:12 --> Utf8 Class Initialized
INFO - 2023-02-28 10:51:12 --> URI Class Initialized
INFO - 2023-02-28 10:51:12 --> URI Class Initialized
INFO - 2023-02-28 10:51:12 --> Router Class Initialized
INFO - 2023-02-28 10:51:12 --> Router Class Initialized
INFO - 2023-02-28 10:51:12 --> Output Class Initialized
INFO - 2023-02-28 10:51:12 --> Output Class Initialized
INFO - 2023-02-28 10:51:12 --> Security Class Initialized
INFO - 2023-02-28 10:51:12 --> Security Class Initialized
DEBUG - 2023-02-28 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:51:12 --> Input Class Initialized
INFO - 2023-02-28 10:51:12 --> Input Class Initialized
INFO - 2023-02-28 10:51:12 --> Language Class Initialized
INFO - 2023-02-28 10:51:12 --> Language Class Initialized
INFO - 2023-02-28 10:51:12 --> Loader Class Initialized
INFO - 2023-02-28 10:51:12 --> Controller Class Initialized
INFO - 2023-02-28 10:51:12 --> Loader Class Initialized
INFO - 2023-02-28 10:51:12 --> Controller Class Initialized
DEBUG - 2023-02-28 10:51:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:51:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:51:12 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:12 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:12 --> Final output sent to browser
INFO - 2023-02-28 10:51:12 --> Final output sent to browser
DEBUG - 2023-02-28 10:51:12 --> Total execution time: 0.0153
DEBUG - 2023-02-28 10:51:12 --> Total execution time: 0.0153
INFO - 2023-02-28 10:51:12 --> Config Class Initialized
INFO - 2023-02-28 10:51:12 --> Config Class Initialized
INFO - 2023-02-28 10:51:12 --> Hooks Class Initialized
INFO - 2023-02-28 10:51:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:51:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:51:12 --> Utf8 Class Initialized
INFO - 2023-02-28 10:51:12 --> Utf8 Class Initialized
INFO - 2023-02-28 10:51:12 --> URI Class Initialized
INFO - 2023-02-28 10:51:12 --> URI Class Initialized
INFO - 2023-02-28 10:51:12 --> Router Class Initialized
INFO - 2023-02-28 10:51:12 --> Router Class Initialized
INFO - 2023-02-28 10:51:12 --> Output Class Initialized
INFO - 2023-02-28 10:51:12 --> Output Class Initialized
INFO - 2023-02-28 10:51:12 --> Security Class Initialized
INFO - 2023-02-28 10:51:12 --> Security Class Initialized
DEBUG - 2023-02-28 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:51:12 --> Input Class Initialized
INFO - 2023-02-28 10:51:12 --> Language Class Initialized
DEBUG - 2023-02-28 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:51:12 --> Loader Class Initialized
INFO - 2023-02-28 10:51:12 --> Input Class Initialized
INFO - 2023-02-28 10:51:12 --> Language Class Initialized
INFO - 2023-02-28 10:51:12 --> Controller Class Initialized
INFO - 2023-02-28 10:51:12 --> Loader Class Initialized
DEBUG - 2023-02-28 10:51:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:51:12 --> Controller Class Initialized
DEBUG - 2023-02-28 10:51:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:51:12 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:12 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:12 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:12 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:12 --> Model "Login_model" initialized
INFO - 2023-02-28 10:51:12 --> Model "Login_model" initialized
INFO - 2023-02-28 10:51:12 --> Final output sent to browser
INFO - 2023-02-28 10:51:12 --> Final output sent to browser
DEBUG - 2023-02-28 10:51:12 --> Total execution time: 0.0250
DEBUG - 2023-02-28 10:51:12 --> Total execution time: 0.0250
INFO - 2023-02-28 10:51:12 --> Config Class Initialized
INFO - 2023-02-28 10:51:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:51:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:51:12 --> Utf8 Class Initialized
INFO - 2023-02-28 10:51:12 --> URI Class Initialized
INFO - 2023-02-28 10:51:12 --> Router Class Initialized
INFO - 2023-02-28 10:51:12 --> Output Class Initialized
INFO - 2023-02-28 10:51:12 --> Security Class Initialized
DEBUG - 2023-02-28 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:51:12 --> Input Class Initialized
INFO - 2023-02-28 10:51:12 --> Language Class Initialized
INFO - 2023-02-28 10:51:12 --> Loader Class Initialized
INFO - 2023-02-28 10:51:12 --> Controller Class Initialized
DEBUG - 2023-02-28 10:51:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:51:12 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:12 --> Final output sent to browser
DEBUG - 2023-02-28 10:51:12 --> Total execution time: 0.0083
INFO - 2023-02-28 10:51:12 --> Config Class Initialized
INFO - 2023-02-28 10:51:12 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:51:12 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:51:12 --> Utf8 Class Initialized
INFO - 2023-02-28 10:51:12 --> URI Class Initialized
INFO - 2023-02-28 10:51:12 --> Router Class Initialized
INFO - 2023-02-28 10:51:12 --> Output Class Initialized
INFO - 2023-02-28 10:51:12 --> Security Class Initialized
DEBUG - 2023-02-28 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:51:12 --> Input Class Initialized
INFO - 2023-02-28 10:51:12 --> Language Class Initialized
INFO - 2023-02-28 10:51:12 --> Loader Class Initialized
INFO - 2023-02-28 10:51:12 --> Controller Class Initialized
DEBUG - 2023-02-28 10:51:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:51:12 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:13 --> Final output sent to browser
DEBUG - 2023-02-28 10:51:13 --> Total execution time: 0.4007
INFO - 2023-02-28 10:51:13 --> Config Class Initialized
INFO - 2023-02-28 10:51:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:51:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:51:13 --> Utf8 Class Initialized
INFO - 2023-02-28 10:51:13 --> URI Class Initialized
INFO - 2023-02-28 10:51:13 --> Router Class Initialized
INFO - 2023-02-28 10:51:13 --> Output Class Initialized
INFO - 2023-02-28 10:51:13 --> Security Class Initialized
DEBUG - 2023-02-28 10:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:51:13 --> Input Class Initialized
INFO - 2023-02-28 10:51:13 --> Language Class Initialized
INFO - 2023-02-28 10:51:13 --> Loader Class Initialized
INFO - 2023-02-28 10:51:13 --> Controller Class Initialized
DEBUG - 2023-02-28 10:51:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:51:13 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:13 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:13 --> Model "Login_model" initialized
INFO - 2023-02-28 10:51:13 --> Final output sent to browser
DEBUG - 2023-02-28 10:51:13 --> Total execution time: 0.0218
INFO - 2023-02-28 10:51:13 --> Config Class Initialized
INFO - 2023-02-28 10:51:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:51:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:51:13 --> Utf8 Class Initialized
INFO - 2023-02-28 10:51:13 --> URI Class Initialized
INFO - 2023-02-28 10:51:13 --> Router Class Initialized
INFO - 2023-02-28 10:51:13 --> Output Class Initialized
INFO - 2023-02-28 10:51:13 --> Security Class Initialized
DEBUG - 2023-02-28 10:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:51:13 --> Input Class Initialized
INFO - 2023-02-28 10:51:13 --> Language Class Initialized
INFO - 2023-02-28 10:51:13 --> Loader Class Initialized
INFO - 2023-02-28 10:51:13 --> Controller Class Initialized
DEBUG - 2023-02-28 10:51:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:51:13 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:13 --> Database Driver Class Initialized
INFO - 2023-02-28 10:51:13 --> Model "Login_model" initialized
INFO - 2023-02-28 10:51:13 --> Final output sent to browser
DEBUG - 2023-02-28 10:51:13 --> Total execution time: 0.0197
INFO - 2023-02-28 10:53:54 --> Config Class Initialized
INFO - 2023-02-28 10:53:54 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:53:54 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:53:54 --> Utf8 Class Initialized
INFO - 2023-02-28 10:53:54 --> URI Class Initialized
INFO - 2023-02-28 10:53:54 --> Router Class Initialized
INFO - 2023-02-28 10:53:54 --> Output Class Initialized
INFO - 2023-02-28 10:53:54 --> Security Class Initialized
DEBUG - 2023-02-28 10:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:53:54 --> Input Class Initialized
INFO - 2023-02-28 10:53:54 --> Language Class Initialized
INFO - 2023-02-28 10:53:54 --> Loader Class Initialized
INFO - 2023-02-28 10:53:54 --> Controller Class Initialized
DEBUG - 2023-02-28 10:53:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:53:54 --> Database Driver Class Initialized
INFO - 2023-02-28 10:53:54 --> Final output sent to browser
DEBUG - 2023-02-28 10:53:54 --> Total execution time: 0.0150
INFO - 2023-02-28 10:53:54 --> Config Class Initialized
INFO - 2023-02-28 10:53:54 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:53:54 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:53:54 --> Utf8 Class Initialized
INFO - 2023-02-28 10:53:54 --> URI Class Initialized
INFO - 2023-02-28 10:53:54 --> Router Class Initialized
INFO - 2023-02-28 10:53:54 --> Output Class Initialized
INFO - 2023-02-28 10:53:54 --> Security Class Initialized
DEBUG - 2023-02-28 10:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:53:54 --> Input Class Initialized
INFO - 2023-02-28 10:53:54 --> Language Class Initialized
INFO - 2023-02-28 10:53:54 --> Loader Class Initialized
INFO - 2023-02-28 10:53:54 --> Controller Class Initialized
DEBUG - 2023-02-28 10:53:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:53:54 --> Database Driver Class Initialized
INFO - 2023-02-28 10:53:54 --> Database Driver Class Initialized
INFO - 2023-02-28 10:53:54 --> Model "Login_model" initialized
INFO - 2023-02-28 10:53:54 --> Final output sent to browser
DEBUG - 2023-02-28 10:53:54 --> Total execution time: 0.0206
INFO - 2023-02-28 10:54:35 --> Config Class Initialized
INFO - 2023-02-28 10:54:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:54:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:54:35 --> Utf8 Class Initialized
INFO - 2023-02-28 10:54:35 --> URI Class Initialized
INFO - 2023-02-28 10:54:35 --> Router Class Initialized
INFO - 2023-02-28 10:54:35 --> Output Class Initialized
INFO - 2023-02-28 10:54:35 --> Security Class Initialized
DEBUG - 2023-02-28 10:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:54:35 --> Input Class Initialized
INFO - 2023-02-28 10:54:35 --> Language Class Initialized
INFO - 2023-02-28 10:54:35 --> Loader Class Initialized
INFO - 2023-02-28 10:54:35 --> Controller Class Initialized
DEBUG - 2023-02-28 10:54:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:54:35 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:35 --> Final output sent to browser
DEBUG - 2023-02-28 10:54:35 --> Total execution time: 0.0138
INFO - 2023-02-28 10:54:35 --> Config Class Initialized
INFO - 2023-02-28 10:54:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:54:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:54:35 --> Utf8 Class Initialized
INFO - 2023-02-28 10:54:35 --> URI Class Initialized
INFO - 2023-02-28 10:54:35 --> Router Class Initialized
INFO - 2023-02-28 10:54:35 --> Output Class Initialized
INFO - 2023-02-28 10:54:35 --> Security Class Initialized
DEBUG - 2023-02-28 10:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:54:35 --> Input Class Initialized
INFO - 2023-02-28 10:54:35 --> Language Class Initialized
INFO - 2023-02-28 10:54:35 --> Loader Class Initialized
INFO - 2023-02-28 10:54:35 --> Controller Class Initialized
DEBUG - 2023-02-28 10:54:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:54:35 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:35 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:35 --> Model "Login_model" initialized
INFO - 2023-02-28 10:54:35 --> Final output sent to browser
DEBUG - 2023-02-28 10:54:35 --> Total execution time: 0.0186
INFO - 2023-02-28 10:54:43 --> Config Class Initialized
INFO - 2023-02-28 10:54:43 --> Config Class Initialized
INFO - 2023-02-28 10:54:43 --> Hooks Class Initialized
INFO - 2023-02-28 10:54:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:54:43 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:54:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:54:43 --> Utf8 Class Initialized
INFO - 2023-02-28 10:54:43 --> Utf8 Class Initialized
INFO - 2023-02-28 10:54:43 --> URI Class Initialized
INFO - 2023-02-28 10:54:43 --> URI Class Initialized
INFO - 2023-02-28 10:54:43 --> Router Class Initialized
INFO - 2023-02-28 10:54:43 --> Router Class Initialized
INFO - 2023-02-28 10:54:43 --> Output Class Initialized
INFO - 2023-02-28 10:54:43 --> Output Class Initialized
INFO - 2023-02-28 10:54:43 --> Security Class Initialized
INFO - 2023-02-28 10:54:43 --> Security Class Initialized
DEBUG - 2023-02-28 10:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 10:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:54:43 --> Input Class Initialized
INFO - 2023-02-28 10:54:43 --> Input Class Initialized
INFO - 2023-02-28 10:54:43 --> Language Class Initialized
INFO - 2023-02-28 10:54:43 --> Language Class Initialized
INFO - 2023-02-28 10:54:43 --> Loader Class Initialized
INFO - 2023-02-28 10:54:43 --> Loader Class Initialized
INFO - 2023-02-28 10:54:43 --> Controller Class Initialized
INFO - 2023-02-28 10:54:43 --> Controller Class Initialized
DEBUG - 2023-02-28 10:54:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:54:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:54:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:43 --> Final output sent to browser
INFO - 2023-02-28 10:54:43 --> Final output sent to browser
DEBUG - 2023-02-28 10:54:43 --> Total execution time: 0.0118
DEBUG - 2023-02-28 10:54:43 --> Total execution time: 0.0118
INFO - 2023-02-28 10:54:43 --> Config Class Initialized
INFO - 2023-02-28 10:54:43 --> Config Class Initialized
INFO - 2023-02-28 10:54:43 --> Hooks Class Initialized
INFO - 2023-02-28 10:54:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:54:43 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:54:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:54:43 --> Utf8 Class Initialized
INFO - 2023-02-28 10:54:43 --> Utf8 Class Initialized
INFO - 2023-02-28 10:54:43 --> URI Class Initialized
INFO - 2023-02-28 10:54:43 --> URI Class Initialized
INFO - 2023-02-28 10:54:43 --> Router Class Initialized
INFO - 2023-02-28 10:54:43 --> Router Class Initialized
INFO - 2023-02-28 10:54:43 --> Output Class Initialized
INFO - 2023-02-28 10:54:43 --> Output Class Initialized
INFO - 2023-02-28 10:54:43 --> Security Class Initialized
INFO - 2023-02-28 10:54:43 --> Security Class Initialized
DEBUG - 2023-02-28 10:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 10:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:54:43 --> Input Class Initialized
INFO - 2023-02-28 10:54:43 --> Input Class Initialized
INFO - 2023-02-28 10:54:43 --> Language Class Initialized
INFO - 2023-02-28 10:54:43 --> Language Class Initialized
INFO - 2023-02-28 10:54:43 --> Loader Class Initialized
INFO - 2023-02-28 10:54:43 --> Loader Class Initialized
INFO - 2023-02-28 10:54:43 --> Controller Class Initialized
INFO - 2023-02-28 10:54:43 --> Controller Class Initialized
DEBUG - 2023-02-28 10:54:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:54:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:54:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:43 --> Model "Login_model" initialized
INFO - 2023-02-28 10:54:43 --> Model "Login_model" initialized
INFO - 2023-02-28 10:54:43 --> Final output sent to browser
INFO - 2023-02-28 10:54:43 --> Final output sent to browser
DEBUG - 2023-02-28 10:54:43 --> Total execution time: 0.0199
DEBUG - 2023-02-28 10:54:43 --> Total execution time: 0.0199
INFO - 2023-02-28 10:54:43 --> Config Class Initialized
INFO - 2023-02-28 10:54:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:54:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:54:43 --> Utf8 Class Initialized
INFO - 2023-02-28 10:54:43 --> URI Class Initialized
INFO - 2023-02-28 10:54:43 --> Router Class Initialized
INFO - 2023-02-28 10:54:43 --> Output Class Initialized
INFO - 2023-02-28 10:54:43 --> Security Class Initialized
DEBUG - 2023-02-28 10:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:54:43 --> Input Class Initialized
INFO - 2023-02-28 10:54:43 --> Language Class Initialized
INFO - 2023-02-28 10:54:43 --> Loader Class Initialized
INFO - 2023-02-28 10:54:43 --> Controller Class Initialized
DEBUG - 2023-02-28 10:54:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:54:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:43 --> Final output sent to browser
DEBUG - 2023-02-28 10:54:43 --> Total execution time: 0.0081
INFO - 2023-02-28 10:54:43 --> Config Class Initialized
INFO - 2023-02-28 10:54:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:54:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:54:43 --> Utf8 Class Initialized
INFO - 2023-02-28 10:54:43 --> URI Class Initialized
INFO - 2023-02-28 10:54:43 --> Router Class Initialized
INFO - 2023-02-28 10:54:43 --> Output Class Initialized
INFO - 2023-02-28 10:54:43 --> Security Class Initialized
DEBUG - 2023-02-28 10:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:54:43 --> Input Class Initialized
INFO - 2023-02-28 10:54:43 --> Language Class Initialized
INFO - 2023-02-28 10:54:43 --> Loader Class Initialized
INFO - 2023-02-28 10:54:43 --> Controller Class Initialized
DEBUG - 2023-02-28 10:54:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:54:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:43 --> Final output sent to browser
DEBUG - 2023-02-28 10:54:43 --> Total execution time: 0.4149
INFO - 2023-02-28 10:54:43 --> Config Class Initialized
INFO - 2023-02-28 10:54:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:54:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:54:43 --> Utf8 Class Initialized
INFO - 2023-02-28 10:54:43 --> URI Class Initialized
INFO - 2023-02-28 10:54:43 --> Router Class Initialized
INFO - 2023-02-28 10:54:43 --> Output Class Initialized
INFO - 2023-02-28 10:54:43 --> Security Class Initialized
DEBUG - 2023-02-28 10:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:54:43 --> Input Class Initialized
INFO - 2023-02-28 10:54:43 --> Language Class Initialized
INFO - 2023-02-28 10:54:43 --> Loader Class Initialized
INFO - 2023-02-28 10:54:43 --> Controller Class Initialized
DEBUG - 2023-02-28 10:54:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:54:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:43 --> Model "Login_model" initialized
INFO - 2023-02-28 10:54:43 --> Final output sent to browser
DEBUG - 2023-02-28 10:54:43 --> Total execution time: 0.0266
INFO - 2023-02-28 10:54:43 --> Config Class Initialized
INFO - 2023-02-28 10:54:43 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:54:43 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:54:43 --> Utf8 Class Initialized
INFO - 2023-02-28 10:54:43 --> URI Class Initialized
INFO - 2023-02-28 10:54:43 --> Router Class Initialized
INFO - 2023-02-28 10:54:43 --> Output Class Initialized
INFO - 2023-02-28 10:54:43 --> Security Class Initialized
DEBUG - 2023-02-28 10:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:54:43 --> Input Class Initialized
INFO - 2023-02-28 10:54:43 --> Language Class Initialized
INFO - 2023-02-28 10:54:43 --> Loader Class Initialized
INFO - 2023-02-28 10:54:43 --> Controller Class Initialized
DEBUG - 2023-02-28 10:54:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:54:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:43 --> Database Driver Class Initialized
INFO - 2023-02-28 10:54:43 --> Model "Login_model" initialized
INFO - 2023-02-28 10:54:43 --> Final output sent to browser
DEBUG - 2023-02-28 10:54:43 --> Total execution time: 0.0184
INFO - 2023-02-28 10:56:34 --> Config Class Initialized
INFO - 2023-02-28 10:56:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:56:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:56:34 --> Utf8 Class Initialized
INFO - 2023-02-28 10:56:34 --> URI Class Initialized
INFO - 2023-02-28 10:56:34 --> Router Class Initialized
INFO - 2023-02-28 10:56:34 --> Output Class Initialized
INFO - 2023-02-28 10:56:34 --> Security Class Initialized
DEBUG - 2023-02-28 10:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:56:34 --> Input Class Initialized
INFO - 2023-02-28 10:56:34 --> Language Class Initialized
INFO - 2023-02-28 10:56:34 --> Loader Class Initialized
INFO - 2023-02-28 10:56:34 --> Controller Class Initialized
DEBUG - 2023-02-28 10:56:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:56:34 --> Database Driver Class Initialized
INFO - 2023-02-28 10:56:34 --> Database Driver Class Initialized
INFO - 2023-02-28 10:56:34 --> Model "Login_model" initialized
INFO - 2023-02-28 10:56:34 --> Final output sent to browser
DEBUG - 2023-02-28 10:56:34 --> Total execution time: 0.1037
INFO - 2023-02-28 10:56:34 --> Config Class Initialized
INFO - 2023-02-28 10:56:34 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:56:34 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:56:34 --> Utf8 Class Initialized
INFO - 2023-02-28 10:56:34 --> URI Class Initialized
INFO - 2023-02-28 10:56:34 --> Router Class Initialized
INFO - 2023-02-28 10:56:34 --> Output Class Initialized
INFO - 2023-02-28 10:56:34 --> Security Class Initialized
DEBUG - 2023-02-28 10:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:56:34 --> Input Class Initialized
INFO - 2023-02-28 10:56:34 --> Language Class Initialized
INFO - 2023-02-28 10:56:34 --> Loader Class Initialized
INFO - 2023-02-28 10:56:34 --> Controller Class Initialized
DEBUG - 2023-02-28 10:56:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:56:34 --> Database Driver Class Initialized
INFO - 2023-02-28 10:56:34 --> Database Driver Class Initialized
INFO - 2023-02-28 10:56:34 --> Model "Login_model" initialized
INFO - 2023-02-28 10:56:34 --> Final output sent to browser
DEBUG - 2023-02-28 10:56:34 --> Total execution time: 0.0236
INFO - 2023-02-28 10:56:45 --> Config Class Initialized
INFO - 2023-02-28 10:56:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:56:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:56:45 --> Utf8 Class Initialized
INFO - 2023-02-28 10:56:45 --> URI Class Initialized
INFO - 2023-02-28 10:56:45 --> Router Class Initialized
INFO - 2023-02-28 10:56:45 --> Output Class Initialized
INFO - 2023-02-28 10:56:45 --> Security Class Initialized
DEBUG - 2023-02-28 10:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:56:45 --> Input Class Initialized
INFO - 2023-02-28 10:56:45 --> Language Class Initialized
INFO - 2023-02-28 10:56:45 --> Loader Class Initialized
INFO - 2023-02-28 10:56:45 --> Controller Class Initialized
DEBUG - 2023-02-28 10:56:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:56:45 --> Database Driver Class Initialized
INFO - 2023-02-28 10:56:45 --> Final output sent to browser
DEBUG - 2023-02-28 10:56:45 --> Total execution time: 0.0133
INFO - 2023-02-28 10:56:45 --> Config Class Initialized
INFO - 2023-02-28 10:56:45 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:56:45 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:56:45 --> Utf8 Class Initialized
INFO - 2023-02-28 10:56:45 --> URI Class Initialized
INFO - 2023-02-28 10:56:45 --> Router Class Initialized
INFO - 2023-02-28 10:56:45 --> Output Class Initialized
INFO - 2023-02-28 10:56:45 --> Security Class Initialized
DEBUG - 2023-02-28 10:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:56:45 --> Input Class Initialized
INFO - 2023-02-28 10:56:45 --> Language Class Initialized
INFO - 2023-02-28 10:56:45 --> Loader Class Initialized
INFO - 2023-02-28 10:56:45 --> Controller Class Initialized
DEBUG - 2023-02-28 10:56:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:56:45 --> Database Driver Class Initialized
INFO - 2023-02-28 10:56:45 --> Database Driver Class Initialized
INFO - 2023-02-28 10:56:45 --> Model "Login_model" initialized
INFO - 2023-02-28 10:56:45 --> Final output sent to browser
DEBUG - 2023-02-28 10:56:45 --> Total execution time: 0.0208
INFO - 2023-02-28 10:57:22 --> Config Class Initialized
INFO - 2023-02-28 10:57:22 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:57:22 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:57:22 --> Utf8 Class Initialized
INFO - 2023-02-28 10:57:22 --> URI Class Initialized
INFO - 2023-02-28 10:57:22 --> Router Class Initialized
INFO - 2023-02-28 10:57:22 --> Output Class Initialized
INFO - 2023-02-28 10:57:22 --> Security Class Initialized
DEBUG - 2023-02-28 10:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:57:22 --> Input Class Initialized
INFO - 2023-02-28 10:57:22 --> Language Class Initialized
INFO - 2023-02-28 10:57:22 --> Loader Class Initialized
INFO - 2023-02-28 10:57:22 --> Controller Class Initialized
DEBUG - 2023-02-28 10:57:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:57:22 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:22 --> Final output sent to browser
DEBUG - 2023-02-28 10:57:22 --> Total execution time: 0.0138
INFO - 2023-02-28 10:57:22 --> Config Class Initialized
INFO - 2023-02-28 10:57:22 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:57:22 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:57:22 --> Utf8 Class Initialized
INFO - 2023-02-28 10:57:22 --> URI Class Initialized
INFO - 2023-02-28 10:57:22 --> Router Class Initialized
INFO - 2023-02-28 10:57:22 --> Output Class Initialized
INFO - 2023-02-28 10:57:22 --> Security Class Initialized
DEBUG - 2023-02-28 10:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:57:22 --> Input Class Initialized
INFO - 2023-02-28 10:57:22 --> Language Class Initialized
INFO - 2023-02-28 10:57:22 --> Loader Class Initialized
INFO - 2023-02-28 10:57:22 --> Controller Class Initialized
DEBUG - 2023-02-28 10:57:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:57:22 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:22 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:22 --> Model "Login_model" initialized
INFO - 2023-02-28 10:57:22 --> Final output sent to browser
DEBUG - 2023-02-28 10:57:22 --> Total execution time: 0.0198
INFO - 2023-02-28 10:57:30 --> Config Class Initialized
INFO - 2023-02-28 10:57:30 --> Config Class Initialized
INFO - 2023-02-28 10:57:30 --> Hooks Class Initialized
INFO - 2023-02-28 10:57:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:57:30 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:57:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:57:30 --> Utf8 Class Initialized
INFO - 2023-02-28 10:57:30 --> Utf8 Class Initialized
INFO - 2023-02-28 10:57:30 --> URI Class Initialized
INFO - 2023-02-28 10:57:30 --> URI Class Initialized
INFO - 2023-02-28 10:57:30 --> Router Class Initialized
INFO - 2023-02-28 10:57:30 --> Router Class Initialized
INFO - 2023-02-28 10:57:30 --> Output Class Initialized
INFO - 2023-02-28 10:57:30 --> Output Class Initialized
INFO - 2023-02-28 10:57:30 --> Security Class Initialized
INFO - 2023-02-28 10:57:30 --> Security Class Initialized
DEBUG - 2023-02-28 10:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 10:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:57:30 --> Input Class Initialized
INFO - 2023-02-28 10:57:30 --> Input Class Initialized
INFO - 2023-02-28 10:57:30 --> Language Class Initialized
INFO - 2023-02-28 10:57:30 --> Language Class Initialized
INFO - 2023-02-28 10:57:30 --> Loader Class Initialized
INFO - 2023-02-28 10:57:30 --> Loader Class Initialized
INFO - 2023-02-28 10:57:30 --> Controller Class Initialized
INFO - 2023-02-28 10:57:30 --> Controller Class Initialized
DEBUG - 2023-02-28 10:57:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:57:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:57:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:30 --> Final output sent to browser
INFO - 2023-02-28 10:57:30 --> Final output sent to browser
DEBUG - 2023-02-28 10:57:30 --> Total execution time: 0.0169
DEBUG - 2023-02-28 10:57:30 --> Total execution time: 0.0169
INFO - 2023-02-28 10:57:30 --> Config Class Initialized
INFO - 2023-02-28 10:57:30 --> Config Class Initialized
INFO - 2023-02-28 10:57:30 --> Hooks Class Initialized
INFO - 2023-02-28 10:57:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:57:30 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:57:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:57:30 --> Utf8 Class Initialized
INFO - 2023-02-28 10:57:30 --> Utf8 Class Initialized
INFO - 2023-02-28 10:57:30 --> URI Class Initialized
INFO - 2023-02-28 10:57:30 --> URI Class Initialized
INFO - 2023-02-28 10:57:30 --> Router Class Initialized
INFO - 2023-02-28 10:57:30 --> Router Class Initialized
INFO - 2023-02-28 10:57:30 --> Output Class Initialized
INFO - 2023-02-28 10:57:30 --> Output Class Initialized
INFO - 2023-02-28 10:57:30 --> Security Class Initialized
DEBUG - 2023-02-28 10:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:57:30 --> Security Class Initialized
INFO - 2023-02-28 10:57:30 --> Input Class Initialized
DEBUG - 2023-02-28 10:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:57:30 --> Language Class Initialized
INFO - 2023-02-28 10:57:30 --> Input Class Initialized
INFO - 2023-02-28 10:57:30 --> Language Class Initialized
INFO - 2023-02-28 10:57:30 --> Loader Class Initialized
INFO - 2023-02-28 10:57:30 --> Loader Class Initialized
INFO - 2023-02-28 10:57:30 --> Controller Class Initialized
INFO - 2023-02-28 10:57:30 --> Controller Class Initialized
DEBUG - 2023-02-28 10:57:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:57:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:57:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:30 --> Model "Login_model" initialized
INFO - 2023-02-28 10:57:30 --> Model "Login_model" initialized
INFO - 2023-02-28 10:57:30 --> Final output sent to browser
INFO - 2023-02-28 10:57:30 --> Final output sent to browser
DEBUG - 2023-02-28 10:57:30 --> Total execution time: 0.0277
DEBUG - 2023-02-28 10:57:30 --> Total execution time: 0.0278
INFO - 2023-02-28 10:57:30 --> Config Class Initialized
INFO - 2023-02-28 10:57:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:57:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:57:30 --> Utf8 Class Initialized
INFO - 2023-02-28 10:57:30 --> URI Class Initialized
INFO - 2023-02-28 10:57:30 --> Router Class Initialized
INFO - 2023-02-28 10:57:30 --> Output Class Initialized
INFO - 2023-02-28 10:57:30 --> Security Class Initialized
DEBUG - 2023-02-28 10:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:57:30 --> Input Class Initialized
INFO - 2023-02-28 10:57:30 --> Language Class Initialized
INFO - 2023-02-28 10:57:30 --> Loader Class Initialized
INFO - 2023-02-28 10:57:30 --> Controller Class Initialized
DEBUG - 2023-02-28 10:57:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:57:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:30 --> Final output sent to browser
DEBUG - 2023-02-28 10:57:30 --> Total execution time: 0.0089
INFO - 2023-02-28 10:57:30 --> Config Class Initialized
INFO - 2023-02-28 10:57:30 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:57:30 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:57:30 --> Utf8 Class Initialized
INFO - 2023-02-28 10:57:30 --> URI Class Initialized
INFO - 2023-02-28 10:57:30 --> Router Class Initialized
INFO - 2023-02-28 10:57:30 --> Output Class Initialized
INFO - 2023-02-28 10:57:30 --> Security Class Initialized
DEBUG - 2023-02-28 10:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:57:30 --> Input Class Initialized
INFO - 2023-02-28 10:57:30 --> Language Class Initialized
INFO - 2023-02-28 10:57:30 --> Loader Class Initialized
INFO - 2023-02-28 10:57:30 --> Controller Class Initialized
DEBUG - 2023-02-28 10:57:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:57:30 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:30 --> Final output sent to browser
DEBUG - 2023-02-28 10:57:30 --> Total execution time: 0.0541
INFO - 2023-02-28 10:57:52 --> Config Class Initialized
INFO - 2023-02-28 10:57:52 --> Config Class Initialized
INFO - 2023-02-28 10:57:52 --> Hooks Class Initialized
INFO - 2023-02-28 10:57:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:57:52 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:57:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:57:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:57:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:57:52 --> URI Class Initialized
INFO - 2023-02-28 10:57:52 --> URI Class Initialized
INFO - 2023-02-28 10:57:52 --> Router Class Initialized
INFO - 2023-02-28 10:57:52 --> Router Class Initialized
INFO - 2023-02-28 10:57:52 --> Output Class Initialized
INFO - 2023-02-28 10:57:52 --> Output Class Initialized
INFO - 2023-02-28 10:57:52 --> Security Class Initialized
INFO - 2023-02-28 10:57:52 --> Security Class Initialized
DEBUG - 2023-02-28 10:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 10:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:57:52 --> Input Class Initialized
INFO - 2023-02-28 10:57:52 --> Input Class Initialized
INFO - 2023-02-28 10:57:52 --> Language Class Initialized
INFO - 2023-02-28 10:57:52 --> Language Class Initialized
INFO - 2023-02-28 10:57:52 --> Loader Class Initialized
INFO - 2023-02-28 10:57:52 --> Loader Class Initialized
INFO - 2023-02-28 10:57:52 --> Controller Class Initialized
INFO - 2023-02-28 10:57:52 --> Controller Class Initialized
DEBUG - 2023-02-28 10:57:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:57:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:57:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:52 --> Final output sent to browser
INFO - 2023-02-28 10:57:52 --> Final output sent to browser
DEBUG - 2023-02-28 10:57:52 --> Total execution time: 0.0121
DEBUG - 2023-02-28 10:57:52 --> Total execution time: 0.0121
INFO - 2023-02-28 10:57:52 --> Config Class Initialized
INFO - 2023-02-28 10:57:52 --> Config Class Initialized
INFO - 2023-02-28 10:57:52 --> Hooks Class Initialized
INFO - 2023-02-28 10:57:52 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:57:52 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:57:52 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:57:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:57:52 --> Utf8 Class Initialized
INFO - 2023-02-28 10:57:52 --> URI Class Initialized
INFO - 2023-02-28 10:57:52 --> URI Class Initialized
INFO - 2023-02-28 10:57:52 --> Router Class Initialized
INFO - 2023-02-28 10:57:52 --> Router Class Initialized
INFO - 2023-02-28 10:57:52 --> Output Class Initialized
INFO - 2023-02-28 10:57:52 --> Output Class Initialized
INFO - 2023-02-28 10:57:52 --> Security Class Initialized
INFO - 2023-02-28 10:57:52 --> Security Class Initialized
DEBUG - 2023-02-28 10:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 10:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:57:52 --> Input Class Initialized
INFO - 2023-02-28 10:57:52 --> Input Class Initialized
INFO - 2023-02-28 10:57:52 --> Language Class Initialized
INFO - 2023-02-28 10:57:52 --> Language Class Initialized
INFO - 2023-02-28 10:57:52 --> Loader Class Initialized
INFO - 2023-02-28 10:57:52 --> Loader Class Initialized
INFO - 2023-02-28 10:57:52 --> Controller Class Initialized
INFO - 2023-02-28 10:57:52 --> Controller Class Initialized
DEBUG - 2023-02-28 10:57:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:57:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:57:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:52 --> Database Driver Class Initialized
INFO - 2023-02-28 10:57:52 --> Model "Login_model" initialized
INFO - 2023-02-28 10:57:52 --> Model "Login_model" initialized
INFO - 2023-02-28 10:57:52 --> Final output sent to browser
DEBUG - 2023-02-28 10:57:52 --> Total execution time: 0.0212
INFO - 2023-02-28 10:57:52 --> Final output sent to browser
DEBUG - 2023-02-28 10:57:52 --> Total execution time: 0.0233
INFO - 2023-02-28 10:58:00 --> Config Class Initialized
INFO - 2023-02-28 10:58:00 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:58:00 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:58:00 --> Utf8 Class Initialized
INFO - 2023-02-28 10:58:00 --> URI Class Initialized
INFO - 2023-02-28 10:58:00 --> Router Class Initialized
INFO - 2023-02-28 10:58:00 --> Output Class Initialized
INFO - 2023-02-28 10:58:00 --> Security Class Initialized
DEBUG - 2023-02-28 10:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:58:00 --> Input Class Initialized
INFO - 2023-02-28 10:58:00 --> Language Class Initialized
INFO - 2023-02-28 10:58:00 --> Loader Class Initialized
INFO - 2023-02-28 10:58:00 --> Controller Class Initialized
DEBUG - 2023-02-28 10:58:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:58:00 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:00 --> Final output sent to browser
DEBUG - 2023-02-28 10:58:00 --> Total execution time: 0.0170
INFO - 2023-02-28 10:58:00 --> Config Class Initialized
INFO - 2023-02-28 10:58:00 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:58:00 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:58:00 --> Utf8 Class Initialized
INFO - 2023-02-28 10:58:00 --> URI Class Initialized
INFO - 2023-02-28 10:58:00 --> Router Class Initialized
INFO - 2023-02-28 10:58:00 --> Output Class Initialized
INFO - 2023-02-28 10:58:00 --> Security Class Initialized
DEBUG - 2023-02-28 10:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:58:00 --> Input Class Initialized
INFO - 2023-02-28 10:58:00 --> Language Class Initialized
INFO - 2023-02-28 10:58:00 --> Loader Class Initialized
INFO - 2023-02-28 10:58:00 --> Controller Class Initialized
DEBUG - 2023-02-28 10:58:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:58:00 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:00 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:00 --> Model "Login_model" initialized
INFO - 2023-02-28 10:58:00 --> Final output sent to browser
DEBUG - 2023-02-28 10:58:00 --> Total execution time: 0.0183
INFO - 2023-02-28 10:58:05 --> Config Class Initialized
INFO - 2023-02-28 10:58:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:58:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:58:05 --> Utf8 Class Initialized
INFO - 2023-02-28 10:58:05 --> URI Class Initialized
INFO - 2023-02-28 10:58:05 --> Router Class Initialized
INFO - 2023-02-28 10:58:05 --> Output Class Initialized
INFO - 2023-02-28 10:58:05 --> Security Class Initialized
DEBUG - 2023-02-28 10:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:58:05 --> Input Class Initialized
INFO - 2023-02-28 10:58:05 --> Language Class Initialized
INFO - 2023-02-28 10:58:05 --> Loader Class Initialized
INFO - 2023-02-28 10:58:05 --> Controller Class Initialized
DEBUG - 2023-02-28 10:58:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:58:05 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:05 --> Final output sent to browser
DEBUG - 2023-02-28 10:58:05 --> Total execution time: 0.0129
INFO - 2023-02-28 10:58:05 --> Config Class Initialized
INFO - 2023-02-28 10:58:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:58:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:58:05 --> Utf8 Class Initialized
INFO - 2023-02-28 10:58:05 --> URI Class Initialized
INFO - 2023-02-28 10:58:05 --> Router Class Initialized
INFO - 2023-02-28 10:58:05 --> Output Class Initialized
INFO - 2023-02-28 10:58:05 --> Security Class Initialized
DEBUG - 2023-02-28 10:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:58:05 --> Input Class Initialized
INFO - 2023-02-28 10:58:05 --> Language Class Initialized
INFO - 2023-02-28 10:58:05 --> Loader Class Initialized
INFO - 2023-02-28 10:58:05 --> Controller Class Initialized
DEBUG - 2023-02-28 10:58:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:58:05 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:05 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:05 --> Model "Login_model" initialized
INFO - 2023-02-28 10:58:05 --> Final output sent to browser
DEBUG - 2023-02-28 10:58:05 --> Total execution time: 0.0174
INFO - 2023-02-28 10:58:06 --> Config Class Initialized
INFO - 2023-02-28 10:58:06 --> Config Class Initialized
INFO - 2023-02-28 10:58:06 --> Hooks Class Initialized
INFO - 2023-02-28 10:58:06 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:58:06 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:58:06 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:58:06 --> Utf8 Class Initialized
INFO - 2023-02-28 10:58:06 --> Utf8 Class Initialized
INFO - 2023-02-28 10:58:06 --> URI Class Initialized
INFO - 2023-02-28 10:58:06 --> URI Class Initialized
INFO - 2023-02-28 10:58:06 --> Router Class Initialized
INFO - 2023-02-28 10:58:06 --> Router Class Initialized
INFO - 2023-02-28 10:58:06 --> Output Class Initialized
INFO - 2023-02-28 10:58:06 --> Output Class Initialized
INFO - 2023-02-28 10:58:06 --> Security Class Initialized
INFO - 2023-02-28 10:58:06 --> Security Class Initialized
DEBUG - 2023-02-28 10:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 10:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:58:06 --> Input Class Initialized
INFO - 2023-02-28 10:58:06 --> Input Class Initialized
INFO - 2023-02-28 10:58:06 --> Language Class Initialized
INFO - 2023-02-28 10:58:06 --> Language Class Initialized
INFO - 2023-02-28 10:58:06 --> Loader Class Initialized
INFO - 2023-02-28 10:58:06 --> Loader Class Initialized
INFO - 2023-02-28 10:58:06 --> Controller Class Initialized
INFO - 2023-02-28 10:58:06 --> Controller Class Initialized
DEBUG - 2023-02-28 10:58:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:58:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:58:06 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:06 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:06 --> Final output sent to browser
INFO - 2023-02-28 10:58:06 --> Database Driver Class Initialized
DEBUG - 2023-02-28 10:58:06 --> Total execution time: 0.0169
INFO - 2023-02-28 10:58:06 --> Config Class Initialized
INFO - 2023-02-28 10:58:06 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:58:06 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:58:06 --> Utf8 Class Initialized
INFO - 2023-02-28 10:58:06 --> URI Class Initialized
INFO - 2023-02-28 10:58:06 --> Router Class Initialized
INFO - 2023-02-28 10:58:06 --> Output Class Initialized
INFO - 2023-02-28 10:58:06 --> Security Class Initialized
DEBUG - 2023-02-28 10:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:58:06 --> Input Class Initialized
INFO - 2023-02-28 10:58:06 --> Language Class Initialized
INFO - 2023-02-28 10:58:06 --> Loader Class Initialized
INFO - 2023-02-28 10:58:06 --> Controller Class Initialized
DEBUG - 2023-02-28 10:58:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:58:06 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:06 --> Model "Login_model" initialized
INFO - 2023-02-28 10:58:06 --> Final output sent to browser
DEBUG - 2023-02-28 10:58:06 --> Total execution time: 0.0276
INFO - 2023-02-28 10:58:06 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:06 --> Model "Login_model" initialized
INFO - 2023-02-28 10:58:06 --> Final output sent to browser
DEBUG - 2023-02-28 10:58:06 --> Total execution time: 0.0189
INFO - 2023-02-28 10:58:06 --> Config Class Initialized
INFO - 2023-02-28 10:58:06 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:58:06 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:58:06 --> Utf8 Class Initialized
INFO - 2023-02-28 10:58:06 --> URI Class Initialized
INFO - 2023-02-28 10:58:06 --> Router Class Initialized
INFO - 2023-02-28 10:58:06 --> Output Class Initialized
INFO - 2023-02-28 10:58:06 --> Security Class Initialized
DEBUG - 2023-02-28 10:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:58:06 --> Input Class Initialized
INFO - 2023-02-28 10:58:06 --> Language Class Initialized
INFO - 2023-02-28 10:58:06 --> Loader Class Initialized
INFO - 2023-02-28 10:58:06 --> Controller Class Initialized
DEBUG - 2023-02-28 10:58:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:58:06 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:06 --> Final output sent to browser
DEBUG - 2023-02-28 10:58:06 --> Total execution time: 0.0109
INFO - 2023-02-28 10:58:06 --> Config Class Initialized
INFO - 2023-02-28 10:58:06 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:58:06 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:58:06 --> Utf8 Class Initialized
INFO - 2023-02-28 10:58:06 --> URI Class Initialized
INFO - 2023-02-28 10:58:06 --> Router Class Initialized
INFO - 2023-02-28 10:58:06 --> Output Class Initialized
INFO - 2023-02-28 10:58:06 --> Security Class Initialized
DEBUG - 2023-02-28 10:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:58:06 --> Input Class Initialized
INFO - 2023-02-28 10:58:06 --> Language Class Initialized
INFO - 2023-02-28 10:58:06 --> Loader Class Initialized
INFO - 2023-02-28 10:58:06 --> Controller Class Initialized
DEBUG - 2023-02-28 10:58:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:58:06 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:06 --> Final output sent to browser
DEBUG - 2023-02-28 10:58:06 --> Total execution time: 0.0799
INFO - 2023-02-28 10:58:26 --> Config Class Initialized
INFO - 2023-02-28 10:58:26 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:58:26 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:58:26 --> Utf8 Class Initialized
INFO - 2023-02-28 10:58:26 --> URI Class Initialized
INFO - 2023-02-28 10:58:26 --> Router Class Initialized
INFO - 2023-02-28 10:58:26 --> Output Class Initialized
INFO - 2023-02-28 10:58:26 --> Security Class Initialized
DEBUG - 2023-02-28 10:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:58:26 --> Input Class Initialized
INFO - 2023-02-28 10:58:26 --> Language Class Initialized
INFO - 2023-02-28 10:58:26 --> Loader Class Initialized
INFO - 2023-02-28 10:58:26 --> Controller Class Initialized
DEBUG - 2023-02-28 10:58:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:58:26 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:26 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:26 --> Model "Login_model" initialized
INFO - 2023-02-28 10:58:26 --> Final output sent to browser
DEBUG - 2023-02-28 10:58:26 --> Total execution time: 0.0243
INFO - 2023-02-28 10:58:26 --> Config Class Initialized
INFO - 2023-02-28 10:58:26 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:58:26 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:58:26 --> Utf8 Class Initialized
INFO - 2023-02-28 10:58:26 --> URI Class Initialized
INFO - 2023-02-28 10:58:26 --> Router Class Initialized
INFO - 2023-02-28 10:58:26 --> Output Class Initialized
INFO - 2023-02-28 10:58:26 --> Security Class Initialized
DEBUG - 2023-02-28 10:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:58:26 --> Input Class Initialized
INFO - 2023-02-28 10:58:26 --> Language Class Initialized
INFO - 2023-02-28 10:58:26 --> Loader Class Initialized
INFO - 2023-02-28 10:58:26 --> Controller Class Initialized
DEBUG - 2023-02-28 10:58:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:58:26 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:26 --> Database Driver Class Initialized
INFO - 2023-02-28 10:58:26 --> Model "Login_model" initialized
INFO - 2023-02-28 10:58:26 --> Final output sent to browser
DEBUG - 2023-02-28 10:58:26 --> Total execution time: 0.0256
INFO - 2023-02-28 10:59:10 --> Config Class Initialized
INFO - 2023-02-28 10:59:10 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:59:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:59:10 --> Utf8 Class Initialized
INFO - 2023-02-28 10:59:10 --> URI Class Initialized
INFO - 2023-02-28 10:59:10 --> Router Class Initialized
INFO - 2023-02-28 10:59:10 --> Output Class Initialized
INFO - 2023-02-28 10:59:10 --> Security Class Initialized
DEBUG - 2023-02-28 10:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:59:10 --> Input Class Initialized
INFO - 2023-02-28 10:59:10 --> Language Class Initialized
INFO - 2023-02-28 10:59:10 --> Loader Class Initialized
INFO - 2023-02-28 10:59:10 --> Controller Class Initialized
DEBUG - 2023-02-28 10:59:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:59:10 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:10 --> Final output sent to browser
DEBUG - 2023-02-28 10:59:10 --> Total execution time: 0.0140
INFO - 2023-02-28 10:59:10 --> Config Class Initialized
INFO - 2023-02-28 10:59:10 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:59:10 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:59:10 --> Utf8 Class Initialized
INFO - 2023-02-28 10:59:10 --> URI Class Initialized
INFO - 2023-02-28 10:59:10 --> Router Class Initialized
INFO - 2023-02-28 10:59:10 --> Output Class Initialized
INFO - 2023-02-28 10:59:10 --> Security Class Initialized
DEBUG - 2023-02-28 10:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:59:10 --> Input Class Initialized
INFO - 2023-02-28 10:59:10 --> Language Class Initialized
INFO - 2023-02-28 10:59:10 --> Loader Class Initialized
INFO - 2023-02-28 10:59:10 --> Controller Class Initialized
DEBUG - 2023-02-28 10:59:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:59:10 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:10 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:10 --> Model "Login_model" initialized
INFO - 2023-02-28 10:59:10 --> Final output sent to browser
DEBUG - 2023-02-28 10:59:10 --> Total execution time: 0.0178
INFO - 2023-02-28 10:59:33 --> Config Class Initialized
INFO - 2023-02-28 10:59:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:59:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:59:33 --> Utf8 Class Initialized
INFO - 2023-02-28 10:59:33 --> URI Class Initialized
INFO - 2023-02-28 10:59:33 --> Router Class Initialized
INFO - 2023-02-28 10:59:33 --> Output Class Initialized
INFO - 2023-02-28 10:59:33 --> Security Class Initialized
DEBUG - 2023-02-28 10:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:59:33 --> Input Class Initialized
INFO - 2023-02-28 10:59:33 --> Language Class Initialized
INFO - 2023-02-28 10:59:33 --> Loader Class Initialized
INFO - 2023-02-28 10:59:33 --> Controller Class Initialized
DEBUG - 2023-02-28 10:59:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:59:33 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:33 --> Final output sent to browser
DEBUG - 2023-02-28 10:59:33 --> Total execution time: 0.0148
INFO - 2023-02-28 10:59:33 --> Config Class Initialized
INFO - 2023-02-28 10:59:33 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:59:33 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:59:33 --> Utf8 Class Initialized
INFO - 2023-02-28 10:59:33 --> URI Class Initialized
INFO - 2023-02-28 10:59:33 --> Router Class Initialized
INFO - 2023-02-28 10:59:33 --> Output Class Initialized
INFO - 2023-02-28 10:59:33 --> Security Class Initialized
DEBUG - 2023-02-28 10:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:59:33 --> Input Class Initialized
INFO - 2023-02-28 10:59:33 --> Language Class Initialized
INFO - 2023-02-28 10:59:33 --> Loader Class Initialized
INFO - 2023-02-28 10:59:33 --> Controller Class Initialized
DEBUG - 2023-02-28 10:59:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:59:33 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:33 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:33 --> Model "Login_model" initialized
INFO - 2023-02-28 10:59:33 --> Final output sent to browser
DEBUG - 2023-02-28 10:59:33 --> Total execution time: 0.0209
INFO - 2023-02-28 10:59:39 --> Config Class Initialized
INFO - 2023-02-28 10:59:39 --> Hooks Class Initialized
INFO - 2023-02-28 10:59:39 --> Config Class Initialized
DEBUG - 2023-02-28 10:59:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:59:39 --> Hooks Class Initialized
INFO - 2023-02-28 10:59:39 --> Utf8 Class Initialized
DEBUG - 2023-02-28 10:59:39 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:59:39 --> URI Class Initialized
INFO - 2023-02-28 10:59:39 --> Utf8 Class Initialized
INFO - 2023-02-28 10:59:39 --> Router Class Initialized
INFO - 2023-02-28 10:59:39 --> URI Class Initialized
INFO - 2023-02-28 10:59:39 --> Output Class Initialized
INFO - 2023-02-28 10:59:39 --> Router Class Initialized
INFO - 2023-02-28 10:59:39 --> Security Class Initialized
INFO - 2023-02-28 10:59:39 --> Output Class Initialized
DEBUG - 2023-02-28 10:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:59:39 --> Security Class Initialized
INFO - 2023-02-28 10:59:39 --> Input Class Initialized
DEBUG - 2023-02-28 10:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:59:39 --> Language Class Initialized
INFO - 2023-02-28 10:59:39 --> Input Class Initialized
INFO - 2023-02-28 10:59:39 --> Language Class Initialized
INFO - 2023-02-28 10:59:39 --> Loader Class Initialized
INFO - 2023-02-28 10:59:39 --> Loader Class Initialized
INFO - 2023-02-28 10:59:39 --> Controller Class Initialized
INFO - 2023-02-28 10:59:39 --> Controller Class Initialized
DEBUG - 2023-02-28 10:59:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:59:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:59:39 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:39 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:39 --> Final output sent to browser
INFO - 2023-02-28 10:59:39 --> Final output sent to browser
DEBUG - 2023-02-28 10:59:39 --> Total execution time: 0.0116
DEBUG - 2023-02-28 10:59:39 --> Total execution time: 0.0116
INFO - 2023-02-28 10:59:40 --> Config Class Initialized
INFO - 2023-02-28 10:59:40 --> Config Class Initialized
INFO - 2023-02-28 10:59:40 --> Hooks Class Initialized
INFO - 2023-02-28 10:59:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:59:40 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 10:59:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:59:40 --> Utf8 Class Initialized
INFO - 2023-02-28 10:59:40 --> Utf8 Class Initialized
INFO - 2023-02-28 10:59:40 --> URI Class Initialized
INFO - 2023-02-28 10:59:40 --> URI Class Initialized
INFO - 2023-02-28 10:59:40 --> Router Class Initialized
INFO - 2023-02-28 10:59:40 --> Router Class Initialized
INFO - 2023-02-28 10:59:40 --> Output Class Initialized
INFO - 2023-02-28 10:59:40 --> Output Class Initialized
INFO - 2023-02-28 10:59:40 --> Security Class Initialized
INFO - 2023-02-28 10:59:40 --> Security Class Initialized
DEBUG - 2023-02-28 10:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 10:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:59:40 --> Input Class Initialized
INFO - 2023-02-28 10:59:40 --> Input Class Initialized
INFO - 2023-02-28 10:59:40 --> Language Class Initialized
INFO - 2023-02-28 10:59:40 --> Language Class Initialized
INFO - 2023-02-28 10:59:40 --> Loader Class Initialized
INFO - 2023-02-28 10:59:40 --> Loader Class Initialized
INFO - 2023-02-28 10:59:40 --> Controller Class Initialized
INFO - 2023-02-28 10:59:40 --> Controller Class Initialized
DEBUG - 2023-02-28 10:59:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 10:59:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:59:40 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:40 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:40 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:40 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:40 --> Model "Login_model" initialized
INFO - 2023-02-28 10:59:40 --> Model "Login_model" initialized
INFO - 2023-02-28 10:59:40 --> Final output sent to browser
INFO - 2023-02-28 10:59:40 --> Final output sent to browser
DEBUG - 2023-02-28 10:59:40 --> Total execution time: 0.0213
DEBUG - 2023-02-28 10:59:40 --> Total execution time: 0.0214
INFO - 2023-02-28 10:59:40 --> Config Class Initialized
INFO - 2023-02-28 10:59:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:59:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:59:40 --> Utf8 Class Initialized
INFO - 2023-02-28 10:59:40 --> URI Class Initialized
INFO - 2023-02-28 10:59:40 --> Router Class Initialized
INFO - 2023-02-28 10:59:40 --> Output Class Initialized
INFO - 2023-02-28 10:59:40 --> Security Class Initialized
DEBUG - 2023-02-28 10:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:59:40 --> Input Class Initialized
INFO - 2023-02-28 10:59:40 --> Language Class Initialized
INFO - 2023-02-28 10:59:40 --> Loader Class Initialized
INFO - 2023-02-28 10:59:40 --> Controller Class Initialized
DEBUG - 2023-02-28 10:59:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:59:40 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:40 --> Final output sent to browser
DEBUG - 2023-02-28 10:59:40 --> Total execution time: 0.0094
INFO - 2023-02-28 10:59:40 --> Config Class Initialized
INFO - 2023-02-28 10:59:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:59:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:59:40 --> Utf8 Class Initialized
INFO - 2023-02-28 10:59:40 --> URI Class Initialized
INFO - 2023-02-28 10:59:40 --> Router Class Initialized
INFO - 2023-02-28 10:59:40 --> Output Class Initialized
INFO - 2023-02-28 10:59:40 --> Security Class Initialized
DEBUG - 2023-02-28 10:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:59:40 --> Input Class Initialized
INFO - 2023-02-28 10:59:40 --> Language Class Initialized
INFO - 2023-02-28 10:59:40 --> Loader Class Initialized
INFO - 2023-02-28 10:59:40 --> Controller Class Initialized
DEBUG - 2023-02-28 10:59:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:59:40 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:40 --> Final output sent to browser
DEBUG - 2023-02-28 10:59:40 --> Total execution time: 0.3581
INFO - 2023-02-28 10:59:40 --> Config Class Initialized
INFO - 2023-02-28 10:59:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:59:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:59:40 --> Utf8 Class Initialized
INFO - 2023-02-28 10:59:40 --> URI Class Initialized
INFO - 2023-02-28 10:59:40 --> Router Class Initialized
INFO - 2023-02-28 10:59:40 --> Output Class Initialized
INFO - 2023-02-28 10:59:40 --> Security Class Initialized
DEBUG - 2023-02-28 10:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:59:40 --> Input Class Initialized
INFO - 2023-02-28 10:59:40 --> Language Class Initialized
INFO - 2023-02-28 10:59:40 --> Loader Class Initialized
INFO - 2023-02-28 10:59:40 --> Controller Class Initialized
DEBUG - 2023-02-28 10:59:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:59:40 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:40 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:40 --> Model "Login_model" initialized
INFO - 2023-02-28 10:59:40 --> Final output sent to browser
DEBUG - 2023-02-28 10:59:40 --> Total execution time: 0.0227
INFO - 2023-02-28 10:59:40 --> Config Class Initialized
INFO - 2023-02-28 10:59:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 10:59:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 10:59:40 --> Utf8 Class Initialized
INFO - 2023-02-28 10:59:40 --> URI Class Initialized
INFO - 2023-02-28 10:59:40 --> Router Class Initialized
INFO - 2023-02-28 10:59:40 --> Output Class Initialized
INFO - 2023-02-28 10:59:40 --> Security Class Initialized
DEBUG - 2023-02-28 10:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 10:59:40 --> Input Class Initialized
INFO - 2023-02-28 10:59:40 --> Language Class Initialized
INFO - 2023-02-28 10:59:40 --> Loader Class Initialized
INFO - 2023-02-28 10:59:40 --> Controller Class Initialized
DEBUG - 2023-02-28 10:59:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 10:59:40 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:40 --> Database Driver Class Initialized
INFO - 2023-02-28 10:59:40 --> Model "Login_model" initialized
INFO - 2023-02-28 10:59:40 --> Final output sent to browser
DEBUG - 2023-02-28 10:59:40 --> Total execution time: 0.0226
INFO - 2023-02-28 11:01:13 --> Config Class Initialized
INFO - 2023-02-28 11:01:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:01:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:01:13 --> Utf8 Class Initialized
INFO - 2023-02-28 11:01:13 --> URI Class Initialized
INFO - 2023-02-28 11:01:13 --> Router Class Initialized
INFO - 2023-02-28 11:01:13 --> Output Class Initialized
INFO - 2023-02-28 11:01:13 --> Security Class Initialized
DEBUG - 2023-02-28 11:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:01:13 --> Input Class Initialized
INFO - 2023-02-28 11:01:13 --> Language Class Initialized
INFO - 2023-02-28 11:01:13 --> Loader Class Initialized
INFO - 2023-02-28 11:01:13 --> Controller Class Initialized
DEBUG - 2023-02-28 11:01:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:01:13 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:13 --> Final output sent to browser
DEBUG - 2023-02-28 11:01:13 --> Total execution time: 0.0177
INFO - 2023-02-28 11:01:13 --> Config Class Initialized
INFO - 2023-02-28 11:01:13 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:01:13 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:01:13 --> Utf8 Class Initialized
INFO - 2023-02-28 11:01:13 --> URI Class Initialized
INFO - 2023-02-28 11:01:13 --> Router Class Initialized
INFO - 2023-02-28 11:01:13 --> Output Class Initialized
INFO - 2023-02-28 11:01:13 --> Security Class Initialized
DEBUG - 2023-02-28 11:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:01:13 --> Input Class Initialized
INFO - 2023-02-28 11:01:13 --> Language Class Initialized
INFO - 2023-02-28 11:01:13 --> Loader Class Initialized
INFO - 2023-02-28 11:01:13 --> Controller Class Initialized
DEBUG - 2023-02-28 11:01:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:01:13 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:13 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:13 --> Model "Login_model" initialized
INFO - 2023-02-28 11:01:13 --> Final output sent to browser
DEBUG - 2023-02-28 11:01:13 --> Total execution time: 0.0174
INFO - 2023-02-28 11:01:29 --> Config Class Initialized
INFO - 2023-02-28 11:01:29 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:01:29 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:01:29 --> Utf8 Class Initialized
INFO - 2023-02-28 11:01:29 --> URI Class Initialized
INFO - 2023-02-28 11:01:29 --> Router Class Initialized
INFO - 2023-02-28 11:01:29 --> Output Class Initialized
INFO - 2023-02-28 11:01:29 --> Security Class Initialized
DEBUG - 2023-02-28 11:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:01:29 --> Input Class Initialized
INFO - 2023-02-28 11:01:29 --> Language Class Initialized
INFO - 2023-02-28 11:01:29 --> Loader Class Initialized
INFO - 2023-02-28 11:01:29 --> Controller Class Initialized
DEBUG - 2023-02-28 11:01:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:01:29 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:29 --> Final output sent to browser
DEBUG - 2023-02-28 11:01:29 --> Total execution time: 0.0235
INFO - 2023-02-28 11:01:29 --> Config Class Initialized
INFO - 2023-02-28 11:01:29 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:01:29 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:01:29 --> Utf8 Class Initialized
INFO - 2023-02-28 11:01:29 --> URI Class Initialized
INFO - 2023-02-28 11:01:29 --> Router Class Initialized
INFO - 2023-02-28 11:01:29 --> Output Class Initialized
INFO - 2023-02-28 11:01:29 --> Security Class Initialized
DEBUG - 2023-02-28 11:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:01:29 --> Input Class Initialized
INFO - 2023-02-28 11:01:29 --> Language Class Initialized
INFO - 2023-02-28 11:01:29 --> Loader Class Initialized
INFO - 2023-02-28 11:01:29 --> Controller Class Initialized
DEBUG - 2023-02-28 11:01:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:01:29 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:29 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:30 --> Model "Login_model" initialized
INFO - 2023-02-28 11:01:30 --> Final output sent to browser
DEBUG - 2023-02-28 11:01:30 --> Total execution time: 0.0156
INFO - 2023-02-28 11:01:40 --> Config Class Initialized
INFO - 2023-02-28 11:01:40 --> Config Class Initialized
INFO - 2023-02-28 11:01:40 --> Hooks Class Initialized
INFO - 2023-02-28 11:01:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:01:40 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 11:01:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:01:40 --> Utf8 Class Initialized
INFO - 2023-02-28 11:01:40 --> Utf8 Class Initialized
INFO - 2023-02-28 11:01:40 --> URI Class Initialized
INFO - 2023-02-28 11:01:40 --> URI Class Initialized
INFO - 2023-02-28 11:01:40 --> Router Class Initialized
INFO - 2023-02-28 11:01:40 --> Router Class Initialized
INFO - 2023-02-28 11:01:40 --> Output Class Initialized
INFO - 2023-02-28 11:01:40 --> Output Class Initialized
INFO - 2023-02-28 11:01:40 --> Security Class Initialized
INFO - 2023-02-28 11:01:40 --> Security Class Initialized
DEBUG - 2023-02-28 11:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 11:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:01:40 --> Input Class Initialized
INFO - 2023-02-28 11:01:40 --> Input Class Initialized
INFO - 2023-02-28 11:01:40 --> Language Class Initialized
INFO - 2023-02-28 11:01:40 --> Language Class Initialized
INFO - 2023-02-28 11:01:40 --> Loader Class Initialized
INFO - 2023-02-28 11:01:40 --> Loader Class Initialized
INFO - 2023-02-28 11:01:40 --> Controller Class Initialized
INFO - 2023-02-28 11:01:40 --> Controller Class Initialized
DEBUG - 2023-02-28 11:01:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 11:01:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:01:40 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:40 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:40 --> Final output sent to browser
INFO - 2023-02-28 11:01:40 --> Final output sent to browser
DEBUG - 2023-02-28 11:01:40 --> Total execution time: 0.0131
DEBUG - 2023-02-28 11:01:40 --> Total execution time: 0.0131
INFO - 2023-02-28 11:01:40 --> Config Class Initialized
INFO - 2023-02-28 11:01:40 --> Config Class Initialized
INFO - 2023-02-28 11:01:40 --> Hooks Class Initialized
INFO - 2023-02-28 11:01:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:01:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:01:40 --> Utf8 Class Initialized
DEBUG - 2023-02-28 11:01:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:01:40 --> URI Class Initialized
INFO - 2023-02-28 11:01:40 --> Utf8 Class Initialized
INFO - 2023-02-28 11:01:40 --> Router Class Initialized
INFO - 2023-02-28 11:01:40 --> URI Class Initialized
INFO - 2023-02-28 11:01:40 --> Output Class Initialized
INFO - 2023-02-28 11:01:40 --> Router Class Initialized
INFO - 2023-02-28 11:01:40 --> Security Class Initialized
INFO - 2023-02-28 11:01:40 --> Output Class Initialized
DEBUG - 2023-02-28 11:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:01:40 --> Security Class Initialized
INFO - 2023-02-28 11:01:40 --> Input Class Initialized
DEBUG - 2023-02-28 11:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:01:40 --> Language Class Initialized
INFO - 2023-02-28 11:01:40 --> Input Class Initialized
INFO - 2023-02-28 11:01:40 --> Loader Class Initialized
INFO - 2023-02-28 11:01:40 --> Language Class Initialized
INFO - 2023-02-28 11:01:40 --> Controller Class Initialized
INFO - 2023-02-28 11:01:40 --> Loader Class Initialized
DEBUG - 2023-02-28 11:01:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:01:40 --> Controller Class Initialized
INFO - 2023-02-28 11:01:40 --> Database Driver Class Initialized
DEBUG - 2023-02-28 11:01:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:01:40 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:40 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:40 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:40 --> Model "Login_model" initialized
INFO - 2023-02-28 11:01:40 --> Model "Login_model" initialized
INFO - 2023-02-28 11:01:40 --> Final output sent to browser
INFO - 2023-02-28 11:01:40 --> Final output sent to browser
DEBUG - 2023-02-28 11:01:40 --> Total execution time: 0.0218
DEBUG - 2023-02-28 11:01:40 --> Total execution time: 0.0218
INFO - 2023-02-28 11:01:40 --> Config Class Initialized
INFO - 2023-02-28 11:01:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:01:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:01:40 --> Utf8 Class Initialized
INFO - 2023-02-28 11:01:40 --> URI Class Initialized
INFO - 2023-02-28 11:01:40 --> Router Class Initialized
INFO - 2023-02-28 11:01:40 --> Output Class Initialized
INFO - 2023-02-28 11:01:40 --> Security Class Initialized
DEBUG - 2023-02-28 11:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:01:40 --> Input Class Initialized
INFO - 2023-02-28 11:01:40 --> Language Class Initialized
INFO - 2023-02-28 11:01:40 --> Loader Class Initialized
INFO - 2023-02-28 11:01:40 --> Controller Class Initialized
DEBUG - 2023-02-28 11:01:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:01:40 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:40 --> Final output sent to browser
DEBUG - 2023-02-28 11:01:40 --> Total execution time: 0.0085
INFO - 2023-02-28 11:01:40 --> Config Class Initialized
INFO - 2023-02-28 11:01:40 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:01:40 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:01:40 --> Utf8 Class Initialized
INFO - 2023-02-28 11:01:40 --> URI Class Initialized
INFO - 2023-02-28 11:01:40 --> Router Class Initialized
INFO - 2023-02-28 11:01:40 --> Output Class Initialized
INFO - 2023-02-28 11:01:40 --> Security Class Initialized
DEBUG - 2023-02-28 11:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:01:40 --> Input Class Initialized
INFO - 2023-02-28 11:01:40 --> Language Class Initialized
INFO - 2023-02-28 11:01:40 --> Loader Class Initialized
INFO - 2023-02-28 11:01:40 --> Controller Class Initialized
DEBUG - 2023-02-28 11:01:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:01:40 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:40 --> Final output sent to browser
DEBUG - 2023-02-28 11:01:40 --> Total execution time: 0.0505
INFO - 2023-02-28 11:01:50 --> Config Class Initialized
INFO - 2023-02-28 11:01:50 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:01:50 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:01:50 --> Utf8 Class Initialized
INFO - 2023-02-28 11:01:50 --> URI Class Initialized
INFO - 2023-02-28 11:01:51 --> Router Class Initialized
INFO - 2023-02-28 11:01:51 --> Output Class Initialized
INFO - 2023-02-28 11:01:51 --> Security Class Initialized
DEBUG - 2023-02-28 11:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:01:51 --> Input Class Initialized
INFO - 2023-02-28 11:01:51 --> Language Class Initialized
INFO - 2023-02-28 11:01:51 --> Loader Class Initialized
INFO - 2023-02-28 11:01:51 --> Controller Class Initialized
DEBUG - 2023-02-28 11:01:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:01:51 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:51 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:51 --> Model "Login_model" initialized
INFO - 2023-02-28 11:01:51 --> Final output sent to browser
DEBUG - 2023-02-28 11:01:51 --> Total execution time: 0.1030
INFO - 2023-02-28 11:01:51 --> Config Class Initialized
INFO - 2023-02-28 11:01:51 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:01:51 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:01:51 --> Utf8 Class Initialized
INFO - 2023-02-28 11:01:51 --> URI Class Initialized
INFO - 2023-02-28 11:01:51 --> Router Class Initialized
INFO - 2023-02-28 11:01:51 --> Output Class Initialized
INFO - 2023-02-28 11:01:51 --> Security Class Initialized
DEBUG - 2023-02-28 11:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:01:51 --> Input Class Initialized
INFO - 2023-02-28 11:01:51 --> Language Class Initialized
INFO - 2023-02-28 11:01:51 --> Loader Class Initialized
INFO - 2023-02-28 11:01:51 --> Controller Class Initialized
DEBUG - 2023-02-28 11:01:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:01:51 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:51 --> Database Driver Class Initialized
INFO - 2023-02-28 11:01:51 --> Model "Login_model" initialized
INFO - 2023-02-28 11:01:51 --> Final output sent to browser
DEBUG - 2023-02-28 11:01:51 --> Total execution time: 0.0214
INFO - 2023-02-28 11:02:05 --> Config Class Initialized
INFO - 2023-02-28 11:02:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:02:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:02:05 --> Utf8 Class Initialized
INFO - 2023-02-28 11:02:05 --> URI Class Initialized
INFO - 2023-02-28 11:02:05 --> Router Class Initialized
INFO - 2023-02-28 11:02:05 --> Output Class Initialized
INFO - 2023-02-28 11:02:05 --> Security Class Initialized
DEBUG - 2023-02-28 11:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:02:05 --> Input Class Initialized
INFO - 2023-02-28 11:02:05 --> Language Class Initialized
INFO - 2023-02-28 11:02:05 --> Loader Class Initialized
INFO - 2023-02-28 11:02:05 --> Controller Class Initialized
DEBUG - 2023-02-28 11:02:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:02:05 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:05 --> Final output sent to browser
DEBUG - 2023-02-28 11:02:05 --> Total execution time: 0.0137
INFO - 2023-02-28 11:02:05 --> Config Class Initialized
INFO - 2023-02-28 11:02:05 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:02:05 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:02:05 --> Utf8 Class Initialized
INFO - 2023-02-28 11:02:05 --> URI Class Initialized
INFO - 2023-02-28 11:02:05 --> Router Class Initialized
INFO - 2023-02-28 11:02:05 --> Output Class Initialized
INFO - 2023-02-28 11:02:05 --> Security Class Initialized
DEBUG - 2023-02-28 11:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:02:05 --> Input Class Initialized
INFO - 2023-02-28 11:02:05 --> Language Class Initialized
INFO - 2023-02-28 11:02:05 --> Loader Class Initialized
INFO - 2023-02-28 11:02:05 --> Controller Class Initialized
DEBUG - 2023-02-28 11:02:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:02:05 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:05 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:05 --> Model "Login_model" initialized
INFO - 2023-02-28 11:02:05 --> Final output sent to browser
DEBUG - 2023-02-28 11:02:05 --> Total execution time: 0.0178
INFO - 2023-02-28 11:02:25 --> Config Class Initialized
INFO - 2023-02-28 11:02:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:02:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:02:25 --> Utf8 Class Initialized
INFO - 2023-02-28 11:02:25 --> URI Class Initialized
INFO - 2023-02-28 11:02:25 --> Router Class Initialized
INFO - 2023-02-28 11:02:25 --> Output Class Initialized
INFO - 2023-02-28 11:02:25 --> Security Class Initialized
DEBUG - 2023-02-28 11:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:02:25 --> Input Class Initialized
INFO - 2023-02-28 11:02:25 --> Language Class Initialized
INFO - 2023-02-28 11:02:25 --> Loader Class Initialized
INFO - 2023-02-28 11:02:25 --> Controller Class Initialized
DEBUG - 2023-02-28 11:02:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:02:25 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:25 --> Final output sent to browser
DEBUG - 2023-02-28 11:02:25 --> Total execution time: 0.0123
INFO - 2023-02-28 11:02:25 --> Config Class Initialized
INFO - 2023-02-28 11:02:25 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:02:25 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:02:25 --> Utf8 Class Initialized
INFO - 2023-02-28 11:02:25 --> URI Class Initialized
INFO - 2023-02-28 11:02:25 --> Router Class Initialized
INFO - 2023-02-28 11:02:25 --> Output Class Initialized
INFO - 2023-02-28 11:02:25 --> Security Class Initialized
DEBUG - 2023-02-28 11:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:02:25 --> Input Class Initialized
INFO - 2023-02-28 11:02:25 --> Language Class Initialized
INFO - 2023-02-28 11:02:25 --> Loader Class Initialized
INFO - 2023-02-28 11:02:25 --> Controller Class Initialized
DEBUG - 2023-02-28 11:02:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:02:25 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:25 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:25 --> Model "Login_model" initialized
INFO - 2023-02-28 11:02:25 --> Final output sent to browser
DEBUG - 2023-02-28 11:02:25 --> Total execution time: 0.0216
INFO - 2023-02-28 11:02:35 --> Config Class Initialized
INFO - 2023-02-28 11:02:35 --> Config Class Initialized
INFO - 2023-02-28 11:02:35 --> Hooks Class Initialized
INFO - 2023-02-28 11:02:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:02:35 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 11:02:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:02:35 --> Utf8 Class Initialized
INFO - 2023-02-28 11:02:35 --> Utf8 Class Initialized
INFO - 2023-02-28 11:02:35 --> URI Class Initialized
INFO - 2023-02-28 11:02:35 --> URI Class Initialized
INFO - 2023-02-28 11:02:35 --> Router Class Initialized
INFO - 2023-02-28 11:02:35 --> Router Class Initialized
INFO - 2023-02-28 11:02:35 --> Output Class Initialized
INFO - 2023-02-28 11:02:35 --> Output Class Initialized
INFO - 2023-02-28 11:02:35 --> Security Class Initialized
INFO - 2023-02-28 11:02:35 --> Security Class Initialized
DEBUG - 2023-02-28 11:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 11:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:02:35 --> Input Class Initialized
INFO - 2023-02-28 11:02:35 --> Input Class Initialized
INFO - 2023-02-28 11:02:35 --> Language Class Initialized
INFO - 2023-02-28 11:02:35 --> Language Class Initialized
INFO - 2023-02-28 11:02:35 --> Loader Class Initialized
INFO - 2023-02-28 11:02:35 --> Loader Class Initialized
INFO - 2023-02-28 11:02:35 --> Controller Class Initialized
INFO - 2023-02-28 11:02:35 --> Controller Class Initialized
DEBUG - 2023-02-28 11:02:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 11:02:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:02:35 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:35 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:35 --> Final output sent to browser
INFO - 2023-02-28 11:02:35 --> Final output sent to browser
DEBUG - 2023-02-28 11:02:35 --> Total execution time: 0.0109
DEBUG - 2023-02-28 11:02:35 --> Total execution time: 0.0109
INFO - 2023-02-28 11:02:35 --> Config Class Initialized
INFO - 2023-02-28 11:02:35 --> Config Class Initialized
INFO - 2023-02-28 11:02:35 --> Hooks Class Initialized
INFO - 2023-02-28 11:02:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:02:35 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 11:02:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:02:35 --> Utf8 Class Initialized
INFO - 2023-02-28 11:02:35 --> Utf8 Class Initialized
INFO - 2023-02-28 11:02:35 --> URI Class Initialized
INFO - 2023-02-28 11:02:35 --> URI Class Initialized
INFO - 2023-02-28 11:02:35 --> Router Class Initialized
INFO - 2023-02-28 11:02:35 --> Router Class Initialized
INFO - 2023-02-28 11:02:35 --> Output Class Initialized
INFO - 2023-02-28 11:02:35 --> Output Class Initialized
INFO - 2023-02-28 11:02:35 --> Security Class Initialized
INFO - 2023-02-28 11:02:35 --> Security Class Initialized
DEBUG - 2023-02-28 11:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 11:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:02:35 --> Input Class Initialized
INFO - 2023-02-28 11:02:35 --> Input Class Initialized
INFO - 2023-02-28 11:02:35 --> Language Class Initialized
INFO - 2023-02-28 11:02:35 --> Language Class Initialized
INFO - 2023-02-28 11:02:35 --> Loader Class Initialized
INFO - 2023-02-28 11:02:35 --> Loader Class Initialized
INFO - 2023-02-28 11:02:35 --> Controller Class Initialized
INFO - 2023-02-28 11:02:35 --> Controller Class Initialized
DEBUG - 2023-02-28 11:02:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 11:02:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:02:35 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:35 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:35 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:35 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:35 --> Model "Login_model" initialized
INFO - 2023-02-28 11:02:35 --> Model "Login_model" initialized
INFO - 2023-02-28 11:02:35 --> Final output sent to browser
INFO - 2023-02-28 11:02:35 --> Final output sent to browser
DEBUG - 2023-02-28 11:02:35 --> Total execution time: 0.0238
DEBUG - 2023-02-28 11:02:35 --> Total execution time: 0.0239
INFO - 2023-02-28 11:02:35 --> Config Class Initialized
INFO - 2023-02-28 11:02:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:02:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:02:35 --> Utf8 Class Initialized
INFO - 2023-02-28 11:02:35 --> URI Class Initialized
INFO - 2023-02-28 11:02:35 --> Router Class Initialized
INFO - 2023-02-28 11:02:35 --> Output Class Initialized
INFO - 2023-02-28 11:02:35 --> Security Class Initialized
DEBUG - 2023-02-28 11:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:02:35 --> Input Class Initialized
INFO - 2023-02-28 11:02:35 --> Language Class Initialized
INFO - 2023-02-28 11:02:35 --> Loader Class Initialized
INFO - 2023-02-28 11:02:35 --> Controller Class Initialized
DEBUG - 2023-02-28 11:02:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:02:35 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:35 --> Final output sent to browser
DEBUG - 2023-02-28 11:02:35 --> Total execution time: 0.0084
INFO - 2023-02-28 11:02:35 --> Config Class Initialized
INFO - 2023-02-28 11:02:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:02:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:02:35 --> Utf8 Class Initialized
INFO - 2023-02-28 11:02:35 --> URI Class Initialized
INFO - 2023-02-28 11:02:35 --> Router Class Initialized
INFO - 2023-02-28 11:02:35 --> Output Class Initialized
INFO - 2023-02-28 11:02:35 --> Security Class Initialized
DEBUG - 2023-02-28 11:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:02:35 --> Input Class Initialized
INFO - 2023-02-28 11:02:35 --> Language Class Initialized
INFO - 2023-02-28 11:02:35 --> Loader Class Initialized
INFO - 2023-02-28 11:02:35 --> Controller Class Initialized
DEBUG - 2023-02-28 11:02:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:02:35 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:35 --> Final output sent to browser
DEBUG - 2023-02-28 11:02:35 --> Total execution time: 0.3700
INFO - 2023-02-28 11:02:35 --> Config Class Initialized
INFO - 2023-02-28 11:02:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:02:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:02:35 --> Utf8 Class Initialized
INFO - 2023-02-28 11:02:35 --> URI Class Initialized
INFO - 2023-02-28 11:02:35 --> Router Class Initialized
INFO - 2023-02-28 11:02:35 --> Output Class Initialized
INFO - 2023-02-28 11:02:35 --> Security Class Initialized
DEBUG - 2023-02-28 11:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:02:35 --> Input Class Initialized
INFO - 2023-02-28 11:02:35 --> Language Class Initialized
INFO - 2023-02-28 11:02:35 --> Loader Class Initialized
INFO - 2023-02-28 11:02:35 --> Controller Class Initialized
DEBUG - 2023-02-28 11:02:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:02:35 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:35 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:35 --> Model "Login_model" initialized
INFO - 2023-02-28 11:02:35 --> Final output sent to browser
DEBUG - 2023-02-28 11:02:35 --> Total execution time: 0.0218
INFO - 2023-02-28 11:02:35 --> Config Class Initialized
INFO - 2023-02-28 11:02:35 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:02:35 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:02:35 --> Utf8 Class Initialized
INFO - 2023-02-28 11:02:35 --> URI Class Initialized
INFO - 2023-02-28 11:02:35 --> Router Class Initialized
INFO - 2023-02-28 11:02:35 --> Output Class Initialized
INFO - 2023-02-28 11:02:35 --> Security Class Initialized
DEBUG - 2023-02-28 11:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:02:35 --> Input Class Initialized
INFO - 2023-02-28 11:02:35 --> Language Class Initialized
INFO - 2023-02-28 11:02:35 --> Loader Class Initialized
INFO - 2023-02-28 11:02:35 --> Controller Class Initialized
DEBUG - 2023-02-28 11:02:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:02:35 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:35 --> Database Driver Class Initialized
INFO - 2023-02-28 11:02:35 --> Model "Login_model" initialized
INFO - 2023-02-28 11:02:35 --> Final output sent to browser
DEBUG - 2023-02-28 11:02:35 --> Total execution time: 0.0201
INFO - 2023-02-28 11:07:48 --> Config Class Initialized
INFO - 2023-02-28 11:07:48 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:07:48 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:07:48 --> Utf8 Class Initialized
INFO - 2023-02-28 11:07:48 --> URI Class Initialized
INFO - 2023-02-28 11:07:48 --> Router Class Initialized
INFO - 2023-02-28 11:07:48 --> Output Class Initialized
INFO - 2023-02-28 11:07:48 --> Security Class Initialized
DEBUG - 2023-02-28 11:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:07:48 --> Input Class Initialized
INFO - 2023-02-28 11:07:48 --> Language Class Initialized
INFO - 2023-02-28 11:07:48 --> Loader Class Initialized
INFO - 2023-02-28 11:07:48 --> Controller Class Initialized
DEBUG - 2023-02-28 11:07:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:07:48 --> Database Driver Class Initialized
INFO - 2023-02-28 11:07:48 --> Database Driver Class Initialized
INFO - 2023-02-28 11:07:48 --> Model "Login_model" initialized
INFO - 2023-02-28 11:07:48 --> Final output sent to browser
DEBUG - 2023-02-28 11:07:48 --> Total execution time: 0.1049
INFO - 2023-02-28 11:07:48 --> Config Class Initialized
INFO - 2023-02-28 11:07:48 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:07:48 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:07:48 --> Utf8 Class Initialized
INFO - 2023-02-28 11:07:48 --> URI Class Initialized
INFO - 2023-02-28 11:07:48 --> Router Class Initialized
INFO - 2023-02-28 11:07:48 --> Output Class Initialized
INFO - 2023-02-28 11:07:48 --> Security Class Initialized
DEBUG - 2023-02-28 11:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:07:48 --> Input Class Initialized
INFO - 2023-02-28 11:07:48 --> Language Class Initialized
INFO - 2023-02-28 11:07:48 --> Loader Class Initialized
INFO - 2023-02-28 11:07:48 --> Controller Class Initialized
DEBUG - 2023-02-28 11:07:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:07:48 --> Database Driver Class Initialized
INFO - 2023-02-28 11:07:48 --> Database Driver Class Initialized
INFO - 2023-02-28 11:07:48 --> Model "Login_model" initialized
INFO - 2023-02-28 11:07:48 --> Final output sent to browser
DEBUG - 2023-02-28 11:07:48 --> Total execution time: 0.0220
INFO - 2023-02-28 11:07:54 --> Config Class Initialized
INFO - 2023-02-28 11:07:54 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:07:54 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:07:54 --> Utf8 Class Initialized
INFO - 2023-02-28 11:07:54 --> URI Class Initialized
INFO - 2023-02-28 11:07:54 --> Router Class Initialized
INFO - 2023-02-28 11:07:54 --> Output Class Initialized
INFO - 2023-02-28 11:07:54 --> Security Class Initialized
DEBUG - 2023-02-28 11:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:07:54 --> Input Class Initialized
INFO - 2023-02-28 11:07:54 --> Language Class Initialized
INFO - 2023-02-28 11:07:54 --> Loader Class Initialized
INFO - 2023-02-28 11:07:54 --> Controller Class Initialized
DEBUG - 2023-02-28 11:07:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:07:54 --> Database Driver Class Initialized
INFO - 2023-02-28 11:07:54 --> Final output sent to browser
DEBUG - 2023-02-28 11:07:54 --> Total execution time: 0.0134
INFO - 2023-02-28 11:07:54 --> Config Class Initialized
INFO - 2023-02-28 11:07:54 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:07:54 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:07:54 --> Utf8 Class Initialized
INFO - 2023-02-28 11:07:54 --> URI Class Initialized
INFO - 2023-02-28 11:07:54 --> Router Class Initialized
INFO - 2023-02-28 11:07:54 --> Output Class Initialized
INFO - 2023-02-28 11:07:54 --> Security Class Initialized
DEBUG - 2023-02-28 11:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:07:54 --> Input Class Initialized
INFO - 2023-02-28 11:07:54 --> Language Class Initialized
INFO - 2023-02-28 11:07:54 --> Loader Class Initialized
INFO - 2023-02-28 11:07:54 --> Controller Class Initialized
DEBUG - 2023-02-28 11:07:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:07:54 --> Database Driver Class Initialized
INFO - 2023-02-28 11:07:54 --> Database Driver Class Initialized
INFO - 2023-02-28 11:07:54 --> Model "Login_model" initialized
INFO - 2023-02-28 11:07:54 --> Final output sent to browser
DEBUG - 2023-02-28 11:07:54 --> Total execution time: 0.0184
INFO - 2023-02-28 11:08:09 --> Config Class Initialized
INFO - 2023-02-28 11:08:09 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:08:09 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:08:09 --> Utf8 Class Initialized
INFO - 2023-02-28 11:08:09 --> URI Class Initialized
INFO - 2023-02-28 11:08:09 --> Router Class Initialized
INFO - 2023-02-28 11:08:09 --> Output Class Initialized
INFO - 2023-02-28 11:08:09 --> Security Class Initialized
DEBUG - 2023-02-28 11:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:08:09 --> Input Class Initialized
INFO - 2023-02-28 11:08:09 --> Language Class Initialized
INFO - 2023-02-28 11:08:09 --> Loader Class Initialized
INFO - 2023-02-28 11:08:09 --> Controller Class Initialized
DEBUG - 2023-02-28 11:08:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:08:09 --> Database Driver Class Initialized
INFO - 2023-02-28 11:08:09 --> Final output sent to browser
DEBUG - 2023-02-28 11:08:09 --> Total execution time: 0.0113
INFO - 2023-02-28 11:08:09 --> Config Class Initialized
INFO - 2023-02-28 11:08:09 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:08:09 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:08:09 --> Utf8 Class Initialized
INFO - 2023-02-28 11:08:09 --> URI Class Initialized
INFO - 2023-02-28 11:08:09 --> Router Class Initialized
INFO - 2023-02-28 11:08:09 --> Output Class Initialized
INFO - 2023-02-28 11:08:09 --> Security Class Initialized
DEBUG - 2023-02-28 11:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:08:09 --> Input Class Initialized
INFO - 2023-02-28 11:08:09 --> Language Class Initialized
INFO - 2023-02-28 11:08:09 --> Loader Class Initialized
INFO - 2023-02-28 11:08:09 --> Controller Class Initialized
DEBUG - 2023-02-28 11:08:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:08:09 --> Database Driver Class Initialized
INFO - 2023-02-28 11:08:09 --> Database Driver Class Initialized
INFO - 2023-02-28 11:08:09 --> Model "Login_model" initialized
INFO - 2023-02-28 11:08:09 --> Final output sent to browser
DEBUG - 2023-02-28 11:08:09 --> Total execution time: 0.0169
INFO - 2023-02-28 11:08:17 --> Config Class Initialized
INFO - 2023-02-28 11:08:17 --> Config Class Initialized
INFO - 2023-02-28 11:08:17 --> Hooks Class Initialized
INFO - 2023-02-28 11:08:17 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:08:17 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 11:08:17 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:08:17 --> Utf8 Class Initialized
INFO - 2023-02-28 11:08:17 --> Utf8 Class Initialized
INFO - 2023-02-28 11:08:17 --> URI Class Initialized
INFO - 2023-02-28 11:08:17 --> URI Class Initialized
INFO - 2023-02-28 11:08:17 --> Router Class Initialized
INFO - 2023-02-28 11:08:17 --> Router Class Initialized
INFO - 2023-02-28 11:08:17 --> Output Class Initialized
INFO - 2023-02-28 11:08:17 --> Output Class Initialized
INFO - 2023-02-28 11:08:17 --> Security Class Initialized
INFO - 2023-02-28 11:08:17 --> Security Class Initialized
DEBUG - 2023-02-28 11:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 11:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:08:17 --> Input Class Initialized
INFO - 2023-02-28 11:08:17 --> Input Class Initialized
INFO - 2023-02-28 11:08:17 --> Language Class Initialized
INFO - 2023-02-28 11:08:17 --> Language Class Initialized
INFO - 2023-02-28 11:08:17 --> Loader Class Initialized
INFO - 2023-02-28 11:08:17 --> Loader Class Initialized
INFO - 2023-02-28 11:08:17 --> Controller Class Initialized
INFO - 2023-02-28 11:08:17 --> Controller Class Initialized
DEBUG - 2023-02-28 11:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 11:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:08:17 --> Database Driver Class Initialized
INFO - 2023-02-28 11:08:17 --> Database Driver Class Initialized
INFO - 2023-02-28 11:08:17 --> Final output sent to browser
INFO - 2023-02-28 11:08:17 --> Final output sent to browser
DEBUG - 2023-02-28 11:08:17 --> Total execution time: 0.0180
DEBUG - 2023-02-28 11:08:17 --> Total execution time: 0.0180
INFO - 2023-02-28 11:08:17 --> Config Class Initialized
INFO - 2023-02-28 11:08:17 --> Config Class Initialized
INFO - 2023-02-28 11:08:17 --> Hooks Class Initialized
INFO - 2023-02-28 11:08:17 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:08:17 --> UTF-8 Support Enabled
DEBUG - 2023-02-28 11:08:17 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:08:17 --> Utf8 Class Initialized
INFO - 2023-02-28 11:08:17 --> Utf8 Class Initialized
INFO - 2023-02-28 11:08:17 --> URI Class Initialized
INFO - 2023-02-28 11:08:17 --> URI Class Initialized
INFO - 2023-02-28 11:08:17 --> Router Class Initialized
INFO - 2023-02-28 11:08:17 --> Router Class Initialized
INFO - 2023-02-28 11:08:17 --> Output Class Initialized
INFO - 2023-02-28 11:08:17 --> Output Class Initialized
INFO - 2023-02-28 11:08:17 --> Security Class Initialized
INFO - 2023-02-28 11:08:17 --> Security Class Initialized
DEBUG - 2023-02-28 11:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-28 11:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:08:17 --> Input Class Initialized
INFO - 2023-02-28 11:08:17 --> Input Class Initialized
INFO - 2023-02-28 11:08:17 --> Language Class Initialized
INFO - 2023-02-28 11:08:17 --> Language Class Initialized
INFO - 2023-02-28 11:08:17 --> Loader Class Initialized
INFO - 2023-02-28 11:08:17 --> Loader Class Initialized
INFO - 2023-02-28 11:08:17 --> Controller Class Initialized
INFO - 2023-02-28 11:08:17 --> Controller Class Initialized
DEBUG - 2023-02-28 11:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-28 11:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:08:17 --> Database Driver Class Initialized
INFO - 2023-02-28 11:08:17 --> Database Driver Class Initialized
INFO - 2023-02-28 11:08:17 --> Database Driver Class Initialized
INFO - 2023-02-28 11:08:17 --> Database Driver Class Initialized
INFO - 2023-02-28 11:08:17 --> Model "Login_model" initialized
INFO - 2023-02-28 11:08:17 --> Model "Login_model" initialized
INFO - 2023-02-28 11:08:17 --> Final output sent to browser
DEBUG - 2023-02-28 11:08:17 --> Total execution time: 0.0192
INFO - 2023-02-28 11:08:17 --> Final output sent to browser
DEBUG - 2023-02-28 11:08:17 --> Total execution time: 0.0208
INFO - 2023-02-28 11:08:17 --> Config Class Initialized
INFO - 2023-02-28 11:08:17 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:08:17 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:08:17 --> Utf8 Class Initialized
INFO - 2023-02-28 11:08:17 --> URI Class Initialized
INFO - 2023-02-28 11:08:17 --> Router Class Initialized
INFO - 2023-02-28 11:08:17 --> Output Class Initialized
INFO - 2023-02-28 11:08:17 --> Security Class Initialized
DEBUG - 2023-02-28 11:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:08:17 --> Input Class Initialized
INFO - 2023-02-28 11:08:17 --> Language Class Initialized
INFO - 2023-02-28 11:08:17 --> Loader Class Initialized
INFO - 2023-02-28 11:08:17 --> Controller Class Initialized
DEBUG - 2023-02-28 11:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:08:17 --> Database Driver Class Initialized
INFO - 2023-02-28 11:08:17 --> Final output sent to browser
DEBUG - 2023-02-28 11:08:17 --> Total execution time: 0.0087
INFO - 2023-02-28 11:08:17 --> Config Class Initialized
INFO - 2023-02-28 11:08:17 --> Hooks Class Initialized
DEBUG - 2023-02-28 11:08:17 --> UTF-8 Support Enabled
INFO - 2023-02-28 11:08:17 --> Utf8 Class Initialized
INFO - 2023-02-28 11:08:17 --> URI Class Initialized
INFO - 2023-02-28 11:08:17 --> Router Class Initialized
INFO - 2023-02-28 11:08:17 --> Output Class Initialized
INFO - 2023-02-28 11:08:17 --> Security Class Initialized
DEBUG - 2023-02-28 11:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-28 11:08:17 --> Input Class Initialized
INFO - 2023-02-28 11:08:17 --> Language Class Initialized
INFO - 2023-02-28 11:08:17 --> Loader Class Initialized
INFO - 2023-02-28 11:08:17 --> Controller Class Initialized
DEBUG - 2023-02-28 11:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-28 11:08:17 --> Database Driver Class Initialized
INFO - 2023-02-28 11:08:17 --> Final output sent to browser
DEBUG - 2023-02-28 11:08:17 --> Total execution time: 0.0780
