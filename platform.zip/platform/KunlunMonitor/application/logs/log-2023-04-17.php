<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-17 01:51:22 --> Config Class Initialized
INFO - 2023-04-17 01:51:22 --> Hooks Class Initialized
DEBUG - 2023-04-17 01:51:22 --> UTF-8 Support Enabled
INFO - 2023-04-17 01:51:22 --> Utf8 Class Initialized
INFO - 2023-04-17 01:51:22 --> URI Class Initialized
INFO - 2023-04-17 01:51:22 --> Router Class Initialized
INFO - 2023-04-17 01:51:22 --> Output Class Initialized
INFO - 2023-04-17 01:51:22 --> Security Class Initialized
DEBUG - 2023-04-17 01:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 01:51:22 --> Input Class Initialized
INFO - 2023-04-17 01:51:22 --> Language Class Initialized
INFO - 2023-04-17 01:51:22 --> Loader Class Initialized
INFO - 2023-04-17 01:51:22 --> Controller Class Initialized
INFO - 2023-04-17 01:51:22 --> Helper loaded: form_helper
INFO - 2023-04-17 01:51:22 --> Helper loaded: url_helper
DEBUG - 2023-04-17 01:51:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 01:51:22 --> Model "Change_model" initialized
INFO - 2023-04-17 01:51:22 --> Model "Grafana_model" initialized
INFO - 2023-04-17 01:51:22 --> Final output sent to browser
DEBUG - 2023-04-17 01:51:22 --> Total execution time: 0.0999
INFO - 2023-04-17 01:51:22 --> Config Class Initialized
INFO - 2023-04-17 01:51:22 --> Hooks Class Initialized
DEBUG - 2023-04-17 01:51:22 --> UTF-8 Support Enabled
INFO - 2023-04-17 01:51:22 --> Utf8 Class Initialized
INFO - 2023-04-17 01:51:22 --> URI Class Initialized
INFO - 2023-04-17 01:51:22 --> Router Class Initialized
INFO - 2023-04-17 01:51:22 --> Output Class Initialized
INFO - 2023-04-17 01:51:22 --> Security Class Initialized
DEBUG - 2023-04-17 01:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 01:51:22 --> Input Class Initialized
INFO - 2023-04-17 01:51:22 --> Language Class Initialized
INFO - 2023-04-17 01:51:22 --> Loader Class Initialized
INFO - 2023-04-17 01:51:22 --> Controller Class Initialized
INFO - 2023-04-17 01:51:22 --> Helper loaded: form_helper
INFO - 2023-04-17 01:51:22 --> Helper loaded: url_helper
DEBUG - 2023-04-17 01:51:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 01:51:22 --> Final output sent to browser
DEBUG - 2023-04-17 01:51:22 --> Total execution time: 0.0438
INFO - 2023-04-17 01:51:22 --> Config Class Initialized
INFO - 2023-04-17 01:51:22 --> Hooks Class Initialized
DEBUG - 2023-04-17 01:51:22 --> UTF-8 Support Enabled
INFO - 2023-04-17 01:51:22 --> Utf8 Class Initialized
INFO - 2023-04-17 01:51:22 --> URI Class Initialized
INFO - 2023-04-17 01:51:22 --> Router Class Initialized
INFO - 2023-04-17 01:51:22 --> Output Class Initialized
INFO - 2023-04-17 01:51:22 --> Security Class Initialized
DEBUG - 2023-04-17 01:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 01:51:22 --> Input Class Initialized
INFO - 2023-04-17 01:51:22 --> Language Class Initialized
INFO - 2023-04-17 01:51:22 --> Loader Class Initialized
INFO - 2023-04-17 01:51:22 --> Controller Class Initialized
INFO - 2023-04-17 01:51:22 --> Helper loaded: form_helper
INFO - 2023-04-17 01:51:22 --> Helper loaded: url_helper
DEBUG - 2023-04-17 01:51:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 01:51:22 --> Database Driver Class Initialized
INFO - 2023-04-17 01:51:22 --> Model "Login_model" initialized
INFO - 2023-04-17 01:51:22 --> Final output sent to browser
DEBUG - 2023-04-17 01:51:22 --> Total execution time: 0.0333
INFO - 2023-04-17 01:51:22 --> Config Class Initialized
INFO - 2023-04-17 01:51:22 --> Hooks Class Initialized
DEBUG - 2023-04-17 01:51:22 --> UTF-8 Support Enabled
INFO - 2023-04-17 01:51:22 --> Utf8 Class Initialized
INFO - 2023-04-17 01:51:22 --> URI Class Initialized
INFO - 2023-04-17 01:51:22 --> Router Class Initialized
INFO - 2023-04-17 01:51:22 --> Output Class Initialized
INFO - 2023-04-17 01:51:22 --> Security Class Initialized
DEBUG - 2023-04-17 01:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 01:51:22 --> Input Class Initialized
INFO - 2023-04-17 01:51:22 --> Language Class Initialized
INFO - 2023-04-17 01:51:22 --> Loader Class Initialized
INFO - 2023-04-17 01:51:22 --> Controller Class Initialized
DEBUG - 2023-04-17 01:51:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 01:51:22 --> Database Driver Class Initialized
INFO - 2023-04-17 01:51:22 --> Model "Cluster_model" initialized
INFO - 2023-04-17 01:51:22 --> Final output sent to browser
DEBUG - 2023-04-17 01:51:22 --> Total execution time: 0.0880
INFO - 2023-04-17 01:51:22 --> Config Class Initialized
INFO - 2023-04-17 01:51:22 --> Hooks Class Initialized
DEBUG - 2023-04-17 01:51:22 --> UTF-8 Support Enabled
INFO - 2023-04-17 01:51:22 --> Utf8 Class Initialized
INFO - 2023-04-17 01:51:22 --> URI Class Initialized
INFO - 2023-04-17 01:51:22 --> Router Class Initialized
INFO - 2023-04-17 01:51:22 --> Output Class Initialized
INFO - 2023-04-17 01:51:22 --> Security Class Initialized
DEBUG - 2023-04-17 01:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 01:51:22 --> Input Class Initialized
INFO - 2023-04-17 01:51:22 --> Language Class Initialized
INFO - 2023-04-17 01:51:22 --> Loader Class Initialized
INFO - 2023-04-17 01:51:22 --> Controller Class Initialized
DEBUG - 2023-04-17 01:51:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 01:51:22 --> Database Driver Class Initialized
INFO - 2023-04-17 01:51:22 --> Model "Cluster_model" initialized
INFO - 2023-04-17 01:51:25 --> Config Class Initialized
INFO - 2023-04-17 01:51:25 --> Hooks Class Initialized
DEBUG - 2023-04-17 01:51:25 --> UTF-8 Support Enabled
INFO - 2023-04-17 01:51:25 --> Utf8 Class Initialized
INFO - 2023-04-17 01:51:25 --> URI Class Initialized
INFO - 2023-04-17 01:51:25 --> Router Class Initialized
INFO - 2023-04-17 01:51:25 --> Output Class Initialized
INFO - 2023-04-17 01:51:25 --> Security Class Initialized
DEBUG - 2023-04-17 01:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 01:51:25 --> Input Class Initialized
INFO - 2023-04-17 01:51:25 --> Language Class Initialized
INFO - 2023-04-17 01:51:25 --> Loader Class Initialized
INFO - 2023-04-17 01:51:25 --> Controller Class Initialized
INFO - 2023-04-17 01:51:25 --> Helper loaded: form_helper
INFO - 2023-04-17 01:51:25 --> Helper loaded: url_helper
DEBUG - 2023-04-17 01:51:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 01:51:25 --> Model "Change_model" initialized
INFO - 2023-04-17 01:51:25 --> Model "Grafana_model" initialized
INFO - 2023-04-17 01:51:25 --> Final output sent to browser
DEBUG - 2023-04-17 01:51:25 --> Total execution time: 0.0351
INFO - 2023-04-17 01:51:25 --> Config Class Initialized
INFO - 2023-04-17 01:51:25 --> Hooks Class Initialized
DEBUG - 2023-04-17 01:51:25 --> UTF-8 Support Enabled
INFO - 2023-04-17 01:51:25 --> Utf8 Class Initialized
INFO - 2023-04-17 01:51:25 --> URI Class Initialized
INFO - 2023-04-17 01:51:25 --> Router Class Initialized
INFO - 2023-04-17 01:51:25 --> Output Class Initialized
INFO - 2023-04-17 01:51:25 --> Security Class Initialized
DEBUG - 2023-04-17 01:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 01:51:25 --> Input Class Initialized
INFO - 2023-04-17 01:51:25 --> Language Class Initialized
INFO - 2023-04-17 01:51:25 --> Loader Class Initialized
INFO - 2023-04-17 01:51:25 --> Controller Class Initialized
INFO - 2023-04-17 01:51:25 --> Helper loaded: form_helper
INFO - 2023-04-17 01:51:25 --> Helper loaded: url_helper
DEBUG - 2023-04-17 01:51:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 01:51:25 --> Database Driver Class Initialized
INFO - 2023-04-17 01:51:25 --> Model "Login_model" initialized
INFO - 2023-04-17 01:51:25 --> Final output sent to browser
DEBUG - 2023-04-17 01:51:25 --> Total execution time: 0.0144
INFO - 2023-04-17 01:51:25 --> Config Class Initialized
INFO - 2023-04-17 01:51:25 --> Hooks Class Initialized
DEBUG - 2023-04-17 01:51:25 --> UTF-8 Support Enabled
INFO - 2023-04-17 01:51:25 --> Utf8 Class Initialized
INFO - 2023-04-17 01:51:25 --> URI Class Initialized
INFO - 2023-04-17 01:51:25 --> Router Class Initialized
INFO - 2023-04-17 01:51:25 --> Output Class Initialized
INFO - 2023-04-17 01:51:25 --> Security Class Initialized
DEBUG - 2023-04-17 01:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 01:51:25 --> Input Class Initialized
INFO - 2023-04-17 01:51:25 --> Language Class Initialized
INFO - 2023-04-17 01:51:25 --> Loader Class Initialized
INFO - 2023-04-17 01:51:25 --> Controller Class Initialized
DEBUG - 2023-04-17 01:51:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 01:51:25 --> Database Driver Class Initialized
INFO - 2023-04-17 01:51:25 --> Model "Cluster_model" initialized
INFO - 2023-04-17 01:51:52 --> Final output sent to browser
DEBUG - 2023-04-17 01:51:52 --> Total execution time: 30.0201
INFO - 2023-04-17 01:51:55 --> Final output sent to browser
DEBUG - 2023-04-17 01:51:55 --> Total execution time: 30.0857
INFO - 2023-04-17 03:17:32 --> Config Class Initialized
INFO - 2023-04-17 03:17:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:32 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:32 --> URI Class Initialized
INFO - 2023-04-17 03:17:32 --> Router Class Initialized
INFO - 2023-04-17 03:17:32 --> Output Class Initialized
INFO - 2023-04-17 03:17:32 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:32 --> Input Class Initialized
INFO - 2023-04-17 03:17:32 --> Language Class Initialized
INFO - 2023-04-17 03:17:32 --> Loader Class Initialized
INFO - 2023-04-17 03:17:32 --> Controller Class Initialized
INFO - 2023-04-17 03:17:32 --> Helper loaded: form_helper
INFO - 2023-04-17 03:17:32 --> Helper loaded: url_helper
DEBUG - 2023-04-17 03:17:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:32 --> Model "Change_model" initialized
INFO - 2023-04-17 03:17:32 --> Model "Grafana_model" initialized
INFO - 2023-04-17 03:17:32 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:32 --> Total execution time: 0.2565
INFO - 2023-04-17 03:17:32 --> Config Class Initialized
INFO - 2023-04-17 03:17:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:32 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:33 --> URI Class Initialized
INFO - 2023-04-17 03:17:33 --> Router Class Initialized
INFO - 2023-04-17 03:17:33 --> Output Class Initialized
INFO - 2023-04-17 03:17:33 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:33 --> Input Class Initialized
INFO - 2023-04-17 03:17:33 --> Language Class Initialized
INFO - 2023-04-17 03:17:33 --> Loader Class Initialized
INFO - 2023-04-17 03:17:33 --> Controller Class Initialized
INFO - 2023-04-17 03:17:33 --> Helper loaded: form_helper
INFO - 2023-04-17 03:17:33 --> Helper loaded: url_helper
DEBUG - 2023-04-17 03:17:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:33 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:33 --> Total execution time: 0.2884
INFO - 2023-04-17 03:17:33 --> Config Class Initialized
INFO - 2023-04-17 03:17:33 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:33 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:33 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:33 --> URI Class Initialized
INFO - 2023-04-17 03:17:33 --> Router Class Initialized
INFO - 2023-04-17 03:17:33 --> Output Class Initialized
INFO - 2023-04-17 03:17:33 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:33 --> Input Class Initialized
INFO - 2023-04-17 03:17:33 --> Language Class Initialized
INFO - 2023-04-17 03:17:33 --> Loader Class Initialized
INFO - 2023-04-17 03:17:33 --> Controller Class Initialized
INFO - 2023-04-17 03:17:33 --> Helper loaded: form_helper
INFO - 2023-04-17 03:17:33 --> Helper loaded: url_helper
DEBUG - 2023-04-17 03:17:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:33 --> Database Driver Class Initialized
INFO - 2023-04-17 03:17:33 --> Model "Login_model" initialized
INFO - 2023-04-17 03:17:33 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:33 --> Total execution time: 0.0309
INFO - 2023-04-17 03:17:45 --> Config Class Initialized
INFO - 2023-04-17 03:17:45 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:45 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:45 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:45 --> URI Class Initialized
INFO - 2023-04-17 03:17:45 --> Router Class Initialized
INFO - 2023-04-17 03:17:45 --> Output Class Initialized
INFO - 2023-04-17 03:17:45 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:45 --> Input Class Initialized
INFO - 2023-04-17 03:17:45 --> Language Class Initialized
INFO - 2023-04-17 03:17:45 --> Loader Class Initialized
INFO - 2023-04-17 03:17:45 --> Controller Class Initialized
INFO - 2023-04-17 03:17:45 --> Helper loaded: form_helper
INFO - 2023-04-17 03:17:45 --> Helper loaded: url_helper
DEBUG - 2023-04-17 03:17:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:46 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:46 --> Total execution time: 0.1317
INFO - 2023-04-17 03:17:46 --> Config Class Initialized
INFO - 2023-04-17 03:17:46 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:46 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:46 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:46 --> URI Class Initialized
INFO - 2023-04-17 03:17:46 --> Router Class Initialized
INFO - 2023-04-17 03:17:46 --> Output Class Initialized
INFO - 2023-04-17 03:17:46 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:46 --> Input Class Initialized
INFO - 2023-04-17 03:17:46 --> Language Class Initialized
INFO - 2023-04-17 03:17:46 --> Loader Class Initialized
INFO - 2023-04-17 03:17:46 --> Controller Class Initialized
INFO - 2023-04-17 03:17:46 --> Helper loaded: form_helper
INFO - 2023-04-17 03:17:46 --> Helper loaded: url_helper
DEBUG - 2023-04-17 03:17:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:46 --> Database Driver Class Initialized
INFO - 2023-04-17 03:17:46 --> Model "Login_model" initialized
INFO - 2023-04-17 03:17:46 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:46 --> Total execution time: 0.1551
INFO - 2023-04-17 03:17:50 --> Config Class Initialized
INFO - 2023-04-17 03:17:50 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:51 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:51 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:51 --> URI Class Initialized
INFO - 2023-04-17 03:17:51 --> Router Class Initialized
INFO - 2023-04-17 03:17:51 --> Output Class Initialized
INFO - 2023-04-17 03:17:51 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:51 --> Input Class Initialized
INFO - 2023-04-17 03:17:51 --> Language Class Initialized
INFO - 2023-04-17 03:17:51 --> Loader Class Initialized
INFO - 2023-04-17 03:17:51 --> Controller Class Initialized
INFO - 2023-04-17 03:17:51 --> Helper loaded: form_helper
INFO - 2023-04-17 03:17:51 --> Helper loaded: url_helper
DEBUG - 2023-04-17 03:17:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:51 --> Model "Change_model" initialized
INFO - 2023-04-17 03:17:51 --> Model "Grafana_model" initialized
INFO - 2023-04-17 03:17:51 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:51 --> Total execution time: 0.2241
INFO - 2023-04-17 03:17:51 --> Config Class Initialized
INFO - 2023-04-17 03:17:51 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:51 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:51 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:51 --> URI Class Initialized
INFO - 2023-04-17 03:17:51 --> Router Class Initialized
INFO - 2023-04-17 03:17:51 --> Output Class Initialized
INFO - 2023-04-17 03:17:51 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:51 --> Input Class Initialized
INFO - 2023-04-17 03:17:51 --> Language Class Initialized
INFO - 2023-04-17 03:17:51 --> Loader Class Initialized
INFO - 2023-04-17 03:17:51 --> Controller Class Initialized
INFO - 2023-04-17 03:17:51 --> Helper loaded: form_helper
INFO - 2023-04-17 03:17:51 --> Helper loaded: url_helper
DEBUG - 2023-04-17 03:17:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:51 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:51 --> Total execution time: 0.0133
INFO - 2023-04-17 03:17:51 --> Config Class Initialized
INFO - 2023-04-17 03:17:51 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:51 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:51 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:51 --> URI Class Initialized
INFO - 2023-04-17 03:17:51 --> Router Class Initialized
INFO - 2023-04-17 03:17:51 --> Output Class Initialized
INFO - 2023-04-17 03:17:51 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:51 --> Input Class Initialized
INFO - 2023-04-17 03:17:51 --> Language Class Initialized
INFO - 2023-04-17 03:17:51 --> Loader Class Initialized
INFO - 2023-04-17 03:17:51 --> Controller Class Initialized
INFO - 2023-04-17 03:17:51 --> Helper loaded: form_helper
INFO - 2023-04-17 03:17:51 --> Helper loaded: url_helper
DEBUG - 2023-04-17 03:17:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:51 --> Database Driver Class Initialized
INFO - 2023-04-17 03:17:51 --> Model "Login_model" initialized
INFO - 2023-04-17 03:17:51 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:51 --> Total execution time: 0.0179
INFO - 2023-04-17 03:17:57 --> Config Class Initialized
INFO - 2023-04-17 03:17:57 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:57 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:57 --> URI Class Initialized
INFO - 2023-04-17 03:17:57 --> Router Class Initialized
INFO - 2023-04-17 03:17:57 --> Output Class Initialized
INFO - 2023-04-17 03:17:57 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:57 --> Input Class Initialized
INFO - 2023-04-17 03:17:57 --> Language Class Initialized
INFO - 2023-04-17 03:17:57 --> Loader Class Initialized
INFO - 2023-04-17 03:17:57 --> Controller Class Initialized
INFO - 2023-04-17 03:17:57 --> Helper loaded: form_helper
INFO - 2023-04-17 03:17:57 --> Helper loaded: url_helper
DEBUG - 2023-04-17 03:17:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:57 --> Model "Change_model" initialized
INFO - 2023-04-17 03:17:57 --> Model "Grafana_model" initialized
INFO - 2023-04-17 03:17:57 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:57 --> Total execution time: 0.1538
INFO - 2023-04-17 03:17:57 --> Config Class Initialized
INFO - 2023-04-17 03:17:57 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:57 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:57 --> URI Class Initialized
INFO - 2023-04-17 03:17:57 --> Router Class Initialized
INFO - 2023-04-17 03:17:57 --> Output Class Initialized
INFO - 2023-04-17 03:17:57 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:57 --> Input Class Initialized
INFO - 2023-04-17 03:17:57 --> Language Class Initialized
INFO - 2023-04-17 03:17:57 --> Loader Class Initialized
INFO - 2023-04-17 03:17:57 --> Controller Class Initialized
INFO - 2023-04-17 03:17:57 --> Helper loaded: form_helper
INFO - 2023-04-17 03:17:57 --> Helper loaded: url_helper
DEBUG - 2023-04-17 03:17:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:57 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:57 --> Total execution time: 0.0048
INFO - 2023-04-17 03:17:57 --> Config Class Initialized
INFO - 2023-04-17 03:17:57 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:57 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:57 --> URI Class Initialized
INFO - 2023-04-17 03:17:57 --> Router Class Initialized
INFO - 2023-04-17 03:17:57 --> Output Class Initialized
INFO - 2023-04-17 03:17:57 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:57 --> Input Class Initialized
INFO - 2023-04-17 03:17:57 --> Language Class Initialized
INFO - 2023-04-17 03:17:57 --> Loader Class Initialized
INFO - 2023-04-17 03:17:57 --> Controller Class Initialized
INFO - 2023-04-17 03:17:57 --> Helper loaded: form_helper
INFO - 2023-04-17 03:17:57 --> Helper loaded: url_helper
DEBUG - 2023-04-17 03:17:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:57 --> Database Driver Class Initialized
INFO - 2023-04-17 03:17:57 --> Model "Login_model" initialized
INFO - 2023-04-17 03:17:57 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:57 --> Total execution time: 0.0217
INFO - 2023-04-17 03:17:57 --> Config Class Initialized
INFO - 2023-04-17 03:17:57 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:57 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:57 --> URI Class Initialized
INFO - 2023-04-17 03:17:57 --> Router Class Initialized
INFO - 2023-04-17 03:17:57 --> Output Class Initialized
INFO - 2023-04-17 03:17:57 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:57 --> Input Class Initialized
INFO - 2023-04-17 03:17:57 --> Language Class Initialized
INFO - 2023-04-17 03:17:57 --> Loader Class Initialized
INFO - 2023-04-17 03:17:57 --> Controller Class Initialized
DEBUG - 2023-04-17 03:17:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:57 --> Database Driver Class Initialized
INFO - 2023-04-17 03:17:57 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:17:57 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:57 --> Total execution time: 0.0221
INFO - 2023-04-17 03:17:57 --> Config Class Initialized
INFO - 2023-04-17 03:17:57 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:57 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:57 --> URI Class Initialized
INFO - 2023-04-17 03:17:57 --> Router Class Initialized
INFO - 2023-04-17 03:17:57 --> Output Class Initialized
INFO - 2023-04-17 03:17:57 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:57 --> Input Class Initialized
INFO - 2023-04-17 03:17:57 --> Language Class Initialized
INFO - 2023-04-17 03:17:57 --> Loader Class Initialized
INFO - 2023-04-17 03:17:57 --> Controller Class Initialized
DEBUG - 2023-04-17 03:17:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:57 --> Database Driver Class Initialized
INFO - 2023-04-17 03:17:57 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:17:57 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:57 --> Total execution time: 0.0173
INFO - 2023-04-17 03:17:59 --> Config Class Initialized
INFO - 2023-04-17 03:17:59 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:59 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:59 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:59 --> URI Class Initialized
INFO - 2023-04-17 03:17:59 --> Router Class Initialized
INFO - 2023-04-17 03:17:59 --> Output Class Initialized
INFO - 2023-04-17 03:17:59 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:59 --> Input Class Initialized
INFO - 2023-04-17 03:17:59 --> Language Class Initialized
INFO - 2023-04-17 03:17:59 --> Loader Class Initialized
INFO - 2023-04-17 03:17:59 --> Controller Class Initialized
DEBUG - 2023-04-17 03:17:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:59 --> Database Driver Class Initialized
INFO - 2023-04-17 03:17:59 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:17:59 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:59 --> Total execution time: 0.1110
INFO - 2023-04-17 03:17:59 --> Config Class Initialized
INFO - 2023-04-17 03:17:59 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:17:59 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:17:59 --> Utf8 Class Initialized
INFO - 2023-04-17 03:17:59 --> URI Class Initialized
INFO - 2023-04-17 03:17:59 --> Router Class Initialized
INFO - 2023-04-17 03:17:59 --> Output Class Initialized
INFO - 2023-04-17 03:17:59 --> Security Class Initialized
DEBUG - 2023-04-17 03:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:17:59 --> Input Class Initialized
INFO - 2023-04-17 03:17:59 --> Language Class Initialized
INFO - 2023-04-17 03:17:59 --> Loader Class Initialized
INFO - 2023-04-17 03:17:59 --> Controller Class Initialized
DEBUG - 2023-04-17 03:17:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:17:59 --> Database Driver Class Initialized
INFO - 2023-04-17 03:17:59 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:17:59 --> Final output sent to browser
DEBUG - 2023-04-17 03:17:59 --> Total execution time: 0.0991
INFO - 2023-04-17 03:18:03 --> Config Class Initialized
INFO - 2023-04-17 03:18:03 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:18:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:18:03 --> Utf8 Class Initialized
INFO - 2023-04-17 03:18:03 --> Config Class Initialized
INFO - 2023-04-17 03:18:03 --> URI Class Initialized
INFO - 2023-04-17 03:18:03 --> Hooks Class Initialized
INFO - 2023-04-17 03:18:03 --> Router Class Initialized
DEBUG - 2023-04-17 03:18:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:18:03 --> Output Class Initialized
INFO - 2023-04-17 03:18:03 --> Security Class Initialized
INFO - 2023-04-17 03:18:03 --> Utf8 Class Initialized
DEBUG - 2023-04-17 03:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:18:03 --> URI Class Initialized
INFO - 2023-04-17 03:18:03 --> Input Class Initialized
INFO - 2023-04-17 03:18:03 --> Router Class Initialized
INFO - 2023-04-17 03:18:03 --> Language Class Initialized
INFO - 2023-04-17 03:18:03 --> Output Class Initialized
INFO - 2023-04-17 03:18:03 --> Loader Class Initialized
INFO - 2023-04-17 03:18:03 --> Security Class Initialized
INFO - 2023-04-17 03:18:03 --> Controller Class Initialized
DEBUG - 2023-04-17 03:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 03:18:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:18:03 --> Input Class Initialized
INFO - 2023-04-17 03:18:03 --> Language Class Initialized
INFO - 2023-04-17 03:18:03 --> Database Driver Class Initialized
INFO - 2023-04-17 03:18:03 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:18:03 --> Loader Class Initialized
INFO - 2023-04-17 03:18:03 --> Final output sent to browser
INFO - 2023-04-17 03:18:03 --> Controller Class Initialized
DEBUG - 2023-04-17 03:18:03 --> Total execution time: 0.0209
DEBUG - 2023-04-17 03:18:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:18:03 --> Final output sent to browser
DEBUG - 2023-04-17 03:18:03 --> Total execution time: 0.0660
INFO - 2023-04-17 03:18:03 --> Config Class Initialized
INFO - 2023-04-17 03:18:03 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:18:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:18:03 --> Config Class Initialized
INFO - 2023-04-17 03:18:03 --> Utf8 Class Initialized
INFO - 2023-04-17 03:18:03 --> Hooks Class Initialized
INFO - 2023-04-17 03:18:03 --> URI Class Initialized
INFO - 2023-04-17 03:18:03 --> Router Class Initialized
INFO - 2023-04-17 03:18:03 --> Output Class Initialized
INFO - 2023-04-17 03:18:03 --> Security Class Initialized
DEBUG - 2023-04-17 03:18:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:18:03 --> Utf8 Class Initialized
INFO - 2023-04-17 03:18:03 --> URI Class Initialized
DEBUG - 2023-04-17 03:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:18:03 --> Input Class Initialized
INFO - 2023-04-17 03:18:03 --> Router Class Initialized
INFO - 2023-04-17 03:18:03 --> Language Class Initialized
INFO - 2023-04-17 03:18:03 --> Output Class Initialized
INFO - 2023-04-17 03:18:03 --> Loader Class Initialized
INFO - 2023-04-17 03:18:03 --> Security Class Initialized
INFO - 2023-04-17 03:18:03 --> Controller Class Initialized
DEBUG - 2023-04-17 03:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 03:18:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:18:03 --> Input Class Initialized
INFO - 2023-04-17 03:18:03 --> Database Driver Class Initialized
INFO - 2023-04-17 03:18:03 --> Language Class Initialized
INFO - 2023-04-17 03:18:03 --> Loader Class Initialized
INFO - 2023-04-17 03:18:03 --> Controller Class Initialized
DEBUG - 2023-04-17 03:18:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:18:03 --> Database Driver Class Initialized
INFO - 2023-04-17 03:18:03 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:18:03 --> Model "Login_model" initialized
INFO - 2023-04-17 03:18:03 --> Database Driver Class Initialized
INFO - 2023-04-17 03:18:03 --> Final output sent to browser
DEBUG - 2023-04-17 03:18:03 --> Total execution time: 0.1812
INFO - 2023-04-17 03:18:03 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:18:03 --> Final output sent to browser
DEBUG - 2023-04-17 03:18:03 --> Total execution time: 0.2275
INFO - 2023-04-17 03:18:03 --> Config Class Initialized
INFO - 2023-04-17 03:18:03 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:18:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:18:03 --> Utf8 Class Initialized
INFO - 2023-04-17 03:18:03 --> URI Class Initialized
INFO - 2023-04-17 03:18:03 --> Router Class Initialized
INFO - 2023-04-17 03:18:03 --> Output Class Initialized
INFO - 2023-04-17 03:18:03 --> Security Class Initialized
DEBUG - 2023-04-17 03:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:18:03 --> Input Class Initialized
INFO - 2023-04-17 03:18:03 --> Language Class Initialized
INFO - 2023-04-17 03:18:03 --> Loader Class Initialized
INFO - 2023-04-17 03:18:03 --> Controller Class Initialized
DEBUG - 2023-04-17 03:18:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:18:03 --> Database Driver Class Initialized
INFO - 2023-04-17 03:18:03 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:18:03 --> Final output sent to browser
DEBUG - 2023-04-17 03:18:03 --> Total execution time: 0.0399
INFO - 2023-04-17 03:18:04 --> Config Class Initialized
INFO - 2023-04-17 03:18:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:18:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:18:04 --> Utf8 Class Initialized
INFO - 2023-04-17 03:18:04 --> URI Class Initialized
INFO - 2023-04-17 03:18:04 --> Router Class Initialized
INFO - 2023-04-17 03:18:04 --> Output Class Initialized
INFO - 2023-04-17 03:18:04 --> Security Class Initialized
DEBUG - 2023-04-17 03:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:18:04 --> Input Class Initialized
INFO - 2023-04-17 03:18:04 --> Language Class Initialized
INFO - 2023-04-17 03:18:04 --> Loader Class Initialized
INFO - 2023-04-17 03:18:04 --> Controller Class Initialized
DEBUG - 2023-04-17 03:18:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:18:04 --> Database Driver Class Initialized
INFO - 2023-04-17 03:18:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:18:04 --> Final output sent to browser
DEBUG - 2023-04-17 03:18:04 --> Total execution time: 0.0170
INFO - 2023-04-17 03:22:21 --> Config Class Initialized
INFO - 2023-04-17 03:22:21 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:22:21 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:22:21 --> Utf8 Class Initialized
INFO - 2023-04-17 03:22:21 --> URI Class Initialized
INFO - 2023-04-17 03:22:21 --> Router Class Initialized
INFO - 2023-04-17 03:22:21 --> Output Class Initialized
INFO - 2023-04-17 03:22:21 --> Security Class Initialized
DEBUG - 2023-04-17 03:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:22:21 --> Input Class Initialized
INFO - 2023-04-17 03:22:21 --> Language Class Initialized
INFO - 2023-04-17 03:22:21 --> Loader Class Initialized
INFO - 2023-04-17 03:22:21 --> Controller Class Initialized
DEBUG - 2023-04-17 03:22:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:22:21 --> Database Driver Class Initialized
INFO - 2023-04-17 03:22:21 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:22:21 --> Final output sent to browser
DEBUG - 2023-04-17 03:22:21 --> Total execution time: 0.0189
INFO - 2023-04-17 03:22:21 --> Config Class Initialized
INFO - 2023-04-17 03:22:21 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:22:21 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:22:21 --> Utf8 Class Initialized
INFO - 2023-04-17 03:22:21 --> URI Class Initialized
INFO - 2023-04-17 03:22:21 --> Router Class Initialized
INFO - 2023-04-17 03:22:21 --> Output Class Initialized
INFO - 2023-04-17 03:22:21 --> Security Class Initialized
DEBUG - 2023-04-17 03:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:22:21 --> Input Class Initialized
INFO - 2023-04-17 03:22:21 --> Language Class Initialized
INFO - 2023-04-17 03:22:21 --> Loader Class Initialized
INFO - 2023-04-17 03:22:21 --> Controller Class Initialized
DEBUG - 2023-04-17 03:22:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:22:21 --> Database Driver Class Initialized
INFO - 2023-04-17 03:22:21 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:22:21 --> Final output sent to browser
DEBUG - 2023-04-17 03:22:21 --> Total execution time: 0.0584
INFO - 2023-04-17 03:22:23 --> Config Class Initialized
INFO - 2023-04-17 03:22:23 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:22:23 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:22:23 --> Utf8 Class Initialized
INFO - 2023-04-17 03:22:23 --> URI Class Initialized
INFO - 2023-04-17 03:22:23 --> Router Class Initialized
INFO - 2023-04-17 03:22:23 --> Output Class Initialized
INFO - 2023-04-17 03:22:23 --> Security Class Initialized
DEBUG - 2023-04-17 03:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:22:23 --> Input Class Initialized
INFO - 2023-04-17 03:22:23 --> Language Class Initialized
INFO - 2023-04-17 03:22:23 --> Loader Class Initialized
INFO - 2023-04-17 03:22:23 --> Controller Class Initialized
DEBUG - 2023-04-17 03:22:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:22:23 --> Database Driver Class Initialized
INFO - 2023-04-17 03:22:23 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:22:23 --> Final output sent to browser
DEBUG - 2023-04-17 03:22:23 --> Total execution time: 0.0643
INFO - 2023-04-17 03:22:23 --> Config Class Initialized
INFO - 2023-04-17 03:22:23 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:22:23 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:22:23 --> Utf8 Class Initialized
INFO - 2023-04-17 03:22:23 --> URI Class Initialized
INFO - 2023-04-17 03:22:23 --> Router Class Initialized
INFO - 2023-04-17 03:22:23 --> Output Class Initialized
INFO - 2023-04-17 03:22:23 --> Security Class Initialized
DEBUG - 2023-04-17 03:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:22:23 --> Input Class Initialized
INFO - 2023-04-17 03:22:23 --> Language Class Initialized
INFO - 2023-04-17 03:22:23 --> Loader Class Initialized
INFO - 2023-04-17 03:22:23 --> Controller Class Initialized
DEBUG - 2023-04-17 03:22:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:22:23 --> Database Driver Class Initialized
INFO - 2023-04-17 03:22:23 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:22:23 --> Final output sent to browser
DEBUG - 2023-04-17 03:22:23 --> Total execution time: 0.0530
INFO - 2023-04-17 03:31:41 --> Config Class Initialized
INFO - 2023-04-17 03:31:41 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:31:41 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:31:41 --> Utf8 Class Initialized
INFO - 2023-04-17 03:31:41 --> URI Class Initialized
INFO - 2023-04-17 03:31:41 --> Router Class Initialized
INFO - 2023-04-17 03:31:41 --> Output Class Initialized
INFO - 2023-04-17 03:31:41 --> Security Class Initialized
DEBUG - 2023-04-17 03:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:31:41 --> Input Class Initialized
INFO - 2023-04-17 03:31:41 --> Language Class Initialized
INFO - 2023-04-17 03:31:41 --> Loader Class Initialized
INFO - 2023-04-17 03:31:41 --> Controller Class Initialized
DEBUG - 2023-04-17 03:31:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:31:41 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:41 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:31:41 --> Final output sent to browser
DEBUG - 2023-04-17 03:31:41 --> Total execution time: 0.0233
INFO - 2023-04-17 03:31:41 --> Config Class Initialized
INFO - 2023-04-17 03:31:41 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:31:41 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:31:41 --> Utf8 Class Initialized
INFO - 2023-04-17 03:31:41 --> URI Class Initialized
INFO - 2023-04-17 03:31:41 --> Router Class Initialized
INFO - 2023-04-17 03:31:41 --> Output Class Initialized
INFO - 2023-04-17 03:31:41 --> Security Class Initialized
DEBUG - 2023-04-17 03:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:31:41 --> Input Class Initialized
INFO - 2023-04-17 03:31:41 --> Language Class Initialized
INFO - 2023-04-17 03:31:41 --> Loader Class Initialized
INFO - 2023-04-17 03:31:41 --> Controller Class Initialized
DEBUG - 2023-04-17 03:31:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:31:41 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:41 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:31:41 --> Final output sent to browser
DEBUG - 2023-04-17 03:31:41 --> Total execution time: 0.0542
INFO - 2023-04-17 03:31:45 --> Config Class Initialized
INFO - 2023-04-17 03:31:45 --> Hooks Class Initialized
INFO - 2023-04-17 03:31:45 --> Config Class Initialized
INFO - 2023-04-17 03:31:45 --> Config Class Initialized
INFO - 2023-04-17 03:31:45 --> Hooks Class Initialized
INFO - 2023-04-17 03:31:45 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:31:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 03:31:45 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:31:45 --> Utf8 Class Initialized
DEBUG - 2023-04-17 03:31:45 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:31:45 --> Utf8 Class Initialized
INFO - 2023-04-17 03:31:45 --> Utf8 Class Initialized
INFO - 2023-04-17 03:31:45 --> URI Class Initialized
INFO - 2023-04-17 03:31:45 --> URI Class Initialized
INFO - 2023-04-17 03:31:45 --> URI Class Initialized
INFO - 2023-04-17 03:31:45 --> Router Class Initialized
INFO - 2023-04-17 03:31:45 --> Router Class Initialized
INFO - 2023-04-17 03:31:45 --> Router Class Initialized
INFO - 2023-04-17 03:31:45 --> Output Class Initialized
INFO - 2023-04-17 03:31:45 --> Output Class Initialized
INFO - 2023-04-17 03:31:45 --> Output Class Initialized
INFO - 2023-04-17 03:31:45 --> Security Class Initialized
INFO - 2023-04-17 03:31:45 --> Security Class Initialized
INFO - 2023-04-17 03:31:45 --> Security Class Initialized
DEBUG - 2023-04-17 03:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 03:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:31:45 --> Input Class Initialized
INFO - 2023-04-17 03:31:45 --> Input Class Initialized
DEBUG - 2023-04-17 03:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:31:45 --> Language Class Initialized
INFO - 2023-04-17 03:31:45 --> Language Class Initialized
INFO - 2023-04-17 03:31:45 --> Input Class Initialized
INFO - 2023-04-17 03:31:45 --> Language Class Initialized
INFO - 2023-04-17 03:31:45 --> Loader Class Initialized
INFO - 2023-04-17 03:31:45 --> Controller Class Initialized
DEBUG - 2023-04-17 03:31:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:31:45 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:45 --> Loader Class Initialized
INFO - 2023-04-17 03:31:45 --> Controller Class Initialized
INFO - 2023-04-17 03:31:45 --> Loader Class Initialized
DEBUG - 2023-04-17 03:31:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:31:45 --> Controller Class Initialized
INFO - 2023-04-17 03:31:45 --> Database Driver Class Initialized
DEBUG - 2023-04-17 03:31:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:31:45 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:45 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:31:45 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:31:45 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:45 --> Model "Login_model" initialized
INFO - 2023-04-17 03:31:45 --> Final output sent to browser
DEBUG - 2023-04-17 03:31:45 --> Total execution time: 0.0688
INFO - 2023-04-17 03:31:45 --> Config Class Initialized
INFO - 2023-04-17 03:31:45 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:31:45 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:31:45 --> Utf8 Class Initialized
INFO - 2023-04-17 03:31:45 --> URI Class Initialized
INFO - 2023-04-17 03:31:45 --> Router Class Initialized
INFO - 2023-04-17 03:31:45 --> Output Class Initialized
INFO - 2023-04-17 03:31:45 --> Security Class Initialized
DEBUG - 2023-04-17 03:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:31:45 --> Input Class Initialized
INFO - 2023-04-17 03:31:45 --> Language Class Initialized
INFO - 2023-04-17 03:31:45 --> Loader Class Initialized
INFO - 2023-04-17 03:31:45 --> Controller Class Initialized
DEBUG - 2023-04-17 03:31:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:31:45 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:45 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:31:46 --> Final output sent to browser
DEBUG - 2023-04-17 03:31:46 --> Total execution time: 0.1156
INFO - 2023-04-17 03:31:46 --> Config Class Initialized
INFO - 2023-04-17 03:31:46 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:31:46 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:31:46 --> Final output sent to browser
INFO - 2023-04-17 03:31:46 --> Final output sent to browser
DEBUG - 2023-04-17 03:31:46 --> Total execution time: 0.0375
DEBUG - 2023-04-17 03:31:46 --> Total execution time: 0.1067
INFO - 2023-04-17 03:31:46 --> Utf8 Class Initialized
INFO - 2023-04-17 03:31:46 --> URI Class Initialized
INFO - 2023-04-17 03:31:46 --> Router Class Initialized
INFO - 2023-04-17 03:31:46 --> Output Class Initialized
INFO - 2023-04-17 03:31:46 --> Config Class Initialized
INFO - 2023-04-17 03:31:46 --> Security Class Initialized
INFO - 2023-04-17 03:31:46 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:31:46 --> Input Class Initialized
DEBUG - 2023-04-17 03:31:46 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:31:46 --> Language Class Initialized
INFO - 2023-04-17 03:31:46 --> Utf8 Class Initialized
INFO - 2023-04-17 03:31:46 --> Loader Class Initialized
INFO - 2023-04-17 03:31:46 --> URI Class Initialized
INFO - 2023-04-17 03:31:46 --> Controller Class Initialized
INFO - 2023-04-17 03:31:46 --> Router Class Initialized
DEBUG - 2023-04-17 03:31:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:31:46 --> Output Class Initialized
INFO - 2023-04-17 03:31:46 --> Security Class Initialized
INFO - 2023-04-17 03:31:46 --> Database Driver Class Initialized
DEBUG - 2023-04-17 03:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:31:46 --> Input Class Initialized
INFO - 2023-04-17 03:31:46 --> Language Class Initialized
INFO - 2023-04-17 03:31:46 --> Loader Class Initialized
INFO - 2023-04-17 03:31:46 --> Config Class Initialized
INFO - 2023-04-17 03:31:46 --> Controller Class Initialized
INFO - 2023-04-17 03:31:46 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:31:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 03:31:46 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:31:46 --> Utf8 Class Initialized
INFO - 2023-04-17 03:31:46 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:46 --> URI Class Initialized
INFO - 2023-04-17 03:31:46 --> Router Class Initialized
INFO - 2023-04-17 03:31:46 --> Output Class Initialized
INFO - 2023-04-17 03:31:46 --> Security Class Initialized
DEBUG - 2023-04-17 03:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:31:46 --> Input Class Initialized
INFO - 2023-04-17 03:31:46 --> Language Class Initialized
INFO - 2023-04-17 03:31:46 --> Loader Class Initialized
INFO - 2023-04-17 03:31:46 --> Controller Class Initialized
DEBUG - 2023-04-17 03:31:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:31:46 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:46 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:46 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:31:46 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:31:46 --> Model "Login_model" initialized
INFO - 2023-04-17 03:31:46 --> Final output sent to browser
DEBUG - 2023-04-17 03:31:46 --> Total execution time: 0.0647
INFO - 2023-04-17 03:31:46 --> Config Class Initialized
INFO - 2023-04-17 03:31:46 --> Final output sent to browser
INFO - 2023-04-17 03:31:46 --> Final output sent to browser
DEBUG - 2023-04-17 03:31:46 --> Total execution time: 0.0272
DEBUG - 2023-04-17 03:31:46 --> Total execution time: 0.0300
INFO - 2023-04-17 03:31:46 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:31:46 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:31:46 --> Utf8 Class Initialized
INFO - 2023-04-17 03:31:46 --> URI Class Initialized
INFO - 2023-04-17 03:31:46 --> Router Class Initialized
INFO - 2023-04-17 03:31:46 --> Output Class Initialized
INFO - 2023-04-17 03:31:46 --> Security Class Initialized
DEBUG - 2023-04-17 03:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:31:46 --> Input Class Initialized
INFO - 2023-04-17 03:31:46 --> Language Class Initialized
INFO - 2023-04-17 03:31:46 --> Loader Class Initialized
INFO - 2023-04-17 03:31:46 --> Controller Class Initialized
DEBUG - 2023-04-17 03:31:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:31:46 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:46 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:31:46 --> Final output sent to browser
DEBUG - 2023-04-17 03:31:46 --> Total execution time: 0.1058
INFO - 2023-04-17 03:31:54 --> Config Class Initialized
INFO - 2023-04-17 03:31:54 --> Config Class Initialized
INFO - 2023-04-17 03:31:54 --> Hooks Class Initialized
INFO - 2023-04-17 03:31:54 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:31:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 03:31:54 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:31:54 --> Utf8 Class Initialized
INFO - 2023-04-17 03:31:54 --> Utf8 Class Initialized
INFO - 2023-04-17 03:31:54 --> URI Class Initialized
INFO - 2023-04-17 03:31:54 --> URI Class Initialized
INFO - 2023-04-17 03:31:54 --> Router Class Initialized
INFO - 2023-04-17 03:31:54 --> Router Class Initialized
INFO - 2023-04-17 03:31:54 --> Output Class Initialized
INFO - 2023-04-17 03:31:54 --> Output Class Initialized
INFO - 2023-04-17 03:31:54 --> Security Class Initialized
INFO - 2023-04-17 03:31:54 --> Security Class Initialized
DEBUG - 2023-04-17 03:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 03:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:31:54 --> Input Class Initialized
INFO - 2023-04-17 03:31:54 --> Input Class Initialized
INFO - 2023-04-17 03:31:54 --> Language Class Initialized
INFO - 2023-04-17 03:31:54 --> Language Class Initialized
INFO - 2023-04-17 03:31:54 --> Loader Class Initialized
INFO - 2023-04-17 03:31:54 --> Loader Class Initialized
INFO - 2023-04-17 03:31:54 --> Controller Class Initialized
INFO - 2023-04-17 03:31:54 --> Controller Class Initialized
DEBUG - 2023-04-17 03:31:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 03:31:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:31:54 --> Final output sent to browser
DEBUG - 2023-04-17 03:31:54 --> Total execution time: 0.0219
INFO - 2023-04-17 03:31:54 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:54 --> Config Class Initialized
INFO - 2023-04-17 03:31:54 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:31:54 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:31:54 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:31:54 --> Utf8 Class Initialized
INFO - 2023-04-17 03:31:54 --> URI Class Initialized
INFO - 2023-04-17 03:31:54 --> Router Class Initialized
INFO - 2023-04-17 03:31:54 --> Output Class Initialized
INFO - 2023-04-17 03:31:54 --> Security Class Initialized
DEBUG - 2023-04-17 03:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:31:54 --> Input Class Initialized
INFO - 2023-04-17 03:31:54 --> Language Class Initialized
INFO - 2023-04-17 03:31:54 --> Loader Class Initialized
INFO - 2023-04-17 03:31:54 --> Controller Class Initialized
DEBUG - 2023-04-17 03:31:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:31:54 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:54 --> Final output sent to browser
DEBUG - 2023-04-17 03:31:54 --> Total execution time: 0.0709
INFO - 2023-04-17 03:31:54 --> Config Class Initialized
INFO - 2023-04-17 03:31:54 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:31:54 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:31:54 --> Utf8 Class Initialized
INFO - 2023-04-17 03:31:54 --> URI Class Initialized
INFO - 2023-04-17 03:31:54 --> Router Class Initialized
INFO - 2023-04-17 03:31:54 --> Output Class Initialized
INFO - 2023-04-17 03:31:54 --> Security Class Initialized
DEBUG - 2023-04-17 03:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:31:54 --> Input Class Initialized
INFO - 2023-04-17 03:31:54 --> Language Class Initialized
INFO - 2023-04-17 03:31:54 --> Loader Class Initialized
INFO - 2023-04-17 03:31:54 --> Controller Class Initialized
DEBUG - 2023-04-17 03:31:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:31:54 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:54 --> Model "Login_model" initialized
INFO - 2023-04-17 03:31:54 --> Database Driver Class Initialized
INFO - 2023-04-17 03:31:54 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:31:54 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:31:54 --> Final output sent to browser
DEBUG - 2023-04-17 03:31:54 --> Total execution time: 0.0291
INFO - 2023-04-17 03:31:54 --> Final output sent to browser
DEBUG - 2023-04-17 03:31:54 --> Total execution time: 0.0791
INFO - 2023-04-17 03:40:32 --> Config Class Initialized
INFO - 2023-04-17 03:40:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:40:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:40:32 --> Utf8 Class Initialized
INFO - 2023-04-17 03:40:32 --> URI Class Initialized
INFO - 2023-04-17 03:40:32 --> Router Class Initialized
INFO - 2023-04-17 03:40:32 --> Output Class Initialized
INFO - 2023-04-17 03:40:32 --> Security Class Initialized
DEBUG - 2023-04-17 03:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:40:32 --> Input Class Initialized
INFO - 2023-04-17 03:40:32 --> Language Class Initialized
INFO - 2023-04-17 03:40:32 --> Loader Class Initialized
INFO - 2023-04-17 03:40:32 --> Controller Class Initialized
DEBUG - 2023-04-17 03:40:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:40:32 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:40:32 --> Final output sent to browser
DEBUG - 2023-04-17 03:40:32 --> Total execution time: 0.0154
INFO - 2023-04-17 03:40:32 --> Config Class Initialized
INFO - 2023-04-17 03:40:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:40:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:40:32 --> Utf8 Class Initialized
INFO - 2023-04-17 03:40:32 --> URI Class Initialized
INFO - 2023-04-17 03:40:32 --> Router Class Initialized
INFO - 2023-04-17 03:40:32 --> Output Class Initialized
INFO - 2023-04-17 03:40:32 --> Security Class Initialized
DEBUG - 2023-04-17 03:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:40:32 --> Input Class Initialized
INFO - 2023-04-17 03:40:32 --> Language Class Initialized
INFO - 2023-04-17 03:40:32 --> Loader Class Initialized
INFO - 2023-04-17 03:40:32 --> Controller Class Initialized
DEBUG - 2023-04-17 03:40:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:40:32 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:40:32 --> Final output sent to browser
DEBUG - 2023-04-17 03:40:32 --> Total execution time: 0.0090
INFO - 2023-04-17 03:40:34 --> Config Class Initialized
INFO - 2023-04-17 03:40:34 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:40:34 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:40:34 --> Utf8 Class Initialized
INFO - 2023-04-17 03:40:34 --> URI Class Initialized
INFO - 2023-04-17 03:40:34 --> Router Class Initialized
INFO - 2023-04-17 03:40:34 --> Output Class Initialized
INFO - 2023-04-17 03:40:34 --> Security Class Initialized
DEBUG - 2023-04-17 03:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:40:34 --> Input Class Initialized
INFO - 2023-04-17 03:40:34 --> Language Class Initialized
INFO - 2023-04-17 03:40:34 --> Loader Class Initialized
INFO - 2023-04-17 03:40:34 --> Controller Class Initialized
DEBUG - 2023-04-17 03:40:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:40:34 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:34 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:40:34 --> Final output sent to browser
DEBUG - 2023-04-17 03:40:34 --> Total execution time: 0.0370
INFO - 2023-04-17 03:40:34 --> Config Class Initialized
INFO - 2023-04-17 03:40:34 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:40:34 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:40:34 --> Utf8 Class Initialized
INFO - 2023-04-17 03:40:34 --> URI Class Initialized
INFO - 2023-04-17 03:40:34 --> Router Class Initialized
INFO - 2023-04-17 03:40:34 --> Output Class Initialized
INFO - 2023-04-17 03:40:34 --> Security Class Initialized
DEBUG - 2023-04-17 03:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:40:34 --> Input Class Initialized
INFO - 2023-04-17 03:40:34 --> Language Class Initialized
INFO - 2023-04-17 03:40:34 --> Loader Class Initialized
INFO - 2023-04-17 03:40:34 --> Controller Class Initialized
DEBUG - 2023-04-17 03:40:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:40:34 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:34 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:40:34 --> Final output sent to browser
DEBUG - 2023-04-17 03:40:34 --> Total execution time: 0.0116
INFO - 2023-04-17 03:40:35 --> Config Class Initialized
INFO - 2023-04-17 03:40:35 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:40:35 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:40:35 --> Utf8 Class Initialized
INFO - 2023-04-17 03:40:35 --> URI Class Initialized
INFO - 2023-04-17 03:40:35 --> Router Class Initialized
INFO - 2023-04-17 03:40:35 --> Output Class Initialized
INFO - 2023-04-17 03:40:35 --> Security Class Initialized
DEBUG - 2023-04-17 03:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:40:35 --> Input Class Initialized
INFO - 2023-04-17 03:40:35 --> Language Class Initialized
INFO - 2023-04-17 03:40:35 --> Loader Class Initialized
INFO - 2023-04-17 03:40:35 --> Controller Class Initialized
DEBUG - 2023-04-17 03:40:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:40:35 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:35 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:40:35 --> Final output sent to browser
DEBUG - 2023-04-17 03:40:35 --> Total execution time: 0.0133
INFO - 2023-04-17 03:40:35 --> Config Class Initialized
INFO - 2023-04-17 03:40:35 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:40:35 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:40:35 --> Utf8 Class Initialized
INFO - 2023-04-17 03:40:35 --> URI Class Initialized
INFO - 2023-04-17 03:40:35 --> Router Class Initialized
INFO - 2023-04-17 03:40:35 --> Output Class Initialized
INFO - 2023-04-17 03:40:35 --> Security Class Initialized
DEBUG - 2023-04-17 03:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:40:35 --> Input Class Initialized
INFO - 2023-04-17 03:40:35 --> Language Class Initialized
INFO - 2023-04-17 03:40:35 --> Loader Class Initialized
INFO - 2023-04-17 03:40:35 --> Controller Class Initialized
DEBUG - 2023-04-17 03:40:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:40:35 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:35 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:40:35 --> Final output sent to browser
DEBUG - 2023-04-17 03:40:35 --> Total execution time: 0.0109
INFO - 2023-04-17 03:40:35 --> Config Class Initialized
INFO - 2023-04-17 03:40:35 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:40:35 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:40:35 --> Utf8 Class Initialized
INFO - 2023-04-17 03:40:35 --> URI Class Initialized
INFO - 2023-04-17 03:40:35 --> Router Class Initialized
INFO - 2023-04-17 03:40:35 --> Output Class Initialized
INFO - 2023-04-17 03:40:35 --> Security Class Initialized
DEBUG - 2023-04-17 03:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:40:35 --> Input Class Initialized
INFO - 2023-04-17 03:40:35 --> Language Class Initialized
INFO - 2023-04-17 03:40:35 --> Loader Class Initialized
INFO - 2023-04-17 03:40:35 --> Controller Class Initialized
DEBUG - 2023-04-17 03:40:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:40:35 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:35 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:40:35 --> Final output sent to browser
DEBUG - 2023-04-17 03:40:35 --> Total execution time: 0.0543
INFO - 2023-04-17 03:40:35 --> Config Class Initialized
INFO - 2023-04-17 03:40:35 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:40:35 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:40:35 --> Utf8 Class Initialized
INFO - 2023-04-17 03:40:35 --> URI Class Initialized
INFO - 2023-04-17 03:40:35 --> Router Class Initialized
INFO - 2023-04-17 03:40:35 --> Output Class Initialized
INFO - 2023-04-17 03:40:35 --> Security Class Initialized
DEBUG - 2023-04-17 03:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:40:35 --> Input Class Initialized
INFO - 2023-04-17 03:40:35 --> Language Class Initialized
INFO - 2023-04-17 03:40:35 --> Loader Class Initialized
INFO - 2023-04-17 03:40:35 --> Controller Class Initialized
DEBUG - 2023-04-17 03:40:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:40:35 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:35 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:40:35 --> Final output sent to browser
DEBUG - 2023-04-17 03:40:35 --> Total execution time: 0.0166
INFO - 2023-04-17 03:40:54 --> Config Class Initialized
INFO - 2023-04-17 03:40:54 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:40:54 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:40:54 --> Utf8 Class Initialized
INFO - 2023-04-17 03:40:54 --> URI Class Initialized
INFO - 2023-04-17 03:40:54 --> Router Class Initialized
INFO - 2023-04-17 03:40:54 --> Output Class Initialized
INFO - 2023-04-17 03:40:54 --> Security Class Initialized
DEBUG - 2023-04-17 03:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:40:54 --> Input Class Initialized
INFO - 2023-04-17 03:40:54 --> Language Class Initialized
INFO - 2023-04-17 03:40:54 --> Loader Class Initialized
INFO - 2023-04-17 03:40:54 --> Controller Class Initialized
DEBUG - 2023-04-17 03:40:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:40:54 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:54 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:40:54 --> Final output sent to browser
DEBUG - 2023-04-17 03:40:54 --> Total execution time: 0.0123
INFO - 2023-04-17 03:40:54 --> Config Class Initialized
INFO - 2023-04-17 03:40:54 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:40:54 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:40:54 --> Utf8 Class Initialized
INFO - 2023-04-17 03:40:54 --> URI Class Initialized
INFO - 2023-04-17 03:40:54 --> Router Class Initialized
INFO - 2023-04-17 03:40:54 --> Output Class Initialized
INFO - 2023-04-17 03:40:54 --> Security Class Initialized
DEBUG - 2023-04-17 03:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:40:54 --> Input Class Initialized
INFO - 2023-04-17 03:40:54 --> Language Class Initialized
INFO - 2023-04-17 03:40:54 --> Loader Class Initialized
INFO - 2023-04-17 03:40:54 --> Controller Class Initialized
DEBUG - 2023-04-17 03:40:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:40:54 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:54 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:40:54 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:54 --> Model "Login_model" initialized
INFO - 2023-04-17 03:40:54 --> Final output sent to browser
DEBUG - 2023-04-17 03:40:54 --> Total execution time: 0.0308
INFO - 2023-04-17 03:40:54 --> Config Class Initialized
INFO - 2023-04-17 03:40:54 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:40:54 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:40:54 --> Utf8 Class Initialized
INFO - 2023-04-17 03:40:54 --> URI Class Initialized
INFO - 2023-04-17 03:40:54 --> Router Class Initialized
INFO - 2023-04-17 03:40:54 --> Output Class Initialized
INFO - 2023-04-17 03:40:54 --> Security Class Initialized
DEBUG - 2023-04-17 03:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:40:54 --> Input Class Initialized
INFO - 2023-04-17 03:40:54 --> Language Class Initialized
INFO - 2023-04-17 03:40:54 --> Loader Class Initialized
INFO - 2023-04-17 03:40:54 --> Controller Class Initialized
DEBUG - 2023-04-17 03:40:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:40:54 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:54 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:40:54 --> Final output sent to browser
DEBUG - 2023-04-17 03:40:54 --> Total execution time: 0.0133
INFO - 2023-04-17 03:40:54 --> Config Class Initialized
INFO - 2023-04-17 03:40:54 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:40:54 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:40:54 --> Utf8 Class Initialized
INFO - 2023-04-17 03:40:54 --> URI Class Initialized
INFO - 2023-04-17 03:40:54 --> Router Class Initialized
INFO - 2023-04-17 03:40:54 --> Output Class Initialized
INFO - 2023-04-17 03:40:54 --> Security Class Initialized
DEBUG - 2023-04-17 03:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:40:54 --> Input Class Initialized
INFO - 2023-04-17 03:40:54 --> Language Class Initialized
INFO - 2023-04-17 03:40:54 --> Loader Class Initialized
INFO - 2023-04-17 03:40:54 --> Controller Class Initialized
DEBUG - 2023-04-17 03:40:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:40:54 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:54 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:40:55 --> Final output sent to browser
DEBUG - 2023-04-17 03:40:55 --> Total execution time: 0.2359
INFO - 2023-04-17 03:40:59 --> Config Class Initialized
INFO - 2023-04-17 03:40:59 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:40:59 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:40:59 --> Utf8 Class Initialized
INFO - 2023-04-17 03:40:59 --> URI Class Initialized
INFO - 2023-04-17 03:40:59 --> Router Class Initialized
INFO - 2023-04-17 03:40:59 --> Output Class Initialized
INFO - 2023-04-17 03:40:59 --> Security Class Initialized
DEBUG - 2023-04-17 03:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:40:59 --> Input Class Initialized
INFO - 2023-04-17 03:40:59 --> Language Class Initialized
INFO - 2023-04-17 03:40:59 --> Loader Class Initialized
INFO - 2023-04-17 03:40:59 --> Controller Class Initialized
DEBUG - 2023-04-17 03:40:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:40:59 --> Database Driver Class Initialized
INFO - 2023-04-17 03:40:59 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:40:59 --> Final output sent to browser
DEBUG - 2023-04-17 03:40:59 --> Total execution time: 0.0167
INFO - 2023-04-17 03:41:04 --> Config Class Initialized
INFO - 2023-04-17 03:41:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:04 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:04 --> URI Class Initialized
INFO - 2023-04-17 03:41:04 --> Router Class Initialized
INFO - 2023-04-17 03:41:04 --> Output Class Initialized
INFO - 2023-04-17 03:41:04 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:04 --> Input Class Initialized
INFO - 2023-04-17 03:41:04 --> Language Class Initialized
INFO - 2023-04-17 03:41:04 --> Loader Class Initialized
INFO - 2023-04-17 03:41:04 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:04 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:04 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:04 --> Total execution time: 0.0166
INFO - 2023-04-17 03:41:04 --> Config Class Initialized
INFO - 2023-04-17 03:41:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:04 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:04 --> URI Class Initialized
INFO - 2023-04-17 03:41:04 --> Router Class Initialized
INFO - 2023-04-17 03:41:04 --> Output Class Initialized
INFO - 2023-04-17 03:41:04 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:04 --> Input Class Initialized
INFO - 2023-04-17 03:41:04 --> Language Class Initialized
INFO - 2023-04-17 03:41:04 --> Loader Class Initialized
INFO - 2023-04-17 03:41:04 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:04 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:04 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:04 --> Total execution time: 0.0163
INFO - 2023-04-17 03:41:09 --> Config Class Initialized
INFO - 2023-04-17 03:41:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:09 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:09 --> URI Class Initialized
INFO - 2023-04-17 03:41:09 --> Router Class Initialized
INFO - 2023-04-17 03:41:09 --> Output Class Initialized
INFO - 2023-04-17 03:41:09 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:09 --> Input Class Initialized
INFO - 2023-04-17 03:41:09 --> Language Class Initialized
INFO - 2023-04-17 03:41:09 --> Loader Class Initialized
INFO - 2023-04-17 03:41:09 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:09 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:09 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:09 --> Total execution time: 0.0143
INFO - 2023-04-17 03:41:14 --> Config Class Initialized
INFO - 2023-04-17 03:41:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:14 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:14 --> URI Class Initialized
INFO - 2023-04-17 03:41:14 --> Router Class Initialized
INFO - 2023-04-17 03:41:14 --> Output Class Initialized
INFO - 2023-04-17 03:41:14 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:14 --> Input Class Initialized
INFO - 2023-04-17 03:41:14 --> Language Class Initialized
INFO - 2023-04-17 03:41:14 --> Loader Class Initialized
INFO - 2023-04-17 03:41:14 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:14 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:14 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:14 --> Total execution time: 0.0116
INFO - 2023-04-17 03:41:14 --> Config Class Initialized
INFO - 2023-04-17 03:41:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:14 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:14 --> URI Class Initialized
INFO - 2023-04-17 03:41:14 --> Router Class Initialized
INFO - 2023-04-17 03:41:14 --> Output Class Initialized
INFO - 2023-04-17 03:41:14 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:14 --> Input Class Initialized
INFO - 2023-04-17 03:41:14 --> Language Class Initialized
INFO - 2023-04-17 03:41:14 --> Loader Class Initialized
INFO - 2023-04-17 03:41:14 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:14 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:14 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:14 --> Total execution time: 0.0132
INFO - 2023-04-17 03:41:19 --> Config Class Initialized
INFO - 2023-04-17 03:41:19 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:19 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:19 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:19 --> URI Class Initialized
INFO - 2023-04-17 03:41:19 --> Router Class Initialized
INFO - 2023-04-17 03:41:19 --> Output Class Initialized
INFO - 2023-04-17 03:41:19 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:19 --> Input Class Initialized
INFO - 2023-04-17 03:41:19 --> Language Class Initialized
INFO - 2023-04-17 03:41:19 --> Loader Class Initialized
INFO - 2023-04-17 03:41:19 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:19 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:19 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:19 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:19 --> Total execution time: 0.0202
INFO - 2023-04-17 03:41:24 --> Config Class Initialized
INFO - 2023-04-17 03:41:24 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:24 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:24 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:24 --> URI Class Initialized
INFO - 2023-04-17 03:41:24 --> Router Class Initialized
INFO - 2023-04-17 03:41:24 --> Output Class Initialized
INFO - 2023-04-17 03:41:24 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:24 --> Input Class Initialized
INFO - 2023-04-17 03:41:24 --> Language Class Initialized
INFO - 2023-04-17 03:41:24 --> Loader Class Initialized
INFO - 2023-04-17 03:41:24 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:24 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:24 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:24 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:24 --> Total execution time: 0.0128
INFO - 2023-04-17 03:41:24 --> Config Class Initialized
INFO - 2023-04-17 03:41:24 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:24 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:24 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:24 --> URI Class Initialized
INFO - 2023-04-17 03:41:24 --> Router Class Initialized
INFO - 2023-04-17 03:41:24 --> Output Class Initialized
INFO - 2023-04-17 03:41:24 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:24 --> Input Class Initialized
INFO - 2023-04-17 03:41:24 --> Language Class Initialized
INFO - 2023-04-17 03:41:24 --> Loader Class Initialized
INFO - 2023-04-17 03:41:24 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:24 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:24 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:24 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:24 --> Total execution time: 0.0147
INFO - 2023-04-17 03:41:29 --> Config Class Initialized
INFO - 2023-04-17 03:41:29 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:29 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:29 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:29 --> URI Class Initialized
INFO - 2023-04-17 03:41:29 --> Router Class Initialized
INFO - 2023-04-17 03:41:29 --> Output Class Initialized
INFO - 2023-04-17 03:41:29 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:29 --> Input Class Initialized
INFO - 2023-04-17 03:41:29 --> Language Class Initialized
INFO - 2023-04-17 03:41:29 --> Loader Class Initialized
INFO - 2023-04-17 03:41:29 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:29 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:29 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:29 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:29 --> Total execution time: 0.0160
INFO - 2023-04-17 03:41:34 --> Config Class Initialized
INFO - 2023-04-17 03:41:34 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:34 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:34 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:34 --> URI Class Initialized
INFO - 2023-04-17 03:41:34 --> Router Class Initialized
INFO - 2023-04-17 03:41:34 --> Output Class Initialized
INFO - 2023-04-17 03:41:34 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:34 --> Input Class Initialized
INFO - 2023-04-17 03:41:34 --> Language Class Initialized
INFO - 2023-04-17 03:41:34 --> Loader Class Initialized
INFO - 2023-04-17 03:41:34 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:34 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:34 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:34 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:34 --> Total execution time: 0.0141
INFO - 2023-04-17 03:41:34 --> Config Class Initialized
INFO - 2023-04-17 03:41:34 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:34 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:34 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:34 --> URI Class Initialized
INFO - 2023-04-17 03:41:34 --> Router Class Initialized
INFO - 2023-04-17 03:41:34 --> Output Class Initialized
INFO - 2023-04-17 03:41:34 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:34 --> Input Class Initialized
INFO - 2023-04-17 03:41:34 --> Language Class Initialized
INFO - 2023-04-17 03:41:34 --> Loader Class Initialized
INFO - 2023-04-17 03:41:34 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:34 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:34 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:34 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:34 --> Total execution time: 0.0149
INFO - 2023-04-17 03:41:39 --> Config Class Initialized
INFO - 2023-04-17 03:41:39 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:39 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:39 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:39 --> URI Class Initialized
INFO - 2023-04-17 03:41:39 --> Router Class Initialized
INFO - 2023-04-17 03:41:39 --> Output Class Initialized
INFO - 2023-04-17 03:41:39 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:39 --> Input Class Initialized
INFO - 2023-04-17 03:41:39 --> Language Class Initialized
INFO - 2023-04-17 03:41:39 --> Loader Class Initialized
INFO - 2023-04-17 03:41:39 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:39 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:39 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:39 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:39 --> Total execution time: 0.0175
INFO - 2023-04-17 03:41:44 --> Config Class Initialized
INFO - 2023-04-17 03:41:44 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:44 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:44 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:44 --> URI Class Initialized
INFO - 2023-04-17 03:41:44 --> Router Class Initialized
INFO - 2023-04-17 03:41:44 --> Output Class Initialized
INFO - 2023-04-17 03:41:44 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:44 --> Input Class Initialized
INFO - 2023-04-17 03:41:44 --> Language Class Initialized
INFO - 2023-04-17 03:41:44 --> Loader Class Initialized
INFO - 2023-04-17 03:41:44 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:44 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:44 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:44 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:44 --> Total execution time: 0.0145
INFO - 2023-04-17 03:41:44 --> Config Class Initialized
INFO - 2023-04-17 03:41:44 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:44 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:44 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:44 --> URI Class Initialized
INFO - 2023-04-17 03:41:44 --> Router Class Initialized
INFO - 2023-04-17 03:41:44 --> Output Class Initialized
INFO - 2023-04-17 03:41:44 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:44 --> Input Class Initialized
INFO - 2023-04-17 03:41:44 --> Language Class Initialized
INFO - 2023-04-17 03:41:44 --> Loader Class Initialized
INFO - 2023-04-17 03:41:44 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:44 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:44 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:44 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:44 --> Total execution time: 0.0132
INFO - 2023-04-17 03:41:49 --> Config Class Initialized
INFO - 2023-04-17 03:41:49 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:49 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:49 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:49 --> URI Class Initialized
INFO - 2023-04-17 03:41:49 --> Router Class Initialized
INFO - 2023-04-17 03:41:49 --> Output Class Initialized
INFO - 2023-04-17 03:41:49 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:49 --> Input Class Initialized
INFO - 2023-04-17 03:41:49 --> Language Class Initialized
INFO - 2023-04-17 03:41:49 --> Loader Class Initialized
INFO - 2023-04-17 03:41:49 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:49 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:49 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:49 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:49 --> Total execution time: 0.0227
INFO - 2023-04-17 03:41:54 --> Config Class Initialized
INFO - 2023-04-17 03:41:54 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:54 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:54 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:54 --> URI Class Initialized
INFO - 2023-04-17 03:41:54 --> Router Class Initialized
INFO - 2023-04-17 03:41:54 --> Output Class Initialized
INFO - 2023-04-17 03:41:54 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:54 --> Input Class Initialized
INFO - 2023-04-17 03:41:54 --> Language Class Initialized
INFO - 2023-04-17 03:41:54 --> Loader Class Initialized
INFO - 2023-04-17 03:41:54 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:54 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:54 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:54 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:54 --> Total execution time: 0.0469
INFO - 2023-04-17 03:41:54 --> Config Class Initialized
INFO - 2023-04-17 03:41:54 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:54 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:54 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:54 --> URI Class Initialized
INFO - 2023-04-17 03:41:54 --> Router Class Initialized
INFO - 2023-04-17 03:41:54 --> Output Class Initialized
INFO - 2023-04-17 03:41:54 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:54 --> Input Class Initialized
INFO - 2023-04-17 03:41:54 --> Language Class Initialized
INFO - 2023-04-17 03:41:54 --> Loader Class Initialized
INFO - 2023-04-17 03:41:54 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:54 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:54 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:54 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:54 --> Total execution time: 0.0360
INFO - 2023-04-17 03:41:59 --> Config Class Initialized
INFO - 2023-04-17 03:41:59 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:41:59 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:41:59 --> Utf8 Class Initialized
INFO - 2023-04-17 03:41:59 --> URI Class Initialized
INFO - 2023-04-17 03:41:59 --> Router Class Initialized
INFO - 2023-04-17 03:41:59 --> Output Class Initialized
INFO - 2023-04-17 03:41:59 --> Security Class Initialized
DEBUG - 2023-04-17 03:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:41:59 --> Input Class Initialized
INFO - 2023-04-17 03:41:59 --> Language Class Initialized
INFO - 2023-04-17 03:41:59 --> Loader Class Initialized
INFO - 2023-04-17 03:41:59 --> Controller Class Initialized
DEBUG - 2023-04-17 03:41:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:41:59 --> Database Driver Class Initialized
INFO - 2023-04-17 03:41:59 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:41:59 --> Final output sent to browser
DEBUG - 2023-04-17 03:41:59 --> Total execution time: 0.0269
INFO - 2023-04-17 03:42:04 --> Config Class Initialized
INFO - 2023-04-17 03:42:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:42:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:42:04 --> Utf8 Class Initialized
INFO - 2023-04-17 03:42:04 --> URI Class Initialized
INFO - 2023-04-17 03:42:04 --> Router Class Initialized
INFO - 2023-04-17 03:42:04 --> Output Class Initialized
INFO - 2023-04-17 03:42:04 --> Security Class Initialized
DEBUG - 2023-04-17 03:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:42:04 --> Input Class Initialized
INFO - 2023-04-17 03:42:04 --> Language Class Initialized
INFO - 2023-04-17 03:42:04 --> Loader Class Initialized
INFO - 2023-04-17 03:42:04 --> Controller Class Initialized
DEBUG - 2023-04-17 03:42:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:42:04 --> Database Driver Class Initialized
INFO - 2023-04-17 03:42:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:42:04 --> Final output sent to browser
DEBUG - 2023-04-17 03:42:04 --> Total execution time: 0.0350
INFO - 2023-04-17 03:42:04 --> Config Class Initialized
INFO - 2023-04-17 03:42:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:42:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:42:04 --> Utf8 Class Initialized
INFO - 2023-04-17 03:42:04 --> URI Class Initialized
INFO - 2023-04-17 03:42:04 --> Router Class Initialized
INFO - 2023-04-17 03:42:04 --> Output Class Initialized
INFO - 2023-04-17 03:42:04 --> Security Class Initialized
DEBUG - 2023-04-17 03:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:42:04 --> Input Class Initialized
INFO - 2023-04-17 03:42:04 --> Language Class Initialized
INFO - 2023-04-17 03:42:04 --> Loader Class Initialized
INFO - 2023-04-17 03:42:04 --> Controller Class Initialized
DEBUG - 2023-04-17 03:42:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:42:04 --> Database Driver Class Initialized
INFO - 2023-04-17 03:42:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:42:04 --> Final output sent to browser
DEBUG - 2023-04-17 03:42:04 --> Total execution time: 0.0376
INFO - 2023-04-17 03:42:09 --> Config Class Initialized
INFO - 2023-04-17 03:42:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:42:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:42:09 --> Utf8 Class Initialized
INFO - 2023-04-17 03:42:09 --> URI Class Initialized
INFO - 2023-04-17 03:42:09 --> Router Class Initialized
INFO - 2023-04-17 03:42:09 --> Output Class Initialized
INFO - 2023-04-17 03:42:09 --> Security Class Initialized
DEBUG - 2023-04-17 03:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:42:09 --> Input Class Initialized
INFO - 2023-04-17 03:42:09 --> Language Class Initialized
INFO - 2023-04-17 03:42:09 --> Loader Class Initialized
INFO - 2023-04-17 03:42:09 --> Controller Class Initialized
DEBUG - 2023-04-17 03:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:42:09 --> Database Driver Class Initialized
INFO - 2023-04-17 03:42:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:42:09 --> Final output sent to browser
DEBUG - 2023-04-17 03:42:09 --> Total execution time: 0.0567
INFO - 2023-04-17 03:42:14 --> Config Class Initialized
INFO - 2023-04-17 03:42:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:42:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:42:14 --> Utf8 Class Initialized
INFO - 2023-04-17 03:42:14 --> URI Class Initialized
INFO - 2023-04-17 03:42:14 --> Router Class Initialized
INFO - 2023-04-17 03:42:14 --> Output Class Initialized
INFO - 2023-04-17 03:42:14 --> Security Class Initialized
DEBUG - 2023-04-17 03:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:42:14 --> Input Class Initialized
INFO - 2023-04-17 03:42:14 --> Language Class Initialized
INFO - 2023-04-17 03:42:14 --> Loader Class Initialized
INFO - 2023-04-17 03:42:14 --> Controller Class Initialized
DEBUG - 2023-04-17 03:42:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:42:14 --> Database Driver Class Initialized
INFO - 2023-04-17 03:42:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:42:14 --> Final output sent to browser
DEBUG - 2023-04-17 03:42:14 --> Total execution time: 0.0159
INFO - 2023-04-17 03:42:14 --> Config Class Initialized
INFO - 2023-04-17 03:42:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:42:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:42:14 --> Utf8 Class Initialized
INFO - 2023-04-17 03:42:14 --> URI Class Initialized
INFO - 2023-04-17 03:42:14 --> Router Class Initialized
INFO - 2023-04-17 03:42:14 --> Output Class Initialized
INFO - 2023-04-17 03:42:14 --> Security Class Initialized
DEBUG - 2023-04-17 03:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:42:14 --> Input Class Initialized
INFO - 2023-04-17 03:42:14 --> Language Class Initialized
INFO - 2023-04-17 03:42:14 --> Loader Class Initialized
INFO - 2023-04-17 03:42:14 --> Controller Class Initialized
DEBUG - 2023-04-17 03:42:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:42:14 --> Database Driver Class Initialized
INFO - 2023-04-17 03:42:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:42:14 --> Final output sent to browser
DEBUG - 2023-04-17 03:42:14 --> Total execution time: 0.0132
INFO - 2023-04-17 03:42:19 --> Config Class Initialized
INFO - 2023-04-17 03:42:19 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:42:19 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:42:19 --> Utf8 Class Initialized
INFO - 2023-04-17 03:42:19 --> URI Class Initialized
INFO - 2023-04-17 03:42:19 --> Router Class Initialized
INFO - 2023-04-17 03:42:19 --> Output Class Initialized
INFO - 2023-04-17 03:42:19 --> Security Class Initialized
DEBUG - 2023-04-17 03:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:42:19 --> Input Class Initialized
INFO - 2023-04-17 03:42:19 --> Language Class Initialized
INFO - 2023-04-17 03:42:19 --> Loader Class Initialized
INFO - 2023-04-17 03:42:19 --> Controller Class Initialized
DEBUG - 2023-04-17 03:42:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:42:19 --> Database Driver Class Initialized
INFO - 2023-04-17 03:42:19 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:42:19 --> Final output sent to browser
DEBUG - 2023-04-17 03:42:19 --> Total execution time: 0.0437
INFO - 2023-04-17 03:42:24 --> Config Class Initialized
INFO - 2023-04-17 03:42:24 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:42:24 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:42:24 --> Utf8 Class Initialized
INFO - 2023-04-17 03:42:24 --> URI Class Initialized
INFO - 2023-04-17 03:42:24 --> Router Class Initialized
INFO - 2023-04-17 03:42:24 --> Output Class Initialized
INFO - 2023-04-17 03:42:24 --> Security Class Initialized
DEBUG - 2023-04-17 03:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:42:24 --> Input Class Initialized
INFO - 2023-04-17 03:42:24 --> Language Class Initialized
INFO - 2023-04-17 03:42:24 --> Loader Class Initialized
INFO - 2023-04-17 03:42:24 --> Controller Class Initialized
DEBUG - 2023-04-17 03:42:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:42:24 --> Database Driver Class Initialized
INFO - 2023-04-17 03:42:24 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:42:24 --> Final output sent to browser
DEBUG - 2023-04-17 03:42:24 --> Total execution time: 0.0124
INFO - 2023-04-17 03:42:24 --> Config Class Initialized
INFO - 2023-04-17 03:42:24 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:42:24 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:42:24 --> Utf8 Class Initialized
INFO - 2023-04-17 03:42:24 --> URI Class Initialized
INFO - 2023-04-17 03:42:24 --> Router Class Initialized
INFO - 2023-04-17 03:42:24 --> Output Class Initialized
INFO - 2023-04-17 03:42:24 --> Security Class Initialized
DEBUG - 2023-04-17 03:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:42:24 --> Input Class Initialized
INFO - 2023-04-17 03:42:24 --> Language Class Initialized
INFO - 2023-04-17 03:42:24 --> Loader Class Initialized
INFO - 2023-04-17 03:42:24 --> Controller Class Initialized
DEBUG - 2023-04-17 03:42:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:42:24 --> Database Driver Class Initialized
INFO - 2023-04-17 03:42:24 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:42:24 --> Final output sent to browser
DEBUG - 2023-04-17 03:42:24 --> Total execution time: 0.0132
INFO - 2023-04-17 03:42:29 --> Config Class Initialized
INFO - 2023-04-17 03:42:29 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:42:29 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:42:29 --> Utf8 Class Initialized
INFO - 2023-04-17 03:42:29 --> URI Class Initialized
INFO - 2023-04-17 03:42:29 --> Router Class Initialized
INFO - 2023-04-17 03:42:29 --> Output Class Initialized
INFO - 2023-04-17 03:42:29 --> Security Class Initialized
DEBUG - 2023-04-17 03:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:42:29 --> Input Class Initialized
INFO - 2023-04-17 03:42:29 --> Language Class Initialized
INFO - 2023-04-17 03:42:29 --> Loader Class Initialized
INFO - 2023-04-17 03:42:29 --> Controller Class Initialized
DEBUG - 2023-04-17 03:42:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:42:29 --> Database Driver Class Initialized
INFO - 2023-04-17 03:42:29 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:42:29 --> Final output sent to browser
DEBUG - 2023-04-17 03:42:29 --> Total execution time: 0.0155
INFO - 2023-04-17 03:42:32 --> Config Class Initialized
INFO - 2023-04-17 03:42:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:42:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:42:32 --> Utf8 Class Initialized
INFO - 2023-04-17 03:42:32 --> URI Class Initialized
INFO - 2023-04-17 03:42:32 --> Router Class Initialized
INFO - 2023-04-17 03:42:32 --> Output Class Initialized
INFO - 2023-04-17 03:42:32 --> Security Class Initialized
DEBUG - 2023-04-17 03:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:42:32 --> Input Class Initialized
INFO - 2023-04-17 03:42:32 --> Language Class Initialized
INFO - 2023-04-17 03:42:32 --> Loader Class Initialized
INFO - 2023-04-17 03:42:32 --> Controller Class Initialized
DEBUG - 2023-04-17 03:42:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:42:32 --> Database Driver Class Initialized
INFO - 2023-04-17 03:42:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:42:32 --> Database Driver Class Initialized
INFO - 2023-04-17 03:42:32 --> Model "Login_model" initialized
INFO - 2023-04-17 03:42:32 --> Final output sent to browser
DEBUG - 2023-04-17 03:42:32 --> Total execution time: 0.0374
INFO - 2023-04-17 03:42:32 --> Config Class Initialized
INFO - 2023-04-17 03:42:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:42:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:42:32 --> Utf8 Class Initialized
INFO - 2023-04-17 03:42:32 --> URI Class Initialized
INFO - 2023-04-17 03:42:32 --> Router Class Initialized
INFO - 2023-04-17 03:42:32 --> Output Class Initialized
INFO - 2023-04-17 03:42:32 --> Security Class Initialized
DEBUG - 2023-04-17 03:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:42:32 --> Input Class Initialized
INFO - 2023-04-17 03:42:32 --> Language Class Initialized
INFO - 2023-04-17 03:42:32 --> Loader Class Initialized
INFO - 2023-04-17 03:42:32 --> Controller Class Initialized
DEBUG - 2023-04-17 03:42:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:42:32 --> Database Driver Class Initialized
INFO - 2023-04-17 03:42:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:42:32 --> Database Driver Class Initialized
INFO - 2023-04-17 03:42:32 --> Model "Login_model" initialized
INFO - 2023-04-17 03:42:32 --> Final output sent to browser
DEBUG - 2023-04-17 03:42:32 --> Total execution time: 0.0322
INFO - 2023-04-17 03:50:15 --> Config Class Initialized
INFO - 2023-04-17 03:50:15 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:50:16 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:16 --> Utf8 Class Initialized
INFO - 2023-04-17 03:50:16 --> URI Class Initialized
INFO - 2023-04-17 03:50:16 --> Router Class Initialized
INFO - 2023-04-17 03:50:16 --> Output Class Initialized
INFO - 2023-04-17 03:50:16 --> Security Class Initialized
DEBUG - 2023-04-17 03:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:16 --> Input Class Initialized
INFO - 2023-04-17 03:50:16 --> Language Class Initialized
INFO - 2023-04-17 03:50:16 --> Loader Class Initialized
INFO - 2023-04-17 03:50:16 --> Controller Class Initialized
DEBUG - 2023-04-17 03:50:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:50:16 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:16 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:50:16 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:16 --> Model "Login_model" initialized
INFO - 2023-04-17 03:50:16 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:16 --> Total execution time: 0.1197
INFO - 2023-04-17 03:50:16 --> Config Class Initialized
INFO - 2023-04-17 03:50:16 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:50:16 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:16 --> Utf8 Class Initialized
INFO - 2023-04-17 03:50:16 --> URI Class Initialized
INFO - 2023-04-17 03:50:16 --> Router Class Initialized
INFO - 2023-04-17 03:50:16 --> Output Class Initialized
INFO - 2023-04-17 03:50:16 --> Security Class Initialized
DEBUG - 2023-04-17 03:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:16 --> Input Class Initialized
INFO - 2023-04-17 03:50:16 --> Language Class Initialized
INFO - 2023-04-17 03:50:16 --> Loader Class Initialized
INFO - 2023-04-17 03:50:16 --> Controller Class Initialized
DEBUG - 2023-04-17 03:50:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:50:16 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:16 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:50:16 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:16 --> Model "Login_model" initialized
INFO - 2023-04-17 03:50:16 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:16 --> Total execution time: 0.0791
INFO - 2023-04-17 03:50:23 --> Config Class Initialized
INFO - 2023-04-17 03:50:23 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:50:23 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:23 --> Utf8 Class Initialized
INFO - 2023-04-17 03:50:23 --> URI Class Initialized
INFO - 2023-04-17 03:50:23 --> Router Class Initialized
INFO - 2023-04-17 03:50:23 --> Output Class Initialized
INFO - 2023-04-17 03:50:23 --> Security Class Initialized
DEBUG - 2023-04-17 03:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:23 --> Input Class Initialized
INFO - 2023-04-17 03:50:23 --> Language Class Initialized
INFO - 2023-04-17 03:50:23 --> Loader Class Initialized
INFO - 2023-04-17 03:50:23 --> Controller Class Initialized
DEBUG - 2023-04-17 03:50:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:50:23 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:23 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:50:23 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:23 --> Total execution time: 0.0147
INFO - 2023-04-17 03:50:23 --> Config Class Initialized
INFO - 2023-04-17 03:50:23 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:50:23 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:23 --> Utf8 Class Initialized
INFO - 2023-04-17 03:50:23 --> URI Class Initialized
INFO - 2023-04-17 03:50:23 --> Router Class Initialized
INFO - 2023-04-17 03:50:23 --> Output Class Initialized
INFO - 2023-04-17 03:50:23 --> Security Class Initialized
DEBUG - 2023-04-17 03:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:23 --> Input Class Initialized
INFO - 2023-04-17 03:50:23 --> Language Class Initialized
INFO - 2023-04-17 03:50:23 --> Loader Class Initialized
INFO - 2023-04-17 03:50:23 --> Controller Class Initialized
DEBUG - 2023-04-17 03:50:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:50:23 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:23 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:50:23 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:23 --> Total execution time: 0.0136
INFO - 2023-04-17 03:50:28 --> Config Class Initialized
INFO - 2023-04-17 03:50:28 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:50:28 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:28 --> Utf8 Class Initialized
INFO - 2023-04-17 03:50:28 --> URI Class Initialized
INFO - 2023-04-17 03:50:28 --> Router Class Initialized
INFO - 2023-04-17 03:50:28 --> Output Class Initialized
INFO - 2023-04-17 03:50:28 --> Security Class Initialized
DEBUG - 2023-04-17 03:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:28 --> Input Class Initialized
INFO - 2023-04-17 03:50:28 --> Language Class Initialized
INFO - 2023-04-17 03:50:28 --> Loader Class Initialized
INFO - 2023-04-17 03:50:28 --> Controller Class Initialized
DEBUG - 2023-04-17 03:50:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:50:28 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:28 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:50:28 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:28 --> Total execution time: 0.0165
INFO - 2023-04-17 03:50:28 --> Config Class Initialized
INFO - 2023-04-17 03:50:28 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:50:28 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:28 --> Utf8 Class Initialized
INFO - 2023-04-17 03:50:28 --> URI Class Initialized
INFO - 2023-04-17 03:50:28 --> Router Class Initialized
INFO - 2023-04-17 03:50:28 --> Output Class Initialized
INFO - 2023-04-17 03:50:28 --> Security Class Initialized
DEBUG - 2023-04-17 03:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:28 --> Input Class Initialized
INFO - 2023-04-17 03:50:28 --> Language Class Initialized
INFO - 2023-04-17 03:50:28 --> Loader Class Initialized
INFO - 2023-04-17 03:50:28 --> Controller Class Initialized
DEBUG - 2023-04-17 03:50:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:50:28 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:28 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:50:28 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:28 --> Total execution time: 0.0563
INFO - 2023-04-17 03:50:31 --> Config Class Initialized
INFO - 2023-04-17 03:50:31 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:50:31 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:31 --> Utf8 Class Initialized
INFO - 2023-04-17 03:50:31 --> URI Class Initialized
INFO - 2023-04-17 03:50:31 --> Router Class Initialized
INFO - 2023-04-17 03:50:31 --> Output Class Initialized
INFO - 2023-04-17 03:50:31 --> Security Class Initialized
DEBUG - 2023-04-17 03:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:31 --> Input Class Initialized
INFO - 2023-04-17 03:50:31 --> Language Class Initialized
INFO - 2023-04-17 03:50:31 --> Loader Class Initialized
INFO - 2023-04-17 03:50:31 --> Controller Class Initialized
DEBUG - 2023-04-17 03:50:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:50:31 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:31 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:50:31 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:31 --> Total execution time: 0.0273
INFO - 2023-04-17 03:50:31 --> Config Class Initialized
INFO - 2023-04-17 03:50:31 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:50:31 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:31 --> Utf8 Class Initialized
INFO - 2023-04-17 03:50:31 --> URI Class Initialized
INFO - 2023-04-17 03:50:31 --> Router Class Initialized
INFO - 2023-04-17 03:50:31 --> Output Class Initialized
INFO - 2023-04-17 03:50:31 --> Security Class Initialized
DEBUG - 2023-04-17 03:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:31 --> Input Class Initialized
INFO - 2023-04-17 03:50:31 --> Language Class Initialized
INFO - 2023-04-17 03:50:31 --> Loader Class Initialized
INFO - 2023-04-17 03:50:31 --> Controller Class Initialized
DEBUG - 2023-04-17 03:50:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:50:31 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:31 --> Config Class Initialized
INFO - 2023-04-17 03:50:31 --> Hooks Class Initialized
INFO - 2023-04-17 03:50:31 --> Config Class Initialized
DEBUG - 2023-04-17 03:50:31 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:31 --> Hooks Class Initialized
INFO - 2023-04-17 03:50:31 --> Utf8 Class Initialized
DEBUG - 2023-04-17 03:50:31 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:31 --> URI Class Initialized
INFO - 2023-04-17 03:50:31 --> Utf8 Class Initialized
INFO - 2023-04-17 03:50:31 --> Router Class Initialized
INFO - 2023-04-17 03:50:31 --> URI Class Initialized
INFO - 2023-04-17 03:50:31 --> Output Class Initialized
INFO - 2023-04-17 03:50:31 --> Router Class Initialized
INFO - 2023-04-17 03:50:31 --> Security Class Initialized
INFO - 2023-04-17 03:50:31 --> Output Class Initialized
DEBUG - 2023-04-17 03:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:31 --> Security Class Initialized
INFO - 2023-04-17 03:50:31 --> Input Class Initialized
DEBUG - 2023-04-17 03:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:31 --> Language Class Initialized
INFO - 2023-04-17 03:50:31 --> Input Class Initialized
INFO - 2023-04-17 03:50:31 --> Language Class Initialized
INFO - 2023-04-17 03:50:31 --> Loader Class Initialized
INFO - 2023-04-17 03:50:31 --> Loader Class Initialized
INFO - 2023-04-17 03:50:31 --> Controller Class Initialized
INFO - 2023-04-17 03:50:31 --> Controller Class Initialized
DEBUG - 2023-04-17 03:50:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 03:50:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:50:31 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:31 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:31 --> Total execution time: 0.0027
INFO - 2023-04-17 03:50:31 --> Config Class Initialized
INFO - 2023-04-17 03:50:31 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:50:31 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:50:31 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:50:31 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:31 --> Utf8 Class Initialized
INFO - 2023-04-17 03:50:31 --> URI Class Initialized
INFO - 2023-04-17 03:50:31 --> Router Class Initialized
INFO - 2023-04-17 03:50:31 --> Output Class Initialized
INFO - 2023-04-17 03:50:31 --> Security Class Initialized
DEBUG - 2023-04-17 03:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:31 --> Input Class Initialized
INFO - 2023-04-17 03:50:31 --> Language Class Initialized
INFO - 2023-04-17 03:50:31 --> Loader Class Initialized
INFO - 2023-04-17 03:50:31 --> Controller Class Initialized
DEBUG - 2023-04-17 03:50:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:50:31 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:31 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:31 --> Total execution time: 0.0371
INFO - 2023-04-17 03:50:31 --> Config Class Initialized
INFO - 2023-04-17 03:50:31 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:50:31 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:31 --> Utf8 Class Initialized
INFO - 2023-04-17 03:50:31 --> URI Class Initialized
INFO - 2023-04-17 03:50:31 --> Router Class Initialized
INFO - 2023-04-17 03:50:31 --> Output Class Initialized
INFO - 2023-04-17 03:50:31 --> Security Class Initialized
DEBUG - 2023-04-17 03:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:31 --> Input Class Initialized
INFO - 2023-04-17 03:50:31 --> Language Class Initialized
INFO - 2023-04-17 03:50:31 --> Loader Class Initialized
INFO - 2023-04-17 03:50:31 --> Controller Class Initialized
DEBUG - 2023-04-17 03:50:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:50:31 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:31 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:31 --> Total execution time: 0.0935
INFO - 2023-04-17 03:50:31 --> Model "Login_model" initialized
INFO - 2023-04-17 03:50:31 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:50:31 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:31 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:31 --> Total execution time: 0.1323
INFO - 2023-04-17 03:50:31 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:50:31 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:31 --> Total execution time: 0.2202
INFO - 2023-04-17 03:50:44 --> Config Class Initialized
INFO - 2023-04-17 03:50:44 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:50:44 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:44 --> Utf8 Class Initialized
INFO - 2023-04-17 03:50:44 --> URI Class Initialized
INFO - 2023-04-17 03:50:44 --> Router Class Initialized
INFO - 2023-04-17 03:50:44 --> Output Class Initialized
INFO - 2023-04-17 03:50:44 --> Security Class Initialized
DEBUG - 2023-04-17 03:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:44 --> Input Class Initialized
INFO - 2023-04-17 03:50:44 --> Language Class Initialized
INFO - 2023-04-17 03:50:44 --> Loader Class Initialized
INFO - 2023-04-17 03:50:44 --> Controller Class Initialized
DEBUG - 2023-04-17 03:50:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:50:44 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:44 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:50:45 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:45 --> Total execution time: 0.1414
INFO - 2023-04-17 03:50:45 --> Config Class Initialized
INFO - 2023-04-17 03:50:45 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:50:45 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:50:45 --> Utf8 Class Initialized
INFO - 2023-04-17 03:50:45 --> URI Class Initialized
INFO - 2023-04-17 03:50:45 --> Router Class Initialized
INFO - 2023-04-17 03:50:45 --> Output Class Initialized
INFO - 2023-04-17 03:50:45 --> Security Class Initialized
DEBUG - 2023-04-17 03:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:50:45 --> Input Class Initialized
INFO - 2023-04-17 03:50:45 --> Language Class Initialized
INFO - 2023-04-17 03:50:45 --> Loader Class Initialized
INFO - 2023-04-17 03:50:45 --> Controller Class Initialized
DEBUG - 2023-04-17 03:50:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:50:45 --> Database Driver Class Initialized
INFO - 2023-04-17 03:50:45 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:50:45 --> Final output sent to browser
DEBUG - 2023-04-17 03:50:45 --> Total execution time: 0.0146
INFO - 2023-04-17 03:53:32 --> Config Class Initialized
INFO - 2023-04-17 03:53:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:53:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:53:32 --> Utf8 Class Initialized
INFO - 2023-04-17 03:53:32 --> URI Class Initialized
INFO - 2023-04-17 03:53:32 --> Router Class Initialized
INFO - 2023-04-17 03:53:32 --> Output Class Initialized
INFO - 2023-04-17 03:53:32 --> Security Class Initialized
DEBUG - 2023-04-17 03:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:53:32 --> Input Class Initialized
INFO - 2023-04-17 03:53:32 --> Language Class Initialized
INFO - 2023-04-17 03:53:32 --> Loader Class Initialized
INFO - 2023-04-17 03:53:32 --> Controller Class Initialized
DEBUG - 2023-04-17 03:53:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:53:32 --> Database Driver Class Initialized
INFO - 2023-04-17 03:53:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:53:32 --> Database Driver Class Initialized
INFO - 2023-04-17 03:53:32 --> Model "Login_model" initialized
INFO - 2023-04-17 03:53:32 --> Final output sent to browser
DEBUG - 2023-04-17 03:53:32 --> Total execution time: 0.0467
INFO - 2023-04-17 03:53:32 --> Config Class Initialized
INFO - 2023-04-17 03:53:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:53:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:53:32 --> Utf8 Class Initialized
INFO - 2023-04-17 03:53:32 --> URI Class Initialized
INFO - 2023-04-17 03:53:32 --> Router Class Initialized
INFO - 2023-04-17 03:53:32 --> Output Class Initialized
INFO - 2023-04-17 03:53:32 --> Security Class Initialized
DEBUG - 2023-04-17 03:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:53:32 --> Input Class Initialized
INFO - 2023-04-17 03:53:32 --> Language Class Initialized
INFO - 2023-04-17 03:53:32 --> Loader Class Initialized
INFO - 2023-04-17 03:53:32 --> Controller Class Initialized
DEBUG - 2023-04-17 03:53:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:53:32 --> Database Driver Class Initialized
INFO - 2023-04-17 03:53:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:53:32 --> Database Driver Class Initialized
INFO - 2023-04-17 03:53:32 --> Model "Login_model" initialized
INFO - 2023-04-17 03:53:32 --> Final output sent to browser
DEBUG - 2023-04-17 03:53:32 --> Total execution time: 0.0388
INFO - 2023-04-17 03:56:24 --> Config Class Initialized
INFO - 2023-04-17 03:56:24 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:56:24 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:56:24 --> Utf8 Class Initialized
INFO - 2023-04-17 03:56:24 --> URI Class Initialized
INFO - 2023-04-17 03:56:24 --> Router Class Initialized
INFO - 2023-04-17 03:56:24 --> Output Class Initialized
INFO - 2023-04-17 03:56:24 --> Security Class Initialized
DEBUG - 2023-04-17 03:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:56:24 --> Input Class Initialized
INFO - 2023-04-17 03:56:24 --> Language Class Initialized
INFO - 2023-04-17 03:56:24 --> Loader Class Initialized
INFO - 2023-04-17 03:56:24 --> Controller Class Initialized
DEBUG - 2023-04-17 03:56:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:56:24 --> Database Driver Class Initialized
INFO - 2023-04-17 03:56:24 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:56:24 --> Final output sent to browser
DEBUG - 2023-04-17 03:56:24 --> Total execution time: 0.0177
INFO - 2023-04-17 03:56:24 --> Config Class Initialized
INFO - 2023-04-17 03:56:24 --> Hooks Class Initialized
DEBUG - 2023-04-17 03:56:24 --> UTF-8 Support Enabled
INFO - 2023-04-17 03:56:24 --> Utf8 Class Initialized
INFO - 2023-04-17 03:56:24 --> URI Class Initialized
INFO - 2023-04-17 03:56:24 --> Router Class Initialized
INFO - 2023-04-17 03:56:24 --> Output Class Initialized
INFO - 2023-04-17 03:56:24 --> Security Class Initialized
DEBUG - 2023-04-17 03:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 03:56:24 --> Input Class Initialized
INFO - 2023-04-17 03:56:24 --> Language Class Initialized
INFO - 2023-04-17 03:56:24 --> Loader Class Initialized
INFO - 2023-04-17 03:56:24 --> Controller Class Initialized
DEBUG - 2023-04-17 03:56:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 03:56:24 --> Database Driver Class Initialized
INFO - 2023-04-17 03:56:24 --> Model "Cluster_model" initialized
INFO - 2023-04-17 03:56:24 --> Final output sent to browser
DEBUG - 2023-04-17 03:56:24 --> Total execution time: 0.0115
INFO - 2023-04-17 04:40:20 --> Config Class Initialized
INFO - 2023-04-17 04:40:20 --> Hooks Class Initialized
DEBUG - 2023-04-17 04:40:20 --> UTF-8 Support Enabled
INFO - 2023-04-17 04:40:20 --> Utf8 Class Initialized
INFO - 2023-04-17 04:40:20 --> URI Class Initialized
INFO - 2023-04-17 04:40:20 --> Router Class Initialized
INFO - 2023-04-17 04:40:20 --> Output Class Initialized
INFO - 2023-04-17 04:40:20 --> Security Class Initialized
DEBUG - 2023-04-17 04:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 04:40:20 --> Input Class Initialized
INFO - 2023-04-17 04:40:20 --> Language Class Initialized
INFO - 2023-04-17 04:40:20 --> Loader Class Initialized
INFO - 2023-04-17 04:40:20 --> Controller Class Initialized
DEBUG - 2023-04-17 04:40:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 04:40:20 --> Database Driver Class Initialized
INFO - 2023-04-17 04:40:20 --> Model "Cluster_model" initialized
INFO - 2023-04-17 04:40:20 --> Final output sent to browser
DEBUG - 2023-04-17 04:40:20 --> Total execution time: 0.0243
INFO - 2023-04-17 04:40:20 --> Config Class Initialized
INFO - 2023-04-17 04:40:20 --> Hooks Class Initialized
DEBUG - 2023-04-17 04:40:20 --> UTF-8 Support Enabled
INFO - 2023-04-17 04:40:20 --> Utf8 Class Initialized
INFO - 2023-04-17 04:40:20 --> URI Class Initialized
INFO - 2023-04-17 04:40:20 --> Router Class Initialized
INFO - 2023-04-17 04:40:20 --> Output Class Initialized
INFO - 2023-04-17 04:40:20 --> Security Class Initialized
DEBUG - 2023-04-17 04:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 04:40:20 --> Input Class Initialized
INFO - 2023-04-17 04:40:20 --> Language Class Initialized
INFO - 2023-04-17 04:40:20 --> Loader Class Initialized
INFO - 2023-04-17 04:40:20 --> Controller Class Initialized
DEBUG - 2023-04-17 04:40:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 04:40:20 --> Database Driver Class Initialized
INFO - 2023-04-17 04:40:20 --> Model "Cluster_model" initialized
INFO - 2023-04-17 04:40:20 --> Final output sent to browser
DEBUG - 2023-04-17 04:40:20 --> Total execution time: 0.0198
INFO - 2023-04-17 04:41:04 --> Config Class Initialized
INFO - 2023-04-17 04:41:04 --> Config Class Initialized
INFO - 2023-04-17 04:41:04 --> Config Class Initialized
INFO - 2023-04-17 04:41:04 --> Hooks Class Initialized
INFO - 2023-04-17 04:41:04 --> Hooks Class Initialized
INFO - 2023-04-17 04:41:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 04:41:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 04:41:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 04:41:04 --> Utf8 Class Initialized
INFO - 2023-04-17 04:41:04 --> Utf8 Class Initialized
DEBUG - 2023-04-17 04:41:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 04:41:04 --> URI Class Initialized
INFO - 2023-04-17 04:41:04 --> Utf8 Class Initialized
INFO - 2023-04-17 04:41:04 --> URI Class Initialized
INFO - 2023-04-17 04:41:04 --> Router Class Initialized
INFO - 2023-04-17 04:41:04 --> URI Class Initialized
INFO - 2023-04-17 04:41:04 --> Router Class Initialized
INFO - 2023-04-17 04:41:04 --> Output Class Initialized
INFO - 2023-04-17 04:41:04 --> Security Class Initialized
INFO - 2023-04-17 04:41:04 --> Output Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 04:41:04 --> Router Class Initialized
INFO - 2023-04-17 04:41:04 --> Input Class Initialized
INFO - 2023-04-17 04:41:04 --> Output Class Initialized
INFO - 2023-04-17 04:41:04 --> Security Class Initialized
INFO - 2023-04-17 04:41:04 --> Language Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 04:41:04 --> Security Class Initialized
INFO - 2023-04-17 04:41:04 --> Input Class Initialized
INFO - 2023-04-17 04:41:04 --> Loader Class Initialized
INFO - 2023-04-17 04:41:04 --> Language Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 04:41:04 --> Controller Class Initialized
INFO - 2023-04-17 04:41:04 --> Input Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 04:41:04 --> Language Class Initialized
INFO - 2023-04-17 04:41:04 --> Loader Class Initialized
INFO - 2023-04-17 04:41:04 --> Controller Class Initialized
INFO - 2023-04-17 04:41:04 --> Database Driver Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 04:41:04 --> Loader Class Initialized
INFO - 2023-04-17 04:41:04 --> Database Driver Class Initialized
INFO - 2023-04-17 04:41:04 --> Controller Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 04:41:04 --> Database Driver Class Initialized
INFO - 2023-04-17 04:41:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 04:41:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 04:41:04 --> Database Driver Class Initialized
INFO - 2023-04-17 04:41:04 --> Model "Login_model" initialized
INFO - 2023-04-17 04:41:04 --> Final output sent to browser
DEBUG - 2023-04-17 04:41:04 --> Total execution time: 0.0275
INFO - 2023-04-17 04:41:04 --> Config Class Initialized
INFO - 2023-04-17 04:41:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 04:41:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 04:41:04 --> Utf8 Class Initialized
INFO - 2023-04-17 04:41:04 --> URI Class Initialized
INFO - 2023-04-17 04:41:04 --> Router Class Initialized
INFO - 2023-04-17 04:41:04 --> Output Class Initialized
INFO - 2023-04-17 04:41:04 --> Security Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 04:41:04 --> Input Class Initialized
INFO - 2023-04-17 04:41:04 --> Language Class Initialized
INFO - 2023-04-17 04:41:04 --> Loader Class Initialized
INFO - 2023-04-17 04:41:04 --> Controller Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 04:41:04 --> Database Driver Class Initialized
INFO - 2023-04-17 04:41:04 --> Final output sent to browser
DEBUG - 2023-04-17 04:41:04 --> Total execution time: 0.0340
INFO - 2023-04-17 04:41:04 --> Final output sent to browser
DEBUG - 2023-04-17 04:41:04 --> Total execution time: 0.0337
INFO - 2023-04-17 04:41:04 --> Config Class Initialized
INFO - 2023-04-17 04:41:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 04:41:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 04:41:04 --> Utf8 Class Initialized
INFO - 2023-04-17 04:41:04 --> URI Class Initialized
INFO - 2023-04-17 04:41:04 --> Router Class Initialized
INFO - 2023-04-17 04:41:04 --> Output Class Initialized
INFO - 2023-04-17 04:41:04 --> Config Class Initialized
INFO - 2023-04-17 04:41:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 04:41:04 --> Hooks Class Initialized
INFO - 2023-04-17 04:41:04 --> Security Class Initialized
DEBUG - 2023-04-17 04:41:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 04:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 04:41:04 --> Utf8 Class Initialized
INFO - 2023-04-17 04:41:04 --> Input Class Initialized
INFO - 2023-04-17 04:41:04 --> Language Class Initialized
INFO - 2023-04-17 04:41:04 --> URI Class Initialized
INFO - 2023-04-17 04:41:04 --> Loader Class Initialized
INFO - 2023-04-17 04:41:04 --> Router Class Initialized
INFO - 2023-04-17 04:41:04 --> Controller Class Initialized
INFO - 2023-04-17 04:41:04 --> Output Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 04:41:04 --> Security Class Initialized
INFO - 2023-04-17 04:41:04 --> Database Driver Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 04:41:04 --> Input Class Initialized
INFO - 2023-04-17 04:41:04 --> Language Class Initialized
INFO - 2023-04-17 04:41:04 --> Loader Class Initialized
INFO - 2023-04-17 04:41:04 --> Controller Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 04:41:04 --> Database Driver Class Initialized
INFO - 2023-04-17 04:41:04 --> Database Driver Class Initialized
INFO - 2023-04-17 04:41:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 04:41:04 --> Final output sent to browser
DEBUG - 2023-04-17 04:41:04 --> Total execution time: 0.0633
INFO - 2023-04-17 04:41:04 --> Config Class Initialized
INFO - 2023-04-17 04:41:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 04:41:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 04:41:04 --> Utf8 Class Initialized
INFO - 2023-04-17 04:41:04 --> URI Class Initialized
INFO - 2023-04-17 04:41:04 --> Router Class Initialized
INFO - 2023-04-17 04:41:04 --> Output Class Initialized
INFO - 2023-04-17 04:41:04 --> Security Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 04:41:04 --> Input Class Initialized
INFO - 2023-04-17 04:41:04 --> Language Class Initialized
INFO - 2023-04-17 04:41:04 --> Loader Class Initialized
INFO - 2023-04-17 04:41:04 --> Controller Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 04:41:04 --> Database Driver Class Initialized
INFO - 2023-04-17 04:41:04 --> Model "Login_model" initialized
INFO - 2023-04-17 04:41:04 --> Final output sent to browser
DEBUG - 2023-04-17 04:41:04 --> Total execution time: 0.0653
INFO - 2023-04-17 04:41:04 --> Config Class Initialized
INFO - 2023-04-17 04:41:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 04:41:04 --> Final output sent to browser
DEBUG - 2023-04-17 04:41:04 --> Total execution time: 0.0680
INFO - 2023-04-17 04:41:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 04:41:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 04:41:04 --> Utf8 Class Initialized
INFO - 2023-04-17 04:41:04 --> URI Class Initialized
INFO - 2023-04-17 04:41:04 --> Final output sent to browser
DEBUG - 2023-04-17 04:41:04 --> Total execution time: 0.0634
INFO - 2023-04-17 04:41:04 --> Router Class Initialized
INFO - 2023-04-17 04:41:04 --> Output Class Initialized
INFO - 2023-04-17 04:41:04 --> Security Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 04:41:04 --> Input Class Initialized
INFO - 2023-04-17 04:41:04 --> Language Class Initialized
INFO - 2023-04-17 04:41:04 --> Loader Class Initialized
INFO - 2023-04-17 04:41:04 --> Controller Class Initialized
DEBUG - 2023-04-17 04:41:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 04:41:04 --> Database Driver Class Initialized
INFO - 2023-04-17 04:41:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 04:41:04 --> Final output sent to browser
DEBUG - 2023-04-17 04:41:04 --> Total execution time: 0.1504
INFO - 2023-04-17 04:41:06 --> Config Class Initialized
INFO - 2023-04-17 04:41:06 --> Hooks Class Initialized
DEBUG - 2023-04-17 04:41:06 --> UTF-8 Support Enabled
INFO - 2023-04-17 04:41:06 --> Utf8 Class Initialized
INFO - 2023-04-17 04:41:06 --> URI Class Initialized
INFO - 2023-04-17 04:41:06 --> Router Class Initialized
INFO - 2023-04-17 04:41:06 --> Output Class Initialized
INFO - 2023-04-17 04:41:06 --> Security Class Initialized
DEBUG - 2023-04-17 04:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 04:41:06 --> Input Class Initialized
INFO - 2023-04-17 04:41:06 --> Language Class Initialized
INFO - 2023-04-17 04:41:06 --> Loader Class Initialized
INFO - 2023-04-17 04:41:06 --> Controller Class Initialized
DEBUG - 2023-04-17 04:41:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 04:41:06 --> Database Driver Class Initialized
INFO - 2023-04-17 04:41:06 --> Model "Cluster_model" initialized
INFO - 2023-04-17 04:41:06 --> Database Driver Class Initialized
INFO - 2023-04-17 04:41:06 --> Model "Login_model" initialized
INFO - 2023-04-17 04:41:06 --> Final output sent to browser
DEBUG - 2023-04-17 04:41:06 --> Total execution time: 0.0588
INFO - 2023-04-17 04:41:06 --> Config Class Initialized
INFO - 2023-04-17 04:41:06 --> Hooks Class Initialized
DEBUG - 2023-04-17 04:41:06 --> UTF-8 Support Enabled
INFO - 2023-04-17 04:41:06 --> Utf8 Class Initialized
INFO - 2023-04-17 04:41:06 --> URI Class Initialized
INFO - 2023-04-17 04:41:06 --> Router Class Initialized
INFO - 2023-04-17 04:41:06 --> Output Class Initialized
INFO - 2023-04-17 04:41:06 --> Security Class Initialized
DEBUG - 2023-04-17 04:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 04:41:06 --> Input Class Initialized
INFO - 2023-04-17 04:41:06 --> Language Class Initialized
INFO - 2023-04-17 04:41:06 --> Loader Class Initialized
INFO - 2023-04-17 04:41:06 --> Controller Class Initialized
DEBUG - 2023-04-17 04:41:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 04:41:06 --> Database Driver Class Initialized
INFO - 2023-04-17 04:41:06 --> Model "Cluster_model" initialized
INFO - 2023-04-17 04:41:06 --> Database Driver Class Initialized
INFO - 2023-04-17 04:41:06 --> Model "Login_model" initialized
INFO - 2023-04-17 04:41:07 --> Final output sent to browser
DEBUG - 2023-04-17 04:41:07 --> Total execution time: 0.0353
INFO - 2023-04-17 05:39:11 --> Config Class Initialized
INFO - 2023-04-17 05:39:11 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:39:11 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:39:11 --> Utf8 Class Initialized
INFO - 2023-04-17 05:39:11 --> URI Class Initialized
INFO - 2023-04-17 05:39:11 --> Router Class Initialized
INFO - 2023-04-17 05:39:11 --> Output Class Initialized
INFO - 2023-04-17 05:39:11 --> Security Class Initialized
DEBUG - 2023-04-17 05:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:39:11 --> Input Class Initialized
INFO - 2023-04-17 05:39:11 --> Language Class Initialized
INFO - 2023-04-17 05:39:11 --> Loader Class Initialized
INFO - 2023-04-17 05:39:11 --> Controller Class Initialized
DEBUG - 2023-04-17 05:39:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:39:11 --> Database Driver Class Initialized
INFO - 2023-04-17 05:39:11 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:39:11 --> Final output sent to browser
DEBUG - 2023-04-17 05:39:11 --> Total execution time: 0.0235
INFO - 2023-04-17 05:39:11 --> Config Class Initialized
INFO - 2023-04-17 05:39:11 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:39:11 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:39:11 --> Utf8 Class Initialized
INFO - 2023-04-17 05:39:11 --> URI Class Initialized
INFO - 2023-04-17 05:39:11 --> Router Class Initialized
INFO - 2023-04-17 05:39:11 --> Output Class Initialized
INFO - 2023-04-17 05:39:11 --> Security Class Initialized
DEBUG - 2023-04-17 05:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:39:11 --> Input Class Initialized
INFO - 2023-04-17 05:39:11 --> Language Class Initialized
INFO - 2023-04-17 05:39:11 --> Loader Class Initialized
INFO - 2023-04-17 05:39:11 --> Controller Class Initialized
DEBUG - 2023-04-17 05:39:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:39:11 --> Database Driver Class Initialized
INFO - 2023-04-17 05:39:11 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:39:11 --> Final output sent to browser
DEBUG - 2023-04-17 05:39:11 --> Total execution time: 0.0235
INFO - 2023-04-17 05:39:13 --> Config Class Initialized
INFO - 2023-04-17 05:39:13 --> Config Class Initialized
INFO - 2023-04-17 05:39:13 --> Hooks Class Initialized
INFO - 2023-04-17 05:39:13 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:39:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 05:39:13 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:39:13 --> Utf8 Class Initialized
INFO - 2023-04-17 05:39:13 --> Utf8 Class Initialized
INFO - 2023-04-17 05:39:13 --> URI Class Initialized
INFO - 2023-04-17 05:39:13 --> URI Class Initialized
INFO - 2023-04-17 05:39:13 --> Router Class Initialized
INFO - 2023-04-17 05:39:13 --> Output Class Initialized
INFO - 2023-04-17 05:39:13 --> Router Class Initialized
INFO - 2023-04-17 05:39:13 --> Security Class Initialized
INFO - 2023-04-17 05:39:13 --> Output Class Initialized
DEBUG - 2023-04-17 05:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:39:13 --> Input Class Initialized
INFO - 2023-04-17 05:39:13 --> Security Class Initialized
INFO - 2023-04-17 05:39:13 --> Language Class Initialized
DEBUG - 2023-04-17 05:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:39:13 --> Input Class Initialized
INFO - 2023-04-17 05:39:13 --> Loader Class Initialized
INFO - 2023-04-17 05:39:13 --> Language Class Initialized
INFO - 2023-04-17 05:39:13 --> Controller Class Initialized
DEBUG - 2023-04-17 05:39:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:39:13 --> Loader Class Initialized
INFO - 2023-04-17 05:39:13 --> Controller Class Initialized
INFO - 2023-04-17 05:39:13 --> Database Driver Class Initialized
DEBUG - 2023-04-17 05:39:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:39:13 --> Final output sent to browser
DEBUG - 2023-04-17 05:39:13 --> Total execution time: 0.0056
INFO - 2023-04-17 05:39:13 --> Config Class Initialized
INFO - 2023-04-17 05:39:13 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:39:13 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:39:13 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:39:13 --> Utf8 Class Initialized
INFO - 2023-04-17 05:39:13 --> URI Class Initialized
INFO - 2023-04-17 05:39:13 --> Router Class Initialized
INFO - 2023-04-17 05:39:13 --> Output Class Initialized
INFO - 2023-04-17 05:39:13 --> Security Class Initialized
DEBUG - 2023-04-17 05:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:39:13 --> Input Class Initialized
INFO - 2023-04-17 05:39:13 --> Language Class Initialized
INFO - 2023-04-17 05:39:13 --> Loader Class Initialized
INFO - 2023-04-17 05:39:13 --> Controller Class Initialized
DEBUG - 2023-04-17 05:39:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:39:13 --> Database Driver Class Initialized
INFO - 2023-04-17 05:39:13 --> Final output sent to browser
DEBUG - 2023-04-17 05:39:13 --> Total execution time: 0.0551
INFO - 2023-04-17 05:39:13 --> Config Class Initialized
INFO - 2023-04-17 05:39:13 --> Hooks Class Initialized
INFO - 2023-04-17 05:39:13 --> Model "Login_model" initialized
DEBUG - 2023-04-17 05:39:13 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:39:13 --> Utf8 Class Initialized
INFO - 2023-04-17 05:39:13 --> URI Class Initialized
INFO - 2023-04-17 05:39:13 --> Router Class Initialized
INFO - 2023-04-17 05:39:13 --> Output Class Initialized
INFO - 2023-04-17 05:39:13 --> Security Class Initialized
DEBUG - 2023-04-17 05:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:39:13 --> Input Class Initialized
INFO - 2023-04-17 05:39:13 --> Language Class Initialized
INFO - 2023-04-17 05:39:13 --> Loader Class Initialized
INFO - 2023-04-17 05:39:13 --> Database Driver Class Initialized
INFO - 2023-04-17 05:39:13 --> Controller Class Initialized
DEBUG - 2023-04-17 05:39:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:39:13 --> Database Driver Class Initialized
INFO - 2023-04-17 05:39:13 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:39:13 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:39:13 --> Final output sent to browser
DEBUG - 2023-04-17 05:39:13 --> Total execution time: 0.0612
INFO - 2023-04-17 05:39:13 --> Final output sent to browser
DEBUG - 2023-04-17 05:39:13 --> Total execution time: 0.0137
INFO - 2023-04-17 05:39:16 --> Config Class Initialized
INFO - 2023-04-17 05:39:16 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:39:16 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:39:16 --> Utf8 Class Initialized
INFO - 2023-04-17 05:39:16 --> URI Class Initialized
INFO - 2023-04-17 05:39:16 --> Router Class Initialized
INFO - 2023-04-17 05:39:16 --> Output Class Initialized
INFO - 2023-04-17 05:39:16 --> Security Class Initialized
DEBUG - 2023-04-17 05:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:39:16 --> Input Class Initialized
INFO - 2023-04-17 05:39:16 --> Language Class Initialized
INFO - 2023-04-17 05:39:16 --> Loader Class Initialized
INFO - 2023-04-17 05:39:16 --> Controller Class Initialized
DEBUG - 2023-04-17 05:39:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:39:16 --> Database Driver Class Initialized
INFO - 2023-04-17 05:39:16 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:39:16 --> Final output sent to browser
DEBUG - 2023-04-17 05:39:16 --> Total execution time: 0.0613
INFO - 2023-04-17 05:39:19 --> Config Class Initialized
INFO - 2023-04-17 05:39:19 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:39:19 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:39:19 --> Utf8 Class Initialized
INFO - 2023-04-17 05:39:19 --> URI Class Initialized
INFO - 2023-04-17 05:39:19 --> Router Class Initialized
INFO - 2023-04-17 05:39:19 --> Output Class Initialized
INFO - 2023-04-17 05:39:19 --> Security Class Initialized
DEBUG - 2023-04-17 05:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:39:19 --> Input Class Initialized
INFO - 2023-04-17 05:39:19 --> Language Class Initialized
INFO - 2023-04-17 05:39:19 --> Loader Class Initialized
INFO - 2023-04-17 05:39:19 --> Controller Class Initialized
DEBUG - 2023-04-17 05:39:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:39:19 --> Database Driver Class Initialized
INFO - 2023-04-17 05:39:19 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:39:19 --> Database Driver Class Initialized
INFO - 2023-04-17 05:39:19 --> Model "Login_model" initialized
INFO - 2023-04-17 05:39:19 --> Final output sent to browser
DEBUG - 2023-04-17 05:39:19 --> Total execution time: 0.0398
INFO - 2023-04-17 05:39:19 --> Config Class Initialized
INFO - 2023-04-17 05:39:19 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:39:19 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:39:19 --> Utf8 Class Initialized
INFO - 2023-04-17 05:39:19 --> URI Class Initialized
INFO - 2023-04-17 05:39:19 --> Router Class Initialized
INFO - 2023-04-17 05:39:19 --> Output Class Initialized
INFO - 2023-04-17 05:39:19 --> Security Class Initialized
DEBUG - 2023-04-17 05:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:39:19 --> Input Class Initialized
INFO - 2023-04-17 05:39:19 --> Language Class Initialized
INFO - 2023-04-17 05:39:19 --> Loader Class Initialized
INFO - 2023-04-17 05:39:19 --> Controller Class Initialized
DEBUG - 2023-04-17 05:39:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:39:19 --> Database Driver Class Initialized
INFO - 2023-04-17 05:39:19 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:39:19 --> Database Driver Class Initialized
INFO - 2023-04-17 05:39:19 --> Model "Login_model" initialized
INFO - 2023-04-17 05:39:19 --> Final output sent to browser
DEBUG - 2023-04-17 05:39:19 --> Total execution time: 0.0794
INFO - 2023-04-17 05:40:41 --> Config Class Initialized
INFO - 2023-04-17 05:40:41 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:40:41 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:40:41 --> Utf8 Class Initialized
INFO - 2023-04-17 05:40:41 --> URI Class Initialized
INFO - 2023-04-17 05:40:41 --> Router Class Initialized
INFO - 2023-04-17 05:40:41 --> Output Class Initialized
INFO - 2023-04-17 05:40:41 --> Security Class Initialized
DEBUG - 2023-04-17 05:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:40:41 --> Input Class Initialized
INFO - 2023-04-17 05:40:41 --> Language Class Initialized
INFO - 2023-04-17 05:40:41 --> Loader Class Initialized
INFO - 2023-04-17 05:40:41 --> Controller Class Initialized
DEBUG - 2023-04-17 05:40:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:40:41 --> Database Driver Class Initialized
INFO - 2023-04-17 05:40:41 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:40:41 --> Final output sent to browser
DEBUG - 2023-04-17 05:40:41 --> Total execution time: 0.0232
INFO - 2023-04-17 05:40:41 --> Config Class Initialized
INFO - 2023-04-17 05:40:41 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:40:41 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:40:41 --> Utf8 Class Initialized
INFO - 2023-04-17 05:40:41 --> URI Class Initialized
INFO - 2023-04-17 05:40:41 --> Router Class Initialized
INFO - 2023-04-17 05:40:41 --> Output Class Initialized
INFO - 2023-04-17 05:40:41 --> Security Class Initialized
DEBUG - 2023-04-17 05:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:40:41 --> Input Class Initialized
INFO - 2023-04-17 05:40:41 --> Language Class Initialized
INFO - 2023-04-17 05:40:41 --> Loader Class Initialized
INFO - 2023-04-17 05:40:41 --> Controller Class Initialized
DEBUG - 2023-04-17 05:40:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:40:41 --> Database Driver Class Initialized
INFO - 2023-04-17 05:40:41 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:40:41 --> Final output sent to browser
DEBUG - 2023-04-17 05:40:41 --> Total execution time: 0.0206
INFO - 2023-04-17 05:41:00 --> Config Class Initialized
INFO - 2023-04-17 05:41:00 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:41:00 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:41:00 --> Utf8 Class Initialized
INFO - 2023-04-17 05:41:00 --> URI Class Initialized
INFO - 2023-04-17 05:41:00 --> Router Class Initialized
INFO - 2023-04-17 05:41:00 --> Output Class Initialized
INFO - 2023-04-17 05:41:00 --> Security Class Initialized
DEBUG - 2023-04-17 05:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:41:00 --> Input Class Initialized
INFO - 2023-04-17 05:41:00 --> Language Class Initialized
INFO - 2023-04-17 05:41:00 --> Loader Class Initialized
INFO - 2023-04-17 05:41:00 --> Controller Class Initialized
DEBUG - 2023-04-17 05:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:41:00 --> Database Driver Class Initialized
INFO - 2023-04-17 05:41:00 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:41:00 --> Final output sent to browser
DEBUG - 2023-04-17 05:41:00 --> Total execution time: 0.0167
INFO - 2023-04-17 05:41:00 --> Config Class Initialized
INFO - 2023-04-17 05:41:00 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:41:00 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:41:00 --> Utf8 Class Initialized
INFO - 2023-04-17 05:41:00 --> URI Class Initialized
INFO - 2023-04-17 05:41:00 --> Router Class Initialized
INFO - 2023-04-17 05:41:00 --> Output Class Initialized
INFO - 2023-04-17 05:41:00 --> Security Class Initialized
DEBUG - 2023-04-17 05:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:41:00 --> Input Class Initialized
INFO - 2023-04-17 05:41:00 --> Language Class Initialized
INFO - 2023-04-17 05:41:00 --> Loader Class Initialized
INFO - 2023-04-17 05:41:00 --> Controller Class Initialized
DEBUG - 2023-04-17 05:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:41:00 --> Database Driver Class Initialized
INFO - 2023-04-17 05:41:00 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:41:00 --> Final output sent to browser
DEBUG - 2023-04-17 05:41:00 --> Total execution time: 0.0511
INFO - 2023-04-17 05:43:13 --> Config Class Initialized
INFO - 2023-04-17 05:43:13 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:43:13 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:43:13 --> Utf8 Class Initialized
INFO - 2023-04-17 05:43:13 --> URI Class Initialized
INFO - 2023-04-17 05:43:13 --> Router Class Initialized
INFO - 2023-04-17 05:43:13 --> Output Class Initialized
INFO - 2023-04-17 05:43:13 --> Security Class Initialized
DEBUG - 2023-04-17 05:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:43:13 --> Input Class Initialized
INFO - 2023-04-17 05:43:13 --> Language Class Initialized
INFO - 2023-04-17 05:43:13 --> Loader Class Initialized
INFO - 2023-04-17 05:43:13 --> Controller Class Initialized
DEBUG - 2023-04-17 05:43:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:43:13 --> Database Driver Class Initialized
INFO - 2023-04-17 05:43:13 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:43:13 --> Final output sent to browser
DEBUG - 2023-04-17 05:43:13 --> Total execution time: 0.0231
INFO - 2023-04-17 05:43:13 --> Config Class Initialized
INFO - 2023-04-17 05:43:13 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:43:13 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:43:13 --> Utf8 Class Initialized
INFO - 2023-04-17 05:43:13 --> URI Class Initialized
INFO - 2023-04-17 05:43:13 --> Router Class Initialized
INFO - 2023-04-17 05:43:13 --> Output Class Initialized
INFO - 2023-04-17 05:43:13 --> Security Class Initialized
DEBUG - 2023-04-17 05:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:43:13 --> Input Class Initialized
INFO - 2023-04-17 05:43:13 --> Language Class Initialized
INFO - 2023-04-17 05:43:13 --> Loader Class Initialized
INFO - 2023-04-17 05:43:13 --> Controller Class Initialized
DEBUG - 2023-04-17 05:43:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:43:13 --> Database Driver Class Initialized
INFO - 2023-04-17 05:43:13 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:43:13 --> Final output sent to browser
DEBUG - 2023-04-17 05:43:13 --> Total execution time: 0.0198
INFO - 2023-04-17 05:43:14 --> Config Class Initialized
INFO - 2023-04-17 05:43:14 --> Config Class Initialized
INFO - 2023-04-17 05:43:14 --> Hooks Class Initialized
INFO - 2023-04-17 05:43:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:43:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 05:43:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:43:14 --> Utf8 Class Initialized
INFO - 2023-04-17 05:43:14 --> Utf8 Class Initialized
INFO - 2023-04-17 05:43:14 --> URI Class Initialized
INFO - 2023-04-17 05:43:14 --> URI Class Initialized
INFO - 2023-04-17 05:43:14 --> Router Class Initialized
INFO - 2023-04-17 05:43:14 --> Router Class Initialized
INFO - 2023-04-17 05:43:14 --> Output Class Initialized
INFO - 2023-04-17 05:43:14 --> Output Class Initialized
INFO - 2023-04-17 05:43:14 --> Security Class Initialized
INFO - 2023-04-17 05:43:14 --> Security Class Initialized
DEBUG - 2023-04-17 05:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 05:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:43:14 --> Input Class Initialized
INFO - 2023-04-17 05:43:14 --> Input Class Initialized
INFO - 2023-04-17 05:43:14 --> Language Class Initialized
INFO - 2023-04-17 05:43:14 --> Language Class Initialized
INFO - 2023-04-17 05:43:14 --> Loader Class Initialized
INFO - 2023-04-17 05:43:14 --> Controller Class Initialized
INFO - 2023-04-17 05:43:14 --> Loader Class Initialized
DEBUG - 2023-04-17 05:43:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:43:14 --> Controller Class Initialized
INFO - 2023-04-17 05:43:14 --> Final output sent to browser
DEBUG - 2023-04-17 05:43:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 05:43:14 --> Total execution time: 0.0050
INFO - 2023-04-17 05:43:14 --> Database Driver Class Initialized
INFO - 2023-04-17 05:43:14 --> Config Class Initialized
INFO - 2023-04-17 05:43:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:43:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:43:14 --> Utf8 Class Initialized
INFO - 2023-04-17 05:43:14 --> URI Class Initialized
INFO - 2023-04-17 05:43:14 --> Router Class Initialized
INFO - 2023-04-17 05:43:14 --> Output Class Initialized
INFO - 2023-04-17 05:43:14 --> Security Class Initialized
DEBUG - 2023-04-17 05:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:43:14 --> Input Class Initialized
INFO - 2023-04-17 05:43:14 --> Language Class Initialized
INFO - 2023-04-17 05:43:14 --> Loader Class Initialized
INFO - 2023-04-17 05:43:14 --> Controller Class Initialized
DEBUG - 2023-04-17 05:43:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:43:14 --> Database Driver Class Initialized
INFO - 2023-04-17 05:43:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:43:14 --> Model "Login_model" initialized
INFO - 2023-04-17 05:43:14 --> Final output sent to browser
DEBUG - 2023-04-17 05:43:14 --> Total execution time: 0.0195
INFO - 2023-04-17 05:43:14 --> Database Driver Class Initialized
INFO - 2023-04-17 05:43:14 --> Config Class Initialized
INFO - 2023-04-17 05:43:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:43:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:43:14 --> Utf8 Class Initialized
INFO - 2023-04-17 05:43:14 --> URI Class Initialized
INFO - 2023-04-17 05:43:14 --> Router Class Initialized
INFO - 2023-04-17 05:43:14 --> Output Class Initialized
INFO - 2023-04-17 05:43:14 --> Security Class Initialized
DEBUG - 2023-04-17 05:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:43:14 --> Input Class Initialized
INFO - 2023-04-17 05:43:14 --> Language Class Initialized
INFO - 2023-04-17 05:43:14 --> Loader Class Initialized
INFO - 2023-04-17 05:43:14 --> Controller Class Initialized
DEBUG - 2023-04-17 05:43:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:43:14 --> Database Driver Class Initialized
INFO - 2023-04-17 05:43:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:43:14 --> Final output sent to browser
DEBUG - 2023-04-17 05:43:14 --> Total execution time: 0.0309
INFO - 2023-04-17 05:43:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:43:15 --> Final output sent to browser
DEBUG - 2023-04-17 05:43:15 --> Total execution time: 0.0684
INFO - 2023-04-17 05:46:13 --> Config Class Initialized
INFO - 2023-04-17 05:46:13 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:46:13 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:46:13 --> Utf8 Class Initialized
INFO - 2023-04-17 05:46:13 --> URI Class Initialized
INFO - 2023-04-17 05:46:13 --> Router Class Initialized
INFO - 2023-04-17 05:46:13 --> Output Class Initialized
INFO - 2023-04-17 05:46:13 --> Security Class Initialized
DEBUG - 2023-04-17 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:46:13 --> Input Class Initialized
INFO - 2023-04-17 05:46:13 --> Language Class Initialized
INFO - 2023-04-17 05:46:13 --> Loader Class Initialized
INFO - 2023-04-17 05:46:13 --> Controller Class Initialized
DEBUG - 2023-04-17 05:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:46:13 --> Database Driver Class Initialized
INFO - 2023-04-17 05:46:13 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:46:13 --> Final output sent to browser
DEBUG - 2023-04-17 05:46:13 --> Total execution time: 0.0245
INFO - 2023-04-17 05:46:13 --> Config Class Initialized
INFO - 2023-04-17 05:46:13 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:46:13 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:46:13 --> Utf8 Class Initialized
INFO - 2023-04-17 05:46:13 --> URI Class Initialized
INFO - 2023-04-17 05:46:13 --> Router Class Initialized
INFO - 2023-04-17 05:46:13 --> Output Class Initialized
INFO - 2023-04-17 05:46:13 --> Security Class Initialized
DEBUG - 2023-04-17 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:46:13 --> Input Class Initialized
INFO - 2023-04-17 05:46:13 --> Language Class Initialized
INFO - 2023-04-17 05:46:13 --> Loader Class Initialized
INFO - 2023-04-17 05:46:13 --> Controller Class Initialized
DEBUG - 2023-04-17 05:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:46:13 --> Database Driver Class Initialized
INFO - 2023-04-17 05:46:13 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:46:13 --> Final output sent to browser
DEBUG - 2023-04-17 05:46:13 --> Total execution time: 0.0198
INFO - 2023-04-17 05:46:15 --> Config Class Initialized
INFO - 2023-04-17 05:46:15 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:46:15 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:46:15 --> Utf8 Class Initialized
INFO - 2023-04-17 05:46:15 --> URI Class Initialized
INFO - 2023-04-17 05:46:15 --> Router Class Initialized
INFO - 2023-04-17 05:46:15 --> Output Class Initialized
INFO - 2023-04-17 05:46:15 --> Security Class Initialized
DEBUG - 2023-04-17 05:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:46:15 --> Input Class Initialized
INFO - 2023-04-17 05:46:15 --> Language Class Initialized
INFO - 2023-04-17 05:46:15 --> Loader Class Initialized
INFO - 2023-04-17 05:46:15 --> Controller Class Initialized
DEBUG - 2023-04-17 05:46:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:46:15 --> Database Driver Class Initialized
INFO - 2023-04-17 05:46:15 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:46:15 --> Final output sent to browser
DEBUG - 2023-04-17 05:46:15 --> Total execution time: 0.0294
INFO - 2023-04-17 05:46:15 --> Config Class Initialized
INFO - 2023-04-17 05:46:15 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:46:15 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:46:15 --> Utf8 Class Initialized
INFO - 2023-04-17 05:46:15 --> URI Class Initialized
INFO - 2023-04-17 05:46:15 --> Router Class Initialized
INFO - 2023-04-17 05:46:15 --> Output Class Initialized
INFO - 2023-04-17 05:46:15 --> Security Class Initialized
DEBUG - 2023-04-17 05:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:46:15 --> Input Class Initialized
INFO - 2023-04-17 05:46:15 --> Language Class Initialized
INFO - 2023-04-17 05:46:15 --> Loader Class Initialized
INFO - 2023-04-17 05:46:15 --> Controller Class Initialized
DEBUG - 2023-04-17 05:46:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:46:15 --> Database Driver Class Initialized
INFO - 2023-04-17 05:46:15 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:46:15 --> Final output sent to browser
DEBUG - 2023-04-17 05:46:15 --> Total execution time: 0.0117
INFO - 2023-04-17 05:47:03 --> Config Class Initialized
INFO - 2023-04-17 05:47:03 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:47:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:47:03 --> Utf8 Class Initialized
INFO - 2023-04-17 05:47:03 --> URI Class Initialized
INFO - 2023-04-17 05:47:03 --> Router Class Initialized
INFO - 2023-04-17 05:47:03 --> Output Class Initialized
INFO - 2023-04-17 05:47:03 --> Security Class Initialized
DEBUG - 2023-04-17 05:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:47:03 --> Input Class Initialized
INFO - 2023-04-17 05:47:03 --> Language Class Initialized
INFO - 2023-04-17 05:47:03 --> Loader Class Initialized
INFO - 2023-04-17 05:47:03 --> Controller Class Initialized
DEBUG - 2023-04-17 05:47:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:47:03 --> Database Driver Class Initialized
INFO - 2023-04-17 05:47:03 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:47:03 --> Final output sent to browser
DEBUG - 2023-04-17 05:47:03 --> Total execution time: 0.0245
INFO - 2023-04-17 05:47:03 --> Config Class Initialized
INFO - 2023-04-17 05:47:03 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:47:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:47:03 --> Utf8 Class Initialized
INFO - 2023-04-17 05:47:03 --> URI Class Initialized
INFO - 2023-04-17 05:47:03 --> Router Class Initialized
INFO - 2023-04-17 05:47:03 --> Output Class Initialized
INFO - 2023-04-17 05:47:03 --> Security Class Initialized
DEBUG - 2023-04-17 05:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:47:03 --> Input Class Initialized
INFO - 2023-04-17 05:47:03 --> Language Class Initialized
INFO - 2023-04-17 05:47:03 --> Loader Class Initialized
INFO - 2023-04-17 05:47:03 --> Controller Class Initialized
DEBUG - 2023-04-17 05:47:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:47:03 --> Database Driver Class Initialized
INFO - 2023-04-17 05:47:03 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:47:03 --> Final output sent to browser
DEBUG - 2023-04-17 05:47:03 --> Total execution time: 0.0214
INFO - 2023-04-17 05:47:06 --> Config Class Initialized
INFO - 2023-04-17 05:47:06 --> Config Class Initialized
INFO - 2023-04-17 05:47:06 --> Hooks Class Initialized
INFO - 2023-04-17 05:47:06 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:47:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 05:47:06 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:47:06 --> Utf8 Class Initialized
INFO - 2023-04-17 05:47:06 --> Utf8 Class Initialized
INFO - 2023-04-17 05:47:06 --> URI Class Initialized
INFO - 2023-04-17 05:47:06 --> URI Class Initialized
INFO - 2023-04-17 05:47:06 --> Router Class Initialized
INFO - 2023-04-17 05:47:06 --> Router Class Initialized
INFO - 2023-04-17 05:47:06 --> Output Class Initialized
INFO - 2023-04-17 05:47:06 --> Output Class Initialized
INFO - 2023-04-17 05:47:06 --> Security Class Initialized
INFO - 2023-04-17 05:47:06 --> Security Class Initialized
DEBUG - 2023-04-17 05:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 05:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:47:06 --> Input Class Initialized
INFO - 2023-04-17 05:47:06 --> Input Class Initialized
INFO - 2023-04-17 05:47:06 --> Language Class Initialized
INFO - 2023-04-17 05:47:06 --> Language Class Initialized
INFO - 2023-04-17 05:47:06 --> Loader Class Initialized
INFO - 2023-04-17 05:47:06 --> Loader Class Initialized
INFO - 2023-04-17 05:47:06 --> Controller Class Initialized
INFO - 2023-04-17 05:47:06 --> Controller Class Initialized
DEBUG - 2023-04-17 05:47:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 05:47:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:47:06 --> Final output sent to browser
DEBUG - 2023-04-17 05:47:06 --> Total execution time: 0.0041
INFO - 2023-04-17 05:47:06 --> Database Driver Class Initialized
INFO - 2023-04-17 05:47:06 --> Config Class Initialized
INFO - 2023-04-17 05:47:06 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:47:06 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:47:06 --> Utf8 Class Initialized
INFO - 2023-04-17 05:47:06 --> URI Class Initialized
INFO - 2023-04-17 05:47:06 --> Router Class Initialized
INFO - 2023-04-17 05:47:06 --> Output Class Initialized
INFO - 2023-04-17 05:47:06 --> Security Class Initialized
DEBUG - 2023-04-17 05:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:47:06 --> Input Class Initialized
INFO - 2023-04-17 05:47:06 --> Language Class Initialized
INFO - 2023-04-17 05:47:06 --> Loader Class Initialized
INFO - 2023-04-17 05:47:06 --> Controller Class Initialized
DEBUG - 2023-04-17 05:47:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:47:06 --> Database Driver Class Initialized
INFO - 2023-04-17 05:47:06 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:47:06 --> Model "Login_model" initialized
INFO - 2023-04-17 05:47:06 --> Database Driver Class Initialized
INFO - 2023-04-17 05:47:06 --> Final output sent to browser
DEBUG - 2023-04-17 05:47:06 --> Total execution time: 0.0311
INFO - 2023-04-17 05:47:06 --> Config Class Initialized
INFO - 2023-04-17 05:47:06 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:47:06 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:47:06 --> Utf8 Class Initialized
INFO - 2023-04-17 05:47:06 --> URI Class Initialized
INFO - 2023-04-17 05:47:06 --> Router Class Initialized
INFO - 2023-04-17 05:47:06 --> Output Class Initialized
INFO - 2023-04-17 05:47:06 --> Security Class Initialized
DEBUG - 2023-04-17 05:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:47:06 --> Input Class Initialized
INFO - 2023-04-17 05:47:06 --> Language Class Initialized
INFO - 2023-04-17 05:47:06 --> Loader Class Initialized
INFO - 2023-04-17 05:47:06 --> Controller Class Initialized
DEBUG - 2023-04-17 05:47:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:47:06 --> Database Driver Class Initialized
INFO - 2023-04-17 05:47:06 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:47:06 --> Final output sent to browser
DEBUG - 2023-04-17 05:47:06 --> Total execution time: 0.0386
INFO - 2023-04-17 05:47:06 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:47:06 --> Final output sent to browser
DEBUG - 2023-04-17 05:47:06 --> Total execution time: 0.0580
INFO - 2023-04-17 05:47:09 --> Config Class Initialized
INFO - 2023-04-17 05:47:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:47:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:47:09 --> Utf8 Class Initialized
INFO - 2023-04-17 05:47:09 --> URI Class Initialized
INFO - 2023-04-17 05:47:09 --> Router Class Initialized
INFO - 2023-04-17 05:47:09 --> Output Class Initialized
INFO - 2023-04-17 05:47:09 --> Security Class Initialized
DEBUG - 2023-04-17 05:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:47:09 --> Input Class Initialized
INFO - 2023-04-17 05:47:09 --> Language Class Initialized
INFO - 2023-04-17 05:47:09 --> Loader Class Initialized
INFO - 2023-04-17 05:47:09 --> Controller Class Initialized
DEBUG - 2023-04-17 05:47:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:47:09 --> Database Driver Class Initialized
INFO - 2023-04-17 05:47:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:47:09 --> Database Driver Class Initialized
INFO - 2023-04-17 05:47:09 --> Model "Login_model" initialized
INFO - 2023-04-17 05:47:09 --> Final output sent to browser
DEBUG - 2023-04-17 05:47:09 --> Total execution time: 0.0416
INFO - 2023-04-17 05:47:09 --> Config Class Initialized
INFO - 2023-04-17 05:47:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 05:47:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 05:47:09 --> Utf8 Class Initialized
INFO - 2023-04-17 05:47:09 --> URI Class Initialized
INFO - 2023-04-17 05:47:09 --> Router Class Initialized
INFO - 2023-04-17 05:47:09 --> Output Class Initialized
INFO - 2023-04-17 05:47:09 --> Security Class Initialized
DEBUG - 2023-04-17 05:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 05:47:09 --> Input Class Initialized
INFO - 2023-04-17 05:47:09 --> Language Class Initialized
INFO - 2023-04-17 05:47:09 --> Loader Class Initialized
INFO - 2023-04-17 05:47:09 --> Controller Class Initialized
DEBUG - 2023-04-17 05:47:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 05:47:09 --> Database Driver Class Initialized
INFO - 2023-04-17 05:47:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 05:47:09 --> Database Driver Class Initialized
INFO - 2023-04-17 05:47:09 --> Model "Login_model" initialized
INFO - 2023-04-17 05:47:09 --> Final output sent to browser
DEBUG - 2023-04-17 05:47:09 --> Total execution time: 0.0419
INFO - 2023-04-17 06:05:58 --> Config Class Initialized
INFO - 2023-04-17 06:05:58 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:05:58 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:05:58 --> Utf8 Class Initialized
INFO - 2023-04-17 06:05:58 --> URI Class Initialized
INFO - 2023-04-17 06:05:58 --> Router Class Initialized
INFO - 2023-04-17 06:05:58 --> Output Class Initialized
INFO - 2023-04-17 06:05:58 --> Security Class Initialized
DEBUG - 2023-04-17 06:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:05:58 --> Input Class Initialized
INFO - 2023-04-17 06:05:58 --> Language Class Initialized
INFO - 2023-04-17 06:05:58 --> Loader Class Initialized
INFO - 2023-04-17 06:05:58 --> Controller Class Initialized
DEBUG - 2023-04-17 06:05:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:05:58 --> Database Driver Class Initialized
INFO - 2023-04-17 06:05:58 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:05:58 --> Final output sent to browser
DEBUG - 2023-04-17 06:05:58 --> Total execution time: 0.0239
INFO - 2023-04-17 06:05:58 --> Config Class Initialized
INFO - 2023-04-17 06:05:58 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:05:58 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:05:58 --> Utf8 Class Initialized
INFO - 2023-04-17 06:05:58 --> URI Class Initialized
INFO - 2023-04-17 06:05:58 --> Router Class Initialized
INFO - 2023-04-17 06:05:58 --> Output Class Initialized
INFO - 2023-04-17 06:05:58 --> Security Class Initialized
DEBUG - 2023-04-17 06:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:05:58 --> Input Class Initialized
INFO - 2023-04-17 06:05:58 --> Language Class Initialized
INFO - 2023-04-17 06:05:58 --> Loader Class Initialized
INFO - 2023-04-17 06:05:58 --> Controller Class Initialized
DEBUG - 2023-04-17 06:05:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:05:58 --> Database Driver Class Initialized
INFO - 2023-04-17 06:05:58 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:05:58 --> Final output sent to browser
DEBUG - 2023-04-17 06:05:58 --> Total execution time: 0.0335
INFO - 2023-04-17 06:06:01 --> Config Class Initialized
INFO - 2023-04-17 06:06:01 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:06:01 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:06:01 --> Utf8 Class Initialized
INFO - 2023-04-17 06:06:01 --> URI Class Initialized
INFO - 2023-04-17 06:06:01 --> Router Class Initialized
INFO - 2023-04-17 06:06:01 --> Output Class Initialized
INFO - 2023-04-17 06:06:01 --> Security Class Initialized
DEBUG - 2023-04-17 06:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:06:01 --> Input Class Initialized
INFO - 2023-04-17 06:06:01 --> Language Class Initialized
INFO - 2023-04-17 06:06:01 --> Loader Class Initialized
INFO - 2023-04-17 06:06:01 --> Controller Class Initialized
DEBUG - 2023-04-17 06:06:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:06:01 --> Database Driver Class Initialized
INFO - 2023-04-17 06:06:01 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:06:01 --> Final output sent to browser
DEBUG - 2023-04-17 06:06:01 --> Total execution time: 0.1300
INFO - 2023-04-17 06:06:01 --> Config Class Initialized
INFO - 2023-04-17 06:06:01 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:06:01 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:06:01 --> Utf8 Class Initialized
INFO - 2023-04-17 06:06:01 --> URI Class Initialized
INFO - 2023-04-17 06:06:01 --> Router Class Initialized
INFO - 2023-04-17 06:06:01 --> Output Class Initialized
INFO - 2023-04-17 06:06:01 --> Security Class Initialized
DEBUG - 2023-04-17 06:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:06:01 --> Input Class Initialized
INFO - 2023-04-17 06:06:01 --> Language Class Initialized
INFO - 2023-04-17 06:06:01 --> Loader Class Initialized
INFO - 2023-04-17 06:06:01 --> Controller Class Initialized
DEBUG - 2023-04-17 06:06:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:06:01 --> Database Driver Class Initialized
INFO - 2023-04-17 06:06:01 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:06:01 --> Final output sent to browser
DEBUG - 2023-04-17 06:06:01 --> Total execution time: 0.0468
INFO - 2023-04-17 06:06:02 --> Config Class Initialized
INFO - 2023-04-17 06:06:02 --> Config Class Initialized
INFO - 2023-04-17 06:06:02 --> Hooks Class Initialized
INFO - 2023-04-17 06:06:02 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:06:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 06:06:02 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:06:02 --> Utf8 Class Initialized
INFO - 2023-04-17 06:06:02 --> Utf8 Class Initialized
INFO - 2023-04-17 06:06:02 --> URI Class Initialized
INFO - 2023-04-17 06:06:02 --> URI Class Initialized
INFO - 2023-04-17 06:06:02 --> Router Class Initialized
INFO - 2023-04-17 06:06:02 --> Router Class Initialized
INFO - 2023-04-17 06:06:02 --> Output Class Initialized
INFO - 2023-04-17 06:06:02 --> Output Class Initialized
INFO - 2023-04-17 06:06:02 --> Security Class Initialized
INFO - 2023-04-17 06:06:02 --> Security Class Initialized
DEBUG - 2023-04-17 06:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 06:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:06:02 --> Input Class Initialized
INFO - 2023-04-17 06:06:02 --> Input Class Initialized
INFO - 2023-04-17 06:06:02 --> Language Class Initialized
INFO - 2023-04-17 06:06:02 --> Language Class Initialized
INFO - 2023-04-17 06:06:02 --> Loader Class Initialized
INFO - 2023-04-17 06:06:02 --> Loader Class Initialized
INFO - 2023-04-17 06:06:02 --> Controller Class Initialized
INFO - 2023-04-17 06:06:02 --> Controller Class Initialized
DEBUG - 2023-04-17 06:06:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 06:06:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:06:02 --> Final output sent to browser
INFO - 2023-04-17 06:06:02 --> Database Driver Class Initialized
DEBUG - 2023-04-17 06:06:02 --> Total execution time: 0.0047
INFO - 2023-04-17 06:06:02 --> Config Class Initialized
INFO - 2023-04-17 06:06:02 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:06:02 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:06:02 --> Utf8 Class Initialized
INFO - 2023-04-17 06:06:02 --> URI Class Initialized
INFO - 2023-04-17 06:06:02 --> Router Class Initialized
INFO - 2023-04-17 06:06:02 --> Output Class Initialized
INFO - 2023-04-17 06:06:02 --> Security Class Initialized
DEBUG - 2023-04-17 06:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:06:02 --> Input Class Initialized
INFO - 2023-04-17 06:06:02 --> Language Class Initialized
INFO - 2023-04-17 06:06:02 --> Loader Class Initialized
INFO - 2023-04-17 06:06:02 --> Controller Class Initialized
DEBUG - 2023-04-17 06:06:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:06:02 --> Database Driver Class Initialized
INFO - 2023-04-17 06:06:02 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:06:02 --> Final output sent to browser
DEBUG - 2023-04-17 06:06:02 --> Total execution time: 0.0459
INFO - 2023-04-17 06:06:02 --> Config Class Initialized
INFO - 2023-04-17 06:06:02 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:06:02 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:06:02 --> Utf8 Class Initialized
INFO - 2023-04-17 06:06:02 --> URI Class Initialized
INFO - 2023-04-17 06:06:02 --> Router Class Initialized
INFO - 2023-04-17 06:06:02 --> Output Class Initialized
INFO - 2023-04-17 06:06:02 --> Security Class Initialized
DEBUG - 2023-04-17 06:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:06:02 --> Input Class Initialized
INFO - 2023-04-17 06:06:02 --> Language Class Initialized
INFO - 2023-04-17 06:06:02 --> Loader Class Initialized
INFO - 2023-04-17 06:06:02 --> Controller Class Initialized
DEBUG - 2023-04-17 06:06:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:06:02 --> Database Driver Class Initialized
INFO - 2023-04-17 06:06:02 --> Model "Login_model" initialized
INFO - 2023-04-17 06:06:02 --> Database Driver Class Initialized
INFO - 2023-04-17 06:06:02 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:06:02 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:06:02 --> Final output sent to browser
INFO - 2023-04-17 06:06:02 --> Final output sent to browser
DEBUG - 2023-04-17 06:06:02 --> Total execution time: 0.0694
DEBUG - 2023-04-17 06:06:02 --> Total execution time: 0.1075
INFO - 2023-04-17 06:30:59 --> Config Class Initialized
INFO - 2023-04-17 06:30:59 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:30:59 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:30:59 --> Utf8 Class Initialized
INFO - 2023-04-17 06:30:59 --> URI Class Initialized
INFO - 2023-04-17 06:30:59 --> Router Class Initialized
INFO - 2023-04-17 06:30:59 --> Output Class Initialized
INFO - 2023-04-17 06:30:59 --> Security Class Initialized
DEBUG - 2023-04-17 06:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:30:59 --> Input Class Initialized
INFO - 2023-04-17 06:30:59 --> Language Class Initialized
INFO - 2023-04-17 06:30:59 --> Loader Class Initialized
INFO - 2023-04-17 06:30:59 --> Controller Class Initialized
DEBUG - 2023-04-17 06:30:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:30:59 --> Database Driver Class Initialized
INFO - 2023-04-17 06:30:59 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:30:59 --> Final output sent to browser
DEBUG - 2023-04-17 06:30:59 --> Total execution time: 0.0373
INFO - 2023-04-17 06:30:59 --> Config Class Initialized
INFO - 2023-04-17 06:30:59 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:30:59 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:30:59 --> Utf8 Class Initialized
INFO - 2023-04-17 06:30:59 --> URI Class Initialized
INFO - 2023-04-17 06:30:59 --> Router Class Initialized
INFO - 2023-04-17 06:30:59 --> Output Class Initialized
INFO - 2023-04-17 06:30:59 --> Security Class Initialized
DEBUG - 2023-04-17 06:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:30:59 --> Input Class Initialized
INFO - 2023-04-17 06:30:59 --> Language Class Initialized
INFO - 2023-04-17 06:30:59 --> Loader Class Initialized
INFO - 2023-04-17 06:30:59 --> Controller Class Initialized
DEBUG - 2023-04-17 06:30:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:30:59 --> Database Driver Class Initialized
INFO - 2023-04-17 06:30:59 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:30:59 --> Final output sent to browser
DEBUG - 2023-04-17 06:30:59 --> Total execution time: 0.0599
INFO - 2023-04-17 06:31:01 --> Config Class Initialized
INFO - 2023-04-17 06:31:01 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:31:01 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:31:01 --> Utf8 Class Initialized
INFO - 2023-04-17 06:31:01 --> URI Class Initialized
INFO - 2023-04-17 06:31:01 --> Router Class Initialized
INFO - 2023-04-17 06:31:01 --> Output Class Initialized
INFO - 2023-04-17 06:31:01 --> Security Class Initialized
DEBUG - 2023-04-17 06:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:31:01 --> Input Class Initialized
INFO - 2023-04-17 06:31:01 --> Language Class Initialized
INFO - 2023-04-17 06:31:01 --> Loader Class Initialized
INFO - 2023-04-17 06:31:01 --> Controller Class Initialized
DEBUG - 2023-04-17 06:31:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:31:01 --> Database Driver Class Initialized
INFO - 2023-04-17 06:31:01 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:31:01 --> Database Driver Class Initialized
INFO - 2023-04-17 06:31:01 --> Model "Login_model" initialized
INFO - 2023-04-17 06:31:01 --> Final output sent to browser
DEBUG - 2023-04-17 06:31:01 --> Total execution time: 0.0817
INFO - 2023-04-17 06:31:01 --> Config Class Initialized
INFO - 2023-04-17 06:31:01 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:31:01 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:31:01 --> Utf8 Class Initialized
INFO - 2023-04-17 06:31:01 --> URI Class Initialized
INFO - 2023-04-17 06:31:01 --> Router Class Initialized
INFO - 2023-04-17 06:31:01 --> Output Class Initialized
INFO - 2023-04-17 06:31:01 --> Security Class Initialized
DEBUG - 2023-04-17 06:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:31:01 --> Input Class Initialized
INFO - 2023-04-17 06:31:01 --> Language Class Initialized
INFO - 2023-04-17 06:31:01 --> Loader Class Initialized
INFO - 2023-04-17 06:31:01 --> Controller Class Initialized
DEBUG - 2023-04-17 06:31:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:31:01 --> Database Driver Class Initialized
INFO - 2023-04-17 06:31:01 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:31:01 --> Database Driver Class Initialized
INFO - 2023-04-17 06:31:01 --> Model "Login_model" initialized
INFO - 2023-04-17 06:31:01 --> Final output sent to browser
DEBUG - 2023-04-17 06:31:01 --> Total execution time: 0.0845
INFO - 2023-04-17 06:33:48 --> Config Class Initialized
INFO - 2023-04-17 06:33:48 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:48 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:48 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:48 --> URI Class Initialized
INFO - 2023-04-17 06:33:48 --> Router Class Initialized
INFO - 2023-04-17 06:33:48 --> Output Class Initialized
INFO - 2023-04-17 06:33:48 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:48 --> Input Class Initialized
INFO - 2023-04-17 06:33:48 --> Language Class Initialized
INFO - 2023-04-17 06:33:48 --> Loader Class Initialized
INFO - 2023-04-17 06:33:48 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:48 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:48 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:48 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:48 --> Total execution time: 0.0270
INFO - 2023-04-17 06:33:48 --> Config Class Initialized
INFO - 2023-04-17 06:33:48 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:48 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:48 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:48 --> URI Class Initialized
INFO - 2023-04-17 06:33:48 --> Router Class Initialized
INFO - 2023-04-17 06:33:48 --> Output Class Initialized
INFO - 2023-04-17 06:33:48 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:48 --> Input Class Initialized
INFO - 2023-04-17 06:33:48 --> Language Class Initialized
INFO - 2023-04-17 06:33:48 --> Loader Class Initialized
INFO - 2023-04-17 06:33:48 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:48 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:48 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:48 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:48 --> Model "Login_model" initialized
INFO - 2023-04-17 06:33:48 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:48 --> Total execution time: 0.0492
INFO - 2023-04-17 06:33:48 --> Config Class Initialized
INFO - 2023-04-17 06:33:49 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:49 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:49 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:49 --> URI Class Initialized
INFO - 2023-04-17 06:33:49 --> Router Class Initialized
INFO - 2023-04-17 06:33:49 --> Output Class Initialized
INFO - 2023-04-17 06:33:49 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:49 --> Input Class Initialized
INFO - 2023-04-17 06:33:49 --> Language Class Initialized
INFO - 2023-04-17 06:33:49 --> Loader Class Initialized
INFO - 2023-04-17 06:33:49 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:49 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:49 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:49 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:49 --> Total execution time: 0.0616
INFO - 2023-04-17 06:33:49 --> Config Class Initialized
INFO - 2023-04-17 06:33:49 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:49 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:49 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:49 --> URI Class Initialized
INFO - 2023-04-17 06:33:49 --> Router Class Initialized
INFO - 2023-04-17 06:33:49 --> Output Class Initialized
INFO - 2023-04-17 06:33:49 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:49 --> Input Class Initialized
INFO - 2023-04-17 06:33:49 --> Language Class Initialized
INFO - 2023-04-17 06:33:49 --> Loader Class Initialized
INFO - 2023-04-17 06:33:49 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:49 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:49 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:49 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:49 --> Model "Login_model" initialized
INFO - 2023-04-17 06:33:49 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:49 --> Total execution time: 0.0348
INFO - 2023-04-17 06:33:49 --> Config Class Initialized
INFO - 2023-04-17 06:33:49 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:49 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:49 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:49 --> URI Class Initialized
INFO - 2023-04-17 06:33:49 --> Router Class Initialized
INFO - 2023-04-17 06:33:49 --> Output Class Initialized
INFO - 2023-04-17 06:33:49 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:49 --> Input Class Initialized
INFO - 2023-04-17 06:33:49 --> Language Class Initialized
INFO - 2023-04-17 06:33:49 --> Loader Class Initialized
INFO - 2023-04-17 06:33:49 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:49 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:49 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:49 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:49 --> Total execution time: 0.0205
INFO - 2023-04-17 06:33:49 --> Config Class Initialized
INFO - 2023-04-17 06:33:49 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:49 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:49 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:49 --> URI Class Initialized
INFO - 2023-04-17 06:33:49 --> Router Class Initialized
INFO - 2023-04-17 06:33:49 --> Output Class Initialized
INFO - 2023-04-17 06:33:49 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:49 --> Input Class Initialized
INFO - 2023-04-17 06:33:49 --> Language Class Initialized
INFO - 2023-04-17 06:33:49 --> Loader Class Initialized
INFO - 2023-04-17 06:33:49 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:49 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:49 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:49 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:49 --> Total execution time: 0.0214
INFO - 2023-04-17 06:33:50 --> Config Class Initialized
INFO - 2023-04-17 06:33:50 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:50 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:50 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:50 --> URI Class Initialized
INFO - 2023-04-17 06:33:50 --> Router Class Initialized
INFO - 2023-04-17 06:33:50 --> Output Class Initialized
INFO - 2023-04-17 06:33:50 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:50 --> Input Class Initialized
INFO - 2023-04-17 06:33:50 --> Language Class Initialized
INFO - 2023-04-17 06:33:50 --> Loader Class Initialized
INFO - 2023-04-17 06:33:50 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:50 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:50 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:50 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:50 --> Model "Login_model" initialized
INFO - 2023-04-17 06:33:50 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:50 --> Total execution time: 0.0303
INFO - 2023-04-17 06:33:50 --> Config Class Initialized
INFO - 2023-04-17 06:33:50 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:50 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:50 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:50 --> URI Class Initialized
INFO - 2023-04-17 06:33:50 --> Router Class Initialized
INFO - 2023-04-17 06:33:50 --> Output Class Initialized
INFO - 2023-04-17 06:33:50 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:50 --> Input Class Initialized
INFO - 2023-04-17 06:33:50 --> Language Class Initialized
INFO - 2023-04-17 06:33:50 --> Loader Class Initialized
INFO - 2023-04-17 06:33:50 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:50 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:50 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:50 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:50 --> Model "Login_model" initialized
INFO - 2023-04-17 06:33:50 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:50 --> Total execution time: 0.0225
INFO - 2023-04-17 06:33:50 --> Config Class Initialized
INFO - 2023-04-17 06:33:50 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:50 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:50 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:50 --> URI Class Initialized
INFO - 2023-04-17 06:33:50 --> Router Class Initialized
INFO - 2023-04-17 06:33:50 --> Output Class Initialized
INFO - 2023-04-17 06:33:50 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:50 --> Input Class Initialized
INFO - 2023-04-17 06:33:50 --> Language Class Initialized
INFO - 2023-04-17 06:33:50 --> Loader Class Initialized
INFO - 2023-04-17 06:33:50 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:50 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:50 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:50 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:50 --> Model "Login_model" initialized
INFO - 2023-04-17 06:33:50 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:50 --> Total execution time: 0.0720
INFO - 2023-04-17 06:33:50 --> Config Class Initialized
INFO - 2023-04-17 06:33:50 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:50 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:50 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:50 --> URI Class Initialized
INFO - 2023-04-17 06:33:50 --> Router Class Initialized
INFO - 2023-04-17 06:33:50 --> Output Class Initialized
INFO - 2023-04-17 06:33:50 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:50 --> Input Class Initialized
INFO - 2023-04-17 06:33:50 --> Language Class Initialized
INFO - 2023-04-17 06:33:50 --> Loader Class Initialized
INFO - 2023-04-17 06:33:50 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:50 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:50 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:50 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:50 --> Model "Login_model" initialized
INFO - 2023-04-17 06:33:51 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:51 --> Total execution time: 0.0657
INFO - 2023-04-17 06:33:52 --> Config Class Initialized
INFO - 2023-04-17 06:33:52 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:52 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:52 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:52 --> URI Class Initialized
INFO - 2023-04-17 06:33:52 --> Router Class Initialized
INFO - 2023-04-17 06:33:52 --> Output Class Initialized
INFO - 2023-04-17 06:33:52 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:52 --> Input Class Initialized
INFO - 2023-04-17 06:33:52 --> Language Class Initialized
INFO - 2023-04-17 06:33:52 --> Loader Class Initialized
INFO - 2023-04-17 06:33:52 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:52 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:52 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:52 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:52 --> Total execution time: 0.0567
INFO - 2023-04-17 06:33:52 --> Config Class Initialized
INFO - 2023-04-17 06:33:52 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:52 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:52 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:52 --> URI Class Initialized
INFO - 2023-04-17 06:33:52 --> Router Class Initialized
INFO - 2023-04-17 06:33:52 --> Output Class Initialized
INFO - 2023-04-17 06:33:52 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:52 --> Input Class Initialized
INFO - 2023-04-17 06:33:52 --> Language Class Initialized
INFO - 2023-04-17 06:33:52 --> Loader Class Initialized
INFO - 2023-04-17 06:33:52 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:52 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:52 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:52 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:52 --> Total execution time: 0.0344
INFO - 2023-04-17 06:33:53 --> Config Class Initialized
INFO - 2023-04-17 06:33:53 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:53 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:53 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:53 --> URI Class Initialized
INFO - 2023-04-17 06:33:53 --> Router Class Initialized
INFO - 2023-04-17 06:33:53 --> Output Class Initialized
INFO - 2023-04-17 06:33:53 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:53 --> Input Class Initialized
INFO - 2023-04-17 06:33:53 --> Language Class Initialized
INFO - 2023-04-17 06:33:53 --> Loader Class Initialized
INFO - 2023-04-17 06:33:53 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:53 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:53 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:53 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:53 --> Total execution time: 0.0372
INFO - 2023-04-17 06:33:53 --> Config Class Initialized
INFO - 2023-04-17 06:33:53 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:53 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:53 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:53 --> URI Class Initialized
INFO - 2023-04-17 06:33:53 --> Router Class Initialized
INFO - 2023-04-17 06:33:53 --> Output Class Initialized
INFO - 2023-04-17 06:33:53 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:53 --> Input Class Initialized
INFO - 2023-04-17 06:33:53 --> Language Class Initialized
INFO - 2023-04-17 06:33:53 --> Loader Class Initialized
INFO - 2023-04-17 06:33:53 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:53 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:53 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:53 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:53 --> Total execution time: 0.0187
INFO - 2023-04-17 06:33:55 --> Config Class Initialized
INFO - 2023-04-17 06:33:55 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:55 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:55 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:55 --> URI Class Initialized
INFO - 2023-04-17 06:33:55 --> Router Class Initialized
INFO - 2023-04-17 06:33:55 --> Output Class Initialized
INFO - 2023-04-17 06:33:55 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:55 --> Input Class Initialized
INFO - 2023-04-17 06:33:55 --> Language Class Initialized
INFO - 2023-04-17 06:33:55 --> Loader Class Initialized
INFO - 2023-04-17 06:33:55 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:55 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:55 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:55 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:55 --> Total execution time: 0.0282
INFO - 2023-04-17 06:33:56 --> Config Class Initialized
INFO - 2023-04-17 06:33:56 --> Config Class Initialized
INFO - 2023-04-17 06:33:56 --> Hooks Class Initialized
INFO - 2023-04-17 06:33:56 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:56 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:56 --> Utf8 Class Initialized
DEBUG - 2023-04-17 06:33:56 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:56 --> URI Class Initialized
INFO - 2023-04-17 06:33:56 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:56 --> Router Class Initialized
INFO - 2023-04-17 06:33:56 --> URI Class Initialized
INFO - 2023-04-17 06:33:56 --> Output Class Initialized
INFO - 2023-04-17 06:33:56 --> Router Class Initialized
INFO - 2023-04-17 06:33:56 --> Security Class Initialized
INFO - 2023-04-17 06:33:56 --> Output Class Initialized
DEBUG - 2023-04-17 06:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:56 --> Security Class Initialized
INFO - 2023-04-17 06:33:56 --> Input Class Initialized
DEBUG - 2023-04-17 06:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:56 --> Language Class Initialized
INFO - 2023-04-17 06:33:56 --> Input Class Initialized
INFO - 2023-04-17 06:33:56 --> Language Class Initialized
INFO - 2023-04-17 06:33:56 --> Loader Class Initialized
INFO - 2023-04-17 06:33:56 --> Controller Class Initialized
INFO - 2023-04-17 06:33:56 --> Loader Class Initialized
DEBUG - 2023-04-17 06:33:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:56 --> Controller Class Initialized
INFO - 2023-04-17 06:33:56 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 06:33:56 --> Total execution time: 0.0038
INFO - 2023-04-17 06:33:56 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:56 --> Config Class Initialized
INFO - 2023-04-17 06:33:56 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:56 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:56 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:56 --> URI Class Initialized
INFO - 2023-04-17 06:33:56 --> Router Class Initialized
INFO - 2023-04-17 06:33:56 --> Output Class Initialized
INFO - 2023-04-17 06:33:56 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:56 --> Input Class Initialized
INFO - 2023-04-17 06:33:56 --> Language Class Initialized
INFO - 2023-04-17 06:33:56 --> Loader Class Initialized
INFO - 2023-04-17 06:33:56 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:56 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:56 --> Model "Login_model" initialized
INFO - 2023-04-17 06:33:56 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:56 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:56 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:56 --> Total execution time: 0.0385
INFO - 2023-04-17 06:33:56 --> Config Class Initialized
INFO - 2023-04-17 06:33:56 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:56 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:56 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:56 --> URI Class Initialized
INFO - 2023-04-17 06:33:56 --> Router Class Initialized
INFO - 2023-04-17 06:33:56 --> Output Class Initialized
INFO - 2023-04-17 06:33:56 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:56 --> Input Class Initialized
INFO - 2023-04-17 06:33:56 --> Language Class Initialized
INFO - 2023-04-17 06:33:56 --> Loader Class Initialized
INFO - 2023-04-17 06:33:56 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:56 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:56 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:56 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:56 --> Total execution time: 0.0478
INFO - 2023-04-17 06:33:56 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:56 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:56 --> Total execution time: 0.0694
INFO - 2023-04-17 06:33:57 --> Config Class Initialized
INFO - 2023-04-17 06:33:57 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:57 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:57 --> URI Class Initialized
INFO - 2023-04-17 06:33:57 --> Router Class Initialized
INFO - 2023-04-17 06:33:57 --> Output Class Initialized
INFO - 2023-04-17 06:33:57 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:57 --> Input Class Initialized
INFO - 2023-04-17 06:33:57 --> Language Class Initialized
INFO - 2023-04-17 06:33:57 --> Loader Class Initialized
INFO - 2023-04-17 06:33:57 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:57 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:57 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:57 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:57 --> Model "Login_model" initialized
INFO - 2023-04-17 06:33:57 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:57 --> Total execution time: 0.0413
INFO - 2023-04-17 06:33:57 --> Config Class Initialized
INFO - 2023-04-17 06:33:57 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:57 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:57 --> URI Class Initialized
INFO - 2023-04-17 06:33:57 --> Router Class Initialized
INFO - 2023-04-17 06:33:57 --> Output Class Initialized
INFO - 2023-04-17 06:33:57 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:57 --> Input Class Initialized
INFO - 2023-04-17 06:33:57 --> Language Class Initialized
INFO - 2023-04-17 06:33:57 --> Loader Class Initialized
INFO - 2023-04-17 06:33:57 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:57 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:57 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:57 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:57 --> Model "Login_model" initialized
INFO - 2023-04-17 06:33:57 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:57 --> Total execution time: 0.0367
INFO - 2023-04-17 06:33:58 --> Config Class Initialized
INFO - 2023-04-17 06:33:58 --> Config Class Initialized
INFO - 2023-04-17 06:33:58 --> Hooks Class Initialized
INFO - 2023-04-17 06:33:58 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:33:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 06:33:58 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:33:58 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:58 --> Utf8 Class Initialized
INFO - 2023-04-17 06:33:58 --> URI Class Initialized
INFO - 2023-04-17 06:33:58 --> URI Class Initialized
INFO - 2023-04-17 06:33:58 --> Router Class Initialized
INFO - 2023-04-17 06:33:58 --> Router Class Initialized
INFO - 2023-04-17 06:33:58 --> Output Class Initialized
INFO - 2023-04-17 06:33:58 --> Output Class Initialized
INFO - 2023-04-17 06:33:58 --> Security Class Initialized
INFO - 2023-04-17 06:33:58 --> Security Class Initialized
DEBUG - 2023-04-17 06:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 06:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:33:58 --> Input Class Initialized
INFO - 2023-04-17 06:33:58 --> Input Class Initialized
INFO - 2023-04-17 06:33:58 --> Language Class Initialized
INFO - 2023-04-17 06:33:58 --> Language Class Initialized
INFO - 2023-04-17 06:33:58 --> Loader Class Initialized
INFO - 2023-04-17 06:33:58 --> Loader Class Initialized
INFO - 2023-04-17 06:33:58 --> Controller Class Initialized
INFO - 2023-04-17 06:33:58 --> Controller Class Initialized
DEBUG - 2023-04-17 06:33:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 06:33:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:33:58 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:58 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:58 --> Model "Login_model" initialized
INFO - 2023-04-17 06:33:58 --> Database Driver Class Initialized
INFO - 2023-04-17 06:33:58 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:58 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:58 --> Total execution time: 0.0304
INFO - 2023-04-17 06:33:58 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:33:58 --> Final output sent to browser
DEBUG - 2023-04-17 06:33:58 --> Total execution time: 0.0386
INFO - 2023-04-17 06:34:00 --> Config Class Initialized
INFO - 2023-04-17 06:34:00 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:34:00 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:34:00 --> Utf8 Class Initialized
INFO - 2023-04-17 06:34:00 --> URI Class Initialized
INFO - 2023-04-17 06:34:00 --> Router Class Initialized
INFO - 2023-04-17 06:34:00 --> Output Class Initialized
INFO - 2023-04-17 06:34:00 --> Security Class Initialized
DEBUG - 2023-04-17 06:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:34:00 --> Input Class Initialized
INFO - 2023-04-17 06:34:00 --> Language Class Initialized
INFO - 2023-04-17 06:34:00 --> Loader Class Initialized
INFO - 2023-04-17 06:34:00 --> Controller Class Initialized
DEBUG - 2023-04-17 06:34:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:34:00 --> Database Driver Class Initialized
INFO - 2023-04-17 06:34:00 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:34:00 --> Final output sent to browser
DEBUG - 2023-04-17 06:34:00 --> Total execution time: 0.0459
INFO - 2023-04-17 06:34:00 --> Config Class Initialized
INFO - 2023-04-17 06:34:00 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:34:00 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:34:00 --> Utf8 Class Initialized
INFO - 2023-04-17 06:34:00 --> URI Class Initialized
INFO - 2023-04-17 06:34:00 --> Router Class Initialized
INFO - 2023-04-17 06:34:00 --> Output Class Initialized
INFO - 2023-04-17 06:34:00 --> Security Class Initialized
DEBUG - 2023-04-17 06:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:34:00 --> Input Class Initialized
INFO - 2023-04-17 06:34:00 --> Language Class Initialized
INFO - 2023-04-17 06:34:00 --> Loader Class Initialized
INFO - 2023-04-17 06:34:00 --> Controller Class Initialized
DEBUG - 2023-04-17 06:34:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:34:00 --> Database Driver Class Initialized
INFO - 2023-04-17 06:34:00 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:34:00 --> Final output sent to browser
DEBUG - 2023-04-17 06:34:00 --> Total execution time: 0.0368
INFO - 2023-04-17 06:34:01 --> Config Class Initialized
INFO - 2023-04-17 06:34:01 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:34:01 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:34:01 --> Utf8 Class Initialized
INFO - 2023-04-17 06:34:01 --> URI Class Initialized
INFO - 2023-04-17 06:34:01 --> Router Class Initialized
INFO - 2023-04-17 06:34:01 --> Output Class Initialized
INFO - 2023-04-17 06:34:01 --> Security Class Initialized
DEBUG - 2023-04-17 06:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:34:01 --> Input Class Initialized
INFO - 2023-04-17 06:34:01 --> Language Class Initialized
INFO - 2023-04-17 06:34:01 --> Loader Class Initialized
INFO - 2023-04-17 06:34:01 --> Controller Class Initialized
DEBUG - 2023-04-17 06:34:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:34:01 --> Database Driver Class Initialized
INFO - 2023-04-17 06:34:01 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:34:01 --> Final output sent to browser
DEBUG - 2023-04-17 06:34:01 --> Total execution time: 0.0186
INFO - 2023-04-17 06:34:01 --> Config Class Initialized
INFO - 2023-04-17 06:34:01 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:34:01 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:34:01 --> Utf8 Class Initialized
INFO - 2023-04-17 06:34:01 --> URI Class Initialized
INFO - 2023-04-17 06:34:01 --> Router Class Initialized
INFO - 2023-04-17 06:34:01 --> Output Class Initialized
INFO - 2023-04-17 06:34:01 --> Security Class Initialized
DEBUG - 2023-04-17 06:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:34:01 --> Input Class Initialized
INFO - 2023-04-17 06:34:01 --> Language Class Initialized
INFO - 2023-04-17 06:34:01 --> Loader Class Initialized
INFO - 2023-04-17 06:34:01 --> Controller Class Initialized
DEBUG - 2023-04-17 06:34:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:34:01 --> Database Driver Class Initialized
INFO - 2023-04-17 06:34:02 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:34:02 --> Final output sent to browser
DEBUG - 2023-04-17 06:34:02 --> Total execution time: 0.6552
INFO - 2023-04-17 06:44:30 --> Config Class Initialized
INFO - 2023-04-17 06:44:30 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:44:30 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:44:30 --> Utf8 Class Initialized
INFO - 2023-04-17 06:44:30 --> URI Class Initialized
INFO - 2023-04-17 06:44:30 --> Router Class Initialized
INFO - 2023-04-17 06:44:30 --> Output Class Initialized
INFO - 2023-04-17 06:44:30 --> Security Class Initialized
DEBUG - 2023-04-17 06:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:44:30 --> Input Class Initialized
INFO - 2023-04-17 06:44:30 --> Language Class Initialized
INFO - 2023-04-17 06:44:30 --> Loader Class Initialized
INFO - 2023-04-17 06:44:30 --> Controller Class Initialized
DEBUG - 2023-04-17 06:44:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:44:30 --> Database Driver Class Initialized
INFO - 2023-04-17 06:44:30 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:44:30 --> Final output sent to browser
DEBUG - 2023-04-17 06:44:30 --> Total execution time: 0.0234
INFO - 2023-04-17 06:44:30 --> Config Class Initialized
INFO - 2023-04-17 06:44:31 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:44:31 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:44:31 --> Utf8 Class Initialized
INFO - 2023-04-17 06:44:31 --> URI Class Initialized
INFO - 2023-04-17 06:44:31 --> Router Class Initialized
INFO - 2023-04-17 06:44:31 --> Output Class Initialized
INFO - 2023-04-17 06:44:31 --> Security Class Initialized
DEBUG - 2023-04-17 06:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:44:31 --> Input Class Initialized
INFO - 2023-04-17 06:44:31 --> Language Class Initialized
INFO - 2023-04-17 06:44:31 --> Loader Class Initialized
INFO - 2023-04-17 06:44:31 --> Controller Class Initialized
DEBUG - 2023-04-17 06:44:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:44:31 --> Database Driver Class Initialized
INFO - 2023-04-17 06:44:31 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:44:31 --> Final output sent to browser
DEBUG - 2023-04-17 06:44:31 --> Total execution time: 0.0614
INFO - 2023-04-17 06:44:31 --> Config Class Initialized
INFO - 2023-04-17 06:44:31 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:44:31 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:44:31 --> Utf8 Class Initialized
INFO - 2023-04-17 06:44:31 --> URI Class Initialized
INFO - 2023-04-17 06:44:31 --> Router Class Initialized
INFO - 2023-04-17 06:44:31 --> Output Class Initialized
INFO - 2023-04-17 06:44:31 --> Security Class Initialized
DEBUG - 2023-04-17 06:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:44:31 --> Input Class Initialized
INFO - 2023-04-17 06:44:31 --> Language Class Initialized
INFO - 2023-04-17 06:44:31 --> Loader Class Initialized
INFO - 2023-04-17 06:44:31 --> Controller Class Initialized
DEBUG - 2023-04-17 06:44:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:44:31 --> Database Driver Class Initialized
INFO - 2023-04-17 06:44:31 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:44:31 --> Database Driver Class Initialized
INFO - 2023-04-17 06:44:31 --> Model "Login_model" initialized
INFO - 2023-04-17 06:44:32 --> Final output sent to browser
DEBUG - 2023-04-17 06:44:32 --> Total execution time: 0.0456
INFO - 2023-04-17 06:44:32 --> Config Class Initialized
INFO - 2023-04-17 06:44:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 06:44:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 06:44:32 --> Utf8 Class Initialized
INFO - 2023-04-17 06:44:32 --> URI Class Initialized
INFO - 2023-04-17 06:44:32 --> Router Class Initialized
INFO - 2023-04-17 06:44:32 --> Output Class Initialized
INFO - 2023-04-17 06:44:32 --> Security Class Initialized
DEBUG - 2023-04-17 06:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 06:44:32 --> Input Class Initialized
INFO - 2023-04-17 06:44:32 --> Language Class Initialized
INFO - 2023-04-17 06:44:32 --> Loader Class Initialized
INFO - 2023-04-17 06:44:32 --> Controller Class Initialized
DEBUG - 2023-04-17 06:44:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 06:44:32 --> Database Driver Class Initialized
INFO - 2023-04-17 06:44:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 06:44:32 --> Database Driver Class Initialized
INFO - 2023-04-17 06:44:32 --> Model "Login_model" initialized
INFO - 2023-04-17 06:44:32 --> Final output sent to browser
DEBUG - 2023-04-17 06:44:32 --> Total execution time: 0.0856
INFO - 2023-04-17 07:03:07 --> Config Class Initialized
INFO - 2023-04-17 07:03:07 --> Config Class Initialized
INFO - 2023-04-17 07:03:07 --> Hooks Class Initialized
INFO - 2023-04-17 07:03:07 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:03:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 07:03:07 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:03:07 --> Utf8 Class Initialized
INFO - 2023-04-17 07:03:07 --> Utf8 Class Initialized
INFO - 2023-04-17 07:03:07 --> URI Class Initialized
INFO - 2023-04-17 07:03:07 --> URI Class Initialized
INFO - 2023-04-17 07:03:07 --> Router Class Initialized
INFO - 2023-04-17 07:03:07 --> Router Class Initialized
INFO - 2023-04-17 07:03:07 --> Output Class Initialized
INFO - 2023-04-17 07:03:07 --> Output Class Initialized
INFO - 2023-04-17 07:03:07 --> Security Class Initialized
INFO - 2023-04-17 07:03:07 --> Security Class Initialized
DEBUG - 2023-04-17 07:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 07:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:03:07 --> Input Class Initialized
INFO - 2023-04-17 07:03:07 --> Input Class Initialized
INFO - 2023-04-17 07:03:07 --> Language Class Initialized
INFO - 2023-04-17 07:03:07 --> Language Class Initialized
INFO - 2023-04-17 07:03:07 --> Loader Class Initialized
INFO - 2023-04-17 07:03:07 --> Loader Class Initialized
INFO - 2023-04-17 07:03:07 --> Controller Class Initialized
INFO - 2023-04-17 07:03:07 --> Controller Class Initialized
DEBUG - 2023-04-17 07:03:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 07:03:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:03:07 --> Final output sent to browser
DEBUG - 2023-04-17 07:03:07 --> Total execution time: 0.0051
INFO - 2023-04-17 07:03:07 --> Database Driver Class Initialized
INFO - 2023-04-17 07:03:07 --> Config Class Initialized
INFO - 2023-04-17 07:03:07 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:03:07 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:03:07 --> Utf8 Class Initialized
INFO - 2023-04-17 07:03:07 --> URI Class Initialized
INFO - 2023-04-17 07:03:07 --> Router Class Initialized
INFO - 2023-04-17 07:03:07 --> Output Class Initialized
INFO - 2023-04-17 07:03:07 --> Security Class Initialized
DEBUG - 2023-04-17 07:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:03:07 --> Input Class Initialized
INFO - 2023-04-17 07:03:07 --> Language Class Initialized
INFO - 2023-04-17 07:03:07 --> Loader Class Initialized
INFO - 2023-04-17 07:03:07 --> Controller Class Initialized
DEBUG - 2023-04-17 07:03:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:03:07 --> Database Driver Class Initialized
INFO - 2023-04-17 07:03:07 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:03:07 --> Model "Login_model" initialized
INFO - 2023-04-17 07:03:07 --> Database Driver Class Initialized
INFO - 2023-04-17 07:03:07 --> Final output sent to browser
DEBUG - 2023-04-17 07:03:07 --> Total execution time: 0.0250
INFO - 2023-04-17 07:03:07 --> Config Class Initialized
INFO - 2023-04-17 07:03:07 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:03:07 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:03:07 --> Utf8 Class Initialized
INFO - 2023-04-17 07:03:07 --> URI Class Initialized
INFO - 2023-04-17 07:03:07 --> Router Class Initialized
INFO - 2023-04-17 07:03:07 --> Output Class Initialized
INFO - 2023-04-17 07:03:07 --> Security Class Initialized
DEBUG - 2023-04-17 07:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:03:07 --> Input Class Initialized
INFO - 2023-04-17 07:03:07 --> Language Class Initialized
INFO - 2023-04-17 07:03:07 --> Loader Class Initialized
INFO - 2023-04-17 07:03:07 --> Controller Class Initialized
DEBUG - 2023-04-17 07:03:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:03:07 --> Database Driver Class Initialized
INFO - 2023-04-17 07:03:07 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:03:07 --> Final output sent to browser
DEBUG - 2023-04-17 07:03:07 --> Total execution time: 0.0312
INFO - 2023-04-17 07:03:07 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:03:07 --> Final output sent to browser
DEBUG - 2023-04-17 07:03:07 --> Total execution time: 0.0616
INFO - 2023-04-17 07:12:39 --> Config Class Initialized
INFO - 2023-04-17 07:12:39 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:12:39 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:12:39 --> Utf8 Class Initialized
INFO - 2023-04-17 07:12:39 --> URI Class Initialized
INFO - 2023-04-17 07:12:39 --> Router Class Initialized
INFO - 2023-04-17 07:12:39 --> Output Class Initialized
INFO - 2023-04-17 07:12:39 --> Security Class Initialized
DEBUG - 2023-04-17 07:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:12:39 --> Input Class Initialized
INFO - 2023-04-17 07:12:39 --> Language Class Initialized
INFO - 2023-04-17 07:12:39 --> Loader Class Initialized
INFO - 2023-04-17 07:12:39 --> Controller Class Initialized
DEBUG - 2023-04-17 07:12:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:12:39 --> Database Driver Class Initialized
INFO - 2023-04-17 07:12:39 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:12:39 --> Final output sent to browser
DEBUG - 2023-04-17 07:12:39 --> Total execution time: 0.0152
INFO - 2023-04-17 07:12:39 --> Config Class Initialized
INFO - 2023-04-17 07:12:39 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:12:39 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:12:39 --> Utf8 Class Initialized
INFO - 2023-04-17 07:12:39 --> URI Class Initialized
INFO - 2023-04-17 07:12:39 --> Router Class Initialized
INFO - 2023-04-17 07:12:39 --> Output Class Initialized
INFO - 2023-04-17 07:12:39 --> Security Class Initialized
DEBUG - 2023-04-17 07:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:12:39 --> Input Class Initialized
INFO - 2023-04-17 07:12:39 --> Language Class Initialized
INFO - 2023-04-17 07:12:39 --> Loader Class Initialized
INFO - 2023-04-17 07:12:39 --> Controller Class Initialized
DEBUG - 2023-04-17 07:12:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:12:39 --> Database Driver Class Initialized
INFO - 2023-04-17 07:12:39 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:12:39 --> Final output sent to browser
DEBUG - 2023-04-17 07:12:39 --> Total execution time: 0.0581
INFO - 2023-04-17 07:12:40 --> Config Class Initialized
INFO - 2023-04-17 07:12:40 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:12:40 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:12:40 --> Utf8 Class Initialized
INFO - 2023-04-17 07:12:40 --> URI Class Initialized
INFO - 2023-04-17 07:12:40 --> Router Class Initialized
INFO - 2023-04-17 07:12:40 --> Output Class Initialized
INFO - 2023-04-17 07:12:40 --> Security Class Initialized
DEBUG - 2023-04-17 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:12:40 --> Input Class Initialized
INFO - 2023-04-17 07:12:40 --> Language Class Initialized
INFO - 2023-04-17 07:12:40 --> Loader Class Initialized
INFO - 2023-04-17 07:12:40 --> Controller Class Initialized
DEBUG - 2023-04-17 07:12:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:12:40 --> Database Driver Class Initialized
INFO - 2023-04-17 07:12:40 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:12:40 --> Final output sent to browser
DEBUG - 2023-04-17 07:12:40 --> Total execution time: 0.0231
INFO - 2023-04-17 07:12:40 --> Config Class Initialized
INFO - 2023-04-17 07:12:40 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:12:40 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:12:40 --> Utf8 Class Initialized
INFO - 2023-04-17 07:12:40 --> URI Class Initialized
INFO - 2023-04-17 07:12:40 --> Router Class Initialized
INFO - 2023-04-17 07:12:40 --> Output Class Initialized
INFO - 2023-04-17 07:12:40 --> Security Class Initialized
DEBUG - 2023-04-17 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:12:40 --> Input Class Initialized
INFO - 2023-04-17 07:12:40 --> Language Class Initialized
INFO - 2023-04-17 07:12:40 --> Loader Class Initialized
INFO - 2023-04-17 07:12:40 --> Controller Class Initialized
DEBUG - 2023-04-17 07:12:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:12:40 --> Database Driver Class Initialized
INFO - 2023-04-17 07:12:40 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:12:40 --> Final output sent to browser
DEBUG - 2023-04-17 07:12:40 --> Total execution time: 0.0598
INFO - 2023-04-17 07:12:41 --> Config Class Initialized
INFO - 2023-04-17 07:12:41 --> Config Class Initialized
INFO - 2023-04-17 07:12:41 --> Hooks Class Initialized
INFO - 2023-04-17 07:12:41 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:12:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 07:12:41 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:12:41 --> Utf8 Class Initialized
INFO - 2023-04-17 07:12:41 --> Utf8 Class Initialized
INFO - 2023-04-17 07:12:41 --> URI Class Initialized
INFO - 2023-04-17 07:12:41 --> URI Class Initialized
INFO - 2023-04-17 07:12:41 --> Router Class Initialized
INFO - 2023-04-17 07:12:41 --> Router Class Initialized
INFO - 2023-04-17 07:12:41 --> Output Class Initialized
INFO - 2023-04-17 07:12:41 --> Output Class Initialized
INFO - 2023-04-17 07:12:41 --> Security Class Initialized
INFO - 2023-04-17 07:12:41 --> Security Class Initialized
DEBUG - 2023-04-17 07:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 07:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:12:41 --> Input Class Initialized
INFO - 2023-04-17 07:12:41 --> Input Class Initialized
INFO - 2023-04-17 07:12:41 --> Language Class Initialized
INFO - 2023-04-17 07:12:41 --> Language Class Initialized
INFO - 2023-04-17 07:12:41 --> Loader Class Initialized
INFO - 2023-04-17 07:12:41 --> Loader Class Initialized
INFO - 2023-04-17 07:12:41 --> Controller Class Initialized
INFO - 2023-04-17 07:12:41 --> Controller Class Initialized
DEBUG - 2023-04-17 07:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 07:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:12:41 --> Database Driver Class Initialized
INFO - 2023-04-17 07:12:41 --> Final output sent to browser
DEBUG - 2023-04-17 07:12:41 --> Total execution time: 0.0228
INFO - 2023-04-17 07:12:41 --> Config Class Initialized
INFO - 2023-04-17 07:12:41 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:12:41 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:12:41 --> Utf8 Class Initialized
INFO - 2023-04-17 07:12:41 --> URI Class Initialized
INFO - 2023-04-17 07:12:41 --> Router Class Initialized
INFO - 2023-04-17 07:12:41 --> Output Class Initialized
INFO - 2023-04-17 07:12:41 --> Security Class Initialized
DEBUG - 2023-04-17 07:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:12:41 --> Input Class Initialized
INFO - 2023-04-17 07:12:41 --> Language Class Initialized
INFO - 2023-04-17 07:12:41 --> Loader Class Initialized
INFO - 2023-04-17 07:12:41 --> Controller Class Initialized
DEBUG - 2023-04-17 07:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:12:41 --> Database Driver Class Initialized
INFO - 2023-04-17 07:12:41 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:12:41 --> Model "Login_model" initialized
INFO - 2023-04-17 07:12:41 --> Final output sent to browser
INFO - 2023-04-17 07:12:41 --> Database Driver Class Initialized
DEBUG - 2023-04-17 07:12:41 --> Total execution time: 0.0400
INFO - 2023-04-17 07:12:41 --> Config Class Initialized
INFO - 2023-04-17 07:12:41 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:12:41 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:12:41 --> Utf8 Class Initialized
INFO - 2023-04-17 07:12:41 --> URI Class Initialized
INFO - 2023-04-17 07:12:41 --> Router Class Initialized
INFO - 2023-04-17 07:12:41 --> Output Class Initialized
INFO - 2023-04-17 07:12:41 --> Security Class Initialized
DEBUG - 2023-04-17 07:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:12:41 --> Input Class Initialized
INFO - 2023-04-17 07:12:41 --> Language Class Initialized
INFO - 2023-04-17 07:12:41 --> Loader Class Initialized
INFO - 2023-04-17 07:12:41 --> Controller Class Initialized
DEBUG - 2023-04-17 07:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:12:41 --> Database Driver Class Initialized
INFO - 2023-04-17 07:12:41 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:12:41 --> Final output sent to browser
DEBUG - 2023-04-17 07:12:41 --> Total execution time: 0.0248
INFO - 2023-04-17 07:12:41 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:12:41 --> Final output sent to browser
DEBUG - 2023-04-17 07:12:41 --> Total execution time: 0.0569
INFO - 2023-04-17 07:12:42 --> Config Class Initialized
INFO - 2023-04-17 07:12:42 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:12:42 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:12:42 --> Utf8 Class Initialized
INFO - 2023-04-17 07:12:42 --> URI Class Initialized
INFO - 2023-04-17 07:12:42 --> Router Class Initialized
INFO - 2023-04-17 07:12:42 --> Output Class Initialized
INFO - 2023-04-17 07:12:42 --> Security Class Initialized
DEBUG - 2023-04-17 07:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:12:42 --> Input Class Initialized
INFO - 2023-04-17 07:12:42 --> Language Class Initialized
INFO - 2023-04-17 07:12:42 --> Loader Class Initialized
INFO - 2023-04-17 07:12:42 --> Controller Class Initialized
DEBUG - 2023-04-17 07:12:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:12:42 --> Database Driver Class Initialized
INFO - 2023-04-17 07:12:42 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:12:42 --> Database Driver Class Initialized
INFO - 2023-04-17 07:12:42 --> Model "Login_model" initialized
INFO - 2023-04-17 07:12:42 --> Final output sent to browser
DEBUG - 2023-04-17 07:12:42 --> Total execution time: 0.0406
INFO - 2023-04-17 07:12:42 --> Config Class Initialized
INFO - 2023-04-17 07:12:42 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:12:42 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:12:42 --> Utf8 Class Initialized
INFO - 2023-04-17 07:12:42 --> URI Class Initialized
INFO - 2023-04-17 07:12:42 --> Router Class Initialized
INFO - 2023-04-17 07:12:42 --> Output Class Initialized
INFO - 2023-04-17 07:12:42 --> Security Class Initialized
DEBUG - 2023-04-17 07:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:12:42 --> Input Class Initialized
INFO - 2023-04-17 07:12:42 --> Language Class Initialized
INFO - 2023-04-17 07:12:42 --> Loader Class Initialized
INFO - 2023-04-17 07:12:42 --> Controller Class Initialized
DEBUG - 2023-04-17 07:12:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:12:42 --> Database Driver Class Initialized
INFO - 2023-04-17 07:12:42 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:12:42 --> Database Driver Class Initialized
INFO - 2023-04-17 07:12:42 --> Model "Login_model" initialized
INFO - 2023-04-17 07:12:42 --> Final output sent to browser
DEBUG - 2023-04-17 07:12:42 --> Total execution time: 0.0328
INFO - 2023-04-17 07:19:44 --> Config Class Initialized
INFO - 2023-04-17 07:19:44 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:44 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:44 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:44 --> URI Class Initialized
INFO - 2023-04-17 07:19:44 --> Router Class Initialized
INFO - 2023-04-17 07:19:44 --> Output Class Initialized
INFO - 2023-04-17 07:19:44 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:44 --> Input Class Initialized
INFO - 2023-04-17 07:19:44 --> Language Class Initialized
INFO - 2023-04-17 07:19:44 --> Loader Class Initialized
INFO - 2023-04-17 07:19:44 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:44 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:44 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:44 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:44 --> Model "Login_model" initialized
INFO - 2023-04-17 07:19:44 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:44 --> Total execution time: 0.1695
INFO - 2023-04-17 07:19:44 --> Config Class Initialized
INFO - 2023-04-17 07:19:44 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:44 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:44 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:44 --> URI Class Initialized
INFO - 2023-04-17 07:19:44 --> Router Class Initialized
INFO - 2023-04-17 07:19:44 --> Output Class Initialized
INFO - 2023-04-17 07:19:44 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:44 --> Input Class Initialized
INFO - 2023-04-17 07:19:44 --> Language Class Initialized
INFO - 2023-04-17 07:19:44 --> Loader Class Initialized
INFO - 2023-04-17 07:19:44 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:44 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:44 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:44 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:44 --> Model "Login_model" initialized
INFO - 2023-04-17 07:19:44 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:44 --> Total execution time: 0.0451
INFO - 2023-04-17 07:19:51 --> Config Class Initialized
INFO - 2023-04-17 07:19:51 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:51 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:51 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:51 --> URI Class Initialized
INFO - 2023-04-17 07:19:51 --> Router Class Initialized
INFO - 2023-04-17 07:19:51 --> Output Class Initialized
INFO - 2023-04-17 07:19:51 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:51 --> Input Class Initialized
INFO - 2023-04-17 07:19:51 --> Language Class Initialized
INFO - 2023-04-17 07:19:51 --> Loader Class Initialized
INFO - 2023-04-17 07:19:51 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:51 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:51 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:51 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:51 --> Total execution time: 0.0133
INFO - 2023-04-17 07:19:51 --> Config Class Initialized
INFO - 2023-04-17 07:19:51 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:51 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:51 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:51 --> URI Class Initialized
INFO - 2023-04-17 07:19:51 --> Router Class Initialized
INFO - 2023-04-17 07:19:51 --> Output Class Initialized
INFO - 2023-04-17 07:19:51 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:51 --> Input Class Initialized
INFO - 2023-04-17 07:19:51 --> Language Class Initialized
INFO - 2023-04-17 07:19:51 --> Loader Class Initialized
INFO - 2023-04-17 07:19:51 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:51 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:51 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:51 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:51 --> Model "Login_model" initialized
INFO - 2023-04-17 07:19:51 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:51 --> Total execution time: 0.0206
INFO - 2023-04-17 07:19:51 --> Config Class Initialized
INFO - 2023-04-17 07:19:51 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:51 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:51 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:51 --> URI Class Initialized
INFO - 2023-04-17 07:19:51 --> Router Class Initialized
INFO - 2023-04-17 07:19:51 --> Output Class Initialized
INFO - 2023-04-17 07:19:51 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:51 --> Input Class Initialized
INFO - 2023-04-17 07:19:51 --> Language Class Initialized
INFO - 2023-04-17 07:19:51 --> Loader Class Initialized
INFO - 2023-04-17 07:19:51 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:51 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:51 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:51 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:51 --> Total execution time: 0.0540
INFO - 2023-04-17 07:19:51 --> Config Class Initialized
INFO - 2023-04-17 07:19:51 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:51 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:51 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:51 --> URI Class Initialized
INFO - 2023-04-17 07:19:51 --> Router Class Initialized
INFO - 2023-04-17 07:19:51 --> Output Class Initialized
INFO - 2023-04-17 07:19:51 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:51 --> Input Class Initialized
INFO - 2023-04-17 07:19:51 --> Language Class Initialized
INFO - 2023-04-17 07:19:51 --> Loader Class Initialized
INFO - 2023-04-17 07:19:51 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:51 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:51 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:51 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:51 --> Model "Login_model" initialized
INFO - 2023-04-17 07:19:51 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:51 --> Total execution time: 0.0220
INFO - 2023-04-17 07:19:52 --> Config Class Initialized
INFO - 2023-04-17 07:19:52 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:52 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:52 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:52 --> URI Class Initialized
INFO - 2023-04-17 07:19:52 --> Router Class Initialized
INFO - 2023-04-17 07:19:52 --> Output Class Initialized
INFO - 2023-04-17 07:19:52 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:52 --> Input Class Initialized
INFO - 2023-04-17 07:19:52 --> Language Class Initialized
INFO - 2023-04-17 07:19:52 --> Loader Class Initialized
INFO - 2023-04-17 07:19:52 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:52 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:52 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:52 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:52 --> Total execution time: 0.0177
INFO - 2023-04-17 07:19:52 --> Config Class Initialized
INFO - 2023-04-17 07:19:52 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:52 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:52 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:52 --> URI Class Initialized
INFO - 2023-04-17 07:19:52 --> Router Class Initialized
INFO - 2023-04-17 07:19:52 --> Output Class Initialized
INFO - 2023-04-17 07:19:52 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:52 --> Input Class Initialized
INFO - 2023-04-17 07:19:52 --> Language Class Initialized
INFO - 2023-04-17 07:19:52 --> Loader Class Initialized
INFO - 2023-04-17 07:19:52 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:52 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:52 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:52 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:52 --> Total execution time: 0.0589
INFO - 2023-04-17 07:19:53 --> Config Class Initialized
INFO - 2023-04-17 07:19:53 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:53 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:53 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:53 --> URI Class Initialized
INFO - 2023-04-17 07:19:53 --> Router Class Initialized
INFO - 2023-04-17 07:19:53 --> Output Class Initialized
INFO - 2023-04-17 07:19:53 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:53 --> Input Class Initialized
INFO - 2023-04-17 07:19:53 --> Language Class Initialized
INFO - 2023-04-17 07:19:53 --> Loader Class Initialized
INFO - 2023-04-17 07:19:53 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:53 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:53 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:53 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:53 --> Model "Login_model" initialized
INFO - 2023-04-17 07:19:54 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:54 --> Total execution time: 0.0308
INFO - 2023-04-17 07:19:54 --> Config Class Initialized
INFO - 2023-04-17 07:19:54 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:54 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:54 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:54 --> URI Class Initialized
INFO - 2023-04-17 07:19:54 --> Router Class Initialized
INFO - 2023-04-17 07:19:54 --> Output Class Initialized
INFO - 2023-04-17 07:19:54 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:54 --> Input Class Initialized
INFO - 2023-04-17 07:19:54 --> Language Class Initialized
INFO - 2023-04-17 07:19:54 --> Loader Class Initialized
INFO - 2023-04-17 07:19:54 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:54 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:54 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:54 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:54 --> Model "Login_model" initialized
INFO - 2023-04-17 07:19:54 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:54 --> Total execution time: 0.0254
INFO - 2023-04-17 07:19:54 --> Config Class Initialized
INFO - 2023-04-17 07:19:54 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:54 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:54 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:54 --> URI Class Initialized
INFO - 2023-04-17 07:19:54 --> Router Class Initialized
INFO - 2023-04-17 07:19:54 --> Output Class Initialized
INFO - 2023-04-17 07:19:54 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:54 --> Input Class Initialized
INFO - 2023-04-17 07:19:54 --> Language Class Initialized
INFO - 2023-04-17 07:19:54 --> Loader Class Initialized
INFO - 2023-04-17 07:19:54 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:54 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:54 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:54 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:54 --> Model "Login_model" initialized
INFO - 2023-04-17 07:19:54 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:54 --> Total execution time: 0.0413
INFO - 2023-04-17 07:19:54 --> Config Class Initialized
INFO - 2023-04-17 07:19:54 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:54 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:54 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:54 --> URI Class Initialized
INFO - 2023-04-17 07:19:54 --> Router Class Initialized
INFO - 2023-04-17 07:19:54 --> Output Class Initialized
INFO - 2023-04-17 07:19:54 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:54 --> Input Class Initialized
INFO - 2023-04-17 07:19:54 --> Language Class Initialized
INFO - 2023-04-17 07:19:54 --> Loader Class Initialized
INFO - 2023-04-17 07:19:54 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:54 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:54 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:54 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:54 --> Model "Login_model" initialized
INFO - 2023-04-17 07:19:54 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:54 --> Total execution time: 0.0410
INFO - 2023-04-17 07:19:56 --> Config Class Initialized
INFO - 2023-04-17 07:19:56 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:56 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:56 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:56 --> URI Class Initialized
INFO - 2023-04-17 07:19:56 --> Router Class Initialized
INFO - 2023-04-17 07:19:56 --> Output Class Initialized
INFO - 2023-04-17 07:19:56 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:56 --> Input Class Initialized
INFO - 2023-04-17 07:19:56 --> Language Class Initialized
INFO - 2023-04-17 07:19:56 --> Loader Class Initialized
INFO - 2023-04-17 07:19:56 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:56 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:56 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:56 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:56 --> Total execution time: 0.0313
INFO - 2023-04-17 07:19:56 --> Config Class Initialized
INFO - 2023-04-17 07:19:56 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:56 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:56 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:56 --> URI Class Initialized
INFO - 2023-04-17 07:19:56 --> Router Class Initialized
INFO - 2023-04-17 07:19:56 --> Output Class Initialized
INFO - 2023-04-17 07:19:56 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:56 --> Input Class Initialized
INFO - 2023-04-17 07:19:56 --> Language Class Initialized
INFO - 2023-04-17 07:19:56 --> Loader Class Initialized
INFO - 2023-04-17 07:19:56 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:56 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:56 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:56 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:56 --> Total execution time: 0.0297
INFO - 2023-04-17 07:19:59 --> Config Class Initialized
INFO - 2023-04-17 07:19:59 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:59 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:59 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:59 --> URI Class Initialized
INFO - 2023-04-17 07:19:59 --> Router Class Initialized
INFO - 2023-04-17 07:19:59 --> Output Class Initialized
INFO - 2023-04-17 07:19:59 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:59 --> Input Class Initialized
INFO - 2023-04-17 07:19:59 --> Language Class Initialized
INFO - 2023-04-17 07:19:59 --> Loader Class Initialized
INFO - 2023-04-17 07:19:59 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:59 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:59 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:59 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:59 --> Total execution time: 0.0154
INFO - 2023-04-17 07:19:59 --> Config Class Initialized
INFO - 2023-04-17 07:19:59 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:19:59 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:19:59 --> Utf8 Class Initialized
INFO - 2023-04-17 07:19:59 --> URI Class Initialized
INFO - 2023-04-17 07:19:59 --> Router Class Initialized
INFO - 2023-04-17 07:19:59 --> Output Class Initialized
INFO - 2023-04-17 07:19:59 --> Security Class Initialized
DEBUG - 2023-04-17 07:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:19:59 --> Input Class Initialized
INFO - 2023-04-17 07:19:59 --> Language Class Initialized
INFO - 2023-04-17 07:19:59 --> Loader Class Initialized
INFO - 2023-04-17 07:19:59 --> Controller Class Initialized
DEBUG - 2023-04-17 07:19:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:19:59 --> Database Driver Class Initialized
INFO - 2023-04-17 07:19:59 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:19:59 --> Final output sent to browser
DEBUG - 2023-04-17 07:19:59 --> Total execution time: 0.0157
INFO - 2023-04-17 07:20:02 --> Config Class Initialized
INFO - 2023-04-17 07:20:02 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:02 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:02 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:02 --> URI Class Initialized
INFO - 2023-04-17 07:20:02 --> Router Class Initialized
INFO - 2023-04-17 07:20:02 --> Output Class Initialized
INFO - 2023-04-17 07:20:02 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:02 --> Input Class Initialized
INFO - 2023-04-17 07:20:02 --> Language Class Initialized
INFO - 2023-04-17 07:20:02 --> Loader Class Initialized
INFO - 2023-04-17 07:20:02 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:02 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:02 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:02 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:02 --> Total execution time: 0.0422
INFO - 2023-04-17 07:20:02 --> Config Class Initialized
INFO - 2023-04-17 07:20:02 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:02 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:02 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:02 --> URI Class Initialized
INFO - 2023-04-17 07:20:02 --> Router Class Initialized
INFO - 2023-04-17 07:20:02 --> Output Class Initialized
INFO - 2023-04-17 07:20:02 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:02 --> Input Class Initialized
INFO - 2023-04-17 07:20:02 --> Language Class Initialized
INFO - 2023-04-17 07:20:02 --> Loader Class Initialized
INFO - 2023-04-17 07:20:02 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:02 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:02 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:02 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:02 --> Total execution time: 0.0187
INFO - 2023-04-17 07:20:03 --> Config Class Initialized
INFO - 2023-04-17 07:20:03 --> Config Class Initialized
INFO - 2023-04-17 07:20:03 --> Hooks Class Initialized
INFO - 2023-04-17 07:20:03 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:03 --> Utf8 Class Initialized
DEBUG - 2023-04-17 07:20:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:03 --> URI Class Initialized
INFO - 2023-04-17 07:20:03 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:03 --> Router Class Initialized
INFO - 2023-04-17 07:20:03 --> URI Class Initialized
INFO - 2023-04-17 07:20:03 --> Output Class Initialized
INFO - 2023-04-17 07:20:03 --> Security Class Initialized
INFO - 2023-04-17 07:20:03 --> Router Class Initialized
DEBUG - 2023-04-17 07:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:03 --> Output Class Initialized
INFO - 2023-04-17 07:20:03 --> Input Class Initialized
INFO - 2023-04-17 07:20:03 --> Security Class Initialized
INFO - 2023-04-17 07:20:03 --> Language Class Initialized
DEBUG - 2023-04-17 07:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:03 --> Input Class Initialized
INFO - 2023-04-17 07:20:03 --> Language Class Initialized
INFO - 2023-04-17 07:20:03 --> Loader Class Initialized
INFO - 2023-04-17 07:20:03 --> Loader Class Initialized
INFO - 2023-04-17 07:20:03 --> Controller Class Initialized
INFO - 2023-04-17 07:20:03 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 07:20:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:03 --> Final output sent to browser
INFO - 2023-04-17 07:20:03 --> Database Driver Class Initialized
DEBUG - 2023-04-17 07:20:03 --> Total execution time: 0.0038
INFO - 2023-04-17 07:20:03 --> Config Class Initialized
INFO - 2023-04-17 07:20:03 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:03 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:03 --> URI Class Initialized
INFO - 2023-04-17 07:20:03 --> Router Class Initialized
INFO - 2023-04-17 07:20:03 --> Output Class Initialized
INFO - 2023-04-17 07:20:03 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:03 --> Input Class Initialized
INFO - 2023-04-17 07:20:03 --> Language Class Initialized
INFO - 2023-04-17 07:20:03 --> Loader Class Initialized
INFO - 2023-04-17 07:20:03 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:03 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:03 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:03 --> Model "Login_model" initialized
INFO - 2023-04-17 07:20:03 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:03 --> Total execution time: 0.0216
INFO - 2023-04-17 07:20:03 --> Config Class Initialized
INFO - 2023-04-17 07:20:03 --> Hooks Class Initialized
INFO - 2023-04-17 07:20:03 --> Database Driver Class Initialized
DEBUG - 2023-04-17 07:20:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:03 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:03 --> URI Class Initialized
INFO - 2023-04-17 07:20:03 --> Router Class Initialized
INFO - 2023-04-17 07:20:03 --> Output Class Initialized
INFO - 2023-04-17 07:20:03 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:03 --> Input Class Initialized
INFO - 2023-04-17 07:20:03 --> Language Class Initialized
INFO - 2023-04-17 07:20:03 --> Loader Class Initialized
INFO - 2023-04-17 07:20:03 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:03 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:03 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:03 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:03 --> Total execution time: 0.0292
INFO - 2023-04-17 07:20:03 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:03 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:03 --> Total execution time: 0.0160
INFO - 2023-04-17 07:20:06 --> Config Class Initialized
INFO - 2023-04-17 07:20:06 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:06 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:06 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:06 --> URI Class Initialized
INFO - 2023-04-17 07:20:06 --> Router Class Initialized
INFO - 2023-04-17 07:20:06 --> Output Class Initialized
INFO - 2023-04-17 07:20:06 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:06 --> Input Class Initialized
INFO - 2023-04-17 07:20:06 --> Language Class Initialized
INFO - 2023-04-17 07:20:06 --> Loader Class Initialized
INFO - 2023-04-17 07:20:06 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:06 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:06 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:06 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:06 --> Total execution time: 0.0149
INFO - 2023-04-17 07:20:06 --> Config Class Initialized
INFO - 2023-04-17 07:20:06 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:06 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:06 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:06 --> URI Class Initialized
INFO - 2023-04-17 07:20:06 --> Router Class Initialized
INFO - 2023-04-17 07:20:06 --> Output Class Initialized
INFO - 2023-04-17 07:20:06 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:06 --> Input Class Initialized
INFO - 2023-04-17 07:20:06 --> Language Class Initialized
INFO - 2023-04-17 07:20:06 --> Loader Class Initialized
INFO - 2023-04-17 07:20:06 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:06 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:06 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:06 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:06 --> Total execution time: 0.0127
INFO - 2023-04-17 07:20:08 --> Config Class Initialized
INFO - 2023-04-17 07:20:08 --> Config Class Initialized
INFO - 2023-04-17 07:20:08 --> Hooks Class Initialized
INFO - 2023-04-17 07:20:08 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:08 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:08 --> Utf8 Class Initialized
DEBUG - 2023-04-17 07:20:08 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:08 --> URI Class Initialized
INFO - 2023-04-17 07:20:08 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:08 --> Router Class Initialized
INFO - 2023-04-17 07:20:08 --> URI Class Initialized
INFO - 2023-04-17 07:20:08 --> Output Class Initialized
INFO - 2023-04-17 07:20:08 --> Router Class Initialized
INFO - 2023-04-17 07:20:08 --> Security Class Initialized
INFO - 2023-04-17 07:20:08 --> Output Class Initialized
DEBUG - 2023-04-17 07:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:08 --> Input Class Initialized
INFO - 2023-04-17 07:20:08 --> Security Class Initialized
INFO - 2023-04-17 07:20:08 --> Language Class Initialized
DEBUG - 2023-04-17 07:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:08 --> Input Class Initialized
INFO - 2023-04-17 07:20:08 --> Loader Class Initialized
INFO - 2023-04-17 07:20:08 --> Language Class Initialized
INFO - 2023-04-17 07:20:08 --> Controller Class Initialized
INFO - 2023-04-17 07:20:08 --> Loader Class Initialized
DEBUG - 2023-04-17 07:20:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:08 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:08 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:08 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:08 --> Model "Login_model" initialized
INFO - 2023-04-17 07:20:08 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:08 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:08 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:08 --> Total execution time: 0.0184
INFO - 2023-04-17 07:20:08 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:08 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:08 --> Total execution time: 0.0287
INFO - 2023-04-17 07:20:10 --> Config Class Initialized
INFO - 2023-04-17 07:20:10 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:10 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:10 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:10 --> URI Class Initialized
INFO - 2023-04-17 07:20:10 --> Router Class Initialized
INFO - 2023-04-17 07:20:10 --> Output Class Initialized
INFO - 2023-04-17 07:20:10 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:10 --> Input Class Initialized
INFO - 2023-04-17 07:20:10 --> Language Class Initialized
INFO - 2023-04-17 07:20:10 --> Loader Class Initialized
INFO - 2023-04-17 07:20:10 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:10 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:10 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:10 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:10 --> Model "Login_model" initialized
INFO - 2023-04-17 07:20:10 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:10 --> Total execution time: 0.0635
INFO - 2023-04-17 07:20:10 --> Config Class Initialized
INFO - 2023-04-17 07:20:10 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:10 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:10 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:10 --> URI Class Initialized
INFO - 2023-04-17 07:20:10 --> Router Class Initialized
INFO - 2023-04-17 07:20:10 --> Output Class Initialized
INFO - 2023-04-17 07:20:10 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:10 --> Input Class Initialized
INFO - 2023-04-17 07:20:10 --> Language Class Initialized
INFO - 2023-04-17 07:20:10 --> Loader Class Initialized
INFO - 2023-04-17 07:20:10 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:10 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:10 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:10 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:10 --> Model "Login_model" initialized
INFO - 2023-04-17 07:20:10 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:10 --> Total execution time: 0.0429
INFO - 2023-04-17 07:20:12 --> Config Class Initialized
INFO - 2023-04-17 07:20:12 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:12 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:12 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:12 --> URI Class Initialized
INFO - 2023-04-17 07:20:12 --> Router Class Initialized
INFO - 2023-04-17 07:20:12 --> Output Class Initialized
INFO - 2023-04-17 07:20:12 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:12 --> Input Class Initialized
INFO - 2023-04-17 07:20:12 --> Language Class Initialized
INFO - 2023-04-17 07:20:12 --> Loader Class Initialized
INFO - 2023-04-17 07:20:12 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:12 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:12 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:12 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:12 --> Total execution time: 0.0147
INFO - 2023-04-17 07:20:12 --> Config Class Initialized
INFO - 2023-04-17 07:20:12 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:12 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:12 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:12 --> URI Class Initialized
INFO - 2023-04-17 07:20:12 --> Router Class Initialized
INFO - 2023-04-17 07:20:12 --> Output Class Initialized
INFO - 2023-04-17 07:20:12 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:12 --> Input Class Initialized
INFO - 2023-04-17 07:20:12 --> Language Class Initialized
INFO - 2023-04-17 07:20:12 --> Loader Class Initialized
INFO - 2023-04-17 07:20:12 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:12 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:12 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:12 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:12 --> Total execution time: 0.1297
INFO - 2023-04-17 07:20:12 --> Config Class Initialized
INFO - 2023-04-17 07:20:12 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:12 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:12 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:12 --> URI Class Initialized
INFO - 2023-04-17 07:20:12 --> Router Class Initialized
INFO - 2023-04-17 07:20:12 --> Output Class Initialized
INFO - 2023-04-17 07:20:12 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:12 --> Input Class Initialized
INFO - 2023-04-17 07:20:12 --> Language Class Initialized
INFO - 2023-04-17 07:20:12 --> Loader Class Initialized
INFO - 2023-04-17 07:20:12 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:12 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:12 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:12 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:12 --> Total execution time: 0.0416
INFO - 2023-04-17 07:20:12 --> Config Class Initialized
INFO - 2023-04-17 07:20:12 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:12 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:12 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:12 --> URI Class Initialized
INFO - 2023-04-17 07:20:12 --> Router Class Initialized
INFO - 2023-04-17 07:20:12 --> Output Class Initialized
INFO - 2023-04-17 07:20:12 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:12 --> Input Class Initialized
INFO - 2023-04-17 07:20:12 --> Language Class Initialized
INFO - 2023-04-17 07:20:12 --> Loader Class Initialized
INFO - 2023-04-17 07:20:12 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:12 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:12 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:12 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:12 --> Total execution time: 0.0112
INFO - 2023-04-17 07:20:42 --> Config Class Initialized
INFO - 2023-04-17 07:20:42 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:42 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:42 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:42 --> URI Class Initialized
INFO - 2023-04-17 07:20:42 --> Router Class Initialized
INFO - 2023-04-17 07:20:42 --> Output Class Initialized
INFO - 2023-04-17 07:20:42 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:42 --> Input Class Initialized
INFO - 2023-04-17 07:20:42 --> Language Class Initialized
INFO - 2023-04-17 07:20:42 --> Loader Class Initialized
INFO - 2023-04-17 07:20:42 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:42 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:42 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:42 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:42 --> Total execution time: 0.0133
INFO - 2023-04-17 07:20:42 --> Config Class Initialized
INFO - 2023-04-17 07:20:42 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:42 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:42 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:42 --> URI Class Initialized
INFO - 2023-04-17 07:20:42 --> Router Class Initialized
INFO - 2023-04-17 07:20:42 --> Output Class Initialized
INFO - 2023-04-17 07:20:42 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:42 --> Input Class Initialized
INFO - 2023-04-17 07:20:42 --> Language Class Initialized
INFO - 2023-04-17 07:20:42 --> Loader Class Initialized
INFO - 2023-04-17 07:20:42 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:42 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:42 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:42 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:42 --> Model "Login_model" initialized
INFO - 2023-04-17 07:20:42 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:42 --> Total execution time: 0.0313
INFO - 2023-04-17 07:20:42 --> Config Class Initialized
INFO - 2023-04-17 07:20:42 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:42 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:42 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:42 --> URI Class Initialized
INFO - 2023-04-17 07:20:42 --> Router Class Initialized
INFO - 2023-04-17 07:20:42 --> Output Class Initialized
INFO - 2023-04-17 07:20:42 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:42 --> Input Class Initialized
INFO - 2023-04-17 07:20:42 --> Language Class Initialized
INFO - 2023-04-17 07:20:42 --> Loader Class Initialized
INFO - 2023-04-17 07:20:42 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:42 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:42 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:42 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:42 --> Total execution time: 0.0144
INFO - 2023-04-17 07:20:42 --> Config Class Initialized
INFO - 2023-04-17 07:20:42 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:42 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:42 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:42 --> URI Class Initialized
INFO - 2023-04-17 07:20:42 --> Router Class Initialized
INFO - 2023-04-17 07:20:42 --> Output Class Initialized
INFO - 2023-04-17 07:20:42 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:42 --> Input Class Initialized
INFO - 2023-04-17 07:20:42 --> Language Class Initialized
INFO - 2023-04-17 07:20:42 --> Loader Class Initialized
INFO - 2023-04-17 07:20:42 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:42 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:42 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:42 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:42 --> Total execution time: 0.5352
INFO - 2023-04-17 07:20:47 --> Config Class Initialized
INFO - 2023-04-17 07:20:47 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:47 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:47 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:47 --> URI Class Initialized
INFO - 2023-04-17 07:20:47 --> Router Class Initialized
INFO - 2023-04-17 07:20:47 --> Output Class Initialized
INFO - 2023-04-17 07:20:47 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:47 --> Input Class Initialized
INFO - 2023-04-17 07:20:47 --> Language Class Initialized
INFO - 2023-04-17 07:20:47 --> Loader Class Initialized
INFO - 2023-04-17 07:20:47 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:47 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:47 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:47 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:47 --> Total execution time: 0.0185
INFO - 2023-04-17 07:20:52 --> Config Class Initialized
INFO - 2023-04-17 07:20:52 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:52 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:52 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:52 --> URI Class Initialized
INFO - 2023-04-17 07:20:52 --> Router Class Initialized
INFO - 2023-04-17 07:20:52 --> Output Class Initialized
INFO - 2023-04-17 07:20:52 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:52 --> Input Class Initialized
INFO - 2023-04-17 07:20:52 --> Language Class Initialized
INFO - 2023-04-17 07:20:52 --> Loader Class Initialized
INFO - 2023-04-17 07:20:52 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:52 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:52 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:52 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:52 --> Total execution time: 0.0158
INFO - 2023-04-17 07:20:52 --> Config Class Initialized
INFO - 2023-04-17 07:20:52 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:52 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:52 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:52 --> URI Class Initialized
INFO - 2023-04-17 07:20:52 --> Router Class Initialized
INFO - 2023-04-17 07:20:52 --> Output Class Initialized
INFO - 2023-04-17 07:20:52 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:52 --> Input Class Initialized
INFO - 2023-04-17 07:20:52 --> Language Class Initialized
INFO - 2023-04-17 07:20:52 --> Loader Class Initialized
INFO - 2023-04-17 07:20:52 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:52 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:52 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:52 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:52 --> Total execution time: 0.0180
INFO - 2023-04-17 07:20:57 --> Config Class Initialized
INFO - 2023-04-17 07:20:57 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:20:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:20:57 --> Utf8 Class Initialized
INFO - 2023-04-17 07:20:57 --> URI Class Initialized
INFO - 2023-04-17 07:20:57 --> Router Class Initialized
INFO - 2023-04-17 07:20:57 --> Output Class Initialized
INFO - 2023-04-17 07:20:57 --> Security Class Initialized
DEBUG - 2023-04-17 07:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:20:57 --> Input Class Initialized
INFO - 2023-04-17 07:20:57 --> Language Class Initialized
INFO - 2023-04-17 07:20:57 --> Loader Class Initialized
INFO - 2023-04-17 07:20:57 --> Controller Class Initialized
DEBUG - 2023-04-17 07:20:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:20:57 --> Database Driver Class Initialized
INFO - 2023-04-17 07:20:57 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:20:57 --> Final output sent to browser
DEBUG - 2023-04-17 07:20:57 --> Total execution time: 0.0183
INFO - 2023-04-17 07:21:02 --> Config Class Initialized
INFO - 2023-04-17 07:21:02 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:02 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:02 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:02 --> URI Class Initialized
INFO - 2023-04-17 07:21:02 --> Router Class Initialized
INFO - 2023-04-17 07:21:02 --> Output Class Initialized
INFO - 2023-04-17 07:21:02 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:02 --> Input Class Initialized
INFO - 2023-04-17 07:21:02 --> Language Class Initialized
INFO - 2023-04-17 07:21:02 --> Loader Class Initialized
INFO - 2023-04-17 07:21:02 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:02 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:02 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:02 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:02 --> Total execution time: 0.0143
INFO - 2023-04-17 07:21:02 --> Config Class Initialized
INFO - 2023-04-17 07:21:02 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:02 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:02 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:02 --> URI Class Initialized
INFO - 2023-04-17 07:21:02 --> Router Class Initialized
INFO - 2023-04-17 07:21:02 --> Output Class Initialized
INFO - 2023-04-17 07:21:02 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:02 --> Input Class Initialized
INFO - 2023-04-17 07:21:02 --> Language Class Initialized
INFO - 2023-04-17 07:21:02 --> Loader Class Initialized
INFO - 2023-04-17 07:21:02 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:02 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:02 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:02 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:02 --> Total execution time: 0.0244
INFO - 2023-04-17 07:21:07 --> Config Class Initialized
INFO - 2023-04-17 07:21:07 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:07 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:07 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:07 --> URI Class Initialized
INFO - 2023-04-17 07:21:07 --> Router Class Initialized
INFO - 2023-04-17 07:21:07 --> Output Class Initialized
INFO - 2023-04-17 07:21:07 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:07 --> Input Class Initialized
INFO - 2023-04-17 07:21:07 --> Language Class Initialized
INFO - 2023-04-17 07:21:07 --> Loader Class Initialized
INFO - 2023-04-17 07:21:07 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:07 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:07 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:07 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:07 --> Total execution time: 0.0165
INFO - 2023-04-17 07:21:12 --> Config Class Initialized
INFO - 2023-04-17 07:21:12 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:12 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:12 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:12 --> URI Class Initialized
INFO - 2023-04-17 07:21:12 --> Router Class Initialized
INFO - 2023-04-17 07:21:12 --> Output Class Initialized
INFO - 2023-04-17 07:21:12 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:12 --> Input Class Initialized
INFO - 2023-04-17 07:21:12 --> Language Class Initialized
INFO - 2023-04-17 07:21:12 --> Loader Class Initialized
INFO - 2023-04-17 07:21:12 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:12 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:12 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:12 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:12 --> Total execution time: 0.0130
INFO - 2023-04-17 07:21:12 --> Config Class Initialized
INFO - 2023-04-17 07:21:12 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:12 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:12 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:12 --> URI Class Initialized
INFO - 2023-04-17 07:21:12 --> Router Class Initialized
INFO - 2023-04-17 07:21:12 --> Output Class Initialized
INFO - 2023-04-17 07:21:12 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:12 --> Input Class Initialized
INFO - 2023-04-17 07:21:12 --> Language Class Initialized
INFO - 2023-04-17 07:21:12 --> Loader Class Initialized
INFO - 2023-04-17 07:21:12 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:12 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:12 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:12 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:12 --> Total execution time: 0.0166
INFO - 2023-04-17 07:21:17 --> Config Class Initialized
INFO - 2023-04-17 07:21:17 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:17 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:17 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:17 --> URI Class Initialized
INFO - 2023-04-17 07:21:17 --> Router Class Initialized
INFO - 2023-04-17 07:21:17 --> Output Class Initialized
INFO - 2023-04-17 07:21:17 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:17 --> Input Class Initialized
INFO - 2023-04-17 07:21:17 --> Language Class Initialized
INFO - 2023-04-17 07:21:17 --> Loader Class Initialized
INFO - 2023-04-17 07:21:17 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:17 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:17 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:17 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:17 --> Total execution time: 0.0182
INFO - 2023-04-17 07:21:22 --> Config Class Initialized
INFO - 2023-04-17 07:21:22 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:22 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:22 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:22 --> URI Class Initialized
INFO - 2023-04-17 07:21:22 --> Router Class Initialized
INFO - 2023-04-17 07:21:22 --> Output Class Initialized
INFO - 2023-04-17 07:21:22 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:22 --> Input Class Initialized
INFO - 2023-04-17 07:21:22 --> Language Class Initialized
INFO - 2023-04-17 07:21:22 --> Loader Class Initialized
INFO - 2023-04-17 07:21:22 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:22 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:22 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:22 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:22 --> Total execution time: 0.0143
INFO - 2023-04-17 07:21:22 --> Config Class Initialized
INFO - 2023-04-17 07:21:22 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:22 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:22 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:22 --> URI Class Initialized
INFO - 2023-04-17 07:21:22 --> Router Class Initialized
INFO - 2023-04-17 07:21:22 --> Output Class Initialized
INFO - 2023-04-17 07:21:22 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:22 --> Input Class Initialized
INFO - 2023-04-17 07:21:22 --> Language Class Initialized
INFO - 2023-04-17 07:21:22 --> Loader Class Initialized
INFO - 2023-04-17 07:21:22 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:22 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:22 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:22 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:22 --> Total execution time: 0.0135
INFO - 2023-04-17 07:21:27 --> Config Class Initialized
INFO - 2023-04-17 07:21:27 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:27 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:27 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:27 --> URI Class Initialized
INFO - 2023-04-17 07:21:27 --> Router Class Initialized
INFO - 2023-04-17 07:21:27 --> Output Class Initialized
INFO - 2023-04-17 07:21:27 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:27 --> Input Class Initialized
INFO - 2023-04-17 07:21:27 --> Language Class Initialized
INFO - 2023-04-17 07:21:27 --> Loader Class Initialized
INFO - 2023-04-17 07:21:27 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:27 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:27 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:27 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:27 --> Total execution time: 0.0167
INFO - 2023-04-17 07:21:32 --> Config Class Initialized
INFO - 2023-04-17 07:21:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:32 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:32 --> URI Class Initialized
INFO - 2023-04-17 07:21:32 --> Router Class Initialized
INFO - 2023-04-17 07:21:32 --> Output Class Initialized
INFO - 2023-04-17 07:21:32 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:32 --> Input Class Initialized
INFO - 2023-04-17 07:21:32 --> Language Class Initialized
INFO - 2023-04-17 07:21:32 --> Loader Class Initialized
INFO - 2023-04-17 07:21:32 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:32 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:32 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:32 --> Total execution time: 0.0183
INFO - 2023-04-17 07:21:32 --> Config Class Initialized
INFO - 2023-04-17 07:21:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:32 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:32 --> URI Class Initialized
INFO - 2023-04-17 07:21:32 --> Router Class Initialized
INFO - 2023-04-17 07:21:32 --> Output Class Initialized
INFO - 2023-04-17 07:21:32 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:32 --> Input Class Initialized
INFO - 2023-04-17 07:21:32 --> Language Class Initialized
INFO - 2023-04-17 07:21:32 --> Loader Class Initialized
INFO - 2023-04-17 07:21:32 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:32 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:32 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:32 --> Total execution time: 0.0165
INFO - 2023-04-17 07:21:37 --> Config Class Initialized
INFO - 2023-04-17 07:21:37 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:37 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:37 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:37 --> URI Class Initialized
INFO - 2023-04-17 07:21:37 --> Router Class Initialized
INFO - 2023-04-17 07:21:37 --> Output Class Initialized
INFO - 2023-04-17 07:21:37 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:37 --> Input Class Initialized
INFO - 2023-04-17 07:21:37 --> Language Class Initialized
INFO - 2023-04-17 07:21:37 --> Loader Class Initialized
INFO - 2023-04-17 07:21:37 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:37 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:37 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:37 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:37 --> Total execution time: 0.0248
INFO - 2023-04-17 07:21:42 --> Config Class Initialized
INFO - 2023-04-17 07:21:42 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:42 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:42 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:42 --> URI Class Initialized
INFO - 2023-04-17 07:21:42 --> Router Class Initialized
INFO - 2023-04-17 07:21:42 --> Output Class Initialized
INFO - 2023-04-17 07:21:42 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:42 --> Input Class Initialized
INFO - 2023-04-17 07:21:42 --> Language Class Initialized
INFO - 2023-04-17 07:21:42 --> Loader Class Initialized
INFO - 2023-04-17 07:21:42 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:42 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:42 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:42 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:42 --> Total execution time: 0.0137
INFO - 2023-04-17 07:21:42 --> Config Class Initialized
INFO - 2023-04-17 07:21:42 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:42 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:42 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:42 --> URI Class Initialized
INFO - 2023-04-17 07:21:42 --> Router Class Initialized
INFO - 2023-04-17 07:21:42 --> Output Class Initialized
INFO - 2023-04-17 07:21:42 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:42 --> Input Class Initialized
INFO - 2023-04-17 07:21:42 --> Language Class Initialized
INFO - 2023-04-17 07:21:42 --> Loader Class Initialized
INFO - 2023-04-17 07:21:42 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:42 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:42 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:42 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:42 --> Total execution time: 0.0144
INFO - 2023-04-17 07:21:47 --> Config Class Initialized
INFO - 2023-04-17 07:21:47 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:47 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:47 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:47 --> URI Class Initialized
INFO - 2023-04-17 07:21:47 --> Router Class Initialized
INFO - 2023-04-17 07:21:47 --> Output Class Initialized
INFO - 2023-04-17 07:21:47 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:47 --> Input Class Initialized
INFO - 2023-04-17 07:21:47 --> Language Class Initialized
INFO - 2023-04-17 07:21:47 --> Loader Class Initialized
INFO - 2023-04-17 07:21:47 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:47 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:47 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:47 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:47 --> Total execution time: 0.0167
INFO - 2023-04-17 07:21:52 --> Config Class Initialized
INFO - 2023-04-17 07:21:52 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:52 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:52 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:52 --> URI Class Initialized
INFO - 2023-04-17 07:21:52 --> Router Class Initialized
INFO - 2023-04-17 07:21:52 --> Output Class Initialized
INFO - 2023-04-17 07:21:52 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:52 --> Input Class Initialized
INFO - 2023-04-17 07:21:52 --> Language Class Initialized
INFO - 2023-04-17 07:21:52 --> Loader Class Initialized
INFO - 2023-04-17 07:21:52 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:52 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:52 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:52 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:52 --> Total execution time: 0.0158
INFO - 2023-04-17 07:21:52 --> Config Class Initialized
INFO - 2023-04-17 07:21:52 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:52 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:52 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:52 --> URI Class Initialized
INFO - 2023-04-17 07:21:52 --> Router Class Initialized
INFO - 2023-04-17 07:21:52 --> Output Class Initialized
INFO - 2023-04-17 07:21:52 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:52 --> Input Class Initialized
INFO - 2023-04-17 07:21:52 --> Language Class Initialized
INFO - 2023-04-17 07:21:52 --> Loader Class Initialized
INFO - 2023-04-17 07:21:52 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:52 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:52 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:53 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:53 --> Total execution time: 0.9214
INFO - 2023-04-17 07:21:58 --> Config Class Initialized
INFO - 2023-04-17 07:21:58 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:58 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:58 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:58 --> URI Class Initialized
INFO - 2023-04-17 07:21:58 --> Router Class Initialized
INFO - 2023-04-17 07:21:58 --> Output Class Initialized
INFO - 2023-04-17 07:21:58 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:58 --> Input Class Initialized
INFO - 2023-04-17 07:21:58 --> Language Class Initialized
INFO - 2023-04-17 07:21:58 --> Loader Class Initialized
INFO - 2023-04-17 07:21:58 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:58 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:58 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:58 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:58 --> Total execution time: 0.0562
INFO - 2023-04-17 07:21:58 --> Config Class Initialized
INFO - 2023-04-17 07:21:58 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:21:58 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:21:58 --> Utf8 Class Initialized
INFO - 2023-04-17 07:21:58 --> URI Class Initialized
INFO - 2023-04-17 07:21:58 --> Router Class Initialized
INFO - 2023-04-17 07:21:58 --> Output Class Initialized
INFO - 2023-04-17 07:21:58 --> Security Class Initialized
DEBUG - 2023-04-17 07:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:21:58 --> Input Class Initialized
INFO - 2023-04-17 07:21:58 --> Language Class Initialized
INFO - 2023-04-17 07:21:58 --> Loader Class Initialized
INFO - 2023-04-17 07:21:58 --> Controller Class Initialized
DEBUG - 2023-04-17 07:21:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:21:58 --> Database Driver Class Initialized
INFO - 2023-04-17 07:21:58 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:21:58 --> Final output sent to browser
DEBUG - 2023-04-17 07:21:58 --> Total execution time: 0.0140
INFO - 2023-04-17 07:22:03 --> Config Class Initialized
INFO - 2023-04-17 07:22:03 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:03 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:03 --> URI Class Initialized
INFO - 2023-04-17 07:22:03 --> Router Class Initialized
INFO - 2023-04-17 07:22:03 --> Output Class Initialized
INFO - 2023-04-17 07:22:03 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:03 --> Input Class Initialized
INFO - 2023-04-17 07:22:03 --> Language Class Initialized
INFO - 2023-04-17 07:22:03 --> Loader Class Initialized
INFO - 2023-04-17 07:22:03 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:03 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:04 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:04 --> Total execution time: 0.0490
INFO - 2023-04-17 07:22:04 --> Config Class Initialized
INFO - 2023-04-17 07:22:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:04 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:04 --> URI Class Initialized
INFO - 2023-04-17 07:22:04 --> Router Class Initialized
INFO - 2023-04-17 07:22:04 --> Output Class Initialized
INFO - 2023-04-17 07:22:04 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:04 --> Input Class Initialized
INFO - 2023-04-17 07:22:04 --> Language Class Initialized
INFO - 2023-04-17 07:22:04 --> Loader Class Initialized
INFO - 2023-04-17 07:22:04 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:04 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:04 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:04 --> Total execution time: 0.8093
INFO - 2023-04-17 07:22:08 --> Config Class Initialized
INFO - 2023-04-17 07:22:08 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:08 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:08 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:08 --> URI Class Initialized
INFO - 2023-04-17 07:22:08 --> Router Class Initialized
INFO - 2023-04-17 07:22:08 --> Output Class Initialized
INFO - 2023-04-17 07:22:08 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:08 --> Input Class Initialized
INFO - 2023-04-17 07:22:08 --> Language Class Initialized
INFO - 2023-04-17 07:22:08 --> Loader Class Initialized
INFO - 2023-04-17 07:22:08 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:08 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:08 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:08 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:08 --> Total execution time: 0.0182
INFO - 2023-04-17 07:22:14 --> Config Class Initialized
INFO - 2023-04-17 07:22:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:14 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:14 --> URI Class Initialized
INFO - 2023-04-17 07:22:14 --> Router Class Initialized
INFO - 2023-04-17 07:22:14 --> Output Class Initialized
INFO - 2023-04-17 07:22:14 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:14 --> Input Class Initialized
INFO - 2023-04-17 07:22:14 --> Language Class Initialized
INFO - 2023-04-17 07:22:14 --> Loader Class Initialized
INFO - 2023-04-17 07:22:14 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:14 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:14 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:14 --> Total execution time: 0.0119
INFO - 2023-04-17 07:22:14 --> Config Class Initialized
INFO - 2023-04-17 07:22:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:14 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:14 --> URI Class Initialized
INFO - 2023-04-17 07:22:14 --> Router Class Initialized
INFO - 2023-04-17 07:22:14 --> Output Class Initialized
INFO - 2023-04-17 07:22:14 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:14 --> Input Class Initialized
INFO - 2023-04-17 07:22:14 --> Language Class Initialized
INFO - 2023-04-17 07:22:14 --> Loader Class Initialized
INFO - 2023-04-17 07:22:14 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:14 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:15 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:15 --> Total execution time: 0.1519
INFO - 2023-04-17 07:22:19 --> Config Class Initialized
INFO - 2023-04-17 07:22:19 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:19 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:19 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:19 --> URI Class Initialized
INFO - 2023-04-17 07:22:19 --> Router Class Initialized
INFO - 2023-04-17 07:22:19 --> Output Class Initialized
INFO - 2023-04-17 07:22:19 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:19 --> Input Class Initialized
INFO - 2023-04-17 07:22:19 --> Language Class Initialized
INFO - 2023-04-17 07:22:19 --> Loader Class Initialized
INFO - 2023-04-17 07:22:19 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:19 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:19 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:19 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:19 --> Total execution time: 0.0254
INFO - 2023-04-17 07:22:24 --> Config Class Initialized
INFO - 2023-04-17 07:22:24 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:24 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:24 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:24 --> URI Class Initialized
INFO - 2023-04-17 07:22:24 --> Router Class Initialized
INFO - 2023-04-17 07:22:24 --> Output Class Initialized
INFO - 2023-04-17 07:22:24 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:24 --> Input Class Initialized
INFO - 2023-04-17 07:22:24 --> Language Class Initialized
INFO - 2023-04-17 07:22:24 --> Loader Class Initialized
INFO - 2023-04-17 07:22:24 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:24 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:24 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:24 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:24 --> Total execution time: 0.0203
INFO - 2023-04-17 07:22:24 --> Config Class Initialized
INFO - 2023-04-17 07:22:24 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:24 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:24 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:24 --> URI Class Initialized
INFO - 2023-04-17 07:22:24 --> Router Class Initialized
INFO - 2023-04-17 07:22:24 --> Output Class Initialized
INFO - 2023-04-17 07:22:24 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:24 --> Input Class Initialized
INFO - 2023-04-17 07:22:24 --> Language Class Initialized
INFO - 2023-04-17 07:22:24 --> Loader Class Initialized
INFO - 2023-04-17 07:22:24 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:24 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:24 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:24 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:24 --> Total execution time: 0.0159
INFO - 2023-04-17 07:22:28 --> Config Class Initialized
INFO - 2023-04-17 07:22:28 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:28 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:28 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:28 --> URI Class Initialized
INFO - 2023-04-17 07:22:28 --> Router Class Initialized
INFO - 2023-04-17 07:22:28 --> Output Class Initialized
INFO - 2023-04-17 07:22:28 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:28 --> Input Class Initialized
INFO - 2023-04-17 07:22:28 --> Language Class Initialized
INFO - 2023-04-17 07:22:28 --> Loader Class Initialized
INFO - 2023-04-17 07:22:28 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:28 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:28 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:28 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:28 --> Total execution time: 0.1028
INFO - 2023-04-17 07:22:33 --> Config Class Initialized
INFO - 2023-04-17 07:22:33 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:34 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:34 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:34 --> URI Class Initialized
INFO - 2023-04-17 07:22:34 --> Router Class Initialized
INFO - 2023-04-17 07:22:34 --> Output Class Initialized
INFO - 2023-04-17 07:22:34 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:34 --> Input Class Initialized
INFO - 2023-04-17 07:22:34 --> Language Class Initialized
INFO - 2023-04-17 07:22:34 --> Loader Class Initialized
INFO - 2023-04-17 07:22:34 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:34 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:34 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:34 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:34 --> Total execution time: 0.1321
INFO - 2023-04-17 07:22:34 --> Config Class Initialized
INFO - 2023-04-17 07:22:34 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:34 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:34 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:34 --> URI Class Initialized
INFO - 2023-04-17 07:22:34 --> Router Class Initialized
INFO - 2023-04-17 07:22:34 --> Output Class Initialized
INFO - 2023-04-17 07:22:34 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:34 --> Input Class Initialized
INFO - 2023-04-17 07:22:34 --> Language Class Initialized
INFO - 2023-04-17 07:22:34 --> Loader Class Initialized
INFO - 2023-04-17 07:22:34 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:34 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:34 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:34 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:34 --> Total execution time: 0.1066
INFO - 2023-04-17 07:22:39 --> Config Class Initialized
INFO - 2023-04-17 07:22:39 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:39 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:39 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:39 --> URI Class Initialized
INFO - 2023-04-17 07:22:39 --> Router Class Initialized
INFO - 2023-04-17 07:22:39 --> Output Class Initialized
INFO - 2023-04-17 07:22:39 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:39 --> Input Class Initialized
INFO - 2023-04-17 07:22:39 --> Language Class Initialized
INFO - 2023-04-17 07:22:39 --> Loader Class Initialized
INFO - 2023-04-17 07:22:39 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:39 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:39 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:39 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:39 --> Total execution time: 0.0173
INFO - 2023-04-17 07:22:39 --> Config Class Initialized
INFO - 2023-04-17 07:22:39 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:39 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:39 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:39 --> URI Class Initialized
INFO - 2023-04-17 07:22:39 --> Router Class Initialized
INFO - 2023-04-17 07:22:39 --> Output Class Initialized
INFO - 2023-04-17 07:22:39 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:39 --> Input Class Initialized
INFO - 2023-04-17 07:22:39 --> Language Class Initialized
INFO - 2023-04-17 07:22:39 --> Loader Class Initialized
INFO - 2023-04-17 07:22:39 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:39 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:39 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:39 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:39 --> Total execution time: 0.0194
INFO - 2023-04-17 07:22:45 --> Config Class Initialized
INFO - 2023-04-17 07:22:45 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:45 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:45 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:45 --> URI Class Initialized
INFO - 2023-04-17 07:22:45 --> Router Class Initialized
INFO - 2023-04-17 07:22:45 --> Output Class Initialized
INFO - 2023-04-17 07:22:45 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:45 --> Input Class Initialized
INFO - 2023-04-17 07:22:45 --> Language Class Initialized
INFO - 2023-04-17 07:22:45 --> Loader Class Initialized
INFO - 2023-04-17 07:22:45 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:45 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:45 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:45 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:45 --> Total execution time: 0.0170
INFO - 2023-04-17 07:22:45 --> Config Class Initialized
INFO - 2023-04-17 07:22:45 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:45 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:45 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:45 --> URI Class Initialized
INFO - 2023-04-17 07:22:45 --> Router Class Initialized
INFO - 2023-04-17 07:22:45 --> Output Class Initialized
INFO - 2023-04-17 07:22:45 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:45 --> Input Class Initialized
INFO - 2023-04-17 07:22:45 --> Language Class Initialized
INFO - 2023-04-17 07:22:45 --> Loader Class Initialized
INFO - 2023-04-17 07:22:45 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:45 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:45 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:45 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:45 --> Total execution time: 0.0194
INFO - 2023-04-17 07:22:50 --> Config Class Initialized
INFO - 2023-04-17 07:22:50 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:50 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:50 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:50 --> URI Class Initialized
INFO - 2023-04-17 07:22:50 --> Router Class Initialized
INFO - 2023-04-17 07:22:50 --> Output Class Initialized
INFO - 2023-04-17 07:22:50 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:50 --> Input Class Initialized
INFO - 2023-04-17 07:22:50 --> Language Class Initialized
INFO - 2023-04-17 07:22:50 --> Loader Class Initialized
INFO - 2023-04-17 07:22:50 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:50 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:50 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:50 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:50 --> Total execution time: 0.0196
INFO - 2023-04-17 07:22:50 --> Config Class Initialized
INFO - 2023-04-17 07:22:50 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:50 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:50 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:50 --> URI Class Initialized
INFO - 2023-04-17 07:22:50 --> Router Class Initialized
INFO - 2023-04-17 07:22:50 --> Output Class Initialized
INFO - 2023-04-17 07:22:50 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:50 --> Input Class Initialized
INFO - 2023-04-17 07:22:50 --> Language Class Initialized
INFO - 2023-04-17 07:22:50 --> Loader Class Initialized
INFO - 2023-04-17 07:22:50 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:50 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:50 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:50 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:50 --> Total execution time: 0.0161
INFO - 2023-04-17 07:22:55 --> Config Class Initialized
INFO - 2023-04-17 07:22:55 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:55 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:55 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:55 --> URI Class Initialized
INFO - 2023-04-17 07:22:55 --> Router Class Initialized
INFO - 2023-04-17 07:22:55 --> Output Class Initialized
INFO - 2023-04-17 07:22:55 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:55 --> Input Class Initialized
INFO - 2023-04-17 07:22:55 --> Language Class Initialized
INFO - 2023-04-17 07:22:55 --> Loader Class Initialized
INFO - 2023-04-17 07:22:55 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:55 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:55 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:55 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:55 --> Total execution time: 0.0186
INFO - 2023-04-17 07:22:55 --> Config Class Initialized
INFO - 2023-04-17 07:22:55 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:22:55 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:22:55 --> Utf8 Class Initialized
INFO - 2023-04-17 07:22:55 --> URI Class Initialized
INFO - 2023-04-17 07:22:55 --> Router Class Initialized
INFO - 2023-04-17 07:22:55 --> Output Class Initialized
INFO - 2023-04-17 07:22:55 --> Security Class Initialized
DEBUG - 2023-04-17 07:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:22:55 --> Input Class Initialized
INFO - 2023-04-17 07:22:55 --> Language Class Initialized
INFO - 2023-04-17 07:22:55 --> Loader Class Initialized
INFO - 2023-04-17 07:22:55 --> Controller Class Initialized
DEBUG - 2023-04-17 07:22:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:22:55 --> Database Driver Class Initialized
INFO - 2023-04-17 07:22:55 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:22:55 --> Final output sent to browser
DEBUG - 2023-04-17 07:22:55 --> Total execution time: 0.0160
INFO - 2023-04-17 07:23:00 --> Config Class Initialized
INFO - 2023-04-17 07:23:00 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:00 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:00 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:00 --> URI Class Initialized
INFO - 2023-04-17 07:23:00 --> Router Class Initialized
INFO - 2023-04-17 07:23:00 --> Output Class Initialized
INFO - 2023-04-17 07:23:00 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:00 --> Input Class Initialized
INFO - 2023-04-17 07:23:00 --> Language Class Initialized
INFO - 2023-04-17 07:23:00 --> Loader Class Initialized
INFO - 2023-04-17 07:23:00 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:00 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:00 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:00 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:00 --> Total execution time: 0.0276
INFO - 2023-04-17 07:23:05 --> Config Class Initialized
INFO - 2023-04-17 07:23:05 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:05 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:05 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:05 --> URI Class Initialized
INFO - 2023-04-17 07:23:05 --> Router Class Initialized
INFO - 2023-04-17 07:23:05 --> Output Class Initialized
INFO - 2023-04-17 07:23:05 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:05 --> Input Class Initialized
INFO - 2023-04-17 07:23:05 --> Language Class Initialized
INFO - 2023-04-17 07:23:05 --> Loader Class Initialized
INFO - 2023-04-17 07:23:05 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:05 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:05 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:05 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:05 --> Total execution time: 0.0155
INFO - 2023-04-17 07:23:05 --> Config Class Initialized
INFO - 2023-04-17 07:23:05 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:05 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:05 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:05 --> URI Class Initialized
INFO - 2023-04-17 07:23:05 --> Router Class Initialized
INFO - 2023-04-17 07:23:05 --> Output Class Initialized
INFO - 2023-04-17 07:23:05 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:05 --> Input Class Initialized
INFO - 2023-04-17 07:23:05 --> Language Class Initialized
INFO - 2023-04-17 07:23:05 --> Loader Class Initialized
INFO - 2023-04-17 07:23:05 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:05 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:05 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:05 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:05 --> Total execution time: 0.0142
INFO - 2023-04-17 07:23:09 --> Config Class Initialized
INFO - 2023-04-17 07:23:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:09 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:09 --> URI Class Initialized
INFO - 2023-04-17 07:23:09 --> Router Class Initialized
INFO - 2023-04-17 07:23:09 --> Output Class Initialized
INFO - 2023-04-17 07:23:09 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:09 --> Input Class Initialized
INFO - 2023-04-17 07:23:09 --> Language Class Initialized
INFO - 2023-04-17 07:23:09 --> Loader Class Initialized
INFO - 2023-04-17 07:23:09 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:09 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:09 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:09 --> Total execution time: 0.0238
INFO - 2023-04-17 07:23:14 --> Config Class Initialized
INFO - 2023-04-17 07:23:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:14 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:14 --> URI Class Initialized
INFO - 2023-04-17 07:23:14 --> Router Class Initialized
INFO - 2023-04-17 07:23:14 --> Output Class Initialized
INFO - 2023-04-17 07:23:14 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:14 --> Input Class Initialized
INFO - 2023-04-17 07:23:14 --> Language Class Initialized
INFO - 2023-04-17 07:23:14 --> Loader Class Initialized
INFO - 2023-04-17 07:23:14 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:14 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:14 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:14 --> Total execution time: 0.0161
INFO - 2023-04-17 07:23:14 --> Config Class Initialized
INFO - 2023-04-17 07:23:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:14 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:14 --> URI Class Initialized
INFO - 2023-04-17 07:23:14 --> Router Class Initialized
INFO - 2023-04-17 07:23:14 --> Output Class Initialized
INFO - 2023-04-17 07:23:14 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:14 --> Input Class Initialized
INFO - 2023-04-17 07:23:14 --> Language Class Initialized
INFO - 2023-04-17 07:23:14 --> Loader Class Initialized
INFO - 2023-04-17 07:23:14 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:14 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:14 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:14 --> Total execution time: 0.0156
INFO - 2023-04-17 07:23:17 --> Config Class Initialized
INFO - 2023-04-17 07:23:17 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:17 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:17 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:17 --> URI Class Initialized
INFO - 2023-04-17 07:23:17 --> Router Class Initialized
INFO - 2023-04-17 07:23:17 --> Output Class Initialized
INFO - 2023-04-17 07:23:17 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:17 --> Input Class Initialized
INFO - 2023-04-17 07:23:17 --> Language Class Initialized
INFO - 2023-04-17 07:23:17 --> Loader Class Initialized
INFO - 2023-04-17 07:23:17 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:17 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:17 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:17 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:17 --> Total execution time: 0.0509
INFO - 2023-04-17 07:23:25 --> Config Class Initialized
INFO - 2023-04-17 07:23:25 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:25 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:25 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:25 --> URI Class Initialized
INFO - 2023-04-17 07:23:25 --> Router Class Initialized
INFO - 2023-04-17 07:23:25 --> Output Class Initialized
INFO - 2023-04-17 07:23:25 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:25 --> Input Class Initialized
INFO - 2023-04-17 07:23:25 --> Language Class Initialized
INFO - 2023-04-17 07:23:25 --> Loader Class Initialized
INFO - 2023-04-17 07:23:25 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:25 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:25 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:25 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:25 --> Total execution time: 0.0148
INFO - 2023-04-17 07:23:25 --> Config Class Initialized
INFO - 2023-04-17 07:23:25 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:25 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:25 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:25 --> URI Class Initialized
INFO - 2023-04-17 07:23:25 --> Router Class Initialized
INFO - 2023-04-17 07:23:25 --> Output Class Initialized
INFO - 2023-04-17 07:23:25 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:25 --> Input Class Initialized
INFO - 2023-04-17 07:23:25 --> Language Class Initialized
INFO - 2023-04-17 07:23:25 --> Loader Class Initialized
INFO - 2023-04-17 07:23:25 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:25 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:25 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:25 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:25 --> Total execution time: 0.0184
INFO - 2023-04-17 07:23:30 --> Config Class Initialized
INFO - 2023-04-17 07:23:30 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:30 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:30 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:30 --> URI Class Initialized
INFO - 2023-04-17 07:23:30 --> Router Class Initialized
INFO - 2023-04-17 07:23:30 --> Output Class Initialized
INFO - 2023-04-17 07:23:30 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:30 --> Input Class Initialized
INFO - 2023-04-17 07:23:30 --> Language Class Initialized
INFO - 2023-04-17 07:23:30 --> Loader Class Initialized
INFO - 2023-04-17 07:23:30 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:30 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:30 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:30 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:30 --> Total execution time: 0.0212
INFO - 2023-04-17 07:23:35 --> Config Class Initialized
INFO - 2023-04-17 07:23:35 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:35 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:35 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:35 --> URI Class Initialized
INFO - 2023-04-17 07:23:35 --> Router Class Initialized
INFO - 2023-04-17 07:23:35 --> Output Class Initialized
INFO - 2023-04-17 07:23:35 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:35 --> Input Class Initialized
INFO - 2023-04-17 07:23:35 --> Language Class Initialized
INFO - 2023-04-17 07:23:35 --> Loader Class Initialized
INFO - 2023-04-17 07:23:35 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:35 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:35 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:35 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:35 --> Total execution time: 0.0178
INFO - 2023-04-17 07:23:35 --> Config Class Initialized
INFO - 2023-04-17 07:23:35 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:35 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:35 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:35 --> URI Class Initialized
INFO - 2023-04-17 07:23:35 --> Router Class Initialized
INFO - 2023-04-17 07:23:35 --> Output Class Initialized
INFO - 2023-04-17 07:23:35 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:35 --> Input Class Initialized
INFO - 2023-04-17 07:23:35 --> Language Class Initialized
INFO - 2023-04-17 07:23:35 --> Loader Class Initialized
INFO - 2023-04-17 07:23:35 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:35 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:35 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:35 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:35 --> Total execution time: 0.0205
INFO - 2023-04-17 07:23:40 --> Config Class Initialized
INFO - 2023-04-17 07:23:40 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:40 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:40 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:40 --> URI Class Initialized
INFO - 2023-04-17 07:23:40 --> Router Class Initialized
INFO - 2023-04-17 07:23:40 --> Output Class Initialized
INFO - 2023-04-17 07:23:40 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:40 --> Input Class Initialized
INFO - 2023-04-17 07:23:40 --> Language Class Initialized
INFO - 2023-04-17 07:23:40 --> Loader Class Initialized
INFO - 2023-04-17 07:23:40 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:40 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:40 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:40 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:40 --> Total execution time: 0.0196
INFO - 2023-04-17 07:23:40 --> Config Class Initialized
INFO - 2023-04-17 07:23:40 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:40 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:40 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:40 --> URI Class Initialized
INFO - 2023-04-17 07:23:40 --> Router Class Initialized
INFO - 2023-04-17 07:23:40 --> Output Class Initialized
INFO - 2023-04-17 07:23:40 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:40 --> Input Class Initialized
INFO - 2023-04-17 07:23:40 --> Language Class Initialized
INFO - 2023-04-17 07:23:40 --> Loader Class Initialized
INFO - 2023-04-17 07:23:40 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:40 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:40 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:40 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:40 --> Total execution time: 0.0164
INFO - 2023-04-17 07:23:45 --> Config Class Initialized
INFO - 2023-04-17 07:23:45 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:45 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:45 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:45 --> URI Class Initialized
INFO - 2023-04-17 07:23:45 --> Router Class Initialized
INFO - 2023-04-17 07:23:45 --> Output Class Initialized
INFO - 2023-04-17 07:23:45 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:45 --> Input Class Initialized
INFO - 2023-04-17 07:23:45 --> Language Class Initialized
INFO - 2023-04-17 07:23:45 --> Loader Class Initialized
INFO - 2023-04-17 07:23:45 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:45 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:45 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:45 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:45 --> Total execution time: 0.0233
INFO - 2023-04-17 07:23:50 --> Config Class Initialized
INFO - 2023-04-17 07:23:50 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:50 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:50 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:50 --> URI Class Initialized
INFO - 2023-04-17 07:23:50 --> Router Class Initialized
INFO - 2023-04-17 07:23:50 --> Output Class Initialized
INFO - 2023-04-17 07:23:50 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:50 --> Input Class Initialized
INFO - 2023-04-17 07:23:50 --> Language Class Initialized
INFO - 2023-04-17 07:23:50 --> Loader Class Initialized
INFO - 2023-04-17 07:23:50 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:50 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:50 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:50 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:50 --> Model "Login_model" initialized
INFO - 2023-04-17 07:23:50 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:50 --> Total execution time: 0.0679
INFO - 2023-04-17 07:23:50 --> Config Class Initialized
INFO - 2023-04-17 07:23:50 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:23:50 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:23:50 --> Utf8 Class Initialized
INFO - 2023-04-17 07:23:50 --> URI Class Initialized
INFO - 2023-04-17 07:23:50 --> Router Class Initialized
INFO - 2023-04-17 07:23:50 --> Output Class Initialized
INFO - 2023-04-17 07:23:50 --> Security Class Initialized
DEBUG - 2023-04-17 07:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:23:50 --> Input Class Initialized
INFO - 2023-04-17 07:23:50 --> Language Class Initialized
INFO - 2023-04-17 07:23:50 --> Loader Class Initialized
INFO - 2023-04-17 07:23:50 --> Controller Class Initialized
DEBUG - 2023-04-17 07:23:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:23:50 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:50 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:23:50 --> Database Driver Class Initialized
INFO - 2023-04-17 07:23:50 --> Model "Login_model" initialized
INFO - 2023-04-17 07:23:50 --> Final output sent to browser
DEBUG - 2023-04-17 07:23:50 --> Total execution time: 0.0631
INFO - 2023-04-17 07:26:45 --> Config Class Initialized
INFO - 2023-04-17 07:26:45 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:26:45 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:26:45 --> Utf8 Class Initialized
INFO - 2023-04-17 07:26:45 --> URI Class Initialized
INFO - 2023-04-17 07:26:45 --> Router Class Initialized
INFO - 2023-04-17 07:26:45 --> Output Class Initialized
INFO - 2023-04-17 07:26:45 --> Security Class Initialized
DEBUG - 2023-04-17 07:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:26:45 --> Input Class Initialized
INFO - 2023-04-17 07:26:45 --> Language Class Initialized
INFO - 2023-04-17 07:26:45 --> Loader Class Initialized
INFO - 2023-04-17 07:26:45 --> Controller Class Initialized
DEBUG - 2023-04-17 07:26:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:26:45 --> Database Driver Class Initialized
INFO - 2023-04-17 07:26:45 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:26:45 --> Database Driver Class Initialized
INFO - 2023-04-17 07:26:45 --> Model "Login_model" initialized
INFO - 2023-04-17 07:26:45 --> Final output sent to browser
DEBUG - 2023-04-17 07:26:45 --> Total execution time: 0.1432
INFO - 2023-04-17 07:26:45 --> Config Class Initialized
INFO - 2023-04-17 07:26:46 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:26:46 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:26:46 --> Utf8 Class Initialized
INFO - 2023-04-17 07:26:46 --> URI Class Initialized
INFO - 2023-04-17 07:26:46 --> Router Class Initialized
INFO - 2023-04-17 07:26:46 --> Output Class Initialized
INFO - 2023-04-17 07:26:46 --> Security Class Initialized
DEBUG - 2023-04-17 07:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:26:46 --> Input Class Initialized
INFO - 2023-04-17 07:26:46 --> Language Class Initialized
INFO - 2023-04-17 07:26:46 --> Loader Class Initialized
INFO - 2023-04-17 07:26:46 --> Controller Class Initialized
DEBUG - 2023-04-17 07:26:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:26:46 --> Database Driver Class Initialized
INFO - 2023-04-17 07:26:46 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:26:46 --> Database Driver Class Initialized
INFO - 2023-04-17 07:26:46 --> Model "Login_model" initialized
INFO - 2023-04-17 07:26:46 --> Final output sent to browser
DEBUG - 2023-04-17 07:26:46 --> Total execution time: 0.1679
INFO - 2023-04-17 07:27:07 --> Config Class Initialized
INFO - 2023-04-17 07:27:07 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:27:07 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:27:07 --> Utf8 Class Initialized
INFO - 2023-04-17 07:27:07 --> URI Class Initialized
INFO - 2023-04-17 07:27:07 --> Router Class Initialized
INFO - 2023-04-17 07:27:07 --> Output Class Initialized
INFO - 2023-04-17 07:27:07 --> Security Class Initialized
DEBUG - 2023-04-17 07:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:27:07 --> Input Class Initialized
INFO - 2023-04-17 07:27:07 --> Language Class Initialized
INFO - 2023-04-17 07:27:07 --> Loader Class Initialized
INFO - 2023-04-17 07:27:07 --> Controller Class Initialized
DEBUG - 2023-04-17 07:27:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:27:07 --> Database Driver Class Initialized
INFO - 2023-04-17 07:27:07 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:27:07 --> Final output sent to browser
DEBUG - 2023-04-17 07:27:07 --> Total execution time: 0.0122
INFO - 2023-04-17 07:27:07 --> Config Class Initialized
INFO - 2023-04-17 07:27:07 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:27:07 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:27:07 --> Utf8 Class Initialized
INFO - 2023-04-17 07:27:07 --> URI Class Initialized
INFO - 2023-04-17 07:27:07 --> Router Class Initialized
INFO - 2023-04-17 07:27:07 --> Output Class Initialized
INFO - 2023-04-17 07:27:07 --> Security Class Initialized
DEBUG - 2023-04-17 07:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:27:07 --> Input Class Initialized
INFO - 2023-04-17 07:27:07 --> Language Class Initialized
INFO - 2023-04-17 07:27:07 --> Loader Class Initialized
INFO - 2023-04-17 07:27:07 --> Controller Class Initialized
DEBUG - 2023-04-17 07:27:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:27:07 --> Database Driver Class Initialized
INFO - 2023-04-17 07:27:07 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:27:07 --> Final output sent to browser
DEBUG - 2023-04-17 07:27:07 --> Total execution time: 0.0549
INFO - 2023-04-17 07:27:07 --> Config Class Initialized
INFO - 2023-04-17 07:27:07 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:27:07 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:27:07 --> Utf8 Class Initialized
INFO - 2023-04-17 07:27:07 --> URI Class Initialized
INFO - 2023-04-17 07:27:07 --> Router Class Initialized
INFO - 2023-04-17 07:27:07 --> Output Class Initialized
INFO - 2023-04-17 07:27:07 --> Security Class Initialized
DEBUG - 2023-04-17 07:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:27:07 --> Input Class Initialized
INFO - 2023-04-17 07:27:07 --> Language Class Initialized
INFO - 2023-04-17 07:27:07 --> Loader Class Initialized
INFO - 2023-04-17 07:27:07 --> Controller Class Initialized
DEBUG - 2023-04-17 07:27:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:27:07 --> Database Driver Class Initialized
INFO - 2023-04-17 07:27:07 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:27:07 --> Final output sent to browser
DEBUG - 2023-04-17 07:27:07 --> Total execution time: 0.0560
INFO - 2023-04-17 07:27:07 --> Config Class Initialized
INFO - 2023-04-17 07:27:07 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:27:07 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:27:07 --> Utf8 Class Initialized
INFO - 2023-04-17 07:27:07 --> URI Class Initialized
INFO - 2023-04-17 07:27:07 --> Router Class Initialized
INFO - 2023-04-17 07:27:07 --> Output Class Initialized
INFO - 2023-04-17 07:27:07 --> Security Class Initialized
DEBUG - 2023-04-17 07:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:27:07 --> Input Class Initialized
INFO - 2023-04-17 07:27:07 --> Language Class Initialized
INFO - 2023-04-17 07:27:07 --> Loader Class Initialized
INFO - 2023-04-17 07:27:07 --> Controller Class Initialized
DEBUG - 2023-04-17 07:27:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:27:07 --> Database Driver Class Initialized
INFO - 2023-04-17 07:27:07 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:27:07 --> Final output sent to browser
DEBUG - 2023-04-17 07:27:07 --> Total execution time: 0.0105
INFO - 2023-04-17 07:27:29 --> Config Class Initialized
INFO - 2023-04-17 07:27:29 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:27:29 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:27:29 --> Utf8 Class Initialized
INFO - 2023-04-17 07:27:29 --> URI Class Initialized
INFO - 2023-04-17 07:27:29 --> Router Class Initialized
INFO - 2023-04-17 07:27:29 --> Output Class Initialized
INFO - 2023-04-17 07:27:29 --> Security Class Initialized
DEBUG - 2023-04-17 07:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:27:29 --> Input Class Initialized
INFO - 2023-04-17 07:27:29 --> Language Class Initialized
INFO - 2023-04-17 07:27:29 --> Loader Class Initialized
INFO - 2023-04-17 07:27:29 --> Controller Class Initialized
DEBUG - 2023-04-17 07:27:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:27:29 --> Database Driver Class Initialized
INFO - 2023-04-17 07:27:29 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:27:29 --> Final output sent to browser
DEBUG - 2023-04-17 07:27:29 --> Total execution time: 0.0268
INFO - 2023-04-17 07:27:29 --> Config Class Initialized
INFO - 2023-04-17 07:27:29 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:27:29 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:27:29 --> Utf8 Class Initialized
INFO - 2023-04-17 07:27:29 --> URI Class Initialized
INFO - 2023-04-17 07:27:29 --> Router Class Initialized
INFO - 2023-04-17 07:27:29 --> Output Class Initialized
INFO - 2023-04-17 07:27:29 --> Security Class Initialized
DEBUG - 2023-04-17 07:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:27:29 --> Input Class Initialized
INFO - 2023-04-17 07:27:29 --> Language Class Initialized
INFO - 2023-04-17 07:27:29 --> Loader Class Initialized
INFO - 2023-04-17 07:27:29 --> Controller Class Initialized
DEBUG - 2023-04-17 07:27:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:27:29 --> Database Driver Class Initialized
INFO - 2023-04-17 07:27:29 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:27:29 --> Final output sent to browser
DEBUG - 2023-04-17 07:27:29 --> Total execution time: 0.0264
INFO - 2023-04-17 07:27:40 --> Config Class Initialized
INFO - 2023-04-17 07:27:40 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:27:40 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:27:40 --> Utf8 Class Initialized
INFO - 2023-04-17 07:27:40 --> URI Class Initialized
INFO - 2023-04-17 07:27:40 --> Router Class Initialized
INFO - 2023-04-17 07:27:40 --> Output Class Initialized
INFO - 2023-04-17 07:27:40 --> Security Class Initialized
DEBUG - 2023-04-17 07:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:27:40 --> Input Class Initialized
INFO - 2023-04-17 07:27:40 --> Language Class Initialized
INFO - 2023-04-17 07:27:40 --> Loader Class Initialized
INFO - 2023-04-17 07:27:40 --> Controller Class Initialized
DEBUG - 2023-04-17 07:27:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:27:40 --> Database Driver Class Initialized
INFO - 2023-04-17 07:27:40 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:27:40 --> Database Driver Class Initialized
INFO - 2023-04-17 07:27:41 --> Model "Login_model" initialized
INFO - 2023-04-17 07:27:41 --> Final output sent to browser
DEBUG - 2023-04-17 07:27:41 --> Total execution time: 0.2777
INFO - 2023-04-17 07:27:41 --> Config Class Initialized
INFO - 2023-04-17 07:27:41 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:27:41 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:27:41 --> Utf8 Class Initialized
INFO - 2023-04-17 07:27:41 --> URI Class Initialized
INFO - 2023-04-17 07:27:41 --> Router Class Initialized
INFO - 2023-04-17 07:27:41 --> Output Class Initialized
INFO - 2023-04-17 07:27:41 --> Security Class Initialized
DEBUG - 2023-04-17 07:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:27:41 --> Input Class Initialized
INFO - 2023-04-17 07:27:41 --> Language Class Initialized
INFO - 2023-04-17 07:27:41 --> Loader Class Initialized
INFO - 2023-04-17 07:27:41 --> Controller Class Initialized
DEBUG - 2023-04-17 07:27:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:27:41 --> Database Driver Class Initialized
INFO - 2023-04-17 07:27:41 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:27:41 --> Database Driver Class Initialized
INFO - 2023-04-17 07:27:41 --> Model "Login_model" initialized
INFO - 2023-04-17 07:27:41 --> Final output sent to browser
DEBUG - 2023-04-17 07:27:41 --> Total execution time: 0.0580
INFO - 2023-04-17 07:42:45 --> Config Class Initialized
INFO - 2023-04-17 07:42:45 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:42:45 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:42:45 --> Utf8 Class Initialized
INFO - 2023-04-17 07:42:45 --> URI Class Initialized
INFO - 2023-04-17 07:42:45 --> Router Class Initialized
INFO - 2023-04-17 07:42:45 --> Output Class Initialized
INFO - 2023-04-17 07:42:45 --> Security Class Initialized
DEBUG - 2023-04-17 07:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:42:45 --> Input Class Initialized
INFO - 2023-04-17 07:42:45 --> Language Class Initialized
INFO - 2023-04-17 07:42:45 --> Loader Class Initialized
INFO - 2023-04-17 07:42:45 --> Controller Class Initialized
DEBUG - 2023-04-17 07:42:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:42:45 --> Database Driver Class Initialized
INFO - 2023-04-17 07:42:45 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:42:45 --> Database Driver Class Initialized
INFO - 2023-04-17 07:42:45 --> Model "Login_model" initialized
INFO - 2023-04-17 07:42:45 --> Final output sent to browser
DEBUG - 2023-04-17 07:42:45 --> Total execution time: 0.1821
INFO - 2023-04-17 07:42:45 --> Config Class Initialized
INFO - 2023-04-17 07:42:45 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:42:45 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:42:45 --> Utf8 Class Initialized
INFO - 2023-04-17 07:42:45 --> URI Class Initialized
INFO - 2023-04-17 07:42:45 --> Router Class Initialized
INFO - 2023-04-17 07:42:45 --> Output Class Initialized
INFO - 2023-04-17 07:42:45 --> Security Class Initialized
DEBUG - 2023-04-17 07:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:42:45 --> Input Class Initialized
INFO - 2023-04-17 07:42:45 --> Language Class Initialized
INFO - 2023-04-17 07:42:45 --> Loader Class Initialized
INFO - 2023-04-17 07:42:45 --> Controller Class Initialized
DEBUG - 2023-04-17 07:42:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:42:45 --> Database Driver Class Initialized
INFO - 2023-04-17 07:42:45 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:42:45 --> Database Driver Class Initialized
INFO - 2023-04-17 07:42:45 --> Model "Login_model" initialized
INFO - 2023-04-17 07:42:45 --> Final output sent to browser
DEBUG - 2023-04-17 07:42:45 --> Total execution time: 0.0554
INFO - 2023-04-17 07:50:11 --> Config Class Initialized
INFO - 2023-04-17 07:50:11 --> Config Class Initialized
INFO - 2023-04-17 07:50:11 --> Hooks Class Initialized
INFO - 2023-04-17 07:50:11 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:50:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 07:50:11 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:50:11 --> Utf8 Class Initialized
INFO - 2023-04-17 07:50:11 --> Utf8 Class Initialized
INFO - 2023-04-17 07:50:11 --> URI Class Initialized
INFO - 2023-04-17 07:50:11 --> URI Class Initialized
INFO - 2023-04-17 07:50:11 --> Router Class Initialized
INFO - 2023-04-17 07:50:11 --> Router Class Initialized
INFO - 2023-04-17 07:50:11 --> Output Class Initialized
INFO - 2023-04-17 07:50:11 --> Output Class Initialized
INFO - 2023-04-17 07:50:11 --> Security Class Initialized
INFO - 2023-04-17 07:50:11 --> Security Class Initialized
DEBUG - 2023-04-17 07:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 07:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:50:11 --> Input Class Initialized
INFO - 2023-04-17 07:50:11 --> Input Class Initialized
INFO - 2023-04-17 07:50:11 --> Language Class Initialized
INFO - 2023-04-17 07:50:11 --> Language Class Initialized
INFO - 2023-04-17 07:50:11 --> Loader Class Initialized
INFO - 2023-04-17 07:50:11 --> Loader Class Initialized
INFO - 2023-04-17 07:50:11 --> Controller Class Initialized
INFO - 2023-04-17 07:50:11 --> Controller Class Initialized
DEBUG - 2023-04-17 07:50:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 07:50:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:50:11 --> Final output sent to browser
DEBUG - 2023-04-17 07:50:11 --> Total execution time: 0.0438
INFO - 2023-04-17 07:50:11 --> Database Driver Class Initialized
INFO - 2023-04-17 07:50:11 --> Config Class Initialized
INFO - 2023-04-17 07:50:11 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:50:11 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:50:11 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:50:11 --> Utf8 Class Initialized
INFO - 2023-04-17 07:50:11 --> URI Class Initialized
INFO - 2023-04-17 07:50:11 --> Router Class Initialized
INFO - 2023-04-17 07:50:11 --> Output Class Initialized
INFO - 2023-04-17 07:50:11 --> Security Class Initialized
DEBUG - 2023-04-17 07:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:50:11 --> Input Class Initialized
INFO - 2023-04-17 07:50:11 --> Language Class Initialized
INFO - 2023-04-17 07:50:11 --> Loader Class Initialized
INFO - 2023-04-17 07:50:11 --> Controller Class Initialized
DEBUG - 2023-04-17 07:50:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:50:11 --> Database Driver Class Initialized
INFO - 2023-04-17 07:50:11 --> Final output sent to browser
DEBUG - 2023-04-17 07:50:11 --> Total execution time: 0.0938
INFO - 2023-04-17 07:50:11 --> Config Class Initialized
INFO - 2023-04-17 07:50:11 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:50:11 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:50:11 --> Utf8 Class Initialized
INFO - 2023-04-17 07:50:11 --> URI Class Initialized
INFO - 2023-04-17 07:50:11 --> Router Class Initialized
INFO - 2023-04-17 07:50:11 --> Output Class Initialized
INFO - 2023-04-17 07:50:11 --> Security Class Initialized
DEBUG - 2023-04-17 07:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:50:11 --> Input Class Initialized
INFO - 2023-04-17 07:50:11 --> Language Class Initialized
INFO - 2023-04-17 07:50:11 --> Loader Class Initialized
INFO - 2023-04-17 07:50:11 --> Controller Class Initialized
DEBUG - 2023-04-17 07:50:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:50:11 --> Model "Login_model" initialized
INFO - 2023-04-17 07:50:11 --> Database Driver Class Initialized
INFO - 2023-04-17 07:50:11 --> Database Driver Class Initialized
INFO - 2023-04-17 07:50:11 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:50:11 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:50:11 --> Final output sent to browser
DEBUG - 2023-04-17 07:50:11 --> Total execution time: 0.0166
INFO - 2023-04-17 07:50:11 --> Final output sent to browser
DEBUG - 2023-04-17 07:50:11 --> Total execution time: 0.0670
INFO - 2023-04-17 07:50:14 --> Config Class Initialized
INFO - 2023-04-17 07:50:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:50:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:50:14 --> Utf8 Class Initialized
INFO - 2023-04-17 07:50:14 --> URI Class Initialized
INFO - 2023-04-17 07:50:14 --> Router Class Initialized
INFO - 2023-04-17 07:50:14 --> Output Class Initialized
INFO - 2023-04-17 07:50:14 --> Security Class Initialized
DEBUG - 2023-04-17 07:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:50:14 --> Input Class Initialized
INFO - 2023-04-17 07:50:14 --> Language Class Initialized
INFO - 2023-04-17 07:50:14 --> Loader Class Initialized
INFO - 2023-04-17 07:50:14 --> Controller Class Initialized
DEBUG - 2023-04-17 07:50:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:50:14 --> Database Driver Class Initialized
INFO - 2023-04-17 07:50:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:50:14 --> Database Driver Class Initialized
INFO - 2023-04-17 07:50:14 --> Model "Login_model" initialized
INFO - 2023-04-17 07:50:14 --> Final output sent to browser
DEBUG - 2023-04-17 07:50:14 --> Total execution time: 0.1032
INFO - 2023-04-17 07:50:14 --> Config Class Initialized
INFO - 2023-04-17 07:50:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:50:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:50:14 --> Utf8 Class Initialized
INFO - 2023-04-17 07:50:14 --> URI Class Initialized
INFO - 2023-04-17 07:50:14 --> Router Class Initialized
INFO - 2023-04-17 07:50:14 --> Output Class Initialized
INFO - 2023-04-17 07:50:14 --> Security Class Initialized
DEBUG - 2023-04-17 07:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:50:14 --> Input Class Initialized
INFO - 2023-04-17 07:50:14 --> Language Class Initialized
INFO - 2023-04-17 07:50:14 --> Loader Class Initialized
INFO - 2023-04-17 07:50:14 --> Controller Class Initialized
DEBUG - 2023-04-17 07:50:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:50:14 --> Database Driver Class Initialized
INFO - 2023-04-17 07:50:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:50:14 --> Database Driver Class Initialized
INFO - 2023-04-17 07:50:14 --> Model "Login_model" initialized
INFO - 2023-04-17 07:50:14 --> Final output sent to browser
DEBUG - 2023-04-17 07:50:14 --> Total execution time: 0.0565
INFO - 2023-04-17 07:51:46 --> Config Class Initialized
INFO - 2023-04-17 07:51:46 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:51:46 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:51:46 --> Utf8 Class Initialized
INFO - 2023-04-17 07:51:46 --> URI Class Initialized
INFO - 2023-04-17 07:51:46 --> Router Class Initialized
INFO - 2023-04-17 07:51:46 --> Output Class Initialized
INFO - 2023-04-17 07:51:46 --> Security Class Initialized
DEBUG - 2023-04-17 07:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:51:46 --> Input Class Initialized
INFO - 2023-04-17 07:51:46 --> Language Class Initialized
INFO - 2023-04-17 07:51:46 --> Loader Class Initialized
INFO - 2023-04-17 07:51:46 --> Controller Class Initialized
DEBUG - 2023-04-17 07:51:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:51:46 --> Database Driver Class Initialized
INFO - 2023-04-17 07:51:46 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:51:46 --> Final output sent to browser
DEBUG - 2023-04-17 07:51:46 --> Total execution time: 0.0193
INFO - 2023-04-17 07:51:46 --> Config Class Initialized
INFO - 2023-04-17 07:51:46 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:51:46 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:51:46 --> Utf8 Class Initialized
INFO - 2023-04-17 07:51:46 --> URI Class Initialized
INFO - 2023-04-17 07:51:46 --> Router Class Initialized
INFO - 2023-04-17 07:51:46 --> Output Class Initialized
INFO - 2023-04-17 07:51:46 --> Security Class Initialized
DEBUG - 2023-04-17 07:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:51:46 --> Input Class Initialized
INFO - 2023-04-17 07:51:46 --> Language Class Initialized
INFO - 2023-04-17 07:51:46 --> Loader Class Initialized
INFO - 2023-04-17 07:51:46 --> Controller Class Initialized
DEBUG - 2023-04-17 07:51:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:51:46 --> Database Driver Class Initialized
INFO - 2023-04-17 07:51:46 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:51:46 --> Final output sent to browser
DEBUG - 2023-04-17 07:51:46 --> Total execution time: 0.0106
INFO - 2023-04-17 07:51:47 --> Config Class Initialized
INFO - 2023-04-17 07:51:47 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:51:47 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:51:47 --> Utf8 Class Initialized
INFO - 2023-04-17 07:51:47 --> URI Class Initialized
INFO - 2023-04-17 07:51:47 --> Router Class Initialized
INFO - 2023-04-17 07:51:47 --> Output Class Initialized
INFO - 2023-04-17 07:51:47 --> Security Class Initialized
DEBUG - 2023-04-17 07:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:51:47 --> Input Class Initialized
INFO - 2023-04-17 07:51:47 --> Language Class Initialized
INFO - 2023-04-17 07:51:47 --> Loader Class Initialized
INFO - 2023-04-17 07:51:47 --> Controller Class Initialized
DEBUG - 2023-04-17 07:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:51:47 --> Database Driver Class Initialized
INFO - 2023-04-17 07:51:47 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:51:47 --> Final output sent to browser
DEBUG - 2023-04-17 07:51:47 --> Total execution time: 0.0155
INFO - 2023-04-17 07:51:47 --> Config Class Initialized
INFO - 2023-04-17 07:51:47 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:51:47 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:51:47 --> Utf8 Class Initialized
INFO - 2023-04-17 07:51:47 --> URI Class Initialized
INFO - 2023-04-17 07:51:47 --> Router Class Initialized
INFO - 2023-04-17 07:51:47 --> Output Class Initialized
INFO - 2023-04-17 07:51:47 --> Security Class Initialized
DEBUG - 2023-04-17 07:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:51:47 --> Input Class Initialized
INFO - 2023-04-17 07:51:47 --> Language Class Initialized
INFO - 2023-04-17 07:51:47 --> Loader Class Initialized
INFO - 2023-04-17 07:51:47 --> Controller Class Initialized
DEBUG - 2023-04-17 07:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:51:47 --> Database Driver Class Initialized
INFO - 2023-04-17 07:51:47 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:51:47 --> Final output sent to browser
DEBUG - 2023-04-17 07:51:47 --> Total execution time: 0.0133
INFO - 2023-04-17 07:51:49 --> Config Class Initialized
INFO - 2023-04-17 07:51:49 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:51:49 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:51:49 --> Utf8 Class Initialized
INFO - 2023-04-17 07:51:49 --> URI Class Initialized
INFO - 2023-04-17 07:51:49 --> Router Class Initialized
INFO - 2023-04-17 07:51:49 --> Output Class Initialized
INFO - 2023-04-17 07:51:49 --> Security Class Initialized
DEBUG - 2023-04-17 07:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:51:49 --> Input Class Initialized
INFO - 2023-04-17 07:51:49 --> Language Class Initialized
INFO - 2023-04-17 07:51:49 --> Loader Class Initialized
INFO - 2023-04-17 07:51:49 --> Controller Class Initialized
DEBUG - 2023-04-17 07:51:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:51:49 --> Database Driver Class Initialized
INFO - 2023-04-17 07:51:49 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:51:49 --> Final output sent to browser
DEBUG - 2023-04-17 07:51:49 --> Total execution time: 0.0434
INFO - 2023-04-17 07:51:49 --> Config Class Initialized
INFO - 2023-04-17 07:51:49 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:51:49 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:51:49 --> Utf8 Class Initialized
INFO - 2023-04-17 07:51:49 --> URI Class Initialized
INFO - 2023-04-17 07:51:49 --> Router Class Initialized
INFO - 2023-04-17 07:51:49 --> Output Class Initialized
INFO - 2023-04-17 07:51:49 --> Security Class Initialized
DEBUG - 2023-04-17 07:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:51:49 --> Input Class Initialized
INFO - 2023-04-17 07:51:49 --> Language Class Initialized
INFO - 2023-04-17 07:51:49 --> Loader Class Initialized
INFO - 2023-04-17 07:51:49 --> Controller Class Initialized
DEBUG - 2023-04-17 07:51:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:51:49 --> Database Driver Class Initialized
INFO - 2023-04-17 07:51:49 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:51:49 --> Final output sent to browser
DEBUG - 2023-04-17 07:51:49 --> Total execution time: 0.0200
INFO - 2023-04-17 07:51:56 --> Config Class Initialized
INFO - 2023-04-17 07:51:56 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:51:56 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:51:56 --> Utf8 Class Initialized
INFO - 2023-04-17 07:51:56 --> URI Class Initialized
INFO - 2023-04-17 07:51:56 --> Router Class Initialized
INFO - 2023-04-17 07:51:56 --> Output Class Initialized
INFO - 2023-04-17 07:51:56 --> Security Class Initialized
DEBUG - 2023-04-17 07:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:51:56 --> Input Class Initialized
INFO - 2023-04-17 07:51:56 --> Language Class Initialized
INFO - 2023-04-17 07:51:56 --> Loader Class Initialized
INFO - 2023-04-17 07:51:56 --> Controller Class Initialized
DEBUG - 2023-04-17 07:51:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:51:56 --> Database Driver Class Initialized
INFO - 2023-04-17 07:51:56 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:51:56 --> Database Driver Class Initialized
INFO - 2023-04-17 07:51:56 --> Model "Login_model" initialized
INFO - 2023-04-17 07:51:56 --> Final output sent to browser
DEBUG - 2023-04-17 07:51:56 --> Total execution time: 0.1487
INFO - 2023-04-17 07:51:56 --> Config Class Initialized
INFO - 2023-04-17 07:51:56 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:51:56 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:51:56 --> Utf8 Class Initialized
INFO - 2023-04-17 07:51:56 --> URI Class Initialized
INFO - 2023-04-17 07:51:56 --> Router Class Initialized
INFO - 2023-04-17 07:51:56 --> Output Class Initialized
INFO - 2023-04-17 07:51:56 --> Security Class Initialized
DEBUG - 2023-04-17 07:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:51:56 --> Input Class Initialized
INFO - 2023-04-17 07:51:56 --> Language Class Initialized
INFO - 2023-04-17 07:51:56 --> Loader Class Initialized
INFO - 2023-04-17 07:51:56 --> Controller Class Initialized
DEBUG - 2023-04-17 07:51:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:51:56 --> Database Driver Class Initialized
INFO - 2023-04-17 07:51:56 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:51:56 --> Database Driver Class Initialized
INFO - 2023-04-17 07:51:56 --> Model "Login_model" initialized
INFO - 2023-04-17 07:51:56 --> Final output sent to browser
DEBUG - 2023-04-17 07:51:56 --> Total execution time: 0.0505
INFO - 2023-04-17 07:52:40 --> Config Class Initialized
INFO - 2023-04-17 07:52:40 --> Config Class Initialized
INFO - 2023-04-17 07:52:40 --> Hooks Class Initialized
INFO - 2023-04-17 07:52:40 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:52:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 07:52:40 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:52:40 --> Utf8 Class Initialized
INFO - 2023-04-17 07:52:40 --> Utf8 Class Initialized
INFO - 2023-04-17 07:52:40 --> URI Class Initialized
INFO - 2023-04-17 07:52:40 --> URI Class Initialized
INFO - 2023-04-17 07:52:40 --> Router Class Initialized
INFO - 2023-04-17 07:52:40 --> Router Class Initialized
INFO - 2023-04-17 07:52:40 --> Output Class Initialized
INFO - 2023-04-17 07:52:40 --> Output Class Initialized
INFO - 2023-04-17 07:52:40 --> Security Class Initialized
INFO - 2023-04-17 07:52:40 --> Security Class Initialized
DEBUG - 2023-04-17 07:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 07:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:52:40 --> Input Class Initialized
INFO - 2023-04-17 07:52:40 --> Input Class Initialized
INFO - 2023-04-17 07:52:40 --> Language Class Initialized
INFO - 2023-04-17 07:52:40 --> Language Class Initialized
INFO - 2023-04-17 07:52:40 --> Loader Class Initialized
INFO - 2023-04-17 07:52:40 --> Loader Class Initialized
INFO - 2023-04-17 07:52:40 --> Controller Class Initialized
INFO - 2023-04-17 07:52:40 --> Controller Class Initialized
DEBUG - 2023-04-17 07:52:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 07:52:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:52:40 --> Final output sent to browser
DEBUG - 2023-04-17 07:52:40 --> Total execution time: 0.0042
INFO - 2023-04-17 07:52:40 --> Database Driver Class Initialized
INFO - 2023-04-17 07:52:40 --> Config Class Initialized
INFO - 2023-04-17 07:52:40 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:52:40 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:52:40 --> Utf8 Class Initialized
INFO - 2023-04-17 07:52:40 --> URI Class Initialized
INFO - 2023-04-17 07:52:40 --> Router Class Initialized
INFO - 2023-04-17 07:52:40 --> Output Class Initialized
INFO - 2023-04-17 07:52:40 --> Security Class Initialized
DEBUG - 2023-04-17 07:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:52:40 --> Input Class Initialized
INFO - 2023-04-17 07:52:40 --> Language Class Initialized
INFO - 2023-04-17 07:52:40 --> Loader Class Initialized
INFO - 2023-04-17 07:52:40 --> Controller Class Initialized
DEBUG - 2023-04-17 07:52:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:52:40 --> Database Driver Class Initialized
INFO - 2023-04-17 07:52:40 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:52:40 --> Model "Login_model" initialized
INFO - 2023-04-17 07:52:40 --> Final output sent to browser
INFO - 2023-04-17 07:52:40 --> Database Driver Class Initialized
DEBUG - 2023-04-17 07:52:40 --> Total execution time: 0.0203
INFO - 2023-04-17 07:52:40 --> Config Class Initialized
INFO - 2023-04-17 07:52:40 --> Hooks Class Initialized
DEBUG - 2023-04-17 07:52:40 --> UTF-8 Support Enabled
INFO - 2023-04-17 07:52:40 --> Utf8 Class Initialized
INFO - 2023-04-17 07:52:40 --> URI Class Initialized
INFO - 2023-04-17 07:52:40 --> Router Class Initialized
INFO - 2023-04-17 07:52:40 --> Output Class Initialized
INFO - 2023-04-17 07:52:40 --> Security Class Initialized
DEBUG - 2023-04-17 07:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 07:52:40 --> Input Class Initialized
INFO - 2023-04-17 07:52:40 --> Language Class Initialized
INFO - 2023-04-17 07:52:40 --> Loader Class Initialized
INFO - 2023-04-17 07:52:40 --> Controller Class Initialized
DEBUG - 2023-04-17 07:52:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 07:52:40 --> Database Driver Class Initialized
INFO - 2023-04-17 07:52:40 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:52:40 --> Model "Cluster_model" initialized
INFO - 2023-04-17 07:52:40 --> Final output sent to browser
DEBUG - 2023-04-17 07:52:40 --> Total execution time: 0.0335
INFO - 2023-04-17 07:52:40 --> Final output sent to browser
DEBUG - 2023-04-17 07:52:40 --> Total execution time: 0.0233
INFO - 2023-04-17 08:19:04 --> Config Class Initialized
INFO - 2023-04-17 08:19:04 --> Config Class Initialized
INFO - 2023-04-17 08:19:04 --> Hooks Class Initialized
INFO - 2023-04-17 08:19:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:19:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 08:19:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:19:04 --> Utf8 Class Initialized
INFO - 2023-04-17 08:19:04 --> Utf8 Class Initialized
INFO - 2023-04-17 08:19:04 --> URI Class Initialized
INFO - 2023-04-17 08:19:04 --> URI Class Initialized
INFO - 2023-04-17 08:19:04 --> Router Class Initialized
INFO - 2023-04-17 08:19:04 --> Router Class Initialized
INFO - 2023-04-17 08:19:04 --> Output Class Initialized
INFO - 2023-04-17 08:19:04 --> Output Class Initialized
INFO - 2023-04-17 08:19:04 --> Security Class Initialized
INFO - 2023-04-17 08:19:04 --> Security Class Initialized
DEBUG - 2023-04-17 08:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:19:04 --> Input Class Initialized
INFO - 2023-04-17 08:19:04 --> Input Class Initialized
INFO - 2023-04-17 08:19:04 --> Language Class Initialized
INFO - 2023-04-17 08:19:04 --> Language Class Initialized
INFO - 2023-04-17 08:19:04 --> Loader Class Initialized
INFO - 2023-04-17 08:19:04 --> Controller Class Initialized
DEBUG - 2023-04-17 08:19:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:19:04 --> Final output sent to browser
DEBUG - 2023-04-17 08:19:04 --> Total execution time: 0.0843
INFO - 2023-04-17 08:19:04 --> Config Class Initialized
INFO - 2023-04-17 08:19:04 --> Loader Class Initialized
INFO - 2023-04-17 08:19:04 --> Hooks Class Initialized
INFO - 2023-04-17 08:19:04 --> Controller Class Initialized
DEBUG - 2023-04-17 08:19:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:19:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:19:04 --> Database Driver Class Initialized
INFO - 2023-04-17 08:19:04 --> Utf8 Class Initialized
INFO - 2023-04-17 08:19:04 --> URI Class Initialized
INFO - 2023-04-17 08:19:04 --> Router Class Initialized
INFO - 2023-04-17 08:19:04 --> Output Class Initialized
INFO - 2023-04-17 08:19:04 --> Security Class Initialized
DEBUG - 2023-04-17 08:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:19:04 --> Input Class Initialized
INFO - 2023-04-17 08:19:04 --> Language Class Initialized
INFO - 2023-04-17 08:19:04 --> Loader Class Initialized
INFO - 2023-04-17 08:19:04 --> Controller Class Initialized
DEBUG - 2023-04-17 08:19:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:19:04 --> Database Driver Class Initialized
INFO - 2023-04-17 08:19:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:19:04 --> Model "Login_model" initialized
INFO - 2023-04-17 08:19:04 --> Database Driver Class Initialized
INFO - 2023-04-17 08:19:04 --> Final output sent to browser
DEBUG - 2023-04-17 08:19:04 --> Total execution time: 0.1766
INFO - 2023-04-17 08:19:04 --> Config Class Initialized
INFO - 2023-04-17 08:19:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:19:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:19:04 --> Utf8 Class Initialized
INFO - 2023-04-17 08:19:04 --> URI Class Initialized
INFO - 2023-04-17 08:19:04 --> Router Class Initialized
INFO - 2023-04-17 08:19:04 --> Output Class Initialized
INFO - 2023-04-17 08:19:04 --> Security Class Initialized
DEBUG - 2023-04-17 08:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:19:04 --> Input Class Initialized
INFO - 2023-04-17 08:19:04 --> Language Class Initialized
INFO - 2023-04-17 08:19:04 --> Loader Class Initialized
INFO - 2023-04-17 08:19:04 --> Controller Class Initialized
DEBUG - 2023-04-17 08:19:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:19:04 --> Database Driver Class Initialized
INFO - 2023-04-17 08:19:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:19:04 --> Final output sent to browser
DEBUG - 2023-04-17 08:19:04 --> Total execution time: 0.1569
INFO - 2023-04-17 08:19:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:19:04 --> Final output sent to browser
DEBUG - 2023-04-17 08:19:04 --> Total execution time: 0.1413
INFO - 2023-04-17 08:19:14 --> Config Class Initialized
INFO - 2023-04-17 08:19:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:19:15 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:19:15 --> Utf8 Class Initialized
INFO - 2023-04-17 08:19:15 --> URI Class Initialized
INFO - 2023-04-17 08:19:15 --> Router Class Initialized
INFO - 2023-04-17 08:19:15 --> Output Class Initialized
INFO - 2023-04-17 08:19:15 --> Security Class Initialized
DEBUG - 2023-04-17 08:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:19:15 --> Input Class Initialized
INFO - 2023-04-17 08:19:15 --> Language Class Initialized
INFO - 2023-04-17 08:19:15 --> Loader Class Initialized
INFO - 2023-04-17 08:19:15 --> Controller Class Initialized
DEBUG - 2023-04-17 08:19:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:19:15 --> Database Driver Class Initialized
INFO - 2023-04-17 08:19:15 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:19:15 --> Database Driver Class Initialized
INFO - 2023-04-17 08:19:15 --> Model "Login_model" initialized
INFO - 2023-04-17 08:19:15 --> Final output sent to browser
DEBUG - 2023-04-17 08:19:15 --> Total execution time: 0.3114
INFO - 2023-04-17 08:19:15 --> Config Class Initialized
INFO - 2023-04-17 08:19:15 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:19:15 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:19:15 --> Utf8 Class Initialized
INFO - 2023-04-17 08:19:15 --> URI Class Initialized
INFO - 2023-04-17 08:19:15 --> Router Class Initialized
INFO - 2023-04-17 08:19:15 --> Output Class Initialized
INFO - 2023-04-17 08:19:15 --> Security Class Initialized
DEBUG - 2023-04-17 08:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:19:15 --> Input Class Initialized
INFO - 2023-04-17 08:19:15 --> Language Class Initialized
INFO - 2023-04-17 08:19:15 --> Loader Class Initialized
INFO - 2023-04-17 08:19:15 --> Controller Class Initialized
DEBUG - 2023-04-17 08:19:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:19:15 --> Database Driver Class Initialized
INFO - 2023-04-17 08:19:15 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:19:15 --> Database Driver Class Initialized
INFO - 2023-04-17 08:19:15 --> Model "Login_model" initialized
INFO - 2023-04-17 08:19:15 --> Final output sent to browser
DEBUG - 2023-04-17 08:19:15 --> Total execution time: 0.2149
INFO - 2023-04-17 08:21:46 --> Config Class Initialized
INFO - 2023-04-17 08:21:46 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:21:46 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:21:46 --> Utf8 Class Initialized
INFO - 2023-04-17 08:21:46 --> URI Class Initialized
INFO - 2023-04-17 08:21:46 --> Router Class Initialized
INFO - 2023-04-17 08:21:46 --> Output Class Initialized
INFO - 2023-04-17 08:21:46 --> Security Class Initialized
DEBUG - 2023-04-17 08:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:21:46 --> Input Class Initialized
INFO - 2023-04-17 08:21:46 --> Language Class Initialized
INFO - 2023-04-17 08:21:46 --> Loader Class Initialized
INFO - 2023-04-17 08:21:46 --> Controller Class Initialized
DEBUG - 2023-04-17 08:21:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:21:46 --> Database Driver Class Initialized
INFO - 2023-04-17 08:21:46 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:21:46 --> Database Driver Class Initialized
INFO - 2023-04-17 08:21:46 --> Model "Login_model" initialized
INFO - 2023-04-17 08:21:46 --> Final output sent to browser
DEBUG - 2023-04-17 08:21:46 --> Total execution time: 0.1654
INFO - 2023-04-17 08:21:46 --> Config Class Initialized
INFO - 2023-04-17 08:21:46 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:21:46 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:21:46 --> Utf8 Class Initialized
INFO - 2023-04-17 08:21:46 --> URI Class Initialized
INFO - 2023-04-17 08:21:46 --> Router Class Initialized
INFO - 2023-04-17 08:21:46 --> Output Class Initialized
INFO - 2023-04-17 08:21:46 --> Security Class Initialized
DEBUG - 2023-04-17 08:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:21:46 --> Input Class Initialized
INFO - 2023-04-17 08:21:46 --> Language Class Initialized
INFO - 2023-04-17 08:21:46 --> Loader Class Initialized
INFO - 2023-04-17 08:21:46 --> Controller Class Initialized
DEBUG - 2023-04-17 08:21:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:21:46 --> Database Driver Class Initialized
INFO - 2023-04-17 08:21:46 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:21:46 --> Database Driver Class Initialized
INFO - 2023-04-17 08:21:46 --> Model "Login_model" initialized
INFO - 2023-04-17 08:21:46 --> Final output sent to browser
DEBUG - 2023-04-17 08:21:46 --> Total execution time: 0.0521
INFO - 2023-04-17 08:31:16 --> Config Class Initialized
INFO - 2023-04-17 08:31:16 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:16 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:16 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:16 --> URI Class Initialized
INFO - 2023-04-17 08:31:16 --> Router Class Initialized
INFO - 2023-04-17 08:31:16 --> Output Class Initialized
INFO - 2023-04-17 08:31:16 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:16 --> Input Class Initialized
INFO - 2023-04-17 08:31:16 --> Language Class Initialized
INFO - 2023-04-17 08:31:16 --> Loader Class Initialized
INFO - 2023-04-17 08:31:16 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:16 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:16 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:16 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:16 --> Total execution time: 0.0352
INFO - 2023-04-17 08:31:16 --> Config Class Initialized
INFO - 2023-04-17 08:31:16 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:16 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:16 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:16 --> URI Class Initialized
INFO - 2023-04-17 08:31:16 --> Router Class Initialized
INFO - 2023-04-17 08:31:16 --> Output Class Initialized
INFO - 2023-04-17 08:31:16 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:16 --> Input Class Initialized
INFO - 2023-04-17 08:31:16 --> Language Class Initialized
INFO - 2023-04-17 08:31:16 --> Loader Class Initialized
INFO - 2023-04-17 08:31:16 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:16 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:16 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:16 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:16 --> Total execution time: 0.0588
INFO - 2023-04-17 08:31:20 --> Config Class Initialized
INFO - 2023-04-17 08:31:20 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:20 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:20 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:20 --> URI Class Initialized
INFO - 2023-04-17 08:31:20 --> Router Class Initialized
INFO - 2023-04-17 08:31:20 --> Output Class Initialized
INFO - 2023-04-17 08:31:20 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:20 --> Input Class Initialized
INFO - 2023-04-17 08:31:20 --> Language Class Initialized
INFO - 2023-04-17 08:31:20 --> Loader Class Initialized
INFO - 2023-04-17 08:31:20 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:20 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:20 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:20 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:20 --> Total execution time: 0.0213
INFO - 2023-04-17 08:31:20 --> Config Class Initialized
INFO - 2023-04-17 08:31:20 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:20 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:20 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:20 --> URI Class Initialized
INFO - 2023-04-17 08:31:20 --> Router Class Initialized
INFO - 2023-04-17 08:31:20 --> Output Class Initialized
INFO - 2023-04-17 08:31:20 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:20 --> Input Class Initialized
INFO - 2023-04-17 08:31:20 --> Language Class Initialized
INFO - 2023-04-17 08:31:20 --> Loader Class Initialized
INFO - 2023-04-17 08:31:20 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:20 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:20 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:20 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:20 --> Total execution time: 0.0509
INFO - 2023-04-17 08:31:22 --> Config Class Initialized
INFO - 2023-04-17 08:31:22 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:22 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:22 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:22 --> URI Class Initialized
INFO - 2023-04-17 08:31:22 --> Router Class Initialized
INFO - 2023-04-17 08:31:22 --> Output Class Initialized
INFO - 2023-04-17 08:31:22 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:22 --> Input Class Initialized
INFO - 2023-04-17 08:31:22 --> Language Class Initialized
INFO - 2023-04-17 08:31:22 --> Loader Class Initialized
INFO - 2023-04-17 08:31:22 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:22 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:22 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:22 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:22 --> Total execution time: 0.0145
INFO - 2023-04-17 08:31:22 --> Config Class Initialized
INFO - 2023-04-17 08:31:22 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:22 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:22 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:22 --> URI Class Initialized
INFO - 2023-04-17 08:31:22 --> Router Class Initialized
INFO - 2023-04-17 08:31:22 --> Output Class Initialized
INFO - 2023-04-17 08:31:22 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:22 --> Input Class Initialized
INFO - 2023-04-17 08:31:22 --> Language Class Initialized
INFO - 2023-04-17 08:31:22 --> Loader Class Initialized
INFO - 2023-04-17 08:31:22 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:22 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:22 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:22 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:22 --> Total execution time: 0.0532
INFO - 2023-04-17 08:31:25 --> Config Class Initialized
INFO - 2023-04-17 08:31:25 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:25 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:25 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:25 --> URI Class Initialized
INFO - 2023-04-17 08:31:25 --> Router Class Initialized
INFO - 2023-04-17 08:31:25 --> Output Class Initialized
INFO - 2023-04-17 08:31:25 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:25 --> Input Class Initialized
INFO - 2023-04-17 08:31:25 --> Language Class Initialized
INFO - 2023-04-17 08:31:25 --> Loader Class Initialized
INFO - 2023-04-17 08:31:25 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:25 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:25 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:25 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:25 --> Total execution time: 0.0128
INFO - 2023-04-17 08:31:25 --> Config Class Initialized
INFO - 2023-04-17 08:31:25 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:25 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:25 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:25 --> URI Class Initialized
INFO - 2023-04-17 08:31:25 --> Router Class Initialized
INFO - 2023-04-17 08:31:25 --> Output Class Initialized
INFO - 2023-04-17 08:31:25 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:25 --> Input Class Initialized
INFO - 2023-04-17 08:31:25 --> Language Class Initialized
INFO - 2023-04-17 08:31:25 --> Loader Class Initialized
INFO - 2023-04-17 08:31:25 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:25 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:25 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:25 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:25 --> Total execution time: 0.0106
INFO - 2023-04-17 08:31:26 --> Config Class Initialized
INFO - 2023-04-17 08:31:26 --> Config Class Initialized
INFO - 2023-04-17 08:31:26 --> Hooks Class Initialized
INFO - 2023-04-17 08:31:26 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 08:31:26 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:26 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:26 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:26 --> URI Class Initialized
INFO - 2023-04-17 08:31:26 --> URI Class Initialized
INFO - 2023-04-17 08:31:26 --> Router Class Initialized
INFO - 2023-04-17 08:31:26 --> Router Class Initialized
INFO - 2023-04-17 08:31:26 --> Output Class Initialized
INFO - 2023-04-17 08:31:26 --> Output Class Initialized
INFO - 2023-04-17 08:31:26 --> Security Class Initialized
INFO - 2023-04-17 08:31:26 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:26 --> Input Class Initialized
INFO - 2023-04-17 08:31:26 --> Input Class Initialized
INFO - 2023-04-17 08:31:26 --> Language Class Initialized
INFO - 2023-04-17 08:31:26 --> Language Class Initialized
INFO - 2023-04-17 08:31:26 --> Loader Class Initialized
INFO - 2023-04-17 08:31:26 --> Loader Class Initialized
INFO - 2023-04-17 08:31:26 --> Controller Class Initialized
INFO - 2023-04-17 08:31:26 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:31:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:26 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:26 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:26 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:26 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:26 --> Final output sent to browser
INFO - 2023-04-17 08:31:26 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:26 --> Total execution time: 0.0379
DEBUG - 2023-04-17 08:31:26 --> Total execution time: 0.0381
INFO - 2023-04-17 08:31:26 --> Config Class Initialized
INFO - 2023-04-17 08:31:26 --> Config Class Initialized
INFO - 2023-04-17 08:31:26 --> Hooks Class Initialized
INFO - 2023-04-17 08:31:26 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 08:31:26 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:26 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:26 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:26 --> URI Class Initialized
INFO - 2023-04-17 08:31:26 --> URI Class Initialized
INFO - 2023-04-17 08:31:26 --> Router Class Initialized
INFO - 2023-04-17 08:31:26 --> Router Class Initialized
INFO - 2023-04-17 08:31:26 --> Output Class Initialized
INFO - 2023-04-17 08:31:26 --> Output Class Initialized
INFO - 2023-04-17 08:31:26 --> Security Class Initialized
INFO - 2023-04-17 08:31:26 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:26 --> Input Class Initialized
INFO - 2023-04-17 08:31:26 --> Input Class Initialized
INFO - 2023-04-17 08:31:26 --> Language Class Initialized
INFO - 2023-04-17 08:31:26 --> Language Class Initialized
INFO - 2023-04-17 08:31:26 --> Loader Class Initialized
INFO - 2023-04-17 08:31:26 --> Loader Class Initialized
INFO - 2023-04-17 08:31:26 --> Controller Class Initialized
INFO - 2023-04-17 08:31:26 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:31:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:26 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:26 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:26 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:26 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:26 --> Final output sent to browser
INFO - 2023-04-17 08:31:26 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:26 --> Total execution time: 0.0161
DEBUG - 2023-04-17 08:31:26 --> Total execution time: 0.0161
INFO - 2023-04-17 08:31:29 --> Config Class Initialized
INFO - 2023-04-17 08:31:29 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:29 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:29 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:29 --> URI Class Initialized
INFO - 2023-04-17 08:31:29 --> Router Class Initialized
INFO - 2023-04-17 08:31:29 --> Output Class Initialized
INFO - 2023-04-17 08:31:29 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:29 --> Input Class Initialized
INFO - 2023-04-17 08:31:29 --> Language Class Initialized
INFO - 2023-04-17 08:31:29 --> Loader Class Initialized
INFO - 2023-04-17 08:31:29 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:29 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:29 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:29 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:29 --> Total execution time: 0.0180
INFO - 2023-04-17 08:31:29 --> Config Class Initialized
INFO - 2023-04-17 08:31:29 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:29 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:29 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:29 --> URI Class Initialized
INFO - 2023-04-17 08:31:29 --> Router Class Initialized
INFO - 2023-04-17 08:31:29 --> Output Class Initialized
INFO - 2023-04-17 08:31:29 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:29 --> Input Class Initialized
INFO - 2023-04-17 08:31:29 --> Language Class Initialized
INFO - 2023-04-17 08:31:29 --> Loader Class Initialized
INFO - 2023-04-17 08:31:29 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:29 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:29 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:29 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:29 --> Total execution time: 0.0528
INFO - 2023-04-17 08:31:32 --> Config Class Initialized
INFO - 2023-04-17 08:31:32 --> Config Class Initialized
INFO - 2023-04-17 08:31:32 --> Hooks Class Initialized
INFO - 2023-04-17 08:31:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 08:31:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:32 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:32 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:32 --> URI Class Initialized
INFO - 2023-04-17 08:31:32 --> URI Class Initialized
INFO - 2023-04-17 08:31:32 --> Router Class Initialized
INFO - 2023-04-17 08:31:32 --> Router Class Initialized
INFO - 2023-04-17 08:31:32 --> Output Class Initialized
INFO - 2023-04-17 08:31:32 --> Output Class Initialized
INFO - 2023-04-17 08:31:32 --> Security Class Initialized
INFO - 2023-04-17 08:31:32 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:32 --> Input Class Initialized
INFO - 2023-04-17 08:31:32 --> Input Class Initialized
INFO - 2023-04-17 08:31:32 --> Language Class Initialized
INFO - 2023-04-17 08:31:32 --> Language Class Initialized
INFO - 2023-04-17 08:31:32 --> Loader Class Initialized
INFO - 2023-04-17 08:31:32 --> Loader Class Initialized
INFO - 2023-04-17 08:31:32 --> Controller Class Initialized
INFO - 2023-04-17 08:31:32 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:31:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:32 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:32 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:32 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:32 --> Total execution time: 0.0156
INFO - 2023-04-17 08:31:32 --> Config Class Initialized
INFO - 2023-04-17 08:31:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:32 --> Final output sent to browser
INFO - 2023-04-17 08:31:32 --> Utf8 Class Initialized
DEBUG - 2023-04-17 08:31:32 --> Total execution time: 0.0186
INFO - 2023-04-17 08:31:32 --> URI Class Initialized
INFO - 2023-04-17 08:31:32 --> Router Class Initialized
INFO - 2023-04-17 08:31:32 --> Output Class Initialized
INFO - 2023-04-17 08:31:32 --> Security Class Initialized
INFO - 2023-04-17 08:31:32 --> Config Class Initialized
INFO - 2023-04-17 08:31:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:31:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:32 --> Input Class Initialized
INFO - 2023-04-17 08:31:32 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:32 --> Language Class Initialized
INFO - 2023-04-17 08:31:32 --> URI Class Initialized
INFO - 2023-04-17 08:31:32 --> Loader Class Initialized
INFO - 2023-04-17 08:31:32 --> Router Class Initialized
INFO - 2023-04-17 08:31:32 --> Controller Class Initialized
INFO - 2023-04-17 08:31:32 --> Output Class Initialized
DEBUG - 2023-04-17 08:31:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:32 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:32 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:32 --> Input Class Initialized
INFO - 2023-04-17 08:31:32 --> Language Class Initialized
INFO - 2023-04-17 08:31:32 --> Loader Class Initialized
INFO - 2023-04-17 08:31:32 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:32 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:32 --> Final output sent to browser
INFO - 2023-04-17 08:31:32 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:32 --> Total execution time: 0.0503
DEBUG - 2023-04-17 08:31:32 --> Total execution time: 0.0550
INFO - 2023-04-17 08:31:33 --> Config Class Initialized
INFO - 2023-04-17 08:31:33 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:33 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:33 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:33 --> URI Class Initialized
INFO - 2023-04-17 08:31:33 --> Router Class Initialized
INFO - 2023-04-17 08:31:33 --> Output Class Initialized
INFO - 2023-04-17 08:31:33 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:33 --> Input Class Initialized
INFO - 2023-04-17 08:31:33 --> Language Class Initialized
INFO - 2023-04-17 08:31:33 --> Loader Class Initialized
INFO - 2023-04-17 08:31:33 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:33 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:33 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:33 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:33 --> Total execution time: 0.0299
INFO - 2023-04-17 08:31:33 --> Config Class Initialized
INFO - 2023-04-17 08:31:33 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:33 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:33 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:33 --> URI Class Initialized
INFO - 2023-04-17 08:31:33 --> Router Class Initialized
INFO - 2023-04-17 08:31:33 --> Output Class Initialized
INFO - 2023-04-17 08:31:33 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:33 --> Input Class Initialized
INFO - 2023-04-17 08:31:33 --> Language Class Initialized
INFO - 2023-04-17 08:31:33 --> Loader Class Initialized
INFO - 2023-04-17 08:31:33 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:33 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:33 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:33 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:33 --> Total execution time: 0.0636
INFO - 2023-04-17 08:31:49 --> Config Class Initialized
INFO - 2023-04-17 08:31:49 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:49 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:49 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:49 --> URI Class Initialized
INFO - 2023-04-17 08:31:49 --> Router Class Initialized
INFO - 2023-04-17 08:31:49 --> Output Class Initialized
INFO - 2023-04-17 08:31:49 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:49 --> Input Class Initialized
INFO - 2023-04-17 08:31:49 --> Language Class Initialized
INFO - 2023-04-17 08:31:49 --> Loader Class Initialized
INFO - 2023-04-17 08:31:49 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:49 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:49 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:49 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:49 --> Total execution time: 0.0168
INFO - 2023-04-17 08:31:49 --> Config Class Initialized
INFO - 2023-04-17 08:31:49 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:49 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:49 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:49 --> URI Class Initialized
INFO - 2023-04-17 08:31:49 --> Router Class Initialized
INFO - 2023-04-17 08:31:49 --> Output Class Initialized
INFO - 2023-04-17 08:31:49 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:49 --> Input Class Initialized
INFO - 2023-04-17 08:31:49 --> Language Class Initialized
INFO - 2023-04-17 08:31:49 --> Loader Class Initialized
INFO - 2023-04-17 08:31:49 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:49 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:49 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:49 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:49 --> Total execution time: 0.0566
INFO - 2023-04-17 08:31:52 --> Config Class Initialized
INFO - 2023-04-17 08:31:52 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:52 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:52 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:52 --> URI Class Initialized
INFO - 2023-04-17 08:31:52 --> Router Class Initialized
INFO - 2023-04-17 08:31:52 --> Output Class Initialized
INFO - 2023-04-17 08:31:52 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:52 --> Input Class Initialized
INFO - 2023-04-17 08:31:52 --> Language Class Initialized
INFO - 2023-04-17 08:31:52 --> Loader Class Initialized
INFO - 2023-04-17 08:31:52 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:52 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:52 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:52 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:52 --> Total execution time: 0.0133
INFO - 2023-04-17 08:31:52 --> Config Class Initialized
INFO - 2023-04-17 08:31:52 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:52 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:52 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:52 --> URI Class Initialized
INFO - 2023-04-17 08:31:52 --> Router Class Initialized
INFO - 2023-04-17 08:31:52 --> Output Class Initialized
INFO - 2023-04-17 08:31:52 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:52 --> Input Class Initialized
INFO - 2023-04-17 08:31:52 --> Language Class Initialized
INFO - 2023-04-17 08:31:52 --> Loader Class Initialized
INFO - 2023-04-17 08:31:52 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:52 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:52 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:52 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:52 --> Total execution time: 0.0112
INFO - 2023-04-17 08:31:55 --> Config Class Initialized
INFO - 2023-04-17 08:31:55 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:55 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:55 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:55 --> URI Class Initialized
INFO - 2023-04-17 08:31:55 --> Router Class Initialized
INFO - 2023-04-17 08:31:55 --> Output Class Initialized
INFO - 2023-04-17 08:31:55 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:55 --> Input Class Initialized
INFO - 2023-04-17 08:31:55 --> Language Class Initialized
INFO - 2023-04-17 08:31:55 --> Loader Class Initialized
INFO - 2023-04-17 08:31:55 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:55 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:55 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:55 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:55 --> Total execution time: 0.0118
INFO - 2023-04-17 08:31:55 --> Config Class Initialized
INFO - 2023-04-17 08:31:55 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:55 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:55 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:55 --> URI Class Initialized
INFO - 2023-04-17 08:31:55 --> Router Class Initialized
INFO - 2023-04-17 08:31:55 --> Output Class Initialized
INFO - 2023-04-17 08:31:55 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:55 --> Input Class Initialized
INFO - 2023-04-17 08:31:55 --> Language Class Initialized
INFO - 2023-04-17 08:31:55 --> Loader Class Initialized
INFO - 2023-04-17 08:31:55 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:55 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:55 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:55 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:55 --> Model "Login_model" initialized
INFO - 2023-04-17 08:31:55 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:55 --> Total execution time: 0.0212
INFO - 2023-04-17 08:31:57 --> Config Class Initialized
INFO - 2023-04-17 08:31:57 --> Hooks Class Initialized
INFO - 2023-04-17 08:31:57 --> Config Class Initialized
DEBUG - 2023-04-17 08:31:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:57 --> Hooks Class Initialized
INFO - 2023-04-17 08:31:57 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:57 --> URI Class Initialized
DEBUG - 2023-04-17 08:31:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:57 --> Router Class Initialized
INFO - 2023-04-17 08:31:57 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:57 --> Output Class Initialized
INFO - 2023-04-17 08:31:57 --> URI Class Initialized
INFO - 2023-04-17 08:31:57 --> Security Class Initialized
INFO - 2023-04-17 08:31:57 --> Router Class Initialized
DEBUG - 2023-04-17 08:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:57 --> Output Class Initialized
INFO - 2023-04-17 08:31:57 --> Input Class Initialized
INFO - 2023-04-17 08:31:57 --> Security Class Initialized
INFO - 2023-04-17 08:31:57 --> Language Class Initialized
DEBUG - 2023-04-17 08:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:57 --> Input Class Initialized
INFO - 2023-04-17 08:31:57 --> Language Class Initialized
INFO - 2023-04-17 08:31:57 --> Loader Class Initialized
INFO - 2023-04-17 08:31:57 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:57 --> Loader Class Initialized
INFO - 2023-04-17 08:31:57 --> Controller Class Initialized
INFO - 2023-04-17 08:31:57 --> Database Driver Class Initialized
DEBUG - 2023-04-17 08:31:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:57 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:57 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:57 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:57 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:57 --> Total execution time: 0.1780
INFO - 2023-04-17 08:31:57 --> Config Class Initialized
INFO - 2023-04-17 08:31:57 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:57 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:57 --> URI Class Initialized
INFO - 2023-04-17 08:31:57 --> Router Class Initialized
INFO - 2023-04-17 08:31:57 --> Output Class Initialized
INFO - 2023-04-17 08:31:57 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:57 --> Input Class Initialized
INFO - 2023-04-17 08:31:57 --> Language Class Initialized
INFO - 2023-04-17 08:31:57 --> Loader Class Initialized
INFO - 2023-04-17 08:31:57 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:57 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:57 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:31:57 --> Final output sent to browser
DEBUG - 2023-04-17 08:31:57 --> Total execution time: 0.0290
INFO - 2023-04-17 08:31:57 --> Config Class Initialized
INFO - 2023-04-17 08:31:57 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:31:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:31:57 --> Utf8 Class Initialized
INFO - 2023-04-17 08:31:57 --> URI Class Initialized
INFO - 2023-04-17 08:31:57 --> Router Class Initialized
INFO - 2023-04-17 08:31:57 --> Output Class Initialized
INFO - 2023-04-17 08:31:57 --> Security Class Initialized
DEBUG - 2023-04-17 08:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:31:57 --> Input Class Initialized
INFO - 2023-04-17 08:31:57 --> Language Class Initialized
INFO - 2023-04-17 08:31:57 --> Loader Class Initialized
INFO - 2023-04-17 08:31:57 --> Controller Class Initialized
DEBUG - 2023-04-17 08:31:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:31:57 --> Database Driver Class Initialized
INFO - 2023-04-17 08:31:57 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:00 --> Config Class Initialized
INFO - 2023-04-17 08:32:00 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:00 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:00 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:00 --> URI Class Initialized
INFO - 2023-04-17 08:32:00 --> Router Class Initialized
INFO - 2023-04-17 08:32:00 --> Output Class Initialized
INFO - 2023-04-17 08:32:00 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:00 --> Input Class Initialized
INFO - 2023-04-17 08:32:00 --> Language Class Initialized
INFO - 2023-04-17 08:32:00 --> Loader Class Initialized
INFO - 2023-04-17 08:32:00 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:00 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:00 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:00 --> Config Class Initialized
INFO - 2023-04-17 08:32:00 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:00 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:00 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:00 --> URI Class Initialized
INFO - 2023-04-17 08:32:00 --> Router Class Initialized
INFO - 2023-04-17 08:32:00 --> Output Class Initialized
INFO - 2023-04-17 08:32:00 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:00 --> Input Class Initialized
INFO - 2023-04-17 08:32:00 --> Language Class Initialized
INFO - 2023-04-17 08:32:00 --> Loader Class Initialized
INFO - 2023-04-17 08:32:00 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:00 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:00 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:08 --> Config Class Initialized
INFO - 2023-04-17 08:32:08 --> Config Class Initialized
INFO - 2023-04-17 08:32:08 --> Hooks Class Initialized
INFO - 2023-04-17 08:32:08 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 08:32:08 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:08 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:08 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:08 --> URI Class Initialized
INFO - 2023-04-17 08:32:08 --> URI Class Initialized
INFO - 2023-04-17 08:32:08 --> Router Class Initialized
INFO - 2023-04-17 08:32:08 --> Router Class Initialized
INFO - 2023-04-17 08:32:08 --> Output Class Initialized
INFO - 2023-04-17 08:32:08 --> Output Class Initialized
INFO - 2023-04-17 08:32:08 --> Security Class Initialized
INFO - 2023-04-17 08:32:08 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:08 --> Input Class Initialized
INFO - 2023-04-17 08:32:08 --> Input Class Initialized
INFO - 2023-04-17 08:32:08 --> Language Class Initialized
INFO - 2023-04-17 08:32:08 --> Language Class Initialized
INFO - 2023-04-17 08:32:08 --> Loader Class Initialized
INFO - 2023-04-17 08:32:08 --> Loader Class Initialized
INFO - 2023-04-17 08:32:08 --> Controller Class Initialized
INFO - 2023-04-17 08:32:08 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:08 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:08 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:08 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:08 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:08 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:08 --> Total execution time: 0.0173
INFO - 2023-04-17 08:32:08 --> Config Class Initialized
INFO - 2023-04-17 08:32:08 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:08 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:08 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:08 --> URI Class Initialized
INFO - 2023-04-17 08:32:08 --> Router Class Initialized
INFO - 2023-04-17 08:32:08 --> Output Class Initialized
INFO - 2023-04-17 08:32:08 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:08 --> Input Class Initialized
INFO - 2023-04-17 08:32:08 --> Language Class Initialized
INFO - 2023-04-17 08:32:08 --> Loader Class Initialized
INFO - 2023-04-17 08:32:08 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:08 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:08 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:08 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:08 --> Total execution time: 0.0124
INFO - 2023-04-17 08:32:08 --> Config Class Initialized
INFO - 2023-04-17 08:32:08 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:08 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:08 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:08 --> URI Class Initialized
INFO - 2023-04-17 08:32:08 --> Router Class Initialized
INFO - 2023-04-17 08:32:08 --> Output Class Initialized
INFO - 2023-04-17 08:32:08 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:08 --> Input Class Initialized
INFO - 2023-04-17 08:32:08 --> Language Class Initialized
INFO - 2023-04-17 08:32:08 --> Loader Class Initialized
INFO - 2023-04-17 08:32:08 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:08 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:08 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:18 --> Config Class Initialized
INFO - 2023-04-17 08:32:18 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:18 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:18 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:18 --> URI Class Initialized
INFO - 2023-04-17 08:32:18 --> Router Class Initialized
INFO - 2023-04-17 08:32:18 --> Output Class Initialized
INFO - 2023-04-17 08:32:18 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:18 --> Input Class Initialized
INFO - 2023-04-17 08:32:18 --> Language Class Initialized
INFO - 2023-04-17 08:32:18 --> Loader Class Initialized
INFO - 2023-04-17 08:32:18 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:18 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:18 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:18 --> Config Class Initialized
INFO - 2023-04-17 08:32:18 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:18 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:18 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:18 --> URI Class Initialized
INFO - 2023-04-17 08:32:18 --> Router Class Initialized
INFO - 2023-04-17 08:32:18 --> Output Class Initialized
INFO - 2023-04-17 08:32:18 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:18 --> Input Class Initialized
INFO - 2023-04-17 08:32:18 --> Language Class Initialized
INFO - 2023-04-17 08:32:18 --> Loader Class Initialized
INFO - 2023-04-17 08:32:18 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:18 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:18 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:18 --> Config Class Initialized
INFO - 2023-04-17 08:32:18 --> Config Class Initialized
INFO - 2023-04-17 08:32:18 --> Hooks Class Initialized
INFO - 2023-04-17 08:32:18 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 08:32:18 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:18 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:18 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:18 --> URI Class Initialized
INFO - 2023-04-17 08:32:18 --> URI Class Initialized
INFO - 2023-04-17 08:32:18 --> Router Class Initialized
INFO - 2023-04-17 08:32:18 --> Router Class Initialized
INFO - 2023-04-17 08:32:18 --> Output Class Initialized
INFO - 2023-04-17 08:32:18 --> Output Class Initialized
INFO - 2023-04-17 08:32:18 --> Security Class Initialized
INFO - 2023-04-17 08:32:18 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:18 --> Input Class Initialized
INFO - 2023-04-17 08:32:18 --> Input Class Initialized
INFO - 2023-04-17 08:32:18 --> Language Class Initialized
INFO - 2023-04-17 08:32:18 --> Language Class Initialized
INFO - 2023-04-17 08:32:18 --> Loader Class Initialized
INFO - 2023-04-17 08:32:18 --> Loader Class Initialized
INFO - 2023-04-17 08:32:18 --> Controller Class Initialized
INFO - 2023-04-17 08:32:18 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:18 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:18 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:18 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:18 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:18 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:18 --> Total execution time: 0.0154
INFO - 2023-04-17 08:32:18 --> Config Class Initialized
INFO - 2023-04-17 08:32:18 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:18 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:18 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:18 --> URI Class Initialized
INFO - 2023-04-17 08:32:18 --> Router Class Initialized
INFO - 2023-04-17 08:32:18 --> Output Class Initialized
INFO - 2023-04-17 08:32:18 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:18 --> Input Class Initialized
INFO - 2023-04-17 08:32:18 --> Language Class Initialized
INFO - 2023-04-17 08:32:18 --> Loader Class Initialized
INFO - 2023-04-17 08:32:18 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:18 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:18 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:18 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:18 --> Total execution time: 0.0119
INFO - 2023-04-17 08:32:18 --> Config Class Initialized
INFO - 2023-04-17 08:32:19 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:19 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:19 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:19 --> URI Class Initialized
INFO - 2023-04-17 08:32:19 --> Router Class Initialized
INFO - 2023-04-17 08:32:19 --> Output Class Initialized
INFO - 2023-04-17 08:32:19 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:19 --> Input Class Initialized
INFO - 2023-04-17 08:32:19 --> Language Class Initialized
INFO - 2023-04-17 08:32:19 --> Loader Class Initialized
INFO - 2023-04-17 08:32:19 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:19 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:19 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:19 --> Config Class Initialized
INFO - 2023-04-17 08:32:19 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:19 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:19 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:19 --> URI Class Initialized
INFO - 2023-04-17 08:32:19 --> Router Class Initialized
INFO - 2023-04-17 08:32:19 --> Output Class Initialized
INFO - 2023-04-17 08:32:19 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:19 --> Input Class Initialized
INFO - 2023-04-17 08:32:19 --> Language Class Initialized
INFO - 2023-04-17 08:32:19 --> Loader Class Initialized
INFO - 2023-04-17 08:32:19 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:19 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:19 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:19 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:19 --> Total execution time: 0.0139
INFO - 2023-04-17 08:32:19 --> Config Class Initialized
INFO - 2023-04-17 08:32:19 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:19 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:19 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:19 --> URI Class Initialized
INFO - 2023-04-17 08:32:19 --> Router Class Initialized
INFO - 2023-04-17 08:32:19 --> Output Class Initialized
INFO - 2023-04-17 08:32:19 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:19 --> Input Class Initialized
INFO - 2023-04-17 08:32:19 --> Language Class Initialized
INFO - 2023-04-17 08:32:19 --> Loader Class Initialized
INFO - 2023-04-17 08:32:19 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:19 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:20 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:20 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:20 --> Total execution time: 0.0143
INFO - 2023-04-17 08:32:20 --> Config Class Initialized
INFO - 2023-04-17 08:32:20 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:20 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:20 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:20 --> URI Class Initialized
INFO - 2023-04-17 08:32:20 --> Router Class Initialized
INFO - 2023-04-17 08:32:20 --> Output Class Initialized
INFO - 2023-04-17 08:32:20 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:20 --> Input Class Initialized
INFO - 2023-04-17 08:32:20 --> Language Class Initialized
INFO - 2023-04-17 08:32:20 --> Loader Class Initialized
INFO - 2023-04-17 08:32:20 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:20 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:20 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:20 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:20 --> Total execution time: 0.0191
INFO - 2023-04-17 08:32:20 --> Config Class Initialized
INFO - 2023-04-17 08:32:20 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:20 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:20 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:20 --> URI Class Initialized
INFO - 2023-04-17 08:32:20 --> Router Class Initialized
INFO - 2023-04-17 08:32:20 --> Output Class Initialized
INFO - 2023-04-17 08:32:20 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:20 --> Input Class Initialized
INFO - 2023-04-17 08:32:20 --> Language Class Initialized
INFO - 2023-04-17 08:32:20 --> Loader Class Initialized
INFO - 2023-04-17 08:32:20 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:20 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:20 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:20 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:20 --> Total execution time: 0.0555
INFO - 2023-04-17 08:32:22 --> Config Class Initialized
INFO - 2023-04-17 08:32:22 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:22 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:22 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:22 --> URI Class Initialized
INFO - 2023-04-17 08:32:22 --> Router Class Initialized
INFO - 2023-04-17 08:32:22 --> Output Class Initialized
INFO - 2023-04-17 08:32:22 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:22 --> Input Class Initialized
INFO - 2023-04-17 08:32:22 --> Language Class Initialized
INFO - 2023-04-17 08:32:22 --> Loader Class Initialized
INFO - 2023-04-17 08:32:22 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:22 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:22 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:22 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:22 --> Total execution time: 0.0259
INFO - 2023-04-17 08:32:22 --> Config Class Initialized
INFO - 2023-04-17 08:32:22 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:22 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:22 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:22 --> URI Class Initialized
INFO - 2023-04-17 08:32:22 --> Router Class Initialized
INFO - 2023-04-17 08:32:22 --> Output Class Initialized
INFO - 2023-04-17 08:32:22 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:22 --> Input Class Initialized
INFO - 2023-04-17 08:32:22 --> Language Class Initialized
INFO - 2023-04-17 08:32:22 --> Loader Class Initialized
INFO - 2023-04-17 08:32:22 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:22 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:22 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:22 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:22 --> Total execution time: 0.0179
INFO - 2023-04-17 08:32:25 --> Config Class Initialized
INFO - 2023-04-17 08:32:25 --> Config Class Initialized
INFO - 2023-04-17 08:32:25 --> Hooks Class Initialized
INFO - 2023-04-17 08:32:25 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 08:32:25 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:25 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:25 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:25 --> URI Class Initialized
INFO - 2023-04-17 08:32:25 --> URI Class Initialized
INFO - 2023-04-17 08:32:25 --> Router Class Initialized
INFO - 2023-04-17 08:32:25 --> Router Class Initialized
INFO - 2023-04-17 08:32:25 --> Output Class Initialized
INFO - 2023-04-17 08:32:25 --> Output Class Initialized
INFO - 2023-04-17 08:32:25 --> Security Class Initialized
INFO - 2023-04-17 08:32:25 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:25 --> Input Class Initialized
INFO - 2023-04-17 08:32:25 --> Input Class Initialized
INFO - 2023-04-17 08:32:25 --> Language Class Initialized
INFO - 2023-04-17 08:32:25 --> Language Class Initialized
INFO - 2023-04-17 08:32:25 --> Loader Class Initialized
INFO - 2023-04-17 08:32:25 --> Loader Class Initialized
INFO - 2023-04-17 08:32:25 --> Controller Class Initialized
INFO - 2023-04-17 08:32:25 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:32:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:25 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:25 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:25 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:25 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:25 --> Total execution time: 0.0152
INFO - 2023-04-17 08:32:25 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:25 --> Config Class Initialized
INFO - 2023-04-17 08:32:25 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:25 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:25 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:25 --> URI Class Initialized
INFO - 2023-04-17 08:32:25 --> Router Class Initialized
INFO - 2023-04-17 08:32:25 --> Output Class Initialized
INFO - 2023-04-17 08:32:25 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:25 --> Final output sent to browser
INFO - 2023-04-17 08:32:25 --> Input Class Initialized
DEBUG - 2023-04-17 08:32:25 --> Total execution time: 0.0191
INFO - 2023-04-17 08:32:25 --> Language Class Initialized
INFO - 2023-04-17 08:32:25 --> Loader Class Initialized
INFO - 2023-04-17 08:32:25 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:25 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:25 --> Config Class Initialized
INFO - 2023-04-17 08:32:25 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:25 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:25 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:25 --> URI Class Initialized
INFO - 2023-04-17 08:32:25 --> Router Class Initialized
INFO - 2023-04-17 08:32:25 --> Output Class Initialized
INFO - 2023-04-17 08:32:25 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:25 --> Input Class Initialized
INFO - 2023-04-17 08:32:25 --> Language Class Initialized
INFO - 2023-04-17 08:32:25 --> Loader Class Initialized
INFO - 2023-04-17 08:32:25 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:25 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:25 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:25 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:25 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:25 --> Total execution time: 0.0345
INFO - 2023-04-17 08:32:25 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:25 --> Total execution time: 0.0337
INFO - 2023-04-17 08:32:26 --> Config Class Initialized
INFO - 2023-04-17 08:32:26 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:26 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:26 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:26 --> URI Class Initialized
INFO - 2023-04-17 08:32:26 --> Router Class Initialized
INFO - 2023-04-17 08:32:26 --> Output Class Initialized
INFO - 2023-04-17 08:32:26 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:26 --> Input Class Initialized
INFO - 2023-04-17 08:32:26 --> Language Class Initialized
INFO - 2023-04-17 08:32:26 --> Loader Class Initialized
INFO - 2023-04-17 08:32:26 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:26 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:26 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:26 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:26 --> Total execution time: 0.0207
INFO - 2023-04-17 08:32:26 --> Config Class Initialized
INFO - 2023-04-17 08:32:26 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:26 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:26 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:26 --> URI Class Initialized
INFO - 2023-04-17 08:32:26 --> Router Class Initialized
INFO - 2023-04-17 08:32:26 --> Output Class Initialized
INFO - 2023-04-17 08:32:26 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:26 --> Input Class Initialized
INFO - 2023-04-17 08:32:26 --> Language Class Initialized
INFO - 2023-04-17 08:32:26 --> Loader Class Initialized
INFO - 2023-04-17 08:32:26 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:26 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:26 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:26 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:26 --> Total execution time: 0.0143
INFO - 2023-04-17 08:32:28 --> Config Class Initialized
INFO - 2023-04-17 08:32:28 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:28 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:28 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:28 --> URI Class Initialized
INFO - 2023-04-17 08:32:28 --> Router Class Initialized
INFO - 2023-04-17 08:32:28 --> Output Class Initialized
INFO - 2023-04-17 08:32:28 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:28 --> Input Class Initialized
INFO - 2023-04-17 08:32:28 --> Language Class Initialized
INFO - 2023-04-17 08:32:28 --> Loader Class Initialized
INFO - 2023-04-17 08:32:28 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:28 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:28 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:28 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:28 --> Total execution time: 0.0144
INFO - 2023-04-17 08:32:28 --> Config Class Initialized
INFO - 2023-04-17 08:32:28 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:28 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:28 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:28 --> URI Class Initialized
INFO - 2023-04-17 08:32:28 --> Router Class Initialized
INFO - 2023-04-17 08:32:28 --> Output Class Initialized
INFO - 2023-04-17 08:32:28 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:28 --> Input Class Initialized
INFO - 2023-04-17 08:32:28 --> Language Class Initialized
INFO - 2023-04-17 08:32:28 --> Loader Class Initialized
INFO - 2023-04-17 08:32:28 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:28 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:28 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:28 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:28 --> Total execution time: 0.0118
INFO - 2023-04-17 08:32:28 --> Config Class Initialized
INFO - 2023-04-17 08:32:28 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:28 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:28 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:28 --> URI Class Initialized
INFO - 2023-04-17 08:32:28 --> Router Class Initialized
INFO - 2023-04-17 08:32:28 --> Output Class Initialized
INFO - 2023-04-17 08:32:28 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:28 --> Input Class Initialized
INFO - 2023-04-17 08:32:28 --> Language Class Initialized
INFO - 2023-04-17 08:32:28 --> Loader Class Initialized
INFO - 2023-04-17 08:32:28 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:28 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:28 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:28 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:28 --> Total execution time: 0.0180
INFO - 2023-04-17 08:32:28 --> Config Class Initialized
INFO - 2023-04-17 08:32:28 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:28 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:28 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:28 --> URI Class Initialized
INFO - 2023-04-17 08:32:28 --> Router Class Initialized
INFO - 2023-04-17 08:32:28 --> Output Class Initialized
INFO - 2023-04-17 08:32:28 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:28 --> Input Class Initialized
INFO - 2023-04-17 08:32:28 --> Language Class Initialized
INFO - 2023-04-17 08:32:28 --> Loader Class Initialized
INFO - 2023-04-17 08:32:28 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:28 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:28 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:28 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:28 --> Total execution time: 0.0123
INFO - 2023-04-17 08:32:29 --> Config Class Initialized
INFO - 2023-04-17 08:32:29 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:29 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:29 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:30 --> URI Class Initialized
INFO - 2023-04-17 08:32:30 --> Router Class Initialized
INFO - 2023-04-17 08:32:30 --> Output Class Initialized
INFO - 2023-04-17 08:32:30 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:30 --> Input Class Initialized
INFO - 2023-04-17 08:32:30 --> Language Class Initialized
INFO - 2023-04-17 08:32:30 --> Loader Class Initialized
INFO - 2023-04-17 08:32:30 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:30 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:30 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:30 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:30 --> Total execution time: 0.0170
INFO - 2023-04-17 08:32:30 --> Config Class Initialized
INFO - 2023-04-17 08:32:30 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:30 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:30 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:30 --> URI Class Initialized
INFO - 2023-04-17 08:32:30 --> Router Class Initialized
INFO - 2023-04-17 08:32:30 --> Output Class Initialized
INFO - 2023-04-17 08:32:30 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:30 --> Input Class Initialized
INFO - 2023-04-17 08:32:30 --> Language Class Initialized
INFO - 2023-04-17 08:32:30 --> Loader Class Initialized
INFO - 2023-04-17 08:32:30 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:30 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:30 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:30 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:30 --> Total execution time: 0.0172
INFO - 2023-04-17 08:32:32 --> Config Class Initialized
INFO - 2023-04-17 08:32:32 --> Config Class Initialized
INFO - 2023-04-17 08:32:32 --> Hooks Class Initialized
INFO - 2023-04-17 08:32:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 08:32:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:32 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:32 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:32 --> URI Class Initialized
INFO - 2023-04-17 08:32:32 --> URI Class Initialized
INFO - 2023-04-17 08:32:32 --> Router Class Initialized
INFO - 2023-04-17 08:32:32 --> Router Class Initialized
INFO - 2023-04-17 08:32:32 --> Output Class Initialized
INFO - 2023-04-17 08:32:32 --> Output Class Initialized
INFO - 2023-04-17 08:32:32 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:32 --> Security Class Initialized
INFO - 2023-04-17 08:32:32 --> Input Class Initialized
DEBUG - 2023-04-17 08:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:32 --> Language Class Initialized
INFO - 2023-04-17 08:32:32 --> Input Class Initialized
INFO - 2023-04-17 08:32:32 --> Language Class Initialized
INFO - 2023-04-17 08:32:32 --> Loader Class Initialized
INFO - 2023-04-17 08:32:32 --> Loader Class Initialized
INFO - 2023-04-17 08:32:32 --> Controller Class Initialized
INFO - 2023-04-17 08:32:32 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:32:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:32 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:32 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:32 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:32 --> Total execution time: 0.0225
INFO - 2023-04-17 08:32:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:32 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:32 --> Total execution time: 0.0702
INFO - 2023-04-17 08:32:32 --> Config Class Initialized
INFO - 2023-04-17 08:32:32 --> Config Class Initialized
INFO - 2023-04-17 08:32:32 --> Hooks Class Initialized
INFO - 2023-04-17 08:32:32 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:32:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 08:32:32 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:32:32 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:32 --> Utf8 Class Initialized
INFO - 2023-04-17 08:32:32 --> URI Class Initialized
INFO - 2023-04-17 08:32:32 --> URI Class Initialized
INFO - 2023-04-17 08:32:32 --> Router Class Initialized
INFO - 2023-04-17 08:32:32 --> Router Class Initialized
INFO - 2023-04-17 08:32:32 --> Output Class Initialized
INFO - 2023-04-17 08:32:32 --> Output Class Initialized
INFO - 2023-04-17 08:32:32 --> Security Class Initialized
INFO - 2023-04-17 08:32:32 --> Security Class Initialized
DEBUG - 2023-04-17 08:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:32 --> Input Class Initialized
DEBUG - 2023-04-17 08:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:32:32 --> Language Class Initialized
INFO - 2023-04-17 08:32:32 --> Input Class Initialized
INFO - 2023-04-17 08:32:32 --> Language Class Initialized
INFO - 2023-04-17 08:32:32 --> Loader Class Initialized
INFO - 2023-04-17 08:32:32 --> Loader Class Initialized
INFO - 2023-04-17 08:32:32 --> Controller Class Initialized
INFO - 2023-04-17 08:32:32 --> Controller Class Initialized
DEBUG - 2023-04-17 08:32:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:32:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:32:32 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:32 --> Database Driver Class Initialized
INFO - 2023-04-17 08:32:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:32 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:32:32 --> Final output sent to browser
INFO - 2023-04-17 08:32:32 --> Final output sent to browser
DEBUG - 2023-04-17 08:32:32 --> Total execution time: 0.0173
DEBUG - 2023-04-17 08:32:32 --> Total execution time: 0.0172
INFO - 2023-04-17 08:33:15 --> Config Class Initialized
INFO - 2023-04-17 08:33:15 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:33:15 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:33:15 --> Utf8 Class Initialized
INFO - 2023-04-17 08:33:15 --> URI Class Initialized
INFO - 2023-04-17 08:33:15 --> Router Class Initialized
INFO - 2023-04-17 08:33:15 --> Output Class Initialized
INFO - 2023-04-17 08:33:15 --> Security Class Initialized
DEBUG - 2023-04-17 08:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:33:15 --> Input Class Initialized
INFO - 2023-04-17 08:33:15 --> Language Class Initialized
INFO - 2023-04-17 08:33:15 --> Loader Class Initialized
INFO - 2023-04-17 08:33:15 --> Controller Class Initialized
DEBUG - 2023-04-17 08:33:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:33:15 --> Database Driver Class Initialized
INFO - 2023-04-17 08:33:15 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:33:15 --> Final output sent to browser
DEBUG - 2023-04-17 08:33:15 --> Total execution time: 0.0139
INFO - 2023-04-17 08:33:15 --> Config Class Initialized
INFO - 2023-04-17 08:33:15 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:33:15 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:33:15 --> Utf8 Class Initialized
INFO - 2023-04-17 08:33:15 --> URI Class Initialized
INFO - 2023-04-17 08:33:15 --> Router Class Initialized
INFO - 2023-04-17 08:33:15 --> Output Class Initialized
INFO - 2023-04-17 08:33:15 --> Security Class Initialized
DEBUG - 2023-04-17 08:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:33:15 --> Input Class Initialized
INFO - 2023-04-17 08:33:15 --> Language Class Initialized
INFO - 2023-04-17 08:33:15 --> Loader Class Initialized
INFO - 2023-04-17 08:33:15 --> Controller Class Initialized
DEBUG - 2023-04-17 08:33:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:33:15 --> Database Driver Class Initialized
INFO - 2023-04-17 08:33:15 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:33:15 --> Final output sent to browser
DEBUG - 2023-04-17 08:33:15 --> Total execution time: 0.0559
INFO - 2023-04-17 08:33:15 --> Config Class Initialized
INFO - 2023-04-17 08:33:15 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:33:15 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:33:15 --> Utf8 Class Initialized
INFO - 2023-04-17 08:33:15 --> URI Class Initialized
INFO - 2023-04-17 08:33:15 --> Router Class Initialized
INFO - 2023-04-17 08:33:15 --> Output Class Initialized
INFO - 2023-04-17 08:33:15 --> Security Class Initialized
DEBUG - 2023-04-17 08:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:33:15 --> Input Class Initialized
INFO - 2023-04-17 08:33:15 --> Language Class Initialized
INFO - 2023-04-17 08:33:15 --> Loader Class Initialized
INFO - 2023-04-17 08:33:15 --> Controller Class Initialized
DEBUG - 2023-04-17 08:33:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:33:15 --> Database Driver Class Initialized
INFO - 2023-04-17 08:33:15 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:33:15 --> Final output sent to browser
DEBUG - 2023-04-17 08:33:15 --> Total execution time: 0.0536
INFO - 2023-04-17 08:33:15 --> Config Class Initialized
INFO - 2023-04-17 08:33:15 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:33:15 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:33:15 --> Utf8 Class Initialized
INFO - 2023-04-17 08:33:15 --> URI Class Initialized
INFO - 2023-04-17 08:33:15 --> Router Class Initialized
INFO - 2023-04-17 08:33:15 --> Output Class Initialized
INFO - 2023-04-17 08:33:15 --> Security Class Initialized
DEBUG - 2023-04-17 08:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:33:15 --> Input Class Initialized
INFO - 2023-04-17 08:33:15 --> Language Class Initialized
INFO - 2023-04-17 08:33:15 --> Loader Class Initialized
INFO - 2023-04-17 08:33:15 --> Controller Class Initialized
DEBUG - 2023-04-17 08:33:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:33:15 --> Database Driver Class Initialized
INFO - 2023-04-17 08:33:15 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:33:15 --> Final output sent to browser
DEBUG - 2023-04-17 08:33:15 --> Total execution time: 0.0514
INFO - 2023-04-17 08:34:31 --> Config Class Initialized
INFO - 2023-04-17 08:34:31 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:34:31 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:34:31 --> Utf8 Class Initialized
INFO - 2023-04-17 08:34:31 --> URI Class Initialized
INFO - 2023-04-17 08:34:31 --> Router Class Initialized
INFO - 2023-04-17 08:34:31 --> Output Class Initialized
INFO - 2023-04-17 08:34:31 --> Security Class Initialized
DEBUG - 2023-04-17 08:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:34:31 --> Input Class Initialized
INFO - 2023-04-17 08:34:31 --> Language Class Initialized
INFO - 2023-04-17 08:34:31 --> Loader Class Initialized
INFO - 2023-04-17 08:34:31 --> Controller Class Initialized
DEBUG - 2023-04-17 08:34:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:34:31 --> Database Driver Class Initialized
INFO - 2023-04-17 08:34:31 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:34:31 --> Database Driver Class Initialized
INFO - 2023-04-17 08:34:31 --> Model "Login_model" initialized
INFO - 2023-04-17 08:34:31 --> Final output sent to browser
DEBUG - 2023-04-17 08:34:31 --> Total execution time: 0.0558
INFO - 2023-04-17 08:34:31 --> Config Class Initialized
INFO - 2023-04-17 08:34:31 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:34:31 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:34:31 --> Utf8 Class Initialized
INFO - 2023-04-17 08:34:31 --> URI Class Initialized
INFO - 2023-04-17 08:34:31 --> Router Class Initialized
INFO - 2023-04-17 08:34:31 --> Output Class Initialized
INFO - 2023-04-17 08:34:31 --> Security Class Initialized
DEBUG - 2023-04-17 08:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:34:31 --> Input Class Initialized
INFO - 2023-04-17 08:34:31 --> Language Class Initialized
INFO - 2023-04-17 08:34:31 --> Loader Class Initialized
INFO - 2023-04-17 08:34:31 --> Controller Class Initialized
DEBUG - 2023-04-17 08:34:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:34:31 --> Database Driver Class Initialized
INFO - 2023-04-17 08:34:31 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:34:31 --> Database Driver Class Initialized
INFO - 2023-04-17 08:34:31 --> Model "Login_model" initialized
INFO - 2023-04-17 08:34:31 --> Final output sent to browser
DEBUG - 2023-04-17 08:34:31 --> Total execution time: 0.1792
INFO - 2023-04-17 08:34:37 --> Config Class Initialized
INFO - 2023-04-17 08:34:37 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:34:37 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:34:37 --> Utf8 Class Initialized
INFO - 2023-04-17 08:34:37 --> URI Class Initialized
INFO - 2023-04-17 08:34:37 --> Router Class Initialized
INFO - 2023-04-17 08:34:37 --> Output Class Initialized
INFO - 2023-04-17 08:34:37 --> Security Class Initialized
DEBUG - 2023-04-17 08:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:34:37 --> Input Class Initialized
INFO - 2023-04-17 08:34:37 --> Language Class Initialized
INFO - 2023-04-17 08:34:37 --> Loader Class Initialized
INFO - 2023-04-17 08:34:37 --> Controller Class Initialized
DEBUG - 2023-04-17 08:34:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:34:37 --> Database Driver Class Initialized
INFO - 2023-04-17 08:34:37 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:34:37 --> Database Driver Class Initialized
INFO - 2023-04-17 08:34:37 --> Model "Login_model" initialized
INFO - 2023-04-17 08:34:37 --> Final output sent to browser
DEBUG - 2023-04-17 08:34:37 --> Total execution time: 0.1162
INFO - 2023-04-17 08:34:37 --> Config Class Initialized
INFO - 2023-04-17 08:34:37 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:34:37 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:34:37 --> Utf8 Class Initialized
INFO - 2023-04-17 08:34:37 --> URI Class Initialized
INFO - 2023-04-17 08:34:37 --> Router Class Initialized
INFO - 2023-04-17 08:34:37 --> Output Class Initialized
INFO - 2023-04-17 08:34:37 --> Security Class Initialized
DEBUG - 2023-04-17 08:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:34:37 --> Input Class Initialized
INFO - 2023-04-17 08:34:37 --> Language Class Initialized
INFO - 2023-04-17 08:34:37 --> Loader Class Initialized
INFO - 2023-04-17 08:34:37 --> Controller Class Initialized
DEBUG - 2023-04-17 08:34:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:34:37 --> Database Driver Class Initialized
INFO - 2023-04-17 08:34:37 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:34:37 --> Database Driver Class Initialized
INFO - 2023-04-17 08:34:37 --> Model "Login_model" initialized
INFO - 2023-04-17 08:34:37 --> Final output sent to browser
DEBUG - 2023-04-17 08:34:37 --> Total execution time: 0.1353
INFO - 2023-04-17 08:34:41 --> Config Class Initialized
INFO - 2023-04-17 08:34:41 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:34:41 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:34:41 --> Utf8 Class Initialized
INFO - 2023-04-17 08:34:41 --> URI Class Initialized
INFO - 2023-04-17 08:34:41 --> Router Class Initialized
INFO - 2023-04-17 08:34:41 --> Output Class Initialized
INFO - 2023-04-17 08:34:41 --> Security Class Initialized
DEBUG - 2023-04-17 08:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:34:41 --> Input Class Initialized
INFO - 2023-04-17 08:34:41 --> Language Class Initialized
INFO - 2023-04-17 08:34:41 --> Loader Class Initialized
INFO - 2023-04-17 08:34:41 --> Controller Class Initialized
DEBUG - 2023-04-17 08:34:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:34:41 --> Database Driver Class Initialized
INFO - 2023-04-17 08:34:41 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:34:41 --> Database Driver Class Initialized
INFO - 2023-04-17 08:34:41 --> Model "Login_model" initialized
INFO - 2023-04-17 08:34:41 --> Final output sent to browser
DEBUG - 2023-04-17 08:34:41 --> Total execution time: 0.0631
INFO - 2023-04-17 08:34:41 --> Config Class Initialized
INFO - 2023-04-17 08:34:41 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:34:41 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:34:41 --> Utf8 Class Initialized
INFO - 2023-04-17 08:34:41 --> URI Class Initialized
INFO - 2023-04-17 08:34:41 --> Router Class Initialized
INFO - 2023-04-17 08:34:41 --> Output Class Initialized
INFO - 2023-04-17 08:34:41 --> Security Class Initialized
DEBUG - 2023-04-17 08:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:34:41 --> Input Class Initialized
INFO - 2023-04-17 08:34:41 --> Language Class Initialized
INFO - 2023-04-17 08:34:41 --> Loader Class Initialized
INFO - 2023-04-17 08:34:41 --> Controller Class Initialized
DEBUG - 2023-04-17 08:34:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:34:41 --> Database Driver Class Initialized
INFO - 2023-04-17 08:34:41 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:34:41 --> Database Driver Class Initialized
INFO - 2023-04-17 08:34:41 --> Model "Login_model" initialized
INFO - 2023-04-17 08:34:41 --> Final output sent to browser
DEBUG - 2023-04-17 08:34:41 --> Total execution time: 0.0587
INFO - 2023-04-17 08:40:03 --> Config Class Initialized
INFO - 2023-04-17 08:40:03 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:40:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:40:03 --> Utf8 Class Initialized
INFO - 2023-04-17 08:40:03 --> URI Class Initialized
INFO - 2023-04-17 08:40:03 --> Router Class Initialized
INFO - 2023-04-17 08:40:03 --> Output Class Initialized
INFO - 2023-04-17 08:40:03 --> Security Class Initialized
DEBUG - 2023-04-17 08:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:40:03 --> Input Class Initialized
INFO - 2023-04-17 08:40:03 --> Language Class Initialized
INFO - 2023-04-17 08:40:03 --> Loader Class Initialized
INFO - 2023-04-17 08:40:03 --> Controller Class Initialized
DEBUG - 2023-04-17 08:40:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:40:03 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:03 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:40:03 --> Final output sent to browser
DEBUG - 2023-04-17 08:40:03 --> Total execution time: 0.0450
INFO - 2023-04-17 08:40:03 --> Config Class Initialized
INFO - 2023-04-17 08:40:03 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:40:03 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:40:03 --> Utf8 Class Initialized
INFO - 2023-04-17 08:40:03 --> URI Class Initialized
INFO - 2023-04-17 08:40:03 --> Router Class Initialized
INFO - 2023-04-17 08:40:03 --> Output Class Initialized
INFO - 2023-04-17 08:40:03 --> Security Class Initialized
DEBUG - 2023-04-17 08:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:40:03 --> Input Class Initialized
INFO - 2023-04-17 08:40:03 --> Language Class Initialized
INFO - 2023-04-17 08:40:03 --> Loader Class Initialized
INFO - 2023-04-17 08:40:03 --> Controller Class Initialized
DEBUG - 2023-04-17 08:40:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:40:03 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:03 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:40:03 --> Final output sent to browser
DEBUG - 2023-04-17 08:40:03 --> Total execution time: 0.1173
INFO - 2023-04-17 08:40:09 --> Config Class Initialized
INFO - 2023-04-17 08:40:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:40:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:40:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:40:09 --> URI Class Initialized
INFO - 2023-04-17 08:40:09 --> Router Class Initialized
INFO - 2023-04-17 08:40:09 --> Output Class Initialized
INFO - 2023-04-17 08:40:09 --> Security Class Initialized
DEBUG - 2023-04-17 08:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:40:09 --> Input Class Initialized
INFO - 2023-04-17 08:40:09 --> Language Class Initialized
INFO - 2023-04-17 08:40:09 --> Loader Class Initialized
INFO - 2023-04-17 08:40:09 --> Controller Class Initialized
DEBUG - 2023-04-17 08:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:40:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:40:09 --> Final output sent to browser
DEBUG - 2023-04-17 08:40:09 --> Total execution time: 0.0604
INFO - 2023-04-17 08:40:09 --> Config Class Initialized
INFO - 2023-04-17 08:40:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:40:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:40:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:40:09 --> URI Class Initialized
INFO - 2023-04-17 08:40:09 --> Router Class Initialized
INFO - 2023-04-17 08:40:09 --> Output Class Initialized
INFO - 2023-04-17 08:40:09 --> Security Class Initialized
DEBUG - 2023-04-17 08:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:40:09 --> Input Class Initialized
INFO - 2023-04-17 08:40:09 --> Language Class Initialized
INFO - 2023-04-17 08:40:09 --> Loader Class Initialized
INFO - 2023-04-17 08:40:09 --> Controller Class Initialized
DEBUG - 2023-04-17 08:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:40:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:40:09 --> Final output sent to browser
DEBUG - 2023-04-17 08:40:09 --> Total execution time: 0.0197
INFO - 2023-04-17 08:40:09 --> Config Class Initialized
INFO - 2023-04-17 08:40:09 --> Hooks Class Initialized
INFO - 2023-04-17 08:40:09 --> Config Class Initialized
INFO - 2023-04-17 08:40:09 --> Config Class Initialized
INFO - 2023-04-17 08:40:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:40:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:40:09 --> Hooks Class Initialized
INFO - 2023-04-17 08:40:09 --> Utf8 Class Initialized
DEBUG - 2023-04-17 08:40:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 08:40:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:40:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:40:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:40:09 --> URI Class Initialized
INFO - 2023-04-17 08:40:09 --> URI Class Initialized
INFO - 2023-04-17 08:40:09 --> URI Class Initialized
INFO - 2023-04-17 08:40:09 --> Router Class Initialized
INFO - 2023-04-17 08:40:09 --> Router Class Initialized
INFO - 2023-04-17 08:40:09 --> Router Class Initialized
INFO - 2023-04-17 08:40:09 --> Output Class Initialized
INFO - 2023-04-17 08:40:09 --> Output Class Initialized
INFO - 2023-04-17 08:40:09 --> Output Class Initialized
INFO - 2023-04-17 08:40:09 --> Security Class Initialized
INFO - 2023-04-17 08:40:09 --> Security Class Initialized
INFO - 2023-04-17 08:40:09 --> Security Class Initialized
DEBUG - 2023-04-17 08:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:40:09 --> Input Class Initialized
INFO - 2023-04-17 08:40:09 --> Input Class Initialized
INFO - 2023-04-17 08:40:09 --> Input Class Initialized
INFO - 2023-04-17 08:40:09 --> Language Class Initialized
INFO - 2023-04-17 08:40:09 --> Language Class Initialized
INFO - 2023-04-17 08:40:09 --> Language Class Initialized
INFO - 2023-04-17 08:40:09 --> Loader Class Initialized
INFO - 2023-04-17 08:40:09 --> Loader Class Initialized
INFO - 2023-04-17 08:40:09 --> Controller Class Initialized
INFO - 2023-04-17 08:40:09 --> Loader Class Initialized
INFO - 2023-04-17 08:40:09 --> Controller Class Initialized
DEBUG - 2023-04-17 08:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:40:09 --> Controller Class Initialized
DEBUG - 2023-04-17 08:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:40:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:40:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:40:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:09 --> Model "Login_model" initialized
INFO - 2023-04-17 08:40:09 --> Final output sent to browser
INFO - 2023-04-17 08:40:09 --> Final output sent to browser
INFO - 2023-04-17 08:40:09 --> Final output sent to browser
DEBUG - 2023-04-17 08:40:09 --> Total execution time: 0.0467
DEBUG - 2023-04-17 08:40:09 --> Total execution time: 0.0466
DEBUG - 2023-04-17 08:40:09 --> Total execution time: 0.0481
INFO - 2023-04-17 08:40:09 --> Config Class Initialized
INFO - 2023-04-17 08:40:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:40:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:40:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:40:09 --> Config Class Initialized
INFO - 2023-04-17 08:40:09 --> Config Class Initialized
INFO - 2023-04-17 08:40:09 --> Hooks Class Initialized
INFO - 2023-04-17 08:40:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:40:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:40:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:40:09 --> URI Class Initialized
DEBUG - 2023-04-17 08:40:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:40:09 --> URI Class Initialized
INFO - 2023-04-17 08:40:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:40:09 --> Router Class Initialized
INFO - 2023-04-17 08:40:09 --> Router Class Initialized
INFO - 2023-04-17 08:40:09 --> URI Class Initialized
INFO - 2023-04-17 08:40:09 --> Output Class Initialized
INFO - 2023-04-17 08:40:09 --> Output Class Initialized
INFO - 2023-04-17 08:40:09 --> Router Class Initialized
INFO - 2023-04-17 08:40:09 --> Security Class Initialized
INFO - 2023-04-17 08:40:09 --> Output Class Initialized
INFO - 2023-04-17 08:40:09 --> Security Class Initialized
INFO - 2023-04-17 08:40:09 --> Security Class Initialized
DEBUG - 2023-04-17 08:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:40:09 --> Input Class Initialized
INFO - 2023-04-17 08:40:09 --> Input Class Initialized
INFO - 2023-04-17 08:40:09 --> Input Class Initialized
INFO - 2023-04-17 08:40:09 --> Language Class Initialized
INFO - 2023-04-17 08:40:09 --> Language Class Initialized
INFO - 2023-04-17 08:40:09 --> Language Class Initialized
INFO - 2023-04-17 08:40:09 --> Loader Class Initialized
INFO - 2023-04-17 08:40:09 --> Loader Class Initialized
INFO - 2023-04-17 08:40:09 --> Loader Class Initialized
INFO - 2023-04-17 08:40:09 --> Controller Class Initialized
INFO - 2023-04-17 08:40:09 --> Controller Class Initialized
INFO - 2023-04-17 08:40:09 --> Controller Class Initialized
DEBUG - 2023-04-17 08:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:40:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:40:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:40:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:09 --> Model "Login_model" initialized
INFO - 2023-04-17 08:40:09 --> Final output sent to browser
INFO - 2023-04-17 08:40:09 --> Final output sent to browser
INFO - 2023-04-17 08:40:09 --> Final output sent to browser
DEBUG - 2023-04-17 08:40:09 --> Total execution time: 0.1117
DEBUG - 2023-04-17 08:40:09 --> Total execution time: 0.1149
DEBUG - 2023-04-17 08:40:09 --> Total execution time: 0.1118
INFO - 2023-04-17 08:40:09 --> Config Class Initialized
INFO - 2023-04-17 08:40:09 --> Config Class Initialized
INFO - 2023-04-17 08:40:09 --> Hooks Class Initialized
INFO - 2023-04-17 08:40:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:40:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 08:40:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:40:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:40:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:40:09 --> URI Class Initialized
INFO - 2023-04-17 08:40:09 --> URI Class Initialized
INFO - 2023-04-17 08:40:09 --> Router Class Initialized
INFO - 2023-04-17 08:40:09 --> Router Class Initialized
INFO - 2023-04-17 08:40:09 --> Output Class Initialized
INFO - 2023-04-17 08:40:09 --> Output Class Initialized
INFO - 2023-04-17 08:40:09 --> Security Class Initialized
INFO - 2023-04-17 08:40:09 --> Security Class Initialized
DEBUG - 2023-04-17 08:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:40:09 --> Input Class Initialized
INFO - 2023-04-17 08:40:09 --> Input Class Initialized
INFO - 2023-04-17 08:40:09 --> Language Class Initialized
INFO - 2023-04-17 08:40:09 --> Language Class Initialized
INFO - 2023-04-17 08:40:09 --> Loader Class Initialized
INFO - 2023-04-17 08:40:09 --> Loader Class Initialized
INFO - 2023-04-17 08:40:09 --> Controller Class Initialized
INFO - 2023-04-17 08:40:09 --> Controller Class Initialized
DEBUG - 2023-04-17 08:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:40:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:40:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:40:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:40:10 --> Final output sent to browser
INFO - 2023-04-17 08:40:10 --> Final output sent to browser
DEBUG - 2023-04-17 08:40:10 --> Total execution time: 0.1164
DEBUG - 2023-04-17 08:40:10 --> Total execution time: 0.1137
INFO - 2023-04-17 08:41:09 --> Config Class Initialized
INFO - 2023-04-17 08:41:09 --> Config Class Initialized
INFO - 2023-04-17 08:41:09 --> Hooks Class Initialized
INFO - 2023-04-17 08:41:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:41:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 08:41:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:41:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:41:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:41:09 --> URI Class Initialized
INFO - 2023-04-17 08:41:09 --> URI Class Initialized
INFO - 2023-04-17 08:41:09 --> Router Class Initialized
INFO - 2023-04-17 08:41:09 --> Router Class Initialized
INFO - 2023-04-17 08:41:09 --> Output Class Initialized
INFO - 2023-04-17 08:41:09 --> Output Class Initialized
INFO - 2023-04-17 08:41:09 --> Security Class Initialized
INFO - 2023-04-17 08:41:09 --> Security Class Initialized
DEBUG - 2023-04-17 08:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:41:09 --> Input Class Initialized
INFO - 2023-04-17 08:41:09 --> Input Class Initialized
INFO - 2023-04-17 08:41:09 --> Language Class Initialized
INFO - 2023-04-17 08:41:09 --> Language Class Initialized
INFO - 2023-04-17 08:41:09 --> Loader Class Initialized
INFO - 2023-04-17 08:41:09 --> Loader Class Initialized
INFO - 2023-04-17 08:41:09 --> Controller Class Initialized
INFO - 2023-04-17 08:41:09 --> Controller Class Initialized
DEBUG - 2023-04-17 08:41:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:41:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:41:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:41:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:41:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:41:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:41:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:41:09 --> Model "Login_model" initialized
INFO - 2023-04-17 08:41:09 --> Final output sent to browser
DEBUG - 2023-04-17 08:41:09 --> Total execution time: 0.0971
INFO - 2023-04-17 08:41:09 --> Config Class Initialized
INFO - 2023-04-17 08:41:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:41:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:41:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:41:09 --> URI Class Initialized
INFO - 2023-04-17 08:41:09 --> Router Class Initialized
INFO - 2023-04-17 08:41:09 --> Output Class Initialized
INFO - 2023-04-17 08:41:09 --> Security Class Initialized
DEBUG - 2023-04-17 08:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:41:09 --> Input Class Initialized
INFO - 2023-04-17 08:41:09 --> Language Class Initialized
INFO - 2023-04-17 08:41:09 --> Loader Class Initialized
INFO - 2023-04-17 08:41:09 --> Controller Class Initialized
DEBUG - 2023-04-17 08:41:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:41:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:41:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:41:09 --> Final output sent to browser
DEBUG - 2023-04-17 08:41:09 --> Total execution time: 0.1050
INFO - 2023-04-17 08:41:10 --> Final output sent to browser
DEBUG - 2023-04-17 08:41:10 --> Total execution time: 0.7162
INFO - 2023-04-17 08:41:10 --> Config Class Initialized
INFO - 2023-04-17 08:41:10 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:41:10 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:41:10 --> Utf8 Class Initialized
INFO - 2023-04-17 08:41:10 --> URI Class Initialized
INFO - 2023-04-17 08:41:10 --> Router Class Initialized
INFO - 2023-04-17 08:41:10 --> Output Class Initialized
INFO - 2023-04-17 08:41:10 --> Security Class Initialized
DEBUG - 2023-04-17 08:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:41:10 --> Input Class Initialized
INFO - 2023-04-17 08:41:10 --> Language Class Initialized
INFO - 2023-04-17 08:41:10 --> Loader Class Initialized
INFO - 2023-04-17 08:41:10 --> Controller Class Initialized
DEBUG - 2023-04-17 08:41:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:41:10 --> Database Driver Class Initialized
INFO - 2023-04-17 08:41:10 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:41:10 --> Database Driver Class Initialized
INFO - 2023-04-17 08:41:10 --> Model "Login_model" initialized
INFO - 2023-04-17 08:41:11 --> Final output sent to browser
DEBUG - 2023-04-17 08:41:11 --> Total execution time: 0.6104
INFO - 2023-04-17 08:42:09 --> Config Class Initialized
INFO - 2023-04-17 08:42:09 --> Config Class Initialized
INFO - 2023-04-17 08:42:09 --> Hooks Class Initialized
INFO - 2023-04-17 08:42:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:42:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 08:42:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:42:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:42:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:42:09 --> URI Class Initialized
INFO - 2023-04-17 08:42:09 --> URI Class Initialized
INFO - 2023-04-17 08:42:09 --> Router Class Initialized
INFO - 2023-04-17 08:42:09 --> Router Class Initialized
INFO - 2023-04-17 08:42:09 --> Output Class Initialized
INFO - 2023-04-17 08:42:09 --> Output Class Initialized
INFO - 2023-04-17 08:42:09 --> Security Class Initialized
INFO - 2023-04-17 08:42:09 --> Security Class Initialized
DEBUG - 2023-04-17 08:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:42:09 --> Input Class Initialized
INFO - 2023-04-17 08:42:09 --> Input Class Initialized
INFO - 2023-04-17 08:42:09 --> Language Class Initialized
INFO - 2023-04-17 08:42:09 --> Language Class Initialized
INFO - 2023-04-17 08:42:09 --> Loader Class Initialized
INFO - 2023-04-17 08:42:09 --> Loader Class Initialized
INFO - 2023-04-17 08:42:09 --> Controller Class Initialized
INFO - 2023-04-17 08:42:09 --> Controller Class Initialized
DEBUG - 2023-04-17 08:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:42:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:42:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:42:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:42:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:42:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:42:09 --> Model "Login_model" initialized
INFO - 2023-04-17 08:42:09 --> Final output sent to browser
DEBUG - 2023-04-17 08:42:09 --> Total execution time: 0.0950
INFO - 2023-04-17 08:42:09 --> Config Class Initialized
INFO - 2023-04-17 08:42:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:42:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:42:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:42:09 --> URI Class Initialized
INFO - 2023-04-17 08:42:09 --> Router Class Initialized
INFO - 2023-04-17 08:42:09 --> Output Class Initialized
INFO - 2023-04-17 08:42:09 --> Security Class Initialized
DEBUG - 2023-04-17 08:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:42:09 --> Input Class Initialized
INFO - 2023-04-17 08:42:09 --> Language Class Initialized
INFO - 2023-04-17 08:42:09 --> Loader Class Initialized
INFO - 2023-04-17 08:42:09 --> Controller Class Initialized
DEBUG - 2023-04-17 08:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:42:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:42:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:42:09 --> Final output sent to browser
DEBUG - 2023-04-17 08:42:09 --> Total execution time: 0.0287
INFO - 2023-04-17 08:42:10 --> Final output sent to browser
DEBUG - 2023-04-17 08:42:10 --> Total execution time: 0.4417
INFO - 2023-04-17 08:42:10 --> Config Class Initialized
INFO - 2023-04-17 08:42:10 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:42:10 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:42:10 --> Utf8 Class Initialized
INFO - 2023-04-17 08:42:10 --> URI Class Initialized
INFO - 2023-04-17 08:42:10 --> Router Class Initialized
INFO - 2023-04-17 08:42:10 --> Output Class Initialized
INFO - 2023-04-17 08:42:10 --> Security Class Initialized
DEBUG - 2023-04-17 08:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:42:10 --> Input Class Initialized
INFO - 2023-04-17 08:42:10 --> Language Class Initialized
INFO - 2023-04-17 08:42:10 --> Loader Class Initialized
INFO - 2023-04-17 08:42:10 --> Controller Class Initialized
DEBUG - 2023-04-17 08:42:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:42:10 --> Database Driver Class Initialized
INFO - 2023-04-17 08:42:10 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:42:10 --> Database Driver Class Initialized
INFO - 2023-04-17 08:42:10 --> Model "Login_model" initialized
INFO - 2023-04-17 08:42:10 --> Final output sent to browser
DEBUG - 2023-04-17 08:42:10 --> Total execution time: 0.4571
INFO - 2023-04-17 08:43:09 --> Config Class Initialized
INFO - 2023-04-17 08:43:09 --> Config Class Initialized
INFO - 2023-04-17 08:43:09 --> Hooks Class Initialized
INFO - 2023-04-17 08:43:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:43:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:43:09 --> Utf8 Class Initialized
DEBUG - 2023-04-17 08:43:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:43:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:43:09 --> URI Class Initialized
INFO - 2023-04-17 08:43:09 --> URI Class Initialized
INFO - 2023-04-17 08:43:09 --> Router Class Initialized
INFO - 2023-04-17 08:43:09 --> Router Class Initialized
INFO - 2023-04-17 08:43:09 --> Output Class Initialized
INFO - 2023-04-17 08:43:09 --> Output Class Initialized
INFO - 2023-04-17 08:43:09 --> Security Class Initialized
INFO - 2023-04-17 08:43:09 --> Security Class Initialized
DEBUG - 2023-04-17 08:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 08:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:43:09 --> Input Class Initialized
INFO - 2023-04-17 08:43:09 --> Input Class Initialized
INFO - 2023-04-17 08:43:09 --> Language Class Initialized
INFO - 2023-04-17 08:43:09 --> Language Class Initialized
INFO - 2023-04-17 08:43:09 --> Loader Class Initialized
INFO - 2023-04-17 08:43:09 --> Loader Class Initialized
INFO - 2023-04-17 08:43:09 --> Controller Class Initialized
INFO - 2023-04-17 08:43:09 --> Controller Class Initialized
DEBUG - 2023-04-17 08:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 08:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:43:09 --> Final output sent to browser
INFO - 2023-04-17 08:43:09 --> Database Driver Class Initialized
DEBUG - 2023-04-17 08:43:09 --> Total execution time: 0.0044
INFO - 2023-04-17 08:43:09 --> Config Class Initialized
INFO - 2023-04-17 08:43:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:43:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:43:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:43:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:43:09 --> URI Class Initialized
INFO - 2023-04-17 08:43:09 --> Router Class Initialized
INFO - 2023-04-17 08:43:09 --> Output Class Initialized
INFO - 2023-04-17 08:43:09 --> Security Class Initialized
DEBUG - 2023-04-17 08:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:43:09 --> Input Class Initialized
INFO - 2023-04-17 08:43:09 --> Language Class Initialized
INFO - 2023-04-17 08:43:09 --> Loader Class Initialized
INFO - 2023-04-17 08:43:09 --> Controller Class Initialized
DEBUG - 2023-04-17 08:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:43:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:43:09 --> Final output sent to browser
DEBUG - 2023-04-17 08:43:09 --> Total execution time: 0.0499
INFO - 2023-04-17 08:43:09 --> Config Class Initialized
INFO - 2023-04-17 08:43:09 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:43:09 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:43:09 --> Utf8 Class Initialized
INFO - 2023-04-17 08:43:09 --> URI Class Initialized
INFO - 2023-04-17 08:43:09 --> Router Class Initialized
INFO - 2023-04-17 08:43:09 --> Output Class Initialized
INFO - 2023-04-17 08:43:09 --> Security Class Initialized
DEBUG - 2023-04-17 08:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:43:09 --> Input Class Initialized
INFO - 2023-04-17 08:43:09 --> Language Class Initialized
INFO - 2023-04-17 08:43:09 --> Loader Class Initialized
INFO - 2023-04-17 08:43:09 --> Controller Class Initialized
DEBUG - 2023-04-17 08:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:43:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:43:09 --> Model "Login_model" initialized
INFO - 2023-04-17 08:43:09 --> Database Driver Class Initialized
INFO - 2023-04-17 08:43:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:43:09 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:43:09 --> Final output sent to browser
DEBUG - 2023-04-17 08:43:09 --> Total execution time: 0.0614
INFO - 2023-04-17 08:43:09 --> Final output sent to browser
DEBUG - 2023-04-17 08:43:09 --> Total execution time: 0.0163
INFO - 2023-04-17 08:43:12 --> Config Class Initialized
INFO - 2023-04-17 08:43:12 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:43:12 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:43:12 --> Utf8 Class Initialized
INFO - 2023-04-17 08:43:12 --> URI Class Initialized
INFO - 2023-04-17 08:43:12 --> Router Class Initialized
INFO - 2023-04-17 08:43:12 --> Output Class Initialized
INFO - 2023-04-17 08:43:12 --> Security Class Initialized
DEBUG - 2023-04-17 08:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:43:12 --> Input Class Initialized
INFO - 2023-04-17 08:43:12 --> Language Class Initialized
INFO - 2023-04-17 08:43:12 --> Loader Class Initialized
INFO - 2023-04-17 08:43:12 --> Controller Class Initialized
DEBUG - 2023-04-17 08:43:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:43:12 --> Database Driver Class Initialized
INFO - 2023-04-17 08:43:12 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:43:12 --> Database Driver Class Initialized
INFO - 2023-04-17 08:43:12 --> Model "Login_model" initialized
INFO - 2023-04-17 08:43:12 --> Final output sent to browser
DEBUG - 2023-04-17 08:43:12 --> Total execution time: 0.1031
INFO - 2023-04-17 08:43:12 --> Config Class Initialized
INFO - 2023-04-17 08:43:12 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:43:12 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:43:12 --> Utf8 Class Initialized
INFO - 2023-04-17 08:43:12 --> URI Class Initialized
INFO - 2023-04-17 08:43:12 --> Router Class Initialized
INFO - 2023-04-17 08:43:12 --> Output Class Initialized
INFO - 2023-04-17 08:43:12 --> Security Class Initialized
DEBUG - 2023-04-17 08:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:43:12 --> Input Class Initialized
INFO - 2023-04-17 08:43:12 --> Language Class Initialized
INFO - 2023-04-17 08:43:12 --> Loader Class Initialized
INFO - 2023-04-17 08:43:12 --> Controller Class Initialized
DEBUG - 2023-04-17 08:43:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:43:12 --> Database Driver Class Initialized
INFO - 2023-04-17 08:43:12 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:43:12 --> Database Driver Class Initialized
INFO - 2023-04-17 08:43:12 --> Model "Login_model" initialized
INFO - 2023-04-17 08:43:12 --> Final output sent to browser
DEBUG - 2023-04-17 08:43:12 --> Total execution time: 0.1444
INFO - 2023-04-17 08:47:58 --> Config Class Initialized
INFO - 2023-04-17 08:47:58 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:47:58 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:47:58 --> Utf8 Class Initialized
INFO - 2023-04-17 08:47:58 --> URI Class Initialized
INFO - 2023-04-17 08:47:58 --> Router Class Initialized
INFO - 2023-04-17 08:47:58 --> Output Class Initialized
INFO - 2023-04-17 08:47:58 --> Security Class Initialized
DEBUG - 2023-04-17 08:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:47:58 --> Input Class Initialized
INFO - 2023-04-17 08:47:58 --> Language Class Initialized
INFO - 2023-04-17 08:47:58 --> Loader Class Initialized
INFO - 2023-04-17 08:47:58 --> Controller Class Initialized
DEBUG - 2023-04-17 08:47:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:47:58 --> Database Driver Class Initialized
INFO - 2023-04-17 08:47:58 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:47:58 --> Database Driver Class Initialized
INFO - 2023-04-17 08:47:58 --> Model "Login_model" initialized
INFO - 2023-04-17 08:47:58 --> Final output sent to browser
DEBUG - 2023-04-17 08:47:58 --> Total execution time: 0.1065
INFO - 2023-04-17 08:47:58 --> Config Class Initialized
INFO - 2023-04-17 08:47:58 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:47:58 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:47:58 --> Utf8 Class Initialized
INFO - 2023-04-17 08:47:58 --> URI Class Initialized
INFO - 2023-04-17 08:47:58 --> Router Class Initialized
INFO - 2023-04-17 08:47:58 --> Output Class Initialized
INFO - 2023-04-17 08:47:58 --> Security Class Initialized
DEBUG - 2023-04-17 08:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:47:58 --> Input Class Initialized
INFO - 2023-04-17 08:47:58 --> Language Class Initialized
INFO - 2023-04-17 08:47:58 --> Loader Class Initialized
INFO - 2023-04-17 08:47:58 --> Controller Class Initialized
DEBUG - 2023-04-17 08:47:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:47:58 --> Database Driver Class Initialized
INFO - 2023-04-17 08:47:58 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:47:58 --> Database Driver Class Initialized
INFO - 2023-04-17 08:47:58 --> Model "Login_model" initialized
INFO - 2023-04-17 08:47:58 --> Final output sent to browser
DEBUG - 2023-04-17 08:47:58 --> Total execution time: 0.0607
INFO - 2023-04-17 08:48:04 --> Config Class Initialized
INFO - 2023-04-17 08:48:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:48:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:48:04 --> Utf8 Class Initialized
INFO - 2023-04-17 08:48:04 --> URI Class Initialized
INFO - 2023-04-17 08:48:04 --> Router Class Initialized
INFO - 2023-04-17 08:48:04 --> Output Class Initialized
INFO - 2023-04-17 08:48:04 --> Security Class Initialized
DEBUG - 2023-04-17 08:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:48:04 --> Input Class Initialized
INFO - 2023-04-17 08:48:04 --> Language Class Initialized
INFO - 2023-04-17 08:48:04 --> Loader Class Initialized
INFO - 2023-04-17 08:48:04 --> Controller Class Initialized
DEBUG - 2023-04-17 08:48:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:48:04 --> Database Driver Class Initialized
INFO - 2023-04-17 08:48:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:48:04 --> Final output sent to browser
DEBUG - 2023-04-17 08:48:04 --> Total execution time: 0.0125
INFO - 2023-04-17 08:48:04 --> Config Class Initialized
INFO - 2023-04-17 08:48:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:48:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:48:04 --> Utf8 Class Initialized
INFO - 2023-04-17 08:48:04 --> URI Class Initialized
INFO - 2023-04-17 08:48:04 --> Router Class Initialized
INFO - 2023-04-17 08:48:04 --> Output Class Initialized
INFO - 2023-04-17 08:48:04 --> Security Class Initialized
DEBUG - 2023-04-17 08:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:48:04 --> Input Class Initialized
INFO - 2023-04-17 08:48:04 --> Language Class Initialized
INFO - 2023-04-17 08:48:04 --> Loader Class Initialized
INFO - 2023-04-17 08:48:04 --> Controller Class Initialized
DEBUG - 2023-04-17 08:48:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:48:04 --> Database Driver Class Initialized
INFO - 2023-04-17 08:48:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:48:04 --> Final output sent to browser
DEBUG - 2023-04-17 08:48:04 --> Total execution time: 0.0517
INFO - 2023-04-17 08:48:04 --> Config Class Initialized
INFO - 2023-04-17 08:48:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:48:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:48:04 --> Utf8 Class Initialized
INFO - 2023-04-17 08:48:04 --> URI Class Initialized
INFO - 2023-04-17 08:48:04 --> Router Class Initialized
INFO - 2023-04-17 08:48:04 --> Output Class Initialized
INFO - 2023-04-17 08:48:04 --> Security Class Initialized
DEBUG - 2023-04-17 08:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:48:04 --> Input Class Initialized
INFO - 2023-04-17 08:48:04 --> Language Class Initialized
INFO - 2023-04-17 08:48:04 --> Loader Class Initialized
INFO - 2023-04-17 08:48:04 --> Controller Class Initialized
DEBUG - 2023-04-17 08:48:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:48:04 --> Database Driver Class Initialized
INFO - 2023-04-17 08:48:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:48:04 --> Final output sent to browser
DEBUG - 2023-04-17 08:48:04 --> Total execution time: 0.0580
INFO - 2023-04-17 08:48:04 --> Config Class Initialized
INFO - 2023-04-17 08:48:04 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:48:04 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:48:04 --> Utf8 Class Initialized
INFO - 2023-04-17 08:48:04 --> URI Class Initialized
INFO - 2023-04-17 08:48:04 --> Router Class Initialized
INFO - 2023-04-17 08:48:04 --> Output Class Initialized
INFO - 2023-04-17 08:48:04 --> Security Class Initialized
DEBUG - 2023-04-17 08:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:48:04 --> Input Class Initialized
INFO - 2023-04-17 08:48:04 --> Language Class Initialized
INFO - 2023-04-17 08:48:04 --> Loader Class Initialized
INFO - 2023-04-17 08:48:04 --> Controller Class Initialized
DEBUG - 2023-04-17 08:48:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:48:04 --> Database Driver Class Initialized
INFO - 2023-04-17 08:48:04 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:48:04 --> Final output sent to browser
DEBUG - 2023-04-17 08:48:04 --> Total execution time: 0.0534
INFO - 2023-04-17 08:50:50 --> Config Class Initialized
INFO - 2023-04-17 08:50:50 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:50:50 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:50:50 --> Utf8 Class Initialized
INFO - 2023-04-17 08:50:50 --> URI Class Initialized
INFO - 2023-04-17 08:50:50 --> Router Class Initialized
INFO - 2023-04-17 08:50:50 --> Output Class Initialized
INFO - 2023-04-17 08:50:50 --> Security Class Initialized
DEBUG - 2023-04-17 08:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:50:50 --> Input Class Initialized
INFO - 2023-04-17 08:50:50 --> Language Class Initialized
INFO - 2023-04-17 08:50:50 --> Loader Class Initialized
INFO - 2023-04-17 08:50:50 --> Controller Class Initialized
DEBUG - 2023-04-17 08:50:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:50:50 --> Database Driver Class Initialized
INFO - 2023-04-17 08:50:50 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:50:50 --> Database Driver Class Initialized
INFO - 2023-04-17 08:50:50 --> Model "Login_model" initialized
INFO - 2023-04-17 08:50:50 --> Final output sent to browser
DEBUG - 2023-04-17 08:50:50 --> Total execution time: 0.0905
INFO - 2023-04-17 08:50:50 --> Config Class Initialized
INFO - 2023-04-17 08:50:50 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:50:50 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:50:50 --> Utf8 Class Initialized
INFO - 2023-04-17 08:50:50 --> URI Class Initialized
INFO - 2023-04-17 08:50:50 --> Router Class Initialized
INFO - 2023-04-17 08:50:50 --> Output Class Initialized
INFO - 2023-04-17 08:50:50 --> Security Class Initialized
DEBUG - 2023-04-17 08:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:50:50 --> Input Class Initialized
INFO - 2023-04-17 08:50:50 --> Language Class Initialized
INFO - 2023-04-17 08:50:50 --> Loader Class Initialized
INFO - 2023-04-17 08:50:50 --> Controller Class Initialized
DEBUG - 2023-04-17 08:50:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:50:50 --> Database Driver Class Initialized
INFO - 2023-04-17 08:50:50 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:50:50 --> Database Driver Class Initialized
INFO - 2023-04-17 08:50:50 --> Model "Login_model" initialized
INFO - 2023-04-17 08:50:50 --> Final output sent to browser
DEBUG - 2023-04-17 08:50:50 --> Total execution time: 0.0915
INFO - 2023-04-17 08:52:17 --> Config Class Initialized
INFO - 2023-04-17 08:52:18 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:52:18 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:52:18 --> Utf8 Class Initialized
INFO - 2023-04-17 08:52:18 --> URI Class Initialized
INFO - 2023-04-17 08:52:18 --> Router Class Initialized
INFO - 2023-04-17 08:52:18 --> Output Class Initialized
INFO - 2023-04-17 08:52:18 --> Security Class Initialized
DEBUG - 2023-04-17 08:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:52:18 --> Input Class Initialized
INFO - 2023-04-17 08:52:18 --> Language Class Initialized
INFO - 2023-04-17 08:52:18 --> Loader Class Initialized
INFO - 2023-04-17 08:52:18 --> Controller Class Initialized
DEBUG - 2023-04-17 08:52:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:52:18 --> Database Driver Class Initialized
INFO - 2023-04-17 08:52:18 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:52:18 --> Database Driver Class Initialized
INFO - 2023-04-17 08:52:18 --> Model "Login_model" initialized
INFO - 2023-04-17 08:52:18 --> Final output sent to browser
DEBUG - 2023-04-17 08:52:18 --> Total execution time: 0.1968
INFO - 2023-04-17 08:52:18 --> Config Class Initialized
INFO - 2023-04-17 08:52:18 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:52:18 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:52:18 --> Utf8 Class Initialized
INFO - 2023-04-17 08:52:18 --> URI Class Initialized
INFO - 2023-04-17 08:52:18 --> Router Class Initialized
INFO - 2023-04-17 08:52:18 --> Output Class Initialized
INFO - 2023-04-17 08:52:18 --> Security Class Initialized
DEBUG - 2023-04-17 08:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:52:18 --> Input Class Initialized
INFO - 2023-04-17 08:52:18 --> Language Class Initialized
INFO - 2023-04-17 08:52:18 --> Loader Class Initialized
INFO - 2023-04-17 08:52:18 --> Controller Class Initialized
DEBUG - 2023-04-17 08:52:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:52:18 --> Database Driver Class Initialized
INFO - 2023-04-17 08:52:18 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:52:18 --> Database Driver Class Initialized
INFO - 2023-04-17 08:52:18 --> Model "Login_model" initialized
INFO - 2023-04-17 08:52:18 --> Final output sent to browser
DEBUG - 2023-04-17 08:52:18 --> Total execution time: 0.0935
INFO - 2023-04-17 08:54:49 --> Config Class Initialized
INFO - 2023-04-17 08:54:49 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:54:49 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:54:49 --> Utf8 Class Initialized
INFO - 2023-04-17 08:54:49 --> URI Class Initialized
INFO - 2023-04-17 08:54:49 --> Router Class Initialized
INFO - 2023-04-17 08:54:49 --> Output Class Initialized
INFO - 2023-04-17 08:54:49 --> Security Class Initialized
DEBUG - 2023-04-17 08:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:54:49 --> Input Class Initialized
INFO - 2023-04-17 08:54:49 --> Language Class Initialized
INFO - 2023-04-17 08:54:49 --> Loader Class Initialized
INFO - 2023-04-17 08:54:49 --> Controller Class Initialized
DEBUG - 2023-04-17 08:54:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:54:49 --> Database Driver Class Initialized
INFO - 2023-04-17 08:54:49 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:54:49 --> Database Driver Class Initialized
INFO - 2023-04-17 08:54:49 --> Model "Login_model" initialized
INFO - 2023-04-17 08:54:49 --> Final output sent to browser
DEBUG - 2023-04-17 08:54:49 --> Total execution time: 0.2643
INFO - 2023-04-17 08:54:49 --> Config Class Initialized
INFO - 2023-04-17 08:54:49 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:54:49 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:54:49 --> Utf8 Class Initialized
INFO - 2023-04-17 08:54:49 --> URI Class Initialized
INFO - 2023-04-17 08:54:49 --> Router Class Initialized
INFO - 2023-04-17 08:54:49 --> Output Class Initialized
INFO - 2023-04-17 08:54:49 --> Security Class Initialized
DEBUG - 2023-04-17 08:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:54:49 --> Input Class Initialized
INFO - 2023-04-17 08:54:49 --> Language Class Initialized
INFO - 2023-04-17 08:54:49 --> Loader Class Initialized
INFO - 2023-04-17 08:54:49 --> Controller Class Initialized
DEBUG - 2023-04-17 08:54:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:54:49 --> Database Driver Class Initialized
INFO - 2023-04-17 08:54:49 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:54:49 --> Database Driver Class Initialized
INFO - 2023-04-17 08:54:49 --> Model "Login_model" initialized
INFO - 2023-04-17 08:54:49 --> Final output sent to browser
DEBUG - 2023-04-17 08:54:49 --> Total execution time: 0.0856
INFO - 2023-04-17 08:55:12 --> Config Class Initialized
INFO - 2023-04-17 08:55:12 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:55:12 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:55:12 --> Utf8 Class Initialized
INFO - 2023-04-17 08:55:12 --> URI Class Initialized
INFO - 2023-04-17 08:55:12 --> Router Class Initialized
INFO - 2023-04-17 08:55:12 --> Output Class Initialized
INFO - 2023-04-17 08:55:12 --> Security Class Initialized
DEBUG - 2023-04-17 08:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:55:12 --> Input Class Initialized
INFO - 2023-04-17 08:55:12 --> Language Class Initialized
INFO - 2023-04-17 08:55:12 --> Loader Class Initialized
INFO - 2023-04-17 08:55:12 --> Controller Class Initialized
DEBUG - 2023-04-17 08:55:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:55:12 --> Database Driver Class Initialized
INFO - 2023-04-17 08:55:12 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:55:12 --> Database Driver Class Initialized
INFO - 2023-04-17 08:55:12 --> Model "Login_model" initialized
INFO - 2023-04-17 08:55:12 --> Final output sent to browser
DEBUG - 2023-04-17 08:55:12 --> Total execution time: 0.1142
INFO - 2023-04-17 08:55:12 --> Config Class Initialized
INFO - 2023-04-17 08:55:12 --> Hooks Class Initialized
DEBUG - 2023-04-17 08:55:12 --> UTF-8 Support Enabled
INFO - 2023-04-17 08:55:12 --> Utf8 Class Initialized
INFO - 2023-04-17 08:55:12 --> URI Class Initialized
INFO - 2023-04-17 08:55:12 --> Router Class Initialized
INFO - 2023-04-17 08:55:12 --> Output Class Initialized
INFO - 2023-04-17 08:55:12 --> Security Class Initialized
DEBUG - 2023-04-17 08:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 08:55:12 --> Input Class Initialized
INFO - 2023-04-17 08:55:12 --> Language Class Initialized
INFO - 2023-04-17 08:55:12 --> Loader Class Initialized
INFO - 2023-04-17 08:55:12 --> Controller Class Initialized
DEBUG - 2023-04-17 08:55:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 08:55:12 --> Database Driver Class Initialized
INFO - 2023-04-17 08:55:12 --> Model "Cluster_model" initialized
INFO - 2023-04-17 08:55:12 --> Database Driver Class Initialized
INFO - 2023-04-17 08:55:12 --> Model "Login_model" initialized
INFO - 2023-04-17 08:55:12 --> Final output sent to browser
DEBUG - 2023-04-17 08:55:12 --> Total execution time: 0.2031
INFO - 2023-04-17 09:04:36 --> Config Class Initialized
INFO - 2023-04-17 09:04:36 --> Hooks Class Initialized
DEBUG - 2023-04-17 09:04:36 --> UTF-8 Support Enabled
INFO - 2023-04-17 09:04:36 --> Utf8 Class Initialized
INFO - 2023-04-17 09:04:36 --> URI Class Initialized
INFO - 2023-04-17 09:04:36 --> Router Class Initialized
INFO - 2023-04-17 09:04:36 --> Output Class Initialized
INFO - 2023-04-17 09:04:36 --> Security Class Initialized
DEBUG - 2023-04-17 09:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 09:04:36 --> Input Class Initialized
INFO - 2023-04-17 09:04:36 --> Language Class Initialized
INFO - 2023-04-17 09:04:36 --> Loader Class Initialized
INFO - 2023-04-17 09:04:36 --> Controller Class Initialized
DEBUG - 2023-04-17 09:04:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 09:04:36 --> Database Driver Class Initialized
INFO - 2023-04-17 09:04:36 --> Model "Cluster_model" initialized
INFO - 2023-04-17 09:04:36 --> Final output sent to browser
DEBUG - 2023-04-17 09:04:36 --> Total execution time: 0.1145
INFO - 2023-04-17 09:04:36 --> Config Class Initialized
INFO - 2023-04-17 09:04:37 --> Hooks Class Initialized
DEBUG - 2023-04-17 09:04:37 --> UTF-8 Support Enabled
INFO - 2023-04-17 09:04:37 --> Utf8 Class Initialized
INFO - 2023-04-17 09:04:37 --> URI Class Initialized
INFO - 2023-04-17 09:04:37 --> Router Class Initialized
INFO - 2023-04-17 09:04:37 --> Output Class Initialized
INFO - 2023-04-17 09:04:37 --> Security Class Initialized
DEBUG - 2023-04-17 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 09:04:37 --> Input Class Initialized
INFO - 2023-04-17 09:04:37 --> Language Class Initialized
INFO - 2023-04-17 09:04:37 --> Loader Class Initialized
INFO - 2023-04-17 09:04:37 --> Controller Class Initialized
DEBUG - 2023-04-17 09:04:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 09:04:37 --> Database Driver Class Initialized
INFO - 2023-04-17 09:04:37 --> Model "Cluster_model" initialized
INFO - 2023-04-17 09:04:37 --> Final output sent to browser
DEBUG - 2023-04-17 09:04:37 --> Total execution time: 0.0646
INFO - 2023-04-17 10:01:10 --> Config Class Initialized
INFO - 2023-04-17 10:01:10 --> Config Class Initialized
INFO - 2023-04-17 10:01:10 --> Hooks Class Initialized
INFO - 2023-04-17 10:01:10 --> Hooks Class Initialized
DEBUG - 2023-04-17 10:01:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-17 10:01:10 --> UTF-8 Support Enabled
INFO - 2023-04-17 10:01:10 --> Utf8 Class Initialized
INFO - 2023-04-17 10:01:10 --> Utf8 Class Initialized
INFO - 2023-04-17 10:01:10 --> URI Class Initialized
INFO - 2023-04-17 10:01:10 --> URI Class Initialized
INFO - 2023-04-17 10:01:10 --> Router Class Initialized
INFO - 2023-04-17 10:01:10 --> Router Class Initialized
INFO - 2023-04-17 10:01:10 --> Output Class Initialized
INFO - 2023-04-17 10:01:10 --> Output Class Initialized
INFO - 2023-04-17 10:01:10 --> Security Class Initialized
INFO - 2023-04-17 10:01:10 --> Security Class Initialized
DEBUG - 2023-04-17 10:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-17 10:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 10:01:10 --> Input Class Initialized
INFO - 2023-04-17 10:01:10 --> Input Class Initialized
INFO - 2023-04-17 10:01:10 --> Language Class Initialized
INFO - 2023-04-17 10:01:10 --> Language Class Initialized
INFO - 2023-04-17 10:01:10 --> Loader Class Initialized
INFO - 2023-04-17 10:01:10 --> Loader Class Initialized
INFO - 2023-04-17 10:01:10 --> Controller Class Initialized
INFO - 2023-04-17 10:01:10 --> Controller Class Initialized
DEBUG - 2023-04-17 10:01:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-17 10:01:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 10:01:10 --> Final output sent to browser
DEBUG - 2023-04-17 10:01:10 --> Total execution time: 0.0134
INFO - 2023-04-17 10:01:10 --> Database Driver Class Initialized
INFO - 2023-04-17 10:01:10 --> Config Class Initialized
INFO - 2023-04-17 10:01:10 --> Hooks Class Initialized
DEBUG - 2023-04-17 10:01:10 --> UTF-8 Support Enabled
INFO - 2023-04-17 10:01:10 --> Utf8 Class Initialized
INFO - 2023-04-17 10:01:10 --> URI Class Initialized
INFO - 2023-04-17 10:01:10 --> Router Class Initialized
INFO - 2023-04-17 10:01:10 --> Output Class Initialized
INFO - 2023-04-17 10:01:10 --> Security Class Initialized
DEBUG - 2023-04-17 10:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 10:01:10 --> Input Class Initialized
INFO - 2023-04-17 10:01:10 --> Language Class Initialized
INFO - 2023-04-17 10:01:10 --> Loader Class Initialized
INFO - 2023-04-17 10:01:10 --> Controller Class Initialized
DEBUG - 2023-04-17 10:01:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 10:01:10 --> Database Driver Class Initialized
INFO - 2023-04-17 10:01:10 --> Model "Cluster_model" initialized
INFO - 2023-04-17 10:01:10 --> Model "Login_model" initialized
INFO - 2023-04-17 10:01:10 --> Database Driver Class Initialized
INFO - 2023-04-17 10:01:10 --> Final output sent to browser
DEBUG - 2023-04-17 10:01:10 --> Total execution time: 0.0806
INFO - 2023-04-17 10:01:10 --> Model "Cluster_model" initialized
INFO - 2023-04-17 10:01:10 --> Final output sent to browser
DEBUG - 2023-04-17 10:01:10 --> Total execution time: 0.0647
INFO - 2023-04-17 10:01:10 --> Config Class Initialized
INFO - 2023-04-17 10:01:10 --> Hooks Class Initialized
DEBUG - 2023-04-17 10:01:10 --> UTF-8 Support Enabled
INFO - 2023-04-17 10:01:10 --> Utf8 Class Initialized
INFO - 2023-04-17 10:01:10 --> URI Class Initialized
INFO - 2023-04-17 10:01:10 --> Router Class Initialized
INFO - 2023-04-17 10:01:10 --> Output Class Initialized
INFO - 2023-04-17 10:01:10 --> Security Class Initialized
DEBUG - 2023-04-17 10:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 10:01:10 --> Input Class Initialized
INFO - 2023-04-17 10:01:10 --> Language Class Initialized
INFO - 2023-04-17 10:01:10 --> Loader Class Initialized
INFO - 2023-04-17 10:01:10 --> Controller Class Initialized
DEBUG - 2023-04-17 10:01:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 10:01:10 --> Database Driver Class Initialized
INFO - 2023-04-17 10:01:10 --> Model "Cluster_model" initialized
INFO - 2023-04-17 10:01:10 --> Final output sent to browser
DEBUG - 2023-04-17 10:01:10 --> Total execution time: 0.0628
INFO - 2023-04-17 10:01:14 --> Config Class Initialized
INFO - 2023-04-17 10:01:14 --> Hooks Class Initialized
DEBUG - 2023-04-17 10:01:14 --> UTF-8 Support Enabled
INFO - 2023-04-17 10:01:14 --> Utf8 Class Initialized
INFO - 2023-04-17 10:01:14 --> URI Class Initialized
INFO - 2023-04-17 10:01:14 --> Router Class Initialized
INFO - 2023-04-17 10:01:14 --> Output Class Initialized
INFO - 2023-04-17 10:01:14 --> Security Class Initialized
DEBUG - 2023-04-17 10:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 10:01:14 --> Input Class Initialized
INFO - 2023-04-17 10:01:14 --> Language Class Initialized
INFO - 2023-04-17 10:01:14 --> Loader Class Initialized
INFO - 2023-04-17 10:01:14 --> Controller Class Initialized
DEBUG - 2023-04-17 10:01:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 10:01:14 --> Database Driver Class Initialized
INFO - 2023-04-17 10:01:14 --> Model "Cluster_model" initialized
INFO - 2023-04-17 10:01:14 --> Database Driver Class Initialized
INFO - 2023-04-17 10:01:14 --> Model "Login_model" initialized
INFO - 2023-04-17 10:01:14 --> Final output sent to browser
DEBUG - 2023-04-17 10:01:14 --> Total execution time: 0.0644
INFO - 2023-04-17 10:01:14 --> Config Class Initialized
INFO - 2023-04-17 10:01:15 --> Hooks Class Initialized
DEBUG - 2023-04-17 10:01:15 --> UTF-8 Support Enabled
INFO - 2023-04-17 10:01:15 --> Utf8 Class Initialized
INFO - 2023-04-17 10:01:15 --> URI Class Initialized
INFO - 2023-04-17 10:01:15 --> Router Class Initialized
INFO - 2023-04-17 10:01:15 --> Output Class Initialized
INFO - 2023-04-17 10:01:15 --> Security Class Initialized
DEBUG - 2023-04-17 10:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 10:01:15 --> Input Class Initialized
INFO - 2023-04-17 10:01:15 --> Language Class Initialized
INFO - 2023-04-17 10:01:15 --> Loader Class Initialized
INFO - 2023-04-17 10:01:15 --> Controller Class Initialized
DEBUG - 2023-04-17 10:01:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 10:01:15 --> Database Driver Class Initialized
INFO - 2023-04-17 10:01:15 --> Model "Cluster_model" initialized
INFO - 2023-04-17 10:01:15 --> Database Driver Class Initialized
INFO - 2023-04-17 10:01:15 --> Model "Login_model" initialized
INFO - 2023-04-17 10:01:15 --> Final output sent to browser
DEBUG - 2023-04-17 10:01:15 --> Total execution time: 0.1054
INFO - 2023-04-17 10:28:57 --> Config Class Initialized
INFO - 2023-04-17 10:28:57 --> Hooks Class Initialized
DEBUG - 2023-04-17 10:28:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 10:28:57 --> Utf8 Class Initialized
INFO - 2023-04-17 10:28:57 --> URI Class Initialized
INFO - 2023-04-17 10:28:57 --> Router Class Initialized
INFO - 2023-04-17 10:28:57 --> Output Class Initialized
INFO - 2023-04-17 10:28:57 --> Security Class Initialized
DEBUG - 2023-04-17 10:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 10:28:57 --> Input Class Initialized
INFO - 2023-04-17 10:28:57 --> Language Class Initialized
INFO - 2023-04-17 10:28:57 --> Loader Class Initialized
INFO - 2023-04-17 10:28:57 --> Controller Class Initialized
DEBUG - 2023-04-17 10:28:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 10:28:57 --> Database Driver Class Initialized
INFO - 2023-04-17 10:28:57 --> Model "Cluster_model" initialized
INFO - 2023-04-17 10:28:57 --> Database Driver Class Initialized
INFO - 2023-04-17 10:28:57 --> Model "Login_model" initialized
INFO - 2023-04-17 10:28:57 --> Final output sent to browser
DEBUG - 2023-04-17 10:28:57 --> Total execution time: 0.1657
INFO - 2023-04-17 10:28:57 --> Config Class Initialized
INFO - 2023-04-17 10:28:57 --> Hooks Class Initialized
DEBUG - 2023-04-17 10:28:57 --> UTF-8 Support Enabled
INFO - 2023-04-17 10:28:57 --> Utf8 Class Initialized
INFO - 2023-04-17 10:28:57 --> URI Class Initialized
INFO - 2023-04-17 10:28:57 --> Router Class Initialized
INFO - 2023-04-17 10:28:57 --> Output Class Initialized
INFO - 2023-04-17 10:28:57 --> Security Class Initialized
DEBUG - 2023-04-17 10:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 10:28:57 --> Input Class Initialized
INFO - 2023-04-17 10:28:57 --> Language Class Initialized
INFO - 2023-04-17 10:28:57 --> Loader Class Initialized
INFO - 2023-04-17 10:28:57 --> Controller Class Initialized
DEBUG - 2023-04-17 10:28:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-17 10:28:57 --> Database Driver Class Initialized
INFO - 2023-04-17 10:28:57 --> Model "Cluster_model" initialized
INFO - 2023-04-17 10:28:57 --> Database Driver Class Initialized
INFO - 2023-04-17 10:28:57 --> Model "Login_model" initialized
INFO - 2023-04-17 10:28:57 --> Final output sent to browser
DEBUG - 2023-04-17 10:28:57 --> Total execution time: 0.1151
