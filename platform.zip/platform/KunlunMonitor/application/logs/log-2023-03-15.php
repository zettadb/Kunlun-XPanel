<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-15 01:49:48 --> Config Class Initialized
INFO - 2023-03-15 01:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:48 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:48 --> URI Class Initialized
INFO - 2023-03-15 01:49:48 --> Router Class Initialized
INFO - 2023-03-15 01:49:48 --> Output Class Initialized
INFO - 2023-03-15 01:49:48 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:48 --> Input Class Initialized
INFO - 2023-03-15 01:49:48 --> Language Class Initialized
INFO - 2023-03-15 01:49:48 --> Loader Class Initialized
INFO - 2023-03-15 01:49:48 --> Controller Class Initialized
INFO - 2023-03-15 01:49:48 --> Helper loaded: form_helper
INFO - 2023-03-15 01:49:48 --> Helper loaded: url_helper
DEBUG - 2023-03-15 01:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:48 --> Model "Change_model" initialized
INFO - 2023-03-15 01:49:48 --> Model "Grafana_model" initialized
INFO - 2023-03-15 01:49:48 --> Final output sent to browser
DEBUG - 2023-03-15 01:49:48 --> Total execution time: 0.0520
INFO - 2023-03-15 01:49:48 --> Config Class Initialized
INFO - 2023-03-15 01:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:48 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:48 --> URI Class Initialized
INFO - 2023-03-15 01:49:48 --> Router Class Initialized
INFO - 2023-03-15 01:49:48 --> Output Class Initialized
INFO - 2023-03-15 01:49:48 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:48 --> Input Class Initialized
INFO - 2023-03-15 01:49:48 --> Language Class Initialized
INFO - 2023-03-15 01:49:48 --> Loader Class Initialized
INFO - 2023-03-15 01:49:48 --> Controller Class Initialized
INFO - 2023-03-15 01:49:48 --> Helper loaded: form_helper
INFO - 2023-03-15 01:49:48 --> Helper loaded: url_helper
DEBUG - 2023-03-15 01:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:48 --> Final output sent to browser
DEBUG - 2023-03-15 01:49:48 --> Total execution time: 0.0078
INFO - 2023-03-15 01:49:48 --> Config Class Initialized
INFO - 2023-03-15 01:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:48 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:48 --> URI Class Initialized
INFO - 2023-03-15 01:49:48 --> Router Class Initialized
INFO - 2023-03-15 01:49:48 --> Output Class Initialized
INFO - 2023-03-15 01:49:48 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:48 --> Input Class Initialized
INFO - 2023-03-15 01:49:48 --> Language Class Initialized
INFO - 2023-03-15 01:49:48 --> Loader Class Initialized
INFO - 2023-03-15 01:49:48 --> Controller Class Initialized
INFO - 2023-03-15 01:49:48 --> Helper loaded: form_helper
INFO - 2023-03-15 01:49:48 --> Helper loaded: url_helper
DEBUG - 2023-03-15 01:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:48 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:48 --> Model "Login_model" initialized
INFO - 2023-03-15 01:49:48 --> Final output sent to browser
DEBUG - 2023-03-15 01:49:48 --> Total execution time: 0.0259
INFO - 2023-03-15 01:49:48 --> Config Class Initialized
INFO - 2023-03-15 01:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:48 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:48 --> URI Class Initialized
INFO - 2023-03-15 01:49:48 --> Router Class Initialized
INFO - 2023-03-15 01:49:48 --> Output Class Initialized
INFO - 2023-03-15 01:49:48 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:48 --> Input Class Initialized
INFO - 2023-03-15 01:49:48 --> Language Class Initialized
INFO - 2023-03-15 01:49:48 --> Loader Class Initialized
INFO - 2023-03-15 01:49:48 --> Controller Class Initialized
DEBUG - 2023-03-15 01:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:48 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:48 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:49:48 --> Final output sent to browser
DEBUG - 2023-03-15 01:49:48 --> Total execution time: 0.0553
INFO - 2023-03-15 01:49:48 --> Config Class Initialized
INFO - 2023-03-15 01:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:48 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:48 --> URI Class Initialized
INFO - 2023-03-15 01:49:48 --> Router Class Initialized
INFO - 2023-03-15 01:49:48 --> Output Class Initialized
INFO - 2023-03-15 01:49:48 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:48 --> Input Class Initialized
INFO - 2023-03-15 01:49:48 --> Language Class Initialized
INFO - 2023-03-15 01:49:48 --> Loader Class Initialized
INFO - 2023-03-15 01:49:48 --> Controller Class Initialized
DEBUG - 2023-03-15 01:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:48 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:48 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:49:48 --> Final output sent to browser
DEBUG - 2023-03-15 01:49:48 --> Total execution time: 0.0160
INFO - 2023-03-15 01:49:49 --> Config Class Initialized
INFO - 2023-03-15 01:49:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:49 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:49 --> URI Class Initialized
INFO - 2023-03-15 01:49:49 --> Router Class Initialized
INFO - 2023-03-15 01:49:49 --> Output Class Initialized
INFO - 2023-03-15 01:49:49 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:49 --> Input Class Initialized
INFO - 2023-03-15 01:49:49 --> Language Class Initialized
INFO - 2023-03-15 01:49:49 --> Loader Class Initialized
INFO - 2023-03-15 01:49:49 --> Controller Class Initialized
DEBUG - 2023-03-15 01:49:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:49:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:49 --> Model "Login_model" initialized
INFO - 2023-03-15 01:49:49 --> Final output sent to browser
DEBUG - 2023-03-15 01:49:49 --> Total execution time: 0.1015
INFO - 2023-03-15 01:49:49 --> Config Class Initialized
INFO - 2023-03-15 01:49:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:49 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:49 --> URI Class Initialized
INFO - 2023-03-15 01:49:49 --> Router Class Initialized
INFO - 2023-03-15 01:49:49 --> Output Class Initialized
INFO - 2023-03-15 01:49:49 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:49 --> Input Class Initialized
INFO - 2023-03-15 01:49:49 --> Language Class Initialized
INFO - 2023-03-15 01:49:49 --> Loader Class Initialized
INFO - 2023-03-15 01:49:49 --> Controller Class Initialized
DEBUG - 2023-03-15 01:49:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:49:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:49 --> Model "Login_model" initialized
INFO - 2023-03-15 01:49:49 --> Final output sent to browser
DEBUG - 2023-03-15 01:49:49 --> Total execution time: 0.0976
INFO - 2023-03-15 01:49:54 --> Config Class Initialized
INFO - 2023-03-15 01:49:54 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:54 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:54 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:54 --> URI Class Initialized
INFO - 2023-03-15 01:49:54 --> Router Class Initialized
INFO - 2023-03-15 01:49:54 --> Output Class Initialized
INFO - 2023-03-15 01:49:54 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:54 --> Input Class Initialized
INFO - 2023-03-15 01:49:54 --> Language Class Initialized
INFO - 2023-03-15 01:49:54 --> Loader Class Initialized
INFO - 2023-03-15 01:49:54 --> Controller Class Initialized
DEBUG - 2023-03-15 01:49:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:54 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:54 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:54 --> Model "Login_model" initialized
INFO - 2023-03-15 01:49:54 --> Final output sent to browser
DEBUG - 2023-03-15 01:49:54 --> Total execution time: 0.0564
INFO - 2023-03-15 01:49:54 --> Config Class Initialized
INFO - 2023-03-15 01:49:54 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:54 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:54 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:54 --> URI Class Initialized
INFO - 2023-03-15 01:49:54 --> Router Class Initialized
INFO - 2023-03-15 01:49:54 --> Output Class Initialized
INFO - 2023-03-15 01:49:54 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:54 --> Input Class Initialized
INFO - 2023-03-15 01:49:54 --> Language Class Initialized
INFO - 2023-03-15 01:49:54 --> Loader Class Initialized
INFO - 2023-03-15 01:49:54 --> Controller Class Initialized
DEBUG - 2023-03-15 01:49:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:54 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:54 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:54 --> Model "Login_model" initialized
INFO - 2023-03-15 01:49:54 --> Final output sent to browser
DEBUG - 2023-03-15 01:49:54 --> Total execution time: 0.0561
INFO - 2023-03-15 01:49:54 --> Config Class Initialized
INFO - 2023-03-15 01:49:54 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:54 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:54 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:54 --> URI Class Initialized
INFO - 2023-03-15 01:49:54 --> Router Class Initialized
INFO - 2023-03-15 01:49:54 --> Output Class Initialized
INFO - 2023-03-15 01:49:54 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:54 --> Input Class Initialized
INFO - 2023-03-15 01:49:54 --> Language Class Initialized
INFO - 2023-03-15 01:49:54 --> Loader Class Initialized
INFO - 2023-03-15 01:49:54 --> Controller Class Initialized
DEBUG - 2023-03-15 01:49:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:54 --> Final output sent to browser
DEBUG - 2023-03-15 01:49:54 --> Total execution time: 0.0790
INFO - 2023-03-15 01:49:54 --> Config Class Initialized
INFO - 2023-03-15 01:49:54 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:54 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:54 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:54 --> URI Class Initialized
INFO - 2023-03-15 01:49:54 --> Router Class Initialized
INFO - 2023-03-15 01:49:54 --> Output Class Initialized
INFO - 2023-03-15 01:49:54 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:54 --> Input Class Initialized
INFO - 2023-03-15 01:49:54 --> Language Class Initialized
INFO - 2023-03-15 01:49:54 --> Loader Class Initialized
INFO - 2023-03-15 01:49:54 --> Controller Class Initialized
DEBUG - 2023-03-15 01:49:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:54 --> Final output sent to browser
DEBUG - 2023-03-15 01:49:54 --> Total execution time: 0.0837
INFO - 2023-03-15 01:49:57 --> Config Class Initialized
INFO - 2023-03-15 01:49:57 --> Config Class Initialized
INFO - 2023-03-15 01:49:57 --> Hooks Class Initialized
INFO - 2023-03-15 01:49:57 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:57 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 01:49:57 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:57 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:57 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:57 --> URI Class Initialized
INFO - 2023-03-15 01:49:57 --> URI Class Initialized
INFO - 2023-03-15 01:49:57 --> Router Class Initialized
INFO - 2023-03-15 01:49:57 --> Router Class Initialized
INFO - 2023-03-15 01:49:57 --> Output Class Initialized
INFO - 2023-03-15 01:49:57 --> Output Class Initialized
INFO - 2023-03-15 01:49:57 --> Security Class Initialized
INFO - 2023-03-15 01:49:57 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 01:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:57 --> Input Class Initialized
INFO - 2023-03-15 01:49:57 --> Input Class Initialized
INFO - 2023-03-15 01:49:57 --> Language Class Initialized
INFO - 2023-03-15 01:49:57 --> Language Class Initialized
INFO - 2023-03-15 01:49:57 --> Loader Class Initialized
INFO - 2023-03-15 01:49:57 --> Loader Class Initialized
INFO - 2023-03-15 01:49:57 --> Controller Class Initialized
INFO - 2023-03-15 01:49:57 --> Controller Class Initialized
DEBUG - 2023-03-15 01:49:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 01:49:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:57 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:57 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:57 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:49:57 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:49:57 --> Final output sent to browser
DEBUG - 2023-03-15 01:49:57 --> Total execution time: 0.0522
INFO - 2023-03-15 01:49:57 --> Config Class Initialized
INFO - 2023-03-15 01:49:57 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:57 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:57 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:57 --> URI Class Initialized
INFO - 2023-03-15 01:49:57 --> Router Class Initialized
INFO - 2023-03-15 01:49:57 --> Output Class Initialized
INFO - 2023-03-15 01:49:57 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:57 --> Input Class Initialized
INFO - 2023-03-15 01:49:57 --> Language Class Initialized
INFO - 2023-03-15 01:49:57 --> Loader Class Initialized
INFO - 2023-03-15 01:49:57 --> Controller Class Initialized
DEBUG - 2023-03-15 01:49:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:57 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:57 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:49:57 --> Final output sent to browser
DEBUG - 2023-03-15 01:49:57 --> Total execution time: 0.0921
INFO - 2023-03-15 01:49:57 --> Config Class Initialized
INFO - 2023-03-15 01:49:57 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:49:57 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:49:57 --> Utf8 Class Initialized
INFO - 2023-03-15 01:49:57 --> URI Class Initialized
INFO - 2023-03-15 01:49:57 --> Router Class Initialized
INFO - 2023-03-15 01:49:57 --> Output Class Initialized
INFO - 2023-03-15 01:49:57 --> Security Class Initialized
DEBUG - 2023-03-15 01:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:49:57 --> Input Class Initialized
INFO - 2023-03-15 01:49:57 --> Language Class Initialized
INFO - 2023-03-15 01:49:57 --> Loader Class Initialized
INFO - 2023-03-15 01:49:57 --> Controller Class Initialized
DEBUG - 2023-03-15 01:49:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:49:57 --> Database Driver Class Initialized
INFO - 2023-03-15 01:49:57 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:02 --> Config Class Initialized
INFO - 2023-03-15 01:50:02 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:02 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:02 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:02 --> URI Class Initialized
INFO - 2023-03-15 01:50:02 --> Router Class Initialized
INFO - 2023-03-15 01:50:02 --> Output Class Initialized
INFO - 2023-03-15 01:50:02 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:02 --> Input Class Initialized
INFO - 2023-03-15 01:50:02 --> Language Class Initialized
INFO - 2023-03-15 01:50:02 --> Loader Class Initialized
INFO - 2023-03-15 01:50:02 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:02 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:02 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:03 --> Config Class Initialized
INFO - 2023-03-15 01:50:03 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:03 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:03 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:03 --> URI Class Initialized
INFO - 2023-03-15 01:50:03 --> Router Class Initialized
INFO - 2023-03-15 01:50:03 --> Output Class Initialized
INFO - 2023-03-15 01:50:03 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:03 --> Input Class Initialized
INFO - 2023-03-15 01:50:03 --> Language Class Initialized
INFO - 2023-03-15 01:50:03 --> Loader Class Initialized
INFO - 2023-03-15 01:50:03 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:03 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:03 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:04 --> Config Class Initialized
INFO - 2023-03-15 01:50:04 --> Config Class Initialized
INFO - 2023-03-15 01:50:04 --> Hooks Class Initialized
INFO - 2023-03-15 01:50:04 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:04 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 01:50:04 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:04 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:04 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:04 --> URI Class Initialized
INFO - 2023-03-15 01:50:04 --> URI Class Initialized
INFO - 2023-03-15 01:50:04 --> Router Class Initialized
INFO - 2023-03-15 01:50:04 --> Router Class Initialized
INFO - 2023-03-15 01:50:04 --> Output Class Initialized
INFO - 2023-03-15 01:50:04 --> Output Class Initialized
INFO - 2023-03-15 01:50:04 --> Security Class Initialized
INFO - 2023-03-15 01:50:04 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 01:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:04 --> Input Class Initialized
INFO - 2023-03-15 01:50:04 --> Input Class Initialized
INFO - 2023-03-15 01:50:04 --> Language Class Initialized
INFO - 2023-03-15 01:50:04 --> Language Class Initialized
INFO - 2023-03-15 01:50:04 --> Loader Class Initialized
INFO - 2023-03-15 01:50:04 --> Loader Class Initialized
INFO - 2023-03-15 01:50:04 --> Controller Class Initialized
INFO - 2023-03-15 01:50:04 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 01:50:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:04 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:04 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:04 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:04 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:04 --> Final output sent to browser
DEBUG - 2023-03-15 01:50:04 --> Total execution time: 0.0594
INFO - 2023-03-15 01:50:04 --> Config Class Initialized
INFO - 2023-03-15 01:50:04 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:04 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:04 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:04 --> URI Class Initialized
INFO - 2023-03-15 01:50:04 --> Router Class Initialized
INFO - 2023-03-15 01:50:04 --> Output Class Initialized
INFO - 2023-03-15 01:50:04 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:04 --> Input Class Initialized
INFO - 2023-03-15 01:50:04 --> Language Class Initialized
INFO - 2023-03-15 01:50:04 --> Loader Class Initialized
INFO - 2023-03-15 01:50:04 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:04 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:04 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:04 --> Final output sent to browser
DEBUG - 2023-03-15 01:50:04 --> Total execution time: 0.0136
INFO - 2023-03-15 01:50:07 --> Config Class Initialized
INFO - 2023-03-15 01:50:07 --> Config Class Initialized
INFO - 2023-03-15 01:50:07 --> Hooks Class Initialized
INFO - 2023-03-15 01:50:07 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:07 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 01:50:07 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:07 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:07 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:07 --> URI Class Initialized
INFO - 2023-03-15 01:50:07 --> URI Class Initialized
INFO - 2023-03-15 01:50:07 --> Router Class Initialized
INFO - 2023-03-15 01:50:07 --> Router Class Initialized
INFO - 2023-03-15 01:50:07 --> Output Class Initialized
INFO - 2023-03-15 01:50:07 --> Output Class Initialized
INFO - 2023-03-15 01:50:07 --> Security Class Initialized
INFO - 2023-03-15 01:50:07 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 01:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:07 --> Input Class Initialized
INFO - 2023-03-15 01:50:07 --> Input Class Initialized
INFO - 2023-03-15 01:50:07 --> Language Class Initialized
INFO - 2023-03-15 01:50:07 --> Language Class Initialized
INFO - 2023-03-15 01:50:07 --> Loader Class Initialized
INFO - 2023-03-15 01:50:07 --> Loader Class Initialized
INFO - 2023-03-15 01:50:07 --> Controller Class Initialized
INFO - 2023-03-15 01:50:07 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 01:50:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:07 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:07 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:07 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:07 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:07 --> Final output sent to browser
DEBUG - 2023-03-15 01:50:07 --> Total execution time: 0.0158
INFO - 2023-03-15 01:50:07 --> Config Class Initialized
INFO - 2023-03-15 01:50:07 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:07 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:07 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:07 --> URI Class Initialized
INFO - 2023-03-15 01:50:07 --> Router Class Initialized
INFO - 2023-03-15 01:50:07 --> Output Class Initialized
INFO - 2023-03-15 01:50:07 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:07 --> Input Class Initialized
INFO - 2023-03-15 01:50:07 --> Language Class Initialized
INFO - 2023-03-15 01:50:07 --> Loader Class Initialized
INFO - 2023-03-15 01:50:07 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:07 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:07 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:08 --> Config Class Initialized
INFO - 2023-03-15 01:50:08 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:08 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:08 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:08 --> URI Class Initialized
INFO - 2023-03-15 01:50:08 --> Router Class Initialized
INFO - 2023-03-15 01:50:08 --> Output Class Initialized
INFO - 2023-03-15 01:50:08 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:08 --> Input Class Initialized
INFO - 2023-03-15 01:50:08 --> Language Class Initialized
INFO - 2023-03-15 01:50:08 --> Loader Class Initialized
INFO - 2023-03-15 01:50:08 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:08 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:08 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:08 --> Final output sent to browser
DEBUG - 2023-03-15 01:50:08 --> Total execution time: 0.0152
INFO - 2023-03-15 01:50:08 --> Config Class Initialized
INFO - 2023-03-15 01:50:08 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:08 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:08 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:08 --> URI Class Initialized
INFO - 2023-03-15 01:50:08 --> Router Class Initialized
INFO - 2023-03-15 01:50:08 --> Output Class Initialized
INFO - 2023-03-15 01:50:08 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:08 --> Input Class Initialized
INFO - 2023-03-15 01:50:08 --> Language Class Initialized
INFO - 2023-03-15 01:50:08 --> Loader Class Initialized
INFO - 2023-03-15 01:50:08 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:08 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:08 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:08 --> Final output sent to browser
DEBUG - 2023-03-15 01:50:08 --> Total execution time: 0.0555
INFO - 2023-03-15 01:50:09 --> Config Class Initialized
INFO - 2023-03-15 01:50:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:09 --> URI Class Initialized
INFO - 2023-03-15 01:50:09 --> Router Class Initialized
INFO - 2023-03-15 01:50:09 --> Output Class Initialized
INFO - 2023-03-15 01:50:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:09 --> Input Class Initialized
INFO - 2023-03-15 01:50:09 --> Language Class Initialized
INFO - 2023-03-15 01:50:09 --> Loader Class Initialized
INFO - 2023-03-15 01:50:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:50:09 --> Total execution time: 0.0463
INFO - 2023-03-15 01:50:09 --> Config Class Initialized
INFO - 2023-03-15 01:50:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:09 --> URI Class Initialized
INFO - 2023-03-15 01:50:09 --> Router Class Initialized
INFO - 2023-03-15 01:50:09 --> Output Class Initialized
INFO - 2023-03-15 01:50:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:09 --> Input Class Initialized
INFO - 2023-03-15 01:50:09 --> Language Class Initialized
INFO - 2023-03-15 01:50:09 --> Loader Class Initialized
INFO - 2023-03-15 01:50:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:09 --> Model "Login_model" initialized
INFO - 2023-03-15 01:50:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:50:09 --> Total execution time: 0.0333
INFO - 2023-03-15 01:50:09 --> Config Class Initialized
INFO - 2023-03-15 01:50:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:09 --> URI Class Initialized
INFO - 2023-03-15 01:50:09 --> Router Class Initialized
INFO - 2023-03-15 01:50:09 --> Output Class Initialized
INFO - 2023-03-15 01:50:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:09 --> Input Class Initialized
INFO - 2023-03-15 01:50:09 --> Language Class Initialized
INFO - 2023-03-15 01:50:09 --> Loader Class Initialized
INFO - 2023-03-15 01:50:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:50:09 --> Total execution time: 0.0420
INFO - 2023-03-15 01:50:09 --> Config Class Initialized
INFO - 2023-03-15 01:50:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:09 --> URI Class Initialized
INFO - 2023-03-15 01:50:09 --> Router Class Initialized
INFO - 2023-03-15 01:50:09 --> Output Class Initialized
INFO - 2023-03-15 01:50:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:09 --> Input Class Initialized
INFO - 2023-03-15 01:50:09 --> Language Class Initialized
INFO - 2023-03-15 01:50:09 --> Loader Class Initialized
INFO - 2023-03-15 01:50:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:09 --> Model "Login_model" initialized
INFO - 2023-03-15 01:50:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:50:09 --> Total execution time: 0.0201
INFO - 2023-03-15 01:50:29 --> Config Class Initialized
INFO - 2023-03-15 01:50:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:29 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:29 --> URI Class Initialized
INFO - 2023-03-15 01:50:29 --> Router Class Initialized
INFO - 2023-03-15 01:50:29 --> Output Class Initialized
INFO - 2023-03-15 01:50:29 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:29 --> Input Class Initialized
INFO - 2023-03-15 01:50:29 --> Language Class Initialized
INFO - 2023-03-15 01:50:29 --> Loader Class Initialized
INFO - 2023-03-15 01:50:29 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:29 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:29 --> Model "Login_model" initialized
INFO - 2023-03-15 01:50:29 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:29 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:29 --> Final output sent to browser
DEBUG - 2023-03-15 01:50:29 --> Total execution time: 0.0436
INFO - 2023-03-15 01:50:29 --> Config Class Initialized
INFO - 2023-03-15 01:50:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:29 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:29 --> URI Class Initialized
INFO - 2023-03-15 01:50:29 --> Router Class Initialized
INFO - 2023-03-15 01:50:29 --> Output Class Initialized
INFO - 2023-03-15 01:50:29 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:29 --> Input Class Initialized
INFO - 2023-03-15 01:50:29 --> Language Class Initialized
INFO - 2023-03-15 01:50:29 --> Loader Class Initialized
INFO - 2023-03-15 01:50:29 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:29 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:29 --> Model "Login_model" initialized
INFO - 2023-03-15 01:50:29 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:29 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:29 --> Final output sent to browser
DEBUG - 2023-03-15 01:50:29 --> Total execution time: 0.0785
INFO - 2023-03-15 01:50:50 --> Config Class Initialized
INFO - 2023-03-15 01:50:50 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:50 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:50 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:50 --> URI Class Initialized
INFO - 2023-03-15 01:50:50 --> Router Class Initialized
INFO - 2023-03-15 01:50:50 --> Output Class Initialized
INFO - 2023-03-15 01:50:50 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:50 --> Input Class Initialized
INFO - 2023-03-15 01:50:50 --> Language Class Initialized
INFO - 2023-03-15 01:50:50 --> Loader Class Initialized
INFO - 2023-03-15 01:50:50 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:50 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:50 --> Model "Login_model" initialized
INFO - 2023-03-15 01:50:50 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:50 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:50 --> Final output sent to browser
DEBUG - 2023-03-15 01:50:50 --> Total execution time: 0.0433
INFO - 2023-03-15 01:50:50 --> Config Class Initialized
INFO - 2023-03-15 01:50:50 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:50:50 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:50:50 --> Utf8 Class Initialized
INFO - 2023-03-15 01:50:50 --> URI Class Initialized
INFO - 2023-03-15 01:50:50 --> Router Class Initialized
INFO - 2023-03-15 01:50:50 --> Output Class Initialized
INFO - 2023-03-15 01:50:50 --> Security Class Initialized
DEBUG - 2023-03-15 01:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:50:50 --> Input Class Initialized
INFO - 2023-03-15 01:50:50 --> Language Class Initialized
INFO - 2023-03-15 01:50:50 --> Loader Class Initialized
INFO - 2023-03-15 01:50:50 --> Controller Class Initialized
DEBUG - 2023-03-15 01:50:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:50:50 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:50 --> Model "Login_model" initialized
INFO - 2023-03-15 01:50:50 --> Database Driver Class Initialized
INFO - 2023-03-15 01:50:50 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:50:50 --> Final output sent to browser
DEBUG - 2023-03-15 01:50:50 --> Total execution time: 0.0325
INFO - 2023-03-15 01:51:09 --> Config Class Initialized
INFO - 2023-03-15 01:51:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:51:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:51:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:51:09 --> URI Class Initialized
INFO - 2023-03-15 01:51:09 --> Router Class Initialized
INFO - 2023-03-15 01:51:09 --> Output Class Initialized
INFO - 2023-03-15 01:51:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:51:09 --> Input Class Initialized
INFO - 2023-03-15 01:51:09 --> Language Class Initialized
INFO - 2023-03-15 01:51:09 --> Loader Class Initialized
INFO - 2023-03-15 01:51:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:51:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:51:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:51:09 --> Model "Login_model" initialized
INFO - 2023-03-15 01:51:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:51:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:51:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:51:09 --> Total execution time: 0.0371
INFO - 2023-03-15 01:51:09 --> Config Class Initialized
INFO - 2023-03-15 01:51:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:51:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:51:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:51:09 --> URI Class Initialized
INFO - 2023-03-15 01:51:09 --> Router Class Initialized
INFO - 2023-03-15 01:51:09 --> Output Class Initialized
INFO - 2023-03-15 01:51:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:51:09 --> Input Class Initialized
INFO - 2023-03-15 01:51:09 --> Language Class Initialized
INFO - 2023-03-15 01:51:09 --> Loader Class Initialized
INFO - 2023-03-15 01:51:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:51:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:51:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:51:09 --> Model "Login_model" initialized
INFO - 2023-03-15 01:51:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:51:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:51:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:51:09 --> Total execution time: 0.0322
INFO - 2023-03-15 01:51:30 --> Config Class Initialized
INFO - 2023-03-15 01:51:30 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:51:30 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:51:30 --> Utf8 Class Initialized
INFO - 2023-03-15 01:51:30 --> URI Class Initialized
INFO - 2023-03-15 01:51:30 --> Router Class Initialized
INFO - 2023-03-15 01:51:30 --> Output Class Initialized
INFO - 2023-03-15 01:51:30 --> Security Class Initialized
DEBUG - 2023-03-15 01:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:51:30 --> Input Class Initialized
INFO - 2023-03-15 01:51:30 --> Language Class Initialized
INFO - 2023-03-15 01:51:30 --> Loader Class Initialized
INFO - 2023-03-15 01:51:30 --> Controller Class Initialized
DEBUG - 2023-03-15 01:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:51:30 --> Database Driver Class Initialized
INFO - 2023-03-15 01:51:30 --> Model "Login_model" initialized
INFO - 2023-03-15 01:51:30 --> Database Driver Class Initialized
INFO - 2023-03-15 01:51:30 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:51:30 --> Final output sent to browser
DEBUG - 2023-03-15 01:51:30 --> Total execution time: 0.0347
INFO - 2023-03-15 01:51:30 --> Config Class Initialized
INFO - 2023-03-15 01:51:30 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:51:30 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:51:30 --> Utf8 Class Initialized
INFO - 2023-03-15 01:51:30 --> URI Class Initialized
INFO - 2023-03-15 01:51:30 --> Router Class Initialized
INFO - 2023-03-15 01:51:30 --> Output Class Initialized
INFO - 2023-03-15 01:51:30 --> Security Class Initialized
DEBUG - 2023-03-15 01:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:51:30 --> Input Class Initialized
INFO - 2023-03-15 01:51:30 --> Language Class Initialized
INFO - 2023-03-15 01:51:30 --> Loader Class Initialized
INFO - 2023-03-15 01:51:30 --> Controller Class Initialized
DEBUG - 2023-03-15 01:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:51:30 --> Database Driver Class Initialized
INFO - 2023-03-15 01:51:30 --> Model "Login_model" initialized
INFO - 2023-03-15 01:51:30 --> Database Driver Class Initialized
INFO - 2023-03-15 01:51:30 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:51:30 --> Final output sent to browser
DEBUG - 2023-03-15 01:51:30 --> Total execution time: 0.0280
INFO - 2023-03-15 01:51:50 --> Config Class Initialized
INFO - 2023-03-15 01:51:50 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:51:50 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:51:50 --> Utf8 Class Initialized
INFO - 2023-03-15 01:51:50 --> URI Class Initialized
INFO - 2023-03-15 01:51:50 --> Router Class Initialized
INFO - 2023-03-15 01:51:50 --> Output Class Initialized
INFO - 2023-03-15 01:51:50 --> Security Class Initialized
DEBUG - 2023-03-15 01:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:51:50 --> Input Class Initialized
INFO - 2023-03-15 01:51:50 --> Language Class Initialized
INFO - 2023-03-15 01:51:50 --> Loader Class Initialized
INFO - 2023-03-15 01:51:50 --> Controller Class Initialized
DEBUG - 2023-03-15 01:51:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:51:50 --> Database Driver Class Initialized
INFO - 2023-03-15 01:51:50 --> Model "Login_model" initialized
INFO - 2023-03-15 01:51:50 --> Database Driver Class Initialized
INFO - 2023-03-15 01:51:50 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:51:50 --> Final output sent to browser
DEBUG - 2023-03-15 01:51:50 --> Total execution time: 0.1216
INFO - 2023-03-15 01:51:50 --> Config Class Initialized
INFO - 2023-03-15 01:51:50 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:51:50 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:51:50 --> Utf8 Class Initialized
INFO - 2023-03-15 01:51:50 --> URI Class Initialized
INFO - 2023-03-15 01:51:50 --> Router Class Initialized
INFO - 2023-03-15 01:51:50 --> Output Class Initialized
INFO - 2023-03-15 01:51:50 --> Security Class Initialized
DEBUG - 2023-03-15 01:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:51:50 --> Input Class Initialized
INFO - 2023-03-15 01:51:50 --> Language Class Initialized
INFO - 2023-03-15 01:51:50 --> Loader Class Initialized
INFO - 2023-03-15 01:51:50 --> Controller Class Initialized
DEBUG - 2023-03-15 01:51:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:51:50 --> Database Driver Class Initialized
INFO - 2023-03-15 01:51:50 --> Model "Login_model" initialized
INFO - 2023-03-15 01:51:50 --> Database Driver Class Initialized
INFO - 2023-03-15 01:51:50 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:51:50 --> Final output sent to browser
DEBUG - 2023-03-15 01:51:50 --> Total execution time: 0.0722
INFO - 2023-03-15 01:52:09 --> Config Class Initialized
INFO - 2023-03-15 01:52:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:52:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:52:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:52:09 --> URI Class Initialized
INFO - 2023-03-15 01:52:09 --> Router Class Initialized
INFO - 2023-03-15 01:52:09 --> Output Class Initialized
INFO - 2023-03-15 01:52:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:52:09 --> Input Class Initialized
INFO - 2023-03-15 01:52:09 --> Language Class Initialized
INFO - 2023-03-15 01:52:09 --> Loader Class Initialized
INFO - 2023-03-15 01:52:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:52:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:52:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:52:09 --> Model "Login_model" initialized
INFO - 2023-03-15 01:52:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:52:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:52:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:52:09 --> Total execution time: 0.0347
INFO - 2023-03-15 01:52:09 --> Config Class Initialized
INFO - 2023-03-15 01:52:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:52:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:52:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:52:09 --> URI Class Initialized
INFO - 2023-03-15 01:52:09 --> Router Class Initialized
INFO - 2023-03-15 01:52:09 --> Output Class Initialized
INFO - 2023-03-15 01:52:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:52:09 --> Input Class Initialized
INFO - 2023-03-15 01:52:09 --> Language Class Initialized
INFO - 2023-03-15 01:52:09 --> Loader Class Initialized
INFO - 2023-03-15 01:52:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:52:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:52:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:52:09 --> Model "Login_model" initialized
INFO - 2023-03-15 01:52:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:52:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:52:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:52:09 --> Total execution time: 0.0795
INFO - 2023-03-15 01:52:29 --> Config Class Initialized
INFO - 2023-03-15 01:52:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:52:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:52:29 --> Utf8 Class Initialized
INFO - 2023-03-15 01:52:29 --> URI Class Initialized
INFO - 2023-03-15 01:52:29 --> Router Class Initialized
INFO - 2023-03-15 01:52:29 --> Output Class Initialized
INFO - 2023-03-15 01:52:29 --> Security Class Initialized
DEBUG - 2023-03-15 01:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:52:29 --> Input Class Initialized
INFO - 2023-03-15 01:52:29 --> Language Class Initialized
INFO - 2023-03-15 01:52:29 --> Loader Class Initialized
INFO - 2023-03-15 01:52:29 --> Controller Class Initialized
DEBUG - 2023-03-15 01:52:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:52:29 --> Database Driver Class Initialized
INFO - 2023-03-15 01:52:29 --> Model "Login_model" initialized
INFO - 2023-03-15 01:52:29 --> Database Driver Class Initialized
INFO - 2023-03-15 01:52:29 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:52:29 --> Final output sent to browser
DEBUG - 2023-03-15 01:52:29 --> Total execution time: 0.0317
INFO - 2023-03-15 01:52:29 --> Config Class Initialized
INFO - 2023-03-15 01:52:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:52:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:52:29 --> Utf8 Class Initialized
INFO - 2023-03-15 01:52:29 --> URI Class Initialized
INFO - 2023-03-15 01:52:29 --> Router Class Initialized
INFO - 2023-03-15 01:52:29 --> Output Class Initialized
INFO - 2023-03-15 01:52:29 --> Security Class Initialized
DEBUG - 2023-03-15 01:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:52:29 --> Input Class Initialized
INFO - 2023-03-15 01:52:29 --> Language Class Initialized
INFO - 2023-03-15 01:52:29 --> Loader Class Initialized
INFO - 2023-03-15 01:52:29 --> Controller Class Initialized
DEBUG - 2023-03-15 01:52:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:52:29 --> Database Driver Class Initialized
INFO - 2023-03-15 01:52:29 --> Model "Login_model" initialized
INFO - 2023-03-15 01:52:29 --> Database Driver Class Initialized
INFO - 2023-03-15 01:52:29 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:52:29 --> Final output sent to browser
DEBUG - 2023-03-15 01:52:29 --> Total execution time: 0.0689
INFO - 2023-03-15 01:52:49 --> Config Class Initialized
INFO - 2023-03-15 01:52:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:52:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:52:49 --> Utf8 Class Initialized
INFO - 2023-03-15 01:52:49 --> URI Class Initialized
INFO - 2023-03-15 01:52:49 --> Router Class Initialized
INFO - 2023-03-15 01:52:49 --> Output Class Initialized
INFO - 2023-03-15 01:52:49 --> Security Class Initialized
DEBUG - 2023-03-15 01:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:52:49 --> Input Class Initialized
INFO - 2023-03-15 01:52:49 --> Language Class Initialized
INFO - 2023-03-15 01:52:49 --> Loader Class Initialized
INFO - 2023-03-15 01:52:49 --> Controller Class Initialized
DEBUG - 2023-03-15 01:52:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:52:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:52:49 --> Model "Login_model" initialized
INFO - 2023-03-15 01:52:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:52:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:52:49 --> Final output sent to browser
DEBUG - 2023-03-15 01:52:49 --> Total execution time: 0.0772
INFO - 2023-03-15 01:52:49 --> Config Class Initialized
INFO - 2023-03-15 01:52:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:52:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:52:49 --> Utf8 Class Initialized
INFO - 2023-03-15 01:52:49 --> URI Class Initialized
INFO - 2023-03-15 01:52:49 --> Router Class Initialized
INFO - 2023-03-15 01:52:49 --> Output Class Initialized
INFO - 2023-03-15 01:52:49 --> Security Class Initialized
DEBUG - 2023-03-15 01:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:52:49 --> Input Class Initialized
INFO - 2023-03-15 01:52:49 --> Language Class Initialized
INFO - 2023-03-15 01:52:49 --> Loader Class Initialized
INFO - 2023-03-15 01:52:49 --> Controller Class Initialized
DEBUG - 2023-03-15 01:52:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:52:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:52:49 --> Model "Login_model" initialized
INFO - 2023-03-15 01:52:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:52:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:52:49 --> Final output sent to browser
DEBUG - 2023-03-15 01:52:49 --> Total execution time: 0.1526
INFO - 2023-03-15 01:53:09 --> Config Class Initialized
INFO - 2023-03-15 01:53:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:53:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:53:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:53:09 --> URI Class Initialized
INFO - 2023-03-15 01:53:09 --> Router Class Initialized
INFO - 2023-03-15 01:53:09 --> Output Class Initialized
INFO - 2023-03-15 01:53:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:53:09 --> Input Class Initialized
INFO - 2023-03-15 01:53:09 --> Language Class Initialized
INFO - 2023-03-15 01:53:09 --> Loader Class Initialized
INFO - 2023-03-15 01:53:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:53:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:53:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:53:09 --> Model "Login_model" initialized
INFO - 2023-03-15 01:53:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:53:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:53:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:53:09 --> Total execution time: 0.0359
INFO - 2023-03-15 01:53:09 --> Config Class Initialized
INFO - 2023-03-15 01:53:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:53:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:53:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:53:09 --> URI Class Initialized
INFO - 2023-03-15 01:53:09 --> Router Class Initialized
INFO - 2023-03-15 01:53:09 --> Output Class Initialized
INFO - 2023-03-15 01:53:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:53:09 --> Input Class Initialized
INFO - 2023-03-15 01:53:09 --> Language Class Initialized
INFO - 2023-03-15 01:53:09 --> Loader Class Initialized
INFO - 2023-03-15 01:53:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:53:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:53:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:53:09 --> Model "Login_model" initialized
INFO - 2023-03-15 01:53:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:53:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:53:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:53:09 --> Total execution time: 0.0310
INFO - 2023-03-15 01:53:30 --> Config Class Initialized
INFO - 2023-03-15 01:53:30 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:53:30 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:53:30 --> Utf8 Class Initialized
INFO - 2023-03-15 01:53:30 --> URI Class Initialized
INFO - 2023-03-15 01:53:30 --> Router Class Initialized
INFO - 2023-03-15 01:53:30 --> Output Class Initialized
INFO - 2023-03-15 01:53:30 --> Security Class Initialized
DEBUG - 2023-03-15 01:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:53:30 --> Input Class Initialized
INFO - 2023-03-15 01:53:30 --> Language Class Initialized
INFO - 2023-03-15 01:53:30 --> Loader Class Initialized
INFO - 2023-03-15 01:53:30 --> Controller Class Initialized
DEBUG - 2023-03-15 01:53:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:53:30 --> Database Driver Class Initialized
INFO - 2023-03-15 01:53:30 --> Model "Login_model" initialized
INFO - 2023-03-15 01:53:30 --> Database Driver Class Initialized
INFO - 2023-03-15 01:53:30 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:53:30 --> Final output sent to browser
DEBUG - 2023-03-15 01:53:30 --> Total execution time: 0.0424
INFO - 2023-03-15 01:53:30 --> Config Class Initialized
INFO - 2023-03-15 01:53:30 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:53:30 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:53:30 --> Utf8 Class Initialized
INFO - 2023-03-15 01:53:30 --> URI Class Initialized
INFO - 2023-03-15 01:53:30 --> Router Class Initialized
INFO - 2023-03-15 01:53:30 --> Output Class Initialized
INFO - 2023-03-15 01:53:30 --> Security Class Initialized
DEBUG - 2023-03-15 01:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:53:30 --> Input Class Initialized
INFO - 2023-03-15 01:53:30 --> Language Class Initialized
INFO - 2023-03-15 01:53:30 --> Loader Class Initialized
INFO - 2023-03-15 01:53:30 --> Controller Class Initialized
DEBUG - 2023-03-15 01:53:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:53:30 --> Database Driver Class Initialized
INFO - 2023-03-15 01:53:30 --> Model "Login_model" initialized
INFO - 2023-03-15 01:53:30 --> Database Driver Class Initialized
INFO - 2023-03-15 01:53:30 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:53:30 --> Final output sent to browser
DEBUG - 2023-03-15 01:53:30 --> Total execution time: 0.0380
INFO - 2023-03-15 01:53:49 --> Config Class Initialized
INFO - 2023-03-15 01:53:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:53:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:53:49 --> Utf8 Class Initialized
INFO - 2023-03-15 01:53:49 --> URI Class Initialized
INFO - 2023-03-15 01:53:49 --> Router Class Initialized
INFO - 2023-03-15 01:53:49 --> Output Class Initialized
INFO - 2023-03-15 01:53:49 --> Security Class Initialized
DEBUG - 2023-03-15 01:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:53:49 --> Input Class Initialized
INFO - 2023-03-15 01:53:49 --> Language Class Initialized
INFO - 2023-03-15 01:53:49 --> Loader Class Initialized
INFO - 2023-03-15 01:53:49 --> Controller Class Initialized
DEBUG - 2023-03-15 01:53:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:53:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:53:49 --> Model "Login_model" initialized
INFO - 2023-03-15 01:53:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:53:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:53:49 --> Final output sent to browser
DEBUG - 2023-03-15 01:53:49 --> Total execution time: 0.0512
INFO - 2023-03-15 01:53:49 --> Config Class Initialized
INFO - 2023-03-15 01:53:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:53:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:53:49 --> Utf8 Class Initialized
INFO - 2023-03-15 01:53:49 --> URI Class Initialized
INFO - 2023-03-15 01:53:49 --> Router Class Initialized
INFO - 2023-03-15 01:53:49 --> Output Class Initialized
INFO - 2023-03-15 01:53:49 --> Security Class Initialized
DEBUG - 2023-03-15 01:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:53:49 --> Input Class Initialized
INFO - 2023-03-15 01:53:49 --> Language Class Initialized
INFO - 2023-03-15 01:53:49 --> Loader Class Initialized
INFO - 2023-03-15 01:53:49 --> Controller Class Initialized
DEBUG - 2023-03-15 01:53:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:53:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:53:49 --> Model "Login_model" initialized
INFO - 2023-03-15 01:53:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:53:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:53:49 --> Final output sent to browser
DEBUG - 2023-03-15 01:53:49 --> Total execution time: 0.1262
INFO - 2023-03-15 01:54:09 --> Config Class Initialized
INFO - 2023-03-15 01:54:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:54:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:54:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:54:09 --> URI Class Initialized
INFO - 2023-03-15 01:54:09 --> Router Class Initialized
INFO - 2023-03-15 01:54:09 --> Output Class Initialized
INFO - 2023-03-15 01:54:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:54:09 --> Input Class Initialized
INFO - 2023-03-15 01:54:09 --> Language Class Initialized
INFO - 2023-03-15 01:54:09 --> Loader Class Initialized
INFO - 2023-03-15 01:54:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:54:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:54:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:54:09 --> Model "Login_model" initialized
INFO - 2023-03-15 01:54:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:54:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:54:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:54:09 --> Total execution time: 0.0680
INFO - 2023-03-15 01:54:09 --> Config Class Initialized
INFO - 2023-03-15 01:54:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:54:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:54:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:54:09 --> URI Class Initialized
INFO - 2023-03-15 01:54:09 --> Router Class Initialized
INFO - 2023-03-15 01:54:09 --> Output Class Initialized
INFO - 2023-03-15 01:54:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:54:09 --> Input Class Initialized
INFO - 2023-03-15 01:54:09 --> Language Class Initialized
INFO - 2023-03-15 01:54:09 --> Loader Class Initialized
INFO - 2023-03-15 01:54:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:54:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:54:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:54:09 --> Model "Login_model" initialized
INFO - 2023-03-15 01:54:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:54:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:54:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:54:09 --> Total execution time: 0.0792
INFO - 2023-03-15 01:54:29 --> Config Class Initialized
INFO - 2023-03-15 01:54:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:54:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:54:29 --> Utf8 Class Initialized
INFO - 2023-03-15 01:54:29 --> URI Class Initialized
INFO - 2023-03-15 01:54:29 --> Router Class Initialized
INFO - 2023-03-15 01:54:29 --> Output Class Initialized
INFO - 2023-03-15 01:54:29 --> Security Class Initialized
DEBUG - 2023-03-15 01:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:54:29 --> Input Class Initialized
INFO - 2023-03-15 01:54:29 --> Language Class Initialized
INFO - 2023-03-15 01:54:29 --> Loader Class Initialized
INFO - 2023-03-15 01:54:29 --> Controller Class Initialized
DEBUG - 2023-03-15 01:54:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:54:29 --> Database Driver Class Initialized
INFO - 2023-03-15 01:54:29 --> Model "Login_model" initialized
INFO - 2023-03-15 01:54:29 --> Database Driver Class Initialized
INFO - 2023-03-15 01:54:29 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:54:29 --> Final output sent to browser
DEBUG - 2023-03-15 01:54:29 --> Total execution time: 0.0530
INFO - 2023-03-15 01:54:29 --> Config Class Initialized
INFO - 2023-03-15 01:54:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:54:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:54:29 --> Utf8 Class Initialized
INFO - 2023-03-15 01:54:29 --> URI Class Initialized
INFO - 2023-03-15 01:54:29 --> Router Class Initialized
INFO - 2023-03-15 01:54:29 --> Output Class Initialized
INFO - 2023-03-15 01:54:29 --> Security Class Initialized
DEBUG - 2023-03-15 01:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:54:29 --> Input Class Initialized
INFO - 2023-03-15 01:54:29 --> Language Class Initialized
INFO - 2023-03-15 01:54:29 --> Loader Class Initialized
INFO - 2023-03-15 01:54:29 --> Controller Class Initialized
DEBUG - 2023-03-15 01:54:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:54:29 --> Database Driver Class Initialized
INFO - 2023-03-15 01:54:29 --> Model "Login_model" initialized
INFO - 2023-03-15 01:54:29 --> Database Driver Class Initialized
INFO - 2023-03-15 01:54:29 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:54:29 --> Final output sent to browser
DEBUG - 2023-03-15 01:54:29 --> Total execution time: 0.0752
INFO - 2023-03-15 01:54:49 --> Config Class Initialized
INFO - 2023-03-15 01:54:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:54:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:54:49 --> Utf8 Class Initialized
INFO - 2023-03-15 01:54:49 --> URI Class Initialized
INFO - 2023-03-15 01:54:49 --> Router Class Initialized
INFO - 2023-03-15 01:54:49 --> Output Class Initialized
INFO - 2023-03-15 01:54:49 --> Security Class Initialized
DEBUG - 2023-03-15 01:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:54:49 --> Input Class Initialized
INFO - 2023-03-15 01:54:49 --> Language Class Initialized
INFO - 2023-03-15 01:54:49 --> Loader Class Initialized
INFO - 2023-03-15 01:54:49 --> Controller Class Initialized
DEBUG - 2023-03-15 01:54:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:54:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:54:49 --> Model "Login_model" initialized
INFO - 2023-03-15 01:54:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:54:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:54:49 --> Final output sent to browser
DEBUG - 2023-03-15 01:54:49 --> Total execution time: 0.0335
INFO - 2023-03-15 01:54:49 --> Config Class Initialized
INFO - 2023-03-15 01:54:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:54:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:54:49 --> Utf8 Class Initialized
INFO - 2023-03-15 01:54:49 --> URI Class Initialized
INFO - 2023-03-15 01:54:49 --> Router Class Initialized
INFO - 2023-03-15 01:54:49 --> Output Class Initialized
INFO - 2023-03-15 01:54:49 --> Security Class Initialized
DEBUG - 2023-03-15 01:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:54:49 --> Input Class Initialized
INFO - 2023-03-15 01:54:49 --> Language Class Initialized
INFO - 2023-03-15 01:54:49 --> Loader Class Initialized
INFO - 2023-03-15 01:54:49 --> Controller Class Initialized
DEBUG - 2023-03-15 01:54:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:54:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:54:49 --> Model "Login_model" initialized
INFO - 2023-03-15 01:54:49 --> Database Driver Class Initialized
INFO - 2023-03-15 01:54:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:54:49 --> Final output sent to browser
DEBUG - 2023-03-15 01:54:49 --> Total execution time: 0.0326
INFO - 2023-03-15 01:55:09 --> Config Class Initialized
INFO - 2023-03-15 01:55:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:55:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:55:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:55:09 --> URI Class Initialized
INFO - 2023-03-15 01:55:09 --> Router Class Initialized
INFO - 2023-03-15 01:55:09 --> Output Class Initialized
INFO - 2023-03-15 01:55:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:55:09 --> Input Class Initialized
INFO - 2023-03-15 01:55:09 --> Language Class Initialized
INFO - 2023-03-15 01:55:09 --> Loader Class Initialized
INFO - 2023-03-15 01:55:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:55:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:55:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:55:09 --> Model "Login_model" initialized
INFO - 2023-03-15 01:55:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:55:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:55:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:55:09 --> Total execution time: 0.0307
INFO - 2023-03-15 01:55:09 --> Config Class Initialized
INFO - 2023-03-15 01:55:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:55:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:55:09 --> Utf8 Class Initialized
INFO - 2023-03-15 01:55:09 --> URI Class Initialized
INFO - 2023-03-15 01:55:09 --> Router Class Initialized
INFO - 2023-03-15 01:55:09 --> Output Class Initialized
INFO - 2023-03-15 01:55:09 --> Security Class Initialized
DEBUG - 2023-03-15 01:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:55:09 --> Input Class Initialized
INFO - 2023-03-15 01:55:09 --> Language Class Initialized
INFO - 2023-03-15 01:55:09 --> Loader Class Initialized
INFO - 2023-03-15 01:55:09 --> Controller Class Initialized
DEBUG - 2023-03-15 01:55:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:55:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:55:09 --> Model "Login_model" initialized
INFO - 2023-03-15 01:55:09 --> Database Driver Class Initialized
INFO - 2023-03-15 01:55:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:55:09 --> Final output sent to browser
DEBUG - 2023-03-15 01:55:09 --> Total execution time: 0.0308
INFO - 2023-03-15 01:56:23 --> Config Class Initialized
INFO - 2023-03-15 01:56:23 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:56:23 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:56:23 --> Utf8 Class Initialized
INFO - 2023-03-15 01:56:23 --> URI Class Initialized
INFO - 2023-03-15 01:56:23 --> Router Class Initialized
INFO - 2023-03-15 01:56:23 --> Output Class Initialized
INFO - 2023-03-15 01:56:23 --> Security Class Initialized
DEBUG - 2023-03-15 01:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:56:23 --> Input Class Initialized
INFO - 2023-03-15 01:56:23 --> Language Class Initialized
INFO - 2023-03-15 01:56:23 --> Loader Class Initialized
INFO - 2023-03-15 01:56:23 --> Controller Class Initialized
DEBUG - 2023-03-15 01:56:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:56:23 --> Database Driver Class Initialized
INFO - 2023-03-15 01:56:23 --> Model "Login_model" initialized
INFO - 2023-03-15 01:56:23 --> Database Driver Class Initialized
INFO - 2023-03-15 01:56:23 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:56:23 --> Final output sent to browser
DEBUG - 2023-03-15 01:56:23 --> Total execution time: 0.0315
INFO - 2023-03-15 01:56:23 --> Config Class Initialized
INFO - 2023-03-15 01:56:23 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:56:23 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:56:23 --> Utf8 Class Initialized
INFO - 2023-03-15 01:56:23 --> URI Class Initialized
INFO - 2023-03-15 01:56:23 --> Router Class Initialized
INFO - 2023-03-15 01:56:23 --> Output Class Initialized
INFO - 2023-03-15 01:56:23 --> Security Class Initialized
DEBUG - 2023-03-15 01:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:56:23 --> Input Class Initialized
INFO - 2023-03-15 01:56:23 --> Language Class Initialized
INFO - 2023-03-15 01:56:23 --> Loader Class Initialized
INFO - 2023-03-15 01:56:23 --> Controller Class Initialized
DEBUG - 2023-03-15 01:56:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:56:23 --> Database Driver Class Initialized
INFO - 2023-03-15 01:56:23 --> Model "Login_model" initialized
INFO - 2023-03-15 01:56:23 --> Database Driver Class Initialized
INFO - 2023-03-15 01:56:23 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:56:23 --> Final output sent to browser
DEBUG - 2023-03-15 01:56:23 --> Total execution time: 0.0325
INFO - 2023-03-15 01:57:08 --> Config Class Initialized
INFO - 2023-03-15 01:57:08 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:57:08 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:57:08 --> Utf8 Class Initialized
INFO - 2023-03-15 01:57:08 --> URI Class Initialized
INFO - 2023-03-15 01:57:08 --> Router Class Initialized
INFO - 2023-03-15 01:57:08 --> Output Class Initialized
INFO - 2023-03-15 01:57:08 --> Security Class Initialized
DEBUG - 2023-03-15 01:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:57:08 --> Input Class Initialized
INFO - 2023-03-15 01:57:08 --> Language Class Initialized
INFO - 2023-03-15 01:57:08 --> Loader Class Initialized
INFO - 2023-03-15 01:57:08 --> Controller Class Initialized
DEBUG - 2023-03-15 01:57:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:57:08 --> Database Driver Class Initialized
INFO - 2023-03-15 01:57:08 --> Model "Login_model" initialized
INFO - 2023-03-15 01:57:08 --> Database Driver Class Initialized
INFO - 2023-03-15 01:57:08 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:57:08 --> Final output sent to browser
DEBUG - 2023-03-15 01:57:08 --> Total execution time: 0.0397
INFO - 2023-03-15 01:57:08 --> Config Class Initialized
INFO - 2023-03-15 01:57:08 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:57:08 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:57:08 --> Utf8 Class Initialized
INFO - 2023-03-15 01:57:08 --> URI Class Initialized
INFO - 2023-03-15 01:57:08 --> Router Class Initialized
INFO - 2023-03-15 01:57:08 --> Output Class Initialized
INFO - 2023-03-15 01:57:08 --> Security Class Initialized
DEBUG - 2023-03-15 01:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:57:08 --> Input Class Initialized
INFO - 2023-03-15 01:57:08 --> Language Class Initialized
INFO - 2023-03-15 01:57:08 --> Loader Class Initialized
INFO - 2023-03-15 01:57:08 --> Controller Class Initialized
DEBUG - 2023-03-15 01:57:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:57:08 --> Database Driver Class Initialized
INFO - 2023-03-15 01:57:08 --> Model "Login_model" initialized
INFO - 2023-03-15 01:57:08 --> Database Driver Class Initialized
INFO - 2023-03-15 01:57:08 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:57:08 --> Final output sent to browser
DEBUG - 2023-03-15 01:57:08 --> Total execution time: 0.0796
INFO - 2023-03-15 01:57:10 --> Config Class Initialized
INFO - 2023-03-15 01:57:10 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:57:10 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:57:10 --> Utf8 Class Initialized
INFO - 2023-03-15 01:57:10 --> URI Class Initialized
INFO - 2023-03-15 01:57:10 --> Router Class Initialized
INFO - 2023-03-15 01:57:10 --> Output Class Initialized
INFO - 2023-03-15 01:57:10 --> Security Class Initialized
DEBUG - 2023-03-15 01:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:57:10 --> Input Class Initialized
INFO - 2023-03-15 01:57:10 --> Language Class Initialized
INFO - 2023-03-15 01:57:10 --> Loader Class Initialized
INFO - 2023-03-15 01:57:10 --> Controller Class Initialized
DEBUG - 2023-03-15 01:57:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:57:10 --> Database Driver Class Initialized
INFO - 2023-03-15 01:57:10 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:57:10 --> Database Driver Class Initialized
INFO - 2023-03-15 01:57:10 --> Model "Login_model" initialized
INFO - 2023-03-15 01:57:10 --> Final output sent to browser
DEBUG - 2023-03-15 01:57:10 --> Total execution time: 0.0871
INFO - 2023-03-15 01:57:10 --> Config Class Initialized
INFO - 2023-03-15 01:57:10 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:57:10 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:57:10 --> Utf8 Class Initialized
INFO - 2023-03-15 01:57:10 --> URI Class Initialized
INFO - 2023-03-15 01:57:10 --> Router Class Initialized
INFO - 2023-03-15 01:57:10 --> Output Class Initialized
INFO - 2023-03-15 01:57:10 --> Security Class Initialized
DEBUG - 2023-03-15 01:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:57:10 --> Input Class Initialized
INFO - 2023-03-15 01:57:10 --> Language Class Initialized
INFO - 2023-03-15 01:57:10 --> Loader Class Initialized
INFO - 2023-03-15 01:57:10 --> Controller Class Initialized
DEBUG - 2023-03-15 01:57:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:57:10 --> Database Driver Class Initialized
INFO - 2023-03-15 01:57:10 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:57:10 --> Database Driver Class Initialized
INFO - 2023-03-15 01:57:10 --> Model "Login_model" initialized
INFO - 2023-03-15 01:57:10 --> Final output sent to browser
DEBUG - 2023-03-15 01:57:10 --> Total execution time: 0.1140
INFO - 2023-03-15 01:57:12 --> Config Class Initialized
INFO - 2023-03-15 01:57:12 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:57:12 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:57:12 --> Utf8 Class Initialized
INFO - 2023-03-15 01:57:12 --> URI Class Initialized
INFO - 2023-03-15 01:57:12 --> Router Class Initialized
INFO - 2023-03-15 01:57:12 --> Output Class Initialized
INFO - 2023-03-15 01:57:12 --> Security Class Initialized
DEBUG - 2023-03-15 01:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:57:12 --> Input Class Initialized
INFO - 2023-03-15 01:57:12 --> Language Class Initialized
INFO - 2023-03-15 01:57:12 --> Loader Class Initialized
INFO - 2023-03-15 01:57:12 --> Controller Class Initialized
DEBUG - 2023-03-15 01:57:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:57:12 --> Database Driver Class Initialized
INFO - 2023-03-15 01:57:12 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:57:12 --> Final output sent to browser
DEBUG - 2023-03-15 01:57:12 --> Total execution time: 0.0621
INFO - 2023-03-15 01:57:12 --> Config Class Initialized
INFO - 2023-03-15 01:57:12 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:57:12 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:57:12 --> Utf8 Class Initialized
INFO - 2023-03-15 01:57:12 --> URI Class Initialized
INFO - 2023-03-15 01:57:12 --> Router Class Initialized
INFO - 2023-03-15 01:57:12 --> Output Class Initialized
INFO - 2023-03-15 01:57:12 --> Security Class Initialized
DEBUG - 2023-03-15 01:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:57:12 --> Input Class Initialized
INFO - 2023-03-15 01:57:12 --> Language Class Initialized
INFO - 2023-03-15 01:57:12 --> Loader Class Initialized
INFO - 2023-03-15 01:57:12 --> Controller Class Initialized
DEBUG - 2023-03-15 01:57:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:57:12 --> Database Driver Class Initialized
INFO - 2023-03-15 01:57:12 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:57:12 --> Final output sent to browser
DEBUG - 2023-03-15 01:57:12 --> Total execution time: 0.0863
INFO - 2023-03-15 01:57:15 --> Config Class Initialized
INFO - 2023-03-15 01:57:15 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:57:15 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:57:15 --> Utf8 Class Initialized
INFO - 2023-03-15 01:57:15 --> URI Class Initialized
INFO - 2023-03-15 01:57:15 --> Router Class Initialized
INFO - 2023-03-15 01:57:15 --> Output Class Initialized
INFO - 2023-03-15 01:57:15 --> Security Class Initialized
DEBUG - 2023-03-15 01:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:57:15 --> Input Class Initialized
INFO - 2023-03-15 01:57:15 --> Language Class Initialized
INFO - 2023-03-15 01:57:15 --> Loader Class Initialized
INFO - 2023-03-15 01:57:15 --> Controller Class Initialized
DEBUG - 2023-03-15 01:57:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:57:15 --> Database Driver Class Initialized
INFO - 2023-03-15 01:57:15 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:57:15 --> Final output sent to browser
DEBUG - 2023-03-15 01:57:15 --> Total execution time: 0.0580
INFO - 2023-03-15 01:57:15 --> Config Class Initialized
INFO - 2023-03-15 01:57:15 --> Hooks Class Initialized
DEBUG - 2023-03-15 01:57:15 --> UTF-8 Support Enabled
INFO - 2023-03-15 01:57:15 --> Utf8 Class Initialized
INFO - 2023-03-15 01:57:15 --> URI Class Initialized
INFO - 2023-03-15 01:57:15 --> Router Class Initialized
INFO - 2023-03-15 01:57:15 --> Output Class Initialized
INFO - 2023-03-15 01:57:15 --> Security Class Initialized
DEBUG - 2023-03-15 01:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 01:57:15 --> Input Class Initialized
INFO - 2023-03-15 01:57:15 --> Language Class Initialized
INFO - 2023-03-15 01:57:15 --> Loader Class Initialized
INFO - 2023-03-15 01:57:15 --> Controller Class Initialized
DEBUG - 2023-03-15 01:57:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 01:57:15 --> Database Driver Class Initialized
INFO - 2023-03-15 01:57:15 --> Model "Cluster_model" initialized
INFO - 2023-03-15 01:57:15 --> Final output sent to browser
DEBUG - 2023-03-15 01:57:15 --> Total execution time: 0.0553
INFO - 2023-03-15 02:06:08 --> Config Class Initialized
INFO - 2023-03-15 02:06:08 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:06:08 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:06:08 --> Utf8 Class Initialized
INFO - 2023-03-15 02:06:08 --> URI Class Initialized
INFO - 2023-03-15 02:06:08 --> Router Class Initialized
INFO - 2023-03-15 02:06:08 --> Output Class Initialized
INFO - 2023-03-15 02:06:08 --> Security Class Initialized
DEBUG - 2023-03-15 02:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:06:08 --> Input Class Initialized
INFO - 2023-03-15 02:06:08 --> Language Class Initialized
INFO - 2023-03-15 02:06:08 --> Loader Class Initialized
INFO - 2023-03-15 02:06:08 --> Controller Class Initialized
DEBUG - 2023-03-15 02:06:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:06:08 --> Database Driver Class Initialized
INFO - 2023-03-15 02:06:08 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:06:08 --> Final output sent to browser
DEBUG - 2023-03-15 02:06:08 --> Total execution time: 0.0526
INFO - 2023-03-15 02:06:08 --> Config Class Initialized
INFO - 2023-03-15 02:06:08 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:06:08 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:06:08 --> Utf8 Class Initialized
INFO - 2023-03-15 02:06:08 --> URI Class Initialized
INFO - 2023-03-15 02:06:08 --> Router Class Initialized
INFO - 2023-03-15 02:06:08 --> Output Class Initialized
INFO - 2023-03-15 02:06:08 --> Security Class Initialized
DEBUG - 2023-03-15 02:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:06:08 --> Input Class Initialized
INFO - 2023-03-15 02:06:08 --> Language Class Initialized
INFO - 2023-03-15 02:06:08 --> Loader Class Initialized
INFO - 2023-03-15 02:06:08 --> Controller Class Initialized
DEBUG - 2023-03-15 02:06:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:06:08 --> Database Driver Class Initialized
INFO - 2023-03-15 02:06:08 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:06:08 --> Final output sent to browser
DEBUG - 2023-03-15 02:06:08 --> Total execution time: 0.0495
INFO - 2023-03-15 02:06:09 --> Config Class Initialized
INFO - 2023-03-15 02:06:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:06:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:06:09 --> Utf8 Class Initialized
INFO - 2023-03-15 02:06:09 --> URI Class Initialized
INFO - 2023-03-15 02:06:09 --> Router Class Initialized
INFO - 2023-03-15 02:06:09 --> Output Class Initialized
INFO - 2023-03-15 02:06:09 --> Security Class Initialized
DEBUG - 2023-03-15 02:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:06:09 --> Input Class Initialized
INFO - 2023-03-15 02:06:09 --> Language Class Initialized
INFO - 2023-03-15 02:06:09 --> Loader Class Initialized
INFO - 2023-03-15 02:06:09 --> Controller Class Initialized
DEBUG - 2023-03-15 02:06:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:06:09 --> Database Driver Class Initialized
INFO - 2023-03-15 02:06:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:06:09 --> Database Driver Class Initialized
INFO - 2023-03-15 02:06:09 --> Model "Login_model" initialized
INFO - 2023-03-15 02:06:09 --> Final output sent to browser
DEBUG - 2023-03-15 02:06:09 --> Total execution time: 0.0472
INFO - 2023-03-15 02:06:09 --> Config Class Initialized
INFO - 2023-03-15 02:06:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:06:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:06:09 --> Utf8 Class Initialized
INFO - 2023-03-15 02:06:09 --> URI Class Initialized
INFO - 2023-03-15 02:06:09 --> Router Class Initialized
INFO - 2023-03-15 02:06:09 --> Output Class Initialized
INFO - 2023-03-15 02:06:09 --> Security Class Initialized
DEBUG - 2023-03-15 02:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:06:09 --> Input Class Initialized
INFO - 2023-03-15 02:06:09 --> Language Class Initialized
INFO - 2023-03-15 02:06:09 --> Loader Class Initialized
INFO - 2023-03-15 02:06:09 --> Controller Class Initialized
DEBUG - 2023-03-15 02:06:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:06:09 --> Database Driver Class Initialized
INFO - 2023-03-15 02:06:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:06:09 --> Database Driver Class Initialized
INFO - 2023-03-15 02:06:09 --> Model "Login_model" initialized
INFO - 2023-03-15 02:06:09 --> Final output sent to browser
DEBUG - 2023-03-15 02:06:09 --> Total execution time: 0.0819
INFO - 2023-03-15 02:07:26 --> Config Class Initialized
INFO - 2023-03-15 02:07:26 --> Config Class Initialized
INFO - 2023-03-15 02:07:26 --> Hooks Class Initialized
INFO - 2023-03-15 02:07:26 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:26 --> Utf8 Class Initialized
DEBUG - 2023-03-15 02:07:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:26 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:26 --> URI Class Initialized
INFO - 2023-03-15 02:07:26 --> URI Class Initialized
INFO - 2023-03-15 02:07:26 --> Router Class Initialized
INFO - 2023-03-15 02:07:26 --> Router Class Initialized
INFO - 2023-03-15 02:07:26 --> Output Class Initialized
INFO - 2023-03-15 02:07:26 --> Output Class Initialized
INFO - 2023-03-15 02:07:26 --> Security Class Initialized
INFO - 2023-03-15 02:07:26 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:26 --> Input Class Initialized
DEBUG - 2023-03-15 02:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:26 --> Language Class Initialized
INFO - 2023-03-15 02:07:26 --> Input Class Initialized
INFO - 2023-03-15 02:07:26 --> Language Class Initialized
INFO - 2023-03-15 02:07:26 --> Loader Class Initialized
INFO - 2023-03-15 02:07:26 --> Loader Class Initialized
INFO - 2023-03-15 02:07:26 --> Controller Class Initialized
INFO - 2023-03-15 02:07:26 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 02:07:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:26 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:26 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:26 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:26 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:26 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:26 --> Total execution time: 0.0151
INFO - 2023-03-15 02:07:26 --> Config Class Initialized
INFO - 2023-03-15 02:07:26 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:26 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:26 --> Config Class Initialized
INFO - 2023-03-15 02:07:27 --> Hooks Class Initialized
INFO - 2023-03-15 02:07:27 --> URI Class Initialized
DEBUG - 2023-03-15 02:07:27 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:27 --> Router Class Initialized
INFO - 2023-03-15 02:07:27 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:27 --> Output Class Initialized
INFO - 2023-03-15 02:07:27 --> URI Class Initialized
INFO - 2023-03-15 02:07:27 --> Security Class Initialized
INFO - 2023-03-15 02:07:27 --> Router Class Initialized
DEBUG - 2023-03-15 02:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:27 --> Output Class Initialized
INFO - 2023-03-15 02:07:27 --> Input Class Initialized
INFO - 2023-03-15 02:07:27 --> Security Class Initialized
INFO - 2023-03-15 02:07:27 --> Language Class Initialized
DEBUG - 2023-03-15 02:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:27 --> Input Class Initialized
INFO - 2023-03-15 02:07:27 --> Loader Class Initialized
INFO - 2023-03-15 02:07:27 --> Language Class Initialized
INFO - 2023-03-15 02:07:27 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:27 --> Loader Class Initialized
INFO - 2023-03-15 02:07:27 --> Controller Class Initialized
INFO - 2023-03-15 02:07:27 --> Database Driver Class Initialized
DEBUG - 2023-03-15 02:07:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:27 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:27 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:27 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:27 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:27 --> Total execution time: 0.1753
INFO - 2023-03-15 02:07:27 --> Config Class Initialized
INFO - 2023-03-15 02:07:27 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:27 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:27 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:27 --> URI Class Initialized
INFO - 2023-03-15 02:07:27 --> Router Class Initialized
INFO - 2023-03-15 02:07:27 --> Output Class Initialized
INFO - 2023-03-15 02:07:27 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:27 --> Input Class Initialized
INFO - 2023-03-15 02:07:27 --> Language Class Initialized
INFO - 2023-03-15 02:07:27 --> Loader Class Initialized
INFO - 2023-03-15 02:07:27 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:27 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:27 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:27 --> Config Class Initialized
INFO - 2023-03-15 02:07:27 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:27 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:27 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:27 --> URI Class Initialized
INFO - 2023-03-15 02:07:27 --> Router Class Initialized
INFO - 2023-03-15 02:07:27 --> Output Class Initialized
INFO - 2023-03-15 02:07:27 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:27 --> Input Class Initialized
INFO - 2023-03-15 02:07:27 --> Language Class Initialized
INFO - 2023-03-15 02:07:27 --> Loader Class Initialized
INFO - 2023-03-15 02:07:27 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:27 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:27 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:28 --> Config Class Initialized
INFO - 2023-03-15 02:07:28 --> Config Class Initialized
INFO - 2023-03-15 02:07:28 --> Hooks Class Initialized
INFO - 2023-03-15 02:07:28 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:28 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 02:07:28 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:28 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:28 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:28 --> URI Class Initialized
INFO - 2023-03-15 02:07:28 --> URI Class Initialized
INFO - 2023-03-15 02:07:28 --> Router Class Initialized
INFO - 2023-03-15 02:07:28 --> Output Class Initialized
INFO - 2023-03-15 02:07:28 --> Router Class Initialized
INFO - 2023-03-15 02:07:28 --> Security Class Initialized
INFO - 2023-03-15 02:07:28 --> Output Class Initialized
DEBUG - 2023-03-15 02:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:28 --> Security Class Initialized
INFO - 2023-03-15 02:07:28 --> Input Class Initialized
DEBUG - 2023-03-15 02:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:28 --> Language Class Initialized
INFO - 2023-03-15 02:07:28 --> Input Class Initialized
INFO - 2023-03-15 02:07:28 --> Language Class Initialized
INFO - 2023-03-15 02:07:28 --> Loader Class Initialized
INFO - 2023-03-15 02:07:28 --> Loader Class Initialized
INFO - 2023-03-15 02:07:28 --> Controller Class Initialized
INFO - 2023-03-15 02:07:28 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 02:07:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:28 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:28 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:28 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:28 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:28 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:28 --> Total execution time: 0.0142
INFO - 2023-03-15 02:07:31 --> Config Class Initialized
INFO - 2023-03-15 02:07:31 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:31 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:31 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:31 --> URI Class Initialized
INFO - 2023-03-15 02:07:31 --> Router Class Initialized
INFO - 2023-03-15 02:07:31 --> Output Class Initialized
INFO - 2023-03-15 02:07:31 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:31 --> Input Class Initialized
INFO - 2023-03-15 02:07:31 --> Language Class Initialized
INFO - 2023-03-15 02:07:31 --> Loader Class Initialized
INFO - 2023-03-15 02:07:31 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:31 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:31 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:31 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:31 --> Total execution time: 0.0140
INFO - 2023-03-15 02:07:31 --> Config Class Initialized
INFO - 2023-03-15 02:07:31 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:31 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:31 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:31 --> URI Class Initialized
INFO - 2023-03-15 02:07:31 --> Router Class Initialized
INFO - 2023-03-15 02:07:31 --> Output Class Initialized
INFO - 2023-03-15 02:07:31 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:31 --> Input Class Initialized
INFO - 2023-03-15 02:07:31 --> Language Class Initialized
INFO - 2023-03-15 02:07:31 --> Loader Class Initialized
INFO - 2023-03-15 02:07:31 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:31 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:31 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:31 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:31 --> Total execution time: 0.0540
INFO - 2023-03-15 02:07:33 --> Config Class Initialized
INFO - 2023-03-15 02:07:33 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:33 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:33 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:33 --> URI Class Initialized
INFO - 2023-03-15 02:07:33 --> Router Class Initialized
INFO - 2023-03-15 02:07:33 --> Output Class Initialized
INFO - 2023-03-15 02:07:33 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:33 --> Input Class Initialized
INFO - 2023-03-15 02:07:33 --> Language Class Initialized
INFO - 2023-03-15 02:07:33 --> Loader Class Initialized
INFO - 2023-03-15 02:07:33 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:33 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:33 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:33 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:33 --> Total execution time: 0.0159
INFO - 2023-03-15 02:07:34 --> Config Class Initialized
INFO - 2023-03-15 02:07:34 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:34 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:34 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:34 --> URI Class Initialized
INFO - 2023-03-15 02:07:34 --> Router Class Initialized
INFO - 2023-03-15 02:07:34 --> Output Class Initialized
INFO - 2023-03-15 02:07:34 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:34 --> Input Class Initialized
INFO - 2023-03-15 02:07:34 --> Language Class Initialized
INFO - 2023-03-15 02:07:34 --> Loader Class Initialized
INFO - 2023-03-15 02:07:34 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:34 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:34 --> Total execution time: 0.0044
INFO - 2023-03-15 02:07:34 --> Config Class Initialized
INFO - 2023-03-15 02:07:34 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:34 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:34 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:34 --> URI Class Initialized
INFO - 2023-03-15 02:07:34 --> Router Class Initialized
INFO - 2023-03-15 02:07:34 --> Output Class Initialized
INFO - 2023-03-15 02:07:34 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:34 --> Input Class Initialized
INFO - 2023-03-15 02:07:34 --> Language Class Initialized
INFO - 2023-03-15 02:07:34 --> Loader Class Initialized
INFO - 2023-03-15 02:07:34 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:34 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:34 --> Model "Login_model" initialized
INFO - 2023-03-15 02:07:34 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:34 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:34 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:34 --> Total execution time: 0.1188
INFO - 2023-03-15 02:07:34 --> Config Class Initialized
INFO - 2023-03-15 02:07:34 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:34 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:34 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:34 --> URI Class Initialized
INFO - 2023-03-15 02:07:34 --> Router Class Initialized
INFO - 2023-03-15 02:07:34 --> Output Class Initialized
INFO - 2023-03-15 02:07:34 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:34 --> Input Class Initialized
INFO - 2023-03-15 02:07:34 --> Language Class Initialized
INFO - 2023-03-15 02:07:34 --> Loader Class Initialized
INFO - 2023-03-15 02:07:34 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:34 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:34 --> Total execution time: 0.0420
INFO - 2023-03-15 02:07:34 --> Config Class Initialized
INFO - 2023-03-15 02:07:34 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:34 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:34 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:34 --> URI Class Initialized
INFO - 2023-03-15 02:07:34 --> Router Class Initialized
INFO - 2023-03-15 02:07:34 --> Output Class Initialized
INFO - 2023-03-15 02:07:34 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:34 --> Input Class Initialized
INFO - 2023-03-15 02:07:34 --> Language Class Initialized
INFO - 2023-03-15 02:07:34 --> Loader Class Initialized
INFO - 2023-03-15 02:07:34 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:34 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:34 --> Model "Login_model" initialized
INFO - 2023-03-15 02:07:34 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:34 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:34 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:34 --> Total execution time: 0.0305
INFO - 2023-03-15 02:07:35 --> Config Class Initialized
INFO - 2023-03-15 02:07:35 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:35 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:35 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:35 --> URI Class Initialized
INFO - 2023-03-15 02:07:35 --> Router Class Initialized
INFO - 2023-03-15 02:07:35 --> Output Class Initialized
INFO - 2023-03-15 02:07:35 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:35 --> Input Class Initialized
INFO - 2023-03-15 02:07:35 --> Language Class Initialized
INFO - 2023-03-15 02:07:35 --> Loader Class Initialized
INFO - 2023-03-15 02:07:35 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:35 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:35 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:35 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:35 --> Model "Login_model" initialized
INFO - 2023-03-15 02:07:35 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:35 --> Total execution time: 0.0874
INFO - 2023-03-15 02:07:35 --> Config Class Initialized
INFO - 2023-03-15 02:07:35 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:35 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:35 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:35 --> URI Class Initialized
INFO - 2023-03-15 02:07:35 --> Router Class Initialized
INFO - 2023-03-15 02:07:35 --> Output Class Initialized
INFO - 2023-03-15 02:07:35 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:35 --> Input Class Initialized
INFO - 2023-03-15 02:07:35 --> Language Class Initialized
INFO - 2023-03-15 02:07:35 --> Loader Class Initialized
INFO - 2023-03-15 02:07:35 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:35 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:35 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:35 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:35 --> Model "Login_model" initialized
INFO - 2023-03-15 02:07:35 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:35 --> Total execution time: 0.0369
INFO - 2023-03-15 02:07:36 --> Config Class Initialized
INFO - 2023-03-15 02:07:36 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:36 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:36 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:36 --> URI Class Initialized
INFO - 2023-03-15 02:07:36 --> Router Class Initialized
INFO - 2023-03-15 02:07:36 --> Output Class Initialized
INFO - 2023-03-15 02:07:36 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:36 --> Input Class Initialized
INFO - 2023-03-15 02:07:36 --> Language Class Initialized
INFO - 2023-03-15 02:07:36 --> Loader Class Initialized
INFO - 2023-03-15 02:07:36 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:36 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:36 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:36 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:36 --> Total execution time: 0.0916
INFO - 2023-03-15 02:07:36 --> Config Class Initialized
INFO - 2023-03-15 02:07:36 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:07:36 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:07:36 --> Utf8 Class Initialized
INFO - 2023-03-15 02:07:36 --> URI Class Initialized
INFO - 2023-03-15 02:07:36 --> Router Class Initialized
INFO - 2023-03-15 02:07:36 --> Output Class Initialized
INFO - 2023-03-15 02:07:36 --> Security Class Initialized
DEBUG - 2023-03-15 02:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:07:36 --> Input Class Initialized
INFO - 2023-03-15 02:07:36 --> Language Class Initialized
INFO - 2023-03-15 02:07:36 --> Loader Class Initialized
INFO - 2023-03-15 02:07:36 --> Controller Class Initialized
DEBUG - 2023-03-15 02:07:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:07:36 --> Database Driver Class Initialized
INFO - 2023-03-15 02:07:36 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:07:36 --> Final output sent to browser
DEBUG - 2023-03-15 02:07:36 --> Total execution time: 0.0435
INFO - 2023-03-15 02:27:37 --> Config Class Initialized
INFO - 2023-03-15 02:27:37 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:27:37 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:27:37 --> Utf8 Class Initialized
INFO - 2023-03-15 02:27:37 --> URI Class Initialized
INFO - 2023-03-15 02:27:37 --> Router Class Initialized
INFO - 2023-03-15 02:27:37 --> Output Class Initialized
INFO - 2023-03-15 02:27:37 --> Security Class Initialized
DEBUG - 2023-03-15 02:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:27:37 --> Input Class Initialized
INFO - 2023-03-15 02:27:37 --> Language Class Initialized
INFO - 2023-03-15 02:27:37 --> Loader Class Initialized
INFO - 2023-03-15 02:27:37 --> Controller Class Initialized
DEBUG - 2023-03-15 02:27:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:27:37 --> Database Driver Class Initialized
INFO - 2023-03-15 02:27:37 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:27:37 --> Final output sent to browser
DEBUG - 2023-03-15 02:27:37 --> Total execution time: 0.0171
INFO - 2023-03-15 02:27:37 --> Config Class Initialized
INFO - 2023-03-15 02:27:37 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:27:37 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:27:37 --> Utf8 Class Initialized
INFO - 2023-03-15 02:27:37 --> URI Class Initialized
INFO - 2023-03-15 02:27:37 --> Router Class Initialized
INFO - 2023-03-15 02:27:37 --> Output Class Initialized
INFO - 2023-03-15 02:27:37 --> Security Class Initialized
DEBUG - 2023-03-15 02:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:27:37 --> Input Class Initialized
INFO - 2023-03-15 02:27:37 --> Language Class Initialized
INFO - 2023-03-15 02:27:37 --> Loader Class Initialized
INFO - 2023-03-15 02:27:37 --> Controller Class Initialized
DEBUG - 2023-03-15 02:27:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:27:37 --> Database Driver Class Initialized
INFO - 2023-03-15 02:27:37 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:27:37 --> Final output sent to browser
DEBUG - 2023-03-15 02:27:37 --> Total execution time: 0.0598
INFO - 2023-03-15 02:27:37 --> Config Class Initialized
INFO - 2023-03-15 02:27:37 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:27:37 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:27:37 --> Utf8 Class Initialized
INFO - 2023-03-15 02:27:37 --> URI Class Initialized
INFO - 2023-03-15 02:27:37 --> Router Class Initialized
INFO - 2023-03-15 02:27:37 --> Output Class Initialized
INFO - 2023-03-15 02:27:37 --> Security Class Initialized
DEBUG - 2023-03-15 02:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:27:37 --> Input Class Initialized
INFO - 2023-03-15 02:27:37 --> Language Class Initialized
INFO - 2023-03-15 02:27:37 --> Loader Class Initialized
INFO - 2023-03-15 02:27:37 --> Controller Class Initialized
DEBUG - 2023-03-15 02:27:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:27:37 --> Database Driver Class Initialized
INFO - 2023-03-15 02:27:37 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:27:37 --> Final output sent to browser
DEBUG - 2023-03-15 02:27:37 --> Total execution time: 0.0389
INFO - 2023-03-15 02:27:37 --> Config Class Initialized
INFO - 2023-03-15 02:27:37 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:27:37 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:27:37 --> Utf8 Class Initialized
INFO - 2023-03-15 02:27:37 --> URI Class Initialized
INFO - 2023-03-15 02:27:37 --> Router Class Initialized
INFO - 2023-03-15 02:27:37 --> Output Class Initialized
INFO - 2023-03-15 02:27:37 --> Security Class Initialized
DEBUG - 2023-03-15 02:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:27:37 --> Input Class Initialized
INFO - 2023-03-15 02:27:37 --> Language Class Initialized
INFO - 2023-03-15 02:27:37 --> Loader Class Initialized
INFO - 2023-03-15 02:27:37 --> Controller Class Initialized
DEBUG - 2023-03-15 02:27:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:27:37 --> Database Driver Class Initialized
INFO - 2023-03-15 02:27:37 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:27:37 --> Final output sent to browser
DEBUG - 2023-03-15 02:27:37 --> Total execution time: 0.0822
INFO - 2023-03-15 02:27:37 --> Config Class Initialized
INFO - 2023-03-15 02:27:38 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:27:38 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:27:38 --> Utf8 Class Initialized
INFO - 2023-03-15 02:27:38 --> URI Class Initialized
INFO - 2023-03-15 02:27:38 --> Router Class Initialized
INFO - 2023-03-15 02:27:38 --> Output Class Initialized
INFO - 2023-03-15 02:27:38 --> Security Class Initialized
DEBUG - 2023-03-15 02:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:27:38 --> Input Class Initialized
INFO - 2023-03-15 02:27:38 --> Language Class Initialized
INFO - 2023-03-15 02:27:38 --> Loader Class Initialized
INFO - 2023-03-15 02:27:38 --> Controller Class Initialized
DEBUG - 2023-03-15 02:27:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:27:38 --> Database Driver Class Initialized
INFO - 2023-03-15 02:27:38 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:27:38 --> Database Driver Class Initialized
INFO - 2023-03-15 02:27:38 --> Model "Login_model" initialized
INFO - 2023-03-15 02:27:38 --> Final output sent to browser
DEBUG - 2023-03-15 02:27:38 --> Total execution time: 0.0768
INFO - 2023-03-15 02:27:38 --> Config Class Initialized
INFO - 2023-03-15 02:27:38 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:27:38 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:27:38 --> Utf8 Class Initialized
INFO - 2023-03-15 02:27:38 --> URI Class Initialized
INFO - 2023-03-15 02:27:38 --> Router Class Initialized
INFO - 2023-03-15 02:27:38 --> Output Class Initialized
INFO - 2023-03-15 02:27:38 --> Security Class Initialized
DEBUG - 2023-03-15 02:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:27:38 --> Input Class Initialized
INFO - 2023-03-15 02:27:38 --> Language Class Initialized
INFO - 2023-03-15 02:27:38 --> Loader Class Initialized
INFO - 2023-03-15 02:27:38 --> Controller Class Initialized
DEBUG - 2023-03-15 02:27:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:27:38 --> Database Driver Class Initialized
INFO - 2023-03-15 02:27:38 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:27:38 --> Database Driver Class Initialized
INFO - 2023-03-15 02:27:38 --> Model "Login_model" initialized
INFO - 2023-03-15 02:27:38 --> Final output sent to browser
DEBUG - 2023-03-15 02:27:38 --> Total execution time: 0.0808
INFO - 2023-03-15 02:27:49 --> Config Class Initialized
INFO - 2023-03-15 02:27:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:27:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:27:49 --> Utf8 Class Initialized
INFO - 2023-03-15 02:27:49 --> URI Class Initialized
INFO - 2023-03-15 02:27:49 --> Router Class Initialized
INFO - 2023-03-15 02:27:49 --> Output Class Initialized
INFO - 2023-03-15 02:27:49 --> Security Class Initialized
DEBUG - 2023-03-15 02:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:27:49 --> Input Class Initialized
INFO - 2023-03-15 02:27:49 --> Language Class Initialized
INFO - 2023-03-15 02:27:49 --> Loader Class Initialized
INFO - 2023-03-15 02:27:49 --> Controller Class Initialized
DEBUG - 2023-03-15 02:27:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:27:49 --> Database Driver Class Initialized
INFO - 2023-03-15 02:27:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:27:49 --> Final output sent to browser
DEBUG - 2023-03-15 02:27:49 --> Total execution time: 0.0487
INFO - 2023-03-15 02:27:49 --> Config Class Initialized
INFO - 2023-03-15 02:27:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:27:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:27:49 --> Utf8 Class Initialized
INFO - 2023-03-15 02:27:49 --> URI Class Initialized
INFO - 2023-03-15 02:27:49 --> Router Class Initialized
INFO - 2023-03-15 02:27:49 --> Output Class Initialized
INFO - 2023-03-15 02:27:49 --> Security Class Initialized
DEBUG - 2023-03-15 02:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:27:49 --> Input Class Initialized
INFO - 2023-03-15 02:27:49 --> Language Class Initialized
INFO - 2023-03-15 02:27:49 --> Loader Class Initialized
INFO - 2023-03-15 02:27:49 --> Controller Class Initialized
DEBUG - 2023-03-15 02:27:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:27:49 --> Database Driver Class Initialized
INFO - 2023-03-15 02:27:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:27:49 --> Final output sent to browser
DEBUG - 2023-03-15 02:27:49 --> Total execution time: 0.0428
INFO - 2023-03-15 02:31:13 --> Config Class Initialized
INFO - 2023-03-15 02:31:13 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:31:13 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:31:13 --> Utf8 Class Initialized
INFO - 2023-03-15 02:31:13 --> URI Class Initialized
INFO - 2023-03-15 02:31:13 --> Router Class Initialized
INFO - 2023-03-15 02:31:13 --> Output Class Initialized
INFO - 2023-03-15 02:31:13 --> Security Class Initialized
DEBUG - 2023-03-15 02:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:31:13 --> Input Class Initialized
INFO - 2023-03-15 02:31:13 --> Language Class Initialized
INFO - 2023-03-15 02:31:13 --> Loader Class Initialized
INFO - 2023-03-15 02:31:13 --> Controller Class Initialized
DEBUG - 2023-03-15 02:31:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:31:13 --> Database Driver Class Initialized
INFO - 2023-03-15 02:31:13 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:31:13 --> Database Driver Class Initialized
INFO - 2023-03-15 02:31:13 --> Model "Login_model" initialized
INFO - 2023-03-15 02:31:13 --> Final output sent to browser
DEBUG - 2023-03-15 02:31:13 --> Total execution time: 0.0803
INFO - 2023-03-15 02:31:13 --> Config Class Initialized
INFO - 2023-03-15 02:31:13 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:31:13 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:31:13 --> Utf8 Class Initialized
INFO - 2023-03-15 02:31:13 --> URI Class Initialized
INFO - 2023-03-15 02:31:13 --> Router Class Initialized
INFO - 2023-03-15 02:31:13 --> Output Class Initialized
INFO - 2023-03-15 02:31:13 --> Security Class Initialized
DEBUG - 2023-03-15 02:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:31:13 --> Input Class Initialized
INFO - 2023-03-15 02:31:13 --> Language Class Initialized
INFO - 2023-03-15 02:31:13 --> Loader Class Initialized
INFO - 2023-03-15 02:31:13 --> Controller Class Initialized
DEBUG - 2023-03-15 02:31:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:31:13 --> Database Driver Class Initialized
INFO - 2023-03-15 02:31:13 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:31:13 --> Database Driver Class Initialized
INFO - 2023-03-15 02:31:13 --> Model "Login_model" initialized
INFO - 2023-03-15 02:31:13 --> Final output sent to browser
DEBUG - 2023-03-15 02:31:13 --> Total execution time: 0.0398
INFO - 2023-03-15 02:59:26 --> Config Class Initialized
INFO - 2023-03-15 02:59:26 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:59:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:59:26 --> Utf8 Class Initialized
INFO - 2023-03-15 02:59:26 --> URI Class Initialized
INFO - 2023-03-15 02:59:26 --> Router Class Initialized
INFO - 2023-03-15 02:59:26 --> Output Class Initialized
INFO - 2023-03-15 02:59:26 --> Security Class Initialized
DEBUG - 2023-03-15 02:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:59:26 --> Input Class Initialized
INFO - 2023-03-15 02:59:26 --> Language Class Initialized
INFO - 2023-03-15 02:59:26 --> Loader Class Initialized
INFO - 2023-03-15 02:59:26 --> Controller Class Initialized
DEBUG - 2023-03-15 02:59:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:59:26 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:26 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:59:26 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:26 --> Model "Login_model" initialized
INFO - 2023-03-15 02:59:26 --> Final output sent to browser
DEBUG - 2023-03-15 02:59:26 --> Total execution time: 0.1320
INFO - 2023-03-15 02:59:26 --> Config Class Initialized
INFO - 2023-03-15 02:59:26 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:59:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:59:26 --> Utf8 Class Initialized
INFO - 2023-03-15 02:59:26 --> URI Class Initialized
INFO - 2023-03-15 02:59:26 --> Router Class Initialized
INFO - 2023-03-15 02:59:26 --> Output Class Initialized
INFO - 2023-03-15 02:59:26 --> Security Class Initialized
DEBUG - 2023-03-15 02:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:59:26 --> Input Class Initialized
INFO - 2023-03-15 02:59:26 --> Language Class Initialized
INFO - 2023-03-15 02:59:26 --> Loader Class Initialized
INFO - 2023-03-15 02:59:26 --> Controller Class Initialized
DEBUG - 2023-03-15 02:59:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:59:26 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:26 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:59:26 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:26 --> Model "Login_model" initialized
INFO - 2023-03-15 02:59:26 --> Final output sent to browser
DEBUG - 2023-03-15 02:59:26 --> Total execution time: 0.0837
INFO - 2023-03-15 02:59:29 --> Config Class Initialized
INFO - 2023-03-15 02:59:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:59:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:59:29 --> Utf8 Class Initialized
INFO - 2023-03-15 02:59:29 --> URI Class Initialized
INFO - 2023-03-15 02:59:29 --> Router Class Initialized
INFO - 2023-03-15 02:59:29 --> Output Class Initialized
INFO - 2023-03-15 02:59:29 --> Security Class Initialized
DEBUG - 2023-03-15 02:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:59:29 --> Input Class Initialized
INFO - 2023-03-15 02:59:29 --> Language Class Initialized
INFO - 2023-03-15 02:59:29 --> Loader Class Initialized
INFO - 2023-03-15 02:59:29 --> Controller Class Initialized
DEBUG - 2023-03-15 02:59:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:59:29 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:29 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:59:29 --> Final output sent to browser
DEBUG - 2023-03-15 02:59:29 --> Total execution time: 0.0539
INFO - 2023-03-15 02:59:29 --> Config Class Initialized
INFO - 2023-03-15 02:59:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:59:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:59:29 --> Utf8 Class Initialized
INFO - 2023-03-15 02:59:29 --> URI Class Initialized
INFO - 2023-03-15 02:59:29 --> Router Class Initialized
INFO - 2023-03-15 02:59:29 --> Output Class Initialized
INFO - 2023-03-15 02:59:29 --> Security Class Initialized
DEBUG - 2023-03-15 02:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:59:29 --> Input Class Initialized
INFO - 2023-03-15 02:59:29 --> Language Class Initialized
INFO - 2023-03-15 02:59:29 --> Loader Class Initialized
INFO - 2023-03-15 02:59:29 --> Controller Class Initialized
DEBUG - 2023-03-15 02:59:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:59:29 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:29 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:59:29 --> Final output sent to browser
DEBUG - 2023-03-15 02:59:29 --> Total execution time: 0.0886
INFO - 2023-03-15 02:59:32 --> Config Class Initialized
INFO - 2023-03-15 02:59:32 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:59:32 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:59:32 --> Utf8 Class Initialized
INFO - 2023-03-15 02:59:32 --> URI Class Initialized
INFO - 2023-03-15 02:59:32 --> Router Class Initialized
INFO - 2023-03-15 02:59:32 --> Output Class Initialized
INFO - 2023-03-15 02:59:32 --> Security Class Initialized
DEBUG - 2023-03-15 02:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:59:32 --> Input Class Initialized
INFO - 2023-03-15 02:59:32 --> Language Class Initialized
INFO - 2023-03-15 02:59:32 --> Loader Class Initialized
INFO - 2023-03-15 02:59:32 --> Controller Class Initialized
DEBUG - 2023-03-15 02:59:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:59:32 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:32 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:59:32 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:32 --> Model "Login_model" initialized
INFO - 2023-03-15 02:59:32 --> Final output sent to browser
DEBUG - 2023-03-15 02:59:32 --> Total execution time: 0.0917
INFO - 2023-03-15 02:59:32 --> Config Class Initialized
INFO - 2023-03-15 02:59:32 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:59:32 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:59:32 --> Utf8 Class Initialized
INFO - 2023-03-15 02:59:32 --> URI Class Initialized
INFO - 2023-03-15 02:59:32 --> Router Class Initialized
INFO - 2023-03-15 02:59:32 --> Output Class Initialized
INFO - 2023-03-15 02:59:32 --> Security Class Initialized
DEBUG - 2023-03-15 02:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:59:32 --> Input Class Initialized
INFO - 2023-03-15 02:59:32 --> Language Class Initialized
INFO - 2023-03-15 02:59:32 --> Loader Class Initialized
INFO - 2023-03-15 02:59:32 --> Controller Class Initialized
DEBUG - 2023-03-15 02:59:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:59:32 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:33 --> Model "Cluster_model" initialized
INFO - 2023-03-15 02:59:33 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:33 --> Model "Login_model" initialized
INFO - 2023-03-15 02:59:33 --> Final output sent to browser
DEBUG - 2023-03-15 02:59:33 --> Total execution time: 0.0405
INFO - 2023-03-15 02:59:38 --> Config Class Initialized
INFO - 2023-03-15 02:59:38 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:59:38 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:59:38 --> Utf8 Class Initialized
INFO - 2023-03-15 02:59:38 --> URI Class Initialized
INFO - 2023-03-15 02:59:38 --> Router Class Initialized
INFO - 2023-03-15 02:59:38 --> Output Class Initialized
INFO - 2023-03-15 02:59:38 --> Security Class Initialized
DEBUG - 2023-03-15 02:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:59:38 --> Input Class Initialized
INFO - 2023-03-15 02:59:38 --> Language Class Initialized
INFO - 2023-03-15 02:59:38 --> Loader Class Initialized
INFO - 2023-03-15 02:59:38 --> Controller Class Initialized
DEBUG - 2023-03-15 02:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:59:38 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:38 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:38 --> Model "Login_model" initialized
INFO - 2023-03-15 02:59:38 --> Final output sent to browser
DEBUG - 2023-03-15 02:59:38 --> Total execution time: 0.0308
INFO - 2023-03-15 02:59:38 --> Config Class Initialized
INFO - 2023-03-15 02:59:38 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:59:38 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:59:38 --> Utf8 Class Initialized
INFO - 2023-03-15 02:59:38 --> URI Class Initialized
INFO - 2023-03-15 02:59:38 --> Router Class Initialized
INFO - 2023-03-15 02:59:38 --> Output Class Initialized
INFO - 2023-03-15 02:59:38 --> Security Class Initialized
DEBUG - 2023-03-15 02:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:59:38 --> Input Class Initialized
INFO - 2023-03-15 02:59:38 --> Language Class Initialized
INFO - 2023-03-15 02:59:38 --> Loader Class Initialized
INFO - 2023-03-15 02:59:38 --> Controller Class Initialized
DEBUG - 2023-03-15 02:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:59:38 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:38 --> Database Driver Class Initialized
INFO - 2023-03-15 02:59:38 --> Model "Login_model" initialized
INFO - 2023-03-15 02:59:38 --> Final output sent to browser
DEBUG - 2023-03-15 02:59:38 --> Total execution time: 0.0674
INFO - 2023-03-15 02:59:38 --> Config Class Initialized
INFO - 2023-03-15 02:59:38 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:59:38 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:59:38 --> Utf8 Class Initialized
INFO - 2023-03-15 02:59:38 --> URI Class Initialized
INFO - 2023-03-15 02:59:38 --> Router Class Initialized
INFO - 2023-03-15 02:59:38 --> Output Class Initialized
INFO - 2023-03-15 02:59:38 --> Security Class Initialized
DEBUG - 2023-03-15 02:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:59:38 --> Input Class Initialized
INFO - 2023-03-15 02:59:38 --> Language Class Initialized
INFO - 2023-03-15 02:59:38 --> Loader Class Initialized
INFO - 2023-03-15 02:59:38 --> Controller Class Initialized
DEBUG - 2023-03-15 02:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:59:38 --> Final output sent to browser
DEBUG - 2023-03-15 02:59:38 --> Total execution time: 0.0458
INFO - 2023-03-15 02:59:38 --> Config Class Initialized
INFO - 2023-03-15 02:59:38 --> Hooks Class Initialized
DEBUG - 2023-03-15 02:59:38 --> UTF-8 Support Enabled
INFO - 2023-03-15 02:59:38 --> Utf8 Class Initialized
INFO - 2023-03-15 02:59:38 --> URI Class Initialized
INFO - 2023-03-15 02:59:38 --> Router Class Initialized
INFO - 2023-03-15 02:59:38 --> Output Class Initialized
INFO - 2023-03-15 02:59:38 --> Security Class Initialized
DEBUG - 2023-03-15 02:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 02:59:38 --> Input Class Initialized
INFO - 2023-03-15 02:59:38 --> Language Class Initialized
INFO - 2023-03-15 02:59:38 --> Loader Class Initialized
INFO - 2023-03-15 02:59:38 --> Controller Class Initialized
DEBUG - 2023-03-15 02:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 02:59:38 --> Final output sent to browser
DEBUG - 2023-03-15 02:59:38 --> Total execution time: 0.0634
INFO - 2023-03-15 03:00:03 --> Config Class Initialized
INFO - 2023-03-15 03:00:03 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:03 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:03 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:03 --> URI Class Initialized
INFO - 2023-03-15 03:00:03 --> Router Class Initialized
INFO - 2023-03-15 03:00:03 --> Output Class Initialized
INFO - 2023-03-15 03:00:03 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:03 --> Input Class Initialized
INFO - 2023-03-15 03:00:03 --> Language Class Initialized
INFO - 2023-03-15 03:00:03 --> Loader Class Initialized
INFO - 2023-03-15 03:00:03 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:03 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:03 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:03 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:03 --> Total execution time: 0.0152
INFO - 2023-03-15 03:00:03 --> Config Class Initialized
INFO - 2023-03-15 03:00:03 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:03 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:03 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:03 --> URI Class Initialized
INFO - 2023-03-15 03:00:03 --> Router Class Initialized
INFO - 2023-03-15 03:00:03 --> Output Class Initialized
INFO - 2023-03-15 03:00:03 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:03 --> Input Class Initialized
INFO - 2023-03-15 03:00:03 --> Language Class Initialized
INFO - 2023-03-15 03:00:03 --> Loader Class Initialized
INFO - 2023-03-15 03:00:03 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:03 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:03 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:03 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:03 --> Total execution time: 0.0516
INFO - 2023-03-15 03:00:05 --> Config Class Initialized
INFO - 2023-03-15 03:00:05 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:05 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:05 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:05 --> URI Class Initialized
INFO - 2023-03-15 03:00:05 --> Router Class Initialized
INFO - 2023-03-15 03:00:05 --> Output Class Initialized
INFO - 2023-03-15 03:00:05 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:05 --> Input Class Initialized
INFO - 2023-03-15 03:00:05 --> Language Class Initialized
INFO - 2023-03-15 03:00:05 --> Loader Class Initialized
INFO - 2023-03-15 03:00:05 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:05 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:05 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:05 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:05 --> Total execution time: 0.0744
INFO - 2023-03-15 03:00:05 --> Config Class Initialized
INFO - 2023-03-15 03:00:05 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:05 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:05 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:05 --> URI Class Initialized
INFO - 2023-03-15 03:00:05 --> Router Class Initialized
INFO - 2023-03-15 03:00:05 --> Output Class Initialized
INFO - 2023-03-15 03:00:05 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:05 --> Input Class Initialized
INFO - 2023-03-15 03:00:05 --> Language Class Initialized
INFO - 2023-03-15 03:00:05 --> Loader Class Initialized
INFO - 2023-03-15 03:00:05 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:05 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:05 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:05 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:05 --> Total execution time: 0.0445
INFO - 2023-03-15 03:00:19 --> Config Class Initialized
INFO - 2023-03-15 03:00:19 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:19 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:19 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:19 --> URI Class Initialized
INFO - 2023-03-15 03:00:19 --> Router Class Initialized
INFO - 2023-03-15 03:00:19 --> Output Class Initialized
INFO - 2023-03-15 03:00:19 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:19 --> Input Class Initialized
INFO - 2023-03-15 03:00:19 --> Language Class Initialized
INFO - 2023-03-15 03:00:19 --> Loader Class Initialized
INFO - 2023-03-15 03:00:19 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:19 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:19 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:19 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:19 --> Total execution time: 0.0216
INFO - 2023-03-15 03:00:19 --> Config Class Initialized
INFO - 2023-03-15 03:00:19 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:19 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:19 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:19 --> URI Class Initialized
INFO - 2023-03-15 03:00:19 --> Router Class Initialized
INFO - 2023-03-15 03:00:19 --> Output Class Initialized
INFO - 2023-03-15 03:00:19 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:19 --> Input Class Initialized
INFO - 2023-03-15 03:00:19 --> Language Class Initialized
INFO - 2023-03-15 03:00:19 --> Loader Class Initialized
INFO - 2023-03-15 03:00:19 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:19 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:19 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:19 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:19 --> Total execution time: 0.0139
INFO - 2023-03-15 03:00:22 --> Config Class Initialized
INFO - 2023-03-15 03:00:22 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:22 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:22 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:22 --> URI Class Initialized
INFO - 2023-03-15 03:00:22 --> Router Class Initialized
INFO - 2023-03-15 03:00:22 --> Output Class Initialized
INFO - 2023-03-15 03:00:22 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:22 --> Input Class Initialized
INFO - 2023-03-15 03:00:22 --> Language Class Initialized
INFO - 2023-03-15 03:00:22 --> Loader Class Initialized
INFO - 2023-03-15 03:00:22 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:22 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:22 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:22 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:22 --> Total execution time: 0.0478
INFO - 2023-03-15 03:00:22 --> Config Class Initialized
INFO - 2023-03-15 03:00:22 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:22 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:22 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:22 --> URI Class Initialized
INFO - 2023-03-15 03:00:22 --> Router Class Initialized
INFO - 2023-03-15 03:00:22 --> Output Class Initialized
INFO - 2023-03-15 03:00:22 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:22 --> Input Class Initialized
INFO - 2023-03-15 03:00:22 --> Language Class Initialized
INFO - 2023-03-15 03:00:22 --> Loader Class Initialized
INFO - 2023-03-15 03:00:22 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:22 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:22 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:22 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:22 --> Total execution time: 0.0484
INFO - 2023-03-15 03:00:23 --> Config Class Initialized
INFO - 2023-03-15 03:00:23 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:23 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:23 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:23 --> URI Class Initialized
INFO - 2023-03-15 03:00:23 --> Router Class Initialized
INFO - 2023-03-15 03:00:23 --> Output Class Initialized
INFO - 2023-03-15 03:00:23 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:23 --> Input Class Initialized
INFO - 2023-03-15 03:00:23 --> Language Class Initialized
INFO - 2023-03-15 03:00:23 --> Loader Class Initialized
INFO - 2023-03-15 03:00:23 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:23 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:23 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:23 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:23 --> Model "Login_model" initialized
INFO - 2023-03-15 03:00:23 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:23 --> Total execution time: 0.0619
INFO - 2023-03-15 03:00:23 --> Config Class Initialized
INFO - 2023-03-15 03:00:23 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:23 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:23 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:23 --> URI Class Initialized
INFO - 2023-03-15 03:00:23 --> Router Class Initialized
INFO - 2023-03-15 03:00:23 --> Output Class Initialized
INFO - 2023-03-15 03:00:23 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:23 --> Input Class Initialized
INFO - 2023-03-15 03:00:23 --> Language Class Initialized
INFO - 2023-03-15 03:00:23 --> Loader Class Initialized
INFO - 2023-03-15 03:00:23 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:23 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:23 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:23 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:23 --> Model "Login_model" initialized
INFO - 2023-03-15 03:00:23 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:23 --> Total execution time: 0.0416
INFO - 2023-03-15 03:00:54 --> Config Class Initialized
INFO - 2023-03-15 03:00:54 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:54 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:54 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:54 --> URI Class Initialized
INFO - 2023-03-15 03:00:54 --> Router Class Initialized
INFO - 2023-03-15 03:00:54 --> Output Class Initialized
INFO - 2023-03-15 03:00:54 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:54 --> Input Class Initialized
INFO - 2023-03-15 03:00:54 --> Language Class Initialized
INFO - 2023-03-15 03:00:54 --> Loader Class Initialized
INFO - 2023-03-15 03:00:54 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:54 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:54 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:54 --> Model "Login_model" initialized
INFO - 2023-03-15 03:00:54 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:54 --> Total execution time: 0.0230
INFO - 2023-03-15 03:00:54 --> Config Class Initialized
INFO - 2023-03-15 03:00:54 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:54 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:54 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:54 --> URI Class Initialized
INFO - 2023-03-15 03:00:54 --> Router Class Initialized
INFO - 2023-03-15 03:00:54 --> Output Class Initialized
INFO - 2023-03-15 03:00:54 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:54 --> Input Class Initialized
INFO - 2023-03-15 03:00:54 --> Language Class Initialized
INFO - 2023-03-15 03:00:54 --> Loader Class Initialized
INFO - 2023-03-15 03:00:54 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:54 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:54 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:54 --> Model "Login_model" initialized
INFO - 2023-03-15 03:00:54 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:54 --> Total execution time: 0.0214
INFO - 2023-03-15 03:00:54 --> Config Class Initialized
INFO - 2023-03-15 03:00:54 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:54 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:54 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:54 --> URI Class Initialized
INFO - 2023-03-15 03:00:54 --> Router Class Initialized
INFO - 2023-03-15 03:00:54 --> Output Class Initialized
INFO - 2023-03-15 03:00:54 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:54 --> Input Class Initialized
INFO - 2023-03-15 03:00:54 --> Language Class Initialized
INFO - 2023-03-15 03:00:54 --> Loader Class Initialized
INFO - 2023-03-15 03:00:54 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:54 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:54 --> Total execution time: 0.0410
INFO - 2023-03-15 03:00:54 --> Config Class Initialized
INFO - 2023-03-15 03:00:54 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:54 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:54 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:54 --> URI Class Initialized
INFO - 2023-03-15 03:00:54 --> Router Class Initialized
INFO - 2023-03-15 03:00:54 --> Output Class Initialized
INFO - 2023-03-15 03:00:54 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:54 --> Input Class Initialized
INFO - 2023-03-15 03:00:54 --> Language Class Initialized
INFO - 2023-03-15 03:00:54 --> Loader Class Initialized
INFO - 2023-03-15 03:00:54 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:54 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:54 --> Total execution time: 0.0554
INFO - 2023-03-15 03:00:54 --> Config Class Initialized
INFO - 2023-03-15 03:00:54 --> Hooks Class Initialized
INFO - 2023-03-15 03:00:54 --> Config Class Initialized
INFO - 2023-03-15 03:00:54 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:54 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 03:00:54 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:54 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:54 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:54 --> URI Class Initialized
INFO - 2023-03-15 03:00:54 --> URI Class Initialized
INFO - 2023-03-15 03:00:54 --> Router Class Initialized
INFO - 2023-03-15 03:00:54 --> Output Class Initialized
INFO - 2023-03-15 03:00:54 --> Router Class Initialized
INFO - 2023-03-15 03:00:54 --> Security Class Initialized
INFO - 2023-03-15 03:00:54 --> Output Class Initialized
DEBUG - 2023-03-15 03:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:54 --> Security Class Initialized
INFO - 2023-03-15 03:00:54 --> Input Class Initialized
DEBUG - 2023-03-15 03:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:54 --> Language Class Initialized
INFO - 2023-03-15 03:00:54 --> Input Class Initialized
INFO - 2023-03-15 03:00:54 --> Language Class Initialized
INFO - 2023-03-15 03:00:54 --> Loader Class Initialized
INFO - 2023-03-15 03:00:54 --> Loader Class Initialized
INFO - 2023-03-15 03:00:54 --> Controller Class Initialized
INFO - 2023-03-15 03:00:54 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 03:00:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:54 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:54 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:54 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:54 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:54 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:54 --> Total execution time: 0.0239
INFO - 2023-03-15 03:00:54 --> Config Class Initialized
INFO - 2023-03-15 03:00:54 --> Hooks Class Initialized
INFO - 2023-03-15 03:00:54 --> Config Class Initialized
INFO - 2023-03-15 03:00:54 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:54 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:54 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:54 --> URI Class Initialized
INFO - 2023-03-15 03:00:54 --> Router Class Initialized
INFO - 2023-03-15 03:00:54 --> Output Class Initialized
INFO - 2023-03-15 03:00:54 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:54 --> Input Class Initialized
INFO - 2023-03-15 03:00:54 --> Language Class Initialized
INFO - 2023-03-15 03:00:54 --> Loader Class Initialized
INFO - 2023-03-15 03:00:54 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:54 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:54 --> Model "Cluster_model" initialized
DEBUG - 2023-03-15 03:00:55 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:55 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:55 --> URI Class Initialized
INFO - 2023-03-15 03:00:55 --> Router Class Initialized
INFO - 2023-03-15 03:00:55 --> Output Class Initialized
INFO - 2023-03-15 03:00:55 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:55 --> Input Class Initialized
INFO - 2023-03-15 03:00:55 --> Language Class Initialized
INFO - 2023-03-15 03:00:55 --> Loader Class Initialized
INFO - 2023-03-15 03:00:55 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:55 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:55 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:55 --> Final output sent to browser
DEBUG - 2023-03-15 03:00:55 --> Total execution time: 0.1769
INFO - 2023-03-15 03:00:57 --> Config Class Initialized
INFO - 2023-03-15 03:00:57 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:57 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:57 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:57 --> URI Class Initialized
INFO - 2023-03-15 03:00:57 --> Router Class Initialized
INFO - 2023-03-15 03:00:57 --> Output Class Initialized
INFO - 2023-03-15 03:00:57 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:57 --> Input Class Initialized
INFO - 2023-03-15 03:00:57 --> Language Class Initialized
INFO - 2023-03-15 03:00:57 --> Loader Class Initialized
INFO - 2023-03-15 03:00:57 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:57 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:57 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:00:57 --> Config Class Initialized
INFO - 2023-03-15 03:00:57 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:00:57 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:00:57 --> Utf8 Class Initialized
INFO - 2023-03-15 03:00:57 --> URI Class Initialized
INFO - 2023-03-15 03:00:57 --> Router Class Initialized
INFO - 2023-03-15 03:00:57 --> Output Class Initialized
INFO - 2023-03-15 03:00:57 --> Security Class Initialized
DEBUG - 2023-03-15 03:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:00:57 --> Input Class Initialized
INFO - 2023-03-15 03:00:57 --> Language Class Initialized
INFO - 2023-03-15 03:00:57 --> Loader Class Initialized
INFO - 2023-03-15 03:00:57 --> Controller Class Initialized
DEBUG - 2023-03-15 03:00:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:00:57 --> Database Driver Class Initialized
INFO - 2023-03-15 03:00:57 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:01:02 --> Config Class Initialized
INFO - 2023-03-15 03:01:02 --> Hooks Class Initialized
INFO - 2023-03-15 03:01:02 --> Config Class Initialized
INFO - 2023-03-15 03:01:02 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:01:02 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 03:01:02 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:01:02 --> Utf8 Class Initialized
INFO - 2023-03-15 03:01:02 --> Utf8 Class Initialized
INFO - 2023-03-15 03:01:02 --> URI Class Initialized
INFO - 2023-03-15 03:01:02 --> URI Class Initialized
INFO - 2023-03-15 03:01:02 --> Router Class Initialized
INFO - 2023-03-15 03:01:02 --> Router Class Initialized
INFO - 2023-03-15 03:01:02 --> Output Class Initialized
INFO - 2023-03-15 03:01:02 --> Output Class Initialized
INFO - 2023-03-15 03:01:02 --> Security Class Initialized
INFO - 2023-03-15 03:01:02 --> Security Class Initialized
DEBUG - 2023-03-15 03:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 03:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:01:02 --> Input Class Initialized
INFO - 2023-03-15 03:01:02 --> Input Class Initialized
INFO - 2023-03-15 03:01:02 --> Language Class Initialized
INFO - 2023-03-15 03:01:02 --> Language Class Initialized
INFO - 2023-03-15 03:01:02 --> Loader Class Initialized
INFO - 2023-03-15 03:01:02 --> Loader Class Initialized
INFO - 2023-03-15 03:01:02 --> Controller Class Initialized
INFO - 2023-03-15 03:01:02 --> Controller Class Initialized
DEBUG - 2023-03-15 03:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 03:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:01:02 --> Database Driver Class Initialized
INFO - 2023-03-15 03:01:02 --> Database Driver Class Initialized
INFO - 2023-03-15 03:01:02 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:01:02 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:01:02 --> Final output sent to browser
DEBUG - 2023-03-15 03:01:02 --> Total execution time: 0.0304
INFO - 2023-03-15 03:01:02 --> Config Class Initialized
INFO - 2023-03-15 03:01:02 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:01:02 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:01:02 --> Utf8 Class Initialized
INFO - 2023-03-15 03:01:02 --> URI Class Initialized
INFO - 2023-03-15 03:01:02 --> Router Class Initialized
INFO - 2023-03-15 03:01:02 --> Output Class Initialized
INFO - 2023-03-15 03:01:02 --> Security Class Initialized
DEBUG - 2023-03-15 03:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:01:02 --> Input Class Initialized
INFO - 2023-03-15 03:01:02 --> Language Class Initialized
INFO - 2023-03-15 03:01:02 --> Loader Class Initialized
INFO - 2023-03-15 03:01:02 --> Controller Class Initialized
DEBUG - 2023-03-15 03:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:01:02 --> Database Driver Class Initialized
INFO - 2023-03-15 03:01:02 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:01:02 --> Final output sent to browser
DEBUG - 2023-03-15 03:01:02 --> Total execution time: 0.0157
INFO - 2023-03-15 03:01:02 --> Config Class Initialized
INFO - 2023-03-15 03:01:02 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:01:02 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:01:02 --> Utf8 Class Initialized
INFO - 2023-03-15 03:01:02 --> URI Class Initialized
INFO - 2023-03-15 03:01:02 --> Router Class Initialized
INFO - 2023-03-15 03:01:02 --> Output Class Initialized
INFO - 2023-03-15 03:01:02 --> Security Class Initialized
DEBUG - 2023-03-15 03:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:01:02 --> Input Class Initialized
INFO - 2023-03-15 03:01:02 --> Language Class Initialized
INFO - 2023-03-15 03:01:02 --> Loader Class Initialized
INFO - 2023-03-15 03:01:02 --> Controller Class Initialized
DEBUG - 2023-03-15 03:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:01:02 --> Database Driver Class Initialized
INFO - 2023-03-15 03:01:02 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:01:16 --> Config Class Initialized
INFO - 2023-03-15 03:01:16 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:01:16 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:01:16 --> Utf8 Class Initialized
INFO - 2023-03-15 03:01:16 --> URI Class Initialized
INFO - 2023-03-15 03:01:16 --> Router Class Initialized
INFO - 2023-03-15 03:01:16 --> Output Class Initialized
INFO - 2023-03-15 03:01:16 --> Security Class Initialized
DEBUG - 2023-03-15 03:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:01:16 --> Input Class Initialized
INFO - 2023-03-15 03:01:16 --> Language Class Initialized
INFO - 2023-03-15 03:01:16 --> Loader Class Initialized
INFO - 2023-03-15 03:01:16 --> Controller Class Initialized
DEBUG - 2023-03-15 03:01:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:01:16 --> Database Driver Class Initialized
INFO - 2023-03-15 03:01:16 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:01:17 --> Config Class Initialized
INFO - 2023-03-15 03:01:17 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:01:17 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:01:17 --> Utf8 Class Initialized
INFO - 2023-03-15 03:01:17 --> URI Class Initialized
INFO - 2023-03-15 03:01:17 --> Router Class Initialized
INFO - 2023-03-15 03:01:17 --> Output Class Initialized
INFO - 2023-03-15 03:01:17 --> Security Class Initialized
DEBUG - 2023-03-15 03:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:01:17 --> Input Class Initialized
INFO - 2023-03-15 03:01:17 --> Language Class Initialized
INFO - 2023-03-15 03:01:17 --> Loader Class Initialized
INFO - 2023-03-15 03:01:17 --> Controller Class Initialized
DEBUG - 2023-03-15 03:01:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:01:17 --> Database Driver Class Initialized
INFO - 2023-03-15 03:01:17 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:01:19 --> Config Class Initialized
INFO - 2023-03-15 03:01:19 --> Hooks Class Initialized
INFO - 2023-03-15 03:01:19 --> Config Class Initialized
DEBUG - 2023-03-15 03:01:19 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:01:19 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:01:19 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:01:19 --> Utf8 Class Initialized
INFO - 2023-03-15 03:01:19 --> Utf8 Class Initialized
INFO - 2023-03-15 03:01:19 --> URI Class Initialized
INFO - 2023-03-15 03:01:19 --> URI Class Initialized
INFO - 2023-03-15 03:01:19 --> Router Class Initialized
INFO - 2023-03-15 03:01:19 --> Router Class Initialized
INFO - 2023-03-15 03:01:19 --> Output Class Initialized
INFO - 2023-03-15 03:01:19 --> Output Class Initialized
INFO - 2023-03-15 03:01:19 --> Security Class Initialized
DEBUG - 2023-03-15 03:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:01:19 --> Security Class Initialized
INFO - 2023-03-15 03:01:19 --> Input Class Initialized
DEBUG - 2023-03-15 03:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:01:19 --> Language Class Initialized
INFO - 2023-03-15 03:01:19 --> Input Class Initialized
INFO - 2023-03-15 03:01:19 --> Language Class Initialized
INFO - 2023-03-15 03:01:19 --> Loader Class Initialized
INFO - 2023-03-15 03:01:19 --> Loader Class Initialized
INFO - 2023-03-15 03:01:19 --> Controller Class Initialized
INFO - 2023-03-15 03:01:19 --> Controller Class Initialized
DEBUG - 2023-03-15 03:01:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 03:01:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:01:19 --> Database Driver Class Initialized
INFO - 2023-03-15 03:01:19 --> Database Driver Class Initialized
INFO - 2023-03-15 03:01:19 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:01:19 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:01:19 --> Final output sent to browser
DEBUG - 2023-03-15 03:01:19 --> Total execution time: 0.0267
INFO - 2023-03-15 03:01:19 --> Config Class Initialized
INFO - 2023-03-15 03:01:19 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:01:19 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:01:19 --> Utf8 Class Initialized
INFO - 2023-03-15 03:01:19 --> URI Class Initialized
INFO - 2023-03-15 03:01:19 --> Router Class Initialized
INFO - 2023-03-15 03:01:19 --> Output Class Initialized
INFO - 2023-03-15 03:01:19 --> Security Class Initialized
DEBUG - 2023-03-15 03:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:01:19 --> Input Class Initialized
INFO - 2023-03-15 03:01:19 --> Language Class Initialized
INFO - 2023-03-15 03:01:19 --> Loader Class Initialized
INFO - 2023-03-15 03:01:19 --> Controller Class Initialized
DEBUG - 2023-03-15 03:01:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:01:19 --> Database Driver Class Initialized
INFO - 2023-03-15 03:01:19 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:01:19 --> Final output sent to browser
DEBUG - 2023-03-15 03:01:19 --> Total execution time: 0.1434
INFO - 2023-03-15 03:01:21 --> Config Class Initialized
INFO - 2023-03-15 03:01:21 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:01:21 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:01:21 --> Utf8 Class Initialized
INFO - 2023-03-15 03:01:21 --> URI Class Initialized
INFO - 2023-03-15 03:01:21 --> Router Class Initialized
INFO - 2023-03-15 03:01:21 --> Output Class Initialized
INFO - 2023-03-15 03:01:21 --> Security Class Initialized
DEBUG - 2023-03-15 03:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:01:21 --> Input Class Initialized
INFO - 2023-03-15 03:01:21 --> Language Class Initialized
INFO - 2023-03-15 03:01:21 --> Loader Class Initialized
INFO - 2023-03-15 03:01:21 --> Controller Class Initialized
DEBUG - 2023-03-15 03:01:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:01:21 --> Database Driver Class Initialized
INFO - 2023-03-15 03:01:21 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:53:15 --> Config Class Initialized
INFO - 2023-03-15 03:53:15 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:53:15 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:53:15 --> Utf8 Class Initialized
INFO - 2023-03-15 03:53:15 --> URI Class Initialized
INFO - 2023-03-15 03:53:15 --> Router Class Initialized
INFO - 2023-03-15 03:53:15 --> Output Class Initialized
INFO - 2023-03-15 03:53:15 --> Security Class Initialized
DEBUG - 2023-03-15 03:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:53:15 --> Input Class Initialized
INFO - 2023-03-15 03:53:15 --> Language Class Initialized
INFO - 2023-03-15 03:53:15 --> Loader Class Initialized
INFO - 2023-03-15 03:53:15 --> Controller Class Initialized
DEBUG - 2023-03-15 03:53:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:53:15 --> Database Driver Class Initialized
INFO - 2023-03-15 03:53:15 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:53:15 --> Final output sent to browser
DEBUG - 2023-03-15 03:53:15 --> Total execution time: 0.0315
INFO - 2023-03-15 03:53:15 --> Config Class Initialized
INFO - 2023-03-15 03:53:15 --> Hooks Class Initialized
DEBUG - 2023-03-15 03:53:15 --> UTF-8 Support Enabled
INFO - 2023-03-15 03:53:15 --> Utf8 Class Initialized
INFO - 2023-03-15 03:53:15 --> URI Class Initialized
INFO - 2023-03-15 03:53:15 --> Router Class Initialized
INFO - 2023-03-15 03:53:15 --> Output Class Initialized
INFO - 2023-03-15 03:53:15 --> Security Class Initialized
DEBUG - 2023-03-15 03:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 03:53:15 --> Input Class Initialized
INFO - 2023-03-15 03:53:15 --> Language Class Initialized
INFO - 2023-03-15 03:53:15 --> Loader Class Initialized
INFO - 2023-03-15 03:53:15 --> Controller Class Initialized
DEBUG - 2023-03-15 03:53:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 03:53:15 --> Database Driver Class Initialized
INFO - 2023-03-15 03:53:15 --> Model "Cluster_model" initialized
INFO - 2023-03-15 03:53:15 --> Final output sent to browser
DEBUG - 2023-03-15 03:53:15 --> Total execution time: 0.0604
INFO - 2023-03-15 05:45:47 --> Config Class Initialized
INFO - 2023-03-15 05:45:47 --> Hooks Class Initialized
DEBUG - 2023-03-15 05:45:47 --> UTF-8 Support Enabled
INFO - 2023-03-15 05:45:47 --> Utf8 Class Initialized
INFO - 2023-03-15 05:45:47 --> URI Class Initialized
INFO - 2023-03-15 05:45:47 --> Router Class Initialized
INFO - 2023-03-15 05:45:47 --> Output Class Initialized
INFO - 2023-03-15 05:45:47 --> Security Class Initialized
DEBUG - 2023-03-15 05:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 05:45:47 --> Input Class Initialized
INFO - 2023-03-15 05:45:47 --> Language Class Initialized
INFO - 2023-03-15 05:45:47 --> Loader Class Initialized
INFO - 2023-03-15 05:45:47 --> Controller Class Initialized
DEBUG - 2023-03-15 05:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 05:45:47 --> Database Driver Class Initialized
INFO - 2023-03-15 05:45:47 --> Model "Cluster_model" initialized
INFO - 2023-03-15 05:49:13 --> Config Class Initialized
INFO - 2023-03-15 05:49:13 --> Hooks Class Initialized
DEBUG - 2023-03-15 05:49:13 --> UTF-8 Support Enabled
INFO - 2023-03-15 05:49:13 --> Utf8 Class Initialized
INFO - 2023-03-15 05:49:13 --> URI Class Initialized
INFO - 2023-03-15 05:49:13 --> Router Class Initialized
INFO - 2023-03-15 05:49:13 --> Output Class Initialized
INFO - 2023-03-15 05:49:13 --> Security Class Initialized
DEBUG - 2023-03-15 05:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 05:49:13 --> Input Class Initialized
INFO - 2023-03-15 05:49:13 --> Language Class Initialized
ERROR - 2023-03-15 05:49:13 --> Severity: error --> Exception: syntax error, unexpected '$res' (T_VARIABLE) /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php 69
INFO - 2023-03-15 05:49:51 --> Config Class Initialized
INFO - 2023-03-15 05:49:51 --> Hooks Class Initialized
DEBUG - 2023-03-15 05:49:51 --> UTF-8 Support Enabled
INFO - 2023-03-15 05:49:51 --> Utf8 Class Initialized
INFO - 2023-03-15 05:49:51 --> URI Class Initialized
INFO - 2023-03-15 05:49:51 --> Router Class Initialized
INFO - 2023-03-15 05:49:51 --> Output Class Initialized
INFO - 2023-03-15 05:49:51 --> Security Class Initialized
DEBUG - 2023-03-15 05:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 05:49:51 --> Input Class Initialized
INFO - 2023-03-15 05:49:51 --> Language Class Initialized
ERROR - 2023-03-15 05:49:51 --> Severity: error --> Exception: syntax error, unexpected '$res' (T_VARIABLE) /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php 69
INFO - 2023-03-15 05:50:33 --> Config Class Initialized
INFO - 2023-03-15 05:50:33 --> Hooks Class Initialized
DEBUG - 2023-03-15 05:50:33 --> UTF-8 Support Enabled
INFO - 2023-03-15 05:50:33 --> Utf8 Class Initialized
INFO - 2023-03-15 05:50:33 --> URI Class Initialized
INFO - 2023-03-15 05:50:33 --> Router Class Initialized
INFO - 2023-03-15 05:50:33 --> Output Class Initialized
INFO - 2023-03-15 05:50:33 --> Security Class Initialized
DEBUG - 2023-03-15 05:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 05:50:33 --> Input Class Initialized
INFO - 2023-03-15 05:50:33 --> Language Class Initialized
ERROR - 2023-03-15 05:50:33 --> Severity: error --> Exception: syntax error, unexpected '$s' (T_VARIABLE) /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php 69
INFO - 2023-03-15 05:52:30 --> Config Class Initialized
INFO - 2023-03-15 05:52:31 --> Hooks Class Initialized
DEBUG - 2023-03-15 05:52:31 --> UTF-8 Support Enabled
INFO - 2023-03-15 05:52:31 --> Utf8 Class Initialized
INFO - 2023-03-15 05:52:31 --> URI Class Initialized
INFO - 2023-03-15 05:52:31 --> Router Class Initialized
INFO - 2023-03-15 05:52:31 --> Output Class Initialized
INFO - 2023-03-15 05:52:31 --> Security Class Initialized
DEBUG - 2023-03-15 05:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 05:52:31 --> Input Class Initialized
INFO - 2023-03-15 05:52:31 --> Language Class Initialized
INFO - 2023-03-15 05:52:31 --> Loader Class Initialized
INFO - 2023-03-15 05:52:31 --> Controller Class Initialized
DEBUG - 2023-03-15 05:52:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 05:52:31 --> Database Driver Class Initialized
INFO - 2023-03-15 05:52:31 --> Model "Cluster_model" initialized
INFO - 2023-03-15 05:56:53 --> Config Class Initialized
INFO - 2023-03-15 05:56:53 --> Hooks Class Initialized
DEBUG - 2023-03-15 05:56:53 --> UTF-8 Support Enabled
INFO - 2023-03-15 05:56:53 --> Utf8 Class Initialized
INFO - 2023-03-15 05:56:53 --> URI Class Initialized
INFO - 2023-03-15 05:56:53 --> Router Class Initialized
INFO - 2023-03-15 05:56:53 --> Output Class Initialized
INFO - 2023-03-15 05:56:53 --> Security Class Initialized
DEBUG - 2023-03-15 05:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 05:56:53 --> Input Class Initialized
INFO - 2023-03-15 05:56:53 --> Language Class Initialized
INFO - 2023-03-15 05:56:53 --> Loader Class Initialized
INFO - 2023-03-15 05:56:53 --> Controller Class Initialized
DEBUG - 2023-03-15 05:56:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 05:56:53 --> Database Driver Class Initialized
INFO - 2023-03-15 05:56:53 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:13:52 --> Config Class Initialized
INFO - 2023-03-15 06:13:52 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:13:52 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:13:52 --> Utf8 Class Initialized
INFO - 2023-03-15 06:13:52 --> URI Class Initialized
INFO - 2023-03-15 06:13:52 --> Router Class Initialized
INFO - 2023-03-15 06:13:52 --> Output Class Initialized
INFO - 2023-03-15 06:13:52 --> Security Class Initialized
DEBUG - 2023-03-15 06:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:13:52 --> Input Class Initialized
INFO - 2023-03-15 06:13:52 --> Language Class Initialized
INFO - 2023-03-15 06:13:52 --> Loader Class Initialized
INFO - 2023-03-15 06:13:52 --> Controller Class Initialized
DEBUG - 2023-03-15 06:13:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:13:52 --> Database Driver Class Initialized
INFO - 2023-03-15 06:13:52 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:14:33 --> Config Class Initialized
INFO - 2023-03-15 06:14:33 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:14:33 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:14:33 --> Utf8 Class Initialized
INFO - 2023-03-15 06:14:33 --> URI Class Initialized
INFO - 2023-03-15 06:14:33 --> Router Class Initialized
INFO - 2023-03-15 06:14:33 --> Output Class Initialized
INFO - 2023-03-15 06:14:33 --> Security Class Initialized
DEBUG - 2023-03-15 06:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:14:33 --> Input Class Initialized
INFO - 2023-03-15 06:14:33 --> Language Class Initialized
INFO - 2023-03-15 06:14:33 --> Loader Class Initialized
INFO - 2023-03-15 06:14:33 --> Controller Class Initialized
DEBUG - 2023-03-15 06:14:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:19:18 --> Config Class Initialized
INFO - 2023-03-15 06:19:18 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:19:18 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:19:18 --> Utf8 Class Initialized
INFO - 2023-03-15 06:19:18 --> URI Class Initialized
INFO - 2023-03-15 06:19:18 --> Router Class Initialized
INFO - 2023-03-15 06:19:18 --> Output Class Initialized
INFO - 2023-03-15 06:19:18 --> Security Class Initialized
DEBUG - 2023-03-15 06:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:19:18 --> Input Class Initialized
INFO - 2023-03-15 06:19:18 --> Language Class Initialized
INFO - 2023-03-15 06:19:18 --> Loader Class Initialized
INFO - 2023-03-15 06:19:18 --> Controller Class Initialized
DEBUG - 2023-03-15 06:19:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:19:18 --> Database Driver Class Initialized
INFO - 2023-03-15 06:19:18 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:21:20 --> Config Class Initialized
INFO - 2023-03-15 06:21:20 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:20 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:20 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:20 --> URI Class Initialized
INFO - 2023-03-15 06:21:20 --> Router Class Initialized
INFO - 2023-03-15 06:21:20 --> Output Class Initialized
INFO - 2023-03-15 06:21:20 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:20 --> Input Class Initialized
INFO - 2023-03-15 06:21:20 --> Language Class Initialized
INFO - 2023-03-15 06:21:20 --> Loader Class Initialized
INFO - 2023-03-15 06:21:20 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:20 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:20 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:21:20 --> Config Class Initialized
INFO - 2023-03-15 06:21:20 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:20 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:20 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:20 --> URI Class Initialized
INFO - 2023-03-15 06:21:20 --> Router Class Initialized
INFO - 2023-03-15 06:21:20 --> Output Class Initialized
INFO - 2023-03-15 06:21:20 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:20 --> Input Class Initialized
INFO - 2023-03-15 06:21:20 --> Language Class Initialized
INFO - 2023-03-15 06:21:20 --> Loader Class Initialized
INFO - 2023-03-15 06:21:20 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:20 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:20 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:21:20 --> Config Class Initialized
INFO - 2023-03-15 06:21:20 --> Config Class Initialized
INFO - 2023-03-15 06:21:20 --> Hooks Class Initialized
INFO - 2023-03-15 06:21:20 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:20 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 06:21:20 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:20 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:20 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:20 --> URI Class Initialized
INFO - 2023-03-15 06:21:20 --> URI Class Initialized
INFO - 2023-03-15 06:21:20 --> Router Class Initialized
INFO - 2023-03-15 06:21:20 --> Router Class Initialized
INFO - 2023-03-15 06:21:20 --> Output Class Initialized
INFO - 2023-03-15 06:21:20 --> Output Class Initialized
INFO - 2023-03-15 06:21:20 --> Security Class Initialized
INFO - 2023-03-15 06:21:20 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 06:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:20 --> Input Class Initialized
INFO - 2023-03-15 06:21:20 --> Input Class Initialized
INFO - 2023-03-15 06:21:20 --> Language Class Initialized
INFO - 2023-03-15 06:21:20 --> Language Class Initialized
INFO - 2023-03-15 06:21:20 --> Loader Class Initialized
INFO - 2023-03-15 06:21:20 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:20 --> Loader Class Initialized
INFO - 2023-03-15 06:21:20 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:20 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:20 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:20 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:21:20 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:21:20 --> Final output sent to browser
DEBUG - 2023-03-15 06:21:20 --> Total execution time: 0.0157
INFO - 2023-03-15 06:21:20 --> Config Class Initialized
INFO - 2023-03-15 06:21:20 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:20 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:20 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:20 --> URI Class Initialized
INFO - 2023-03-15 06:21:20 --> Router Class Initialized
INFO - 2023-03-15 06:21:20 --> Output Class Initialized
INFO - 2023-03-15 06:21:20 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:20 --> Input Class Initialized
INFO - 2023-03-15 06:21:20 --> Language Class Initialized
INFO - 2023-03-15 06:21:20 --> Loader Class Initialized
INFO - 2023-03-15 06:21:20 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:20 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:20 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:21:20 --> Final output sent to browser
DEBUG - 2023-03-15 06:21:20 --> Total execution time: 0.0518
INFO - 2023-03-15 06:21:20 --> Config Class Initialized
INFO - 2023-03-15 06:21:20 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:20 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:20 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:20 --> URI Class Initialized
INFO - 2023-03-15 06:21:20 --> Router Class Initialized
INFO - 2023-03-15 06:21:20 --> Output Class Initialized
INFO - 2023-03-15 06:21:20 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:20 --> Input Class Initialized
INFO - 2023-03-15 06:21:20 --> Language Class Initialized
INFO - 2023-03-15 06:21:20 --> Loader Class Initialized
INFO - 2023-03-15 06:21:20 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:20 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:20 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:21:21 --> Config Class Initialized
INFO - 2023-03-15 06:21:21 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:21 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:21 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:21 --> URI Class Initialized
INFO - 2023-03-15 06:21:21 --> Router Class Initialized
INFO - 2023-03-15 06:21:21 --> Output Class Initialized
INFO - 2023-03-15 06:21:21 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:21 --> Input Class Initialized
INFO - 2023-03-15 06:21:21 --> Language Class Initialized
INFO - 2023-03-15 06:21:21 --> Loader Class Initialized
INFO - 2023-03-15 06:21:21 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:21 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:21 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:21 --> Model "Login_model" initialized
INFO - 2023-03-15 06:21:21 --> Final output sent to browser
DEBUG - 2023-03-15 06:21:21 --> Total execution time: 0.0243
INFO - 2023-03-15 06:21:21 --> Config Class Initialized
INFO - 2023-03-15 06:21:21 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:21 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:21 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:21 --> URI Class Initialized
INFO - 2023-03-15 06:21:21 --> Router Class Initialized
INFO - 2023-03-15 06:21:21 --> Output Class Initialized
INFO - 2023-03-15 06:21:21 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:21 --> Input Class Initialized
INFO - 2023-03-15 06:21:21 --> Language Class Initialized
INFO - 2023-03-15 06:21:21 --> Loader Class Initialized
INFO - 2023-03-15 06:21:21 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:21 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:21 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:21 --> Model "Login_model" initialized
INFO - 2023-03-15 06:21:21 --> Final output sent to browser
DEBUG - 2023-03-15 06:21:21 --> Total execution time: 0.0643
INFO - 2023-03-15 06:21:21 --> Config Class Initialized
INFO - 2023-03-15 06:21:21 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:21 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:21 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:21 --> URI Class Initialized
INFO - 2023-03-15 06:21:21 --> Router Class Initialized
INFO - 2023-03-15 06:21:21 --> Output Class Initialized
INFO - 2023-03-15 06:21:21 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:21 --> Input Class Initialized
INFO - 2023-03-15 06:21:21 --> Language Class Initialized
INFO - 2023-03-15 06:21:21 --> Loader Class Initialized
INFO - 2023-03-15 06:21:21 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:21 --> Final output sent to browser
DEBUG - 2023-03-15 06:21:21 --> Total execution time: 0.0464
INFO - 2023-03-15 06:21:21 --> Config Class Initialized
INFO - 2023-03-15 06:21:21 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:21 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:21 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:21 --> URI Class Initialized
INFO - 2023-03-15 06:21:21 --> Router Class Initialized
INFO - 2023-03-15 06:21:21 --> Output Class Initialized
INFO - 2023-03-15 06:21:21 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:21 --> Input Class Initialized
INFO - 2023-03-15 06:21:21 --> Language Class Initialized
INFO - 2023-03-15 06:21:21 --> Loader Class Initialized
INFO - 2023-03-15 06:21:21 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:21 --> Final output sent to browser
DEBUG - 2023-03-15 06:21:21 --> Total execution time: 0.0598
INFO - 2023-03-15 06:21:23 --> Config Class Initialized
INFO - 2023-03-15 06:21:23 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:23 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:23 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:23 --> URI Class Initialized
INFO - 2023-03-15 06:21:23 --> Router Class Initialized
INFO - 2023-03-15 06:21:23 --> Output Class Initialized
INFO - 2023-03-15 06:21:23 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:23 --> Input Class Initialized
INFO - 2023-03-15 06:21:23 --> Language Class Initialized
INFO - 2023-03-15 06:21:23 --> Loader Class Initialized
INFO - 2023-03-15 06:21:23 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:23 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:23 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:23 --> Model "Login_model" initialized
INFO - 2023-03-15 06:21:23 --> Final output sent to browser
DEBUG - 2023-03-15 06:21:23 --> Total execution time: 0.0276
INFO - 2023-03-15 06:21:23 --> Config Class Initialized
INFO - 2023-03-15 06:21:23 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:23 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:23 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:23 --> URI Class Initialized
INFO - 2023-03-15 06:21:23 --> Router Class Initialized
INFO - 2023-03-15 06:21:23 --> Output Class Initialized
INFO - 2023-03-15 06:21:23 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:23 --> Input Class Initialized
INFO - 2023-03-15 06:21:23 --> Language Class Initialized
INFO - 2023-03-15 06:21:23 --> Loader Class Initialized
INFO - 2023-03-15 06:21:23 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:23 --> Final output sent to browser
DEBUG - 2023-03-15 06:21:23 --> Total execution time: 0.1376
INFO - 2023-03-15 06:21:24 --> Config Class Initialized
INFO - 2023-03-15 06:21:24 --> Config Class Initialized
INFO - 2023-03-15 06:21:24 --> Hooks Class Initialized
INFO - 2023-03-15 06:21:24 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:24 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 06:21:24 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:24 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:24 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:24 --> URI Class Initialized
INFO - 2023-03-15 06:21:24 --> URI Class Initialized
INFO - 2023-03-15 06:21:24 --> Router Class Initialized
INFO - 2023-03-15 06:21:24 --> Router Class Initialized
INFO - 2023-03-15 06:21:24 --> Output Class Initialized
INFO - 2023-03-15 06:21:24 --> Output Class Initialized
INFO - 2023-03-15 06:21:24 --> Security Class Initialized
INFO - 2023-03-15 06:21:24 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 06:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:24 --> Input Class Initialized
INFO - 2023-03-15 06:21:24 --> Input Class Initialized
INFO - 2023-03-15 06:21:24 --> Language Class Initialized
INFO - 2023-03-15 06:21:24 --> Language Class Initialized
INFO - 2023-03-15 06:21:24 --> Loader Class Initialized
INFO - 2023-03-15 06:21:24 --> Loader Class Initialized
INFO - 2023-03-15 06:21:24 --> Controller Class Initialized
INFO - 2023-03-15 06:21:24 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 06:21:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:24 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:24 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:24 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:21:24 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:21:24 --> Final output sent to browser
DEBUG - 2023-03-15 06:21:24 --> Total execution time: 0.0149
INFO - 2023-03-15 06:21:26 --> Config Class Initialized
INFO - 2023-03-15 06:21:26 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:26 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:26 --> URI Class Initialized
INFO - 2023-03-15 06:21:26 --> Router Class Initialized
INFO - 2023-03-15 06:21:26 --> Output Class Initialized
INFO - 2023-03-15 06:21:26 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:26 --> Input Class Initialized
INFO - 2023-03-15 06:21:26 --> Language Class Initialized
INFO - 2023-03-15 06:21:26 --> Loader Class Initialized
INFO - 2023-03-15 06:21:26 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:26 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:26 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:21:27 --> Config Class Initialized
INFO - 2023-03-15 06:21:27 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:21:27 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:21:27 --> Utf8 Class Initialized
INFO - 2023-03-15 06:21:27 --> URI Class Initialized
INFO - 2023-03-15 06:21:27 --> Router Class Initialized
INFO - 2023-03-15 06:21:27 --> Output Class Initialized
INFO - 2023-03-15 06:21:27 --> Security Class Initialized
DEBUG - 2023-03-15 06:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:21:27 --> Input Class Initialized
INFO - 2023-03-15 06:21:27 --> Language Class Initialized
INFO - 2023-03-15 06:21:27 --> Loader Class Initialized
INFO - 2023-03-15 06:21:27 --> Controller Class Initialized
DEBUG - 2023-03-15 06:21:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:21:27 --> Database Driver Class Initialized
INFO - 2023-03-15 06:21:27 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:25 --> Config Class Initialized
INFO - 2023-03-15 06:25:25 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:25 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:25 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:25 --> URI Class Initialized
INFO - 2023-03-15 06:25:25 --> Router Class Initialized
INFO - 2023-03-15 06:25:25 --> Output Class Initialized
INFO - 2023-03-15 06:25:25 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:25 --> Input Class Initialized
INFO - 2023-03-15 06:25:25 --> Language Class Initialized
INFO - 2023-03-15 06:25:25 --> Loader Class Initialized
INFO - 2023-03-15 06:25:25 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:25 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:25 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:26 --> Config Class Initialized
INFO - 2023-03-15 06:25:26 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:26 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:26 --> URI Class Initialized
INFO - 2023-03-15 06:25:26 --> Router Class Initialized
INFO - 2023-03-15 06:25:26 --> Output Class Initialized
INFO - 2023-03-15 06:25:26 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:26 --> Input Class Initialized
INFO - 2023-03-15 06:25:26 --> Language Class Initialized
INFO - 2023-03-15 06:25:26 --> Loader Class Initialized
INFO - 2023-03-15 06:25:26 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:26 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:26 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:39 --> Config Class Initialized
INFO - 2023-03-15 06:25:39 --> Config Class Initialized
INFO - 2023-03-15 06:25:39 --> Hooks Class Initialized
INFO - 2023-03-15 06:25:39 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:39 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:39 --> Utf8 Class Initialized
DEBUG - 2023-03-15 06:25:39 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:39 --> URI Class Initialized
INFO - 2023-03-15 06:25:39 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:39 --> URI Class Initialized
INFO - 2023-03-15 06:25:39 --> Router Class Initialized
INFO - 2023-03-15 06:25:39 --> Router Class Initialized
INFO - 2023-03-15 06:25:39 --> Output Class Initialized
INFO - 2023-03-15 06:25:39 --> Output Class Initialized
INFO - 2023-03-15 06:25:39 --> Security Class Initialized
INFO - 2023-03-15 06:25:39 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 06:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:39 --> Input Class Initialized
INFO - 2023-03-15 06:25:39 --> Input Class Initialized
INFO - 2023-03-15 06:25:39 --> Language Class Initialized
INFO - 2023-03-15 06:25:39 --> Language Class Initialized
INFO - 2023-03-15 06:25:39 --> Loader Class Initialized
INFO - 2023-03-15 06:25:39 --> Loader Class Initialized
INFO - 2023-03-15 06:25:39 --> Controller Class Initialized
INFO - 2023-03-15 06:25:39 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 06:25:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:39 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:39 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:39 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:39 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:39 --> Final output sent to browser
DEBUG - 2023-03-15 06:25:39 --> Total execution time: 0.0145
INFO - 2023-03-15 06:25:39 --> Config Class Initialized
INFO - 2023-03-15 06:25:39 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:39 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:39 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:39 --> URI Class Initialized
INFO - 2023-03-15 06:25:39 --> Router Class Initialized
INFO - 2023-03-15 06:25:39 --> Output Class Initialized
INFO - 2023-03-15 06:25:39 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:39 --> Input Class Initialized
INFO - 2023-03-15 06:25:39 --> Language Class Initialized
INFO - 2023-03-15 06:25:39 --> Loader Class Initialized
INFO - 2023-03-15 06:25:39 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:39 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:39 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:39 --> Final output sent to browser
DEBUG - 2023-03-15 06:25:39 --> Total execution time: 0.0133
INFO - 2023-03-15 06:25:40 --> Config Class Initialized
INFO - 2023-03-15 06:25:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:40 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:40 --> URI Class Initialized
INFO - 2023-03-15 06:25:40 --> Router Class Initialized
INFO - 2023-03-15 06:25:40 --> Output Class Initialized
INFO - 2023-03-15 06:25:40 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:40 --> Input Class Initialized
INFO - 2023-03-15 06:25:40 --> Language Class Initialized
INFO - 2023-03-15 06:25:40 --> Loader Class Initialized
INFO - 2023-03-15 06:25:40 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:40 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:40 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:41 --> Config Class Initialized
INFO - 2023-03-15 06:25:41 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:41 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:41 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:41 --> URI Class Initialized
INFO - 2023-03-15 06:25:41 --> Router Class Initialized
INFO - 2023-03-15 06:25:41 --> Output Class Initialized
INFO - 2023-03-15 06:25:41 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:41 --> Input Class Initialized
INFO - 2023-03-15 06:25:41 --> Language Class Initialized
INFO - 2023-03-15 06:25:41 --> Loader Class Initialized
INFO - 2023-03-15 06:25:41 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:41 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:41 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:41 --> Config Class Initialized
INFO - 2023-03-15 06:25:41 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:41 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:41 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:41 --> URI Class Initialized
INFO - 2023-03-15 06:25:41 --> Router Class Initialized
INFO - 2023-03-15 06:25:41 --> Output Class Initialized
INFO - 2023-03-15 06:25:41 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:41 --> Input Class Initialized
INFO - 2023-03-15 06:25:41 --> Language Class Initialized
INFO - 2023-03-15 06:25:41 --> Loader Class Initialized
INFO - 2023-03-15 06:25:41 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:41 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:41 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:41 --> Config Class Initialized
INFO - 2023-03-15 06:25:41 --> Config Class Initialized
INFO - 2023-03-15 06:25:41 --> Hooks Class Initialized
INFO - 2023-03-15 06:25:41 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:41 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 06:25:41 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:41 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:41 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:41 --> URI Class Initialized
INFO - 2023-03-15 06:25:41 --> URI Class Initialized
INFO - 2023-03-15 06:25:41 --> Router Class Initialized
INFO - 2023-03-15 06:25:41 --> Router Class Initialized
INFO - 2023-03-15 06:25:41 --> Output Class Initialized
INFO - 2023-03-15 06:25:41 --> Output Class Initialized
INFO - 2023-03-15 06:25:41 --> Security Class Initialized
INFO - 2023-03-15 06:25:41 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 06:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:41 --> Input Class Initialized
INFO - 2023-03-15 06:25:41 --> Input Class Initialized
INFO - 2023-03-15 06:25:41 --> Language Class Initialized
INFO - 2023-03-15 06:25:41 --> Language Class Initialized
INFO - 2023-03-15 06:25:41 --> Loader Class Initialized
INFO - 2023-03-15 06:25:41 --> Loader Class Initialized
INFO - 2023-03-15 06:25:41 --> Controller Class Initialized
INFO - 2023-03-15 06:25:41 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 06:25:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:41 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:41 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:41 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:41 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:41 --> Final output sent to browser
DEBUG - 2023-03-15 06:25:41 --> Total execution time: 0.0147
INFO - 2023-03-15 06:25:51 --> Config Class Initialized
INFO - 2023-03-15 06:25:51 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:51 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:51 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:51 --> URI Class Initialized
INFO - 2023-03-15 06:25:51 --> Router Class Initialized
INFO - 2023-03-15 06:25:51 --> Output Class Initialized
INFO - 2023-03-15 06:25:51 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:51 --> Input Class Initialized
INFO - 2023-03-15 06:25:51 --> Language Class Initialized
INFO - 2023-03-15 06:25:51 --> Loader Class Initialized
INFO - 2023-03-15 06:25:51 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:51 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:51 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:51 --> Config Class Initialized
INFO - 2023-03-15 06:25:51 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:51 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:51 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:51 --> URI Class Initialized
INFO - 2023-03-15 06:25:51 --> Router Class Initialized
INFO - 2023-03-15 06:25:51 --> Output Class Initialized
INFO - 2023-03-15 06:25:51 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:51 --> Input Class Initialized
INFO - 2023-03-15 06:25:51 --> Language Class Initialized
INFO - 2023-03-15 06:25:51 --> Loader Class Initialized
INFO - 2023-03-15 06:25:51 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:51 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:51 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:52 --> Config Class Initialized
INFO - 2023-03-15 06:25:52 --> Config Class Initialized
INFO - 2023-03-15 06:25:52 --> Hooks Class Initialized
INFO - 2023-03-15 06:25:52 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:52 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 06:25:52 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:52 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:52 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:52 --> URI Class Initialized
INFO - 2023-03-15 06:25:52 --> URI Class Initialized
INFO - 2023-03-15 06:25:52 --> Router Class Initialized
INFO - 2023-03-15 06:25:52 --> Router Class Initialized
INFO - 2023-03-15 06:25:52 --> Output Class Initialized
INFO - 2023-03-15 06:25:52 --> Output Class Initialized
INFO - 2023-03-15 06:25:52 --> Security Class Initialized
INFO - 2023-03-15 06:25:52 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 06:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:52 --> Input Class Initialized
INFO - 2023-03-15 06:25:52 --> Input Class Initialized
INFO - 2023-03-15 06:25:52 --> Language Class Initialized
INFO - 2023-03-15 06:25:52 --> Language Class Initialized
INFO - 2023-03-15 06:25:52 --> Loader Class Initialized
INFO - 2023-03-15 06:25:52 --> Controller Class Initialized
INFO - 2023-03-15 06:25:52 --> Loader Class Initialized
DEBUG - 2023-03-15 06:25:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:52 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:52 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:52 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:52 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:52 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:52 --> Final output sent to browser
DEBUG - 2023-03-15 06:25:52 --> Total execution time: 0.0159
INFO - 2023-03-15 06:25:52 --> Config Class Initialized
INFO - 2023-03-15 06:25:52 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:52 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:52 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:52 --> URI Class Initialized
INFO - 2023-03-15 06:25:52 --> Router Class Initialized
INFO - 2023-03-15 06:25:52 --> Output Class Initialized
INFO - 2023-03-15 06:25:52 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:52 --> Input Class Initialized
INFO - 2023-03-15 06:25:52 --> Language Class Initialized
INFO - 2023-03-15 06:25:52 --> Loader Class Initialized
INFO - 2023-03-15 06:25:52 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:52 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:52 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:52 --> Final output sent to browser
DEBUG - 2023-03-15 06:25:52 --> Total execution time: 0.0109
INFO - 2023-03-15 06:25:52 --> Config Class Initialized
INFO - 2023-03-15 06:25:52 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:52 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:52 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:52 --> URI Class Initialized
INFO - 2023-03-15 06:25:52 --> Router Class Initialized
INFO - 2023-03-15 06:25:52 --> Output Class Initialized
INFO - 2023-03-15 06:25:52 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:52 --> Input Class Initialized
INFO - 2023-03-15 06:25:52 --> Language Class Initialized
INFO - 2023-03-15 06:25:52 --> Loader Class Initialized
INFO - 2023-03-15 06:25:52 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:52 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:52 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:53 --> Config Class Initialized
INFO - 2023-03-15 06:25:53 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:53 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:53 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:53 --> URI Class Initialized
INFO - 2023-03-15 06:25:53 --> Router Class Initialized
INFO - 2023-03-15 06:25:53 --> Output Class Initialized
INFO - 2023-03-15 06:25:53 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:53 --> Input Class Initialized
INFO - 2023-03-15 06:25:53 --> Language Class Initialized
INFO - 2023-03-15 06:25:53 --> Loader Class Initialized
INFO - 2023-03-15 06:25:53 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:53 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:53 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:53 --> Model "Login_model" initialized
INFO - 2023-03-15 06:25:53 --> Final output sent to browser
DEBUG - 2023-03-15 06:25:53 --> Total execution time: 0.0226
INFO - 2023-03-15 06:25:53 --> Config Class Initialized
INFO - 2023-03-15 06:25:53 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:53 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:53 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:53 --> URI Class Initialized
INFO - 2023-03-15 06:25:53 --> Router Class Initialized
INFO - 2023-03-15 06:25:53 --> Output Class Initialized
INFO - 2023-03-15 06:25:53 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:53 --> Input Class Initialized
INFO - 2023-03-15 06:25:53 --> Language Class Initialized
INFO - 2023-03-15 06:25:53 --> Loader Class Initialized
INFO - 2023-03-15 06:25:53 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:53 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:53 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:53 --> Model "Login_model" initialized
INFO - 2023-03-15 06:25:53 --> Final output sent to browser
DEBUG - 2023-03-15 06:25:53 --> Total execution time: 0.0197
INFO - 2023-03-15 06:25:53 --> Config Class Initialized
INFO - 2023-03-15 06:25:53 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:53 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:53 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:53 --> URI Class Initialized
INFO - 2023-03-15 06:25:53 --> Router Class Initialized
INFO - 2023-03-15 06:25:53 --> Output Class Initialized
INFO - 2023-03-15 06:25:53 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:53 --> Input Class Initialized
INFO - 2023-03-15 06:25:53 --> Language Class Initialized
INFO - 2023-03-15 06:25:53 --> Loader Class Initialized
INFO - 2023-03-15 06:25:53 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:53 --> Final output sent to browser
DEBUG - 2023-03-15 06:25:53 --> Total execution time: 0.0439
INFO - 2023-03-15 06:25:53 --> Config Class Initialized
INFO - 2023-03-15 06:25:53 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:53 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:53 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:53 --> URI Class Initialized
INFO - 2023-03-15 06:25:53 --> Router Class Initialized
INFO - 2023-03-15 06:25:53 --> Output Class Initialized
INFO - 2023-03-15 06:25:53 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:53 --> Input Class Initialized
INFO - 2023-03-15 06:25:53 --> Language Class Initialized
INFO - 2023-03-15 06:25:53 --> Loader Class Initialized
INFO - 2023-03-15 06:25:53 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:53 --> Final output sent to browser
DEBUG - 2023-03-15 06:25:53 --> Total execution time: 0.0469
INFO - 2023-03-15 06:25:55 --> Config Class Initialized
INFO - 2023-03-15 06:25:55 --> Config Class Initialized
INFO - 2023-03-15 06:25:55 --> Hooks Class Initialized
INFO - 2023-03-15 06:25:55 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:55 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 06:25:55 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:55 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:55 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:55 --> URI Class Initialized
INFO - 2023-03-15 06:25:55 --> URI Class Initialized
INFO - 2023-03-15 06:25:55 --> Router Class Initialized
INFO - 2023-03-15 06:25:55 --> Router Class Initialized
INFO - 2023-03-15 06:25:55 --> Output Class Initialized
INFO - 2023-03-15 06:25:55 --> Output Class Initialized
INFO - 2023-03-15 06:25:55 --> Security Class Initialized
INFO - 2023-03-15 06:25:55 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 06:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:55 --> Input Class Initialized
INFO - 2023-03-15 06:25:55 --> Input Class Initialized
INFO - 2023-03-15 06:25:55 --> Language Class Initialized
INFO - 2023-03-15 06:25:55 --> Language Class Initialized
INFO - 2023-03-15 06:25:55 --> Loader Class Initialized
INFO - 2023-03-15 06:25:55 --> Loader Class Initialized
INFO - 2023-03-15 06:25:55 --> Controller Class Initialized
INFO - 2023-03-15 06:25:55 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 06:25:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:55 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:55 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:55 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:55 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:25:55 --> Final output sent to browser
DEBUG - 2023-03-15 06:25:55 --> Total execution time: 0.0191
INFO - 2023-03-15 06:25:55 --> Config Class Initialized
INFO - 2023-03-15 06:25:55 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:25:55 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:25:55 --> Utf8 Class Initialized
INFO - 2023-03-15 06:25:55 --> URI Class Initialized
INFO - 2023-03-15 06:25:55 --> Router Class Initialized
INFO - 2023-03-15 06:25:55 --> Output Class Initialized
INFO - 2023-03-15 06:25:55 --> Security Class Initialized
DEBUG - 2023-03-15 06:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:25:55 --> Input Class Initialized
INFO - 2023-03-15 06:25:55 --> Language Class Initialized
INFO - 2023-03-15 06:25:55 --> Loader Class Initialized
INFO - 2023-03-15 06:25:55 --> Controller Class Initialized
DEBUG - 2023-03-15 06:25:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:25:55 --> Database Driver Class Initialized
INFO - 2023-03-15 06:25:55 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:26:30 --> Config Class Initialized
INFO - 2023-03-15 06:26:30 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:26:30 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:26:30 --> Utf8 Class Initialized
INFO - 2023-03-15 06:26:30 --> URI Class Initialized
INFO - 2023-03-15 06:26:30 --> Router Class Initialized
INFO - 2023-03-15 06:26:30 --> Output Class Initialized
INFO - 2023-03-15 06:26:30 --> Security Class Initialized
DEBUG - 2023-03-15 06:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:26:30 --> Input Class Initialized
INFO - 2023-03-15 06:26:30 --> Language Class Initialized
INFO - 2023-03-15 06:26:30 --> Loader Class Initialized
INFO - 2023-03-15 06:26:30 --> Controller Class Initialized
DEBUG - 2023-03-15 06:26:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:26:30 --> Database Driver Class Initialized
INFO - 2023-03-15 06:26:30 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:36:36 --> Config Class Initialized
INFO - 2023-03-15 06:36:36 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:36:36 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:36:36 --> Utf8 Class Initialized
INFO - 2023-03-15 06:36:36 --> URI Class Initialized
INFO - 2023-03-15 06:36:36 --> Router Class Initialized
INFO - 2023-03-15 06:36:36 --> Output Class Initialized
INFO - 2023-03-15 06:36:36 --> Security Class Initialized
DEBUG - 2023-03-15 06:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:36:36 --> Input Class Initialized
INFO - 2023-03-15 06:36:36 --> Language Class Initialized
INFO - 2023-03-15 06:36:36 --> Loader Class Initialized
INFO - 2023-03-15 06:36:36 --> Controller Class Initialized
DEBUG - 2023-03-15 06:36:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:36:36 --> Database Driver Class Initialized
INFO - 2023-03-15 06:36:36 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:37:09 --> Config Class Initialized
INFO - 2023-03-15 06:37:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:37:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:37:09 --> Utf8 Class Initialized
INFO - 2023-03-15 06:37:09 --> URI Class Initialized
INFO - 2023-03-15 06:37:09 --> Router Class Initialized
INFO - 2023-03-15 06:37:09 --> Output Class Initialized
INFO - 2023-03-15 06:37:09 --> Security Class Initialized
DEBUG - 2023-03-15 06:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:37:09 --> Input Class Initialized
INFO - 2023-03-15 06:37:09 --> Language Class Initialized
INFO - 2023-03-15 06:37:09 --> Loader Class Initialized
INFO - 2023-03-15 06:37:09 --> Controller Class Initialized
DEBUG - 2023-03-15 06:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:37:09 --> Database Driver Class Initialized
INFO - 2023-03-15 06:37:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:37:10 --> Config Class Initialized
INFO - 2023-03-15 06:37:10 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:37:10 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:37:10 --> Utf8 Class Initialized
INFO - 2023-03-15 06:37:10 --> URI Class Initialized
INFO - 2023-03-15 06:37:10 --> Router Class Initialized
INFO - 2023-03-15 06:37:10 --> Output Class Initialized
INFO - 2023-03-15 06:37:10 --> Security Class Initialized
DEBUG - 2023-03-15 06:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:37:10 --> Input Class Initialized
INFO - 2023-03-15 06:37:10 --> Language Class Initialized
INFO - 2023-03-15 06:37:10 --> Loader Class Initialized
INFO - 2023-03-15 06:37:10 --> Controller Class Initialized
DEBUG - 2023-03-15 06:37:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:37:10 --> Database Driver Class Initialized
INFO - 2023-03-15 06:37:10 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:37:11 --> Config Class Initialized
INFO - 2023-03-15 06:37:11 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:37:11 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:37:11 --> Utf8 Class Initialized
INFO - 2023-03-15 06:37:11 --> URI Class Initialized
INFO - 2023-03-15 06:37:11 --> Router Class Initialized
INFO - 2023-03-15 06:37:11 --> Output Class Initialized
INFO - 2023-03-15 06:37:11 --> Security Class Initialized
DEBUG - 2023-03-15 06:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:37:11 --> Input Class Initialized
INFO - 2023-03-15 06:37:11 --> Language Class Initialized
INFO - 2023-03-15 06:37:11 --> Loader Class Initialized
INFO - 2023-03-15 06:37:11 --> Controller Class Initialized
DEBUG - 2023-03-15 06:37:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:37:11 --> Database Driver Class Initialized
INFO - 2023-03-15 06:37:11 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:37:53 --> Config Class Initialized
INFO - 2023-03-15 06:37:53 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:37:53 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:37:53 --> Utf8 Class Initialized
INFO - 2023-03-15 06:37:53 --> URI Class Initialized
INFO - 2023-03-15 06:37:53 --> Router Class Initialized
INFO - 2023-03-15 06:37:53 --> Output Class Initialized
INFO - 2023-03-15 06:37:53 --> Security Class Initialized
DEBUG - 2023-03-15 06:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:37:53 --> Input Class Initialized
INFO - 2023-03-15 06:37:53 --> Language Class Initialized
INFO - 2023-03-15 06:37:53 --> Loader Class Initialized
INFO - 2023-03-15 06:37:53 --> Controller Class Initialized
DEBUG - 2023-03-15 06:37:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:37:53 --> Database Driver Class Initialized
INFO - 2023-03-15 06:37:53 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:37:54 --> Config Class Initialized
INFO - 2023-03-15 06:37:54 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:37:54 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:37:54 --> Utf8 Class Initialized
INFO - 2023-03-15 06:37:54 --> URI Class Initialized
INFO - 2023-03-15 06:37:54 --> Router Class Initialized
INFO - 2023-03-15 06:37:54 --> Output Class Initialized
INFO - 2023-03-15 06:37:54 --> Security Class Initialized
DEBUG - 2023-03-15 06:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:37:54 --> Input Class Initialized
INFO - 2023-03-15 06:37:54 --> Language Class Initialized
INFO - 2023-03-15 06:37:54 --> Loader Class Initialized
INFO - 2023-03-15 06:37:54 --> Controller Class Initialized
DEBUG - 2023-03-15 06:37:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:37:54 --> Database Driver Class Initialized
INFO - 2023-03-15 06:37:54 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:38:23 --> Config Class Initialized
INFO - 2023-03-15 06:38:23 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:38:23 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:38:23 --> Utf8 Class Initialized
INFO - 2023-03-15 06:38:23 --> URI Class Initialized
INFO - 2023-03-15 06:38:23 --> Router Class Initialized
INFO - 2023-03-15 06:38:23 --> Output Class Initialized
INFO - 2023-03-15 06:38:23 --> Security Class Initialized
DEBUG - 2023-03-15 06:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:38:23 --> Input Class Initialized
INFO - 2023-03-15 06:38:23 --> Language Class Initialized
INFO - 2023-03-15 06:38:23 --> Loader Class Initialized
INFO - 2023-03-15 06:38:23 --> Controller Class Initialized
DEBUG - 2023-03-15 06:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:38:23 --> Database Driver Class Initialized
INFO - 2023-03-15 06:38:23 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:38:47 --> Config Class Initialized
INFO - 2023-03-15 06:38:47 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:38:47 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:38:47 --> Utf8 Class Initialized
INFO - 2023-03-15 06:38:47 --> URI Class Initialized
INFO - 2023-03-15 06:38:47 --> Router Class Initialized
INFO - 2023-03-15 06:38:47 --> Output Class Initialized
INFO - 2023-03-15 06:38:47 --> Security Class Initialized
DEBUG - 2023-03-15 06:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:38:47 --> Input Class Initialized
INFO - 2023-03-15 06:38:47 --> Language Class Initialized
INFO - 2023-03-15 06:38:47 --> Loader Class Initialized
INFO - 2023-03-15 06:38:47 --> Controller Class Initialized
DEBUG - 2023-03-15 06:38:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:38:47 --> Database Driver Class Initialized
INFO - 2023-03-15 06:38:47 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:38:49 --> Config Class Initialized
INFO - 2023-03-15 06:38:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:38:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:38:49 --> Utf8 Class Initialized
INFO - 2023-03-15 06:38:49 --> URI Class Initialized
INFO - 2023-03-15 06:38:49 --> Router Class Initialized
INFO - 2023-03-15 06:38:49 --> Output Class Initialized
INFO - 2023-03-15 06:38:49 --> Security Class Initialized
DEBUG - 2023-03-15 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:38:49 --> Input Class Initialized
INFO - 2023-03-15 06:38:49 --> Language Class Initialized
INFO - 2023-03-15 06:38:49 --> Loader Class Initialized
INFO - 2023-03-15 06:38:49 --> Controller Class Initialized
DEBUG - 2023-03-15 06:38:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:38:49 --> Database Driver Class Initialized
INFO - 2023-03-15 06:38:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:39:03 --> Config Class Initialized
INFO - 2023-03-15 06:39:03 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:39:03 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:39:03 --> Utf8 Class Initialized
INFO - 2023-03-15 06:39:03 --> URI Class Initialized
INFO - 2023-03-15 06:39:03 --> Router Class Initialized
INFO - 2023-03-15 06:39:03 --> Output Class Initialized
INFO - 2023-03-15 06:39:03 --> Security Class Initialized
DEBUG - 2023-03-15 06:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:39:03 --> Input Class Initialized
INFO - 2023-03-15 06:39:03 --> Language Class Initialized
INFO - 2023-03-15 06:39:03 --> Loader Class Initialized
INFO - 2023-03-15 06:39:03 --> Controller Class Initialized
DEBUG - 2023-03-15 06:39:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:39:03 --> Database Driver Class Initialized
INFO - 2023-03-15 06:39:03 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:39:04 --> Config Class Initialized
INFO - 2023-03-15 06:39:04 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:39:04 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:39:04 --> Utf8 Class Initialized
INFO - 2023-03-15 06:39:04 --> URI Class Initialized
INFO - 2023-03-15 06:39:04 --> Router Class Initialized
INFO - 2023-03-15 06:39:04 --> Output Class Initialized
INFO - 2023-03-15 06:39:04 --> Security Class Initialized
DEBUG - 2023-03-15 06:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:39:04 --> Input Class Initialized
INFO - 2023-03-15 06:39:04 --> Language Class Initialized
INFO - 2023-03-15 06:39:04 --> Loader Class Initialized
INFO - 2023-03-15 06:39:04 --> Controller Class Initialized
DEBUG - 2023-03-15 06:39:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:39:04 --> Database Driver Class Initialized
INFO - 2023-03-15 06:39:04 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:39:12 --> Config Class Initialized
INFO - 2023-03-15 06:39:12 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:39:12 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:39:12 --> Utf8 Class Initialized
INFO - 2023-03-15 06:39:12 --> URI Class Initialized
INFO - 2023-03-15 06:39:12 --> Router Class Initialized
INFO - 2023-03-15 06:39:12 --> Output Class Initialized
INFO - 2023-03-15 06:39:12 --> Security Class Initialized
DEBUG - 2023-03-15 06:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:39:12 --> Input Class Initialized
INFO - 2023-03-15 06:39:12 --> Language Class Initialized
INFO - 2023-03-15 06:39:12 --> Loader Class Initialized
INFO - 2023-03-15 06:39:12 --> Controller Class Initialized
DEBUG - 2023-03-15 06:39:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:39:12 --> Database Driver Class Initialized
INFO - 2023-03-15 06:39:12 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:39:21 --> Config Class Initialized
INFO - 2023-03-15 06:39:21 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:39:21 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:39:21 --> Utf8 Class Initialized
INFO - 2023-03-15 06:39:21 --> URI Class Initialized
INFO - 2023-03-15 06:39:21 --> Router Class Initialized
INFO - 2023-03-15 06:39:21 --> Output Class Initialized
INFO - 2023-03-15 06:39:21 --> Security Class Initialized
DEBUG - 2023-03-15 06:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:39:21 --> Input Class Initialized
INFO - 2023-03-15 06:39:21 --> Language Class Initialized
INFO - 2023-03-15 06:39:21 --> Loader Class Initialized
INFO - 2023-03-15 06:39:21 --> Controller Class Initialized
DEBUG - 2023-03-15 06:39:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:39:21 --> Database Driver Class Initialized
INFO - 2023-03-15 06:39:21 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:39:41 --> Config Class Initialized
INFO - 2023-03-15 06:39:41 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:39:41 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:39:41 --> Utf8 Class Initialized
INFO - 2023-03-15 06:39:41 --> URI Class Initialized
INFO - 2023-03-15 06:39:41 --> Router Class Initialized
INFO - 2023-03-15 06:39:41 --> Output Class Initialized
INFO - 2023-03-15 06:39:41 --> Security Class Initialized
DEBUG - 2023-03-15 06:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:39:41 --> Input Class Initialized
INFO - 2023-03-15 06:39:41 --> Language Class Initialized
INFO - 2023-03-15 06:39:41 --> Loader Class Initialized
INFO - 2023-03-15 06:39:41 --> Controller Class Initialized
DEBUG - 2023-03-15 06:39:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:39:41 --> Database Driver Class Initialized
INFO - 2023-03-15 06:39:41 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:40:08 --> Config Class Initialized
INFO - 2023-03-15 06:40:08 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:40:08 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:40:08 --> Utf8 Class Initialized
INFO - 2023-03-15 06:40:08 --> URI Class Initialized
INFO - 2023-03-15 06:40:08 --> Router Class Initialized
INFO - 2023-03-15 06:40:08 --> Output Class Initialized
INFO - 2023-03-15 06:40:08 --> Security Class Initialized
DEBUG - 2023-03-15 06:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:40:08 --> Input Class Initialized
INFO - 2023-03-15 06:40:08 --> Language Class Initialized
INFO - 2023-03-15 06:40:08 --> Loader Class Initialized
INFO - 2023-03-15 06:40:08 --> Controller Class Initialized
DEBUG - 2023-03-15 06:40:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:40:08 --> Database Driver Class Initialized
INFO - 2023-03-15 06:40:08 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:40:23 --> Config Class Initialized
INFO - 2023-03-15 06:40:23 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:40:23 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:40:23 --> Utf8 Class Initialized
INFO - 2023-03-15 06:40:23 --> URI Class Initialized
INFO - 2023-03-15 06:40:23 --> Router Class Initialized
INFO - 2023-03-15 06:40:23 --> Output Class Initialized
INFO - 2023-03-15 06:40:23 --> Security Class Initialized
DEBUG - 2023-03-15 06:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:40:23 --> Input Class Initialized
INFO - 2023-03-15 06:40:23 --> Language Class Initialized
INFO - 2023-03-15 06:40:23 --> Loader Class Initialized
INFO - 2023-03-15 06:40:23 --> Controller Class Initialized
DEBUG - 2023-03-15 06:40:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:40:23 --> Database Driver Class Initialized
INFO - 2023-03-15 06:40:23 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:41:04 --> Config Class Initialized
INFO - 2023-03-15 06:41:04 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:41:04 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:41:04 --> Utf8 Class Initialized
INFO - 2023-03-15 06:41:04 --> URI Class Initialized
INFO - 2023-03-15 06:41:04 --> Router Class Initialized
INFO - 2023-03-15 06:41:04 --> Output Class Initialized
INFO - 2023-03-15 06:41:04 --> Security Class Initialized
DEBUG - 2023-03-15 06:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:41:04 --> Input Class Initialized
INFO - 2023-03-15 06:41:04 --> Language Class Initialized
INFO - 2023-03-15 06:41:04 --> Loader Class Initialized
INFO - 2023-03-15 06:41:04 --> Controller Class Initialized
DEBUG - 2023-03-15 06:41:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:41:04 --> Database Driver Class Initialized
INFO - 2023-03-15 06:41:04 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:50:30 --> Config Class Initialized
INFO - 2023-03-15 06:50:30 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:50:30 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:50:30 --> Utf8 Class Initialized
INFO - 2023-03-15 06:50:30 --> URI Class Initialized
INFO - 2023-03-15 06:50:30 --> Router Class Initialized
INFO - 2023-03-15 06:50:30 --> Output Class Initialized
INFO - 2023-03-15 06:50:30 --> Security Class Initialized
DEBUG - 2023-03-15 06:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:50:30 --> Input Class Initialized
INFO - 2023-03-15 06:50:30 --> Language Class Initialized
INFO - 2023-03-15 06:50:30 --> Loader Class Initialized
INFO - 2023-03-15 06:50:30 --> Controller Class Initialized
DEBUG - 2023-03-15 06:50:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:50:30 --> Database Driver Class Initialized
INFO - 2023-03-15 06:50:30 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:51:21 --> Config Class Initialized
INFO - 2023-03-15 06:51:21 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:51:21 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:51:21 --> Utf8 Class Initialized
INFO - 2023-03-15 06:51:21 --> URI Class Initialized
INFO - 2023-03-15 06:51:21 --> Router Class Initialized
INFO - 2023-03-15 06:51:21 --> Output Class Initialized
INFO - 2023-03-15 06:51:21 --> Security Class Initialized
DEBUG - 2023-03-15 06:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:51:21 --> Input Class Initialized
INFO - 2023-03-15 06:51:21 --> Language Class Initialized
INFO - 2023-03-15 06:51:21 --> Loader Class Initialized
INFO - 2023-03-15 06:51:21 --> Controller Class Initialized
DEBUG - 2023-03-15 06:51:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:51:21 --> Database Driver Class Initialized
INFO - 2023-03-15 06:51:21 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:52:22 --> Config Class Initialized
INFO - 2023-03-15 06:52:22 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:52:22 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:52:22 --> Utf8 Class Initialized
INFO - 2023-03-15 06:52:22 --> URI Class Initialized
INFO - 2023-03-15 06:52:22 --> Router Class Initialized
INFO - 2023-03-15 06:52:22 --> Output Class Initialized
INFO - 2023-03-15 06:52:22 --> Security Class Initialized
DEBUG - 2023-03-15 06:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:52:22 --> Input Class Initialized
INFO - 2023-03-15 06:52:22 --> Language Class Initialized
INFO - 2023-03-15 06:52:22 --> Loader Class Initialized
INFO - 2023-03-15 06:52:22 --> Controller Class Initialized
DEBUG - 2023-03-15 06:52:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:52:22 --> Database Driver Class Initialized
INFO - 2023-03-15 06:52:22 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:54:26 --> Config Class Initialized
INFO - 2023-03-15 06:54:26 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:54:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:54:26 --> Utf8 Class Initialized
INFO - 2023-03-15 06:54:26 --> URI Class Initialized
INFO - 2023-03-15 06:54:26 --> Router Class Initialized
INFO - 2023-03-15 06:54:26 --> Output Class Initialized
INFO - 2023-03-15 06:54:26 --> Security Class Initialized
DEBUG - 2023-03-15 06:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:54:26 --> Input Class Initialized
INFO - 2023-03-15 06:54:26 --> Language Class Initialized
INFO - 2023-03-15 06:54:26 --> Loader Class Initialized
INFO - 2023-03-15 06:54:26 --> Controller Class Initialized
DEBUG - 2023-03-15 06:54:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:54:26 --> Database Driver Class Initialized
INFO - 2023-03-15 06:54:26 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:55:10 --> Config Class Initialized
INFO - 2023-03-15 06:55:10 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:55:10 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:55:10 --> Utf8 Class Initialized
INFO - 2023-03-15 06:55:10 --> URI Class Initialized
INFO - 2023-03-15 06:55:10 --> Router Class Initialized
INFO - 2023-03-15 06:55:10 --> Output Class Initialized
INFO - 2023-03-15 06:55:10 --> Security Class Initialized
DEBUG - 2023-03-15 06:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:55:10 --> Input Class Initialized
INFO - 2023-03-15 06:55:10 --> Language Class Initialized
INFO - 2023-03-15 06:55:10 --> Loader Class Initialized
INFO - 2023-03-15 06:55:10 --> Controller Class Initialized
DEBUG - 2023-03-15 06:55:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:55:10 --> Database Driver Class Initialized
INFO - 2023-03-15 06:55:10 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:55:33 --> Config Class Initialized
INFO - 2023-03-15 06:55:33 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:55:33 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:55:33 --> Utf8 Class Initialized
INFO - 2023-03-15 06:55:33 --> URI Class Initialized
INFO - 2023-03-15 06:55:33 --> Router Class Initialized
INFO - 2023-03-15 06:55:33 --> Output Class Initialized
INFO - 2023-03-15 06:55:33 --> Security Class Initialized
DEBUG - 2023-03-15 06:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:55:33 --> Input Class Initialized
INFO - 2023-03-15 06:55:33 --> Language Class Initialized
INFO - 2023-03-15 06:55:33 --> Loader Class Initialized
INFO - 2023-03-15 06:55:33 --> Controller Class Initialized
DEBUG - 2023-03-15 06:55:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:55:33 --> Database Driver Class Initialized
INFO - 2023-03-15 06:55:33 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:55:33 --> Database Driver Class Initialized
INFO - 2023-03-15 06:55:33 --> Model "Login_model" initialized
INFO - 2023-03-15 06:55:33 --> Final output sent to browser
DEBUG - 2023-03-15 06:55:33 --> Total execution time: 0.1488
INFO - 2023-03-15 06:55:33 --> Config Class Initialized
INFO - 2023-03-15 06:55:33 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:55:33 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:55:33 --> Utf8 Class Initialized
INFO - 2023-03-15 06:55:33 --> URI Class Initialized
INFO - 2023-03-15 06:55:33 --> Router Class Initialized
INFO - 2023-03-15 06:55:33 --> Output Class Initialized
INFO - 2023-03-15 06:55:33 --> Security Class Initialized
DEBUG - 2023-03-15 06:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:55:33 --> Input Class Initialized
INFO - 2023-03-15 06:55:33 --> Language Class Initialized
INFO - 2023-03-15 06:55:33 --> Loader Class Initialized
INFO - 2023-03-15 06:55:33 --> Controller Class Initialized
DEBUG - 2023-03-15 06:55:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:55:33 --> Database Driver Class Initialized
INFO - 2023-03-15 06:55:33 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:55:33 --> Database Driver Class Initialized
INFO - 2023-03-15 06:55:33 --> Model "Login_model" initialized
INFO - 2023-03-15 06:55:33 --> Final output sent to browser
DEBUG - 2023-03-15 06:55:33 --> Total execution time: 0.0976
INFO - 2023-03-15 06:55:36 --> Config Class Initialized
INFO - 2023-03-15 06:55:36 --> Config Class Initialized
INFO - 2023-03-15 06:55:36 --> Hooks Class Initialized
INFO - 2023-03-15 06:55:36 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:55:36 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 06:55:36 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:55:36 --> Utf8 Class Initialized
INFO - 2023-03-15 06:55:36 --> Utf8 Class Initialized
INFO - 2023-03-15 06:55:36 --> URI Class Initialized
INFO - 2023-03-15 06:55:36 --> URI Class Initialized
INFO - 2023-03-15 06:55:36 --> Router Class Initialized
INFO - 2023-03-15 06:55:36 --> Router Class Initialized
INFO - 2023-03-15 06:55:36 --> Output Class Initialized
INFO - 2023-03-15 06:55:36 --> Output Class Initialized
INFO - 2023-03-15 06:55:36 --> Security Class Initialized
INFO - 2023-03-15 06:55:36 --> Security Class Initialized
DEBUG - 2023-03-15 06:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:55:36 --> Input Class Initialized
DEBUG - 2023-03-15 06:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:55:36 --> Input Class Initialized
INFO - 2023-03-15 06:55:36 --> Language Class Initialized
INFO - 2023-03-15 06:55:36 --> Language Class Initialized
INFO - 2023-03-15 06:55:36 --> Loader Class Initialized
INFO - 2023-03-15 06:55:36 --> Loader Class Initialized
INFO - 2023-03-15 06:55:36 --> Controller Class Initialized
INFO - 2023-03-15 06:55:36 --> Controller Class Initialized
DEBUG - 2023-03-15 06:55:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 06:55:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:55:36 --> Database Driver Class Initialized
INFO - 2023-03-15 06:55:36 --> Database Driver Class Initialized
INFO - 2023-03-15 06:55:36 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:55:36 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:55:36 --> Final output sent to browser
DEBUG - 2023-03-15 06:55:36 --> Total execution time: 0.0153
INFO - 2023-03-15 06:55:36 --> Config Class Initialized
INFO - 2023-03-15 06:55:36 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:55:36 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:55:36 --> Utf8 Class Initialized
INFO - 2023-03-15 06:55:36 --> URI Class Initialized
INFO - 2023-03-15 06:55:36 --> Router Class Initialized
INFO - 2023-03-15 06:55:36 --> Output Class Initialized
INFO - 2023-03-15 06:55:36 --> Security Class Initialized
DEBUG - 2023-03-15 06:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:55:36 --> Input Class Initialized
INFO - 2023-03-15 06:55:36 --> Language Class Initialized
INFO - 2023-03-15 06:55:36 --> Loader Class Initialized
INFO - 2023-03-15 06:55:36 --> Controller Class Initialized
DEBUG - 2023-03-15 06:55:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:55:36 --> Database Driver Class Initialized
INFO - 2023-03-15 06:55:36 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:55:36 --> Final output sent to browser
DEBUG - 2023-03-15 06:55:36 --> Total execution time: 0.0519
INFO - 2023-03-15 06:55:36 --> Config Class Initialized
INFO - 2023-03-15 06:55:36 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:55:36 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:55:36 --> Utf8 Class Initialized
INFO - 2023-03-15 06:55:36 --> URI Class Initialized
INFO - 2023-03-15 06:55:36 --> Router Class Initialized
INFO - 2023-03-15 06:55:36 --> Output Class Initialized
INFO - 2023-03-15 06:55:36 --> Security Class Initialized
DEBUG - 2023-03-15 06:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:55:36 --> Input Class Initialized
INFO - 2023-03-15 06:55:36 --> Language Class Initialized
INFO - 2023-03-15 06:55:36 --> Loader Class Initialized
INFO - 2023-03-15 06:55:36 --> Controller Class Initialized
DEBUG - 2023-03-15 06:55:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:55:36 --> Database Driver Class Initialized
INFO - 2023-03-15 06:55:36 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:56:05 --> Config Class Initialized
INFO - 2023-03-15 06:56:05 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:56:05 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:56:05 --> Utf8 Class Initialized
INFO - 2023-03-15 06:56:05 --> URI Class Initialized
INFO - 2023-03-15 06:56:05 --> Router Class Initialized
INFO - 2023-03-15 06:56:05 --> Output Class Initialized
INFO - 2023-03-15 06:56:05 --> Security Class Initialized
DEBUG - 2023-03-15 06:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:56:05 --> Input Class Initialized
INFO - 2023-03-15 06:56:05 --> Language Class Initialized
INFO - 2023-03-15 06:56:05 --> Loader Class Initialized
INFO - 2023-03-15 06:56:05 --> Controller Class Initialized
DEBUG - 2023-03-15 06:56:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:56:05 --> Database Driver Class Initialized
INFO - 2023-03-15 06:56:05 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:56:05 --> Config Class Initialized
INFO - 2023-03-15 06:56:06 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:56:06 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:56:06 --> Utf8 Class Initialized
INFO - 2023-03-15 06:56:06 --> URI Class Initialized
INFO - 2023-03-15 06:56:06 --> Router Class Initialized
INFO - 2023-03-15 06:56:06 --> Output Class Initialized
INFO - 2023-03-15 06:56:06 --> Security Class Initialized
DEBUG - 2023-03-15 06:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:56:06 --> Input Class Initialized
INFO - 2023-03-15 06:56:06 --> Language Class Initialized
INFO - 2023-03-15 06:56:06 --> Loader Class Initialized
INFO - 2023-03-15 06:56:06 --> Controller Class Initialized
DEBUG - 2023-03-15 06:56:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:56:06 --> Database Driver Class Initialized
INFO - 2023-03-15 06:56:06 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:57:14 --> Config Class Initialized
INFO - 2023-03-15 06:57:14 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:57:14 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:57:14 --> Utf8 Class Initialized
INFO - 2023-03-15 06:57:14 --> URI Class Initialized
INFO - 2023-03-15 06:57:14 --> Router Class Initialized
INFO - 2023-03-15 06:57:14 --> Output Class Initialized
INFO - 2023-03-15 06:57:14 --> Security Class Initialized
DEBUG - 2023-03-15 06:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:57:14 --> Input Class Initialized
INFO - 2023-03-15 06:57:14 --> Language Class Initialized
INFO - 2023-03-15 06:57:14 --> Loader Class Initialized
INFO - 2023-03-15 06:57:14 --> Controller Class Initialized
DEBUG - 2023-03-15 06:57:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:57:14 --> Database Driver Class Initialized
INFO - 2023-03-15 06:57:14 --> Model "Cluster_model" initialized
INFO - 2023-03-15 06:58:07 --> Config Class Initialized
INFO - 2023-03-15 06:58:07 --> Hooks Class Initialized
DEBUG - 2023-03-15 06:58:07 --> UTF-8 Support Enabled
INFO - 2023-03-15 06:58:07 --> Utf8 Class Initialized
INFO - 2023-03-15 06:58:07 --> URI Class Initialized
INFO - 2023-03-15 06:58:07 --> Router Class Initialized
INFO - 2023-03-15 06:58:07 --> Output Class Initialized
INFO - 2023-03-15 06:58:07 --> Security Class Initialized
DEBUG - 2023-03-15 06:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 06:58:07 --> Input Class Initialized
INFO - 2023-03-15 06:58:07 --> Language Class Initialized
INFO - 2023-03-15 06:58:07 --> Loader Class Initialized
INFO - 2023-03-15 06:58:07 --> Controller Class Initialized
DEBUG - 2023-03-15 06:58:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 06:58:07 --> Database Driver Class Initialized
INFO - 2023-03-15 06:58:07 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:03:11 --> Config Class Initialized
INFO - 2023-03-15 07:03:11 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:03:11 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:03:11 --> Utf8 Class Initialized
INFO - 2023-03-15 07:03:11 --> URI Class Initialized
INFO - 2023-03-15 07:03:11 --> Router Class Initialized
INFO - 2023-03-15 07:03:11 --> Output Class Initialized
INFO - 2023-03-15 07:03:11 --> Security Class Initialized
DEBUG - 2023-03-15 07:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:03:11 --> Input Class Initialized
INFO - 2023-03-15 07:03:11 --> Language Class Initialized
INFO - 2023-03-15 07:03:11 --> Loader Class Initialized
INFO - 2023-03-15 07:03:11 --> Controller Class Initialized
DEBUG - 2023-03-15 07:03:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:03:11 --> Database Driver Class Initialized
INFO - 2023-03-15 07:03:11 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:04:36 --> Config Class Initialized
INFO - 2023-03-15 07:04:36 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:04:36 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:04:36 --> Utf8 Class Initialized
INFO - 2023-03-15 07:04:36 --> URI Class Initialized
INFO - 2023-03-15 07:04:36 --> Router Class Initialized
INFO - 2023-03-15 07:04:36 --> Output Class Initialized
INFO - 2023-03-15 07:04:36 --> Security Class Initialized
DEBUG - 2023-03-15 07:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:04:36 --> Input Class Initialized
INFO - 2023-03-15 07:04:36 --> Language Class Initialized
INFO - 2023-03-15 07:04:36 --> Loader Class Initialized
INFO - 2023-03-15 07:04:36 --> Controller Class Initialized
DEBUG - 2023-03-15 07:04:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:04:36 --> Database Driver Class Initialized
INFO - 2023-03-15 07:04:36 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:05:59 --> Config Class Initialized
INFO - 2023-03-15 07:05:59 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:05:59 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:05:59 --> Utf8 Class Initialized
INFO - 2023-03-15 07:05:59 --> URI Class Initialized
INFO - 2023-03-15 07:05:59 --> Router Class Initialized
INFO - 2023-03-15 07:05:59 --> Output Class Initialized
INFO - 2023-03-15 07:05:59 --> Security Class Initialized
DEBUG - 2023-03-15 07:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:05:59 --> Input Class Initialized
INFO - 2023-03-15 07:05:59 --> Language Class Initialized
INFO - 2023-03-15 07:05:59 --> Loader Class Initialized
INFO - 2023-03-15 07:05:59 --> Controller Class Initialized
DEBUG - 2023-03-15 07:05:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:05:59 --> Database Driver Class Initialized
INFO - 2023-03-15 07:05:59 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:06:56 --> Config Class Initialized
INFO - 2023-03-15 07:06:56 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:06:56 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:06:56 --> Utf8 Class Initialized
INFO - 2023-03-15 07:06:56 --> URI Class Initialized
INFO - 2023-03-15 07:06:56 --> Router Class Initialized
INFO - 2023-03-15 07:06:56 --> Output Class Initialized
INFO - 2023-03-15 07:06:56 --> Security Class Initialized
DEBUG - 2023-03-15 07:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:06:56 --> Input Class Initialized
INFO - 2023-03-15 07:06:56 --> Language Class Initialized
INFO - 2023-03-15 07:06:56 --> Loader Class Initialized
INFO - 2023-03-15 07:06:56 --> Controller Class Initialized
DEBUG - 2023-03-15 07:06:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:06:56 --> Database Driver Class Initialized
INFO - 2023-03-15 07:06:56 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:07:27 --> Config Class Initialized
INFO - 2023-03-15 07:07:27 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:07:27 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:07:27 --> Utf8 Class Initialized
INFO - 2023-03-15 07:07:27 --> URI Class Initialized
INFO - 2023-03-15 07:07:27 --> Router Class Initialized
INFO - 2023-03-15 07:07:27 --> Output Class Initialized
INFO - 2023-03-15 07:07:27 --> Security Class Initialized
DEBUG - 2023-03-15 07:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:07:27 --> Input Class Initialized
INFO - 2023-03-15 07:07:27 --> Language Class Initialized
INFO - 2023-03-15 07:07:27 --> Loader Class Initialized
INFO - 2023-03-15 07:07:27 --> Controller Class Initialized
DEBUG - 2023-03-15 07:07:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:07:27 --> Database Driver Class Initialized
INFO - 2023-03-15 07:07:27 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:08:14 --> Config Class Initialized
INFO - 2023-03-15 07:08:14 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:08:14 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:08:14 --> Utf8 Class Initialized
INFO - 2023-03-15 07:08:14 --> URI Class Initialized
INFO - 2023-03-15 07:08:14 --> Router Class Initialized
INFO - 2023-03-15 07:08:14 --> Output Class Initialized
INFO - 2023-03-15 07:08:14 --> Security Class Initialized
DEBUG - 2023-03-15 07:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:08:14 --> Input Class Initialized
INFO - 2023-03-15 07:08:14 --> Language Class Initialized
INFO - 2023-03-15 07:08:14 --> Loader Class Initialized
INFO - 2023-03-15 07:08:14 --> Controller Class Initialized
DEBUG - 2023-03-15 07:08:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:08:14 --> Database Driver Class Initialized
INFO - 2023-03-15 07:08:14 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:25 --> Config Class Initialized
INFO - 2023-03-15 07:09:25 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:25 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:25 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:25 --> URI Class Initialized
INFO - 2023-03-15 07:09:25 --> Router Class Initialized
INFO - 2023-03-15 07:09:25 --> Output Class Initialized
INFO - 2023-03-15 07:09:25 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:25 --> Input Class Initialized
INFO - 2023-03-15 07:09:25 --> Language Class Initialized
INFO - 2023-03-15 07:09:25 --> Loader Class Initialized
INFO - 2023-03-15 07:09:25 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:25 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:25 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:40 --> Config Class Initialized
INFO - 2023-03-15 07:09:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:40 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:40 --> URI Class Initialized
INFO - 2023-03-15 07:09:40 --> Router Class Initialized
INFO - 2023-03-15 07:09:40 --> Output Class Initialized
INFO - 2023-03-15 07:09:40 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:40 --> Input Class Initialized
INFO - 2023-03-15 07:09:40 --> Language Class Initialized
INFO - 2023-03-15 07:09:40 --> Loader Class Initialized
INFO - 2023-03-15 07:09:40 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:40 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:40 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:40 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:40 --> Model "Login_model" initialized
INFO - 2023-03-15 07:09:40 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:40 --> Total execution time: 0.1644
INFO - 2023-03-15 07:09:40 --> Config Class Initialized
INFO - 2023-03-15 07:09:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:40 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:40 --> URI Class Initialized
INFO - 2023-03-15 07:09:40 --> Router Class Initialized
INFO - 2023-03-15 07:09:40 --> Output Class Initialized
INFO - 2023-03-15 07:09:40 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:40 --> Input Class Initialized
INFO - 2023-03-15 07:09:40 --> Language Class Initialized
INFO - 2023-03-15 07:09:40 --> Loader Class Initialized
INFO - 2023-03-15 07:09:40 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:40 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:40 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:40 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:40 --> Model "Login_model" initialized
INFO - 2023-03-15 07:09:40 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:40 --> Total execution time: 0.0784
INFO - 2023-03-15 07:09:44 --> Config Class Initialized
INFO - 2023-03-15 07:09:44 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:44 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:44 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:44 --> URI Class Initialized
INFO - 2023-03-15 07:09:44 --> Router Class Initialized
INFO - 2023-03-15 07:09:44 --> Output Class Initialized
INFO - 2023-03-15 07:09:44 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:44 --> Input Class Initialized
INFO - 2023-03-15 07:09:44 --> Language Class Initialized
INFO - 2023-03-15 07:09:44 --> Loader Class Initialized
INFO - 2023-03-15 07:09:44 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:44 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:44 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:44 --> Model "Login_model" initialized
INFO - 2023-03-15 07:09:44 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:44 --> Total execution time: 0.0283
INFO - 2023-03-15 07:09:44 --> Config Class Initialized
INFO - 2023-03-15 07:09:44 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:44 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:44 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:44 --> URI Class Initialized
INFO - 2023-03-15 07:09:44 --> Router Class Initialized
INFO - 2023-03-15 07:09:44 --> Output Class Initialized
INFO - 2023-03-15 07:09:44 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:44 --> Input Class Initialized
INFO - 2023-03-15 07:09:44 --> Language Class Initialized
INFO - 2023-03-15 07:09:44 --> Loader Class Initialized
INFO - 2023-03-15 07:09:44 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:44 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:44 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:44 --> Model "Login_model" initialized
INFO - 2023-03-15 07:09:44 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:44 --> Total execution time: 0.0633
INFO - 2023-03-15 07:09:44 --> Config Class Initialized
INFO - 2023-03-15 07:09:44 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:44 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:44 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:44 --> URI Class Initialized
INFO - 2023-03-15 07:09:44 --> Router Class Initialized
INFO - 2023-03-15 07:09:44 --> Output Class Initialized
INFO - 2023-03-15 07:09:44 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:44 --> Input Class Initialized
INFO - 2023-03-15 07:09:44 --> Language Class Initialized
INFO - 2023-03-15 07:09:44 --> Loader Class Initialized
INFO - 2023-03-15 07:09:44 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:44 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:44 --> Total execution time: 0.0457
INFO - 2023-03-15 07:09:44 --> Config Class Initialized
INFO - 2023-03-15 07:09:44 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:44 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:44 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:44 --> URI Class Initialized
INFO - 2023-03-15 07:09:44 --> Router Class Initialized
INFO - 2023-03-15 07:09:44 --> Output Class Initialized
INFO - 2023-03-15 07:09:44 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:44 --> Input Class Initialized
INFO - 2023-03-15 07:09:44 --> Language Class Initialized
INFO - 2023-03-15 07:09:44 --> Loader Class Initialized
INFO - 2023-03-15 07:09:44 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:45 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:45 --> Total execution time: 0.0735
INFO - 2023-03-15 07:09:46 --> Config Class Initialized
INFO - 2023-03-15 07:09:46 --> Config Class Initialized
INFO - 2023-03-15 07:09:46 --> Hooks Class Initialized
INFO - 2023-03-15 07:09:46 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:09:46 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:46 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:46 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:46 --> URI Class Initialized
INFO - 2023-03-15 07:09:46 --> URI Class Initialized
INFO - 2023-03-15 07:09:46 --> Router Class Initialized
INFO - 2023-03-15 07:09:46 --> Router Class Initialized
INFO - 2023-03-15 07:09:46 --> Output Class Initialized
INFO - 2023-03-15 07:09:46 --> Output Class Initialized
INFO - 2023-03-15 07:09:46 --> Security Class Initialized
INFO - 2023-03-15 07:09:46 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:46 --> Input Class Initialized
INFO - 2023-03-15 07:09:46 --> Input Class Initialized
INFO - 2023-03-15 07:09:46 --> Language Class Initialized
INFO - 2023-03-15 07:09:46 --> Language Class Initialized
INFO - 2023-03-15 07:09:46 --> Loader Class Initialized
INFO - 2023-03-15 07:09:46 --> Loader Class Initialized
INFO - 2023-03-15 07:09:46 --> Controller Class Initialized
INFO - 2023-03-15 07:09:46 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:09:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:46 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:46 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:46 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:46 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:46 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:46 --> Total execution time: 0.0200
INFO - 2023-03-15 07:09:46 --> Config Class Initialized
INFO - 2023-03-15 07:09:46 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:46 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:46 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:46 --> URI Class Initialized
INFO - 2023-03-15 07:09:46 --> Router Class Initialized
INFO - 2023-03-15 07:09:46 --> Output Class Initialized
INFO - 2023-03-15 07:09:46 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:46 --> Input Class Initialized
INFO - 2023-03-15 07:09:46 --> Language Class Initialized
INFO - 2023-03-15 07:09:46 --> Loader Class Initialized
INFO - 2023-03-15 07:09:46 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:46 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:46 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:46 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:46 --> Total execution time: 0.1513
INFO - 2023-03-15 07:09:46 --> Config Class Initialized
INFO - 2023-03-15 07:09:46 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:46 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:46 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:46 --> URI Class Initialized
INFO - 2023-03-15 07:09:46 --> Router Class Initialized
INFO - 2023-03-15 07:09:46 --> Output Class Initialized
INFO - 2023-03-15 07:09:46 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:46 --> Input Class Initialized
INFO - 2023-03-15 07:09:46 --> Language Class Initialized
INFO - 2023-03-15 07:09:46 --> Loader Class Initialized
INFO - 2023-03-15 07:09:46 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:46 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:46 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:48 --> Config Class Initialized
INFO - 2023-03-15 07:09:48 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:48 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:48 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:48 --> URI Class Initialized
INFO - 2023-03-15 07:09:48 --> Router Class Initialized
INFO - 2023-03-15 07:09:48 --> Output Class Initialized
INFO - 2023-03-15 07:09:48 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:48 --> Input Class Initialized
INFO - 2023-03-15 07:09:48 --> Language Class Initialized
INFO - 2023-03-15 07:09:48 --> Loader Class Initialized
INFO - 2023-03-15 07:09:48 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:48 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:48 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:49 --> Config Class Initialized
INFO - 2023-03-15 07:09:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:49 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:49 --> URI Class Initialized
INFO - 2023-03-15 07:09:49 --> Router Class Initialized
INFO - 2023-03-15 07:09:49 --> Output Class Initialized
INFO - 2023-03-15 07:09:49 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:49 --> Input Class Initialized
INFO - 2023-03-15 07:09:49 --> Language Class Initialized
INFO - 2023-03-15 07:09:49 --> Loader Class Initialized
INFO - 2023-03-15 07:09:49 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:49 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:50 --> Config Class Initialized
INFO - 2023-03-15 07:09:50 --> Config Class Initialized
INFO - 2023-03-15 07:09:50 --> Hooks Class Initialized
INFO - 2023-03-15 07:09:50 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:50 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:09:50 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:50 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:50 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:50 --> URI Class Initialized
INFO - 2023-03-15 07:09:50 --> URI Class Initialized
INFO - 2023-03-15 07:09:50 --> Router Class Initialized
INFO - 2023-03-15 07:09:50 --> Router Class Initialized
INFO - 2023-03-15 07:09:50 --> Output Class Initialized
INFO - 2023-03-15 07:09:50 --> Output Class Initialized
INFO - 2023-03-15 07:09:50 --> Security Class Initialized
INFO - 2023-03-15 07:09:50 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:50 --> Input Class Initialized
INFO - 2023-03-15 07:09:50 --> Language Class Initialized
INFO - 2023-03-15 07:09:50 --> Input Class Initialized
INFO - 2023-03-15 07:09:50 --> Language Class Initialized
INFO - 2023-03-15 07:09:50 --> Loader Class Initialized
INFO - 2023-03-15 07:09:50 --> Loader Class Initialized
INFO - 2023-03-15 07:09:50 --> Controller Class Initialized
INFO - 2023-03-15 07:09:50 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:09:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:50 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:50 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:50 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:50 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:50 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:50 --> Total execution time: 0.0158
INFO - 2023-03-15 07:09:50 --> Config Class Initialized
INFO - 2023-03-15 07:09:50 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:50 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:50 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:50 --> URI Class Initialized
INFO - 2023-03-15 07:09:50 --> Router Class Initialized
INFO - 2023-03-15 07:09:50 --> Output Class Initialized
INFO - 2023-03-15 07:09:50 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:50 --> Input Class Initialized
INFO - 2023-03-15 07:09:50 --> Language Class Initialized
INFO - 2023-03-15 07:09:50 --> Loader Class Initialized
INFO - 2023-03-15 07:09:50 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:50 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:50 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:50 --> Model "Login_model" initialized
INFO - 2023-03-15 07:09:50 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:50 --> Total execution time: 0.0275
INFO - 2023-03-15 07:09:50 --> Config Class Initialized
INFO - 2023-03-15 07:09:50 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:50 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:50 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:50 --> URI Class Initialized
INFO - 2023-03-15 07:09:50 --> Router Class Initialized
INFO - 2023-03-15 07:09:50 --> Output Class Initialized
INFO - 2023-03-15 07:09:50 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:50 --> Input Class Initialized
INFO - 2023-03-15 07:09:50 --> Language Class Initialized
INFO - 2023-03-15 07:09:50 --> Loader Class Initialized
INFO - 2023-03-15 07:09:50 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:50 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:50 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:50 --> Model "Login_model" initialized
INFO - 2023-03-15 07:09:50 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:50 --> Total execution time: 0.0494
INFO - 2023-03-15 07:09:50 --> Config Class Initialized
INFO - 2023-03-15 07:09:50 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:50 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:50 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:50 --> URI Class Initialized
INFO - 2023-03-15 07:09:50 --> Router Class Initialized
INFO - 2023-03-15 07:09:50 --> Output Class Initialized
INFO - 2023-03-15 07:09:50 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:50 --> Input Class Initialized
INFO - 2023-03-15 07:09:50 --> Language Class Initialized
INFO - 2023-03-15 07:09:50 --> Loader Class Initialized
INFO - 2023-03-15 07:09:50 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:50 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:50 --> Total execution time: 0.0445
INFO - 2023-03-15 07:09:50 --> Config Class Initialized
INFO - 2023-03-15 07:09:50 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:50 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:50 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:50 --> URI Class Initialized
INFO - 2023-03-15 07:09:50 --> Router Class Initialized
INFO - 2023-03-15 07:09:50 --> Output Class Initialized
INFO - 2023-03-15 07:09:50 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:50 --> Input Class Initialized
INFO - 2023-03-15 07:09:50 --> Language Class Initialized
INFO - 2023-03-15 07:09:50 --> Loader Class Initialized
INFO - 2023-03-15 07:09:50 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:50 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:50 --> Total execution time: 0.0519
INFO - 2023-03-15 07:09:51 --> Config Class Initialized
INFO - 2023-03-15 07:09:51 --> Hooks Class Initialized
INFO - 2023-03-15 07:09:51 --> Config Class Initialized
INFO - 2023-03-15 07:09:51 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:51 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:09:51 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:51 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:51 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:51 --> URI Class Initialized
INFO - 2023-03-15 07:09:51 --> URI Class Initialized
INFO - 2023-03-15 07:09:51 --> Router Class Initialized
INFO - 2023-03-15 07:09:51 --> Router Class Initialized
INFO - 2023-03-15 07:09:51 --> Output Class Initialized
INFO - 2023-03-15 07:09:51 --> Output Class Initialized
INFO - 2023-03-15 07:09:51 --> Security Class Initialized
INFO - 2023-03-15 07:09:51 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:51 --> Input Class Initialized
INFO - 2023-03-15 07:09:51 --> Input Class Initialized
INFO - 2023-03-15 07:09:51 --> Language Class Initialized
INFO - 2023-03-15 07:09:51 --> Language Class Initialized
INFO - 2023-03-15 07:09:51 --> Loader Class Initialized
INFO - 2023-03-15 07:09:51 --> Loader Class Initialized
INFO - 2023-03-15 07:09:51 --> Controller Class Initialized
INFO - 2023-03-15 07:09:51 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:09:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:51 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:51 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:51 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:51 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:51 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:51 --> Total execution time: 0.0173
INFO - 2023-03-15 07:09:51 --> Config Class Initialized
INFO - 2023-03-15 07:09:51 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:51 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:51 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:51 --> URI Class Initialized
INFO - 2023-03-15 07:09:51 --> Router Class Initialized
INFO - 2023-03-15 07:09:51 --> Output Class Initialized
INFO - 2023-03-15 07:09:51 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:51 --> Input Class Initialized
INFO - 2023-03-15 07:09:51 --> Language Class Initialized
INFO - 2023-03-15 07:09:51 --> Loader Class Initialized
INFO - 2023-03-15 07:09:51 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:51 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:51 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:51 --> Final output sent to browser
DEBUG - 2023-03-15 07:09:51 --> Total execution time: 0.0108
INFO - 2023-03-15 07:09:51 --> Config Class Initialized
INFO - 2023-03-15 07:09:51 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:51 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:51 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:51 --> URI Class Initialized
INFO - 2023-03-15 07:09:51 --> Router Class Initialized
INFO - 2023-03-15 07:09:51 --> Output Class Initialized
INFO - 2023-03-15 07:09:51 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:51 --> Input Class Initialized
INFO - 2023-03-15 07:09:51 --> Language Class Initialized
INFO - 2023-03-15 07:09:51 --> Loader Class Initialized
INFO - 2023-03-15 07:09:51 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:51 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:51 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:53 --> Config Class Initialized
INFO - 2023-03-15 07:09:53 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:53 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:53 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:53 --> URI Class Initialized
INFO - 2023-03-15 07:09:53 --> Router Class Initialized
INFO - 2023-03-15 07:09:53 --> Output Class Initialized
INFO - 2023-03-15 07:09:53 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:53 --> Input Class Initialized
INFO - 2023-03-15 07:09:53 --> Language Class Initialized
INFO - 2023-03-15 07:09:53 --> Loader Class Initialized
INFO - 2023-03-15 07:09:53 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:53 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:53 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:09:53 --> Config Class Initialized
INFO - 2023-03-15 07:09:53 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:09:53 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:09:53 --> Utf8 Class Initialized
INFO - 2023-03-15 07:09:53 --> URI Class Initialized
INFO - 2023-03-15 07:09:53 --> Router Class Initialized
INFO - 2023-03-15 07:09:53 --> Output Class Initialized
INFO - 2023-03-15 07:09:53 --> Security Class Initialized
DEBUG - 2023-03-15 07:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:09:53 --> Input Class Initialized
INFO - 2023-03-15 07:09:53 --> Language Class Initialized
INFO - 2023-03-15 07:09:53 --> Loader Class Initialized
INFO - 2023-03-15 07:09:53 --> Controller Class Initialized
DEBUG - 2023-03-15 07:09:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:09:53 --> Database Driver Class Initialized
INFO - 2023-03-15 07:09:53 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:10:06 --> Config Class Initialized
INFO - 2023-03-15 07:10:06 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:10:06 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:10:06 --> Utf8 Class Initialized
INFO - 2023-03-15 07:10:06 --> URI Class Initialized
INFO - 2023-03-15 07:10:06 --> Router Class Initialized
INFO - 2023-03-15 07:10:06 --> Output Class Initialized
INFO - 2023-03-15 07:10:06 --> Security Class Initialized
DEBUG - 2023-03-15 07:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:10:06 --> Input Class Initialized
INFO - 2023-03-15 07:10:06 --> Language Class Initialized
INFO - 2023-03-15 07:10:06 --> Loader Class Initialized
INFO - 2023-03-15 07:10:06 --> Controller Class Initialized
DEBUG - 2023-03-15 07:10:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-03-15 07:10:06 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 231
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-03-15 07:10:06 --> Config Class Initialized
INFO - 2023-03-15 07:10:06 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:10:06 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:10:06 --> Utf8 Class Initialized
INFO - 2023-03-15 07:10:06 --> URI Class Initialized
INFO - 2023-03-15 07:10:06 --> Router Class Initialized
INFO - 2023-03-15 07:10:06 --> Output Class Initialized
INFO - 2023-03-15 07:10:06 --> Security Class Initialized
DEBUG - 2023-03-15 07:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:10:06 --> Input Class Initialized
INFO - 2023-03-15 07:10:06 --> Language Class Initialized
INFO - 2023-03-15 07:10:06 --> Loader Class Initialized
INFO - 2023-03-15 07:10:06 --> Controller Class Initialized
DEBUG - 2023-03-15 07:10:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:10:06 --> Database Driver Class Initialized
INFO - 2023-03-15 07:10:06 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:10:06 --> Final output sent to browser
DEBUG - 2023-03-15 07:10:06 --> Total execution time: 0.0157
INFO - 2023-03-15 07:10:07 --> Config Class Initialized
INFO - 2023-03-15 07:10:07 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:10:07 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:10:07 --> Utf8 Class Initialized
INFO - 2023-03-15 07:10:07 --> URI Class Initialized
INFO - 2023-03-15 07:10:07 --> Router Class Initialized
INFO - 2023-03-15 07:10:07 --> Output Class Initialized
INFO - 2023-03-15 07:10:07 --> Security Class Initialized
DEBUG - 2023-03-15 07:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:10:07 --> Input Class Initialized
INFO - 2023-03-15 07:10:07 --> Language Class Initialized
INFO - 2023-03-15 07:10:07 --> Loader Class Initialized
INFO - 2023-03-15 07:10:07 --> Controller Class Initialized
DEBUG - 2023-03-15 07:10:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:10:07 --> Final output sent to browser
DEBUG - 2023-03-15 07:10:07 --> Total execution time: 0.0021
INFO - 2023-03-15 07:10:07 --> Config Class Initialized
INFO - 2023-03-15 07:10:07 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:10:07 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:10:07 --> Utf8 Class Initialized
INFO - 2023-03-15 07:10:07 --> URI Class Initialized
INFO - 2023-03-15 07:10:07 --> Router Class Initialized
INFO - 2023-03-15 07:10:07 --> Output Class Initialized
INFO - 2023-03-15 07:10:07 --> Security Class Initialized
DEBUG - 2023-03-15 07:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:10:07 --> Input Class Initialized
INFO - 2023-03-15 07:10:07 --> Language Class Initialized
INFO - 2023-03-15 07:10:07 --> Loader Class Initialized
INFO - 2023-03-15 07:10:07 --> Controller Class Initialized
DEBUG - 2023-03-15 07:10:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:10:07 --> Database Driver Class Initialized
INFO - 2023-03-15 07:10:07 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:10:07 --> Final output sent to browser
DEBUG - 2023-03-15 07:10:07 --> Total execution time: 0.0164
INFO - 2023-03-15 07:10:16 --> Config Class Initialized
INFO - 2023-03-15 07:10:16 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:10:16 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:10:16 --> Utf8 Class Initialized
INFO - 2023-03-15 07:10:16 --> URI Class Initialized
INFO - 2023-03-15 07:10:16 --> Router Class Initialized
INFO - 2023-03-15 07:10:16 --> Output Class Initialized
INFO - 2023-03-15 07:10:16 --> Security Class Initialized
DEBUG - 2023-03-15 07:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:10:16 --> Input Class Initialized
INFO - 2023-03-15 07:10:16 --> Language Class Initialized
INFO - 2023-03-15 07:10:16 --> Loader Class Initialized
INFO - 2023-03-15 07:10:16 --> Controller Class Initialized
DEBUG - 2023-03-15 07:10:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:10:16 --> Database Driver Class Initialized
INFO - 2023-03-15 07:10:16 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:10:17 --> Config Class Initialized
INFO - 2023-03-15 07:10:17 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:10:17 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:10:17 --> Utf8 Class Initialized
INFO - 2023-03-15 07:10:17 --> URI Class Initialized
INFO - 2023-03-15 07:10:17 --> Router Class Initialized
INFO - 2023-03-15 07:10:17 --> Output Class Initialized
INFO - 2023-03-15 07:10:17 --> Security Class Initialized
DEBUG - 2023-03-15 07:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:10:17 --> Input Class Initialized
INFO - 2023-03-15 07:10:17 --> Language Class Initialized
INFO - 2023-03-15 07:10:17 --> Loader Class Initialized
INFO - 2023-03-15 07:10:17 --> Controller Class Initialized
DEBUG - 2023-03-15 07:10:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:10:17 --> Database Driver Class Initialized
INFO - 2023-03-15 07:10:17 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:10:39 --> Config Class Initialized
INFO - 2023-03-15 07:10:39 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:10:39 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:10:39 --> Utf8 Class Initialized
INFO - 2023-03-15 07:10:39 --> URI Class Initialized
INFO - 2023-03-15 07:10:39 --> Router Class Initialized
INFO - 2023-03-15 07:10:39 --> Output Class Initialized
INFO - 2023-03-15 07:10:39 --> Security Class Initialized
DEBUG - 2023-03-15 07:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:10:39 --> Input Class Initialized
INFO - 2023-03-15 07:10:39 --> Language Class Initialized
INFO - 2023-03-15 07:10:39 --> Loader Class Initialized
INFO - 2023-03-15 07:10:39 --> Controller Class Initialized
DEBUG - 2023-03-15 07:10:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-03-15 07:10:39 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 231
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-03-15 07:10:39 --> Config Class Initialized
INFO - 2023-03-15 07:10:39 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:10:39 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:10:39 --> Utf8 Class Initialized
INFO - 2023-03-15 07:10:39 --> URI Class Initialized
INFO - 2023-03-15 07:10:39 --> Router Class Initialized
INFO - 2023-03-15 07:10:39 --> Output Class Initialized
INFO - 2023-03-15 07:10:39 --> Security Class Initialized
DEBUG - 2023-03-15 07:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:10:39 --> Input Class Initialized
INFO - 2023-03-15 07:10:39 --> Language Class Initialized
INFO - 2023-03-15 07:10:39 --> Loader Class Initialized
INFO - 2023-03-15 07:10:39 --> Controller Class Initialized
DEBUG - 2023-03-15 07:10:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:10:39 --> Database Driver Class Initialized
INFO - 2023-03-15 07:10:39 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:10:39 --> Final output sent to browser
DEBUG - 2023-03-15 07:10:39 --> Total execution time: 0.0178
INFO - 2023-03-15 07:10:40 --> Config Class Initialized
INFO - 2023-03-15 07:10:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:10:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:10:40 --> Utf8 Class Initialized
INFO - 2023-03-15 07:10:40 --> URI Class Initialized
INFO - 2023-03-15 07:10:40 --> Router Class Initialized
INFO - 2023-03-15 07:10:40 --> Output Class Initialized
INFO - 2023-03-15 07:10:40 --> Security Class Initialized
DEBUG - 2023-03-15 07:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:10:40 --> Input Class Initialized
INFO - 2023-03-15 07:10:40 --> Language Class Initialized
INFO - 2023-03-15 07:10:40 --> Loader Class Initialized
INFO - 2023-03-15 07:10:40 --> Controller Class Initialized
DEBUG - 2023-03-15 07:10:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:10:40 --> Final output sent to browser
DEBUG - 2023-03-15 07:10:40 --> Total execution time: 0.0040
INFO - 2023-03-15 07:10:40 --> Config Class Initialized
INFO - 2023-03-15 07:10:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:10:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:10:40 --> Utf8 Class Initialized
INFO - 2023-03-15 07:10:40 --> URI Class Initialized
INFO - 2023-03-15 07:10:40 --> Router Class Initialized
INFO - 2023-03-15 07:10:40 --> Output Class Initialized
INFO - 2023-03-15 07:10:40 --> Security Class Initialized
DEBUG - 2023-03-15 07:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:10:40 --> Input Class Initialized
INFO - 2023-03-15 07:10:40 --> Language Class Initialized
INFO - 2023-03-15 07:10:40 --> Loader Class Initialized
INFO - 2023-03-15 07:10:40 --> Controller Class Initialized
DEBUG - 2023-03-15 07:10:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:10:40 --> Database Driver Class Initialized
INFO - 2023-03-15 07:10:40 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:10:40 --> Final output sent to browser
DEBUG - 2023-03-15 07:10:40 --> Total execution time: 0.0210
INFO - 2023-03-15 07:14:37 --> Config Class Initialized
INFO - 2023-03-15 07:14:37 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:37 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:37 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:37 --> URI Class Initialized
INFO - 2023-03-15 07:14:37 --> Router Class Initialized
INFO - 2023-03-15 07:14:37 --> Output Class Initialized
INFO - 2023-03-15 07:14:37 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:37 --> Input Class Initialized
INFO - 2023-03-15 07:14:37 --> Language Class Initialized
INFO - 2023-03-15 07:14:37 --> Loader Class Initialized
INFO - 2023-03-15 07:14:37 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:37 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:38 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:14:38 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:38 --> Model "Login_model" initialized
INFO - 2023-03-15 07:14:38 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:38 --> Total execution time: 1.0803
INFO - 2023-03-15 07:14:38 --> Config Class Initialized
INFO - 2023-03-15 07:14:38 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:38 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:38 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:38 --> URI Class Initialized
INFO - 2023-03-15 07:14:38 --> Router Class Initialized
INFO - 2023-03-15 07:14:38 --> Output Class Initialized
INFO - 2023-03-15 07:14:38 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:38 --> Input Class Initialized
INFO - 2023-03-15 07:14:38 --> Language Class Initialized
INFO - 2023-03-15 07:14:38 --> Loader Class Initialized
INFO - 2023-03-15 07:14:38 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:38 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:38 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:14:38 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:38 --> Model "Login_model" initialized
INFO - 2023-03-15 07:14:38 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:38 --> Total execution time: 0.0628
INFO - 2023-03-15 07:14:44 --> Config Class Initialized
INFO - 2023-03-15 07:14:44 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:44 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:44 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:44 --> URI Class Initialized
INFO - 2023-03-15 07:14:44 --> Router Class Initialized
INFO - 2023-03-15 07:14:44 --> Output Class Initialized
INFO - 2023-03-15 07:14:44 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:44 --> Input Class Initialized
INFO - 2023-03-15 07:14:44 --> Language Class Initialized
INFO - 2023-03-15 07:14:44 --> Loader Class Initialized
INFO - 2023-03-15 07:14:44 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:44 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:44 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:14:44 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:44 --> Total execution time: 0.0538
INFO - 2023-03-15 07:14:44 --> Config Class Initialized
INFO - 2023-03-15 07:14:44 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:44 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:44 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:44 --> URI Class Initialized
INFO - 2023-03-15 07:14:44 --> Router Class Initialized
INFO - 2023-03-15 07:14:44 --> Output Class Initialized
INFO - 2023-03-15 07:14:44 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:44 --> Input Class Initialized
INFO - 2023-03-15 07:14:44 --> Language Class Initialized
INFO - 2023-03-15 07:14:44 --> Loader Class Initialized
INFO - 2023-03-15 07:14:44 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:44 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:44 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:14:44 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:44 --> Total execution time: 0.0855
INFO - 2023-03-15 07:14:47 --> Config Class Initialized
INFO - 2023-03-15 07:14:47 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:47 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:47 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:47 --> URI Class Initialized
INFO - 2023-03-15 07:14:47 --> Router Class Initialized
INFO - 2023-03-15 07:14:47 --> Output Class Initialized
INFO - 2023-03-15 07:14:47 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:47 --> Input Class Initialized
INFO - 2023-03-15 07:14:47 --> Language Class Initialized
INFO - 2023-03-15 07:14:47 --> Loader Class Initialized
INFO - 2023-03-15 07:14:47 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:47 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:47 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:14:47 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:47 --> Total execution time: 0.0171
INFO - 2023-03-15 07:14:47 --> Config Class Initialized
INFO - 2023-03-15 07:14:47 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:47 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:47 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:47 --> URI Class Initialized
INFO - 2023-03-15 07:14:47 --> Router Class Initialized
INFO - 2023-03-15 07:14:47 --> Output Class Initialized
INFO - 2023-03-15 07:14:47 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:47 --> Input Class Initialized
INFO - 2023-03-15 07:14:47 --> Language Class Initialized
INFO - 2023-03-15 07:14:47 --> Loader Class Initialized
INFO - 2023-03-15 07:14:47 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:47 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:47 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:14:47 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:47 --> Total execution time: 0.0546
INFO - 2023-03-15 07:14:49 --> Config Class Initialized
INFO - 2023-03-15 07:14:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:49 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:49 --> URI Class Initialized
INFO - 2023-03-15 07:14:49 --> Router Class Initialized
INFO - 2023-03-15 07:14:49 --> Output Class Initialized
INFO - 2023-03-15 07:14:49 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:49 --> Input Class Initialized
INFO - 2023-03-15 07:14:49 --> Language Class Initialized
INFO - 2023-03-15 07:14:49 --> Loader Class Initialized
INFO - 2023-03-15 07:14:49 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:49 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:14:49 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:49 --> Total execution time: 0.1368
INFO - 2023-03-15 07:14:49 --> Config Class Initialized
INFO - 2023-03-15 07:14:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:49 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:49 --> URI Class Initialized
INFO - 2023-03-15 07:14:49 --> Router Class Initialized
INFO - 2023-03-15 07:14:49 --> Output Class Initialized
INFO - 2023-03-15 07:14:49 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:49 --> Input Class Initialized
INFO - 2023-03-15 07:14:49 --> Language Class Initialized
INFO - 2023-03-15 07:14:49 --> Loader Class Initialized
INFO - 2023-03-15 07:14:49 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:49 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:14:49 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:49 --> Total execution time: 0.1464
INFO - 2023-03-15 07:14:52 --> Config Class Initialized
INFO - 2023-03-15 07:14:52 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:52 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:52 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:52 --> URI Class Initialized
INFO - 2023-03-15 07:14:52 --> Router Class Initialized
INFO - 2023-03-15 07:14:52 --> Output Class Initialized
INFO - 2023-03-15 07:14:52 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:52 --> Input Class Initialized
INFO - 2023-03-15 07:14:52 --> Language Class Initialized
INFO - 2023-03-15 07:14:52 --> Loader Class Initialized
INFO - 2023-03-15 07:14:52 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:52 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:52 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:14:52 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:52 --> Model "Login_model" initialized
INFO - 2023-03-15 07:14:52 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:52 --> Total execution time: 0.0421
INFO - 2023-03-15 07:14:52 --> Config Class Initialized
INFO - 2023-03-15 07:14:52 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:52 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:52 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:52 --> URI Class Initialized
INFO - 2023-03-15 07:14:52 --> Router Class Initialized
INFO - 2023-03-15 07:14:52 --> Output Class Initialized
INFO - 2023-03-15 07:14:52 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:52 --> Input Class Initialized
INFO - 2023-03-15 07:14:52 --> Language Class Initialized
INFO - 2023-03-15 07:14:52 --> Loader Class Initialized
INFO - 2023-03-15 07:14:52 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:52 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:52 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:14:52 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:52 --> Model "Login_model" initialized
INFO - 2023-03-15 07:14:52 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:52 --> Total execution time: 0.0452
INFO - 2023-03-15 07:14:55 --> Config Class Initialized
INFO - 2023-03-15 07:14:55 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:55 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:55 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:55 --> URI Class Initialized
INFO - 2023-03-15 07:14:55 --> Router Class Initialized
INFO - 2023-03-15 07:14:55 --> Output Class Initialized
INFO - 2023-03-15 07:14:55 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:55 --> Input Class Initialized
INFO - 2023-03-15 07:14:55 --> Language Class Initialized
INFO - 2023-03-15 07:14:55 --> Loader Class Initialized
INFO - 2023-03-15 07:14:55 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:55 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:55 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:55 --> Model "Login_model" initialized
INFO - 2023-03-15 07:14:55 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:55 --> Total execution time: 0.0498
INFO - 2023-03-15 07:14:55 --> Config Class Initialized
INFO - 2023-03-15 07:14:55 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:55 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:55 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:55 --> URI Class Initialized
INFO - 2023-03-15 07:14:55 --> Router Class Initialized
INFO - 2023-03-15 07:14:55 --> Output Class Initialized
INFO - 2023-03-15 07:14:55 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:55 --> Input Class Initialized
INFO - 2023-03-15 07:14:55 --> Language Class Initialized
INFO - 2023-03-15 07:14:55 --> Loader Class Initialized
INFO - 2023-03-15 07:14:55 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:55 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:55 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:55 --> Model "Login_model" initialized
INFO - 2023-03-15 07:14:55 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:55 --> Total execution time: 0.0223
INFO - 2023-03-15 07:14:55 --> Config Class Initialized
INFO - 2023-03-15 07:14:55 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:55 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:55 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:55 --> URI Class Initialized
INFO - 2023-03-15 07:14:55 --> Router Class Initialized
INFO - 2023-03-15 07:14:55 --> Output Class Initialized
INFO - 2023-03-15 07:14:55 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:55 --> Input Class Initialized
INFO - 2023-03-15 07:14:55 --> Language Class Initialized
INFO - 2023-03-15 07:14:55 --> Loader Class Initialized
INFO - 2023-03-15 07:14:55 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:55 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:55 --> Total execution time: 0.0480
INFO - 2023-03-15 07:14:55 --> Config Class Initialized
INFO - 2023-03-15 07:14:55 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:55 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:55 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:55 --> URI Class Initialized
INFO - 2023-03-15 07:14:55 --> Router Class Initialized
INFO - 2023-03-15 07:14:55 --> Output Class Initialized
INFO - 2023-03-15 07:14:55 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:55 --> Input Class Initialized
INFO - 2023-03-15 07:14:55 --> Language Class Initialized
INFO - 2023-03-15 07:14:55 --> Loader Class Initialized
INFO - 2023-03-15 07:14:55 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:56 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:56 --> Total execution time: 0.0562
INFO - 2023-03-15 07:14:58 --> Config Class Initialized
INFO - 2023-03-15 07:14:58 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:58 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:58 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:58 --> URI Class Initialized
INFO - 2023-03-15 07:14:58 --> Router Class Initialized
INFO - 2023-03-15 07:14:58 --> Output Class Initialized
INFO - 2023-03-15 07:14:58 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:58 --> Input Class Initialized
INFO - 2023-03-15 07:14:58 --> Language Class Initialized
INFO - 2023-03-15 07:14:58 --> Loader Class Initialized
INFO - 2023-03-15 07:14:58 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:58 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:58 --> Config Class Initialized
INFO - 2023-03-15 07:14:58 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:58 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:58 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:58 --> URI Class Initialized
INFO - 2023-03-15 07:14:58 --> Router Class Initialized
INFO - 2023-03-15 07:14:58 --> Output Class Initialized
INFO - 2023-03-15 07:14:58 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:58 --> Input Class Initialized
INFO - 2023-03-15 07:14:58 --> Language Class Initialized
INFO - 2023-03-15 07:14:58 --> Loader Class Initialized
INFO - 2023-03-15 07:14:58 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:58 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:58 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:14:58 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:14:58 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:58 --> Total execution time: 0.0512
INFO - 2023-03-15 07:14:58 --> Config Class Initialized
INFO - 2023-03-15 07:14:58 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:58 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:58 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:58 --> URI Class Initialized
INFO - 2023-03-15 07:14:58 --> Router Class Initialized
INFO - 2023-03-15 07:14:58 --> Output Class Initialized
INFO - 2023-03-15 07:14:58 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:58 --> Input Class Initialized
INFO - 2023-03-15 07:14:58 --> Language Class Initialized
INFO - 2023-03-15 07:14:58 --> Loader Class Initialized
INFO - 2023-03-15 07:14:58 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:58 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:58 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:14:58 --> Final output sent to browser
DEBUG - 2023-03-15 07:14:58 --> Total execution time: 0.0540
INFO - 2023-03-15 07:14:58 --> Config Class Initialized
INFO - 2023-03-15 07:14:58 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:14:58 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:14:58 --> Utf8 Class Initialized
INFO - 2023-03-15 07:14:58 --> URI Class Initialized
INFO - 2023-03-15 07:14:58 --> Router Class Initialized
INFO - 2023-03-15 07:14:58 --> Output Class Initialized
INFO - 2023-03-15 07:14:58 --> Security Class Initialized
DEBUG - 2023-03-15 07:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:14:58 --> Input Class Initialized
INFO - 2023-03-15 07:14:58 --> Language Class Initialized
INFO - 2023-03-15 07:14:58 --> Loader Class Initialized
INFO - 2023-03-15 07:14:58 --> Controller Class Initialized
DEBUG - 2023-03-15 07:14:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:14:58 --> Database Driver Class Initialized
INFO - 2023-03-15 07:14:58 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:15:00 --> Config Class Initialized
INFO - 2023-03-15 07:15:00 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:15:00 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:15:00 --> Utf8 Class Initialized
INFO - 2023-03-15 07:15:00 --> URI Class Initialized
INFO - 2023-03-15 07:15:00 --> Router Class Initialized
INFO - 2023-03-15 07:15:00 --> Output Class Initialized
INFO - 2023-03-15 07:15:00 --> Security Class Initialized
DEBUG - 2023-03-15 07:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:15:00 --> Input Class Initialized
INFO - 2023-03-15 07:15:00 --> Language Class Initialized
INFO - 2023-03-15 07:15:00 --> Loader Class Initialized
INFO - 2023-03-15 07:15:00 --> Controller Class Initialized
DEBUG - 2023-03-15 07:15:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:15:00 --> Database Driver Class Initialized
INFO - 2023-03-15 07:15:00 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:15:00 --> Config Class Initialized
INFO - 2023-03-15 07:15:00 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:15:00 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:15:00 --> Utf8 Class Initialized
INFO - 2023-03-15 07:15:00 --> URI Class Initialized
INFO - 2023-03-15 07:15:00 --> Router Class Initialized
INFO - 2023-03-15 07:15:00 --> Output Class Initialized
INFO - 2023-03-15 07:15:00 --> Security Class Initialized
DEBUG - 2023-03-15 07:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:15:00 --> Input Class Initialized
INFO - 2023-03-15 07:15:00 --> Language Class Initialized
INFO - 2023-03-15 07:15:00 --> Loader Class Initialized
INFO - 2023-03-15 07:15:00 --> Controller Class Initialized
DEBUG - 2023-03-15 07:15:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:15:00 --> Database Driver Class Initialized
INFO - 2023-03-15 07:15:00 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:15:25 --> Config Class Initialized
INFO - 2023-03-15 07:15:25 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:15:25 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:15:25 --> Utf8 Class Initialized
INFO - 2023-03-15 07:15:25 --> URI Class Initialized
INFO - 2023-03-15 07:15:25 --> Router Class Initialized
INFO - 2023-03-15 07:15:25 --> Output Class Initialized
INFO - 2023-03-15 07:15:25 --> Security Class Initialized
DEBUG - 2023-03-15 07:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:15:25 --> Input Class Initialized
INFO - 2023-03-15 07:15:25 --> Language Class Initialized
INFO - 2023-03-15 07:15:25 --> Loader Class Initialized
INFO - 2023-03-15 07:15:25 --> Controller Class Initialized
DEBUG - 2023-03-15 07:15:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:15:25 --> Database Driver Class Initialized
INFO - 2023-03-15 07:15:25 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:15:25 --> Config Class Initialized
INFO - 2023-03-15 07:15:25 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:15:25 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:15:25 --> Utf8 Class Initialized
INFO - 2023-03-15 07:15:25 --> URI Class Initialized
INFO - 2023-03-15 07:15:25 --> Router Class Initialized
INFO - 2023-03-15 07:15:25 --> Output Class Initialized
INFO - 2023-03-15 07:15:25 --> Security Class Initialized
DEBUG - 2023-03-15 07:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:15:25 --> Input Class Initialized
INFO - 2023-03-15 07:15:25 --> Language Class Initialized
INFO - 2023-03-15 07:15:25 --> Loader Class Initialized
INFO - 2023-03-15 07:15:25 --> Controller Class Initialized
DEBUG - 2023-03-15 07:15:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:15:25 --> Database Driver Class Initialized
INFO - 2023-03-15 07:15:25 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:15:28 --> Config Class Initialized
INFO - 2023-03-15 07:15:28 --> Config Class Initialized
INFO - 2023-03-15 07:15:28 --> Hooks Class Initialized
INFO - 2023-03-15 07:15:28 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:15:28 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:15:28 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:15:28 --> Utf8 Class Initialized
INFO - 2023-03-15 07:15:28 --> Utf8 Class Initialized
INFO - 2023-03-15 07:15:28 --> URI Class Initialized
INFO - 2023-03-15 07:15:28 --> URI Class Initialized
INFO - 2023-03-15 07:15:28 --> Router Class Initialized
INFO - 2023-03-15 07:15:28 --> Router Class Initialized
INFO - 2023-03-15 07:15:28 --> Output Class Initialized
INFO - 2023-03-15 07:15:28 --> Output Class Initialized
INFO - 2023-03-15 07:15:28 --> Security Class Initialized
INFO - 2023-03-15 07:15:28 --> Security Class Initialized
DEBUG - 2023-03-15 07:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:15:28 --> Input Class Initialized
INFO - 2023-03-15 07:15:28 --> Input Class Initialized
INFO - 2023-03-15 07:15:28 --> Language Class Initialized
INFO - 2023-03-15 07:15:28 --> Language Class Initialized
INFO - 2023-03-15 07:15:28 --> Loader Class Initialized
INFO - 2023-03-15 07:15:28 --> Loader Class Initialized
INFO - 2023-03-15 07:15:28 --> Controller Class Initialized
INFO - 2023-03-15 07:15:28 --> Controller Class Initialized
DEBUG - 2023-03-15 07:15:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:15:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:15:28 --> Database Driver Class Initialized
INFO - 2023-03-15 07:15:28 --> Database Driver Class Initialized
INFO - 2023-03-15 07:15:28 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:15:28 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:15:28 --> Final output sent to browser
DEBUG - 2023-03-15 07:15:28 --> Total execution time: 0.0203
INFO - 2023-03-15 07:15:28 --> Config Class Initialized
INFO - 2023-03-15 07:15:28 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:15:28 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:15:28 --> Utf8 Class Initialized
INFO - 2023-03-15 07:15:28 --> URI Class Initialized
INFO - 2023-03-15 07:15:28 --> Router Class Initialized
INFO - 2023-03-15 07:15:28 --> Output Class Initialized
INFO - 2023-03-15 07:15:28 --> Security Class Initialized
DEBUG - 2023-03-15 07:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:15:28 --> Input Class Initialized
INFO - 2023-03-15 07:15:28 --> Language Class Initialized
INFO - 2023-03-15 07:15:28 --> Loader Class Initialized
INFO - 2023-03-15 07:15:28 --> Controller Class Initialized
DEBUG - 2023-03-15 07:15:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:15:28 --> Database Driver Class Initialized
INFO - 2023-03-15 07:15:28 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:15:28 --> Final output sent to browser
DEBUG - 2023-03-15 07:15:28 --> Total execution time: 0.0110
INFO - 2023-03-15 07:15:59 --> Config Class Initialized
INFO - 2023-03-15 07:15:59 --> Config Class Initialized
INFO - 2023-03-15 07:15:59 --> Hooks Class Initialized
INFO - 2023-03-15 07:15:59 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:15:59 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:15:59 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:15:59 --> Utf8 Class Initialized
INFO - 2023-03-15 07:15:59 --> Utf8 Class Initialized
INFO - 2023-03-15 07:15:59 --> URI Class Initialized
INFO - 2023-03-15 07:15:59 --> URI Class Initialized
INFO - 2023-03-15 07:15:59 --> Router Class Initialized
INFO - 2023-03-15 07:15:59 --> Router Class Initialized
INFO - 2023-03-15 07:15:59 --> Output Class Initialized
INFO - 2023-03-15 07:15:59 --> Output Class Initialized
INFO - 2023-03-15 07:15:59 --> Security Class Initialized
INFO - 2023-03-15 07:15:59 --> Security Class Initialized
DEBUG - 2023-03-15 07:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:15:59 --> Input Class Initialized
INFO - 2023-03-15 07:15:59 --> Input Class Initialized
INFO - 2023-03-15 07:15:59 --> Language Class Initialized
INFO - 2023-03-15 07:15:59 --> Language Class Initialized
INFO - 2023-03-15 07:15:59 --> Loader Class Initialized
INFO - 2023-03-15 07:15:59 --> Loader Class Initialized
INFO - 2023-03-15 07:15:59 --> Controller Class Initialized
INFO - 2023-03-15 07:15:59 --> Controller Class Initialized
DEBUG - 2023-03-15 07:15:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:15:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:15:59 --> Database Driver Class Initialized
INFO - 2023-03-15 07:15:59 --> Database Driver Class Initialized
INFO - 2023-03-15 07:15:59 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:15:59 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:15:59 --> Final output sent to browser
DEBUG - 2023-03-15 07:15:59 --> Total execution time: 0.0151
INFO - 2023-03-15 07:15:59 --> Config Class Initialized
INFO - 2023-03-15 07:15:59 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:15:59 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:15:59 --> Utf8 Class Initialized
INFO - 2023-03-15 07:15:59 --> URI Class Initialized
INFO - 2023-03-15 07:15:59 --> Router Class Initialized
INFO - 2023-03-15 07:15:59 --> Output Class Initialized
INFO - 2023-03-15 07:15:59 --> Security Class Initialized
DEBUG - 2023-03-15 07:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:15:59 --> Input Class Initialized
INFO - 2023-03-15 07:15:59 --> Language Class Initialized
INFO - 2023-03-15 07:15:59 --> Loader Class Initialized
INFO - 2023-03-15 07:15:59 --> Controller Class Initialized
DEBUG - 2023-03-15 07:15:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:15:59 --> Database Driver Class Initialized
INFO - 2023-03-15 07:15:59 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:15:59 --> Final output sent to browser
DEBUG - 2023-03-15 07:15:59 --> Total execution time: 0.0125
INFO - 2023-03-15 07:15:59 --> Config Class Initialized
INFO - 2023-03-15 07:15:59 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:15:59 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:15:59 --> Utf8 Class Initialized
INFO - 2023-03-15 07:15:59 --> URI Class Initialized
INFO - 2023-03-15 07:15:59 --> Router Class Initialized
INFO - 2023-03-15 07:15:59 --> Output Class Initialized
INFO - 2023-03-15 07:15:59 --> Security Class Initialized
DEBUG - 2023-03-15 07:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:15:59 --> Input Class Initialized
INFO - 2023-03-15 07:15:59 --> Language Class Initialized
INFO - 2023-03-15 07:15:59 --> Loader Class Initialized
INFO - 2023-03-15 07:15:59 --> Controller Class Initialized
DEBUG - 2023-03-15 07:15:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:15:59 --> Database Driver Class Initialized
INFO - 2023-03-15 07:15:59 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:01 --> Config Class Initialized
INFO - 2023-03-15 07:16:01 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:01 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:01 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:01 --> URI Class Initialized
INFO - 2023-03-15 07:16:01 --> Router Class Initialized
INFO - 2023-03-15 07:16:01 --> Output Class Initialized
INFO - 2023-03-15 07:16:01 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:01 --> Input Class Initialized
INFO - 2023-03-15 07:16:01 --> Language Class Initialized
INFO - 2023-03-15 07:16:01 --> Loader Class Initialized
INFO - 2023-03-15 07:16:01 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:01 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:01 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:01 --> Config Class Initialized
INFO - 2023-03-15 07:16:01 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:01 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:01 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:01 --> URI Class Initialized
INFO - 2023-03-15 07:16:01 --> Router Class Initialized
INFO - 2023-03-15 07:16:01 --> Output Class Initialized
INFO - 2023-03-15 07:16:01 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:01 --> Input Class Initialized
INFO - 2023-03-15 07:16:01 --> Language Class Initialized
INFO - 2023-03-15 07:16:01 --> Loader Class Initialized
INFO - 2023-03-15 07:16:01 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:01 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:01 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:03 --> Config Class Initialized
INFO - 2023-03-15 07:16:03 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:03 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:03 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:03 --> URI Class Initialized
INFO - 2023-03-15 07:16:03 --> Router Class Initialized
INFO - 2023-03-15 07:16:03 --> Output Class Initialized
INFO - 2023-03-15 07:16:03 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:03 --> Input Class Initialized
INFO - 2023-03-15 07:16:03 --> Language Class Initialized
INFO - 2023-03-15 07:16:03 --> Loader Class Initialized
INFO - 2023-03-15 07:16:03 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:03 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:03 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:03 --> Config Class Initialized
INFO - 2023-03-15 07:16:03 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:03 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:03 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:03 --> URI Class Initialized
INFO - 2023-03-15 07:16:03 --> Router Class Initialized
INFO - 2023-03-15 07:16:03 --> Output Class Initialized
INFO - 2023-03-15 07:16:03 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:03 --> Input Class Initialized
INFO - 2023-03-15 07:16:03 --> Language Class Initialized
INFO - 2023-03-15 07:16:03 --> Loader Class Initialized
INFO - 2023-03-15 07:16:03 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:03 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:03 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:04 --> Config Class Initialized
INFO - 2023-03-15 07:16:04 --> Config Class Initialized
INFO - 2023-03-15 07:16:04 --> Hooks Class Initialized
INFO - 2023-03-15 07:16:04 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:04 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:04 --> Utf8 Class Initialized
DEBUG - 2023-03-15 07:16:04 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:04 --> URI Class Initialized
INFO - 2023-03-15 07:16:04 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:04 --> Router Class Initialized
INFO - 2023-03-15 07:16:04 --> URI Class Initialized
INFO - 2023-03-15 07:16:04 --> Output Class Initialized
INFO - 2023-03-15 07:16:04 --> Router Class Initialized
INFO - 2023-03-15 07:16:04 --> Security Class Initialized
INFO - 2023-03-15 07:16:04 --> Output Class Initialized
DEBUG - 2023-03-15 07:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:04 --> Security Class Initialized
INFO - 2023-03-15 07:16:04 --> Input Class Initialized
DEBUG - 2023-03-15 07:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:04 --> Language Class Initialized
INFO - 2023-03-15 07:16:04 --> Input Class Initialized
INFO - 2023-03-15 07:16:04 --> Language Class Initialized
INFO - 2023-03-15 07:16:04 --> Loader Class Initialized
INFO - 2023-03-15 07:16:04 --> Loader Class Initialized
INFO - 2023-03-15 07:16:04 --> Controller Class Initialized
INFO - 2023-03-15 07:16:04 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:16:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:04 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:04 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:04 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:04 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:04 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:04 --> Total execution time: 0.0223
INFO - 2023-03-15 07:16:04 --> Config Class Initialized
INFO - 2023-03-15 07:16:04 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:04 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:04 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:04 --> URI Class Initialized
INFO - 2023-03-15 07:16:04 --> Router Class Initialized
INFO - 2023-03-15 07:16:04 --> Output Class Initialized
INFO - 2023-03-15 07:16:04 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:04 --> Input Class Initialized
INFO - 2023-03-15 07:16:04 --> Language Class Initialized
INFO - 2023-03-15 07:16:04 --> Loader Class Initialized
INFO - 2023-03-15 07:16:04 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:04 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:04 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:05 --> Config Class Initialized
INFO - 2023-03-15 07:16:05 --> Config Class Initialized
INFO - 2023-03-15 07:16:05 --> Hooks Class Initialized
INFO - 2023-03-15 07:16:05 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:05 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:16:05 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:05 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:05 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:05 --> URI Class Initialized
INFO - 2023-03-15 07:16:05 --> URI Class Initialized
INFO - 2023-03-15 07:16:05 --> Router Class Initialized
INFO - 2023-03-15 07:16:05 --> Router Class Initialized
INFO - 2023-03-15 07:16:05 --> Output Class Initialized
INFO - 2023-03-15 07:16:05 --> Output Class Initialized
INFO - 2023-03-15 07:16:05 --> Security Class Initialized
INFO - 2023-03-15 07:16:05 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:05 --> Input Class Initialized
INFO - 2023-03-15 07:16:05 --> Input Class Initialized
INFO - 2023-03-15 07:16:05 --> Language Class Initialized
INFO - 2023-03-15 07:16:05 --> Language Class Initialized
INFO - 2023-03-15 07:16:05 --> Loader Class Initialized
INFO - 2023-03-15 07:16:05 --> Loader Class Initialized
INFO - 2023-03-15 07:16:05 --> Controller Class Initialized
INFO - 2023-03-15 07:16:05 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:16:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:05 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:05 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:05 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:05 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:05 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:05 --> Total execution time: 0.0186
INFO - 2023-03-15 07:16:05 --> Config Class Initialized
INFO - 2023-03-15 07:16:05 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:05 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:05 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:05 --> URI Class Initialized
INFO - 2023-03-15 07:16:05 --> Router Class Initialized
INFO - 2023-03-15 07:16:05 --> Output Class Initialized
INFO - 2023-03-15 07:16:05 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:05 --> Input Class Initialized
INFO - 2023-03-15 07:16:05 --> Language Class Initialized
INFO - 2023-03-15 07:16:05 --> Loader Class Initialized
INFO - 2023-03-15 07:16:05 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:05 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:05 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:05 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:05 --> Total execution time: 0.0142
INFO - 2023-03-15 07:16:05 --> Config Class Initialized
INFO - 2023-03-15 07:16:05 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:05 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:05 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:05 --> URI Class Initialized
INFO - 2023-03-15 07:16:05 --> Router Class Initialized
INFO - 2023-03-15 07:16:05 --> Output Class Initialized
INFO - 2023-03-15 07:16:05 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:05 --> Input Class Initialized
INFO - 2023-03-15 07:16:05 --> Language Class Initialized
INFO - 2023-03-15 07:16:05 --> Loader Class Initialized
INFO - 2023-03-15 07:16:05 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:05 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:05 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:05 --> Config Class Initialized
INFO - 2023-03-15 07:16:05 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:05 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:05 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:05 --> URI Class Initialized
INFO - 2023-03-15 07:16:05 --> Router Class Initialized
INFO - 2023-03-15 07:16:05 --> Output Class Initialized
INFO - 2023-03-15 07:16:05 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:05 --> Input Class Initialized
INFO - 2023-03-15 07:16:05 --> Language Class Initialized
INFO - 2023-03-15 07:16:05 --> Loader Class Initialized
INFO - 2023-03-15 07:16:05 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:05 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:05 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:05 --> Model "Login_model" initialized
INFO - 2023-03-15 07:16:05 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:05 --> Total execution time: 0.0252
INFO - 2023-03-15 07:16:05 --> Config Class Initialized
INFO - 2023-03-15 07:16:05 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:05 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:05 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:05 --> URI Class Initialized
INFO - 2023-03-15 07:16:05 --> Router Class Initialized
INFO - 2023-03-15 07:16:05 --> Output Class Initialized
INFO - 2023-03-15 07:16:05 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:05 --> Input Class Initialized
INFO - 2023-03-15 07:16:05 --> Language Class Initialized
INFO - 2023-03-15 07:16:05 --> Loader Class Initialized
INFO - 2023-03-15 07:16:05 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:05 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:05 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:05 --> Model "Login_model" initialized
INFO - 2023-03-15 07:16:05 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:05 --> Total execution time: 0.0236
INFO - 2023-03-15 07:16:05 --> Config Class Initialized
INFO - 2023-03-15 07:16:05 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:05 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:05 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:05 --> URI Class Initialized
INFO - 2023-03-15 07:16:05 --> Router Class Initialized
INFO - 2023-03-15 07:16:05 --> Output Class Initialized
INFO - 2023-03-15 07:16:05 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:05 --> Input Class Initialized
INFO - 2023-03-15 07:16:05 --> Language Class Initialized
INFO - 2023-03-15 07:16:05 --> Loader Class Initialized
INFO - 2023-03-15 07:16:05 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:05 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:05 --> Total execution time: 0.0493
INFO - 2023-03-15 07:16:05 --> Config Class Initialized
INFO - 2023-03-15 07:16:05 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:05 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:05 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:05 --> URI Class Initialized
INFO - 2023-03-15 07:16:05 --> Router Class Initialized
INFO - 2023-03-15 07:16:05 --> Output Class Initialized
INFO - 2023-03-15 07:16:05 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:05 --> Input Class Initialized
INFO - 2023-03-15 07:16:05 --> Language Class Initialized
INFO - 2023-03-15 07:16:05 --> Loader Class Initialized
INFO - 2023-03-15 07:16:05 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:05 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:05 --> Total execution time: 0.0522
INFO - 2023-03-15 07:16:10 --> Config Class Initialized
INFO - 2023-03-15 07:16:10 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:10 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:10 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:10 --> URI Class Initialized
INFO - 2023-03-15 07:16:10 --> Router Class Initialized
INFO - 2023-03-15 07:16:10 --> Output Class Initialized
INFO - 2023-03-15 07:16:10 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:10 --> Input Class Initialized
INFO - 2023-03-15 07:16:10 --> Language Class Initialized
INFO - 2023-03-15 07:16:10 --> Loader Class Initialized
INFO - 2023-03-15 07:16:10 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:10 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:10 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:10 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:10 --> Model "Login_model" initialized
INFO - 2023-03-15 07:16:10 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:10 --> Total execution time: 0.0484
INFO - 2023-03-15 07:16:10 --> Config Class Initialized
INFO - 2023-03-15 07:16:10 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:10 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:10 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:10 --> URI Class Initialized
INFO - 2023-03-15 07:16:10 --> Router Class Initialized
INFO - 2023-03-15 07:16:10 --> Output Class Initialized
INFO - 2023-03-15 07:16:10 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:10 --> Input Class Initialized
INFO - 2023-03-15 07:16:10 --> Language Class Initialized
INFO - 2023-03-15 07:16:10 --> Loader Class Initialized
INFO - 2023-03-15 07:16:10 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:10 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:10 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:10 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:10 --> Model "Login_model" initialized
INFO - 2023-03-15 07:16:10 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:10 --> Total execution time: 0.0439
INFO - 2023-03-15 07:16:11 --> Config Class Initialized
INFO - 2023-03-15 07:16:11 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:11 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:11 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:11 --> URI Class Initialized
INFO - 2023-03-15 07:16:11 --> Router Class Initialized
INFO - 2023-03-15 07:16:11 --> Output Class Initialized
INFO - 2023-03-15 07:16:11 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:11 --> Input Class Initialized
INFO - 2023-03-15 07:16:11 --> Language Class Initialized
INFO - 2023-03-15 07:16:11 --> Loader Class Initialized
INFO - 2023-03-15 07:16:11 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:11 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:11 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:11 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:11 --> Total execution time: 0.0154
INFO - 2023-03-15 07:16:11 --> Config Class Initialized
INFO - 2023-03-15 07:16:11 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:11 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:11 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:11 --> URI Class Initialized
INFO - 2023-03-15 07:16:11 --> Router Class Initialized
INFO - 2023-03-15 07:16:11 --> Output Class Initialized
INFO - 2023-03-15 07:16:11 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:11 --> Input Class Initialized
INFO - 2023-03-15 07:16:11 --> Language Class Initialized
INFO - 2023-03-15 07:16:11 --> Loader Class Initialized
INFO - 2023-03-15 07:16:11 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:11 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:11 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:11 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:11 --> Total execution time: 0.0585
INFO - 2023-03-15 07:16:12 --> Config Class Initialized
INFO - 2023-03-15 07:16:12 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:12 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:12 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:12 --> URI Class Initialized
INFO - 2023-03-15 07:16:12 --> Router Class Initialized
INFO - 2023-03-15 07:16:12 --> Output Class Initialized
INFO - 2023-03-15 07:16:12 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:12 --> Input Class Initialized
INFO - 2023-03-15 07:16:12 --> Language Class Initialized
INFO - 2023-03-15 07:16:12 --> Loader Class Initialized
INFO - 2023-03-15 07:16:12 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:12 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:12 --> Total execution time: 0.0461
INFO - 2023-03-15 07:16:12 --> Config Class Initialized
INFO - 2023-03-15 07:16:12 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:12 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:12 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:12 --> URI Class Initialized
INFO - 2023-03-15 07:16:12 --> Router Class Initialized
INFO - 2023-03-15 07:16:12 --> Output Class Initialized
INFO - 2023-03-15 07:16:12 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:12 --> Input Class Initialized
INFO - 2023-03-15 07:16:12 --> Language Class Initialized
INFO - 2023-03-15 07:16:12 --> Loader Class Initialized
INFO - 2023-03-15 07:16:12 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:12 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:12 --> Model "Login_model" initialized
INFO - 2023-03-15 07:16:12 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:12 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:12 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:12 --> Total execution time: 0.0205
INFO - 2023-03-15 07:16:12 --> Config Class Initialized
INFO - 2023-03-15 07:16:12 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:12 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:12 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:12 --> URI Class Initialized
INFO - 2023-03-15 07:16:12 --> Router Class Initialized
INFO - 2023-03-15 07:16:12 --> Output Class Initialized
INFO - 2023-03-15 07:16:12 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:12 --> Input Class Initialized
INFO - 2023-03-15 07:16:12 --> Language Class Initialized
INFO - 2023-03-15 07:16:12 --> Loader Class Initialized
INFO - 2023-03-15 07:16:12 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:12 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:12 --> Total execution time: 0.0423
INFO - 2023-03-15 07:16:12 --> Config Class Initialized
INFO - 2023-03-15 07:16:12 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:12 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:12 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:12 --> URI Class Initialized
INFO - 2023-03-15 07:16:12 --> Router Class Initialized
INFO - 2023-03-15 07:16:12 --> Output Class Initialized
INFO - 2023-03-15 07:16:12 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:12 --> Input Class Initialized
INFO - 2023-03-15 07:16:12 --> Language Class Initialized
INFO - 2023-03-15 07:16:12 --> Loader Class Initialized
INFO - 2023-03-15 07:16:12 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:12 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:12 --> Model "Login_model" initialized
INFO - 2023-03-15 07:16:12 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:12 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:12 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:12 --> Total execution time: 0.0205
INFO - 2023-03-15 07:16:12 --> Config Class Initialized
INFO - 2023-03-15 07:16:12 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:12 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:12 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:12 --> URI Class Initialized
INFO - 2023-03-15 07:16:12 --> Router Class Initialized
INFO - 2023-03-15 07:16:12 --> Output Class Initialized
INFO - 2023-03-15 07:16:12 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:12 --> Input Class Initialized
INFO - 2023-03-15 07:16:12 --> Language Class Initialized
INFO - 2023-03-15 07:16:12 --> Loader Class Initialized
INFO - 2023-03-15 07:16:12 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:12 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:12 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:12 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:12 --> Model "Login_model" initialized
INFO - 2023-03-15 07:16:12 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:12 --> Total execution time: 0.0442
INFO - 2023-03-15 07:16:14 --> Config Class Initialized
INFO - 2023-03-15 07:16:14 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:14 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:14 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:14 --> URI Class Initialized
INFO - 2023-03-15 07:16:14 --> Router Class Initialized
INFO - 2023-03-15 07:16:14 --> Output Class Initialized
INFO - 2023-03-15 07:16:14 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:14 --> Input Class Initialized
INFO - 2023-03-15 07:16:14 --> Language Class Initialized
INFO - 2023-03-15 07:16:14 --> Loader Class Initialized
INFO - 2023-03-15 07:16:14 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:14 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:14 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:14 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:14 --> Total execution time: 0.0164
INFO - 2023-03-15 07:16:14 --> Config Class Initialized
INFO - 2023-03-15 07:16:14 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:14 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:14 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:14 --> URI Class Initialized
INFO - 2023-03-15 07:16:14 --> Router Class Initialized
INFO - 2023-03-15 07:16:14 --> Output Class Initialized
INFO - 2023-03-15 07:16:14 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:14 --> Input Class Initialized
INFO - 2023-03-15 07:16:14 --> Language Class Initialized
INFO - 2023-03-15 07:16:14 --> Loader Class Initialized
INFO - 2023-03-15 07:16:14 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:14 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:14 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:14 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:14 --> Total execution time: 0.0149
INFO - 2023-03-15 07:16:26 --> Config Class Initialized
INFO - 2023-03-15 07:16:26 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:26 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:26 --> URI Class Initialized
INFO - 2023-03-15 07:16:26 --> Router Class Initialized
INFO - 2023-03-15 07:16:26 --> Output Class Initialized
INFO - 2023-03-15 07:16:26 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:26 --> Input Class Initialized
INFO - 2023-03-15 07:16:26 --> Language Class Initialized
INFO - 2023-03-15 07:16:26 --> Loader Class Initialized
INFO - 2023-03-15 07:16:26 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:26 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:26 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:26 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:26 --> Model "Login_model" initialized
INFO - 2023-03-15 07:16:26 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:26 --> Total execution time: 0.0796
INFO - 2023-03-15 07:16:26 --> Config Class Initialized
INFO - 2023-03-15 07:16:26 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:26 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:26 --> URI Class Initialized
INFO - 2023-03-15 07:16:26 --> Router Class Initialized
INFO - 2023-03-15 07:16:26 --> Output Class Initialized
INFO - 2023-03-15 07:16:26 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:26 --> Input Class Initialized
INFO - 2023-03-15 07:16:26 --> Language Class Initialized
INFO - 2023-03-15 07:16:26 --> Loader Class Initialized
INFO - 2023-03-15 07:16:26 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:26 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:26 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:26 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:26 --> Model "Login_model" initialized
INFO - 2023-03-15 07:16:26 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:26 --> Total execution time: 0.1678
INFO - 2023-03-15 07:16:29 --> Config Class Initialized
INFO - 2023-03-15 07:16:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:29 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:29 --> URI Class Initialized
INFO - 2023-03-15 07:16:29 --> Router Class Initialized
INFO - 2023-03-15 07:16:29 --> Output Class Initialized
INFO - 2023-03-15 07:16:29 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:29 --> Input Class Initialized
INFO - 2023-03-15 07:16:29 --> Language Class Initialized
INFO - 2023-03-15 07:16:29 --> Loader Class Initialized
INFO - 2023-03-15 07:16:29 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:29 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:29 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:29 --> Model "Login_model" initialized
INFO - 2023-03-15 07:16:29 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:29 --> Total execution time: 0.0479
INFO - 2023-03-15 07:16:29 --> Config Class Initialized
INFO - 2023-03-15 07:16:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:29 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:29 --> URI Class Initialized
INFO - 2023-03-15 07:16:29 --> Router Class Initialized
INFO - 2023-03-15 07:16:29 --> Output Class Initialized
INFO - 2023-03-15 07:16:29 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:29 --> Input Class Initialized
INFO - 2023-03-15 07:16:29 --> Language Class Initialized
INFO - 2023-03-15 07:16:29 --> Loader Class Initialized
INFO - 2023-03-15 07:16:29 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:29 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:29 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:29 --> Model "Login_model" initialized
INFO - 2023-03-15 07:16:29 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:29 --> Total execution time: 0.0629
INFO - 2023-03-15 07:16:29 --> Config Class Initialized
INFO - 2023-03-15 07:16:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:29 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:29 --> URI Class Initialized
INFO - 2023-03-15 07:16:29 --> Router Class Initialized
INFO - 2023-03-15 07:16:29 --> Output Class Initialized
INFO - 2023-03-15 07:16:29 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:29 --> Input Class Initialized
INFO - 2023-03-15 07:16:29 --> Language Class Initialized
INFO - 2023-03-15 07:16:29 --> Loader Class Initialized
INFO - 2023-03-15 07:16:29 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:29 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:29 --> Total execution time: 0.0487
INFO - 2023-03-15 07:16:29 --> Config Class Initialized
INFO - 2023-03-15 07:16:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:29 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:29 --> URI Class Initialized
INFO - 2023-03-15 07:16:29 --> Router Class Initialized
INFO - 2023-03-15 07:16:29 --> Output Class Initialized
INFO - 2023-03-15 07:16:29 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:29 --> Input Class Initialized
INFO - 2023-03-15 07:16:29 --> Language Class Initialized
INFO - 2023-03-15 07:16:29 --> Loader Class Initialized
INFO - 2023-03-15 07:16:29 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:29 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:29 --> Total execution time: 0.0667
INFO - 2023-03-15 07:16:30 --> Config Class Initialized
INFO - 2023-03-15 07:16:30 --> Config Class Initialized
INFO - 2023-03-15 07:16:30 --> Hooks Class Initialized
INFO - 2023-03-15 07:16:30 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:30 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:16:30 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:30 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:30 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:30 --> URI Class Initialized
INFO - 2023-03-15 07:16:30 --> URI Class Initialized
INFO - 2023-03-15 07:16:30 --> Router Class Initialized
INFO - 2023-03-15 07:16:30 --> Output Class Initialized
INFO - 2023-03-15 07:16:30 --> Router Class Initialized
INFO - 2023-03-15 07:16:30 --> Security Class Initialized
INFO - 2023-03-15 07:16:30 --> Output Class Initialized
DEBUG - 2023-03-15 07:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:30 --> Security Class Initialized
INFO - 2023-03-15 07:16:30 --> Input Class Initialized
DEBUG - 2023-03-15 07:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:30 --> Language Class Initialized
INFO - 2023-03-15 07:16:30 --> Input Class Initialized
INFO - 2023-03-15 07:16:30 --> Language Class Initialized
INFO - 2023-03-15 07:16:30 --> Loader Class Initialized
INFO - 2023-03-15 07:16:30 --> Loader Class Initialized
INFO - 2023-03-15 07:16:30 --> Controller Class Initialized
INFO - 2023-03-15 07:16:30 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:16:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:30 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:30 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:30 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:30 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:30 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:30 --> Total execution time: 0.0160
INFO - 2023-03-15 07:16:30 --> Config Class Initialized
INFO - 2023-03-15 07:16:30 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:30 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:30 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:30 --> URI Class Initialized
INFO - 2023-03-15 07:16:30 --> Router Class Initialized
INFO - 2023-03-15 07:16:30 --> Output Class Initialized
INFO - 2023-03-15 07:16:30 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:30 --> Input Class Initialized
INFO - 2023-03-15 07:16:30 --> Language Class Initialized
INFO - 2023-03-15 07:16:30 --> Loader Class Initialized
INFO - 2023-03-15 07:16:30 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:30 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:30 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:30 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:30 --> Total execution time: 0.1331
INFO - 2023-03-15 07:16:30 --> Config Class Initialized
INFO - 2023-03-15 07:16:30 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:30 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:30 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:30 --> URI Class Initialized
INFO - 2023-03-15 07:16:30 --> Router Class Initialized
INFO - 2023-03-15 07:16:30 --> Output Class Initialized
INFO - 2023-03-15 07:16:30 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:30 --> Input Class Initialized
INFO - 2023-03-15 07:16:30 --> Language Class Initialized
INFO - 2023-03-15 07:16:30 --> Loader Class Initialized
INFO - 2023-03-15 07:16:30 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:30 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:30 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:33 --> Config Class Initialized
INFO - 2023-03-15 07:16:33 --> Config Class Initialized
INFO - 2023-03-15 07:16:33 --> Hooks Class Initialized
INFO - 2023-03-15 07:16:33 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:33 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:16:33 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:33 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:33 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:33 --> URI Class Initialized
INFO - 2023-03-15 07:16:33 --> URI Class Initialized
INFO - 2023-03-15 07:16:33 --> Router Class Initialized
INFO - 2023-03-15 07:16:33 --> Router Class Initialized
INFO - 2023-03-15 07:16:33 --> Output Class Initialized
INFO - 2023-03-15 07:16:33 --> Output Class Initialized
INFO - 2023-03-15 07:16:33 --> Security Class Initialized
INFO - 2023-03-15 07:16:33 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:33 --> Input Class Initialized
INFO - 2023-03-15 07:16:33 --> Input Class Initialized
INFO - 2023-03-15 07:16:33 --> Language Class Initialized
INFO - 2023-03-15 07:16:33 --> Language Class Initialized
INFO - 2023-03-15 07:16:33 --> Loader Class Initialized
INFO - 2023-03-15 07:16:33 --> Loader Class Initialized
INFO - 2023-03-15 07:16:33 --> Controller Class Initialized
INFO - 2023-03-15 07:16:33 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:16:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:33 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:33 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:33 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:33 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:16:33 --> Final output sent to browser
DEBUG - 2023-03-15 07:16:33 --> Total execution time: 0.0164
INFO - 2023-03-15 07:16:33 --> Config Class Initialized
INFO - 2023-03-15 07:16:33 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:16:33 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:16:33 --> Utf8 Class Initialized
INFO - 2023-03-15 07:16:33 --> URI Class Initialized
INFO - 2023-03-15 07:16:33 --> Router Class Initialized
INFO - 2023-03-15 07:16:33 --> Output Class Initialized
INFO - 2023-03-15 07:16:33 --> Security Class Initialized
DEBUG - 2023-03-15 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:16:33 --> Input Class Initialized
INFO - 2023-03-15 07:16:33 --> Language Class Initialized
INFO - 2023-03-15 07:16:33 --> Loader Class Initialized
INFO - 2023-03-15 07:16:33 --> Controller Class Initialized
DEBUG - 2023-03-15 07:16:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:16:33 --> Database Driver Class Initialized
INFO - 2023-03-15 07:16:33 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:09 --> Config Class Initialized
INFO - 2023-03-15 07:19:09 --> Hooks Class Initialized
INFO - 2023-03-15 07:19:09 --> Config Class Initialized
DEBUG - 2023-03-15 07:19:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:09 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:09 --> Hooks Class Initialized
INFO - 2023-03-15 07:19:09 --> URI Class Initialized
DEBUG - 2023-03-15 07:19:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:09 --> Router Class Initialized
INFO - 2023-03-15 07:19:09 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:09 --> URI Class Initialized
INFO - 2023-03-15 07:19:09 --> Output Class Initialized
INFO - 2023-03-15 07:19:09 --> Router Class Initialized
INFO - 2023-03-15 07:19:09 --> Security Class Initialized
INFO - 2023-03-15 07:19:09 --> Output Class Initialized
DEBUG - 2023-03-15 07:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:09 --> Security Class Initialized
INFO - 2023-03-15 07:19:09 --> Input Class Initialized
DEBUG - 2023-03-15 07:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:09 --> Language Class Initialized
INFO - 2023-03-15 07:19:09 --> Input Class Initialized
INFO - 2023-03-15 07:19:09 --> Language Class Initialized
INFO - 2023-03-15 07:19:09 --> Loader Class Initialized
INFO - 2023-03-15 07:19:09 --> Loader Class Initialized
INFO - 2023-03-15 07:19:09 --> Controller Class Initialized
INFO - 2023-03-15 07:19:09 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:19:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:09 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:09 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:09 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:09 --> Total execution time: 0.3467
INFO - 2023-03-15 07:19:09 --> Config Class Initialized
INFO - 2023-03-15 07:19:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:09 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:09 --> URI Class Initialized
INFO - 2023-03-15 07:19:09 --> Router Class Initialized
INFO - 2023-03-15 07:19:09 --> Output Class Initialized
INFO - 2023-03-15 07:19:09 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:09 --> Input Class Initialized
INFO - 2023-03-15 07:19:09 --> Language Class Initialized
INFO - 2023-03-15 07:19:09 --> Loader Class Initialized
INFO - 2023-03-15 07:19:09 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:09 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:09 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:09 --> Total execution time: 0.0405
INFO - 2023-03-15 07:19:09 --> Config Class Initialized
INFO - 2023-03-15 07:19:09 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:09 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:09 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:09 --> URI Class Initialized
INFO - 2023-03-15 07:19:09 --> Router Class Initialized
INFO - 2023-03-15 07:19:09 --> Output Class Initialized
INFO - 2023-03-15 07:19:09 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:09 --> Input Class Initialized
INFO - 2023-03-15 07:19:09 --> Language Class Initialized
INFO - 2023-03-15 07:19:09 --> Loader Class Initialized
INFO - 2023-03-15 07:19:09 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:09 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:09 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:17 --> Config Class Initialized
INFO - 2023-03-15 07:19:17 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:17 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:17 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:17 --> URI Class Initialized
INFO - 2023-03-15 07:19:17 --> Router Class Initialized
INFO - 2023-03-15 07:19:17 --> Output Class Initialized
INFO - 2023-03-15 07:19:17 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:17 --> Input Class Initialized
INFO - 2023-03-15 07:19:17 --> Language Class Initialized
INFO - 2023-03-15 07:19:17 --> Loader Class Initialized
INFO - 2023-03-15 07:19:17 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:17 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:17 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:17 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:17 --> Model "Login_model" initialized
INFO - 2023-03-15 07:19:17 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:17 --> Total execution time: 0.1309
INFO - 2023-03-15 07:19:17 --> Config Class Initialized
INFO - 2023-03-15 07:19:17 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:17 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:17 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:17 --> URI Class Initialized
INFO - 2023-03-15 07:19:17 --> Router Class Initialized
INFO - 2023-03-15 07:19:17 --> Output Class Initialized
INFO - 2023-03-15 07:19:17 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:17 --> Input Class Initialized
INFO - 2023-03-15 07:19:17 --> Language Class Initialized
INFO - 2023-03-15 07:19:17 --> Loader Class Initialized
INFO - 2023-03-15 07:19:17 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:17 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:17 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:17 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:17 --> Model "Login_model" initialized
INFO - 2023-03-15 07:19:17 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:17 --> Total execution time: 0.0385
INFO - 2023-03-15 07:19:21 --> Config Class Initialized
INFO - 2023-03-15 07:19:21 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:21 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:21 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:21 --> URI Class Initialized
INFO - 2023-03-15 07:19:21 --> Router Class Initialized
INFO - 2023-03-15 07:19:21 --> Output Class Initialized
INFO - 2023-03-15 07:19:21 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:21 --> Input Class Initialized
INFO - 2023-03-15 07:19:21 --> Language Class Initialized
INFO - 2023-03-15 07:19:21 --> Loader Class Initialized
INFO - 2023-03-15 07:19:21 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:21 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:21 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:21 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:21 --> Total execution time: 0.0511
INFO - 2023-03-15 07:19:21 --> Config Class Initialized
INFO - 2023-03-15 07:19:21 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:21 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:21 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:21 --> URI Class Initialized
INFO - 2023-03-15 07:19:21 --> Router Class Initialized
INFO - 2023-03-15 07:19:21 --> Output Class Initialized
INFO - 2023-03-15 07:19:21 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:21 --> Input Class Initialized
INFO - 2023-03-15 07:19:21 --> Language Class Initialized
INFO - 2023-03-15 07:19:21 --> Loader Class Initialized
INFO - 2023-03-15 07:19:21 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:21 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:21 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:21 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:21 --> Total execution time: 0.0426
INFO - 2023-03-15 07:19:24 --> Config Class Initialized
INFO - 2023-03-15 07:19:24 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:24 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:24 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:24 --> URI Class Initialized
INFO - 2023-03-15 07:19:24 --> Router Class Initialized
INFO - 2023-03-15 07:19:24 --> Output Class Initialized
INFO - 2023-03-15 07:19:24 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:24 --> Input Class Initialized
INFO - 2023-03-15 07:19:24 --> Language Class Initialized
INFO - 2023-03-15 07:19:24 --> Loader Class Initialized
INFO - 2023-03-15 07:19:24 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:24 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:24 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:24 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:24 --> Total execution time: 0.0163
INFO - 2023-03-15 07:19:24 --> Config Class Initialized
INFO - 2023-03-15 07:19:24 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:24 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:24 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:24 --> URI Class Initialized
INFO - 2023-03-15 07:19:24 --> Router Class Initialized
INFO - 2023-03-15 07:19:24 --> Output Class Initialized
INFO - 2023-03-15 07:19:24 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:24 --> Input Class Initialized
INFO - 2023-03-15 07:19:24 --> Language Class Initialized
INFO - 2023-03-15 07:19:24 --> Loader Class Initialized
INFO - 2023-03-15 07:19:24 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:24 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:24 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:24 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:24 --> Total execution time: 0.0108
INFO - 2023-03-15 07:19:27 --> Config Class Initialized
INFO - 2023-03-15 07:19:27 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:27 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:27 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:27 --> URI Class Initialized
INFO - 2023-03-15 07:19:27 --> Router Class Initialized
INFO - 2023-03-15 07:19:27 --> Output Class Initialized
INFO - 2023-03-15 07:19:27 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:27 --> Input Class Initialized
INFO - 2023-03-15 07:19:27 --> Language Class Initialized
INFO - 2023-03-15 07:19:27 --> Loader Class Initialized
INFO - 2023-03-15 07:19:27 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:27 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:27 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:27 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:27 --> Model "Login_model" initialized
INFO - 2023-03-15 07:19:27 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:27 --> Total execution time: 0.0469
INFO - 2023-03-15 07:19:27 --> Config Class Initialized
INFO - 2023-03-15 07:19:27 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:27 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:27 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:27 --> URI Class Initialized
INFO - 2023-03-15 07:19:27 --> Router Class Initialized
INFO - 2023-03-15 07:19:27 --> Output Class Initialized
INFO - 2023-03-15 07:19:27 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:27 --> Input Class Initialized
INFO - 2023-03-15 07:19:27 --> Language Class Initialized
INFO - 2023-03-15 07:19:27 --> Loader Class Initialized
INFO - 2023-03-15 07:19:27 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:27 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:27 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:27 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:27 --> Model "Login_model" initialized
INFO - 2023-03-15 07:19:27 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:27 --> Total execution time: 0.0407
INFO - 2023-03-15 07:19:31 --> Config Class Initialized
INFO - 2023-03-15 07:19:31 --> Config Class Initialized
INFO - 2023-03-15 07:19:31 --> Hooks Class Initialized
INFO - 2023-03-15 07:19:31 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:31 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:19:31 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:31 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:31 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:31 --> URI Class Initialized
INFO - 2023-03-15 07:19:31 --> URI Class Initialized
INFO - 2023-03-15 07:19:31 --> Router Class Initialized
INFO - 2023-03-15 07:19:31 --> Router Class Initialized
INFO - 2023-03-15 07:19:31 --> Output Class Initialized
INFO - 2023-03-15 07:19:31 --> Output Class Initialized
INFO - 2023-03-15 07:19:31 --> Security Class Initialized
INFO - 2023-03-15 07:19:31 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:31 --> Input Class Initialized
INFO - 2023-03-15 07:19:31 --> Input Class Initialized
INFO - 2023-03-15 07:19:31 --> Language Class Initialized
INFO - 2023-03-15 07:19:31 --> Language Class Initialized
INFO - 2023-03-15 07:19:31 --> Loader Class Initialized
INFO - 2023-03-15 07:19:31 --> Loader Class Initialized
INFO - 2023-03-15 07:19:31 --> Controller Class Initialized
INFO - 2023-03-15 07:19:31 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:19:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:31 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:31 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:31 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:31 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:31 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:31 --> Total execution time: 0.0439
INFO - 2023-03-15 07:19:31 --> Config Class Initialized
INFO - 2023-03-15 07:19:31 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:31 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:31 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:31 --> URI Class Initialized
INFO - 2023-03-15 07:19:31 --> Router Class Initialized
INFO - 2023-03-15 07:19:31 --> Output Class Initialized
INFO - 2023-03-15 07:19:31 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:31 --> Input Class Initialized
INFO - 2023-03-15 07:19:31 --> Language Class Initialized
INFO - 2023-03-15 07:19:31 --> Loader Class Initialized
INFO - 2023-03-15 07:19:31 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:31 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:31 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:31 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:32 --> Total execution time: 0.0554
INFO - 2023-03-15 07:19:32 --> Config Class Initialized
INFO - 2023-03-15 07:19:32 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:32 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:32 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:32 --> URI Class Initialized
INFO - 2023-03-15 07:19:32 --> Router Class Initialized
INFO - 2023-03-15 07:19:32 --> Output Class Initialized
INFO - 2023-03-15 07:19:32 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:32 --> Input Class Initialized
INFO - 2023-03-15 07:19:32 --> Language Class Initialized
INFO - 2023-03-15 07:19:32 --> Loader Class Initialized
INFO - 2023-03-15 07:19:32 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:32 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:32 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:58 --> Config Class Initialized
INFO - 2023-03-15 07:19:58 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:58 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:58 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:58 --> URI Class Initialized
INFO - 2023-03-15 07:19:58 --> Router Class Initialized
INFO - 2023-03-15 07:19:58 --> Output Class Initialized
INFO - 2023-03-15 07:19:58 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:58 --> Input Class Initialized
INFO - 2023-03-15 07:19:58 --> Language Class Initialized
INFO - 2023-03-15 07:19:58 --> Loader Class Initialized
INFO - 2023-03-15 07:19:58 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-03-15 07:19:58 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 227
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-03-15 07:19:58 --> Config Class Initialized
INFO - 2023-03-15 07:19:58 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:58 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:58 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:58 --> URI Class Initialized
INFO - 2023-03-15 07:19:58 --> Router Class Initialized
INFO - 2023-03-15 07:19:58 --> Output Class Initialized
INFO - 2023-03-15 07:19:58 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:58 --> Input Class Initialized
INFO - 2023-03-15 07:19:58 --> Language Class Initialized
INFO - 2023-03-15 07:19:58 --> Loader Class Initialized
INFO - 2023-03-15 07:19:58 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:58 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:58 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:58 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:58 --> Total execution time: 0.0217
INFO - 2023-03-15 07:19:59 --> Config Class Initialized
INFO - 2023-03-15 07:19:59 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:59 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:59 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:59 --> URI Class Initialized
INFO - 2023-03-15 07:19:59 --> Router Class Initialized
INFO - 2023-03-15 07:19:59 --> Output Class Initialized
INFO - 2023-03-15 07:19:59 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:59 --> Input Class Initialized
INFO - 2023-03-15 07:19:59 --> Language Class Initialized
INFO - 2023-03-15 07:19:59 --> Loader Class Initialized
INFO - 2023-03-15 07:19:59 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:59 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:59 --> Total execution time: 0.0042
INFO - 2023-03-15 07:19:59 --> Config Class Initialized
INFO - 2023-03-15 07:19:59 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:19:59 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:19:59 --> Utf8 Class Initialized
INFO - 2023-03-15 07:19:59 --> URI Class Initialized
INFO - 2023-03-15 07:19:59 --> Router Class Initialized
INFO - 2023-03-15 07:19:59 --> Output Class Initialized
INFO - 2023-03-15 07:19:59 --> Security Class Initialized
DEBUG - 2023-03-15 07:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:19:59 --> Input Class Initialized
INFO - 2023-03-15 07:19:59 --> Language Class Initialized
INFO - 2023-03-15 07:19:59 --> Loader Class Initialized
INFO - 2023-03-15 07:19:59 --> Controller Class Initialized
DEBUG - 2023-03-15 07:19:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:19:59 --> Database Driver Class Initialized
INFO - 2023-03-15 07:19:59 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:19:59 --> Final output sent to browser
DEBUG - 2023-03-15 07:19:59 --> Total execution time: 0.0294
INFO - 2023-03-15 07:20:38 --> Config Class Initialized
INFO - 2023-03-15 07:20:38 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:20:38 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:20:38 --> Utf8 Class Initialized
INFO - 2023-03-15 07:20:38 --> URI Class Initialized
INFO - 2023-03-15 07:20:38 --> Router Class Initialized
INFO - 2023-03-15 07:20:38 --> Output Class Initialized
INFO - 2023-03-15 07:20:38 --> Security Class Initialized
DEBUG - 2023-03-15 07:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:20:38 --> Input Class Initialized
INFO - 2023-03-15 07:20:38 --> Language Class Initialized
INFO - 2023-03-15 07:20:38 --> Loader Class Initialized
INFO - 2023-03-15 07:20:38 --> Controller Class Initialized
DEBUG - 2023-03-15 07:20:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-03-15 07:20:38 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 227
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-03-15 07:20:38 --> Config Class Initialized
INFO - 2023-03-15 07:20:38 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:20:38 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:20:38 --> Utf8 Class Initialized
INFO - 2023-03-15 07:20:38 --> URI Class Initialized
INFO - 2023-03-15 07:20:38 --> Router Class Initialized
INFO - 2023-03-15 07:20:38 --> Output Class Initialized
INFO - 2023-03-15 07:20:38 --> Security Class Initialized
DEBUG - 2023-03-15 07:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:20:38 --> Input Class Initialized
INFO - 2023-03-15 07:20:38 --> Language Class Initialized
INFO - 2023-03-15 07:20:38 --> Loader Class Initialized
INFO - 2023-03-15 07:20:38 --> Controller Class Initialized
DEBUG - 2023-03-15 07:20:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:20:38 --> Database Driver Class Initialized
INFO - 2023-03-15 07:20:38 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:20:38 --> Final output sent to browser
DEBUG - 2023-03-15 07:20:38 --> Total execution time: 0.0183
INFO - 2023-03-15 07:20:39 --> Config Class Initialized
INFO - 2023-03-15 07:20:39 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:20:39 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:20:39 --> Utf8 Class Initialized
INFO - 2023-03-15 07:20:39 --> URI Class Initialized
INFO - 2023-03-15 07:20:39 --> Router Class Initialized
INFO - 2023-03-15 07:20:39 --> Output Class Initialized
INFO - 2023-03-15 07:20:39 --> Security Class Initialized
DEBUG - 2023-03-15 07:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:20:39 --> Input Class Initialized
INFO - 2023-03-15 07:20:39 --> Language Class Initialized
INFO - 2023-03-15 07:20:39 --> Loader Class Initialized
INFO - 2023-03-15 07:20:39 --> Controller Class Initialized
DEBUG - 2023-03-15 07:20:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:20:39 --> Final output sent to browser
DEBUG - 2023-03-15 07:20:39 --> Total execution time: 0.0050
INFO - 2023-03-15 07:20:39 --> Config Class Initialized
INFO - 2023-03-15 07:20:39 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:20:39 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:20:39 --> Utf8 Class Initialized
INFO - 2023-03-15 07:20:39 --> URI Class Initialized
INFO - 2023-03-15 07:20:39 --> Router Class Initialized
INFO - 2023-03-15 07:20:39 --> Output Class Initialized
INFO - 2023-03-15 07:20:39 --> Security Class Initialized
DEBUG - 2023-03-15 07:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:20:39 --> Input Class Initialized
INFO - 2023-03-15 07:20:39 --> Language Class Initialized
INFO - 2023-03-15 07:20:39 --> Loader Class Initialized
INFO - 2023-03-15 07:20:39 --> Controller Class Initialized
DEBUG - 2023-03-15 07:20:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:20:39 --> Database Driver Class Initialized
INFO - 2023-03-15 07:20:39 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:20:39 --> Final output sent to browser
DEBUG - 2023-03-15 07:20:39 --> Total execution time: 0.0150
INFO - 2023-03-15 07:23:24 --> Config Class Initialized
INFO - 2023-03-15 07:23:24 --> Config Class Initialized
INFO - 2023-03-15 07:23:24 --> Hooks Class Initialized
INFO - 2023-03-15 07:23:24 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:23:24 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:23:24 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:23:24 --> Utf8 Class Initialized
INFO - 2023-03-15 07:23:24 --> Utf8 Class Initialized
INFO - 2023-03-15 07:23:24 --> URI Class Initialized
INFO - 2023-03-15 07:23:24 --> URI Class Initialized
INFO - 2023-03-15 07:23:24 --> Router Class Initialized
INFO - 2023-03-15 07:23:24 --> Router Class Initialized
INFO - 2023-03-15 07:23:24 --> Output Class Initialized
INFO - 2023-03-15 07:23:24 --> Output Class Initialized
INFO - 2023-03-15 07:23:24 --> Security Class Initialized
INFO - 2023-03-15 07:23:24 --> Security Class Initialized
DEBUG - 2023-03-15 07:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:23:24 --> Input Class Initialized
INFO - 2023-03-15 07:23:24 --> Input Class Initialized
INFO - 2023-03-15 07:23:24 --> Language Class Initialized
INFO - 2023-03-15 07:23:24 --> Language Class Initialized
INFO - 2023-03-15 07:23:24 --> Loader Class Initialized
INFO - 2023-03-15 07:23:24 --> Loader Class Initialized
INFO - 2023-03-15 07:23:24 --> Controller Class Initialized
INFO - 2023-03-15 07:23:24 --> Controller Class Initialized
DEBUG - 2023-03-15 07:23:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:23:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:23:24 --> Database Driver Class Initialized
INFO - 2023-03-15 07:23:24 --> Database Driver Class Initialized
INFO - 2023-03-15 07:23:25 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:23:25 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:23:25 --> Final output sent to browser
DEBUG - 2023-03-15 07:23:25 --> Total execution time: 1.0701
INFO - 2023-03-15 07:23:25 --> Config Class Initialized
INFO - 2023-03-15 07:23:25 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:23:25 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:23:25 --> Utf8 Class Initialized
INFO - 2023-03-15 07:23:25 --> URI Class Initialized
INFO - 2023-03-15 07:23:25 --> Router Class Initialized
INFO - 2023-03-15 07:23:25 --> Output Class Initialized
INFO - 2023-03-15 07:23:25 --> Security Class Initialized
DEBUG - 2023-03-15 07:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:23:25 --> Input Class Initialized
INFO - 2023-03-15 07:23:25 --> Language Class Initialized
INFO - 2023-03-15 07:23:25 --> Loader Class Initialized
INFO - 2023-03-15 07:23:25 --> Controller Class Initialized
DEBUG - 2023-03-15 07:23:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:23:25 --> Database Driver Class Initialized
INFO - 2023-03-15 07:23:25 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:23:25 --> Final output sent to browser
DEBUG - 2023-03-15 07:23:25 --> Total execution time: 0.1366
INFO - 2023-03-15 07:23:25 --> Config Class Initialized
INFO - 2023-03-15 07:23:25 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:23:25 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:23:25 --> Utf8 Class Initialized
INFO - 2023-03-15 07:23:25 --> URI Class Initialized
INFO - 2023-03-15 07:23:25 --> Router Class Initialized
INFO - 2023-03-15 07:23:25 --> Output Class Initialized
INFO - 2023-03-15 07:23:25 --> Security Class Initialized
DEBUG - 2023-03-15 07:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:23:25 --> Input Class Initialized
INFO - 2023-03-15 07:23:25 --> Language Class Initialized
INFO - 2023-03-15 07:23:25 --> Loader Class Initialized
INFO - 2023-03-15 07:23:25 --> Controller Class Initialized
DEBUG - 2023-03-15 07:23:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:23:25 --> Database Driver Class Initialized
INFO - 2023-03-15 07:23:25 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:29:58 --> Config Class Initialized
INFO - 2023-03-15 07:29:58 --> Config Class Initialized
INFO - 2023-03-15 07:29:58 --> Hooks Class Initialized
INFO - 2023-03-15 07:29:58 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:29:58 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:29:58 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:29:58 --> Utf8 Class Initialized
INFO - 2023-03-15 07:29:58 --> Utf8 Class Initialized
INFO - 2023-03-15 07:29:58 --> URI Class Initialized
INFO - 2023-03-15 07:29:58 --> URI Class Initialized
INFO - 2023-03-15 07:29:58 --> Router Class Initialized
INFO - 2023-03-15 07:29:58 --> Router Class Initialized
INFO - 2023-03-15 07:29:58 --> Output Class Initialized
INFO - 2023-03-15 07:29:58 --> Output Class Initialized
INFO - 2023-03-15 07:29:58 --> Security Class Initialized
INFO - 2023-03-15 07:29:58 --> Security Class Initialized
DEBUG - 2023-03-15 07:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:29:58 --> Input Class Initialized
INFO - 2023-03-15 07:29:58 --> Input Class Initialized
INFO - 2023-03-15 07:29:58 --> Language Class Initialized
INFO - 2023-03-15 07:29:58 --> Language Class Initialized
INFO - 2023-03-15 07:29:58 --> Loader Class Initialized
INFO - 2023-03-15 07:29:58 --> Loader Class Initialized
INFO - 2023-03-15 07:29:58 --> Controller Class Initialized
INFO - 2023-03-15 07:29:58 --> Controller Class Initialized
DEBUG - 2023-03-15 07:29:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:29:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:29:58 --> Database Driver Class Initialized
INFO - 2023-03-15 07:29:58 --> Database Driver Class Initialized
INFO - 2023-03-15 07:29:58 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:29:58 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:29:58 --> Final output sent to browser
DEBUG - 2023-03-15 07:29:58 --> Total execution time: 0.0604
INFO - 2023-03-15 07:29:58 --> Config Class Initialized
INFO - 2023-03-15 07:29:58 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:29:58 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:29:58 --> Utf8 Class Initialized
INFO - 2023-03-15 07:29:58 --> URI Class Initialized
INFO - 2023-03-15 07:29:58 --> Router Class Initialized
INFO - 2023-03-15 07:29:58 --> Output Class Initialized
INFO - 2023-03-15 07:29:58 --> Security Class Initialized
DEBUG - 2023-03-15 07:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:29:58 --> Input Class Initialized
INFO - 2023-03-15 07:29:58 --> Language Class Initialized
INFO - 2023-03-15 07:29:58 --> Loader Class Initialized
INFO - 2023-03-15 07:29:58 --> Controller Class Initialized
DEBUG - 2023-03-15 07:29:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:29:59 --> Database Driver Class Initialized
INFO - 2023-03-15 07:29:59 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:29:59 --> Final output sent to browser
DEBUG - 2023-03-15 07:29:59 --> Total execution time: 0.0943
INFO - 2023-03-15 07:29:59 --> Config Class Initialized
INFO - 2023-03-15 07:29:59 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:29:59 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:29:59 --> Utf8 Class Initialized
INFO - 2023-03-15 07:29:59 --> URI Class Initialized
INFO - 2023-03-15 07:29:59 --> Router Class Initialized
INFO - 2023-03-15 07:29:59 --> Output Class Initialized
INFO - 2023-03-15 07:29:59 --> Security Class Initialized
DEBUG - 2023-03-15 07:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:29:59 --> Input Class Initialized
INFO - 2023-03-15 07:29:59 --> Language Class Initialized
INFO - 2023-03-15 07:29:59 --> Loader Class Initialized
INFO - 2023-03-15 07:29:59 --> Controller Class Initialized
DEBUG - 2023-03-15 07:29:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:29:59 --> Database Driver Class Initialized
INFO - 2023-03-15 07:29:59 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:30:26 --> Config Class Initialized
INFO - 2023-03-15 07:30:26 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:30:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:30:26 --> Utf8 Class Initialized
INFO - 2023-03-15 07:30:26 --> URI Class Initialized
INFO - 2023-03-15 07:30:26 --> Router Class Initialized
INFO - 2023-03-15 07:30:26 --> Output Class Initialized
INFO - 2023-03-15 07:30:26 --> Security Class Initialized
DEBUG - 2023-03-15 07:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:30:26 --> Input Class Initialized
INFO - 2023-03-15 07:30:26 --> Language Class Initialized
INFO - 2023-03-15 07:30:26 --> Loader Class Initialized
INFO - 2023-03-15 07:30:26 --> Controller Class Initialized
DEBUG - 2023-03-15 07:30:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-03-15 07:30:26 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 227
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-03-15 07:30:26 --> Config Class Initialized
INFO - 2023-03-15 07:30:26 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:30:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:30:26 --> Utf8 Class Initialized
INFO - 2023-03-15 07:30:26 --> URI Class Initialized
INFO - 2023-03-15 07:30:26 --> Router Class Initialized
INFO - 2023-03-15 07:30:26 --> Output Class Initialized
INFO - 2023-03-15 07:30:26 --> Security Class Initialized
DEBUG - 2023-03-15 07:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:30:26 --> Input Class Initialized
INFO - 2023-03-15 07:30:26 --> Language Class Initialized
INFO - 2023-03-15 07:30:26 --> Loader Class Initialized
INFO - 2023-03-15 07:30:26 --> Controller Class Initialized
DEBUG - 2023-03-15 07:30:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:30:26 --> Database Driver Class Initialized
INFO - 2023-03-15 07:30:26 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:30:26 --> Final output sent to browser
DEBUG - 2023-03-15 07:30:26 --> Total execution time: 0.0151
INFO - 2023-03-15 07:30:27 --> Config Class Initialized
INFO - 2023-03-15 07:30:27 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:30:27 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:30:27 --> Utf8 Class Initialized
INFO - 2023-03-15 07:30:27 --> URI Class Initialized
INFO - 2023-03-15 07:30:27 --> Router Class Initialized
INFO - 2023-03-15 07:30:27 --> Output Class Initialized
INFO - 2023-03-15 07:30:27 --> Security Class Initialized
DEBUG - 2023-03-15 07:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:30:27 --> Input Class Initialized
INFO - 2023-03-15 07:30:27 --> Language Class Initialized
INFO - 2023-03-15 07:30:27 --> Loader Class Initialized
INFO - 2023-03-15 07:30:27 --> Controller Class Initialized
DEBUG - 2023-03-15 07:30:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:30:27 --> Final output sent to browser
DEBUG - 2023-03-15 07:30:27 --> Total execution time: 0.0040
INFO - 2023-03-15 07:30:27 --> Config Class Initialized
INFO - 2023-03-15 07:30:27 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:30:27 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:30:27 --> Utf8 Class Initialized
INFO - 2023-03-15 07:30:27 --> URI Class Initialized
INFO - 2023-03-15 07:30:27 --> Router Class Initialized
INFO - 2023-03-15 07:30:27 --> Output Class Initialized
INFO - 2023-03-15 07:30:27 --> Security Class Initialized
DEBUG - 2023-03-15 07:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:30:27 --> Input Class Initialized
INFO - 2023-03-15 07:30:27 --> Language Class Initialized
INFO - 2023-03-15 07:30:27 --> Loader Class Initialized
INFO - 2023-03-15 07:30:27 --> Controller Class Initialized
DEBUG - 2023-03-15 07:30:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:30:27 --> Database Driver Class Initialized
INFO - 2023-03-15 07:30:27 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:30:27 --> Final output sent to browser
DEBUG - 2023-03-15 07:30:27 --> Total execution time: 0.0163
INFO - 2023-03-15 07:31:08 --> Config Class Initialized
INFO - 2023-03-15 07:31:08 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:31:08 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:31:08 --> Utf8 Class Initialized
INFO - 2023-03-15 07:31:08 --> URI Class Initialized
INFO - 2023-03-15 07:31:08 --> Router Class Initialized
INFO - 2023-03-15 07:31:08 --> Output Class Initialized
INFO - 2023-03-15 07:31:08 --> Security Class Initialized
DEBUG - 2023-03-15 07:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:31:08 --> Input Class Initialized
INFO - 2023-03-15 07:31:08 --> Language Class Initialized
INFO - 2023-03-15 07:31:08 --> Loader Class Initialized
INFO - 2023-03-15 07:31:08 --> Controller Class Initialized
DEBUG - 2023-03-15 07:31:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:31:08 --> Database Driver Class Initialized
INFO - 2023-03-15 07:31:08 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:31:08 --> Config Class Initialized
INFO - 2023-03-15 07:31:08 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:31:08 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:31:08 --> Utf8 Class Initialized
INFO - 2023-03-15 07:31:08 --> URI Class Initialized
INFO - 2023-03-15 07:31:08 --> Router Class Initialized
INFO - 2023-03-15 07:31:08 --> Output Class Initialized
INFO - 2023-03-15 07:31:08 --> Security Class Initialized
DEBUG - 2023-03-15 07:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:31:08 --> Input Class Initialized
INFO - 2023-03-15 07:31:08 --> Language Class Initialized
INFO - 2023-03-15 07:31:08 --> Loader Class Initialized
INFO - 2023-03-15 07:31:08 --> Controller Class Initialized
DEBUG - 2023-03-15 07:31:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:31:08 --> Database Driver Class Initialized
INFO - 2023-03-15 07:31:08 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:31:47 --> Config Class Initialized
INFO - 2023-03-15 07:31:47 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:31:47 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:31:47 --> Utf8 Class Initialized
INFO - 2023-03-15 07:31:47 --> URI Class Initialized
INFO - 2023-03-15 07:31:47 --> Router Class Initialized
INFO - 2023-03-15 07:31:47 --> Output Class Initialized
INFO - 2023-03-15 07:31:47 --> Security Class Initialized
DEBUG - 2023-03-15 07:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:31:47 --> Input Class Initialized
INFO - 2023-03-15 07:31:47 --> Language Class Initialized
INFO - 2023-03-15 07:31:47 --> Loader Class Initialized
INFO - 2023-03-15 07:31:47 --> Controller Class Initialized
DEBUG - 2023-03-15 07:31:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:31:47 --> Database Driver Class Initialized
INFO - 2023-03-15 07:31:47 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:31:48 --> Config Class Initialized
INFO - 2023-03-15 07:31:48 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:31:48 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:31:48 --> Utf8 Class Initialized
INFO - 2023-03-15 07:31:48 --> URI Class Initialized
INFO - 2023-03-15 07:31:48 --> Router Class Initialized
INFO - 2023-03-15 07:31:48 --> Output Class Initialized
INFO - 2023-03-15 07:31:48 --> Security Class Initialized
DEBUG - 2023-03-15 07:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:31:48 --> Input Class Initialized
INFO - 2023-03-15 07:31:48 --> Language Class Initialized
INFO - 2023-03-15 07:31:48 --> Loader Class Initialized
INFO - 2023-03-15 07:31:48 --> Controller Class Initialized
DEBUG - 2023-03-15 07:31:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:31:48 --> Database Driver Class Initialized
INFO - 2023-03-15 07:31:48 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:32:05 --> Config Class Initialized
INFO - 2023-03-15 07:32:05 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:32:05 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:32:05 --> Utf8 Class Initialized
INFO - 2023-03-15 07:32:05 --> URI Class Initialized
INFO - 2023-03-15 07:32:05 --> Router Class Initialized
INFO - 2023-03-15 07:32:05 --> Output Class Initialized
INFO - 2023-03-15 07:32:05 --> Security Class Initialized
DEBUG - 2023-03-15 07:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:32:05 --> Input Class Initialized
INFO - 2023-03-15 07:32:05 --> Language Class Initialized
INFO - 2023-03-15 07:32:05 --> Loader Class Initialized
INFO - 2023-03-15 07:32:05 --> Controller Class Initialized
DEBUG - 2023-03-15 07:32:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-03-15 07:32:05 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 227
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-03-15 07:32:05 --> Config Class Initialized
INFO - 2023-03-15 07:32:05 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:32:05 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:32:05 --> Utf8 Class Initialized
INFO - 2023-03-15 07:32:05 --> URI Class Initialized
INFO - 2023-03-15 07:32:05 --> Router Class Initialized
INFO - 2023-03-15 07:32:05 --> Output Class Initialized
INFO - 2023-03-15 07:32:05 --> Security Class Initialized
DEBUG - 2023-03-15 07:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:32:05 --> Input Class Initialized
INFO - 2023-03-15 07:32:05 --> Language Class Initialized
INFO - 2023-03-15 07:32:05 --> Loader Class Initialized
INFO - 2023-03-15 07:32:05 --> Controller Class Initialized
DEBUG - 2023-03-15 07:32:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:32:05 --> Database Driver Class Initialized
INFO - 2023-03-15 07:32:05 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:32:05 --> Final output sent to browser
DEBUG - 2023-03-15 07:32:05 --> Total execution time: 0.0165
INFO - 2023-03-15 07:32:06 --> Config Class Initialized
INFO - 2023-03-15 07:32:06 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:32:06 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:32:06 --> Utf8 Class Initialized
INFO - 2023-03-15 07:32:06 --> URI Class Initialized
INFO - 2023-03-15 07:32:06 --> Router Class Initialized
INFO - 2023-03-15 07:32:06 --> Output Class Initialized
INFO - 2023-03-15 07:32:06 --> Security Class Initialized
DEBUG - 2023-03-15 07:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:32:06 --> Input Class Initialized
INFO - 2023-03-15 07:32:06 --> Language Class Initialized
INFO - 2023-03-15 07:32:06 --> Loader Class Initialized
INFO - 2023-03-15 07:32:06 --> Controller Class Initialized
DEBUG - 2023-03-15 07:32:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:32:06 --> Final output sent to browser
DEBUG - 2023-03-15 07:32:06 --> Total execution time: 0.0039
INFO - 2023-03-15 07:32:06 --> Config Class Initialized
INFO - 2023-03-15 07:32:06 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:32:06 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:32:06 --> Utf8 Class Initialized
INFO - 2023-03-15 07:32:06 --> URI Class Initialized
INFO - 2023-03-15 07:32:06 --> Router Class Initialized
INFO - 2023-03-15 07:32:06 --> Output Class Initialized
INFO - 2023-03-15 07:32:06 --> Security Class Initialized
DEBUG - 2023-03-15 07:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:32:06 --> Input Class Initialized
INFO - 2023-03-15 07:32:06 --> Language Class Initialized
INFO - 2023-03-15 07:32:06 --> Loader Class Initialized
INFO - 2023-03-15 07:32:06 --> Controller Class Initialized
DEBUG - 2023-03-15 07:32:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:32:06 --> Database Driver Class Initialized
INFO - 2023-03-15 07:32:06 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:32:06 --> Final output sent to browser
DEBUG - 2023-03-15 07:32:06 --> Total execution time: 0.0532
INFO - 2023-03-15 07:32:18 --> Config Class Initialized
INFO - 2023-03-15 07:32:18 --> Config Class Initialized
INFO - 2023-03-15 07:32:18 --> Hooks Class Initialized
INFO - 2023-03-15 07:32:18 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:32:18 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:32:18 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:32:18 --> Utf8 Class Initialized
INFO - 2023-03-15 07:32:18 --> Utf8 Class Initialized
INFO - 2023-03-15 07:32:18 --> URI Class Initialized
INFO - 2023-03-15 07:32:18 --> URI Class Initialized
INFO - 2023-03-15 07:32:18 --> Router Class Initialized
INFO - 2023-03-15 07:32:18 --> Router Class Initialized
INFO - 2023-03-15 07:32:18 --> Output Class Initialized
INFO - 2023-03-15 07:32:18 --> Output Class Initialized
INFO - 2023-03-15 07:32:18 --> Security Class Initialized
INFO - 2023-03-15 07:32:18 --> Security Class Initialized
DEBUG - 2023-03-15 07:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:32:18 --> Input Class Initialized
INFO - 2023-03-15 07:32:18 --> Input Class Initialized
INFO - 2023-03-15 07:32:18 --> Language Class Initialized
INFO - 2023-03-15 07:32:18 --> Language Class Initialized
INFO - 2023-03-15 07:32:18 --> Loader Class Initialized
INFO - 2023-03-15 07:32:18 --> Loader Class Initialized
INFO - 2023-03-15 07:32:18 --> Controller Class Initialized
INFO - 2023-03-15 07:32:18 --> Controller Class Initialized
DEBUG - 2023-03-15 07:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:32:18 --> Database Driver Class Initialized
INFO - 2023-03-15 07:32:18 --> Database Driver Class Initialized
INFO - 2023-03-15 07:32:18 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:32:18 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:32:18 --> Final output sent to browser
DEBUG - 2023-03-15 07:32:18 --> Total execution time: 0.0157
INFO - 2023-03-15 07:32:18 --> Config Class Initialized
INFO - 2023-03-15 07:32:18 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:32:18 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:32:18 --> Utf8 Class Initialized
INFO - 2023-03-15 07:32:18 --> URI Class Initialized
INFO - 2023-03-15 07:32:18 --> Router Class Initialized
INFO - 2023-03-15 07:32:18 --> Output Class Initialized
INFO - 2023-03-15 07:32:18 --> Security Class Initialized
DEBUG - 2023-03-15 07:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:32:18 --> Input Class Initialized
INFO - 2023-03-15 07:32:18 --> Language Class Initialized
INFO - 2023-03-15 07:32:18 --> Loader Class Initialized
INFO - 2023-03-15 07:32:18 --> Controller Class Initialized
DEBUG - 2023-03-15 07:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:32:18 --> Database Driver Class Initialized
INFO - 2023-03-15 07:32:18 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:32:18 --> Final output sent to browser
DEBUG - 2023-03-15 07:32:18 --> Total execution time: 0.0524
INFO - 2023-03-15 07:32:18 --> Config Class Initialized
INFO - 2023-03-15 07:32:18 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:32:18 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:32:18 --> Utf8 Class Initialized
INFO - 2023-03-15 07:32:18 --> URI Class Initialized
INFO - 2023-03-15 07:32:18 --> Router Class Initialized
INFO - 2023-03-15 07:32:18 --> Output Class Initialized
INFO - 2023-03-15 07:32:18 --> Security Class Initialized
DEBUG - 2023-03-15 07:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:32:18 --> Input Class Initialized
INFO - 2023-03-15 07:32:18 --> Language Class Initialized
INFO - 2023-03-15 07:32:18 --> Loader Class Initialized
INFO - 2023-03-15 07:32:18 --> Controller Class Initialized
DEBUG - 2023-03-15 07:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:32:18 --> Database Driver Class Initialized
INFO - 2023-03-15 07:32:18 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:32:21 --> Config Class Initialized
INFO - 2023-03-15 07:32:21 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:32:21 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:32:21 --> Utf8 Class Initialized
INFO - 2023-03-15 07:32:21 --> URI Class Initialized
INFO - 2023-03-15 07:32:21 --> Router Class Initialized
INFO - 2023-03-15 07:32:21 --> Output Class Initialized
INFO - 2023-03-15 07:32:21 --> Security Class Initialized
DEBUG - 2023-03-15 07:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:32:21 --> Input Class Initialized
INFO - 2023-03-15 07:32:21 --> Language Class Initialized
INFO - 2023-03-15 07:32:21 --> Loader Class Initialized
INFO - 2023-03-15 07:32:21 --> Controller Class Initialized
DEBUG - 2023-03-15 07:32:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:32:21 --> Database Driver Class Initialized
INFO - 2023-03-15 07:32:21 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:32:21 --> Config Class Initialized
INFO - 2023-03-15 07:32:21 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:32:21 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:32:21 --> Utf8 Class Initialized
INFO - 2023-03-15 07:32:21 --> URI Class Initialized
INFO - 2023-03-15 07:32:21 --> Router Class Initialized
INFO - 2023-03-15 07:32:21 --> Output Class Initialized
INFO - 2023-03-15 07:32:21 --> Security Class Initialized
DEBUG - 2023-03-15 07:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:32:21 --> Input Class Initialized
INFO - 2023-03-15 07:32:21 --> Language Class Initialized
INFO - 2023-03-15 07:32:21 --> Loader Class Initialized
INFO - 2023-03-15 07:32:21 --> Controller Class Initialized
DEBUG - 2023-03-15 07:32:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:32:21 --> Database Driver Class Initialized
INFO - 2023-03-15 07:32:21 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:33:43 --> Config Class Initialized
INFO - 2023-03-15 07:33:43 --> Config Class Initialized
INFO - 2023-03-15 07:33:43 --> Hooks Class Initialized
INFO - 2023-03-15 07:33:43 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:33:43 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:33:43 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:33:43 --> Utf8 Class Initialized
INFO - 2023-03-15 07:33:43 --> Utf8 Class Initialized
INFO - 2023-03-15 07:33:43 --> URI Class Initialized
INFO - 2023-03-15 07:33:43 --> URI Class Initialized
INFO - 2023-03-15 07:33:43 --> Router Class Initialized
INFO - 2023-03-15 07:33:43 --> Router Class Initialized
INFO - 2023-03-15 07:33:43 --> Output Class Initialized
INFO - 2023-03-15 07:33:43 --> Output Class Initialized
INFO - 2023-03-15 07:33:43 --> Security Class Initialized
DEBUG - 2023-03-15 07:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:33:43 --> Input Class Initialized
INFO - 2023-03-15 07:33:43 --> Language Class Initialized
INFO - 2023-03-15 07:33:43 --> Loader Class Initialized
INFO - 2023-03-15 07:33:43 --> Security Class Initialized
INFO - 2023-03-15 07:33:43 --> Controller Class Initialized
DEBUG - 2023-03-15 07:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:33:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:33:43 --> Input Class Initialized
INFO - 2023-03-15 07:33:43 --> Language Class Initialized
INFO - 2023-03-15 07:33:43 --> Database Driver Class Initialized
INFO - 2023-03-15 07:33:43 --> Loader Class Initialized
INFO - 2023-03-15 07:33:43 --> Controller Class Initialized
DEBUG - 2023-03-15 07:33:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:33:43 --> Database Driver Class Initialized
INFO - 2023-03-15 07:33:43 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:33:43 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:33:43 --> Final output sent to browser
DEBUG - 2023-03-15 07:33:43 --> Total execution time: 0.0806
INFO - 2023-03-15 07:33:43 --> Config Class Initialized
INFO - 2023-03-15 07:33:43 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:33:43 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:33:43 --> Utf8 Class Initialized
INFO - 2023-03-15 07:33:43 --> URI Class Initialized
INFO - 2023-03-15 07:33:43 --> Router Class Initialized
INFO - 2023-03-15 07:33:43 --> Output Class Initialized
INFO - 2023-03-15 07:33:43 --> Security Class Initialized
DEBUG - 2023-03-15 07:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:33:43 --> Input Class Initialized
INFO - 2023-03-15 07:33:43 --> Language Class Initialized
INFO - 2023-03-15 07:33:43 --> Loader Class Initialized
INFO - 2023-03-15 07:33:43 --> Controller Class Initialized
DEBUG - 2023-03-15 07:33:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:33:43 --> Database Driver Class Initialized
INFO - 2023-03-15 07:33:43 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:33:43 --> Final output sent to browser
DEBUG - 2023-03-15 07:33:43 --> Total execution time: 0.0477
INFO - 2023-03-15 07:33:43 --> Config Class Initialized
INFO - 2023-03-15 07:33:43 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:33:43 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:33:43 --> Utf8 Class Initialized
INFO - 2023-03-15 07:33:43 --> URI Class Initialized
INFO - 2023-03-15 07:33:43 --> Router Class Initialized
INFO - 2023-03-15 07:33:43 --> Output Class Initialized
INFO - 2023-03-15 07:33:43 --> Security Class Initialized
DEBUG - 2023-03-15 07:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:33:43 --> Input Class Initialized
INFO - 2023-03-15 07:33:43 --> Language Class Initialized
INFO - 2023-03-15 07:33:43 --> Loader Class Initialized
INFO - 2023-03-15 07:33:43 --> Controller Class Initialized
DEBUG - 2023-03-15 07:33:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:33:43 --> Database Driver Class Initialized
INFO - 2023-03-15 07:33:43 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:35:49 --> Config Class Initialized
INFO - 2023-03-15 07:35:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:35:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:35:49 --> Utf8 Class Initialized
INFO - 2023-03-15 07:35:49 --> URI Class Initialized
INFO - 2023-03-15 07:35:49 --> Router Class Initialized
INFO - 2023-03-15 07:35:49 --> Output Class Initialized
INFO - 2023-03-15 07:35:49 --> Security Class Initialized
DEBUG - 2023-03-15 07:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:35:49 --> Input Class Initialized
INFO - 2023-03-15 07:35:49 --> Language Class Initialized
INFO - 2023-03-15 07:35:49 --> Loader Class Initialized
INFO - 2023-03-15 07:35:49 --> Controller Class Initialized
DEBUG - 2023-03-15 07:35:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:35:49 --> Database Driver Class Initialized
INFO - 2023-03-15 07:35:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:35:49 --> Config Class Initialized
INFO - 2023-03-15 07:35:49 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:35:49 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:35:49 --> Utf8 Class Initialized
INFO - 2023-03-15 07:35:49 --> URI Class Initialized
INFO - 2023-03-15 07:35:49 --> Router Class Initialized
INFO - 2023-03-15 07:35:49 --> Output Class Initialized
INFO - 2023-03-15 07:35:49 --> Security Class Initialized
DEBUG - 2023-03-15 07:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:35:49 --> Input Class Initialized
INFO - 2023-03-15 07:35:49 --> Language Class Initialized
INFO - 2023-03-15 07:35:49 --> Loader Class Initialized
INFO - 2023-03-15 07:35:49 --> Controller Class Initialized
DEBUG - 2023-03-15 07:35:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:35:49 --> Database Driver Class Initialized
INFO - 2023-03-15 07:35:49 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:36:01 --> Config Class Initialized
INFO - 2023-03-15 07:36:01 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:36:01 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:36:01 --> Utf8 Class Initialized
INFO - 2023-03-15 07:36:01 --> URI Class Initialized
INFO - 2023-03-15 07:36:01 --> Router Class Initialized
INFO - 2023-03-15 07:36:01 --> Output Class Initialized
INFO - 2023-03-15 07:36:01 --> Security Class Initialized
DEBUG - 2023-03-15 07:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:36:01 --> Input Class Initialized
INFO - 2023-03-15 07:36:01 --> Language Class Initialized
INFO - 2023-03-15 07:36:01 --> Loader Class Initialized
INFO - 2023-03-15 07:36:01 --> Controller Class Initialized
DEBUG - 2023-03-15 07:36:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-03-15 07:36:01 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 227
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-03-15 07:36:01 --> Config Class Initialized
INFO - 2023-03-15 07:36:01 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:36:01 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:36:01 --> Utf8 Class Initialized
INFO - 2023-03-15 07:36:01 --> URI Class Initialized
INFO - 2023-03-15 07:36:01 --> Router Class Initialized
INFO - 2023-03-15 07:36:01 --> Output Class Initialized
INFO - 2023-03-15 07:36:01 --> Security Class Initialized
DEBUG - 2023-03-15 07:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:36:01 --> Input Class Initialized
INFO - 2023-03-15 07:36:01 --> Language Class Initialized
INFO - 2023-03-15 07:36:01 --> Loader Class Initialized
INFO - 2023-03-15 07:36:01 --> Controller Class Initialized
DEBUG - 2023-03-15 07:36:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:36:01 --> Database Driver Class Initialized
INFO - 2023-03-15 07:36:01 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:36:01 --> Final output sent to browser
DEBUG - 2023-03-15 07:36:01 --> Total execution time: 0.0205
INFO - 2023-03-15 07:36:02 --> Config Class Initialized
INFO - 2023-03-15 07:36:02 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:36:02 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:36:02 --> Utf8 Class Initialized
INFO - 2023-03-15 07:36:02 --> URI Class Initialized
INFO - 2023-03-15 07:36:02 --> Router Class Initialized
INFO - 2023-03-15 07:36:02 --> Output Class Initialized
INFO - 2023-03-15 07:36:02 --> Security Class Initialized
DEBUG - 2023-03-15 07:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:36:02 --> Input Class Initialized
INFO - 2023-03-15 07:36:02 --> Language Class Initialized
INFO - 2023-03-15 07:36:02 --> Loader Class Initialized
INFO - 2023-03-15 07:36:02 --> Controller Class Initialized
DEBUG - 2023-03-15 07:36:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:36:02 --> Final output sent to browser
DEBUG - 2023-03-15 07:36:02 --> Total execution time: 0.0046
INFO - 2023-03-15 07:36:02 --> Config Class Initialized
INFO - 2023-03-15 07:36:02 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:36:02 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:36:02 --> Utf8 Class Initialized
INFO - 2023-03-15 07:36:02 --> URI Class Initialized
INFO - 2023-03-15 07:36:02 --> Router Class Initialized
INFO - 2023-03-15 07:36:02 --> Output Class Initialized
INFO - 2023-03-15 07:36:02 --> Security Class Initialized
DEBUG - 2023-03-15 07:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:36:02 --> Input Class Initialized
INFO - 2023-03-15 07:36:02 --> Language Class Initialized
INFO - 2023-03-15 07:36:02 --> Loader Class Initialized
INFO - 2023-03-15 07:36:02 --> Controller Class Initialized
DEBUG - 2023-03-15 07:36:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:36:02 --> Database Driver Class Initialized
INFO - 2023-03-15 07:36:02 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:36:02 --> Final output sent to browser
DEBUG - 2023-03-15 07:36:02 --> Total execution time: 0.0158
INFO - 2023-03-15 07:42:13 --> Config Class Initialized
INFO - 2023-03-15 07:42:13 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:42:13 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:42:13 --> Utf8 Class Initialized
INFO - 2023-03-15 07:42:13 --> URI Class Initialized
INFO - 2023-03-15 07:42:13 --> Router Class Initialized
INFO - 2023-03-15 07:42:13 --> Output Class Initialized
INFO - 2023-03-15 07:42:13 --> Security Class Initialized
DEBUG - 2023-03-15 07:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:42:13 --> Input Class Initialized
INFO - 2023-03-15 07:42:13 --> Language Class Initialized
INFO - 2023-03-15 07:42:13 --> Loader Class Initialized
INFO - 2023-03-15 07:42:13 --> Controller Class Initialized
DEBUG - 2023-03-15 07:42:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:42:13 --> Database Driver Class Initialized
INFO - 2023-03-15 07:42:13 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:42:13 --> Config Class Initialized
INFO - 2023-03-15 07:42:13 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:42:13 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:42:13 --> Utf8 Class Initialized
INFO - 2023-03-15 07:42:13 --> URI Class Initialized
INFO - 2023-03-15 07:42:13 --> Router Class Initialized
INFO - 2023-03-15 07:42:13 --> Output Class Initialized
INFO - 2023-03-15 07:42:13 --> Security Class Initialized
DEBUG - 2023-03-15 07:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:42:13 --> Input Class Initialized
INFO - 2023-03-15 07:42:13 --> Language Class Initialized
INFO - 2023-03-15 07:42:13 --> Loader Class Initialized
INFO - 2023-03-15 07:42:13 --> Controller Class Initialized
DEBUG - 2023-03-15 07:42:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:42:13 --> Database Driver Class Initialized
INFO - 2023-03-15 07:42:13 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:42:14 --> Config Class Initialized
INFO - 2023-03-15 07:42:14 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:42:14 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:42:14 --> Utf8 Class Initialized
INFO - 2023-03-15 07:42:14 --> URI Class Initialized
INFO - 2023-03-15 07:42:14 --> Router Class Initialized
INFO - 2023-03-15 07:42:14 --> Output Class Initialized
INFO - 2023-03-15 07:42:14 --> Security Class Initialized
INFO - 2023-03-15 07:42:14 --> Config Class Initialized
DEBUG - 2023-03-15 07:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:42:14 --> Hooks Class Initialized
INFO - 2023-03-15 07:42:14 --> Input Class Initialized
INFO - 2023-03-15 07:42:14 --> Language Class Initialized
DEBUG - 2023-03-15 07:42:14 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:42:14 --> Loader Class Initialized
INFO - 2023-03-15 07:42:14 --> Utf8 Class Initialized
INFO - 2023-03-15 07:42:14 --> Controller Class Initialized
DEBUG - 2023-03-15 07:42:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:42:14 --> URI Class Initialized
INFO - 2023-03-15 07:42:14 --> Router Class Initialized
INFO - 2023-03-15 07:42:14 --> Database Driver Class Initialized
INFO - 2023-03-15 07:42:14 --> Output Class Initialized
INFO - 2023-03-15 07:42:14 --> Security Class Initialized
DEBUG - 2023-03-15 07:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:42:14 --> Input Class Initialized
INFO - 2023-03-15 07:42:14 --> Language Class Initialized
INFO - 2023-03-15 07:42:14 --> Loader Class Initialized
INFO - 2023-03-15 07:42:14 --> Controller Class Initialized
DEBUG - 2023-03-15 07:42:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:42:14 --> Database Driver Class Initialized
INFO - 2023-03-15 07:42:14 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:42:14 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:42:14 --> Final output sent to browser
DEBUG - 2023-03-15 07:42:14 --> Total execution time: 0.0180
INFO - 2023-03-15 07:42:14 --> Config Class Initialized
INFO - 2023-03-15 07:42:14 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:42:14 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:42:14 --> Utf8 Class Initialized
INFO - 2023-03-15 07:42:14 --> URI Class Initialized
INFO - 2023-03-15 07:42:14 --> Router Class Initialized
INFO - 2023-03-15 07:42:14 --> Output Class Initialized
INFO - 2023-03-15 07:42:14 --> Security Class Initialized
DEBUG - 2023-03-15 07:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:42:14 --> Input Class Initialized
INFO - 2023-03-15 07:42:14 --> Language Class Initialized
INFO - 2023-03-15 07:42:14 --> Loader Class Initialized
INFO - 2023-03-15 07:42:14 --> Controller Class Initialized
DEBUG - 2023-03-15 07:42:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:42:14 --> Database Driver Class Initialized
INFO - 2023-03-15 07:42:14 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:42:14 --> Final output sent to browser
DEBUG - 2023-03-15 07:42:14 --> Total execution time: 0.0551
INFO - 2023-03-15 07:42:14 --> Config Class Initialized
INFO - 2023-03-15 07:42:14 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:42:14 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:42:14 --> Utf8 Class Initialized
INFO - 2023-03-15 07:42:14 --> URI Class Initialized
INFO - 2023-03-15 07:42:14 --> Router Class Initialized
INFO - 2023-03-15 07:42:14 --> Output Class Initialized
INFO - 2023-03-15 07:42:14 --> Security Class Initialized
DEBUG - 2023-03-15 07:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:42:14 --> Input Class Initialized
INFO - 2023-03-15 07:42:14 --> Language Class Initialized
INFO - 2023-03-15 07:42:14 --> Loader Class Initialized
INFO - 2023-03-15 07:42:14 --> Controller Class Initialized
DEBUG - 2023-03-15 07:42:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:42:14 --> Database Driver Class Initialized
INFO - 2023-03-15 07:42:14 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:49:16 --> Config Class Initialized
INFO - 2023-03-15 07:49:16 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:49:16 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:49:16 --> Utf8 Class Initialized
INFO - 2023-03-15 07:49:16 --> URI Class Initialized
INFO - 2023-03-15 07:49:16 --> Router Class Initialized
INFO - 2023-03-15 07:49:16 --> Output Class Initialized
INFO - 2023-03-15 07:49:16 --> Security Class Initialized
DEBUG - 2023-03-15 07:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:49:16 --> Input Class Initialized
INFO - 2023-03-15 07:49:16 --> Language Class Initialized
INFO - 2023-03-15 07:49:16 --> Loader Class Initialized
INFO - 2023-03-15 07:49:16 --> Controller Class Initialized
DEBUG - 2023-03-15 07:49:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:49:16 --> Database Driver Class Initialized
INFO - 2023-03-15 07:49:16 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:50:29 --> Config Class Initialized
INFO - 2023-03-15 07:50:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:50:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:50:29 --> Utf8 Class Initialized
INFO - 2023-03-15 07:50:29 --> URI Class Initialized
INFO - 2023-03-15 07:50:29 --> Router Class Initialized
INFO - 2023-03-15 07:50:29 --> Output Class Initialized
INFO - 2023-03-15 07:50:29 --> Security Class Initialized
DEBUG - 2023-03-15 07:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:50:29 --> Input Class Initialized
INFO - 2023-03-15 07:50:29 --> Language Class Initialized
INFO - 2023-03-15 07:50:29 --> Loader Class Initialized
INFO - 2023-03-15 07:50:29 --> Controller Class Initialized
DEBUG - 2023-03-15 07:50:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:50:29 --> Database Driver Class Initialized
INFO - 2023-03-15 07:50:29 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:50:29 --> Config Class Initialized
INFO - 2023-03-15 07:50:29 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:50:29 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:50:29 --> Utf8 Class Initialized
INFO - 2023-03-15 07:50:29 --> URI Class Initialized
INFO - 2023-03-15 07:50:29 --> Router Class Initialized
INFO - 2023-03-15 07:50:29 --> Output Class Initialized
INFO - 2023-03-15 07:50:29 --> Security Class Initialized
DEBUG - 2023-03-15 07:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:50:29 --> Input Class Initialized
INFO - 2023-03-15 07:50:29 --> Language Class Initialized
INFO - 2023-03-15 07:50:29 --> Loader Class Initialized
INFO - 2023-03-15 07:50:29 --> Controller Class Initialized
DEBUG - 2023-03-15 07:50:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:50:29 --> Database Driver Class Initialized
INFO - 2023-03-15 07:50:29 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:50:41 --> Config Class Initialized
INFO - 2023-03-15 07:50:41 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:50:41 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:50:41 --> Utf8 Class Initialized
INFO - 2023-03-15 07:50:41 --> URI Class Initialized
INFO - 2023-03-15 07:50:41 --> Router Class Initialized
INFO - 2023-03-15 07:50:41 --> Output Class Initialized
INFO - 2023-03-15 07:50:41 --> Security Class Initialized
DEBUG - 2023-03-15 07:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:50:41 --> Input Class Initialized
INFO - 2023-03-15 07:50:41 --> Language Class Initialized
INFO - 2023-03-15 07:50:41 --> Loader Class Initialized
INFO - 2023-03-15 07:50:41 --> Controller Class Initialized
DEBUG - 2023-03-15 07:50:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:50:41 --> Database Driver Class Initialized
INFO - 2023-03-15 07:50:41 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:50:41 --> Config Class Initialized
INFO - 2023-03-15 07:50:41 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:50:41 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:50:41 --> Utf8 Class Initialized
INFO - 2023-03-15 07:50:41 --> URI Class Initialized
INFO - 2023-03-15 07:50:41 --> Router Class Initialized
INFO - 2023-03-15 07:50:41 --> Output Class Initialized
INFO - 2023-03-15 07:50:41 --> Security Class Initialized
DEBUG - 2023-03-15 07:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:50:42 --> Input Class Initialized
INFO - 2023-03-15 07:50:42 --> Language Class Initialized
INFO - 2023-03-15 07:50:42 --> Loader Class Initialized
INFO - 2023-03-15 07:50:42 --> Controller Class Initialized
DEBUG - 2023-03-15 07:50:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:50:42 --> Database Driver Class Initialized
INFO - 2023-03-15 07:50:42 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:50:42 --> Config Class Initialized
INFO - 2023-03-15 07:50:42 --> Config Class Initialized
INFO - 2023-03-15 07:50:42 --> Hooks Class Initialized
INFO - 2023-03-15 07:50:42 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:50:42 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:50:42 --> Utf8 Class Initialized
DEBUG - 2023-03-15 07:50:42 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:50:42 --> URI Class Initialized
INFO - 2023-03-15 07:50:42 --> Utf8 Class Initialized
INFO - 2023-03-15 07:50:42 --> Router Class Initialized
INFO - 2023-03-15 07:50:42 --> URI Class Initialized
INFO - 2023-03-15 07:50:42 --> Output Class Initialized
INFO - 2023-03-15 07:50:42 --> Router Class Initialized
INFO - 2023-03-15 07:50:42 --> Security Class Initialized
INFO - 2023-03-15 07:50:42 --> Output Class Initialized
DEBUG - 2023-03-15 07:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:50:42 --> Security Class Initialized
INFO - 2023-03-15 07:50:42 --> Input Class Initialized
DEBUG - 2023-03-15 07:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:50:42 --> Language Class Initialized
INFO - 2023-03-15 07:50:42 --> Input Class Initialized
INFO - 2023-03-15 07:50:42 --> Loader Class Initialized
INFO - 2023-03-15 07:50:42 --> Language Class Initialized
INFO - 2023-03-15 07:50:42 --> Controller Class Initialized
INFO - 2023-03-15 07:50:42 --> Loader Class Initialized
DEBUG - 2023-03-15 07:50:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:50:42 --> Controller Class Initialized
DEBUG - 2023-03-15 07:50:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:50:42 --> Database Driver Class Initialized
INFO - 2023-03-15 07:50:42 --> Database Driver Class Initialized
INFO - 2023-03-15 07:50:42 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:50:42 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:50:42 --> Final output sent to browser
DEBUG - 2023-03-15 07:50:42 --> Total execution time: 0.0540
INFO - 2023-03-15 07:50:42 --> Config Class Initialized
INFO - 2023-03-15 07:50:42 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:50:42 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:50:42 --> Utf8 Class Initialized
INFO - 2023-03-15 07:50:42 --> URI Class Initialized
INFO - 2023-03-15 07:50:42 --> Router Class Initialized
INFO - 2023-03-15 07:50:42 --> Output Class Initialized
INFO - 2023-03-15 07:50:42 --> Security Class Initialized
DEBUG - 2023-03-15 07:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:50:42 --> Input Class Initialized
INFO - 2023-03-15 07:50:42 --> Language Class Initialized
INFO - 2023-03-15 07:50:42 --> Loader Class Initialized
INFO - 2023-03-15 07:50:42 --> Controller Class Initialized
DEBUG - 2023-03-15 07:50:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:50:42 --> Database Driver Class Initialized
INFO - 2023-03-15 07:50:42 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:50:42 --> Final output sent to browser
DEBUG - 2023-03-15 07:50:42 --> Total execution time: 0.0116
INFO - 2023-03-15 07:50:43 --> Config Class Initialized
INFO - 2023-03-15 07:50:43 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:50:43 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:50:43 --> Utf8 Class Initialized
INFO - 2023-03-15 07:50:43 --> URI Class Initialized
INFO - 2023-03-15 07:50:43 --> Router Class Initialized
INFO - 2023-03-15 07:50:43 --> Output Class Initialized
INFO - 2023-03-15 07:50:43 --> Security Class Initialized
DEBUG - 2023-03-15 07:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:50:43 --> Input Class Initialized
INFO - 2023-03-15 07:50:43 --> Language Class Initialized
INFO - 2023-03-15 07:50:43 --> Loader Class Initialized
INFO - 2023-03-15 07:50:43 --> Controller Class Initialized
DEBUG - 2023-03-15 07:50:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:50:43 --> Database Driver Class Initialized
INFO - 2023-03-15 07:50:43 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:24 --> Config Class Initialized
INFO - 2023-03-15 07:52:24 --> Config Class Initialized
INFO - 2023-03-15 07:52:24 --> Hooks Class Initialized
INFO - 2023-03-15 07:52:24 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:24 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:52:24 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:24 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:24 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:24 --> URI Class Initialized
INFO - 2023-03-15 07:52:24 --> URI Class Initialized
INFO - 2023-03-15 07:52:24 --> Router Class Initialized
INFO - 2023-03-15 07:52:24 --> Router Class Initialized
INFO - 2023-03-15 07:52:24 --> Output Class Initialized
INFO - 2023-03-15 07:52:24 --> Output Class Initialized
INFO - 2023-03-15 07:52:24 --> Security Class Initialized
INFO - 2023-03-15 07:52:24 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:24 --> Input Class Initialized
INFO - 2023-03-15 07:52:24 --> Input Class Initialized
INFO - 2023-03-15 07:52:24 --> Language Class Initialized
INFO - 2023-03-15 07:52:24 --> Language Class Initialized
INFO - 2023-03-15 07:52:24 --> Loader Class Initialized
INFO - 2023-03-15 07:52:24 --> Loader Class Initialized
INFO - 2023-03-15 07:52:24 --> Controller Class Initialized
INFO - 2023-03-15 07:52:24 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:52:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:52:24 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:24 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:24 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:24 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:24 --> Final output sent to browser
DEBUG - 2023-03-15 07:52:24 --> Total execution time: 0.0532
INFO - 2023-03-15 07:52:24 --> Config Class Initialized
INFO - 2023-03-15 07:52:25 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:25 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:25 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:25 --> URI Class Initialized
INFO - 2023-03-15 07:52:25 --> Router Class Initialized
INFO - 2023-03-15 07:52:25 --> Output Class Initialized
INFO - 2023-03-15 07:52:25 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:25 --> Input Class Initialized
INFO - 2023-03-15 07:52:25 --> Language Class Initialized
INFO - 2023-03-15 07:52:25 --> Loader Class Initialized
INFO - 2023-03-15 07:52:25 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:52:25 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:25 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:25 --> Final output sent to browser
DEBUG - 2023-03-15 07:52:25 --> Total execution time: 0.1315
INFO - 2023-03-15 07:52:25 --> Config Class Initialized
INFO - 2023-03-15 07:52:25 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:25 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:25 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:25 --> URI Class Initialized
INFO - 2023-03-15 07:52:25 --> Router Class Initialized
INFO - 2023-03-15 07:52:25 --> Output Class Initialized
INFO - 2023-03-15 07:52:25 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:25 --> Input Class Initialized
INFO - 2023-03-15 07:52:25 --> Language Class Initialized
INFO - 2023-03-15 07:52:25 --> Loader Class Initialized
INFO - 2023-03-15 07:52:25 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:52:25 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:25 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:35 --> Config Class Initialized
INFO - 2023-03-15 07:52:35 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:35 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:35 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:35 --> URI Class Initialized
INFO - 2023-03-15 07:52:35 --> Router Class Initialized
INFO - 2023-03-15 07:52:35 --> Output Class Initialized
INFO - 2023-03-15 07:52:35 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:35 --> Input Class Initialized
INFO - 2023-03-15 07:52:35 --> Language Class Initialized
INFO - 2023-03-15 07:52:35 --> Loader Class Initialized
INFO - 2023-03-15 07:52:35 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:52:35 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:35 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:35 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:35 --> Model "Login_model" initialized
INFO - 2023-03-15 07:52:35 --> Final output sent to browser
DEBUG - 2023-03-15 07:52:35 --> Total execution time: 0.1322
INFO - 2023-03-15 07:52:35 --> Config Class Initialized
INFO - 2023-03-15 07:52:35 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:35 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:35 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:35 --> URI Class Initialized
INFO - 2023-03-15 07:52:35 --> Router Class Initialized
INFO - 2023-03-15 07:52:35 --> Output Class Initialized
INFO - 2023-03-15 07:52:35 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:35 --> Input Class Initialized
INFO - 2023-03-15 07:52:35 --> Language Class Initialized
INFO - 2023-03-15 07:52:35 --> Loader Class Initialized
INFO - 2023-03-15 07:52:35 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:52:35 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:35 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:35 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:35 --> Model "Login_model" initialized
INFO - 2023-03-15 07:52:35 --> Final output sent to browser
DEBUG - 2023-03-15 07:52:35 --> Total execution time: 0.1223
INFO - 2023-03-15 07:52:40 --> Config Class Initialized
INFO - 2023-03-15 07:52:40 --> Config Class Initialized
INFO - 2023-03-15 07:52:40 --> Hooks Class Initialized
INFO - 2023-03-15 07:52:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:40 --> UTF-8 Support Enabled
DEBUG - 2023-03-15 07:52:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:40 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:40 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:40 --> URI Class Initialized
INFO - 2023-03-15 07:52:40 --> URI Class Initialized
INFO - 2023-03-15 07:52:40 --> Router Class Initialized
INFO - 2023-03-15 07:52:40 --> Router Class Initialized
INFO - 2023-03-15 07:52:40 --> Output Class Initialized
INFO - 2023-03-15 07:52:40 --> Output Class Initialized
INFO - 2023-03-15 07:52:40 --> Security Class Initialized
INFO - 2023-03-15 07:52:40 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-15 07:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:40 --> Input Class Initialized
INFO - 2023-03-15 07:52:40 --> Input Class Initialized
INFO - 2023-03-15 07:52:40 --> Language Class Initialized
INFO - 2023-03-15 07:52:40 --> Language Class Initialized
INFO - 2023-03-15 07:52:40 --> Loader Class Initialized
INFO - 2023-03-15 07:52:40 --> Loader Class Initialized
INFO - 2023-03-15 07:52:40 --> Controller Class Initialized
INFO - 2023-03-15 07:52:40 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-15 07:52:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:52:40 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:40 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:40 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:40 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:40 --> Final output sent to browser
DEBUG - 2023-03-15 07:52:40 --> Total execution time: 0.0167
INFO - 2023-03-15 07:52:40 --> Config Class Initialized
INFO - 2023-03-15 07:52:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:40 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:40 --> URI Class Initialized
INFO - 2023-03-15 07:52:40 --> Router Class Initialized
INFO - 2023-03-15 07:52:40 --> Output Class Initialized
INFO - 2023-03-15 07:52:40 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:40 --> Input Class Initialized
INFO - 2023-03-15 07:52:40 --> Language Class Initialized
INFO - 2023-03-15 07:52:40 --> Loader Class Initialized
INFO - 2023-03-15 07:52:40 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:52:40 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:40 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:40 --> Final output sent to browser
DEBUG - 2023-03-15 07:52:40 --> Total execution time: 0.0568
INFO - 2023-03-15 07:52:40 --> Config Class Initialized
INFO - 2023-03-15 07:52:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:40 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:40 --> URI Class Initialized
INFO - 2023-03-15 07:52:40 --> Router Class Initialized
INFO - 2023-03-15 07:52:40 --> Output Class Initialized
INFO - 2023-03-15 07:52:40 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:40 --> Input Class Initialized
INFO - 2023-03-15 07:52:40 --> Language Class Initialized
INFO - 2023-03-15 07:52:40 --> Loader Class Initialized
INFO - 2023-03-15 07:52:40 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:52:40 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:40 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:42 --> Config Class Initialized
INFO - 2023-03-15 07:52:42 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:42 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:42 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:42 --> URI Class Initialized
INFO - 2023-03-15 07:52:42 --> Router Class Initialized
INFO - 2023-03-15 07:52:42 --> Output Class Initialized
INFO - 2023-03-15 07:52:42 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:42 --> Input Class Initialized
INFO - 2023-03-15 07:52:42 --> Language Class Initialized
INFO - 2023-03-15 07:52:42 --> Loader Class Initialized
INFO - 2023-03-15 07:52:42 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:52:42 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:42 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:42 --> Config Class Initialized
INFO - 2023-03-15 07:52:42 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:42 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:42 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:42 --> URI Class Initialized
INFO - 2023-03-15 07:52:42 --> Router Class Initialized
INFO - 2023-03-15 07:52:42 --> Output Class Initialized
INFO - 2023-03-15 07:52:42 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:42 --> Input Class Initialized
INFO - 2023-03-15 07:52:42 --> Language Class Initialized
INFO - 2023-03-15 07:52:42 --> Loader Class Initialized
INFO - 2023-03-15 07:52:42 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:52:42 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:42 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:57 --> Config Class Initialized
INFO - 2023-03-15 07:52:57 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:57 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:57 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:57 --> URI Class Initialized
INFO - 2023-03-15 07:52:57 --> Router Class Initialized
INFO - 2023-03-15 07:52:57 --> Output Class Initialized
INFO - 2023-03-15 07:52:57 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:57 --> Input Class Initialized
INFO - 2023-03-15 07:52:57 --> Language Class Initialized
INFO - 2023-03-15 07:52:57 --> Loader Class Initialized
INFO - 2023-03-15 07:52:57 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-03-15 07:52:57 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 227
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-03-15 07:52:57 --> Config Class Initialized
INFO - 2023-03-15 07:52:57 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:57 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:57 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:57 --> URI Class Initialized
INFO - 2023-03-15 07:52:57 --> Router Class Initialized
INFO - 2023-03-15 07:52:57 --> Output Class Initialized
INFO - 2023-03-15 07:52:57 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:57 --> Input Class Initialized
INFO - 2023-03-15 07:52:57 --> Language Class Initialized
INFO - 2023-03-15 07:52:57 --> Loader Class Initialized
INFO - 2023-03-15 07:52:57 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:52:57 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:57 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:57 --> Final output sent to browser
DEBUG - 2023-03-15 07:52:57 --> Total execution time: 0.0257
INFO - 2023-03-15 07:52:58 --> Config Class Initialized
INFO - 2023-03-15 07:52:58 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:58 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:58 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:58 --> URI Class Initialized
INFO - 2023-03-15 07:52:58 --> Router Class Initialized
INFO - 2023-03-15 07:52:58 --> Output Class Initialized
INFO - 2023-03-15 07:52:58 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:58 --> Input Class Initialized
INFO - 2023-03-15 07:52:58 --> Language Class Initialized
INFO - 2023-03-15 07:52:58 --> Loader Class Initialized
INFO - 2023-03-15 07:52:58 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:52:58 --> Final output sent to browser
DEBUG - 2023-03-15 07:52:58 --> Total execution time: 0.0024
INFO - 2023-03-15 07:52:58 --> Config Class Initialized
INFO - 2023-03-15 07:52:58 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:52:58 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:52:58 --> Utf8 Class Initialized
INFO - 2023-03-15 07:52:58 --> URI Class Initialized
INFO - 2023-03-15 07:52:58 --> Router Class Initialized
INFO - 2023-03-15 07:52:58 --> Output Class Initialized
INFO - 2023-03-15 07:52:58 --> Security Class Initialized
DEBUG - 2023-03-15 07:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:52:58 --> Input Class Initialized
INFO - 2023-03-15 07:52:58 --> Language Class Initialized
INFO - 2023-03-15 07:52:58 --> Loader Class Initialized
INFO - 2023-03-15 07:52:58 --> Controller Class Initialized
DEBUG - 2023-03-15 07:52:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:52:58 --> Database Driver Class Initialized
INFO - 2023-03-15 07:52:58 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:52:58 --> Final output sent to browser
DEBUG - 2023-03-15 07:52:58 --> Total execution time: 0.0145
INFO - 2023-03-15 07:53:40 --> Config Class Initialized
INFO - 2023-03-15 07:53:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:53:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:53:40 --> Utf8 Class Initialized
INFO - 2023-03-15 07:53:40 --> URI Class Initialized
INFO - 2023-03-15 07:53:40 --> Router Class Initialized
INFO - 2023-03-15 07:53:40 --> Output Class Initialized
INFO - 2023-03-15 07:53:40 --> Security Class Initialized
DEBUG - 2023-03-15 07:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:53:40 --> Input Class Initialized
INFO - 2023-03-15 07:53:40 --> Language Class Initialized
INFO - 2023-03-15 07:53:40 --> Loader Class Initialized
INFO - 2023-03-15 07:53:40 --> Controller Class Initialized
DEBUG - 2023-03-15 07:53:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:53:40 --> Database Driver Class Initialized
INFO - 2023-03-15 07:53:40 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:53:40 --> Final output sent to browser
DEBUG - 2023-03-15 07:53:40 --> Total execution time: 0.0522
INFO - 2023-03-15 07:53:40 --> Config Class Initialized
INFO - 2023-03-15 07:53:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:53:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:53:41 --> Utf8 Class Initialized
INFO - 2023-03-15 07:53:41 --> URI Class Initialized
INFO - 2023-03-15 07:53:41 --> Router Class Initialized
INFO - 2023-03-15 07:53:41 --> Output Class Initialized
INFO - 2023-03-15 07:53:41 --> Security Class Initialized
DEBUG - 2023-03-15 07:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:53:41 --> Input Class Initialized
INFO - 2023-03-15 07:53:41 --> Language Class Initialized
INFO - 2023-03-15 07:53:41 --> Loader Class Initialized
INFO - 2023-03-15 07:53:41 --> Controller Class Initialized
DEBUG - 2023-03-15 07:53:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:53:41 --> Database Driver Class Initialized
INFO - 2023-03-15 07:53:41 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:53:41 --> Final output sent to browser
DEBUG - 2023-03-15 07:53:41 --> Total execution time: 0.0952
INFO - 2023-03-15 07:53:43 --> Config Class Initialized
INFO - 2023-03-15 07:53:43 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:53:43 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:53:43 --> Utf8 Class Initialized
INFO - 2023-03-15 07:53:43 --> URI Class Initialized
INFO - 2023-03-15 07:53:43 --> Router Class Initialized
INFO - 2023-03-15 07:53:43 --> Output Class Initialized
INFO - 2023-03-15 07:53:43 --> Security Class Initialized
DEBUG - 2023-03-15 07:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:53:43 --> Input Class Initialized
INFO - 2023-03-15 07:53:43 --> Language Class Initialized
INFO - 2023-03-15 07:53:43 --> Loader Class Initialized
INFO - 2023-03-15 07:53:43 --> Controller Class Initialized
DEBUG - 2023-03-15 07:53:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:53:43 --> Database Driver Class Initialized
INFO - 2023-03-15 07:53:43 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:53:43 --> Final output sent to browser
DEBUG - 2023-03-15 07:53:43 --> Total execution time: 0.0358
INFO - 2023-03-15 07:53:43 --> Config Class Initialized
INFO - 2023-03-15 07:53:43 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:53:43 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:53:43 --> Utf8 Class Initialized
INFO - 2023-03-15 07:53:43 --> URI Class Initialized
INFO - 2023-03-15 07:53:43 --> Router Class Initialized
INFO - 2023-03-15 07:53:43 --> Output Class Initialized
INFO - 2023-03-15 07:53:43 --> Security Class Initialized
DEBUG - 2023-03-15 07:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:53:43 --> Input Class Initialized
INFO - 2023-03-15 07:53:43 --> Language Class Initialized
INFO - 2023-03-15 07:53:43 --> Loader Class Initialized
INFO - 2023-03-15 07:53:43 --> Controller Class Initialized
DEBUG - 2023-03-15 07:53:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:53:43 --> Database Driver Class Initialized
INFO - 2023-03-15 07:53:43 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:53:43 --> Final output sent to browser
DEBUG - 2023-03-15 07:53:43 --> Total execution time: 0.0131
INFO - 2023-03-15 07:55:09 --> Config Class Initialized
INFO - 2023-03-15 07:55:10 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:55:10 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:55:10 --> Utf8 Class Initialized
INFO - 2023-03-15 07:55:10 --> URI Class Initialized
INFO - 2023-03-15 07:55:10 --> Router Class Initialized
INFO - 2023-03-15 07:55:10 --> Output Class Initialized
INFO - 2023-03-15 07:55:10 --> Security Class Initialized
DEBUG - 2023-03-15 07:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:55:10 --> Input Class Initialized
INFO - 2023-03-15 07:55:10 --> Language Class Initialized
INFO - 2023-03-15 07:55:10 --> Loader Class Initialized
INFO - 2023-03-15 07:55:10 --> Controller Class Initialized
DEBUG - 2023-03-15 07:55:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:55:10 --> Database Driver Class Initialized
INFO - 2023-03-15 07:55:10 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:55:23 --> Config Class Initialized
INFO - 2023-03-15 07:55:23 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:55:23 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:55:23 --> Utf8 Class Initialized
INFO - 2023-03-15 07:55:23 --> URI Class Initialized
INFO - 2023-03-15 07:55:23 --> Router Class Initialized
INFO - 2023-03-15 07:55:23 --> Output Class Initialized
INFO - 2023-03-15 07:55:23 --> Security Class Initialized
DEBUG - 2023-03-15 07:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:55:23 --> Input Class Initialized
INFO - 2023-03-15 07:55:23 --> Language Class Initialized
INFO - 2023-03-15 07:55:23 --> Loader Class Initialized
INFO - 2023-03-15 07:55:23 --> Controller Class Initialized
DEBUG - 2023-03-15 07:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:55:23 --> Database Driver Class Initialized
INFO - 2023-03-15 07:55:23 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:55:23 --> Final output sent to browser
DEBUG - 2023-03-15 07:55:23 --> Total execution time: 0.0472
INFO - 2023-03-15 07:55:23 --> Config Class Initialized
INFO - 2023-03-15 07:55:23 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:55:23 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:55:23 --> Utf8 Class Initialized
INFO - 2023-03-15 07:55:23 --> URI Class Initialized
INFO - 2023-03-15 07:55:23 --> Router Class Initialized
INFO - 2023-03-15 07:55:23 --> Output Class Initialized
INFO - 2023-03-15 07:55:23 --> Security Class Initialized
DEBUG - 2023-03-15 07:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:55:23 --> Input Class Initialized
INFO - 2023-03-15 07:55:23 --> Language Class Initialized
INFO - 2023-03-15 07:55:23 --> Loader Class Initialized
INFO - 2023-03-15 07:55:23 --> Controller Class Initialized
DEBUG - 2023-03-15 07:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:55:23 --> Database Driver Class Initialized
INFO - 2023-03-15 07:55:23 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:55:23 --> Final output sent to browser
DEBUG - 2023-03-15 07:55:23 --> Total execution time: 0.0853
INFO - 2023-03-15 07:55:26 --> Config Class Initialized
INFO - 2023-03-15 07:55:26 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:55:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:55:26 --> Utf8 Class Initialized
INFO - 2023-03-15 07:55:26 --> URI Class Initialized
INFO - 2023-03-15 07:55:26 --> Router Class Initialized
INFO - 2023-03-15 07:55:26 --> Output Class Initialized
INFO - 2023-03-15 07:55:26 --> Security Class Initialized
DEBUG - 2023-03-15 07:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:55:26 --> Input Class Initialized
INFO - 2023-03-15 07:55:26 --> Language Class Initialized
INFO - 2023-03-15 07:55:26 --> Loader Class Initialized
INFO - 2023-03-15 07:55:26 --> Controller Class Initialized
DEBUG - 2023-03-15 07:55:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:55:26 --> Database Driver Class Initialized
INFO - 2023-03-15 07:55:26 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:55:26 --> Database Driver Class Initialized
INFO - 2023-03-15 07:55:26 --> Model "Login_model" initialized
INFO - 2023-03-15 07:55:26 --> Final output sent to browser
DEBUG - 2023-03-15 07:55:26 --> Total execution time: 0.0576
INFO - 2023-03-15 07:55:26 --> Config Class Initialized
INFO - 2023-03-15 07:55:26 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:55:26 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:55:26 --> Utf8 Class Initialized
INFO - 2023-03-15 07:55:26 --> URI Class Initialized
INFO - 2023-03-15 07:55:26 --> Router Class Initialized
INFO - 2023-03-15 07:55:26 --> Output Class Initialized
INFO - 2023-03-15 07:55:26 --> Security Class Initialized
DEBUG - 2023-03-15 07:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:55:26 --> Input Class Initialized
INFO - 2023-03-15 07:55:26 --> Language Class Initialized
INFO - 2023-03-15 07:55:26 --> Loader Class Initialized
INFO - 2023-03-15 07:55:26 --> Controller Class Initialized
DEBUG - 2023-03-15 07:55:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:55:26 --> Database Driver Class Initialized
INFO - 2023-03-15 07:55:26 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:55:26 --> Database Driver Class Initialized
INFO - 2023-03-15 07:55:26 --> Model "Login_model" initialized
INFO - 2023-03-15 07:55:26 --> Final output sent to browser
DEBUG - 2023-03-15 07:55:26 --> Total execution time: 0.0818
INFO - 2023-03-15 07:55:30 --> Config Class Initialized
INFO - 2023-03-15 07:55:30 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:55:30 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:55:30 --> Utf8 Class Initialized
INFO - 2023-03-15 07:55:30 --> URI Class Initialized
INFO - 2023-03-15 07:55:30 --> Router Class Initialized
INFO - 2023-03-15 07:55:30 --> Output Class Initialized
INFO - 2023-03-15 07:55:30 --> Security Class Initialized
DEBUG - 2023-03-15 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:55:30 --> Input Class Initialized
INFO - 2023-03-15 07:55:30 --> Language Class Initialized
INFO - 2023-03-15 07:55:30 --> Loader Class Initialized
INFO - 2023-03-15 07:55:30 --> Controller Class Initialized
DEBUG - 2023-03-15 07:55:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:55:30 --> Database Driver Class Initialized
INFO - 2023-03-15 07:55:30 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:55:30 --> Final output sent to browser
DEBUG - 2023-03-15 07:55:30 --> Total execution time: 0.0180
INFO - 2023-03-15 07:55:30 --> Config Class Initialized
INFO - 2023-03-15 07:55:30 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:55:30 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:55:30 --> Utf8 Class Initialized
INFO - 2023-03-15 07:55:30 --> URI Class Initialized
INFO - 2023-03-15 07:55:30 --> Router Class Initialized
INFO - 2023-03-15 07:55:30 --> Output Class Initialized
INFO - 2023-03-15 07:55:30 --> Security Class Initialized
DEBUG - 2023-03-15 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:55:30 --> Input Class Initialized
INFO - 2023-03-15 07:55:30 --> Language Class Initialized
INFO - 2023-03-15 07:55:30 --> Loader Class Initialized
INFO - 2023-03-15 07:55:30 --> Controller Class Initialized
DEBUG - 2023-03-15 07:55:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:55:30 --> Database Driver Class Initialized
INFO - 2023-03-15 07:55:30 --> Model "Cluster_model" initialized
INFO - 2023-03-15 07:55:30 --> Final output sent to browser
DEBUG - 2023-03-15 07:55:30 --> Total execution time: 0.0571
INFO - 2023-03-15 07:55:32 --> Config Class Initialized
INFO - 2023-03-15 07:55:32 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:55:32 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:55:32 --> Utf8 Class Initialized
INFO - 2023-03-15 07:55:32 --> URI Class Initialized
INFO - 2023-03-15 07:55:32 --> Router Class Initialized
INFO - 2023-03-15 07:55:32 --> Output Class Initialized
INFO - 2023-03-15 07:55:32 --> Security Class Initialized
DEBUG - 2023-03-15 07:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:55:32 --> Input Class Initialized
INFO - 2023-03-15 07:55:32 --> Language Class Initialized
INFO - 2023-03-15 07:55:32 --> Loader Class Initialized
INFO - 2023-03-15 07:55:32 --> Controller Class Initialized
DEBUG - 2023-03-15 07:55:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:55:32 --> Database Driver Class Initialized
INFO - 2023-03-15 07:55:32 --> Database Driver Class Initialized
INFO - 2023-03-15 07:55:32 --> Model "Login_model" initialized
INFO - 2023-03-15 07:55:32 --> Final output sent to browser
DEBUG - 2023-03-15 07:55:32 --> Total execution time: 0.1423
INFO - 2023-03-15 07:55:32 --> Config Class Initialized
INFO - 2023-03-15 07:55:33 --> Hooks Class Initialized
DEBUG - 2023-03-15 07:55:33 --> UTF-8 Support Enabled
INFO - 2023-03-15 07:55:33 --> Utf8 Class Initialized
INFO - 2023-03-15 07:55:33 --> URI Class Initialized
INFO - 2023-03-15 07:55:33 --> Router Class Initialized
INFO - 2023-03-15 07:55:33 --> Output Class Initialized
INFO - 2023-03-15 07:55:33 --> Security Class Initialized
DEBUG - 2023-03-15 07:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 07:55:33 --> Input Class Initialized
INFO - 2023-03-15 07:55:33 --> Language Class Initialized
INFO - 2023-03-15 07:55:33 --> Loader Class Initialized
INFO - 2023-03-15 07:55:33 --> Controller Class Initialized
DEBUG - 2023-03-15 07:55:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 07:55:33 --> Database Driver Class Initialized
INFO - 2023-03-15 07:55:33 --> Database Driver Class Initialized
INFO - 2023-03-15 07:55:33 --> Model "Login_model" initialized
INFO - 2023-03-15 07:55:33 --> Final output sent to browser
DEBUG - 2023-03-15 07:55:33 --> Total execution time: 0.0695
INFO - 2023-03-15 08:04:58 --> Config Class Initialized
INFO - 2023-03-15 08:04:58 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:04:58 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:04:58 --> Utf8 Class Initialized
INFO - 2023-03-15 08:04:58 --> URI Class Initialized
INFO - 2023-03-15 08:04:58 --> Router Class Initialized
INFO - 2023-03-15 08:04:58 --> Output Class Initialized
INFO - 2023-03-15 08:04:58 --> Security Class Initialized
DEBUG - 2023-03-15 08:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:04:58 --> Input Class Initialized
INFO - 2023-03-15 08:04:58 --> Language Class Initialized
INFO - 2023-03-15 08:04:58 --> Loader Class Initialized
INFO - 2023-03-15 08:04:58 --> Controller Class Initialized
DEBUG - 2023-03-15 08:04:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:04:58 --> Database Driver Class Initialized
INFO - 2023-03-15 08:04:58 --> Database Driver Class Initialized
INFO - 2023-03-15 08:04:58 --> Model "Login_model" initialized
INFO - 2023-03-15 08:04:58 --> Final output sent to browser
DEBUG - 2023-03-15 08:04:58 --> Total execution time: 0.1239
INFO - 2023-03-15 08:04:58 --> Config Class Initialized
INFO - 2023-03-15 08:04:58 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:04:58 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:04:58 --> Utf8 Class Initialized
INFO - 2023-03-15 08:04:58 --> URI Class Initialized
INFO - 2023-03-15 08:04:58 --> Router Class Initialized
INFO - 2023-03-15 08:04:58 --> Output Class Initialized
INFO - 2023-03-15 08:04:58 --> Security Class Initialized
DEBUG - 2023-03-15 08:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:04:58 --> Input Class Initialized
INFO - 2023-03-15 08:04:58 --> Language Class Initialized
INFO - 2023-03-15 08:04:58 --> Loader Class Initialized
INFO - 2023-03-15 08:04:58 --> Controller Class Initialized
DEBUG - 2023-03-15 08:04:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:04:58 --> Database Driver Class Initialized
INFO - 2023-03-15 08:04:58 --> Database Driver Class Initialized
INFO - 2023-03-15 08:04:58 --> Model "Login_model" initialized
INFO - 2023-03-15 08:04:58 --> Final output sent to browser
DEBUG - 2023-03-15 08:04:58 --> Total execution time: 0.0656
INFO - 2023-03-15 08:05:33 --> Config Class Initialized
INFO - 2023-03-15 08:05:33 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:05:33 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:05:33 --> Utf8 Class Initialized
INFO - 2023-03-15 08:05:33 --> URI Class Initialized
INFO - 2023-03-15 08:05:33 --> Router Class Initialized
INFO - 2023-03-15 08:05:33 --> Output Class Initialized
INFO - 2023-03-15 08:05:33 --> Security Class Initialized
DEBUG - 2023-03-15 08:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:05:33 --> Input Class Initialized
INFO - 2023-03-15 08:05:33 --> Language Class Initialized
INFO - 2023-03-15 08:05:33 --> Loader Class Initialized
INFO - 2023-03-15 08:05:33 --> Controller Class Initialized
DEBUG - 2023-03-15 08:05:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:05:33 --> Database Driver Class Initialized
INFO - 2023-03-15 08:05:33 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:05:33 --> Final output sent to browser
DEBUG - 2023-03-15 08:05:33 --> Total execution time: 0.0605
INFO - 2023-03-15 08:05:33 --> Config Class Initialized
INFO - 2023-03-15 08:05:33 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:05:33 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:05:33 --> Utf8 Class Initialized
INFO - 2023-03-15 08:05:33 --> URI Class Initialized
INFO - 2023-03-15 08:05:33 --> Router Class Initialized
INFO - 2023-03-15 08:05:33 --> Output Class Initialized
INFO - 2023-03-15 08:05:33 --> Security Class Initialized
DEBUG - 2023-03-15 08:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:05:33 --> Input Class Initialized
INFO - 2023-03-15 08:05:33 --> Language Class Initialized
INFO - 2023-03-15 08:05:33 --> Loader Class Initialized
INFO - 2023-03-15 08:05:33 --> Controller Class Initialized
DEBUG - 2023-03-15 08:05:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:05:33 --> Database Driver Class Initialized
INFO - 2023-03-15 08:05:33 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:05:33 --> Final output sent to browser
DEBUG - 2023-03-15 08:05:33 --> Total execution time: 0.0526
INFO - 2023-03-15 08:28:32 --> Config Class Initialized
INFO - 2023-03-15 08:28:32 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:28:32 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:28:32 --> Utf8 Class Initialized
INFO - 2023-03-15 08:28:32 --> URI Class Initialized
INFO - 2023-03-15 08:28:32 --> Router Class Initialized
INFO - 2023-03-15 08:28:32 --> Output Class Initialized
INFO - 2023-03-15 08:28:32 --> Security Class Initialized
DEBUG - 2023-03-15 08:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:28:32 --> Input Class Initialized
INFO - 2023-03-15 08:28:32 --> Language Class Initialized
INFO - 2023-03-15 08:28:32 --> Loader Class Initialized
INFO - 2023-03-15 08:28:32 --> Controller Class Initialized
DEBUG - 2023-03-15 08:28:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:28:32 --> Database Driver Class Initialized
INFO - 2023-03-15 08:28:32 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:28:32 --> Database Driver Class Initialized
INFO - 2023-03-15 08:28:32 --> Model "Login_model" initialized
INFO - 2023-03-15 08:28:32 --> Final output sent to browser
DEBUG - 2023-03-15 08:28:32 --> Total execution time: 0.0708
INFO - 2023-03-15 08:28:32 --> Config Class Initialized
INFO - 2023-03-15 08:28:32 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:28:32 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:28:32 --> Utf8 Class Initialized
INFO - 2023-03-15 08:28:32 --> URI Class Initialized
INFO - 2023-03-15 08:28:32 --> Router Class Initialized
INFO - 2023-03-15 08:28:32 --> Output Class Initialized
INFO - 2023-03-15 08:28:32 --> Security Class Initialized
DEBUG - 2023-03-15 08:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:28:32 --> Input Class Initialized
INFO - 2023-03-15 08:28:32 --> Language Class Initialized
INFO - 2023-03-15 08:28:32 --> Loader Class Initialized
INFO - 2023-03-15 08:28:32 --> Controller Class Initialized
DEBUG - 2023-03-15 08:28:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:28:32 --> Database Driver Class Initialized
INFO - 2023-03-15 08:28:32 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:28:32 --> Database Driver Class Initialized
INFO - 2023-03-15 08:28:32 --> Model "Login_model" initialized
INFO - 2023-03-15 08:28:32 --> Final output sent to browser
DEBUG - 2023-03-15 08:28:32 --> Total execution time: 0.0847
INFO - 2023-03-15 08:48:11 --> Config Class Initialized
INFO - 2023-03-15 08:48:11 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:48:11 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:48:11 --> Utf8 Class Initialized
INFO - 2023-03-15 08:48:11 --> URI Class Initialized
INFO - 2023-03-15 08:48:11 --> Router Class Initialized
INFO - 2023-03-15 08:48:11 --> Output Class Initialized
INFO - 2023-03-15 08:48:11 --> Security Class Initialized
DEBUG - 2023-03-15 08:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:48:11 --> Input Class Initialized
INFO - 2023-03-15 08:48:11 --> Language Class Initialized
INFO - 2023-03-15 08:48:11 --> Loader Class Initialized
INFO - 2023-03-15 08:48:11 --> Controller Class Initialized
DEBUG - 2023-03-15 08:48:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:48:11 --> Database Driver Class Initialized
INFO - 2023-03-15 08:48:11 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:48:11 --> Final output sent to browser
DEBUG - 2023-03-15 08:48:11 --> Total execution time: 0.0229
INFO - 2023-03-15 08:48:11 --> Config Class Initialized
INFO - 2023-03-15 08:48:11 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:48:11 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:48:11 --> Utf8 Class Initialized
INFO - 2023-03-15 08:48:11 --> URI Class Initialized
INFO - 2023-03-15 08:48:11 --> Router Class Initialized
INFO - 2023-03-15 08:48:11 --> Output Class Initialized
INFO - 2023-03-15 08:48:11 --> Security Class Initialized
DEBUG - 2023-03-15 08:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:48:11 --> Input Class Initialized
INFO - 2023-03-15 08:48:11 --> Language Class Initialized
INFO - 2023-03-15 08:48:11 --> Loader Class Initialized
INFO - 2023-03-15 08:48:11 --> Controller Class Initialized
DEBUG - 2023-03-15 08:48:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:48:11 --> Database Driver Class Initialized
INFO - 2023-03-15 08:48:11 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:48:11 --> Final output sent to browser
DEBUG - 2023-03-15 08:48:11 --> Total execution time: 0.0606
INFO - 2023-03-15 08:48:20 --> Config Class Initialized
INFO - 2023-03-15 08:48:20 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:48:20 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:48:20 --> Utf8 Class Initialized
INFO - 2023-03-15 08:48:20 --> URI Class Initialized
INFO - 2023-03-15 08:48:20 --> Router Class Initialized
INFO - 2023-03-15 08:48:20 --> Output Class Initialized
INFO - 2023-03-15 08:48:20 --> Security Class Initialized
DEBUG - 2023-03-15 08:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:48:20 --> Input Class Initialized
INFO - 2023-03-15 08:48:20 --> Language Class Initialized
INFO - 2023-03-15 08:48:20 --> Loader Class Initialized
INFO - 2023-03-15 08:48:20 --> Controller Class Initialized
DEBUG - 2023-03-15 08:48:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:48:20 --> Database Driver Class Initialized
INFO - 2023-03-15 08:48:20 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:48:20 --> Final output sent to browser
DEBUG - 2023-03-15 08:48:20 --> Total execution time: 0.0567
INFO - 2023-03-15 08:48:20 --> Config Class Initialized
INFO - 2023-03-15 08:48:20 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:48:20 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:48:20 --> Utf8 Class Initialized
INFO - 2023-03-15 08:48:20 --> URI Class Initialized
INFO - 2023-03-15 08:48:20 --> Router Class Initialized
INFO - 2023-03-15 08:48:20 --> Output Class Initialized
INFO - 2023-03-15 08:48:20 --> Security Class Initialized
DEBUG - 2023-03-15 08:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:48:20 --> Input Class Initialized
INFO - 2023-03-15 08:48:20 --> Language Class Initialized
INFO - 2023-03-15 08:48:20 --> Loader Class Initialized
INFO - 2023-03-15 08:48:20 --> Controller Class Initialized
DEBUG - 2023-03-15 08:48:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:48:20 --> Database Driver Class Initialized
INFO - 2023-03-15 08:48:20 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:48:20 --> Final output sent to browser
DEBUG - 2023-03-15 08:48:20 --> Total execution time: 0.0390
INFO - 2023-03-15 08:49:15 --> Config Class Initialized
INFO - 2023-03-15 08:49:15 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:49:15 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:49:15 --> Utf8 Class Initialized
INFO - 2023-03-15 08:49:15 --> URI Class Initialized
INFO - 2023-03-15 08:49:15 --> Router Class Initialized
INFO - 2023-03-15 08:49:15 --> Output Class Initialized
INFO - 2023-03-15 08:49:15 --> Security Class Initialized
DEBUG - 2023-03-15 08:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:49:15 --> Input Class Initialized
INFO - 2023-03-15 08:49:15 --> Language Class Initialized
INFO - 2023-03-15 08:49:15 --> Loader Class Initialized
INFO - 2023-03-15 08:49:15 --> Controller Class Initialized
DEBUG - 2023-03-15 08:49:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:49:15 --> Database Driver Class Initialized
INFO - 2023-03-15 08:49:15 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:49:15 --> Final output sent to browser
DEBUG - 2023-03-15 08:49:15 --> Total execution time: 0.0138
INFO - 2023-03-15 08:49:15 --> Config Class Initialized
INFO - 2023-03-15 08:49:15 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:49:15 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:49:15 --> Utf8 Class Initialized
INFO - 2023-03-15 08:49:15 --> URI Class Initialized
INFO - 2023-03-15 08:49:15 --> Router Class Initialized
INFO - 2023-03-15 08:49:15 --> Output Class Initialized
INFO - 2023-03-15 08:49:15 --> Security Class Initialized
DEBUG - 2023-03-15 08:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:49:15 --> Input Class Initialized
INFO - 2023-03-15 08:49:15 --> Language Class Initialized
INFO - 2023-03-15 08:49:15 --> Loader Class Initialized
INFO - 2023-03-15 08:49:15 --> Controller Class Initialized
DEBUG - 2023-03-15 08:49:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:49:15 --> Database Driver Class Initialized
INFO - 2023-03-15 08:49:15 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:49:15 --> Final output sent to browser
DEBUG - 2023-03-15 08:49:15 --> Total execution time: 0.0119
INFO - 2023-03-15 08:59:53 --> Config Class Initialized
INFO - 2023-03-15 08:59:53 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:59:53 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:59:53 --> Utf8 Class Initialized
INFO - 2023-03-15 08:59:53 --> URI Class Initialized
INFO - 2023-03-15 08:59:53 --> Router Class Initialized
INFO - 2023-03-15 08:59:53 --> Output Class Initialized
INFO - 2023-03-15 08:59:53 --> Security Class Initialized
DEBUG - 2023-03-15 08:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:59:53 --> Input Class Initialized
INFO - 2023-03-15 08:59:53 --> Language Class Initialized
INFO - 2023-03-15 08:59:53 --> Loader Class Initialized
INFO - 2023-03-15 08:59:53 --> Controller Class Initialized
DEBUG - 2023-03-15 08:59:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:59:53 --> Database Driver Class Initialized
INFO - 2023-03-15 08:59:53 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:59:53 --> Final output sent to browser
DEBUG - 2023-03-15 08:59:53 --> Total execution time: 0.0776
INFO - 2023-03-15 08:59:53 --> Config Class Initialized
INFO - 2023-03-15 08:59:53 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:59:53 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:59:53 --> Utf8 Class Initialized
INFO - 2023-03-15 08:59:53 --> URI Class Initialized
INFO - 2023-03-15 08:59:53 --> Router Class Initialized
INFO - 2023-03-15 08:59:53 --> Output Class Initialized
INFO - 2023-03-15 08:59:53 --> Security Class Initialized
DEBUG - 2023-03-15 08:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:59:53 --> Input Class Initialized
INFO - 2023-03-15 08:59:53 --> Language Class Initialized
INFO - 2023-03-15 08:59:53 --> Loader Class Initialized
INFO - 2023-03-15 08:59:53 --> Controller Class Initialized
DEBUG - 2023-03-15 08:59:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:59:53 --> Database Driver Class Initialized
INFO - 2023-03-15 08:59:53 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:59:53 --> Final output sent to browser
DEBUG - 2023-03-15 08:59:53 --> Total execution time: 0.0637
INFO - 2023-03-15 08:59:57 --> Config Class Initialized
INFO - 2023-03-15 08:59:57 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:59:57 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:59:57 --> Utf8 Class Initialized
INFO - 2023-03-15 08:59:57 --> URI Class Initialized
INFO - 2023-03-15 08:59:57 --> Router Class Initialized
INFO - 2023-03-15 08:59:57 --> Output Class Initialized
INFO - 2023-03-15 08:59:57 --> Security Class Initialized
DEBUG - 2023-03-15 08:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:59:57 --> Input Class Initialized
INFO - 2023-03-15 08:59:57 --> Language Class Initialized
INFO - 2023-03-15 08:59:57 --> Loader Class Initialized
INFO - 2023-03-15 08:59:57 --> Controller Class Initialized
DEBUG - 2023-03-15 08:59:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:59:57 --> Database Driver Class Initialized
INFO - 2023-03-15 08:59:57 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:59:57 --> Final output sent to browser
DEBUG - 2023-03-15 08:59:57 --> Total execution time: 0.0496
INFO - 2023-03-15 08:59:57 --> Config Class Initialized
INFO - 2023-03-15 08:59:57 --> Hooks Class Initialized
DEBUG - 2023-03-15 08:59:57 --> UTF-8 Support Enabled
INFO - 2023-03-15 08:59:57 --> Utf8 Class Initialized
INFO - 2023-03-15 08:59:57 --> URI Class Initialized
INFO - 2023-03-15 08:59:57 --> Router Class Initialized
INFO - 2023-03-15 08:59:57 --> Output Class Initialized
INFO - 2023-03-15 08:59:57 --> Security Class Initialized
DEBUG - 2023-03-15 08:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 08:59:57 --> Input Class Initialized
INFO - 2023-03-15 08:59:57 --> Language Class Initialized
INFO - 2023-03-15 08:59:57 --> Loader Class Initialized
INFO - 2023-03-15 08:59:57 --> Controller Class Initialized
DEBUG - 2023-03-15 08:59:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 08:59:57 --> Database Driver Class Initialized
INFO - 2023-03-15 08:59:58 --> Model "Cluster_model" initialized
INFO - 2023-03-15 08:59:58 --> Final output sent to browser
DEBUG - 2023-03-15 08:59:58 --> Total execution time: 0.0723
INFO - 2023-03-15 09:00:01 --> Config Class Initialized
INFO - 2023-03-15 09:00:01 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:00:01 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:00:01 --> Utf8 Class Initialized
INFO - 2023-03-15 09:00:01 --> URI Class Initialized
INFO - 2023-03-15 09:00:01 --> Router Class Initialized
INFO - 2023-03-15 09:00:01 --> Output Class Initialized
INFO - 2023-03-15 09:00:01 --> Security Class Initialized
DEBUG - 2023-03-15 09:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:00:01 --> Input Class Initialized
INFO - 2023-03-15 09:00:01 --> Language Class Initialized
INFO - 2023-03-15 09:00:01 --> Loader Class Initialized
INFO - 2023-03-15 09:00:01 --> Controller Class Initialized
DEBUG - 2023-03-15 09:00:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:00:01 --> Database Driver Class Initialized
INFO - 2023-03-15 09:00:01 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:00:01 --> Final output sent to browser
DEBUG - 2023-03-15 09:00:01 --> Total execution time: 0.0750
INFO - 2023-03-15 09:00:01 --> Config Class Initialized
INFO - 2023-03-15 09:00:01 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:00:01 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:00:01 --> Utf8 Class Initialized
INFO - 2023-03-15 09:00:01 --> URI Class Initialized
INFO - 2023-03-15 09:00:01 --> Router Class Initialized
INFO - 2023-03-15 09:00:01 --> Output Class Initialized
INFO - 2023-03-15 09:00:01 --> Security Class Initialized
DEBUG - 2023-03-15 09:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:00:01 --> Input Class Initialized
INFO - 2023-03-15 09:00:01 --> Language Class Initialized
INFO - 2023-03-15 09:00:01 --> Loader Class Initialized
INFO - 2023-03-15 09:00:01 --> Controller Class Initialized
DEBUG - 2023-03-15 09:00:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:00:01 --> Database Driver Class Initialized
INFO - 2023-03-15 09:00:01 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:00:01 --> Final output sent to browser
DEBUG - 2023-03-15 09:00:01 --> Total execution time: 0.0498
INFO - 2023-03-15 09:48:57 --> Config Class Initialized
INFO - 2023-03-15 09:48:57 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:48:57 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:48:57 --> Utf8 Class Initialized
INFO - 2023-03-15 09:48:57 --> URI Class Initialized
INFO - 2023-03-15 09:48:57 --> Router Class Initialized
INFO - 2023-03-15 09:48:57 --> Output Class Initialized
INFO - 2023-03-15 09:48:57 --> Security Class Initialized
DEBUG - 2023-03-15 09:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:48:57 --> Input Class Initialized
INFO - 2023-03-15 09:48:57 --> Language Class Initialized
INFO - 2023-03-15 09:48:57 --> Loader Class Initialized
INFO - 2023-03-15 09:48:57 --> Controller Class Initialized
DEBUG - 2023-03-15 09:48:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:48:57 --> Database Driver Class Initialized
INFO - 2023-03-15 09:48:57 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:48:57 --> Final output sent to browser
DEBUG - 2023-03-15 09:48:57 --> Total execution time: 0.1819
INFO - 2023-03-15 09:48:57 --> Config Class Initialized
INFO - 2023-03-15 09:48:57 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:48:57 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:48:57 --> Utf8 Class Initialized
INFO - 2023-03-15 09:48:57 --> URI Class Initialized
INFO - 2023-03-15 09:48:57 --> Router Class Initialized
INFO - 2023-03-15 09:48:57 --> Output Class Initialized
INFO - 2023-03-15 09:48:57 --> Security Class Initialized
DEBUG - 2023-03-15 09:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:48:57 --> Input Class Initialized
INFO - 2023-03-15 09:48:57 --> Language Class Initialized
INFO - 2023-03-15 09:48:57 --> Loader Class Initialized
INFO - 2023-03-15 09:48:57 --> Controller Class Initialized
DEBUG - 2023-03-15 09:48:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:48:57 --> Database Driver Class Initialized
INFO - 2023-03-15 09:48:57 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:48:57 --> Final output sent to browser
DEBUG - 2023-03-15 09:48:57 --> Total execution time: 0.0779
INFO - 2023-03-15 09:49:02 --> Config Class Initialized
INFO - 2023-03-15 09:49:02 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:49:02 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:49:02 --> Utf8 Class Initialized
INFO - 2023-03-15 09:49:02 --> URI Class Initialized
INFO - 2023-03-15 09:49:02 --> Router Class Initialized
INFO - 2023-03-15 09:49:02 --> Output Class Initialized
INFO - 2023-03-15 09:49:02 --> Security Class Initialized
DEBUG - 2023-03-15 09:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:49:02 --> Input Class Initialized
INFO - 2023-03-15 09:49:02 --> Language Class Initialized
INFO - 2023-03-15 09:49:02 --> Loader Class Initialized
INFO - 2023-03-15 09:49:02 --> Controller Class Initialized
DEBUG - 2023-03-15 09:49:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:49:02 --> Database Driver Class Initialized
INFO - 2023-03-15 09:49:02 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:49:02 --> Final output sent to browser
DEBUG - 2023-03-15 09:49:02 --> Total execution time: 0.0732
INFO - 2023-03-15 09:49:02 --> Config Class Initialized
INFO - 2023-03-15 09:49:02 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:49:02 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:49:02 --> Utf8 Class Initialized
INFO - 2023-03-15 09:49:02 --> URI Class Initialized
INFO - 2023-03-15 09:49:02 --> Router Class Initialized
INFO - 2023-03-15 09:49:02 --> Output Class Initialized
INFO - 2023-03-15 09:49:02 --> Security Class Initialized
DEBUG - 2023-03-15 09:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:49:02 --> Input Class Initialized
INFO - 2023-03-15 09:49:02 --> Language Class Initialized
INFO - 2023-03-15 09:49:02 --> Loader Class Initialized
INFO - 2023-03-15 09:49:02 --> Controller Class Initialized
DEBUG - 2023-03-15 09:49:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:49:02 --> Database Driver Class Initialized
INFO - 2023-03-15 09:49:02 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:49:02 --> Final output sent to browser
DEBUG - 2023-03-15 09:49:02 --> Total execution time: 0.0836
INFO - 2023-03-15 09:49:06 --> Config Class Initialized
INFO - 2023-03-15 09:49:06 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:49:06 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:49:06 --> Utf8 Class Initialized
INFO - 2023-03-15 09:49:06 --> URI Class Initialized
INFO - 2023-03-15 09:49:06 --> Router Class Initialized
INFO - 2023-03-15 09:49:06 --> Output Class Initialized
INFO - 2023-03-15 09:49:06 --> Security Class Initialized
DEBUG - 2023-03-15 09:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:49:06 --> Input Class Initialized
INFO - 2023-03-15 09:49:06 --> Language Class Initialized
INFO - 2023-03-15 09:49:06 --> Loader Class Initialized
INFO - 2023-03-15 09:49:06 --> Controller Class Initialized
DEBUG - 2023-03-15 09:49:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:49:06 --> Database Driver Class Initialized
INFO - 2023-03-15 09:49:06 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:49:06 --> Database Driver Class Initialized
INFO - 2023-03-15 09:49:06 --> Model "Login_model" initialized
INFO - 2023-03-15 09:49:06 --> Final output sent to browser
DEBUG - 2023-03-15 09:49:06 --> Total execution time: 0.0859
INFO - 2023-03-15 09:49:06 --> Config Class Initialized
INFO - 2023-03-15 09:49:06 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:49:06 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:49:06 --> Utf8 Class Initialized
INFO - 2023-03-15 09:49:06 --> URI Class Initialized
INFO - 2023-03-15 09:49:06 --> Router Class Initialized
INFO - 2023-03-15 09:49:06 --> Output Class Initialized
INFO - 2023-03-15 09:49:06 --> Security Class Initialized
DEBUG - 2023-03-15 09:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:49:06 --> Input Class Initialized
INFO - 2023-03-15 09:49:06 --> Language Class Initialized
INFO - 2023-03-15 09:49:06 --> Loader Class Initialized
INFO - 2023-03-15 09:49:06 --> Controller Class Initialized
DEBUG - 2023-03-15 09:49:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:49:06 --> Database Driver Class Initialized
INFO - 2023-03-15 09:49:06 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:49:06 --> Database Driver Class Initialized
INFO - 2023-03-15 09:49:06 --> Model "Login_model" initialized
INFO - 2023-03-15 09:49:06 --> Final output sent to browser
DEBUG - 2023-03-15 09:49:06 --> Total execution time: 0.0892
INFO - 2023-03-15 09:49:21 --> Config Class Initialized
INFO - 2023-03-15 09:49:21 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:49:21 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:49:21 --> Utf8 Class Initialized
INFO - 2023-03-15 09:49:21 --> URI Class Initialized
INFO - 2023-03-15 09:49:21 --> Router Class Initialized
INFO - 2023-03-15 09:49:21 --> Output Class Initialized
INFO - 2023-03-15 09:49:21 --> Security Class Initialized
DEBUG - 2023-03-15 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:49:21 --> Input Class Initialized
INFO - 2023-03-15 09:49:21 --> Language Class Initialized
INFO - 2023-03-15 09:49:21 --> Loader Class Initialized
INFO - 2023-03-15 09:49:21 --> Controller Class Initialized
DEBUG - 2023-03-15 09:49:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:49:21 --> Database Driver Class Initialized
INFO - 2023-03-15 09:49:21 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:49:21 --> Final output sent to browser
DEBUG - 2023-03-15 09:49:21 --> Total execution time: 0.0790
INFO - 2023-03-15 09:49:21 --> Config Class Initialized
INFO - 2023-03-15 09:49:21 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:49:21 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:49:21 --> Utf8 Class Initialized
INFO - 2023-03-15 09:49:21 --> URI Class Initialized
INFO - 2023-03-15 09:49:21 --> Router Class Initialized
INFO - 2023-03-15 09:49:21 --> Output Class Initialized
INFO - 2023-03-15 09:49:21 --> Security Class Initialized
DEBUG - 2023-03-15 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:49:21 --> Input Class Initialized
INFO - 2023-03-15 09:49:21 --> Language Class Initialized
INFO - 2023-03-15 09:49:21 --> Loader Class Initialized
INFO - 2023-03-15 09:49:21 --> Controller Class Initialized
DEBUG - 2023-03-15 09:49:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:49:21 --> Database Driver Class Initialized
INFO - 2023-03-15 09:49:21 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:49:21 --> Final output sent to browser
DEBUG - 2023-03-15 09:49:21 --> Total execution time: 0.0621
INFO - 2023-03-15 09:49:24 --> Config Class Initialized
INFO - 2023-03-15 09:49:24 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:49:24 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:49:24 --> Utf8 Class Initialized
INFO - 2023-03-15 09:49:24 --> URI Class Initialized
INFO - 2023-03-15 09:49:24 --> Router Class Initialized
INFO - 2023-03-15 09:49:24 --> Output Class Initialized
INFO - 2023-03-15 09:49:24 --> Security Class Initialized
DEBUG - 2023-03-15 09:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:49:24 --> Input Class Initialized
INFO - 2023-03-15 09:49:24 --> Language Class Initialized
INFO - 2023-03-15 09:49:24 --> Loader Class Initialized
INFO - 2023-03-15 09:49:24 --> Controller Class Initialized
DEBUG - 2023-03-15 09:49:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:49:24 --> Database Driver Class Initialized
INFO - 2023-03-15 09:49:24 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:49:24 --> Database Driver Class Initialized
INFO - 2023-03-15 09:49:24 --> Model "Login_model" initialized
INFO - 2023-03-15 09:49:24 --> Final output sent to browser
DEBUG - 2023-03-15 09:49:24 --> Total execution time: 0.0823
INFO - 2023-03-15 09:49:24 --> Config Class Initialized
INFO - 2023-03-15 09:49:24 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:49:24 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:49:24 --> Utf8 Class Initialized
INFO - 2023-03-15 09:49:24 --> URI Class Initialized
INFO - 2023-03-15 09:49:24 --> Router Class Initialized
INFO - 2023-03-15 09:49:24 --> Output Class Initialized
INFO - 2023-03-15 09:49:24 --> Security Class Initialized
DEBUG - 2023-03-15 09:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:49:24 --> Input Class Initialized
INFO - 2023-03-15 09:49:24 --> Language Class Initialized
INFO - 2023-03-15 09:49:24 --> Loader Class Initialized
INFO - 2023-03-15 09:49:24 --> Controller Class Initialized
DEBUG - 2023-03-15 09:49:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:49:24 --> Database Driver Class Initialized
INFO - 2023-03-15 09:49:24 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:49:24 --> Database Driver Class Initialized
INFO - 2023-03-15 09:49:24 --> Model "Login_model" initialized
INFO - 2023-03-15 09:49:24 --> Final output sent to browser
DEBUG - 2023-03-15 09:49:24 --> Total execution time: 0.0500
INFO - 2023-03-15 09:56:41 --> Config Class Initialized
INFO - 2023-03-15 09:56:41 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:56:41 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:56:41 --> Utf8 Class Initialized
INFO - 2023-03-15 09:56:41 --> URI Class Initialized
INFO - 2023-03-15 09:56:41 --> Router Class Initialized
INFO - 2023-03-15 09:56:41 --> Output Class Initialized
INFO - 2023-03-15 09:56:41 --> Security Class Initialized
DEBUG - 2023-03-15 09:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:56:41 --> Input Class Initialized
INFO - 2023-03-15 09:56:41 --> Language Class Initialized
INFO - 2023-03-15 09:56:41 --> Loader Class Initialized
INFO - 2023-03-15 09:56:41 --> Controller Class Initialized
DEBUG - 2023-03-15 09:56:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:56:41 --> Database Driver Class Initialized
INFO - 2023-03-15 09:56:41 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:56:41 --> Final output sent to browser
DEBUG - 2023-03-15 09:56:41 --> Total execution time: 0.0162
INFO - 2023-03-15 09:56:41 --> Config Class Initialized
INFO - 2023-03-15 09:56:41 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:56:41 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:56:41 --> Utf8 Class Initialized
INFO - 2023-03-15 09:56:41 --> URI Class Initialized
INFO - 2023-03-15 09:56:41 --> Router Class Initialized
INFO - 2023-03-15 09:56:41 --> Output Class Initialized
INFO - 2023-03-15 09:56:41 --> Security Class Initialized
DEBUG - 2023-03-15 09:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:56:41 --> Input Class Initialized
INFO - 2023-03-15 09:56:41 --> Language Class Initialized
INFO - 2023-03-15 09:56:41 --> Loader Class Initialized
INFO - 2023-03-15 09:56:41 --> Controller Class Initialized
DEBUG - 2023-03-15 09:56:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:56:41 --> Database Driver Class Initialized
INFO - 2023-03-15 09:56:41 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:56:41 --> Final output sent to browser
DEBUG - 2023-03-15 09:56:41 --> Total execution time: 0.0551
INFO - 2023-03-15 09:56:43 --> Config Class Initialized
INFO - 2023-03-15 09:56:43 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:56:43 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:56:43 --> Utf8 Class Initialized
INFO - 2023-03-15 09:56:43 --> URI Class Initialized
INFO - 2023-03-15 09:56:43 --> Router Class Initialized
INFO - 2023-03-15 09:56:43 --> Output Class Initialized
INFO - 2023-03-15 09:56:43 --> Security Class Initialized
DEBUG - 2023-03-15 09:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:56:43 --> Input Class Initialized
INFO - 2023-03-15 09:56:43 --> Language Class Initialized
INFO - 2023-03-15 09:56:43 --> Loader Class Initialized
INFO - 2023-03-15 09:56:43 --> Controller Class Initialized
DEBUG - 2023-03-15 09:56:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:56:43 --> Database Driver Class Initialized
INFO - 2023-03-15 09:56:43 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:56:43 --> Final output sent to browser
INFO - 2023-03-15 09:56:44 --> Config Class Initialized
DEBUG - 2023-03-15 09:56:44 --> Total execution time: 0.0562
INFO - 2023-03-15 09:56:44 --> Hooks Class Initialized
DEBUG - 2023-03-15 09:56:44 --> UTF-8 Support Enabled
INFO - 2023-03-15 09:56:44 --> Utf8 Class Initialized
INFO - 2023-03-15 09:56:44 --> URI Class Initialized
INFO - 2023-03-15 09:56:44 --> Router Class Initialized
INFO - 2023-03-15 09:56:44 --> Output Class Initialized
INFO - 2023-03-15 09:56:44 --> Security Class Initialized
DEBUG - 2023-03-15 09:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 09:56:44 --> Input Class Initialized
INFO - 2023-03-15 09:56:44 --> Language Class Initialized
INFO - 2023-03-15 09:56:44 --> Loader Class Initialized
INFO - 2023-03-15 09:56:44 --> Controller Class Initialized
DEBUG - 2023-03-15 09:56:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 09:56:44 --> Database Driver Class Initialized
INFO - 2023-03-15 09:56:44 --> Model "Cluster_model" initialized
INFO - 2023-03-15 09:56:44 --> Final output sent to browser
DEBUG - 2023-03-15 09:56:44 --> Total execution time: 0.0932
INFO - 2023-03-15 10:08:32 --> Config Class Initialized
INFO - 2023-03-15 10:08:32 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:08:32 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:08:32 --> Utf8 Class Initialized
INFO - 2023-03-15 10:08:32 --> URI Class Initialized
INFO - 2023-03-15 10:08:32 --> Router Class Initialized
INFO - 2023-03-15 10:08:32 --> Output Class Initialized
INFO - 2023-03-15 10:08:32 --> Security Class Initialized
DEBUG - 2023-03-15 10:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:08:32 --> Input Class Initialized
INFO - 2023-03-15 10:08:32 --> Language Class Initialized
INFO - 2023-03-15 10:08:32 --> Loader Class Initialized
INFO - 2023-03-15 10:08:32 --> Controller Class Initialized
DEBUG - 2023-03-15 10:08:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:08:32 --> Database Driver Class Initialized
INFO - 2023-03-15 10:08:32 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:08:32 --> Final output sent to browser
DEBUG - 2023-03-15 10:08:32 --> Total execution time: 0.0227
INFO - 2023-03-15 10:08:32 --> Config Class Initialized
INFO - 2023-03-15 10:08:32 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:08:32 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:08:32 --> Utf8 Class Initialized
INFO - 2023-03-15 10:08:32 --> URI Class Initialized
INFO - 2023-03-15 10:08:32 --> Router Class Initialized
INFO - 2023-03-15 10:08:32 --> Output Class Initialized
INFO - 2023-03-15 10:08:32 --> Security Class Initialized
DEBUG - 2023-03-15 10:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:08:32 --> Input Class Initialized
INFO - 2023-03-15 10:08:32 --> Language Class Initialized
INFO - 2023-03-15 10:08:32 --> Loader Class Initialized
INFO - 2023-03-15 10:08:32 --> Controller Class Initialized
DEBUG - 2023-03-15 10:08:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:08:32 --> Database Driver Class Initialized
INFO - 2023-03-15 10:08:32 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:08:32 --> Final output sent to browser
DEBUG - 2023-03-15 10:08:32 --> Total execution time: 0.0542
INFO - 2023-03-15 10:08:35 --> Config Class Initialized
INFO - 2023-03-15 10:08:35 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:08:35 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:08:35 --> Utf8 Class Initialized
INFO - 2023-03-15 10:08:35 --> URI Class Initialized
INFO - 2023-03-15 10:08:35 --> Router Class Initialized
INFO - 2023-03-15 10:08:35 --> Output Class Initialized
INFO - 2023-03-15 10:08:35 --> Security Class Initialized
DEBUG - 2023-03-15 10:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:08:35 --> Input Class Initialized
INFO - 2023-03-15 10:08:35 --> Language Class Initialized
INFO - 2023-03-15 10:08:35 --> Loader Class Initialized
INFO - 2023-03-15 10:08:35 --> Controller Class Initialized
DEBUG - 2023-03-15 10:08:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:08:35 --> Database Driver Class Initialized
INFO - 2023-03-15 10:08:35 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:08:35 --> Final output sent to browser
DEBUG - 2023-03-15 10:08:35 --> Total execution time: 0.0447
INFO - 2023-03-15 10:08:35 --> Config Class Initialized
INFO - 2023-03-15 10:08:35 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:08:35 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:08:35 --> Utf8 Class Initialized
INFO - 2023-03-15 10:08:35 --> URI Class Initialized
INFO - 2023-03-15 10:08:35 --> Router Class Initialized
INFO - 2023-03-15 10:08:35 --> Output Class Initialized
INFO - 2023-03-15 10:08:35 --> Security Class Initialized
DEBUG - 2023-03-15 10:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:08:35 --> Input Class Initialized
INFO - 2023-03-15 10:08:35 --> Language Class Initialized
INFO - 2023-03-15 10:08:35 --> Loader Class Initialized
INFO - 2023-03-15 10:08:35 --> Controller Class Initialized
DEBUG - 2023-03-15 10:08:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:08:35 --> Database Driver Class Initialized
INFO - 2023-03-15 10:08:35 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:08:35 --> Final output sent to browser
DEBUG - 2023-03-15 10:08:35 --> Total execution time: 0.0811
INFO - 2023-03-15 10:08:40 --> Config Class Initialized
INFO - 2023-03-15 10:08:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:08:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:08:40 --> Utf8 Class Initialized
INFO - 2023-03-15 10:08:40 --> URI Class Initialized
INFO - 2023-03-15 10:08:40 --> Router Class Initialized
INFO - 2023-03-15 10:08:40 --> Output Class Initialized
INFO - 2023-03-15 10:08:40 --> Security Class Initialized
DEBUG - 2023-03-15 10:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:08:40 --> Input Class Initialized
INFO - 2023-03-15 10:08:40 --> Language Class Initialized
INFO - 2023-03-15 10:08:40 --> Loader Class Initialized
INFO - 2023-03-15 10:08:40 --> Controller Class Initialized
DEBUG - 2023-03-15 10:08:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:08:40 --> Database Driver Class Initialized
INFO - 2023-03-15 10:08:40 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:08:40 --> Database Driver Class Initialized
INFO - 2023-03-15 10:08:40 --> Model "Login_model" initialized
INFO - 2023-03-15 10:08:40 --> Final output sent to browser
DEBUG - 2023-03-15 10:08:40 --> Total execution time: 0.0472
INFO - 2023-03-15 10:08:40 --> Config Class Initialized
INFO - 2023-03-15 10:08:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:08:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:08:40 --> Utf8 Class Initialized
INFO - 2023-03-15 10:08:40 --> URI Class Initialized
INFO - 2023-03-15 10:08:40 --> Router Class Initialized
INFO - 2023-03-15 10:08:40 --> Output Class Initialized
INFO - 2023-03-15 10:08:40 --> Security Class Initialized
DEBUG - 2023-03-15 10:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:08:40 --> Input Class Initialized
INFO - 2023-03-15 10:08:40 --> Language Class Initialized
INFO - 2023-03-15 10:08:40 --> Loader Class Initialized
INFO - 2023-03-15 10:08:40 --> Controller Class Initialized
DEBUG - 2023-03-15 10:08:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:08:40 --> Database Driver Class Initialized
INFO - 2023-03-15 10:08:40 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:08:40 --> Database Driver Class Initialized
INFO - 2023-03-15 10:08:40 --> Model "Login_model" initialized
INFO - 2023-03-15 10:08:41 --> Final output sent to browser
DEBUG - 2023-03-15 10:08:41 --> Total execution time: 0.0784
INFO - 2023-03-15 10:45:04 --> Config Class Initialized
INFO - 2023-03-15 10:45:04 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:45:04 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:45:04 --> Utf8 Class Initialized
INFO - 2023-03-15 10:45:04 --> URI Class Initialized
INFO - 2023-03-15 10:45:04 --> Router Class Initialized
INFO - 2023-03-15 10:45:04 --> Output Class Initialized
INFO - 2023-03-15 10:45:04 --> Security Class Initialized
DEBUG - 2023-03-15 10:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:45:04 --> Input Class Initialized
INFO - 2023-03-15 10:45:04 --> Language Class Initialized
INFO - 2023-03-15 10:45:04 --> Loader Class Initialized
INFO - 2023-03-15 10:45:04 --> Controller Class Initialized
DEBUG - 2023-03-15 10:45:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:45:04 --> Database Driver Class Initialized
INFO - 2023-03-15 10:45:04 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:45:04 --> Final output sent to browser
DEBUG - 2023-03-15 10:45:04 --> Total execution time: 0.0222
INFO - 2023-03-15 10:45:04 --> Config Class Initialized
INFO - 2023-03-15 10:45:04 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:45:04 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:45:04 --> Utf8 Class Initialized
INFO - 2023-03-15 10:45:04 --> URI Class Initialized
INFO - 2023-03-15 10:45:04 --> Router Class Initialized
INFO - 2023-03-15 10:45:04 --> Output Class Initialized
INFO - 2023-03-15 10:45:04 --> Security Class Initialized
DEBUG - 2023-03-15 10:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:45:04 --> Input Class Initialized
INFO - 2023-03-15 10:45:04 --> Language Class Initialized
INFO - 2023-03-15 10:45:04 --> Loader Class Initialized
INFO - 2023-03-15 10:45:04 --> Controller Class Initialized
DEBUG - 2023-03-15 10:45:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:45:04 --> Database Driver Class Initialized
INFO - 2023-03-15 10:45:04 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:45:04 --> Final output sent to browser
DEBUG - 2023-03-15 10:45:04 --> Total execution time: 0.0562
INFO - 2023-03-15 10:45:06 --> Config Class Initialized
INFO - 2023-03-15 10:45:06 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:45:06 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:45:06 --> Utf8 Class Initialized
INFO - 2023-03-15 10:45:06 --> URI Class Initialized
INFO - 2023-03-15 10:45:06 --> Router Class Initialized
INFO - 2023-03-15 10:45:06 --> Output Class Initialized
INFO - 2023-03-15 10:45:06 --> Security Class Initialized
DEBUG - 2023-03-15 10:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:45:06 --> Input Class Initialized
INFO - 2023-03-15 10:45:06 --> Language Class Initialized
INFO - 2023-03-15 10:45:06 --> Loader Class Initialized
INFO - 2023-03-15 10:45:06 --> Controller Class Initialized
DEBUG - 2023-03-15 10:45:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:45:06 --> Database Driver Class Initialized
INFO - 2023-03-15 10:45:06 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:45:06 --> Final output sent to browser
DEBUG - 2023-03-15 10:45:06 --> Total execution time: 0.1355
INFO - 2023-03-15 10:45:06 --> Config Class Initialized
INFO - 2023-03-15 10:45:06 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:45:06 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:45:06 --> Utf8 Class Initialized
INFO - 2023-03-15 10:45:06 --> URI Class Initialized
INFO - 2023-03-15 10:45:06 --> Router Class Initialized
INFO - 2023-03-15 10:45:06 --> Output Class Initialized
INFO - 2023-03-15 10:45:06 --> Security Class Initialized
DEBUG - 2023-03-15 10:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:45:06 --> Input Class Initialized
INFO - 2023-03-15 10:45:06 --> Language Class Initialized
INFO - 2023-03-15 10:45:06 --> Loader Class Initialized
INFO - 2023-03-15 10:45:06 --> Controller Class Initialized
DEBUG - 2023-03-15 10:45:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:45:06 --> Database Driver Class Initialized
INFO - 2023-03-15 10:45:06 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:45:06 --> Final output sent to browser
DEBUG - 2023-03-15 10:45:06 --> Total execution time: 0.0791
INFO - 2023-03-15 10:53:40 --> Config Class Initialized
INFO - 2023-03-15 10:53:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:53:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:53:40 --> Utf8 Class Initialized
INFO - 2023-03-15 10:53:40 --> URI Class Initialized
INFO - 2023-03-15 10:53:40 --> Router Class Initialized
INFO - 2023-03-15 10:53:40 --> Output Class Initialized
INFO - 2023-03-15 10:53:40 --> Security Class Initialized
DEBUG - 2023-03-15 10:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:53:40 --> Input Class Initialized
INFO - 2023-03-15 10:53:40 --> Language Class Initialized
INFO - 2023-03-15 10:53:40 --> Loader Class Initialized
INFO - 2023-03-15 10:53:40 --> Controller Class Initialized
DEBUG - 2023-03-15 10:53:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:53:40 --> Database Driver Class Initialized
INFO - 2023-03-15 10:53:40 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:53:40 --> Final output sent to browser
DEBUG - 2023-03-15 10:53:40 --> Total execution time: 0.0175
INFO - 2023-03-15 10:53:40 --> Config Class Initialized
INFO - 2023-03-15 10:53:40 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:53:40 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:53:40 --> Utf8 Class Initialized
INFO - 2023-03-15 10:53:40 --> URI Class Initialized
INFO - 2023-03-15 10:53:40 --> Router Class Initialized
INFO - 2023-03-15 10:53:40 --> Output Class Initialized
INFO - 2023-03-15 10:53:40 --> Security Class Initialized
DEBUG - 2023-03-15 10:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:53:40 --> Input Class Initialized
INFO - 2023-03-15 10:53:40 --> Language Class Initialized
INFO - 2023-03-15 10:53:40 --> Loader Class Initialized
INFO - 2023-03-15 10:53:40 --> Controller Class Initialized
DEBUG - 2023-03-15 10:53:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:53:40 --> Database Driver Class Initialized
INFO - 2023-03-15 10:53:40 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:53:40 --> Final output sent to browser
DEBUG - 2023-03-15 10:53:40 --> Total execution time: 0.0118
INFO - 2023-03-15 10:58:25 --> Config Class Initialized
INFO - 2023-03-15 10:58:25 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:58:25 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:58:25 --> Utf8 Class Initialized
INFO - 2023-03-15 10:58:25 --> URI Class Initialized
INFO - 2023-03-15 10:58:25 --> Router Class Initialized
INFO - 2023-03-15 10:58:25 --> Output Class Initialized
INFO - 2023-03-15 10:58:25 --> Security Class Initialized
DEBUG - 2023-03-15 10:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:58:25 --> Input Class Initialized
INFO - 2023-03-15 10:58:25 --> Language Class Initialized
INFO - 2023-03-15 10:58:25 --> Loader Class Initialized
INFO - 2023-03-15 10:58:25 --> Controller Class Initialized
DEBUG - 2023-03-15 10:58:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:58:25 --> Database Driver Class Initialized
INFO - 2023-03-15 10:58:25 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:58:25 --> Final output sent to browser
INFO - 2023-03-15 10:58:25 --> Config Class Initialized
DEBUG - 2023-03-15 10:58:25 --> Total execution time: 0.0476
INFO - 2023-03-15 10:58:25 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:58:25 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:58:25 --> Utf8 Class Initialized
INFO - 2023-03-15 10:58:25 --> URI Class Initialized
INFO - 2023-03-15 10:58:25 --> Router Class Initialized
INFO - 2023-03-15 10:58:25 --> Output Class Initialized
INFO - 2023-03-15 10:58:25 --> Security Class Initialized
DEBUG - 2023-03-15 10:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:58:25 --> Input Class Initialized
INFO - 2023-03-15 10:58:25 --> Language Class Initialized
INFO - 2023-03-15 10:58:25 --> Loader Class Initialized
INFO - 2023-03-15 10:58:25 --> Controller Class Initialized
DEBUG - 2023-03-15 10:58:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:58:25 --> Database Driver Class Initialized
INFO - 2023-03-15 10:58:25 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:58:25 --> Final output sent to browser
DEBUG - 2023-03-15 10:58:25 --> Total execution time: 0.0839
INFO - 2023-03-15 10:59:37 --> Config Class Initialized
INFO - 2023-03-15 10:59:37 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:59:37 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:59:37 --> Utf8 Class Initialized
INFO - 2023-03-15 10:59:37 --> URI Class Initialized
INFO - 2023-03-15 10:59:37 --> Router Class Initialized
INFO - 2023-03-15 10:59:37 --> Output Class Initialized
INFO - 2023-03-15 10:59:37 --> Security Class Initialized
DEBUG - 2023-03-15 10:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:59:37 --> Input Class Initialized
INFO - 2023-03-15 10:59:37 --> Language Class Initialized
INFO - 2023-03-15 10:59:37 --> Loader Class Initialized
INFO - 2023-03-15 10:59:37 --> Controller Class Initialized
DEBUG - 2023-03-15 10:59:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:59:37 --> Database Driver Class Initialized
INFO - 2023-03-15 10:59:37 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:59:37 --> Final output sent to browser
DEBUG - 2023-03-15 10:59:37 --> Total execution time: 0.0317
INFO - 2023-03-15 10:59:37 --> Config Class Initialized
INFO - 2023-03-15 10:59:37 --> Hooks Class Initialized
DEBUG - 2023-03-15 10:59:37 --> UTF-8 Support Enabled
INFO - 2023-03-15 10:59:37 --> Utf8 Class Initialized
INFO - 2023-03-15 10:59:37 --> URI Class Initialized
INFO - 2023-03-15 10:59:37 --> Router Class Initialized
INFO - 2023-03-15 10:59:37 --> Output Class Initialized
INFO - 2023-03-15 10:59:37 --> Security Class Initialized
DEBUG - 2023-03-15 10:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 10:59:37 --> Input Class Initialized
INFO - 2023-03-15 10:59:37 --> Language Class Initialized
INFO - 2023-03-15 10:59:37 --> Loader Class Initialized
INFO - 2023-03-15 10:59:37 --> Controller Class Initialized
DEBUG - 2023-03-15 10:59:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 10:59:37 --> Database Driver Class Initialized
INFO - 2023-03-15 10:59:37 --> Model "Cluster_model" initialized
INFO - 2023-03-15 10:59:37 --> Final output sent to browser
DEBUG - 2023-03-15 10:59:37 --> Total execution time: 0.0549
INFO - 2023-03-15 11:00:10 --> Config Class Initialized
INFO - 2023-03-15 11:00:10 --> Hooks Class Initialized
DEBUG - 2023-03-15 11:00:10 --> UTF-8 Support Enabled
INFO - 2023-03-15 11:00:10 --> Utf8 Class Initialized
INFO - 2023-03-15 11:00:10 --> URI Class Initialized
INFO - 2023-03-15 11:00:10 --> Router Class Initialized
INFO - 2023-03-15 11:00:10 --> Output Class Initialized
INFO - 2023-03-15 11:00:10 --> Security Class Initialized
DEBUG - 2023-03-15 11:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 11:00:10 --> Input Class Initialized
INFO - 2023-03-15 11:00:10 --> Language Class Initialized
INFO - 2023-03-15 11:00:10 --> Loader Class Initialized
INFO - 2023-03-15 11:00:10 --> Controller Class Initialized
DEBUG - 2023-03-15 11:00:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 11:00:10 --> Database Driver Class Initialized
INFO - 2023-03-15 11:00:10 --> Model "Cluster_model" initialized
INFO - 2023-03-15 11:00:10 --> Final output sent to browser
DEBUG - 2023-03-15 11:00:10 --> Total execution time: 0.0448
INFO - 2023-03-15 11:00:10 --> Config Class Initialized
INFO - 2023-03-15 11:00:10 --> Hooks Class Initialized
DEBUG - 2023-03-15 11:00:10 --> UTF-8 Support Enabled
INFO - 2023-03-15 11:00:10 --> Utf8 Class Initialized
INFO - 2023-03-15 11:00:10 --> URI Class Initialized
INFO - 2023-03-15 11:00:10 --> Router Class Initialized
INFO - 2023-03-15 11:00:10 --> Output Class Initialized
INFO - 2023-03-15 11:00:10 --> Security Class Initialized
DEBUG - 2023-03-15 11:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 11:00:10 --> Input Class Initialized
INFO - 2023-03-15 11:00:10 --> Language Class Initialized
INFO - 2023-03-15 11:00:10 --> Loader Class Initialized
INFO - 2023-03-15 11:00:10 --> Controller Class Initialized
DEBUG - 2023-03-15 11:00:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 11:00:10 --> Database Driver Class Initialized
INFO - 2023-03-15 11:00:10 --> Model "Cluster_model" initialized
INFO - 2023-03-15 11:00:10 --> Final output sent to browser
DEBUG - 2023-03-15 11:00:10 --> Total execution time: 0.0405
INFO - 2023-03-15 11:00:13 --> Config Class Initialized
INFO - 2023-03-15 11:00:13 --> Hooks Class Initialized
DEBUG - 2023-03-15 11:00:13 --> UTF-8 Support Enabled
INFO - 2023-03-15 11:00:13 --> Utf8 Class Initialized
INFO - 2023-03-15 11:00:13 --> URI Class Initialized
INFO - 2023-03-15 11:00:13 --> Router Class Initialized
INFO - 2023-03-15 11:00:13 --> Output Class Initialized
INFO - 2023-03-15 11:00:13 --> Security Class Initialized
DEBUG - 2023-03-15 11:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 11:00:13 --> Input Class Initialized
INFO - 2023-03-15 11:00:13 --> Language Class Initialized
INFO - 2023-03-15 11:00:13 --> Loader Class Initialized
INFO - 2023-03-15 11:00:13 --> Controller Class Initialized
DEBUG - 2023-03-15 11:00:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 11:00:13 --> Database Driver Class Initialized
INFO - 2023-03-15 11:00:13 --> Model "Cluster_model" initialized
INFO - 2023-03-15 11:00:13 --> Database Driver Class Initialized
INFO - 2023-03-15 11:00:13 --> Model "Login_model" initialized
INFO - 2023-03-15 11:00:13 --> Final output sent to browser
DEBUG - 2023-03-15 11:00:13 --> Total execution time: 0.0470
INFO - 2023-03-15 11:00:13 --> Config Class Initialized
INFO - 2023-03-15 11:00:13 --> Hooks Class Initialized
DEBUG - 2023-03-15 11:00:13 --> UTF-8 Support Enabled
INFO - 2023-03-15 11:00:13 --> Utf8 Class Initialized
INFO - 2023-03-15 11:00:13 --> URI Class Initialized
INFO - 2023-03-15 11:00:13 --> Router Class Initialized
INFO - 2023-03-15 11:00:13 --> Output Class Initialized
INFO - 2023-03-15 11:00:13 --> Security Class Initialized
DEBUG - 2023-03-15 11:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 11:00:13 --> Input Class Initialized
INFO - 2023-03-15 11:00:13 --> Language Class Initialized
INFO - 2023-03-15 11:00:13 --> Loader Class Initialized
INFO - 2023-03-15 11:00:13 --> Controller Class Initialized
DEBUG - 2023-03-15 11:00:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 11:00:13 --> Database Driver Class Initialized
INFO - 2023-03-15 11:00:13 --> Model "Cluster_model" initialized
INFO - 2023-03-15 11:00:13 --> Database Driver Class Initialized
INFO - 2023-03-15 11:00:13 --> Model "Login_model" initialized
INFO - 2023-03-15 11:00:13 --> Final output sent to browser
DEBUG - 2023-03-15 11:00:13 --> Total execution time: 0.0811
INFO - 2023-03-15 11:02:02 --> Config Class Initialized
INFO - 2023-03-15 11:02:02 --> Hooks Class Initialized
DEBUG - 2023-03-15 11:02:02 --> UTF-8 Support Enabled
INFO - 2023-03-15 11:02:02 --> Utf8 Class Initialized
INFO - 2023-03-15 11:02:02 --> URI Class Initialized
INFO - 2023-03-15 11:02:02 --> Router Class Initialized
INFO - 2023-03-15 11:02:02 --> Output Class Initialized
INFO - 2023-03-15 11:02:02 --> Security Class Initialized
DEBUG - 2023-03-15 11:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 11:02:02 --> Input Class Initialized
INFO - 2023-03-15 11:02:02 --> Language Class Initialized
INFO - 2023-03-15 11:02:02 --> Loader Class Initialized
INFO - 2023-03-15 11:02:02 --> Controller Class Initialized
DEBUG - 2023-03-15 11:02:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 11:02:02 --> Database Driver Class Initialized
INFO - 2023-03-15 11:02:02 --> Model "Cluster_model" initialized
INFO - 2023-03-15 11:02:02 --> Final output sent to browser
DEBUG - 2023-03-15 11:02:02 --> Total execution time: 0.0425
INFO - 2023-03-15 11:02:02 --> Config Class Initialized
INFO - 2023-03-15 11:02:02 --> Hooks Class Initialized
DEBUG - 2023-03-15 11:02:02 --> UTF-8 Support Enabled
INFO - 2023-03-15 11:02:02 --> Utf8 Class Initialized
INFO - 2023-03-15 11:02:02 --> URI Class Initialized
INFO - 2023-03-15 11:02:02 --> Router Class Initialized
INFO - 2023-03-15 11:02:02 --> Output Class Initialized
INFO - 2023-03-15 11:02:02 --> Security Class Initialized
DEBUG - 2023-03-15 11:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 11:02:02 --> Input Class Initialized
INFO - 2023-03-15 11:02:02 --> Language Class Initialized
INFO - 2023-03-15 11:02:02 --> Loader Class Initialized
INFO - 2023-03-15 11:02:02 --> Controller Class Initialized
DEBUG - 2023-03-15 11:02:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 11:02:02 --> Database Driver Class Initialized
INFO - 2023-03-15 11:02:02 --> Model "Cluster_model" initialized
INFO - 2023-03-15 11:02:02 --> Final output sent to browser
DEBUG - 2023-03-15 11:02:02 --> Total execution time: 0.0413
INFO - 2023-03-15 11:02:46 --> Config Class Initialized
INFO - 2023-03-15 11:02:46 --> Hooks Class Initialized
DEBUG - 2023-03-15 11:02:46 --> UTF-8 Support Enabled
INFO - 2023-03-15 11:02:46 --> Utf8 Class Initialized
INFO - 2023-03-15 11:02:46 --> URI Class Initialized
INFO - 2023-03-15 11:02:46 --> Router Class Initialized
INFO - 2023-03-15 11:02:46 --> Output Class Initialized
INFO - 2023-03-15 11:02:46 --> Security Class Initialized
DEBUG - 2023-03-15 11:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 11:02:46 --> Input Class Initialized
INFO - 2023-03-15 11:02:46 --> Language Class Initialized
INFO - 2023-03-15 11:02:46 --> Loader Class Initialized
INFO - 2023-03-15 11:02:46 --> Controller Class Initialized
DEBUG - 2023-03-15 11:02:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 11:02:46 --> Database Driver Class Initialized
INFO - 2023-03-15 11:02:46 --> Model "Cluster_model" initialized
INFO - 2023-03-15 11:02:46 --> Final output sent to browser
DEBUG - 2023-03-15 11:02:46 --> Total execution time: 0.0148
INFO - 2023-03-15 11:02:46 --> Config Class Initialized
INFO - 2023-03-15 11:02:46 --> Hooks Class Initialized
DEBUG - 2023-03-15 11:02:46 --> UTF-8 Support Enabled
INFO - 2023-03-15 11:02:46 --> Utf8 Class Initialized
INFO - 2023-03-15 11:02:46 --> URI Class Initialized
INFO - 2023-03-15 11:02:46 --> Router Class Initialized
INFO - 2023-03-15 11:02:46 --> Output Class Initialized
INFO - 2023-03-15 11:02:46 --> Security Class Initialized
DEBUG - 2023-03-15 11:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 11:02:46 --> Input Class Initialized
INFO - 2023-03-15 11:02:46 --> Language Class Initialized
INFO - 2023-03-15 11:02:46 --> Loader Class Initialized
INFO - 2023-03-15 11:02:46 --> Controller Class Initialized
DEBUG - 2023-03-15 11:02:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 11:02:46 --> Database Driver Class Initialized
INFO - 2023-03-15 11:02:46 --> Model "Cluster_model" initialized
INFO - 2023-03-15 11:02:46 --> Final output sent to browser
DEBUG - 2023-03-15 11:02:46 --> Total execution time: 0.0127
INFO - 2023-03-15 14:07:45 --> Config Class Initialized
INFO - 2023-03-15 14:07:45 --> Hooks Class Initialized
DEBUG - 2023-03-15 14:07:45 --> UTF-8 Support Enabled
INFO - 2023-03-15 14:07:45 --> Utf8 Class Initialized
INFO - 2023-03-15 14:07:45 --> URI Class Initialized
INFO - 2023-03-15 14:07:45 --> Router Class Initialized
INFO - 2023-03-15 14:07:45 --> Output Class Initialized
INFO - 2023-03-15 14:07:45 --> Security Class Initialized
DEBUG - 2023-03-15 14:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 14:07:45 --> Input Class Initialized
INFO - 2023-03-15 14:07:45 --> Language Class Initialized
INFO - 2023-03-15 14:07:45 --> Loader Class Initialized
INFO - 2023-03-15 14:07:45 --> Controller Class Initialized
DEBUG - 2023-03-15 14:07:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 14:07:45 --> Database Driver Class Initialized
INFO - 2023-03-15 14:07:48 --> Config Class Initialized
INFO - 2023-03-15 14:07:48 --> Hooks Class Initialized
DEBUG - 2023-03-15 14:07:48 --> UTF-8 Support Enabled
INFO - 2023-03-15 14:07:48 --> Utf8 Class Initialized
INFO - 2023-03-15 14:07:48 --> URI Class Initialized
INFO - 2023-03-15 14:07:48 --> Router Class Initialized
INFO - 2023-03-15 14:07:48 --> Output Class Initialized
INFO - 2023-03-15 14:07:48 --> Security Class Initialized
DEBUG - 2023-03-15 14:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 14:07:48 --> Input Class Initialized
INFO - 2023-03-15 14:07:48 --> Language Class Initialized
INFO - 2023-03-15 14:07:48 --> Loader Class Initialized
INFO - 2023-03-15 14:07:48 --> Controller Class Initialized
DEBUG - 2023-03-15 14:07:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 14:07:48 --> Database Driver Class Initialized
INFO - 2023-03-15 14:07:50 --> Config Class Initialized
INFO - 2023-03-15 14:07:50 --> Hooks Class Initialized
DEBUG - 2023-03-15 14:07:50 --> UTF-8 Support Enabled
INFO - 2023-03-15 14:07:50 --> Utf8 Class Initialized
INFO - 2023-03-15 14:07:50 --> URI Class Initialized
INFO - 2023-03-15 14:07:50 --> Router Class Initialized
INFO - 2023-03-15 14:07:50 --> Output Class Initialized
INFO - 2023-03-15 14:07:50 --> Security Class Initialized
DEBUG - 2023-03-15 14:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-15 14:07:50 --> Input Class Initialized
INFO - 2023-03-15 14:07:50 --> Language Class Initialized
INFO - 2023-03-15 14:07:50 --> Loader Class Initialized
INFO - 2023-03-15 14:07:50 --> Controller Class Initialized
DEBUG - 2023-03-15 14:07:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-15 14:07:50 --> Database Driver Class Initialized
ERROR - 2023-03-15 14:07:55 --> Unable to connect to the database
INFO - 2023-03-15 14:07:55 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-15 14:07:58 --> Unable to connect to the database
INFO - 2023-03-15 14:07:58 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-15 14:08:00 --> Unable to connect to the database
INFO - 2023-03-15 14:08:00 --> Language file loaded: language/english/db_lang.php
