<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-02 03:11:59 --> Config Class Initialized
INFO - 2023-03-02 03:11:59 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:11:59 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:11:59 --> Utf8 Class Initialized
INFO - 2023-03-02 03:11:59 --> URI Class Initialized
INFO - 2023-03-02 03:11:59 --> Router Class Initialized
INFO - 2023-03-02 03:11:59 --> Output Class Initialized
INFO - 2023-03-02 03:11:59 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:00 --> Input Class Initialized
INFO - 2023-03-02 03:12:00 --> Language Class Initialized
INFO - 2023-03-02 03:12:00 --> Loader Class Initialized
INFO - 2023-03-02 03:12:00 --> Controller Class Initialized
INFO - 2023-03-02 03:12:00 --> Helper loaded: form_helper
INFO - 2023-03-02 03:12:00 --> Helper loaded: url_helper
DEBUG - 2023-03-02 03:12:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:00 --> Model "Change_model" initialized
INFO - 2023-03-02 03:12:00 --> Model "Grafana_model" initialized
INFO - 2023-03-02 03:12:00 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:00 --> Total execution time: 0.0442
INFO - 2023-03-02 03:12:00 --> Config Class Initialized
INFO - 2023-03-02 03:12:00 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:00 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:00 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:00 --> URI Class Initialized
INFO - 2023-03-02 03:12:00 --> Router Class Initialized
INFO - 2023-03-02 03:12:00 --> Output Class Initialized
INFO - 2023-03-02 03:12:00 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:00 --> Input Class Initialized
INFO - 2023-03-02 03:12:00 --> Language Class Initialized
INFO - 2023-03-02 03:12:00 --> Loader Class Initialized
INFO - 2023-03-02 03:12:00 --> Controller Class Initialized
INFO - 2023-03-02 03:12:00 --> Helper loaded: form_helper
INFO - 2023-03-02 03:12:00 --> Helper loaded: url_helper
DEBUG - 2023-03-02 03:12:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:00 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:00 --> Total execution time: 0.0332
INFO - 2023-03-02 03:12:00 --> Config Class Initialized
INFO - 2023-03-02 03:12:00 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:00 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:00 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:00 --> URI Class Initialized
INFO - 2023-03-02 03:12:00 --> Router Class Initialized
INFO - 2023-03-02 03:12:00 --> Output Class Initialized
INFO - 2023-03-02 03:12:00 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:00 --> Input Class Initialized
INFO - 2023-03-02 03:12:00 --> Language Class Initialized
INFO - 2023-03-02 03:12:00 --> Loader Class Initialized
INFO - 2023-03-02 03:12:00 --> Controller Class Initialized
INFO - 2023-03-02 03:12:00 --> Helper loaded: form_helper
INFO - 2023-03-02 03:12:00 --> Helper loaded: url_helper
DEBUG - 2023-03-02 03:12:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:00 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:00 --> Model "Login_model" initialized
INFO - 2023-03-02 03:12:00 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:00 --> Total execution time: 0.0237
INFO - 2023-03-02 03:12:00 --> Config Class Initialized
INFO - 2023-03-02 03:12:00 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:00 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:00 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:00 --> URI Class Initialized
INFO - 2023-03-02 03:12:00 --> Router Class Initialized
INFO - 2023-03-02 03:12:00 --> Output Class Initialized
INFO - 2023-03-02 03:12:00 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:00 --> Input Class Initialized
INFO - 2023-03-02 03:12:00 --> Language Class Initialized
INFO - 2023-03-02 03:12:00 --> Loader Class Initialized
INFO - 2023-03-02 03:12:00 --> Controller Class Initialized
DEBUG - 2023-03-02 03:12:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:00 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:00 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:12:00 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:00 --> Total execution time: 0.0154
INFO - 2023-03-02 03:12:00 --> Config Class Initialized
INFO - 2023-03-02 03:12:00 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:00 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:00 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:00 --> URI Class Initialized
INFO - 2023-03-02 03:12:00 --> Router Class Initialized
INFO - 2023-03-02 03:12:00 --> Output Class Initialized
INFO - 2023-03-02 03:12:00 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:00 --> Input Class Initialized
INFO - 2023-03-02 03:12:00 --> Language Class Initialized
INFO - 2023-03-02 03:12:00 --> Loader Class Initialized
INFO - 2023-03-02 03:12:00 --> Controller Class Initialized
DEBUG - 2023-03-02 03:12:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:00 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:00 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:12:02 --> Config Class Initialized
INFO - 2023-03-02 03:12:02 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:02 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:02 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:02 --> URI Class Initialized
INFO - 2023-03-02 03:12:02 --> Router Class Initialized
INFO - 2023-03-02 03:12:02 --> Output Class Initialized
INFO - 2023-03-02 03:12:02 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:02 --> Input Class Initialized
INFO - 2023-03-02 03:12:02 --> Language Class Initialized
INFO - 2023-03-02 03:12:02 --> Loader Class Initialized
INFO - 2023-03-02 03:12:02 --> Controller Class Initialized
INFO - 2023-03-02 03:12:02 --> Helper loaded: form_helper
INFO - 2023-03-02 03:12:02 --> Helper loaded: url_helper
DEBUG - 2023-03-02 03:12:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:02 --> Model "Change_model" initialized
INFO - 2023-03-02 03:12:02 --> Model "Grafana_model" initialized
INFO - 2023-03-02 03:12:02 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:02 --> Total execution time: 0.0783
INFO - 2023-03-02 03:12:02 --> Config Class Initialized
INFO - 2023-03-02 03:12:02 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:02 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:02 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:02 --> URI Class Initialized
INFO - 2023-03-02 03:12:02 --> Router Class Initialized
INFO - 2023-03-02 03:12:02 --> Output Class Initialized
INFO - 2023-03-02 03:12:02 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:02 --> Input Class Initialized
INFO - 2023-03-02 03:12:02 --> Language Class Initialized
INFO - 2023-03-02 03:12:02 --> Loader Class Initialized
INFO - 2023-03-02 03:12:02 --> Controller Class Initialized
INFO - 2023-03-02 03:12:02 --> Helper loaded: form_helper
INFO - 2023-03-02 03:12:02 --> Helper loaded: url_helper
DEBUG - 2023-03-02 03:12:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:02 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:02 --> Model "Login_model" initialized
INFO - 2023-03-02 03:12:02 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:02 --> Total execution time: 0.1786
INFO - 2023-03-02 03:12:02 --> Config Class Initialized
INFO - 2023-03-02 03:12:02 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:02 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:02 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:02 --> URI Class Initialized
INFO - 2023-03-02 03:12:02 --> Router Class Initialized
INFO - 2023-03-02 03:12:02 --> Output Class Initialized
INFO - 2023-03-02 03:12:02 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:02 --> Input Class Initialized
INFO - 2023-03-02 03:12:02 --> Language Class Initialized
INFO - 2023-03-02 03:12:02 --> Loader Class Initialized
INFO - 2023-03-02 03:12:02 --> Controller Class Initialized
DEBUG - 2023-03-02 03:12:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:02 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:02 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:12:03 --> Config Class Initialized
INFO - 2023-03-02 03:12:03 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:03 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:03 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:03 --> URI Class Initialized
INFO - 2023-03-02 03:12:03 --> Router Class Initialized
INFO - 2023-03-02 03:12:03 --> Output Class Initialized
INFO - 2023-03-02 03:12:03 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:03 --> Input Class Initialized
INFO - 2023-03-02 03:12:03 --> Language Class Initialized
INFO - 2023-03-02 03:12:03 --> Loader Class Initialized
INFO - 2023-03-02 03:12:03 --> Controller Class Initialized
INFO - 2023-03-02 03:12:03 --> Helper loaded: form_helper
INFO - 2023-03-02 03:12:03 --> Helper loaded: url_helper
DEBUG - 2023-03-02 03:12:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:03 --> Model "Change_model" initialized
INFO - 2023-03-02 03:12:03 --> Model "Grafana_model" initialized
INFO - 2023-03-02 03:12:03 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:03 --> Total execution time: 0.0247
INFO - 2023-03-02 03:12:03 --> Config Class Initialized
INFO - 2023-03-02 03:12:03 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:03 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:03 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:03 --> URI Class Initialized
INFO - 2023-03-02 03:12:03 --> Router Class Initialized
INFO - 2023-03-02 03:12:03 --> Output Class Initialized
INFO - 2023-03-02 03:12:03 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:03 --> Input Class Initialized
INFO - 2023-03-02 03:12:03 --> Language Class Initialized
INFO - 2023-03-02 03:12:03 --> Loader Class Initialized
INFO - 2023-03-02 03:12:03 --> Controller Class Initialized
INFO - 2023-03-02 03:12:03 --> Helper loaded: form_helper
INFO - 2023-03-02 03:12:03 --> Helper loaded: url_helper
DEBUG - 2023-03-02 03:12:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:03 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:03 --> Model "Login_model" initialized
INFO - 2023-03-02 03:12:03 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:03 --> Total execution time: 0.0170
INFO - 2023-03-02 03:12:03 --> Config Class Initialized
INFO - 2023-03-02 03:12:03 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:03 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:03 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:03 --> URI Class Initialized
INFO - 2023-03-02 03:12:03 --> Router Class Initialized
INFO - 2023-03-02 03:12:03 --> Output Class Initialized
INFO - 2023-03-02 03:12:03 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:03 --> Input Class Initialized
INFO - 2023-03-02 03:12:03 --> Language Class Initialized
INFO - 2023-03-02 03:12:03 --> Loader Class Initialized
INFO - 2023-03-02 03:12:03 --> Controller Class Initialized
DEBUG - 2023-03-02 03:12:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:03 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:03 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:12:21 --> Config Class Initialized
INFO - 2023-03-02 03:12:21 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:21 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:21 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:21 --> URI Class Initialized
INFO - 2023-03-02 03:12:21 --> Router Class Initialized
INFO - 2023-03-02 03:12:21 --> Output Class Initialized
INFO - 2023-03-02 03:12:21 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:21 --> Input Class Initialized
INFO - 2023-03-02 03:12:21 --> Language Class Initialized
INFO - 2023-03-02 03:12:21 --> Loader Class Initialized
INFO - 2023-03-02 03:12:21 --> Controller Class Initialized
INFO - 2023-03-02 03:12:21 --> Helper loaded: form_helper
INFO - 2023-03-02 03:12:21 --> Helper loaded: url_helper
DEBUG - 2023-03-02 03:12:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:21 --> Model "Change_model" initialized
INFO - 2023-03-02 03:12:21 --> Model "Grafana_model" initialized
INFO - 2023-03-02 03:12:21 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:21 --> Total execution time: 0.1568
INFO - 2023-03-02 03:12:21 --> Config Class Initialized
INFO - 2023-03-02 03:12:21 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:21 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:21 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:21 --> URI Class Initialized
INFO - 2023-03-02 03:12:21 --> Router Class Initialized
INFO - 2023-03-02 03:12:21 --> Output Class Initialized
INFO - 2023-03-02 03:12:21 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:21 --> Input Class Initialized
INFO - 2023-03-02 03:12:21 --> Language Class Initialized
INFO - 2023-03-02 03:12:21 --> Loader Class Initialized
INFO - 2023-03-02 03:12:21 --> Controller Class Initialized
INFO - 2023-03-02 03:12:21 --> Helper loaded: form_helper
INFO - 2023-03-02 03:12:21 --> Helper loaded: url_helper
DEBUG - 2023-03-02 03:12:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:21 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:21 --> Total execution time: 0.0423
INFO - 2023-03-02 03:12:21 --> Config Class Initialized
INFO - 2023-03-02 03:12:21 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:21 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:21 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:21 --> URI Class Initialized
INFO - 2023-03-02 03:12:21 --> Router Class Initialized
INFO - 2023-03-02 03:12:21 --> Output Class Initialized
INFO - 2023-03-02 03:12:21 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:21 --> Input Class Initialized
INFO - 2023-03-02 03:12:21 --> Language Class Initialized
INFO - 2023-03-02 03:12:21 --> Loader Class Initialized
INFO - 2023-03-02 03:12:21 --> Controller Class Initialized
INFO - 2023-03-02 03:12:21 --> Helper loaded: form_helper
INFO - 2023-03-02 03:12:21 --> Helper loaded: url_helper
DEBUG - 2023-03-02 03:12:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:21 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:21 --> Model "Login_model" initialized
INFO - 2023-03-02 03:12:42 --> Final output sent to browser
INFO - 2023-03-02 03:12:43 --> Final output sent to browser
INFO - 2023-03-02 03:12:43 --> Final output sent to browser
INFO - 2023-03-02 03:12:43 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:43 --> Total execution time: 42.8243
DEBUG - 2023-03-02 03:12:43 --> Total execution time: 39.4561
DEBUG - 2023-03-02 03:12:43 --> Total execution time: 21.4963
DEBUG - 2023-03-02 03:12:43 --> Total execution time: 40.3386
INFO - 2023-03-02 03:12:43 --> Config Class Initialized
INFO - 2023-03-02 03:12:43 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:43 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:43 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:43 --> URI Class Initialized
INFO - 2023-03-02 03:12:43 --> Router Class Initialized
INFO - 2023-03-02 03:12:43 --> Output Class Initialized
INFO - 2023-03-02 03:12:43 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:43 --> Input Class Initialized
INFO - 2023-03-02 03:12:43 --> Language Class Initialized
INFO - 2023-03-02 03:12:43 --> Loader Class Initialized
INFO - 2023-03-02 03:12:43 --> Controller Class Initialized
DEBUG - 2023-03-02 03:12:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:43 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:43 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:12:43 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:43 --> Total execution time: 0.1017
INFO - 2023-03-02 03:12:43 --> Config Class Initialized
INFO - 2023-03-02 03:12:43 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:43 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:43 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:43 --> URI Class Initialized
INFO - 2023-03-02 03:12:43 --> Router Class Initialized
INFO - 2023-03-02 03:12:43 --> Output Class Initialized
INFO - 2023-03-02 03:12:43 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:43 --> Input Class Initialized
INFO - 2023-03-02 03:12:43 --> Language Class Initialized
INFO - 2023-03-02 03:12:43 --> Loader Class Initialized
INFO - 2023-03-02 03:12:43 --> Controller Class Initialized
DEBUG - 2023-03-02 03:12:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:43 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:43 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:12:43 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:43 --> Total execution time: 0.0255
INFO - 2023-03-02 03:12:43 --> Config Class Initialized
INFO - 2023-03-02 03:12:43 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:43 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:43 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:43 --> URI Class Initialized
INFO - 2023-03-02 03:12:43 --> Router Class Initialized
INFO - 2023-03-02 03:12:43 --> Output Class Initialized
INFO - 2023-03-02 03:12:43 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:43 --> Input Class Initialized
INFO - 2023-03-02 03:12:43 --> Language Class Initialized
INFO - 2023-03-02 03:12:43 --> Loader Class Initialized
INFO - 2023-03-02 03:12:43 --> Controller Class Initialized
DEBUG - 2023-03-02 03:12:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:43 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:43 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:12:43 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:43 --> Model "Login_model" initialized
INFO - 2023-03-02 03:12:44 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:44 --> Total execution time: 0.3447
INFO - 2023-03-02 03:12:44 --> Config Class Initialized
INFO - 2023-03-02 03:12:44 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:12:44 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:12:44 --> Utf8 Class Initialized
INFO - 2023-03-02 03:12:44 --> URI Class Initialized
INFO - 2023-03-02 03:12:44 --> Router Class Initialized
INFO - 2023-03-02 03:12:44 --> Output Class Initialized
INFO - 2023-03-02 03:12:44 --> Security Class Initialized
DEBUG - 2023-03-02 03:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:12:44 --> Input Class Initialized
INFO - 2023-03-02 03:12:44 --> Language Class Initialized
INFO - 2023-03-02 03:12:44 --> Loader Class Initialized
INFO - 2023-03-02 03:12:44 --> Controller Class Initialized
DEBUG - 2023-03-02 03:12:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:12:44 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:44 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:12:44 --> Database Driver Class Initialized
INFO - 2023-03-02 03:12:44 --> Model "Login_model" initialized
INFO - 2023-03-02 03:12:44 --> Final output sent to browser
DEBUG - 2023-03-02 03:12:44 --> Total execution time: 0.3061
INFO - 2023-03-02 03:13:12 --> Config Class Initialized
INFO - 2023-03-02 03:13:12 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:13:12 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:13:12 --> Utf8 Class Initialized
INFO - 2023-03-02 03:13:12 --> URI Class Initialized
INFO - 2023-03-02 03:13:12 --> Router Class Initialized
INFO - 2023-03-02 03:13:12 --> Output Class Initialized
INFO - 2023-03-02 03:13:12 --> Security Class Initialized
DEBUG - 2023-03-02 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:13:12 --> Input Class Initialized
INFO - 2023-03-02 03:13:12 --> Language Class Initialized
INFO - 2023-03-02 03:13:12 --> Loader Class Initialized
INFO - 2023-03-02 03:13:12 --> Controller Class Initialized
DEBUG - 2023-03-02 03:13:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:13:12 --> Database Driver Class Initialized
INFO - 2023-03-02 03:13:12 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:13:12 --> Database Driver Class Initialized
INFO - 2023-03-02 03:13:12 --> Model "Login_model" initialized
INFO - 2023-03-02 03:13:12 --> Final output sent to browser
DEBUG - 2023-03-02 03:13:12 --> Total execution time: 0.2846
INFO - 2023-03-02 03:13:12 --> Config Class Initialized
INFO - 2023-03-02 03:13:12 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:13:12 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:13:12 --> Utf8 Class Initialized
INFO - 2023-03-02 03:13:12 --> URI Class Initialized
INFO - 2023-03-02 03:13:12 --> Router Class Initialized
INFO - 2023-03-02 03:13:12 --> Output Class Initialized
INFO - 2023-03-02 03:13:12 --> Security Class Initialized
DEBUG - 2023-03-02 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:13:12 --> Input Class Initialized
INFO - 2023-03-02 03:13:12 --> Language Class Initialized
INFO - 2023-03-02 03:13:12 --> Loader Class Initialized
INFO - 2023-03-02 03:13:12 --> Controller Class Initialized
DEBUG - 2023-03-02 03:13:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:13:12 --> Database Driver Class Initialized
INFO - 2023-03-02 03:13:12 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:13:12 --> Database Driver Class Initialized
INFO - 2023-03-02 03:13:12 --> Model "Login_model" initialized
INFO - 2023-03-02 03:13:12 --> Final output sent to browser
DEBUG - 2023-03-02 03:13:12 --> Total execution time: 0.0893
INFO - 2023-03-02 03:29:26 --> Config Class Initialized
INFO - 2023-03-02 03:29:26 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:29:26 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:29:26 --> Utf8 Class Initialized
INFO - 2023-03-02 03:29:26 --> URI Class Initialized
INFO - 2023-03-02 03:29:26 --> Router Class Initialized
INFO - 2023-03-02 03:29:26 --> Output Class Initialized
INFO - 2023-03-02 03:29:26 --> Security Class Initialized
DEBUG - 2023-03-02 03:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:29:26 --> Input Class Initialized
INFO - 2023-03-02 03:29:26 --> Language Class Initialized
INFO - 2023-03-02 03:29:26 --> Loader Class Initialized
INFO - 2023-03-02 03:29:26 --> Controller Class Initialized
DEBUG - 2023-03-02 03:29:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:29:26 --> Database Driver Class Initialized
INFO - 2023-03-02 03:29:26 --> Final output sent to browser
DEBUG - 2023-03-02 03:29:26 --> Total execution time: 0.0365
INFO - 2023-03-02 03:29:26 --> Config Class Initialized
INFO - 2023-03-02 03:29:26 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:29:26 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:29:26 --> Utf8 Class Initialized
INFO - 2023-03-02 03:29:26 --> URI Class Initialized
INFO - 2023-03-02 03:29:26 --> Router Class Initialized
INFO - 2023-03-02 03:29:26 --> Output Class Initialized
INFO - 2023-03-02 03:29:26 --> Security Class Initialized
DEBUG - 2023-03-02 03:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:29:26 --> Input Class Initialized
INFO - 2023-03-02 03:29:26 --> Language Class Initialized
INFO - 2023-03-02 03:29:26 --> Loader Class Initialized
INFO - 2023-03-02 03:29:26 --> Controller Class Initialized
DEBUG - 2023-03-02 03:29:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:29:26 --> Database Driver Class Initialized
INFO - 2023-03-02 03:29:28 --> Final output sent to browser
DEBUG - 2023-03-02 03:29:28 --> Total execution time: 1.8320
INFO - 2023-03-02 03:29:57 --> Config Class Initialized
INFO - 2023-03-02 03:29:57 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:29:57 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:29:57 --> Utf8 Class Initialized
INFO - 2023-03-02 03:29:57 --> URI Class Initialized
INFO - 2023-03-02 03:29:57 --> Router Class Initialized
INFO - 2023-03-02 03:29:57 --> Output Class Initialized
INFO - 2023-03-02 03:29:57 --> Security Class Initialized
DEBUG - 2023-03-02 03:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:29:57 --> Input Class Initialized
INFO - 2023-03-02 03:29:57 --> Language Class Initialized
INFO - 2023-03-02 03:29:57 --> Loader Class Initialized
INFO - 2023-03-02 03:29:57 --> Controller Class Initialized
DEBUG - 2023-03-02 03:29:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:29:57 --> Database Driver Class Initialized
INFO - 2023-03-02 03:29:57 --> Final output sent to browser
DEBUG - 2023-03-02 03:29:57 --> Total execution time: 0.0182
INFO - 2023-03-02 03:29:57 --> Config Class Initialized
INFO - 2023-03-02 03:29:57 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:29:57 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:29:57 --> Utf8 Class Initialized
INFO - 2023-03-02 03:29:57 --> URI Class Initialized
INFO - 2023-03-02 03:29:57 --> Router Class Initialized
INFO - 2023-03-02 03:29:57 --> Output Class Initialized
INFO - 2023-03-02 03:29:57 --> Security Class Initialized
DEBUG - 2023-03-02 03:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:29:57 --> Input Class Initialized
INFO - 2023-03-02 03:29:57 --> Language Class Initialized
INFO - 2023-03-02 03:29:57 --> Loader Class Initialized
INFO - 2023-03-02 03:29:57 --> Controller Class Initialized
DEBUG - 2023-03-02 03:29:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:29:57 --> Database Driver Class Initialized
INFO - 2023-03-02 03:29:58 --> Final output sent to browser
DEBUG - 2023-03-02 03:29:58 --> Total execution time: 0.4213
INFO - 2023-03-02 03:31:08 --> Config Class Initialized
INFO - 2023-03-02 03:31:08 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:08 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:08 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:08 --> URI Class Initialized
INFO - 2023-03-02 03:31:08 --> Router Class Initialized
INFO - 2023-03-02 03:31:08 --> Output Class Initialized
INFO - 2023-03-02 03:31:08 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:08 --> Input Class Initialized
INFO - 2023-03-02 03:31:08 --> Language Class Initialized
INFO - 2023-03-02 03:31:08 --> Loader Class Initialized
INFO - 2023-03-02 03:31:08 --> Controller Class Initialized
INFO - 2023-03-02 03:31:08 --> Helper loaded: form_helper
INFO - 2023-03-02 03:31:08 --> Helper loaded: url_helper
DEBUG - 2023-03-02 03:31:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:08 --> Model "Change_model" initialized
INFO - 2023-03-02 03:31:08 --> Model "Grafana_model" initialized
INFO - 2023-03-02 03:31:08 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:08 --> Total execution time: 0.0308
INFO - 2023-03-02 03:31:09 --> Config Class Initialized
INFO - 2023-03-02 03:31:09 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:09 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:09 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:09 --> URI Class Initialized
INFO - 2023-03-02 03:31:09 --> Router Class Initialized
INFO - 2023-03-02 03:31:09 --> Output Class Initialized
INFO - 2023-03-02 03:31:09 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:09 --> Input Class Initialized
INFO - 2023-03-02 03:31:09 --> Language Class Initialized
INFO - 2023-03-02 03:31:09 --> Loader Class Initialized
INFO - 2023-03-02 03:31:09 --> Controller Class Initialized
INFO - 2023-03-02 03:31:09 --> Helper loaded: form_helper
INFO - 2023-03-02 03:31:09 --> Helper loaded: url_helper
DEBUG - 2023-03-02 03:31:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:09 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:09 --> Total execution time: 0.0038
INFO - 2023-03-02 03:31:09 --> Config Class Initialized
INFO - 2023-03-02 03:31:09 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:09 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:09 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:09 --> URI Class Initialized
INFO - 2023-03-02 03:31:09 --> Router Class Initialized
INFO - 2023-03-02 03:31:09 --> Output Class Initialized
INFO - 2023-03-02 03:31:09 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:09 --> Input Class Initialized
INFO - 2023-03-02 03:31:09 --> Language Class Initialized
INFO - 2023-03-02 03:31:09 --> Loader Class Initialized
INFO - 2023-03-02 03:31:09 --> Controller Class Initialized
INFO - 2023-03-02 03:31:09 --> Helper loaded: form_helper
INFO - 2023-03-02 03:31:09 --> Helper loaded: url_helper
DEBUG - 2023-03-02 03:31:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:09 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:09 --> Model "Login_model" initialized
INFO - 2023-03-02 03:31:09 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:09 --> Total execution time: 0.0178
INFO - 2023-03-02 03:31:09 --> Config Class Initialized
INFO - 2023-03-02 03:31:09 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:09 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:09 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:09 --> URI Class Initialized
INFO - 2023-03-02 03:31:09 --> Router Class Initialized
INFO - 2023-03-02 03:31:09 --> Output Class Initialized
INFO - 2023-03-02 03:31:09 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:09 --> Input Class Initialized
INFO - 2023-03-02 03:31:09 --> Language Class Initialized
INFO - 2023-03-02 03:31:09 --> Loader Class Initialized
INFO - 2023-03-02 03:31:09 --> Controller Class Initialized
DEBUG - 2023-03-02 03:31:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:09 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:09 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:31:09 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:09 --> Total execution time: 0.0573
INFO - 2023-03-02 03:31:09 --> Config Class Initialized
INFO - 2023-03-02 03:31:09 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:09 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:09 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:09 --> URI Class Initialized
INFO - 2023-03-02 03:31:09 --> Router Class Initialized
INFO - 2023-03-02 03:31:09 --> Output Class Initialized
INFO - 2023-03-02 03:31:09 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:09 --> Input Class Initialized
INFO - 2023-03-02 03:31:09 --> Language Class Initialized
INFO - 2023-03-02 03:31:09 --> Loader Class Initialized
INFO - 2023-03-02 03:31:09 --> Controller Class Initialized
DEBUG - 2023-03-02 03:31:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:09 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:09 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:31:09 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:09 --> Total execution time: 0.0645
INFO - 2023-03-02 03:31:09 --> Config Class Initialized
INFO - 2023-03-02 03:31:09 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:09 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:09 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:09 --> URI Class Initialized
INFO - 2023-03-02 03:31:09 --> Router Class Initialized
INFO - 2023-03-02 03:31:09 --> Output Class Initialized
INFO - 2023-03-02 03:31:09 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:09 --> Input Class Initialized
INFO - 2023-03-02 03:31:09 --> Language Class Initialized
INFO - 2023-03-02 03:31:09 --> Loader Class Initialized
INFO - 2023-03-02 03:31:09 --> Controller Class Initialized
DEBUG - 2023-03-02 03:31:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:09 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:09 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:31:09 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:09 --> Model "Login_model" initialized
INFO - 2023-03-02 03:31:09 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:09 --> Total execution time: 0.1293
INFO - 2023-03-02 03:31:09 --> Config Class Initialized
INFO - 2023-03-02 03:31:09 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:09 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:09 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:09 --> URI Class Initialized
INFO - 2023-03-02 03:31:09 --> Router Class Initialized
INFO - 2023-03-02 03:31:09 --> Output Class Initialized
INFO - 2023-03-02 03:31:09 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:09 --> Input Class Initialized
INFO - 2023-03-02 03:31:09 --> Language Class Initialized
INFO - 2023-03-02 03:31:09 --> Loader Class Initialized
INFO - 2023-03-02 03:31:09 --> Controller Class Initialized
DEBUG - 2023-03-02 03:31:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:09 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:09 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:31:09 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:09 --> Model "Login_model" initialized
INFO - 2023-03-02 03:31:09 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:09 --> Total execution time: 0.1339
INFO - 2023-03-02 03:31:13 --> Config Class Initialized
INFO - 2023-03-02 03:31:13 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:13 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:13 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:13 --> URI Class Initialized
INFO - 2023-03-02 03:31:13 --> Router Class Initialized
INFO - 2023-03-02 03:31:13 --> Output Class Initialized
INFO - 2023-03-02 03:31:13 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:13 --> Input Class Initialized
INFO - 2023-03-02 03:31:13 --> Language Class Initialized
INFO - 2023-03-02 03:31:13 --> Loader Class Initialized
INFO - 2023-03-02 03:31:13 --> Controller Class Initialized
DEBUG - 2023-03-02 03:31:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:13 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:13 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:31:13 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:13 --> Total execution time: 0.0237
INFO - 2023-03-02 03:31:13 --> Config Class Initialized
INFO - 2023-03-02 03:31:13 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:13 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:13 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:13 --> URI Class Initialized
INFO - 2023-03-02 03:31:13 --> Router Class Initialized
INFO - 2023-03-02 03:31:13 --> Output Class Initialized
INFO - 2023-03-02 03:31:13 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:13 --> Input Class Initialized
INFO - 2023-03-02 03:31:13 --> Language Class Initialized
INFO - 2023-03-02 03:31:13 --> Loader Class Initialized
INFO - 2023-03-02 03:31:13 --> Controller Class Initialized
DEBUG - 2023-03-02 03:31:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:13 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:13 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:31:13 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:13 --> Total execution time: 0.0419
INFO - 2023-03-02 03:31:15 --> Config Class Initialized
INFO - 2023-03-02 03:31:15 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:15 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:15 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:15 --> URI Class Initialized
INFO - 2023-03-02 03:31:15 --> Router Class Initialized
INFO - 2023-03-02 03:31:15 --> Output Class Initialized
INFO - 2023-03-02 03:31:15 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:15 --> Input Class Initialized
INFO - 2023-03-02 03:31:15 --> Language Class Initialized
INFO - 2023-03-02 03:31:15 --> Loader Class Initialized
INFO - 2023-03-02 03:31:15 --> Controller Class Initialized
DEBUG - 2023-03-02 03:31:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:15 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:15 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:15 --> Model "Login_model" initialized
INFO - 2023-03-02 03:31:15 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:15 --> Total execution time: 0.0265
INFO - 2023-03-02 03:31:15 --> Config Class Initialized
INFO - 2023-03-02 03:31:15 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:15 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:15 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:15 --> URI Class Initialized
INFO - 2023-03-02 03:31:15 --> Router Class Initialized
INFO - 2023-03-02 03:31:15 --> Output Class Initialized
INFO - 2023-03-02 03:31:15 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:15 --> Input Class Initialized
INFO - 2023-03-02 03:31:15 --> Language Class Initialized
INFO - 2023-03-02 03:31:15 --> Loader Class Initialized
INFO - 2023-03-02 03:31:15 --> Controller Class Initialized
DEBUG - 2023-03-02 03:31:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:15 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:15 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:15 --> Model "Login_model" initialized
INFO - 2023-03-02 03:31:15 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:15 --> Total execution time: 0.0649
INFO - 2023-03-02 03:31:57 --> Config Class Initialized
INFO - 2023-03-02 03:31:57 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:57 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:57 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:57 --> URI Class Initialized
INFO - 2023-03-02 03:31:57 --> Router Class Initialized
INFO - 2023-03-02 03:31:57 --> Output Class Initialized
INFO - 2023-03-02 03:31:57 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:57 --> Input Class Initialized
INFO - 2023-03-02 03:31:57 --> Language Class Initialized
INFO - 2023-03-02 03:31:57 --> Loader Class Initialized
INFO - 2023-03-02 03:31:57 --> Controller Class Initialized
DEBUG - 2023-03-02 03:31:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:57 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:57 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:31:57 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:57 --> Total execution time: 0.0557
INFO - 2023-03-02 03:31:57 --> Config Class Initialized
INFO - 2023-03-02 03:31:57 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:57 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:57 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:57 --> URI Class Initialized
INFO - 2023-03-02 03:31:57 --> Router Class Initialized
INFO - 2023-03-02 03:31:57 --> Output Class Initialized
INFO - 2023-03-02 03:31:57 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:57 --> Input Class Initialized
INFO - 2023-03-02 03:31:57 --> Language Class Initialized
INFO - 2023-03-02 03:31:57 --> Loader Class Initialized
INFO - 2023-03-02 03:31:57 --> Controller Class Initialized
DEBUG - 2023-03-02 03:31:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:57 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:57 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:31:57 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:57 --> Total execution time: 0.0417
INFO - 2023-03-02 03:31:59 --> Config Class Initialized
INFO - 2023-03-02 03:31:59 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:59 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:59 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:59 --> URI Class Initialized
INFO - 2023-03-02 03:31:59 --> Router Class Initialized
INFO - 2023-03-02 03:31:59 --> Output Class Initialized
INFO - 2023-03-02 03:31:59 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:59 --> Input Class Initialized
INFO - 2023-03-02 03:31:59 --> Language Class Initialized
INFO - 2023-03-02 03:31:59 --> Loader Class Initialized
INFO - 2023-03-02 03:31:59 --> Controller Class Initialized
DEBUG - 2023-03-02 03:31:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:59 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:59 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:31:59 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:59 --> Total execution time: 0.1261
INFO - 2023-03-02 03:31:59 --> Config Class Initialized
INFO - 2023-03-02 03:31:59 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:31:59 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:31:59 --> Utf8 Class Initialized
INFO - 2023-03-02 03:31:59 --> URI Class Initialized
INFO - 2023-03-02 03:31:59 --> Router Class Initialized
INFO - 2023-03-02 03:31:59 --> Output Class Initialized
INFO - 2023-03-02 03:31:59 --> Security Class Initialized
DEBUG - 2023-03-02 03:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:31:59 --> Input Class Initialized
INFO - 2023-03-02 03:31:59 --> Language Class Initialized
INFO - 2023-03-02 03:31:59 --> Loader Class Initialized
INFO - 2023-03-02 03:31:59 --> Controller Class Initialized
DEBUG - 2023-03-02 03:31:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:31:59 --> Database Driver Class Initialized
INFO - 2023-03-02 03:31:59 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:31:59 --> Final output sent to browser
DEBUG - 2023-03-02 03:31:59 --> Total execution time: 0.0754
INFO - 2023-03-02 03:32:03 --> Config Class Initialized
INFO - 2023-03-02 03:32:03 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:32:03 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:32:03 --> Utf8 Class Initialized
INFO - 2023-03-02 03:32:03 --> URI Class Initialized
INFO - 2023-03-02 03:32:03 --> Router Class Initialized
INFO - 2023-03-02 03:32:03 --> Output Class Initialized
INFO - 2023-03-02 03:32:03 --> Security Class Initialized
DEBUG - 2023-03-02 03:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:32:03 --> Input Class Initialized
INFO - 2023-03-02 03:32:03 --> Language Class Initialized
INFO - 2023-03-02 03:32:03 --> Loader Class Initialized
INFO - 2023-03-02 03:32:03 --> Controller Class Initialized
DEBUG - 2023-03-02 03:32:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:32:03 --> Database Driver Class Initialized
INFO - 2023-03-02 03:32:03 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:32:03 --> Database Driver Class Initialized
INFO - 2023-03-02 03:32:03 --> Model "Login_model" initialized
INFO - 2023-03-02 03:32:03 --> Final output sent to browser
DEBUG - 2023-03-02 03:32:03 --> Total execution time: 0.0510
INFO - 2023-03-02 03:32:03 --> Config Class Initialized
INFO - 2023-03-02 03:32:03 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:32:03 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:32:03 --> Utf8 Class Initialized
INFO - 2023-03-02 03:32:03 --> URI Class Initialized
INFO - 2023-03-02 03:32:03 --> Router Class Initialized
INFO - 2023-03-02 03:32:03 --> Output Class Initialized
INFO - 2023-03-02 03:32:03 --> Security Class Initialized
DEBUG - 2023-03-02 03:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:32:03 --> Input Class Initialized
INFO - 2023-03-02 03:32:03 --> Language Class Initialized
INFO - 2023-03-02 03:32:03 --> Loader Class Initialized
INFO - 2023-03-02 03:32:03 --> Controller Class Initialized
DEBUG - 2023-03-02 03:32:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:32:03 --> Database Driver Class Initialized
INFO - 2023-03-02 03:32:03 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:32:03 --> Database Driver Class Initialized
INFO - 2023-03-02 03:32:03 --> Model "Login_model" initialized
INFO - 2023-03-02 03:32:03 --> Final output sent to browser
DEBUG - 2023-03-02 03:32:03 --> Total execution time: 0.0893
INFO - 2023-03-02 03:33:39 --> Config Class Initialized
INFO - 2023-03-02 03:33:39 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:33:39 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:33:39 --> Utf8 Class Initialized
INFO - 2023-03-02 03:33:39 --> URI Class Initialized
INFO - 2023-03-02 03:33:39 --> Router Class Initialized
INFO - 2023-03-02 03:33:39 --> Output Class Initialized
INFO - 2023-03-02 03:33:39 --> Security Class Initialized
DEBUG - 2023-03-02 03:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:33:39 --> Input Class Initialized
INFO - 2023-03-02 03:33:39 --> Language Class Initialized
INFO - 2023-03-02 03:33:39 --> Loader Class Initialized
INFO - 2023-03-02 03:33:39 --> Controller Class Initialized
DEBUG - 2023-03-02 03:33:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:33:39 --> Database Driver Class Initialized
INFO - 2023-03-02 03:33:39 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:33:39 --> Config Class Initialized
INFO - 2023-03-02 03:33:39 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:33:39 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:33:39 --> Utf8 Class Initialized
INFO - 2023-03-02 03:33:39 --> URI Class Initialized
INFO - 2023-03-02 03:33:39 --> Router Class Initialized
INFO - 2023-03-02 03:33:39 --> Output Class Initialized
INFO - 2023-03-02 03:33:39 --> Security Class Initialized
DEBUG - 2023-03-02 03:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:33:39 --> Input Class Initialized
INFO - 2023-03-02 03:33:39 --> Language Class Initialized
INFO - 2023-03-02 03:33:39 --> Loader Class Initialized
INFO - 2023-03-02 03:33:39 --> Controller Class Initialized
DEBUG - 2023-03-02 03:33:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:33:39 --> Database Driver Class Initialized
INFO - 2023-03-02 03:33:39 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:33:39 --> Config Class Initialized
INFO - 2023-03-02 03:33:39 --> Config Class Initialized
INFO - 2023-03-02 03:33:39 --> Hooks Class Initialized
INFO - 2023-03-02 03:33:39 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:33:39 --> UTF-8 Support Enabled
DEBUG - 2023-03-02 03:33:39 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:33:39 --> Utf8 Class Initialized
INFO - 2023-03-02 03:33:39 --> Utf8 Class Initialized
INFO - 2023-03-02 03:33:39 --> URI Class Initialized
INFO - 2023-03-02 03:33:39 --> URI Class Initialized
INFO - 2023-03-02 03:33:39 --> Router Class Initialized
INFO - 2023-03-02 03:33:39 --> Router Class Initialized
INFO - 2023-03-02 03:33:39 --> Output Class Initialized
INFO - 2023-03-02 03:33:39 --> Output Class Initialized
INFO - 2023-03-02 03:33:39 --> Security Class Initialized
INFO - 2023-03-02 03:33:39 --> Security Class Initialized
DEBUG - 2023-03-02 03:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-02 03:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:33:39 --> Input Class Initialized
INFO - 2023-03-02 03:33:39 --> Input Class Initialized
INFO - 2023-03-02 03:33:39 --> Language Class Initialized
INFO - 2023-03-02 03:33:39 --> Language Class Initialized
INFO - 2023-03-02 03:33:39 --> Loader Class Initialized
INFO - 2023-03-02 03:33:39 --> Loader Class Initialized
INFO - 2023-03-02 03:33:39 --> Controller Class Initialized
INFO - 2023-03-02 03:33:39 --> Controller Class Initialized
DEBUG - 2023-03-02 03:33:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-02 03:33:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:33:39 --> Database Driver Class Initialized
INFO - 2023-03-02 03:33:39 --> Database Driver Class Initialized
INFO - 2023-03-02 03:33:39 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:33:39 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:33:39 --> Final output sent to browser
DEBUG - 2023-03-02 03:33:39 --> Total execution time: 0.0154
INFO - 2023-03-02 03:33:39 --> Config Class Initialized
INFO - 2023-03-02 03:33:39 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:33:39 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:33:39 --> Utf8 Class Initialized
INFO - 2023-03-02 03:33:39 --> URI Class Initialized
INFO - 2023-03-02 03:33:39 --> Router Class Initialized
INFO - 2023-03-02 03:33:39 --> Output Class Initialized
INFO - 2023-03-02 03:33:39 --> Security Class Initialized
DEBUG - 2023-03-02 03:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:33:39 --> Input Class Initialized
INFO - 2023-03-02 03:33:39 --> Language Class Initialized
INFO - 2023-03-02 03:33:39 --> Loader Class Initialized
INFO - 2023-03-02 03:33:39 --> Controller Class Initialized
DEBUG - 2023-03-02 03:33:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:33:39 --> Database Driver Class Initialized
INFO - 2023-03-02 03:33:39 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:33:39 --> Final output sent to browser
DEBUG - 2023-03-02 03:33:39 --> Total execution time: 0.0599
INFO - 2023-03-02 03:33:40 --> Config Class Initialized
INFO - 2023-03-02 03:33:40 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:33:40 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:33:40 --> Utf8 Class Initialized
INFO - 2023-03-02 03:33:40 --> URI Class Initialized
INFO - 2023-03-02 03:33:40 --> Router Class Initialized
INFO - 2023-03-02 03:33:40 --> Output Class Initialized
INFO - 2023-03-02 03:33:40 --> Security Class Initialized
DEBUG - 2023-03-02 03:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:33:40 --> Input Class Initialized
INFO - 2023-03-02 03:33:40 --> Language Class Initialized
INFO - 2023-03-02 03:33:40 --> Loader Class Initialized
INFO - 2023-03-02 03:33:40 --> Controller Class Initialized
DEBUG - 2023-03-02 03:33:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:33:40 --> Database Driver Class Initialized
INFO - 2023-03-02 03:33:40 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:33:40 --> Config Class Initialized
INFO - 2023-03-02 03:33:40 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:33:40 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:33:40 --> Utf8 Class Initialized
INFO - 2023-03-02 03:33:40 --> URI Class Initialized
INFO - 2023-03-02 03:33:40 --> Router Class Initialized
INFO - 2023-03-02 03:33:40 --> Output Class Initialized
INFO - 2023-03-02 03:33:40 --> Security Class Initialized
DEBUG - 2023-03-02 03:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:33:40 --> Input Class Initialized
INFO - 2023-03-02 03:33:40 --> Language Class Initialized
INFO - 2023-03-02 03:33:40 --> Loader Class Initialized
INFO - 2023-03-02 03:33:40 --> Controller Class Initialized
DEBUG - 2023-03-02 03:33:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:33:40 --> Database Driver Class Initialized
INFO - 2023-03-02 03:33:40 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:33:41 --> Config Class Initialized
INFO - 2023-03-02 03:33:41 --> Config Class Initialized
INFO - 2023-03-02 03:33:41 --> Hooks Class Initialized
INFO - 2023-03-02 03:33:41 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:33:41 --> UTF-8 Support Enabled
DEBUG - 2023-03-02 03:33:41 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:33:41 --> Utf8 Class Initialized
INFO - 2023-03-02 03:33:41 --> Utf8 Class Initialized
INFO - 2023-03-02 03:33:41 --> URI Class Initialized
INFO - 2023-03-02 03:33:41 --> URI Class Initialized
INFO - 2023-03-02 03:33:41 --> Router Class Initialized
INFO - 2023-03-02 03:33:41 --> Router Class Initialized
INFO - 2023-03-02 03:33:41 --> Output Class Initialized
INFO - 2023-03-02 03:33:41 --> Output Class Initialized
INFO - 2023-03-02 03:33:41 --> Security Class Initialized
INFO - 2023-03-02 03:33:41 --> Security Class Initialized
DEBUG - 2023-03-02 03:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-02 03:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:33:41 --> Input Class Initialized
INFO - 2023-03-02 03:33:41 --> Input Class Initialized
INFO - 2023-03-02 03:33:41 --> Language Class Initialized
INFO - 2023-03-02 03:33:41 --> Language Class Initialized
INFO - 2023-03-02 03:33:41 --> Loader Class Initialized
INFO - 2023-03-02 03:33:41 --> Loader Class Initialized
INFO - 2023-03-02 03:33:41 --> Controller Class Initialized
INFO - 2023-03-02 03:33:41 --> Controller Class Initialized
DEBUG - 2023-03-02 03:33:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-02 03:33:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:33:41 --> Database Driver Class Initialized
INFO - 2023-03-02 03:33:41 --> Database Driver Class Initialized
INFO - 2023-03-02 03:33:41 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:33:41 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:33:41 --> Final output sent to browser
DEBUG - 2023-03-02 03:33:41 --> Total execution time: 0.0158
INFO - 2023-03-02 03:33:41 --> Config Class Initialized
INFO - 2023-03-02 03:33:41 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:33:41 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:33:41 --> Utf8 Class Initialized
INFO - 2023-03-02 03:33:41 --> URI Class Initialized
INFO - 2023-03-02 03:33:41 --> Router Class Initialized
INFO - 2023-03-02 03:33:41 --> Output Class Initialized
INFO - 2023-03-02 03:33:41 --> Security Class Initialized
DEBUG - 2023-03-02 03:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:33:41 --> Input Class Initialized
INFO - 2023-03-02 03:33:41 --> Language Class Initialized
INFO - 2023-03-02 03:33:41 --> Loader Class Initialized
INFO - 2023-03-02 03:33:41 --> Controller Class Initialized
DEBUG - 2023-03-02 03:33:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:33:41 --> Database Driver Class Initialized
INFO - 2023-03-02 03:33:41 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:33:42 --> Config Class Initialized
INFO - 2023-03-02 03:33:42 --> Config Class Initialized
INFO - 2023-03-02 03:33:42 --> Hooks Class Initialized
INFO - 2023-03-02 03:33:42 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:33:42 --> UTF-8 Support Enabled
DEBUG - 2023-03-02 03:33:42 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:33:42 --> Utf8 Class Initialized
INFO - 2023-03-02 03:33:42 --> Utf8 Class Initialized
INFO - 2023-03-02 03:33:42 --> URI Class Initialized
INFO - 2023-03-02 03:33:42 --> URI Class Initialized
INFO - 2023-03-02 03:33:42 --> Router Class Initialized
INFO - 2023-03-02 03:33:42 --> Router Class Initialized
INFO - 2023-03-02 03:33:42 --> Output Class Initialized
INFO - 2023-03-02 03:33:42 --> Output Class Initialized
INFO - 2023-03-02 03:33:42 --> Security Class Initialized
INFO - 2023-03-02 03:33:42 --> Security Class Initialized
DEBUG - 2023-03-02 03:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-02 03:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:33:42 --> Input Class Initialized
INFO - 2023-03-02 03:33:42 --> Input Class Initialized
INFO - 2023-03-02 03:33:42 --> Language Class Initialized
INFO - 2023-03-02 03:33:42 --> Language Class Initialized
INFO - 2023-03-02 03:33:42 --> Loader Class Initialized
INFO - 2023-03-02 03:33:42 --> Loader Class Initialized
INFO - 2023-03-02 03:33:42 --> Controller Class Initialized
INFO - 2023-03-02 03:33:42 --> Controller Class Initialized
DEBUG - 2023-03-02 03:33:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-02 03:33:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:33:42 --> Database Driver Class Initialized
INFO - 2023-03-02 03:33:42 --> Database Driver Class Initialized
INFO - 2023-03-02 03:33:42 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:33:42 --> Model "Cluster_model" initialized
INFO - 2023-03-02 03:33:42 --> Final output sent to browser
DEBUG - 2023-03-02 03:33:42 --> Total execution time: 0.0571
INFO - 2023-03-02 03:37:55 --> Config Class Initialized
INFO - 2023-03-02 03:37:55 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:37:55 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:37:55 --> Utf8 Class Initialized
INFO - 2023-03-02 03:37:55 --> URI Class Initialized
INFO - 2023-03-02 03:37:55 --> Router Class Initialized
INFO - 2023-03-02 03:37:55 --> Output Class Initialized
INFO - 2023-03-02 03:37:55 --> Security Class Initialized
DEBUG - 2023-03-02 03:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:37:55 --> Input Class Initialized
INFO - 2023-03-02 03:37:55 --> Language Class Initialized
INFO - 2023-03-02 03:37:55 --> Loader Class Initialized
INFO - 2023-03-02 03:37:55 --> Controller Class Initialized
DEBUG - 2023-03-02 03:37:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:37:55 --> Database Driver Class Initialized
INFO - 2023-03-02 03:37:55 --> Final output sent to browser
DEBUG - 2023-03-02 03:37:55 --> Total execution time: 0.0203
INFO - 2023-03-02 03:37:55 --> Config Class Initialized
INFO - 2023-03-02 03:37:55 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:37:55 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:37:55 --> Utf8 Class Initialized
INFO - 2023-03-02 03:37:55 --> URI Class Initialized
INFO - 2023-03-02 03:37:55 --> Router Class Initialized
INFO - 2023-03-02 03:37:55 --> Output Class Initialized
INFO - 2023-03-02 03:37:55 --> Security Class Initialized
DEBUG - 2023-03-02 03:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:37:55 --> Input Class Initialized
INFO - 2023-03-02 03:37:55 --> Language Class Initialized
INFO - 2023-03-02 03:37:55 --> Loader Class Initialized
INFO - 2023-03-02 03:37:55 --> Controller Class Initialized
DEBUG - 2023-03-02 03:37:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:37:55 --> Database Driver Class Initialized
INFO - 2023-03-02 03:37:55 --> Final output sent to browser
DEBUG - 2023-03-02 03:37:55 --> Total execution time: 0.0181
INFO - 2023-03-02 03:38:05 --> Config Class Initialized
INFO - 2023-03-02 03:38:05 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:38:05 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:38:05 --> Utf8 Class Initialized
INFO - 2023-03-02 03:38:05 --> URI Class Initialized
INFO - 2023-03-02 03:38:05 --> Router Class Initialized
INFO - 2023-03-02 03:38:05 --> Output Class Initialized
INFO - 2023-03-02 03:38:05 --> Security Class Initialized
DEBUG - 2023-03-02 03:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:38:05 --> Input Class Initialized
INFO - 2023-03-02 03:38:05 --> Language Class Initialized
INFO - 2023-03-02 03:38:05 --> Loader Class Initialized
INFO - 2023-03-02 03:38:05 --> Controller Class Initialized
DEBUG - 2023-03-02 03:38:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:38:05 --> Database Driver Class Initialized
INFO - 2023-03-02 03:38:05 --> Final output sent to browser
DEBUG - 2023-03-02 03:38:05 --> Total execution time: 0.0144
INFO - 2023-03-02 03:38:05 --> Config Class Initialized
INFO - 2023-03-02 03:38:05 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:38:05 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:38:05 --> Utf8 Class Initialized
INFO - 2023-03-02 03:38:05 --> URI Class Initialized
INFO - 2023-03-02 03:38:05 --> Router Class Initialized
INFO - 2023-03-02 03:38:05 --> Output Class Initialized
INFO - 2023-03-02 03:38:05 --> Security Class Initialized
DEBUG - 2023-03-02 03:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:38:05 --> Input Class Initialized
INFO - 2023-03-02 03:38:05 --> Language Class Initialized
INFO - 2023-03-02 03:38:05 --> Loader Class Initialized
INFO - 2023-03-02 03:38:05 --> Controller Class Initialized
DEBUG - 2023-03-02 03:38:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:38:05 --> Database Driver Class Initialized
INFO - 2023-03-02 03:38:05 --> Final output sent to browser
DEBUG - 2023-03-02 03:38:05 --> Total execution time: 0.0142
INFO - 2023-03-02 03:38:08 --> Config Class Initialized
INFO - 2023-03-02 03:38:08 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:38:08 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:38:08 --> Utf8 Class Initialized
INFO - 2023-03-02 03:38:08 --> URI Class Initialized
INFO - 2023-03-02 03:38:08 --> Router Class Initialized
INFO - 2023-03-02 03:38:08 --> Output Class Initialized
INFO - 2023-03-02 03:38:08 --> Security Class Initialized
DEBUG - 2023-03-02 03:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:38:08 --> Input Class Initialized
INFO - 2023-03-02 03:38:08 --> Language Class Initialized
INFO - 2023-03-02 03:38:08 --> Loader Class Initialized
INFO - 2023-03-02 03:38:08 --> Controller Class Initialized
DEBUG - 2023-03-02 03:38:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:38:08 --> Database Driver Class Initialized
INFO - 2023-03-02 03:38:08 --> Final output sent to browser
DEBUG - 2023-03-02 03:38:08 --> Total execution time: 0.0168
INFO - 2023-03-02 03:40:00 --> Config Class Initialized
INFO - 2023-03-02 03:40:00 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:40:00 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:40:00 --> Utf8 Class Initialized
INFO - 2023-03-02 03:40:00 --> URI Class Initialized
INFO - 2023-03-02 03:40:00 --> Router Class Initialized
INFO - 2023-03-02 03:40:00 --> Output Class Initialized
INFO - 2023-03-02 03:40:00 --> Security Class Initialized
DEBUG - 2023-03-02 03:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:40:00 --> Input Class Initialized
INFO - 2023-03-02 03:40:00 --> Language Class Initialized
INFO - 2023-03-02 03:40:00 --> Loader Class Initialized
INFO - 2023-03-02 03:40:00 --> Controller Class Initialized
DEBUG - 2023-03-02 03:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:40:00 --> Database Driver Class Initialized
INFO - 2023-03-02 03:40:00 --> Final output sent to browser
DEBUG - 2023-03-02 03:40:00 --> Total execution time: 0.0552
INFO - 2023-03-02 03:40:00 --> Config Class Initialized
INFO - 2023-03-02 03:40:00 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:40:00 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:40:00 --> Utf8 Class Initialized
INFO - 2023-03-02 03:40:00 --> URI Class Initialized
INFO - 2023-03-02 03:40:00 --> Router Class Initialized
INFO - 2023-03-02 03:40:00 --> Output Class Initialized
INFO - 2023-03-02 03:40:00 --> Security Class Initialized
DEBUG - 2023-03-02 03:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:40:00 --> Input Class Initialized
INFO - 2023-03-02 03:40:00 --> Language Class Initialized
INFO - 2023-03-02 03:40:00 --> Loader Class Initialized
INFO - 2023-03-02 03:40:00 --> Controller Class Initialized
DEBUG - 2023-03-02 03:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:40:00 --> Database Driver Class Initialized
INFO - 2023-03-02 03:40:00 --> Final output sent to browser
DEBUG - 2023-03-02 03:40:00 --> Total execution time: 0.0165
INFO - 2023-03-02 03:40:03 --> Config Class Initialized
INFO - 2023-03-02 03:40:03 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:40:03 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:40:03 --> Utf8 Class Initialized
INFO - 2023-03-02 03:40:03 --> URI Class Initialized
INFO - 2023-03-02 03:40:03 --> Router Class Initialized
INFO - 2023-03-02 03:40:03 --> Output Class Initialized
INFO - 2023-03-02 03:40:03 --> Security Class Initialized
DEBUG - 2023-03-02 03:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:40:03 --> Input Class Initialized
INFO - 2023-03-02 03:40:03 --> Language Class Initialized
INFO - 2023-03-02 03:40:03 --> Loader Class Initialized
INFO - 2023-03-02 03:40:03 --> Controller Class Initialized
DEBUG - 2023-03-02 03:40:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:40:03 --> Database Driver Class Initialized
INFO - 2023-03-02 03:40:03 --> Final output sent to browser
DEBUG - 2023-03-02 03:40:03 --> Total execution time: 0.0193
INFO - 2023-03-02 03:40:07 --> Config Class Initialized
INFO - 2023-03-02 03:40:07 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:40:07 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:40:07 --> Utf8 Class Initialized
INFO - 2023-03-02 03:40:07 --> URI Class Initialized
INFO - 2023-03-02 03:40:07 --> Router Class Initialized
INFO - 2023-03-02 03:40:07 --> Output Class Initialized
INFO - 2023-03-02 03:40:07 --> Security Class Initialized
DEBUG - 2023-03-02 03:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:40:07 --> Input Class Initialized
INFO - 2023-03-02 03:40:07 --> Language Class Initialized
INFO - 2023-03-02 03:40:07 --> Loader Class Initialized
INFO - 2023-03-02 03:40:07 --> Controller Class Initialized
DEBUG - 2023-03-02 03:40:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:40:07 --> Database Driver Class Initialized
INFO - 2023-03-02 03:40:07 --> Final output sent to browser
DEBUG - 2023-03-02 03:40:07 --> Total execution time: 0.0144
INFO - 2023-03-02 03:40:07 --> Config Class Initialized
INFO - 2023-03-02 03:40:07 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:40:07 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:40:07 --> Utf8 Class Initialized
INFO - 2023-03-02 03:40:07 --> URI Class Initialized
INFO - 2023-03-02 03:40:07 --> Router Class Initialized
INFO - 2023-03-02 03:40:07 --> Output Class Initialized
INFO - 2023-03-02 03:40:07 --> Security Class Initialized
DEBUG - 2023-03-02 03:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:40:07 --> Input Class Initialized
INFO - 2023-03-02 03:40:07 --> Language Class Initialized
INFO - 2023-03-02 03:40:07 --> Loader Class Initialized
INFO - 2023-03-02 03:40:07 --> Controller Class Initialized
DEBUG - 2023-03-02 03:40:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:40:07 --> Database Driver Class Initialized
INFO - 2023-03-02 03:40:07 --> Final output sent to browser
DEBUG - 2023-03-02 03:40:07 --> Total execution time: 0.0144
INFO - 2023-03-02 03:40:19 --> Config Class Initialized
INFO - 2023-03-02 03:40:19 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:40:19 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:40:19 --> Utf8 Class Initialized
INFO - 2023-03-02 03:40:19 --> URI Class Initialized
INFO - 2023-03-02 03:40:19 --> Router Class Initialized
INFO - 2023-03-02 03:40:19 --> Output Class Initialized
INFO - 2023-03-02 03:40:19 --> Security Class Initialized
DEBUG - 2023-03-02 03:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:40:19 --> Input Class Initialized
INFO - 2023-03-02 03:40:19 --> Language Class Initialized
INFO - 2023-03-02 03:40:19 --> Loader Class Initialized
INFO - 2023-03-02 03:40:19 --> Controller Class Initialized
DEBUG - 2023-03-02 03:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:40:19 --> Database Driver Class Initialized
INFO - 2023-03-02 03:40:19 --> Final output sent to browser
DEBUG - 2023-03-02 03:40:19 --> Total execution time: 0.0151
INFO - 2023-03-02 03:40:19 --> Config Class Initialized
INFO - 2023-03-02 03:40:19 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:40:19 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:40:19 --> Utf8 Class Initialized
INFO - 2023-03-02 03:40:19 --> URI Class Initialized
INFO - 2023-03-02 03:40:19 --> Router Class Initialized
INFO - 2023-03-02 03:40:19 --> Output Class Initialized
INFO - 2023-03-02 03:40:19 --> Security Class Initialized
DEBUG - 2023-03-02 03:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:40:19 --> Input Class Initialized
INFO - 2023-03-02 03:40:19 --> Language Class Initialized
INFO - 2023-03-02 03:40:19 --> Loader Class Initialized
INFO - 2023-03-02 03:40:19 --> Controller Class Initialized
DEBUG - 2023-03-02 03:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:40:19 --> Database Driver Class Initialized
INFO - 2023-03-02 03:40:19 --> Final output sent to browser
DEBUG - 2023-03-02 03:40:19 --> Total execution time: 0.0250
INFO - 2023-03-02 03:46:39 --> Config Class Initialized
INFO - 2023-03-02 03:46:39 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:46:39 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:46:39 --> Utf8 Class Initialized
INFO - 2023-03-02 03:46:39 --> URI Class Initialized
INFO - 2023-03-02 03:46:39 --> Router Class Initialized
INFO - 2023-03-02 03:46:39 --> Output Class Initialized
INFO - 2023-03-02 03:46:39 --> Security Class Initialized
DEBUG - 2023-03-02 03:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:46:39 --> Input Class Initialized
INFO - 2023-03-02 03:46:39 --> Language Class Initialized
INFO - 2023-03-02 03:46:39 --> Loader Class Initialized
INFO - 2023-03-02 03:46:39 --> Controller Class Initialized
DEBUG - 2023-03-02 03:46:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:46:39 --> Database Driver Class Initialized
INFO - 2023-03-02 03:46:39 --> Final output sent to browser
DEBUG - 2023-03-02 03:46:39 --> Total execution time: 0.0169
INFO - 2023-03-02 03:46:39 --> Config Class Initialized
INFO - 2023-03-02 03:46:39 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:46:39 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:46:39 --> Utf8 Class Initialized
INFO - 2023-03-02 03:46:39 --> URI Class Initialized
INFO - 2023-03-02 03:46:39 --> Router Class Initialized
INFO - 2023-03-02 03:46:39 --> Output Class Initialized
INFO - 2023-03-02 03:46:39 --> Security Class Initialized
DEBUG - 2023-03-02 03:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:46:39 --> Input Class Initialized
INFO - 2023-03-02 03:46:39 --> Language Class Initialized
INFO - 2023-03-02 03:46:39 --> Loader Class Initialized
INFO - 2023-03-02 03:46:39 --> Controller Class Initialized
DEBUG - 2023-03-02 03:46:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:46:39 --> Database Driver Class Initialized
INFO - 2023-03-02 03:46:39 --> Final output sent to browser
DEBUG - 2023-03-02 03:46:39 --> Total execution time: 0.0179
INFO - 2023-03-02 03:48:15 --> Config Class Initialized
INFO - 2023-03-02 03:48:15 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:48:15 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:48:15 --> Utf8 Class Initialized
INFO - 2023-03-02 03:48:15 --> URI Class Initialized
INFO - 2023-03-02 03:48:15 --> Router Class Initialized
INFO - 2023-03-02 03:48:15 --> Output Class Initialized
INFO - 2023-03-02 03:48:15 --> Security Class Initialized
DEBUG - 2023-03-02 03:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:48:15 --> Input Class Initialized
INFO - 2023-03-02 03:48:15 --> Language Class Initialized
INFO - 2023-03-02 03:48:15 --> Loader Class Initialized
INFO - 2023-03-02 03:48:15 --> Controller Class Initialized
DEBUG - 2023-03-02 03:48:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:48:15 --> Database Driver Class Initialized
INFO - 2023-03-02 03:48:15 --> Final output sent to browser
DEBUG - 2023-03-02 03:48:15 --> Total execution time: 0.0249
INFO - 2023-03-02 03:48:15 --> Config Class Initialized
INFO - 2023-03-02 03:48:15 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:48:15 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:48:15 --> Utf8 Class Initialized
INFO - 2023-03-02 03:48:15 --> URI Class Initialized
INFO - 2023-03-02 03:48:15 --> Router Class Initialized
INFO - 2023-03-02 03:48:15 --> Output Class Initialized
INFO - 2023-03-02 03:48:15 --> Security Class Initialized
DEBUG - 2023-03-02 03:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:48:15 --> Input Class Initialized
INFO - 2023-03-02 03:48:15 --> Language Class Initialized
INFO - 2023-03-02 03:48:15 --> Loader Class Initialized
INFO - 2023-03-02 03:48:15 --> Controller Class Initialized
DEBUG - 2023-03-02 03:48:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:48:15 --> Database Driver Class Initialized
INFO - 2023-03-02 03:48:15 --> Final output sent to browser
DEBUG - 2023-03-02 03:48:15 --> Total execution time: 0.0157
INFO - 2023-03-02 03:49:06 --> Config Class Initialized
INFO - 2023-03-02 03:49:06 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:49:06 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:49:06 --> Utf8 Class Initialized
INFO - 2023-03-02 03:49:06 --> URI Class Initialized
INFO - 2023-03-02 03:49:06 --> Router Class Initialized
INFO - 2023-03-02 03:49:06 --> Output Class Initialized
INFO - 2023-03-02 03:49:06 --> Security Class Initialized
DEBUG - 2023-03-02 03:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:49:06 --> Input Class Initialized
INFO - 2023-03-02 03:49:06 --> Language Class Initialized
INFO - 2023-03-02 03:49:06 --> Loader Class Initialized
INFO - 2023-03-02 03:49:06 --> Controller Class Initialized
DEBUG - 2023-03-02 03:49:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:49:06 --> Database Driver Class Initialized
INFO - 2023-03-02 03:49:06 --> Final output sent to browser
DEBUG - 2023-03-02 03:49:06 --> Total execution time: 0.0165
INFO - 2023-03-02 03:49:06 --> Config Class Initialized
INFO - 2023-03-02 03:49:06 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:49:06 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:49:06 --> Utf8 Class Initialized
INFO - 2023-03-02 03:49:06 --> URI Class Initialized
INFO - 2023-03-02 03:49:06 --> Router Class Initialized
INFO - 2023-03-02 03:49:06 --> Output Class Initialized
INFO - 2023-03-02 03:49:06 --> Security Class Initialized
DEBUG - 2023-03-02 03:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:49:06 --> Input Class Initialized
INFO - 2023-03-02 03:49:06 --> Language Class Initialized
INFO - 2023-03-02 03:49:06 --> Loader Class Initialized
INFO - 2023-03-02 03:49:06 --> Controller Class Initialized
DEBUG - 2023-03-02 03:49:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:49:06 --> Database Driver Class Initialized
INFO - 2023-03-02 03:49:06 --> Final output sent to browser
DEBUG - 2023-03-02 03:49:06 --> Total execution time: 0.0241
INFO - 2023-03-02 03:51:41 --> Config Class Initialized
INFO - 2023-03-02 03:51:41 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:51:41 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:51:41 --> Utf8 Class Initialized
INFO - 2023-03-02 03:51:41 --> URI Class Initialized
INFO - 2023-03-02 03:51:41 --> Router Class Initialized
INFO - 2023-03-02 03:51:41 --> Output Class Initialized
INFO - 2023-03-02 03:51:41 --> Security Class Initialized
DEBUG - 2023-03-02 03:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:51:41 --> Input Class Initialized
INFO - 2023-03-02 03:51:41 --> Language Class Initialized
INFO - 2023-03-02 03:51:41 --> Loader Class Initialized
INFO - 2023-03-02 03:51:41 --> Controller Class Initialized
DEBUG - 2023-03-02 03:51:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:51:41 --> Database Driver Class Initialized
INFO - 2023-03-02 03:51:41 --> Final output sent to browser
DEBUG - 2023-03-02 03:51:41 --> Total execution time: 0.0204
INFO - 2023-03-02 03:51:41 --> Config Class Initialized
INFO - 2023-03-02 03:51:41 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:51:41 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:51:41 --> Utf8 Class Initialized
INFO - 2023-03-02 03:51:41 --> URI Class Initialized
INFO - 2023-03-02 03:51:41 --> Router Class Initialized
INFO - 2023-03-02 03:51:41 --> Output Class Initialized
INFO - 2023-03-02 03:51:41 --> Security Class Initialized
DEBUG - 2023-03-02 03:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:51:41 --> Input Class Initialized
INFO - 2023-03-02 03:51:41 --> Language Class Initialized
INFO - 2023-03-02 03:51:41 --> Loader Class Initialized
INFO - 2023-03-02 03:51:41 --> Controller Class Initialized
DEBUG - 2023-03-02 03:51:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:51:41 --> Database Driver Class Initialized
INFO - 2023-03-02 03:51:41 --> Final output sent to browser
DEBUG - 2023-03-02 03:51:41 --> Total execution time: 0.0200
INFO - 2023-03-02 03:51:48 --> Config Class Initialized
INFO - 2023-03-02 03:51:48 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:51:48 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:51:48 --> Utf8 Class Initialized
INFO - 2023-03-02 03:51:48 --> URI Class Initialized
INFO - 2023-03-02 03:51:48 --> Router Class Initialized
INFO - 2023-03-02 03:51:48 --> Output Class Initialized
INFO - 2023-03-02 03:51:48 --> Security Class Initialized
DEBUG - 2023-03-02 03:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:51:48 --> Input Class Initialized
INFO - 2023-03-02 03:51:48 --> Language Class Initialized
INFO - 2023-03-02 03:51:48 --> Loader Class Initialized
INFO - 2023-03-02 03:51:48 --> Controller Class Initialized
DEBUG - 2023-03-02 03:51:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:51:48 --> Database Driver Class Initialized
INFO - 2023-03-02 03:51:48 --> Final output sent to browser
DEBUG - 2023-03-02 03:51:48 --> Total execution time: 0.0148
INFO - 2023-03-02 03:51:48 --> Config Class Initialized
INFO - 2023-03-02 03:51:48 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:51:48 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:51:48 --> Utf8 Class Initialized
INFO - 2023-03-02 03:51:48 --> URI Class Initialized
INFO - 2023-03-02 03:51:48 --> Router Class Initialized
INFO - 2023-03-02 03:51:48 --> Output Class Initialized
INFO - 2023-03-02 03:51:48 --> Security Class Initialized
DEBUG - 2023-03-02 03:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:51:48 --> Input Class Initialized
INFO - 2023-03-02 03:51:48 --> Language Class Initialized
INFO - 2023-03-02 03:51:48 --> Loader Class Initialized
INFO - 2023-03-02 03:51:48 --> Controller Class Initialized
DEBUG - 2023-03-02 03:51:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:51:48 --> Database Driver Class Initialized
INFO - 2023-03-02 03:51:48 --> Final output sent to browser
DEBUG - 2023-03-02 03:51:48 --> Total execution time: 0.0159
INFO - 2023-03-02 03:52:27 --> Config Class Initialized
INFO - 2023-03-02 03:52:27 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:52:27 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:52:27 --> Utf8 Class Initialized
INFO - 2023-03-02 03:52:27 --> URI Class Initialized
INFO - 2023-03-02 03:52:27 --> Router Class Initialized
INFO - 2023-03-02 03:52:27 --> Output Class Initialized
INFO - 2023-03-02 03:52:27 --> Security Class Initialized
DEBUG - 2023-03-02 03:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:52:27 --> Input Class Initialized
INFO - 2023-03-02 03:52:27 --> Language Class Initialized
INFO - 2023-03-02 03:52:27 --> Loader Class Initialized
INFO - 2023-03-02 03:52:27 --> Controller Class Initialized
DEBUG - 2023-03-02 03:52:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:52:27 --> Database Driver Class Initialized
INFO - 2023-03-02 03:52:27 --> Final output sent to browser
DEBUG - 2023-03-02 03:52:27 --> Total execution time: 0.0139
INFO - 2023-03-02 03:52:27 --> Config Class Initialized
INFO - 2023-03-02 03:52:27 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:52:27 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:52:27 --> Utf8 Class Initialized
INFO - 2023-03-02 03:52:27 --> URI Class Initialized
INFO - 2023-03-02 03:52:27 --> Router Class Initialized
INFO - 2023-03-02 03:52:27 --> Output Class Initialized
INFO - 2023-03-02 03:52:27 --> Security Class Initialized
DEBUG - 2023-03-02 03:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:52:27 --> Input Class Initialized
INFO - 2023-03-02 03:52:27 --> Language Class Initialized
INFO - 2023-03-02 03:52:27 --> Loader Class Initialized
INFO - 2023-03-02 03:52:27 --> Controller Class Initialized
DEBUG - 2023-03-02 03:52:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:52:27 --> Database Driver Class Initialized
INFO - 2023-03-02 03:52:27 --> Final output sent to browser
DEBUG - 2023-03-02 03:52:27 --> Total execution time: 0.0164
INFO - 2023-03-02 03:52:28 --> Config Class Initialized
INFO - 2023-03-02 03:52:28 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:52:28 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:52:28 --> Utf8 Class Initialized
INFO - 2023-03-02 03:52:28 --> URI Class Initialized
INFO - 2023-03-02 03:52:28 --> Router Class Initialized
INFO - 2023-03-02 03:52:28 --> Output Class Initialized
INFO - 2023-03-02 03:52:28 --> Security Class Initialized
DEBUG - 2023-03-02 03:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:52:28 --> Input Class Initialized
INFO - 2023-03-02 03:52:28 --> Language Class Initialized
INFO - 2023-03-02 03:52:28 --> Loader Class Initialized
INFO - 2023-03-02 03:52:28 --> Controller Class Initialized
DEBUG - 2023-03-02 03:52:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:52:28 --> Database Driver Class Initialized
INFO - 2023-03-02 03:52:28 --> Final output sent to browser
DEBUG - 2023-03-02 03:52:28 --> Total execution time: 0.0172
INFO - 2023-03-02 03:52:29 --> Config Class Initialized
INFO - 2023-03-02 03:52:29 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:52:29 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:52:29 --> Utf8 Class Initialized
INFO - 2023-03-02 03:52:29 --> URI Class Initialized
INFO - 2023-03-02 03:52:29 --> Router Class Initialized
INFO - 2023-03-02 03:52:29 --> Output Class Initialized
INFO - 2023-03-02 03:52:29 --> Security Class Initialized
DEBUG - 2023-03-02 03:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:52:29 --> Input Class Initialized
INFO - 2023-03-02 03:52:29 --> Language Class Initialized
INFO - 2023-03-02 03:52:29 --> Loader Class Initialized
INFO - 2023-03-02 03:52:29 --> Controller Class Initialized
DEBUG - 2023-03-02 03:52:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:52:29 --> Database Driver Class Initialized
INFO - 2023-03-02 03:52:29 --> Final output sent to browser
DEBUG - 2023-03-02 03:52:29 --> Total execution time: 0.0188
INFO - 2023-03-02 03:52:32 --> Config Class Initialized
INFO - 2023-03-02 03:52:32 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:52:32 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:52:32 --> Utf8 Class Initialized
INFO - 2023-03-02 03:52:32 --> URI Class Initialized
INFO - 2023-03-02 03:52:32 --> Router Class Initialized
INFO - 2023-03-02 03:52:32 --> Output Class Initialized
INFO - 2023-03-02 03:52:32 --> Security Class Initialized
DEBUG - 2023-03-02 03:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:52:32 --> Input Class Initialized
INFO - 2023-03-02 03:52:32 --> Language Class Initialized
INFO - 2023-03-02 03:52:32 --> Loader Class Initialized
INFO - 2023-03-02 03:52:32 --> Controller Class Initialized
DEBUG - 2023-03-02 03:52:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:52:32 --> Database Driver Class Initialized
INFO - 2023-03-02 03:52:32 --> Final output sent to browser
DEBUG - 2023-03-02 03:52:32 --> Total execution time: 0.0131
INFO - 2023-03-02 03:52:32 --> Config Class Initialized
INFO - 2023-03-02 03:52:32 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:52:32 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:52:32 --> Utf8 Class Initialized
INFO - 2023-03-02 03:52:32 --> URI Class Initialized
INFO - 2023-03-02 03:52:32 --> Router Class Initialized
INFO - 2023-03-02 03:52:32 --> Output Class Initialized
INFO - 2023-03-02 03:52:32 --> Security Class Initialized
DEBUG - 2023-03-02 03:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:52:32 --> Input Class Initialized
INFO - 2023-03-02 03:52:32 --> Language Class Initialized
INFO - 2023-03-02 03:52:32 --> Loader Class Initialized
INFO - 2023-03-02 03:52:32 --> Controller Class Initialized
DEBUG - 2023-03-02 03:52:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:52:32 --> Database Driver Class Initialized
INFO - 2023-03-02 03:52:32 --> Final output sent to browser
DEBUG - 2023-03-02 03:52:32 --> Total execution time: 0.0153
INFO - 2023-03-02 03:53:58 --> Config Class Initialized
INFO - 2023-03-02 03:53:58 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:53:58 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:53:58 --> Utf8 Class Initialized
INFO - 2023-03-02 03:53:58 --> URI Class Initialized
INFO - 2023-03-02 03:53:58 --> Router Class Initialized
INFO - 2023-03-02 03:53:58 --> Output Class Initialized
INFO - 2023-03-02 03:53:58 --> Security Class Initialized
DEBUG - 2023-03-02 03:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:53:58 --> Input Class Initialized
INFO - 2023-03-02 03:53:58 --> Language Class Initialized
INFO - 2023-03-02 03:53:58 --> Loader Class Initialized
INFO - 2023-03-02 03:53:58 --> Controller Class Initialized
DEBUG - 2023-03-02 03:53:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:53:58 --> Database Driver Class Initialized
INFO - 2023-03-02 03:53:58 --> Final output sent to browser
DEBUG - 2023-03-02 03:53:58 --> Total execution time: 0.0173
INFO - 2023-03-02 03:53:58 --> Config Class Initialized
INFO - 2023-03-02 03:53:58 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:53:58 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:53:58 --> Utf8 Class Initialized
INFO - 2023-03-02 03:53:58 --> URI Class Initialized
INFO - 2023-03-02 03:53:58 --> Router Class Initialized
INFO - 2023-03-02 03:53:58 --> Output Class Initialized
INFO - 2023-03-02 03:53:58 --> Security Class Initialized
DEBUG - 2023-03-02 03:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:53:58 --> Input Class Initialized
INFO - 2023-03-02 03:53:58 --> Language Class Initialized
INFO - 2023-03-02 03:53:58 --> Loader Class Initialized
INFO - 2023-03-02 03:53:58 --> Controller Class Initialized
DEBUG - 2023-03-02 03:53:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:53:58 --> Database Driver Class Initialized
INFO - 2023-03-02 03:53:58 --> Final output sent to browser
DEBUG - 2023-03-02 03:53:58 --> Total execution time: 0.0186
INFO - 2023-03-02 03:54:03 --> Config Class Initialized
INFO - 2023-03-02 03:54:03 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:54:03 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:54:03 --> Utf8 Class Initialized
INFO - 2023-03-02 03:54:03 --> URI Class Initialized
INFO - 2023-03-02 03:54:03 --> Router Class Initialized
INFO - 2023-03-02 03:54:03 --> Output Class Initialized
INFO - 2023-03-02 03:54:03 --> Security Class Initialized
DEBUG - 2023-03-02 03:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:54:03 --> Input Class Initialized
INFO - 2023-03-02 03:54:03 --> Language Class Initialized
INFO - 2023-03-02 03:54:03 --> Loader Class Initialized
INFO - 2023-03-02 03:54:03 --> Controller Class Initialized
DEBUG - 2023-03-02 03:54:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:54:03 --> Database Driver Class Initialized
INFO - 2023-03-02 03:54:03 --> Final output sent to browser
DEBUG - 2023-03-02 03:54:03 --> Total execution time: 0.0177
INFO - 2023-03-02 03:54:05 --> Config Class Initialized
INFO - 2023-03-02 03:54:05 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:54:05 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:54:05 --> Utf8 Class Initialized
INFO - 2023-03-02 03:54:05 --> URI Class Initialized
INFO - 2023-03-02 03:54:05 --> Router Class Initialized
INFO - 2023-03-02 03:54:05 --> Output Class Initialized
INFO - 2023-03-02 03:54:05 --> Security Class Initialized
DEBUG - 2023-03-02 03:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:54:05 --> Input Class Initialized
INFO - 2023-03-02 03:54:05 --> Language Class Initialized
INFO - 2023-03-02 03:54:05 --> Loader Class Initialized
INFO - 2023-03-02 03:54:05 --> Controller Class Initialized
DEBUG - 2023-03-02 03:54:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:54:05 --> Database Driver Class Initialized
INFO - 2023-03-02 03:54:05 --> Final output sent to browser
DEBUG - 2023-03-02 03:54:05 --> Total execution time: 0.0144
INFO - 2023-03-02 03:54:05 --> Config Class Initialized
INFO - 2023-03-02 03:54:05 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:54:05 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:54:05 --> Utf8 Class Initialized
INFO - 2023-03-02 03:54:05 --> URI Class Initialized
INFO - 2023-03-02 03:54:05 --> Router Class Initialized
INFO - 2023-03-02 03:54:05 --> Output Class Initialized
INFO - 2023-03-02 03:54:05 --> Security Class Initialized
DEBUG - 2023-03-02 03:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:54:05 --> Input Class Initialized
INFO - 2023-03-02 03:54:05 --> Language Class Initialized
INFO - 2023-03-02 03:54:05 --> Loader Class Initialized
INFO - 2023-03-02 03:54:05 --> Controller Class Initialized
DEBUG - 2023-03-02 03:54:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:54:05 --> Database Driver Class Initialized
INFO - 2023-03-02 03:54:05 --> Final output sent to browser
DEBUG - 2023-03-02 03:54:05 --> Total execution time: 0.0151
INFO - 2023-03-02 03:54:06 --> Config Class Initialized
INFO - 2023-03-02 03:54:06 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:54:06 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:54:06 --> Utf8 Class Initialized
INFO - 2023-03-02 03:54:06 --> URI Class Initialized
INFO - 2023-03-02 03:54:06 --> Router Class Initialized
INFO - 2023-03-02 03:54:06 --> Output Class Initialized
INFO - 2023-03-02 03:54:06 --> Security Class Initialized
DEBUG - 2023-03-02 03:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:54:06 --> Input Class Initialized
INFO - 2023-03-02 03:54:06 --> Language Class Initialized
INFO - 2023-03-02 03:54:06 --> Loader Class Initialized
INFO - 2023-03-02 03:54:06 --> Controller Class Initialized
DEBUG - 2023-03-02 03:54:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:54:06 --> Database Driver Class Initialized
INFO - 2023-03-02 03:54:06 --> Final output sent to browser
DEBUG - 2023-03-02 03:54:06 --> Total execution time: 0.0180
INFO - 2023-03-02 03:54:07 --> Config Class Initialized
INFO - 2023-03-02 03:54:07 --> Hooks Class Initialized
DEBUG - 2023-03-02 03:54:07 --> UTF-8 Support Enabled
INFO - 2023-03-02 03:54:07 --> Utf8 Class Initialized
INFO - 2023-03-02 03:54:07 --> URI Class Initialized
INFO - 2023-03-02 03:54:07 --> Router Class Initialized
INFO - 2023-03-02 03:54:07 --> Output Class Initialized
INFO - 2023-03-02 03:54:07 --> Security Class Initialized
DEBUG - 2023-03-02 03:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 03:54:07 --> Input Class Initialized
INFO - 2023-03-02 03:54:07 --> Language Class Initialized
INFO - 2023-03-02 03:54:07 --> Loader Class Initialized
INFO - 2023-03-02 03:54:07 --> Controller Class Initialized
DEBUG - 2023-03-02 03:54:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 03:54:07 --> Database Driver Class Initialized
INFO - 2023-03-02 03:54:07 --> Final output sent to browser
DEBUG - 2023-03-02 03:54:07 --> Total execution time: 0.0178
INFO - 2023-03-02 04:00:31 --> Config Class Initialized
INFO - 2023-03-02 04:00:31 --> Hooks Class Initialized
DEBUG - 2023-03-02 04:00:31 --> UTF-8 Support Enabled
INFO - 2023-03-02 04:00:31 --> Utf8 Class Initialized
INFO - 2023-03-02 04:00:31 --> URI Class Initialized
INFO - 2023-03-02 04:00:31 --> Router Class Initialized
INFO - 2023-03-02 04:00:31 --> Output Class Initialized
INFO - 2023-03-02 04:00:31 --> Security Class Initialized
DEBUG - 2023-03-02 04:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 04:00:31 --> Input Class Initialized
INFO - 2023-03-02 04:00:31 --> Language Class Initialized
INFO - 2023-03-02 04:00:31 --> Loader Class Initialized
INFO - 2023-03-02 04:00:31 --> Controller Class Initialized
DEBUG - 2023-03-02 04:00:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 04:00:31 --> Database Driver Class Initialized
INFO - 2023-03-02 04:00:31 --> Final output sent to browser
DEBUG - 2023-03-02 04:00:31 --> Total execution time: 0.0240
INFO - 2023-03-02 04:00:31 --> Config Class Initialized
INFO - 2023-03-02 04:00:31 --> Hooks Class Initialized
DEBUG - 2023-03-02 04:00:31 --> UTF-8 Support Enabled
INFO - 2023-03-02 04:00:31 --> Utf8 Class Initialized
INFO - 2023-03-02 04:00:31 --> URI Class Initialized
INFO - 2023-03-02 04:00:31 --> Router Class Initialized
INFO - 2023-03-02 04:00:31 --> Output Class Initialized
INFO - 2023-03-02 04:00:31 --> Security Class Initialized
DEBUG - 2023-03-02 04:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 04:00:31 --> Input Class Initialized
INFO - 2023-03-02 04:00:31 --> Language Class Initialized
INFO - 2023-03-02 04:00:31 --> Loader Class Initialized
INFO - 2023-03-02 04:00:31 --> Controller Class Initialized
DEBUG - 2023-03-02 04:00:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 04:00:31 --> Database Driver Class Initialized
INFO - 2023-03-02 04:00:31 --> Final output sent to browser
DEBUG - 2023-03-02 04:00:31 --> Total execution time: 0.0144
INFO - 2023-03-02 04:13:14 --> Config Class Initialized
INFO - 2023-03-02 04:13:14 --> Hooks Class Initialized
DEBUG - 2023-03-02 04:13:14 --> UTF-8 Support Enabled
INFO - 2023-03-02 04:13:14 --> Utf8 Class Initialized
INFO - 2023-03-02 04:13:14 --> URI Class Initialized
INFO - 2023-03-02 04:13:14 --> Router Class Initialized
INFO - 2023-03-02 04:13:14 --> Output Class Initialized
INFO - 2023-03-02 04:13:14 --> Security Class Initialized
DEBUG - 2023-03-02 04:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 04:13:14 --> Input Class Initialized
INFO - 2023-03-02 04:13:14 --> Language Class Initialized
INFO - 2023-03-02 04:13:14 --> Loader Class Initialized
INFO - 2023-03-02 04:13:14 --> Controller Class Initialized
DEBUG - 2023-03-02 04:13:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 04:13:14 --> Database Driver Class Initialized
INFO - 2023-03-02 04:13:14 --> Final output sent to browser
DEBUG - 2023-03-02 04:13:14 --> Total execution time: 0.0157
INFO - 2023-03-02 04:13:14 --> Config Class Initialized
INFO - 2023-03-02 04:13:14 --> Hooks Class Initialized
DEBUG - 2023-03-02 04:13:14 --> UTF-8 Support Enabled
INFO - 2023-03-02 04:13:14 --> Utf8 Class Initialized
INFO - 2023-03-02 04:13:14 --> URI Class Initialized
INFO - 2023-03-02 04:13:14 --> Router Class Initialized
INFO - 2023-03-02 04:13:14 --> Output Class Initialized
INFO - 2023-03-02 04:13:14 --> Security Class Initialized
DEBUG - 2023-03-02 04:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 04:13:14 --> Input Class Initialized
INFO - 2023-03-02 04:13:14 --> Language Class Initialized
INFO - 2023-03-02 04:13:14 --> Loader Class Initialized
INFO - 2023-03-02 04:13:14 --> Controller Class Initialized
DEBUG - 2023-03-02 04:13:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 04:13:14 --> Database Driver Class Initialized
INFO - 2023-03-02 04:13:14 --> Final output sent to browser
DEBUG - 2023-03-02 04:13:14 --> Total execution time: 0.0186
INFO - 2023-03-02 04:13:15 --> Config Class Initialized
INFO - 2023-03-02 04:13:15 --> Hooks Class Initialized
DEBUG - 2023-03-02 04:13:15 --> UTF-8 Support Enabled
INFO - 2023-03-02 04:13:15 --> Utf8 Class Initialized
INFO - 2023-03-02 04:13:15 --> URI Class Initialized
INFO - 2023-03-02 04:13:15 --> Router Class Initialized
INFO - 2023-03-02 04:13:15 --> Output Class Initialized
INFO - 2023-03-02 04:13:15 --> Security Class Initialized
DEBUG - 2023-03-02 04:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 04:13:15 --> Input Class Initialized
INFO - 2023-03-02 04:13:15 --> Language Class Initialized
INFO - 2023-03-02 04:13:15 --> Loader Class Initialized
INFO - 2023-03-02 04:13:15 --> Controller Class Initialized
DEBUG - 2023-03-02 04:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 04:13:15 --> Database Driver Class Initialized
INFO - 2023-03-02 04:13:15 --> Final output sent to browser
DEBUG - 2023-03-02 04:13:15 --> Total execution time: 0.0169
INFO - 2023-03-02 04:15:15 --> Config Class Initialized
INFO - 2023-03-02 04:15:15 --> Hooks Class Initialized
DEBUG - 2023-03-02 04:15:15 --> UTF-8 Support Enabled
INFO - 2023-03-02 04:15:15 --> Utf8 Class Initialized
INFO - 2023-03-02 04:15:15 --> URI Class Initialized
INFO - 2023-03-02 04:15:15 --> Router Class Initialized
INFO - 2023-03-02 04:15:15 --> Output Class Initialized
INFO - 2023-03-02 04:15:15 --> Security Class Initialized
DEBUG - 2023-03-02 04:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 04:15:15 --> Input Class Initialized
INFO - 2023-03-02 04:15:15 --> Language Class Initialized
INFO - 2023-03-02 04:15:15 --> Loader Class Initialized
INFO - 2023-03-02 04:15:15 --> Controller Class Initialized
DEBUG - 2023-03-02 04:15:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 04:15:15 --> Database Driver Class Initialized
INFO - 2023-03-02 04:15:15 --> Final output sent to browser
DEBUG - 2023-03-02 04:15:15 --> Total execution time: 0.0942
INFO - 2023-03-02 04:15:15 --> Config Class Initialized
INFO - 2023-03-02 04:15:15 --> Hooks Class Initialized
DEBUG - 2023-03-02 04:15:15 --> UTF-8 Support Enabled
INFO - 2023-03-02 04:15:15 --> Utf8 Class Initialized
INFO - 2023-03-02 04:15:15 --> URI Class Initialized
INFO - 2023-03-02 04:15:15 --> Router Class Initialized
INFO - 2023-03-02 04:15:15 --> Output Class Initialized
INFO - 2023-03-02 04:15:15 --> Security Class Initialized
DEBUG - 2023-03-02 04:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 04:15:15 --> Input Class Initialized
INFO - 2023-03-02 04:15:15 --> Language Class Initialized
INFO - 2023-03-02 04:15:15 --> Loader Class Initialized
INFO - 2023-03-02 04:15:15 --> Controller Class Initialized
DEBUG - 2023-03-02 04:15:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 04:15:15 --> Database Driver Class Initialized
INFO - 2023-03-02 04:15:15 --> Final output sent to browser
DEBUG - 2023-03-02 04:15:15 --> Total execution time: 0.0561
INFO - 2023-03-02 04:15:31 --> Config Class Initialized
INFO - 2023-03-02 04:15:31 --> Hooks Class Initialized
DEBUG - 2023-03-02 04:15:31 --> UTF-8 Support Enabled
INFO - 2023-03-02 04:15:31 --> Utf8 Class Initialized
INFO - 2023-03-02 04:15:31 --> URI Class Initialized
INFO - 2023-03-02 04:15:31 --> Router Class Initialized
INFO - 2023-03-02 04:15:31 --> Output Class Initialized
INFO - 2023-03-02 04:15:31 --> Security Class Initialized
DEBUG - 2023-03-02 04:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 04:15:31 --> Input Class Initialized
INFO - 2023-03-02 04:15:31 --> Language Class Initialized
INFO - 2023-03-02 04:15:31 --> Loader Class Initialized
INFO - 2023-03-02 04:15:31 --> Controller Class Initialized
DEBUG - 2023-03-02 04:15:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 04:15:31 --> Database Driver Class Initialized
INFO - 2023-03-02 04:15:31 --> Final output sent to browser
DEBUG - 2023-03-02 04:15:31 --> Total execution time: 0.0165
INFO - 2023-03-02 04:15:31 --> Config Class Initialized
INFO - 2023-03-02 04:15:31 --> Hooks Class Initialized
DEBUG - 2023-03-02 04:15:31 --> UTF-8 Support Enabled
INFO - 2023-03-02 04:15:31 --> Utf8 Class Initialized
INFO - 2023-03-02 04:15:31 --> URI Class Initialized
INFO - 2023-03-02 04:15:31 --> Router Class Initialized
INFO - 2023-03-02 04:15:31 --> Output Class Initialized
INFO - 2023-03-02 04:15:31 --> Security Class Initialized
DEBUG - 2023-03-02 04:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 04:15:31 --> Input Class Initialized
INFO - 2023-03-02 04:15:31 --> Language Class Initialized
INFO - 2023-03-02 04:15:31 --> Loader Class Initialized
INFO - 2023-03-02 04:15:31 --> Controller Class Initialized
DEBUG - 2023-03-02 04:15:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 04:15:31 --> Database Driver Class Initialized
INFO - 2023-03-02 04:15:31 --> Final output sent to browser
DEBUG - 2023-03-02 04:15:31 --> Total execution time: 0.0177
INFO - 2023-03-02 04:15:45 --> Config Class Initialized
INFO - 2023-03-02 04:15:45 --> Hooks Class Initialized
DEBUG - 2023-03-02 04:15:45 --> UTF-8 Support Enabled
INFO - 2023-03-02 04:15:45 --> Utf8 Class Initialized
INFO - 2023-03-02 04:15:45 --> URI Class Initialized
INFO - 2023-03-02 04:15:45 --> Router Class Initialized
INFO - 2023-03-02 04:15:45 --> Output Class Initialized
INFO - 2023-03-02 04:15:45 --> Security Class Initialized
DEBUG - 2023-03-02 04:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 04:15:45 --> Input Class Initialized
INFO - 2023-03-02 04:15:45 --> Language Class Initialized
INFO - 2023-03-02 04:15:45 --> Loader Class Initialized
INFO - 2023-03-02 04:15:45 --> Controller Class Initialized
DEBUG - 2023-03-02 04:15:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 04:15:45 --> Database Driver Class Initialized
INFO - 2023-03-02 04:15:45 --> Final output sent to browser
DEBUG - 2023-03-02 04:15:45 --> Total execution time: 0.0529
INFO - 2023-03-02 04:15:45 --> Config Class Initialized
INFO - 2023-03-02 04:15:45 --> Hooks Class Initialized
DEBUG - 2023-03-02 04:15:45 --> UTF-8 Support Enabled
INFO - 2023-03-02 04:15:45 --> Utf8 Class Initialized
INFO - 2023-03-02 04:15:45 --> URI Class Initialized
INFO - 2023-03-02 04:15:45 --> Router Class Initialized
INFO - 2023-03-02 04:15:45 --> Output Class Initialized
INFO - 2023-03-02 04:15:45 --> Security Class Initialized
DEBUG - 2023-03-02 04:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 04:15:45 --> Input Class Initialized
INFO - 2023-03-02 04:15:45 --> Language Class Initialized
INFO - 2023-03-02 04:15:45 --> Loader Class Initialized
INFO - 2023-03-02 04:15:45 --> Controller Class Initialized
DEBUG - 2023-03-02 04:15:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 04:15:45 --> Database Driver Class Initialized
INFO - 2023-03-02 04:15:46 --> Final output sent to browser
DEBUG - 2023-03-02 04:15:46 --> Total execution time: 0.4363
INFO - 2023-03-02 05:45:07 --> Config Class Initialized
INFO - 2023-03-02 05:45:07 --> Hooks Class Initialized
DEBUG - 2023-03-02 05:45:07 --> UTF-8 Support Enabled
INFO - 2023-03-02 05:45:07 --> Utf8 Class Initialized
INFO - 2023-03-02 05:45:07 --> URI Class Initialized
INFO - 2023-03-02 05:45:07 --> Router Class Initialized
INFO - 2023-03-02 05:45:07 --> Output Class Initialized
INFO - 2023-03-02 05:45:07 --> Security Class Initialized
DEBUG - 2023-03-02 05:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 05:45:07 --> Input Class Initialized
INFO - 2023-03-02 05:45:07 --> Language Class Initialized
INFO - 2023-03-02 05:45:07 --> Loader Class Initialized
INFO - 2023-03-02 05:45:07 --> Controller Class Initialized
DEBUG - 2023-03-02 05:45:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 05:45:07 --> Database Driver Class Initialized
INFO - 2023-03-02 05:45:07 --> Final output sent to browser
DEBUG - 2023-03-02 05:45:07 --> Total execution time: 0.0163
INFO - 2023-03-02 05:45:07 --> Config Class Initialized
INFO - 2023-03-02 05:45:07 --> Hooks Class Initialized
DEBUG - 2023-03-02 05:45:07 --> UTF-8 Support Enabled
INFO - 2023-03-02 05:45:07 --> Utf8 Class Initialized
INFO - 2023-03-02 05:45:07 --> URI Class Initialized
INFO - 2023-03-02 05:45:07 --> Router Class Initialized
INFO - 2023-03-02 05:45:07 --> Output Class Initialized
INFO - 2023-03-02 05:45:07 --> Security Class Initialized
DEBUG - 2023-03-02 05:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 05:45:07 --> Input Class Initialized
INFO - 2023-03-02 05:45:07 --> Language Class Initialized
INFO - 2023-03-02 05:45:07 --> Loader Class Initialized
INFO - 2023-03-02 05:45:07 --> Controller Class Initialized
DEBUG - 2023-03-02 05:45:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 05:45:07 --> Database Driver Class Initialized
INFO - 2023-03-02 05:45:08 --> Final output sent to browser
DEBUG - 2023-03-02 05:45:08 --> Total execution time: 0.0215
INFO - 2023-03-02 05:45:27 --> Config Class Initialized
INFO - 2023-03-02 05:45:27 --> Hooks Class Initialized
DEBUG - 2023-03-02 05:45:27 --> UTF-8 Support Enabled
INFO - 2023-03-02 05:45:27 --> Utf8 Class Initialized
INFO - 2023-03-02 05:45:27 --> URI Class Initialized
INFO - 2023-03-02 05:45:27 --> Router Class Initialized
INFO - 2023-03-02 05:45:27 --> Output Class Initialized
INFO - 2023-03-02 05:45:27 --> Security Class Initialized
DEBUG - 2023-03-02 05:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 05:45:27 --> Input Class Initialized
INFO - 2023-03-02 05:45:27 --> Language Class Initialized
INFO - 2023-03-02 05:45:27 --> Loader Class Initialized
INFO - 2023-03-02 05:45:27 --> Controller Class Initialized
DEBUG - 2023-03-02 05:45:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 05:45:27 --> Database Driver Class Initialized
INFO - 2023-03-02 05:45:27 --> Final output sent to browser
DEBUG - 2023-03-02 05:45:27 --> Total execution time: 0.1669
INFO - 2023-03-02 05:45:27 --> Config Class Initialized
INFO - 2023-03-02 05:45:27 --> Hooks Class Initialized
DEBUG - 2023-03-02 05:45:27 --> UTF-8 Support Enabled
INFO - 2023-03-02 05:45:27 --> Utf8 Class Initialized
INFO - 2023-03-02 05:45:27 --> URI Class Initialized
INFO - 2023-03-02 05:45:27 --> Router Class Initialized
INFO - 2023-03-02 05:45:27 --> Output Class Initialized
INFO - 2023-03-02 05:45:27 --> Security Class Initialized
DEBUG - 2023-03-02 05:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 05:45:27 --> Input Class Initialized
INFO - 2023-03-02 05:45:27 --> Language Class Initialized
INFO - 2023-03-02 05:45:27 --> Loader Class Initialized
INFO - 2023-03-02 05:45:27 --> Controller Class Initialized
DEBUG - 2023-03-02 05:45:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 05:45:27 --> Database Driver Class Initialized
INFO - 2023-03-02 05:45:27 --> Final output sent to browser
DEBUG - 2023-03-02 05:45:27 --> Total execution time: 0.0179
INFO - 2023-03-02 05:46:47 --> Config Class Initialized
INFO - 2023-03-02 05:46:47 --> Hooks Class Initialized
DEBUG - 2023-03-02 05:46:47 --> UTF-8 Support Enabled
INFO - 2023-03-02 05:46:47 --> Utf8 Class Initialized
INFO - 2023-03-02 05:46:47 --> URI Class Initialized
INFO - 2023-03-02 05:46:47 --> Router Class Initialized
INFO - 2023-03-02 05:46:47 --> Output Class Initialized
INFO - 2023-03-02 05:46:47 --> Security Class Initialized
DEBUG - 2023-03-02 05:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 05:46:47 --> Input Class Initialized
INFO - 2023-03-02 05:46:47 --> Language Class Initialized
INFO - 2023-03-02 05:46:47 --> Loader Class Initialized
INFO - 2023-03-02 05:46:47 --> Controller Class Initialized
DEBUG - 2023-03-02 05:46:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 05:46:47 --> Database Driver Class Initialized
INFO - 2023-03-02 05:46:47 --> Final output sent to browser
DEBUG - 2023-03-02 05:46:47 --> Total execution time: 0.0129
INFO - 2023-03-02 05:46:47 --> Config Class Initialized
INFO - 2023-03-02 05:46:47 --> Hooks Class Initialized
DEBUG - 2023-03-02 05:46:47 --> UTF-8 Support Enabled
INFO - 2023-03-02 05:46:47 --> Utf8 Class Initialized
INFO - 2023-03-02 05:46:47 --> URI Class Initialized
INFO - 2023-03-02 05:46:47 --> Router Class Initialized
INFO - 2023-03-02 05:46:47 --> Output Class Initialized
INFO - 2023-03-02 05:46:47 --> Security Class Initialized
DEBUG - 2023-03-02 05:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 05:46:47 --> Input Class Initialized
INFO - 2023-03-02 05:46:47 --> Language Class Initialized
INFO - 2023-03-02 05:46:47 --> Loader Class Initialized
INFO - 2023-03-02 05:46:47 --> Controller Class Initialized
DEBUG - 2023-03-02 05:46:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 05:46:47 --> Database Driver Class Initialized
INFO - 2023-03-02 05:46:47 --> Final output sent to browser
DEBUG - 2023-03-02 05:46:47 --> Total execution time: 0.0616
INFO - 2023-03-02 05:47:13 --> Config Class Initialized
INFO - 2023-03-02 05:47:13 --> Hooks Class Initialized
DEBUG - 2023-03-02 05:47:13 --> UTF-8 Support Enabled
INFO - 2023-03-02 05:47:13 --> Utf8 Class Initialized
INFO - 2023-03-02 05:47:13 --> URI Class Initialized
INFO - 2023-03-02 05:47:13 --> Router Class Initialized
INFO - 2023-03-02 05:47:13 --> Output Class Initialized
INFO - 2023-03-02 05:47:13 --> Security Class Initialized
DEBUG - 2023-03-02 05:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 05:47:13 --> Input Class Initialized
INFO - 2023-03-02 05:47:13 --> Language Class Initialized
INFO - 2023-03-02 05:47:13 --> Loader Class Initialized
INFO - 2023-03-02 05:47:13 --> Controller Class Initialized
DEBUG - 2023-03-02 05:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 05:47:13 --> Database Driver Class Initialized
INFO - 2023-03-02 05:47:13 --> Final output sent to browser
DEBUG - 2023-03-02 05:47:13 --> Total execution time: 0.0108
INFO - 2023-03-02 05:47:13 --> Config Class Initialized
INFO - 2023-03-02 05:47:13 --> Hooks Class Initialized
DEBUG - 2023-03-02 05:47:13 --> UTF-8 Support Enabled
INFO - 2023-03-02 05:47:13 --> Utf8 Class Initialized
INFO - 2023-03-02 05:47:13 --> URI Class Initialized
INFO - 2023-03-02 05:47:13 --> Router Class Initialized
INFO - 2023-03-02 05:47:13 --> Output Class Initialized
INFO - 2023-03-02 05:47:13 --> Security Class Initialized
DEBUG - 2023-03-02 05:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 05:47:13 --> Input Class Initialized
INFO - 2023-03-02 05:47:13 --> Language Class Initialized
INFO - 2023-03-02 05:47:13 --> Loader Class Initialized
INFO - 2023-03-02 05:47:13 --> Controller Class Initialized
DEBUG - 2023-03-02 05:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 05:47:13 --> Database Driver Class Initialized
INFO - 2023-03-02 05:47:13 --> Final output sent to browser
DEBUG - 2023-03-02 05:47:13 --> Total execution time: 0.0161
INFO - 2023-03-02 05:47:34 --> Config Class Initialized
INFO - 2023-03-02 05:47:34 --> Hooks Class Initialized
DEBUG - 2023-03-02 05:47:34 --> UTF-8 Support Enabled
INFO - 2023-03-02 05:47:34 --> Utf8 Class Initialized
INFO - 2023-03-02 05:47:34 --> URI Class Initialized
INFO - 2023-03-02 05:47:34 --> Router Class Initialized
INFO - 2023-03-02 05:47:34 --> Output Class Initialized
INFO - 2023-03-02 05:47:34 --> Security Class Initialized
DEBUG - 2023-03-02 05:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 05:47:34 --> Input Class Initialized
INFO - 2023-03-02 05:47:34 --> Language Class Initialized
INFO - 2023-03-02 05:47:34 --> Loader Class Initialized
INFO - 2023-03-02 05:47:34 --> Controller Class Initialized
DEBUG - 2023-03-02 05:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 05:47:34 --> Database Driver Class Initialized
INFO - 2023-03-02 05:47:34 --> Final output sent to browser
DEBUG - 2023-03-02 05:47:34 --> Total execution time: 0.0114
INFO - 2023-03-02 05:47:34 --> Config Class Initialized
INFO - 2023-03-02 05:47:34 --> Hooks Class Initialized
DEBUG - 2023-03-02 05:47:34 --> UTF-8 Support Enabled
INFO - 2023-03-02 05:47:34 --> Utf8 Class Initialized
INFO - 2023-03-02 05:47:34 --> URI Class Initialized
INFO - 2023-03-02 05:47:34 --> Router Class Initialized
INFO - 2023-03-02 05:47:34 --> Output Class Initialized
INFO - 2023-03-02 05:47:34 --> Security Class Initialized
DEBUG - 2023-03-02 05:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 05:47:34 --> Input Class Initialized
INFO - 2023-03-02 05:47:34 --> Language Class Initialized
INFO - 2023-03-02 05:47:34 --> Loader Class Initialized
INFO - 2023-03-02 05:47:34 --> Controller Class Initialized
DEBUG - 2023-03-02 05:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 05:47:34 --> Database Driver Class Initialized
INFO - 2023-03-02 05:47:34 --> Final output sent to browser
DEBUG - 2023-03-02 05:47:34 --> Total execution time: 0.0243
INFO - 2023-03-02 05:47:42 --> Config Class Initialized
INFO - 2023-03-02 05:47:42 --> Hooks Class Initialized
DEBUG - 2023-03-02 05:47:42 --> UTF-8 Support Enabled
INFO - 2023-03-02 05:47:42 --> Utf8 Class Initialized
INFO - 2023-03-02 05:47:42 --> URI Class Initialized
INFO - 2023-03-02 05:47:42 --> Router Class Initialized
INFO - 2023-03-02 05:47:42 --> Output Class Initialized
INFO - 2023-03-02 05:47:42 --> Security Class Initialized
DEBUG - 2023-03-02 05:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 05:47:42 --> Input Class Initialized
INFO - 2023-03-02 05:47:42 --> Language Class Initialized
INFO - 2023-03-02 05:47:42 --> Loader Class Initialized
INFO - 2023-03-02 05:47:42 --> Controller Class Initialized
DEBUG - 2023-03-02 05:47:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 05:47:42 --> Database Driver Class Initialized
INFO - 2023-03-02 05:47:42 --> Final output sent to browser
DEBUG - 2023-03-02 05:47:42 --> Total execution time: 0.0150
INFO - 2023-03-02 05:47:42 --> Config Class Initialized
INFO - 2023-03-02 05:47:42 --> Hooks Class Initialized
DEBUG - 2023-03-02 05:47:42 --> UTF-8 Support Enabled
INFO - 2023-03-02 05:47:42 --> Utf8 Class Initialized
INFO - 2023-03-02 05:47:42 --> URI Class Initialized
INFO - 2023-03-02 05:47:42 --> Router Class Initialized
INFO - 2023-03-02 05:47:42 --> Output Class Initialized
INFO - 2023-03-02 05:47:42 --> Security Class Initialized
DEBUG - 2023-03-02 05:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 05:47:42 --> Input Class Initialized
INFO - 2023-03-02 05:47:42 --> Language Class Initialized
INFO - 2023-03-02 05:47:42 --> Loader Class Initialized
INFO - 2023-03-02 05:47:42 --> Controller Class Initialized
DEBUG - 2023-03-02 05:47:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 05:47:42 --> Database Driver Class Initialized
INFO - 2023-03-02 05:47:42 --> Final output sent to browser
DEBUG - 2023-03-02 05:47:42 --> Total execution time: 0.0226
INFO - 2023-03-02 06:35:05 --> Config Class Initialized
INFO - 2023-03-02 06:35:05 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:35:05 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:35:05 --> Utf8 Class Initialized
INFO - 2023-03-02 06:35:05 --> URI Class Initialized
INFO - 2023-03-02 06:35:05 --> Router Class Initialized
INFO - 2023-03-02 06:35:05 --> Output Class Initialized
INFO - 2023-03-02 06:35:05 --> Security Class Initialized
DEBUG - 2023-03-02 06:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:35:05 --> Input Class Initialized
INFO - 2023-03-02 06:35:05 --> Language Class Initialized
INFO - 2023-03-02 06:35:05 --> Loader Class Initialized
INFO - 2023-03-02 06:35:05 --> Controller Class Initialized
DEBUG - 2023-03-02 06:35:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:35:05 --> Database Driver Class Initialized
INFO - 2023-03-02 06:35:05 --> Final output sent to browser
DEBUG - 2023-03-02 06:35:05 --> Total execution time: 0.0167
INFO - 2023-03-02 06:35:05 --> Config Class Initialized
INFO - 2023-03-02 06:35:05 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:35:05 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:35:05 --> Utf8 Class Initialized
INFO - 2023-03-02 06:35:05 --> URI Class Initialized
INFO - 2023-03-02 06:35:05 --> Router Class Initialized
INFO - 2023-03-02 06:35:05 --> Output Class Initialized
INFO - 2023-03-02 06:35:05 --> Security Class Initialized
DEBUG - 2023-03-02 06:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:35:05 --> Input Class Initialized
INFO - 2023-03-02 06:35:05 --> Language Class Initialized
INFO - 2023-03-02 06:35:05 --> Loader Class Initialized
INFO - 2023-03-02 06:35:05 --> Controller Class Initialized
DEBUG - 2023-03-02 06:35:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:35:05 --> Database Driver Class Initialized
INFO - 2023-03-02 06:35:07 --> Final output sent to browser
DEBUG - 2023-03-02 06:35:07 --> Total execution time: 1.5726
INFO - 2023-03-02 06:36:24 --> Config Class Initialized
INFO - 2023-03-02 06:36:24 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:36:24 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:36:24 --> Utf8 Class Initialized
INFO - 2023-03-02 06:36:24 --> URI Class Initialized
INFO - 2023-03-02 06:36:24 --> Router Class Initialized
INFO - 2023-03-02 06:36:24 --> Output Class Initialized
INFO - 2023-03-02 06:36:24 --> Security Class Initialized
DEBUG - 2023-03-02 06:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:36:24 --> Input Class Initialized
INFO - 2023-03-02 06:36:24 --> Language Class Initialized
INFO - 2023-03-02 06:36:24 --> Loader Class Initialized
INFO - 2023-03-02 06:36:24 --> Controller Class Initialized
DEBUG - 2023-03-02 06:36:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:36:24 --> Database Driver Class Initialized
INFO - 2023-03-02 06:36:24 --> Final output sent to browser
DEBUG - 2023-03-02 06:36:24 --> Total execution time: 0.0145
INFO - 2023-03-02 06:36:24 --> Config Class Initialized
INFO - 2023-03-02 06:36:24 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:36:24 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:36:24 --> Utf8 Class Initialized
INFO - 2023-03-02 06:36:24 --> URI Class Initialized
INFO - 2023-03-02 06:36:24 --> Router Class Initialized
INFO - 2023-03-02 06:36:24 --> Output Class Initialized
INFO - 2023-03-02 06:36:24 --> Security Class Initialized
DEBUG - 2023-03-02 06:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:36:24 --> Input Class Initialized
INFO - 2023-03-02 06:36:24 --> Language Class Initialized
INFO - 2023-03-02 06:36:24 --> Loader Class Initialized
INFO - 2023-03-02 06:36:24 --> Controller Class Initialized
DEBUG - 2023-03-02 06:36:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:36:24 --> Database Driver Class Initialized
INFO - 2023-03-02 06:36:24 --> Final output sent to browser
DEBUG - 2023-03-02 06:36:24 --> Total execution time: 0.0259
INFO - 2023-03-02 06:37:25 --> Config Class Initialized
INFO - 2023-03-02 06:37:25 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:37:25 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:37:25 --> Utf8 Class Initialized
INFO - 2023-03-02 06:37:25 --> URI Class Initialized
INFO - 2023-03-02 06:37:25 --> Router Class Initialized
INFO - 2023-03-02 06:37:25 --> Output Class Initialized
INFO - 2023-03-02 06:37:25 --> Security Class Initialized
DEBUG - 2023-03-02 06:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:37:25 --> Input Class Initialized
INFO - 2023-03-02 06:37:25 --> Language Class Initialized
INFO - 2023-03-02 06:37:25 --> Loader Class Initialized
INFO - 2023-03-02 06:37:25 --> Controller Class Initialized
DEBUG - 2023-03-02 06:37:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:37:25 --> Database Driver Class Initialized
INFO - 2023-03-02 06:37:25 --> Final output sent to browser
DEBUG - 2023-03-02 06:37:25 --> Total execution time: 0.0185
INFO - 2023-03-02 06:37:25 --> Config Class Initialized
INFO - 2023-03-02 06:37:25 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:37:25 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:37:25 --> Utf8 Class Initialized
INFO - 2023-03-02 06:37:25 --> URI Class Initialized
INFO - 2023-03-02 06:37:25 --> Router Class Initialized
INFO - 2023-03-02 06:37:25 --> Output Class Initialized
INFO - 2023-03-02 06:37:25 --> Security Class Initialized
DEBUG - 2023-03-02 06:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:37:25 --> Input Class Initialized
INFO - 2023-03-02 06:37:25 --> Language Class Initialized
INFO - 2023-03-02 06:37:25 --> Loader Class Initialized
INFO - 2023-03-02 06:37:25 --> Controller Class Initialized
DEBUG - 2023-03-02 06:37:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:37:25 --> Database Driver Class Initialized
INFO - 2023-03-02 06:37:26 --> Final output sent to browser
DEBUG - 2023-03-02 06:37:26 --> Total execution time: 0.0293
INFO - 2023-03-02 06:37:27 --> Config Class Initialized
INFO - 2023-03-02 06:37:27 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:37:27 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:37:27 --> Utf8 Class Initialized
INFO - 2023-03-02 06:37:27 --> URI Class Initialized
INFO - 2023-03-02 06:37:27 --> Router Class Initialized
INFO - 2023-03-02 06:37:27 --> Output Class Initialized
INFO - 2023-03-02 06:37:27 --> Security Class Initialized
DEBUG - 2023-03-02 06:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:37:27 --> Input Class Initialized
INFO - 2023-03-02 06:37:27 --> Language Class Initialized
INFO - 2023-03-02 06:37:27 --> Loader Class Initialized
INFO - 2023-03-02 06:37:27 --> Controller Class Initialized
DEBUG - 2023-03-02 06:37:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:37:27 --> Database Driver Class Initialized
INFO - 2023-03-02 06:37:27 --> Final output sent to browser
DEBUG - 2023-03-02 06:37:27 --> Total execution time: 0.0252
INFO - 2023-03-02 06:39:30 --> Config Class Initialized
INFO - 2023-03-02 06:39:30 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:39:30 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:39:30 --> Utf8 Class Initialized
INFO - 2023-03-02 06:39:30 --> URI Class Initialized
INFO - 2023-03-02 06:39:30 --> Router Class Initialized
INFO - 2023-03-02 06:39:30 --> Output Class Initialized
INFO - 2023-03-02 06:39:30 --> Security Class Initialized
DEBUG - 2023-03-02 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:39:30 --> Input Class Initialized
INFO - 2023-03-02 06:39:30 --> Language Class Initialized
INFO - 2023-03-02 06:39:30 --> Loader Class Initialized
INFO - 2023-03-02 06:39:30 --> Controller Class Initialized
DEBUG - 2023-03-02 06:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:39:30 --> Database Driver Class Initialized
INFO - 2023-03-02 06:39:30 --> Final output sent to browser
DEBUG - 2023-03-02 06:39:30 --> Total execution time: 0.0751
INFO - 2023-03-02 06:39:30 --> Config Class Initialized
INFO - 2023-03-02 06:39:30 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:39:30 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:39:30 --> Utf8 Class Initialized
INFO - 2023-03-02 06:39:30 --> URI Class Initialized
INFO - 2023-03-02 06:39:30 --> Router Class Initialized
INFO - 2023-03-02 06:39:30 --> Output Class Initialized
INFO - 2023-03-02 06:39:30 --> Security Class Initialized
DEBUG - 2023-03-02 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:39:30 --> Input Class Initialized
INFO - 2023-03-02 06:39:30 --> Language Class Initialized
INFO - 2023-03-02 06:39:30 --> Loader Class Initialized
INFO - 2023-03-02 06:39:30 --> Controller Class Initialized
DEBUG - 2023-03-02 06:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:39:30 --> Database Driver Class Initialized
INFO - 2023-03-02 06:39:31 --> Final output sent to browser
DEBUG - 2023-03-02 06:39:31 --> Total execution time: 0.2385
INFO - 2023-03-02 06:39:33 --> Config Class Initialized
INFO - 2023-03-02 06:39:33 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:39:33 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:39:33 --> Utf8 Class Initialized
INFO - 2023-03-02 06:39:33 --> URI Class Initialized
INFO - 2023-03-02 06:39:33 --> Router Class Initialized
INFO - 2023-03-02 06:39:33 --> Output Class Initialized
INFO - 2023-03-02 06:39:33 --> Security Class Initialized
DEBUG - 2023-03-02 06:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:39:33 --> Input Class Initialized
INFO - 2023-03-02 06:39:33 --> Language Class Initialized
INFO - 2023-03-02 06:39:33 --> Loader Class Initialized
INFO - 2023-03-02 06:39:33 --> Controller Class Initialized
DEBUG - 2023-03-02 06:39:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:39:33 --> Database Driver Class Initialized
INFO - 2023-03-02 06:39:33 --> Final output sent to browser
DEBUG - 2023-03-02 06:39:33 --> Total execution time: 0.2451
INFO - 2023-03-02 06:39:33 --> Config Class Initialized
INFO - 2023-03-02 06:39:33 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:39:33 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:39:33 --> Utf8 Class Initialized
INFO - 2023-03-02 06:39:33 --> URI Class Initialized
INFO - 2023-03-02 06:39:33 --> Router Class Initialized
INFO - 2023-03-02 06:39:33 --> Output Class Initialized
INFO - 2023-03-02 06:39:33 --> Security Class Initialized
DEBUG - 2023-03-02 06:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:39:33 --> Input Class Initialized
INFO - 2023-03-02 06:39:33 --> Language Class Initialized
INFO - 2023-03-02 06:39:33 --> Loader Class Initialized
INFO - 2023-03-02 06:39:33 --> Controller Class Initialized
DEBUG - 2023-03-02 06:39:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:39:33 --> Database Driver Class Initialized
INFO - 2023-03-02 06:39:33 --> Final output sent to browser
DEBUG - 2023-03-02 06:39:33 --> Total execution time: 0.2484
INFO - 2023-03-02 06:39:34 --> Config Class Initialized
INFO - 2023-03-02 06:39:34 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:39:34 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:39:34 --> Utf8 Class Initialized
INFO - 2023-03-02 06:39:34 --> URI Class Initialized
INFO - 2023-03-02 06:39:34 --> Router Class Initialized
INFO - 2023-03-02 06:39:34 --> Output Class Initialized
INFO - 2023-03-02 06:39:34 --> Security Class Initialized
DEBUG - 2023-03-02 06:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:39:34 --> Input Class Initialized
INFO - 2023-03-02 06:39:34 --> Language Class Initialized
INFO - 2023-03-02 06:39:34 --> Loader Class Initialized
INFO - 2023-03-02 06:39:34 --> Controller Class Initialized
DEBUG - 2023-03-02 06:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:39:34 --> Database Driver Class Initialized
INFO - 2023-03-02 06:39:34 --> Config Class Initialized
INFO - 2023-03-02 06:39:34 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:39:34 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:39:34 --> Utf8 Class Initialized
INFO - 2023-03-02 06:39:34 --> URI Class Initialized
INFO - 2023-03-02 06:39:34 --> Router Class Initialized
INFO - 2023-03-02 06:39:34 --> Output Class Initialized
INFO - 2023-03-02 06:39:34 --> Security Class Initialized
DEBUG - 2023-03-02 06:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:39:34 --> Input Class Initialized
INFO - 2023-03-02 06:39:34 --> Language Class Initialized
INFO - 2023-03-02 06:39:34 --> Loader Class Initialized
INFO - 2023-03-02 06:39:34 --> Controller Class Initialized
DEBUG - 2023-03-02 06:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:39:34 --> Database Driver Class Initialized
INFO - 2023-03-02 06:39:34 --> Final output sent to browser
DEBUG - 2023-03-02 06:39:34 --> Total execution time: 0.2517
INFO - 2023-03-02 06:39:34 --> Config Class Initialized
INFO - 2023-03-02 06:39:34 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:39:34 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:39:34 --> Utf8 Class Initialized
INFO - 2023-03-02 06:39:34 --> URI Class Initialized
INFO - 2023-03-02 06:39:34 --> Router Class Initialized
INFO - 2023-03-02 06:39:34 --> Output Class Initialized
INFO - 2023-03-02 06:39:34 --> Security Class Initialized
DEBUG - 2023-03-02 06:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:39:34 --> Input Class Initialized
INFO - 2023-03-02 06:39:34 --> Language Class Initialized
INFO - 2023-03-02 06:39:34 --> Loader Class Initialized
INFO - 2023-03-02 06:39:34 --> Controller Class Initialized
DEBUG - 2023-03-02 06:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:39:34 --> Database Driver Class Initialized
INFO - 2023-03-02 06:39:34 --> Final output sent to browser
DEBUG - 2023-03-02 06:39:34 --> Total execution time: 0.2435
INFO - 2023-03-02 06:39:35 --> Config Class Initialized
INFO - 2023-03-02 06:39:35 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:39:35 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:39:35 --> Utf8 Class Initialized
INFO - 2023-03-02 06:39:35 --> URI Class Initialized
INFO - 2023-03-02 06:39:35 --> Router Class Initialized
INFO - 2023-03-02 06:39:35 --> Output Class Initialized
INFO - 2023-03-02 06:39:35 --> Security Class Initialized
DEBUG - 2023-03-02 06:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:39:35 --> Input Class Initialized
INFO - 2023-03-02 06:39:35 --> Language Class Initialized
INFO - 2023-03-02 06:39:35 --> Loader Class Initialized
INFO - 2023-03-02 06:39:35 --> Controller Class Initialized
DEBUG - 2023-03-02 06:39:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:39:35 --> Database Driver Class Initialized
INFO - 2023-03-02 06:39:35 --> Final output sent to browser
DEBUG - 2023-03-02 06:39:35 --> Total execution time: 0.2398
INFO - 2023-03-02 06:39:35 --> Config Class Initialized
INFO - 2023-03-02 06:39:35 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:39:35 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:39:35 --> Utf8 Class Initialized
INFO - 2023-03-02 06:39:35 --> URI Class Initialized
INFO - 2023-03-02 06:39:35 --> Router Class Initialized
INFO - 2023-03-02 06:39:35 --> Output Class Initialized
INFO - 2023-03-02 06:39:35 --> Security Class Initialized
DEBUG - 2023-03-02 06:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:39:35 --> Input Class Initialized
INFO - 2023-03-02 06:39:35 --> Language Class Initialized
INFO - 2023-03-02 06:39:35 --> Loader Class Initialized
INFO - 2023-03-02 06:39:35 --> Controller Class Initialized
DEBUG - 2023-03-02 06:39:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:39:35 --> Database Driver Class Initialized
INFO - 2023-03-02 06:39:35 --> Final output sent to browser
DEBUG - 2023-03-02 06:39:35 --> Total execution time: 0.2429
INFO - 2023-03-02 06:39:35 --> Final output sent to browser
DEBUG - 2023-03-02 06:39:35 --> Total execution time: 0.2827
INFO - 2023-03-02 06:39:53 --> Config Class Initialized
INFO - 2023-03-02 06:39:53 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:39:53 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:39:53 --> Utf8 Class Initialized
INFO - 2023-03-02 06:39:53 --> URI Class Initialized
INFO - 2023-03-02 06:39:53 --> Router Class Initialized
INFO - 2023-03-02 06:39:53 --> Output Class Initialized
INFO - 2023-03-02 06:39:53 --> Security Class Initialized
DEBUG - 2023-03-02 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:39:53 --> Input Class Initialized
INFO - 2023-03-02 06:39:53 --> Language Class Initialized
INFO - 2023-03-02 06:39:53 --> Loader Class Initialized
INFO - 2023-03-02 06:39:53 --> Controller Class Initialized
DEBUG - 2023-03-02 06:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:39:53 --> Database Driver Class Initialized
INFO - 2023-03-02 06:39:53 --> Final output sent to browser
DEBUG - 2023-03-02 06:39:53 --> Total execution time: 0.0646
INFO - 2023-03-02 06:39:53 --> Config Class Initialized
INFO - 2023-03-02 06:39:53 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:39:53 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:39:53 --> Utf8 Class Initialized
INFO - 2023-03-02 06:39:53 --> URI Class Initialized
INFO - 2023-03-02 06:39:53 --> Router Class Initialized
INFO - 2023-03-02 06:39:53 --> Output Class Initialized
INFO - 2023-03-02 06:39:53 --> Security Class Initialized
DEBUG - 2023-03-02 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:39:53 --> Input Class Initialized
INFO - 2023-03-02 06:39:53 --> Language Class Initialized
INFO - 2023-03-02 06:39:53 --> Loader Class Initialized
INFO - 2023-03-02 06:39:53 --> Controller Class Initialized
DEBUG - 2023-03-02 06:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:39:53 --> Database Driver Class Initialized
INFO - 2023-03-02 06:39:54 --> Final output sent to browser
DEBUG - 2023-03-02 06:39:54 --> Total execution time: 1.1217
INFO - 2023-03-02 06:39:57 --> Config Class Initialized
INFO - 2023-03-02 06:39:57 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:39:57 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:39:57 --> Utf8 Class Initialized
INFO - 2023-03-02 06:39:57 --> URI Class Initialized
INFO - 2023-03-02 06:39:57 --> Router Class Initialized
INFO - 2023-03-02 06:39:57 --> Output Class Initialized
INFO - 2023-03-02 06:39:57 --> Security Class Initialized
DEBUG - 2023-03-02 06:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:39:57 --> Input Class Initialized
INFO - 2023-03-02 06:39:57 --> Language Class Initialized
INFO - 2023-03-02 06:39:57 --> Loader Class Initialized
INFO - 2023-03-02 06:39:57 --> Controller Class Initialized
DEBUG - 2023-03-02 06:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:39:57 --> Database Driver Class Initialized
INFO - 2023-03-02 06:39:57 --> Final output sent to browser
DEBUG - 2023-03-02 06:39:57 --> Total execution time: 0.1289
INFO - 2023-03-02 06:40:13 --> Config Class Initialized
INFO - 2023-03-02 06:40:13 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:40:13 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:40:13 --> Utf8 Class Initialized
INFO - 2023-03-02 06:40:13 --> URI Class Initialized
INFO - 2023-03-02 06:40:13 --> Router Class Initialized
INFO - 2023-03-02 06:40:13 --> Output Class Initialized
INFO - 2023-03-02 06:40:13 --> Security Class Initialized
DEBUG - 2023-03-02 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:40:13 --> Input Class Initialized
INFO - 2023-03-02 06:40:13 --> Language Class Initialized
INFO - 2023-03-02 06:40:13 --> Loader Class Initialized
INFO - 2023-03-02 06:40:13 --> Controller Class Initialized
INFO - 2023-03-02 06:40:13 --> Helper loaded: form_helper
INFO - 2023-03-02 06:40:13 --> Helper loaded: url_helper
DEBUG - 2023-03-02 06:40:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:40:13 --> Model "Change_model" initialized
INFO - 2023-03-02 06:40:13 --> Model "Grafana_model" initialized
INFO - 2023-03-02 06:40:13 --> Final output sent to browser
DEBUG - 2023-03-02 06:40:13 --> Total execution time: 0.2442
INFO - 2023-03-02 06:40:13 --> Config Class Initialized
INFO - 2023-03-02 06:40:13 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:40:13 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:40:13 --> Utf8 Class Initialized
INFO - 2023-03-02 06:40:13 --> URI Class Initialized
INFO - 2023-03-02 06:40:13 --> Router Class Initialized
INFO - 2023-03-02 06:40:13 --> Output Class Initialized
INFO - 2023-03-02 06:40:13 --> Security Class Initialized
DEBUG - 2023-03-02 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:40:13 --> Input Class Initialized
INFO - 2023-03-02 06:40:13 --> Language Class Initialized
INFO - 2023-03-02 06:40:13 --> Loader Class Initialized
INFO - 2023-03-02 06:40:13 --> Controller Class Initialized
INFO - 2023-03-02 06:40:13 --> Helper loaded: form_helper
INFO - 2023-03-02 06:40:13 --> Helper loaded: url_helper
DEBUG - 2023-03-02 06:40:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:40:13 --> Final output sent to browser
DEBUG - 2023-03-02 06:40:13 --> Total execution time: 0.0426
INFO - 2023-03-02 06:40:13 --> Config Class Initialized
INFO - 2023-03-02 06:40:13 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:40:13 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:40:13 --> Utf8 Class Initialized
INFO - 2023-03-02 06:40:13 --> URI Class Initialized
INFO - 2023-03-02 06:40:13 --> Router Class Initialized
INFO - 2023-03-02 06:40:13 --> Output Class Initialized
INFO - 2023-03-02 06:40:13 --> Security Class Initialized
DEBUG - 2023-03-02 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:40:13 --> Input Class Initialized
INFO - 2023-03-02 06:40:13 --> Language Class Initialized
INFO - 2023-03-02 06:40:13 --> Loader Class Initialized
INFO - 2023-03-02 06:40:13 --> Controller Class Initialized
INFO - 2023-03-02 06:40:13 --> Helper loaded: form_helper
INFO - 2023-03-02 06:40:13 --> Helper loaded: url_helper
DEBUG - 2023-03-02 06:40:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:40:13 --> Database Driver Class Initialized
INFO - 2023-03-02 06:40:14 --> Model "Login_model" initialized
INFO - 2023-03-02 06:40:14 --> Final output sent to browser
DEBUG - 2023-03-02 06:40:14 --> Total execution time: 0.1501
INFO - 2023-03-02 06:40:14 --> Config Class Initialized
INFO - 2023-03-02 06:40:14 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:40:14 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:40:14 --> Utf8 Class Initialized
INFO - 2023-03-02 06:40:14 --> URI Class Initialized
INFO - 2023-03-02 06:40:14 --> Router Class Initialized
INFO - 2023-03-02 06:40:14 --> Output Class Initialized
INFO - 2023-03-02 06:40:14 --> Security Class Initialized
DEBUG - 2023-03-02 06:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:40:14 --> Input Class Initialized
INFO - 2023-03-02 06:40:14 --> Language Class Initialized
INFO - 2023-03-02 06:40:14 --> Loader Class Initialized
INFO - 2023-03-02 06:40:14 --> Controller Class Initialized
DEBUG - 2023-03-02 06:40:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:40:14 --> Database Driver Class Initialized
INFO - 2023-03-02 06:40:14 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:40:15 --> Final output sent to browser
DEBUG - 2023-03-02 06:40:15 --> Total execution time: 1.1702
INFO - 2023-03-02 06:40:15 --> Config Class Initialized
INFO - 2023-03-02 06:40:15 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:40:15 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:40:15 --> Utf8 Class Initialized
INFO - 2023-03-02 06:40:15 --> URI Class Initialized
INFO - 2023-03-02 06:40:15 --> Router Class Initialized
INFO - 2023-03-02 06:40:15 --> Output Class Initialized
INFO - 2023-03-02 06:40:15 --> Security Class Initialized
DEBUG - 2023-03-02 06:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:40:15 --> Input Class Initialized
INFO - 2023-03-02 06:40:15 --> Language Class Initialized
INFO - 2023-03-02 06:40:15 --> Loader Class Initialized
INFO - 2023-03-02 06:40:15 --> Controller Class Initialized
DEBUG - 2023-03-02 06:40:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:40:15 --> Database Driver Class Initialized
INFO - 2023-03-02 06:40:15 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:40:15 --> Final output sent to browser
DEBUG - 2023-03-02 06:40:15 --> Total execution time: 0.1284
INFO - 2023-03-02 06:40:15 --> Config Class Initialized
INFO - 2023-03-02 06:40:15 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:40:15 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:40:15 --> Utf8 Class Initialized
INFO - 2023-03-02 06:40:15 --> URI Class Initialized
INFO - 2023-03-02 06:40:15 --> Router Class Initialized
INFO - 2023-03-02 06:40:15 --> Output Class Initialized
INFO - 2023-03-02 06:40:15 --> Security Class Initialized
DEBUG - 2023-03-02 06:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:40:15 --> Input Class Initialized
INFO - 2023-03-02 06:40:15 --> Language Class Initialized
INFO - 2023-03-02 06:40:15 --> Loader Class Initialized
INFO - 2023-03-02 06:40:15 --> Controller Class Initialized
DEBUG - 2023-03-02 06:40:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:40:15 --> Database Driver Class Initialized
INFO - 2023-03-02 06:40:16 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:40:16 --> Database Driver Class Initialized
INFO - 2023-03-02 06:40:16 --> Model "Login_model" initialized
INFO - 2023-03-02 06:40:16 --> Final output sent to browser
DEBUG - 2023-03-02 06:40:16 --> Total execution time: 0.5297
INFO - 2023-03-02 06:40:16 --> Config Class Initialized
INFO - 2023-03-02 06:40:16 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:40:16 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:40:16 --> Utf8 Class Initialized
INFO - 2023-03-02 06:40:16 --> URI Class Initialized
INFO - 2023-03-02 06:40:16 --> Router Class Initialized
INFO - 2023-03-02 06:40:16 --> Output Class Initialized
INFO - 2023-03-02 06:40:16 --> Security Class Initialized
DEBUG - 2023-03-02 06:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:40:16 --> Input Class Initialized
INFO - 2023-03-02 06:40:16 --> Language Class Initialized
INFO - 2023-03-02 06:40:16 --> Loader Class Initialized
INFO - 2023-03-02 06:40:16 --> Controller Class Initialized
DEBUG - 2023-03-02 06:40:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:40:16 --> Database Driver Class Initialized
INFO - 2023-03-02 06:40:16 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:40:16 --> Database Driver Class Initialized
INFO - 2023-03-02 06:40:16 --> Model "Login_model" initialized
INFO - 2023-03-02 06:40:16 --> Final output sent to browser
DEBUG - 2023-03-02 06:40:16 --> Total execution time: 0.4933
INFO - 2023-03-02 06:40:22 --> Config Class Initialized
INFO - 2023-03-02 06:40:22 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:40:22 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:40:22 --> Utf8 Class Initialized
INFO - 2023-03-02 06:40:22 --> URI Class Initialized
INFO - 2023-03-02 06:40:22 --> Router Class Initialized
INFO - 2023-03-02 06:40:22 --> Output Class Initialized
INFO - 2023-03-02 06:40:22 --> Security Class Initialized
DEBUG - 2023-03-02 06:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:40:22 --> Input Class Initialized
INFO - 2023-03-02 06:40:22 --> Language Class Initialized
INFO - 2023-03-02 06:40:22 --> Loader Class Initialized
INFO - 2023-03-02 06:40:22 --> Controller Class Initialized
DEBUG - 2023-03-02 06:40:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:40:22 --> Database Driver Class Initialized
INFO - 2023-03-02 06:40:22 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:40:23 --> Final output sent to browser
DEBUG - 2023-03-02 06:40:23 --> Total execution time: 0.5351
INFO - 2023-03-02 06:40:23 --> Config Class Initialized
INFO - 2023-03-02 06:40:23 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:40:23 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:40:23 --> Utf8 Class Initialized
INFO - 2023-03-02 06:40:23 --> URI Class Initialized
INFO - 2023-03-02 06:40:23 --> Router Class Initialized
INFO - 2023-03-02 06:40:23 --> Output Class Initialized
INFO - 2023-03-02 06:40:23 --> Security Class Initialized
DEBUG - 2023-03-02 06:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:40:23 --> Input Class Initialized
INFO - 2023-03-02 06:40:23 --> Language Class Initialized
INFO - 2023-03-02 06:40:23 --> Loader Class Initialized
INFO - 2023-03-02 06:40:23 --> Controller Class Initialized
DEBUG - 2023-03-02 06:40:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:40:23 --> Database Driver Class Initialized
INFO - 2023-03-02 06:40:23 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:40:23 --> Final output sent to browser
DEBUG - 2023-03-02 06:40:23 --> Total execution time: 0.5392
INFO - 2023-03-02 06:40:26 --> Config Class Initialized
INFO - 2023-03-02 06:40:26 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:40:26 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:40:26 --> Utf8 Class Initialized
INFO - 2023-03-02 06:40:26 --> URI Class Initialized
INFO - 2023-03-02 06:40:26 --> Router Class Initialized
INFO - 2023-03-02 06:40:26 --> Output Class Initialized
INFO - 2023-03-02 06:40:26 --> Security Class Initialized
DEBUG - 2023-03-02 06:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:40:26 --> Input Class Initialized
INFO - 2023-03-02 06:40:26 --> Language Class Initialized
INFO - 2023-03-02 06:40:26 --> Loader Class Initialized
INFO - 2023-03-02 06:40:26 --> Controller Class Initialized
DEBUG - 2023-03-02 06:40:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:40:26 --> Database Driver Class Initialized
INFO - 2023-03-02 06:40:26 --> Database Driver Class Initialized
INFO - 2023-03-02 06:40:26 --> Model "Login_model" initialized
INFO - 2023-03-02 06:40:26 --> Final output sent to browser
DEBUG - 2023-03-02 06:40:26 --> Total execution time: 0.2326
INFO - 2023-03-02 06:40:26 --> Config Class Initialized
INFO - 2023-03-02 06:40:26 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:40:26 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:40:26 --> Utf8 Class Initialized
INFO - 2023-03-02 06:40:26 --> URI Class Initialized
INFO - 2023-03-02 06:40:26 --> Router Class Initialized
INFO - 2023-03-02 06:40:26 --> Output Class Initialized
INFO - 2023-03-02 06:40:26 --> Security Class Initialized
DEBUG - 2023-03-02 06:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:40:26 --> Input Class Initialized
INFO - 2023-03-02 06:40:26 --> Language Class Initialized
INFO - 2023-03-02 06:40:26 --> Loader Class Initialized
INFO - 2023-03-02 06:40:26 --> Controller Class Initialized
DEBUG - 2023-03-02 06:40:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:40:26 --> Database Driver Class Initialized
INFO - 2023-03-02 06:40:27 --> Database Driver Class Initialized
INFO - 2023-03-02 06:40:27 --> Model "Login_model" initialized
INFO - 2023-03-02 06:40:27 --> Final output sent to browser
DEBUG - 2023-03-02 06:40:27 --> Total execution time: 0.2760
INFO - 2023-03-02 06:41:05 --> Config Class Initialized
INFO - 2023-03-02 06:41:05 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:05 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:05 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:05 --> URI Class Initialized
INFO - 2023-03-02 06:41:05 --> Router Class Initialized
INFO - 2023-03-02 06:41:05 --> Output Class Initialized
INFO - 2023-03-02 06:41:05 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:05 --> Input Class Initialized
INFO - 2023-03-02 06:41:05 --> Language Class Initialized
INFO - 2023-03-02 06:41:05 --> Loader Class Initialized
INFO - 2023-03-02 06:41:05 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:05 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:05 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:05 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:05 --> Total execution time: 0.0192
INFO - 2023-03-02 06:41:05 --> Config Class Initialized
INFO - 2023-03-02 06:41:05 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:05 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:05 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:05 --> URI Class Initialized
INFO - 2023-03-02 06:41:05 --> Router Class Initialized
INFO - 2023-03-02 06:41:05 --> Output Class Initialized
INFO - 2023-03-02 06:41:05 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:05 --> Input Class Initialized
INFO - 2023-03-02 06:41:05 --> Language Class Initialized
INFO - 2023-03-02 06:41:05 --> Loader Class Initialized
INFO - 2023-03-02 06:41:05 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:05 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:05 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:05 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:05 --> Total execution time: 0.0535
INFO - 2023-03-02 06:41:07 --> Config Class Initialized
INFO - 2023-03-02 06:41:07 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:07 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:07 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:07 --> URI Class Initialized
INFO - 2023-03-02 06:41:07 --> Router Class Initialized
INFO - 2023-03-02 06:41:07 --> Output Class Initialized
INFO - 2023-03-02 06:41:07 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:07 --> Input Class Initialized
INFO - 2023-03-02 06:41:07 --> Language Class Initialized
INFO - 2023-03-02 06:41:07 --> Loader Class Initialized
INFO - 2023-03-02 06:41:07 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:07 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:07 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:07 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:07 --> Total execution time: 0.0472
INFO - 2023-03-02 06:41:07 --> Config Class Initialized
INFO - 2023-03-02 06:41:07 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:07 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:07 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:07 --> URI Class Initialized
INFO - 2023-03-02 06:41:07 --> Router Class Initialized
INFO - 2023-03-02 06:41:07 --> Output Class Initialized
INFO - 2023-03-02 06:41:07 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:07 --> Input Class Initialized
INFO - 2023-03-02 06:41:07 --> Language Class Initialized
INFO - 2023-03-02 06:41:07 --> Loader Class Initialized
INFO - 2023-03-02 06:41:07 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:07 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:07 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:07 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:07 --> Total execution time: 0.1025
INFO - 2023-03-02 06:41:10 --> Config Class Initialized
INFO - 2023-03-02 06:41:10 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:10 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:10 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:10 --> URI Class Initialized
INFO - 2023-03-02 06:41:10 --> Router Class Initialized
INFO - 2023-03-02 06:41:10 --> Output Class Initialized
INFO - 2023-03-02 06:41:10 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:10 --> Input Class Initialized
INFO - 2023-03-02 06:41:10 --> Language Class Initialized
INFO - 2023-03-02 06:41:10 --> Loader Class Initialized
INFO - 2023-03-02 06:41:10 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:10 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:10 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:10 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:10 --> Model "Login_model" initialized
INFO - 2023-03-02 06:41:10 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:10 --> Total execution time: 0.0392
INFO - 2023-03-02 06:41:10 --> Config Class Initialized
INFO - 2023-03-02 06:41:10 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:10 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:10 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:10 --> URI Class Initialized
INFO - 2023-03-02 06:41:10 --> Router Class Initialized
INFO - 2023-03-02 06:41:10 --> Output Class Initialized
INFO - 2023-03-02 06:41:10 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:10 --> Input Class Initialized
INFO - 2023-03-02 06:41:10 --> Language Class Initialized
INFO - 2023-03-02 06:41:10 --> Loader Class Initialized
INFO - 2023-03-02 06:41:10 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:10 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:10 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:10 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:10 --> Model "Login_model" initialized
INFO - 2023-03-02 06:41:10 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:10 --> Total execution time: 0.0843
INFO - 2023-03-02 06:41:20 --> Config Class Initialized
INFO - 2023-03-02 06:41:20 --> Config Class Initialized
INFO - 2023-03-02 06:41:20 --> Hooks Class Initialized
INFO - 2023-03-02 06:41:20 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:20 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:20 --> Utf8 Class Initialized
DEBUG - 2023-03-02 06:41:20 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:20 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:20 --> URI Class Initialized
INFO - 2023-03-02 06:41:20 --> URI Class Initialized
INFO - 2023-03-02 06:41:20 --> Router Class Initialized
INFO - 2023-03-02 06:41:20 --> Router Class Initialized
INFO - 2023-03-02 06:41:20 --> Output Class Initialized
INFO - 2023-03-02 06:41:20 --> Output Class Initialized
INFO - 2023-03-02 06:41:20 --> Security Class Initialized
INFO - 2023-03-02 06:41:20 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-02 06:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:20 --> Input Class Initialized
INFO - 2023-03-02 06:41:20 --> Input Class Initialized
INFO - 2023-03-02 06:41:20 --> Language Class Initialized
INFO - 2023-03-02 06:41:20 --> Language Class Initialized
INFO - 2023-03-02 06:41:20 --> Loader Class Initialized
INFO - 2023-03-02 06:41:20 --> Loader Class Initialized
INFO - 2023-03-02 06:41:20 --> Controller Class Initialized
INFO - 2023-03-02 06:41:20 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-02 06:41:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:20 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:20 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:20 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:20 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:20 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:20 --> Total execution time: 0.0146
INFO - 2023-03-02 06:41:20 --> Config Class Initialized
INFO - 2023-03-02 06:41:20 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:20 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:20 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:20 --> URI Class Initialized
INFO - 2023-03-02 06:41:20 --> Router Class Initialized
INFO - 2023-03-02 06:41:20 --> Output Class Initialized
INFO - 2023-03-02 06:41:20 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:20 --> Input Class Initialized
INFO - 2023-03-02 06:41:20 --> Language Class Initialized
INFO - 2023-03-02 06:41:20 --> Loader Class Initialized
INFO - 2023-03-02 06:41:20 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:20 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:20 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:20 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:20 --> Total execution time: 0.0930
INFO - 2023-03-02 06:41:20 --> Config Class Initialized
INFO - 2023-03-02 06:41:20 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:20 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:20 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:20 --> URI Class Initialized
INFO - 2023-03-02 06:41:20 --> Router Class Initialized
INFO - 2023-03-02 06:41:20 --> Output Class Initialized
INFO - 2023-03-02 06:41:20 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:20 --> Input Class Initialized
INFO - 2023-03-02 06:41:20 --> Language Class Initialized
INFO - 2023-03-02 06:41:20 --> Loader Class Initialized
INFO - 2023-03-02 06:41:20 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:20 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:20 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:22 --> Config Class Initialized
INFO - 2023-03-02 06:41:22 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:22 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:22 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:22 --> URI Class Initialized
INFO - 2023-03-02 06:41:22 --> Router Class Initialized
INFO - 2023-03-02 06:41:22 --> Output Class Initialized
INFO - 2023-03-02 06:41:22 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:22 --> Input Class Initialized
INFO - 2023-03-02 06:41:22 --> Language Class Initialized
INFO - 2023-03-02 06:41:22 --> Loader Class Initialized
INFO - 2023-03-02 06:41:22 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:22 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:22 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:22 --> Config Class Initialized
INFO - 2023-03-02 06:41:22 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:22 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:22 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:22 --> URI Class Initialized
INFO - 2023-03-02 06:41:22 --> Router Class Initialized
INFO - 2023-03-02 06:41:22 --> Output Class Initialized
INFO - 2023-03-02 06:41:22 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:22 --> Input Class Initialized
INFO - 2023-03-02 06:41:22 --> Language Class Initialized
INFO - 2023-03-02 06:41:22 --> Loader Class Initialized
INFO - 2023-03-02 06:41:22 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:22 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:22 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:50 --> Config Class Initialized
INFO - 2023-03-02 06:41:50 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:50 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:50 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:50 --> URI Class Initialized
INFO - 2023-03-02 06:41:50 --> Router Class Initialized
INFO - 2023-03-02 06:41:50 --> Output Class Initialized
INFO - 2023-03-02 06:41:50 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:50 --> Input Class Initialized
INFO - 2023-03-02 06:41:50 --> Language Class Initialized
INFO - 2023-03-02 06:41:50 --> Loader Class Initialized
INFO - 2023-03-02 06:41:50 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:50 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:50 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:50 --> Config Class Initialized
INFO - 2023-03-02 06:41:50 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:50 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:50 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:50 --> URI Class Initialized
INFO - 2023-03-02 06:41:50 --> Router Class Initialized
INFO - 2023-03-02 06:41:50 --> Output Class Initialized
INFO - 2023-03-02 06:41:50 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:50 --> Input Class Initialized
INFO - 2023-03-02 06:41:50 --> Language Class Initialized
INFO - 2023-03-02 06:41:50 --> Loader Class Initialized
INFO - 2023-03-02 06:41:50 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:50 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:50 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:51 --> Config Class Initialized
INFO - 2023-03-02 06:41:51 --> Config Class Initialized
INFO - 2023-03-02 06:41:51 --> Hooks Class Initialized
INFO - 2023-03-02 06:41:51 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2023-03-02 06:41:51 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:51 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:51 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:51 --> URI Class Initialized
INFO - 2023-03-02 06:41:51 --> URI Class Initialized
INFO - 2023-03-02 06:41:51 --> Router Class Initialized
INFO - 2023-03-02 06:41:51 --> Output Class Initialized
INFO - 2023-03-02 06:41:51 --> Router Class Initialized
INFO - 2023-03-02 06:41:51 --> Security Class Initialized
INFO - 2023-03-02 06:41:51 --> Output Class Initialized
DEBUG - 2023-03-02 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:51 --> Security Class Initialized
INFO - 2023-03-02 06:41:51 --> Input Class Initialized
DEBUG - 2023-03-02 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:51 --> Input Class Initialized
INFO - 2023-03-02 06:41:51 --> Language Class Initialized
INFO - 2023-03-02 06:41:51 --> Language Class Initialized
INFO - 2023-03-02 06:41:51 --> Loader Class Initialized
INFO - 2023-03-02 06:41:51 --> Loader Class Initialized
INFO - 2023-03-02 06:41:51 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:51 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:51 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:51 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:51 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:51 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:51 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:51 --> Total execution time: 0.0349
INFO - 2023-03-02 06:41:51 --> Config Class Initialized
INFO - 2023-03-02 06:41:51 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:51 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:51 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:51 --> URI Class Initialized
INFO - 2023-03-02 06:41:51 --> Router Class Initialized
INFO - 2023-03-02 06:41:51 --> Output Class Initialized
INFO - 2023-03-02 06:41:51 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:51 --> Input Class Initialized
INFO - 2023-03-02 06:41:51 --> Language Class Initialized
INFO - 2023-03-02 06:41:51 --> Loader Class Initialized
INFO - 2023-03-02 06:41:51 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:51 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:51 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:51 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:51 --> Total execution time: 0.0102
INFO - 2023-03-02 06:41:54 --> Config Class Initialized
INFO - 2023-03-02 06:41:54 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:54 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:54 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:54 --> URI Class Initialized
INFO - 2023-03-02 06:41:54 --> Router Class Initialized
INFO - 2023-03-02 06:41:54 --> Output Class Initialized
INFO - 2023-03-02 06:41:54 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:54 --> Input Class Initialized
INFO - 2023-03-02 06:41:54 --> Language Class Initialized
INFO - 2023-03-02 06:41:54 --> Loader Class Initialized
INFO - 2023-03-02 06:41:54 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:54 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:54 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:54 --> Config Class Initialized
INFO - 2023-03-02 06:41:54 --> Hooks Class Initialized
INFO - 2023-03-02 06:41:54 --> Config Class Initialized
INFO - 2023-03-02 06:41:54 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:54 --> UTF-8 Support Enabled
DEBUG - 2023-03-02 06:41:54 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:54 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:54 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:54 --> URI Class Initialized
INFO - 2023-03-02 06:41:54 --> URI Class Initialized
INFO - 2023-03-02 06:41:54 --> Router Class Initialized
INFO - 2023-03-02 06:41:54 --> Router Class Initialized
INFO - 2023-03-02 06:41:54 --> Output Class Initialized
INFO - 2023-03-02 06:41:54 --> Output Class Initialized
INFO - 2023-03-02 06:41:54 --> Security Class Initialized
INFO - 2023-03-02 06:41:54 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-02 06:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:54 --> Input Class Initialized
INFO - 2023-03-02 06:41:54 --> Input Class Initialized
INFO - 2023-03-02 06:41:54 --> Language Class Initialized
INFO - 2023-03-02 06:41:54 --> Language Class Initialized
INFO - 2023-03-02 06:41:54 --> Loader Class Initialized
INFO - 2023-03-02 06:41:54 --> Loader Class Initialized
INFO - 2023-03-02 06:41:54 --> Controller Class Initialized
INFO - 2023-03-02 06:41:54 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-02 06:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:54 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:54 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:54 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:54 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:54 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:54 --> Total execution time: 0.0598
INFO - 2023-03-02 06:41:55 --> Config Class Initialized
INFO - 2023-03-02 06:41:55 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:55 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:55 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:55 --> URI Class Initialized
INFO - 2023-03-02 06:41:55 --> Router Class Initialized
INFO - 2023-03-02 06:41:55 --> Output Class Initialized
INFO - 2023-03-02 06:41:55 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:55 --> Input Class Initialized
INFO - 2023-03-02 06:41:55 --> Language Class Initialized
INFO - 2023-03-02 06:41:55 --> Loader Class Initialized
INFO - 2023-03-02 06:41:55 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:55 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:55 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:56 --> Config Class Initialized
INFO - 2023-03-02 06:41:56 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:56 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:56 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:56 --> URI Class Initialized
INFO - 2023-03-02 06:41:56 --> Router Class Initialized
INFO - 2023-03-02 06:41:56 --> Output Class Initialized
INFO - 2023-03-02 06:41:56 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:56 --> Input Class Initialized
INFO - 2023-03-02 06:41:56 --> Language Class Initialized
INFO - 2023-03-02 06:41:56 --> Loader Class Initialized
INFO - 2023-03-02 06:41:56 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:56 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:56 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:57 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:57 --> Model "Login_model" initialized
INFO - 2023-03-02 06:41:57 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:57 --> Total execution time: 0.1060
INFO - 2023-03-02 06:41:57 --> Config Class Initialized
INFO - 2023-03-02 06:41:57 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:57 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:57 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:57 --> URI Class Initialized
INFO - 2023-03-02 06:41:57 --> Router Class Initialized
INFO - 2023-03-02 06:41:57 --> Output Class Initialized
INFO - 2023-03-02 06:41:57 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:57 --> Input Class Initialized
INFO - 2023-03-02 06:41:57 --> Language Class Initialized
INFO - 2023-03-02 06:41:57 --> Loader Class Initialized
INFO - 2023-03-02 06:41:57 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:57 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:57 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:57 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:57 --> Model "Login_model" initialized
INFO - 2023-03-02 06:41:57 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:57 --> Total execution time: 0.0425
INFO - 2023-03-02 06:41:57 --> Config Class Initialized
INFO - 2023-03-02 06:41:57 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:57 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:57 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:57 --> URI Class Initialized
INFO - 2023-03-02 06:41:57 --> Router Class Initialized
INFO - 2023-03-02 06:41:57 --> Output Class Initialized
INFO - 2023-03-02 06:41:57 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:57 --> Input Class Initialized
INFO - 2023-03-02 06:41:57 --> Language Class Initialized
INFO - 2023-03-02 06:41:57 --> Loader Class Initialized
INFO - 2023-03-02 06:41:57 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:57 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:58 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:58 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:58 --> Total execution time: 0.0204
INFO - 2023-03-02 06:41:58 --> Config Class Initialized
INFO - 2023-03-02 06:41:58 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:58 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:58 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:58 --> URI Class Initialized
INFO - 2023-03-02 06:41:58 --> Router Class Initialized
INFO - 2023-03-02 06:41:58 --> Output Class Initialized
INFO - 2023-03-02 06:41:58 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:58 --> Input Class Initialized
INFO - 2023-03-02 06:41:58 --> Language Class Initialized
INFO - 2023-03-02 06:41:58 --> Loader Class Initialized
INFO - 2023-03-02 06:41:58 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:58 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:58 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:58 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:58 --> Total execution time: 0.0570
INFO - 2023-03-02 06:41:58 --> Config Class Initialized
INFO - 2023-03-02 06:41:59 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:59 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:59 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:59 --> URI Class Initialized
INFO - 2023-03-02 06:41:59 --> Router Class Initialized
INFO - 2023-03-02 06:41:59 --> Output Class Initialized
INFO - 2023-03-02 06:41:59 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:59 --> Input Class Initialized
INFO - 2023-03-02 06:41:59 --> Language Class Initialized
INFO - 2023-03-02 06:41:59 --> Loader Class Initialized
INFO - 2023-03-02 06:41:59 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:59 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:59 --> Total execution time: 0.0420
INFO - 2023-03-02 06:41:59 --> Config Class Initialized
INFO - 2023-03-02 06:41:59 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:59 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:59 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:59 --> URI Class Initialized
INFO - 2023-03-02 06:41:59 --> Router Class Initialized
INFO - 2023-03-02 06:41:59 --> Output Class Initialized
INFO - 2023-03-02 06:41:59 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:59 --> Input Class Initialized
INFO - 2023-03-02 06:41:59 --> Language Class Initialized
INFO - 2023-03-02 06:41:59 --> Loader Class Initialized
INFO - 2023-03-02 06:41:59 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:59 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:59 --> Model "Login_model" initialized
INFO - 2023-03-02 06:41:59 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:59 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:59 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:59 --> Total execution time: 0.0198
INFO - 2023-03-02 06:41:59 --> Config Class Initialized
INFO - 2023-03-02 06:41:59 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:59 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:59 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:59 --> URI Class Initialized
INFO - 2023-03-02 06:41:59 --> Router Class Initialized
INFO - 2023-03-02 06:41:59 --> Output Class Initialized
INFO - 2023-03-02 06:41:59 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:59 --> Input Class Initialized
INFO - 2023-03-02 06:41:59 --> Language Class Initialized
INFO - 2023-03-02 06:41:59 --> Loader Class Initialized
INFO - 2023-03-02 06:41:59 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:59 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:59 --> Total execution time: 0.0826
INFO - 2023-03-02 06:41:59 --> Config Class Initialized
INFO - 2023-03-02 06:41:59 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:59 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:59 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:59 --> URI Class Initialized
INFO - 2023-03-02 06:41:59 --> Router Class Initialized
INFO - 2023-03-02 06:41:59 --> Output Class Initialized
INFO - 2023-03-02 06:41:59 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:59 --> Input Class Initialized
INFO - 2023-03-02 06:41:59 --> Language Class Initialized
INFO - 2023-03-02 06:41:59 --> Loader Class Initialized
INFO - 2023-03-02 06:41:59 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:59 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:59 --> Model "Login_model" initialized
INFO - 2023-03-02 06:41:59 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:59 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:59 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:59 --> Total execution time: 0.0235
INFO - 2023-03-02 06:41:59 --> Config Class Initialized
INFO - 2023-03-02 06:41:59 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:41:59 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:41:59 --> Utf8 Class Initialized
INFO - 2023-03-02 06:41:59 --> URI Class Initialized
INFO - 2023-03-02 06:41:59 --> Router Class Initialized
INFO - 2023-03-02 06:41:59 --> Output Class Initialized
INFO - 2023-03-02 06:41:59 --> Security Class Initialized
DEBUG - 2023-03-02 06:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:41:59 --> Input Class Initialized
INFO - 2023-03-02 06:41:59 --> Language Class Initialized
INFO - 2023-03-02 06:41:59 --> Loader Class Initialized
INFO - 2023-03-02 06:41:59 --> Controller Class Initialized
DEBUG - 2023-03-02 06:41:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:41:59 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:59 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:41:59 --> Database Driver Class Initialized
INFO - 2023-03-02 06:41:59 --> Model "Login_model" initialized
INFO - 2023-03-02 06:41:59 --> Final output sent to browser
DEBUG - 2023-03-02 06:41:59 --> Total execution time: 0.1200
INFO - 2023-03-02 06:42:02 --> Config Class Initialized
INFO - 2023-03-02 06:42:02 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:02 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:02 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:02 --> URI Class Initialized
INFO - 2023-03-02 06:42:02 --> Router Class Initialized
INFO - 2023-03-02 06:42:02 --> Output Class Initialized
INFO - 2023-03-02 06:42:02 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:02 --> Input Class Initialized
INFO - 2023-03-02 06:42:02 --> Language Class Initialized
INFO - 2023-03-02 06:42:02 --> Loader Class Initialized
INFO - 2023-03-02 06:42:02 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:02 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:02 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:02 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:02 --> Total execution time: 0.0471
INFO - 2023-03-02 06:42:02 --> Config Class Initialized
INFO - 2023-03-02 06:42:02 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:02 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:02 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:02 --> URI Class Initialized
INFO - 2023-03-02 06:42:02 --> Router Class Initialized
INFO - 2023-03-02 06:42:02 --> Output Class Initialized
INFO - 2023-03-02 06:42:02 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:02 --> Input Class Initialized
INFO - 2023-03-02 06:42:02 --> Language Class Initialized
INFO - 2023-03-02 06:42:02 --> Loader Class Initialized
INFO - 2023-03-02 06:42:02 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:02 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:02 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:02 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:02 --> Total execution time: 0.0401
INFO - 2023-03-02 06:42:04 --> Config Class Initialized
INFO - 2023-03-02 06:42:04 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:04 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:04 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:04 --> URI Class Initialized
INFO - 2023-03-02 06:42:04 --> Router Class Initialized
INFO - 2023-03-02 06:42:04 --> Output Class Initialized
INFO - 2023-03-02 06:42:04 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:04 --> Input Class Initialized
INFO - 2023-03-02 06:42:04 --> Language Class Initialized
INFO - 2023-03-02 06:42:04 --> Loader Class Initialized
INFO - 2023-03-02 06:42:04 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:04 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:04 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:04 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:04 --> Total execution time: 0.0191
INFO - 2023-03-02 06:42:04 --> Config Class Initialized
INFO - 2023-03-02 06:42:04 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:04 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:04 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:04 --> URI Class Initialized
INFO - 2023-03-02 06:42:04 --> Router Class Initialized
INFO - 2023-03-02 06:42:04 --> Output Class Initialized
INFO - 2023-03-02 06:42:04 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:04 --> Input Class Initialized
INFO - 2023-03-02 06:42:04 --> Language Class Initialized
INFO - 2023-03-02 06:42:04 --> Loader Class Initialized
INFO - 2023-03-02 06:42:04 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:04 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:04 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:04 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:04 --> Total execution time: 0.0123
INFO - 2023-03-02 06:42:07 --> Config Class Initialized
INFO - 2023-03-02 06:42:07 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:07 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:07 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:07 --> URI Class Initialized
INFO - 2023-03-02 06:42:07 --> Router Class Initialized
INFO - 2023-03-02 06:42:07 --> Output Class Initialized
INFO - 2023-03-02 06:42:07 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:07 --> Input Class Initialized
INFO - 2023-03-02 06:42:07 --> Language Class Initialized
INFO - 2023-03-02 06:42:07 --> Loader Class Initialized
INFO - 2023-03-02 06:42:07 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:07 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:07 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:07 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:07 --> Total execution time: 0.0147
INFO - 2023-03-02 06:42:07 --> Config Class Initialized
INFO - 2023-03-02 06:42:07 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:07 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:07 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:07 --> URI Class Initialized
INFO - 2023-03-02 06:42:07 --> Router Class Initialized
INFO - 2023-03-02 06:42:07 --> Output Class Initialized
INFO - 2023-03-02 06:42:07 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:07 --> Input Class Initialized
INFO - 2023-03-02 06:42:07 --> Language Class Initialized
INFO - 2023-03-02 06:42:07 --> Loader Class Initialized
INFO - 2023-03-02 06:42:07 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:07 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:07 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:07 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:07 --> Total execution time: 0.0164
INFO - 2023-03-02 06:42:09 --> Config Class Initialized
INFO - 2023-03-02 06:42:09 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:09 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:09 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:09 --> URI Class Initialized
INFO - 2023-03-02 06:42:09 --> Router Class Initialized
INFO - 2023-03-02 06:42:09 --> Output Class Initialized
INFO - 2023-03-02 06:42:09 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:09 --> Input Class Initialized
INFO - 2023-03-02 06:42:09 --> Language Class Initialized
INFO - 2023-03-02 06:42:09 --> Loader Class Initialized
INFO - 2023-03-02 06:42:09 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:09 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:09 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:09 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:09 --> Total execution time: 0.0171
INFO - 2023-03-02 06:42:09 --> Config Class Initialized
INFO - 2023-03-02 06:42:09 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:09 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:09 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:09 --> URI Class Initialized
INFO - 2023-03-02 06:42:09 --> Router Class Initialized
INFO - 2023-03-02 06:42:09 --> Output Class Initialized
INFO - 2023-03-02 06:42:09 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:09 --> Input Class Initialized
INFO - 2023-03-02 06:42:09 --> Language Class Initialized
INFO - 2023-03-02 06:42:09 --> Loader Class Initialized
INFO - 2023-03-02 06:42:09 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:09 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:09 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:09 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:09 --> Total execution time: 0.0528
INFO - 2023-03-02 06:42:11 --> Config Class Initialized
INFO - 2023-03-02 06:42:11 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:11 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:11 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:11 --> URI Class Initialized
INFO - 2023-03-02 06:42:11 --> Router Class Initialized
INFO - 2023-03-02 06:42:11 --> Output Class Initialized
INFO - 2023-03-02 06:42:11 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:11 --> Input Class Initialized
INFO - 2023-03-02 06:42:11 --> Language Class Initialized
INFO - 2023-03-02 06:42:11 --> Loader Class Initialized
INFO - 2023-03-02 06:42:11 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:11 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:11 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:11 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:11 --> Total execution time: 0.0443
INFO - 2023-03-02 06:42:11 --> Config Class Initialized
INFO - 2023-03-02 06:42:11 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:11 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:11 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:11 --> URI Class Initialized
INFO - 2023-03-02 06:42:11 --> Router Class Initialized
INFO - 2023-03-02 06:42:11 --> Output Class Initialized
INFO - 2023-03-02 06:42:11 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:11 --> Input Class Initialized
INFO - 2023-03-02 06:42:11 --> Language Class Initialized
INFO - 2023-03-02 06:42:11 --> Loader Class Initialized
INFO - 2023-03-02 06:42:11 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:11 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:11 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:11 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:11 --> Total execution time: 0.0419
INFO - 2023-03-02 06:42:13 --> Config Class Initialized
INFO - 2023-03-02 06:42:13 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:13 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:13 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:13 --> URI Class Initialized
INFO - 2023-03-02 06:42:13 --> Router Class Initialized
INFO - 2023-03-02 06:42:13 --> Output Class Initialized
INFO - 2023-03-02 06:42:13 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:13 --> Input Class Initialized
INFO - 2023-03-02 06:42:13 --> Language Class Initialized
INFO - 2023-03-02 06:42:13 --> Loader Class Initialized
INFO - 2023-03-02 06:42:13 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:13 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:13 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:13 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:13 --> Model "Login_model" initialized
INFO - 2023-03-02 06:42:13 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:13 --> Total execution time: 0.0440
INFO - 2023-03-02 06:42:13 --> Config Class Initialized
INFO - 2023-03-02 06:42:13 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:13 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:13 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:13 --> URI Class Initialized
INFO - 2023-03-02 06:42:13 --> Router Class Initialized
INFO - 2023-03-02 06:42:13 --> Output Class Initialized
INFO - 2023-03-02 06:42:13 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:13 --> Input Class Initialized
INFO - 2023-03-02 06:42:13 --> Language Class Initialized
INFO - 2023-03-02 06:42:13 --> Loader Class Initialized
INFO - 2023-03-02 06:42:13 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:13 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:13 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:13 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:13 --> Model "Login_model" initialized
INFO - 2023-03-02 06:42:13 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:13 --> Total execution time: 0.0399
INFO - 2023-03-02 06:42:42 --> Config Class Initialized
INFO - 2023-03-02 06:42:42 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:42 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:42 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:42 --> URI Class Initialized
INFO - 2023-03-02 06:42:42 --> Router Class Initialized
INFO - 2023-03-02 06:42:42 --> Output Class Initialized
INFO - 2023-03-02 06:42:42 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:42 --> Input Class Initialized
INFO - 2023-03-02 06:42:42 --> Language Class Initialized
INFO - 2023-03-02 06:42:42 --> Loader Class Initialized
INFO - 2023-03-02 06:42:42 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:42 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:42 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:42 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:42 --> Total execution time: 0.0877
INFO - 2023-03-02 06:42:42 --> Config Class Initialized
INFO - 2023-03-02 06:42:42 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:42 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:42 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:42 --> URI Class Initialized
INFO - 2023-03-02 06:42:42 --> Router Class Initialized
INFO - 2023-03-02 06:42:42 --> Output Class Initialized
INFO - 2023-03-02 06:42:42 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:42 --> Input Class Initialized
INFO - 2023-03-02 06:42:42 --> Language Class Initialized
INFO - 2023-03-02 06:42:42 --> Loader Class Initialized
INFO - 2023-03-02 06:42:42 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:42 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:42 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:42 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:42 --> Total execution time: 0.0853
INFO - 2023-03-02 06:42:44 --> Config Class Initialized
INFO - 2023-03-02 06:42:44 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:44 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:44 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:44 --> URI Class Initialized
INFO - 2023-03-02 06:42:44 --> Router Class Initialized
INFO - 2023-03-02 06:42:44 --> Output Class Initialized
INFO - 2023-03-02 06:42:44 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:44 --> Input Class Initialized
INFO - 2023-03-02 06:42:44 --> Language Class Initialized
INFO - 2023-03-02 06:42:44 --> Loader Class Initialized
INFO - 2023-03-02 06:42:44 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:44 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:44 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:44 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:44 --> Total execution time: 0.0576
INFO - 2023-03-02 06:42:44 --> Config Class Initialized
INFO - 2023-03-02 06:42:44 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:42:44 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:42:44 --> Utf8 Class Initialized
INFO - 2023-03-02 06:42:44 --> URI Class Initialized
INFO - 2023-03-02 06:42:44 --> Router Class Initialized
INFO - 2023-03-02 06:42:44 --> Output Class Initialized
INFO - 2023-03-02 06:42:44 --> Security Class Initialized
DEBUG - 2023-03-02 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:42:44 --> Input Class Initialized
INFO - 2023-03-02 06:42:44 --> Language Class Initialized
INFO - 2023-03-02 06:42:44 --> Loader Class Initialized
INFO - 2023-03-02 06:42:44 --> Controller Class Initialized
DEBUG - 2023-03-02 06:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:42:44 --> Database Driver Class Initialized
INFO - 2023-03-02 06:42:44 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:42:44 --> Final output sent to browser
DEBUG - 2023-03-02 06:42:44 --> Total execution time: 0.0117
INFO - 2023-03-02 06:49:07 --> Config Class Initialized
INFO - 2023-03-02 06:49:07 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:07 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:07 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:07 --> URI Class Initialized
INFO - 2023-03-02 06:49:07 --> Router Class Initialized
INFO - 2023-03-02 06:49:07 --> Output Class Initialized
INFO - 2023-03-02 06:49:07 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:07 --> Input Class Initialized
INFO - 2023-03-02 06:49:07 --> Language Class Initialized
INFO - 2023-03-02 06:49:07 --> Loader Class Initialized
INFO - 2023-03-02 06:49:07 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:07 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:07 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:07 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:07 --> Total execution time: 0.0597
INFO - 2023-03-02 06:49:07 --> Config Class Initialized
INFO - 2023-03-02 06:49:07 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:07 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:07 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:07 --> URI Class Initialized
INFO - 2023-03-02 06:49:07 --> Router Class Initialized
INFO - 2023-03-02 06:49:07 --> Output Class Initialized
INFO - 2023-03-02 06:49:07 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:07 --> Input Class Initialized
INFO - 2023-03-02 06:49:07 --> Language Class Initialized
INFO - 2023-03-02 06:49:07 --> Loader Class Initialized
INFO - 2023-03-02 06:49:07 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:07 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:07 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:07 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:07 --> Total execution time: 0.0951
INFO - 2023-03-02 06:49:08 --> Config Class Initialized
INFO - 2023-03-02 06:49:08 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:08 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:08 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:08 --> URI Class Initialized
INFO - 2023-03-02 06:49:08 --> Router Class Initialized
INFO - 2023-03-02 06:49:08 --> Output Class Initialized
INFO - 2023-03-02 06:49:08 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:08 --> Input Class Initialized
INFO - 2023-03-02 06:49:08 --> Language Class Initialized
INFO - 2023-03-02 06:49:08 --> Loader Class Initialized
INFO - 2023-03-02 06:49:08 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:08 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:08 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:08 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:08 --> Model "Login_model" initialized
INFO - 2023-03-02 06:49:08 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:08 --> Total execution time: 0.0414
INFO - 2023-03-02 06:49:08 --> Config Class Initialized
INFO - 2023-03-02 06:49:08 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:08 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:08 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:08 --> URI Class Initialized
INFO - 2023-03-02 06:49:08 --> Router Class Initialized
INFO - 2023-03-02 06:49:08 --> Output Class Initialized
INFO - 2023-03-02 06:49:08 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:08 --> Input Class Initialized
INFO - 2023-03-02 06:49:08 --> Language Class Initialized
INFO - 2023-03-02 06:49:08 --> Loader Class Initialized
INFO - 2023-03-02 06:49:08 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:08 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:08 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:08 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:08 --> Model "Login_model" initialized
INFO - 2023-03-02 06:49:08 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:08 --> Total execution time: 0.0817
INFO - 2023-03-02 06:49:12 --> Config Class Initialized
INFO - 2023-03-02 06:49:12 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:12 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:12 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:12 --> URI Class Initialized
INFO - 2023-03-02 06:49:12 --> Router Class Initialized
INFO - 2023-03-02 06:49:12 --> Output Class Initialized
INFO - 2023-03-02 06:49:12 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:12 --> Input Class Initialized
INFO - 2023-03-02 06:49:12 --> Language Class Initialized
INFO - 2023-03-02 06:49:12 --> Loader Class Initialized
INFO - 2023-03-02 06:49:12 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:12 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:12 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:12 --> Config Class Initialized
INFO - 2023-03-02 06:49:12 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:12 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:12 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:12 --> URI Class Initialized
INFO - 2023-03-02 06:49:12 --> Router Class Initialized
INFO - 2023-03-02 06:49:12 --> Output Class Initialized
INFO - 2023-03-02 06:49:12 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:12 --> Input Class Initialized
INFO - 2023-03-02 06:49:12 --> Language Class Initialized
INFO - 2023-03-02 06:49:12 --> Loader Class Initialized
INFO - 2023-03-02 06:49:12 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:12 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:12 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:12 --> Config Class Initialized
INFO - 2023-03-02 06:49:12 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:12 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:12 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:12 --> URI Class Initialized
INFO - 2023-03-02 06:49:12 --> Router Class Initialized
INFO - 2023-03-02 06:49:12 --> Output Class Initialized
INFO - 2023-03-02 06:49:12 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:12 --> Input Class Initialized
INFO - 2023-03-02 06:49:12 --> Language Class Initialized
INFO - 2023-03-02 06:49:12 --> Loader Class Initialized
INFO - 2023-03-02 06:49:12 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:12 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:12 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:12 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:12 --> Total execution time: 0.0502
INFO - 2023-03-02 06:49:12 --> Config Class Initialized
INFO - 2023-03-02 06:49:12 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:12 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:12 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:12 --> URI Class Initialized
INFO - 2023-03-02 06:49:12 --> Router Class Initialized
INFO - 2023-03-02 06:49:12 --> Output Class Initialized
INFO - 2023-03-02 06:49:12 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:12 --> Input Class Initialized
INFO - 2023-03-02 06:49:12 --> Language Class Initialized
INFO - 2023-03-02 06:49:12 --> Loader Class Initialized
INFO - 2023-03-02 06:49:12 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:12 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:12 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:12 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:12 --> Total execution time: 0.0512
INFO - 2023-03-02 06:49:13 --> Config Class Initialized
INFO - 2023-03-02 06:49:13 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:13 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:13 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:13 --> URI Class Initialized
INFO - 2023-03-02 06:49:13 --> Router Class Initialized
INFO - 2023-03-02 06:49:13 --> Output Class Initialized
INFO - 2023-03-02 06:49:13 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:13 --> Input Class Initialized
INFO - 2023-03-02 06:49:13 --> Language Class Initialized
INFO - 2023-03-02 06:49:13 --> Loader Class Initialized
INFO - 2023-03-02 06:49:13 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:13 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:13 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:13 --> Config Class Initialized
INFO - 2023-03-02 06:49:13 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:13 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:13 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:13 --> URI Class Initialized
INFO - 2023-03-02 06:49:13 --> Router Class Initialized
INFO - 2023-03-02 06:49:13 --> Output Class Initialized
INFO - 2023-03-02 06:49:13 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:13 --> Input Class Initialized
INFO - 2023-03-02 06:49:13 --> Language Class Initialized
INFO - 2023-03-02 06:49:13 --> Loader Class Initialized
INFO - 2023-03-02 06:49:13 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:13 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:13 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:13 --> Config Class Initialized
INFO - 2023-03-02 06:49:13 --> Config Class Initialized
INFO - 2023-03-02 06:49:13 --> Hooks Class Initialized
INFO - 2023-03-02 06:49:13 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:13 --> UTF-8 Support Enabled
DEBUG - 2023-03-02 06:49:13 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:13 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:13 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:13 --> URI Class Initialized
INFO - 2023-03-02 06:49:13 --> URI Class Initialized
INFO - 2023-03-02 06:49:13 --> Router Class Initialized
INFO - 2023-03-02 06:49:13 --> Router Class Initialized
INFO - 2023-03-02 06:49:13 --> Output Class Initialized
INFO - 2023-03-02 06:49:13 --> Output Class Initialized
INFO - 2023-03-02 06:49:13 --> Security Class Initialized
INFO - 2023-03-02 06:49:13 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-02 06:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:13 --> Input Class Initialized
INFO - 2023-03-02 06:49:13 --> Input Class Initialized
INFO - 2023-03-02 06:49:13 --> Language Class Initialized
INFO - 2023-03-02 06:49:13 --> Language Class Initialized
INFO - 2023-03-02 06:49:13 --> Loader Class Initialized
INFO - 2023-03-02 06:49:13 --> Loader Class Initialized
INFO - 2023-03-02 06:49:13 --> Controller Class Initialized
INFO - 2023-03-02 06:49:13 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-02 06:49:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:13 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:13 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:13 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:13 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:13 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:13 --> Total execution time: 0.0162
INFO - 2023-03-02 06:49:13 --> Config Class Initialized
INFO - 2023-03-02 06:49:13 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:13 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:13 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:13 --> URI Class Initialized
INFO - 2023-03-02 06:49:13 --> Router Class Initialized
INFO - 2023-03-02 06:49:13 --> Output Class Initialized
INFO - 2023-03-02 06:49:13 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:13 --> Input Class Initialized
INFO - 2023-03-02 06:49:13 --> Language Class Initialized
INFO - 2023-03-02 06:49:13 --> Loader Class Initialized
INFO - 2023-03-02 06:49:13 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:13 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:13 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:14 --> Config Class Initialized
INFO - 2023-03-02 06:49:14 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:14 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:14 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:14 --> URI Class Initialized
INFO - 2023-03-02 06:49:14 --> Router Class Initialized
INFO - 2023-03-02 06:49:14 --> Output Class Initialized
INFO - 2023-03-02 06:49:14 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:14 --> Input Class Initialized
INFO - 2023-03-02 06:49:14 --> Language Class Initialized
INFO - 2023-03-02 06:49:14 --> Loader Class Initialized
INFO - 2023-03-02 06:49:14 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:14 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:14 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:14 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:14 --> Total execution time: 0.0140
INFO - 2023-03-02 06:49:14 --> Config Class Initialized
INFO - 2023-03-02 06:49:14 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:14 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:14 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:14 --> URI Class Initialized
INFO - 2023-03-02 06:49:14 --> Router Class Initialized
INFO - 2023-03-02 06:49:14 --> Output Class Initialized
INFO - 2023-03-02 06:49:14 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:14 --> Input Class Initialized
INFO - 2023-03-02 06:49:14 --> Language Class Initialized
INFO - 2023-03-02 06:49:14 --> Loader Class Initialized
INFO - 2023-03-02 06:49:14 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:14 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:14 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:14 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:14 --> Total execution time: 0.0538
INFO - 2023-03-02 06:49:16 --> Config Class Initialized
INFO - 2023-03-02 06:49:16 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:16 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:16 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:16 --> URI Class Initialized
INFO - 2023-03-02 06:49:16 --> Router Class Initialized
INFO - 2023-03-02 06:49:16 --> Output Class Initialized
INFO - 2023-03-02 06:49:16 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:16 --> Input Class Initialized
INFO - 2023-03-02 06:49:16 --> Language Class Initialized
INFO - 2023-03-02 06:49:16 --> Loader Class Initialized
INFO - 2023-03-02 06:49:16 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:16 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:16 --> Total execution time: 0.0090
INFO - 2023-03-02 06:49:16 --> Config Class Initialized
INFO - 2023-03-02 06:49:16 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:16 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:16 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:16 --> URI Class Initialized
INFO - 2023-03-02 06:49:16 --> Router Class Initialized
INFO - 2023-03-02 06:49:16 --> Output Class Initialized
INFO - 2023-03-02 06:49:16 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:16 --> Input Class Initialized
INFO - 2023-03-02 06:49:16 --> Language Class Initialized
INFO - 2023-03-02 06:49:16 --> Loader Class Initialized
INFO - 2023-03-02 06:49:16 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:16 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:16 --> Model "Login_model" initialized
INFO - 2023-03-02 06:49:16 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:16 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:16 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:16 --> Total execution time: 0.0231
INFO - 2023-03-02 06:49:16 --> Config Class Initialized
INFO - 2023-03-02 06:49:16 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:16 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:16 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:16 --> URI Class Initialized
INFO - 2023-03-02 06:49:16 --> Router Class Initialized
INFO - 2023-03-02 06:49:16 --> Output Class Initialized
INFO - 2023-03-02 06:49:16 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:16 --> Input Class Initialized
INFO - 2023-03-02 06:49:16 --> Language Class Initialized
INFO - 2023-03-02 06:49:16 --> Loader Class Initialized
INFO - 2023-03-02 06:49:16 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:16 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:16 --> Total execution time: 0.0459
INFO - 2023-03-02 06:49:16 --> Config Class Initialized
INFO - 2023-03-02 06:49:16 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:16 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:16 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:16 --> URI Class Initialized
INFO - 2023-03-02 06:49:16 --> Router Class Initialized
INFO - 2023-03-02 06:49:16 --> Output Class Initialized
INFO - 2023-03-02 06:49:16 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:16 --> Input Class Initialized
INFO - 2023-03-02 06:49:16 --> Language Class Initialized
INFO - 2023-03-02 06:49:16 --> Loader Class Initialized
INFO - 2023-03-02 06:49:16 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:16 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:16 --> Model "Login_model" initialized
INFO - 2023-03-02 06:49:16 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:16 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:16 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:16 --> Total execution time: 0.0197
INFO - 2023-03-02 06:49:17 --> Config Class Initialized
INFO - 2023-03-02 06:49:17 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:17 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:17 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:17 --> URI Class Initialized
INFO - 2023-03-02 06:49:17 --> Router Class Initialized
INFO - 2023-03-02 06:49:17 --> Output Class Initialized
INFO - 2023-03-02 06:49:17 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:17 --> Input Class Initialized
INFO - 2023-03-02 06:49:17 --> Language Class Initialized
INFO - 2023-03-02 06:49:17 --> Loader Class Initialized
INFO - 2023-03-02 06:49:17 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:17 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:17 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:17 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:17 --> Model "Login_model" initialized
INFO - 2023-03-02 06:49:17 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:17 --> Total execution time: 0.0402
INFO - 2023-03-02 06:49:17 --> Config Class Initialized
INFO - 2023-03-02 06:49:17 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:17 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:17 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:17 --> URI Class Initialized
INFO - 2023-03-02 06:49:17 --> Router Class Initialized
INFO - 2023-03-02 06:49:17 --> Output Class Initialized
INFO - 2023-03-02 06:49:17 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:17 --> Input Class Initialized
INFO - 2023-03-02 06:49:17 --> Language Class Initialized
INFO - 2023-03-02 06:49:17 --> Loader Class Initialized
INFO - 2023-03-02 06:49:17 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:17 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:17 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:17 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:17 --> Model "Login_model" initialized
INFO - 2023-03-02 06:49:17 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:17 --> Total execution time: 0.0359
INFO - 2023-03-02 06:49:19 --> Config Class Initialized
INFO - 2023-03-02 06:49:19 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:19 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:19 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:19 --> URI Class Initialized
INFO - 2023-03-02 06:49:19 --> Router Class Initialized
INFO - 2023-03-02 06:49:19 --> Output Class Initialized
INFO - 2023-03-02 06:49:19 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:19 --> Input Class Initialized
INFO - 2023-03-02 06:49:19 --> Language Class Initialized
INFO - 2023-03-02 06:49:19 --> Loader Class Initialized
INFO - 2023-03-02 06:49:19 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:19 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:19 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:19 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:19 --> Model "Login_model" initialized
INFO - 2023-03-02 06:49:19 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:19 --> Total execution time: 0.0828
INFO - 2023-03-02 06:49:20 --> Config Class Initialized
INFO - 2023-03-02 06:49:20 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:20 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:20 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:20 --> URI Class Initialized
INFO - 2023-03-02 06:49:20 --> Router Class Initialized
INFO - 2023-03-02 06:49:20 --> Output Class Initialized
INFO - 2023-03-02 06:49:20 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:20 --> Input Class Initialized
INFO - 2023-03-02 06:49:20 --> Language Class Initialized
INFO - 2023-03-02 06:49:20 --> Loader Class Initialized
INFO - 2023-03-02 06:49:20 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:20 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:20 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:20 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:20 --> Total execution time: 0.0147
INFO - 2023-03-02 06:49:20 --> Config Class Initialized
INFO - 2023-03-02 06:49:20 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:20 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:20 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:20 --> URI Class Initialized
INFO - 2023-03-02 06:49:20 --> Router Class Initialized
INFO - 2023-03-02 06:49:20 --> Output Class Initialized
INFO - 2023-03-02 06:49:20 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:20 --> Input Class Initialized
INFO - 2023-03-02 06:49:20 --> Language Class Initialized
INFO - 2023-03-02 06:49:20 --> Loader Class Initialized
INFO - 2023-03-02 06:49:20 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:20 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:20 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:20 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:20 --> Total execution time: 0.0110
INFO - 2023-03-02 06:49:21 --> Config Class Initialized
INFO - 2023-03-02 06:49:21 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:21 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:21 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:21 --> URI Class Initialized
INFO - 2023-03-02 06:49:21 --> Router Class Initialized
INFO - 2023-03-02 06:49:21 --> Output Class Initialized
INFO - 2023-03-02 06:49:21 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:21 --> Input Class Initialized
INFO - 2023-03-02 06:49:21 --> Language Class Initialized
INFO - 2023-03-02 06:49:21 --> Loader Class Initialized
INFO - 2023-03-02 06:49:21 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:21 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:21 --> Model "Login_model" initialized
INFO - 2023-03-02 06:49:21 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:21 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:21 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:21 --> Total execution time: 0.0207
INFO - 2023-03-02 06:49:21 --> Config Class Initialized
INFO - 2023-03-02 06:49:21 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:21 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:21 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:21 --> URI Class Initialized
INFO - 2023-03-02 06:49:21 --> Router Class Initialized
INFO - 2023-03-02 06:49:21 --> Output Class Initialized
INFO - 2023-03-02 06:49:21 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:21 --> Input Class Initialized
INFO - 2023-03-02 06:49:21 --> Language Class Initialized
INFO - 2023-03-02 06:49:21 --> Loader Class Initialized
INFO - 2023-03-02 06:49:21 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:21 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:21 --> Model "Login_model" initialized
INFO - 2023-03-02 06:49:21 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:21 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:21 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:21 --> Total execution time: 0.0190
INFO - 2023-03-02 06:49:21 --> Config Class Initialized
INFO - 2023-03-02 06:49:21 --> Hooks Class Initialized
DEBUG - 2023-03-02 06:49:21 --> UTF-8 Support Enabled
INFO - 2023-03-02 06:49:21 --> Utf8 Class Initialized
INFO - 2023-03-02 06:49:21 --> URI Class Initialized
INFO - 2023-03-02 06:49:21 --> Router Class Initialized
INFO - 2023-03-02 06:49:21 --> Output Class Initialized
INFO - 2023-03-02 06:49:21 --> Security Class Initialized
DEBUG - 2023-03-02 06:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 06:49:21 --> Input Class Initialized
INFO - 2023-03-02 06:49:21 --> Language Class Initialized
INFO - 2023-03-02 06:49:21 --> Loader Class Initialized
INFO - 2023-03-02 06:49:21 --> Controller Class Initialized
DEBUG - 2023-03-02 06:49:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 06:49:21 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:21 --> Model "Cluster_model" initialized
INFO - 2023-03-02 06:49:21 --> Database Driver Class Initialized
INFO - 2023-03-02 06:49:21 --> Model "Login_model" initialized
INFO - 2023-03-02 06:49:21 --> Final output sent to browser
DEBUG - 2023-03-02 06:49:21 --> Total execution time: 0.0397
INFO - 2023-03-02 07:10:31 --> Config Class Initialized
INFO - 2023-03-02 07:10:31 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:10:31 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:10:31 --> Utf8 Class Initialized
INFO - 2023-03-02 07:10:31 --> URI Class Initialized
INFO - 2023-03-02 07:10:31 --> Router Class Initialized
INFO - 2023-03-02 07:10:31 --> Output Class Initialized
INFO - 2023-03-02 07:10:31 --> Security Class Initialized
DEBUG - 2023-03-02 07:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:10:31 --> Input Class Initialized
INFO - 2023-03-02 07:10:31 --> Language Class Initialized
INFO - 2023-03-02 07:10:31 --> Loader Class Initialized
INFO - 2023-03-02 07:10:31 --> Controller Class Initialized
DEBUG - 2023-03-02 07:10:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:10:31 --> Database Driver Class Initialized
INFO - 2023-03-02 07:10:31 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:10:31 --> Final output sent to browser
DEBUG - 2023-03-02 07:10:31 --> Total execution time: 0.0215
INFO - 2023-03-02 07:10:31 --> Config Class Initialized
INFO - 2023-03-02 07:10:31 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:10:31 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:10:31 --> Utf8 Class Initialized
INFO - 2023-03-02 07:10:31 --> URI Class Initialized
INFO - 2023-03-02 07:10:31 --> Router Class Initialized
INFO - 2023-03-02 07:10:31 --> Output Class Initialized
INFO - 2023-03-02 07:10:31 --> Security Class Initialized
DEBUG - 2023-03-02 07:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:10:31 --> Input Class Initialized
INFO - 2023-03-02 07:10:31 --> Language Class Initialized
INFO - 2023-03-02 07:10:31 --> Loader Class Initialized
INFO - 2023-03-02 07:10:31 --> Controller Class Initialized
DEBUG - 2023-03-02 07:10:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:10:31 --> Database Driver Class Initialized
INFO - 2023-03-02 07:10:31 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:10:31 --> Final output sent to browser
DEBUG - 2023-03-02 07:10:31 --> Total execution time: 0.0599
INFO - 2023-03-02 07:10:32 --> Config Class Initialized
INFO - 2023-03-02 07:10:32 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:10:32 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:10:32 --> Utf8 Class Initialized
INFO - 2023-03-02 07:10:32 --> URI Class Initialized
INFO - 2023-03-02 07:10:32 --> Router Class Initialized
INFO - 2023-03-02 07:10:32 --> Output Class Initialized
INFO - 2023-03-02 07:10:32 --> Security Class Initialized
DEBUG - 2023-03-02 07:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:10:32 --> Input Class Initialized
INFO - 2023-03-02 07:10:32 --> Language Class Initialized
INFO - 2023-03-02 07:10:32 --> Loader Class Initialized
INFO - 2023-03-02 07:10:32 --> Controller Class Initialized
DEBUG - 2023-03-02 07:10:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:10:32 --> Database Driver Class Initialized
INFO - 2023-03-02 07:10:32 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:10:32 --> Final output sent to browser
DEBUG - 2023-03-02 07:10:32 --> Total execution time: 0.0489
INFO - 2023-03-02 07:10:32 --> Config Class Initialized
INFO - 2023-03-02 07:10:32 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:10:32 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:10:32 --> Utf8 Class Initialized
INFO - 2023-03-02 07:10:32 --> URI Class Initialized
INFO - 2023-03-02 07:10:32 --> Router Class Initialized
INFO - 2023-03-02 07:10:32 --> Output Class Initialized
INFO - 2023-03-02 07:10:32 --> Security Class Initialized
DEBUG - 2023-03-02 07:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:10:32 --> Input Class Initialized
INFO - 2023-03-02 07:10:32 --> Language Class Initialized
INFO - 2023-03-02 07:10:32 --> Loader Class Initialized
INFO - 2023-03-02 07:10:32 --> Controller Class Initialized
DEBUG - 2023-03-02 07:10:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:10:32 --> Database Driver Class Initialized
INFO - 2023-03-02 07:10:32 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:10:32 --> Final output sent to browser
DEBUG - 2023-03-02 07:10:32 --> Total execution time: 0.0721
INFO - 2023-03-02 07:36:51 --> Config Class Initialized
INFO - 2023-03-02 07:36:51 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:36:51 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:36:51 --> Utf8 Class Initialized
INFO - 2023-03-02 07:36:51 --> URI Class Initialized
INFO - 2023-03-02 07:36:51 --> Router Class Initialized
INFO - 2023-03-02 07:36:51 --> Output Class Initialized
INFO - 2023-03-02 07:36:51 --> Security Class Initialized
DEBUG - 2023-03-02 07:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:36:51 --> Input Class Initialized
INFO - 2023-03-02 07:36:51 --> Language Class Initialized
INFO - 2023-03-02 07:36:51 --> Loader Class Initialized
INFO - 2023-03-02 07:36:51 --> Controller Class Initialized
DEBUG - 2023-03-02 07:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:36:51 --> Database Driver Class Initialized
INFO - 2023-03-02 07:36:51 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:36:51 --> Database Driver Class Initialized
INFO - 2023-03-02 07:36:51 --> Model "Login_model" initialized
INFO - 2023-03-02 07:36:51 --> Final output sent to browser
DEBUG - 2023-03-02 07:36:51 --> Total execution time: 0.0509
INFO - 2023-03-02 07:36:51 --> Config Class Initialized
INFO - 2023-03-02 07:36:51 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:36:51 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:36:51 --> Utf8 Class Initialized
INFO - 2023-03-02 07:36:51 --> URI Class Initialized
INFO - 2023-03-02 07:36:51 --> Router Class Initialized
INFO - 2023-03-02 07:36:51 --> Output Class Initialized
INFO - 2023-03-02 07:36:51 --> Security Class Initialized
DEBUG - 2023-03-02 07:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:36:51 --> Input Class Initialized
INFO - 2023-03-02 07:36:51 --> Language Class Initialized
INFO - 2023-03-02 07:36:51 --> Loader Class Initialized
INFO - 2023-03-02 07:36:51 --> Controller Class Initialized
DEBUG - 2023-03-02 07:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:36:51 --> Database Driver Class Initialized
INFO - 2023-03-02 07:36:51 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:36:51 --> Database Driver Class Initialized
INFO - 2023-03-02 07:36:51 --> Model "Login_model" initialized
INFO - 2023-03-02 07:36:51 --> Final output sent to browser
DEBUG - 2023-03-02 07:36:51 --> Total execution time: 0.1235
INFO - 2023-03-02 07:45:21 --> Config Class Initialized
INFO - 2023-03-02 07:45:21 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:45:21 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:45:21 --> Utf8 Class Initialized
INFO - 2023-03-02 07:45:21 --> URI Class Initialized
INFO - 2023-03-02 07:45:21 --> Router Class Initialized
INFO - 2023-03-02 07:45:21 --> Output Class Initialized
INFO - 2023-03-02 07:45:21 --> Security Class Initialized
DEBUG - 2023-03-02 07:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:45:21 --> Input Class Initialized
INFO - 2023-03-02 07:45:21 --> Language Class Initialized
INFO - 2023-03-02 07:45:21 --> Loader Class Initialized
INFO - 2023-03-02 07:45:21 --> Controller Class Initialized
DEBUG - 2023-03-02 07:45:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:45:21 --> Database Driver Class Initialized
INFO - 2023-03-02 07:45:21 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:45:21 --> Final output sent to browser
DEBUG - 2023-03-02 07:45:21 --> Total execution time: 0.0228
INFO - 2023-03-02 07:45:21 --> Config Class Initialized
INFO - 2023-03-02 07:45:21 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:45:21 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:45:21 --> Utf8 Class Initialized
INFO - 2023-03-02 07:45:21 --> URI Class Initialized
INFO - 2023-03-02 07:45:21 --> Router Class Initialized
INFO - 2023-03-02 07:45:21 --> Output Class Initialized
INFO - 2023-03-02 07:45:21 --> Security Class Initialized
DEBUG - 2023-03-02 07:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:45:21 --> Input Class Initialized
INFO - 2023-03-02 07:45:21 --> Language Class Initialized
INFO - 2023-03-02 07:45:21 --> Loader Class Initialized
INFO - 2023-03-02 07:45:21 --> Controller Class Initialized
DEBUG - 2023-03-02 07:45:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:45:21 --> Database Driver Class Initialized
INFO - 2023-03-02 07:45:21 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:45:21 --> Final output sent to browser
DEBUG - 2023-03-02 07:45:21 --> Total execution time: 0.0164
INFO - 2023-03-02 07:45:23 --> Config Class Initialized
INFO - 2023-03-02 07:45:23 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:45:23 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:45:23 --> Utf8 Class Initialized
INFO - 2023-03-02 07:45:23 --> URI Class Initialized
INFO - 2023-03-02 07:45:23 --> Router Class Initialized
INFO - 2023-03-02 07:45:23 --> Output Class Initialized
INFO - 2023-03-02 07:45:23 --> Security Class Initialized
DEBUG - 2023-03-02 07:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:45:23 --> Input Class Initialized
INFO - 2023-03-02 07:45:23 --> Language Class Initialized
INFO - 2023-03-02 07:45:23 --> Loader Class Initialized
INFO - 2023-03-02 07:45:23 --> Controller Class Initialized
DEBUG - 2023-03-02 07:45:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:45:23 --> Database Driver Class Initialized
INFO - 2023-03-02 07:45:23 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:45:23 --> Final output sent to browser
DEBUG - 2023-03-02 07:45:23 --> Total execution time: 0.0427
INFO - 2023-03-02 07:45:23 --> Config Class Initialized
INFO - 2023-03-02 07:45:23 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:45:23 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:45:23 --> Utf8 Class Initialized
INFO - 2023-03-02 07:45:23 --> URI Class Initialized
INFO - 2023-03-02 07:45:23 --> Router Class Initialized
INFO - 2023-03-02 07:45:23 --> Output Class Initialized
INFO - 2023-03-02 07:45:23 --> Security Class Initialized
DEBUG - 2023-03-02 07:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:45:23 --> Input Class Initialized
INFO - 2023-03-02 07:45:23 --> Language Class Initialized
INFO - 2023-03-02 07:45:23 --> Loader Class Initialized
INFO - 2023-03-02 07:45:23 --> Controller Class Initialized
DEBUG - 2023-03-02 07:45:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:45:23 --> Database Driver Class Initialized
INFO - 2023-03-02 07:45:23 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:45:23 --> Final output sent to browser
DEBUG - 2023-03-02 07:45:23 --> Total execution time: 0.2805
INFO - 2023-03-02 07:48:55 --> Config Class Initialized
INFO - 2023-03-02 07:48:55 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:48:55 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:48:55 --> Utf8 Class Initialized
INFO - 2023-03-02 07:48:55 --> URI Class Initialized
INFO - 2023-03-02 07:48:55 --> Router Class Initialized
INFO - 2023-03-02 07:48:55 --> Output Class Initialized
INFO - 2023-03-02 07:48:55 --> Security Class Initialized
DEBUG - 2023-03-02 07:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:48:55 --> Input Class Initialized
INFO - 2023-03-02 07:48:55 --> Language Class Initialized
INFO - 2023-03-02 07:48:55 --> Loader Class Initialized
INFO - 2023-03-02 07:48:55 --> Controller Class Initialized
DEBUG - 2023-03-02 07:48:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:48:55 --> Database Driver Class Initialized
INFO - 2023-03-02 07:48:55 --> Final output sent to browser
DEBUG - 2023-03-02 07:48:55 --> Total execution time: 0.0135
INFO - 2023-03-02 07:48:55 --> Config Class Initialized
INFO - 2023-03-02 07:48:55 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:48:55 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:48:55 --> Utf8 Class Initialized
INFO - 2023-03-02 07:48:55 --> URI Class Initialized
INFO - 2023-03-02 07:48:55 --> Router Class Initialized
INFO - 2023-03-02 07:48:55 --> Output Class Initialized
INFO - 2023-03-02 07:48:55 --> Security Class Initialized
DEBUG - 2023-03-02 07:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:48:55 --> Input Class Initialized
INFO - 2023-03-02 07:48:55 --> Language Class Initialized
INFO - 2023-03-02 07:48:55 --> Loader Class Initialized
INFO - 2023-03-02 07:48:55 --> Controller Class Initialized
DEBUG - 2023-03-02 07:48:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:48:55 --> Database Driver Class Initialized
INFO - 2023-03-02 07:48:55 --> Final output sent to browser
DEBUG - 2023-03-02 07:48:55 --> Total execution time: 0.0193
INFO - 2023-03-02 07:49:20 --> Config Class Initialized
INFO - 2023-03-02 07:49:20 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:49:20 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:49:20 --> Utf8 Class Initialized
INFO - 2023-03-02 07:49:20 --> URI Class Initialized
INFO - 2023-03-02 07:49:20 --> Router Class Initialized
INFO - 2023-03-02 07:49:20 --> Output Class Initialized
INFO - 2023-03-02 07:49:20 --> Security Class Initialized
DEBUG - 2023-03-02 07:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:49:20 --> Input Class Initialized
INFO - 2023-03-02 07:49:20 --> Language Class Initialized
INFO - 2023-03-02 07:49:20 --> Loader Class Initialized
INFO - 2023-03-02 07:49:20 --> Controller Class Initialized
DEBUG - 2023-03-02 07:49:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:49:20 --> Database Driver Class Initialized
INFO - 2023-03-02 07:49:20 --> Final output sent to browser
DEBUG - 2023-03-02 07:49:20 --> Total execution time: 0.0103
INFO - 2023-03-02 07:49:20 --> Config Class Initialized
INFO - 2023-03-02 07:49:20 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:49:20 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:49:20 --> Utf8 Class Initialized
INFO - 2023-03-02 07:49:20 --> URI Class Initialized
INFO - 2023-03-02 07:49:20 --> Router Class Initialized
INFO - 2023-03-02 07:49:20 --> Output Class Initialized
INFO - 2023-03-02 07:49:20 --> Security Class Initialized
DEBUG - 2023-03-02 07:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:49:20 --> Input Class Initialized
INFO - 2023-03-02 07:49:20 --> Language Class Initialized
INFO - 2023-03-02 07:49:20 --> Loader Class Initialized
INFO - 2023-03-02 07:49:20 --> Controller Class Initialized
DEBUG - 2023-03-02 07:49:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:49:20 --> Database Driver Class Initialized
INFO - 2023-03-02 07:49:21 --> Final output sent to browser
DEBUG - 2023-03-02 07:49:21 --> Total execution time: 1.1347
INFO - 2023-03-02 07:51:24 --> Config Class Initialized
INFO - 2023-03-02 07:51:24 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:51:24 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:51:24 --> Utf8 Class Initialized
INFO - 2023-03-02 07:51:24 --> URI Class Initialized
INFO - 2023-03-02 07:51:24 --> Router Class Initialized
INFO - 2023-03-02 07:51:24 --> Output Class Initialized
INFO - 2023-03-02 07:51:24 --> Security Class Initialized
DEBUG - 2023-03-02 07:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:51:24 --> Input Class Initialized
INFO - 2023-03-02 07:51:24 --> Language Class Initialized
INFO - 2023-03-02 07:51:24 --> Loader Class Initialized
INFO - 2023-03-02 07:51:24 --> Controller Class Initialized
DEBUG - 2023-03-02 07:51:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:51:24 --> Database Driver Class Initialized
INFO - 2023-03-02 07:51:24 --> Final output sent to browser
DEBUG - 2023-03-02 07:51:24 --> Total execution time: 0.0114
INFO - 2023-03-02 07:51:24 --> Config Class Initialized
INFO - 2023-03-02 07:51:24 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:51:24 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:51:24 --> Utf8 Class Initialized
INFO - 2023-03-02 07:51:24 --> URI Class Initialized
INFO - 2023-03-02 07:51:24 --> Router Class Initialized
INFO - 2023-03-02 07:51:24 --> Output Class Initialized
INFO - 2023-03-02 07:51:24 --> Security Class Initialized
DEBUG - 2023-03-02 07:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:51:24 --> Input Class Initialized
INFO - 2023-03-02 07:51:24 --> Language Class Initialized
INFO - 2023-03-02 07:51:24 --> Loader Class Initialized
INFO - 2023-03-02 07:51:24 --> Controller Class Initialized
DEBUG - 2023-03-02 07:51:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:51:24 --> Database Driver Class Initialized
INFO - 2023-03-02 07:51:24 --> Final output sent to browser
DEBUG - 2023-03-02 07:51:24 --> Total execution time: 0.0138
INFO - 2023-03-02 07:58:47 --> Config Class Initialized
INFO - 2023-03-02 07:58:47 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:58:47 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:58:47 --> Utf8 Class Initialized
INFO - 2023-03-02 07:58:47 --> URI Class Initialized
INFO - 2023-03-02 07:58:47 --> Router Class Initialized
INFO - 2023-03-02 07:58:47 --> Output Class Initialized
INFO - 2023-03-02 07:58:47 --> Security Class Initialized
DEBUG - 2023-03-02 07:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:58:47 --> Input Class Initialized
INFO - 2023-03-02 07:58:47 --> Language Class Initialized
INFO - 2023-03-02 07:58:47 --> Loader Class Initialized
INFO - 2023-03-02 07:58:47 --> Controller Class Initialized
INFO - 2023-03-02 07:58:47 --> Helper loaded: form_helper
INFO - 2023-03-02 07:58:47 --> Helper loaded: url_helper
DEBUG - 2023-03-02 07:58:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:58:47 --> Model "Change_model" initialized
INFO - 2023-03-02 07:58:47 --> Model "Grafana_model" initialized
INFO - 2023-03-02 07:58:47 --> Final output sent to browser
DEBUG - 2023-03-02 07:58:47 --> Total execution time: 0.0318
INFO - 2023-03-02 07:58:47 --> Config Class Initialized
INFO - 2023-03-02 07:58:47 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:58:47 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:58:47 --> Utf8 Class Initialized
INFO - 2023-03-02 07:58:47 --> URI Class Initialized
INFO - 2023-03-02 07:58:47 --> Router Class Initialized
INFO - 2023-03-02 07:58:47 --> Output Class Initialized
INFO - 2023-03-02 07:58:47 --> Security Class Initialized
DEBUG - 2023-03-02 07:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:58:47 --> Input Class Initialized
INFO - 2023-03-02 07:58:47 --> Language Class Initialized
INFO - 2023-03-02 07:58:47 --> Loader Class Initialized
INFO - 2023-03-02 07:58:47 --> Controller Class Initialized
INFO - 2023-03-02 07:58:47 --> Helper loaded: form_helper
INFO - 2023-03-02 07:58:47 --> Helper loaded: url_helper
DEBUG - 2023-03-02 07:58:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:58:47 --> Final output sent to browser
DEBUG - 2023-03-02 07:58:47 --> Total execution time: 0.0030
INFO - 2023-03-02 07:58:47 --> Config Class Initialized
INFO - 2023-03-02 07:58:47 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:58:47 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:58:47 --> Utf8 Class Initialized
INFO - 2023-03-02 07:58:47 --> URI Class Initialized
INFO - 2023-03-02 07:58:47 --> Router Class Initialized
INFO - 2023-03-02 07:58:47 --> Output Class Initialized
INFO - 2023-03-02 07:58:47 --> Security Class Initialized
DEBUG - 2023-03-02 07:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:58:47 --> Input Class Initialized
INFO - 2023-03-02 07:58:47 --> Language Class Initialized
INFO - 2023-03-02 07:58:47 --> Loader Class Initialized
INFO - 2023-03-02 07:58:47 --> Controller Class Initialized
INFO - 2023-03-02 07:58:47 --> Helper loaded: form_helper
INFO - 2023-03-02 07:58:47 --> Helper loaded: url_helper
DEBUG - 2023-03-02 07:58:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:58:47 --> Database Driver Class Initialized
INFO - 2023-03-02 07:58:47 --> Model "Login_model" initialized
INFO - 2023-03-02 07:58:47 --> Final output sent to browser
DEBUG - 2023-03-02 07:58:47 --> Total execution time: 0.0191
INFO - 2023-03-02 07:58:47 --> Config Class Initialized
INFO - 2023-03-02 07:58:47 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:58:47 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:58:47 --> Utf8 Class Initialized
INFO - 2023-03-02 07:58:47 --> URI Class Initialized
INFO - 2023-03-02 07:58:47 --> Router Class Initialized
INFO - 2023-03-02 07:58:47 --> Output Class Initialized
INFO - 2023-03-02 07:58:47 --> Security Class Initialized
DEBUG - 2023-03-02 07:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:58:47 --> Input Class Initialized
INFO - 2023-03-02 07:58:47 --> Language Class Initialized
INFO - 2023-03-02 07:58:47 --> Loader Class Initialized
INFO - 2023-03-02 07:58:47 --> Controller Class Initialized
DEBUG - 2023-03-02 07:58:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:58:47 --> Database Driver Class Initialized
INFO - 2023-03-02 07:58:47 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:58:47 --> Final output sent to browser
DEBUG - 2023-03-02 07:58:47 --> Total execution time: 0.0542
INFO - 2023-03-02 07:58:47 --> Config Class Initialized
INFO - 2023-03-02 07:58:47 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:58:47 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:58:47 --> Utf8 Class Initialized
INFO - 2023-03-02 07:58:47 --> URI Class Initialized
INFO - 2023-03-02 07:58:47 --> Router Class Initialized
INFO - 2023-03-02 07:58:47 --> Output Class Initialized
INFO - 2023-03-02 07:58:47 --> Security Class Initialized
DEBUG - 2023-03-02 07:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:58:47 --> Input Class Initialized
INFO - 2023-03-02 07:58:47 --> Language Class Initialized
INFO - 2023-03-02 07:58:47 --> Loader Class Initialized
INFO - 2023-03-02 07:58:47 --> Controller Class Initialized
DEBUG - 2023-03-02 07:58:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:58:47 --> Database Driver Class Initialized
INFO - 2023-03-02 07:58:47 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:58:49 --> Config Class Initialized
INFO - 2023-03-02 07:58:49 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:58:49 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:58:49 --> Utf8 Class Initialized
INFO - 2023-03-02 07:58:49 --> URI Class Initialized
INFO - 2023-03-02 07:58:49 --> Router Class Initialized
INFO - 2023-03-02 07:58:49 --> Output Class Initialized
INFO - 2023-03-02 07:58:49 --> Security Class Initialized
DEBUG - 2023-03-02 07:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:58:49 --> Input Class Initialized
INFO - 2023-03-02 07:58:49 --> Language Class Initialized
INFO - 2023-03-02 07:58:49 --> Loader Class Initialized
INFO - 2023-03-02 07:58:49 --> Controller Class Initialized
INFO - 2023-03-02 07:58:49 --> Helper loaded: form_helper
INFO - 2023-03-02 07:58:49 --> Helper loaded: url_helper
DEBUG - 2023-03-02 07:58:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:58:49 --> Model "Change_model" initialized
INFO - 2023-03-02 07:58:49 --> Model "Grafana_model" initialized
INFO - 2023-03-02 07:58:49 --> Final output sent to browser
DEBUG - 2023-03-02 07:58:49 --> Total execution time: 0.0287
INFO - 2023-03-02 07:58:49 --> Config Class Initialized
INFO - 2023-03-02 07:58:49 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:58:49 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:58:49 --> Utf8 Class Initialized
INFO - 2023-03-02 07:58:49 --> URI Class Initialized
INFO - 2023-03-02 07:58:49 --> Router Class Initialized
INFO - 2023-03-02 07:58:49 --> Output Class Initialized
INFO - 2023-03-02 07:58:49 --> Security Class Initialized
DEBUG - 2023-03-02 07:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:58:49 --> Input Class Initialized
INFO - 2023-03-02 07:58:49 --> Language Class Initialized
INFO - 2023-03-02 07:58:49 --> Loader Class Initialized
INFO - 2023-03-02 07:58:49 --> Controller Class Initialized
INFO - 2023-03-02 07:58:49 --> Helper loaded: form_helper
INFO - 2023-03-02 07:58:49 --> Helper loaded: url_helper
DEBUG - 2023-03-02 07:58:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:58:49 --> Database Driver Class Initialized
INFO - 2023-03-02 07:58:49 --> Model "Login_model" initialized
INFO - 2023-03-02 07:58:49 --> Final output sent to browser
DEBUG - 2023-03-02 07:58:49 --> Total execution time: 0.0583
INFO - 2023-03-02 07:58:49 --> Config Class Initialized
INFO - 2023-03-02 07:58:49 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:58:49 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:58:49 --> Utf8 Class Initialized
INFO - 2023-03-02 07:58:49 --> URI Class Initialized
INFO - 2023-03-02 07:58:49 --> Router Class Initialized
INFO - 2023-03-02 07:58:49 --> Output Class Initialized
INFO - 2023-03-02 07:58:49 --> Security Class Initialized
DEBUG - 2023-03-02 07:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:58:49 --> Input Class Initialized
INFO - 2023-03-02 07:58:49 --> Language Class Initialized
INFO - 2023-03-02 07:58:49 --> Loader Class Initialized
INFO - 2023-03-02 07:58:49 --> Controller Class Initialized
DEBUG - 2023-03-02 07:58:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:58:49 --> Database Driver Class Initialized
INFO - 2023-03-02 07:58:49 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:59:00 --> Final output sent to browser
INFO - 2023-03-02 07:59:00 --> Final output sent to browser
DEBUG - 2023-03-02 07:59:00 --> Total execution time: 11.1960
DEBUG - 2023-03-02 07:59:00 --> Total execution time: 12.8773
INFO - 2023-03-02 07:59:01 --> Config Class Initialized
INFO - 2023-03-02 07:59:01 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:59:01 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:59:01 --> Utf8 Class Initialized
INFO - 2023-03-02 07:59:01 --> URI Class Initialized
INFO - 2023-03-02 07:59:01 --> Router Class Initialized
INFO - 2023-03-02 07:59:01 --> Output Class Initialized
INFO - 2023-03-02 07:59:01 --> Security Class Initialized
DEBUG - 2023-03-02 07:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:59:01 --> Input Class Initialized
INFO - 2023-03-02 07:59:01 --> Language Class Initialized
INFO - 2023-03-02 07:59:01 --> Loader Class Initialized
INFO - 2023-03-02 07:59:01 --> Controller Class Initialized
DEBUG - 2023-03-02 07:59:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:59:01 --> Database Driver Class Initialized
INFO - 2023-03-02 07:59:01 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:59:01 --> Database Driver Class Initialized
INFO - 2023-03-02 07:59:01 --> Model "Login_model" initialized
INFO - 2023-03-02 07:59:01 --> Final output sent to browser
DEBUG - 2023-03-02 07:59:01 --> Total execution time: 0.3298
INFO - 2023-03-02 07:59:01 --> Config Class Initialized
INFO - 2023-03-02 07:59:01 --> Hooks Class Initialized
DEBUG - 2023-03-02 07:59:01 --> UTF-8 Support Enabled
INFO - 2023-03-02 07:59:01 --> Utf8 Class Initialized
INFO - 2023-03-02 07:59:01 --> URI Class Initialized
INFO - 2023-03-02 07:59:01 --> Router Class Initialized
INFO - 2023-03-02 07:59:01 --> Output Class Initialized
INFO - 2023-03-02 07:59:01 --> Security Class Initialized
DEBUG - 2023-03-02 07:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 07:59:01 --> Input Class Initialized
INFO - 2023-03-02 07:59:01 --> Language Class Initialized
INFO - 2023-03-02 07:59:01 --> Loader Class Initialized
INFO - 2023-03-02 07:59:01 --> Controller Class Initialized
DEBUG - 2023-03-02 07:59:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 07:59:01 --> Database Driver Class Initialized
INFO - 2023-03-02 07:59:01 --> Model "Cluster_model" initialized
INFO - 2023-03-02 07:59:01 --> Database Driver Class Initialized
INFO - 2023-03-02 07:59:01 --> Model "Login_model" initialized
INFO - 2023-03-02 07:59:01 --> Final output sent to browser
DEBUG - 2023-03-02 07:59:01 --> Total execution time: 0.1664
INFO - 2023-03-02 08:00:20 --> Config Class Initialized
INFO - 2023-03-02 08:00:20 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:00:20 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:00:20 --> Utf8 Class Initialized
INFO - 2023-03-02 08:00:20 --> URI Class Initialized
INFO - 2023-03-02 08:00:20 --> Router Class Initialized
INFO - 2023-03-02 08:00:20 --> Output Class Initialized
INFO - 2023-03-02 08:00:20 --> Security Class Initialized
DEBUG - 2023-03-02 08:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:00:20 --> Input Class Initialized
INFO - 2023-03-02 08:00:20 --> Language Class Initialized
INFO - 2023-03-02 08:00:20 --> Loader Class Initialized
INFO - 2023-03-02 08:00:20 --> Controller Class Initialized
DEBUG - 2023-03-02 08:00:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:00:20 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:20 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:00:20 --> Final output sent to browser
INFO - 2023-03-02 08:00:20 --> Config Class Initialized
DEBUG - 2023-03-02 08:00:20 --> Total execution time: 0.0484
INFO - 2023-03-02 08:00:20 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:00:20 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:00:20 --> Utf8 Class Initialized
INFO - 2023-03-02 08:00:20 --> URI Class Initialized
INFO - 2023-03-02 08:00:20 --> Router Class Initialized
INFO - 2023-03-02 08:00:20 --> Output Class Initialized
INFO - 2023-03-02 08:00:20 --> Security Class Initialized
DEBUG - 2023-03-02 08:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:00:20 --> Input Class Initialized
INFO - 2023-03-02 08:00:20 --> Language Class Initialized
INFO - 2023-03-02 08:00:20 --> Loader Class Initialized
INFO - 2023-03-02 08:00:20 --> Controller Class Initialized
DEBUG - 2023-03-02 08:00:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:00:20 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:20 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:00:20 --> Final output sent to browser
DEBUG - 2023-03-02 08:00:20 --> Total execution time: 0.0825
INFO - 2023-03-02 08:00:24 --> Config Class Initialized
INFO - 2023-03-02 08:00:24 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:00:24 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:00:24 --> Utf8 Class Initialized
INFO - 2023-03-02 08:00:24 --> URI Class Initialized
INFO - 2023-03-02 08:00:24 --> Router Class Initialized
INFO - 2023-03-02 08:00:24 --> Output Class Initialized
INFO - 2023-03-02 08:00:24 --> Security Class Initialized
DEBUG - 2023-03-02 08:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:00:24 --> Input Class Initialized
INFO - 2023-03-02 08:00:24 --> Language Class Initialized
INFO - 2023-03-02 08:00:24 --> Loader Class Initialized
INFO - 2023-03-02 08:00:24 --> Controller Class Initialized
DEBUG - 2023-03-02 08:00:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:00:24 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:24 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:00:24 --> Final output sent to browser
DEBUG - 2023-03-02 08:00:24 --> Total execution time: 0.0156
INFO - 2023-03-02 08:00:24 --> Config Class Initialized
INFO - 2023-03-02 08:00:24 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:00:24 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:00:24 --> Utf8 Class Initialized
INFO - 2023-03-02 08:00:24 --> URI Class Initialized
INFO - 2023-03-02 08:00:24 --> Router Class Initialized
INFO - 2023-03-02 08:00:24 --> Output Class Initialized
INFO - 2023-03-02 08:00:24 --> Security Class Initialized
DEBUG - 2023-03-02 08:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:00:24 --> Input Class Initialized
INFO - 2023-03-02 08:00:24 --> Language Class Initialized
INFO - 2023-03-02 08:00:24 --> Loader Class Initialized
INFO - 2023-03-02 08:00:24 --> Controller Class Initialized
DEBUG - 2023-03-02 08:00:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:00:24 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:24 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:00:24 --> Final output sent to browser
DEBUG - 2023-03-02 08:00:24 --> Total execution time: 0.0553
INFO - 2023-03-02 08:00:25 --> Config Class Initialized
INFO - 2023-03-02 08:00:25 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:00:25 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:00:25 --> Utf8 Class Initialized
INFO - 2023-03-02 08:00:25 --> URI Class Initialized
INFO - 2023-03-02 08:00:25 --> Router Class Initialized
INFO - 2023-03-02 08:00:25 --> Output Class Initialized
INFO - 2023-03-02 08:00:25 --> Security Class Initialized
DEBUG - 2023-03-02 08:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:00:25 --> Input Class Initialized
INFO - 2023-03-02 08:00:25 --> Language Class Initialized
INFO - 2023-03-02 08:00:25 --> Loader Class Initialized
INFO - 2023-03-02 08:00:25 --> Controller Class Initialized
DEBUG - 2023-03-02 08:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:00:25 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:25 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:00:25 --> Final output sent to browser
DEBUG - 2023-03-02 08:00:25 --> Total execution time: 0.0311
INFO - 2023-03-02 08:00:25 --> Config Class Initialized
INFO - 2023-03-02 08:00:25 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:00:25 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:00:25 --> Utf8 Class Initialized
INFO - 2023-03-02 08:00:25 --> URI Class Initialized
INFO - 2023-03-02 08:00:25 --> Router Class Initialized
INFO - 2023-03-02 08:00:25 --> Output Class Initialized
INFO - 2023-03-02 08:00:25 --> Security Class Initialized
DEBUG - 2023-03-02 08:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:00:25 --> Input Class Initialized
INFO - 2023-03-02 08:00:25 --> Language Class Initialized
INFO - 2023-03-02 08:00:25 --> Loader Class Initialized
INFO - 2023-03-02 08:00:25 --> Controller Class Initialized
DEBUG - 2023-03-02 08:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:00:25 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:25 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:00:25 --> Final output sent to browser
DEBUG - 2023-03-02 08:00:25 --> Total execution time: 0.0644
INFO - 2023-03-02 08:00:27 --> Config Class Initialized
INFO - 2023-03-02 08:00:27 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:00:27 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:00:27 --> Utf8 Class Initialized
INFO - 2023-03-02 08:00:27 --> URI Class Initialized
INFO - 2023-03-02 08:00:27 --> Router Class Initialized
INFO - 2023-03-02 08:00:27 --> Output Class Initialized
INFO - 2023-03-02 08:00:27 --> Security Class Initialized
DEBUG - 2023-03-02 08:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:00:27 --> Input Class Initialized
INFO - 2023-03-02 08:00:27 --> Language Class Initialized
INFO - 2023-03-02 08:00:27 --> Loader Class Initialized
INFO - 2023-03-02 08:00:27 --> Controller Class Initialized
DEBUG - 2023-03-02 08:00:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:00:27 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:27 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:27 --> Model "Login_model" initialized
INFO - 2023-03-02 08:00:27 --> Final output sent to browser
DEBUG - 2023-03-02 08:00:27 --> Total execution time: 0.1337
INFO - 2023-03-02 08:00:27 --> Config Class Initialized
INFO - 2023-03-02 08:00:27 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:00:27 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:00:27 --> Utf8 Class Initialized
INFO - 2023-03-02 08:00:27 --> URI Class Initialized
INFO - 2023-03-02 08:00:27 --> Router Class Initialized
INFO - 2023-03-02 08:00:27 --> Output Class Initialized
INFO - 2023-03-02 08:00:27 --> Security Class Initialized
DEBUG - 2023-03-02 08:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:00:27 --> Input Class Initialized
INFO - 2023-03-02 08:00:27 --> Language Class Initialized
INFO - 2023-03-02 08:00:27 --> Loader Class Initialized
INFO - 2023-03-02 08:00:27 --> Controller Class Initialized
DEBUG - 2023-03-02 08:00:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:00:27 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:27 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:27 --> Model "Login_model" initialized
INFO - 2023-03-02 08:00:27 --> Final output sent to browser
DEBUG - 2023-03-02 08:00:27 --> Total execution time: 0.0444
INFO - 2023-03-02 08:00:28 --> Config Class Initialized
INFO - 2023-03-02 08:00:28 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:00:28 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:00:28 --> Utf8 Class Initialized
INFO - 2023-03-02 08:00:28 --> URI Class Initialized
INFO - 2023-03-02 08:00:28 --> Router Class Initialized
INFO - 2023-03-02 08:00:28 --> Output Class Initialized
INFO - 2023-03-02 08:00:28 --> Security Class Initialized
DEBUG - 2023-03-02 08:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:00:28 --> Input Class Initialized
INFO - 2023-03-02 08:00:28 --> Language Class Initialized
INFO - 2023-03-02 08:00:28 --> Loader Class Initialized
INFO - 2023-03-02 08:00:28 --> Controller Class Initialized
DEBUG - 2023-03-02 08:00:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:00:28 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:28 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:00:28 --> Final output sent to browser
DEBUG - 2023-03-02 08:00:28 --> Total execution time: 0.0552
INFO - 2023-03-02 08:00:28 --> Config Class Initialized
INFO - 2023-03-02 08:00:28 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:00:28 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:00:28 --> Utf8 Class Initialized
INFO - 2023-03-02 08:00:28 --> URI Class Initialized
INFO - 2023-03-02 08:00:28 --> Router Class Initialized
INFO - 2023-03-02 08:00:28 --> Output Class Initialized
INFO - 2023-03-02 08:00:28 --> Security Class Initialized
DEBUG - 2023-03-02 08:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:00:28 --> Input Class Initialized
INFO - 2023-03-02 08:00:28 --> Language Class Initialized
INFO - 2023-03-02 08:00:28 --> Loader Class Initialized
INFO - 2023-03-02 08:00:28 --> Controller Class Initialized
DEBUG - 2023-03-02 08:00:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:00:28 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:28 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:00:28 --> Final output sent to browser
DEBUG - 2023-03-02 08:00:28 --> Total execution time: 0.0710
INFO - 2023-03-02 08:00:29 --> Config Class Initialized
INFO - 2023-03-02 08:00:29 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:00:29 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:00:29 --> Utf8 Class Initialized
INFO - 2023-03-02 08:00:29 --> URI Class Initialized
INFO - 2023-03-02 08:00:29 --> Router Class Initialized
INFO - 2023-03-02 08:00:29 --> Output Class Initialized
INFO - 2023-03-02 08:00:29 --> Security Class Initialized
DEBUG - 2023-03-02 08:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:00:29 --> Input Class Initialized
INFO - 2023-03-02 08:00:29 --> Language Class Initialized
INFO - 2023-03-02 08:00:29 --> Loader Class Initialized
INFO - 2023-03-02 08:00:29 --> Controller Class Initialized
DEBUG - 2023-03-02 08:00:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:00:29 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:29 --> Database Driver Class Initialized
INFO - 2023-03-02 08:00:29 --> Model "Login_model" initialized
INFO - 2023-03-02 08:00:29 --> Final output sent to browser
DEBUG - 2023-03-02 08:00:29 --> Total execution time: 0.0355
INFO - 2023-03-02 08:05:28 --> Config Class Initialized
INFO - 2023-03-02 08:05:28 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:05:28 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:05:28 --> Utf8 Class Initialized
INFO - 2023-03-02 08:05:28 --> URI Class Initialized
INFO - 2023-03-02 08:05:28 --> Router Class Initialized
INFO - 2023-03-02 08:05:28 --> Output Class Initialized
INFO - 2023-03-02 08:05:28 --> Security Class Initialized
DEBUG - 2023-03-02 08:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:05:28 --> Input Class Initialized
INFO - 2023-03-02 08:05:28 --> Language Class Initialized
INFO - 2023-03-02 08:05:28 --> Loader Class Initialized
INFO - 2023-03-02 08:05:28 --> Controller Class Initialized
DEBUG - 2023-03-02 08:05:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:05:28 --> Database Driver Class Initialized
INFO - 2023-03-02 08:05:28 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:05:28 --> Final output sent to browser
DEBUG - 2023-03-02 08:05:28 --> Total execution time: 0.0155
INFO - 2023-03-02 08:05:28 --> Config Class Initialized
INFO - 2023-03-02 08:05:28 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:05:28 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:05:28 --> Utf8 Class Initialized
INFO - 2023-03-02 08:05:28 --> URI Class Initialized
INFO - 2023-03-02 08:05:28 --> Router Class Initialized
INFO - 2023-03-02 08:05:28 --> Output Class Initialized
INFO - 2023-03-02 08:05:28 --> Security Class Initialized
DEBUG - 2023-03-02 08:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:05:28 --> Input Class Initialized
INFO - 2023-03-02 08:05:28 --> Language Class Initialized
INFO - 2023-03-02 08:05:28 --> Loader Class Initialized
INFO - 2023-03-02 08:05:28 --> Controller Class Initialized
DEBUG - 2023-03-02 08:05:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:05:28 --> Database Driver Class Initialized
INFO - 2023-03-02 08:05:28 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:05:28 --> Final output sent to browser
DEBUG - 2023-03-02 08:05:28 --> Total execution time: 0.0559
INFO - 2023-03-02 08:05:29 --> Config Class Initialized
INFO - 2023-03-02 08:05:29 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:05:29 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:05:29 --> Utf8 Class Initialized
INFO - 2023-03-02 08:05:29 --> URI Class Initialized
INFO - 2023-03-02 08:05:29 --> Router Class Initialized
INFO - 2023-03-02 08:05:29 --> Output Class Initialized
INFO - 2023-03-02 08:05:29 --> Security Class Initialized
DEBUG - 2023-03-02 08:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:05:29 --> Input Class Initialized
INFO - 2023-03-02 08:05:29 --> Language Class Initialized
INFO - 2023-03-02 08:05:29 --> Loader Class Initialized
INFO - 2023-03-02 08:05:29 --> Controller Class Initialized
DEBUG - 2023-03-02 08:05:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:05:29 --> Database Driver Class Initialized
INFO - 2023-03-02 08:05:29 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:05:29 --> Final output sent to browser
DEBUG - 2023-03-02 08:05:29 --> Total execution time: 0.0530
INFO - 2023-03-02 08:05:29 --> Config Class Initialized
INFO - 2023-03-02 08:05:29 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:05:29 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:05:29 --> Utf8 Class Initialized
INFO - 2023-03-02 08:05:29 --> URI Class Initialized
INFO - 2023-03-02 08:05:29 --> Router Class Initialized
INFO - 2023-03-02 08:05:29 --> Output Class Initialized
INFO - 2023-03-02 08:05:29 --> Security Class Initialized
DEBUG - 2023-03-02 08:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:05:29 --> Input Class Initialized
INFO - 2023-03-02 08:05:29 --> Language Class Initialized
INFO - 2023-03-02 08:05:29 --> Loader Class Initialized
INFO - 2023-03-02 08:05:29 --> Controller Class Initialized
DEBUG - 2023-03-02 08:05:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:05:29 --> Database Driver Class Initialized
INFO - 2023-03-02 08:05:29 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:05:29 --> Final output sent to browser
DEBUG - 2023-03-02 08:05:29 --> Total execution time: 0.1241
INFO - 2023-03-02 08:08:40 --> Config Class Initialized
INFO - 2023-03-02 08:08:40 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:08:40 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:08:40 --> Utf8 Class Initialized
INFO - 2023-03-02 08:08:40 --> URI Class Initialized
INFO - 2023-03-02 08:08:40 --> Router Class Initialized
INFO - 2023-03-02 08:08:40 --> Output Class Initialized
INFO - 2023-03-02 08:08:40 --> Security Class Initialized
DEBUG - 2023-03-02 08:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:08:40 --> Input Class Initialized
INFO - 2023-03-02 08:08:40 --> Language Class Initialized
INFO - 2023-03-02 08:08:40 --> Loader Class Initialized
INFO - 2023-03-02 08:08:40 --> Controller Class Initialized
DEBUG - 2023-03-02 08:08:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:08:40 --> Database Driver Class Initialized
INFO - 2023-03-02 08:08:40 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:08:40 --> Database Driver Class Initialized
INFO - 2023-03-02 08:08:40 --> Model "Login_model" initialized
INFO - 2023-03-02 08:08:40 --> Final output sent to browser
DEBUG - 2023-03-02 08:08:40 --> Total execution time: 0.0502
INFO - 2023-03-02 08:08:40 --> Config Class Initialized
INFO - 2023-03-02 08:08:40 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:08:40 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:08:40 --> Utf8 Class Initialized
INFO - 2023-03-02 08:08:40 --> URI Class Initialized
INFO - 2023-03-02 08:08:40 --> Router Class Initialized
INFO - 2023-03-02 08:08:40 --> Output Class Initialized
INFO - 2023-03-02 08:08:40 --> Security Class Initialized
DEBUG - 2023-03-02 08:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:08:40 --> Input Class Initialized
INFO - 2023-03-02 08:08:40 --> Language Class Initialized
INFO - 2023-03-02 08:08:40 --> Loader Class Initialized
INFO - 2023-03-02 08:08:40 --> Controller Class Initialized
DEBUG - 2023-03-02 08:08:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:08:40 --> Database Driver Class Initialized
INFO - 2023-03-02 08:08:40 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:08:40 --> Database Driver Class Initialized
INFO - 2023-03-02 08:08:40 --> Model "Login_model" initialized
INFO - 2023-03-02 08:08:40 --> Final output sent to browser
DEBUG - 2023-03-02 08:08:40 --> Total execution time: 0.0888
INFO - 2023-03-02 08:10:00 --> Config Class Initialized
INFO - 2023-03-02 08:10:00 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:10:00 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:10:00 --> Utf8 Class Initialized
INFO - 2023-03-02 08:10:00 --> URI Class Initialized
INFO - 2023-03-02 08:10:00 --> Router Class Initialized
INFO - 2023-03-02 08:10:00 --> Output Class Initialized
INFO - 2023-03-02 08:10:00 --> Security Class Initialized
DEBUG - 2023-03-02 08:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:10:00 --> Input Class Initialized
INFO - 2023-03-02 08:10:00 --> Language Class Initialized
INFO - 2023-03-02 08:10:00 --> Loader Class Initialized
INFO - 2023-03-02 08:10:00 --> Controller Class Initialized
DEBUG - 2023-03-02 08:10:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:10:00 --> Database Driver Class Initialized
INFO - 2023-03-02 08:10:00 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:10:00 --> Final output sent to browser
DEBUG - 2023-03-02 08:10:00 --> Total execution time: 0.0180
INFO - 2023-03-02 08:10:00 --> Config Class Initialized
INFO - 2023-03-02 08:10:00 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:10:00 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:10:00 --> Utf8 Class Initialized
INFO - 2023-03-02 08:10:00 --> URI Class Initialized
INFO - 2023-03-02 08:10:00 --> Router Class Initialized
INFO - 2023-03-02 08:10:00 --> Output Class Initialized
INFO - 2023-03-02 08:10:00 --> Security Class Initialized
DEBUG - 2023-03-02 08:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:10:00 --> Input Class Initialized
INFO - 2023-03-02 08:10:00 --> Language Class Initialized
INFO - 2023-03-02 08:10:00 --> Loader Class Initialized
INFO - 2023-03-02 08:10:00 --> Controller Class Initialized
DEBUG - 2023-03-02 08:10:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:10:00 --> Database Driver Class Initialized
INFO - 2023-03-02 08:10:00 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:10:00 --> Final output sent to browser
DEBUG - 2023-03-02 08:10:00 --> Total execution time: 0.0525
INFO - 2023-03-02 08:10:01 --> Config Class Initialized
INFO - 2023-03-02 08:10:01 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:10:01 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:10:01 --> Utf8 Class Initialized
INFO - 2023-03-02 08:10:01 --> URI Class Initialized
INFO - 2023-03-02 08:10:01 --> Router Class Initialized
INFO - 2023-03-02 08:10:01 --> Output Class Initialized
INFO - 2023-03-02 08:10:01 --> Security Class Initialized
DEBUG - 2023-03-02 08:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:10:01 --> Input Class Initialized
INFO - 2023-03-02 08:10:01 --> Language Class Initialized
INFO - 2023-03-02 08:10:01 --> Loader Class Initialized
INFO - 2023-03-02 08:10:01 --> Controller Class Initialized
DEBUG - 2023-03-02 08:10:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:10:01 --> Database Driver Class Initialized
INFO - 2023-03-02 08:10:01 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:10:01 --> Final output sent to browser
DEBUG - 2023-03-02 08:10:01 --> Total execution time: 0.0125
INFO - 2023-03-02 08:10:01 --> Config Class Initialized
INFO - 2023-03-02 08:10:01 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:10:01 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:10:01 --> Utf8 Class Initialized
INFO - 2023-03-02 08:10:01 --> URI Class Initialized
INFO - 2023-03-02 08:10:01 --> Router Class Initialized
INFO - 2023-03-02 08:10:01 --> Output Class Initialized
INFO - 2023-03-02 08:10:01 --> Security Class Initialized
DEBUG - 2023-03-02 08:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:10:01 --> Input Class Initialized
INFO - 2023-03-02 08:10:01 --> Language Class Initialized
INFO - 2023-03-02 08:10:01 --> Loader Class Initialized
INFO - 2023-03-02 08:10:01 --> Controller Class Initialized
DEBUG - 2023-03-02 08:10:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:10:01 --> Database Driver Class Initialized
INFO - 2023-03-02 08:10:01 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:10:01 --> Final output sent to browser
DEBUG - 2023-03-02 08:10:01 --> Total execution time: 0.0537
INFO - 2023-03-02 08:10:03 --> Config Class Initialized
INFO - 2023-03-02 08:10:03 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:10:03 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:10:03 --> Utf8 Class Initialized
INFO - 2023-03-02 08:10:03 --> URI Class Initialized
INFO - 2023-03-02 08:10:03 --> Router Class Initialized
INFO - 2023-03-02 08:10:03 --> Output Class Initialized
INFO - 2023-03-02 08:10:03 --> Security Class Initialized
DEBUG - 2023-03-02 08:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:10:03 --> Input Class Initialized
INFO - 2023-03-02 08:10:03 --> Language Class Initialized
INFO - 2023-03-02 08:10:03 --> Loader Class Initialized
INFO - 2023-03-02 08:10:03 --> Controller Class Initialized
DEBUG - 2023-03-02 08:10:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:10:03 --> Database Driver Class Initialized
INFO - 2023-03-02 08:10:03 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:10:03 --> Final output sent to browser
DEBUG - 2023-03-02 08:10:03 --> Total execution time: 0.0452
INFO - 2023-03-02 08:10:03 --> Config Class Initialized
INFO - 2023-03-02 08:10:03 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:10:03 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:10:03 --> Utf8 Class Initialized
INFO - 2023-03-02 08:10:03 --> URI Class Initialized
INFO - 2023-03-02 08:10:03 --> Router Class Initialized
INFO - 2023-03-02 08:10:03 --> Output Class Initialized
INFO - 2023-03-02 08:10:03 --> Security Class Initialized
DEBUG - 2023-03-02 08:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:10:03 --> Input Class Initialized
INFO - 2023-03-02 08:10:03 --> Language Class Initialized
INFO - 2023-03-02 08:10:03 --> Loader Class Initialized
INFO - 2023-03-02 08:10:03 --> Controller Class Initialized
DEBUG - 2023-03-02 08:10:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:10:03 --> Database Driver Class Initialized
INFO - 2023-03-02 08:10:03 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:10:03 --> Final output sent to browser
DEBUG - 2023-03-02 08:10:03 --> Total execution time: 0.0926
INFO - 2023-03-02 08:10:24 --> Config Class Initialized
INFO - 2023-03-02 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:10:24 --> Utf8 Class Initialized
INFO - 2023-03-02 08:10:24 --> URI Class Initialized
INFO - 2023-03-02 08:10:24 --> Router Class Initialized
INFO - 2023-03-02 08:10:24 --> Output Class Initialized
INFO - 2023-03-02 08:10:24 --> Security Class Initialized
DEBUG - 2023-03-02 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:10:24 --> Input Class Initialized
INFO - 2023-03-02 08:10:24 --> Language Class Initialized
INFO - 2023-03-02 08:10:24 --> Loader Class Initialized
INFO - 2023-03-02 08:10:24 --> Controller Class Initialized
DEBUG - 2023-03-02 08:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:10:24 --> Database Driver Class Initialized
INFO - 2023-03-02 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:10:24 --> Final output sent to browser
DEBUG - 2023-03-02 08:10:24 --> Total execution time: 0.1459
INFO - 2023-03-02 08:10:24 --> Config Class Initialized
INFO - 2023-03-02 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:10:24 --> Utf8 Class Initialized
INFO - 2023-03-02 08:10:24 --> URI Class Initialized
INFO - 2023-03-02 08:10:24 --> Router Class Initialized
INFO - 2023-03-02 08:10:24 --> Output Class Initialized
INFO - 2023-03-02 08:10:24 --> Security Class Initialized
DEBUG - 2023-03-02 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:10:24 --> Input Class Initialized
INFO - 2023-03-02 08:10:24 --> Language Class Initialized
INFO - 2023-03-02 08:10:24 --> Loader Class Initialized
INFO - 2023-03-02 08:10:24 --> Controller Class Initialized
DEBUG - 2023-03-02 08:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:10:24 --> Database Driver Class Initialized
INFO - 2023-03-02 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:10:24 --> Final output sent to browser
DEBUG - 2023-03-02 08:10:24 --> Total execution time: 0.1288
INFO - 2023-03-02 08:14:20 --> Config Class Initialized
INFO - 2023-03-02 08:14:20 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:14:20 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:14:20 --> Utf8 Class Initialized
INFO - 2023-03-02 08:14:20 --> URI Class Initialized
INFO - 2023-03-02 08:14:20 --> Router Class Initialized
INFO - 2023-03-02 08:14:20 --> Output Class Initialized
INFO - 2023-03-02 08:14:20 --> Security Class Initialized
DEBUG - 2023-03-02 08:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:14:20 --> Input Class Initialized
INFO - 2023-03-02 08:14:20 --> Language Class Initialized
INFO - 2023-03-02 08:14:20 --> Loader Class Initialized
INFO - 2023-03-02 08:14:20 --> Controller Class Initialized
DEBUG - 2023-03-02 08:14:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:14:20 --> Database Driver Class Initialized
INFO - 2023-03-02 08:14:20 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:14:20 --> Database Driver Class Initialized
INFO - 2023-03-02 08:14:21 --> Model "Login_model" initialized
INFO - 2023-03-02 08:14:21 --> Final output sent to browser
DEBUG - 2023-03-02 08:14:21 --> Total execution time: 0.0539
INFO - 2023-03-02 08:14:21 --> Config Class Initialized
INFO - 2023-03-02 08:14:21 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:14:21 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:14:21 --> Utf8 Class Initialized
INFO - 2023-03-02 08:14:21 --> URI Class Initialized
INFO - 2023-03-02 08:14:21 --> Router Class Initialized
INFO - 2023-03-02 08:14:21 --> Output Class Initialized
INFO - 2023-03-02 08:14:21 --> Security Class Initialized
DEBUG - 2023-03-02 08:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:14:21 --> Input Class Initialized
INFO - 2023-03-02 08:14:21 --> Language Class Initialized
INFO - 2023-03-02 08:14:21 --> Loader Class Initialized
INFO - 2023-03-02 08:14:21 --> Controller Class Initialized
DEBUG - 2023-03-02 08:14:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:14:21 --> Database Driver Class Initialized
INFO - 2023-03-02 08:14:21 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:14:21 --> Database Driver Class Initialized
INFO - 2023-03-02 08:14:21 --> Model "Login_model" initialized
INFO - 2023-03-02 08:14:21 --> Final output sent to browser
DEBUG - 2023-03-02 08:14:21 --> Total execution time: 0.0410
INFO - 2023-03-02 08:19:00 --> Config Class Initialized
INFO - 2023-03-02 08:19:00 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:19:00 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:19:00 --> Utf8 Class Initialized
INFO - 2023-03-02 08:19:00 --> URI Class Initialized
INFO - 2023-03-02 08:19:00 --> Router Class Initialized
INFO - 2023-03-02 08:19:00 --> Output Class Initialized
INFO - 2023-03-02 08:19:00 --> Security Class Initialized
DEBUG - 2023-03-02 08:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:19:00 --> Input Class Initialized
INFO - 2023-03-02 08:19:00 --> Language Class Initialized
INFO - 2023-03-02 08:19:00 --> Loader Class Initialized
INFO - 2023-03-02 08:19:00 --> Controller Class Initialized
INFO - 2023-03-02 08:19:00 --> Helper loaded: form_helper
INFO - 2023-03-02 08:19:00 --> Helper loaded: url_helper
DEBUG - 2023-03-02 08:19:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:19:00 --> Model "Change_model" initialized
INFO - 2023-03-02 08:19:00 --> Model "Grafana_model" initialized
INFO - 2023-03-02 08:19:00 --> Final output sent to browser
DEBUG - 2023-03-02 08:19:00 --> Total execution time: 0.0246
INFO - 2023-03-02 08:19:00 --> Config Class Initialized
INFO - 2023-03-02 08:19:01 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:19:01 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:19:01 --> Utf8 Class Initialized
INFO - 2023-03-02 08:19:01 --> URI Class Initialized
INFO - 2023-03-02 08:19:01 --> Router Class Initialized
INFO - 2023-03-02 08:19:01 --> Output Class Initialized
INFO - 2023-03-02 08:19:01 --> Security Class Initialized
DEBUG - 2023-03-02 08:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:19:01 --> Input Class Initialized
INFO - 2023-03-02 08:19:01 --> Language Class Initialized
INFO - 2023-03-02 08:19:01 --> Loader Class Initialized
INFO - 2023-03-02 08:19:01 --> Controller Class Initialized
INFO - 2023-03-02 08:19:01 --> Helper loaded: form_helper
INFO - 2023-03-02 08:19:01 --> Helper loaded: url_helper
DEBUG - 2023-03-02 08:19:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:19:01 --> Final output sent to browser
DEBUG - 2023-03-02 08:19:01 --> Total execution time: 0.0425
INFO - 2023-03-02 08:19:01 --> Config Class Initialized
INFO - 2023-03-02 08:19:01 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:19:01 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:19:01 --> Utf8 Class Initialized
INFO - 2023-03-02 08:19:01 --> URI Class Initialized
INFO - 2023-03-02 08:19:01 --> Router Class Initialized
INFO - 2023-03-02 08:19:01 --> Output Class Initialized
INFO - 2023-03-02 08:19:01 --> Security Class Initialized
DEBUG - 2023-03-02 08:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:19:01 --> Input Class Initialized
INFO - 2023-03-02 08:19:01 --> Language Class Initialized
INFO - 2023-03-02 08:19:01 --> Loader Class Initialized
INFO - 2023-03-02 08:19:01 --> Controller Class Initialized
INFO - 2023-03-02 08:19:01 --> Helper loaded: form_helper
INFO - 2023-03-02 08:19:01 --> Helper loaded: url_helper
DEBUG - 2023-03-02 08:19:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:19:01 --> Database Driver Class Initialized
INFO - 2023-03-02 08:19:01 --> Model "Login_model" initialized
INFO - 2023-03-02 08:19:01 --> Final output sent to browser
DEBUG - 2023-03-02 08:19:01 --> Total execution time: 0.0118
INFO - 2023-03-02 08:19:19 --> Config Class Initialized
INFO - 2023-03-02 08:19:19 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:19:19 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:19:19 --> Utf8 Class Initialized
INFO - 2023-03-02 08:19:19 --> URI Class Initialized
INFO - 2023-03-02 08:19:19 --> Router Class Initialized
INFO - 2023-03-02 08:19:19 --> Output Class Initialized
INFO - 2023-03-02 08:19:19 --> Security Class Initialized
DEBUG - 2023-03-02 08:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:19:19 --> Input Class Initialized
INFO - 2023-03-02 08:19:19 --> Language Class Initialized
INFO - 2023-03-02 08:19:19 --> Loader Class Initialized
INFO - 2023-03-02 08:19:19 --> Controller Class Initialized
INFO - 2023-03-02 08:19:19 --> Helper loaded: form_helper
INFO - 2023-03-02 08:19:19 --> Helper loaded: url_helper
DEBUG - 2023-03-02 08:19:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:19:19 --> Model "Change_model" initialized
INFO - 2023-03-02 08:19:19 --> Model "Grafana_model" initialized
INFO - 2023-03-02 08:19:19 --> Final output sent to browser
DEBUG - 2023-03-02 08:19:19 --> Total execution time: 0.0323
INFO - 2023-03-02 08:19:19 --> Config Class Initialized
INFO - 2023-03-02 08:19:19 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:19:19 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:19:19 --> Utf8 Class Initialized
INFO - 2023-03-02 08:19:19 --> URI Class Initialized
INFO - 2023-03-02 08:19:19 --> Router Class Initialized
INFO - 2023-03-02 08:19:19 --> Output Class Initialized
INFO - 2023-03-02 08:19:19 --> Security Class Initialized
DEBUG - 2023-03-02 08:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:19:19 --> Input Class Initialized
INFO - 2023-03-02 08:19:19 --> Language Class Initialized
INFO - 2023-03-02 08:19:19 --> Loader Class Initialized
INFO - 2023-03-02 08:19:19 --> Controller Class Initialized
INFO - 2023-03-02 08:19:19 --> Helper loaded: form_helper
INFO - 2023-03-02 08:19:19 --> Helper loaded: url_helper
DEBUG - 2023-03-02 08:19:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:19:19 --> Final output sent to browser
DEBUG - 2023-03-02 08:19:19 --> Total execution time: 0.0416
INFO - 2023-03-02 08:19:19 --> Config Class Initialized
INFO - 2023-03-02 08:19:19 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:19:19 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:19:19 --> Utf8 Class Initialized
INFO - 2023-03-02 08:19:19 --> URI Class Initialized
INFO - 2023-03-02 08:19:19 --> Router Class Initialized
INFO - 2023-03-02 08:19:19 --> Output Class Initialized
INFO - 2023-03-02 08:19:19 --> Security Class Initialized
DEBUG - 2023-03-02 08:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:19:19 --> Input Class Initialized
INFO - 2023-03-02 08:19:19 --> Language Class Initialized
INFO - 2023-03-02 08:19:19 --> Loader Class Initialized
INFO - 2023-03-02 08:19:19 --> Controller Class Initialized
INFO - 2023-03-02 08:19:19 --> Helper loaded: form_helper
INFO - 2023-03-02 08:19:19 --> Helper loaded: url_helper
DEBUG - 2023-03-02 08:19:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:19:19 --> Database Driver Class Initialized
INFO - 2023-03-02 08:19:19 --> Model "Login_model" initialized
INFO - 2023-03-02 08:19:19 --> Final output sent to browser
DEBUG - 2023-03-02 08:19:19 --> Total execution time: 0.0306
INFO - 2023-03-02 08:19:19 --> Config Class Initialized
INFO - 2023-03-02 08:19:19 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:19:19 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:19:19 --> Utf8 Class Initialized
INFO - 2023-03-02 08:19:19 --> URI Class Initialized
INFO - 2023-03-02 08:19:19 --> Router Class Initialized
INFO - 2023-03-02 08:19:19 --> Output Class Initialized
INFO - 2023-03-02 08:19:19 --> Security Class Initialized
DEBUG - 2023-03-02 08:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:19:19 --> Input Class Initialized
INFO - 2023-03-02 08:19:19 --> Language Class Initialized
INFO - 2023-03-02 08:19:19 --> Loader Class Initialized
INFO - 2023-03-02 08:19:19 --> Controller Class Initialized
DEBUG - 2023-03-02 08:19:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:19:19 --> Database Driver Class Initialized
INFO - 2023-03-02 08:19:19 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:19:19 --> Final output sent to browser
DEBUG - 2023-03-02 08:19:19 --> Total execution time: 0.0155
INFO - 2023-03-02 08:19:19 --> Config Class Initialized
INFO - 2023-03-02 08:19:19 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:19:19 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:19:19 --> Utf8 Class Initialized
INFO - 2023-03-02 08:19:19 --> URI Class Initialized
INFO - 2023-03-02 08:19:19 --> Router Class Initialized
INFO - 2023-03-02 08:19:19 --> Output Class Initialized
INFO - 2023-03-02 08:19:19 --> Security Class Initialized
DEBUG - 2023-03-02 08:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:19:19 --> Input Class Initialized
INFO - 2023-03-02 08:19:19 --> Language Class Initialized
INFO - 2023-03-02 08:19:19 --> Loader Class Initialized
INFO - 2023-03-02 08:19:19 --> Controller Class Initialized
DEBUG - 2023-03-02 08:19:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:19:19 --> Database Driver Class Initialized
INFO - 2023-03-02 08:19:19 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:19:21 --> Final output sent to browser
DEBUG - 2023-03-02 08:19:21 --> Total execution time: 1.5116
INFO - 2023-03-02 08:19:21 --> Config Class Initialized
INFO - 2023-03-02 08:19:21 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:19:21 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:19:21 --> Utf8 Class Initialized
INFO - 2023-03-02 08:19:21 --> URI Class Initialized
INFO - 2023-03-02 08:19:21 --> Router Class Initialized
INFO - 2023-03-02 08:19:21 --> Output Class Initialized
INFO - 2023-03-02 08:19:21 --> Security Class Initialized
DEBUG - 2023-03-02 08:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:19:21 --> Input Class Initialized
INFO - 2023-03-02 08:19:21 --> Language Class Initialized
INFO - 2023-03-02 08:19:21 --> Loader Class Initialized
INFO - 2023-03-02 08:19:21 --> Controller Class Initialized
DEBUG - 2023-03-02 08:19:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:19:21 --> Database Driver Class Initialized
INFO - 2023-03-02 08:19:21 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:19:21 --> Database Driver Class Initialized
INFO - 2023-03-02 08:19:21 --> Model "Login_model" initialized
INFO - 2023-03-02 08:19:21 --> Final output sent to browser
DEBUG - 2023-03-02 08:19:21 --> Total execution time: 0.1000
INFO - 2023-03-02 08:19:21 --> Config Class Initialized
INFO - 2023-03-02 08:19:21 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:19:21 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:19:21 --> Utf8 Class Initialized
INFO - 2023-03-02 08:19:21 --> URI Class Initialized
INFO - 2023-03-02 08:19:21 --> Router Class Initialized
INFO - 2023-03-02 08:19:21 --> Output Class Initialized
INFO - 2023-03-02 08:19:21 --> Security Class Initialized
DEBUG - 2023-03-02 08:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:19:21 --> Input Class Initialized
INFO - 2023-03-02 08:19:21 --> Language Class Initialized
INFO - 2023-03-02 08:19:21 --> Loader Class Initialized
INFO - 2023-03-02 08:19:21 --> Controller Class Initialized
DEBUG - 2023-03-02 08:19:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:19:21 --> Database Driver Class Initialized
INFO - 2023-03-02 08:19:21 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:19:21 --> Database Driver Class Initialized
INFO - 2023-03-02 08:19:21 --> Model "Login_model" initialized
INFO - 2023-03-02 08:19:21 --> Final output sent to browser
DEBUG - 2023-03-02 08:19:21 --> Total execution time: 0.0888
INFO - 2023-03-02 08:19:28 --> Config Class Initialized
INFO - 2023-03-02 08:19:28 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:19:28 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:19:28 --> Utf8 Class Initialized
INFO - 2023-03-02 08:19:28 --> URI Class Initialized
INFO - 2023-03-02 08:19:28 --> Router Class Initialized
INFO - 2023-03-02 08:19:28 --> Output Class Initialized
INFO - 2023-03-02 08:19:28 --> Security Class Initialized
DEBUG - 2023-03-02 08:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:19:28 --> Input Class Initialized
INFO - 2023-03-02 08:19:28 --> Language Class Initialized
INFO - 2023-03-02 08:19:28 --> Loader Class Initialized
INFO - 2023-03-02 08:19:28 --> Controller Class Initialized
DEBUG - 2023-03-02 08:19:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:19:28 --> Database Driver Class Initialized
INFO - 2023-03-02 08:19:28 --> Database Driver Class Initialized
INFO - 2023-03-02 08:19:28 --> Model "Login_model" initialized
INFO - 2023-03-02 08:19:28 --> Final output sent to browser
DEBUG - 2023-03-02 08:19:28 --> Total execution time: 0.0522
INFO - 2023-03-02 08:19:28 --> Config Class Initialized
INFO - 2023-03-02 08:19:28 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:19:28 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:19:28 --> Utf8 Class Initialized
INFO - 2023-03-02 08:19:28 --> URI Class Initialized
INFO - 2023-03-02 08:19:28 --> Router Class Initialized
INFO - 2023-03-02 08:19:28 --> Output Class Initialized
INFO - 2023-03-02 08:19:28 --> Security Class Initialized
DEBUG - 2023-03-02 08:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:19:28 --> Input Class Initialized
INFO - 2023-03-02 08:19:28 --> Language Class Initialized
INFO - 2023-03-02 08:19:28 --> Loader Class Initialized
INFO - 2023-03-02 08:19:28 --> Controller Class Initialized
DEBUG - 2023-03-02 08:19:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:19:28 --> Database Driver Class Initialized
INFO - 2023-03-02 08:19:28 --> Database Driver Class Initialized
INFO - 2023-03-02 08:19:28 --> Model "Login_model" initialized
INFO - 2023-03-02 08:19:28 --> Final output sent to browser
DEBUG - 2023-03-02 08:19:28 --> Total execution time: 0.0891
INFO - 2023-03-02 08:35:22 --> Config Class Initialized
INFO - 2023-03-02 08:35:22 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:35:22 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:35:22 --> Utf8 Class Initialized
INFO - 2023-03-02 08:35:22 --> URI Class Initialized
INFO - 2023-03-02 08:35:22 --> Router Class Initialized
INFO - 2023-03-02 08:35:22 --> Output Class Initialized
INFO - 2023-03-02 08:35:22 --> Security Class Initialized
DEBUG - 2023-03-02 08:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:35:22 --> Input Class Initialized
INFO - 2023-03-02 08:35:22 --> Language Class Initialized
INFO - 2023-03-02 08:35:22 --> Loader Class Initialized
INFO - 2023-03-02 08:35:22 --> Controller Class Initialized
DEBUG - 2023-03-02 08:35:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:35:22 --> Database Driver Class Initialized
INFO - 2023-03-02 08:35:22 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:35:22 --> Final output sent to browser
DEBUG - 2023-03-02 08:35:22 --> Total execution time: 0.0593
INFO - 2023-03-02 08:35:22 --> Config Class Initialized
INFO - 2023-03-02 08:35:22 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:35:22 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:35:22 --> Utf8 Class Initialized
INFO - 2023-03-02 08:35:22 --> URI Class Initialized
INFO - 2023-03-02 08:35:22 --> Router Class Initialized
INFO - 2023-03-02 08:35:22 --> Output Class Initialized
INFO - 2023-03-02 08:35:22 --> Security Class Initialized
DEBUG - 2023-03-02 08:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:35:22 --> Input Class Initialized
INFO - 2023-03-02 08:35:22 --> Language Class Initialized
INFO - 2023-03-02 08:35:22 --> Loader Class Initialized
INFO - 2023-03-02 08:35:22 --> Controller Class Initialized
DEBUG - 2023-03-02 08:35:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:35:22 --> Database Driver Class Initialized
INFO - 2023-03-02 08:35:22 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:35:22 --> Final output sent to browser
DEBUG - 2023-03-02 08:35:22 --> Total execution time: 0.0594
INFO - 2023-03-02 08:35:24 --> Config Class Initialized
INFO - 2023-03-02 08:35:24 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:35:24 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:35:24 --> Utf8 Class Initialized
INFO - 2023-03-02 08:35:24 --> URI Class Initialized
INFO - 2023-03-02 08:35:24 --> Router Class Initialized
INFO - 2023-03-02 08:35:24 --> Output Class Initialized
INFO - 2023-03-02 08:35:24 --> Security Class Initialized
DEBUG - 2023-03-02 08:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:35:24 --> Input Class Initialized
INFO - 2023-03-02 08:35:24 --> Language Class Initialized
INFO - 2023-03-02 08:35:24 --> Loader Class Initialized
INFO - 2023-03-02 08:35:24 --> Controller Class Initialized
DEBUG - 2023-03-02 08:35:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:35:24 --> Database Driver Class Initialized
INFO - 2023-03-02 08:35:24 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:35:24 --> Final output sent to browser
DEBUG - 2023-03-02 08:35:24 --> Total execution time: 0.0612
INFO - 2023-03-02 08:35:24 --> Config Class Initialized
INFO - 2023-03-02 08:35:24 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:35:24 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:35:24 --> Utf8 Class Initialized
INFO - 2023-03-02 08:35:24 --> URI Class Initialized
INFO - 2023-03-02 08:35:24 --> Router Class Initialized
INFO - 2023-03-02 08:35:24 --> Output Class Initialized
INFO - 2023-03-02 08:35:24 --> Security Class Initialized
DEBUG - 2023-03-02 08:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:35:24 --> Input Class Initialized
INFO - 2023-03-02 08:35:24 --> Language Class Initialized
INFO - 2023-03-02 08:35:24 --> Loader Class Initialized
INFO - 2023-03-02 08:35:24 --> Controller Class Initialized
DEBUG - 2023-03-02 08:35:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:35:24 --> Database Driver Class Initialized
INFO - 2023-03-02 08:35:24 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:35:24 --> Final output sent to browser
DEBUG - 2023-03-02 08:35:24 --> Total execution time: 0.0926
INFO - 2023-03-02 08:35:27 --> Config Class Initialized
INFO - 2023-03-02 08:35:27 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:35:27 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:35:27 --> Utf8 Class Initialized
INFO - 2023-03-02 08:35:27 --> URI Class Initialized
INFO - 2023-03-02 08:35:27 --> Router Class Initialized
INFO - 2023-03-02 08:35:27 --> Output Class Initialized
INFO - 2023-03-02 08:35:27 --> Security Class Initialized
DEBUG - 2023-03-02 08:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:35:27 --> Input Class Initialized
INFO - 2023-03-02 08:35:27 --> Language Class Initialized
INFO - 2023-03-02 08:35:27 --> Loader Class Initialized
INFO - 2023-03-02 08:35:27 --> Controller Class Initialized
DEBUG - 2023-03-02 08:35:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:35:27 --> Database Driver Class Initialized
INFO - 2023-03-02 08:35:27 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:35:27 --> Database Driver Class Initialized
INFO - 2023-03-02 08:35:27 --> Model "Login_model" initialized
INFO - 2023-03-02 08:35:27 --> Final output sent to browser
DEBUG - 2023-03-02 08:35:27 --> Total execution time: 0.0587
INFO - 2023-03-02 08:35:27 --> Config Class Initialized
INFO - 2023-03-02 08:35:27 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:35:27 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:35:27 --> Utf8 Class Initialized
INFO - 2023-03-02 08:35:27 --> URI Class Initialized
INFO - 2023-03-02 08:35:27 --> Router Class Initialized
INFO - 2023-03-02 08:35:27 --> Output Class Initialized
INFO - 2023-03-02 08:35:27 --> Security Class Initialized
DEBUG - 2023-03-02 08:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:35:27 --> Input Class Initialized
INFO - 2023-03-02 08:35:27 --> Language Class Initialized
INFO - 2023-03-02 08:35:27 --> Loader Class Initialized
INFO - 2023-03-02 08:35:27 --> Controller Class Initialized
DEBUG - 2023-03-02 08:35:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:35:27 --> Database Driver Class Initialized
INFO - 2023-03-02 08:35:27 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:35:27 --> Database Driver Class Initialized
INFO - 2023-03-02 08:35:27 --> Model "Login_model" initialized
INFO - 2023-03-02 08:35:27 --> Final output sent to browser
DEBUG - 2023-03-02 08:35:27 --> Total execution time: 0.0804
INFO - 2023-03-02 08:43:50 --> Config Class Initialized
INFO - 2023-03-02 08:43:50 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:43:50 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:43:50 --> Utf8 Class Initialized
INFO - 2023-03-02 08:43:50 --> URI Class Initialized
INFO - 2023-03-02 08:43:50 --> Router Class Initialized
INFO - 2023-03-02 08:43:50 --> Output Class Initialized
INFO - 2023-03-02 08:43:50 --> Security Class Initialized
DEBUG - 2023-03-02 08:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:43:50 --> Input Class Initialized
INFO - 2023-03-02 08:43:50 --> Language Class Initialized
INFO - 2023-03-02 08:43:50 --> Loader Class Initialized
INFO - 2023-03-02 08:43:50 --> Controller Class Initialized
DEBUG - 2023-03-02 08:43:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:43:50 --> Database Driver Class Initialized
INFO - 2023-03-02 08:43:50 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:43:50 --> Final output sent to browser
DEBUG - 2023-03-02 08:43:50 --> Total execution time: 0.0506
INFO - 2023-03-02 08:43:50 --> Config Class Initialized
INFO - 2023-03-02 08:43:50 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:43:50 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:43:50 --> Utf8 Class Initialized
INFO - 2023-03-02 08:43:50 --> URI Class Initialized
INFO - 2023-03-02 08:43:50 --> Router Class Initialized
INFO - 2023-03-02 08:43:50 --> Output Class Initialized
INFO - 2023-03-02 08:43:50 --> Security Class Initialized
DEBUG - 2023-03-02 08:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:43:50 --> Input Class Initialized
INFO - 2023-03-02 08:43:50 --> Language Class Initialized
INFO - 2023-03-02 08:43:50 --> Loader Class Initialized
INFO - 2023-03-02 08:43:50 --> Controller Class Initialized
DEBUG - 2023-03-02 08:43:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:43:50 --> Database Driver Class Initialized
INFO - 2023-03-02 08:43:50 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:43:50 --> Final output sent to browser
DEBUG - 2023-03-02 08:43:50 --> Total execution time: 0.0480
INFO - 2023-03-02 08:43:53 --> Config Class Initialized
INFO - 2023-03-02 08:43:53 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:43:53 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:43:53 --> Utf8 Class Initialized
INFO - 2023-03-02 08:43:53 --> URI Class Initialized
INFO - 2023-03-02 08:43:53 --> Router Class Initialized
INFO - 2023-03-02 08:43:53 --> Output Class Initialized
INFO - 2023-03-02 08:43:53 --> Security Class Initialized
DEBUG - 2023-03-02 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:43:53 --> Input Class Initialized
INFO - 2023-03-02 08:43:53 --> Language Class Initialized
INFO - 2023-03-02 08:43:53 --> Loader Class Initialized
INFO - 2023-03-02 08:43:53 --> Controller Class Initialized
DEBUG - 2023-03-02 08:43:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:43:53 --> Database Driver Class Initialized
INFO - 2023-03-02 08:43:53 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:43:53 --> Final output sent to browser
DEBUG - 2023-03-02 08:43:53 --> Total execution time: 0.0225
INFO - 2023-03-02 08:43:53 --> Config Class Initialized
INFO - 2023-03-02 08:43:53 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:43:53 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:43:53 --> Utf8 Class Initialized
INFO - 2023-03-02 08:43:53 --> URI Class Initialized
INFO - 2023-03-02 08:43:53 --> Router Class Initialized
INFO - 2023-03-02 08:43:53 --> Output Class Initialized
INFO - 2023-03-02 08:43:53 --> Security Class Initialized
DEBUG - 2023-03-02 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:43:53 --> Input Class Initialized
INFO - 2023-03-02 08:43:53 --> Language Class Initialized
INFO - 2023-03-02 08:43:53 --> Loader Class Initialized
INFO - 2023-03-02 08:43:53 --> Controller Class Initialized
DEBUG - 2023-03-02 08:43:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:43:53 --> Database Driver Class Initialized
INFO - 2023-03-02 08:43:53 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:43:53 --> Final output sent to browser
DEBUG - 2023-03-02 08:43:53 --> Total execution time: 0.0517
INFO - 2023-03-02 08:43:55 --> Config Class Initialized
INFO - 2023-03-02 08:43:55 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:43:55 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:43:55 --> Utf8 Class Initialized
INFO - 2023-03-02 08:43:55 --> URI Class Initialized
INFO - 2023-03-02 08:43:55 --> Router Class Initialized
INFO - 2023-03-02 08:43:55 --> Output Class Initialized
INFO - 2023-03-02 08:43:55 --> Security Class Initialized
DEBUG - 2023-03-02 08:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:43:55 --> Input Class Initialized
INFO - 2023-03-02 08:43:55 --> Language Class Initialized
INFO - 2023-03-02 08:43:55 --> Loader Class Initialized
INFO - 2023-03-02 08:43:55 --> Controller Class Initialized
DEBUG - 2023-03-02 08:43:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:43:55 --> Database Driver Class Initialized
INFO - 2023-03-02 08:43:55 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:43:55 --> Database Driver Class Initialized
INFO - 2023-03-02 08:43:55 --> Model "Login_model" initialized
INFO - 2023-03-02 08:43:55 --> Final output sent to browser
DEBUG - 2023-03-02 08:43:55 --> Total execution time: 0.0996
INFO - 2023-03-02 08:43:55 --> Config Class Initialized
INFO - 2023-03-02 08:43:56 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:43:56 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:43:56 --> Utf8 Class Initialized
INFO - 2023-03-02 08:43:56 --> URI Class Initialized
INFO - 2023-03-02 08:43:56 --> Router Class Initialized
INFO - 2023-03-02 08:43:56 --> Output Class Initialized
INFO - 2023-03-02 08:43:56 --> Security Class Initialized
DEBUG - 2023-03-02 08:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:43:56 --> Input Class Initialized
INFO - 2023-03-02 08:43:56 --> Language Class Initialized
INFO - 2023-03-02 08:43:56 --> Loader Class Initialized
INFO - 2023-03-02 08:43:56 --> Controller Class Initialized
DEBUG - 2023-03-02 08:43:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:43:56 --> Database Driver Class Initialized
INFO - 2023-03-02 08:43:56 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:43:56 --> Database Driver Class Initialized
INFO - 2023-03-02 08:43:56 --> Model "Login_model" initialized
INFO - 2023-03-02 08:43:56 --> Final output sent to browser
DEBUG - 2023-03-02 08:43:56 --> Total execution time: 0.1149
INFO - 2023-03-02 08:43:59 --> Config Class Initialized
INFO - 2023-03-02 08:43:59 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:43:59 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:43:59 --> Utf8 Class Initialized
INFO - 2023-03-02 08:43:59 --> URI Class Initialized
INFO - 2023-03-02 08:43:59 --> Router Class Initialized
INFO - 2023-03-02 08:43:59 --> Output Class Initialized
INFO - 2023-03-02 08:43:59 --> Security Class Initialized
DEBUG - 2023-03-02 08:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:43:59 --> Input Class Initialized
INFO - 2023-03-02 08:43:59 --> Language Class Initialized
INFO - 2023-03-02 08:43:59 --> Loader Class Initialized
INFO - 2023-03-02 08:43:59 --> Controller Class Initialized
DEBUG - 2023-03-02 08:43:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:43:59 --> Database Driver Class Initialized
INFO - 2023-03-02 08:43:59 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:43:59 --> Final output sent to browser
DEBUG - 2023-03-02 08:43:59 --> Total execution time: 0.1169
INFO - 2023-03-02 08:43:59 --> Config Class Initialized
INFO - 2023-03-02 08:43:59 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:43:59 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:43:59 --> Utf8 Class Initialized
INFO - 2023-03-02 08:43:59 --> URI Class Initialized
INFO - 2023-03-02 08:43:59 --> Router Class Initialized
INFO - 2023-03-02 08:43:59 --> Output Class Initialized
INFO - 2023-03-02 08:43:59 --> Security Class Initialized
DEBUG - 2023-03-02 08:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:43:59 --> Input Class Initialized
INFO - 2023-03-02 08:43:59 --> Language Class Initialized
INFO - 2023-03-02 08:43:59 --> Loader Class Initialized
INFO - 2023-03-02 08:43:59 --> Controller Class Initialized
DEBUG - 2023-03-02 08:43:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:43:59 --> Database Driver Class Initialized
INFO - 2023-03-02 08:43:59 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:43:59 --> Final output sent to browser
DEBUG - 2023-03-02 08:43:59 --> Total execution time: 0.1002
INFO - 2023-03-02 08:44:04 --> Config Class Initialized
INFO - 2023-03-02 08:44:04 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:44:04 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:44:04 --> Utf8 Class Initialized
INFO - 2023-03-02 08:44:04 --> URI Class Initialized
INFO - 2023-03-02 08:44:04 --> Router Class Initialized
INFO - 2023-03-02 08:44:04 --> Output Class Initialized
INFO - 2023-03-02 08:44:04 --> Security Class Initialized
DEBUG - 2023-03-02 08:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:44:04 --> Input Class Initialized
INFO - 2023-03-02 08:44:04 --> Language Class Initialized
INFO - 2023-03-02 08:44:04 --> Loader Class Initialized
INFO - 2023-03-02 08:44:04 --> Controller Class Initialized
DEBUG - 2023-03-02 08:44:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:44:04 --> Database Driver Class Initialized
INFO - 2023-03-02 08:44:04 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:44:04 --> Database Driver Class Initialized
INFO - 2023-03-02 08:44:04 --> Model "Login_model" initialized
INFO - 2023-03-02 08:44:04 --> Final output sent to browser
DEBUG - 2023-03-02 08:44:04 --> Total execution time: 0.0402
INFO - 2023-03-02 08:44:04 --> Config Class Initialized
INFO - 2023-03-02 08:44:04 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:44:04 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:44:04 --> Utf8 Class Initialized
INFO - 2023-03-02 08:44:04 --> URI Class Initialized
INFO - 2023-03-02 08:44:04 --> Router Class Initialized
INFO - 2023-03-02 08:44:04 --> Output Class Initialized
INFO - 2023-03-02 08:44:04 --> Security Class Initialized
DEBUG - 2023-03-02 08:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:44:04 --> Input Class Initialized
INFO - 2023-03-02 08:44:04 --> Language Class Initialized
INFO - 2023-03-02 08:44:04 --> Loader Class Initialized
INFO - 2023-03-02 08:44:04 --> Controller Class Initialized
DEBUG - 2023-03-02 08:44:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:44:04 --> Database Driver Class Initialized
INFO - 2023-03-02 08:44:04 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:44:04 --> Database Driver Class Initialized
INFO - 2023-03-02 08:44:04 --> Model "Login_model" initialized
INFO - 2023-03-02 08:44:04 --> Final output sent to browser
DEBUG - 2023-03-02 08:44:04 --> Total execution time: 0.0371
INFO - 2023-03-02 08:44:34 --> Config Class Initialized
INFO - 2023-03-02 08:44:34 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:44:34 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:44:34 --> Utf8 Class Initialized
INFO - 2023-03-02 08:44:34 --> URI Class Initialized
INFO - 2023-03-02 08:44:34 --> Router Class Initialized
INFO - 2023-03-02 08:44:34 --> Output Class Initialized
INFO - 2023-03-02 08:44:34 --> Security Class Initialized
DEBUG - 2023-03-02 08:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:44:34 --> Input Class Initialized
INFO - 2023-03-02 08:44:34 --> Language Class Initialized
INFO - 2023-03-02 08:44:34 --> Loader Class Initialized
INFO - 2023-03-02 08:44:34 --> Controller Class Initialized
DEBUG - 2023-03-02 08:44:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:44:34 --> Database Driver Class Initialized
INFO - 2023-03-02 08:44:34 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:44:35 --> Database Driver Class Initialized
INFO - 2023-03-02 08:44:35 --> Model "Login_model" initialized
INFO - 2023-03-02 08:44:35 --> Final output sent to browser
DEBUG - 2023-03-02 08:44:35 --> Total execution time: 0.1255
INFO - 2023-03-02 08:44:35 --> Config Class Initialized
INFO - 2023-03-02 08:44:35 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:44:35 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:44:35 --> Utf8 Class Initialized
INFO - 2023-03-02 08:44:35 --> URI Class Initialized
INFO - 2023-03-02 08:44:35 --> Router Class Initialized
INFO - 2023-03-02 08:44:35 --> Output Class Initialized
INFO - 2023-03-02 08:44:35 --> Security Class Initialized
DEBUG - 2023-03-02 08:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:44:35 --> Input Class Initialized
INFO - 2023-03-02 08:44:35 --> Language Class Initialized
INFO - 2023-03-02 08:44:35 --> Loader Class Initialized
INFO - 2023-03-02 08:44:35 --> Controller Class Initialized
DEBUG - 2023-03-02 08:44:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:44:35 --> Database Driver Class Initialized
INFO - 2023-03-02 08:44:35 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:44:35 --> Database Driver Class Initialized
INFO - 2023-03-02 08:44:35 --> Model "Login_model" initialized
INFO - 2023-03-02 08:44:35 --> Final output sent to browser
DEBUG - 2023-03-02 08:44:35 --> Total execution time: 0.1166
INFO - 2023-03-02 08:44:42 --> Config Class Initialized
INFO - 2023-03-02 08:44:42 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:44:42 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:44:42 --> Utf8 Class Initialized
INFO - 2023-03-02 08:44:42 --> URI Class Initialized
INFO - 2023-03-02 08:44:42 --> Router Class Initialized
INFO - 2023-03-02 08:44:42 --> Output Class Initialized
INFO - 2023-03-02 08:44:42 --> Security Class Initialized
DEBUG - 2023-03-02 08:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:44:42 --> Input Class Initialized
INFO - 2023-03-02 08:44:42 --> Language Class Initialized
INFO - 2023-03-02 08:44:42 --> Loader Class Initialized
INFO - 2023-03-02 08:44:42 --> Controller Class Initialized
DEBUG - 2023-03-02 08:44:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:44:42 --> Database Driver Class Initialized
INFO - 2023-03-02 08:44:42 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:44:42 --> Database Driver Class Initialized
INFO - 2023-03-02 08:44:42 --> Model "Login_model" initialized
INFO - 2023-03-02 08:44:42 --> Final output sent to browser
DEBUG - 2023-03-02 08:44:42 --> Total execution time: 0.0483
INFO - 2023-03-02 08:44:42 --> Config Class Initialized
INFO - 2023-03-02 08:44:42 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:44:42 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:44:42 --> Utf8 Class Initialized
INFO - 2023-03-02 08:44:42 --> URI Class Initialized
INFO - 2023-03-02 08:44:42 --> Router Class Initialized
INFO - 2023-03-02 08:44:42 --> Output Class Initialized
INFO - 2023-03-02 08:44:42 --> Security Class Initialized
DEBUG - 2023-03-02 08:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:44:42 --> Input Class Initialized
INFO - 2023-03-02 08:44:42 --> Language Class Initialized
INFO - 2023-03-02 08:44:42 --> Loader Class Initialized
INFO - 2023-03-02 08:44:42 --> Controller Class Initialized
DEBUG - 2023-03-02 08:44:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:44:42 --> Database Driver Class Initialized
INFO - 2023-03-02 08:44:42 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:44:42 --> Database Driver Class Initialized
INFO - 2023-03-02 08:44:42 --> Model "Login_model" initialized
INFO - 2023-03-02 08:44:42 --> Final output sent to browser
DEBUG - 2023-03-02 08:44:42 --> Total execution time: 0.1997
INFO - 2023-03-02 08:47:33 --> Config Class Initialized
INFO - 2023-03-02 08:47:33 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:47:33 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:47:33 --> Utf8 Class Initialized
INFO - 2023-03-02 08:47:33 --> URI Class Initialized
INFO - 2023-03-02 08:47:33 --> Router Class Initialized
INFO - 2023-03-02 08:47:33 --> Output Class Initialized
INFO - 2023-03-02 08:47:33 --> Security Class Initialized
DEBUG - 2023-03-02 08:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:47:33 --> Input Class Initialized
INFO - 2023-03-02 08:47:33 --> Language Class Initialized
INFO - 2023-03-02 08:47:33 --> Loader Class Initialized
INFO - 2023-03-02 08:47:33 --> Controller Class Initialized
DEBUG - 2023-03-02 08:47:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:47:33 --> Final output sent to browser
DEBUG - 2023-03-02 08:47:33 --> Total execution time: 0.0622
INFO - 2023-03-02 08:47:33 --> Config Class Initialized
INFO - 2023-03-02 08:47:33 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:47:33 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:47:33 --> Utf8 Class Initialized
INFO - 2023-03-02 08:47:33 --> URI Class Initialized
INFO - 2023-03-02 08:47:33 --> Router Class Initialized
INFO - 2023-03-02 08:47:33 --> Output Class Initialized
INFO - 2023-03-02 08:47:33 --> Security Class Initialized
DEBUG - 2023-03-02 08:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:47:33 --> Input Class Initialized
INFO - 2023-03-02 08:47:33 --> Language Class Initialized
INFO - 2023-03-02 08:47:33 --> Loader Class Initialized
INFO - 2023-03-02 08:47:33 --> Controller Class Initialized
DEBUG - 2023-03-02 08:47:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:47:33 --> Database Driver Class Initialized
INFO - 2023-03-02 08:47:33 --> Model "Login_model" initialized
INFO - 2023-03-02 08:47:33 --> Database Driver Class Initialized
INFO - 2023-03-02 08:47:33 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:47:34 --> Final output sent to browser
DEBUG - 2023-03-02 08:47:34 --> Total execution time: 0.0637
INFO - 2023-03-02 08:47:34 --> Config Class Initialized
INFO - 2023-03-02 08:47:34 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:47:34 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:47:34 --> Utf8 Class Initialized
INFO - 2023-03-02 08:47:34 --> URI Class Initialized
INFO - 2023-03-02 08:47:34 --> Router Class Initialized
INFO - 2023-03-02 08:47:34 --> Output Class Initialized
INFO - 2023-03-02 08:47:34 --> Security Class Initialized
DEBUG - 2023-03-02 08:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:47:34 --> Input Class Initialized
INFO - 2023-03-02 08:47:34 --> Language Class Initialized
INFO - 2023-03-02 08:47:34 --> Loader Class Initialized
INFO - 2023-03-02 08:47:34 --> Controller Class Initialized
DEBUG - 2023-03-02 08:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:47:34 --> Final output sent to browser
DEBUG - 2023-03-02 08:47:34 --> Total execution time: 0.1491
INFO - 2023-03-02 08:47:34 --> Config Class Initialized
INFO - 2023-03-02 08:47:34 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:47:34 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:47:34 --> Utf8 Class Initialized
INFO - 2023-03-02 08:47:34 --> URI Class Initialized
INFO - 2023-03-02 08:47:34 --> Router Class Initialized
INFO - 2023-03-02 08:47:34 --> Output Class Initialized
INFO - 2023-03-02 08:47:34 --> Security Class Initialized
DEBUG - 2023-03-02 08:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:47:34 --> Input Class Initialized
INFO - 2023-03-02 08:47:34 --> Language Class Initialized
INFO - 2023-03-02 08:47:34 --> Loader Class Initialized
INFO - 2023-03-02 08:47:34 --> Controller Class Initialized
DEBUG - 2023-03-02 08:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:47:34 --> Database Driver Class Initialized
INFO - 2023-03-02 08:47:34 --> Model "Login_model" initialized
INFO - 2023-03-02 08:47:34 --> Database Driver Class Initialized
INFO - 2023-03-02 08:47:34 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:47:34 --> Final output sent to browser
DEBUG - 2023-03-02 08:47:34 --> Total execution time: 0.0264
INFO - 2023-03-02 08:47:34 --> Config Class Initialized
INFO - 2023-03-02 08:47:34 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:47:34 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:47:34 --> Utf8 Class Initialized
INFO - 2023-03-02 08:47:34 --> URI Class Initialized
INFO - 2023-03-02 08:47:34 --> Router Class Initialized
INFO - 2023-03-02 08:47:34 --> Output Class Initialized
INFO - 2023-03-02 08:47:34 --> Security Class Initialized
DEBUG - 2023-03-02 08:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:47:34 --> Input Class Initialized
INFO - 2023-03-02 08:47:34 --> Language Class Initialized
INFO - 2023-03-02 08:47:34 --> Loader Class Initialized
INFO - 2023-03-02 08:47:34 --> Controller Class Initialized
DEBUG - 2023-03-02 08:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:47:34 --> Database Driver Class Initialized
INFO - 2023-03-02 08:47:34 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:47:34 --> Final output sent to browser
DEBUG - 2023-03-02 08:47:34 --> Total execution time: 0.0170
INFO - 2023-03-02 08:47:34 --> Config Class Initialized
INFO - 2023-03-02 08:47:34 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:47:34 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:47:34 --> Utf8 Class Initialized
INFO - 2023-03-02 08:47:34 --> URI Class Initialized
INFO - 2023-03-02 08:47:34 --> Router Class Initialized
INFO - 2023-03-02 08:47:34 --> Output Class Initialized
INFO - 2023-03-02 08:47:34 --> Security Class Initialized
DEBUG - 2023-03-02 08:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:47:34 --> Input Class Initialized
INFO - 2023-03-02 08:47:34 --> Language Class Initialized
INFO - 2023-03-02 08:47:34 --> Loader Class Initialized
INFO - 2023-03-02 08:47:34 --> Controller Class Initialized
DEBUG - 2023-03-02 08:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:47:34 --> Database Driver Class Initialized
INFO - 2023-03-02 08:47:34 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:47:34 --> Final output sent to browser
DEBUG - 2023-03-02 08:47:34 --> Total execution time: 0.0525
INFO - 2023-03-02 08:47:39 --> Config Class Initialized
INFO - 2023-03-02 08:47:39 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:47:39 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:47:39 --> Utf8 Class Initialized
INFO - 2023-03-02 08:47:39 --> URI Class Initialized
INFO - 2023-03-02 08:47:39 --> Router Class Initialized
INFO - 2023-03-02 08:47:39 --> Output Class Initialized
INFO - 2023-03-02 08:47:39 --> Security Class Initialized
DEBUG - 2023-03-02 08:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:47:39 --> Input Class Initialized
INFO - 2023-03-02 08:47:39 --> Language Class Initialized
INFO - 2023-03-02 08:47:39 --> Loader Class Initialized
INFO - 2023-03-02 08:47:39 --> Controller Class Initialized
DEBUG - 2023-03-02 08:47:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:47:39 --> Database Driver Class Initialized
INFO - 2023-03-02 08:47:39 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:47:39 --> Final output sent to browser
DEBUG - 2023-03-02 08:47:39 --> Total execution time: 0.0417
INFO - 2023-03-02 08:47:39 --> Config Class Initialized
INFO - 2023-03-02 08:47:39 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:47:39 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:47:39 --> Utf8 Class Initialized
INFO - 2023-03-02 08:47:39 --> URI Class Initialized
INFO - 2023-03-02 08:47:39 --> Router Class Initialized
INFO - 2023-03-02 08:47:39 --> Output Class Initialized
INFO - 2023-03-02 08:47:39 --> Security Class Initialized
DEBUG - 2023-03-02 08:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:47:39 --> Input Class Initialized
INFO - 2023-03-02 08:47:39 --> Language Class Initialized
INFO - 2023-03-02 08:47:39 --> Loader Class Initialized
INFO - 2023-03-02 08:47:39 --> Controller Class Initialized
DEBUG - 2023-03-02 08:47:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:47:39 --> Database Driver Class Initialized
INFO - 2023-03-02 08:47:39 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:47:39 --> Final output sent to browser
DEBUG - 2023-03-02 08:47:39 --> Total execution time: 0.0784
INFO - 2023-03-02 08:47:42 --> Config Class Initialized
INFO - 2023-03-02 08:47:42 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:47:42 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:47:42 --> Utf8 Class Initialized
INFO - 2023-03-02 08:47:42 --> URI Class Initialized
INFO - 2023-03-02 08:47:42 --> Router Class Initialized
INFO - 2023-03-02 08:47:42 --> Output Class Initialized
INFO - 2023-03-02 08:47:42 --> Security Class Initialized
DEBUG - 2023-03-02 08:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:47:42 --> Input Class Initialized
INFO - 2023-03-02 08:47:42 --> Language Class Initialized
INFO - 2023-03-02 08:47:42 --> Loader Class Initialized
INFO - 2023-03-02 08:47:42 --> Controller Class Initialized
DEBUG - 2023-03-02 08:47:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:47:42 --> Database Driver Class Initialized
INFO - 2023-03-02 08:47:42 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:47:42 --> Final output sent to browser
DEBUG - 2023-03-02 08:47:42 --> Total execution time: 0.0144
INFO - 2023-03-02 08:47:42 --> Config Class Initialized
INFO - 2023-03-02 08:47:42 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:47:42 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:47:42 --> Utf8 Class Initialized
INFO - 2023-03-02 08:47:42 --> URI Class Initialized
INFO - 2023-03-02 08:47:42 --> Router Class Initialized
INFO - 2023-03-02 08:47:42 --> Output Class Initialized
INFO - 2023-03-02 08:47:42 --> Security Class Initialized
DEBUG - 2023-03-02 08:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:47:42 --> Input Class Initialized
INFO - 2023-03-02 08:47:42 --> Language Class Initialized
INFO - 2023-03-02 08:47:42 --> Loader Class Initialized
INFO - 2023-03-02 08:47:42 --> Controller Class Initialized
DEBUG - 2023-03-02 08:47:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:47:42 --> Database Driver Class Initialized
INFO - 2023-03-02 08:47:42 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:47:42 --> Final output sent to browser
DEBUG - 2023-03-02 08:47:42 --> Total execution time: 0.0150
INFO - 2023-03-02 08:57:07 --> Config Class Initialized
INFO - 2023-03-02 08:57:07 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:57:07 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:57:07 --> Utf8 Class Initialized
INFO - 2023-03-02 08:57:07 --> URI Class Initialized
INFO - 2023-03-02 08:57:07 --> Router Class Initialized
INFO - 2023-03-02 08:57:07 --> Output Class Initialized
INFO - 2023-03-02 08:57:07 --> Security Class Initialized
DEBUG - 2023-03-02 08:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:57:07 --> Input Class Initialized
INFO - 2023-03-02 08:57:07 --> Language Class Initialized
INFO - 2023-03-02 08:57:07 --> Loader Class Initialized
INFO - 2023-03-02 08:57:07 --> Controller Class Initialized
DEBUG - 2023-03-02 08:57:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:57:07 --> Database Driver Class Initialized
INFO - 2023-03-02 08:57:07 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:57:08 --> Final output sent to browser
DEBUG - 2023-03-02 08:57:08 --> Total execution time: 0.0578
INFO - 2023-03-02 08:57:08 --> Config Class Initialized
INFO - 2023-03-02 08:57:08 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:57:08 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:57:08 --> Utf8 Class Initialized
INFO - 2023-03-02 08:57:08 --> URI Class Initialized
INFO - 2023-03-02 08:57:08 --> Router Class Initialized
INFO - 2023-03-02 08:57:08 --> Output Class Initialized
INFO - 2023-03-02 08:57:08 --> Security Class Initialized
DEBUG - 2023-03-02 08:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:57:08 --> Input Class Initialized
INFO - 2023-03-02 08:57:08 --> Language Class Initialized
INFO - 2023-03-02 08:57:08 --> Loader Class Initialized
INFO - 2023-03-02 08:57:08 --> Controller Class Initialized
DEBUG - 2023-03-02 08:57:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:57:08 --> Database Driver Class Initialized
INFO - 2023-03-02 08:57:08 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:57:08 --> Final output sent to browser
DEBUG - 2023-03-02 08:57:08 --> Total execution time: 0.0878
INFO - 2023-03-02 08:57:11 --> Config Class Initialized
INFO - 2023-03-02 08:57:11 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:57:11 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:57:11 --> Utf8 Class Initialized
INFO - 2023-03-02 08:57:11 --> URI Class Initialized
INFO - 2023-03-02 08:57:11 --> Router Class Initialized
INFO - 2023-03-02 08:57:11 --> Output Class Initialized
INFO - 2023-03-02 08:57:11 --> Security Class Initialized
DEBUG - 2023-03-02 08:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:57:11 --> Input Class Initialized
INFO - 2023-03-02 08:57:11 --> Language Class Initialized
INFO - 2023-03-02 08:57:11 --> Loader Class Initialized
INFO - 2023-03-02 08:57:11 --> Controller Class Initialized
DEBUG - 2023-03-02 08:57:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:57:11 --> Database Driver Class Initialized
INFO - 2023-03-02 08:57:11 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:57:11 --> Database Driver Class Initialized
INFO - 2023-03-02 08:57:11 --> Model "Login_model" initialized
INFO - 2023-03-02 08:57:11 --> Final output sent to browser
DEBUG - 2023-03-02 08:57:11 --> Total execution time: 0.0450
INFO - 2023-03-02 08:57:11 --> Config Class Initialized
INFO - 2023-03-02 08:57:11 --> Hooks Class Initialized
DEBUG - 2023-03-02 08:57:11 --> UTF-8 Support Enabled
INFO - 2023-03-02 08:57:11 --> Utf8 Class Initialized
INFO - 2023-03-02 08:57:11 --> URI Class Initialized
INFO - 2023-03-02 08:57:11 --> Router Class Initialized
INFO - 2023-03-02 08:57:11 --> Output Class Initialized
INFO - 2023-03-02 08:57:11 --> Security Class Initialized
DEBUG - 2023-03-02 08:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 08:57:11 --> Input Class Initialized
INFO - 2023-03-02 08:57:11 --> Language Class Initialized
INFO - 2023-03-02 08:57:11 --> Loader Class Initialized
INFO - 2023-03-02 08:57:11 --> Controller Class Initialized
DEBUG - 2023-03-02 08:57:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 08:57:11 --> Database Driver Class Initialized
INFO - 2023-03-02 08:57:11 --> Model "Cluster_model" initialized
INFO - 2023-03-02 08:57:11 --> Database Driver Class Initialized
INFO - 2023-03-02 08:57:11 --> Model "Login_model" initialized
INFO - 2023-03-02 08:57:11 --> Final output sent to browser
DEBUG - 2023-03-02 08:57:11 --> Total execution time: 0.0791
INFO - 2023-03-02 09:02:30 --> Config Class Initialized
INFO - 2023-03-02 09:02:30 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:02:30 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:02:30 --> Utf8 Class Initialized
INFO - 2023-03-02 09:02:30 --> URI Class Initialized
INFO - 2023-03-02 09:02:30 --> Router Class Initialized
INFO - 2023-03-02 09:02:30 --> Output Class Initialized
INFO - 2023-03-02 09:02:30 --> Security Class Initialized
DEBUG - 2023-03-02 09:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:02:30 --> Input Class Initialized
INFO - 2023-03-02 09:02:30 --> Language Class Initialized
INFO - 2023-03-02 09:02:30 --> Loader Class Initialized
INFO - 2023-03-02 09:02:30 --> Controller Class Initialized
DEBUG - 2023-03-02 09:02:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:02:30 --> Final output sent to browser
DEBUG - 2023-03-02 09:02:30 --> Total execution time: 0.0043
INFO - 2023-03-02 09:02:30 --> Config Class Initialized
INFO - 2023-03-02 09:02:30 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:02:30 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:02:30 --> Utf8 Class Initialized
INFO - 2023-03-02 09:02:30 --> URI Class Initialized
INFO - 2023-03-02 09:02:30 --> Router Class Initialized
INFO - 2023-03-02 09:02:30 --> Output Class Initialized
INFO - 2023-03-02 09:02:30 --> Security Class Initialized
DEBUG - 2023-03-02 09:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:02:30 --> Input Class Initialized
INFO - 2023-03-02 09:02:30 --> Language Class Initialized
INFO - 2023-03-02 09:02:30 --> Loader Class Initialized
INFO - 2023-03-02 09:02:30 --> Controller Class Initialized
DEBUG - 2023-03-02 09:02:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:02:30 --> Database Driver Class Initialized
INFO - 2023-03-02 09:02:31 --> Model "Login_model" initialized
INFO - 2023-03-02 09:02:31 --> Database Driver Class Initialized
INFO - 2023-03-02 09:02:31 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:02:31 --> Final output sent to browser
DEBUG - 2023-03-02 09:02:31 --> Total execution time: 1.0229
INFO - 2023-03-02 09:02:31 --> Config Class Initialized
INFO - 2023-03-02 09:02:31 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:02:31 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:02:31 --> Utf8 Class Initialized
INFO - 2023-03-02 09:02:31 --> URI Class Initialized
INFO - 2023-03-02 09:02:31 --> Router Class Initialized
INFO - 2023-03-02 09:02:31 --> Output Class Initialized
INFO - 2023-03-02 09:02:31 --> Security Class Initialized
DEBUG - 2023-03-02 09:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:02:31 --> Input Class Initialized
INFO - 2023-03-02 09:02:31 --> Language Class Initialized
INFO - 2023-03-02 09:02:31 --> Loader Class Initialized
INFO - 2023-03-02 09:02:31 --> Controller Class Initialized
DEBUG - 2023-03-02 09:02:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:02:31 --> Final output sent to browser
DEBUG - 2023-03-02 09:02:31 --> Total execution time: 0.0454
INFO - 2023-03-02 09:02:31 --> Config Class Initialized
INFO - 2023-03-02 09:02:31 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:02:31 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:02:31 --> Utf8 Class Initialized
INFO - 2023-03-02 09:02:31 --> URI Class Initialized
INFO - 2023-03-02 09:02:31 --> Router Class Initialized
INFO - 2023-03-02 09:02:31 --> Output Class Initialized
INFO - 2023-03-02 09:02:31 --> Security Class Initialized
DEBUG - 2023-03-02 09:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:02:31 --> Input Class Initialized
INFO - 2023-03-02 09:02:31 --> Language Class Initialized
INFO - 2023-03-02 09:02:31 --> Loader Class Initialized
INFO - 2023-03-02 09:02:31 --> Controller Class Initialized
DEBUG - 2023-03-02 09:02:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:02:31 --> Database Driver Class Initialized
INFO - 2023-03-02 09:02:31 --> Model "Login_model" initialized
INFO - 2023-03-02 09:02:31 --> Database Driver Class Initialized
INFO - 2023-03-02 09:02:31 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:02:31 --> Final output sent to browser
DEBUG - 2023-03-02 09:02:31 --> Total execution time: 0.0255
INFO - 2023-03-02 09:02:32 --> Config Class Initialized
INFO - 2023-03-02 09:02:32 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:02:32 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:02:32 --> Utf8 Class Initialized
INFO - 2023-03-02 09:02:32 --> URI Class Initialized
INFO - 2023-03-02 09:02:32 --> Router Class Initialized
INFO - 2023-03-02 09:02:32 --> Output Class Initialized
INFO - 2023-03-02 09:02:32 --> Security Class Initialized
DEBUG - 2023-03-02 09:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:02:32 --> Input Class Initialized
INFO - 2023-03-02 09:02:32 --> Language Class Initialized
INFO - 2023-03-02 09:02:32 --> Loader Class Initialized
INFO - 2023-03-02 09:02:32 --> Controller Class Initialized
DEBUG - 2023-03-02 09:02:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:02:32 --> Database Driver Class Initialized
INFO - 2023-03-02 09:02:32 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:02:32 --> Database Driver Class Initialized
INFO - 2023-03-02 09:02:32 --> Model "Login_model" initialized
INFO - 2023-03-02 09:02:32 --> Final output sent to browser
DEBUG - 2023-03-02 09:02:32 --> Total execution time: 0.0473
INFO - 2023-03-02 09:02:32 --> Config Class Initialized
INFO - 2023-03-02 09:02:32 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:02:32 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:02:32 --> Utf8 Class Initialized
INFO - 2023-03-02 09:02:32 --> URI Class Initialized
INFO - 2023-03-02 09:02:32 --> Router Class Initialized
INFO - 2023-03-02 09:02:32 --> Output Class Initialized
INFO - 2023-03-02 09:02:32 --> Security Class Initialized
DEBUG - 2023-03-02 09:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:02:32 --> Input Class Initialized
INFO - 2023-03-02 09:02:32 --> Language Class Initialized
INFO - 2023-03-02 09:02:32 --> Loader Class Initialized
INFO - 2023-03-02 09:02:32 --> Controller Class Initialized
DEBUG - 2023-03-02 09:02:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:02:32 --> Database Driver Class Initialized
INFO - 2023-03-02 09:02:32 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:02:32 --> Database Driver Class Initialized
INFO - 2023-03-02 09:02:32 --> Model "Login_model" initialized
INFO - 2023-03-02 09:02:32 --> Final output sent to browser
DEBUG - 2023-03-02 09:02:32 --> Total execution time: 0.0443
INFO - 2023-03-02 09:02:35 --> Config Class Initialized
INFO - 2023-03-02 09:02:35 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:02:35 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:02:35 --> Utf8 Class Initialized
INFO - 2023-03-02 09:02:35 --> URI Class Initialized
INFO - 2023-03-02 09:02:35 --> Router Class Initialized
INFO - 2023-03-02 09:02:35 --> Output Class Initialized
INFO - 2023-03-02 09:02:35 --> Security Class Initialized
DEBUG - 2023-03-02 09:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:02:35 --> Input Class Initialized
INFO - 2023-03-02 09:02:35 --> Language Class Initialized
INFO - 2023-03-02 09:02:35 --> Loader Class Initialized
INFO - 2023-03-02 09:02:35 --> Controller Class Initialized
DEBUG - 2023-03-02 09:02:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:02:35 --> Database Driver Class Initialized
INFO - 2023-03-02 09:02:35 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:02:35 --> Final output sent to browser
DEBUG - 2023-03-02 09:02:35 --> Total execution time: 0.0499
INFO - 2023-03-02 09:02:35 --> Config Class Initialized
INFO - 2023-03-02 09:02:35 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:02:35 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:02:35 --> Utf8 Class Initialized
INFO - 2023-03-02 09:02:35 --> URI Class Initialized
INFO - 2023-03-02 09:02:35 --> Router Class Initialized
INFO - 2023-03-02 09:02:35 --> Output Class Initialized
INFO - 2023-03-02 09:02:35 --> Security Class Initialized
DEBUG - 2023-03-02 09:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:02:35 --> Input Class Initialized
INFO - 2023-03-02 09:02:35 --> Language Class Initialized
INFO - 2023-03-02 09:02:35 --> Loader Class Initialized
INFO - 2023-03-02 09:02:35 --> Controller Class Initialized
DEBUG - 2023-03-02 09:02:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:02:35 --> Database Driver Class Initialized
INFO - 2023-03-02 09:02:35 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:02:35 --> Final output sent to browser
DEBUG - 2023-03-02 09:02:35 --> Total execution time: 0.0499
INFO - 2023-03-02 09:09:17 --> Config Class Initialized
INFO - 2023-03-02 09:09:17 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:17 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:17 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:17 --> URI Class Initialized
INFO - 2023-03-02 09:09:17 --> Router Class Initialized
INFO - 2023-03-02 09:09:17 --> Output Class Initialized
INFO - 2023-03-02 09:09:17 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:17 --> Input Class Initialized
INFO - 2023-03-02 09:09:17 --> Language Class Initialized
INFO - 2023-03-02 09:09:17 --> Loader Class Initialized
INFO - 2023-03-02 09:09:17 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:17 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:17 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:17 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:17 --> Total execution time: 0.0613
INFO - 2023-03-02 09:09:17 --> Config Class Initialized
INFO - 2023-03-02 09:09:17 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:17 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:17 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:17 --> URI Class Initialized
INFO - 2023-03-02 09:09:17 --> Router Class Initialized
INFO - 2023-03-02 09:09:17 --> Output Class Initialized
INFO - 2023-03-02 09:09:17 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:17 --> Input Class Initialized
INFO - 2023-03-02 09:09:17 --> Language Class Initialized
INFO - 2023-03-02 09:09:17 --> Loader Class Initialized
INFO - 2023-03-02 09:09:17 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:17 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:17 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:17 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:17 --> Total execution time: 0.0541
INFO - 2023-03-02 09:09:19 --> Config Class Initialized
INFO - 2023-03-02 09:09:19 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:19 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:19 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:19 --> URI Class Initialized
INFO - 2023-03-02 09:09:19 --> Router Class Initialized
INFO - 2023-03-02 09:09:19 --> Output Class Initialized
INFO - 2023-03-02 09:09:19 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:19 --> Input Class Initialized
INFO - 2023-03-02 09:09:19 --> Language Class Initialized
INFO - 2023-03-02 09:09:19 --> Loader Class Initialized
INFO - 2023-03-02 09:09:19 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:19 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:19 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:19 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:19 --> Total execution time: 0.0564
INFO - 2023-03-02 09:09:19 --> Config Class Initialized
INFO - 2023-03-02 09:09:19 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:19 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:19 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:19 --> URI Class Initialized
INFO - 2023-03-02 09:09:19 --> Router Class Initialized
INFO - 2023-03-02 09:09:19 --> Output Class Initialized
INFO - 2023-03-02 09:09:19 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:19 --> Input Class Initialized
INFO - 2023-03-02 09:09:19 --> Language Class Initialized
INFO - 2023-03-02 09:09:19 --> Loader Class Initialized
INFO - 2023-03-02 09:09:19 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:19 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:19 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:19 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:19 --> Total execution time: 0.0911
INFO - 2023-03-02 09:09:20 --> Config Class Initialized
INFO - 2023-03-02 09:09:20 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:20 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:20 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:20 --> URI Class Initialized
INFO - 2023-03-02 09:09:20 --> Router Class Initialized
INFO - 2023-03-02 09:09:20 --> Output Class Initialized
INFO - 2023-03-02 09:09:20 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:20 --> Input Class Initialized
INFO - 2023-03-02 09:09:20 --> Language Class Initialized
INFO - 2023-03-02 09:09:20 --> Loader Class Initialized
INFO - 2023-03-02 09:09:20 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:20 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:20 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:20 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:20 --> Model "Login_model" initialized
INFO - 2023-03-02 09:09:20 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:20 --> Total execution time: 0.1292
INFO - 2023-03-02 09:09:20 --> Config Class Initialized
INFO - 2023-03-02 09:09:20 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:20 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:20 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:20 --> URI Class Initialized
INFO - 2023-03-02 09:09:20 --> Router Class Initialized
INFO - 2023-03-02 09:09:20 --> Output Class Initialized
INFO - 2023-03-02 09:09:20 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:20 --> Input Class Initialized
INFO - 2023-03-02 09:09:20 --> Language Class Initialized
INFO - 2023-03-02 09:09:20 --> Loader Class Initialized
INFO - 2023-03-02 09:09:20 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:20 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:20 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:20 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:20 --> Model "Login_model" initialized
INFO - 2023-03-02 09:09:21 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:21 --> Total execution time: 0.0813
INFO - 2023-03-02 09:09:35 --> Config Class Initialized
INFO - 2023-03-02 09:09:35 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:35 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:35 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:35 --> URI Class Initialized
INFO - 2023-03-02 09:09:35 --> Router Class Initialized
INFO - 2023-03-02 09:09:35 --> Output Class Initialized
INFO - 2023-03-02 09:09:35 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:35 --> Input Class Initialized
INFO - 2023-03-02 09:09:35 --> Language Class Initialized
INFO - 2023-03-02 09:09:35 --> Loader Class Initialized
INFO - 2023-03-02 09:09:35 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:35 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:35 --> Total execution time: 0.0040
INFO - 2023-03-02 09:09:35 --> Config Class Initialized
INFO - 2023-03-02 09:09:35 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:35 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:35 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:35 --> URI Class Initialized
INFO - 2023-03-02 09:09:35 --> Router Class Initialized
INFO - 2023-03-02 09:09:35 --> Output Class Initialized
INFO - 2023-03-02 09:09:35 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:35 --> Input Class Initialized
INFO - 2023-03-02 09:09:35 --> Language Class Initialized
INFO - 2023-03-02 09:09:35 --> Loader Class Initialized
INFO - 2023-03-02 09:09:35 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:35 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:35 --> Model "Login_model" initialized
INFO - 2023-03-02 09:09:35 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:35 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:35 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:35 --> Total execution time: 0.0246
INFO - 2023-03-02 09:09:35 --> Config Class Initialized
INFO - 2023-03-02 09:09:35 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:35 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:35 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:35 --> URI Class Initialized
INFO - 2023-03-02 09:09:35 --> Router Class Initialized
INFO - 2023-03-02 09:09:35 --> Output Class Initialized
INFO - 2023-03-02 09:09:35 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:35 --> Input Class Initialized
INFO - 2023-03-02 09:09:35 --> Language Class Initialized
INFO - 2023-03-02 09:09:35 --> Loader Class Initialized
INFO - 2023-03-02 09:09:35 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:35 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:35 --> Total execution time: 0.0463
INFO - 2023-03-02 09:09:35 --> Config Class Initialized
INFO - 2023-03-02 09:09:35 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:35 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:35 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:35 --> URI Class Initialized
INFO - 2023-03-02 09:09:35 --> Router Class Initialized
INFO - 2023-03-02 09:09:35 --> Output Class Initialized
INFO - 2023-03-02 09:09:35 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:35 --> Input Class Initialized
INFO - 2023-03-02 09:09:35 --> Language Class Initialized
INFO - 2023-03-02 09:09:35 --> Loader Class Initialized
INFO - 2023-03-02 09:09:35 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:35 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:35 --> Model "Login_model" initialized
INFO - 2023-03-02 09:09:35 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:35 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:35 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:35 --> Total execution time: 0.0258
INFO - 2023-03-02 09:09:36 --> Config Class Initialized
INFO - 2023-03-02 09:09:36 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:36 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:36 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:36 --> URI Class Initialized
INFO - 2023-03-02 09:09:36 --> Router Class Initialized
INFO - 2023-03-02 09:09:36 --> Output Class Initialized
INFO - 2023-03-02 09:09:36 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:36 --> Input Class Initialized
INFO - 2023-03-02 09:09:36 --> Language Class Initialized
INFO - 2023-03-02 09:09:36 --> Loader Class Initialized
INFO - 2023-03-02 09:09:36 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:36 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:36 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:36 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:36 --> Total execution time: 0.0154
INFO - 2023-03-02 09:09:36 --> Config Class Initialized
INFO - 2023-03-02 09:09:36 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:36 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:36 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:36 --> URI Class Initialized
INFO - 2023-03-02 09:09:36 --> Router Class Initialized
INFO - 2023-03-02 09:09:36 --> Output Class Initialized
INFO - 2023-03-02 09:09:36 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:36 --> Input Class Initialized
INFO - 2023-03-02 09:09:36 --> Language Class Initialized
INFO - 2023-03-02 09:09:36 --> Loader Class Initialized
INFO - 2023-03-02 09:09:36 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:36 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:36 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:36 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:36 --> Total execution time: 0.0529
INFO - 2023-03-02 09:09:39 --> Config Class Initialized
INFO - 2023-03-02 09:09:39 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:39 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:39 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:39 --> URI Class Initialized
INFO - 2023-03-02 09:09:39 --> Router Class Initialized
INFO - 2023-03-02 09:09:39 --> Output Class Initialized
INFO - 2023-03-02 09:09:39 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:39 --> Input Class Initialized
INFO - 2023-03-02 09:09:39 --> Language Class Initialized
INFO - 2023-03-02 09:09:39 --> Loader Class Initialized
INFO - 2023-03-02 09:09:39 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:39 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:39 --> Total execution time: 0.0081
INFO - 2023-03-02 09:09:39 --> Config Class Initialized
INFO - 2023-03-02 09:09:39 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:39 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:39 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:39 --> URI Class Initialized
INFO - 2023-03-02 09:09:39 --> Router Class Initialized
INFO - 2023-03-02 09:09:39 --> Output Class Initialized
INFO - 2023-03-02 09:09:39 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:39 --> Input Class Initialized
INFO - 2023-03-02 09:09:39 --> Language Class Initialized
INFO - 2023-03-02 09:09:39 --> Loader Class Initialized
INFO - 2023-03-02 09:09:39 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:39 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:39 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:39 --> Model "Node_model" initialized
INFO - 2023-03-02 09:09:39 --> Model "Grafana_model" initialized
INFO - 2023-03-02 09:09:39 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:39 --> Total execution time: 0.1976
INFO - 2023-03-02 09:09:46 --> Config Class Initialized
INFO - 2023-03-02 09:09:46 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:46 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:46 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:46 --> URI Class Initialized
INFO - 2023-03-02 09:09:46 --> Router Class Initialized
INFO - 2023-03-02 09:09:46 --> Output Class Initialized
INFO - 2023-03-02 09:09:46 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:46 --> Input Class Initialized
INFO - 2023-03-02 09:09:46 --> Language Class Initialized
INFO - 2023-03-02 09:09:46 --> Loader Class Initialized
INFO - 2023-03-02 09:09:46 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:46 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:46 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:46 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:46 --> Model "Login_model" initialized
INFO - 2023-03-02 09:09:46 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:46 --> Total execution time: 0.1628
INFO - 2023-03-02 09:09:46 --> Config Class Initialized
INFO - 2023-03-02 09:09:46 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:46 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:46 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:46 --> URI Class Initialized
INFO - 2023-03-02 09:09:46 --> Router Class Initialized
INFO - 2023-03-02 09:09:46 --> Output Class Initialized
INFO - 2023-03-02 09:09:46 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:46 --> Input Class Initialized
INFO - 2023-03-02 09:09:46 --> Language Class Initialized
INFO - 2023-03-02 09:09:46 --> Loader Class Initialized
INFO - 2023-03-02 09:09:46 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:46 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:46 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:46 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:46 --> Model "Login_model" initialized
INFO - 2023-03-02 09:09:46 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:46 --> Total execution time: 0.0406
INFO - 2023-03-02 09:09:50 --> Config Class Initialized
INFO - 2023-03-02 09:09:50 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:50 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:50 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:50 --> URI Class Initialized
INFO - 2023-03-02 09:09:50 --> Router Class Initialized
INFO - 2023-03-02 09:09:50 --> Output Class Initialized
INFO - 2023-03-02 09:09:50 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:50 --> Input Class Initialized
INFO - 2023-03-02 09:09:50 --> Language Class Initialized
INFO - 2023-03-02 09:09:50 --> Loader Class Initialized
INFO - 2023-03-02 09:09:50 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:50 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:50 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:50 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:50 --> Total execution time: 0.0528
INFO - 2023-03-02 09:09:50 --> Config Class Initialized
INFO - 2023-03-02 09:09:50 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:09:50 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:09:50 --> Utf8 Class Initialized
INFO - 2023-03-02 09:09:50 --> URI Class Initialized
INFO - 2023-03-02 09:09:50 --> Router Class Initialized
INFO - 2023-03-02 09:09:50 --> Output Class Initialized
INFO - 2023-03-02 09:09:50 --> Security Class Initialized
DEBUG - 2023-03-02 09:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:09:50 --> Input Class Initialized
INFO - 2023-03-02 09:09:50 --> Language Class Initialized
INFO - 2023-03-02 09:09:50 --> Loader Class Initialized
INFO - 2023-03-02 09:09:50 --> Controller Class Initialized
DEBUG - 2023-03-02 09:09:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:09:50 --> Database Driver Class Initialized
INFO - 2023-03-02 09:09:50 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:09:50 --> Final output sent to browser
DEBUG - 2023-03-02 09:09:50 --> Total execution time: 0.0440
INFO - 2023-03-02 09:10:25 --> Config Class Initialized
INFO - 2023-03-02 09:10:25 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:10:25 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:10:25 --> Utf8 Class Initialized
INFO - 2023-03-02 09:10:25 --> URI Class Initialized
INFO - 2023-03-02 09:10:25 --> Router Class Initialized
INFO - 2023-03-02 09:10:25 --> Output Class Initialized
INFO - 2023-03-02 09:10:25 --> Security Class Initialized
DEBUG - 2023-03-02 09:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:10:25 --> Input Class Initialized
INFO - 2023-03-02 09:10:25 --> Language Class Initialized
INFO - 2023-03-02 09:10:25 --> Loader Class Initialized
INFO - 2023-03-02 09:10:25 --> Controller Class Initialized
DEBUG - 2023-03-02 09:10:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:10:25 --> Database Driver Class Initialized
INFO - 2023-03-02 09:10:25 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:10:25 --> Final output sent to browser
DEBUG - 2023-03-02 09:10:25 --> Total execution time: 0.0565
INFO - 2023-03-02 09:10:25 --> Config Class Initialized
INFO - 2023-03-02 09:10:25 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:10:25 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:10:25 --> Utf8 Class Initialized
INFO - 2023-03-02 09:10:25 --> URI Class Initialized
INFO - 2023-03-02 09:10:25 --> Router Class Initialized
INFO - 2023-03-02 09:10:25 --> Output Class Initialized
INFO - 2023-03-02 09:10:25 --> Security Class Initialized
DEBUG - 2023-03-02 09:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:10:25 --> Input Class Initialized
INFO - 2023-03-02 09:10:25 --> Language Class Initialized
INFO - 2023-03-02 09:10:25 --> Loader Class Initialized
INFO - 2023-03-02 09:10:25 --> Controller Class Initialized
DEBUG - 2023-03-02 09:10:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:10:25 --> Database Driver Class Initialized
INFO - 2023-03-02 09:10:25 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:10:25 --> Final output sent to browser
DEBUG - 2023-03-02 09:10:25 --> Total execution time: 0.0523
INFO - 2023-03-02 09:20:55 --> Config Class Initialized
INFO - 2023-03-02 09:20:55 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:20:55 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:20:55 --> Utf8 Class Initialized
INFO - 2023-03-02 09:20:55 --> URI Class Initialized
INFO - 2023-03-02 09:20:55 --> Router Class Initialized
INFO - 2023-03-02 09:20:55 --> Output Class Initialized
INFO - 2023-03-02 09:20:55 --> Security Class Initialized
DEBUG - 2023-03-02 09:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:20:55 --> Input Class Initialized
INFO - 2023-03-02 09:20:55 --> Language Class Initialized
INFO - 2023-03-02 09:20:55 --> Loader Class Initialized
INFO - 2023-03-02 09:20:55 --> Controller Class Initialized
DEBUG - 2023-03-02 09:20:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:20:55 --> Database Driver Class Initialized
INFO - 2023-03-02 09:20:55 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:20:55 --> Final output sent to browser
DEBUG - 2023-03-02 09:20:55 --> Total execution time: 0.2181
INFO - 2023-03-02 09:20:55 --> Config Class Initialized
INFO - 2023-03-02 09:20:55 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:20:55 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:20:55 --> Utf8 Class Initialized
INFO - 2023-03-02 09:20:55 --> URI Class Initialized
INFO - 2023-03-02 09:20:55 --> Router Class Initialized
INFO - 2023-03-02 09:20:55 --> Output Class Initialized
INFO - 2023-03-02 09:20:55 --> Security Class Initialized
DEBUG - 2023-03-02 09:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:20:55 --> Input Class Initialized
INFO - 2023-03-02 09:20:55 --> Language Class Initialized
INFO - 2023-03-02 09:20:55 --> Loader Class Initialized
INFO - 2023-03-02 09:20:55 --> Controller Class Initialized
DEBUG - 2023-03-02 09:20:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:20:55 --> Database Driver Class Initialized
INFO - 2023-03-02 09:20:55 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:20:55 --> Final output sent to browser
DEBUG - 2023-03-02 09:20:55 --> Total execution time: 0.1744
INFO - 2023-03-02 09:20:58 --> Config Class Initialized
INFO - 2023-03-02 09:20:58 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:20:58 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:20:58 --> Utf8 Class Initialized
INFO - 2023-03-02 09:20:58 --> URI Class Initialized
INFO - 2023-03-02 09:20:58 --> Router Class Initialized
INFO - 2023-03-02 09:20:58 --> Output Class Initialized
INFO - 2023-03-02 09:20:58 --> Security Class Initialized
DEBUG - 2023-03-02 09:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:20:58 --> Input Class Initialized
INFO - 2023-03-02 09:20:58 --> Language Class Initialized
INFO - 2023-03-02 09:20:58 --> Loader Class Initialized
INFO - 2023-03-02 09:20:58 --> Controller Class Initialized
DEBUG - 2023-03-02 09:20:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:20:58 --> Database Driver Class Initialized
INFO - 2023-03-02 09:20:58 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:20:58 --> Final output sent to browser
DEBUG - 2023-03-02 09:20:58 --> Total execution time: 0.6217
INFO - 2023-03-02 09:20:58 --> Config Class Initialized
INFO - 2023-03-02 09:20:58 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:20:58 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:20:58 --> Utf8 Class Initialized
INFO - 2023-03-02 09:20:58 --> URI Class Initialized
INFO - 2023-03-02 09:20:58 --> Router Class Initialized
INFO - 2023-03-02 09:20:58 --> Output Class Initialized
INFO - 2023-03-02 09:20:58 --> Security Class Initialized
DEBUG - 2023-03-02 09:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:20:58 --> Input Class Initialized
INFO - 2023-03-02 09:20:58 --> Language Class Initialized
INFO - 2023-03-02 09:20:58 --> Loader Class Initialized
INFO - 2023-03-02 09:20:58 --> Controller Class Initialized
DEBUG - 2023-03-02 09:20:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:20:58 --> Database Driver Class Initialized
INFO - 2023-03-02 09:20:58 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:20:59 --> Final output sent to browser
DEBUG - 2023-03-02 09:20:59 --> Total execution time: 0.6170
INFO - 2023-03-02 09:21:02 --> Config Class Initialized
INFO - 2023-03-02 09:21:02 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:21:02 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:21:02 --> Utf8 Class Initialized
INFO - 2023-03-02 09:21:02 --> URI Class Initialized
INFO - 2023-03-02 09:21:02 --> Router Class Initialized
INFO - 2023-03-02 09:21:02 --> Output Class Initialized
INFO - 2023-03-02 09:21:02 --> Security Class Initialized
DEBUG - 2023-03-02 09:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:21:02 --> Input Class Initialized
INFO - 2023-03-02 09:21:02 --> Language Class Initialized
INFO - 2023-03-02 09:21:02 --> Loader Class Initialized
INFO - 2023-03-02 09:21:02 --> Controller Class Initialized
DEBUG - 2023-03-02 09:21:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:21:02 --> Database Driver Class Initialized
INFO - 2023-03-02 09:21:02 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:21:02 --> Database Driver Class Initialized
INFO - 2023-03-02 09:21:02 --> Model "Login_model" initialized
INFO - 2023-03-02 09:21:03 --> Final output sent to browser
DEBUG - 2023-03-02 09:21:03 --> Total execution time: 0.4951
INFO - 2023-03-02 09:21:03 --> Config Class Initialized
INFO - 2023-03-02 09:21:03 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:21:03 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:21:03 --> Utf8 Class Initialized
INFO - 2023-03-02 09:21:03 --> URI Class Initialized
INFO - 2023-03-02 09:21:03 --> Router Class Initialized
INFO - 2023-03-02 09:21:03 --> Output Class Initialized
INFO - 2023-03-02 09:21:03 --> Security Class Initialized
DEBUG - 2023-03-02 09:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:21:03 --> Input Class Initialized
INFO - 2023-03-02 09:21:03 --> Language Class Initialized
INFO - 2023-03-02 09:21:03 --> Loader Class Initialized
INFO - 2023-03-02 09:21:03 --> Controller Class Initialized
DEBUG - 2023-03-02 09:21:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:21:03 --> Database Driver Class Initialized
INFO - 2023-03-02 09:21:03 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:21:03 --> Database Driver Class Initialized
INFO - 2023-03-02 09:21:03 --> Model "Login_model" initialized
INFO - 2023-03-02 09:21:03 --> Final output sent to browser
DEBUG - 2023-03-02 09:21:03 --> Total execution time: 0.0983
INFO - 2023-03-02 09:41:17 --> Config Class Initialized
INFO - 2023-03-02 09:41:17 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:41:17 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:41:17 --> Utf8 Class Initialized
INFO - 2023-03-02 09:41:17 --> URI Class Initialized
INFO - 2023-03-02 09:41:17 --> Router Class Initialized
INFO - 2023-03-02 09:41:17 --> Output Class Initialized
INFO - 2023-03-02 09:41:17 --> Security Class Initialized
DEBUG - 2023-03-02 09:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:41:17 --> Input Class Initialized
INFO - 2023-03-02 09:41:17 --> Language Class Initialized
INFO - 2023-03-02 09:41:17 --> Loader Class Initialized
INFO - 2023-03-02 09:41:17 --> Controller Class Initialized
DEBUG - 2023-03-02 09:41:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:41:17 --> Database Driver Class Initialized
INFO - 2023-03-02 09:41:17 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:41:17 --> Final output sent to browser
DEBUG - 2023-03-02 09:41:17 --> Total execution time: 0.0440
INFO - 2023-03-02 09:41:17 --> Config Class Initialized
INFO - 2023-03-02 09:41:17 --> Hooks Class Initialized
DEBUG - 2023-03-02 09:41:17 --> UTF-8 Support Enabled
INFO - 2023-03-02 09:41:17 --> Utf8 Class Initialized
INFO - 2023-03-02 09:41:17 --> URI Class Initialized
INFO - 2023-03-02 09:41:17 --> Router Class Initialized
INFO - 2023-03-02 09:41:17 --> Output Class Initialized
INFO - 2023-03-02 09:41:17 --> Security Class Initialized
DEBUG - 2023-03-02 09:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 09:41:17 --> Input Class Initialized
INFO - 2023-03-02 09:41:17 --> Language Class Initialized
INFO - 2023-03-02 09:41:17 --> Loader Class Initialized
INFO - 2023-03-02 09:41:17 --> Controller Class Initialized
DEBUG - 2023-03-02 09:41:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 09:41:17 --> Database Driver Class Initialized
INFO - 2023-03-02 09:41:17 --> Model "Cluster_model" initialized
INFO - 2023-03-02 09:41:17 --> Final output sent to browser
DEBUG - 2023-03-02 09:41:17 --> Total execution time: 0.0160
INFO - 2023-03-02 10:15:27 --> Config Class Initialized
INFO - 2023-03-02 10:15:27 --> Hooks Class Initialized
DEBUG - 2023-03-02 10:15:27 --> UTF-8 Support Enabled
INFO - 2023-03-02 10:15:27 --> Utf8 Class Initialized
INFO - 2023-03-02 10:15:27 --> URI Class Initialized
INFO - 2023-03-02 10:15:27 --> Router Class Initialized
INFO - 2023-03-02 10:15:27 --> Output Class Initialized
INFO - 2023-03-02 10:15:27 --> Security Class Initialized
DEBUG - 2023-03-02 10:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 10:15:27 --> Input Class Initialized
INFO - 2023-03-02 10:15:27 --> Language Class Initialized
INFO - 2023-03-02 10:15:27 --> Loader Class Initialized
INFO - 2023-03-02 10:15:27 --> Controller Class Initialized
DEBUG - 2023-03-02 10:15:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 10:15:27 --> Database Driver Class Initialized
INFO - 2023-03-02 10:15:27 --> Model "Cluster_model" initialized
INFO - 2023-03-02 10:15:27 --> Database Driver Class Initialized
INFO - 2023-03-02 10:15:27 --> Model "Login_model" initialized
INFO - 2023-03-02 10:15:27 --> Final output sent to browser
DEBUG - 2023-03-02 10:15:27 --> Total execution time: 0.0486
INFO - 2023-03-02 10:15:27 --> Config Class Initialized
INFO - 2023-03-02 10:15:27 --> Hooks Class Initialized
DEBUG - 2023-03-02 10:15:27 --> UTF-8 Support Enabled
INFO - 2023-03-02 10:15:27 --> Utf8 Class Initialized
INFO - 2023-03-02 10:15:27 --> URI Class Initialized
INFO - 2023-03-02 10:15:27 --> Router Class Initialized
INFO - 2023-03-02 10:15:27 --> Output Class Initialized
INFO - 2023-03-02 10:15:27 --> Security Class Initialized
DEBUG - 2023-03-02 10:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 10:15:27 --> Input Class Initialized
INFO - 2023-03-02 10:15:27 --> Language Class Initialized
INFO - 2023-03-02 10:15:27 --> Loader Class Initialized
INFO - 2023-03-02 10:15:27 --> Controller Class Initialized
DEBUG - 2023-03-02 10:15:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 10:15:27 --> Database Driver Class Initialized
INFO - 2023-03-02 10:15:27 --> Model "Cluster_model" initialized
INFO - 2023-03-02 10:15:27 --> Database Driver Class Initialized
INFO - 2023-03-02 10:15:27 --> Model "Login_model" initialized
INFO - 2023-03-02 10:15:27 --> Final output sent to browser
DEBUG - 2023-03-02 10:15:27 --> Total execution time: 0.0820
INFO - 2023-03-02 10:15:30 --> Config Class Initialized
INFO - 2023-03-02 10:15:30 --> Hooks Class Initialized
DEBUG - 2023-03-02 10:15:30 --> UTF-8 Support Enabled
INFO - 2023-03-02 10:15:30 --> Utf8 Class Initialized
INFO - 2023-03-02 10:15:30 --> URI Class Initialized
INFO - 2023-03-02 10:15:30 --> Router Class Initialized
INFO - 2023-03-02 10:15:30 --> Output Class Initialized
INFO - 2023-03-02 10:15:30 --> Security Class Initialized
DEBUG - 2023-03-02 10:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 10:15:30 --> Input Class Initialized
INFO - 2023-03-02 10:15:30 --> Language Class Initialized
INFO - 2023-03-02 10:15:30 --> Loader Class Initialized
INFO - 2023-03-02 10:15:30 --> Controller Class Initialized
DEBUG - 2023-03-02 10:15:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 10:15:30 --> Database Driver Class Initialized
INFO - 2023-03-02 10:15:30 --> Model "Cluster_model" initialized
INFO - 2023-03-02 10:15:30 --> Final output sent to browser
DEBUG - 2023-03-02 10:15:30 --> Total execution time: 0.2549
INFO - 2023-03-02 10:15:30 --> Config Class Initialized
INFO - 2023-03-02 10:15:30 --> Hooks Class Initialized
DEBUG - 2023-03-02 10:15:30 --> UTF-8 Support Enabled
INFO - 2023-03-02 10:15:30 --> Utf8 Class Initialized
INFO - 2023-03-02 10:15:30 --> URI Class Initialized
INFO - 2023-03-02 10:15:30 --> Router Class Initialized
INFO - 2023-03-02 10:15:30 --> Output Class Initialized
INFO - 2023-03-02 10:15:30 --> Security Class Initialized
DEBUG - 2023-03-02 10:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 10:15:30 --> Input Class Initialized
INFO - 2023-03-02 10:15:30 --> Language Class Initialized
INFO - 2023-03-02 10:15:30 --> Loader Class Initialized
INFO - 2023-03-02 10:15:30 --> Controller Class Initialized
DEBUG - 2023-03-02 10:15:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 10:15:30 --> Database Driver Class Initialized
INFO - 2023-03-02 10:15:30 --> Model "Cluster_model" initialized
INFO - 2023-03-02 10:15:30 --> Final output sent to browser
DEBUG - 2023-03-02 10:15:30 --> Total execution time: 0.0520
INFO - 2023-03-02 10:15:31 --> Config Class Initialized
INFO - 2023-03-02 10:15:31 --> Hooks Class Initialized
DEBUG - 2023-03-02 10:15:31 --> UTF-8 Support Enabled
INFO - 2023-03-02 10:15:31 --> Utf8 Class Initialized
INFO - 2023-03-02 10:15:31 --> URI Class Initialized
INFO - 2023-03-02 10:15:31 --> Router Class Initialized
INFO - 2023-03-02 10:15:31 --> Output Class Initialized
INFO - 2023-03-02 10:15:31 --> Security Class Initialized
DEBUG - 2023-03-02 10:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 10:15:31 --> Input Class Initialized
INFO - 2023-03-02 10:15:31 --> Language Class Initialized
INFO - 2023-03-02 10:15:31 --> Loader Class Initialized
INFO - 2023-03-02 10:15:31 --> Controller Class Initialized
DEBUG - 2023-03-02 10:15:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 10:15:31 --> Database Driver Class Initialized
INFO - 2023-03-02 10:15:31 --> Model "Cluster_model" initialized
INFO - 2023-03-02 10:15:31 --> Final output sent to browser
DEBUG - 2023-03-02 10:15:31 --> Total execution time: 0.0485
INFO - 2023-03-02 10:15:31 --> Config Class Initialized
INFO - 2023-03-02 10:15:31 --> Hooks Class Initialized
DEBUG - 2023-03-02 10:15:31 --> UTF-8 Support Enabled
INFO - 2023-03-02 10:15:31 --> Utf8 Class Initialized
INFO - 2023-03-02 10:15:31 --> URI Class Initialized
INFO - 2023-03-02 10:15:31 --> Router Class Initialized
INFO - 2023-03-02 10:15:31 --> Output Class Initialized
INFO - 2023-03-02 10:15:31 --> Security Class Initialized
DEBUG - 2023-03-02 10:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 10:15:31 --> Input Class Initialized
INFO - 2023-03-02 10:15:31 --> Language Class Initialized
INFO - 2023-03-02 10:15:31 --> Loader Class Initialized
INFO - 2023-03-02 10:15:31 --> Controller Class Initialized
DEBUG - 2023-03-02 10:15:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 10:15:31 --> Database Driver Class Initialized
INFO - 2023-03-02 10:15:31 --> Model "Cluster_model" initialized
INFO - 2023-03-02 10:15:31 --> Final output sent to browser
DEBUG - 2023-03-02 10:15:31 --> Total execution time: 0.0812
INFO - 2023-03-02 10:46:19 --> Config Class Initialized
INFO - 2023-03-02 10:46:19 --> Hooks Class Initialized
DEBUG - 2023-03-02 10:46:19 --> UTF-8 Support Enabled
INFO - 2023-03-02 10:46:19 --> Utf8 Class Initialized
INFO - 2023-03-02 10:46:19 --> URI Class Initialized
INFO - 2023-03-02 10:46:19 --> Router Class Initialized
INFO - 2023-03-02 10:46:19 --> Output Class Initialized
INFO - 2023-03-02 10:46:19 --> Security Class Initialized
DEBUG - 2023-03-02 10:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 10:46:19 --> Input Class Initialized
INFO - 2023-03-02 10:46:19 --> Language Class Initialized
INFO - 2023-03-02 10:46:19 --> Loader Class Initialized
INFO - 2023-03-02 10:46:19 --> Controller Class Initialized
DEBUG - 2023-03-02 10:46:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 10:46:19 --> Database Driver Class Initialized
INFO - 2023-03-02 10:46:19 --> Model "Cluster_model" initialized
INFO - 2023-03-02 10:46:19 --> Final output sent to browser
DEBUG - 2023-03-02 10:46:19 --> Total execution time: 0.1015
INFO - 2023-03-02 10:46:19 --> Config Class Initialized
INFO - 2023-03-02 10:46:19 --> Hooks Class Initialized
DEBUG - 2023-03-02 10:46:19 --> UTF-8 Support Enabled
INFO - 2023-03-02 10:46:19 --> Utf8 Class Initialized
INFO - 2023-03-02 10:46:19 --> URI Class Initialized
INFO - 2023-03-02 10:46:19 --> Router Class Initialized
INFO - 2023-03-02 10:46:19 --> Output Class Initialized
INFO - 2023-03-02 10:46:19 --> Security Class Initialized
DEBUG - 2023-03-02 10:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 10:46:19 --> Input Class Initialized
INFO - 2023-03-02 10:46:19 --> Language Class Initialized
INFO - 2023-03-02 10:46:19 --> Loader Class Initialized
INFO - 2023-03-02 10:46:19 --> Controller Class Initialized
DEBUG - 2023-03-02 10:46:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 10:46:19 --> Database Driver Class Initialized
INFO - 2023-03-02 10:46:19 --> Model "Cluster_model" initialized
INFO - 2023-03-02 10:46:19 --> Final output sent to browser
DEBUG - 2023-03-02 10:46:19 --> Total execution time: 0.0123
INFO - 2023-03-02 10:49:21 --> Config Class Initialized
INFO - 2023-03-02 10:49:21 --> Hooks Class Initialized
DEBUG - 2023-03-02 10:49:21 --> UTF-8 Support Enabled
INFO - 2023-03-02 10:49:21 --> Utf8 Class Initialized
INFO - 2023-03-02 10:49:21 --> URI Class Initialized
INFO - 2023-03-02 10:49:21 --> Router Class Initialized
INFO - 2023-03-02 10:49:21 --> Output Class Initialized
INFO - 2023-03-02 10:49:21 --> Security Class Initialized
DEBUG - 2023-03-02 10:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 10:49:21 --> Input Class Initialized
INFO - 2023-03-02 10:49:21 --> Language Class Initialized
INFO - 2023-03-02 10:49:21 --> Loader Class Initialized
INFO - 2023-03-02 10:49:21 --> Controller Class Initialized
DEBUG - 2023-03-02 10:49:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 10:49:21 --> Database Driver Class Initialized
INFO - 2023-03-02 10:49:21 --> Model "Cluster_model" initialized
INFO - 2023-03-02 10:49:21 --> Final output sent to browser
DEBUG - 2023-03-02 10:49:21 --> Total execution time: 0.0439
INFO - 2023-03-02 10:49:21 --> Config Class Initialized
INFO - 2023-03-02 10:49:21 --> Hooks Class Initialized
DEBUG - 2023-03-02 10:49:21 --> UTF-8 Support Enabled
INFO - 2023-03-02 10:49:21 --> Utf8 Class Initialized
INFO - 2023-03-02 10:49:21 --> URI Class Initialized
INFO - 2023-03-02 10:49:21 --> Router Class Initialized
INFO - 2023-03-02 10:49:21 --> Output Class Initialized
INFO - 2023-03-02 10:49:21 --> Security Class Initialized
DEBUG - 2023-03-02 10:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-02 10:49:21 --> Input Class Initialized
INFO - 2023-03-02 10:49:21 --> Language Class Initialized
INFO - 2023-03-02 10:49:21 --> Loader Class Initialized
INFO - 2023-03-02 10:49:21 --> Controller Class Initialized
DEBUG - 2023-03-02 10:49:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-02 10:49:21 --> Database Driver Class Initialized
INFO - 2023-03-02 10:49:21 --> Model "Cluster_model" initialized
INFO - 2023-03-02 10:49:21 --> Final output sent to browser
DEBUG - 2023-03-02 10:49:21 --> Total execution time: 0.0472
