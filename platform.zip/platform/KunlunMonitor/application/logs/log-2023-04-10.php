<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-10 07:01:36 --> Config Class Initialized
INFO - 2023-04-10 07:01:36 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:01:36 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:01:36 --> Utf8 Class Initialized
INFO - 2023-04-10 07:01:36 --> URI Class Initialized
INFO - 2023-04-10 07:01:36 --> Router Class Initialized
INFO - 2023-04-10 07:01:36 --> Output Class Initialized
INFO - 2023-04-10 07:01:36 --> Security Class Initialized
DEBUG - 2023-04-10 07:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:01:36 --> Input Class Initialized
INFO - 2023-04-10 07:01:36 --> Language Class Initialized
INFO - 2023-04-10 07:01:36 --> Loader Class Initialized
INFO - 2023-04-10 07:01:36 --> Controller Class Initialized
INFO - 2023-04-10 07:01:36 --> Helper loaded: form_helper
INFO - 2023-04-10 07:01:36 --> Helper loaded: url_helper
DEBUG - 2023-04-10 07:01:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:01:36 --> Model "Change_model" initialized
INFO - 2023-04-10 07:01:37 --> Model "Grafana_model" initialized
INFO - 2023-04-10 07:01:37 --> Final output sent to browser
DEBUG - 2023-04-10 07:01:37 --> Total execution time: 1.2392
INFO - 2023-04-10 07:01:37 --> Config Class Initialized
INFO - 2023-04-10 07:01:38 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:01:38 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:01:38 --> Utf8 Class Initialized
INFO - 2023-04-10 07:01:38 --> URI Class Initialized
INFO - 2023-04-10 07:01:38 --> Router Class Initialized
INFO - 2023-04-10 07:01:38 --> Output Class Initialized
INFO - 2023-04-10 07:01:38 --> Security Class Initialized
DEBUG - 2023-04-10 07:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:01:38 --> Input Class Initialized
INFO - 2023-04-10 07:01:38 --> Language Class Initialized
INFO - 2023-04-10 07:01:38 --> Loader Class Initialized
INFO - 2023-04-10 07:01:38 --> Controller Class Initialized
INFO - 2023-04-10 07:01:38 --> Helper loaded: form_helper
INFO - 2023-04-10 07:01:38 --> Helper loaded: url_helper
DEBUG - 2023-04-10 07:01:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:01:38 --> Final output sent to browser
DEBUG - 2023-04-10 07:01:38 --> Total execution time: 0.0513
INFO - 2023-04-10 07:01:38 --> Config Class Initialized
INFO - 2023-04-10 07:01:38 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:01:38 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:01:38 --> Utf8 Class Initialized
INFO - 2023-04-10 07:01:38 --> URI Class Initialized
INFO - 2023-04-10 07:01:38 --> Router Class Initialized
INFO - 2023-04-10 07:01:38 --> Output Class Initialized
INFO - 2023-04-10 07:01:38 --> Security Class Initialized
DEBUG - 2023-04-10 07:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:01:38 --> Input Class Initialized
INFO - 2023-04-10 07:01:38 --> Language Class Initialized
INFO - 2023-04-10 07:01:38 --> Loader Class Initialized
INFO - 2023-04-10 07:01:38 --> Controller Class Initialized
INFO - 2023-04-10 07:01:38 --> Helper loaded: form_helper
INFO - 2023-04-10 07:01:38 --> Helper loaded: url_helper
DEBUG - 2023-04-10 07:01:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:01:38 --> Database Driver Class Initialized
INFO - 2023-04-10 07:01:38 --> Model "Login_model" initialized
INFO - 2023-04-10 07:01:38 --> Final output sent to browser
DEBUG - 2023-04-10 07:01:38 --> Total execution time: 0.0572
INFO - 2023-04-10 07:01:38 --> Config Class Initialized
INFO - 2023-04-10 07:01:38 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:01:38 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:01:38 --> Utf8 Class Initialized
INFO - 2023-04-10 07:01:38 --> URI Class Initialized
INFO - 2023-04-10 07:01:38 --> Router Class Initialized
INFO - 2023-04-10 07:01:38 --> Output Class Initialized
INFO - 2023-04-10 07:01:38 --> Security Class Initialized
DEBUG - 2023-04-10 07:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:01:38 --> Input Class Initialized
INFO - 2023-04-10 07:01:38 --> Language Class Initialized
INFO - 2023-04-10 07:01:38 --> Loader Class Initialized
INFO - 2023-04-10 07:01:38 --> Controller Class Initialized
DEBUG - 2023-04-10 07:01:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:01:38 --> Database Driver Class Initialized
INFO - 2023-04-10 07:01:38 --> Model "Cluster_model" initialized
INFO - 2023-04-10 07:01:38 --> Final output sent to browser
DEBUG - 2023-04-10 07:01:38 --> Total execution time: 0.0632
INFO - 2023-04-10 07:01:38 --> Config Class Initialized
INFO - 2023-04-10 07:01:38 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:01:38 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:01:38 --> Utf8 Class Initialized
INFO - 2023-04-10 07:01:38 --> URI Class Initialized
INFO - 2023-04-10 07:01:38 --> Router Class Initialized
INFO - 2023-04-10 07:01:38 --> Output Class Initialized
INFO - 2023-04-10 07:01:38 --> Security Class Initialized
DEBUG - 2023-04-10 07:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:01:38 --> Input Class Initialized
INFO - 2023-04-10 07:01:38 --> Language Class Initialized
INFO - 2023-04-10 07:01:38 --> Loader Class Initialized
INFO - 2023-04-10 07:01:38 --> Controller Class Initialized
DEBUG - 2023-04-10 07:01:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:01:38 --> Database Driver Class Initialized
INFO - 2023-04-10 07:01:38 --> Model "Cluster_model" initialized
INFO - 2023-04-10 07:01:38 --> Final output sent to browser
DEBUG - 2023-04-10 07:01:38 --> Total execution time: 0.0157
INFO - 2023-04-10 07:01:38 --> Config Class Initialized
INFO - 2023-04-10 07:01:38 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:01:38 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:01:38 --> Utf8 Class Initialized
INFO - 2023-04-10 07:01:38 --> URI Class Initialized
INFO - 2023-04-10 07:01:38 --> Router Class Initialized
INFO - 2023-04-10 07:01:38 --> Output Class Initialized
INFO - 2023-04-10 07:01:38 --> Security Class Initialized
DEBUG - 2023-04-10 07:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:01:38 --> Input Class Initialized
INFO - 2023-04-10 07:01:38 --> Language Class Initialized
INFO - 2023-04-10 07:01:38 --> Loader Class Initialized
INFO - 2023-04-10 07:01:38 --> Controller Class Initialized
DEBUG - 2023-04-10 07:01:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:01:38 --> Database Driver Class Initialized
INFO - 2023-04-10 07:01:38 --> Model "Cluster_model" initialized
INFO - 2023-04-10 07:01:38 --> Database Driver Class Initialized
INFO - 2023-04-10 07:01:38 --> Model "Login_model" initialized
INFO - 2023-04-10 07:01:38 --> Final output sent to browser
DEBUG - 2023-04-10 07:01:38 --> Total execution time: 0.1577
INFO - 2023-04-10 07:01:38 --> Config Class Initialized
INFO - 2023-04-10 07:01:38 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:01:38 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:01:38 --> Utf8 Class Initialized
INFO - 2023-04-10 07:01:38 --> URI Class Initialized
INFO - 2023-04-10 07:01:38 --> Router Class Initialized
INFO - 2023-04-10 07:01:38 --> Output Class Initialized
INFO - 2023-04-10 07:01:38 --> Security Class Initialized
DEBUG - 2023-04-10 07:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:01:38 --> Input Class Initialized
INFO - 2023-04-10 07:01:38 --> Language Class Initialized
INFO - 2023-04-10 07:01:38 --> Loader Class Initialized
INFO - 2023-04-10 07:01:38 --> Controller Class Initialized
DEBUG - 2023-04-10 07:01:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:01:38 --> Database Driver Class Initialized
INFO - 2023-04-10 07:01:38 --> Model "Cluster_model" initialized
INFO - 2023-04-10 07:01:38 --> Database Driver Class Initialized
INFO - 2023-04-10 07:01:38 --> Model "Login_model" initialized
INFO - 2023-04-10 07:01:38 --> Final output sent to browser
DEBUG - 2023-04-10 07:01:38 --> Total execution time: 0.1059
INFO - 2023-04-10 07:01:58 --> Config Class Initialized
INFO - 2023-04-10 07:01:58 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:01:58 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:01:58 --> Utf8 Class Initialized
INFO - 2023-04-10 07:01:58 --> URI Class Initialized
INFO - 2023-04-10 07:01:58 --> Router Class Initialized
INFO - 2023-04-10 07:01:58 --> Output Class Initialized
INFO - 2023-04-10 07:01:58 --> Security Class Initialized
DEBUG - 2023-04-10 07:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:01:58 --> Input Class Initialized
INFO - 2023-04-10 07:01:58 --> Language Class Initialized
INFO - 2023-04-10 07:01:58 --> Loader Class Initialized
INFO - 2023-04-10 07:01:58 --> Controller Class Initialized
INFO - 2023-04-10 07:01:58 --> Helper loaded: form_helper
INFO - 2023-04-10 07:01:58 --> Helper loaded: url_helper
DEBUG - 2023-04-10 07:01:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:01:58 --> Final output sent to browser
DEBUG - 2023-04-10 07:01:58 --> Total execution time: 0.0074
INFO - 2023-04-10 07:01:58 --> Config Class Initialized
INFO - 2023-04-10 07:01:58 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:01:58 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:01:58 --> Utf8 Class Initialized
INFO - 2023-04-10 07:01:58 --> URI Class Initialized
INFO - 2023-04-10 07:01:58 --> Router Class Initialized
INFO - 2023-04-10 07:01:58 --> Output Class Initialized
INFO - 2023-04-10 07:01:58 --> Security Class Initialized
DEBUG - 2023-04-10 07:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:01:58 --> Input Class Initialized
INFO - 2023-04-10 07:01:58 --> Language Class Initialized
INFO - 2023-04-10 07:01:58 --> Loader Class Initialized
INFO - 2023-04-10 07:01:58 --> Controller Class Initialized
INFO - 2023-04-10 07:01:58 --> Helper loaded: form_helper
INFO - 2023-04-10 07:01:58 --> Helper loaded: url_helper
DEBUG - 2023-04-10 07:01:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:01:58 --> Database Driver Class Initialized
INFO - 2023-04-10 07:01:58 --> Model "Login_model" initialized
INFO - 2023-04-10 07:01:58 --> Final output sent to browser
DEBUG - 2023-04-10 07:01:58 --> Total execution time: 0.0218
INFO - 2023-04-10 07:02:06 --> Config Class Initialized
INFO - 2023-04-10 07:02:06 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:02:06 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:02:06 --> Utf8 Class Initialized
INFO - 2023-04-10 07:02:06 --> URI Class Initialized
INFO - 2023-04-10 07:02:06 --> Router Class Initialized
INFO - 2023-04-10 07:02:06 --> Output Class Initialized
INFO - 2023-04-10 07:02:06 --> Security Class Initialized
DEBUG - 2023-04-10 07:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:02:06 --> Input Class Initialized
INFO - 2023-04-10 07:02:06 --> Language Class Initialized
INFO - 2023-04-10 07:02:06 --> Loader Class Initialized
INFO - 2023-04-10 07:02:06 --> Controller Class Initialized
INFO - 2023-04-10 07:02:06 --> Helper loaded: form_helper
INFO - 2023-04-10 07:02:06 --> Helper loaded: url_helper
DEBUG - 2023-04-10 07:02:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:02:06 --> Final output sent to browser
DEBUG - 2023-04-10 07:02:06 --> Total execution time: 0.0077
INFO - 2023-04-10 07:02:06 --> Config Class Initialized
INFO - 2023-04-10 07:02:06 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:02:06 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:02:06 --> Utf8 Class Initialized
INFO - 2023-04-10 07:02:06 --> URI Class Initialized
INFO - 2023-04-10 07:02:06 --> Router Class Initialized
INFO - 2023-04-10 07:02:06 --> Output Class Initialized
INFO - 2023-04-10 07:02:06 --> Security Class Initialized
DEBUG - 2023-04-10 07:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:02:06 --> Input Class Initialized
INFO - 2023-04-10 07:02:06 --> Language Class Initialized
INFO - 2023-04-10 07:02:06 --> Loader Class Initialized
INFO - 2023-04-10 07:02:06 --> Controller Class Initialized
INFO - 2023-04-10 07:02:06 --> Helper loaded: form_helper
INFO - 2023-04-10 07:02:06 --> Helper loaded: url_helper
DEBUG - 2023-04-10 07:02:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:02:06 --> Database Driver Class Initialized
INFO - 2023-04-10 07:02:07 --> Model "Login_model" initialized
INFO - 2023-04-10 07:02:07 --> Final output sent to browser
DEBUG - 2023-04-10 07:02:07 --> Total execution time: 0.0258
INFO - 2023-04-10 07:02:11 --> Config Class Initialized
INFO - 2023-04-10 07:02:11 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:02:11 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:02:11 --> Utf8 Class Initialized
INFO - 2023-04-10 07:02:11 --> URI Class Initialized
INFO - 2023-04-10 07:02:11 --> Router Class Initialized
INFO - 2023-04-10 07:02:11 --> Output Class Initialized
INFO - 2023-04-10 07:02:11 --> Security Class Initialized
DEBUG - 2023-04-10 07:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:02:11 --> Input Class Initialized
INFO - 2023-04-10 07:02:11 --> Language Class Initialized
INFO - 2023-04-10 07:02:11 --> Loader Class Initialized
INFO - 2023-04-10 07:02:11 --> Controller Class Initialized
INFO - 2023-04-10 07:02:11 --> Helper loaded: form_helper
INFO - 2023-04-10 07:02:11 --> Helper loaded: url_helper
DEBUG - 2023-04-10 07:02:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:02:11 --> Database Driver Class Initialized
INFO - 2023-04-10 07:02:11 --> Model "Login_model" initialized
INFO - 2023-04-10 07:02:11 --> Final output sent to browser
DEBUG - 2023-04-10 07:02:11 --> Total execution time: 0.0312
INFO - 2023-04-10 07:02:17 --> Config Class Initialized
INFO - 2023-04-10 07:02:17 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:02:17 --> Utf8 Class Initialized
INFO - 2023-04-10 07:02:17 --> URI Class Initialized
INFO - 2023-04-10 07:02:17 --> Router Class Initialized
INFO - 2023-04-10 07:02:17 --> Output Class Initialized
INFO - 2023-04-10 07:02:17 --> Security Class Initialized
DEBUG - 2023-04-10 07:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:02:17 --> Input Class Initialized
INFO - 2023-04-10 07:02:17 --> Language Class Initialized
INFO - 2023-04-10 07:02:17 --> Loader Class Initialized
INFO - 2023-04-10 07:02:17 --> Controller Class Initialized
INFO - 2023-04-10 07:02:17 --> Helper loaded: form_helper
INFO - 2023-04-10 07:02:17 --> Helper loaded: url_helper
DEBUG - 2023-04-10 07:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:02:17 --> Model "Change_model" initialized
INFO - 2023-04-10 07:02:17 --> Model "Grafana_model" initialized
INFO - 2023-04-10 07:02:17 --> Final output sent to browser
DEBUG - 2023-04-10 07:02:17 --> Total execution time: 0.2064
INFO - 2023-04-10 07:02:17 --> Config Class Initialized
INFO - 2023-04-10 07:02:17 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:02:17 --> Utf8 Class Initialized
INFO - 2023-04-10 07:02:17 --> URI Class Initialized
INFO - 2023-04-10 07:02:17 --> Router Class Initialized
INFO - 2023-04-10 07:02:17 --> Output Class Initialized
INFO - 2023-04-10 07:02:17 --> Security Class Initialized
DEBUG - 2023-04-10 07:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:02:17 --> Input Class Initialized
INFO - 2023-04-10 07:02:17 --> Language Class Initialized
INFO - 2023-04-10 07:02:17 --> Loader Class Initialized
INFO - 2023-04-10 07:02:17 --> Controller Class Initialized
INFO - 2023-04-10 07:02:17 --> Helper loaded: form_helper
INFO - 2023-04-10 07:02:17 --> Helper loaded: url_helper
DEBUG - 2023-04-10 07:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:02:17 --> Final output sent to browser
DEBUG - 2023-04-10 07:02:17 --> Total execution time: 0.0037
INFO - 2023-04-10 07:02:17 --> Config Class Initialized
INFO - 2023-04-10 07:02:17 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:02:17 --> Utf8 Class Initialized
INFO - 2023-04-10 07:02:17 --> URI Class Initialized
INFO - 2023-04-10 07:02:17 --> Router Class Initialized
INFO - 2023-04-10 07:02:17 --> Output Class Initialized
INFO - 2023-04-10 07:02:17 --> Security Class Initialized
DEBUG - 2023-04-10 07:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:02:17 --> Input Class Initialized
INFO - 2023-04-10 07:02:17 --> Language Class Initialized
INFO - 2023-04-10 07:02:17 --> Loader Class Initialized
INFO - 2023-04-10 07:02:17 --> Controller Class Initialized
INFO - 2023-04-10 07:02:17 --> Helper loaded: form_helper
INFO - 2023-04-10 07:02:17 --> Helper loaded: url_helper
DEBUG - 2023-04-10 07:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:02:17 --> Database Driver Class Initialized
INFO - 2023-04-10 07:02:17 --> Model "Login_model" initialized
INFO - 2023-04-10 07:02:17 --> Final output sent to browser
DEBUG - 2023-04-10 07:02:17 --> Total execution time: 0.0224
INFO - 2023-04-10 07:02:17 --> Config Class Initialized
INFO - 2023-04-10 07:02:17 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:02:17 --> Utf8 Class Initialized
INFO - 2023-04-10 07:02:17 --> URI Class Initialized
INFO - 2023-04-10 07:02:17 --> Router Class Initialized
INFO - 2023-04-10 07:02:17 --> Output Class Initialized
INFO - 2023-04-10 07:02:17 --> Security Class Initialized
DEBUG - 2023-04-10 07:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:02:17 --> Input Class Initialized
INFO - 2023-04-10 07:02:17 --> Language Class Initialized
INFO - 2023-04-10 07:02:17 --> Loader Class Initialized
INFO - 2023-04-10 07:02:17 --> Controller Class Initialized
DEBUG - 2023-04-10 07:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:02:17 --> Database Driver Class Initialized
INFO - 2023-04-10 07:02:17 --> Model "Cluster_model" initialized
INFO - 2023-04-10 07:02:18 --> Final output sent to browser
DEBUG - 2023-04-10 07:02:18 --> Total execution time: 0.0306
INFO - 2023-04-10 07:02:18 --> Config Class Initialized
INFO - 2023-04-10 07:02:18 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:02:18 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:02:18 --> Utf8 Class Initialized
INFO - 2023-04-10 07:02:18 --> URI Class Initialized
INFO - 2023-04-10 07:02:18 --> Router Class Initialized
INFO - 2023-04-10 07:02:18 --> Output Class Initialized
INFO - 2023-04-10 07:02:18 --> Security Class Initialized
DEBUG - 2023-04-10 07:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:02:18 --> Input Class Initialized
INFO - 2023-04-10 07:02:18 --> Language Class Initialized
INFO - 2023-04-10 07:02:18 --> Loader Class Initialized
INFO - 2023-04-10 07:02:18 --> Controller Class Initialized
DEBUG - 2023-04-10 07:02:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:02:18 --> Database Driver Class Initialized
INFO - 2023-04-10 07:02:18 --> Model "Cluster_model" initialized
INFO - 2023-04-10 07:02:18 --> Final output sent to browser
DEBUG - 2023-04-10 07:02:18 --> Total execution time: 0.1200
INFO - 2023-04-10 07:02:18 --> Config Class Initialized
INFO - 2023-04-10 07:02:18 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:02:18 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:02:18 --> Utf8 Class Initialized
INFO - 2023-04-10 07:02:18 --> URI Class Initialized
INFO - 2023-04-10 07:02:18 --> Router Class Initialized
INFO - 2023-04-10 07:02:18 --> Output Class Initialized
INFO - 2023-04-10 07:02:18 --> Security Class Initialized
DEBUG - 2023-04-10 07:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:02:18 --> Input Class Initialized
INFO - 2023-04-10 07:02:18 --> Language Class Initialized
INFO - 2023-04-10 07:02:18 --> Loader Class Initialized
INFO - 2023-04-10 07:02:18 --> Controller Class Initialized
DEBUG - 2023-04-10 07:02:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:02:18 --> Database Driver Class Initialized
INFO - 2023-04-10 07:02:18 --> Model "Cluster_model" initialized
INFO - 2023-04-10 07:02:18 --> Database Driver Class Initialized
INFO - 2023-04-10 07:02:18 --> Model "Login_model" initialized
INFO - 2023-04-10 07:02:18 --> Final output sent to browser
DEBUG - 2023-04-10 07:02:18 --> Total execution time: 0.2253
INFO - 2023-04-10 07:02:18 --> Config Class Initialized
INFO - 2023-04-10 07:02:18 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:02:18 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:02:18 --> Utf8 Class Initialized
INFO - 2023-04-10 07:02:18 --> URI Class Initialized
INFO - 2023-04-10 07:02:18 --> Router Class Initialized
INFO - 2023-04-10 07:02:18 --> Output Class Initialized
INFO - 2023-04-10 07:02:18 --> Security Class Initialized
DEBUG - 2023-04-10 07:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:02:18 --> Input Class Initialized
INFO - 2023-04-10 07:02:18 --> Language Class Initialized
INFO - 2023-04-10 07:02:18 --> Loader Class Initialized
INFO - 2023-04-10 07:02:18 --> Controller Class Initialized
DEBUG - 2023-04-10 07:02:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:02:18 --> Database Driver Class Initialized
INFO - 2023-04-10 07:02:18 --> Model "Cluster_model" initialized
INFO - 2023-04-10 07:02:18 --> Database Driver Class Initialized
INFO - 2023-04-10 07:02:18 --> Model "Login_model" initialized
INFO - 2023-04-10 07:02:18 --> Final output sent to browser
DEBUG - 2023-04-10 07:02:18 --> Total execution time: 0.0665
INFO - 2023-04-10 07:04:08 --> Config Class Initialized
INFO - 2023-04-10 07:04:08 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:04:08 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:04:08 --> Utf8 Class Initialized
INFO - 2023-04-10 07:04:08 --> URI Class Initialized
INFO - 2023-04-10 07:04:08 --> Router Class Initialized
INFO - 2023-04-10 07:04:08 --> Output Class Initialized
INFO - 2023-04-10 07:04:08 --> Security Class Initialized
DEBUG - 2023-04-10 07:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:04:08 --> Input Class Initialized
INFO - 2023-04-10 07:04:08 --> Language Class Initialized
INFO - 2023-04-10 07:04:08 --> Loader Class Initialized
INFO - 2023-04-10 07:04:08 --> Controller Class Initialized
DEBUG - 2023-04-10 07:04:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:04:08 --> Database Driver Class Initialized
INFO - 2023-04-10 07:04:08 --> Model "Cluster_model" initialized
INFO - 2023-04-10 07:04:08 --> Final output sent to browser
DEBUG - 2023-04-10 07:04:08 --> Total execution time: 0.0195
INFO - 2023-04-10 07:04:08 --> Config Class Initialized
INFO - 2023-04-10 07:04:08 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:04:08 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:04:08 --> Utf8 Class Initialized
INFO - 2023-04-10 07:04:08 --> URI Class Initialized
INFO - 2023-04-10 07:04:08 --> Router Class Initialized
INFO - 2023-04-10 07:04:08 --> Output Class Initialized
INFO - 2023-04-10 07:04:08 --> Security Class Initialized
DEBUG - 2023-04-10 07:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:04:08 --> Input Class Initialized
INFO - 2023-04-10 07:04:08 --> Language Class Initialized
INFO - 2023-04-10 07:04:08 --> Loader Class Initialized
INFO - 2023-04-10 07:04:08 --> Controller Class Initialized
DEBUG - 2023-04-10 07:04:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:04:08 --> Database Driver Class Initialized
INFO - 2023-04-10 07:04:08 --> Model "Cluster_model" initialized
INFO - 2023-04-10 07:04:08 --> Final output sent to browser
DEBUG - 2023-04-10 07:04:08 --> Total execution time: 0.1496
INFO - 2023-04-10 07:04:10 --> Config Class Initialized
INFO - 2023-04-10 07:04:10 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:04:10 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:04:10 --> Utf8 Class Initialized
INFO - 2023-04-10 07:04:10 --> URI Class Initialized
INFO - 2023-04-10 07:04:10 --> Router Class Initialized
INFO - 2023-04-10 07:04:10 --> Output Class Initialized
INFO - 2023-04-10 07:04:10 --> Security Class Initialized
DEBUG - 2023-04-10 07:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:04:10 --> Input Class Initialized
INFO - 2023-04-10 07:04:10 --> Language Class Initialized
INFO - 2023-04-10 07:04:10 --> Loader Class Initialized
INFO - 2023-04-10 07:04:10 --> Controller Class Initialized
DEBUG - 2023-04-10 07:04:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:04:10 --> Database Driver Class Initialized
INFO - 2023-04-10 07:04:10 --> Model "Cluster_model" initialized
INFO - 2023-04-10 07:04:10 --> Final output sent to browser
DEBUG - 2023-04-10 07:04:10 --> Total execution time: 0.0697
INFO - 2023-04-10 07:04:10 --> Config Class Initialized
INFO - 2023-04-10 07:04:10 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:04:10 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:04:10 --> Utf8 Class Initialized
INFO - 2023-04-10 07:04:10 --> URI Class Initialized
INFO - 2023-04-10 07:04:10 --> Router Class Initialized
INFO - 2023-04-10 07:04:10 --> Output Class Initialized
INFO - 2023-04-10 07:04:10 --> Security Class Initialized
DEBUG - 2023-04-10 07:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:04:10 --> Input Class Initialized
INFO - 2023-04-10 07:04:10 --> Language Class Initialized
INFO - 2023-04-10 07:04:10 --> Loader Class Initialized
INFO - 2023-04-10 07:04:10 --> Controller Class Initialized
DEBUG - 2023-04-10 07:04:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:04:10 --> Database Driver Class Initialized
INFO - 2023-04-10 07:04:10 --> Model "Cluster_model" initialized
INFO - 2023-04-10 07:04:10 --> Final output sent to browser
DEBUG - 2023-04-10 07:04:10 --> Total execution time: 0.1406
INFO - 2023-04-10 07:59:55 --> Config Class Initialized
INFO - 2023-04-10 07:59:55 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:59:55 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:59:55 --> Utf8 Class Initialized
INFO - 2023-04-10 07:59:55 --> URI Class Initialized
INFO - 2023-04-10 07:59:55 --> Router Class Initialized
INFO - 2023-04-10 07:59:55 --> Output Class Initialized
INFO - 2023-04-10 07:59:55 --> Security Class Initialized
DEBUG - 2023-04-10 07:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:59:55 --> Input Class Initialized
INFO - 2023-04-10 07:59:55 --> Language Class Initialized
INFO - 2023-04-10 07:59:55 --> Loader Class Initialized
INFO - 2023-04-10 07:59:55 --> Controller Class Initialized
DEBUG - 2023-04-10 07:59:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:59:55 --> Final output sent to browser
DEBUG - 2023-04-10 07:59:55 --> Total execution time: 0.0146
INFO - 2023-04-10 07:59:55 --> Config Class Initialized
INFO - 2023-04-10 07:59:55 --> Hooks Class Initialized
DEBUG - 2023-04-10 07:59:55 --> UTF-8 Support Enabled
INFO - 2023-04-10 07:59:55 --> Utf8 Class Initialized
INFO - 2023-04-10 07:59:55 --> URI Class Initialized
INFO - 2023-04-10 07:59:55 --> Router Class Initialized
INFO - 2023-04-10 07:59:55 --> Output Class Initialized
INFO - 2023-04-10 07:59:55 --> Security Class Initialized
DEBUG - 2023-04-10 07:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 07:59:55 --> Input Class Initialized
INFO - 2023-04-10 07:59:55 --> Language Class Initialized
INFO - 2023-04-10 07:59:55 --> Loader Class Initialized
INFO - 2023-04-10 07:59:55 --> Controller Class Initialized
DEBUG - 2023-04-10 07:59:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 07:59:55 --> Database Driver Class Initialized
INFO - 2023-04-10 07:59:55 --> Model "Cluster_model" initialized
INFO - 2023-04-10 07:59:55 --> Final output sent to browser
DEBUG - 2023-04-10 07:59:55 --> Total execution time: 0.0431
INFO - 2023-04-10 08:00:04 --> Config Class Initialized
INFO - 2023-04-10 08:00:04 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:04 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:04 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:04 --> URI Class Initialized
INFO - 2023-04-10 08:00:04 --> Router Class Initialized
INFO - 2023-04-10 08:00:04 --> Output Class Initialized
INFO - 2023-04-10 08:00:04 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:04 --> Input Class Initialized
INFO - 2023-04-10 08:00:04 --> Language Class Initialized
INFO - 2023-04-10 08:00:04 --> Loader Class Initialized
INFO - 2023-04-10 08:00:04 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:04 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:04 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:04 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:04 --> Model "Login_model" initialized
INFO - 2023-04-10 08:00:04 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:04 --> Total execution time: 0.0856
INFO - 2023-04-10 08:00:04 --> Config Class Initialized
INFO - 2023-04-10 08:00:05 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:05 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:05 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:05 --> URI Class Initialized
INFO - 2023-04-10 08:00:05 --> Router Class Initialized
INFO - 2023-04-10 08:00:05 --> Output Class Initialized
INFO - 2023-04-10 08:00:05 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:05 --> Input Class Initialized
INFO - 2023-04-10 08:00:05 --> Language Class Initialized
INFO - 2023-04-10 08:00:05 --> Loader Class Initialized
INFO - 2023-04-10 08:00:05 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:05 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:05 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:05 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:05 --> Model "Login_model" initialized
INFO - 2023-04-10 08:00:05 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:05 --> Total execution time: 0.1172
INFO - 2023-04-10 08:00:06 --> Config Class Initialized
INFO - 2023-04-10 08:00:06 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:06 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:06 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:06 --> URI Class Initialized
INFO - 2023-04-10 08:00:06 --> Router Class Initialized
INFO - 2023-04-10 08:00:06 --> Output Class Initialized
INFO - 2023-04-10 08:00:06 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:06 --> Input Class Initialized
INFO - 2023-04-10 08:00:06 --> Language Class Initialized
INFO - 2023-04-10 08:00:06 --> Loader Class Initialized
INFO - 2023-04-10 08:00:06 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:06 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:06 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:06 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:06 --> Total execution time: 0.0139
INFO - 2023-04-10 08:00:06 --> Config Class Initialized
INFO - 2023-04-10 08:00:06 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:06 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:06 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:06 --> URI Class Initialized
INFO - 2023-04-10 08:00:06 --> Router Class Initialized
INFO - 2023-04-10 08:00:06 --> Output Class Initialized
INFO - 2023-04-10 08:00:06 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:06 --> Input Class Initialized
INFO - 2023-04-10 08:00:06 --> Language Class Initialized
INFO - 2023-04-10 08:00:06 --> Loader Class Initialized
INFO - 2023-04-10 08:00:06 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:06 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:06 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:06 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:06 --> Model "Login_model" initialized
INFO - 2023-04-10 08:00:06 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:06 --> Total execution time: 0.0357
INFO - 2023-04-10 08:00:06 --> Config Class Initialized
INFO - 2023-04-10 08:00:06 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:06 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:06 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:06 --> URI Class Initialized
INFO - 2023-04-10 08:00:06 --> Router Class Initialized
INFO - 2023-04-10 08:00:06 --> Output Class Initialized
INFO - 2023-04-10 08:00:06 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:06 --> Input Class Initialized
INFO - 2023-04-10 08:00:06 --> Language Class Initialized
INFO - 2023-04-10 08:00:06 --> Loader Class Initialized
INFO - 2023-04-10 08:00:06 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:06 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:06 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:06 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:06 --> Total execution time: 0.1348
INFO - 2023-04-10 08:00:06 --> Config Class Initialized
INFO - 2023-04-10 08:00:06 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:06 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:06 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:06 --> URI Class Initialized
INFO - 2023-04-10 08:00:06 --> Router Class Initialized
INFO - 2023-04-10 08:00:06 --> Output Class Initialized
INFO - 2023-04-10 08:00:06 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:06 --> Input Class Initialized
INFO - 2023-04-10 08:00:06 --> Language Class Initialized
INFO - 2023-04-10 08:00:06 --> Loader Class Initialized
INFO - 2023-04-10 08:00:06 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:06 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:06 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:06 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:06 --> Model "Login_model" initialized
INFO - 2023-04-10 08:00:06 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:06 --> Total execution time: 0.0370
INFO - 2023-04-10 08:00:10 --> Config Class Initialized
INFO - 2023-04-10 08:00:10 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:10 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:10 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:10 --> URI Class Initialized
INFO - 2023-04-10 08:00:10 --> Router Class Initialized
INFO - 2023-04-10 08:00:10 --> Output Class Initialized
INFO - 2023-04-10 08:00:10 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:10 --> Input Class Initialized
INFO - 2023-04-10 08:00:10 --> Language Class Initialized
INFO - 2023-04-10 08:00:10 --> Loader Class Initialized
INFO - 2023-04-10 08:00:10 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:10 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:10 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:10 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:10 --> Total execution time: 0.0217
INFO - 2023-04-10 08:00:10 --> Config Class Initialized
INFO - 2023-04-10 08:00:10 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:10 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:10 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:10 --> URI Class Initialized
INFO - 2023-04-10 08:00:10 --> Router Class Initialized
INFO - 2023-04-10 08:00:10 --> Output Class Initialized
INFO - 2023-04-10 08:00:10 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:10 --> Input Class Initialized
INFO - 2023-04-10 08:00:10 --> Language Class Initialized
INFO - 2023-04-10 08:00:10 --> Loader Class Initialized
INFO - 2023-04-10 08:00:10 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:10 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:10 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:10 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:10 --> Model "Login_model" initialized
INFO - 2023-04-10 08:00:10 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:10 --> Total execution time: 0.0461
INFO - 2023-04-10 08:00:24 --> Config Class Initialized
INFO - 2023-04-10 08:00:24 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:24 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:24 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:24 --> URI Class Initialized
INFO - 2023-04-10 08:00:24 --> Router Class Initialized
INFO - 2023-04-10 08:00:24 --> Output Class Initialized
INFO - 2023-04-10 08:00:24 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:24 --> Input Class Initialized
INFO - 2023-04-10 08:00:24 --> Language Class Initialized
INFO - 2023-04-10 08:00:24 --> Loader Class Initialized
INFO - 2023-04-10 08:00:24 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:24 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:24 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:24 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:24 --> Total execution time: 0.0422
INFO - 2023-04-10 08:00:24 --> Config Class Initialized
INFO - 2023-04-10 08:00:24 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:24 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:24 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:24 --> URI Class Initialized
INFO - 2023-04-10 08:00:24 --> Router Class Initialized
INFO - 2023-04-10 08:00:24 --> Output Class Initialized
INFO - 2023-04-10 08:00:24 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:24 --> Input Class Initialized
INFO - 2023-04-10 08:00:24 --> Language Class Initialized
INFO - 2023-04-10 08:00:24 --> Loader Class Initialized
INFO - 2023-04-10 08:00:24 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:24 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:24 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:24 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:24 --> Total execution time: 0.0534
INFO - 2023-04-10 08:00:27 --> Config Class Initialized
INFO - 2023-04-10 08:00:27 --> Config Class Initialized
INFO - 2023-04-10 08:00:27 --> Hooks Class Initialized
INFO - 2023-04-10 08:00:27 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-10 08:00:27 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:27 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:27 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:27 --> URI Class Initialized
INFO - 2023-04-10 08:00:27 --> URI Class Initialized
INFO - 2023-04-10 08:00:27 --> Router Class Initialized
INFO - 2023-04-10 08:00:27 --> Router Class Initialized
INFO - 2023-04-10 08:00:27 --> Output Class Initialized
INFO - 2023-04-10 08:00:27 --> Output Class Initialized
INFO - 2023-04-10 08:00:27 --> Security Class Initialized
INFO - 2023-04-10 08:00:27 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-10 08:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:27 --> Input Class Initialized
INFO - 2023-04-10 08:00:27 --> Input Class Initialized
INFO - 2023-04-10 08:00:27 --> Language Class Initialized
INFO - 2023-04-10 08:00:27 --> Language Class Initialized
INFO - 2023-04-10 08:00:27 --> Loader Class Initialized
INFO - 2023-04-10 08:00:27 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:27 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:27 --> Loader Class Initialized
INFO - 2023-04-10 08:00:27 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:27 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:27 --> Total execution time: 0.0075
INFO - 2023-04-10 08:00:27 --> Config Class Initialized
INFO - 2023-04-10 08:00:27 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:27 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:27 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:27 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:27 --> URI Class Initialized
INFO - 2023-04-10 08:00:27 --> Router Class Initialized
INFO - 2023-04-10 08:00:27 --> Output Class Initialized
INFO - 2023-04-10 08:00:27 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:27 --> Input Class Initialized
INFO - 2023-04-10 08:00:27 --> Language Class Initialized
INFO - 2023-04-10 08:00:27 --> Loader Class Initialized
INFO - 2023-04-10 08:00:27 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:27 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:27 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:27 --> Total execution time: 0.0557
INFO - 2023-04-10 08:00:27 --> Config Class Initialized
INFO - 2023-04-10 08:00:27 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:27 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:27 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:27 --> URI Class Initialized
INFO - 2023-04-10 08:00:27 --> Router Class Initialized
INFO - 2023-04-10 08:00:27 --> Output Class Initialized
INFO - 2023-04-10 08:00:27 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:27 --> Input Class Initialized
INFO - 2023-04-10 08:00:27 --> Language Class Initialized
INFO - 2023-04-10 08:00:27 --> Loader Class Initialized
INFO - 2023-04-10 08:00:27 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:27 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:27 --> Model "Login_model" initialized
INFO - 2023-04-10 08:00:27 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:27 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:27 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:27 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:27 --> Total execution time: 0.0136
INFO - 2023-04-10 08:00:27 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:27 --> Total execution time: 0.0634
INFO - 2023-04-10 08:00:29 --> Config Class Initialized
INFO - 2023-04-10 08:00:29 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:29 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:29 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:29 --> URI Class Initialized
INFO - 2023-04-10 08:00:29 --> Router Class Initialized
INFO - 2023-04-10 08:00:29 --> Output Class Initialized
INFO - 2023-04-10 08:00:29 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:29 --> Input Class Initialized
INFO - 2023-04-10 08:00:29 --> Language Class Initialized
INFO - 2023-04-10 08:00:29 --> Loader Class Initialized
INFO - 2023-04-10 08:00:29 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:29 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:30 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:30 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:30 --> Model "Login_model" initialized
INFO - 2023-04-10 08:00:31 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:31 --> Total execution time: 1.1010
INFO - 2023-04-10 08:00:31 --> Config Class Initialized
INFO - 2023-04-10 08:00:31 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:31 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:31 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:31 --> URI Class Initialized
INFO - 2023-04-10 08:00:31 --> Router Class Initialized
INFO - 2023-04-10 08:00:31 --> Output Class Initialized
INFO - 2023-04-10 08:00:31 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:31 --> Input Class Initialized
INFO - 2023-04-10 08:00:31 --> Language Class Initialized
INFO - 2023-04-10 08:00:31 --> Loader Class Initialized
INFO - 2023-04-10 08:00:31 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:31 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:31 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:31 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:31 --> Model "Login_model" initialized
INFO - 2023-04-10 08:00:31 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:31 --> Total execution time: 0.0541
INFO - 2023-04-10 08:00:38 --> Config Class Initialized
INFO - 2023-04-10 08:00:38 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:38 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:38 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:38 --> URI Class Initialized
INFO - 2023-04-10 08:00:38 --> Router Class Initialized
INFO - 2023-04-10 08:00:38 --> Output Class Initialized
INFO - 2023-04-10 08:00:38 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:38 --> Input Class Initialized
INFO - 2023-04-10 08:00:38 --> Language Class Initialized
INFO - 2023-04-10 08:00:38 --> Loader Class Initialized
INFO - 2023-04-10 08:00:38 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:38 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:38 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:38 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:38 --> Total execution time: 0.0452
INFO - 2023-04-10 08:00:38 --> Config Class Initialized
INFO - 2023-04-10 08:00:38 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:00:38 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:00:38 --> Utf8 Class Initialized
INFO - 2023-04-10 08:00:38 --> URI Class Initialized
INFO - 2023-04-10 08:00:38 --> Router Class Initialized
INFO - 2023-04-10 08:00:38 --> Output Class Initialized
INFO - 2023-04-10 08:00:38 --> Security Class Initialized
DEBUG - 2023-04-10 08:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:00:38 --> Input Class Initialized
INFO - 2023-04-10 08:00:38 --> Language Class Initialized
INFO - 2023-04-10 08:00:38 --> Loader Class Initialized
INFO - 2023-04-10 08:00:38 --> Controller Class Initialized
DEBUG - 2023-04-10 08:00:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:00:38 --> Database Driver Class Initialized
INFO - 2023-04-10 08:00:38 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:00:38 --> Final output sent to browser
DEBUG - 2023-04-10 08:00:38 --> Total execution time: 0.0845
INFO - 2023-04-10 08:01:05 --> Config Class Initialized
INFO - 2023-04-10 08:01:05 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:01:05 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:05 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:05 --> URI Class Initialized
INFO - 2023-04-10 08:01:05 --> Router Class Initialized
INFO - 2023-04-10 08:01:05 --> Output Class Initialized
INFO - 2023-04-10 08:01:05 --> Security Class Initialized
DEBUG - 2023-04-10 08:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:01:05 --> Input Class Initialized
INFO - 2023-04-10 08:01:05 --> Language Class Initialized
INFO - 2023-04-10 08:01:05 --> Loader Class Initialized
INFO - 2023-04-10 08:01:05 --> Controller Class Initialized
DEBUG - 2023-04-10 08:01:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:05 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:05 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:01:05 --> Final output sent to browser
DEBUG - 2023-04-10 08:01:05 --> Total execution time: 0.0521
INFO - 2023-04-10 08:01:05 --> Config Class Initialized
INFO - 2023-04-10 08:01:05 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:01:05 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:05 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:05 --> URI Class Initialized
INFO - 2023-04-10 08:01:05 --> Router Class Initialized
INFO - 2023-04-10 08:01:05 --> Output Class Initialized
INFO - 2023-04-10 08:01:05 --> Security Class Initialized
DEBUG - 2023-04-10 08:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:01:05 --> Input Class Initialized
INFO - 2023-04-10 08:01:05 --> Language Class Initialized
INFO - 2023-04-10 08:01:05 --> Loader Class Initialized
INFO - 2023-04-10 08:01:05 --> Controller Class Initialized
DEBUG - 2023-04-10 08:01:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:05 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:05 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:01:05 --> Final output sent to browser
DEBUG - 2023-04-10 08:01:05 --> Total execution time: 0.0582
INFO - 2023-04-10 08:01:08 --> Config Class Initialized
INFO - 2023-04-10 08:01:08 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:01:08 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:08 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:08 --> URI Class Initialized
INFO - 2023-04-10 08:01:08 --> Router Class Initialized
INFO - 2023-04-10 08:01:08 --> Output Class Initialized
INFO - 2023-04-10 08:01:08 --> Security Class Initialized
DEBUG - 2023-04-10 08:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:01:08 --> Input Class Initialized
INFO - 2023-04-10 08:01:08 --> Language Class Initialized
INFO - 2023-04-10 08:01:08 --> Loader Class Initialized
INFO - 2023-04-10 08:01:08 --> Controller Class Initialized
DEBUG - 2023-04-10 08:01:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:08 --> Final output sent to browser
DEBUG - 2023-04-10 08:01:08 --> Total execution time: 0.0037
INFO - 2023-04-10 08:01:08 --> Config Class Initialized
INFO - 2023-04-10 08:01:08 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:01:08 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:08 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:08 --> URI Class Initialized
INFO - 2023-04-10 08:01:08 --> Router Class Initialized
INFO - 2023-04-10 08:01:08 --> Output Class Initialized
INFO - 2023-04-10 08:01:08 --> Security Class Initialized
DEBUG - 2023-04-10 08:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:01:08 --> Input Class Initialized
INFO - 2023-04-10 08:01:08 --> Language Class Initialized
INFO - 2023-04-10 08:01:08 --> Loader Class Initialized
INFO - 2023-04-10 08:01:08 --> Controller Class Initialized
DEBUG - 2023-04-10 08:01:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:08 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:08 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:01:08 --> Final output sent to browser
DEBUG - 2023-04-10 08:01:08 --> Total execution time: 0.0134
INFO - 2023-04-10 08:01:09 --> Config Class Initialized
INFO - 2023-04-10 08:01:09 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:01:09 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:09 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:09 --> URI Class Initialized
INFO - 2023-04-10 08:01:09 --> Router Class Initialized
INFO - 2023-04-10 08:01:09 --> Output Class Initialized
INFO - 2023-04-10 08:01:09 --> Security Class Initialized
DEBUG - 2023-04-10 08:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:01:09 --> Input Class Initialized
INFO - 2023-04-10 08:01:09 --> Language Class Initialized
INFO - 2023-04-10 08:01:09 --> Loader Class Initialized
INFO - 2023-04-10 08:01:09 --> Controller Class Initialized
DEBUG - 2023-04-10 08:01:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:09 --> Final output sent to browser
DEBUG - 2023-04-10 08:01:09 --> Total execution time: 0.0027
INFO - 2023-04-10 08:01:09 --> Config Class Initialized
INFO - 2023-04-10 08:01:09 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:01:09 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:09 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:09 --> URI Class Initialized
INFO - 2023-04-10 08:01:09 --> Router Class Initialized
INFO - 2023-04-10 08:01:09 --> Output Class Initialized
INFO - 2023-04-10 08:01:09 --> Security Class Initialized
DEBUG - 2023-04-10 08:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:01:09 --> Input Class Initialized
INFO - 2023-04-10 08:01:09 --> Language Class Initialized
INFO - 2023-04-10 08:01:09 --> Loader Class Initialized
INFO - 2023-04-10 08:01:09 --> Controller Class Initialized
DEBUG - 2023-04-10 08:01:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:09 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:09 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:01:09 --> Final output sent to browser
DEBUG - 2023-04-10 08:01:09 --> Total execution time: 0.0339
INFO - 2023-04-10 08:01:26 --> Config Class Initialized
INFO - 2023-04-10 08:01:26 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:01:26 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:26 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:26 --> URI Class Initialized
INFO - 2023-04-10 08:01:26 --> Router Class Initialized
INFO - 2023-04-10 08:01:26 --> Output Class Initialized
INFO - 2023-04-10 08:01:26 --> Security Class Initialized
DEBUG - 2023-04-10 08:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:01:26 --> Input Class Initialized
INFO - 2023-04-10 08:01:26 --> Language Class Initialized
INFO - 2023-04-10 08:01:26 --> Loader Class Initialized
INFO - 2023-04-10 08:01:26 --> Controller Class Initialized
DEBUG - 2023-04-10 08:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:26 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:26 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:01:26 --> Final output sent to browser
DEBUG - 2023-04-10 08:01:26 --> Total execution time: 0.1528
INFO - 2023-04-10 08:01:26 --> Config Class Initialized
INFO - 2023-04-10 08:01:26 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:01:26 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:26 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:26 --> URI Class Initialized
INFO - 2023-04-10 08:01:26 --> Router Class Initialized
INFO - 2023-04-10 08:01:26 --> Output Class Initialized
INFO - 2023-04-10 08:01:26 --> Security Class Initialized
DEBUG - 2023-04-10 08:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:01:26 --> Input Class Initialized
INFO - 2023-04-10 08:01:26 --> Language Class Initialized
INFO - 2023-04-10 08:01:26 --> Loader Class Initialized
INFO - 2023-04-10 08:01:26 --> Controller Class Initialized
DEBUG - 2023-04-10 08:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:26 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:26 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:01:26 --> Final output sent to browser
DEBUG - 2023-04-10 08:01:26 --> Total execution time: 0.0765
INFO - 2023-04-10 08:01:32 --> Config Class Initialized
INFO - 2023-04-10 08:01:32 --> Config Class Initialized
INFO - 2023-04-10 08:01:32 --> Hooks Class Initialized
INFO - 2023-04-10 08:01:32 --> Hooks Class Initialized
INFO - 2023-04-10 08:01:32 --> Config Class Initialized
DEBUG - 2023-04-10 08:01:32 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:32 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:01:32 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:32 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:32 --> Utf8 Class Initialized
DEBUG - 2023-04-10 08:01:32 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:32 --> URI Class Initialized
INFO - 2023-04-10 08:01:32 --> URI Class Initialized
INFO - 2023-04-10 08:01:32 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:32 --> Router Class Initialized
INFO - 2023-04-10 08:01:32 --> Router Class Initialized
INFO - 2023-04-10 08:01:32 --> URI Class Initialized
INFO - 2023-04-10 08:01:32 --> Output Class Initialized
INFO - 2023-04-10 08:01:32 --> Output Class Initialized
INFO - 2023-04-10 08:01:32 --> Router Class Initialized
INFO - 2023-04-10 08:01:32 --> Security Class Initialized
INFO - 2023-04-10 08:01:32 --> Output Class Initialized
INFO - 2023-04-10 08:01:32 --> Security Class Initialized
DEBUG - 2023-04-10 08:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:01:32 --> Security Class Initialized
INFO - 2023-04-10 08:01:32 --> Input Class Initialized
DEBUG - 2023-04-10 08:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-10 08:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:01:32 --> Language Class Initialized
INFO - 2023-04-10 08:01:32 --> Input Class Initialized
INFO - 2023-04-10 08:01:32 --> Input Class Initialized
INFO - 2023-04-10 08:01:32 --> Language Class Initialized
INFO - 2023-04-10 08:01:32 --> Language Class Initialized
INFO - 2023-04-10 08:01:32 --> Loader Class Initialized
INFO - 2023-04-10 08:01:32 --> Controller Class Initialized
DEBUG - 2023-04-10 08:01:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:32 --> Loader Class Initialized
INFO - 2023-04-10 08:01:32 --> Loader Class Initialized
INFO - 2023-04-10 08:01:32 --> Controller Class Initialized
INFO - 2023-04-10 08:01:32 --> Controller Class Initialized
DEBUG - 2023-04-10 08:01:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-10 08:01:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:32 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:01:32 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:01:32 --> Model "Login_model" initialized
INFO - 2023-04-10 08:01:32 --> Final output sent to browser
DEBUG - 2023-04-10 08:01:32 --> Total execution time: 0.0273
INFO - 2023-04-10 08:01:32 --> Config Class Initialized
INFO - 2023-04-10 08:01:32 --> Hooks Class Initialized
INFO - 2023-04-10 08:01:32 --> Final output sent to browser
INFO - 2023-04-10 08:01:32 --> Final output sent to browser
DEBUG - 2023-04-10 08:01:32 --> Total execution time: 0.0420
DEBUG - 2023-04-10 08:01:32 --> Total execution time: 0.0435
DEBUG - 2023-04-10 08:01:32 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:32 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:32 --> URI Class Initialized
INFO - 2023-04-10 08:01:32 --> Router Class Initialized
INFO - 2023-04-10 08:01:32 --> Config Class Initialized
INFO - 2023-04-10 08:01:32 --> Output Class Initialized
INFO - 2023-04-10 08:01:32 --> Hooks Class Initialized
INFO - 2023-04-10 08:01:32 --> Security Class Initialized
DEBUG - 2023-04-10 08:01:32 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:32 --> Config Class Initialized
INFO - 2023-04-10 08:01:32 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:32 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:01:32 --> URI Class Initialized
DEBUG - 2023-04-10 08:01:32 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:32 --> Input Class Initialized
INFO - 2023-04-10 08:01:32 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:32 --> Router Class Initialized
INFO - 2023-04-10 08:01:32 --> Language Class Initialized
INFO - 2023-04-10 08:01:32 --> URI Class Initialized
INFO - 2023-04-10 08:01:32 --> Output Class Initialized
INFO - 2023-04-10 08:01:32 --> Loader Class Initialized
INFO - 2023-04-10 08:01:32 --> Router Class Initialized
INFO - 2023-04-10 08:01:32 --> Security Class Initialized
INFO - 2023-04-10 08:01:32 --> Controller Class Initialized
INFO - 2023-04-10 08:01:32 --> Output Class Initialized
DEBUG - 2023-04-10 08:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-10 08:01:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:32 --> Security Class Initialized
INFO - 2023-04-10 08:01:32 --> Input Class Initialized
DEBUG - 2023-04-10 08:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:01:32 --> Language Class Initialized
INFO - 2023-04-10 08:01:32 --> Input Class Initialized
INFO - 2023-04-10 08:01:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:32 --> Language Class Initialized
INFO - 2023-04-10 08:01:32 --> Loader Class Initialized
INFO - 2023-04-10 08:01:32 --> Loader Class Initialized
INFO - 2023-04-10 08:01:32 --> Controller Class Initialized
INFO - 2023-04-10 08:01:32 --> Controller Class Initialized
DEBUG - 2023-04-10 08:01:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-10 08:01:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:32 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:01:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:32 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:01:32 --> Model "Login_model" initialized
INFO - 2023-04-10 08:01:32 --> Final output sent to browser
DEBUG - 2023-04-10 08:01:32 --> Total execution time: 0.0635
INFO - 2023-04-10 08:01:32 --> Config Class Initialized
INFO - 2023-04-10 08:01:32 --> Final output sent to browser
INFO - 2023-04-10 08:01:32 --> Final output sent to browser
INFO - 2023-04-10 08:01:33 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:01:33 --> Total execution time: 0.0653
DEBUG - 2023-04-10 08:01:33 --> Total execution time: 0.1074
DEBUG - 2023-04-10 08:01:33 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:33 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:33 --> URI Class Initialized
INFO - 2023-04-10 08:01:33 --> Router Class Initialized
INFO - 2023-04-10 08:01:33 --> Output Class Initialized
INFO - 2023-04-10 08:01:33 --> Security Class Initialized
INFO - 2023-04-10 08:01:33 --> Config Class Initialized
INFO - 2023-04-10 08:01:33 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-10 08:01:33 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:01:33 --> Input Class Initialized
INFO - 2023-04-10 08:01:33 --> Utf8 Class Initialized
INFO - 2023-04-10 08:01:33 --> Language Class Initialized
INFO - 2023-04-10 08:01:33 --> URI Class Initialized
INFO - 2023-04-10 08:01:33 --> Loader Class Initialized
INFO - 2023-04-10 08:01:33 --> Router Class Initialized
INFO - 2023-04-10 08:01:33 --> Controller Class Initialized
DEBUG - 2023-04-10 08:01:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:33 --> Output Class Initialized
INFO - 2023-04-10 08:01:33 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:33 --> Security Class Initialized
DEBUG - 2023-04-10 08:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:01:33 --> Input Class Initialized
INFO - 2023-04-10 08:01:33 --> Language Class Initialized
INFO - 2023-04-10 08:01:33 --> Loader Class Initialized
INFO - 2023-04-10 08:01:33 --> Controller Class Initialized
DEBUG - 2023-04-10 08:01:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:01:33 --> Database Driver Class Initialized
INFO - 2023-04-10 08:01:33 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:01:33 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:01:33 --> Final output sent to browser
INFO - 2023-04-10 08:01:33 --> Final output sent to browser
DEBUG - 2023-04-10 08:01:33 --> Total execution time: 0.0619
DEBUG - 2023-04-10 08:01:33 --> Total execution time: 0.1053
INFO - 2023-04-10 08:02:32 --> Config Class Initialized
INFO - 2023-04-10 08:02:32 --> Config Class Initialized
INFO - 2023-04-10 08:02:32 --> Hooks Class Initialized
INFO - 2023-04-10 08:02:32 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:02:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-10 08:02:32 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:02:32 --> Utf8 Class Initialized
INFO - 2023-04-10 08:02:32 --> Utf8 Class Initialized
INFO - 2023-04-10 08:02:32 --> URI Class Initialized
INFO - 2023-04-10 08:02:32 --> URI Class Initialized
INFO - 2023-04-10 08:02:32 --> Router Class Initialized
INFO - 2023-04-10 08:02:32 --> Router Class Initialized
INFO - 2023-04-10 08:02:32 --> Output Class Initialized
INFO - 2023-04-10 08:02:32 --> Output Class Initialized
INFO - 2023-04-10 08:02:32 --> Security Class Initialized
INFO - 2023-04-10 08:02:32 --> Security Class Initialized
DEBUG - 2023-04-10 08:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-10 08:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:02:32 --> Input Class Initialized
INFO - 2023-04-10 08:02:32 --> Input Class Initialized
INFO - 2023-04-10 08:02:32 --> Language Class Initialized
INFO - 2023-04-10 08:02:32 --> Language Class Initialized
INFO - 2023-04-10 08:02:32 --> Loader Class Initialized
INFO - 2023-04-10 08:02:32 --> Loader Class Initialized
INFO - 2023-04-10 08:02:32 --> Controller Class Initialized
INFO - 2023-04-10 08:02:32 --> Controller Class Initialized
DEBUG - 2023-04-10 08:02:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-10 08:02:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:02:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:02:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:02:32 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:02:32 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:02:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:02:32 --> Model "Login_model" initialized
INFO - 2023-04-10 08:02:32 --> Final output sent to browser
DEBUG - 2023-04-10 08:02:32 --> Total execution time: 0.0329
INFO - 2023-04-10 08:02:32 --> Config Class Initialized
INFO - 2023-04-10 08:02:32 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:02:32 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:02:32 --> Utf8 Class Initialized
INFO - 2023-04-10 08:02:32 --> URI Class Initialized
INFO - 2023-04-10 08:02:32 --> Router Class Initialized
INFO - 2023-04-10 08:02:32 --> Output Class Initialized
INFO - 2023-04-10 08:02:32 --> Security Class Initialized
DEBUG - 2023-04-10 08:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:02:32 --> Input Class Initialized
INFO - 2023-04-10 08:02:32 --> Language Class Initialized
INFO - 2023-04-10 08:02:32 --> Loader Class Initialized
INFO - 2023-04-10 08:02:32 --> Controller Class Initialized
DEBUG - 2023-04-10 08:02:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:02:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:02:32 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:02:32 --> Final output sent to browser
DEBUG - 2023-04-10 08:02:32 --> Total execution time: 0.0352
INFO - 2023-04-10 08:02:33 --> Final output sent to browser
DEBUG - 2023-04-10 08:02:33 --> Total execution time: 0.8845
INFO - 2023-04-10 08:02:33 --> Config Class Initialized
INFO - 2023-04-10 08:02:33 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:02:33 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:02:33 --> Utf8 Class Initialized
INFO - 2023-04-10 08:02:33 --> URI Class Initialized
INFO - 2023-04-10 08:02:33 --> Router Class Initialized
INFO - 2023-04-10 08:02:33 --> Output Class Initialized
INFO - 2023-04-10 08:02:33 --> Security Class Initialized
DEBUG - 2023-04-10 08:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:02:33 --> Input Class Initialized
INFO - 2023-04-10 08:02:33 --> Language Class Initialized
INFO - 2023-04-10 08:02:33 --> Loader Class Initialized
INFO - 2023-04-10 08:02:33 --> Controller Class Initialized
DEBUG - 2023-04-10 08:02:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:02:33 --> Database Driver Class Initialized
INFO - 2023-04-10 08:02:33 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:02:33 --> Database Driver Class Initialized
INFO - 2023-04-10 08:02:33 --> Model "Login_model" initialized
INFO - 2023-04-10 08:02:34 --> Final output sent to browser
DEBUG - 2023-04-10 08:02:34 --> Total execution time: 0.7538
INFO - 2023-04-10 08:03:27 --> Config Class Initialized
INFO - 2023-04-10 08:03:27 --> Config Class Initialized
INFO - 2023-04-10 08:03:27 --> Hooks Class Initialized
INFO - 2023-04-10 08:03:27 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:03:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-10 08:03:27 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:03:27 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:27 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:27 --> URI Class Initialized
INFO - 2023-04-10 08:03:27 --> URI Class Initialized
INFO - 2023-04-10 08:03:27 --> Router Class Initialized
INFO - 2023-04-10 08:03:27 --> Router Class Initialized
INFO - 2023-04-10 08:03:27 --> Output Class Initialized
INFO - 2023-04-10 08:03:27 --> Output Class Initialized
INFO - 2023-04-10 08:03:27 --> Security Class Initialized
INFO - 2023-04-10 08:03:27 --> Security Class Initialized
DEBUG - 2023-04-10 08:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-10 08:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:03:27 --> Input Class Initialized
INFO - 2023-04-10 08:03:27 --> Input Class Initialized
INFO - 2023-04-10 08:03:27 --> Language Class Initialized
INFO - 2023-04-10 08:03:27 --> Language Class Initialized
INFO - 2023-04-10 08:03:27 --> Loader Class Initialized
INFO - 2023-04-10 08:03:27 --> Loader Class Initialized
INFO - 2023-04-10 08:03:27 --> Controller Class Initialized
INFO - 2023-04-10 08:03:27 --> Controller Class Initialized
DEBUG - 2023-04-10 08:03:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-10 08:03:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:03:27 --> Final output sent to browser
DEBUG - 2023-04-10 08:03:27 --> Total execution time: 0.0045
INFO - 2023-04-10 08:03:27 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:27 --> Config Class Initialized
INFO - 2023-04-10 08:03:27 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:03:27 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:03:27 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:27 --> URI Class Initialized
INFO - 2023-04-10 08:03:27 --> Router Class Initialized
INFO - 2023-04-10 08:03:27 --> Output Class Initialized
INFO - 2023-04-10 08:03:27 --> Security Class Initialized
DEBUG - 2023-04-10 08:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:03:27 --> Input Class Initialized
INFO - 2023-04-10 08:03:27 --> Language Class Initialized
INFO - 2023-04-10 08:03:27 --> Loader Class Initialized
INFO - 2023-04-10 08:03:27 --> Controller Class Initialized
DEBUG - 2023-04-10 08:03:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:03:27 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:27 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:03:27 --> Model "Login_model" initialized
INFO - 2023-04-10 08:03:27 --> Final output sent to browser
DEBUG - 2023-04-10 08:03:27 --> Total execution time: 0.0184
INFO - 2023-04-10 08:03:27 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:27 --> Config Class Initialized
INFO - 2023-04-10 08:03:27 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:03:27 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:03:27 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:27 --> URI Class Initialized
INFO - 2023-04-10 08:03:27 --> Router Class Initialized
INFO - 2023-04-10 08:03:27 --> Output Class Initialized
INFO - 2023-04-10 08:03:27 --> Security Class Initialized
DEBUG - 2023-04-10 08:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:03:27 --> Input Class Initialized
INFO - 2023-04-10 08:03:27 --> Language Class Initialized
INFO - 2023-04-10 08:03:27 --> Loader Class Initialized
INFO - 2023-04-10 08:03:27 --> Controller Class Initialized
DEBUG - 2023-04-10 08:03:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:03:27 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:27 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:03:27 --> Final output sent to browser
DEBUG - 2023-04-10 08:03:27 --> Total execution time: 0.0219
INFO - 2023-04-10 08:03:27 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:03:27 --> Final output sent to browser
DEBUG - 2023-04-10 08:03:27 --> Total execution time: 0.0593
INFO - 2023-04-10 08:03:28 --> Config Class Initialized
INFO - 2023-04-10 08:03:28 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:03:28 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:03:28 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:28 --> URI Class Initialized
INFO - 2023-04-10 08:03:28 --> Router Class Initialized
INFO - 2023-04-10 08:03:28 --> Output Class Initialized
INFO - 2023-04-10 08:03:28 --> Security Class Initialized
DEBUG - 2023-04-10 08:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:03:28 --> Input Class Initialized
INFO - 2023-04-10 08:03:28 --> Language Class Initialized
INFO - 2023-04-10 08:03:28 --> Loader Class Initialized
INFO - 2023-04-10 08:03:28 --> Controller Class Initialized
DEBUG - 2023-04-10 08:03:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:03:28 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:28 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:03:28 --> Final output sent to browser
DEBUG - 2023-04-10 08:03:28 --> Total execution time: 0.0175
INFO - 2023-04-10 08:03:28 --> Config Class Initialized
INFO - 2023-04-10 08:03:28 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:03:28 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:03:28 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:28 --> URI Class Initialized
INFO - 2023-04-10 08:03:28 --> Router Class Initialized
INFO - 2023-04-10 08:03:28 --> Output Class Initialized
INFO - 2023-04-10 08:03:28 --> Security Class Initialized
DEBUG - 2023-04-10 08:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:03:28 --> Input Class Initialized
INFO - 2023-04-10 08:03:28 --> Language Class Initialized
INFO - 2023-04-10 08:03:28 --> Loader Class Initialized
INFO - 2023-04-10 08:03:28 --> Controller Class Initialized
DEBUG - 2023-04-10 08:03:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:03:28 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:28 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:03:28 --> Final output sent to browser
DEBUG - 2023-04-10 08:03:28 --> Total execution time: 0.0540
INFO - 2023-04-10 08:03:31 --> Config Class Initialized
INFO - 2023-04-10 08:03:31 --> Config Class Initialized
INFO - 2023-04-10 08:03:31 --> Config Class Initialized
INFO - 2023-04-10 08:03:31 --> Hooks Class Initialized
INFO - 2023-04-10 08:03:31 --> Hooks Class Initialized
INFO - 2023-04-10 08:03:31 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:03:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-10 08:03:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-10 08:03:31 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:03:31 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:31 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:31 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:31 --> URI Class Initialized
INFO - 2023-04-10 08:03:31 --> URI Class Initialized
INFO - 2023-04-10 08:03:31 --> URI Class Initialized
INFO - 2023-04-10 08:03:31 --> Router Class Initialized
INFO - 2023-04-10 08:03:31 --> Router Class Initialized
INFO - 2023-04-10 08:03:31 --> Router Class Initialized
INFO - 2023-04-10 08:03:31 --> Output Class Initialized
INFO - 2023-04-10 08:03:31 --> Output Class Initialized
INFO - 2023-04-10 08:03:31 --> Output Class Initialized
INFO - 2023-04-10 08:03:31 --> Security Class Initialized
INFO - 2023-04-10 08:03:31 --> Security Class Initialized
INFO - 2023-04-10 08:03:31 --> Security Class Initialized
DEBUG - 2023-04-10 08:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-10 08:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-10 08:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:03:31 --> Input Class Initialized
INFO - 2023-04-10 08:03:31 --> Input Class Initialized
INFO - 2023-04-10 08:03:31 --> Input Class Initialized
INFO - 2023-04-10 08:03:31 --> Language Class Initialized
INFO - 2023-04-10 08:03:31 --> Language Class Initialized
INFO - 2023-04-10 08:03:31 --> Language Class Initialized
INFO - 2023-04-10 08:03:31 --> Loader Class Initialized
INFO - 2023-04-10 08:03:31 --> Loader Class Initialized
INFO - 2023-04-10 08:03:31 --> Loader Class Initialized
INFO - 2023-04-10 08:03:31 --> Controller Class Initialized
INFO - 2023-04-10 08:03:31 --> Controller Class Initialized
INFO - 2023-04-10 08:03:31 --> Controller Class Initialized
DEBUG - 2023-04-10 08:03:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-10 08:03:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-10 08:03:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:03:31 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:31 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:31 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:32 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:03:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:32 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:03:32 --> Model "Login_model" initialized
INFO - 2023-04-10 08:03:32 --> Final output sent to browser
DEBUG - 2023-04-10 08:03:32 --> Total execution time: 0.0245
INFO - 2023-04-10 08:03:32 --> Config Class Initialized
INFO - 2023-04-10 08:03:32 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:03:32 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:03:32 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:32 --> URI Class Initialized
INFO - 2023-04-10 08:03:32 --> Router Class Initialized
INFO - 2023-04-10 08:03:32 --> Output Class Initialized
INFO - 2023-04-10 08:03:32 --> Security Class Initialized
DEBUG - 2023-04-10 08:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:03:32 --> Input Class Initialized
INFO - 2023-04-10 08:03:32 --> Language Class Initialized
INFO - 2023-04-10 08:03:32 --> Loader Class Initialized
INFO - 2023-04-10 08:03:32 --> Controller Class Initialized
DEBUG - 2023-04-10 08:03:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:03:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:32 --> Final output sent to browser
DEBUG - 2023-04-10 08:03:32 --> Total execution time: 0.0307
INFO - 2023-04-10 08:03:32 --> Config Class Initialized
INFO - 2023-04-10 08:03:32 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:03:32 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:03:32 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:32 --> URI Class Initialized
INFO - 2023-04-10 08:03:32 --> Router Class Initialized
INFO - 2023-04-10 08:03:32 --> Output Class Initialized
INFO - 2023-04-10 08:03:32 --> Security Class Initialized
DEBUG - 2023-04-10 08:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:03:32 --> Input Class Initialized
INFO - 2023-04-10 08:03:32 --> Language Class Initialized
INFO - 2023-04-10 08:03:32 --> Loader Class Initialized
INFO - 2023-04-10 08:03:32 --> Controller Class Initialized
DEBUG - 2023-04-10 08:03:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:03:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:32 --> Final output sent to browser
DEBUG - 2023-04-10 08:03:32 --> Total execution time: 0.0388
INFO - 2023-04-10 08:03:32 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:03:32 --> Config Class Initialized
INFO - 2023-04-10 08:03:32 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:03:32 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:03:32 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:32 --> URI Class Initialized
INFO - 2023-04-10 08:03:32 --> Router Class Initialized
INFO - 2023-04-10 08:03:32 --> Output Class Initialized
INFO - 2023-04-10 08:03:32 --> Security Class Initialized
DEBUG - 2023-04-10 08:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:03:32 --> Input Class Initialized
INFO - 2023-04-10 08:03:32 --> Language Class Initialized
INFO - 2023-04-10 08:03:32 --> Loader Class Initialized
INFO - 2023-04-10 08:03:32 --> Controller Class Initialized
DEBUG - 2023-04-10 08:03:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:03:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:32 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:03:32 --> Model "Login_model" initialized
INFO - 2023-04-10 08:03:32 --> Final output sent to browser
DEBUG - 2023-04-10 08:03:32 --> Total execution time: 0.0217
INFO - 2023-04-10 08:03:32 --> Config Class Initialized
INFO - 2023-04-10 08:03:32 --> Final output sent to browser
INFO - 2023-04-10 08:03:32 --> Final output sent to browser
DEBUG - 2023-04-10 08:03:32 --> Total execution time: 0.0227
DEBUG - 2023-04-10 08:03:32 --> Total execution time: 0.0320
INFO - 2023-04-10 08:03:32 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:03:32 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:03:32 --> Config Class Initialized
INFO - 2023-04-10 08:03:32 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:32 --> Hooks Class Initialized
INFO - 2023-04-10 08:03:32 --> URI Class Initialized
DEBUG - 2023-04-10 08:03:32 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:03:32 --> Router Class Initialized
INFO - 2023-04-10 08:03:32 --> Utf8 Class Initialized
INFO - 2023-04-10 08:03:32 --> Output Class Initialized
INFO - 2023-04-10 08:03:32 --> URI Class Initialized
INFO - 2023-04-10 08:03:32 --> Security Class Initialized
INFO - 2023-04-10 08:03:32 --> Router Class Initialized
DEBUG - 2023-04-10 08:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:03:32 --> Output Class Initialized
INFO - 2023-04-10 08:03:32 --> Input Class Initialized
INFO - 2023-04-10 08:03:32 --> Security Class Initialized
INFO - 2023-04-10 08:03:32 --> Language Class Initialized
DEBUG - 2023-04-10 08:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:03:32 --> Input Class Initialized
INFO - 2023-04-10 08:03:32 --> Loader Class Initialized
INFO - 2023-04-10 08:03:32 --> Language Class Initialized
INFO - 2023-04-10 08:03:32 --> Controller Class Initialized
INFO - 2023-04-10 08:03:32 --> Loader Class Initialized
DEBUG - 2023-04-10 08:03:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:03:32 --> Controller Class Initialized
INFO - 2023-04-10 08:03:32 --> Database Driver Class Initialized
DEBUG - 2023-04-10 08:03:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:03:32 --> Database Driver Class Initialized
INFO - 2023-04-10 08:03:32 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:03:32 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:03:32 --> Final output sent to browser
DEBUG - 2023-04-10 08:03:32 --> Total execution time: 0.0983
INFO - 2023-04-10 08:03:32 --> Final output sent to browser
DEBUG - 2023-04-10 08:03:32 --> Total execution time: 0.1491
INFO - 2023-04-10 08:04:07 --> Config Class Initialized
INFO - 2023-04-10 08:04:07 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:07 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:07 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:07 --> URI Class Initialized
INFO - 2023-04-10 08:04:07 --> Router Class Initialized
INFO - 2023-04-10 08:04:07 --> Output Class Initialized
INFO - 2023-04-10 08:04:07 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:07 --> Input Class Initialized
INFO - 2023-04-10 08:04:07 --> Language Class Initialized
INFO - 2023-04-10 08:04:07 --> Loader Class Initialized
INFO - 2023-04-10 08:04:07 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:07 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:07 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:07 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:07 --> Total execution time: 0.0156
INFO - 2023-04-10 08:04:07 --> Config Class Initialized
INFO - 2023-04-10 08:04:07 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:07 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:07 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:07 --> URI Class Initialized
INFO - 2023-04-10 08:04:07 --> Router Class Initialized
INFO - 2023-04-10 08:04:07 --> Output Class Initialized
INFO - 2023-04-10 08:04:07 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:07 --> Input Class Initialized
INFO - 2023-04-10 08:04:07 --> Language Class Initialized
INFO - 2023-04-10 08:04:07 --> Loader Class Initialized
INFO - 2023-04-10 08:04:07 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:07 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:07 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:07 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:07 --> Total execution time: 0.0119
INFO - 2023-04-10 08:04:08 --> Config Class Initialized
INFO - 2023-04-10 08:04:08 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:08 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:08 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:08 --> URI Class Initialized
INFO - 2023-04-10 08:04:08 --> Router Class Initialized
INFO - 2023-04-10 08:04:08 --> Output Class Initialized
INFO - 2023-04-10 08:04:08 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:08 --> Input Class Initialized
INFO - 2023-04-10 08:04:08 --> Language Class Initialized
INFO - 2023-04-10 08:04:08 --> Loader Class Initialized
INFO - 2023-04-10 08:04:08 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:08 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:08 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:08 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:08 --> Total execution time: 0.1344
INFO - 2023-04-10 08:04:08 --> Config Class Initialized
INFO - 2023-04-10 08:04:08 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:08 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:08 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:08 --> URI Class Initialized
INFO - 2023-04-10 08:04:08 --> Router Class Initialized
INFO - 2023-04-10 08:04:08 --> Output Class Initialized
INFO - 2023-04-10 08:04:08 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:08 --> Input Class Initialized
INFO - 2023-04-10 08:04:08 --> Language Class Initialized
INFO - 2023-04-10 08:04:08 --> Loader Class Initialized
INFO - 2023-04-10 08:04:08 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:08 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:08 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:08 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:08 --> Total execution time: 0.0869
INFO - 2023-04-10 08:04:17 --> Config Class Initialized
INFO - 2023-04-10 08:04:17 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:17 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:17 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:17 --> URI Class Initialized
INFO - 2023-04-10 08:04:17 --> Router Class Initialized
INFO - 2023-04-10 08:04:17 --> Output Class Initialized
INFO - 2023-04-10 08:04:17 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:17 --> Input Class Initialized
INFO - 2023-04-10 08:04:17 --> Language Class Initialized
INFO - 2023-04-10 08:04:17 --> Loader Class Initialized
INFO - 2023-04-10 08:04:17 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:17 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:17 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:17 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:17 --> Total execution time: 0.0459
INFO - 2023-04-10 08:04:17 --> Config Class Initialized
INFO - 2023-04-10 08:04:17 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:17 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:17 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:17 --> URI Class Initialized
INFO - 2023-04-10 08:04:17 --> Router Class Initialized
INFO - 2023-04-10 08:04:17 --> Output Class Initialized
INFO - 2023-04-10 08:04:17 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:17 --> Input Class Initialized
INFO - 2023-04-10 08:04:17 --> Language Class Initialized
INFO - 2023-04-10 08:04:17 --> Loader Class Initialized
INFO - 2023-04-10 08:04:17 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:17 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:17 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:17 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:17 --> Total execution time: 0.0863
INFO - 2023-04-10 08:04:20 --> Config Class Initialized
INFO - 2023-04-10 08:04:20 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:20 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:20 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:20 --> URI Class Initialized
INFO - 2023-04-10 08:04:20 --> Router Class Initialized
INFO - 2023-04-10 08:04:20 --> Output Class Initialized
INFO - 2023-04-10 08:04:20 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:20 --> Input Class Initialized
INFO - 2023-04-10 08:04:20 --> Language Class Initialized
INFO - 2023-04-10 08:04:20 --> Loader Class Initialized
INFO - 2023-04-10 08:04:20 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:20 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:20 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:20 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:20 --> Total execution time: 0.1538
INFO - 2023-04-10 08:04:20 --> Config Class Initialized
INFO - 2023-04-10 08:04:20 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:20 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:20 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:20 --> URI Class Initialized
INFO - 2023-04-10 08:04:20 --> Router Class Initialized
INFO - 2023-04-10 08:04:20 --> Output Class Initialized
INFO - 2023-04-10 08:04:20 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:20 --> Input Class Initialized
INFO - 2023-04-10 08:04:20 --> Language Class Initialized
INFO - 2023-04-10 08:04:20 --> Loader Class Initialized
INFO - 2023-04-10 08:04:20 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:20 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:20 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:20 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:20 --> Total execution time: 0.0804
INFO - 2023-04-10 08:04:22 --> Config Class Initialized
INFO - 2023-04-10 08:04:22 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:22 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:22 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:22 --> URI Class Initialized
INFO - 2023-04-10 08:04:22 --> Router Class Initialized
INFO - 2023-04-10 08:04:22 --> Output Class Initialized
INFO - 2023-04-10 08:04:22 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:22 --> Input Class Initialized
INFO - 2023-04-10 08:04:22 --> Language Class Initialized
INFO - 2023-04-10 08:04:22 --> Loader Class Initialized
INFO - 2023-04-10 08:04:22 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:22 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:22 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:22 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:22 --> Total execution time: 0.0261
INFO - 2023-04-10 08:04:22 --> Config Class Initialized
INFO - 2023-04-10 08:04:22 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:22 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:22 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:22 --> URI Class Initialized
INFO - 2023-04-10 08:04:22 --> Router Class Initialized
INFO - 2023-04-10 08:04:22 --> Output Class Initialized
INFO - 2023-04-10 08:04:22 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:22 --> Input Class Initialized
INFO - 2023-04-10 08:04:22 --> Language Class Initialized
INFO - 2023-04-10 08:04:22 --> Loader Class Initialized
INFO - 2023-04-10 08:04:22 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:22 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:22 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:22 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:22 --> Total execution time: 0.0623
INFO - 2023-04-10 08:04:26 --> Config Class Initialized
INFO - 2023-04-10 08:04:26 --> Config Class Initialized
INFO - 2023-04-10 08:04:26 --> Hooks Class Initialized
INFO - 2023-04-10 08:04:26 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-10 08:04:26 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:26 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:26 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:26 --> URI Class Initialized
INFO - 2023-04-10 08:04:26 --> URI Class Initialized
INFO - 2023-04-10 08:04:26 --> Router Class Initialized
INFO - 2023-04-10 08:04:26 --> Router Class Initialized
INFO - 2023-04-10 08:04:26 --> Output Class Initialized
INFO - 2023-04-10 08:04:26 --> Output Class Initialized
INFO - 2023-04-10 08:04:26 --> Security Class Initialized
INFO - 2023-04-10 08:04:26 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-10 08:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:26 --> Input Class Initialized
INFO - 2023-04-10 08:04:26 --> Input Class Initialized
INFO - 2023-04-10 08:04:26 --> Language Class Initialized
INFO - 2023-04-10 08:04:26 --> Language Class Initialized
INFO - 2023-04-10 08:04:26 --> Loader Class Initialized
INFO - 2023-04-10 08:04:26 --> Loader Class Initialized
INFO - 2023-04-10 08:04:26 --> Controller Class Initialized
INFO - 2023-04-10 08:04:26 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-10 08:04:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:26 --> Final output sent to browser
INFO - 2023-04-10 08:04:26 --> Database Driver Class Initialized
DEBUG - 2023-04-10 08:04:26 --> Total execution time: 0.0044
INFO - 2023-04-10 08:04:26 --> Config Class Initialized
INFO - 2023-04-10 08:04:26 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:26 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:26 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:26 --> URI Class Initialized
INFO - 2023-04-10 08:04:26 --> Router Class Initialized
INFO - 2023-04-10 08:04:26 --> Output Class Initialized
INFO - 2023-04-10 08:04:26 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:26 --> Input Class Initialized
INFO - 2023-04-10 08:04:26 --> Language Class Initialized
INFO - 2023-04-10 08:04:26 --> Loader Class Initialized
INFO - 2023-04-10 08:04:26 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:26 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:26 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:26 --> Model "Login_model" initialized
INFO - 2023-04-10 08:04:26 --> Final output sent to browser
INFO - 2023-04-10 08:04:26 --> Database Driver Class Initialized
DEBUG - 2023-04-10 08:04:26 --> Total execution time: 0.0207
INFO - 2023-04-10 08:04:26 --> Config Class Initialized
INFO - 2023-04-10 08:04:26 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:26 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:26 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:26 --> URI Class Initialized
INFO - 2023-04-10 08:04:26 --> Router Class Initialized
INFO - 2023-04-10 08:04:26 --> Output Class Initialized
INFO - 2023-04-10 08:04:26 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:26 --> Input Class Initialized
INFO - 2023-04-10 08:04:26 --> Language Class Initialized
INFO - 2023-04-10 08:04:26 --> Loader Class Initialized
INFO - 2023-04-10 08:04:26 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:26 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:26 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:26 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:26 --> Total execution time: 0.0283
INFO - 2023-04-10 08:04:26 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:27 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:27 --> Total execution time: 0.0885
INFO - 2023-04-10 08:04:40 --> Config Class Initialized
INFO - 2023-04-10 08:04:40 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:40 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:40 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:40 --> URI Class Initialized
INFO - 2023-04-10 08:04:40 --> Router Class Initialized
INFO - 2023-04-10 08:04:40 --> Output Class Initialized
INFO - 2023-04-10 08:04:40 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:40 --> Input Class Initialized
INFO - 2023-04-10 08:04:40 --> Language Class Initialized
INFO - 2023-04-10 08:04:40 --> Loader Class Initialized
INFO - 2023-04-10 08:04:40 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:40 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:40 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:40 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:40 --> Total execution time: 0.0151
INFO - 2023-04-10 08:04:40 --> Config Class Initialized
INFO - 2023-04-10 08:04:40 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:40 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:40 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:40 --> URI Class Initialized
INFO - 2023-04-10 08:04:40 --> Router Class Initialized
INFO - 2023-04-10 08:04:40 --> Output Class Initialized
INFO - 2023-04-10 08:04:40 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:40 --> Input Class Initialized
INFO - 2023-04-10 08:04:40 --> Language Class Initialized
INFO - 2023-04-10 08:04:40 --> Loader Class Initialized
INFO - 2023-04-10 08:04:40 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:40 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:40 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:40 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:40 --> Total execution time: 0.0159
INFO - 2023-04-10 08:04:40 --> Config Class Initialized
INFO - 2023-04-10 08:04:40 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:40 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:40 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:40 --> URI Class Initialized
INFO - 2023-04-10 08:04:40 --> Router Class Initialized
INFO - 2023-04-10 08:04:40 --> Output Class Initialized
INFO - 2023-04-10 08:04:40 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:40 --> Input Class Initialized
INFO - 2023-04-10 08:04:40 --> Language Class Initialized
INFO - 2023-04-10 08:04:40 --> Loader Class Initialized
INFO - 2023-04-10 08:04:40 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:40 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:40 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:40 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:40 --> Total execution time: 0.0568
INFO - 2023-04-10 08:04:40 --> Config Class Initialized
INFO - 2023-04-10 08:04:40 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:40 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:40 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:40 --> URI Class Initialized
INFO - 2023-04-10 08:04:40 --> Router Class Initialized
INFO - 2023-04-10 08:04:40 --> Output Class Initialized
INFO - 2023-04-10 08:04:40 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:40 --> Input Class Initialized
INFO - 2023-04-10 08:04:40 --> Language Class Initialized
INFO - 2023-04-10 08:04:40 --> Loader Class Initialized
INFO - 2023-04-10 08:04:40 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:40 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:40 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:40 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:40 --> Total execution time: 0.0120
INFO - 2023-04-10 08:04:44 --> Config Class Initialized
INFO - 2023-04-10 08:04:44 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:44 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:44 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:44 --> URI Class Initialized
INFO - 2023-04-10 08:04:44 --> Router Class Initialized
INFO - 2023-04-10 08:04:44 --> Output Class Initialized
INFO - 2023-04-10 08:04:44 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:44 --> Input Class Initialized
INFO - 2023-04-10 08:04:44 --> Language Class Initialized
INFO - 2023-04-10 08:04:44 --> Loader Class Initialized
INFO - 2023-04-10 08:04:44 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:44 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:44 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:44 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:44 --> Total execution time: 0.0452
INFO - 2023-04-10 08:04:44 --> Config Class Initialized
INFO - 2023-04-10 08:04:44 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:04:44 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:04:44 --> Utf8 Class Initialized
INFO - 2023-04-10 08:04:44 --> URI Class Initialized
INFO - 2023-04-10 08:04:44 --> Router Class Initialized
INFO - 2023-04-10 08:04:44 --> Output Class Initialized
INFO - 2023-04-10 08:04:44 --> Security Class Initialized
DEBUG - 2023-04-10 08:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:04:44 --> Input Class Initialized
INFO - 2023-04-10 08:04:44 --> Language Class Initialized
INFO - 2023-04-10 08:04:44 --> Loader Class Initialized
INFO - 2023-04-10 08:04:44 --> Controller Class Initialized
DEBUG - 2023-04-10 08:04:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:04:44 --> Database Driver Class Initialized
INFO - 2023-04-10 08:04:44 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:04:44 --> Final output sent to browser
DEBUG - 2023-04-10 08:04:44 --> Total execution time: 0.0396
INFO - 2023-04-10 08:51:19 --> Config Class Initialized
INFO - 2023-04-10 08:51:19 --> Config Class Initialized
INFO - 2023-04-10 08:51:19 --> Hooks Class Initialized
INFO - 2023-04-10 08:51:19 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-10 08:51:19 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:51:19 --> Utf8 Class Initialized
INFO - 2023-04-10 08:51:19 --> Utf8 Class Initialized
INFO - 2023-04-10 08:51:19 --> URI Class Initialized
INFO - 2023-04-10 08:51:19 --> URI Class Initialized
INFO - 2023-04-10 08:51:19 --> Router Class Initialized
INFO - 2023-04-10 08:51:19 --> Router Class Initialized
INFO - 2023-04-10 08:51:19 --> Output Class Initialized
INFO - 2023-04-10 08:51:19 --> Output Class Initialized
INFO - 2023-04-10 08:51:19 --> Security Class Initialized
INFO - 2023-04-10 08:51:19 --> Security Class Initialized
DEBUG - 2023-04-10 08:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-10 08:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:51:19 --> Input Class Initialized
INFO - 2023-04-10 08:51:19 --> Input Class Initialized
INFO - 2023-04-10 08:51:19 --> Language Class Initialized
INFO - 2023-04-10 08:51:19 --> Language Class Initialized
INFO - 2023-04-10 08:51:19 --> Loader Class Initialized
INFO - 2023-04-10 08:51:19 --> Loader Class Initialized
INFO - 2023-04-10 08:51:19 --> Controller Class Initialized
INFO - 2023-04-10 08:51:19 --> Controller Class Initialized
DEBUG - 2023-04-10 08:51:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-10 08:51:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:51:19 --> Final output sent to browser
DEBUG - 2023-04-10 08:51:19 --> Total execution time: 0.0042
INFO - 2023-04-10 08:51:19 --> Database Driver Class Initialized
INFO - 2023-04-10 08:51:19 --> Config Class Initialized
INFO - 2023-04-10 08:51:19 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:51:19 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:51:19 --> Utf8 Class Initialized
INFO - 2023-04-10 08:51:19 --> URI Class Initialized
INFO - 2023-04-10 08:51:19 --> Router Class Initialized
INFO - 2023-04-10 08:51:19 --> Output Class Initialized
INFO - 2023-04-10 08:51:19 --> Security Class Initialized
DEBUG - 2023-04-10 08:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:51:19 --> Input Class Initialized
INFO - 2023-04-10 08:51:19 --> Language Class Initialized
INFO - 2023-04-10 08:51:19 --> Loader Class Initialized
INFO - 2023-04-10 08:51:19 --> Controller Class Initialized
DEBUG - 2023-04-10 08:51:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:51:19 --> Database Driver Class Initialized
INFO - 2023-04-10 08:51:19 --> Model "Login_model" initialized
INFO - 2023-04-10 08:51:19 --> Database Driver Class Initialized
INFO - 2023-04-10 08:51:19 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:51:19 --> Final output sent to browser
DEBUG - 2023-04-10 08:51:19 --> Total execution time: 0.0851
INFO - 2023-04-10 08:51:20 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:51:20 --> Final output sent to browser
DEBUG - 2023-04-10 08:51:20 --> Total execution time: 1.0186
INFO - 2023-04-10 08:51:20 --> Config Class Initialized
INFO - 2023-04-10 08:51:20 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:51:20 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:51:20 --> Utf8 Class Initialized
INFO - 2023-04-10 08:51:20 --> URI Class Initialized
INFO - 2023-04-10 08:51:20 --> Router Class Initialized
INFO - 2023-04-10 08:51:20 --> Output Class Initialized
INFO - 2023-04-10 08:51:20 --> Security Class Initialized
DEBUG - 2023-04-10 08:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:51:20 --> Input Class Initialized
INFO - 2023-04-10 08:51:20 --> Language Class Initialized
INFO - 2023-04-10 08:51:20 --> Loader Class Initialized
INFO - 2023-04-10 08:51:20 --> Controller Class Initialized
DEBUG - 2023-04-10 08:51:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:51:20 --> Database Driver Class Initialized
INFO - 2023-04-10 08:51:20 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:51:20 --> Final output sent to browser
DEBUG - 2023-04-10 08:51:20 --> Total execution time: 0.0196
INFO - 2023-04-10 08:52:10 --> Config Class Initialized
INFO - 2023-04-10 08:52:10 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:52:10 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:52:10 --> Utf8 Class Initialized
INFO - 2023-04-10 08:52:10 --> URI Class Initialized
INFO - 2023-04-10 08:52:10 --> Router Class Initialized
INFO - 2023-04-10 08:52:10 --> Output Class Initialized
INFO - 2023-04-10 08:52:10 --> Security Class Initialized
DEBUG - 2023-04-10 08:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:52:10 --> Input Class Initialized
INFO - 2023-04-10 08:52:10 --> Language Class Initialized
INFO - 2023-04-10 08:52:10 --> Loader Class Initialized
INFO - 2023-04-10 08:52:10 --> Controller Class Initialized
DEBUG - 2023-04-10 08:52:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:52:10 --> Database Driver Class Initialized
INFO - 2023-04-10 08:52:10 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:52:10 --> Final output sent to browser
DEBUG - 2023-04-10 08:52:10 --> Total execution time: 0.0638
INFO - 2023-04-10 08:52:10 --> Config Class Initialized
INFO - 2023-04-10 08:52:10 --> Hooks Class Initialized
DEBUG - 2023-04-10 08:52:10 --> UTF-8 Support Enabled
INFO - 2023-04-10 08:52:10 --> Utf8 Class Initialized
INFO - 2023-04-10 08:52:10 --> URI Class Initialized
INFO - 2023-04-10 08:52:10 --> Router Class Initialized
INFO - 2023-04-10 08:52:10 --> Output Class Initialized
INFO - 2023-04-10 08:52:10 --> Security Class Initialized
DEBUG - 2023-04-10 08:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 08:52:10 --> Input Class Initialized
INFO - 2023-04-10 08:52:10 --> Language Class Initialized
INFO - 2023-04-10 08:52:10 --> Loader Class Initialized
INFO - 2023-04-10 08:52:10 --> Controller Class Initialized
DEBUG - 2023-04-10 08:52:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 08:52:10 --> Database Driver Class Initialized
INFO - 2023-04-10 08:52:10 --> Model "Cluster_model" initialized
INFO - 2023-04-10 08:52:10 --> Final output sent to browser
DEBUG - 2023-04-10 08:52:10 --> Total execution time: 0.0882
INFO - 2023-04-10 09:26:29 --> Config Class Initialized
INFO - 2023-04-10 09:26:29 --> Hooks Class Initialized
DEBUG - 2023-04-10 09:26:29 --> UTF-8 Support Enabled
INFO - 2023-04-10 09:26:29 --> Utf8 Class Initialized
INFO - 2023-04-10 09:26:29 --> URI Class Initialized
INFO - 2023-04-10 09:26:29 --> Router Class Initialized
INFO - 2023-04-10 09:26:29 --> Output Class Initialized
INFO - 2023-04-10 09:26:29 --> Security Class Initialized
DEBUG - 2023-04-10 09:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 09:26:29 --> Input Class Initialized
INFO - 2023-04-10 09:26:29 --> Language Class Initialized
INFO - 2023-04-10 09:26:29 --> Loader Class Initialized
INFO - 2023-04-10 09:26:29 --> Controller Class Initialized
DEBUG - 2023-04-10 09:26:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 09:26:29 --> Database Driver Class Initialized
INFO - 2023-04-10 09:26:29 --> Model "Cluster_model" initialized
INFO - 2023-04-10 09:26:29 --> Final output sent to browser
DEBUG - 2023-04-10 09:26:29 --> Total execution time: 0.1399
INFO - 2023-04-10 09:26:29 --> Config Class Initialized
INFO - 2023-04-10 09:26:29 --> Hooks Class Initialized
DEBUG - 2023-04-10 09:26:29 --> UTF-8 Support Enabled
INFO - 2023-04-10 09:26:29 --> Utf8 Class Initialized
INFO - 2023-04-10 09:26:29 --> URI Class Initialized
INFO - 2023-04-10 09:26:29 --> Router Class Initialized
INFO - 2023-04-10 09:26:29 --> Output Class Initialized
INFO - 2023-04-10 09:26:29 --> Security Class Initialized
DEBUG - 2023-04-10 09:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 09:26:29 --> Input Class Initialized
INFO - 2023-04-10 09:26:29 --> Language Class Initialized
INFO - 2023-04-10 09:26:29 --> Loader Class Initialized
INFO - 2023-04-10 09:26:29 --> Controller Class Initialized
DEBUG - 2023-04-10 09:26:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 09:26:29 --> Database Driver Class Initialized
INFO - 2023-04-10 09:26:29 --> Model "Cluster_model" initialized
INFO - 2023-04-10 09:26:29 --> Final output sent to browser
DEBUG - 2023-04-10 09:26:29 --> Total execution time: 0.1000
INFO - 2023-04-10 09:26:33 --> Config Class Initialized
INFO - 2023-04-10 09:26:33 --> Hooks Class Initialized
DEBUG - 2023-04-10 09:26:33 --> UTF-8 Support Enabled
INFO - 2023-04-10 09:26:33 --> Utf8 Class Initialized
INFO - 2023-04-10 09:26:33 --> URI Class Initialized
INFO - 2023-04-10 09:26:33 --> Router Class Initialized
INFO - 2023-04-10 09:26:33 --> Output Class Initialized
INFO - 2023-04-10 09:26:33 --> Security Class Initialized
DEBUG - 2023-04-10 09:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 09:26:33 --> Input Class Initialized
INFO - 2023-04-10 09:26:33 --> Language Class Initialized
INFO - 2023-04-10 09:26:33 --> Loader Class Initialized
INFO - 2023-04-10 09:26:33 --> Controller Class Initialized
DEBUG - 2023-04-10 09:26:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 09:26:33 --> Database Driver Class Initialized
INFO - 2023-04-10 09:26:33 --> Model "Cluster_model" initialized
INFO - 2023-04-10 09:26:33 --> Final output sent to browser
DEBUG - 2023-04-10 09:26:33 --> Total execution time: 0.0261
INFO - 2023-04-10 09:26:33 --> Config Class Initialized
INFO - 2023-04-10 09:26:33 --> Hooks Class Initialized
DEBUG - 2023-04-10 09:26:33 --> UTF-8 Support Enabled
INFO - 2023-04-10 09:26:33 --> Utf8 Class Initialized
INFO - 2023-04-10 09:26:33 --> URI Class Initialized
INFO - 2023-04-10 09:26:33 --> Router Class Initialized
INFO - 2023-04-10 09:26:33 --> Output Class Initialized
INFO - 2023-04-10 09:26:33 --> Security Class Initialized
DEBUG - 2023-04-10 09:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 09:26:33 --> Input Class Initialized
INFO - 2023-04-10 09:26:33 --> Language Class Initialized
INFO - 2023-04-10 09:26:33 --> Loader Class Initialized
INFO - 2023-04-10 09:26:33 --> Controller Class Initialized
DEBUG - 2023-04-10 09:26:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 09:26:33 --> Database Driver Class Initialized
INFO - 2023-04-10 09:26:33 --> Model "Cluster_model" initialized
INFO - 2023-04-10 09:26:33 --> Final output sent to browser
DEBUG - 2023-04-10 09:26:33 --> Total execution time: 0.0617
INFO - 2023-04-10 09:26:36 --> Config Class Initialized
INFO - 2023-04-10 09:26:36 --> Hooks Class Initialized
DEBUG - 2023-04-10 09:26:36 --> UTF-8 Support Enabled
INFO - 2023-04-10 09:26:36 --> Utf8 Class Initialized
INFO - 2023-04-10 09:26:36 --> URI Class Initialized
INFO - 2023-04-10 09:26:36 --> Router Class Initialized
INFO - 2023-04-10 09:26:36 --> Output Class Initialized
INFO - 2023-04-10 09:26:36 --> Security Class Initialized
DEBUG - 2023-04-10 09:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 09:26:36 --> Input Class Initialized
INFO - 2023-04-10 09:26:36 --> Language Class Initialized
INFO - 2023-04-10 09:26:36 --> Loader Class Initialized
INFO - 2023-04-10 09:26:36 --> Controller Class Initialized
DEBUG - 2023-04-10 09:26:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 09:26:36 --> Database Driver Class Initialized
INFO - 2023-04-10 09:26:36 --> Model "Cluster_model" initialized
INFO - 2023-04-10 09:26:36 --> Final output sent to browser
DEBUG - 2023-04-10 09:26:36 --> Total execution time: 0.0520
INFO - 2023-04-10 09:26:36 --> Config Class Initialized
INFO - 2023-04-10 09:26:36 --> Hooks Class Initialized
DEBUG - 2023-04-10 09:26:36 --> UTF-8 Support Enabled
INFO - 2023-04-10 09:26:36 --> Utf8 Class Initialized
INFO - 2023-04-10 09:26:36 --> URI Class Initialized
INFO - 2023-04-10 09:26:36 --> Router Class Initialized
INFO - 2023-04-10 09:26:36 --> Output Class Initialized
INFO - 2023-04-10 09:26:36 --> Security Class Initialized
DEBUG - 2023-04-10 09:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 09:26:36 --> Input Class Initialized
INFO - 2023-04-10 09:26:36 --> Language Class Initialized
INFO - 2023-04-10 09:26:36 --> Loader Class Initialized
INFO - 2023-04-10 09:26:36 --> Controller Class Initialized
DEBUG - 2023-04-10 09:26:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 09:26:36 --> Database Driver Class Initialized
INFO - 2023-04-10 09:26:36 --> Model "Cluster_model" initialized
INFO - 2023-04-10 09:26:36 --> Final output sent to browser
DEBUG - 2023-04-10 09:26:36 --> Total execution time: 0.0450
INFO - 2023-04-10 09:57:47 --> Config Class Initialized
INFO - 2023-04-10 09:57:47 --> Hooks Class Initialized
DEBUG - 2023-04-10 09:57:47 --> UTF-8 Support Enabled
INFO - 2023-04-10 09:57:47 --> Utf8 Class Initialized
INFO - 2023-04-10 09:57:47 --> URI Class Initialized
INFO - 2023-04-10 09:57:47 --> Router Class Initialized
INFO - 2023-04-10 09:57:47 --> Output Class Initialized
INFO - 2023-04-10 09:57:47 --> Security Class Initialized
DEBUG - 2023-04-10 09:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 09:57:47 --> Input Class Initialized
INFO - 2023-04-10 09:57:47 --> Language Class Initialized
INFO - 2023-04-10 09:57:47 --> Loader Class Initialized
INFO - 2023-04-10 09:57:47 --> Controller Class Initialized
DEBUG - 2023-04-10 09:57:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 09:57:47 --> Database Driver Class Initialized
INFO - 2023-04-10 09:57:47 --> Model "Cluster_model" initialized
INFO - 2023-04-10 09:57:47 --> Final output sent to browser
DEBUG - 2023-04-10 09:57:47 --> Total execution time: 0.0247
INFO - 2023-04-10 09:57:47 --> Config Class Initialized
INFO - 2023-04-10 09:57:47 --> Hooks Class Initialized
DEBUG - 2023-04-10 09:57:47 --> UTF-8 Support Enabled
INFO - 2023-04-10 09:57:47 --> Utf8 Class Initialized
INFO - 2023-04-10 09:57:47 --> URI Class Initialized
INFO - 2023-04-10 09:57:47 --> Router Class Initialized
INFO - 2023-04-10 09:57:47 --> Output Class Initialized
INFO - 2023-04-10 09:57:47 --> Security Class Initialized
DEBUG - 2023-04-10 09:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 09:57:47 --> Input Class Initialized
INFO - 2023-04-10 09:57:47 --> Language Class Initialized
INFO - 2023-04-10 09:57:47 --> Loader Class Initialized
INFO - 2023-04-10 09:57:47 --> Controller Class Initialized
DEBUG - 2023-04-10 09:57:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 09:57:47 --> Database Driver Class Initialized
INFO - 2023-04-10 09:57:47 --> Model "Cluster_model" initialized
INFO - 2023-04-10 09:57:47 --> Final output sent to browser
DEBUG - 2023-04-10 09:57:47 --> Total execution time: 0.0163
INFO - 2023-04-10 10:00:47 --> Config Class Initialized
INFO - 2023-04-10 10:00:47 --> Hooks Class Initialized
DEBUG - 2023-04-10 10:00:47 --> UTF-8 Support Enabled
INFO - 2023-04-10 10:00:47 --> Utf8 Class Initialized
INFO - 2023-04-10 10:00:47 --> URI Class Initialized
INFO - 2023-04-10 10:00:47 --> Router Class Initialized
INFO - 2023-04-10 10:00:47 --> Output Class Initialized
INFO - 2023-04-10 10:00:47 --> Security Class Initialized
DEBUG - 2023-04-10 10:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 10:00:47 --> Input Class Initialized
INFO - 2023-04-10 10:00:47 --> Language Class Initialized
INFO - 2023-04-10 10:00:47 --> Loader Class Initialized
INFO - 2023-04-10 10:00:47 --> Controller Class Initialized
DEBUG - 2023-04-10 10:00:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 10:00:47 --> Database Driver Class Initialized
INFO - 2023-04-10 10:00:47 --> Model "Cluster_model" initialized
INFO - 2023-04-10 10:00:47 --> Final output sent to browser
INFO - 2023-04-10 10:00:47 --> Config Class Initialized
DEBUG - 2023-04-10 10:00:47 --> Total execution time: 0.1047
INFO - 2023-04-10 10:00:47 --> Hooks Class Initialized
DEBUG - 2023-04-10 10:00:47 --> UTF-8 Support Enabled
INFO - 2023-04-10 10:00:47 --> Utf8 Class Initialized
INFO - 2023-04-10 10:00:47 --> URI Class Initialized
INFO - 2023-04-10 10:00:47 --> Router Class Initialized
INFO - 2023-04-10 10:00:47 --> Output Class Initialized
INFO - 2023-04-10 10:00:47 --> Security Class Initialized
DEBUG - 2023-04-10 10:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 10:00:47 --> Input Class Initialized
INFO - 2023-04-10 10:00:47 --> Language Class Initialized
INFO - 2023-04-10 10:00:47 --> Loader Class Initialized
INFO - 2023-04-10 10:00:47 --> Controller Class Initialized
DEBUG - 2023-04-10 10:00:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 10:00:47 --> Database Driver Class Initialized
INFO - 2023-04-10 10:00:47 --> Model "Cluster_model" initialized
INFO - 2023-04-10 10:00:47 --> Final output sent to browser
DEBUG - 2023-04-10 10:00:47 --> Total execution time: 0.1077
INFO - 2023-04-10 10:48:49 --> Config Class Initialized
INFO - 2023-04-10 10:48:49 --> Config Class Initialized
INFO - 2023-04-10 10:48:49 --> Hooks Class Initialized
INFO - 2023-04-10 10:48:49 --> Hooks Class Initialized
DEBUG - 2023-04-10 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-10 10:48:49 --> UTF-8 Support Enabled
INFO - 2023-04-10 10:48:49 --> Utf8 Class Initialized
INFO - 2023-04-10 10:48:49 --> Utf8 Class Initialized
INFO - 2023-04-10 10:48:49 --> URI Class Initialized
INFO - 2023-04-10 10:48:49 --> URI Class Initialized
INFO - 2023-04-10 10:48:49 --> Router Class Initialized
INFO - 2023-04-10 10:48:49 --> Router Class Initialized
INFO - 2023-04-10 10:48:49 --> Output Class Initialized
INFO - 2023-04-10 10:48:49 --> Output Class Initialized
INFO - 2023-04-10 10:48:49 --> Security Class Initialized
INFO - 2023-04-10 10:48:49 --> Security Class Initialized
DEBUG - 2023-04-10 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-10 10:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 10:48:49 --> Input Class Initialized
INFO - 2023-04-10 10:48:49 --> Input Class Initialized
INFO - 2023-04-10 10:48:49 --> Language Class Initialized
INFO - 2023-04-10 10:48:49 --> Language Class Initialized
INFO - 2023-04-10 10:48:49 --> Loader Class Initialized
INFO - 2023-04-10 10:48:49 --> Loader Class Initialized
INFO - 2023-04-10 10:48:49 --> Controller Class Initialized
INFO - 2023-04-10 10:48:49 --> Controller Class Initialized
DEBUG - 2023-04-10 10:48:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-10 10:48:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 10:48:49 --> Final output sent to browser
DEBUG - 2023-04-10 10:48:49 --> Total execution time: 0.0059
INFO - 2023-04-10 10:48:49 --> Config Class Initialized
INFO - 2023-04-10 10:48:49 --> Hooks Class Initialized
INFO - 2023-04-10 10:48:49 --> Database Driver Class Initialized
DEBUG - 2023-04-10 10:48:49 --> UTF-8 Support Enabled
INFO - 2023-04-10 10:48:49 --> Utf8 Class Initialized
INFO - 2023-04-10 10:48:49 --> URI Class Initialized
INFO - 2023-04-10 10:48:49 --> Router Class Initialized
INFO - 2023-04-10 10:48:49 --> Output Class Initialized
INFO - 2023-04-10 10:48:49 --> Security Class Initialized
DEBUG - 2023-04-10 10:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 10:48:49 --> Input Class Initialized
INFO - 2023-04-10 10:48:49 --> Language Class Initialized
INFO - 2023-04-10 10:48:49 --> Loader Class Initialized
INFO - 2023-04-10 10:48:49 --> Controller Class Initialized
DEBUG - 2023-04-10 10:48:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 10:48:49 --> Database Driver Class Initialized
INFO - 2023-04-10 10:48:49 --> Model "Cluster_model" initialized
INFO - 2023-04-10 10:48:49 --> Model "Login_model" initialized
INFO - 2023-04-10 10:48:49 --> Final output sent to browser
DEBUG - 2023-04-10 10:48:49 --> Total execution time: 0.0631
INFO - 2023-04-10 10:48:49 --> Database Driver Class Initialized
INFO - 2023-04-10 10:48:49 --> Config Class Initialized
INFO - 2023-04-10 10:48:49 --> Hooks Class Initialized
DEBUG - 2023-04-10 10:48:49 --> UTF-8 Support Enabled
INFO - 2023-04-10 10:48:49 --> Utf8 Class Initialized
INFO - 2023-04-10 10:48:49 --> URI Class Initialized
INFO - 2023-04-10 10:48:49 --> Router Class Initialized
INFO - 2023-04-10 10:48:49 --> Output Class Initialized
INFO - 2023-04-10 10:48:49 --> Security Class Initialized
DEBUG - 2023-04-10 10:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 10:48:49 --> Input Class Initialized
INFO - 2023-04-10 10:48:49 --> Language Class Initialized
INFO - 2023-04-10 10:48:49 --> Loader Class Initialized
INFO - 2023-04-10 10:48:49 --> Controller Class Initialized
DEBUG - 2023-04-10 10:48:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 10:48:49 --> Database Driver Class Initialized
INFO - 2023-04-10 10:48:49 --> Model "Cluster_model" initialized
INFO - 2023-04-10 10:48:49 --> Final output sent to browser
DEBUG - 2023-04-10 10:48:49 --> Total execution time: 0.0648
INFO - 2023-04-10 10:48:49 --> Model "Cluster_model" initialized
INFO - 2023-04-10 10:48:49 --> Final output sent to browser
DEBUG - 2023-04-10 10:48:49 --> Total execution time: 0.0572
INFO - 2023-04-10 10:48:50 --> Config Class Initialized
INFO - 2023-04-10 10:48:50 --> Hooks Class Initialized
DEBUG - 2023-04-10 10:48:50 --> UTF-8 Support Enabled
INFO - 2023-04-10 10:48:50 --> Utf8 Class Initialized
INFO - 2023-04-10 10:48:50 --> URI Class Initialized
INFO - 2023-04-10 10:48:50 --> Router Class Initialized
INFO - 2023-04-10 10:48:50 --> Output Class Initialized
INFO - 2023-04-10 10:48:50 --> Security Class Initialized
DEBUG - 2023-04-10 10:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 10:48:50 --> Input Class Initialized
INFO - 2023-04-10 10:48:50 --> Language Class Initialized
INFO - 2023-04-10 10:48:50 --> Loader Class Initialized
INFO - 2023-04-10 10:48:50 --> Controller Class Initialized
DEBUG - 2023-04-10 10:48:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 10:48:50 --> Database Driver Class Initialized
INFO - 2023-04-10 10:48:50 --> Model "Cluster_model" initialized
INFO - 2023-04-10 10:48:50 --> Final output sent to browser
DEBUG - 2023-04-10 10:48:50 --> Total execution time: 0.0444
INFO - 2023-04-10 10:48:50 --> Config Class Initialized
INFO - 2023-04-10 10:48:50 --> Hooks Class Initialized
DEBUG - 2023-04-10 10:48:50 --> UTF-8 Support Enabled
INFO - 2023-04-10 10:48:50 --> Utf8 Class Initialized
INFO - 2023-04-10 10:48:50 --> URI Class Initialized
INFO - 2023-04-10 10:48:50 --> Router Class Initialized
INFO - 2023-04-10 10:48:50 --> Output Class Initialized
INFO - 2023-04-10 10:48:50 --> Security Class Initialized
DEBUG - 2023-04-10 10:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 10:48:50 --> Input Class Initialized
INFO - 2023-04-10 10:48:50 --> Language Class Initialized
INFO - 2023-04-10 10:48:50 --> Loader Class Initialized
INFO - 2023-04-10 10:48:50 --> Controller Class Initialized
DEBUG - 2023-04-10 10:48:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 10:48:50 --> Database Driver Class Initialized
INFO - 2023-04-10 10:48:50 --> Model "Cluster_model" initialized
INFO - 2023-04-10 10:48:50 --> Final output sent to browser
DEBUG - 2023-04-10 10:48:50 --> Total execution time: 0.0827
INFO - 2023-04-10 10:48:51 --> Config Class Initialized
INFO - 2023-04-10 10:48:51 --> Hooks Class Initialized
DEBUG - 2023-04-10 10:48:51 --> UTF-8 Support Enabled
INFO - 2023-04-10 10:48:51 --> Utf8 Class Initialized
INFO - 2023-04-10 10:48:51 --> URI Class Initialized
INFO - 2023-04-10 10:48:51 --> Router Class Initialized
INFO - 2023-04-10 10:48:51 --> Output Class Initialized
INFO - 2023-04-10 10:48:51 --> Security Class Initialized
DEBUG - 2023-04-10 10:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 10:48:51 --> Input Class Initialized
INFO - 2023-04-10 10:48:51 --> Language Class Initialized
INFO - 2023-04-10 10:48:51 --> Loader Class Initialized
INFO - 2023-04-10 10:48:51 --> Controller Class Initialized
DEBUG - 2023-04-10 10:48:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 10:48:51 --> Database Driver Class Initialized
INFO - 2023-04-10 10:48:51 --> Model "Cluster_model" initialized
INFO - 2023-04-10 10:48:51 --> Final output sent to browser
DEBUG - 2023-04-10 10:48:51 --> Total execution time: 0.0193
INFO - 2023-04-10 10:48:51 --> Config Class Initialized
INFO - 2023-04-10 10:48:52 --> Hooks Class Initialized
DEBUG - 2023-04-10 10:48:52 --> UTF-8 Support Enabled
INFO - 2023-04-10 10:48:52 --> Utf8 Class Initialized
INFO - 2023-04-10 10:48:52 --> URI Class Initialized
INFO - 2023-04-10 10:48:52 --> Router Class Initialized
INFO - 2023-04-10 10:48:52 --> Output Class Initialized
INFO - 2023-04-10 10:48:52 --> Security Class Initialized
DEBUG - 2023-04-10 10:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 10:48:52 --> Input Class Initialized
INFO - 2023-04-10 10:48:52 --> Language Class Initialized
INFO - 2023-04-10 10:48:52 --> Loader Class Initialized
INFO - 2023-04-10 10:48:52 --> Controller Class Initialized
DEBUG - 2023-04-10 10:48:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 10:48:52 --> Database Driver Class Initialized
INFO - 2023-04-10 10:48:52 --> Model "Cluster_model" initialized
INFO - 2023-04-10 10:48:52 --> Final output sent to browser
DEBUG - 2023-04-10 10:48:52 --> Total execution time: 0.0562
INFO - 2023-04-10 12:44:29 --> Config Class Initialized
INFO - 2023-04-10 12:44:29 --> Config Class Initialized
INFO - 2023-04-10 12:44:29 --> Hooks Class Initialized
INFO - 2023-04-10 12:44:29 --> Hooks Class Initialized
DEBUG - 2023-04-10 12:44:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-10 12:44:29 --> UTF-8 Support Enabled
INFO - 2023-04-10 12:44:29 --> Utf8 Class Initialized
INFO - 2023-04-10 12:44:29 --> Utf8 Class Initialized
INFO - 2023-04-10 12:44:29 --> URI Class Initialized
INFO - 2023-04-10 12:44:29 --> URI Class Initialized
INFO - 2023-04-10 12:44:29 --> Router Class Initialized
INFO - 2023-04-10 12:44:29 --> Router Class Initialized
INFO - 2023-04-10 12:44:29 --> Output Class Initialized
INFO - 2023-04-10 12:44:29 --> Output Class Initialized
INFO - 2023-04-10 12:44:29 --> Security Class Initialized
INFO - 2023-04-10 12:44:29 --> Security Class Initialized
DEBUG - 2023-04-10 12:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-10 12:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 12:44:29 --> Input Class Initialized
INFO - 2023-04-10 12:44:29 --> Input Class Initialized
INFO - 2023-04-10 12:44:29 --> Language Class Initialized
INFO - 2023-04-10 12:44:29 --> Language Class Initialized
INFO - 2023-04-10 12:44:29 --> Loader Class Initialized
INFO - 2023-04-10 12:44:29 --> Loader Class Initialized
INFO - 2023-04-10 12:44:29 --> Controller Class Initialized
INFO - 2023-04-10 12:44:29 --> Controller Class Initialized
DEBUG - 2023-04-10 12:44:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-10 12:44:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 12:44:29 --> Final output sent to browser
DEBUG - 2023-04-10 12:44:29 --> Total execution time: 0.0046
INFO - 2023-04-10 12:44:29 --> Database Driver Class Initialized
INFO - 2023-04-10 12:44:29 --> Config Class Initialized
INFO - 2023-04-10 12:44:30 --> Hooks Class Initialized
DEBUG - 2023-04-10 12:44:30 --> UTF-8 Support Enabled
INFO - 2023-04-10 12:44:30 --> Utf8 Class Initialized
INFO - 2023-04-10 12:44:30 --> URI Class Initialized
INFO - 2023-04-10 12:44:30 --> Router Class Initialized
INFO - 2023-04-10 12:44:30 --> Output Class Initialized
INFO - 2023-04-10 12:44:30 --> Security Class Initialized
DEBUG - 2023-04-10 12:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-10 12:44:30 --> Input Class Initialized
INFO - 2023-04-10 12:44:30 --> Language Class Initialized
INFO - 2023-04-10 12:44:30 --> Loader Class Initialized
INFO - 2023-04-10 12:44:30 --> Controller Class Initialized
DEBUG - 2023-04-10 12:44:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-10 12:44:30 --> Database Driver Class Initialized
ERROR - 2023-04-10 12:44:39 --> Unable to connect to the database
INFO - 2023-04-10 12:44:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-04-10 12:44:40 --> Unable to connect to the database
INFO - 2023-04-10 12:44:40 --> Model "Login_model" initialized
ERROR - 2023-04-10 12:44:40 --> Unable to connect to the database
ERROR - 2023-04-10 12:44:40 --> Query error: Host is down - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' group by id;
INFO - 2023-04-10 12:44:40 --> Final output sent to browser
DEBUG - 2023-04-10 12:44:40 --> Total execution time: 10.0454
