<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-14 06:35:16 --> Config Class Initialized
INFO - 2023-04-14 06:35:16 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:16 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:16 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:16 --> URI Class Initialized
INFO - 2023-04-14 06:35:16 --> Router Class Initialized
INFO - 2023-04-14 06:35:16 --> Output Class Initialized
INFO - 2023-04-14 06:35:16 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:16 --> Input Class Initialized
INFO - 2023-04-14 06:35:16 --> Language Class Initialized
INFO - 2023-04-14 06:35:16 --> Loader Class Initialized
INFO - 2023-04-14 06:35:16 --> Controller Class Initialized
INFO - 2023-04-14 06:35:16 --> Helper loaded: form_helper
INFO - 2023-04-14 06:35:16 --> Helper loaded: url_helper
DEBUG - 2023-04-14 06:35:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:16 --> Model "Change_model" initialized
INFO - 2023-04-14 06:35:16 --> Model "Grafana_model" initialized
INFO - 2023-04-14 06:35:16 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:16 --> Total execution time: 0.2175
INFO - 2023-04-14 06:35:16 --> Config Class Initialized
INFO - 2023-04-14 06:35:16 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:16 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:16 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:16 --> URI Class Initialized
INFO - 2023-04-14 06:35:16 --> Router Class Initialized
INFO - 2023-04-14 06:35:16 --> Output Class Initialized
INFO - 2023-04-14 06:35:16 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:16 --> Input Class Initialized
INFO - 2023-04-14 06:35:16 --> Language Class Initialized
INFO - 2023-04-14 06:35:16 --> Loader Class Initialized
INFO - 2023-04-14 06:35:16 --> Controller Class Initialized
INFO - 2023-04-14 06:35:16 --> Helper loaded: form_helper
INFO - 2023-04-14 06:35:16 --> Helper loaded: url_helper
DEBUG - 2023-04-14 06:35:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:16 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:16 --> Total execution time: 0.0407
INFO - 2023-04-14 06:35:16 --> Config Class Initialized
INFO - 2023-04-14 06:35:16 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:16 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:16 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:16 --> URI Class Initialized
INFO - 2023-04-14 06:35:16 --> Router Class Initialized
INFO - 2023-04-14 06:35:16 --> Output Class Initialized
INFO - 2023-04-14 06:35:16 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:16 --> Input Class Initialized
INFO - 2023-04-14 06:35:16 --> Language Class Initialized
INFO - 2023-04-14 06:35:16 --> Loader Class Initialized
INFO - 2023-04-14 06:35:16 --> Controller Class Initialized
INFO - 2023-04-14 06:35:16 --> Helper loaded: form_helper
INFO - 2023-04-14 06:35:16 --> Helper loaded: url_helper
DEBUG - 2023-04-14 06:35:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:16 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:16 --> Model "Login_model" initialized
INFO - 2023-04-14 06:35:16 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:16 --> Total execution time: 0.0346
INFO - 2023-04-14 06:35:16 --> Config Class Initialized
INFO - 2023-04-14 06:35:16 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:16 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:16 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:16 --> URI Class Initialized
INFO - 2023-04-14 06:35:16 --> Router Class Initialized
INFO - 2023-04-14 06:35:16 --> Output Class Initialized
INFO - 2023-04-14 06:35:16 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:16 --> Input Class Initialized
INFO - 2023-04-14 06:35:16 --> Language Class Initialized
INFO - 2023-04-14 06:35:16 --> Loader Class Initialized
INFO - 2023-04-14 06:35:16 --> Controller Class Initialized
DEBUG - 2023-04-14 06:35:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:16 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:16 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:35:16 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:16 --> Total execution time: 0.0392
INFO - 2023-04-14 06:35:16 --> Config Class Initialized
INFO - 2023-04-14 06:35:16 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:16 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:16 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:16 --> URI Class Initialized
INFO - 2023-04-14 06:35:16 --> Router Class Initialized
INFO - 2023-04-14 06:35:16 --> Output Class Initialized
INFO - 2023-04-14 06:35:16 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:16 --> Input Class Initialized
INFO - 2023-04-14 06:35:16 --> Language Class Initialized
INFO - 2023-04-14 06:35:16 --> Loader Class Initialized
INFO - 2023-04-14 06:35:16 --> Controller Class Initialized
DEBUG - 2023-04-14 06:35:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:16 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:16 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:35:16 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:16 --> Total execution time: 0.0145
INFO - 2023-04-14 06:35:16 --> Config Class Initialized
INFO - 2023-04-14 06:35:16 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:16 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:16 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:16 --> URI Class Initialized
INFO - 2023-04-14 06:35:16 --> Router Class Initialized
INFO - 2023-04-14 06:35:16 --> Output Class Initialized
INFO - 2023-04-14 06:35:16 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:16 --> Input Class Initialized
INFO - 2023-04-14 06:35:16 --> Language Class Initialized
INFO - 2023-04-14 06:35:16 --> Loader Class Initialized
INFO - 2023-04-14 06:35:16 --> Controller Class Initialized
DEBUG - 2023-04-14 06:35:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:16 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:16 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:35:16 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:16 --> Model "Login_model" initialized
INFO - 2023-04-14 06:35:16 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:16 --> Total execution time: 0.0840
INFO - 2023-04-14 06:35:16 --> Config Class Initialized
INFO - 2023-04-14 06:35:16 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:16 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:16 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:16 --> URI Class Initialized
INFO - 2023-04-14 06:35:16 --> Router Class Initialized
INFO - 2023-04-14 06:35:16 --> Output Class Initialized
INFO - 2023-04-14 06:35:16 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:16 --> Input Class Initialized
INFO - 2023-04-14 06:35:16 --> Language Class Initialized
INFO - 2023-04-14 06:35:16 --> Loader Class Initialized
INFO - 2023-04-14 06:35:16 --> Controller Class Initialized
DEBUG - 2023-04-14 06:35:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:16 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:16 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:35:17 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:17 --> Model "Login_model" initialized
INFO - 2023-04-14 06:35:17 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:17 --> Total execution time: 0.1930
INFO - 2023-04-14 06:35:21 --> Config Class Initialized
INFO - 2023-04-14 06:35:21 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:21 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:21 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:21 --> URI Class Initialized
INFO - 2023-04-14 06:35:21 --> Router Class Initialized
INFO - 2023-04-14 06:35:21 --> Output Class Initialized
INFO - 2023-04-14 06:35:21 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:21 --> Input Class Initialized
INFO - 2023-04-14 06:35:21 --> Language Class Initialized
INFO - 2023-04-14 06:35:21 --> Loader Class Initialized
INFO - 2023-04-14 06:35:21 --> Controller Class Initialized
DEBUG - 2023-04-14 06:35:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:21 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:21 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:35:21 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:21 --> Total execution time: 0.1058
INFO - 2023-04-14 06:35:21 --> Config Class Initialized
INFO - 2023-04-14 06:35:21 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:21 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:21 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:21 --> URI Class Initialized
INFO - 2023-04-14 06:35:21 --> Router Class Initialized
INFO - 2023-04-14 06:35:21 --> Output Class Initialized
INFO - 2023-04-14 06:35:21 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:21 --> Input Class Initialized
INFO - 2023-04-14 06:35:21 --> Language Class Initialized
INFO - 2023-04-14 06:35:21 --> Loader Class Initialized
INFO - 2023-04-14 06:35:21 --> Controller Class Initialized
DEBUG - 2023-04-14 06:35:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:21 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:21 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:35:21 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:21 --> Total execution time: 0.0501
INFO - 2023-04-14 06:35:24 --> Config Class Initialized
INFO - 2023-04-14 06:35:24 --> Config Class Initialized
INFO - 2023-04-14 06:35:24 --> Hooks Class Initialized
INFO - 2023-04-14 06:35:24 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-14 06:35:24 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:24 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:24 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:24 --> URI Class Initialized
INFO - 2023-04-14 06:35:24 --> URI Class Initialized
INFO - 2023-04-14 06:35:24 --> Router Class Initialized
INFO - 2023-04-14 06:35:24 --> Router Class Initialized
INFO - 2023-04-14 06:35:24 --> Output Class Initialized
INFO - 2023-04-14 06:35:24 --> Output Class Initialized
INFO - 2023-04-14 06:35:24 --> Security Class Initialized
INFO - 2023-04-14 06:35:24 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-14 06:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:24 --> Input Class Initialized
INFO - 2023-04-14 06:35:24 --> Input Class Initialized
INFO - 2023-04-14 06:35:24 --> Language Class Initialized
INFO - 2023-04-14 06:35:24 --> Language Class Initialized
INFO - 2023-04-14 06:35:24 --> Loader Class Initialized
INFO - 2023-04-14 06:35:24 --> Controller Class Initialized
DEBUG - 2023-04-14 06:35:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:24 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:24 --> Loader Class Initialized
INFO - 2023-04-14 06:35:24 --> Controller Class Initialized
DEBUG - 2023-04-14 06:35:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:24 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:24 --> Total execution time: 0.0067
INFO - 2023-04-14 06:35:24 --> Config Class Initialized
INFO - 2023-04-14 06:35:24 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:35:25 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:25 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:25 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:25 --> URI Class Initialized
INFO - 2023-04-14 06:35:25 --> Router Class Initialized
INFO - 2023-04-14 06:35:25 --> Output Class Initialized
INFO - 2023-04-14 06:35:25 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:25 --> Input Class Initialized
INFO - 2023-04-14 06:35:25 --> Language Class Initialized
INFO - 2023-04-14 06:35:25 --> Loader Class Initialized
INFO - 2023-04-14 06:35:25 --> Controller Class Initialized
DEBUG - 2023-04-14 06:35:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:25 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:25 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:25 --> Total execution time: 0.0520
INFO - 2023-04-14 06:35:25 --> Config Class Initialized
INFO - 2023-04-14 06:35:25 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:25 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:25 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:25 --> URI Class Initialized
INFO - 2023-04-14 06:35:25 --> Router Class Initialized
INFO - 2023-04-14 06:35:25 --> Output Class Initialized
INFO - 2023-04-14 06:35:25 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:25 --> Input Class Initialized
INFO - 2023-04-14 06:35:25 --> Language Class Initialized
INFO - 2023-04-14 06:35:25 --> Loader Class Initialized
INFO - 2023-04-14 06:35:25 --> Controller Class Initialized
DEBUG - 2023-04-14 06:35:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:25 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:25 --> Model "Login_model" initialized
INFO - 2023-04-14 06:35:25 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:25 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:35:25 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:25 --> Total execution time: 0.0137
INFO - 2023-04-14 06:35:25 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:35:25 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:25 --> Total execution time: 0.0623
INFO - 2023-04-14 06:35:27 --> Config Class Initialized
INFO - 2023-04-14 06:35:27 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:27 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:27 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:27 --> URI Class Initialized
INFO - 2023-04-14 06:35:27 --> Router Class Initialized
INFO - 2023-04-14 06:35:27 --> Output Class Initialized
INFO - 2023-04-14 06:35:27 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:27 --> Input Class Initialized
INFO - 2023-04-14 06:35:27 --> Language Class Initialized
INFO - 2023-04-14 06:35:27 --> Loader Class Initialized
INFO - 2023-04-14 06:35:27 --> Controller Class Initialized
DEBUG - 2023-04-14 06:35:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:27 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:27 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:35:27 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:27 --> Model "Login_model" initialized
INFO - 2023-04-14 06:35:27 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:27 --> Total execution time: 0.1107
INFO - 2023-04-14 06:35:27 --> Config Class Initialized
INFO - 2023-04-14 06:35:27 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:35:27 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:35:27 --> Utf8 Class Initialized
INFO - 2023-04-14 06:35:27 --> URI Class Initialized
INFO - 2023-04-14 06:35:27 --> Router Class Initialized
INFO - 2023-04-14 06:35:27 --> Output Class Initialized
INFO - 2023-04-14 06:35:27 --> Security Class Initialized
DEBUG - 2023-04-14 06:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:35:27 --> Input Class Initialized
INFO - 2023-04-14 06:35:27 --> Language Class Initialized
INFO - 2023-04-14 06:35:27 --> Loader Class Initialized
INFO - 2023-04-14 06:35:27 --> Controller Class Initialized
DEBUG - 2023-04-14 06:35:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:35:27 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:27 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:35:27 --> Database Driver Class Initialized
INFO - 2023-04-14 06:35:27 --> Model "Login_model" initialized
INFO - 2023-04-14 06:35:27 --> Final output sent to browser
DEBUG - 2023-04-14 06:35:27 --> Total execution time: 0.0683
INFO - 2023-04-14 06:36:37 --> Config Class Initialized
INFO - 2023-04-14 06:36:37 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:36:37 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:36:37 --> Utf8 Class Initialized
INFO - 2023-04-14 06:36:37 --> URI Class Initialized
INFO - 2023-04-14 06:36:37 --> Router Class Initialized
INFO - 2023-04-14 06:36:37 --> Output Class Initialized
INFO - 2023-04-14 06:36:37 --> Security Class Initialized
DEBUG - 2023-04-14 06:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:36:37 --> Input Class Initialized
INFO - 2023-04-14 06:36:37 --> Language Class Initialized
INFO - 2023-04-14 06:36:37 --> Loader Class Initialized
INFO - 2023-04-14 06:36:37 --> Controller Class Initialized
DEBUG - 2023-04-14 06:36:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:36:37 --> Database Driver Class Initialized
INFO - 2023-04-14 06:36:37 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:36:37 --> Final output sent to browser
DEBUG - 2023-04-14 06:36:37 --> Total execution time: 0.0447
INFO - 2023-04-14 06:36:37 --> Config Class Initialized
INFO - 2023-04-14 06:36:37 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:36:37 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:36:37 --> Utf8 Class Initialized
INFO - 2023-04-14 06:36:37 --> URI Class Initialized
INFO - 2023-04-14 06:36:37 --> Router Class Initialized
INFO - 2023-04-14 06:36:37 --> Output Class Initialized
INFO - 2023-04-14 06:36:37 --> Security Class Initialized
DEBUG - 2023-04-14 06:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:36:37 --> Input Class Initialized
INFO - 2023-04-14 06:36:37 --> Language Class Initialized
INFO - 2023-04-14 06:36:37 --> Loader Class Initialized
INFO - 2023-04-14 06:36:37 --> Controller Class Initialized
DEBUG - 2023-04-14 06:36:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:36:37 --> Database Driver Class Initialized
INFO - 2023-04-14 06:36:37 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:36:37 --> Final output sent to browser
DEBUG - 2023-04-14 06:36:37 --> Total execution time: 0.0383
INFO - 2023-04-14 06:36:40 --> Config Class Initialized
INFO - 2023-04-14 06:36:40 --> Config Class Initialized
INFO - 2023-04-14 06:36:40 --> Hooks Class Initialized
INFO - 2023-04-14 06:36:40 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:36:40 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:36:40 --> Utf8 Class Initialized
DEBUG - 2023-04-14 06:36:40 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:36:40 --> URI Class Initialized
INFO - 2023-04-14 06:36:40 --> Utf8 Class Initialized
INFO - 2023-04-14 06:36:40 --> URI Class Initialized
INFO - 2023-04-14 06:36:40 --> Router Class Initialized
INFO - 2023-04-14 06:36:40 --> Router Class Initialized
INFO - 2023-04-14 06:36:40 --> Output Class Initialized
INFO - 2023-04-14 06:36:40 --> Output Class Initialized
INFO - 2023-04-14 06:36:40 --> Security Class Initialized
INFO - 2023-04-14 06:36:40 --> Security Class Initialized
DEBUG - 2023-04-14 06:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-14 06:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:36:40 --> Input Class Initialized
INFO - 2023-04-14 06:36:40 --> Input Class Initialized
INFO - 2023-04-14 06:36:40 --> Language Class Initialized
INFO - 2023-04-14 06:36:40 --> Loader Class Initialized
INFO - 2023-04-14 06:36:40 --> Controller Class Initialized
DEBUG - 2023-04-14 06:36:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:36:40 --> Language Class Initialized
INFO - 2023-04-14 06:36:40 --> Database Driver Class Initialized
INFO - 2023-04-14 06:36:40 --> Loader Class Initialized
INFO - 2023-04-14 06:36:40 --> Controller Class Initialized
DEBUG - 2023-04-14 06:36:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:36:40 --> Final output sent to browser
DEBUG - 2023-04-14 06:36:40 --> Total execution time: 0.0219
INFO - 2023-04-14 06:36:40 --> Config Class Initialized
INFO - 2023-04-14 06:36:40 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:36:40 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:36:40 --> Utf8 Class Initialized
INFO - 2023-04-14 06:36:40 --> URI Class Initialized
INFO - 2023-04-14 06:36:40 --> Router Class Initialized
INFO - 2023-04-14 06:36:40 --> Output Class Initialized
INFO - 2023-04-14 06:36:40 --> Security Class Initialized
DEBUG - 2023-04-14 06:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:36:40 --> Input Class Initialized
INFO - 2023-04-14 06:36:40 --> Language Class Initialized
INFO - 2023-04-14 06:36:40 --> Loader Class Initialized
INFO - 2023-04-14 06:36:40 --> Controller Class Initialized
DEBUG - 2023-04-14 06:36:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:36:40 --> Database Driver Class Initialized
INFO - 2023-04-14 06:36:40 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:36:40 --> Final output sent to browser
DEBUG - 2023-04-14 06:36:40 --> Total execution time: 0.0313
INFO - 2023-04-14 06:36:40 --> Config Class Initialized
INFO - 2023-04-14 06:36:40 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:36:40 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:36:40 --> Utf8 Class Initialized
INFO - 2023-04-14 06:36:40 --> URI Class Initialized
INFO - 2023-04-14 06:36:40 --> Router Class Initialized
INFO - 2023-04-14 06:36:40 --> Output Class Initialized
INFO - 2023-04-14 06:36:40 --> Security Class Initialized
DEBUG - 2023-04-14 06:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:36:40 --> Input Class Initialized
INFO - 2023-04-14 06:36:40 --> Language Class Initialized
INFO - 2023-04-14 06:36:40 --> Loader Class Initialized
INFO - 2023-04-14 06:36:40 --> Model "Login_model" initialized
INFO - 2023-04-14 06:36:40 --> Controller Class Initialized
DEBUG - 2023-04-14 06:36:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:36:40 --> Database Driver Class Initialized
INFO - 2023-04-14 06:36:40 --> Database Driver Class Initialized
INFO - 2023-04-14 06:36:40 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:36:40 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:36:40 --> Final output sent to browser
DEBUG - 2023-04-14 06:36:40 --> Total execution time: 0.0142
INFO - 2023-04-14 06:36:40 --> Final output sent to browser
DEBUG - 2023-04-14 06:36:40 --> Total execution time: 0.0237
INFO - 2023-04-14 06:36:44 --> Config Class Initialized
INFO - 2023-04-14 06:36:44 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:36:44 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:36:44 --> Utf8 Class Initialized
INFO - 2023-04-14 06:36:44 --> URI Class Initialized
INFO - 2023-04-14 06:36:44 --> Router Class Initialized
INFO - 2023-04-14 06:36:44 --> Output Class Initialized
INFO - 2023-04-14 06:36:44 --> Security Class Initialized
DEBUG - 2023-04-14 06:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:36:44 --> Input Class Initialized
INFO - 2023-04-14 06:36:44 --> Language Class Initialized
INFO - 2023-04-14 06:36:44 --> Loader Class Initialized
INFO - 2023-04-14 06:36:44 --> Controller Class Initialized
DEBUG - 2023-04-14 06:36:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:36:44 --> Database Driver Class Initialized
INFO - 2023-04-14 06:36:44 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:36:44 --> Final output sent to browser
DEBUG - 2023-04-14 06:36:44 --> Total execution time: 0.0171
INFO - 2023-04-14 06:36:44 --> Config Class Initialized
INFO - 2023-04-14 06:36:44 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:36:44 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:36:44 --> Utf8 Class Initialized
INFO - 2023-04-14 06:36:44 --> URI Class Initialized
INFO - 2023-04-14 06:36:44 --> Router Class Initialized
INFO - 2023-04-14 06:36:44 --> Output Class Initialized
INFO - 2023-04-14 06:36:44 --> Security Class Initialized
DEBUG - 2023-04-14 06:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:36:44 --> Input Class Initialized
INFO - 2023-04-14 06:36:44 --> Language Class Initialized
INFO - 2023-04-14 06:36:44 --> Loader Class Initialized
INFO - 2023-04-14 06:36:44 --> Controller Class Initialized
DEBUG - 2023-04-14 06:36:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:36:44 --> Database Driver Class Initialized
INFO - 2023-04-14 06:36:44 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:36:44 --> Final output sent to browser
DEBUG - 2023-04-14 06:36:44 --> Total execution time: 0.0520
INFO - 2023-04-14 06:41:43 --> Config Class Initialized
INFO - 2023-04-14 06:41:43 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:41:43 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:41:43 --> Utf8 Class Initialized
INFO - 2023-04-14 06:41:43 --> URI Class Initialized
INFO - 2023-04-14 06:41:43 --> Router Class Initialized
INFO - 2023-04-14 06:41:43 --> Output Class Initialized
INFO - 2023-04-14 06:41:43 --> Security Class Initialized
DEBUG - 2023-04-14 06:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:41:43 --> Input Class Initialized
INFO - 2023-04-14 06:41:43 --> Language Class Initialized
INFO - 2023-04-14 06:41:43 --> Loader Class Initialized
INFO - 2023-04-14 06:41:43 --> Controller Class Initialized
DEBUG - 2023-04-14 06:41:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:41:43 --> Database Driver Class Initialized
INFO - 2023-04-14 06:41:43 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:41:43 --> Final output sent to browser
DEBUG - 2023-04-14 06:41:43 --> Total execution time: 0.0486
INFO - 2023-04-14 06:41:43 --> Config Class Initialized
INFO - 2023-04-14 06:41:43 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:41:43 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:41:43 --> Utf8 Class Initialized
INFO - 2023-04-14 06:41:43 --> URI Class Initialized
INFO - 2023-04-14 06:41:43 --> Router Class Initialized
INFO - 2023-04-14 06:41:43 --> Output Class Initialized
INFO - 2023-04-14 06:41:43 --> Security Class Initialized
DEBUG - 2023-04-14 06:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:41:43 --> Input Class Initialized
INFO - 2023-04-14 06:41:43 --> Language Class Initialized
INFO - 2023-04-14 06:41:43 --> Loader Class Initialized
INFO - 2023-04-14 06:41:43 --> Controller Class Initialized
DEBUG - 2023-04-14 06:41:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-14 06:41:43 --> Database Driver Class Initialized
INFO - 2023-04-14 06:41:44 --> Model "Cluster_model" initialized
INFO - 2023-04-14 06:41:44 --> Final output sent to browser
DEBUG - 2023-04-14 06:41:44 --> Total execution time: 0.0848
