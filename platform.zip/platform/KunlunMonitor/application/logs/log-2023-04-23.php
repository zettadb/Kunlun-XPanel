<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-23 06:01:05 --> Config Class Initialized
INFO - 2023-04-23 06:01:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:05 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:05 --> URI Class Initialized
INFO - 2023-04-23 06:01:05 --> Router Class Initialized
INFO - 2023-04-23 06:01:05 --> Output Class Initialized
INFO - 2023-04-23 06:01:05 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:05 --> Input Class Initialized
INFO - 2023-04-23 06:01:05 --> Language Class Initialized
INFO - 2023-04-23 06:01:05 --> Loader Class Initialized
INFO - 2023-04-23 06:01:05 --> Controller Class Initialized
INFO - 2023-04-23 06:01:05 --> Helper loaded: form_helper
INFO - 2023-04-23 06:01:05 --> Helper loaded: url_helper
DEBUG - 2023-04-23 06:01:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:05 --> Model "Change_model" initialized
INFO - 2023-04-23 06:01:05 --> Model "Grafana_model" initialized
INFO - 2023-04-23 06:01:05 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:05 --> Total execution time: 0.0805
INFO - 2023-04-23 06:01:05 --> Config Class Initialized
INFO - 2023-04-23 06:01:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:05 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:05 --> URI Class Initialized
INFO - 2023-04-23 06:01:05 --> Router Class Initialized
INFO - 2023-04-23 06:01:05 --> Output Class Initialized
INFO - 2023-04-23 06:01:05 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:05 --> Input Class Initialized
INFO - 2023-04-23 06:01:05 --> Language Class Initialized
INFO - 2023-04-23 06:01:05 --> Loader Class Initialized
INFO - 2023-04-23 06:01:05 --> Controller Class Initialized
INFO - 2023-04-23 06:01:05 --> Helper loaded: form_helper
INFO - 2023-04-23 06:01:05 --> Helper loaded: url_helper
DEBUG - 2023-04-23 06:01:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:05 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:05 --> Total execution time: 0.0031
INFO - 2023-04-23 06:01:05 --> Config Class Initialized
INFO - 2023-04-23 06:01:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:05 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:05 --> URI Class Initialized
INFO - 2023-04-23 06:01:05 --> Router Class Initialized
INFO - 2023-04-23 06:01:05 --> Output Class Initialized
INFO - 2023-04-23 06:01:05 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:05 --> Input Class Initialized
INFO - 2023-04-23 06:01:05 --> Language Class Initialized
INFO - 2023-04-23 06:01:05 --> Loader Class Initialized
INFO - 2023-04-23 06:01:05 --> Controller Class Initialized
INFO - 2023-04-23 06:01:05 --> Helper loaded: form_helper
INFO - 2023-04-23 06:01:05 --> Helper loaded: url_helper
DEBUG - 2023-04-23 06:01:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:05 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:05 --> Model "Login_model" initialized
INFO - 2023-04-23 06:01:05 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:05 --> Total execution time: 0.0803
INFO - 2023-04-23 06:01:05 --> Config Class Initialized
INFO - 2023-04-23 06:01:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:05 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:05 --> URI Class Initialized
INFO - 2023-04-23 06:01:05 --> Router Class Initialized
INFO - 2023-04-23 06:01:05 --> Output Class Initialized
INFO - 2023-04-23 06:01:05 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:05 --> Input Class Initialized
INFO - 2023-04-23 06:01:05 --> Language Class Initialized
INFO - 2023-04-23 06:01:05 --> Loader Class Initialized
INFO - 2023-04-23 06:01:05 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:05 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:05 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:05 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:05 --> Total execution time: 0.0352
INFO - 2023-04-23 06:01:05 --> Config Class Initialized
INFO - 2023-04-23 06:01:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:05 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:05 --> URI Class Initialized
INFO - 2023-04-23 06:01:05 --> Router Class Initialized
INFO - 2023-04-23 06:01:05 --> Output Class Initialized
INFO - 2023-04-23 06:01:05 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:05 --> Input Class Initialized
INFO - 2023-04-23 06:01:05 --> Language Class Initialized
INFO - 2023-04-23 06:01:05 --> Loader Class Initialized
INFO - 2023-04-23 06:01:05 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:05 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:05 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:05 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:05 --> Total execution time: 0.0169
INFO - 2023-04-23 06:01:05 --> Config Class Initialized
INFO - 2023-04-23 06:01:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:05 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:05 --> URI Class Initialized
INFO - 2023-04-23 06:01:05 --> Router Class Initialized
INFO - 2023-04-23 06:01:05 --> Output Class Initialized
INFO - 2023-04-23 06:01:05 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:05 --> Input Class Initialized
INFO - 2023-04-23 06:01:05 --> Language Class Initialized
INFO - 2023-04-23 06:01:05 --> Loader Class Initialized
INFO - 2023-04-23 06:01:05 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:05 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:05 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:05 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:05 --> Model "Login_model" initialized
INFO - 2023-04-23 06:01:05 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:05 --> Total execution time: 0.0657
INFO - 2023-04-23 06:01:05 --> Config Class Initialized
INFO - 2023-04-23 06:01:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:05 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:05 --> URI Class Initialized
INFO - 2023-04-23 06:01:05 --> Router Class Initialized
INFO - 2023-04-23 06:01:05 --> Output Class Initialized
INFO - 2023-04-23 06:01:05 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:05 --> Input Class Initialized
INFO - 2023-04-23 06:01:05 --> Language Class Initialized
INFO - 2023-04-23 06:01:05 --> Loader Class Initialized
INFO - 2023-04-23 06:01:05 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:05 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:05 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:05 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:05 --> Model "Login_model" initialized
INFO - 2023-04-23 06:01:05 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:05 --> Total execution time: 0.0595
INFO - 2023-04-23 06:01:08 --> Config Class Initialized
INFO - 2023-04-23 06:01:08 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:08 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:08 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:08 --> URI Class Initialized
INFO - 2023-04-23 06:01:08 --> Router Class Initialized
INFO - 2023-04-23 06:01:08 --> Output Class Initialized
INFO - 2023-04-23 06:01:08 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:08 --> Input Class Initialized
INFO - 2023-04-23 06:01:08 --> Language Class Initialized
INFO - 2023-04-23 06:01:08 --> Loader Class Initialized
INFO - 2023-04-23 06:01:08 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:08 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:08 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:08 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:08 --> Total execution time: 0.0427
INFO - 2023-04-23 06:01:08 --> Config Class Initialized
INFO - 2023-04-23 06:01:08 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:08 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:08 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:08 --> URI Class Initialized
INFO - 2023-04-23 06:01:08 --> Router Class Initialized
INFO - 2023-04-23 06:01:08 --> Output Class Initialized
INFO - 2023-04-23 06:01:08 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:08 --> Input Class Initialized
INFO - 2023-04-23 06:01:08 --> Language Class Initialized
INFO - 2023-04-23 06:01:08 --> Loader Class Initialized
INFO - 2023-04-23 06:01:08 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:08 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:08 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:08 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:08 --> Total execution time: 0.0385
INFO - 2023-04-23 06:01:10 --> Config Class Initialized
INFO - 2023-04-23 06:01:10 --> Config Class Initialized
INFO - 2023-04-23 06:01:10 --> Hooks Class Initialized
INFO - 2023-04-23 06:01:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 06:01:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:10 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:10 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:10 --> URI Class Initialized
INFO - 2023-04-23 06:01:10 --> URI Class Initialized
INFO - 2023-04-23 06:01:10 --> Router Class Initialized
INFO - 2023-04-23 06:01:10 --> Router Class Initialized
INFO - 2023-04-23 06:01:10 --> Output Class Initialized
INFO - 2023-04-23 06:01:10 --> Output Class Initialized
INFO - 2023-04-23 06:01:10 --> Security Class Initialized
INFO - 2023-04-23 06:01:10 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 06:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:10 --> Input Class Initialized
INFO - 2023-04-23 06:01:10 --> Input Class Initialized
INFO - 2023-04-23 06:01:10 --> Language Class Initialized
INFO - 2023-04-23 06:01:10 --> Language Class Initialized
INFO - 2023-04-23 06:01:10 --> Loader Class Initialized
INFO - 2023-04-23 06:01:10 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:10 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:10 --> Loader Class Initialized
INFO - 2023-04-23 06:01:10 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:10 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:10 --> Total execution time: 0.0105
INFO - 2023-04-23 06:01:10 --> Config Class Initialized
INFO - 2023-04-23 06:01:10 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:10 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:10 --> URI Class Initialized
INFO - 2023-04-23 06:01:10 --> Router Class Initialized
INFO - 2023-04-23 06:01:10 --> Output Class Initialized
INFO - 2023-04-23 06:01:10 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:10 --> Input Class Initialized
INFO - 2023-04-23 06:01:10 --> Language Class Initialized
INFO - 2023-04-23 06:01:10 --> Loader Class Initialized
INFO - 2023-04-23 06:01:10 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:10 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:10 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:10 --> Total execution time: 0.0561
INFO - 2023-04-23 06:01:10 --> Config Class Initialized
INFO - 2023-04-23 06:01:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:10 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:10 --> URI Class Initialized
INFO - 2023-04-23 06:01:10 --> Router Class Initialized
INFO - 2023-04-23 06:01:10 --> Output Class Initialized
INFO - 2023-04-23 06:01:10 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:10 --> Input Class Initialized
INFO - 2023-04-23 06:01:10 --> Language Class Initialized
INFO - 2023-04-23 06:01:10 --> Loader Class Initialized
INFO - 2023-04-23 06:01:10 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:10 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:10 --> Model "Login_model" initialized
INFO - 2023-04-23 06:01:10 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:10 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:10 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:10 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:10 --> Total execution time: 0.0135
INFO - 2023-04-23 06:01:10 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:10 --> Total execution time: 0.0620
INFO - 2023-04-23 06:01:13 --> Config Class Initialized
INFO - 2023-04-23 06:01:13 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:13 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:13 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:13 --> URI Class Initialized
INFO - 2023-04-23 06:01:13 --> Router Class Initialized
INFO - 2023-04-23 06:01:13 --> Output Class Initialized
INFO - 2023-04-23 06:01:13 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:13 --> Input Class Initialized
INFO - 2023-04-23 06:01:13 --> Language Class Initialized
INFO - 2023-04-23 06:01:13 --> Loader Class Initialized
INFO - 2023-04-23 06:01:13 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:13 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:13 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:13 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:13 --> Model "Login_model" initialized
INFO - 2023-04-23 06:01:13 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:13 --> Total execution time: 0.0637
INFO - 2023-04-23 06:01:13 --> Config Class Initialized
INFO - 2023-04-23 06:01:13 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:13 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:13 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:13 --> URI Class Initialized
INFO - 2023-04-23 06:01:13 --> Router Class Initialized
INFO - 2023-04-23 06:01:13 --> Output Class Initialized
INFO - 2023-04-23 06:01:13 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:13 --> Input Class Initialized
INFO - 2023-04-23 06:01:13 --> Language Class Initialized
INFO - 2023-04-23 06:01:13 --> Loader Class Initialized
INFO - 2023-04-23 06:01:13 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:13 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:13 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:14 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:14 --> Model "Login_model" initialized
INFO - 2023-04-23 06:01:14 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:14 --> Total execution time: 0.0603
INFO - 2023-04-23 06:01:15 --> Config Class Initialized
INFO - 2023-04-23 06:01:15 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:15 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:15 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:15 --> URI Class Initialized
INFO - 2023-04-23 06:01:15 --> Router Class Initialized
INFO - 2023-04-23 06:01:15 --> Output Class Initialized
INFO - 2023-04-23 06:01:15 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:15 --> Input Class Initialized
INFO - 2023-04-23 06:01:15 --> Language Class Initialized
INFO - 2023-04-23 06:01:15 --> Loader Class Initialized
INFO - 2023-04-23 06:01:15 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:15 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:15 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:15 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:15 --> Total execution time: 0.0139
INFO - 2023-04-23 06:01:15 --> Config Class Initialized
INFO - 2023-04-23 06:01:15 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:15 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:15 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:15 --> URI Class Initialized
INFO - 2023-04-23 06:01:15 --> Router Class Initialized
INFO - 2023-04-23 06:01:15 --> Output Class Initialized
INFO - 2023-04-23 06:01:15 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:15 --> Input Class Initialized
INFO - 2023-04-23 06:01:15 --> Language Class Initialized
INFO - 2023-04-23 06:01:15 --> Loader Class Initialized
INFO - 2023-04-23 06:01:15 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:15 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:15 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:15 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:15 --> Total execution time: 0.0967
INFO - 2023-04-23 06:01:15 --> Config Class Initialized
INFO - 2023-04-23 06:01:15 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:15 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:15 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:15 --> URI Class Initialized
INFO - 2023-04-23 06:01:15 --> Router Class Initialized
INFO - 2023-04-23 06:01:15 --> Output Class Initialized
INFO - 2023-04-23 06:01:15 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:15 --> Input Class Initialized
INFO - 2023-04-23 06:01:15 --> Language Class Initialized
INFO - 2023-04-23 06:01:15 --> Loader Class Initialized
INFO - 2023-04-23 06:01:15 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:15 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:15 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:15 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:15 --> Total execution time: 0.0480
INFO - 2023-04-23 06:01:15 --> Config Class Initialized
INFO - 2023-04-23 06:01:15 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:01:15 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:01:15 --> Utf8 Class Initialized
INFO - 2023-04-23 06:01:15 --> URI Class Initialized
INFO - 2023-04-23 06:01:15 --> Router Class Initialized
INFO - 2023-04-23 06:01:15 --> Output Class Initialized
INFO - 2023-04-23 06:01:15 --> Security Class Initialized
DEBUG - 2023-04-23 06:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:01:15 --> Input Class Initialized
INFO - 2023-04-23 06:01:15 --> Language Class Initialized
INFO - 2023-04-23 06:01:15 --> Loader Class Initialized
INFO - 2023-04-23 06:01:15 --> Controller Class Initialized
DEBUG - 2023-04-23 06:01:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:01:15 --> Database Driver Class Initialized
INFO - 2023-04-23 06:01:15 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:01:15 --> Final output sent to browser
DEBUG - 2023-04-23 06:01:15 --> Total execution time: 0.0117
INFO - 2023-04-23 06:02:03 --> Config Class Initialized
INFO - 2023-04-23 06:02:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:02:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:02:03 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:03 --> URI Class Initialized
INFO - 2023-04-23 06:02:03 --> Router Class Initialized
INFO - 2023-04-23 06:02:03 --> Output Class Initialized
INFO - 2023-04-23 06:02:03 --> Security Class Initialized
DEBUG - 2023-04-23 06:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:02:03 --> Input Class Initialized
INFO - 2023-04-23 06:02:03 --> Language Class Initialized
INFO - 2023-04-23 06:02:03 --> Loader Class Initialized
INFO - 2023-04-23 06:02:03 --> Controller Class Initialized
DEBUG - 2023-04-23 06:02:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:02:03 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:03 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:03 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:03 --> Model "Login_model" initialized
INFO - 2023-04-23 06:02:03 --> Final output sent to browser
DEBUG - 2023-04-23 06:02:03 --> Total execution time: 0.0647
INFO - 2023-04-23 06:02:03 --> Config Class Initialized
INFO - 2023-04-23 06:02:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:02:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:02:03 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:03 --> URI Class Initialized
INFO - 2023-04-23 06:02:03 --> Router Class Initialized
INFO - 2023-04-23 06:02:03 --> Output Class Initialized
INFO - 2023-04-23 06:02:03 --> Security Class Initialized
DEBUG - 2023-04-23 06:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:02:03 --> Input Class Initialized
INFO - 2023-04-23 06:02:03 --> Language Class Initialized
INFO - 2023-04-23 06:02:03 --> Loader Class Initialized
INFO - 2023-04-23 06:02:03 --> Controller Class Initialized
DEBUG - 2023-04-23 06:02:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:02:03 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:03 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:04 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:04 --> Model "Login_model" initialized
INFO - 2023-04-23 06:02:04 --> Final output sent to browser
DEBUG - 2023-04-23 06:02:04 --> Total execution time: 0.2192
INFO - 2023-04-23 06:02:09 --> Config Class Initialized
INFO - 2023-04-23 06:02:09 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:02:09 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:02:09 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:09 --> URI Class Initialized
INFO - 2023-04-23 06:02:09 --> Router Class Initialized
INFO - 2023-04-23 06:02:09 --> Output Class Initialized
INFO - 2023-04-23 06:02:09 --> Security Class Initialized
DEBUG - 2023-04-23 06:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:02:09 --> Input Class Initialized
INFO - 2023-04-23 06:02:09 --> Language Class Initialized
INFO - 2023-04-23 06:02:09 --> Loader Class Initialized
INFO - 2023-04-23 06:02:09 --> Controller Class Initialized
DEBUG - 2023-04-23 06:02:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:02:09 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:09 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:09 --> Final output sent to browser
DEBUG - 2023-04-23 06:02:09 --> Total execution time: 0.0858
INFO - 2023-04-23 06:02:09 --> Config Class Initialized
INFO - 2023-04-23 06:02:09 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:02:09 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:02:09 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:09 --> URI Class Initialized
INFO - 2023-04-23 06:02:09 --> Router Class Initialized
INFO - 2023-04-23 06:02:09 --> Output Class Initialized
INFO - 2023-04-23 06:02:09 --> Security Class Initialized
DEBUG - 2023-04-23 06:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:02:09 --> Input Class Initialized
INFO - 2023-04-23 06:02:09 --> Language Class Initialized
INFO - 2023-04-23 06:02:09 --> Loader Class Initialized
INFO - 2023-04-23 06:02:09 --> Controller Class Initialized
DEBUG - 2023-04-23 06:02:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:02:09 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:09 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:09 --> Final output sent to browser
DEBUG - 2023-04-23 06:02:09 --> Total execution time: 0.0811
INFO - 2023-04-23 06:02:15 --> Config Class Initialized
INFO - 2023-04-23 06:02:15 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:02:15 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:02:15 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:15 --> URI Class Initialized
INFO - 2023-04-23 06:02:15 --> Router Class Initialized
INFO - 2023-04-23 06:02:15 --> Output Class Initialized
INFO - 2023-04-23 06:02:15 --> Security Class Initialized
DEBUG - 2023-04-23 06:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:02:15 --> Input Class Initialized
INFO - 2023-04-23 06:02:15 --> Language Class Initialized
INFO - 2023-04-23 06:02:15 --> Loader Class Initialized
INFO - 2023-04-23 06:02:15 --> Controller Class Initialized
DEBUG - 2023-04-23 06:02:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:02:15 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:15 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:15 --> Final output sent to browser
DEBUG - 2023-04-23 06:02:15 --> Total execution time: 0.0136
INFO - 2023-04-23 06:02:15 --> Config Class Initialized
INFO - 2023-04-23 06:02:15 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:02:15 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:02:15 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:15 --> URI Class Initialized
INFO - 2023-04-23 06:02:15 --> Router Class Initialized
INFO - 2023-04-23 06:02:15 --> Output Class Initialized
INFO - 2023-04-23 06:02:15 --> Security Class Initialized
DEBUG - 2023-04-23 06:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:02:15 --> Input Class Initialized
INFO - 2023-04-23 06:02:15 --> Language Class Initialized
INFO - 2023-04-23 06:02:15 --> Loader Class Initialized
INFO - 2023-04-23 06:02:15 --> Controller Class Initialized
DEBUG - 2023-04-23 06:02:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:02:15 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:15 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:15 --> Final output sent to browser
DEBUG - 2023-04-23 06:02:15 --> Total execution time: 0.0099
INFO - 2023-04-23 06:02:17 --> Config Class Initialized
INFO - 2023-04-23 06:02:17 --> Config Class Initialized
INFO - 2023-04-23 06:02:17 --> Hooks Class Initialized
INFO - 2023-04-23 06:02:17 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:02:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 06:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:02:17 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:17 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:17 --> URI Class Initialized
INFO - 2023-04-23 06:02:17 --> URI Class Initialized
INFO - 2023-04-23 06:02:17 --> Router Class Initialized
INFO - 2023-04-23 06:02:17 --> Router Class Initialized
INFO - 2023-04-23 06:02:17 --> Output Class Initialized
INFO - 2023-04-23 06:02:17 --> Output Class Initialized
INFO - 2023-04-23 06:02:17 --> Security Class Initialized
INFO - 2023-04-23 06:02:17 --> Security Class Initialized
DEBUG - 2023-04-23 06:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 06:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:02:17 --> Input Class Initialized
INFO - 2023-04-23 06:02:17 --> Input Class Initialized
INFO - 2023-04-23 06:02:17 --> Language Class Initialized
INFO - 2023-04-23 06:02:17 --> Language Class Initialized
INFO - 2023-04-23 06:02:17 --> Loader Class Initialized
INFO - 2023-04-23 06:02:17 --> Loader Class Initialized
INFO - 2023-04-23 06:02:17 --> Controller Class Initialized
INFO - 2023-04-23 06:02:17 --> Controller Class Initialized
DEBUG - 2023-04-23 06:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 06:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:02:17 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:17 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:17 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:17 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:17 --> Final output sent to browser
INFO - 2023-04-23 06:02:17 --> Final output sent to browser
DEBUG - 2023-04-23 06:02:17 --> Total execution time: 0.0153
DEBUG - 2023-04-23 06:02:17 --> Total execution time: 0.0154
INFO - 2023-04-23 06:02:17 --> Config Class Initialized
INFO - 2023-04-23 06:02:17 --> Config Class Initialized
INFO - 2023-04-23 06:02:17 --> Hooks Class Initialized
INFO - 2023-04-23 06:02:17 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:02:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 06:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:02:17 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:17 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:17 --> URI Class Initialized
INFO - 2023-04-23 06:02:17 --> URI Class Initialized
INFO - 2023-04-23 06:02:17 --> Router Class Initialized
INFO - 2023-04-23 06:02:17 --> Router Class Initialized
INFO - 2023-04-23 06:02:17 --> Output Class Initialized
INFO - 2023-04-23 06:02:17 --> Output Class Initialized
INFO - 2023-04-23 06:02:17 --> Security Class Initialized
INFO - 2023-04-23 06:02:17 --> Security Class Initialized
DEBUG - 2023-04-23 06:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 06:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:02:17 --> Input Class Initialized
INFO - 2023-04-23 06:02:17 --> Input Class Initialized
INFO - 2023-04-23 06:02:17 --> Language Class Initialized
INFO - 2023-04-23 06:02:17 --> Language Class Initialized
INFO - 2023-04-23 06:02:17 --> Loader Class Initialized
INFO - 2023-04-23 06:02:17 --> Loader Class Initialized
INFO - 2023-04-23 06:02:17 --> Controller Class Initialized
INFO - 2023-04-23 06:02:17 --> Controller Class Initialized
DEBUG - 2023-04-23 06:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 06:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:02:17 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:17 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:17 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:17 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:17 --> Final output sent to browser
INFO - 2023-04-23 06:02:17 --> Final output sent to browser
DEBUG - 2023-04-23 06:02:17 --> Total execution time: 0.0138
DEBUG - 2023-04-23 06:02:17 --> Total execution time: 0.0138
INFO - 2023-04-23 06:02:20 --> Config Class Initialized
INFO - 2023-04-23 06:02:20 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:02:20 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:02:20 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:20 --> URI Class Initialized
INFO - 2023-04-23 06:02:20 --> Router Class Initialized
INFO - 2023-04-23 06:02:20 --> Output Class Initialized
INFO - 2023-04-23 06:02:20 --> Security Class Initialized
DEBUG - 2023-04-23 06:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:02:20 --> Input Class Initialized
INFO - 2023-04-23 06:02:20 --> Language Class Initialized
INFO - 2023-04-23 06:02:20 --> Loader Class Initialized
INFO - 2023-04-23 06:02:20 --> Controller Class Initialized
DEBUG - 2023-04-23 06:02:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:02:20 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:20 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:20 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:20 --> Model "Login_model" initialized
INFO - 2023-04-23 06:02:20 --> Final output sent to browser
DEBUG - 2023-04-23 06:02:20 --> Total execution time: 0.1368
INFO - 2023-04-23 06:02:20 --> Config Class Initialized
INFO - 2023-04-23 06:02:20 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:02:20 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:02:20 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:20 --> URI Class Initialized
INFO - 2023-04-23 06:02:20 --> Router Class Initialized
INFO - 2023-04-23 06:02:20 --> Output Class Initialized
INFO - 2023-04-23 06:02:20 --> Security Class Initialized
DEBUG - 2023-04-23 06:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:02:20 --> Input Class Initialized
INFO - 2023-04-23 06:02:20 --> Language Class Initialized
INFO - 2023-04-23 06:02:20 --> Loader Class Initialized
INFO - 2023-04-23 06:02:20 --> Controller Class Initialized
DEBUG - 2023-04-23 06:02:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:02:20 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:20 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:21 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:21 --> Model "Login_model" initialized
INFO - 2023-04-23 06:02:21 --> Final output sent to browser
DEBUG - 2023-04-23 06:02:21 --> Total execution time: 0.0595
INFO - 2023-04-23 06:02:23 --> Config Class Initialized
INFO - 2023-04-23 06:02:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:02:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:02:23 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:23 --> URI Class Initialized
INFO - 2023-04-23 06:02:23 --> Router Class Initialized
INFO - 2023-04-23 06:02:23 --> Output Class Initialized
INFO - 2023-04-23 06:02:23 --> Security Class Initialized
DEBUG - 2023-04-23 06:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:02:23 --> Input Class Initialized
INFO - 2023-04-23 06:02:23 --> Language Class Initialized
INFO - 2023-04-23 06:02:23 --> Loader Class Initialized
INFO - 2023-04-23 06:02:23 --> Controller Class Initialized
DEBUG - 2023-04-23 06:02:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:02:23 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:23 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:23 --> Final output sent to browser
DEBUG - 2023-04-23 06:02:23 --> Total execution time: 0.0444
INFO - 2023-04-23 06:02:23 --> Config Class Initialized
INFO - 2023-04-23 06:02:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:02:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:02:23 --> Utf8 Class Initialized
INFO - 2023-04-23 06:02:23 --> URI Class Initialized
INFO - 2023-04-23 06:02:23 --> Router Class Initialized
INFO - 2023-04-23 06:02:23 --> Output Class Initialized
INFO - 2023-04-23 06:02:23 --> Security Class Initialized
DEBUG - 2023-04-23 06:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:02:23 --> Input Class Initialized
INFO - 2023-04-23 06:02:23 --> Language Class Initialized
INFO - 2023-04-23 06:02:23 --> Loader Class Initialized
INFO - 2023-04-23 06:02:23 --> Controller Class Initialized
DEBUG - 2023-04-23 06:02:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:02:23 --> Database Driver Class Initialized
INFO - 2023-04-23 06:02:23 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:02:23 --> Final output sent to browser
DEBUG - 2023-04-23 06:02:23 --> Total execution time: 0.0814
INFO - 2023-04-23 06:06:48 --> Config Class Initialized
INFO - 2023-04-23 06:06:48 --> Config Class Initialized
INFO - 2023-04-23 06:06:48 --> Hooks Class Initialized
INFO - 2023-04-23 06:06:48 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:06:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 06:06:48 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:06:48 --> Utf8 Class Initialized
INFO - 2023-04-23 06:06:48 --> Utf8 Class Initialized
INFO - 2023-04-23 06:06:48 --> URI Class Initialized
INFO - 2023-04-23 06:06:48 --> URI Class Initialized
INFO - 2023-04-23 06:06:48 --> Router Class Initialized
INFO - 2023-04-23 06:06:48 --> Router Class Initialized
INFO - 2023-04-23 06:06:48 --> Output Class Initialized
INFO - 2023-04-23 06:06:48 --> Output Class Initialized
INFO - 2023-04-23 06:06:48 --> Security Class Initialized
INFO - 2023-04-23 06:06:48 --> Security Class Initialized
DEBUG - 2023-04-23 06:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 06:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:06:48 --> Input Class Initialized
INFO - 2023-04-23 06:06:48 --> Input Class Initialized
INFO - 2023-04-23 06:06:48 --> Language Class Initialized
INFO - 2023-04-23 06:06:48 --> Language Class Initialized
INFO - 2023-04-23 06:06:48 --> Loader Class Initialized
INFO - 2023-04-23 06:06:48 --> Loader Class Initialized
INFO - 2023-04-23 06:06:48 --> Controller Class Initialized
INFO - 2023-04-23 06:06:48 --> Controller Class Initialized
DEBUG - 2023-04-23 06:06:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 06:06:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:06:48 --> Final output sent to browser
DEBUG - 2023-04-23 06:06:48 --> Total execution time: 0.0063
INFO - 2023-04-23 06:06:48 --> Database Driver Class Initialized
INFO - 2023-04-23 06:06:48 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:06:48 --> Final output sent to browser
INFO - 2023-04-23 06:06:48 --> Config Class Initialized
DEBUG - 2023-04-23 06:06:48 --> Total execution time: 0.0485
INFO - 2023-04-23 06:06:48 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:06:48 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:06:48 --> Utf8 Class Initialized
INFO - 2023-04-23 06:06:48 --> URI Class Initialized
INFO - 2023-04-23 06:06:48 --> Router Class Initialized
INFO - 2023-04-23 06:06:48 --> Output Class Initialized
INFO - 2023-04-23 06:06:48 --> Security Class Initialized
DEBUG - 2023-04-23 06:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:06:48 --> Input Class Initialized
INFO - 2023-04-23 06:06:48 --> Language Class Initialized
INFO - 2023-04-23 06:06:48 --> Config Class Initialized
INFO - 2023-04-23 06:06:48 --> Loader Class Initialized
INFO - 2023-04-23 06:06:48 --> Hooks Class Initialized
INFO - 2023-04-23 06:06:48 --> Controller Class Initialized
DEBUG - 2023-04-23 06:06:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 06:06:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:06:48 --> Utf8 Class Initialized
INFO - 2023-04-23 06:06:48 --> URI Class Initialized
INFO - 2023-04-23 06:06:48 --> Router Class Initialized
INFO - 2023-04-23 06:06:48 --> Output Class Initialized
INFO - 2023-04-23 06:06:48 --> Security Class Initialized
INFO - 2023-04-23 06:06:48 --> Database Driver Class Initialized
DEBUG - 2023-04-23 06:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:06:48 --> Input Class Initialized
INFO - 2023-04-23 06:06:48 --> Language Class Initialized
INFO - 2023-04-23 06:06:48 --> Loader Class Initialized
INFO - 2023-04-23 06:06:48 --> Controller Class Initialized
DEBUG - 2023-04-23 06:06:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:06:48 --> Database Driver Class Initialized
INFO - 2023-04-23 06:06:48 --> Model "Login_model" initialized
INFO - 2023-04-23 06:06:48 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:06:48 --> Database Driver Class Initialized
INFO - 2023-04-23 06:06:48 --> Final output sent to browser
DEBUG - 2023-04-23 06:06:48 --> Total execution time: 0.0153
INFO - 2023-04-23 06:06:48 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:06:48 --> Final output sent to browser
DEBUG - 2023-04-23 06:06:48 --> Total execution time: 0.0641
INFO - 2023-04-23 06:10:14 --> Config Class Initialized
INFO - 2023-04-23 06:10:14 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:14 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:14 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:14 --> URI Class Initialized
INFO - 2023-04-23 06:10:14 --> Router Class Initialized
INFO - 2023-04-23 06:10:14 --> Output Class Initialized
INFO - 2023-04-23 06:10:14 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:14 --> Input Class Initialized
INFO - 2023-04-23 06:10:14 --> Language Class Initialized
INFO - 2023-04-23 06:10:14 --> Loader Class Initialized
INFO - 2023-04-23 06:10:14 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:14 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:14 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:14 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:14 --> Total execution time: 0.0478
INFO - 2023-04-23 06:10:14 --> Config Class Initialized
INFO - 2023-04-23 06:10:14 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:14 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:14 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:14 --> URI Class Initialized
INFO - 2023-04-23 06:10:14 --> Router Class Initialized
INFO - 2023-04-23 06:10:14 --> Output Class Initialized
INFO - 2023-04-23 06:10:14 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:14 --> Input Class Initialized
INFO - 2023-04-23 06:10:14 --> Language Class Initialized
INFO - 2023-04-23 06:10:14 --> Loader Class Initialized
INFO - 2023-04-23 06:10:14 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:14 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:14 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:14 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:14 --> Total execution time: 0.0811
INFO - 2023-04-23 06:10:16 --> Config Class Initialized
INFO - 2023-04-23 06:10:16 --> Config Class Initialized
INFO - 2023-04-23 06:10:16 --> Hooks Class Initialized
INFO - 2023-04-23 06:10:16 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 06:10:16 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:16 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:16 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:16 --> URI Class Initialized
INFO - 2023-04-23 06:10:16 --> URI Class Initialized
INFO - 2023-04-23 06:10:16 --> Router Class Initialized
INFO - 2023-04-23 06:10:16 --> Router Class Initialized
INFO - 2023-04-23 06:10:16 --> Output Class Initialized
INFO - 2023-04-23 06:10:16 --> Output Class Initialized
INFO - 2023-04-23 06:10:16 --> Security Class Initialized
INFO - 2023-04-23 06:10:16 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 06:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:16 --> Input Class Initialized
INFO - 2023-04-23 06:10:16 --> Input Class Initialized
INFO - 2023-04-23 06:10:16 --> Language Class Initialized
INFO - 2023-04-23 06:10:16 --> Language Class Initialized
INFO - 2023-04-23 06:10:16 --> Loader Class Initialized
INFO - 2023-04-23 06:10:16 --> Loader Class Initialized
INFO - 2023-04-23 06:10:16 --> Controller Class Initialized
INFO - 2023-04-23 06:10:16 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 06:10:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:16 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:16 --> Total execution time: 0.0051
INFO - 2023-04-23 06:10:16 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:16 --> Config Class Initialized
INFO - 2023-04-23 06:10:16 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:16 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:16 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:16 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:16 --> URI Class Initialized
INFO - 2023-04-23 06:10:16 --> Router Class Initialized
INFO - 2023-04-23 06:10:16 --> Output Class Initialized
INFO - 2023-04-23 06:10:16 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:16 --> Input Class Initialized
INFO - 2023-04-23 06:10:16 --> Language Class Initialized
INFO - 2023-04-23 06:10:16 --> Loader Class Initialized
INFO - 2023-04-23 06:10:16 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:16 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:16 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:16 --> Total execution time: 0.0517
INFO - 2023-04-23 06:10:16 --> Config Class Initialized
INFO - 2023-04-23 06:10:16 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:16 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:16 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:16 --> URI Class Initialized
INFO - 2023-04-23 06:10:16 --> Router Class Initialized
INFO - 2023-04-23 06:10:16 --> Output Class Initialized
INFO - 2023-04-23 06:10:16 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:16 --> Input Class Initialized
INFO - 2023-04-23 06:10:16 --> Language Class Initialized
INFO - 2023-04-23 06:10:16 --> Loader Class Initialized
INFO - 2023-04-23 06:10:16 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:16 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:16 --> Model "Login_model" initialized
INFO - 2023-04-23 06:10:16 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:16 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:16 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:16 --> Total execution time: 0.0136
INFO - 2023-04-23 06:10:16 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:16 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:16 --> Total execution time: 0.1048
INFO - 2023-04-23 06:10:18 --> Config Class Initialized
INFO - 2023-04-23 06:10:18 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:18 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:18 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:18 --> URI Class Initialized
INFO - 2023-04-23 06:10:18 --> Router Class Initialized
INFO - 2023-04-23 06:10:18 --> Output Class Initialized
INFO - 2023-04-23 06:10:18 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:18 --> Input Class Initialized
INFO - 2023-04-23 06:10:18 --> Language Class Initialized
INFO - 2023-04-23 06:10:18 --> Loader Class Initialized
INFO - 2023-04-23 06:10:18 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:18 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:18 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:18 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:18 --> Model "Login_model" initialized
INFO - 2023-04-23 06:10:18 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:18 --> Total execution time: 0.0585
INFO - 2023-04-23 06:10:18 --> Config Class Initialized
INFO - 2023-04-23 06:10:18 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:18 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:18 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:18 --> URI Class Initialized
INFO - 2023-04-23 06:10:18 --> Router Class Initialized
INFO - 2023-04-23 06:10:18 --> Output Class Initialized
INFO - 2023-04-23 06:10:18 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:18 --> Input Class Initialized
INFO - 2023-04-23 06:10:18 --> Language Class Initialized
INFO - 2023-04-23 06:10:18 --> Loader Class Initialized
INFO - 2023-04-23 06:10:18 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:18 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:18 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:18 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:18 --> Model "Login_model" initialized
INFO - 2023-04-23 06:10:18 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:18 --> Total execution time: 0.0936
INFO - 2023-04-23 06:10:25 --> Config Class Initialized
INFO - 2023-04-23 06:10:25 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:25 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:25 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:25 --> URI Class Initialized
INFO - 2023-04-23 06:10:25 --> Router Class Initialized
INFO - 2023-04-23 06:10:25 --> Output Class Initialized
INFO - 2023-04-23 06:10:25 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:25 --> Input Class Initialized
INFO - 2023-04-23 06:10:25 --> Language Class Initialized
INFO - 2023-04-23 06:10:25 --> Loader Class Initialized
INFO - 2023-04-23 06:10:25 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:25 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:25 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:25 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:25 --> Total execution time: 0.0109
INFO - 2023-04-23 06:10:25 --> Config Class Initialized
INFO - 2023-04-23 06:10:25 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:25 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:25 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:25 --> URI Class Initialized
INFO - 2023-04-23 06:10:25 --> Router Class Initialized
INFO - 2023-04-23 06:10:25 --> Output Class Initialized
INFO - 2023-04-23 06:10:25 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:25 --> Input Class Initialized
INFO - 2023-04-23 06:10:25 --> Language Class Initialized
INFO - 2023-04-23 06:10:25 --> Loader Class Initialized
INFO - 2023-04-23 06:10:25 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:25 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:25 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:25 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:25 --> Total execution time: 0.0108
INFO - 2023-04-23 06:10:25 --> Config Class Initialized
INFO - 2023-04-23 06:10:25 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:25 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:25 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:25 --> URI Class Initialized
INFO - 2023-04-23 06:10:25 --> Router Class Initialized
INFO - 2023-04-23 06:10:25 --> Output Class Initialized
INFO - 2023-04-23 06:10:25 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:25 --> Input Class Initialized
INFO - 2023-04-23 06:10:25 --> Language Class Initialized
INFO - 2023-04-23 06:10:25 --> Loader Class Initialized
INFO - 2023-04-23 06:10:25 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:25 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:25 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:25 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:25 --> Total execution time: 0.0457
INFO - 2023-04-23 06:10:25 --> Config Class Initialized
INFO - 2023-04-23 06:10:25 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:25 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:25 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:25 --> URI Class Initialized
INFO - 2023-04-23 06:10:25 --> Router Class Initialized
INFO - 2023-04-23 06:10:25 --> Output Class Initialized
INFO - 2023-04-23 06:10:25 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:25 --> Input Class Initialized
INFO - 2023-04-23 06:10:25 --> Language Class Initialized
INFO - 2023-04-23 06:10:25 --> Loader Class Initialized
INFO - 2023-04-23 06:10:25 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:25 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:25 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:25 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:25 --> Total execution time: 0.0855
INFO - 2023-04-23 06:10:27 --> Config Class Initialized
INFO - 2023-04-23 06:10:27 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:27 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:27 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:27 --> URI Class Initialized
INFO - 2023-04-23 06:10:27 --> Router Class Initialized
INFO - 2023-04-23 06:10:27 --> Output Class Initialized
INFO - 2023-04-23 06:10:27 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:27 --> Input Class Initialized
INFO - 2023-04-23 06:10:27 --> Language Class Initialized
INFO - 2023-04-23 06:10:27 --> Loader Class Initialized
INFO - 2023-04-23 06:10:27 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:27 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:27 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:27 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:27 --> Total execution time: 0.0116
INFO - 2023-04-23 06:10:27 --> Config Class Initialized
INFO - 2023-04-23 06:10:27 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:27 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:27 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:27 --> URI Class Initialized
INFO - 2023-04-23 06:10:27 --> Router Class Initialized
INFO - 2023-04-23 06:10:27 --> Output Class Initialized
INFO - 2023-04-23 06:10:27 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:27 --> Input Class Initialized
INFO - 2023-04-23 06:10:27 --> Language Class Initialized
INFO - 2023-04-23 06:10:27 --> Loader Class Initialized
INFO - 2023-04-23 06:10:27 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:27 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:27 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:27 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:27 --> Total execution time: 0.0546
INFO - 2023-04-23 06:10:30 --> Config Class Initialized
INFO - 2023-04-23 06:10:30 --> Config Class Initialized
INFO - 2023-04-23 06:10:30 --> Hooks Class Initialized
INFO - 2023-04-23 06:10:30 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 06:10:30 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:30 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:30 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:30 --> URI Class Initialized
INFO - 2023-04-23 06:10:30 --> URI Class Initialized
INFO - 2023-04-23 06:10:30 --> Router Class Initialized
INFO - 2023-04-23 06:10:30 --> Router Class Initialized
INFO - 2023-04-23 06:10:30 --> Output Class Initialized
INFO - 2023-04-23 06:10:30 --> Output Class Initialized
INFO - 2023-04-23 06:10:30 --> Security Class Initialized
INFO - 2023-04-23 06:10:30 --> Security Class Initialized
DEBUG - 2023-04-23 06:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 06:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:30 --> Input Class Initialized
INFO - 2023-04-23 06:10:30 --> Input Class Initialized
INFO - 2023-04-23 06:10:30 --> Language Class Initialized
INFO - 2023-04-23 06:10:30 --> Language Class Initialized
INFO - 2023-04-23 06:10:30 --> Loader Class Initialized
INFO - 2023-04-23 06:10:30 --> Loader Class Initialized
INFO - 2023-04-23 06:10:30 --> Controller Class Initialized
INFO - 2023-04-23 06:10:30 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 06:10:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:30 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:30 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:30 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:30 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:30 --> Final output sent to browser
INFO - 2023-04-23 06:10:30 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:30 --> Total execution time: 0.0185
DEBUG - 2023-04-23 06:10:30 --> Total execution time: 0.0185
INFO - 2023-04-23 06:10:30 --> Config Class Initialized
INFO - 2023-04-23 06:10:30 --> Config Class Initialized
INFO - 2023-04-23 06:10:30 --> Hooks Class Initialized
INFO - 2023-04-23 06:10:30 --> Hooks Class Initialized
DEBUG - 2023-04-23 06:10:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 06:10:30 --> UTF-8 Support Enabled
INFO - 2023-04-23 06:10:30 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:30 --> Utf8 Class Initialized
INFO - 2023-04-23 06:10:30 --> URI Class Initialized
INFO - 2023-04-23 06:10:30 --> URI Class Initialized
INFO - 2023-04-23 06:10:30 --> Router Class Initialized
INFO - 2023-04-23 06:10:30 --> Router Class Initialized
INFO - 2023-04-23 06:10:30 --> Output Class Initialized
INFO - 2023-04-23 06:10:30 --> Security Class Initialized
INFO - 2023-04-23 06:10:30 --> Output Class Initialized
DEBUG - 2023-04-23 06:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:30 --> Security Class Initialized
INFO - 2023-04-23 06:10:30 --> Input Class Initialized
DEBUG - 2023-04-23 06:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 06:10:30 --> Language Class Initialized
INFO - 2023-04-23 06:10:30 --> Input Class Initialized
INFO - 2023-04-23 06:10:30 --> Language Class Initialized
INFO - 2023-04-23 06:10:30 --> Loader Class Initialized
INFO - 2023-04-23 06:10:30 --> Loader Class Initialized
INFO - 2023-04-23 06:10:30 --> Controller Class Initialized
INFO - 2023-04-23 06:10:30 --> Controller Class Initialized
DEBUG - 2023-04-23 06:10:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 06:10:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 06:10:30 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:30 --> Database Driver Class Initialized
INFO - 2023-04-23 06:10:30 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:30 --> Model "Cluster_model" initialized
INFO - 2023-04-23 06:10:30 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:30 --> Total execution time: 0.0526
INFO - 2023-04-23 06:10:30 --> Final output sent to browser
DEBUG - 2023-04-23 06:10:30 --> Total execution time: 0.0531
INFO - 2023-04-23 07:01:54 --> Config Class Initialized
INFO - 2023-04-23 07:01:54 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:01:54 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:01:54 --> Utf8 Class Initialized
INFO - 2023-04-23 07:01:54 --> URI Class Initialized
INFO - 2023-04-23 07:01:54 --> Router Class Initialized
INFO - 2023-04-23 07:01:54 --> Output Class Initialized
INFO - 2023-04-23 07:01:54 --> Security Class Initialized
DEBUG - 2023-04-23 07:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:01:54 --> Input Class Initialized
INFO - 2023-04-23 07:01:54 --> Language Class Initialized
INFO - 2023-04-23 07:01:54 --> Loader Class Initialized
INFO - 2023-04-23 07:01:54 --> Controller Class Initialized
DEBUG - 2023-04-23 07:01:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:01:54 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:54 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:01:54 --> Final output sent to browser
DEBUG - 2023-04-23 07:01:54 --> Total execution time: 0.0235
INFO - 2023-04-23 07:01:54 --> Config Class Initialized
INFO - 2023-04-23 07:01:54 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:01:54 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:01:54 --> Utf8 Class Initialized
INFO - 2023-04-23 07:01:54 --> URI Class Initialized
INFO - 2023-04-23 07:01:54 --> Router Class Initialized
INFO - 2023-04-23 07:01:54 --> Output Class Initialized
INFO - 2023-04-23 07:01:54 --> Security Class Initialized
DEBUG - 2023-04-23 07:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:01:54 --> Input Class Initialized
INFO - 2023-04-23 07:01:54 --> Language Class Initialized
INFO - 2023-04-23 07:01:54 --> Loader Class Initialized
INFO - 2023-04-23 07:01:54 --> Controller Class Initialized
DEBUG - 2023-04-23 07:01:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:01:54 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:54 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:01:54 --> Final output sent to browser
DEBUG - 2023-04-23 07:01:54 --> Total execution time: 0.0550
INFO - 2023-04-23 07:01:56 --> Config Class Initialized
INFO - 2023-04-23 07:01:56 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:01:56 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:01:56 --> Utf8 Class Initialized
INFO - 2023-04-23 07:01:56 --> URI Class Initialized
INFO - 2023-04-23 07:01:56 --> Router Class Initialized
INFO - 2023-04-23 07:01:56 --> Output Class Initialized
INFO - 2023-04-23 07:01:56 --> Security Class Initialized
DEBUG - 2023-04-23 07:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:01:56 --> Input Class Initialized
INFO - 2023-04-23 07:01:56 --> Language Class Initialized
INFO - 2023-04-23 07:01:56 --> Loader Class Initialized
INFO - 2023-04-23 07:01:56 --> Controller Class Initialized
DEBUG - 2023-04-23 07:01:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:01:56 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:56 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:01:56 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:56 --> Model "Login_model" initialized
INFO - 2023-04-23 07:01:56 --> Final output sent to browser
DEBUG - 2023-04-23 07:01:56 --> Total execution time: 0.0890
INFO - 2023-04-23 07:01:56 --> Config Class Initialized
INFO - 2023-04-23 07:01:56 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:01:56 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:01:56 --> Utf8 Class Initialized
INFO - 2023-04-23 07:01:56 --> URI Class Initialized
INFO - 2023-04-23 07:01:56 --> Router Class Initialized
INFO - 2023-04-23 07:01:56 --> Output Class Initialized
INFO - 2023-04-23 07:01:56 --> Security Class Initialized
DEBUG - 2023-04-23 07:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:01:56 --> Input Class Initialized
INFO - 2023-04-23 07:01:56 --> Language Class Initialized
INFO - 2023-04-23 07:01:56 --> Loader Class Initialized
INFO - 2023-04-23 07:01:56 --> Controller Class Initialized
DEBUG - 2023-04-23 07:01:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:01:56 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:56 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:01:56 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:56 --> Model "Login_model" initialized
INFO - 2023-04-23 07:01:56 --> Final output sent to browser
DEBUG - 2023-04-23 07:01:56 --> Total execution time: 0.1126
INFO - 2023-04-23 07:01:57 --> Config Class Initialized
INFO - 2023-04-23 07:01:57 --> Hooks Class Initialized
INFO - 2023-04-23 07:01:57 --> Config Class Initialized
INFO - 2023-04-23 07:01:57 --> Config Class Initialized
INFO - 2023-04-23 07:01:57 --> Hooks Class Initialized
INFO - 2023-04-23 07:01:57 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:01:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:01:57 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:01:57 --> Utf8 Class Initialized
INFO - 2023-04-23 07:01:57 --> Utf8 Class Initialized
DEBUG - 2023-04-23 07:01:57 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:01:57 --> URI Class Initialized
INFO - 2023-04-23 07:01:57 --> URI Class Initialized
INFO - 2023-04-23 07:01:57 --> Utf8 Class Initialized
INFO - 2023-04-23 07:01:57 --> Router Class Initialized
INFO - 2023-04-23 07:01:57 --> Router Class Initialized
INFO - 2023-04-23 07:01:57 --> URI Class Initialized
INFO - 2023-04-23 07:01:57 --> Output Class Initialized
INFO - 2023-04-23 07:01:57 --> Output Class Initialized
INFO - 2023-04-23 07:01:57 --> Security Class Initialized
INFO - 2023-04-23 07:01:57 --> Router Class Initialized
INFO - 2023-04-23 07:01:57 --> Security Class Initialized
DEBUG - 2023-04-23 07:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:01:57 --> Output Class Initialized
INFO - 2023-04-23 07:01:57 --> Input Class Initialized
INFO - 2023-04-23 07:01:57 --> Input Class Initialized
INFO - 2023-04-23 07:01:57 --> Security Class Initialized
INFO - 2023-04-23 07:01:57 --> Language Class Initialized
INFO - 2023-04-23 07:01:57 --> Language Class Initialized
DEBUG - 2023-04-23 07:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:01:57 --> Input Class Initialized
INFO - 2023-04-23 07:01:57 --> Language Class Initialized
INFO - 2023-04-23 07:01:57 --> Loader Class Initialized
INFO - 2023-04-23 07:01:57 --> Controller Class Initialized
DEBUG - 2023-04-23 07:01:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:01:57 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:57 --> Loader Class Initialized
INFO - 2023-04-23 07:01:57 --> Loader Class Initialized
INFO - 2023-04-23 07:01:57 --> Controller Class Initialized
INFO - 2023-04-23 07:01:57 --> Controller Class Initialized
DEBUG - 2023-04-23 07:01:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 07:01:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:01:57 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:57 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:57 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:01:57 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:57 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:01:57 --> Model "Login_model" initialized
INFO - 2023-04-23 07:01:57 --> Final output sent to browser
DEBUG - 2023-04-23 07:01:57 --> Total execution time: 0.0401
INFO - 2023-04-23 07:01:57 --> Config Class Initialized
INFO - 2023-04-23 07:01:57 --> Hooks Class Initialized
INFO - 2023-04-23 07:01:57 --> Final output sent to browser
INFO - 2023-04-23 07:01:57 --> Final output sent to browser
DEBUG - 2023-04-23 07:01:57 --> Total execution time: 0.0508
DEBUG - 2023-04-23 07:01:57 --> Total execution time: 0.0590
DEBUG - 2023-04-23 07:01:57 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:01:57 --> Utf8 Class Initialized
INFO - 2023-04-23 07:01:57 --> URI Class Initialized
INFO - 2023-04-23 07:01:57 --> Router Class Initialized
INFO - 2023-04-23 07:01:57 --> Config Class Initialized
INFO - 2023-04-23 07:01:57 --> Output Class Initialized
INFO - 2023-04-23 07:01:57 --> Config Class Initialized
INFO - 2023-04-23 07:01:57 --> Security Class Initialized
INFO - 2023-04-23 07:01:57 --> Hooks Class Initialized
INFO - 2023-04-23 07:01:57 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:01:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:01:57 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:01:57 --> Input Class Initialized
INFO - 2023-04-23 07:01:57 --> Utf8 Class Initialized
INFO - 2023-04-23 07:01:57 --> Utf8 Class Initialized
INFO - 2023-04-23 07:01:57 --> Language Class Initialized
INFO - 2023-04-23 07:01:57 --> URI Class Initialized
INFO - 2023-04-23 07:01:57 --> URI Class Initialized
INFO - 2023-04-23 07:01:57 --> Loader Class Initialized
INFO - 2023-04-23 07:01:57 --> Router Class Initialized
INFO - 2023-04-23 07:01:57 --> Router Class Initialized
INFO - 2023-04-23 07:01:57 --> Output Class Initialized
INFO - 2023-04-23 07:01:57 --> Output Class Initialized
INFO - 2023-04-23 07:01:57 --> Controller Class Initialized
INFO - 2023-04-23 07:01:57 --> Security Class Initialized
INFO - 2023-04-23 07:01:57 --> Security Class Initialized
DEBUG - 2023-04-23 07:01:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 07:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:01:57 --> Input Class Initialized
DEBUG - 2023-04-23 07:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:01:57 --> Language Class Initialized
INFO - 2023-04-23 07:01:57 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:57 --> Input Class Initialized
INFO - 2023-04-23 07:01:57 --> Language Class Initialized
INFO - 2023-04-23 07:01:57 --> Loader Class Initialized
INFO - 2023-04-23 07:01:57 --> Loader Class Initialized
INFO - 2023-04-23 07:01:57 --> Controller Class Initialized
INFO - 2023-04-23 07:01:57 --> Controller Class Initialized
DEBUG - 2023-04-23 07:01:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 07:01:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:01:57 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:57 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:57 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:01:57 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:01:57 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:57 --> Model "Login_model" initialized
INFO - 2023-04-23 07:01:57 --> Final output sent to browser
DEBUG - 2023-04-23 07:01:57 --> Total execution time: 0.1061
INFO - 2023-04-23 07:01:57 --> Config Class Initialized
INFO - 2023-04-23 07:01:57 --> Final output sent to browser
INFO - 2023-04-23 07:01:57 --> Final output sent to browser
DEBUG - 2023-04-23 07:01:57 --> Total execution time: 0.1556
INFO - 2023-04-23 07:01:57 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:01:57 --> Total execution time: 0.1173
DEBUG - 2023-04-23 07:01:57 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:01:57 --> Utf8 Class Initialized
INFO - 2023-04-23 07:01:57 --> URI Class Initialized
INFO - 2023-04-23 07:01:57 --> Router Class Initialized
INFO - 2023-04-23 07:01:57 --> Config Class Initialized
INFO - 2023-04-23 07:01:57 --> Hooks Class Initialized
INFO - 2023-04-23 07:01:57 --> Output Class Initialized
DEBUG - 2023-04-23 07:01:57 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:01:57 --> Security Class Initialized
INFO - 2023-04-23 07:01:57 --> Utf8 Class Initialized
DEBUG - 2023-04-23 07:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:01:57 --> Input Class Initialized
INFO - 2023-04-23 07:01:57 --> URI Class Initialized
INFO - 2023-04-23 07:01:57 --> Language Class Initialized
INFO - 2023-04-23 07:01:57 --> Router Class Initialized
INFO - 2023-04-23 07:01:57 --> Loader Class Initialized
INFO - 2023-04-23 07:01:57 --> Output Class Initialized
INFO - 2023-04-23 07:01:57 --> Controller Class Initialized
INFO - 2023-04-23 07:01:57 --> Security Class Initialized
DEBUG - 2023-04-23 07:01:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 07:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:01:57 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:57 --> Input Class Initialized
INFO - 2023-04-23 07:01:57 --> Language Class Initialized
INFO - 2023-04-23 07:01:57 --> Loader Class Initialized
INFO - 2023-04-23 07:01:57 --> Controller Class Initialized
DEBUG - 2023-04-23 07:01:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:01:57 --> Database Driver Class Initialized
INFO - 2023-04-23 07:01:57 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:01:57 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:01:57 --> Final output sent to browser
INFO - 2023-04-23 07:01:57 --> Final output sent to browser
DEBUG - 2023-04-23 07:01:57 --> Total execution time: 0.1506
DEBUG - 2023-04-23 07:01:57 --> Total execution time: 0.1944
INFO - 2023-04-23 07:02:20 --> Config Class Initialized
INFO - 2023-04-23 07:02:20 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:02:20 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:02:20 --> Utf8 Class Initialized
INFO - 2023-04-23 07:02:20 --> URI Class Initialized
INFO - 2023-04-23 07:02:20 --> Router Class Initialized
INFO - 2023-04-23 07:02:20 --> Output Class Initialized
INFO - 2023-04-23 07:02:20 --> Security Class Initialized
DEBUG - 2023-04-23 07:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:02:20 --> Input Class Initialized
INFO - 2023-04-23 07:02:20 --> Language Class Initialized
INFO - 2023-04-23 07:02:20 --> Loader Class Initialized
INFO - 2023-04-23 07:02:20 --> Controller Class Initialized
DEBUG - 2023-04-23 07:02:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:02:20 --> Database Driver Class Initialized
INFO - 2023-04-23 07:02:20 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:02:20 --> Final output sent to browser
DEBUG - 2023-04-23 07:02:20 --> Total execution time: 0.0145
INFO - 2023-04-23 07:02:20 --> Config Class Initialized
INFO - 2023-04-23 07:02:20 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:02:20 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:02:20 --> Utf8 Class Initialized
INFO - 2023-04-23 07:02:20 --> URI Class Initialized
INFO - 2023-04-23 07:02:20 --> Router Class Initialized
INFO - 2023-04-23 07:02:20 --> Output Class Initialized
INFO - 2023-04-23 07:02:20 --> Security Class Initialized
DEBUG - 2023-04-23 07:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:02:20 --> Input Class Initialized
INFO - 2023-04-23 07:02:20 --> Language Class Initialized
INFO - 2023-04-23 07:02:20 --> Loader Class Initialized
INFO - 2023-04-23 07:02:20 --> Controller Class Initialized
DEBUG - 2023-04-23 07:02:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:02:20 --> Database Driver Class Initialized
INFO - 2023-04-23 07:02:20 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:02:20 --> Final output sent to browser
DEBUG - 2023-04-23 07:02:20 --> Total execution time: 0.0521
INFO - 2023-04-23 07:02:23 --> Config Class Initialized
INFO - 2023-04-23 07:02:23 --> Config Class Initialized
INFO - 2023-04-23 07:02:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:02:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:02:23 --> Utf8 Class Initialized
INFO - 2023-04-23 07:02:23 --> URI Class Initialized
INFO - 2023-04-23 07:02:23 --> Router Class Initialized
INFO - 2023-04-23 07:02:23 --> Output Class Initialized
INFO - 2023-04-23 07:02:23 --> Security Class Initialized
INFO - 2023-04-23 07:02:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:02:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:02:23 --> Utf8 Class Initialized
INFO - 2023-04-23 07:02:23 --> URI Class Initialized
INFO - 2023-04-23 07:02:23 --> Router Class Initialized
INFO - 2023-04-23 07:02:23 --> Output Class Initialized
INFO - 2023-04-23 07:02:23 --> Security Class Initialized
DEBUG - 2023-04-23 07:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:02:23 --> Input Class Initialized
INFO - 2023-04-23 07:02:23 --> Language Class Initialized
DEBUG - 2023-04-23 07:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:02:23 --> Loader Class Initialized
INFO - 2023-04-23 07:02:23 --> Input Class Initialized
INFO - 2023-04-23 07:02:23 --> Controller Class Initialized
INFO - 2023-04-23 07:02:23 --> Language Class Initialized
DEBUG - 2023-04-23 07:02:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:02:23 --> Loader Class Initialized
INFO - 2023-04-23 07:02:23 --> Final output sent to browser
INFO - 2023-04-23 07:02:23 --> Controller Class Initialized
DEBUG - 2023-04-23 07:02:23 --> Total execution time: 0.0954
DEBUG - 2023-04-23 07:02:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:02:23 --> Database Driver Class Initialized
INFO - 2023-04-23 07:02:23 --> Config Class Initialized
INFO - 2023-04-23 07:02:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:02:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:02:23 --> Utf8 Class Initialized
INFO - 2023-04-23 07:02:23 --> URI Class Initialized
INFO - 2023-04-23 07:02:23 --> Router Class Initialized
INFO - 2023-04-23 07:02:23 --> Output Class Initialized
INFO - 2023-04-23 07:02:23 --> Security Class Initialized
DEBUG - 2023-04-23 07:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:02:23 --> Input Class Initialized
INFO - 2023-04-23 07:02:23 --> Language Class Initialized
INFO - 2023-04-23 07:02:23 --> Loader Class Initialized
INFO - 2023-04-23 07:02:23 --> Controller Class Initialized
DEBUG - 2023-04-23 07:02:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:02:23 --> Database Driver Class Initialized
INFO - 2023-04-23 07:02:23 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:02:23 --> Model "Login_model" initialized
INFO - 2023-04-23 07:02:23 --> Database Driver Class Initialized
INFO - 2023-04-23 07:02:23 --> Final output sent to browser
DEBUG - 2023-04-23 07:02:23 --> Total execution time: 0.1477
INFO - 2023-04-23 07:02:23 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:02:23 --> Final output sent to browser
DEBUG - 2023-04-23 07:02:23 --> Total execution time: 0.0665
INFO - 2023-04-23 07:02:23 --> Config Class Initialized
INFO - 2023-04-23 07:02:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:02:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:02:23 --> Utf8 Class Initialized
INFO - 2023-04-23 07:02:23 --> URI Class Initialized
INFO - 2023-04-23 07:02:23 --> Router Class Initialized
INFO - 2023-04-23 07:02:23 --> Output Class Initialized
INFO - 2023-04-23 07:02:23 --> Security Class Initialized
DEBUG - 2023-04-23 07:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:02:23 --> Input Class Initialized
INFO - 2023-04-23 07:02:23 --> Language Class Initialized
INFO - 2023-04-23 07:02:23 --> Loader Class Initialized
INFO - 2023-04-23 07:02:23 --> Controller Class Initialized
DEBUG - 2023-04-23 07:02:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:02:23 --> Database Driver Class Initialized
INFO - 2023-04-23 07:02:23 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:02:23 --> Final output sent to browser
DEBUG - 2023-04-23 07:02:23 --> Total execution time: 0.0829
INFO - 2023-04-23 07:31:22 --> Config Class Initialized
INFO - 2023-04-23 07:31:22 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:31:22 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:31:22 --> Utf8 Class Initialized
INFO - 2023-04-23 07:31:22 --> URI Class Initialized
INFO - 2023-04-23 07:31:22 --> Router Class Initialized
INFO - 2023-04-23 07:31:22 --> Output Class Initialized
INFO - 2023-04-23 07:31:22 --> Security Class Initialized
DEBUG - 2023-04-23 07:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:31:22 --> Input Class Initialized
INFO - 2023-04-23 07:31:22 --> Language Class Initialized
INFO - 2023-04-23 07:31:22 --> Loader Class Initialized
INFO - 2023-04-23 07:31:22 --> Controller Class Initialized
DEBUG - 2023-04-23 07:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:31:22 --> Database Driver Class Initialized
INFO - 2023-04-23 07:31:22 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:31:22 --> Final output sent to browser
INFO - 2023-04-23 07:31:22 --> Config Class Initialized
DEBUG - 2023-04-23 07:31:22 --> Total execution time: 0.0455
INFO - 2023-04-23 07:31:22 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:31:22 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:31:22 --> Utf8 Class Initialized
INFO - 2023-04-23 07:31:22 --> URI Class Initialized
INFO - 2023-04-23 07:31:22 --> Router Class Initialized
INFO - 2023-04-23 07:31:22 --> Output Class Initialized
INFO - 2023-04-23 07:31:22 --> Security Class Initialized
DEBUG - 2023-04-23 07:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:31:22 --> Input Class Initialized
INFO - 2023-04-23 07:31:22 --> Language Class Initialized
INFO - 2023-04-23 07:31:22 --> Loader Class Initialized
INFO - 2023-04-23 07:31:22 --> Controller Class Initialized
DEBUG - 2023-04-23 07:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:31:22 --> Database Driver Class Initialized
INFO - 2023-04-23 07:31:22 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:31:22 --> Final output sent to browser
DEBUG - 2023-04-23 07:31:22 --> Total execution time: 0.1223
INFO - 2023-04-23 07:31:24 --> Config Class Initialized
INFO - 2023-04-23 07:31:24 --> Config Class Initialized
INFO - 2023-04-23 07:31:24 --> Hooks Class Initialized
INFO - 2023-04-23 07:31:24 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:31:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:31:25 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:31:25 --> Utf8 Class Initialized
INFO - 2023-04-23 07:31:25 --> Utf8 Class Initialized
INFO - 2023-04-23 07:31:25 --> URI Class Initialized
INFO - 2023-04-23 07:31:25 --> URI Class Initialized
INFO - 2023-04-23 07:31:25 --> Router Class Initialized
INFO - 2023-04-23 07:31:25 --> Output Class Initialized
INFO - 2023-04-23 07:31:25 --> Router Class Initialized
INFO - 2023-04-23 07:31:25 --> Security Class Initialized
INFO - 2023-04-23 07:31:25 --> Output Class Initialized
DEBUG - 2023-04-23 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:31:25 --> Security Class Initialized
INFO - 2023-04-23 07:31:25 --> Input Class Initialized
DEBUG - 2023-04-23 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:31:25 --> Language Class Initialized
INFO - 2023-04-23 07:31:25 --> Input Class Initialized
INFO - 2023-04-23 07:31:25 --> Language Class Initialized
INFO - 2023-04-23 07:31:25 --> Loader Class Initialized
INFO - 2023-04-23 07:31:25 --> Controller Class Initialized
DEBUG - 2023-04-23 07:31:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:31:25 --> Loader Class Initialized
INFO - 2023-04-23 07:31:25 --> Final output sent to browser
INFO - 2023-04-23 07:31:25 --> Controller Class Initialized
DEBUG - 2023-04-23 07:31:25 --> Total execution time: 0.3146
DEBUG - 2023-04-23 07:31:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:31:25 --> Database Driver Class Initialized
INFO - 2023-04-23 07:31:25 --> Config Class Initialized
INFO - 2023-04-23 07:31:25 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:31:25 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:31:25 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:31:25 --> Utf8 Class Initialized
INFO - 2023-04-23 07:31:25 --> URI Class Initialized
INFO - 2023-04-23 07:31:25 --> Router Class Initialized
INFO - 2023-04-23 07:31:25 --> Output Class Initialized
INFO - 2023-04-23 07:31:25 --> Security Class Initialized
DEBUG - 2023-04-23 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:31:25 --> Input Class Initialized
INFO - 2023-04-23 07:31:25 --> Language Class Initialized
INFO - 2023-04-23 07:31:25 --> Loader Class Initialized
INFO - 2023-04-23 07:31:25 --> Controller Class Initialized
DEBUG - 2023-04-23 07:31:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:31:25 --> Database Driver Class Initialized
INFO - 2023-04-23 07:31:25 --> Final output sent to browser
DEBUG - 2023-04-23 07:31:25 --> Total execution time: 0.3575
INFO - 2023-04-23 07:31:25 --> Config Class Initialized
INFO - 2023-04-23 07:31:25 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:31:25 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:31:25 --> Utf8 Class Initialized
INFO - 2023-04-23 07:31:25 --> URI Class Initialized
INFO - 2023-04-23 07:31:25 --> Router Class Initialized
INFO - 2023-04-23 07:31:25 --> Output Class Initialized
INFO - 2023-04-23 07:31:25 --> Security Class Initialized
DEBUG - 2023-04-23 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:31:25 --> Input Class Initialized
INFO - 2023-04-23 07:31:25 --> Language Class Initialized
INFO - 2023-04-23 07:31:25 --> Loader Class Initialized
INFO - 2023-04-23 07:31:25 --> Controller Class Initialized
DEBUG - 2023-04-23 07:31:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:31:25 --> Database Driver Class Initialized
INFO - 2023-04-23 07:31:25 --> Model "Login_model" initialized
INFO - 2023-04-23 07:31:25 --> Database Driver Class Initialized
INFO - 2023-04-23 07:31:25 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:31:25 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:31:25 --> Final output sent to browser
INFO - 2023-04-23 07:31:25 --> Final output sent to browser
DEBUG - 2023-04-23 07:31:25 --> Total execution time: 0.0665
DEBUG - 2023-04-23 07:31:25 --> Total execution time: 0.0189
INFO - 2023-04-23 07:31:38 --> Config Class Initialized
INFO - 2023-04-23 07:31:38 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:31:38 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:31:38 --> Utf8 Class Initialized
INFO - 2023-04-23 07:31:38 --> URI Class Initialized
INFO - 2023-04-23 07:31:38 --> Router Class Initialized
INFO - 2023-04-23 07:31:38 --> Output Class Initialized
INFO - 2023-04-23 07:31:38 --> Security Class Initialized
DEBUG - 2023-04-23 07:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:31:38 --> Input Class Initialized
INFO - 2023-04-23 07:31:38 --> Language Class Initialized
INFO - 2023-04-23 07:31:38 --> Loader Class Initialized
INFO - 2023-04-23 07:31:38 --> Controller Class Initialized
DEBUG - 2023-04-23 07:31:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:31:38 --> Database Driver Class Initialized
INFO - 2023-04-23 07:31:38 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:31:38 --> Final output sent to browser
DEBUG - 2023-04-23 07:31:38 --> Total execution time: 0.0174
INFO - 2023-04-23 07:31:38 --> Config Class Initialized
INFO - 2023-04-23 07:31:38 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:31:38 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:31:38 --> Utf8 Class Initialized
INFO - 2023-04-23 07:31:38 --> URI Class Initialized
INFO - 2023-04-23 07:31:38 --> Router Class Initialized
INFO - 2023-04-23 07:31:38 --> Output Class Initialized
INFO - 2023-04-23 07:31:38 --> Security Class Initialized
DEBUG - 2023-04-23 07:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:31:38 --> Input Class Initialized
INFO - 2023-04-23 07:31:38 --> Language Class Initialized
INFO - 2023-04-23 07:31:38 --> Loader Class Initialized
INFO - 2023-04-23 07:31:38 --> Controller Class Initialized
DEBUG - 2023-04-23 07:31:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:31:38 --> Database Driver Class Initialized
INFO - 2023-04-23 07:31:38 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:31:38 --> Final output sent to browser
DEBUG - 2023-04-23 07:31:38 --> Total execution time: 0.0520
INFO - 2023-04-23 07:31:41 --> Config Class Initialized
INFO - 2023-04-23 07:31:41 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:31:41 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:31:41 --> Utf8 Class Initialized
INFO - 2023-04-23 07:31:41 --> URI Class Initialized
INFO - 2023-04-23 07:31:41 --> Router Class Initialized
INFO - 2023-04-23 07:31:41 --> Output Class Initialized
INFO - 2023-04-23 07:31:41 --> Security Class Initialized
DEBUG - 2023-04-23 07:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:31:41 --> Input Class Initialized
INFO - 2023-04-23 07:31:41 --> Language Class Initialized
INFO - 2023-04-23 07:31:41 --> Loader Class Initialized
INFO - 2023-04-23 07:31:41 --> Controller Class Initialized
DEBUG - 2023-04-23 07:31:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:31:41 --> Database Driver Class Initialized
INFO - 2023-04-23 07:31:41 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:31:41 --> Final output sent to browser
DEBUG - 2023-04-23 07:31:41 --> Total execution time: 0.0216
INFO - 2023-04-23 07:31:41 --> Config Class Initialized
INFO - 2023-04-23 07:31:41 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:31:41 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:31:41 --> Utf8 Class Initialized
INFO - 2023-04-23 07:31:41 --> URI Class Initialized
INFO - 2023-04-23 07:31:41 --> Router Class Initialized
INFO - 2023-04-23 07:31:41 --> Output Class Initialized
INFO - 2023-04-23 07:31:41 --> Security Class Initialized
DEBUG - 2023-04-23 07:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:31:41 --> Input Class Initialized
INFO - 2023-04-23 07:31:41 --> Language Class Initialized
INFO - 2023-04-23 07:31:41 --> Loader Class Initialized
INFO - 2023-04-23 07:31:41 --> Controller Class Initialized
DEBUG - 2023-04-23 07:31:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:31:41 --> Database Driver Class Initialized
INFO - 2023-04-23 07:31:41 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:31:41 --> Final output sent to browser
DEBUG - 2023-04-23 07:31:41 --> Total execution time: 0.0574
INFO - 2023-04-23 07:35:49 --> Config Class Initialized
INFO - 2023-04-23 07:35:49 --> Config Class Initialized
INFO - 2023-04-23 07:35:49 --> Hooks Class Initialized
INFO - 2023-04-23 07:35:49 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:35:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:35:49 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:35:49 --> Utf8 Class Initialized
INFO - 2023-04-23 07:35:49 --> Utf8 Class Initialized
INFO - 2023-04-23 07:35:49 --> URI Class Initialized
INFO - 2023-04-23 07:35:49 --> URI Class Initialized
INFO - 2023-04-23 07:35:49 --> Router Class Initialized
INFO - 2023-04-23 07:35:49 --> Router Class Initialized
INFO - 2023-04-23 07:35:49 --> Output Class Initialized
INFO - 2023-04-23 07:35:49 --> Output Class Initialized
INFO - 2023-04-23 07:35:49 --> Security Class Initialized
INFO - 2023-04-23 07:35:49 --> Security Class Initialized
DEBUG - 2023-04-23 07:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 07:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:35:49 --> Input Class Initialized
INFO - 2023-04-23 07:35:49 --> Input Class Initialized
INFO - 2023-04-23 07:35:49 --> Language Class Initialized
INFO - 2023-04-23 07:35:49 --> Language Class Initialized
INFO - 2023-04-23 07:35:49 --> Loader Class Initialized
INFO - 2023-04-23 07:35:49 --> Loader Class Initialized
INFO - 2023-04-23 07:35:49 --> Controller Class Initialized
INFO - 2023-04-23 07:35:49 --> Controller Class Initialized
DEBUG - 2023-04-23 07:35:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 07:35:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:35:49 --> Final output sent to browser
DEBUG - 2023-04-23 07:35:49 --> Total execution time: 0.0052
INFO - 2023-04-23 07:35:49 --> Database Driver Class Initialized
INFO - 2023-04-23 07:35:49 --> Config Class Initialized
INFO - 2023-04-23 07:35:49 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:35:49 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:35:49 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:35:49 --> Utf8 Class Initialized
INFO - 2023-04-23 07:35:49 --> URI Class Initialized
INFO - 2023-04-23 07:35:49 --> Router Class Initialized
INFO - 2023-04-23 07:35:49 --> Output Class Initialized
INFO - 2023-04-23 07:35:49 --> Security Class Initialized
DEBUG - 2023-04-23 07:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:35:49 --> Input Class Initialized
INFO - 2023-04-23 07:35:49 --> Language Class Initialized
INFO - 2023-04-23 07:35:49 --> Loader Class Initialized
INFO - 2023-04-23 07:35:49 --> Controller Class Initialized
INFO - 2023-04-23 07:35:49 --> Final output sent to browser
DEBUG - 2023-04-23 07:35:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 07:35:49 --> Total execution time: 0.0506
INFO - 2023-04-23 07:35:49 --> Database Driver Class Initialized
INFO - 2023-04-23 07:35:49 --> Config Class Initialized
INFO - 2023-04-23 07:35:49 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:35:49 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:35:49 --> Utf8 Class Initialized
INFO - 2023-04-23 07:35:49 --> URI Class Initialized
INFO - 2023-04-23 07:35:49 --> Router Class Initialized
INFO - 2023-04-23 07:35:49 --> Output Class Initialized
INFO - 2023-04-23 07:35:49 --> Security Class Initialized
DEBUG - 2023-04-23 07:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:35:49 --> Input Class Initialized
INFO - 2023-04-23 07:35:49 --> Language Class Initialized
INFO - 2023-04-23 07:35:49 --> Loader Class Initialized
INFO - 2023-04-23 07:35:49 --> Controller Class Initialized
DEBUG - 2023-04-23 07:35:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:35:49 --> Database Driver Class Initialized
INFO - 2023-04-23 07:35:49 --> Model "Login_model" initialized
INFO - 2023-04-23 07:35:49 --> Database Driver Class Initialized
INFO - 2023-04-23 07:35:49 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:35:49 --> Final output sent to browser
DEBUG - 2023-04-23 07:35:49 --> Total execution time: 0.0148
INFO - 2023-04-23 07:35:49 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:35:49 --> Final output sent to browser
DEBUG - 2023-04-23 07:35:49 --> Total execution time: 0.0649
INFO - 2023-04-23 07:35:50 --> Config Class Initialized
INFO - 2023-04-23 07:35:50 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:35:50 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:35:50 --> Utf8 Class Initialized
INFO - 2023-04-23 07:35:50 --> URI Class Initialized
INFO - 2023-04-23 07:35:50 --> Router Class Initialized
INFO - 2023-04-23 07:35:50 --> Output Class Initialized
INFO - 2023-04-23 07:35:50 --> Security Class Initialized
DEBUG - 2023-04-23 07:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:35:50 --> Input Class Initialized
INFO - 2023-04-23 07:35:50 --> Language Class Initialized
INFO - 2023-04-23 07:35:50 --> Loader Class Initialized
INFO - 2023-04-23 07:35:50 --> Controller Class Initialized
DEBUG - 2023-04-23 07:35:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:35:50 --> Database Driver Class Initialized
INFO - 2023-04-23 07:35:50 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:35:50 --> Database Driver Class Initialized
INFO - 2023-04-23 07:35:50 --> Model "Login_model" initialized
INFO - 2023-04-23 07:35:50 --> Final output sent to browser
DEBUG - 2023-04-23 07:35:50 --> Total execution time: 0.0804
INFO - 2023-04-23 07:35:50 --> Config Class Initialized
INFO - 2023-04-23 07:35:51 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:35:51 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:35:51 --> Utf8 Class Initialized
INFO - 2023-04-23 07:35:51 --> URI Class Initialized
INFO - 2023-04-23 07:35:51 --> Router Class Initialized
INFO - 2023-04-23 07:35:51 --> Output Class Initialized
INFO - 2023-04-23 07:35:51 --> Security Class Initialized
DEBUG - 2023-04-23 07:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:35:51 --> Input Class Initialized
INFO - 2023-04-23 07:35:51 --> Language Class Initialized
INFO - 2023-04-23 07:35:51 --> Loader Class Initialized
INFO - 2023-04-23 07:35:51 --> Controller Class Initialized
DEBUG - 2023-04-23 07:35:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:35:51 --> Database Driver Class Initialized
INFO - 2023-04-23 07:35:51 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:35:51 --> Database Driver Class Initialized
INFO - 2023-04-23 07:35:51 --> Model "Login_model" initialized
INFO - 2023-04-23 07:35:51 --> Final output sent to browser
DEBUG - 2023-04-23 07:35:51 --> Total execution time: 0.0988
INFO - 2023-04-23 07:36:48 --> Config Class Initialized
INFO - 2023-04-23 07:36:48 --> Config Class Initialized
INFO - 2023-04-23 07:36:48 --> Hooks Class Initialized
INFO - 2023-04-23 07:36:48 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:36:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 07:36:48 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:36:48 --> Utf8 Class Initialized
INFO - 2023-04-23 07:36:48 --> Utf8 Class Initialized
INFO - 2023-04-23 07:36:48 --> URI Class Initialized
INFO - 2023-04-23 07:36:48 --> URI Class Initialized
INFO - 2023-04-23 07:36:48 --> Router Class Initialized
INFO - 2023-04-23 07:36:48 --> Router Class Initialized
INFO - 2023-04-23 07:36:48 --> Output Class Initialized
INFO - 2023-04-23 07:36:48 --> Output Class Initialized
INFO - 2023-04-23 07:36:48 --> Security Class Initialized
DEBUG - 2023-04-23 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:36:48 --> Security Class Initialized
INFO - 2023-04-23 07:36:48 --> Input Class Initialized
DEBUG - 2023-04-23 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:36:48 --> Language Class Initialized
INFO - 2023-04-23 07:36:48 --> Input Class Initialized
INFO - 2023-04-23 07:36:48 --> Language Class Initialized
INFO - 2023-04-23 07:36:48 --> Loader Class Initialized
INFO - 2023-04-23 07:36:48 --> Loader Class Initialized
INFO - 2023-04-23 07:36:48 --> Controller Class Initialized
INFO - 2023-04-23 07:36:48 --> Controller Class Initialized
DEBUG - 2023-04-23 07:36:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 07:36:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:36:48 --> Final output sent to browser
DEBUG - 2023-04-23 07:36:48 --> Total execution time: 0.0172
INFO - 2023-04-23 07:36:48 --> Database Driver Class Initialized
INFO - 2023-04-23 07:36:48 --> Config Class Initialized
INFO - 2023-04-23 07:36:48 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:36:48 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:36:48 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:36:48 --> Utf8 Class Initialized
INFO - 2023-04-23 07:36:48 --> URI Class Initialized
INFO - 2023-04-23 07:36:48 --> Router Class Initialized
INFO - 2023-04-23 07:36:48 --> Output Class Initialized
INFO - 2023-04-23 07:36:48 --> Security Class Initialized
DEBUG - 2023-04-23 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:36:48 --> Input Class Initialized
INFO - 2023-04-23 07:36:48 --> Language Class Initialized
INFO - 2023-04-23 07:36:48 --> Loader Class Initialized
INFO - 2023-04-23 07:36:48 --> Controller Class Initialized
DEBUG - 2023-04-23 07:36:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:36:48 --> Database Driver Class Initialized
INFO - 2023-04-23 07:36:48 --> Final output sent to browser
DEBUG - 2023-04-23 07:36:48 --> Total execution time: 0.0650
INFO - 2023-04-23 07:36:48 --> Config Class Initialized
INFO - 2023-04-23 07:36:48 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:36:48 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:36:48 --> Utf8 Class Initialized
INFO - 2023-04-23 07:36:48 --> URI Class Initialized
INFO - 2023-04-23 07:36:48 --> Router Class Initialized
INFO - 2023-04-23 07:36:48 --> Output Class Initialized
INFO - 2023-04-23 07:36:48 --> Security Class Initialized
DEBUG - 2023-04-23 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:36:48 --> Input Class Initialized
INFO - 2023-04-23 07:36:48 --> Language Class Initialized
INFO - 2023-04-23 07:36:48 --> Loader Class Initialized
INFO - 2023-04-23 07:36:48 --> Controller Class Initialized
DEBUG - 2023-04-23 07:36:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:36:48 --> Database Driver Class Initialized
INFO - 2023-04-23 07:36:48 --> Model "Login_model" initialized
INFO - 2023-04-23 07:36:48 --> Database Driver Class Initialized
INFO - 2023-04-23 07:36:48 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:36:48 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:36:48 --> Final output sent to browser
INFO - 2023-04-23 07:36:48 --> Final output sent to browser
DEBUG - 2023-04-23 07:36:48 --> Total execution time: 0.0584
DEBUG - 2023-04-23 07:36:48 --> Total execution time: 0.0137
INFO - 2023-04-23 07:36:50 --> Config Class Initialized
INFO - 2023-04-23 07:36:50 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:36:50 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:36:50 --> Utf8 Class Initialized
INFO - 2023-04-23 07:36:50 --> URI Class Initialized
INFO - 2023-04-23 07:36:50 --> Router Class Initialized
INFO - 2023-04-23 07:36:50 --> Output Class Initialized
INFO - 2023-04-23 07:36:51 --> Security Class Initialized
DEBUG - 2023-04-23 07:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:36:51 --> Input Class Initialized
INFO - 2023-04-23 07:36:51 --> Language Class Initialized
INFO - 2023-04-23 07:36:51 --> Loader Class Initialized
INFO - 2023-04-23 07:36:51 --> Controller Class Initialized
DEBUG - 2023-04-23 07:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:36:51 --> Database Driver Class Initialized
INFO - 2023-04-23 07:36:51 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:36:51 --> Final output sent to browser
DEBUG - 2023-04-23 07:36:51 --> Total execution time: 0.1069
INFO - 2023-04-23 07:36:51 --> Config Class Initialized
INFO - 2023-04-23 07:36:51 --> Hooks Class Initialized
DEBUG - 2023-04-23 07:36:51 --> UTF-8 Support Enabled
INFO - 2023-04-23 07:36:51 --> Utf8 Class Initialized
INFO - 2023-04-23 07:36:51 --> URI Class Initialized
INFO - 2023-04-23 07:36:51 --> Router Class Initialized
INFO - 2023-04-23 07:36:51 --> Output Class Initialized
INFO - 2023-04-23 07:36:51 --> Security Class Initialized
DEBUG - 2023-04-23 07:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 07:36:51 --> Input Class Initialized
INFO - 2023-04-23 07:36:51 --> Language Class Initialized
INFO - 2023-04-23 07:36:51 --> Loader Class Initialized
INFO - 2023-04-23 07:36:51 --> Controller Class Initialized
DEBUG - 2023-04-23 07:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 07:36:51 --> Database Driver Class Initialized
INFO - 2023-04-23 07:36:51 --> Model "Cluster_model" initialized
INFO - 2023-04-23 07:36:51 --> Final output sent to browser
DEBUG - 2023-04-23 07:36:51 --> Total execution time: 0.0842
INFO - 2023-04-23 08:05:58 --> Config Class Initialized
INFO - 2023-04-23 08:05:58 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:05:58 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:05:58 --> Utf8 Class Initialized
INFO - 2023-04-23 08:05:58 --> URI Class Initialized
INFO - 2023-04-23 08:05:58 --> Router Class Initialized
INFO - 2023-04-23 08:05:58 --> Output Class Initialized
INFO - 2023-04-23 08:05:58 --> Security Class Initialized
DEBUG - 2023-04-23 08:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:05:58 --> Input Class Initialized
INFO - 2023-04-23 08:05:58 --> Language Class Initialized
INFO - 2023-04-23 08:05:58 --> Loader Class Initialized
INFO - 2023-04-23 08:05:58 --> Controller Class Initialized
DEBUG - 2023-04-23 08:05:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:05:58 --> Database Driver Class Initialized
INFO - 2023-04-23 08:05:58 --> Model "Cluster_model" initialized
INFO - 2023-04-23 08:05:58 --> Final output sent to browser
DEBUG - 2023-04-23 08:05:58 --> Total execution time: 0.0591
INFO - 2023-04-23 08:05:58 --> Config Class Initialized
INFO - 2023-04-23 08:05:59 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:05:59 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:05:59 --> Utf8 Class Initialized
INFO - 2023-04-23 08:05:59 --> URI Class Initialized
INFO - 2023-04-23 08:05:59 --> Router Class Initialized
INFO - 2023-04-23 08:05:59 --> Output Class Initialized
INFO - 2023-04-23 08:05:59 --> Security Class Initialized
DEBUG - 2023-04-23 08:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:05:59 --> Input Class Initialized
INFO - 2023-04-23 08:05:59 --> Language Class Initialized
INFO - 2023-04-23 08:05:59 --> Loader Class Initialized
INFO - 2023-04-23 08:05:59 --> Controller Class Initialized
DEBUG - 2023-04-23 08:05:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:05:59 --> Database Driver Class Initialized
INFO - 2023-04-23 08:05:59 --> Model "Cluster_model" initialized
INFO - 2023-04-23 08:05:59 --> Final output sent to browser
DEBUG - 2023-04-23 08:05:59 --> Total execution time: 0.0855
INFO - 2023-04-23 08:06:09 --> Config Class Initialized
INFO - 2023-04-23 08:06:09 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:06:09 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:06:09 --> Utf8 Class Initialized
INFO - 2023-04-23 08:06:09 --> URI Class Initialized
INFO - 2023-04-23 08:06:09 --> Router Class Initialized
INFO - 2023-04-23 08:06:09 --> Output Class Initialized
INFO - 2023-04-23 08:06:09 --> Security Class Initialized
DEBUG - 2023-04-23 08:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:06:09 --> Input Class Initialized
INFO - 2023-04-23 08:06:09 --> Language Class Initialized
INFO - 2023-04-23 08:06:09 --> Loader Class Initialized
INFO - 2023-04-23 08:06:09 --> Controller Class Initialized
INFO - 2023-04-23 08:06:09 --> Helper loaded: form_helper
INFO - 2023-04-23 08:06:09 --> Helper loaded: url_helper
DEBUG - 2023-04-23 08:06:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:06:09 --> Model "Change_model" initialized
INFO - 2023-04-23 08:06:09 --> Final output sent to browser
DEBUG - 2023-04-23 08:06:09 --> Total execution time: 0.0149
INFO - 2023-04-23 08:06:23 --> Config Class Initialized
INFO - 2023-04-23 08:06:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:06:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:06:23 --> Utf8 Class Initialized
INFO - 2023-04-23 08:06:23 --> URI Class Initialized
INFO - 2023-04-23 08:06:23 --> Router Class Initialized
INFO - 2023-04-23 08:06:23 --> Output Class Initialized
INFO - 2023-04-23 08:06:23 --> Security Class Initialized
DEBUG - 2023-04-23 08:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:06:23 --> Input Class Initialized
INFO - 2023-04-23 08:06:23 --> Language Class Initialized
INFO - 2023-04-23 08:06:23 --> Loader Class Initialized
INFO - 2023-04-23 08:06:23 --> Controller Class Initialized
INFO - 2023-04-23 08:06:23 --> Helper loaded: form_helper
INFO - 2023-04-23 08:06:23 --> Helper loaded: url_helper
DEBUG - 2023-04-23 08:06:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:06:23 --> Model "Change_model" initialized
INFO - 2023-04-23 08:06:23 --> Final output sent to browser
DEBUG - 2023-04-23 08:06:23 --> Total execution time: 0.0122
INFO - 2023-04-23 08:59:16 --> Config Class Initialized
INFO - 2023-04-23 08:59:16 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:59:16 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:59:16 --> Utf8 Class Initialized
INFO - 2023-04-23 08:59:16 --> URI Class Initialized
INFO - 2023-04-23 08:59:16 --> Router Class Initialized
INFO - 2023-04-23 08:59:16 --> Output Class Initialized
INFO - 2023-04-23 08:59:16 --> Security Class Initialized
DEBUG - 2023-04-23 08:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:59:16 --> Input Class Initialized
INFO - 2023-04-23 08:59:16 --> Language Class Initialized
INFO - 2023-04-23 08:59:16 --> Loader Class Initialized
INFO - 2023-04-23 08:59:16 --> Controller Class Initialized
INFO - 2023-04-23 08:59:16 --> Helper loaded: form_helper
INFO - 2023-04-23 08:59:16 --> Helper loaded: url_helper
DEBUG - 2023-04-23 08:59:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:59:16 --> Model "Change_model" initialized
INFO - 2023-04-23 08:59:16 --> Model "Grafana_model" initialized
INFO - 2023-04-23 08:59:16 --> Final output sent to browser
DEBUG - 2023-04-23 08:59:16 --> Total execution time: 0.0478
INFO - 2023-04-23 08:59:16 --> Config Class Initialized
INFO - 2023-04-23 08:59:16 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:59:16 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:59:16 --> Utf8 Class Initialized
INFO - 2023-04-23 08:59:16 --> URI Class Initialized
INFO - 2023-04-23 08:59:16 --> Router Class Initialized
INFO - 2023-04-23 08:59:16 --> Output Class Initialized
INFO - 2023-04-23 08:59:16 --> Security Class Initialized
DEBUG - 2023-04-23 08:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:59:16 --> Input Class Initialized
INFO - 2023-04-23 08:59:16 --> Language Class Initialized
INFO - 2023-04-23 08:59:16 --> Loader Class Initialized
INFO - 2023-04-23 08:59:16 --> Controller Class Initialized
INFO - 2023-04-23 08:59:16 --> Helper loaded: form_helper
INFO - 2023-04-23 08:59:16 --> Helper loaded: url_helper
DEBUG - 2023-04-23 08:59:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:59:16 --> Final output sent to browser
DEBUG - 2023-04-23 08:59:16 --> Total execution time: 0.0051
INFO - 2023-04-23 08:59:16 --> Config Class Initialized
INFO - 2023-04-23 08:59:16 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:59:16 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:59:16 --> Utf8 Class Initialized
INFO - 2023-04-23 08:59:16 --> URI Class Initialized
INFO - 2023-04-23 08:59:16 --> Router Class Initialized
INFO - 2023-04-23 08:59:16 --> Output Class Initialized
INFO - 2023-04-23 08:59:16 --> Security Class Initialized
DEBUG - 2023-04-23 08:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:59:16 --> Input Class Initialized
INFO - 2023-04-23 08:59:16 --> Language Class Initialized
INFO - 2023-04-23 08:59:16 --> Loader Class Initialized
INFO - 2023-04-23 08:59:16 --> Controller Class Initialized
INFO - 2023-04-23 08:59:16 --> Helper loaded: form_helper
INFO - 2023-04-23 08:59:16 --> Helper loaded: url_helper
DEBUG - 2023-04-23 08:59:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:59:16 --> Database Driver Class Initialized
INFO - 2023-04-23 08:59:16 --> Model "Login_model" initialized
INFO - 2023-04-23 08:59:16 --> Final output sent to browser
DEBUG - 2023-04-23 08:59:16 --> Total execution time: 0.0433
INFO - 2023-04-23 08:59:27 --> Config Class Initialized
INFO - 2023-04-23 08:59:27 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:59:27 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:59:27 --> Utf8 Class Initialized
INFO - 2023-04-23 08:59:27 --> URI Class Initialized
INFO - 2023-04-23 08:59:27 --> Router Class Initialized
INFO - 2023-04-23 08:59:27 --> Output Class Initialized
INFO - 2023-04-23 08:59:27 --> Security Class Initialized
DEBUG - 2023-04-23 08:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:59:27 --> Input Class Initialized
INFO - 2023-04-23 08:59:27 --> Language Class Initialized
INFO - 2023-04-23 08:59:27 --> Loader Class Initialized
INFO - 2023-04-23 08:59:27 --> Controller Class Initialized
INFO - 2023-04-23 08:59:27 --> Helper loaded: form_helper
INFO - 2023-04-23 08:59:27 --> Helper loaded: url_helper
DEBUG - 2023-04-23 08:59:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:59:27 --> Final output sent to browser
DEBUG - 2023-04-23 08:59:27 --> Total execution time: 0.0045
INFO - 2023-04-23 08:59:27 --> Config Class Initialized
INFO - 2023-04-23 08:59:27 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:59:27 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:59:27 --> Utf8 Class Initialized
INFO - 2023-04-23 08:59:27 --> URI Class Initialized
INFO - 2023-04-23 08:59:27 --> Router Class Initialized
INFO - 2023-04-23 08:59:27 --> Output Class Initialized
INFO - 2023-04-23 08:59:27 --> Security Class Initialized
DEBUG - 2023-04-23 08:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:59:27 --> Input Class Initialized
INFO - 2023-04-23 08:59:27 --> Language Class Initialized
INFO - 2023-04-23 08:59:27 --> Loader Class Initialized
INFO - 2023-04-23 08:59:27 --> Controller Class Initialized
INFO - 2023-04-23 08:59:27 --> Helper loaded: form_helper
INFO - 2023-04-23 08:59:27 --> Helper loaded: url_helper
DEBUG - 2023-04-23 08:59:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:59:27 --> Database Driver Class Initialized
INFO - 2023-04-23 08:59:27 --> Model "Login_model" initialized
INFO - 2023-04-23 08:59:27 --> Final output sent to browser
DEBUG - 2023-04-23 08:59:27 --> Total execution time: 0.0275
INFO - 2023-04-23 08:59:34 --> Config Class Initialized
INFO - 2023-04-23 08:59:34 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:59:34 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:59:34 --> Utf8 Class Initialized
INFO - 2023-04-23 08:59:34 --> URI Class Initialized
INFO - 2023-04-23 08:59:34 --> Router Class Initialized
INFO - 2023-04-23 08:59:34 --> Output Class Initialized
INFO - 2023-04-23 08:59:34 --> Security Class Initialized
DEBUG - 2023-04-23 08:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:59:34 --> Input Class Initialized
INFO - 2023-04-23 08:59:34 --> Language Class Initialized
INFO - 2023-04-23 08:59:34 --> Loader Class Initialized
INFO - 2023-04-23 08:59:34 --> Controller Class Initialized
INFO - 2023-04-23 08:59:34 --> Helper loaded: form_helper
INFO - 2023-04-23 08:59:34 --> Helper loaded: url_helper
DEBUG - 2023-04-23 08:59:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:59:34 --> Model "Change_model" initialized
INFO - 2023-04-23 08:59:34 --> Model "Grafana_model" initialized
INFO - 2023-04-23 08:59:34 --> Final output sent to browser
DEBUG - 2023-04-23 08:59:34 --> Total execution time: 0.0720
INFO - 2023-04-23 08:59:34 --> Config Class Initialized
INFO - 2023-04-23 08:59:34 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:59:34 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:59:34 --> Utf8 Class Initialized
INFO - 2023-04-23 08:59:34 --> URI Class Initialized
INFO - 2023-04-23 08:59:34 --> Router Class Initialized
INFO - 2023-04-23 08:59:34 --> Output Class Initialized
INFO - 2023-04-23 08:59:34 --> Security Class Initialized
DEBUG - 2023-04-23 08:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:59:34 --> Input Class Initialized
INFO - 2023-04-23 08:59:34 --> Language Class Initialized
INFO - 2023-04-23 08:59:34 --> Loader Class Initialized
INFO - 2023-04-23 08:59:34 --> Controller Class Initialized
INFO - 2023-04-23 08:59:34 --> Helper loaded: form_helper
INFO - 2023-04-23 08:59:34 --> Helper loaded: url_helper
DEBUG - 2023-04-23 08:59:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:59:34 --> Final output sent to browser
DEBUG - 2023-04-23 08:59:34 --> Total execution time: 0.0018
INFO - 2023-04-23 08:59:34 --> Config Class Initialized
INFO - 2023-04-23 08:59:34 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:59:34 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:59:34 --> Utf8 Class Initialized
INFO - 2023-04-23 08:59:34 --> URI Class Initialized
INFO - 2023-04-23 08:59:34 --> Router Class Initialized
INFO - 2023-04-23 08:59:34 --> Output Class Initialized
INFO - 2023-04-23 08:59:34 --> Security Class Initialized
DEBUG - 2023-04-23 08:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:59:34 --> Input Class Initialized
INFO - 2023-04-23 08:59:34 --> Language Class Initialized
INFO - 2023-04-23 08:59:34 --> Loader Class Initialized
INFO - 2023-04-23 08:59:34 --> Controller Class Initialized
INFO - 2023-04-23 08:59:34 --> Helper loaded: form_helper
INFO - 2023-04-23 08:59:34 --> Helper loaded: url_helper
DEBUG - 2023-04-23 08:59:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:59:34 --> Database Driver Class Initialized
INFO - 2023-04-23 08:59:34 --> Model "Login_model" initialized
INFO - 2023-04-23 08:59:35 --> Final output sent to browser
DEBUG - 2023-04-23 08:59:35 --> Total execution time: 0.0222
INFO - 2023-04-23 08:59:35 --> Config Class Initialized
INFO - 2023-04-23 08:59:35 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:59:35 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:59:35 --> Utf8 Class Initialized
INFO - 2023-04-23 08:59:35 --> URI Class Initialized
INFO - 2023-04-23 08:59:35 --> Router Class Initialized
INFO - 2023-04-23 08:59:35 --> Output Class Initialized
INFO - 2023-04-23 08:59:35 --> Security Class Initialized
DEBUG - 2023-04-23 08:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:59:35 --> Input Class Initialized
INFO - 2023-04-23 08:59:35 --> Language Class Initialized
INFO - 2023-04-23 08:59:35 --> Loader Class Initialized
INFO - 2023-04-23 08:59:35 --> Controller Class Initialized
DEBUG - 2023-04-23 08:59:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:59:35 --> Database Driver Class Initialized
INFO - 2023-04-23 08:59:35 --> Model "Cluster_model" initialized
INFO - 2023-04-23 08:59:35 --> Final output sent to browser
DEBUG - 2023-04-23 08:59:35 --> Total execution time: 0.0156
INFO - 2023-04-23 08:59:35 --> Config Class Initialized
INFO - 2023-04-23 08:59:35 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:59:35 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:59:35 --> Utf8 Class Initialized
INFO - 2023-04-23 08:59:35 --> URI Class Initialized
INFO - 2023-04-23 08:59:35 --> Router Class Initialized
INFO - 2023-04-23 08:59:35 --> Output Class Initialized
INFO - 2023-04-23 08:59:35 --> Security Class Initialized
DEBUG - 2023-04-23 08:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:59:35 --> Input Class Initialized
INFO - 2023-04-23 08:59:35 --> Language Class Initialized
INFO - 2023-04-23 08:59:35 --> Loader Class Initialized
INFO - 2023-04-23 08:59:35 --> Controller Class Initialized
DEBUG - 2023-04-23 08:59:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:59:35 --> Database Driver Class Initialized
INFO - 2023-04-23 08:59:35 --> Model "Cluster_model" initialized
INFO - 2023-04-23 08:59:35 --> Final output sent to browser
DEBUG - 2023-04-23 08:59:35 --> Total execution time: 0.0207
INFO - 2023-04-23 08:59:35 --> Config Class Initialized
INFO - 2023-04-23 08:59:35 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:59:35 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:59:35 --> Utf8 Class Initialized
INFO - 2023-04-23 08:59:35 --> URI Class Initialized
INFO - 2023-04-23 08:59:35 --> Router Class Initialized
INFO - 2023-04-23 08:59:35 --> Output Class Initialized
INFO - 2023-04-23 08:59:35 --> Security Class Initialized
DEBUG - 2023-04-23 08:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:59:35 --> Input Class Initialized
INFO - 2023-04-23 08:59:35 --> Language Class Initialized
INFO - 2023-04-23 08:59:35 --> Loader Class Initialized
INFO - 2023-04-23 08:59:35 --> Controller Class Initialized
DEBUG - 2023-04-23 08:59:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:59:35 --> Database Driver Class Initialized
INFO - 2023-04-23 08:59:35 --> Model "Cluster_model" initialized
INFO - 2023-04-23 08:59:35 --> Database Driver Class Initialized
INFO - 2023-04-23 08:59:35 --> Model "Login_model" initialized
INFO - 2023-04-23 08:59:35 --> Final output sent to browser
DEBUG - 2023-04-23 08:59:35 --> Total execution time: 0.1182
INFO - 2023-04-23 08:59:35 --> Config Class Initialized
INFO - 2023-04-23 08:59:35 --> Hooks Class Initialized
DEBUG - 2023-04-23 08:59:35 --> UTF-8 Support Enabled
INFO - 2023-04-23 08:59:35 --> Utf8 Class Initialized
INFO - 2023-04-23 08:59:35 --> URI Class Initialized
INFO - 2023-04-23 08:59:35 --> Router Class Initialized
INFO - 2023-04-23 08:59:35 --> Output Class Initialized
INFO - 2023-04-23 08:59:35 --> Security Class Initialized
DEBUG - 2023-04-23 08:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 08:59:35 --> Input Class Initialized
INFO - 2023-04-23 08:59:35 --> Language Class Initialized
INFO - 2023-04-23 08:59:35 --> Loader Class Initialized
INFO - 2023-04-23 08:59:35 --> Controller Class Initialized
DEBUG - 2023-04-23 08:59:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 08:59:35 --> Database Driver Class Initialized
INFO - 2023-04-23 08:59:35 --> Model "Cluster_model" initialized
INFO - 2023-04-23 08:59:35 --> Database Driver Class Initialized
INFO - 2023-04-23 08:59:35 --> Model "Login_model" initialized
INFO - 2023-04-23 08:59:35 --> Final output sent to browser
DEBUG - 2023-04-23 08:59:35 --> Total execution time: 0.1329
INFO - 2023-04-23 09:02:39 --> Config Class Initialized
INFO - 2023-04-23 09:02:39 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:02:39 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:02:39 --> Utf8 Class Initialized
INFO - 2023-04-23 09:02:39 --> URI Class Initialized
INFO - 2023-04-23 09:02:39 --> Router Class Initialized
INFO - 2023-04-23 09:02:39 --> Output Class Initialized
INFO - 2023-04-23 09:02:39 --> Security Class Initialized
DEBUG - 2023-04-23 09:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:02:39 --> Input Class Initialized
INFO - 2023-04-23 09:02:39 --> Language Class Initialized
INFO - 2023-04-23 09:02:39 --> Loader Class Initialized
INFO - 2023-04-23 09:02:39 --> Controller Class Initialized
DEBUG - 2023-04-23 09:02:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:02:39 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:39 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:02:39 --> Final output sent to browser
DEBUG - 2023-04-23 09:02:39 --> Total execution time: 0.0140
INFO - 2023-04-23 09:02:39 --> Config Class Initialized
INFO - 2023-04-23 09:02:39 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:02:39 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:02:39 --> Utf8 Class Initialized
INFO - 2023-04-23 09:02:39 --> URI Class Initialized
INFO - 2023-04-23 09:02:39 --> Router Class Initialized
INFO - 2023-04-23 09:02:39 --> Output Class Initialized
INFO - 2023-04-23 09:02:39 --> Security Class Initialized
DEBUG - 2023-04-23 09:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:02:39 --> Input Class Initialized
INFO - 2023-04-23 09:02:39 --> Language Class Initialized
INFO - 2023-04-23 09:02:39 --> Loader Class Initialized
INFO - 2023-04-23 09:02:39 --> Controller Class Initialized
DEBUG - 2023-04-23 09:02:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:02:39 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:39 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:02:39 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:39 --> Model "Login_model" initialized
INFO - 2023-04-23 09:02:39 --> Final output sent to browser
DEBUG - 2023-04-23 09:02:39 --> Total execution time: 0.1008
INFO - 2023-04-23 09:02:39 --> Config Class Initialized
INFO - 2023-04-23 09:02:39 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:02:40 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:02:40 --> Utf8 Class Initialized
INFO - 2023-04-23 09:02:40 --> URI Class Initialized
INFO - 2023-04-23 09:02:40 --> Router Class Initialized
INFO - 2023-04-23 09:02:40 --> Output Class Initialized
INFO - 2023-04-23 09:02:40 --> Security Class Initialized
DEBUG - 2023-04-23 09:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:02:40 --> Input Class Initialized
INFO - 2023-04-23 09:02:40 --> Language Class Initialized
INFO - 2023-04-23 09:02:40 --> Loader Class Initialized
INFO - 2023-04-23 09:02:40 --> Controller Class Initialized
DEBUG - 2023-04-23 09:02:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:02:40 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:40 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:02:40 --> Final output sent to browser
DEBUG - 2023-04-23 09:02:40 --> Total execution time: 0.0925
INFO - 2023-04-23 09:02:40 --> Config Class Initialized
INFO - 2023-04-23 09:02:40 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:02:40 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:02:40 --> Utf8 Class Initialized
INFO - 2023-04-23 09:02:40 --> URI Class Initialized
INFO - 2023-04-23 09:02:40 --> Router Class Initialized
INFO - 2023-04-23 09:02:40 --> Output Class Initialized
INFO - 2023-04-23 09:02:40 --> Security Class Initialized
DEBUG - 2023-04-23 09:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:02:40 --> Input Class Initialized
INFO - 2023-04-23 09:02:40 --> Language Class Initialized
INFO - 2023-04-23 09:02:40 --> Loader Class Initialized
INFO - 2023-04-23 09:02:40 --> Controller Class Initialized
DEBUG - 2023-04-23 09:02:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:02:40 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:40 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:02:40 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:40 --> Model "Login_model" initialized
INFO - 2023-04-23 09:02:40 --> Final output sent to browser
DEBUG - 2023-04-23 09:02:40 --> Total execution time: 0.0227
INFO - 2023-04-23 09:02:43 --> Config Class Initialized
INFO - 2023-04-23 09:02:43 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:02:43 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:02:43 --> Utf8 Class Initialized
INFO - 2023-04-23 09:02:43 --> URI Class Initialized
INFO - 2023-04-23 09:02:43 --> Router Class Initialized
INFO - 2023-04-23 09:02:43 --> Output Class Initialized
INFO - 2023-04-23 09:02:43 --> Security Class Initialized
DEBUG - 2023-04-23 09:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:02:43 --> Input Class Initialized
INFO - 2023-04-23 09:02:43 --> Language Class Initialized
INFO - 2023-04-23 09:02:43 --> Loader Class Initialized
INFO - 2023-04-23 09:02:43 --> Controller Class Initialized
DEBUG - 2023-04-23 09:02:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:02:43 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:43 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:02:43 --> Final output sent to browser
DEBUG - 2023-04-23 09:02:43 --> Total execution time: 0.0129
INFO - 2023-04-23 09:02:43 --> Config Class Initialized
INFO - 2023-04-23 09:02:43 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:02:43 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:02:43 --> Utf8 Class Initialized
INFO - 2023-04-23 09:02:43 --> URI Class Initialized
INFO - 2023-04-23 09:02:43 --> Router Class Initialized
INFO - 2023-04-23 09:02:43 --> Output Class Initialized
INFO - 2023-04-23 09:02:43 --> Security Class Initialized
DEBUG - 2023-04-23 09:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:02:43 --> Input Class Initialized
INFO - 2023-04-23 09:02:43 --> Language Class Initialized
INFO - 2023-04-23 09:02:43 --> Loader Class Initialized
INFO - 2023-04-23 09:02:43 --> Controller Class Initialized
DEBUG - 2023-04-23 09:02:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:02:43 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:43 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:02:43 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:43 --> Model "Login_model" initialized
INFO - 2023-04-23 09:02:43 --> Final output sent to browser
DEBUG - 2023-04-23 09:02:43 --> Total execution time: 0.0768
INFO - 2023-04-23 09:02:47 --> Config Class Initialized
INFO - 2023-04-23 09:02:47 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:02:47 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:02:47 --> Utf8 Class Initialized
INFO - 2023-04-23 09:02:47 --> URI Class Initialized
INFO - 2023-04-23 09:02:47 --> Router Class Initialized
INFO - 2023-04-23 09:02:47 --> Output Class Initialized
INFO - 2023-04-23 09:02:47 --> Security Class Initialized
DEBUG - 2023-04-23 09:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:02:47 --> Input Class Initialized
INFO - 2023-04-23 09:02:47 --> Language Class Initialized
INFO - 2023-04-23 09:02:47 --> Loader Class Initialized
INFO - 2023-04-23 09:02:47 --> Controller Class Initialized
DEBUG - 2023-04-23 09:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:02:47 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:47 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:02:47 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:47 --> Model "Login_model" initialized
INFO - 2023-04-23 09:02:47 --> Final output sent to browser
DEBUG - 2023-04-23 09:02:47 --> Total execution time: 0.0388
INFO - 2023-04-23 09:02:56 --> Config Class Initialized
INFO - 2023-04-23 09:02:56 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:02:56 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:02:56 --> Utf8 Class Initialized
INFO - 2023-04-23 09:02:56 --> URI Class Initialized
INFO - 2023-04-23 09:02:56 --> Router Class Initialized
INFO - 2023-04-23 09:02:56 --> Output Class Initialized
INFO - 2023-04-23 09:02:56 --> Security Class Initialized
DEBUG - 2023-04-23 09:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:02:56 --> Input Class Initialized
INFO - 2023-04-23 09:02:56 --> Language Class Initialized
INFO - 2023-04-23 09:02:56 --> Loader Class Initialized
INFO - 2023-04-23 09:02:56 --> Controller Class Initialized
DEBUG - 2023-04-23 09:02:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:02:56 --> Final output sent to browser
DEBUG - 2023-04-23 09:02:56 --> Total execution time: 0.0085
INFO - 2023-04-23 09:02:56 --> Config Class Initialized
INFO - 2023-04-23 09:02:56 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:02:56 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:02:56 --> Utf8 Class Initialized
INFO - 2023-04-23 09:02:56 --> URI Class Initialized
INFO - 2023-04-23 09:02:56 --> Router Class Initialized
INFO - 2023-04-23 09:02:56 --> Output Class Initialized
INFO - 2023-04-23 09:02:56 --> Security Class Initialized
DEBUG - 2023-04-23 09:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:02:56 --> Input Class Initialized
INFO - 2023-04-23 09:02:56 --> Language Class Initialized
INFO - 2023-04-23 09:02:56 --> Loader Class Initialized
INFO - 2023-04-23 09:02:56 --> Controller Class Initialized
DEBUG - 2023-04-23 09:02:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:02:56 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:57 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:02:57 --> Model "Mysql_model" initialized
INFO - 2023-04-23 09:02:57 --> Model "Grafana_model" initialized
INFO - 2023-04-23 09:02:57 --> Final output sent to browser
DEBUG - 2023-04-23 09:02:57 --> Total execution time: 0.0213
INFO - 2023-04-23 09:02:59 --> Config Class Initialized
INFO - 2023-04-23 09:02:59 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:02:59 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:02:59 --> Utf8 Class Initialized
INFO - 2023-04-23 09:02:59 --> URI Class Initialized
INFO - 2023-04-23 09:02:59 --> Router Class Initialized
INFO - 2023-04-23 09:02:59 --> Output Class Initialized
INFO - 2023-04-23 09:02:59 --> Security Class Initialized
DEBUG - 2023-04-23 09:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:02:59 --> Input Class Initialized
INFO - 2023-04-23 09:02:59 --> Language Class Initialized
INFO - 2023-04-23 09:02:59 --> Loader Class Initialized
INFO - 2023-04-23 09:02:59 --> Controller Class Initialized
DEBUG - 2023-04-23 09:02:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:02:59 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:59 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:02:59 --> Database Driver Class Initialized
INFO - 2023-04-23 09:02:59 --> Model "Login_model" initialized
INFO - 2023-04-23 09:02:59 --> Final output sent to browser
DEBUG - 2023-04-23 09:02:59 --> Total execution time: 0.1117
INFO - 2023-04-23 09:02:59 --> Config Class Initialized
INFO - 2023-04-23 09:03:00 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:00 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:00 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:00 --> URI Class Initialized
INFO - 2023-04-23 09:03:00 --> Router Class Initialized
INFO - 2023-04-23 09:03:00 --> Output Class Initialized
INFO - 2023-04-23 09:03:00 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:00 --> Input Class Initialized
INFO - 2023-04-23 09:03:00 --> Language Class Initialized
INFO - 2023-04-23 09:03:00 --> Loader Class Initialized
INFO - 2023-04-23 09:03:00 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:00 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:00 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:00 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:00 --> Model "Login_model" initialized
INFO - 2023-04-23 09:03:00 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:00 --> Total execution time: 0.0997
INFO - 2023-04-23 09:03:03 --> Config Class Initialized
INFO - 2023-04-23 09:03:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:03 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:03 --> URI Class Initialized
INFO - 2023-04-23 09:03:03 --> Router Class Initialized
INFO - 2023-04-23 09:03:03 --> Output Class Initialized
INFO - 2023-04-23 09:03:03 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:03 --> Input Class Initialized
INFO - 2023-04-23 09:03:03 --> Language Class Initialized
INFO - 2023-04-23 09:03:03 --> Loader Class Initialized
INFO - 2023-04-23 09:03:03 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:03 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:03 --> Total execution time: 0.0041
INFO - 2023-04-23 09:03:03 --> Config Class Initialized
INFO - 2023-04-23 09:03:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:03 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:03 --> URI Class Initialized
INFO - 2023-04-23 09:03:03 --> Router Class Initialized
INFO - 2023-04-23 09:03:03 --> Output Class Initialized
INFO - 2023-04-23 09:03:03 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:03 --> Input Class Initialized
INFO - 2023-04-23 09:03:03 --> Language Class Initialized
INFO - 2023-04-23 09:03:03 --> Loader Class Initialized
INFO - 2023-04-23 09:03:03 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:03 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:03 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:03 --> Model "Mysql_model" initialized
INFO - 2023-04-23 09:03:03 --> Model "Grafana_model" initialized
INFO - 2023-04-23 09:03:03 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:03 --> Total execution time: 0.0151
INFO - 2023-04-23 09:03:04 --> Config Class Initialized
INFO - 2023-04-23 09:03:04 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:04 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:04 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:04 --> URI Class Initialized
INFO - 2023-04-23 09:03:04 --> Router Class Initialized
INFO - 2023-04-23 09:03:04 --> Output Class Initialized
INFO - 2023-04-23 09:03:04 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:04 --> Input Class Initialized
INFO - 2023-04-23 09:03:04 --> Language Class Initialized
INFO - 2023-04-23 09:03:04 --> Loader Class Initialized
INFO - 2023-04-23 09:03:04 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:04 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:04 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:04 --> Model "Mysql_model" initialized
INFO - 2023-04-23 09:03:04 --> Model "Grafana_model" initialized
INFO - 2023-04-23 09:03:04 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:04 --> Total execution time: 0.0160
INFO - 2023-04-23 09:03:08 --> Config Class Initialized
INFO - 2023-04-23 09:03:08 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:08 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:08 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:08 --> URI Class Initialized
INFO - 2023-04-23 09:03:08 --> Router Class Initialized
INFO - 2023-04-23 09:03:08 --> Output Class Initialized
INFO - 2023-04-23 09:03:08 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:08 --> Input Class Initialized
INFO - 2023-04-23 09:03:08 --> Language Class Initialized
INFO - 2023-04-23 09:03:08 --> Loader Class Initialized
INFO - 2023-04-23 09:03:08 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:08 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:08 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:08 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:08 --> Total execution time: 0.0419
INFO - 2023-04-23 09:03:08 --> Config Class Initialized
INFO - 2023-04-23 09:03:08 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:08 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:08 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:08 --> URI Class Initialized
INFO - 2023-04-23 09:03:08 --> Router Class Initialized
INFO - 2023-04-23 09:03:08 --> Output Class Initialized
INFO - 2023-04-23 09:03:08 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:08 --> Input Class Initialized
INFO - 2023-04-23 09:03:08 --> Language Class Initialized
INFO - 2023-04-23 09:03:08 --> Loader Class Initialized
INFO - 2023-04-23 09:03:08 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:08 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:08 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:08 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:08 --> Total execution time: 0.0526
INFO - 2023-04-23 09:03:10 --> Config Class Initialized
INFO - 2023-04-23 09:03:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:10 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:10 --> URI Class Initialized
INFO - 2023-04-23 09:03:10 --> Router Class Initialized
INFO - 2023-04-23 09:03:10 --> Output Class Initialized
INFO - 2023-04-23 09:03:10 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:10 --> Input Class Initialized
INFO - 2023-04-23 09:03:10 --> Language Class Initialized
INFO - 2023-04-23 09:03:10 --> Loader Class Initialized
INFO - 2023-04-23 09:03:10 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:10 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:10 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:10 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:10 --> Total execution time: 0.0120
INFO - 2023-04-23 09:03:10 --> Config Class Initialized
INFO - 2023-04-23 09:03:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:10 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:10 --> URI Class Initialized
INFO - 2023-04-23 09:03:10 --> Router Class Initialized
INFO - 2023-04-23 09:03:10 --> Output Class Initialized
INFO - 2023-04-23 09:03:10 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:10 --> Input Class Initialized
INFO - 2023-04-23 09:03:10 --> Language Class Initialized
INFO - 2023-04-23 09:03:10 --> Loader Class Initialized
INFO - 2023-04-23 09:03:10 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:10 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:10 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:10 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:10 --> Model "Login_model" initialized
INFO - 2023-04-23 09:03:10 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:10 --> Total execution time: 0.0212
INFO - 2023-04-23 09:03:10 --> Config Class Initialized
INFO - 2023-04-23 09:03:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:10 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:10 --> URI Class Initialized
INFO - 2023-04-23 09:03:10 --> Router Class Initialized
INFO - 2023-04-23 09:03:10 --> Output Class Initialized
INFO - 2023-04-23 09:03:10 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:10 --> Input Class Initialized
INFO - 2023-04-23 09:03:10 --> Language Class Initialized
INFO - 2023-04-23 09:03:10 --> Loader Class Initialized
INFO - 2023-04-23 09:03:10 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:10 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:10 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:10 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:10 --> Total execution time: 0.0084
INFO - 2023-04-23 09:03:10 --> Config Class Initialized
INFO - 2023-04-23 09:03:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:10 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:10 --> URI Class Initialized
INFO - 2023-04-23 09:03:10 --> Router Class Initialized
INFO - 2023-04-23 09:03:10 --> Output Class Initialized
INFO - 2023-04-23 09:03:10 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:10 --> Input Class Initialized
INFO - 2023-04-23 09:03:10 --> Language Class Initialized
INFO - 2023-04-23 09:03:10 --> Loader Class Initialized
INFO - 2023-04-23 09:03:10 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:10 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:10 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:10 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:10 --> Model "Login_model" initialized
INFO - 2023-04-23 09:03:10 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:10 --> Total execution time: 0.0847
INFO - 2023-04-23 09:03:11 --> Config Class Initialized
INFO - 2023-04-23 09:03:11 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:11 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:11 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:11 --> URI Class Initialized
INFO - 2023-04-23 09:03:11 --> Router Class Initialized
INFO - 2023-04-23 09:03:11 --> Output Class Initialized
INFO - 2023-04-23 09:03:11 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:11 --> Input Class Initialized
INFO - 2023-04-23 09:03:11 --> Language Class Initialized
INFO - 2023-04-23 09:03:11 --> Loader Class Initialized
INFO - 2023-04-23 09:03:11 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:11 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:11 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:11 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:11 --> Model "Login_model" initialized
INFO - 2023-04-23 09:03:11 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:11 --> Total execution time: 0.0720
INFO - 2023-04-23 09:03:11 --> Config Class Initialized
INFO - 2023-04-23 09:03:11 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:11 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:11 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:11 --> URI Class Initialized
INFO - 2023-04-23 09:03:11 --> Router Class Initialized
INFO - 2023-04-23 09:03:11 --> Output Class Initialized
INFO - 2023-04-23 09:03:11 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:11 --> Input Class Initialized
INFO - 2023-04-23 09:03:11 --> Language Class Initialized
INFO - 2023-04-23 09:03:11 --> Loader Class Initialized
INFO - 2023-04-23 09:03:11 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:11 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:11 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:11 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:11 --> Model "Login_model" initialized
INFO - 2023-04-23 09:03:11 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:11 --> Total execution time: 0.0674
INFO - 2023-04-23 09:03:12 --> Config Class Initialized
INFO - 2023-04-23 09:03:12 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:12 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:12 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:12 --> URI Class Initialized
INFO - 2023-04-23 09:03:12 --> Router Class Initialized
INFO - 2023-04-23 09:03:12 --> Output Class Initialized
INFO - 2023-04-23 09:03:12 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:12 --> Input Class Initialized
INFO - 2023-04-23 09:03:12 --> Language Class Initialized
INFO - 2023-04-23 09:03:12 --> Loader Class Initialized
INFO - 2023-04-23 09:03:12 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:12 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:12 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:12 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:12 --> Total execution time: 0.0727
INFO - 2023-04-23 09:03:12 --> Config Class Initialized
INFO - 2023-04-23 09:03:12 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:12 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:12 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:12 --> URI Class Initialized
INFO - 2023-04-23 09:03:12 --> Router Class Initialized
INFO - 2023-04-23 09:03:12 --> Output Class Initialized
INFO - 2023-04-23 09:03:12 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:12 --> Input Class Initialized
INFO - 2023-04-23 09:03:12 --> Language Class Initialized
INFO - 2023-04-23 09:03:12 --> Loader Class Initialized
INFO - 2023-04-23 09:03:12 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:12 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:12 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:12 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:12 --> Total execution time: 0.0509
INFO - 2023-04-23 09:03:12 --> Config Class Initialized
INFO - 2023-04-23 09:03:12 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:12 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:12 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:12 --> URI Class Initialized
INFO - 2023-04-23 09:03:12 --> Router Class Initialized
INFO - 2023-04-23 09:03:12 --> Output Class Initialized
INFO - 2023-04-23 09:03:12 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:12 --> Input Class Initialized
INFO - 2023-04-23 09:03:12 --> Language Class Initialized
INFO - 2023-04-23 09:03:12 --> Loader Class Initialized
INFO - 2023-04-23 09:03:12 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:12 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:12 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:12 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:12 --> Total execution time: 0.0540
INFO - 2023-04-23 09:03:12 --> Config Class Initialized
INFO - 2023-04-23 09:03:12 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:12 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:12 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:12 --> URI Class Initialized
INFO - 2023-04-23 09:03:12 --> Router Class Initialized
INFO - 2023-04-23 09:03:12 --> Output Class Initialized
INFO - 2023-04-23 09:03:12 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:12 --> Input Class Initialized
INFO - 2023-04-23 09:03:12 --> Language Class Initialized
INFO - 2023-04-23 09:03:12 --> Loader Class Initialized
INFO - 2023-04-23 09:03:12 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:12 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:12 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:12 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:12 --> Total execution time: 0.0552
INFO - 2023-04-23 09:03:24 --> Config Class Initialized
INFO - 2023-04-23 09:03:24 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:24 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:24 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:24 --> URI Class Initialized
INFO - 2023-04-23 09:03:24 --> Router Class Initialized
INFO - 2023-04-23 09:03:24 --> Output Class Initialized
INFO - 2023-04-23 09:03:24 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:24 --> Input Class Initialized
INFO - 2023-04-23 09:03:24 --> Language Class Initialized
INFO - 2023-04-23 09:03:24 --> Loader Class Initialized
INFO - 2023-04-23 09:03:24 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:24 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:24 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:24 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:24 --> Model "Login_model" initialized
INFO - 2023-04-23 09:03:24 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:24 --> Total execution time: 0.1749
INFO - 2023-04-23 09:03:24 --> Config Class Initialized
INFO - 2023-04-23 09:03:24 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:03:24 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:03:24 --> Utf8 Class Initialized
INFO - 2023-04-23 09:03:24 --> URI Class Initialized
INFO - 2023-04-23 09:03:24 --> Router Class Initialized
INFO - 2023-04-23 09:03:24 --> Output Class Initialized
INFO - 2023-04-23 09:03:24 --> Security Class Initialized
DEBUG - 2023-04-23 09:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:03:24 --> Input Class Initialized
INFO - 2023-04-23 09:03:24 --> Language Class Initialized
INFO - 2023-04-23 09:03:24 --> Loader Class Initialized
INFO - 2023-04-23 09:03:24 --> Controller Class Initialized
DEBUG - 2023-04-23 09:03:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:03:24 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:24 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:03:24 --> Database Driver Class Initialized
INFO - 2023-04-23 09:03:24 --> Model "Login_model" initialized
INFO - 2023-04-23 09:03:24 --> Final output sent to browser
DEBUG - 2023-04-23 09:03:24 --> Total execution time: 0.0725
INFO - 2023-04-23 09:04:03 --> Config Class Initialized
INFO - 2023-04-23 09:04:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:03 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:03 --> URI Class Initialized
INFO - 2023-04-23 09:04:03 --> Router Class Initialized
INFO - 2023-04-23 09:04:03 --> Output Class Initialized
INFO - 2023-04-23 09:04:03 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:03 --> Input Class Initialized
INFO - 2023-04-23 09:04:03 --> Language Class Initialized
INFO - 2023-04-23 09:04:03 --> Loader Class Initialized
INFO - 2023-04-23 09:04:03 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:03 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:03 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:03 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:03 --> Total execution time: 0.0194
INFO - 2023-04-23 09:04:03 --> Config Class Initialized
INFO - 2023-04-23 09:04:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:03 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:03 --> URI Class Initialized
INFO - 2023-04-23 09:04:03 --> Router Class Initialized
INFO - 2023-04-23 09:04:03 --> Output Class Initialized
INFO - 2023-04-23 09:04:03 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:03 --> Input Class Initialized
INFO - 2023-04-23 09:04:03 --> Language Class Initialized
INFO - 2023-04-23 09:04:03 --> Loader Class Initialized
INFO - 2023-04-23 09:04:03 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:03 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:03 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:03 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:03 --> Total execution time: 0.0571
INFO - 2023-04-23 09:04:05 --> Config Class Initialized
INFO - 2023-04-23 09:04:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:05 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:05 --> URI Class Initialized
INFO - 2023-04-23 09:04:05 --> Router Class Initialized
INFO - 2023-04-23 09:04:05 --> Output Class Initialized
INFO - 2023-04-23 09:04:05 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:05 --> Input Class Initialized
INFO - 2023-04-23 09:04:05 --> Language Class Initialized
INFO - 2023-04-23 09:04:05 --> Loader Class Initialized
INFO - 2023-04-23 09:04:05 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:05 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:05 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:05 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:05 --> Total execution time: 0.0183
INFO - 2023-04-23 09:04:05 --> Config Class Initialized
INFO - 2023-04-23 09:04:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:05 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:05 --> URI Class Initialized
INFO - 2023-04-23 09:04:05 --> Router Class Initialized
INFO - 2023-04-23 09:04:05 --> Output Class Initialized
INFO - 2023-04-23 09:04:05 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:05 --> Input Class Initialized
INFO - 2023-04-23 09:04:05 --> Language Class Initialized
INFO - 2023-04-23 09:04:05 --> Loader Class Initialized
INFO - 2023-04-23 09:04:05 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:05 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:05 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:05 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:05 --> Total execution time: 0.0545
INFO - 2023-04-23 09:04:07 --> Config Class Initialized
INFO - 2023-04-23 09:04:07 --> Hooks Class Initialized
INFO - 2023-04-23 09:04:07 --> Config Class Initialized
INFO - 2023-04-23 09:04:07 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:04:07 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:07 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:07 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:07 --> URI Class Initialized
INFO - 2023-04-23 09:04:07 --> URI Class Initialized
INFO - 2023-04-23 09:04:07 --> Router Class Initialized
INFO - 2023-04-23 09:04:07 --> Router Class Initialized
INFO - 2023-04-23 09:04:07 --> Output Class Initialized
INFO - 2023-04-23 09:04:07 --> Output Class Initialized
INFO - 2023-04-23 09:04:07 --> Security Class Initialized
INFO - 2023-04-23 09:04:07 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:07 --> Input Class Initialized
INFO - 2023-04-23 09:04:07 --> Input Class Initialized
INFO - 2023-04-23 09:04:07 --> Language Class Initialized
INFO - 2023-04-23 09:04:07 --> Language Class Initialized
INFO - 2023-04-23 09:04:07 --> Loader Class Initialized
INFO - 2023-04-23 09:04:07 --> Loader Class Initialized
INFO - 2023-04-23 09:04:07 --> Controller Class Initialized
INFO - 2023-04-23 09:04:07 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 09:04:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:07 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:07 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:07 --> Total execution time: 0.0051
INFO - 2023-04-23 09:04:07 --> Config Class Initialized
INFO - 2023-04-23 09:04:07 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:07 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:07 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:07 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:07 --> URI Class Initialized
INFO - 2023-04-23 09:04:07 --> Router Class Initialized
INFO - 2023-04-23 09:04:07 --> Output Class Initialized
INFO - 2023-04-23 09:04:07 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:07 --> Input Class Initialized
INFO - 2023-04-23 09:04:07 --> Language Class Initialized
INFO - 2023-04-23 09:04:07 --> Loader Class Initialized
INFO - 2023-04-23 09:04:07 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:07 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:07 --> Model "Login_model" initialized
INFO - 2023-04-23 09:04:07 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:07 --> Total execution time: 0.1091
INFO - 2023-04-23 09:04:07 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:07 --> Config Class Initialized
INFO - 2023-04-23 09:04:07 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:07 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:07 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:07 --> URI Class Initialized
INFO - 2023-04-23 09:04:07 --> Router Class Initialized
INFO - 2023-04-23 09:04:07 --> Output Class Initialized
INFO - 2023-04-23 09:04:07 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:07 --> Input Class Initialized
INFO - 2023-04-23 09:04:07 --> Language Class Initialized
INFO - 2023-04-23 09:04:07 --> Loader Class Initialized
INFO - 2023-04-23 09:04:07 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:07 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:07 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:07 --> Final output sent to browser
INFO - 2023-04-23 09:04:07 --> Model "Cluster_model" initialized
DEBUG - 2023-04-23 09:04:07 --> Total execution time: 0.1144
INFO - 2023-04-23 09:04:08 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:08 --> Total execution time: 0.0945
INFO - 2023-04-23 09:04:10 --> Config Class Initialized
INFO - 2023-04-23 09:04:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:10 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:10 --> URI Class Initialized
INFO - 2023-04-23 09:04:10 --> Router Class Initialized
INFO - 2023-04-23 09:04:10 --> Output Class Initialized
INFO - 2023-04-23 09:04:10 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:10 --> Input Class Initialized
INFO - 2023-04-23 09:04:10 --> Language Class Initialized
INFO - 2023-04-23 09:04:10 --> Loader Class Initialized
INFO - 2023-04-23 09:04:10 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:10 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:10 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:10 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:10 --> Model "Login_model" initialized
INFO - 2023-04-23 09:04:10 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:10 --> Total execution time: 0.0840
INFO - 2023-04-23 09:04:10 --> Config Class Initialized
INFO - 2023-04-23 09:04:10 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:10 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:10 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:10 --> URI Class Initialized
INFO - 2023-04-23 09:04:10 --> Router Class Initialized
INFO - 2023-04-23 09:04:10 --> Output Class Initialized
INFO - 2023-04-23 09:04:10 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:10 --> Input Class Initialized
INFO - 2023-04-23 09:04:10 --> Language Class Initialized
INFO - 2023-04-23 09:04:10 --> Loader Class Initialized
INFO - 2023-04-23 09:04:10 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:10 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:10 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:10 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:10 --> Model "Login_model" initialized
INFO - 2023-04-23 09:04:10 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:10 --> Total execution time: 0.0734
INFO - 2023-04-23 09:04:21 --> Config Class Initialized
INFO - 2023-04-23 09:04:21 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:21 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:21 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:21 --> URI Class Initialized
INFO - 2023-04-23 09:04:21 --> Router Class Initialized
INFO - 2023-04-23 09:04:21 --> Output Class Initialized
INFO - 2023-04-23 09:04:21 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:21 --> Input Class Initialized
INFO - 2023-04-23 09:04:21 --> Language Class Initialized
INFO - 2023-04-23 09:04:21 --> Loader Class Initialized
INFO - 2023-04-23 09:04:21 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:21 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:21 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:21 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:21 --> Total execution time: 0.0175
INFO - 2023-04-23 09:04:21 --> Config Class Initialized
INFO - 2023-04-23 09:04:21 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:21 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:21 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:21 --> URI Class Initialized
INFO - 2023-04-23 09:04:21 --> Router Class Initialized
INFO - 2023-04-23 09:04:21 --> Output Class Initialized
INFO - 2023-04-23 09:04:21 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:21 --> Input Class Initialized
INFO - 2023-04-23 09:04:21 --> Language Class Initialized
INFO - 2023-04-23 09:04:21 --> Loader Class Initialized
INFO - 2023-04-23 09:04:21 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:21 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:21 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:21 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:21 --> Total execution time: 0.0173
INFO - 2023-04-23 09:04:23 --> Config Class Initialized
INFO - 2023-04-23 09:04:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:23 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:23 --> URI Class Initialized
INFO - 2023-04-23 09:04:23 --> Router Class Initialized
INFO - 2023-04-23 09:04:23 --> Output Class Initialized
INFO - 2023-04-23 09:04:23 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:23 --> Input Class Initialized
INFO - 2023-04-23 09:04:23 --> Language Class Initialized
INFO - 2023-04-23 09:04:23 --> Loader Class Initialized
INFO - 2023-04-23 09:04:23 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:23 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:23 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:23 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:23 --> Total execution time: 0.0296
INFO - 2023-04-23 09:04:23 --> Config Class Initialized
INFO - 2023-04-23 09:04:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:23 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:23 --> URI Class Initialized
INFO - 2023-04-23 09:04:23 --> Router Class Initialized
INFO - 2023-04-23 09:04:23 --> Output Class Initialized
INFO - 2023-04-23 09:04:23 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:23 --> Input Class Initialized
INFO - 2023-04-23 09:04:23 --> Language Class Initialized
INFO - 2023-04-23 09:04:23 --> Loader Class Initialized
INFO - 2023-04-23 09:04:23 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:23 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:23 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:23 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:23 --> Total execution time: 0.0165
INFO - 2023-04-23 09:04:26 --> Config Class Initialized
INFO - 2023-04-23 09:04:26 --> Hooks Class Initialized
INFO - 2023-04-23 09:04:26 --> Config Class Initialized
INFO - 2023-04-23 09:04:26 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:26 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:26 --> Utf8 Class Initialized
DEBUG - 2023-04-23 09:04:26 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:26 --> URI Class Initialized
INFO - 2023-04-23 09:04:26 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:26 --> Router Class Initialized
INFO - 2023-04-23 09:04:26 --> URI Class Initialized
INFO - 2023-04-23 09:04:26 --> Output Class Initialized
INFO - 2023-04-23 09:04:26 --> Router Class Initialized
INFO - 2023-04-23 09:04:26 --> Security Class Initialized
INFO - 2023-04-23 09:04:26 --> Output Class Initialized
DEBUG - 2023-04-23 09:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:26 --> Security Class Initialized
INFO - 2023-04-23 09:04:26 --> Input Class Initialized
DEBUG - 2023-04-23 09:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:26 --> Language Class Initialized
INFO - 2023-04-23 09:04:26 --> Input Class Initialized
INFO - 2023-04-23 09:04:26 --> Loader Class Initialized
INFO - 2023-04-23 09:04:26 --> Language Class Initialized
INFO - 2023-04-23 09:04:26 --> Controller Class Initialized
INFO - 2023-04-23 09:04:26 --> Loader Class Initialized
DEBUG - 2023-04-23 09:04:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:26 --> Controller Class Initialized
INFO - 2023-04-23 09:04:26 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 09:04:26 --> Total execution time: 0.0332
INFO - 2023-04-23 09:04:26 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:26 --> Config Class Initialized
INFO - 2023-04-23 09:04:26 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:26 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:26 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:26 --> URI Class Initialized
INFO - 2023-04-23 09:04:26 --> Router Class Initialized
INFO - 2023-04-23 09:04:26 --> Output Class Initialized
INFO - 2023-04-23 09:04:26 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:26 --> Input Class Initialized
INFO - 2023-04-23 09:04:26 --> Language Class Initialized
INFO - 2023-04-23 09:04:26 --> Loader Class Initialized
INFO - 2023-04-23 09:04:26 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:26 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:26 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:26 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:26 --> Total execution time: 0.0298
INFO - 2023-04-23 09:04:26 --> Config Class Initialized
INFO - 2023-04-23 09:04:26 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:26 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:26 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:26 --> URI Class Initialized
INFO - 2023-04-23 09:04:26 --> Router Class Initialized
INFO - 2023-04-23 09:04:26 --> Output Class Initialized
INFO - 2023-04-23 09:04:26 --> Security Class Initialized
INFO - 2023-04-23 09:04:26 --> Model "Login_model" initialized
DEBUG - 2023-04-23 09:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:26 --> Input Class Initialized
INFO - 2023-04-23 09:04:26 --> Language Class Initialized
INFO - 2023-04-23 09:04:26 --> Loader Class Initialized
INFO - 2023-04-23 09:04:26 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:26 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:26 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:26 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:26 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:26 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:26 --> Total execution time: 0.0244
INFO - 2023-04-23 09:04:26 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:26 --> Total execution time: 0.0181
INFO - 2023-04-23 09:04:29 --> Config Class Initialized
INFO - 2023-04-23 09:04:29 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:29 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:29 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:29 --> URI Class Initialized
INFO - 2023-04-23 09:04:29 --> Router Class Initialized
INFO - 2023-04-23 09:04:29 --> Output Class Initialized
INFO - 2023-04-23 09:04:29 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:29 --> Input Class Initialized
INFO - 2023-04-23 09:04:29 --> Language Class Initialized
INFO - 2023-04-23 09:04:29 --> Loader Class Initialized
INFO - 2023-04-23 09:04:29 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:29 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:29 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:29 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:29 --> Model "Login_model" initialized
INFO - 2023-04-23 09:04:29 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:29 --> Total execution time: 0.0839
INFO - 2023-04-23 09:04:29 --> Config Class Initialized
INFO - 2023-04-23 09:04:29 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:29 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:29 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:29 --> URI Class Initialized
INFO - 2023-04-23 09:04:29 --> Router Class Initialized
INFO - 2023-04-23 09:04:29 --> Output Class Initialized
INFO - 2023-04-23 09:04:29 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:29 --> Input Class Initialized
INFO - 2023-04-23 09:04:29 --> Language Class Initialized
INFO - 2023-04-23 09:04:29 --> Loader Class Initialized
INFO - 2023-04-23 09:04:29 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:29 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:29 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:29 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:29 --> Model "Login_model" initialized
INFO - 2023-04-23 09:04:29 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:29 --> Total execution time: 0.0782
INFO - 2023-04-23 09:04:32 --> Config Class Initialized
INFO - 2023-04-23 09:04:32 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:32 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:32 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:32 --> URI Class Initialized
INFO - 2023-04-23 09:04:32 --> Router Class Initialized
INFO - 2023-04-23 09:04:32 --> Output Class Initialized
INFO - 2023-04-23 09:04:32 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:32 --> Input Class Initialized
INFO - 2023-04-23 09:04:32 --> Language Class Initialized
INFO - 2023-04-23 09:04:32 --> Loader Class Initialized
INFO - 2023-04-23 09:04:32 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:32 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:32 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:32 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:32 --> Total execution time: 0.0145
INFO - 2023-04-23 09:04:32 --> Config Class Initialized
INFO - 2023-04-23 09:04:32 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:32 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:32 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:32 --> URI Class Initialized
INFO - 2023-04-23 09:04:32 --> Router Class Initialized
INFO - 2023-04-23 09:04:32 --> Output Class Initialized
INFO - 2023-04-23 09:04:32 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:32 --> Input Class Initialized
INFO - 2023-04-23 09:04:32 --> Language Class Initialized
INFO - 2023-04-23 09:04:32 --> Loader Class Initialized
INFO - 2023-04-23 09:04:32 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:32 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:32 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:32 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:32 --> Total execution time: 0.0124
INFO - 2023-04-23 09:04:32 --> Config Class Initialized
INFO - 2023-04-23 09:04:32 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:32 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:32 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:32 --> URI Class Initialized
INFO - 2023-04-23 09:04:32 --> Router Class Initialized
INFO - 2023-04-23 09:04:32 --> Output Class Initialized
INFO - 2023-04-23 09:04:32 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:32 --> Input Class Initialized
INFO - 2023-04-23 09:04:32 --> Language Class Initialized
INFO - 2023-04-23 09:04:32 --> Loader Class Initialized
INFO - 2023-04-23 09:04:32 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:32 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:32 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:32 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:32 --> Total execution time: 0.0536
INFO - 2023-04-23 09:04:32 --> Config Class Initialized
INFO - 2023-04-23 09:04:32 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:04:32 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:04:32 --> Utf8 Class Initialized
INFO - 2023-04-23 09:04:32 --> URI Class Initialized
INFO - 2023-04-23 09:04:32 --> Router Class Initialized
INFO - 2023-04-23 09:04:32 --> Output Class Initialized
INFO - 2023-04-23 09:04:32 --> Security Class Initialized
DEBUG - 2023-04-23 09:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:04:32 --> Input Class Initialized
INFO - 2023-04-23 09:04:32 --> Language Class Initialized
INFO - 2023-04-23 09:04:32 --> Loader Class Initialized
INFO - 2023-04-23 09:04:32 --> Controller Class Initialized
DEBUG - 2023-04-23 09:04:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:04:32 --> Database Driver Class Initialized
INFO - 2023-04-23 09:04:32 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:04:32 --> Final output sent to browser
DEBUG - 2023-04-23 09:04:32 --> Total execution time: 0.0123
INFO - 2023-04-23 09:07:19 --> Config Class Initialized
INFO - 2023-04-23 09:07:20 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:07:20 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:07:20 --> Utf8 Class Initialized
INFO - 2023-04-23 09:07:20 --> URI Class Initialized
INFO - 2023-04-23 09:07:20 --> Router Class Initialized
INFO - 2023-04-23 09:07:20 --> Output Class Initialized
INFO - 2023-04-23 09:07:20 --> Security Class Initialized
DEBUG - 2023-04-23 09:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:07:20 --> Input Class Initialized
INFO - 2023-04-23 09:07:20 --> Language Class Initialized
INFO - 2023-04-23 09:07:20 --> Loader Class Initialized
INFO - 2023-04-23 09:07:20 --> Controller Class Initialized
DEBUG - 2023-04-23 09:07:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:07:20 --> Database Driver Class Initialized
INFO - 2023-04-23 09:07:20 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:07:20 --> Database Driver Class Initialized
INFO - 2023-04-23 09:07:20 --> Model "Login_model" initialized
INFO - 2023-04-23 09:07:20 --> Final output sent to browser
DEBUG - 2023-04-23 09:07:20 --> Total execution time: 0.1376
INFO - 2023-04-23 09:07:20 --> Config Class Initialized
INFO - 2023-04-23 09:07:20 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:07:20 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:07:20 --> Utf8 Class Initialized
INFO - 2023-04-23 09:07:20 --> URI Class Initialized
INFO - 2023-04-23 09:07:20 --> Router Class Initialized
INFO - 2023-04-23 09:07:20 --> Output Class Initialized
INFO - 2023-04-23 09:07:20 --> Security Class Initialized
DEBUG - 2023-04-23 09:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:07:20 --> Input Class Initialized
INFO - 2023-04-23 09:07:20 --> Language Class Initialized
INFO - 2023-04-23 09:07:20 --> Loader Class Initialized
INFO - 2023-04-23 09:07:20 --> Controller Class Initialized
DEBUG - 2023-04-23 09:07:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:07:20 --> Database Driver Class Initialized
INFO - 2023-04-23 09:07:20 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:07:20 --> Database Driver Class Initialized
INFO - 2023-04-23 09:07:20 --> Model "Login_model" initialized
INFO - 2023-04-23 09:07:20 --> Final output sent to browser
DEBUG - 2023-04-23 09:07:20 --> Total execution time: 0.0735
INFO - 2023-04-23 09:08:12 --> Config Class Initialized
INFO - 2023-04-23 09:08:12 --> Config Class Initialized
INFO - 2023-04-23 09:08:12 --> Hooks Class Initialized
INFO - 2023-04-23 09:08:12 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:08:12 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:08:12 --> Utf8 Class Initialized
DEBUG - 2023-04-23 09:08:12 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:08:12 --> URI Class Initialized
INFO - 2023-04-23 09:08:12 --> Utf8 Class Initialized
INFO - 2023-04-23 09:08:12 --> Router Class Initialized
INFO - 2023-04-23 09:08:12 --> Output Class Initialized
INFO - 2023-04-23 09:08:12 --> URI Class Initialized
INFO - 2023-04-23 09:08:12 --> Security Class Initialized
INFO - 2023-04-23 09:08:12 --> Router Class Initialized
DEBUG - 2023-04-23 09:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:08:12 --> Output Class Initialized
INFO - 2023-04-23 09:08:12 --> Input Class Initialized
INFO - 2023-04-23 09:08:12 --> Security Class Initialized
INFO - 2023-04-23 09:08:12 --> Language Class Initialized
DEBUG - 2023-04-23 09:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:08:12 --> Input Class Initialized
INFO - 2023-04-23 09:08:12 --> Language Class Initialized
INFO - 2023-04-23 09:08:12 --> Loader Class Initialized
INFO - 2023-04-23 09:08:12 --> Controller Class Initialized
DEBUG - 2023-04-23 09:08:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:08:12 --> Database Driver Class Initialized
INFO - 2023-04-23 09:08:12 --> Loader Class Initialized
INFO - 2023-04-23 09:08:12 --> Controller Class Initialized
DEBUG - 2023-04-23 09:08:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:08:12 --> Database Driver Class Initialized
INFO - 2023-04-23 09:08:12 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:08:12 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:08:12 --> Final output sent to browser
INFO - 2023-04-23 09:08:12 --> Database Driver Class Initialized
DEBUG - 2023-04-23 09:08:12 --> Total execution time: 0.0640
INFO - 2023-04-23 09:08:12 --> Model "Login_model" initialized
INFO - 2023-04-23 09:08:12 --> Config Class Initialized
INFO - 2023-04-23 09:08:12 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:08:12 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:08:12 --> Utf8 Class Initialized
INFO - 2023-04-23 09:08:12 --> URI Class Initialized
INFO - 2023-04-23 09:08:12 --> Final output sent to browser
INFO - 2023-04-23 09:08:12 --> Router Class Initialized
DEBUG - 2023-04-23 09:08:12 --> Total execution time: 0.2309
INFO - 2023-04-23 09:08:12 --> Output Class Initialized
INFO - 2023-04-23 09:08:12 --> Security Class Initialized
DEBUG - 2023-04-23 09:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:08:12 --> Input Class Initialized
INFO - 2023-04-23 09:08:12 --> Language Class Initialized
INFO - 2023-04-23 09:08:12 --> Loader Class Initialized
INFO - 2023-04-23 09:08:12 --> Controller Class Initialized
INFO - 2023-04-23 09:08:12 --> Config Class Initialized
INFO - 2023-04-23 09:08:12 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:08:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 09:08:12 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:08:12 --> Utf8 Class Initialized
INFO - 2023-04-23 09:08:12 --> Database Driver Class Initialized
INFO - 2023-04-23 09:08:12 --> URI Class Initialized
INFO - 2023-04-23 09:08:12 --> Router Class Initialized
INFO - 2023-04-23 09:08:12 --> Output Class Initialized
INFO - 2023-04-23 09:08:12 --> Security Class Initialized
DEBUG - 2023-04-23 09:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:08:12 --> Input Class Initialized
INFO - 2023-04-23 09:08:12 --> Language Class Initialized
INFO - 2023-04-23 09:08:12 --> Loader Class Initialized
INFO - 2023-04-23 09:08:12 --> Controller Class Initialized
DEBUG - 2023-04-23 09:08:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:08:12 --> Database Driver Class Initialized
INFO - 2023-04-23 09:08:12 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:08:12 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:08:12 --> Final output sent to browser
DEBUG - 2023-04-23 09:08:12 --> Total execution time: 0.0989
INFO - 2023-04-23 09:08:12 --> Database Driver Class Initialized
INFO - 2023-04-23 09:08:12 --> Model "Login_model" initialized
INFO - 2023-04-23 09:08:12 --> Final output sent to browser
DEBUG - 2023-04-23 09:08:12 --> Total execution time: 0.1657
INFO - 2023-04-23 09:19:03 --> Config Class Initialized
INFO - 2023-04-23 09:19:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:03 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:03 --> URI Class Initialized
INFO - 2023-04-23 09:19:03 --> Router Class Initialized
INFO - 2023-04-23 09:19:03 --> Output Class Initialized
INFO - 2023-04-23 09:19:03 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:03 --> Input Class Initialized
INFO - 2023-04-23 09:19:03 --> Language Class Initialized
INFO - 2023-04-23 09:19:03 --> Loader Class Initialized
INFO - 2023-04-23 09:19:03 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:03 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:03 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:03 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:03 --> Total execution time: 0.0204
INFO - 2023-04-23 09:19:03 --> Config Class Initialized
INFO - 2023-04-23 09:19:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:03 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:03 --> URI Class Initialized
INFO - 2023-04-23 09:19:03 --> Router Class Initialized
INFO - 2023-04-23 09:19:03 --> Output Class Initialized
INFO - 2023-04-23 09:19:03 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:03 --> Input Class Initialized
INFO - 2023-04-23 09:19:03 --> Language Class Initialized
INFO - 2023-04-23 09:19:03 --> Loader Class Initialized
INFO - 2023-04-23 09:19:03 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:03 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:03 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:03 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:03 --> Model "Login_model" initialized
INFO - 2023-04-23 09:19:03 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:03 --> Total execution time: 0.0315
INFO - 2023-04-23 09:19:03 --> Config Class Initialized
INFO - 2023-04-23 09:19:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:03 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:03 --> URI Class Initialized
INFO - 2023-04-23 09:19:03 --> Router Class Initialized
INFO - 2023-04-23 09:19:03 --> Output Class Initialized
INFO - 2023-04-23 09:19:03 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:03 --> Input Class Initialized
INFO - 2023-04-23 09:19:03 --> Language Class Initialized
INFO - 2023-04-23 09:19:03 --> Loader Class Initialized
INFO - 2023-04-23 09:19:03 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:03 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:03 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:03 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:03 --> Total execution time: 0.1335
INFO - 2023-04-23 09:19:03 --> Config Class Initialized
INFO - 2023-04-23 09:19:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:03 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:03 --> URI Class Initialized
INFO - 2023-04-23 09:19:03 --> Router Class Initialized
INFO - 2023-04-23 09:19:03 --> Output Class Initialized
INFO - 2023-04-23 09:19:03 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:03 --> Input Class Initialized
INFO - 2023-04-23 09:19:03 --> Language Class Initialized
INFO - 2023-04-23 09:19:03 --> Loader Class Initialized
INFO - 2023-04-23 09:19:03 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:03 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:03 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:03 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:03 --> Model "Login_model" initialized
INFO - 2023-04-23 09:19:03 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:03 --> Total execution time: 0.0280
INFO - 2023-04-23 09:19:05 --> Config Class Initialized
INFO - 2023-04-23 09:19:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:05 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:05 --> URI Class Initialized
INFO - 2023-04-23 09:19:05 --> Router Class Initialized
INFO - 2023-04-23 09:19:05 --> Output Class Initialized
INFO - 2023-04-23 09:19:05 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:05 --> Input Class Initialized
INFO - 2023-04-23 09:19:05 --> Language Class Initialized
INFO - 2023-04-23 09:19:05 --> Loader Class Initialized
INFO - 2023-04-23 09:19:05 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:05 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:05 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:05 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:05 --> Total execution time: 0.0880
INFO - 2023-04-23 09:19:05 --> Config Class Initialized
INFO - 2023-04-23 09:19:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:05 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:05 --> URI Class Initialized
INFO - 2023-04-23 09:19:05 --> Router Class Initialized
INFO - 2023-04-23 09:19:05 --> Output Class Initialized
INFO - 2023-04-23 09:19:05 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:05 --> Input Class Initialized
INFO - 2023-04-23 09:19:05 --> Language Class Initialized
INFO - 2023-04-23 09:19:05 --> Loader Class Initialized
INFO - 2023-04-23 09:19:05 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:05 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:05 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:05 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:05 --> Total execution time: 0.0603
INFO - 2023-04-23 09:19:09 --> Config Class Initialized
INFO - 2023-04-23 09:19:09 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:09 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:09 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:09 --> URI Class Initialized
INFO - 2023-04-23 09:19:09 --> Router Class Initialized
INFO - 2023-04-23 09:19:09 --> Output Class Initialized
INFO - 2023-04-23 09:19:09 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:09 --> Input Class Initialized
INFO - 2023-04-23 09:19:09 --> Language Class Initialized
INFO - 2023-04-23 09:19:09 --> Loader Class Initialized
INFO - 2023-04-23 09:19:09 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:09 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:09 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:09 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:09 --> Total execution time: 0.0101
INFO - 2023-04-23 09:19:09 --> Config Class Initialized
INFO - 2023-04-23 09:19:09 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:09 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:09 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:09 --> URI Class Initialized
INFO - 2023-04-23 09:19:09 --> Router Class Initialized
INFO - 2023-04-23 09:19:09 --> Output Class Initialized
INFO - 2023-04-23 09:19:09 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:09 --> Input Class Initialized
INFO - 2023-04-23 09:19:09 --> Language Class Initialized
INFO - 2023-04-23 09:19:09 --> Loader Class Initialized
INFO - 2023-04-23 09:19:09 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:09 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:09 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:09 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:09 --> Model "Login_model" initialized
INFO - 2023-04-23 09:19:09 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:09 --> Total execution time: 0.0227
INFO - 2023-04-23 09:19:09 --> Config Class Initialized
INFO - 2023-04-23 09:19:09 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:09 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:09 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:09 --> URI Class Initialized
INFO - 2023-04-23 09:19:09 --> Router Class Initialized
INFO - 2023-04-23 09:19:09 --> Output Class Initialized
INFO - 2023-04-23 09:19:09 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:09 --> Input Class Initialized
INFO - 2023-04-23 09:19:09 --> Language Class Initialized
INFO - 2023-04-23 09:19:09 --> Loader Class Initialized
INFO - 2023-04-23 09:19:09 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:09 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:09 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:09 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:09 --> Total execution time: 0.0098
INFO - 2023-04-23 09:19:09 --> Config Class Initialized
INFO - 2023-04-23 09:19:09 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:09 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:09 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:09 --> URI Class Initialized
INFO - 2023-04-23 09:19:09 --> Router Class Initialized
INFO - 2023-04-23 09:19:09 --> Output Class Initialized
INFO - 2023-04-23 09:19:09 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:09 --> Input Class Initialized
INFO - 2023-04-23 09:19:09 --> Language Class Initialized
INFO - 2023-04-23 09:19:09 --> Loader Class Initialized
INFO - 2023-04-23 09:19:09 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:09 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:09 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:09 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:09 --> Model "Login_model" initialized
INFO - 2023-04-23 09:19:09 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:09 --> Total execution time: 0.0232
INFO - 2023-04-23 09:19:11 --> Config Class Initialized
INFO - 2023-04-23 09:19:11 --> Config Class Initialized
INFO - 2023-04-23 09:19:11 --> Hooks Class Initialized
INFO - 2023-04-23 09:19:11 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:19:11 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:11 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:11 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:11 --> URI Class Initialized
INFO - 2023-04-23 09:19:11 --> URI Class Initialized
INFO - 2023-04-23 09:19:11 --> Router Class Initialized
INFO - 2023-04-23 09:19:11 --> Router Class Initialized
INFO - 2023-04-23 09:19:11 --> Output Class Initialized
INFO - 2023-04-23 09:19:11 --> Output Class Initialized
INFO - 2023-04-23 09:19:11 --> Security Class Initialized
INFO - 2023-04-23 09:19:11 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:11 --> Input Class Initialized
INFO - 2023-04-23 09:19:11 --> Input Class Initialized
INFO - 2023-04-23 09:19:11 --> Language Class Initialized
INFO - 2023-04-23 09:19:11 --> Language Class Initialized
INFO - 2023-04-23 09:19:11 --> Loader Class Initialized
INFO - 2023-04-23 09:19:11 --> Controller Class Initialized
INFO - 2023-04-23 09:19:11 --> Loader Class Initialized
DEBUG - 2023-04-23 09:19:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:11 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:11 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:11 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:11 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:11 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:11 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:11 --> Total execution time: 0.0155
INFO - 2023-04-23 09:19:11 --> Config Class Initialized
INFO - 2023-04-23 09:19:11 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:11 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:11 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:11 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:11 --> URI Class Initialized
INFO - 2023-04-23 09:19:11 --> Router Class Initialized
INFO - 2023-04-23 09:19:11 --> Output Class Initialized
INFO - 2023-04-23 09:19:11 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:11 --> Input Class Initialized
INFO - 2023-04-23 09:19:11 --> Language Class Initialized
INFO - 2023-04-23 09:19:11 --> Loader Class Initialized
INFO - 2023-04-23 09:19:11 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:11 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:11 --> Model "Login_model" initialized
INFO - 2023-04-23 09:19:11 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:11 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:11 --> Total execution time: 0.0543
INFO - 2023-04-23 09:19:11 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:11 --> Total execution time: 0.1116
INFO - 2023-04-23 09:19:11 --> Config Class Initialized
INFO - 2023-04-23 09:19:11 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:11 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:11 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:11 --> URI Class Initialized
INFO - 2023-04-23 09:19:11 --> Router Class Initialized
INFO - 2023-04-23 09:19:11 --> Output Class Initialized
INFO - 2023-04-23 09:19:11 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:11 --> Input Class Initialized
INFO - 2023-04-23 09:19:11 --> Language Class Initialized
INFO - 2023-04-23 09:19:11 --> Loader Class Initialized
INFO - 2023-04-23 09:19:11 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:11 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:11 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:11 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:11 --> Model "Login_model" initialized
INFO - 2023-04-23 09:19:11 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:11 --> Total execution time: 0.1128
INFO - 2023-04-23 09:19:16 --> Config Class Initialized
INFO - 2023-04-23 09:19:16 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:16 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:16 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:16 --> URI Class Initialized
INFO - 2023-04-23 09:19:16 --> Router Class Initialized
INFO - 2023-04-23 09:19:16 --> Output Class Initialized
INFO - 2023-04-23 09:19:16 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:16 --> Input Class Initialized
INFO - 2023-04-23 09:19:16 --> Language Class Initialized
INFO - 2023-04-23 09:19:16 --> Loader Class Initialized
INFO - 2023-04-23 09:19:16 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:16 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:16 --> Total execution time: 0.0463
INFO - 2023-04-23 09:19:16 --> Config Class Initialized
INFO - 2023-04-23 09:19:16 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:16 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:16 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:16 --> URI Class Initialized
INFO - 2023-04-23 09:19:16 --> Router Class Initialized
INFO - 2023-04-23 09:19:16 --> Output Class Initialized
INFO - 2023-04-23 09:19:16 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:16 --> Input Class Initialized
INFO - 2023-04-23 09:19:16 --> Language Class Initialized
INFO - 2023-04-23 09:19:16 --> Loader Class Initialized
INFO - 2023-04-23 09:19:16 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:16 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:16 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:16 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:16 --> Total execution time: 0.0390
INFO - 2023-04-23 09:19:28 --> Config Class Initialized
INFO - 2023-04-23 09:19:28 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:28 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:28 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:28 --> URI Class Initialized
INFO - 2023-04-23 09:19:28 --> Router Class Initialized
INFO - 2023-04-23 09:19:28 --> Output Class Initialized
INFO - 2023-04-23 09:19:28 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:28 --> Input Class Initialized
INFO - 2023-04-23 09:19:28 --> Language Class Initialized
INFO - 2023-04-23 09:19:28 --> Loader Class Initialized
INFO - 2023-04-23 09:19:28 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:28 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:28 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:28 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:28 --> Total execution time: 0.0385
INFO - 2023-04-23 09:19:28 --> Config Class Initialized
INFO - 2023-04-23 09:19:28 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:28 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:28 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:28 --> URI Class Initialized
INFO - 2023-04-23 09:19:28 --> Router Class Initialized
INFO - 2023-04-23 09:19:28 --> Output Class Initialized
INFO - 2023-04-23 09:19:28 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:28 --> Input Class Initialized
INFO - 2023-04-23 09:19:28 --> Language Class Initialized
INFO - 2023-04-23 09:19:28 --> Loader Class Initialized
INFO - 2023-04-23 09:19:28 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:28 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:28 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:28 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:28 --> Total execution time: 0.0754
INFO - 2023-04-23 09:19:30 --> Config Class Initialized
INFO - 2023-04-23 09:19:30 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:30 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:30 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:30 --> URI Class Initialized
INFO - 2023-04-23 09:19:30 --> Router Class Initialized
INFO - 2023-04-23 09:19:30 --> Output Class Initialized
INFO - 2023-04-23 09:19:30 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:30 --> Input Class Initialized
INFO - 2023-04-23 09:19:30 --> Language Class Initialized
INFO - 2023-04-23 09:19:30 --> Loader Class Initialized
INFO - 2023-04-23 09:19:30 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:30 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:30 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:30 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:30 --> Total execution time: 0.0171
INFO - 2023-04-23 09:19:30 --> Config Class Initialized
INFO - 2023-04-23 09:19:30 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:30 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:30 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:30 --> URI Class Initialized
INFO - 2023-04-23 09:19:30 --> Router Class Initialized
INFO - 2023-04-23 09:19:30 --> Output Class Initialized
INFO - 2023-04-23 09:19:30 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:30 --> Input Class Initialized
INFO - 2023-04-23 09:19:30 --> Language Class Initialized
INFO - 2023-04-23 09:19:30 --> Loader Class Initialized
INFO - 2023-04-23 09:19:30 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:30 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:30 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:30 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:30 --> Total execution time: 0.0548
INFO - 2023-04-23 09:19:42 --> Config Class Initialized
INFO - 2023-04-23 09:19:42 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:42 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:42 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:42 --> URI Class Initialized
INFO - 2023-04-23 09:19:42 --> Router Class Initialized
INFO - 2023-04-23 09:19:42 --> Output Class Initialized
INFO - 2023-04-23 09:19:42 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:42 --> Input Class Initialized
INFO - 2023-04-23 09:19:42 --> Language Class Initialized
INFO - 2023-04-23 09:19:42 --> Loader Class Initialized
INFO - 2023-04-23 09:19:42 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:42 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:42 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:43 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:43 --> Total execution time: 0.0182
INFO - 2023-04-23 09:19:43 --> Config Class Initialized
INFO - 2023-04-23 09:19:43 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:43 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:43 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:43 --> URI Class Initialized
INFO - 2023-04-23 09:19:43 --> Router Class Initialized
INFO - 2023-04-23 09:19:43 --> Output Class Initialized
INFO - 2023-04-23 09:19:43 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:43 --> Input Class Initialized
INFO - 2023-04-23 09:19:43 --> Language Class Initialized
INFO - 2023-04-23 09:19:43 --> Loader Class Initialized
INFO - 2023-04-23 09:19:43 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:43 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:43 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:43 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:43 --> Total execution time: 0.0548
INFO - 2023-04-23 09:19:46 --> Config Class Initialized
INFO - 2023-04-23 09:19:46 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:46 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:46 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:46 --> URI Class Initialized
INFO - 2023-04-23 09:19:46 --> Router Class Initialized
INFO - 2023-04-23 09:19:46 --> Output Class Initialized
INFO - 2023-04-23 09:19:46 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:46 --> Input Class Initialized
INFO - 2023-04-23 09:19:46 --> Language Class Initialized
INFO - 2023-04-23 09:19:46 --> Loader Class Initialized
INFO - 2023-04-23 09:19:46 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:46 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:46 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:46 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:46 --> Total execution time: 0.0478
INFO - 2023-04-23 09:19:46 --> Config Class Initialized
INFO - 2023-04-23 09:19:46 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:46 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:46 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:46 --> URI Class Initialized
INFO - 2023-04-23 09:19:46 --> Router Class Initialized
INFO - 2023-04-23 09:19:46 --> Output Class Initialized
INFO - 2023-04-23 09:19:46 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:46 --> Input Class Initialized
INFO - 2023-04-23 09:19:46 --> Language Class Initialized
INFO - 2023-04-23 09:19:46 --> Loader Class Initialized
INFO - 2023-04-23 09:19:46 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:46 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:46 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:46 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:46 --> Total execution time: 0.0564
INFO - 2023-04-23 09:19:50 --> Config Class Initialized
INFO - 2023-04-23 09:19:50 --> Config Class Initialized
INFO - 2023-04-23 09:19:50 --> Hooks Class Initialized
INFO - 2023-04-23 09:19:50 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:19:50 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:50 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:50 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:50 --> URI Class Initialized
INFO - 2023-04-23 09:19:50 --> URI Class Initialized
INFO - 2023-04-23 09:19:50 --> Router Class Initialized
INFO - 2023-04-23 09:19:50 --> Router Class Initialized
INFO - 2023-04-23 09:19:50 --> Output Class Initialized
INFO - 2023-04-23 09:19:50 --> Output Class Initialized
INFO - 2023-04-23 09:19:50 --> Security Class Initialized
INFO - 2023-04-23 09:19:50 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:50 --> Input Class Initialized
INFO - 2023-04-23 09:19:50 --> Input Class Initialized
INFO - 2023-04-23 09:19:50 --> Language Class Initialized
INFO - 2023-04-23 09:19:50 --> Language Class Initialized
INFO - 2023-04-23 09:19:50 --> Loader Class Initialized
INFO - 2023-04-23 09:19:50 --> Loader Class Initialized
INFO - 2023-04-23 09:19:50 --> Controller Class Initialized
INFO - 2023-04-23 09:19:50 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 09:19:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:50 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:50 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:50 --> Total execution time: 0.0071
INFO - 2023-04-23 09:19:50 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:50 --> Config Class Initialized
INFO - 2023-04-23 09:19:50 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:50 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:50 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:50 --> URI Class Initialized
INFO - 2023-04-23 09:19:50 --> Router Class Initialized
INFO - 2023-04-23 09:19:50 --> Output Class Initialized
INFO - 2023-04-23 09:19:50 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:50 --> Input Class Initialized
INFO - 2023-04-23 09:19:50 --> Language Class Initialized
INFO - 2023-04-23 09:19:50 --> Loader Class Initialized
INFO - 2023-04-23 09:19:50 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:50 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:50 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:50 --> Total execution time: 0.0461
INFO - 2023-04-23 09:19:50 --> Config Class Initialized
INFO - 2023-04-23 09:19:50 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:50 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:50 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:50 --> Model "Login_model" initialized
INFO - 2023-04-23 09:19:50 --> URI Class Initialized
INFO - 2023-04-23 09:19:50 --> Router Class Initialized
INFO - 2023-04-23 09:19:50 --> Output Class Initialized
INFO - 2023-04-23 09:19:50 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:50 --> Input Class Initialized
INFO - 2023-04-23 09:19:50 --> Language Class Initialized
INFO - 2023-04-23 09:19:50 --> Loader Class Initialized
INFO - 2023-04-23 09:19:50 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:50 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:50 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:50 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:50 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:50 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:50 --> Total execution time: 0.0571
INFO - 2023-04-23 09:19:50 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:50 --> Total execution time: 0.0902
INFO - 2023-04-23 09:19:52 --> Config Class Initialized
INFO - 2023-04-23 09:19:52 --> Config Class Initialized
INFO - 2023-04-23 09:19:52 --> Hooks Class Initialized
INFO - 2023-04-23 09:19:52 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:52 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:52 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:52 --> URI Class Initialized
DEBUG - 2023-04-23 09:19:52 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:52 --> Router Class Initialized
INFO - 2023-04-23 09:19:52 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:52 --> Output Class Initialized
INFO - 2023-04-23 09:19:52 --> URI Class Initialized
INFO - 2023-04-23 09:19:52 --> Security Class Initialized
INFO - 2023-04-23 09:19:52 --> Router Class Initialized
DEBUG - 2023-04-23 09:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:52 --> Output Class Initialized
INFO - 2023-04-23 09:19:52 --> Input Class Initialized
INFO - 2023-04-23 09:19:52 --> Security Class Initialized
INFO - 2023-04-23 09:19:52 --> Language Class Initialized
DEBUG - 2023-04-23 09:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:52 --> Input Class Initialized
INFO - 2023-04-23 09:19:52 --> Loader Class Initialized
INFO - 2023-04-23 09:19:52 --> Language Class Initialized
INFO - 2023-04-23 09:19:52 --> Controller Class Initialized
INFO - 2023-04-23 09:19:52 --> Loader Class Initialized
DEBUG - 2023-04-23 09:19:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:52 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:52 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:52 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:52 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:52 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:52 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:52 --> Total execution time: 0.0157
INFO - 2023-04-23 09:19:52 --> Config Class Initialized
INFO - 2023-04-23 09:19:52 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:52 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:52 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:52 --> URI Class Initialized
INFO - 2023-04-23 09:19:52 --> Router Class Initialized
INFO - 2023-04-23 09:19:52 --> Output Class Initialized
INFO - 2023-04-23 09:19:52 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:52 --> Input Class Initialized
INFO - 2023-04-23 09:19:52 --> Language Class Initialized
INFO - 2023-04-23 09:19:52 --> Loader Class Initialized
INFO - 2023-04-23 09:19:52 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:52 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:52 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:52 --> Model "Login_model" initialized
INFO - 2023-04-23 09:19:52 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:52 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:52 --> Total execution time: 0.0918
INFO - 2023-04-23 09:19:52 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:52 --> Total execution time: 0.1637
INFO - 2023-04-23 09:19:52 --> Config Class Initialized
INFO - 2023-04-23 09:19:52 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:19:52 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:19:52 --> Utf8 Class Initialized
INFO - 2023-04-23 09:19:52 --> URI Class Initialized
INFO - 2023-04-23 09:19:52 --> Router Class Initialized
INFO - 2023-04-23 09:19:52 --> Output Class Initialized
INFO - 2023-04-23 09:19:52 --> Security Class Initialized
DEBUG - 2023-04-23 09:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:19:52 --> Input Class Initialized
INFO - 2023-04-23 09:19:52 --> Language Class Initialized
INFO - 2023-04-23 09:19:52 --> Loader Class Initialized
INFO - 2023-04-23 09:19:52 --> Controller Class Initialized
DEBUG - 2023-04-23 09:19:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:19:52 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:52 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:19:52 --> Database Driver Class Initialized
INFO - 2023-04-23 09:19:52 --> Model "Login_model" initialized
INFO - 2023-04-23 09:19:52 --> Final output sent to browser
DEBUG - 2023-04-23 09:19:52 --> Total execution time: 0.2249
INFO - 2023-04-23 09:48:58 --> Config Class Initialized
INFO - 2023-04-23 09:48:58 --> Config Class Initialized
INFO - 2023-04-23 09:48:58 --> Hooks Class Initialized
INFO - 2023-04-23 09:48:58 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:48:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:48:58 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:48:58 --> Utf8 Class Initialized
INFO - 2023-04-23 09:48:58 --> Utf8 Class Initialized
INFO - 2023-04-23 09:48:58 --> URI Class Initialized
INFO - 2023-04-23 09:48:58 --> URI Class Initialized
INFO - 2023-04-23 09:48:58 --> Router Class Initialized
INFO - 2023-04-23 09:48:58 --> Router Class Initialized
INFO - 2023-04-23 09:48:58 --> Output Class Initialized
INFO - 2023-04-23 09:48:58 --> Output Class Initialized
INFO - 2023-04-23 09:48:58 --> Security Class Initialized
INFO - 2023-04-23 09:48:58 --> Security Class Initialized
DEBUG - 2023-04-23 09:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:48:58 --> Input Class Initialized
INFO - 2023-04-23 09:48:58 --> Input Class Initialized
INFO - 2023-04-23 09:48:58 --> Language Class Initialized
INFO - 2023-04-23 09:48:58 --> Language Class Initialized
INFO - 2023-04-23 09:48:58 --> Loader Class Initialized
INFO - 2023-04-23 09:48:58 --> Loader Class Initialized
INFO - 2023-04-23 09:48:58 --> Controller Class Initialized
INFO - 2023-04-23 09:48:58 --> Controller Class Initialized
DEBUG - 2023-04-23 09:48:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 09:48:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:48:58 --> Database Driver Class Initialized
INFO - 2023-04-23 09:48:58 --> Database Driver Class Initialized
INFO - 2023-04-23 09:48:58 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:48:58 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:48:58 --> Final output sent to browser
DEBUG - 2023-04-23 09:48:58 --> Total execution time: 0.1044
INFO - 2023-04-23 09:48:58 --> Database Driver Class Initialized
INFO - 2023-04-23 09:48:58 --> Config Class Initialized
INFO - 2023-04-23 09:48:58 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:48:58 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:48:58 --> Utf8 Class Initialized
INFO - 2023-04-23 09:48:58 --> URI Class Initialized
INFO - 2023-04-23 09:48:58 --> Router Class Initialized
INFO - 2023-04-23 09:48:58 --> Output Class Initialized
INFO - 2023-04-23 09:48:58 --> Security Class Initialized
DEBUG - 2023-04-23 09:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:48:58 --> Input Class Initialized
INFO - 2023-04-23 09:48:58 --> Language Class Initialized
INFO - 2023-04-23 09:48:58 --> Loader Class Initialized
INFO - 2023-04-23 09:48:58 --> Controller Class Initialized
DEBUG - 2023-04-23 09:48:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:48:58 --> Database Driver Class Initialized
INFO - 2023-04-23 09:48:58 --> Model "Login_model" initialized
INFO - 2023-04-23 09:48:58 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:48:58 --> Final output sent to browser
DEBUG - 2023-04-23 09:48:58 --> Total execution time: 0.0188
INFO - 2023-04-23 09:48:58 --> Final output sent to browser
DEBUG - 2023-04-23 09:48:58 --> Total execution time: 0.2090
INFO - 2023-04-23 09:48:58 --> Config Class Initialized
INFO - 2023-04-23 09:48:58 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:48:58 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:48:58 --> Utf8 Class Initialized
INFO - 2023-04-23 09:48:58 --> URI Class Initialized
INFO - 2023-04-23 09:48:58 --> Router Class Initialized
INFO - 2023-04-23 09:48:58 --> Output Class Initialized
INFO - 2023-04-23 09:48:58 --> Security Class Initialized
DEBUG - 2023-04-23 09:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:48:58 --> Input Class Initialized
INFO - 2023-04-23 09:48:58 --> Language Class Initialized
INFO - 2023-04-23 09:48:58 --> Loader Class Initialized
INFO - 2023-04-23 09:48:58 --> Controller Class Initialized
DEBUG - 2023-04-23 09:48:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:48:58 --> Database Driver Class Initialized
INFO - 2023-04-23 09:48:58 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:48:58 --> Database Driver Class Initialized
INFO - 2023-04-23 09:48:58 --> Model "Login_model" initialized
INFO - 2023-04-23 09:48:58 --> Final output sent to browser
DEBUG - 2023-04-23 09:48:58 --> Total execution time: 0.0971
INFO - 2023-04-23 09:49:03 --> Config Class Initialized
INFO - 2023-04-23 09:49:03 --> Config Class Initialized
INFO - 2023-04-23 09:49:03 --> Hooks Class Initialized
INFO - 2023-04-23 09:49:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:49:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:49:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:49:03 --> Utf8 Class Initialized
INFO - 2023-04-23 09:49:03 --> Utf8 Class Initialized
INFO - 2023-04-23 09:49:03 --> URI Class Initialized
INFO - 2023-04-23 09:49:03 --> URI Class Initialized
INFO - 2023-04-23 09:49:03 --> Router Class Initialized
INFO - 2023-04-23 09:49:03 --> Router Class Initialized
INFO - 2023-04-23 09:49:03 --> Output Class Initialized
INFO - 2023-04-23 09:49:03 --> Output Class Initialized
INFO - 2023-04-23 09:49:03 --> Security Class Initialized
INFO - 2023-04-23 09:49:03 --> Security Class Initialized
DEBUG - 2023-04-23 09:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:49:03 --> Input Class Initialized
INFO - 2023-04-23 09:49:03 --> Language Class Initialized
INFO - 2023-04-23 09:49:03 --> Input Class Initialized
INFO - 2023-04-23 09:49:03 --> Language Class Initialized
INFO - 2023-04-23 09:49:03 --> Loader Class Initialized
INFO - 2023-04-23 09:49:03 --> Loader Class Initialized
INFO - 2023-04-23 09:49:03 --> Controller Class Initialized
INFO - 2023-04-23 09:49:03 --> Controller Class Initialized
DEBUG - 2023-04-23 09:49:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 09:49:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:49:03 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:03 --> Total execution time: 0.0053
INFO - 2023-04-23 09:49:03 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:03 --> Config Class Initialized
INFO - 2023-04-23 09:49:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:49:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:49:03 --> Utf8 Class Initialized
INFO - 2023-04-23 09:49:03 --> URI Class Initialized
INFO - 2023-04-23 09:49:03 --> Router Class Initialized
INFO - 2023-04-23 09:49:03 --> Output Class Initialized
INFO - 2023-04-23 09:49:03 --> Security Class Initialized
DEBUG - 2023-04-23 09:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:49:03 --> Input Class Initialized
INFO - 2023-04-23 09:49:03 --> Language Class Initialized
INFO - 2023-04-23 09:49:03 --> Loader Class Initialized
INFO - 2023-04-23 09:49:03 --> Controller Class Initialized
DEBUG - 2023-04-23 09:49:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:49:03 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:03 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:49:03 --> Model "Login_model" initialized
INFO - 2023-04-23 09:49:03 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:03 --> Total execution time: 0.0218
INFO - 2023-04-23 09:49:03 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:03 --> Config Class Initialized
INFO - 2023-04-23 09:49:03 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:49:03 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:49:03 --> Utf8 Class Initialized
INFO - 2023-04-23 09:49:03 --> URI Class Initialized
INFO - 2023-04-23 09:49:03 --> Router Class Initialized
INFO - 2023-04-23 09:49:03 --> Output Class Initialized
INFO - 2023-04-23 09:49:03 --> Security Class Initialized
DEBUG - 2023-04-23 09:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:49:03 --> Input Class Initialized
INFO - 2023-04-23 09:49:03 --> Language Class Initialized
INFO - 2023-04-23 09:49:03 --> Loader Class Initialized
INFO - 2023-04-23 09:49:03 --> Controller Class Initialized
DEBUG - 2023-04-23 09:49:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:49:03 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:03 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:49:03 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:03 --> Total execution time: 0.0262
INFO - 2023-04-23 09:49:03 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:49:03 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:03 --> Total execution time: 0.0562
INFO - 2023-04-23 09:49:06 --> Config Class Initialized
INFO - 2023-04-23 09:49:06 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:49:06 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:49:06 --> Utf8 Class Initialized
INFO - 2023-04-23 09:49:06 --> URI Class Initialized
INFO - 2023-04-23 09:49:06 --> Router Class Initialized
INFO - 2023-04-23 09:49:06 --> Output Class Initialized
INFO - 2023-04-23 09:49:06 --> Security Class Initialized
DEBUG - 2023-04-23 09:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:49:06 --> Input Class Initialized
INFO - 2023-04-23 09:49:06 --> Language Class Initialized
INFO - 2023-04-23 09:49:06 --> Loader Class Initialized
INFO - 2023-04-23 09:49:06 --> Controller Class Initialized
DEBUG - 2023-04-23 09:49:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:49:06 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:06 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:49:06 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:06 --> Total execution time: 0.0180
INFO - 2023-04-23 09:49:06 --> Config Class Initialized
INFO - 2023-04-23 09:49:06 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:49:06 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:49:06 --> Utf8 Class Initialized
INFO - 2023-04-23 09:49:06 --> URI Class Initialized
INFO - 2023-04-23 09:49:06 --> Router Class Initialized
INFO - 2023-04-23 09:49:06 --> Output Class Initialized
INFO - 2023-04-23 09:49:06 --> Security Class Initialized
DEBUG - 2023-04-23 09:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:49:06 --> Input Class Initialized
INFO - 2023-04-23 09:49:06 --> Language Class Initialized
INFO - 2023-04-23 09:49:06 --> Loader Class Initialized
INFO - 2023-04-23 09:49:06 --> Controller Class Initialized
DEBUG - 2023-04-23 09:49:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:49:06 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:06 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:49:06 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:06 --> Total execution time: 0.0611
INFO - 2023-04-23 09:49:08 --> Config Class Initialized
INFO - 2023-04-23 09:49:08 --> Config Class Initialized
INFO - 2023-04-23 09:49:08 --> Hooks Class Initialized
INFO - 2023-04-23 09:49:08 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:49:08 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:49:08 --> Utf8 Class Initialized
DEBUG - 2023-04-23 09:49:08 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:49:08 --> URI Class Initialized
INFO - 2023-04-23 09:49:08 --> Utf8 Class Initialized
INFO - 2023-04-23 09:49:08 --> Router Class Initialized
INFO - 2023-04-23 09:49:08 --> URI Class Initialized
INFO - 2023-04-23 09:49:08 --> Output Class Initialized
INFO - 2023-04-23 09:49:08 --> Router Class Initialized
INFO - 2023-04-23 09:49:08 --> Output Class Initialized
INFO - 2023-04-23 09:49:08 --> Security Class Initialized
INFO - 2023-04-23 09:49:08 --> Security Class Initialized
DEBUG - 2023-04-23 09:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:49:08 --> Input Class Initialized
INFO - 2023-04-23 09:49:08 --> Input Class Initialized
INFO - 2023-04-23 09:49:08 --> Language Class Initialized
INFO - 2023-04-23 09:49:08 --> Language Class Initialized
INFO - 2023-04-23 09:49:08 --> Loader Class Initialized
INFO - 2023-04-23 09:49:08 --> Loader Class Initialized
INFO - 2023-04-23 09:49:08 --> Controller Class Initialized
INFO - 2023-04-23 09:49:08 --> Controller Class Initialized
DEBUG - 2023-04-23 09:49:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 09:49:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:49:08 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:08 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:08 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:49:08 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:49:08 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:08 --> Total execution time: 0.0927
INFO - 2023-04-23 09:49:08 --> Config Class Initialized
INFO - 2023-04-23 09:49:08 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:49:08 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:49:08 --> Utf8 Class Initialized
INFO - 2023-04-23 09:49:08 --> URI Class Initialized
INFO - 2023-04-23 09:49:08 --> Router Class Initialized
INFO - 2023-04-23 09:49:08 --> Output Class Initialized
INFO - 2023-04-23 09:49:08 --> Security Class Initialized
DEBUG - 2023-04-23 09:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:49:08 --> Input Class Initialized
INFO - 2023-04-23 09:49:08 --> Language Class Initialized
INFO - 2023-04-23 09:49:08 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:08 --> Loader Class Initialized
INFO - 2023-04-23 09:49:08 --> Controller Class Initialized
DEBUG - 2023-04-23 09:49:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:49:08 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:09 --> Model "Login_model" initialized
INFO - 2023-04-23 09:49:09 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:49:09 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:09 --> Total execution time: 0.0155
INFO - 2023-04-23 09:49:09 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:09 --> Total execution time: 0.1656
INFO - 2023-04-23 09:49:09 --> Config Class Initialized
INFO - 2023-04-23 09:49:09 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:49:09 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:49:09 --> Utf8 Class Initialized
INFO - 2023-04-23 09:49:09 --> URI Class Initialized
INFO - 2023-04-23 09:49:09 --> Router Class Initialized
INFO - 2023-04-23 09:49:09 --> Output Class Initialized
INFO - 2023-04-23 09:49:09 --> Security Class Initialized
DEBUG - 2023-04-23 09:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:49:09 --> Input Class Initialized
INFO - 2023-04-23 09:49:09 --> Language Class Initialized
INFO - 2023-04-23 09:49:09 --> Loader Class Initialized
INFO - 2023-04-23 09:49:09 --> Controller Class Initialized
DEBUG - 2023-04-23 09:49:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:49:09 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:09 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:49:09 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:09 --> Model "Login_model" initialized
INFO - 2023-04-23 09:49:09 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:09 --> Total execution time: 0.0652
INFO - 2023-04-23 09:49:18 --> Config Class Initialized
INFO - 2023-04-23 09:49:18 --> Config Class Initialized
INFO - 2023-04-23 09:49:18 --> Hooks Class Initialized
INFO - 2023-04-23 09:49:18 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:49:18 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:49:18 --> Utf8 Class Initialized
DEBUG - 2023-04-23 09:49:18 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:49:18 --> URI Class Initialized
INFO - 2023-04-23 09:49:18 --> Utf8 Class Initialized
INFO - 2023-04-23 09:49:18 --> Router Class Initialized
INFO - 2023-04-23 09:49:18 --> URI Class Initialized
INFO - 2023-04-23 09:49:18 --> Output Class Initialized
INFO - 2023-04-23 09:49:18 --> Router Class Initialized
INFO - 2023-04-23 09:49:18 --> Security Class Initialized
INFO - 2023-04-23 09:49:18 --> Output Class Initialized
DEBUG - 2023-04-23 09:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:49:18 --> Security Class Initialized
INFO - 2023-04-23 09:49:18 --> Input Class Initialized
DEBUG - 2023-04-23 09:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:49:18 --> Language Class Initialized
INFO - 2023-04-23 09:49:18 --> Input Class Initialized
INFO - 2023-04-23 09:49:18 --> Loader Class Initialized
INFO - 2023-04-23 09:49:18 --> Language Class Initialized
INFO - 2023-04-23 09:49:18 --> Controller Class Initialized
INFO - 2023-04-23 09:49:18 --> Loader Class Initialized
DEBUG - 2023-04-23 09:49:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:49:18 --> Controller Class Initialized
DEBUG - 2023-04-23 09:49:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:49:18 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:18 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:18 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:49:18 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:49:18 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:18 --> Total execution time: 0.1010
INFO - 2023-04-23 09:49:18 --> Config Class Initialized
INFO - 2023-04-23 09:49:18 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:49:18 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:49:18 --> Utf8 Class Initialized
INFO - 2023-04-23 09:49:18 --> URI Class Initialized
INFO - 2023-04-23 09:49:18 --> Router Class Initialized
INFO - 2023-04-23 09:49:18 --> Output Class Initialized
INFO - 2023-04-23 09:49:18 --> Security Class Initialized
DEBUG - 2023-04-23 09:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:49:18 --> Input Class Initialized
INFO - 2023-04-23 09:49:18 --> Language Class Initialized
INFO - 2023-04-23 09:49:18 --> Loader Class Initialized
INFO - 2023-04-23 09:49:18 --> Controller Class Initialized
DEBUG - 2023-04-23 09:49:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:49:18 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:18 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:18 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:49:18 --> Model "Login_model" initialized
INFO - 2023-04-23 09:49:18 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:18 --> Total execution time: 0.0135
INFO - 2023-04-23 09:49:18 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:19 --> Total execution time: 0.1734
INFO - 2023-04-23 09:49:19 --> Config Class Initialized
INFO - 2023-04-23 09:49:19 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:49:19 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:49:19 --> Utf8 Class Initialized
INFO - 2023-04-23 09:49:19 --> URI Class Initialized
INFO - 2023-04-23 09:49:19 --> Router Class Initialized
INFO - 2023-04-23 09:49:19 --> Output Class Initialized
INFO - 2023-04-23 09:49:19 --> Security Class Initialized
DEBUG - 2023-04-23 09:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:49:19 --> Input Class Initialized
INFO - 2023-04-23 09:49:19 --> Language Class Initialized
INFO - 2023-04-23 09:49:19 --> Loader Class Initialized
INFO - 2023-04-23 09:49:19 --> Controller Class Initialized
DEBUG - 2023-04-23 09:49:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:49:19 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:19 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:49:19 --> Database Driver Class Initialized
INFO - 2023-04-23 09:49:19 --> Model "Login_model" initialized
INFO - 2023-04-23 09:49:19 --> Final output sent to browser
DEBUG - 2023-04-23 09:49:19 --> Total execution time: 0.1582
INFO - 2023-04-23 09:50:40 --> Config Class Initialized
INFO - 2023-04-23 09:50:40 --> Config Class Initialized
INFO - 2023-04-23 09:50:40 --> Hooks Class Initialized
INFO - 2023-04-23 09:50:40 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:50:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:50:40 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:50:40 --> Utf8 Class Initialized
INFO - 2023-04-23 09:50:40 --> Utf8 Class Initialized
INFO - 2023-04-23 09:50:40 --> URI Class Initialized
INFO - 2023-04-23 09:50:40 --> URI Class Initialized
INFO - 2023-04-23 09:50:40 --> Router Class Initialized
INFO - 2023-04-23 09:50:40 --> Output Class Initialized
INFO - 2023-04-23 09:50:40 --> Router Class Initialized
INFO - 2023-04-23 09:50:40 --> Security Class Initialized
INFO - 2023-04-23 09:50:40 --> Output Class Initialized
DEBUG - 2023-04-23 09:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:50:40 --> Security Class Initialized
INFO - 2023-04-23 09:50:40 --> Input Class Initialized
INFO - 2023-04-23 09:50:40 --> Language Class Initialized
DEBUG - 2023-04-23 09:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:50:40 --> Loader Class Initialized
INFO - 2023-04-23 09:50:40 --> Input Class Initialized
INFO - 2023-04-23 09:50:40 --> Language Class Initialized
INFO - 2023-04-23 09:50:40 --> Controller Class Initialized
DEBUG - 2023-04-23 09:50:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:50:40 --> Database Driver Class Initialized
INFO - 2023-04-23 09:50:40 --> Loader Class Initialized
INFO - 2023-04-23 09:50:40 --> Controller Class Initialized
DEBUG - 2023-04-23 09:50:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:50:40 --> Database Driver Class Initialized
INFO - 2023-04-23 09:50:40 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:50:40 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:50:40 --> Final output sent to browser
INFO - 2023-04-23 09:50:40 --> Database Driver Class Initialized
INFO - 2023-04-23 09:50:40 --> Model "Login_model" initialized
DEBUG - 2023-04-23 09:50:40 --> Total execution time: 0.0307
INFO - 2023-04-23 09:50:40 --> Config Class Initialized
INFO - 2023-04-23 09:50:40 --> Final output sent to browser
INFO - 2023-04-23 09:50:40 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:50:40 --> Total execution time: 0.1386
DEBUG - 2023-04-23 09:50:40 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:50:40 --> Config Class Initialized
INFO - 2023-04-23 09:50:40 --> Utf8 Class Initialized
INFO - 2023-04-23 09:50:40 --> Hooks Class Initialized
INFO - 2023-04-23 09:50:40 --> URI Class Initialized
DEBUG - 2023-04-23 09:50:40 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:50:40 --> Router Class Initialized
INFO - 2023-04-23 09:50:40 --> Utf8 Class Initialized
INFO - 2023-04-23 09:50:40 --> Output Class Initialized
INFO - 2023-04-23 09:50:40 --> URI Class Initialized
INFO - 2023-04-23 09:50:40 --> Security Class Initialized
INFO - 2023-04-23 09:50:40 --> Router Class Initialized
DEBUG - 2023-04-23 09:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:50:40 --> Output Class Initialized
INFO - 2023-04-23 09:50:40 --> Input Class Initialized
INFO - 2023-04-23 09:50:40 --> Security Class Initialized
INFO - 2023-04-23 09:50:40 --> Language Class Initialized
DEBUG - 2023-04-23 09:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:50:40 --> Input Class Initialized
INFO - 2023-04-23 09:50:40 --> Loader Class Initialized
INFO - 2023-04-23 09:50:40 --> Language Class Initialized
INFO - 2023-04-23 09:50:40 --> Controller Class Initialized
DEBUG - 2023-04-23 09:50:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:50:40 --> Loader Class Initialized
INFO - 2023-04-23 09:50:40 --> Controller Class Initialized
INFO - 2023-04-23 09:50:40 --> Database Driver Class Initialized
DEBUG - 2023-04-23 09:50:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:50:40 --> Database Driver Class Initialized
INFO - 2023-04-23 09:50:40 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:50:40 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:50:40 --> Final output sent to browser
DEBUG - 2023-04-23 09:50:40 --> Total execution time: 0.2640
INFO - 2023-04-23 09:50:40 --> Database Driver Class Initialized
INFO - 2023-04-23 09:50:41 --> Model "Login_model" initialized
INFO - 2023-04-23 09:50:41 --> Final output sent to browser
DEBUG - 2023-04-23 09:50:41 --> Total execution time: 0.1593
INFO - 2023-04-23 09:52:23 --> Config Class Initialized
INFO - 2023-04-23 09:52:23 --> Config Class Initialized
INFO - 2023-04-23 09:52:23 --> Hooks Class Initialized
INFO - 2023-04-23 09:52:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:52:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:52:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:52:23 --> Utf8 Class Initialized
INFO - 2023-04-23 09:52:23 --> Utf8 Class Initialized
INFO - 2023-04-23 09:52:23 --> URI Class Initialized
INFO - 2023-04-23 09:52:23 --> URI Class Initialized
INFO - 2023-04-23 09:52:23 --> Router Class Initialized
INFO - 2023-04-23 09:52:23 --> Router Class Initialized
INFO - 2023-04-23 09:52:23 --> Output Class Initialized
INFO - 2023-04-23 09:52:23 --> Security Class Initialized
DEBUG - 2023-04-23 09:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:52:23 --> Output Class Initialized
INFO - 2023-04-23 09:52:23 --> Input Class Initialized
INFO - 2023-04-23 09:52:23 --> Security Class Initialized
INFO - 2023-04-23 09:52:23 --> Language Class Initialized
DEBUG - 2023-04-23 09:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:52:23 --> Input Class Initialized
INFO - 2023-04-23 09:52:23 --> Loader Class Initialized
INFO - 2023-04-23 09:52:23 --> Language Class Initialized
INFO - 2023-04-23 09:52:23 --> Controller Class Initialized
INFO - 2023-04-23 09:52:23 --> Loader Class Initialized
DEBUG - 2023-04-23 09:52:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:52:23 --> Controller Class Initialized
DEBUG - 2023-04-23 09:52:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:52:23 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:23 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:23 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:23 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:23 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:23 --> Total execution time: 0.0730
INFO - 2023-04-23 09:52:23 --> Config Class Initialized
INFO - 2023-04-23 09:52:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:52:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:52:23 --> Utf8 Class Initialized
INFO - 2023-04-23 09:52:23 --> URI Class Initialized
INFO - 2023-04-23 09:52:23 --> Router Class Initialized
INFO - 2023-04-23 09:52:23 --> Output Class Initialized
INFO - 2023-04-23 09:52:23 --> Security Class Initialized
DEBUG - 2023-04-23 09:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:52:23 --> Input Class Initialized
INFO - 2023-04-23 09:52:23 --> Language Class Initialized
INFO - 2023-04-23 09:52:23 --> Loader Class Initialized
INFO - 2023-04-23 09:52:23 --> Controller Class Initialized
DEBUG - 2023-04-23 09:52:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:52:23 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:23 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:23 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:23 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:23 --> Total execution time: 0.0171
INFO - 2023-04-23 09:52:23 --> Model "Login_model" initialized
INFO - 2023-04-23 09:52:23 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:23 --> Total execution time: 0.2200
INFO - 2023-04-23 09:52:23 --> Config Class Initialized
INFO - 2023-04-23 09:52:23 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:52:23 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:52:23 --> Utf8 Class Initialized
INFO - 2023-04-23 09:52:23 --> URI Class Initialized
INFO - 2023-04-23 09:52:23 --> Router Class Initialized
INFO - 2023-04-23 09:52:23 --> Output Class Initialized
INFO - 2023-04-23 09:52:23 --> Security Class Initialized
DEBUG - 2023-04-23 09:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:52:23 --> Input Class Initialized
INFO - 2023-04-23 09:52:23 --> Language Class Initialized
INFO - 2023-04-23 09:52:23 --> Loader Class Initialized
INFO - 2023-04-23 09:52:23 --> Controller Class Initialized
DEBUG - 2023-04-23 09:52:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:52:23 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:23 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:23 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:23 --> Model "Login_model" initialized
INFO - 2023-04-23 09:52:23 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:23 --> Total execution time: 0.1156
INFO - 2023-04-23 09:52:35 --> Config Class Initialized
INFO - 2023-04-23 09:52:35 --> Hooks Class Initialized
INFO - 2023-04-23 09:52:35 --> Config Class Initialized
DEBUG - 2023-04-23 09:52:35 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:52:35 --> Hooks Class Initialized
INFO - 2023-04-23 09:52:35 --> Utf8 Class Initialized
DEBUG - 2023-04-23 09:52:35 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:52:35 --> URI Class Initialized
INFO - 2023-04-23 09:52:35 --> Utf8 Class Initialized
INFO - 2023-04-23 09:52:35 --> URI Class Initialized
INFO - 2023-04-23 09:52:35 --> Router Class Initialized
INFO - 2023-04-23 09:52:35 --> Output Class Initialized
INFO - 2023-04-23 09:52:35 --> Router Class Initialized
INFO - 2023-04-23 09:52:35 --> Security Class Initialized
INFO - 2023-04-23 09:52:35 --> Output Class Initialized
INFO - 2023-04-23 09:52:35 --> Security Class Initialized
DEBUG - 2023-04-23 09:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:52:35 --> Input Class Initialized
INFO - 2023-04-23 09:52:35 --> Input Class Initialized
INFO - 2023-04-23 09:52:35 --> Language Class Initialized
INFO - 2023-04-23 09:52:35 --> Language Class Initialized
INFO - 2023-04-23 09:52:35 --> Loader Class Initialized
INFO - 2023-04-23 09:52:35 --> Loader Class Initialized
INFO - 2023-04-23 09:52:35 --> Controller Class Initialized
INFO - 2023-04-23 09:52:35 --> Controller Class Initialized
DEBUG - 2023-04-23 09:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 09:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:52:35 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:35 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:35 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:35 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:35 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:35 --> Total execution time: 0.0182
INFO - 2023-04-23 09:52:35 --> Config Class Initialized
INFO - 2023-04-23 09:52:35 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:52:35 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:52:35 --> Utf8 Class Initialized
INFO - 2023-04-23 09:52:35 --> URI Class Initialized
INFO - 2023-04-23 09:52:35 --> Router Class Initialized
INFO - 2023-04-23 09:52:35 --> Output Class Initialized
INFO - 2023-04-23 09:52:35 --> Security Class Initialized
DEBUG - 2023-04-23 09:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:52:35 --> Input Class Initialized
INFO - 2023-04-23 09:52:35 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:35 --> Language Class Initialized
INFO - 2023-04-23 09:52:35 --> Loader Class Initialized
INFO - 2023-04-23 09:52:35 --> Controller Class Initialized
DEBUG - 2023-04-23 09:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:52:35 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:35 --> Model "Login_model" initialized
INFO - 2023-04-23 09:52:35 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:35 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:35 --> Total execution time: 0.1082
INFO - 2023-04-23 09:52:35 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:35 --> Total execution time: 0.1850
INFO - 2023-04-23 09:52:35 --> Config Class Initialized
INFO - 2023-04-23 09:52:35 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:52:35 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:52:35 --> Utf8 Class Initialized
INFO - 2023-04-23 09:52:35 --> URI Class Initialized
INFO - 2023-04-23 09:52:35 --> Router Class Initialized
INFO - 2023-04-23 09:52:35 --> Output Class Initialized
INFO - 2023-04-23 09:52:35 --> Security Class Initialized
DEBUG - 2023-04-23 09:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:52:35 --> Input Class Initialized
INFO - 2023-04-23 09:52:35 --> Language Class Initialized
INFO - 2023-04-23 09:52:35 --> Loader Class Initialized
INFO - 2023-04-23 09:52:35 --> Controller Class Initialized
DEBUG - 2023-04-23 09:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:52:35 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:35 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:35 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:35 --> Model "Login_model" initialized
INFO - 2023-04-23 09:52:35 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:35 --> Total execution time: 0.1102
INFO - 2023-04-23 09:52:42 --> Config Class Initialized
INFO - 2023-04-23 09:52:42 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:52:42 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:52:42 --> Utf8 Class Initialized
INFO - 2023-04-23 09:52:42 --> URI Class Initialized
INFO - 2023-04-23 09:52:42 --> Router Class Initialized
INFO - 2023-04-23 09:52:42 --> Output Class Initialized
INFO - 2023-04-23 09:52:42 --> Security Class Initialized
DEBUG - 2023-04-23 09:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:52:42 --> Input Class Initialized
INFO - 2023-04-23 09:52:42 --> Language Class Initialized
INFO - 2023-04-23 09:52:42 --> Loader Class Initialized
INFO - 2023-04-23 09:52:42 --> Controller Class Initialized
DEBUG - 2023-04-23 09:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:52:42 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:42 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:42 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:42 --> Total execution time: 0.0135
INFO - 2023-04-23 09:52:42 --> Config Class Initialized
INFO - 2023-04-23 09:52:42 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:52:42 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:52:42 --> Utf8 Class Initialized
INFO - 2023-04-23 09:52:42 --> URI Class Initialized
INFO - 2023-04-23 09:52:42 --> Router Class Initialized
INFO - 2023-04-23 09:52:42 --> Output Class Initialized
INFO - 2023-04-23 09:52:42 --> Security Class Initialized
DEBUG - 2023-04-23 09:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:52:42 --> Input Class Initialized
INFO - 2023-04-23 09:52:42 --> Language Class Initialized
INFO - 2023-04-23 09:52:42 --> Loader Class Initialized
INFO - 2023-04-23 09:52:42 --> Controller Class Initialized
DEBUG - 2023-04-23 09:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:52:42 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:42 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:42 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:42 --> Model "Login_model" initialized
INFO - 2023-04-23 09:52:42 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:42 --> Total execution time: 0.0592
INFO - 2023-04-23 09:52:42 --> Config Class Initialized
INFO - 2023-04-23 09:52:42 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:52:42 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:52:42 --> Utf8 Class Initialized
INFO - 2023-04-23 09:52:42 --> URI Class Initialized
INFO - 2023-04-23 09:52:42 --> Router Class Initialized
INFO - 2023-04-23 09:52:42 --> Output Class Initialized
INFO - 2023-04-23 09:52:42 --> Security Class Initialized
DEBUG - 2023-04-23 09:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:52:42 --> Input Class Initialized
INFO - 2023-04-23 09:52:42 --> Language Class Initialized
INFO - 2023-04-23 09:52:42 --> Loader Class Initialized
INFO - 2023-04-23 09:52:42 --> Controller Class Initialized
DEBUG - 2023-04-23 09:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:52:42 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:42 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:42 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:42 --> Total execution time: 0.0518
INFO - 2023-04-23 09:52:42 --> Config Class Initialized
INFO - 2023-04-23 09:52:42 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:52:42 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:52:42 --> Utf8 Class Initialized
INFO - 2023-04-23 09:52:42 --> URI Class Initialized
INFO - 2023-04-23 09:52:42 --> Router Class Initialized
INFO - 2023-04-23 09:52:42 --> Output Class Initialized
INFO - 2023-04-23 09:52:42 --> Security Class Initialized
DEBUG - 2023-04-23 09:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:52:42 --> Input Class Initialized
INFO - 2023-04-23 09:52:42 --> Language Class Initialized
INFO - 2023-04-23 09:52:42 --> Loader Class Initialized
INFO - 2023-04-23 09:52:42 --> Controller Class Initialized
DEBUG - 2023-04-23 09:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:52:42 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:42 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:42 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:42 --> Model "Login_model" initialized
INFO - 2023-04-23 09:52:42 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:42 --> Total execution time: 0.0208
INFO - 2023-04-23 09:52:43 --> Config Class Initialized
INFO - 2023-04-23 09:52:43 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:52:43 --> Utf8 Class Initialized
INFO - 2023-04-23 09:52:43 --> URI Class Initialized
INFO - 2023-04-23 09:52:43 --> Router Class Initialized
INFO - 2023-04-23 09:52:43 --> Output Class Initialized
INFO - 2023-04-23 09:52:43 --> Security Class Initialized
DEBUG - 2023-04-23 09:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:52:43 --> Input Class Initialized
INFO - 2023-04-23 09:52:43 --> Language Class Initialized
INFO - 2023-04-23 09:52:43 --> Loader Class Initialized
INFO - 2023-04-23 09:52:43 --> Controller Class Initialized
DEBUG - 2023-04-23 09:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:52:43 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:43 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:43 --> Total execution time: 0.0159
INFO - 2023-04-23 09:52:43 --> Config Class Initialized
INFO - 2023-04-23 09:52:43 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:52:43 --> Utf8 Class Initialized
INFO - 2023-04-23 09:52:43 --> URI Class Initialized
INFO - 2023-04-23 09:52:43 --> Router Class Initialized
INFO - 2023-04-23 09:52:43 --> Output Class Initialized
INFO - 2023-04-23 09:52:43 --> Security Class Initialized
DEBUG - 2023-04-23 09:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:52:43 --> Input Class Initialized
INFO - 2023-04-23 09:52:43 --> Language Class Initialized
INFO - 2023-04-23 09:52:43 --> Loader Class Initialized
INFO - 2023-04-23 09:52:43 --> Controller Class Initialized
DEBUG - 2023-04-23 09:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:52:43 --> Database Driver Class Initialized
INFO - 2023-04-23 09:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:52:43 --> Final output sent to browser
DEBUG - 2023-04-23 09:52:43 --> Total execution time: 0.0589
INFO - 2023-04-23 09:54:32 --> Config Class Initialized
INFO - 2023-04-23 09:54:32 --> Config Class Initialized
INFO - 2023-04-23 09:54:32 --> Hooks Class Initialized
INFO - 2023-04-23 09:54:32 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:54:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 09:54:32 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:54:32 --> Utf8 Class Initialized
INFO - 2023-04-23 09:54:32 --> Utf8 Class Initialized
INFO - 2023-04-23 09:54:32 --> URI Class Initialized
INFO - 2023-04-23 09:54:32 --> URI Class Initialized
INFO - 2023-04-23 09:54:32 --> Router Class Initialized
INFO - 2023-04-23 09:54:32 --> Router Class Initialized
INFO - 2023-04-23 09:54:32 --> Output Class Initialized
INFO - 2023-04-23 09:54:32 --> Output Class Initialized
INFO - 2023-04-23 09:54:32 --> Security Class Initialized
INFO - 2023-04-23 09:54:32 --> Security Class Initialized
DEBUG - 2023-04-23 09:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 09:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:54:32 --> Input Class Initialized
INFO - 2023-04-23 09:54:32 --> Input Class Initialized
INFO - 2023-04-23 09:54:32 --> Language Class Initialized
INFO - 2023-04-23 09:54:32 --> Language Class Initialized
INFO - 2023-04-23 09:54:32 --> Loader Class Initialized
INFO - 2023-04-23 09:54:32 --> Loader Class Initialized
INFO - 2023-04-23 09:54:32 --> Controller Class Initialized
INFO - 2023-04-23 09:54:32 --> Controller Class Initialized
DEBUG - 2023-04-23 09:54:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-23 09:54:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:54:32 --> Database Driver Class Initialized
INFO - 2023-04-23 09:54:32 --> Database Driver Class Initialized
INFO - 2023-04-23 09:54:32 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:54:32 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:54:32 --> Final output sent to browser
DEBUG - 2023-04-23 09:54:32 --> Total execution time: 0.0515
INFO - 2023-04-23 09:54:32 --> Config Class Initialized
INFO - 2023-04-23 09:54:32 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:54:32 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:54:32 --> Utf8 Class Initialized
INFO - 2023-04-23 09:54:32 --> URI Class Initialized
INFO - 2023-04-23 09:54:32 --> Router Class Initialized
INFO - 2023-04-23 09:54:32 --> Output Class Initialized
INFO - 2023-04-23 09:54:32 --> Security Class Initialized
DEBUG - 2023-04-23 09:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:54:32 --> Input Class Initialized
INFO - 2023-04-23 09:54:32 --> Language Class Initialized
INFO - 2023-04-23 09:54:32 --> Loader Class Initialized
INFO - 2023-04-23 09:54:32 --> Controller Class Initialized
DEBUG - 2023-04-23 09:54:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:54:32 --> Database Driver Class Initialized
INFO - 2023-04-23 09:54:32 --> Database Driver Class Initialized
INFO - 2023-04-23 09:54:32 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:54:32 --> Final output sent to browser
DEBUG - 2023-04-23 09:54:32 --> Total execution time: 0.0107
INFO - 2023-04-23 09:54:32 --> Model "Login_model" initialized
INFO - 2023-04-23 09:54:32 --> Final output sent to browser
DEBUG - 2023-04-23 09:54:32 --> Total execution time: 0.1623
INFO - 2023-04-23 09:54:32 --> Config Class Initialized
INFO - 2023-04-23 09:54:32 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:54:32 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:54:32 --> Utf8 Class Initialized
INFO - 2023-04-23 09:54:32 --> URI Class Initialized
INFO - 2023-04-23 09:54:32 --> Router Class Initialized
INFO - 2023-04-23 09:54:32 --> Output Class Initialized
INFO - 2023-04-23 09:54:32 --> Security Class Initialized
DEBUG - 2023-04-23 09:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:54:32 --> Input Class Initialized
INFO - 2023-04-23 09:54:32 --> Language Class Initialized
INFO - 2023-04-23 09:54:32 --> Loader Class Initialized
INFO - 2023-04-23 09:54:32 --> Controller Class Initialized
DEBUG - 2023-04-23 09:54:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:54:32 --> Database Driver Class Initialized
INFO - 2023-04-23 09:54:32 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:54:32 --> Database Driver Class Initialized
INFO - 2023-04-23 09:54:32 --> Model "Login_model" initialized
INFO - 2023-04-23 09:54:32 --> Final output sent to browser
DEBUG - 2023-04-23 09:54:32 --> Total execution time: 0.0693
INFO - 2023-04-23 09:54:52 --> Config Class Initialized
INFO - 2023-04-23 09:54:52 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:54:52 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:54:52 --> Utf8 Class Initialized
INFO - 2023-04-23 09:54:52 --> URI Class Initialized
INFO - 2023-04-23 09:54:52 --> Router Class Initialized
INFO - 2023-04-23 09:54:52 --> Output Class Initialized
INFO - 2023-04-23 09:54:52 --> Security Class Initialized
DEBUG - 2023-04-23 09:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:54:52 --> Input Class Initialized
INFO - 2023-04-23 09:54:52 --> Language Class Initialized
INFO - 2023-04-23 09:54:52 --> Loader Class Initialized
INFO - 2023-04-23 09:54:52 --> Controller Class Initialized
DEBUG - 2023-04-23 09:54:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:54:52 --> Database Driver Class Initialized
INFO - 2023-04-23 09:54:52 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:54:52 --> Final output sent to browser
DEBUG - 2023-04-23 09:54:52 --> Total execution time: 0.0120
INFO - 2023-04-23 09:54:52 --> Config Class Initialized
INFO - 2023-04-23 09:54:52 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:54:52 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:54:52 --> Utf8 Class Initialized
INFO - 2023-04-23 09:54:52 --> URI Class Initialized
INFO - 2023-04-23 09:54:52 --> Router Class Initialized
INFO - 2023-04-23 09:54:52 --> Output Class Initialized
INFO - 2023-04-23 09:54:52 --> Security Class Initialized
DEBUG - 2023-04-23 09:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:54:52 --> Input Class Initialized
INFO - 2023-04-23 09:54:52 --> Language Class Initialized
INFO - 2023-04-23 09:54:52 --> Loader Class Initialized
INFO - 2023-04-23 09:54:52 --> Controller Class Initialized
DEBUG - 2023-04-23 09:54:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:54:52 --> Database Driver Class Initialized
INFO - 2023-04-23 09:54:52 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:54:52 --> Final output sent to browser
DEBUG - 2023-04-23 09:54:52 --> Total execution time: 0.0510
INFO - 2023-04-23 09:54:52 --> Config Class Initialized
INFO - 2023-04-23 09:54:52 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:54:52 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:54:52 --> Utf8 Class Initialized
INFO - 2023-04-23 09:54:52 --> URI Class Initialized
INFO - 2023-04-23 09:54:52 --> Router Class Initialized
INFO - 2023-04-23 09:54:52 --> Output Class Initialized
INFO - 2023-04-23 09:54:52 --> Security Class Initialized
DEBUG - 2023-04-23 09:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:54:52 --> Input Class Initialized
INFO - 2023-04-23 09:54:52 --> Language Class Initialized
INFO - 2023-04-23 09:54:52 --> Loader Class Initialized
INFO - 2023-04-23 09:54:52 --> Controller Class Initialized
DEBUG - 2023-04-23 09:54:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:54:52 --> Database Driver Class Initialized
INFO - 2023-04-23 09:54:52 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:54:52 --> Final output sent to browser
DEBUG - 2023-04-23 09:54:52 --> Total execution time: 0.0503
INFO - 2023-04-23 09:54:52 --> Config Class Initialized
INFO - 2023-04-23 09:54:52 --> Hooks Class Initialized
DEBUG - 2023-04-23 09:54:52 --> UTF-8 Support Enabled
INFO - 2023-04-23 09:54:52 --> Utf8 Class Initialized
INFO - 2023-04-23 09:54:52 --> URI Class Initialized
INFO - 2023-04-23 09:54:52 --> Router Class Initialized
INFO - 2023-04-23 09:54:52 --> Output Class Initialized
INFO - 2023-04-23 09:54:52 --> Security Class Initialized
DEBUG - 2023-04-23 09:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 09:54:52 --> Input Class Initialized
INFO - 2023-04-23 09:54:52 --> Language Class Initialized
INFO - 2023-04-23 09:54:52 --> Loader Class Initialized
INFO - 2023-04-23 09:54:52 --> Controller Class Initialized
DEBUG - 2023-04-23 09:54:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 09:54:52 --> Database Driver Class Initialized
INFO - 2023-04-23 09:54:52 --> Model "Cluster_model" initialized
INFO - 2023-04-23 09:54:52 --> Final output sent to browser
DEBUG - 2023-04-23 09:54:52 --> Total execution time: 0.0547
INFO - 2023-04-23 10:27:04 --> Config Class Initialized
INFO - 2023-04-23 10:27:04 --> Config Class Initialized
INFO - 2023-04-23 10:27:04 --> Hooks Class Initialized
INFO - 2023-04-23 10:27:04 --> Hooks Class Initialized
DEBUG - 2023-04-23 10:27:04 --> UTF-8 Support Enabled
INFO - 2023-04-23 10:27:04 --> Utf8 Class Initialized
DEBUG - 2023-04-23 10:27:04 --> UTF-8 Support Enabled
INFO - 2023-04-23 10:27:04 --> Utf8 Class Initialized
INFO - 2023-04-23 10:27:04 --> URI Class Initialized
INFO - 2023-04-23 10:27:04 --> URI Class Initialized
INFO - 2023-04-23 10:27:04 --> Router Class Initialized
INFO - 2023-04-23 10:27:04 --> Router Class Initialized
INFO - 2023-04-23 10:27:04 --> Output Class Initialized
INFO - 2023-04-23 10:27:04 --> Output Class Initialized
INFO - 2023-04-23 10:27:04 --> Security Class Initialized
INFO - 2023-04-23 10:27:04 --> Security Class Initialized
DEBUG - 2023-04-23 10:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 10:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 10:27:04 --> Input Class Initialized
INFO - 2023-04-23 10:27:04 --> Input Class Initialized
INFO - 2023-04-23 10:27:04 --> Language Class Initialized
INFO - 2023-04-23 10:27:04 --> Language Class Initialized
INFO - 2023-04-23 10:27:04 --> Loader Class Initialized
INFO - 2023-04-23 10:27:04 --> Controller Class Initialized
DEBUG - 2023-04-23 10:27:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 10:27:04 --> Database Driver Class Initialized
INFO - 2023-04-23 10:27:04 --> Loader Class Initialized
INFO - 2023-04-23 10:27:04 --> Controller Class Initialized
DEBUG - 2023-04-23 10:27:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 10:27:04 --> Database Driver Class Initialized
INFO - 2023-04-23 10:27:04 --> Model "Cluster_model" initialized
INFO - 2023-04-23 10:27:04 --> Model "Cluster_model" initialized
INFO - 2023-04-23 10:27:04 --> Final output sent to browser
DEBUG - 2023-04-23 10:27:04 --> Total execution time: 0.0275
INFO - 2023-04-23 10:27:04 --> Database Driver Class Initialized
INFO - 2023-04-23 10:27:04 --> Config Class Initialized
INFO - 2023-04-23 10:27:04 --> Hooks Class Initialized
DEBUG - 2023-04-23 10:27:04 --> UTF-8 Support Enabled
INFO - 2023-04-23 10:27:04 --> Utf8 Class Initialized
INFO - 2023-04-23 10:27:04 --> URI Class Initialized
INFO - 2023-04-23 10:27:04 --> Router Class Initialized
INFO - 2023-04-23 10:27:04 --> Output Class Initialized
INFO - 2023-04-23 10:27:04 --> Security Class Initialized
DEBUG - 2023-04-23 10:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 10:27:04 --> Input Class Initialized
INFO - 2023-04-23 10:27:04 --> Language Class Initialized
INFO - 2023-04-23 10:27:04 --> Loader Class Initialized
INFO - 2023-04-23 10:27:04 --> Controller Class Initialized
DEBUG - 2023-04-23 10:27:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 10:27:04 --> Model "Login_model" initialized
INFO - 2023-04-23 10:27:04 --> Database Driver Class Initialized
INFO - 2023-04-23 10:27:05 --> Model "Cluster_model" initialized
INFO - 2023-04-23 10:27:05 --> Final output sent to browser
DEBUG - 2023-04-23 10:27:05 --> Total execution time: 0.0634
INFO - 2023-04-23 10:27:05 --> Final output sent to browser
DEBUG - 2023-04-23 10:27:05 --> Total execution time: 0.1355
INFO - 2023-04-23 10:27:05 --> Config Class Initialized
INFO - 2023-04-23 10:27:05 --> Hooks Class Initialized
DEBUG - 2023-04-23 10:27:05 --> UTF-8 Support Enabled
INFO - 2023-04-23 10:27:05 --> Utf8 Class Initialized
INFO - 2023-04-23 10:27:05 --> URI Class Initialized
INFO - 2023-04-23 10:27:05 --> Router Class Initialized
INFO - 2023-04-23 10:27:05 --> Output Class Initialized
INFO - 2023-04-23 10:27:05 --> Security Class Initialized
DEBUG - 2023-04-23 10:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 10:27:05 --> Input Class Initialized
INFO - 2023-04-23 10:27:05 --> Language Class Initialized
INFO - 2023-04-23 10:27:05 --> Loader Class Initialized
INFO - 2023-04-23 10:27:05 --> Controller Class Initialized
DEBUG - 2023-04-23 10:27:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 10:27:05 --> Database Driver Class Initialized
INFO - 2023-04-23 10:27:05 --> Model "Cluster_model" initialized
INFO - 2023-04-23 10:27:05 --> Database Driver Class Initialized
INFO - 2023-04-23 10:27:05 --> Model "Login_model" initialized
INFO - 2023-04-23 10:27:05 --> Final output sent to browser
DEBUG - 2023-04-23 10:27:05 --> Total execution time: 0.1614
INFO - 2023-04-23 10:27:07 --> Config Class Initialized
INFO - 2023-04-23 10:27:07 --> Hooks Class Initialized
DEBUG - 2023-04-23 10:27:07 --> UTF-8 Support Enabled
INFO - 2023-04-23 10:27:07 --> Utf8 Class Initialized
INFO - 2023-04-23 10:27:07 --> URI Class Initialized
INFO - 2023-04-23 10:27:07 --> Router Class Initialized
INFO - 2023-04-23 10:27:07 --> Output Class Initialized
INFO - 2023-04-23 10:27:07 --> Security Class Initialized
DEBUG - 2023-04-23 10:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 10:27:07 --> Input Class Initialized
INFO - 2023-04-23 10:27:07 --> Language Class Initialized
INFO - 2023-04-23 10:27:07 --> Loader Class Initialized
INFO - 2023-04-23 10:27:07 --> Controller Class Initialized
DEBUG - 2023-04-23 10:27:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 10:27:07 --> Database Driver Class Initialized
INFO - 2023-04-23 10:27:07 --> Model "Cluster_model" initialized
INFO - 2023-04-23 10:27:07 --> Final output sent to browser
DEBUG - 2023-04-23 10:27:07 --> Total execution time: 0.0172
INFO - 2023-04-23 10:27:07 --> Config Class Initialized
INFO - 2023-04-23 10:27:07 --> Hooks Class Initialized
DEBUG - 2023-04-23 10:27:07 --> UTF-8 Support Enabled
INFO - 2023-04-23 10:27:07 --> Utf8 Class Initialized
INFO - 2023-04-23 10:27:07 --> URI Class Initialized
INFO - 2023-04-23 10:27:07 --> Router Class Initialized
INFO - 2023-04-23 10:27:07 --> Output Class Initialized
INFO - 2023-04-23 10:27:07 --> Security Class Initialized
DEBUG - 2023-04-23 10:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 10:27:07 --> Input Class Initialized
INFO - 2023-04-23 10:27:07 --> Language Class Initialized
INFO - 2023-04-23 10:27:07 --> Loader Class Initialized
INFO - 2023-04-23 10:27:07 --> Controller Class Initialized
DEBUG - 2023-04-23 10:27:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 10:27:07 --> Database Driver Class Initialized
INFO - 2023-04-23 10:27:07 --> Model "Cluster_model" initialized
INFO - 2023-04-23 10:27:07 --> Final output sent to browser
DEBUG - 2023-04-23 10:27:07 --> Total execution time: 0.0575
INFO - 2023-04-23 10:27:07 --> Config Class Initialized
INFO - 2023-04-23 10:27:07 --> Hooks Class Initialized
DEBUG - 2023-04-23 10:27:07 --> UTF-8 Support Enabled
INFO - 2023-04-23 10:27:07 --> Utf8 Class Initialized
INFO - 2023-04-23 10:27:07 --> URI Class Initialized
INFO - 2023-04-23 10:27:07 --> Router Class Initialized
INFO - 2023-04-23 10:27:07 --> Output Class Initialized
INFO - 2023-04-23 10:27:07 --> Security Class Initialized
DEBUG - 2023-04-23 10:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 10:27:07 --> Input Class Initialized
INFO - 2023-04-23 10:27:07 --> Language Class Initialized
INFO - 2023-04-23 10:27:07 --> Loader Class Initialized
INFO - 2023-04-23 10:27:07 --> Controller Class Initialized
DEBUG - 2023-04-23 10:27:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 10:27:07 --> Database Driver Class Initialized
INFO - 2023-04-23 10:27:07 --> Model "Cluster_model" initialized
INFO - 2023-04-23 10:27:07 --> Final output sent to browser
DEBUG - 2023-04-23 10:27:07 --> Total execution time: 0.0665
INFO - 2023-04-23 10:27:07 --> Config Class Initialized
INFO - 2023-04-23 10:27:07 --> Hooks Class Initialized
DEBUG - 2023-04-23 10:27:07 --> UTF-8 Support Enabled
INFO - 2023-04-23 10:27:07 --> Utf8 Class Initialized
INFO - 2023-04-23 10:27:07 --> URI Class Initialized
INFO - 2023-04-23 10:27:07 --> Router Class Initialized
INFO - 2023-04-23 10:27:07 --> Output Class Initialized
INFO - 2023-04-23 10:27:07 --> Security Class Initialized
DEBUG - 2023-04-23 10:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 10:27:07 --> Input Class Initialized
INFO - 2023-04-23 10:27:07 --> Language Class Initialized
INFO - 2023-04-23 10:27:07 --> Loader Class Initialized
INFO - 2023-04-23 10:27:07 --> Controller Class Initialized
DEBUG - 2023-04-23 10:27:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 10:27:07 --> Database Driver Class Initialized
INFO - 2023-04-23 10:27:07 --> Model "Cluster_model" initialized
INFO - 2023-04-23 10:27:07 --> Final output sent to browser
DEBUG - 2023-04-23 10:27:07 --> Total execution time: 0.0536
INFO - 2023-04-23 10:58:11 --> Config Class Initialized
INFO - 2023-04-23 10:58:11 --> Config Class Initialized
INFO - 2023-04-23 10:58:11 --> Hooks Class Initialized
INFO - 2023-04-23 10:58:11 --> Hooks Class Initialized
DEBUG - 2023-04-23 10:58:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-23 10:58:11 --> UTF-8 Support Enabled
INFO - 2023-04-23 10:58:11 --> Utf8 Class Initialized
INFO - 2023-04-23 10:58:11 --> Utf8 Class Initialized
INFO - 2023-04-23 10:58:11 --> URI Class Initialized
INFO - 2023-04-23 10:58:11 --> URI Class Initialized
INFO - 2023-04-23 10:58:11 --> Router Class Initialized
INFO - 2023-04-23 10:58:11 --> Router Class Initialized
INFO - 2023-04-23 10:58:11 --> Output Class Initialized
INFO - 2023-04-23 10:58:11 --> Output Class Initialized
INFO - 2023-04-23 10:58:11 --> Security Class Initialized
INFO - 2023-04-23 10:58:11 --> Security Class Initialized
DEBUG - 2023-04-23 10:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-23 10:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 10:58:11 --> Input Class Initialized
INFO - 2023-04-23 10:58:11 --> Input Class Initialized
INFO - 2023-04-23 10:58:11 --> Language Class Initialized
INFO - 2023-04-23 10:58:11 --> Language Class Initialized
INFO - 2023-04-23 10:58:11 --> Loader Class Initialized
INFO - 2023-04-23 10:58:11 --> Controller Class Initialized
DEBUG - 2023-04-23 10:58:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 10:58:11 --> Database Driver Class Initialized
INFO - 2023-04-23 10:58:11 --> Loader Class Initialized
INFO - 2023-04-23 10:58:11 --> Controller Class Initialized
DEBUG - 2023-04-23 10:58:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 10:58:11 --> Database Driver Class Initialized
INFO - 2023-04-23 10:58:11 --> Model "Cluster_model" initialized
INFO - 2023-04-23 10:58:11 --> Model "Cluster_model" initialized
INFO - 2023-04-23 10:58:11 --> Final output sent to browser
DEBUG - 2023-04-23 10:58:11 --> Total execution time: 0.1472
INFO - 2023-04-23 10:58:11 --> Database Driver Class Initialized
INFO - 2023-04-23 10:58:11 --> Config Class Initialized
INFO - 2023-04-23 10:58:11 --> Hooks Class Initialized
DEBUG - 2023-04-23 10:58:11 --> UTF-8 Support Enabled
INFO - 2023-04-23 10:58:11 --> Utf8 Class Initialized
INFO - 2023-04-23 10:58:11 --> URI Class Initialized
INFO - 2023-04-23 10:58:11 --> Router Class Initialized
INFO - 2023-04-23 10:58:11 --> Output Class Initialized
INFO - 2023-04-23 10:58:11 --> Security Class Initialized
DEBUG - 2023-04-23 10:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 10:58:11 --> Input Class Initialized
INFO - 2023-04-23 10:58:11 --> Language Class Initialized
INFO - 2023-04-23 10:58:11 --> Loader Class Initialized
INFO - 2023-04-23 10:58:11 --> Controller Class Initialized
DEBUG - 2023-04-23 10:58:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 10:58:11 --> Database Driver Class Initialized
INFO - 2023-04-23 10:58:11 --> Model "Login_model" initialized
INFO - 2023-04-23 10:58:11 --> Model "Cluster_model" initialized
INFO - 2023-04-23 10:58:11 --> Final output sent to browser
DEBUG - 2023-04-23 10:58:11 --> Total execution time: 0.0540
INFO - 2023-04-23 10:58:11 --> Final output sent to browser
DEBUG - 2023-04-23 10:58:11 --> Total execution time: 0.2434
INFO - 2023-04-23 10:58:11 --> Config Class Initialized
INFO - 2023-04-23 10:58:12 --> Hooks Class Initialized
DEBUG - 2023-04-23 10:58:12 --> UTF-8 Support Enabled
INFO - 2023-04-23 10:58:12 --> Utf8 Class Initialized
INFO - 2023-04-23 10:58:12 --> URI Class Initialized
INFO - 2023-04-23 10:58:12 --> Router Class Initialized
INFO - 2023-04-23 10:58:12 --> Output Class Initialized
INFO - 2023-04-23 10:58:12 --> Security Class Initialized
DEBUG - 2023-04-23 10:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-23 10:58:12 --> Input Class Initialized
INFO - 2023-04-23 10:58:12 --> Language Class Initialized
INFO - 2023-04-23 10:58:12 --> Loader Class Initialized
INFO - 2023-04-23 10:58:12 --> Controller Class Initialized
DEBUG - 2023-04-23 10:58:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-23 10:58:12 --> Database Driver Class Initialized
INFO - 2023-04-23 10:58:12 --> Model "Cluster_model" initialized
INFO - 2023-04-23 10:58:12 --> Database Driver Class Initialized
INFO - 2023-04-23 10:58:12 --> Model "Login_model" initialized
INFO - 2023-04-23 10:58:12 --> Final output sent to browser
DEBUG - 2023-04-23 10:58:12 --> Total execution time: 0.1081
