<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-08 05:59:28 --> Config Class Initialized
INFO - 2023-03-08 05:59:28 --> Hooks Class Initialized
DEBUG - 2023-03-08 05:59:28 --> UTF-8 Support Enabled
INFO - 2023-03-08 05:59:28 --> Utf8 Class Initialized
INFO - 2023-03-08 05:59:28 --> URI Class Initialized
INFO - 2023-03-08 05:59:28 --> Router Class Initialized
INFO - 2023-03-08 05:59:28 --> Output Class Initialized
INFO - 2023-03-08 05:59:28 --> Security Class Initialized
DEBUG - 2023-03-08 05:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 05:59:28 --> Input Class Initialized
INFO - 2023-03-08 05:59:28 --> Language Class Initialized
INFO - 2023-03-08 05:59:28 --> Loader Class Initialized
INFO - 2023-03-08 05:59:28 --> Controller Class Initialized
INFO - 2023-03-08 05:59:28 --> Helper loaded: form_helper
INFO - 2023-03-08 05:59:28 --> Helper loaded: url_helper
DEBUG - 2023-03-08 05:59:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 05:59:28 --> Model "Change_model" initialized
INFO - 2023-03-08 05:59:28 --> Model "Grafana_model" initialized
INFO - 2023-03-08 05:59:28 --> Final output sent to browser
DEBUG - 2023-03-08 05:59:28 --> Total execution time: 0.0425
INFO - 2023-03-08 05:59:28 --> Config Class Initialized
INFO - 2023-03-08 05:59:28 --> Hooks Class Initialized
DEBUG - 2023-03-08 05:59:28 --> UTF-8 Support Enabled
INFO - 2023-03-08 05:59:28 --> Utf8 Class Initialized
INFO - 2023-03-08 05:59:28 --> URI Class Initialized
INFO - 2023-03-08 05:59:28 --> Router Class Initialized
INFO - 2023-03-08 05:59:28 --> Output Class Initialized
INFO - 2023-03-08 05:59:28 --> Security Class Initialized
DEBUG - 2023-03-08 05:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 05:59:28 --> Input Class Initialized
INFO - 2023-03-08 05:59:28 --> Language Class Initialized
INFO - 2023-03-08 05:59:28 --> Loader Class Initialized
INFO - 2023-03-08 05:59:28 --> Controller Class Initialized
INFO - 2023-03-08 05:59:28 --> Helper loaded: form_helper
INFO - 2023-03-08 05:59:28 --> Helper loaded: url_helper
DEBUG - 2023-03-08 05:59:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 05:59:28 --> Final output sent to browser
DEBUG - 2023-03-08 05:59:28 --> Total execution time: 0.0395
INFO - 2023-03-08 05:59:28 --> Config Class Initialized
INFO - 2023-03-08 05:59:28 --> Hooks Class Initialized
DEBUG - 2023-03-08 05:59:28 --> UTF-8 Support Enabled
INFO - 2023-03-08 05:59:28 --> Utf8 Class Initialized
INFO - 2023-03-08 05:59:28 --> URI Class Initialized
INFO - 2023-03-08 05:59:28 --> Router Class Initialized
INFO - 2023-03-08 05:59:28 --> Output Class Initialized
INFO - 2023-03-08 05:59:28 --> Security Class Initialized
DEBUG - 2023-03-08 05:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 05:59:28 --> Input Class Initialized
INFO - 2023-03-08 05:59:28 --> Language Class Initialized
INFO - 2023-03-08 05:59:28 --> Loader Class Initialized
INFO - 2023-03-08 05:59:28 --> Controller Class Initialized
INFO - 2023-03-08 05:59:28 --> Helper loaded: form_helper
INFO - 2023-03-08 05:59:28 --> Helper loaded: url_helper
DEBUG - 2023-03-08 05:59:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 05:59:28 --> Database Driver Class Initialized
INFO - 2023-03-08 05:59:28 --> Model "Login_model" initialized
INFO - 2023-03-08 05:59:28 --> Final output sent to browser
DEBUG - 2023-03-08 05:59:28 --> Total execution time: 0.0228
INFO - 2023-03-08 05:59:28 --> Config Class Initialized
INFO - 2023-03-08 05:59:28 --> Hooks Class Initialized
DEBUG - 2023-03-08 05:59:28 --> UTF-8 Support Enabled
INFO - 2023-03-08 05:59:28 --> Utf8 Class Initialized
INFO - 2023-03-08 05:59:28 --> URI Class Initialized
INFO - 2023-03-08 05:59:28 --> Router Class Initialized
INFO - 2023-03-08 05:59:28 --> Output Class Initialized
INFO - 2023-03-08 05:59:28 --> Security Class Initialized
DEBUG - 2023-03-08 05:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 05:59:28 --> Input Class Initialized
INFO - 2023-03-08 05:59:28 --> Language Class Initialized
INFO - 2023-03-08 05:59:28 --> Loader Class Initialized
INFO - 2023-03-08 05:59:28 --> Controller Class Initialized
DEBUG - 2023-03-08 05:59:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 05:59:28 --> Database Driver Class Initialized
INFO - 2023-03-08 05:59:28 --> Model "Cluster_model" initialized
INFO - 2023-03-08 05:59:28 --> Final output sent to browser
DEBUG - 2023-03-08 05:59:28 --> Total execution time: 0.0988
INFO - 2023-03-08 05:59:28 --> Config Class Initialized
INFO - 2023-03-08 05:59:28 --> Hooks Class Initialized
DEBUG - 2023-03-08 05:59:28 --> UTF-8 Support Enabled
INFO - 2023-03-08 05:59:28 --> Utf8 Class Initialized
INFO - 2023-03-08 05:59:28 --> URI Class Initialized
INFO - 2023-03-08 05:59:28 --> Router Class Initialized
INFO - 2023-03-08 05:59:28 --> Output Class Initialized
INFO - 2023-03-08 05:59:28 --> Security Class Initialized
DEBUG - 2023-03-08 05:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 05:59:28 --> Input Class Initialized
INFO - 2023-03-08 05:59:28 --> Language Class Initialized
INFO - 2023-03-08 05:59:28 --> Loader Class Initialized
INFO - 2023-03-08 05:59:28 --> Controller Class Initialized
DEBUG - 2023-03-08 05:59:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 05:59:28 --> Database Driver Class Initialized
INFO - 2023-03-08 05:59:28 --> Model "Cluster_model" initialized
INFO - 2023-03-08 05:59:28 --> Final output sent to browser
DEBUG - 2023-03-08 05:59:28 --> Total execution time: 0.0156
INFO - 2023-03-08 05:59:29 --> Config Class Initialized
INFO - 2023-03-08 05:59:29 --> Hooks Class Initialized
DEBUG - 2023-03-08 05:59:29 --> UTF-8 Support Enabled
INFO - 2023-03-08 05:59:29 --> Utf8 Class Initialized
INFO - 2023-03-08 05:59:29 --> URI Class Initialized
INFO - 2023-03-08 05:59:29 --> Router Class Initialized
INFO - 2023-03-08 05:59:29 --> Output Class Initialized
INFO - 2023-03-08 05:59:29 --> Security Class Initialized
DEBUG - 2023-03-08 05:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 05:59:29 --> Input Class Initialized
INFO - 2023-03-08 05:59:29 --> Language Class Initialized
INFO - 2023-03-08 05:59:29 --> Loader Class Initialized
INFO - 2023-03-08 05:59:29 --> Controller Class Initialized
DEBUG - 2023-03-08 05:59:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 05:59:29 --> Database Driver Class Initialized
INFO - 2023-03-08 05:59:29 --> Model "Cluster_model" initialized
INFO - 2023-03-08 05:59:29 --> Database Driver Class Initialized
INFO - 2023-03-08 05:59:29 --> Model "Login_model" initialized
INFO - 2023-03-08 05:59:29 --> Final output sent to browser
DEBUG - 2023-03-08 05:59:29 --> Total execution time: 0.1234
INFO - 2023-03-08 05:59:29 --> Config Class Initialized
INFO - 2023-03-08 05:59:29 --> Hooks Class Initialized
DEBUG - 2023-03-08 05:59:29 --> UTF-8 Support Enabled
INFO - 2023-03-08 05:59:29 --> Utf8 Class Initialized
INFO - 2023-03-08 05:59:29 --> URI Class Initialized
INFO - 2023-03-08 05:59:29 --> Router Class Initialized
INFO - 2023-03-08 05:59:29 --> Output Class Initialized
INFO - 2023-03-08 05:59:29 --> Security Class Initialized
DEBUG - 2023-03-08 05:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 05:59:29 --> Input Class Initialized
INFO - 2023-03-08 05:59:29 --> Language Class Initialized
INFO - 2023-03-08 05:59:29 --> Loader Class Initialized
INFO - 2023-03-08 05:59:29 --> Controller Class Initialized
DEBUG - 2023-03-08 05:59:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 05:59:29 --> Database Driver Class Initialized
INFO - 2023-03-08 05:59:29 --> Model "Cluster_model" initialized
INFO - 2023-03-08 05:59:29 --> Database Driver Class Initialized
INFO - 2023-03-08 05:59:29 --> Model "Login_model" initialized
INFO - 2023-03-08 05:59:29 --> Final output sent to browser
DEBUG - 2023-03-08 05:59:29 --> Total execution time: 0.0747
INFO - 2023-03-08 06:01:45 --> Config Class Initialized
INFO - 2023-03-08 06:01:45 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:01:45 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:01:45 --> Utf8 Class Initialized
INFO - 2023-03-08 06:01:45 --> URI Class Initialized
INFO - 2023-03-08 06:01:45 --> Router Class Initialized
INFO - 2023-03-08 06:01:45 --> Output Class Initialized
INFO - 2023-03-08 06:01:45 --> Security Class Initialized
DEBUG - 2023-03-08 06:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:01:45 --> Input Class Initialized
INFO - 2023-03-08 06:01:45 --> Language Class Initialized
INFO - 2023-03-08 06:01:45 --> Loader Class Initialized
INFO - 2023-03-08 06:01:45 --> Controller Class Initialized
DEBUG - 2023-03-08 06:01:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:01:45 --> Database Driver Class Initialized
INFO - 2023-03-08 06:01:45 --> Final output sent to browser
DEBUG - 2023-03-08 06:01:45 --> Total execution time: 0.0180
INFO - 2023-03-08 06:01:45 --> Config Class Initialized
INFO - 2023-03-08 06:01:45 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:01:45 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:01:45 --> Utf8 Class Initialized
INFO - 2023-03-08 06:01:45 --> URI Class Initialized
INFO - 2023-03-08 06:01:45 --> Router Class Initialized
INFO - 2023-03-08 06:01:45 --> Output Class Initialized
INFO - 2023-03-08 06:01:45 --> Security Class Initialized
DEBUG - 2023-03-08 06:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:01:45 --> Input Class Initialized
INFO - 2023-03-08 06:01:45 --> Language Class Initialized
INFO - 2023-03-08 06:01:45 --> Loader Class Initialized
INFO - 2023-03-08 06:01:45 --> Controller Class Initialized
DEBUG - 2023-03-08 06:01:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:01:45 --> Database Driver Class Initialized
INFO - 2023-03-08 06:02:08 --> Config Class Initialized
INFO - 2023-03-08 06:02:08 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:02:08 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:02:08 --> Utf8 Class Initialized
INFO - 2023-03-08 06:02:08 --> URI Class Initialized
INFO - 2023-03-08 06:02:08 --> Router Class Initialized
INFO - 2023-03-08 06:02:08 --> Output Class Initialized
INFO - 2023-03-08 06:02:08 --> Security Class Initialized
DEBUG - 2023-03-08 06:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:02:08 --> Input Class Initialized
INFO - 2023-03-08 06:02:08 --> Language Class Initialized
INFO - 2023-03-08 06:02:08 --> Loader Class Initialized
INFO - 2023-03-08 06:02:08 --> Controller Class Initialized
DEBUG - 2023-03-08 06:02:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:02:08 --> Database Driver Class Initialized
INFO - 2023-03-08 06:02:08 --> Final output sent to browser
DEBUG - 2023-03-08 06:02:08 --> Total execution time: 0.0534
INFO - 2023-03-08 06:02:08 --> Config Class Initialized
INFO - 2023-03-08 06:02:08 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:02:08 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:02:08 --> Utf8 Class Initialized
INFO - 2023-03-08 06:02:08 --> URI Class Initialized
INFO - 2023-03-08 06:02:08 --> Router Class Initialized
INFO - 2023-03-08 06:02:08 --> Output Class Initialized
INFO - 2023-03-08 06:02:08 --> Security Class Initialized
DEBUG - 2023-03-08 06:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:02:08 --> Input Class Initialized
INFO - 2023-03-08 06:02:08 --> Language Class Initialized
INFO - 2023-03-08 06:02:08 --> Loader Class Initialized
INFO - 2023-03-08 06:02:08 --> Controller Class Initialized
DEBUG - 2023-03-08 06:02:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:02:08 --> Database Driver Class Initialized
INFO - 2023-03-08 06:03:00 --> Final output sent to browser
DEBUG - 2023-03-08 06:03:00 --> Total execution time: 75.0123
INFO - 2023-03-08 06:03:23 --> Final output sent to browser
DEBUG - 2023-03-08 06:03:23 --> Total execution time: 75.0122
INFO - 2023-03-08 06:03:40 --> Config Class Initialized
INFO - 2023-03-08 06:03:40 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:03:40 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:03:40 --> Utf8 Class Initialized
INFO - 2023-03-08 06:03:40 --> URI Class Initialized
INFO - 2023-03-08 06:03:40 --> Router Class Initialized
INFO - 2023-03-08 06:03:40 --> Output Class Initialized
INFO - 2023-03-08 06:03:40 --> Security Class Initialized
DEBUG - 2023-03-08 06:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:03:40 --> Input Class Initialized
INFO - 2023-03-08 06:03:40 --> Language Class Initialized
INFO - 2023-03-08 06:03:40 --> Loader Class Initialized
INFO - 2023-03-08 06:03:40 --> Controller Class Initialized
DEBUG - 2023-03-08 06:03:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:03:40 --> Database Driver Class Initialized
INFO - 2023-03-08 06:03:40 --> Final output sent to browser
DEBUG - 2023-03-08 06:03:40 --> Total execution time: 0.0218
INFO - 2023-03-08 06:03:40 --> Config Class Initialized
INFO - 2023-03-08 06:03:40 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:03:40 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:03:40 --> Utf8 Class Initialized
INFO - 2023-03-08 06:03:40 --> URI Class Initialized
INFO - 2023-03-08 06:03:40 --> Router Class Initialized
INFO - 2023-03-08 06:03:40 --> Output Class Initialized
INFO - 2023-03-08 06:03:40 --> Security Class Initialized
DEBUG - 2023-03-08 06:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:03:40 --> Input Class Initialized
INFO - 2023-03-08 06:03:40 --> Language Class Initialized
INFO - 2023-03-08 06:03:40 --> Loader Class Initialized
INFO - 2023-03-08 06:03:40 --> Controller Class Initialized
DEBUG - 2023-03-08 06:03:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:03:40 --> Database Driver Class Initialized
INFO - 2023-03-08 06:03:40 --> Final output sent to browser
DEBUG - 2023-03-08 06:03:40 --> Total execution time: 0.0171
INFO - 2023-03-08 06:04:38 --> Config Class Initialized
INFO - 2023-03-08 06:04:38 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:04:38 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:04:38 --> Utf8 Class Initialized
INFO - 2023-03-08 06:04:38 --> URI Class Initialized
INFO - 2023-03-08 06:04:38 --> Router Class Initialized
INFO - 2023-03-08 06:04:38 --> Output Class Initialized
INFO - 2023-03-08 06:04:38 --> Security Class Initialized
DEBUG - 2023-03-08 06:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:04:38 --> Input Class Initialized
INFO - 2023-03-08 06:04:38 --> Language Class Initialized
INFO - 2023-03-08 06:04:38 --> Loader Class Initialized
INFO - 2023-03-08 06:04:38 --> Controller Class Initialized
DEBUG - 2023-03-08 06:04:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:04:38 --> Database Driver Class Initialized
INFO - 2023-03-08 06:04:38 --> Final output sent to browser
DEBUG - 2023-03-08 06:04:38 --> Total execution time: 0.0089
INFO - 2023-03-08 06:04:38 --> Config Class Initialized
INFO - 2023-03-08 06:04:38 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:04:38 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:04:38 --> Utf8 Class Initialized
INFO - 2023-03-08 06:04:38 --> URI Class Initialized
INFO - 2023-03-08 06:04:38 --> Router Class Initialized
INFO - 2023-03-08 06:04:38 --> Output Class Initialized
INFO - 2023-03-08 06:04:38 --> Security Class Initialized
DEBUG - 2023-03-08 06:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:04:38 --> Input Class Initialized
INFO - 2023-03-08 06:04:38 --> Language Class Initialized
INFO - 2023-03-08 06:04:38 --> Loader Class Initialized
INFO - 2023-03-08 06:04:38 --> Controller Class Initialized
DEBUG - 2023-03-08 06:04:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:04:38 --> Database Driver Class Initialized
INFO - 2023-03-08 06:04:38 --> Final output sent to browser
DEBUG - 2023-03-08 06:04:38 --> Total execution time: 0.0248
INFO - 2023-03-08 06:05:07 --> Config Class Initialized
INFO - 2023-03-08 06:05:07 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:05:07 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:05:07 --> Utf8 Class Initialized
INFO - 2023-03-08 06:05:07 --> URI Class Initialized
INFO - 2023-03-08 06:05:07 --> Router Class Initialized
INFO - 2023-03-08 06:05:07 --> Output Class Initialized
INFO - 2023-03-08 06:05:07 --> Security Class Initialized
DEBUG - 2023-03-08 06:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:05:07 --> Input Class Initialized
INFO - 2023-03-08 06:05:07 --> Language Class Initialized
INFO - 2023-03-08 06:05:07 --> Loader Class Initialized
INFO - 2023-03-08 06:05:07 --> Controller Class Initialized
DEBUG - 2023-03-08 06:05:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:05:07 --> Database Driver Class Initialized
INFO - 2023-03-08 06:05:07 --> Final output sent to browser
DEBUG - 2023-03-08 06:05:07 --> Total execution time: 0.0139
INFO - 2023-03-08 06:05:07 --> Config Class Initialized
INFO - 2023-03-08 06:05:07 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:05:07 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:05:07 --> Utf8 Class Initialized
INFO - 2023-03-08 06:05:07 --> URI Class Initialized
INFO - 2023-03-08 06:05:07 --> Router Class Initialized
INFO - 2023-03-08 06:05:07 --> Output Class Initialized
INFO - 2023-03-08 06:05:07 --> Security Class Initialized
DEBUG - 2023-03-08 06:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:05:07 --> Input Class Initialized
INFO - 2023-03-08 06:05:07 --> Language Class Initialized
INFO - 2023-03-08 06:05:07 --> Loader Class Initialized
INFO - 2023-03-08 06:05:07 --> Controller Class Initialized
DEBUG - 2023-03-08 06:05:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:05:07 --> Database Driver Class Initialized
INFO - 2023-03-08 06:05:07 --> Final output sent to browser
DEBUG - 2023-03-08 06:05:08 --> Total execution time: 0.0732
INFO - 2023-03-08 06:28:15 --> Config Class Initialized
INFO - 2023-03-08 06:28:15 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:28:15 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:28:15 --> Utf8 Class Initialized
INFO - 2023-03-08 06:28:15 --> URI Class Initialized
INFO - 2023-03-08 06:28:15 --> Router Class Initialized
INFO - 2023-03-08 06:28:15 --> Output Class Initialized
INFO - 2023-03-08 06:28:15 --> Security Class Initialized
DEBUG - 2023-03-08 06:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:28:15 --> Input Class Initialized
INFO - 2023-03-08 06:28:15 --> Language Class Initialized
INFO - 2023-03-08 06:28:15 --> Loader Class Initialized
INFO - 2023-03-08 06:28:15 --> Controller Class Initialized
DEBUG - 2023-03-08 06:28:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:28:15 --> Database Driver Class Initialized
INFO - 2023-03-08 06:28:15 --> Final output sent to browser
DEBUG - 2023-03-08 06:28:15 --> Total execution time: 0.0580
INFO - 2023-03-08 06:28:15 --> Config Class Initialized
INFO - 2023-03-08 06:28:15 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:28:15 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:28:15 --> Utf8 Class Initialized
INFO - 2023-03-08 06:28:15 --> URI Class Initialized
INFO - 2023-03-08 06:28:15 --> Router Class Initialized
INFO - 2023-03-08 06:28:15 --> Output Class Initialized
INFO - 2023-03-08 06:28:15 --> Security Class Initialized
DEBUG - 2023-03-08 06:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:28:15 --> Input Class Initialized
INFO - 2023-03-08 06:28:15 --> Language Class Initialized
INFO - 2023-03-08 06:28:15 --> Loader Class Initialized
INFO - 2023-03-08 06:28:15 --> Controller Class Initialized
DEBUG - 2023-03-08 06:28:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:28:15 --> Database Driver Class Initialized
INFO - 2023-03-08 06:28:15 --> Final output sent to browser
DEBUG - 2023-03-08 06:28:15 --> Total execution time: 0.0829
INFO - 2023-03-08 06:30:55 --> Config Class Initialized
INFO - 2023-03-08 06:30:55 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:30:55 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:30:55 --> Utf8 Class Initialized
INFO - 2023-03-08 06:30:55 --> URI Class Initialized
INFO - 2023-03-08 06:30:55 --> Router Class Initialized
INFO - 2023-03-08 06:30:55 --> Output Class Initialized
INFO - 2023-03-08 06:30:55 --> Security Class Initialized
DEBUG - 2023-03-08 06:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:30:55 --> Input Class Initialized
INFO - 2023-03-08 06:30:55 --> Language Class Initialized
INFO - 2023-03-08 06:30:55 --> Loader Class Initialized
INFO - 2023-03-08 06:30:55 --> Controller Class Initialized
DEBUG - 2023-03-08 06:30:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:30:55 --> Database Driver Class Initialized
INFO - 2023-03-08 06:30:55 --> Final output sent to browser
DEBUG - 2023-03-08 06:30:55 --> Total execution time: 0.0573
INFO - 2023-03-08 06:30:55 --> Config Class Initialized
INFO - 2023-03-08 06:30:55 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:30:55 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:30:55 --> Utf8 Class Initialized
INFO - 2023-03-08 06:30:55 --> URI Class Initialized
INFO - 2023-03-08 06:30:55 --> Router Class Initialized
INFO - 2023-03-08 06:30:55 --> Output Class Initialized
INFO - 2023-03-08 06:30:55 --> Security Class Initialized
DEBUG - 2023-03-08 06:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:30:55 --> Input Class Initialized
INFO - 2023-03-08 06:30:55 --> Language Class Initialized
INFO - 2023-03-08 06:30:55 --> Loader Class Initialized
INFO - 2023-03-08 06:30:55 --> Controller Class Initialized
DEBUG - 2023-03-08 06:30:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:30:55 --> Database Driver Class Initialized
INFO - 2023-03-08 06:30:55 --> Final output sent to browser
DEBUG - 2023-03-08 06:30:55 --> Total execution time: 0.0911
INFO - 2023-03-08 06:33:16 --> Config Class Initialized
INFO - 2023-03-08 06:33:16 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:33:16 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:33:16 --> Utf8 Class Initialized
INFO - 2023-03-08 06:33:16 --> URI Class Initialized
INFO - 2023-03-08 06:33:16 --> Router Class Initialized
INFO - 2023-03-08 06:33:16 --> Output Class Initialized
INFO - 2023-03-08 06:33:16 --> Security Class Initialized
DEBUG - 2023-03-08 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:33:16 --> Input Class Initialized
INFO - 2023-03-08 06:33:16 --> Language Class Initialized
INFO - 2023-03-08 06:33:16 --> Loader Class Initialized
INFO - 2023-03-08 06:33:16 --> Controller Class Initialized
DEBUG - 2023-03-08 06:33:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:33:16 --> Database Driver Class Initialized
INFO - 2023-03-08 06:33:16 --> Final output sent to browser
DEBUG - 2023-03-08 06:33:16 --> Total execution time: 0.0169
INFO - 2023-03-08 06:33:16 --> Config Class Initialized
INFO - 2023-03-08 06:33:16 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:33:16 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:33:16 --> Utf8 Class Initialized
INFO - 2023-03-08 06:33:16 --> URI Class Initialized
INFO - 2023-03-08 06:33:16 --> Router Class Initialized
INFO - 2023-03-08 06:33:16 --> Output Class Initialized
INFO - 2023-03-08 06:33:16 --> Security Class Initialized
DEBUG - 2023-03-08 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:33:16 --> Input Class Initialized
INFO - 2023-03-08 06:33:16 --> Language Class Initialized
INFO - 2023-03-08 06:33:16 --> Loader Class Initialized
INFO - 2023-03-08 06:33:16 --> Controller Class Initialized
DEBUG - 2023-03-08 06:33:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:33:16 --> Database Driver Class Initialized
INFO - 2023-03-08 06:33:17 --> Final output sent to browser
DEBUG - 2023-03-08 06:33:17 --> Total execution time: 1.0010
INFO - 2023-03-08 06:40:00 --> Config Class Initialized
INFO - 2023-03-08 06:40:00 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:00 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:00 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:00 --> URI Class Initialized
INFO - 2023-03-08 06:40:00 --> Router Class Initialized
INFO - 2023-03-08 06:40:00 --> Output Class Initialized
INFO - 2023-03-08 06:40:00 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:00 --> Input Class Initialized
INFO - 2023-03-08 06:40:00 --> Language Class Initialized
INFO - 2023-03-08 06:40:00 --> Loader Class Initialized
INFO - 2023-03-08 06:40:00 --> Controller Class Initialized
INFO - 2023-03-08 06:40:00 --> Helper loaded: form_helper
INFO - 2023-03-08 06:40:00 --> Helper loaded: url_helper
DEBUG - 2023-03-08 06:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:00 --> Model "Change_model" initialized
INFO - 2023-03-08 06:40:00 --> Model "Grafana_model" initialized
INFO - 2023-03-08 06:40:00 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:00 --> Total execution time: 0.1193
INFO - 2023-03-08 06:40:00 --> Config Class Initialized
INFO - 2023-03-08 06:40:00 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:00 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:00 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:00 --> URI Class Initialized
INFO - 2023-03-08 06:40:00 --> Router Class Initialized
INFO - 2023-03-08 06:40:00 --> Output Class Initialized
INFO - 2023-03-08 06:40:00 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:00 --> Input Class Initialized
INFO - 2023-03-08 06:40:00 --> Language Class Initialized
INFO - 2023-03-08 06:40:00 --> Loader Class Initialized
INFO - 2023-03-08 06:40:00 --> Controller Class Initialized
INFO - 2023-03-08 06:40:00 --> Helper loaded: form_helper
INFO - 2023-03-08 06:40:00 --> Helper loaded: url_helper
DEBUG - 2023-03-08 06:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:00 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:00 --> Total execution time: 0.0135
INFO - 2023-03-08 06:40:00 --> Config Class Initialized
INFO - 2023-03-08 06:40:00 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:00 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:00 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:00 --> URI Class Initialized
INFO - 2023-03-08 06:40:00 --> Router Class Initialized
INFO - 2023-03-08 06:40:00 --> Output Class Initialized
INFO - 2023-03-08 06:40:00 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:00 --> Input Class Initialized
INFO - 2023-03-08 06:40:00 --> Language Class Initialized
INFO - 2023-03-08 06:40:00 --> Loader Class Initialized
INFO - 2023-03-08 06:40:00 --> Controller Class Initialized
INFO - 2023-03-08 06:40:00 --> Helper loaded: form_helper
INFO - 2023-03-08 06:40:00 --> Helper loaded: url_helper
DEBUG - 2023-03-08 06:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:00 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:01 --> Model "Login_model" initialized
INFO - 2023-03-08 06:40:01 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:01 --> Total execution time: 1.1046
INFO - 2023-03-08 06:40:01 --> Config Class Initialized
INFO - 2023-03-08 06:40:01 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:01 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:01 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:01 --> URI Class Initialized
INFO - 2023-03-08 06:40:01 --> Router Class Initialized
INFO - 2023-03-08 06:40:01 --> Output Class Initialized
INFO - 2023-03-08 06:40:01 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:01 --> Input Class Initialized
INFO - 2023-03-08 06:40:01 --> Language Class Initialized
INFO - 2023-03-08 06:40:01 --> Loader Class Initialized
INFO - 2023-03-08 06:40:01 --> Controller Class Initialized
DEBUG - 2023-03-08 06:40:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:01 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:01 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:40:01 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:01 --> Total execution time: 0.0595
INFO - 2023-03-08 06:40:01 --> Config Class Initialized
INFO - 2023-03-08 06:40:01 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:01 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:01 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:01 --> URI Class Initialized
INFO - 2023-03-08 06:40:01 --> Router Class Initialized
INFO - 2023-03-08 06:40:01 --> Output Class Initialized
INFO - 2023-03-08 06:40:01 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:01 --> Input Class Initialized
INFO - 2023-03-08 06:40:01 --> Language Class Initialized
INFO - 2023-03-08 06:40:01 --> Loader Class Initialized
INFO - 2023-03-08 06:40:01 --> Controller Class Initialized
DEBUG - 2023-03-08 06:40:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:01 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:01 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:40:01 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:01 --> Total execution time: 0.0154
INFO - 2023-03-08 06:40:02 --> Config Class Initialized
INFO - 2023-03-08 06:40:02 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:02 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:02 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:02 --> URI Class Initialized
INFO - 2023-03-08 06:40:02 --> Router Class Initialized
INFO - 2023-03-08 06:40:02 --> Output Class Initialized
INFO - 2023-03-08 06:40:02 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:02 --> Input Class Initialized
INFO - 2023-03-08 06:40:02 --> Language Class Initialized
INFO - 2023-03-08 06:40:02 --> Loader Class Initialized
INFO - 2023-03-08 06:40:02 --> Controller Class Initialized
DEBUG - 2023-03-08 06:40:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:02 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:02 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:40:02 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:02 --> Model "Login_model" initialized
INFO - 2023-03-08 06:40:02 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:02 --> Total execution time: 0.0708
INFO - 2023-03-08 06:40:02 --> Config Class Initialized
INFO - 2023-03-08 06:40:02 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:02 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:02 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:02 --> URI Class Initialized
INFO - 2023-03-08 06:40:02 --> Router Class Initialized
INFO - 2023-03-08 06:40:02 --> Output Class Initialized
INFO - 2023-03-08 06:40:02 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:02 --> Input Class Initialized
INFO - 2023-03-08 06:40:02 --> Language Class Initialized
INFO - 2023-03-08 06:40:02 --> Loader Class Initialized
INFO - 2023-03-08 06:40:02 --> Controller Class Initialized
DEBUG - 2023-03-08 06:40:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:02 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:02 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:40:02 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:02 --> Model "Login_model" initialized
INFO - 2023-03-08 06:40:02 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:02 --> Total execution time: 0.0789
INFO - 2023-03-08 06:40:18 --> Config Class Initialized
INFO - 2023-03-08 06:40:18 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:18 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:18 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:18 --> URI Class Initialized
INFO - 2023-03-08 06:40:18 --> Router Class Initialized
INFO - 2023-03-08 06:40:18 --> Output Class Initialized
INFO - 2023-03-08 06:40:18 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:18 --> Input Class Initialized
INFO - 2023-03-08 06:40:18 --> Language Class Initialized
INFO - 2023-03-08 06:40:18 --> Loader Class Initialized
INFO - 2023-03-08 06:40:18 --> Controller Class Initialized
INFO - 2023-03-08 06:40:18 --> Helper loaded: form_helper
INFO - 2023-03-08 06:40:18 --> Helper loaded: url_helper
DEBUG - 2023-03-08 06:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:18 --> Model "Change_model" initialized
INFO - 2023-03-08 06:40:18 --> Model "Grafana_model" initialized
INFO - 2023-03-08 06:40:18 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:18 --> Total execution time: 0.0255
INFO - 2023-03-08 06:40:18 --> Config Class Initialized
INFO - 2023-03-08 06:40:18 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:18 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:18 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:18 --> URI Class Initialized
INFO - 2023-03-08 06:40:18 --> Router Class Initialized
INFO - 2023-03-08 06:40:18 --> Output Class Initialized
INFO - 2023-03-08 06:40:18 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:18 --> Input Class Initialized
INFO - 2023-03-08 06:40:18 --> Language Class Initialized
INFO - 2023-03-08 06:40:18 --> Loader Class Initialized
INFO - 2023-03-08 06:40:18 --> Controller Class Initialized
INFO - 2023-03-08 06:40:18 --> Helper loaded: form_helper
INFO - 2023-03-08 06:40:18 --> Helper loaded: url_helper
DEBUG - 2023-03-08 06:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:18 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:18 --> Total execution time: 0.0459
INFO - 2023-03-08 06:40:18 --> Config Class Initialized
INFO - 2023-03-08 06:40:18 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:18 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:18 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:18 --> URI Class Initialized
INFO - 2023-03-08 06:40:18 --> Router Class Initialized
INFO - 2023-03-08 06:40:18 --> Output Class Initialized
INFO - 2023-03-08 06:40:18 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:18 --> Input Class Initialized
INFO - 2023-03-08 06:40:18 --> Language Class Initialized
INFO - 2023-03-08 06:40:18 --> Loader Class Initialized
INFO - 2023-03-08 06:40:18 --> Controller Class Initialized
INFO - 2023-03-08 06:40:18 --> Helper loaded: form_helper
INFO - 2023-03-08 06:40:18 --> Helper loaded: url_helper
DEBUG - 2023-03-08 06:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:18 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:18 --> Model "Login_model" initialized
INFO - 2023-03-08 06:40:18 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:18 --> Total execution time: 0.0167
INFO - 2023-03-08 06:40:18 --> Config Class Initialized
INFO - 2023-03-08 06:40:18 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:18 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:18 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:18 --> URI Class Initialized
INFO - 2023-03-08 06:40:18 --> Router Class Initialized
INFO - 2023-03-08 06:40:18 --> Output Class Initialized
INFO - 2023-03-08 06:40:18 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:18 --> Input Class Initialized
INFO - 2023-03-08 06:40:18 --> Language Class Initialized
INFO - 2023-03-08 06:40:18 --> Loader Class Initialized
INFO - 2023-03-08 06:40:18 --> Controller Class Initialized
DEBUG - 2023-03-08 06:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:18 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:18 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:40:18 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:18 --> Total execution time: 0.0136
INFO - 2023-03-08 06:40:18 --> Config Class Initialized
INFO - 2023-03-08 06:40:18 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:18 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:18 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:18 --> URI Class Initialized
INFO - 2023-03-08 06:40:18 --> Router Class Initialized
INFO - 2023-03-08 06:40:18 --> Output Class Initialized
INFO - 2023-03-08 06:40:18 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:18 --> Input Class Initialized
INFO - 2023-03-08 06:40:18 --> Language Class Initialized
INFO - 2023-03-08 06:40:18 --> Loader Class Initialized
INFO - 2023-03-08 06:40:18 --> Controller Class Initialized
DEBUG - 2023-03-08 06:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:18 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:18 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:40:18 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:18 --> Total execution time: 0.0120
INFO - 2023-03-08 06:40:19 --> Config Class Initialized
INFO - 2023-03-08 06:40:19 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:19 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:19 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:19 --> URI Class Initialized
INFO - 2023-03-08 06:40:19 --> Router Class Initialized
INFO - 2023-03-08 06:40:19 --> Output Class Initialized
INFO - 2023-03-08 06:40:19 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:19 --> Input Class Initialized
INFO - 2023-03-08 06:40:19 --> Language Class Initialized
INFO - 2023-03-08 06:40:19 --> Loader Class Initialized
INFO - 2023-03-08 06:40:19 --> Controller Class Initialized
DEBUG - 2023-03-08 06:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:19 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:19 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:40:19 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:19 --> Model "Login_model" initialized
INFO - 2023-03-08 06:40:19 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:19 --> Total execution time: 0.0758
INFO - 2023-03-08 06:40:19 --> Config Class Initialized
INFO - 2023-03-08 06:40:19 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:19 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:19 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:19 --> URI Class Initialized
INFO - 2023-03-08 06:40:19 --> Router Class Initialized
INFO - 2023-03-08 06:40:19 --> Output Class Initialized
INFO - 2023-03-08 06:40:19 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:19 --> Input Class Initialized
INFO - 2023-03-08 06:40:19 --> Language Class Initialized
INFO - 2023-03-08 06:40:19 --> Loader Class Initialized
INFO - 2023-03-08 06:40:19 --> Controller Class Initialized
DEBUG - 2023-03-08 06:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:19 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:19 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:40:19 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:19 --> Model "Login_model" initialized
INFO - 2023-03-08 06:40:19 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:19 --> Total execution time: 0.0735
INFO - 2023-03-08 06:40:24 --> Config Class Initialized
INFO - 2023-03-08 06:40:24 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:24 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:24 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:24 --> URI Class Initialized
INFO - 2023-03-08 06:40:24 --> Router Class Initialized
INFO - 2023-03-08 06:40:24 --> Output Class Initialized
INFO - 2023-03-08 06:40:24 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:24 --> Input Class Initialized
INFO - 2023-03-08 06:40:24 --> Language Class Initialized
INFO - 2023-03-08 06:40:24 --> Loader Class Initialized
INFO - 2023-03-08 06:40:24 --> Controller Class Initialized
DEBUG - 2023-03-08 06:40:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:24 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:24 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:24 --> Model "Login_model" initialized
INFO - 2023-03-08 06:40:24 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:24 --> Total execution time: 0.0375
INFO - 2023-03-08 06:40:24 --> Config Class Initialized
INFO - 2023-03-08 06:40:24 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:24 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:24 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:24 --> URI Class Initialized
INFO - 2023-03-08 06:40:24 --> Router Class Initialized
INFO - 2023-03-08 06:40:24 --> Output Class Initialized
INFO - 2023-03-08 06:40:24 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:24 --> Input Class Initialized
INFO - 2023-03-08 06:40:24 --> Language Class Initialized
INFO - 2023-03-08 06:40:24 --> Loader Class Initialized
INFO - 2023-03-08 06:40:24 --> Controller Class Initialized
DEBUG - 2023-03-08 06:40:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:24 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:24 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:24 --> Model "Login_model" initialized
INFO - 2023-03-08 06:40:24 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:24 --> Total execution time: 0.0336
INFO - 2023-03-08 06:40:31 --> Config Class Initialized
INFO - 2023-03-08 06:40:31 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:31 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:31 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:31 --> URI Class Initialized
INFO - 2023-03-08 06:40:31 --> Router Class Initialized
INFO - 2023-03-08 06:40:31 --> Output Class Initialized
INFO - 2023-03-08 06:40:31 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:31 --> Input Class Initialized
INFO - 2023-03-08 06:40:31 --> Language Class Initialized
INFO - 2023-03-08 06:40:31 --> Loader Class Initialized
INFO - 2023-03-08 06:40:31 --> Controller Class Initialized
DEBUG - 2023-03-08 06:40:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:31 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:31 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:31 --> Total execution time: 0.0137
INFO - 2023-03-08 06:40:31 --> Config Class Initialized
INFO - 2023-03-08 06:40:31 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:40:31 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:40:31 --> Utf8 Class Initialized
INFO - 2023-03-08 06:40:31 --> URI Class Initialized
INFO - 2023-03-08 06:40:31 --> Router Class Initialized
INFO - 2023-03-08 06:40:31 --> Output Class Initialized
INFO - 2023-03-08 06:40:31 --> Security Class Initialized
DEBUG - 2023-03-08 06:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:40:31 --> Input Class Initialized
INFO - 2023-03-08 06:40:31 --> Language Class Initialized
INFO - 2023-03-08 06:40:31 --> Loader Class Initialized
INFO - 2023-03-08 06:40:31 --> Controller Class Initialized
DEBUG - 2023-03-08 06:40:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:40:31 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:31 --> Database Driver Class Initialized
INFO - 2023-03-08 06:40:31 --> Model "Login_model" initialized
INFO - 2023-03-08 06:40:31 --> Final output sent to browser
DEBUG - 2023-03-08 06:40:31 --> Total execution time: 0.0203
INFO - 2023-03-08 06:41:03 --> Config Class Initialized
INFO - 2023-03-08 06:41:03 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:41:03 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:41:03 --> Utf8 Class Initialized
INFO - 2023-03-08 06:41:03 --> URI Class Initialized
INFO - 2023-03-08 06:41:03 --> Router Class Initialized
INFO - 2023-03-08 06:41:03 --> Output Class Initialized
INFO - 2023-03-08 06:41:03 --> Security Class Initialized
DEBUG - 2023-03-08 06:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:41:03 --> Input Class Initialized
INFO - 2023-03-08 06:41:03 --> Language Class Initialized
INFO - 2023-03-08 06:41:03 --> Loader Class Initialized
INFO - 2023-03-08 06:41:03 --> Controller Class Initialized
DEBUG - 2023-03-08 06:41:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:41:03 --> Database Driver Class Initialized
INFO - 2023-03-08 06:41:03 --> Final output sent to browser
DEBUG - 2023-03-08 06:41:03 --> Total execution time: 0.0516
INFO - 2023-03-08 06:41:03 --> Config Class Initialized
INFO - 2023-03-08 06:41:03 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:41:03 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:41:03 --> Utf8 Class Initialized
INFO - 2023-03-08 06:41:03 --> URI Class Initialized
INFO - 2023-03-08 06:41:03 --> Router Class Initialized
INFO - 2023-03-08 06:41:03 --> Output Class Initialized
INFO - 2023-03-08 06:41:03 --> Security Class Initialized
DEBUG - 2023-03-08 06:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:41:03 --> Input Class Initialized
INFO - 2023-03-08 06:41:03 --> Language Class Initialized
INFO - 2023-03-08 06:41:03 --> Loader Class Initialized
INFO - 2023-03-08 06:41:03 --> Controller Class Initialized
DEBUG - 2023-03-08 06:41:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:41:03 --> Database Driver Class Initialized
INFO - 2023-03-08 06:41:03 --> Database Driver Class Initialized
INFO - 2023-03-08 06:41:03 --> Model "Login_model" initialized
INFO - 2023-03-08 06:41:03 --> Final output sent to browser
DEBUG - 2023-03-08 06:41:03 --> Total execution time: 0.0172
INFO - 2023-03-08 06:41:03 --> Config Class Initialized
INFO - 2023-03-08 06:41:03 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:41:03 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:41:03 --> Utf8 Class Initialized
INFO - 2023-03-08 06:41:03 --> URI Class Initialized
INFO - 2023-03-08 06:41:03 --> Router Class Initialized
INFO - 2023-03-08 06:41:03 --> Output Class Initialized
INFO - 2023-03-08 06:41:03 --> Security Class Initialized
DEBUG - 2023-03-08 06:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:41:03 --> Input Class Initialized
INFO - 2023-03-08 06:41:03 --> Language Class Initialized
INFO - 2023-03-08 06:41:03 --> Loader Class Initialized
INFO - 2023-03-08 06:41:03 --> Controller Class Initialized
DEBUG - 2023-03-08 06:41:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:41:03 --> Database Driver Class Initialized
INFO - 2023-03-08 06:41:03 --> Final output sent to browser
DEBUG - 2023-03-08 06:41:03 --> Total execution time: 0.0126
INFO - 2023-03-08 06:41:03 --> Config Class Initialized
INFO - 2023-03-08 06:41:03 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:41:03 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:41:03 --> Utf8 Class Initialized
INFO - 2023-03-08 06:41:03 --> URI Class Initialized
INFO - 2023-03-08 06:41:03 --> Router Class Initialized
INFO - 2023-03-08 06:41:03 --> Output Class Initialized
INFO - 2023-03-08 06:41:03 --> Security Class Initialized
DEBUG - 2023-03-08 06:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:41:03 --> Input Class Initialized
INFO - 2023-03-08 06:41:03 --> Language Class Initialized
INFO - 2023-03-08 06:41:03 --> Loader Class Initialized
INFO - 2023-03-08 06:41:03 --> Controller Class Initialized
DEBUG - 2023-03-08 06:41:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:41:03 --> Database Driver Class Initialized
INFO - 2023-03-08 06:42:18 --> Final output sent to browser
DEBUG - 2023-03-08 06:42:18 --> Total execution time: 75.0047
INFO - 2023-03-08 06:42:49 --> Config Class Initialized
INFO - 2023-03-08 06:42:49 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:42:49 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:42:49 --> Utf8 Class Initialized
INFO - 2023-03-08 06:42:49 --> URI Class Initialized
INFO - 2023-03-08 06:42:49 --> Router Class Initialized
INFO - 2023-03-08 06:42:49 --> Output Class Initialized
INFO - 2023-03-08 06:42:49 --> Security Class Initialized
DEBUG - 2023-03-08 06:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:42:49 --> Input Class Initialized
INFO - 2023-03-08 06:42:49 --> Language Class Initialized
INFO - 2023-03-08 06:42:49 --> Loader Class Initialized
INFO - 2023-03-08 06:42:49 --> Controller Class Initialized
DEBUG - 2023-03-08 06:42:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:42:49 --> Database Driver Class Initialized
INFO - 2023-03-08 06:42:49 --> Final output sent to browser
DEBUG - 2023-03-08 06:42:49 --> Total execution time: 0.0145
INFO - 2023-03-08 06:42:49 --> Config Class Initialized
INFO - 2023-03-08 06:42:49 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:42:49 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:42:49 --> Utf8 Class Initialized
INFO - 2023-03-08 06:42:49 --> URI Class Initialized
INFO - 2023-03-08 06:42:49 --> Router Class Initialized
INFO - 2023-03-08 06:42:49 --> Output Class Initialized
INFO - 2023-03-08 06:42:49 --> Security Class Initialized
DEBUG - 2023-03-08 06:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:42:49 --> Input Class Initialized
INFO - 2023-03-08 06:42:49 --> Language Class Initialized
INFO - 2023-03-08 06:42:49 --> Loader Class Initialized
INFO - 2023-03-08 06:42:49 --> Controller Class Initialized
DEBUG - 2023-03-08 06:42:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:42:49 --> Database Driver Class Initialized
INFO - 2023-03-08 06:42:49 --> Database Driver Class Initialized
INFO - 2023-03-08 06:42:49 --> Model "Login_model" initialized
INFO - 2023-03-08 06:42:49 --> Final output sent to browser
DEBUG - 2023-03-08 06:42:49 --> Total execution time: 0.0279
INFO - 2023-03-08 06:43:09 --> Config Class Initialized
INFO - 2023-03-08 06:43:09 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:43:09 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:43:09 --> Utf8 Class Initialized
INFO - 2023-03-08 06:43:09 --> URI Class Initialized
INFO - 2023-03-08 06:43:09 --> Router Class Initialized
INFO - 2023-03-08 06:43:09 --> Output Class Initialized
INFO - 2023-03-08 06:43:09 --> Security Class Initialized
DEBUG - 2023-03-08 06:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:43:09 --> Input Class Initialized
INFO - 2023-03-08 06:43:09 --> Language Class Initialized
INFO - 2023-03-08 06:43:09 --> Loader Class Initialized
INFO - 2023-03-08 06:43:09 --> Controller Class Initialized
DEBUG - 2023-03-08 06:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:43:09 --> Database Driver Class Initialized
INFO - 2023-03-08 06:43:09 --> Final output sent to browser
DEBUG - 2023-03-08 06:43:09 --> Total execution time: 0.0139
INFO - 2023-03-08 06:43:09 --> Config Class Initialized
INFO - 2023-03-08 06:43:09 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:43:09 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:43:09 --> Utf8 Class Initialized
INFO - 2023-03-08 06:43:09 --> URI Class Initialized
INFO - 2023-03-08 06:43:09 --> Router Class Initialized
INFO - 2023-03-08 06:43:09 --> Output Class Initialized
INFO - 2023-03-08 06:43:09 --> Security Class Initialized
DEBUG - 2023-03-08 06:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:43:09 --> Input Class Initialized
INFO - 2023-03-08 06:43:09 --> Language Class Initialized
INFO - 2023-03-08 06:43:09 --> Loader Class Initialized
INFO - 2023-03-08 06:43:09 --> Controller Class Initialized
DEBUG - 2023-03-08 06:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:43:09 --> Database Driver Class Initialized
INFO - 2023-03-08 06:43:09 --> Database Driver Class Initialized
INFO - 2023-03-08 06:43:09 --> Model "Login_model" initialized
INFO - 2023-03-08 06:43:09 --> Final output sent to browser
DEBUG - 2023-03-08 06:43:09 --> Total execution time: 0.0264
INFO - 2023-03-08 06:43:09 --> Config Class Initialized
INFO - 2023-03-08 06:43:09 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:43:09 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:43:09 --> Utf8 Class Initialized
INFO - 2023-03-08 06:43:09 --> URI Class Initialized
INFO - 2023-03-08 06:43:09 --> Router Class Initialized
INFO - 2023-03-08 06:43:09 --> Output Class Initialized
INFO - 2023-03-08 06:43:09 --> Security Class Initialized
DEBUG - 2023-03-08 06:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:43:09 --> Input Class Initialized
INFO - 2023-03-08 06:43:09 --> Language Class Initialized
INFO - 2023-03-08 06:43:09 --> Loader Class Initialized
INFO - 2023-03-08 06:43:09 --> Controller Class Initialized
DEBUG - 2023-03-08 06:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:43:09 --> Database Driver Class Initialized
INFO - 2023-03-08 06:43:09 --> Final output sent to browser
DEBUG - 2023-03-08 06:43:09 --> Total execution time: 0.0126
INFO - 2023-03-08 06:43:09 --> Config Class Initialized
INFO - 2023-03-08 06:43:09 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:43:09 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:43:09 --> Utf8 Class Initialized
INFO - 2023-03-08 06:43:09 --> URI Class Initialized
INFO - 2023-03-08 06:43:09 --> Router Class Initialized
INFO - 2023-03-08 06:43:09 --> Output Class Initialized
INFO - 2023-03-08 06:43:09 --> Security Class Initialized
DEBUG - 2023-03-08 06:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:43:09 --> Input Class Initialized
INFO - 2023-03-08 06:43:09 --> Language Class Initialized
INFO - 2023-03-08 06:43:09 --> Loader Class Initialized
INFO - 2023-03-08 06:43:09 --> Controller Class Initialized
DEBUG - 2023-03-08 06:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:43:09 --> Database Driver Class Initialized
INFO - 2023-03-08 06:43:10 --> Final output sent to browser
DEBUG - 2023-03-08 06:43:10 --> Total execution time: 0.9435
INFO - 2023-03-08 06:43:10 --> Config Class Initialized
INFO - 2023-03-08 06:43:10 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:43:10 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:43:10 --> Utf8 Class Initialized
INFO - 2023-03-08 06:43:10 --> URI Class Initialized
INFO - 2023-03-08 06:43:10 --> Router Class Initialized
INFO - 2023-03-08 06:43:10 --> Output Class Initialized
INFO - 2023-03-08 06:43:10 --> Security Class Initialized
DEBUG - 2023-03-08 06:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:43:10 --> Input Class Initialized
INFO - 2023-03-08 06:43:10 --> Language Class Initialized
INFO - 2023-03-08 06:43:10 --> Loader Class Initialized
INFO - 2023-03-08 06:43:10 --> Controller Class Initialized
DEBUG - 2023-03-08 06:43:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:43:10 --> Database Driver Class Initialized
INFO - 2023-03-08 06:43:10 --> Database Driver Class Initialized
INFO - 2023-03-08 06:43:10 --> Model "Login_model" initialized
INFO - 2023-03-08 06:43:10 --> Final output sent to browser
DEBUG - 2023-03-08 06:43:10 --> Total execution time: 0.0685
INFO - 2023-03-08 06:43:10 --> Config Class Initialized
INFO - 2023-03-08 06:43:10 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:43:10 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:43:10 --> Utf8 Class Initialized
INFO - 2023-03-08 06:43:10 --> URI Class Initialized
INFO - 2023-03-08 06:43:10 --> Router Class Initialized
INFO - 2023-03-08 06:43:10 --> Output Class Initialized
INFO - 2023-03-08 06:43:10 --> Security Class Initialized
DEBUG - 2023-03-08 06:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:43:10 --> Input Class Initialized
INFO - 2023-03-08 06:43:10 --> Language Class Initialized
INFO - 2023-03-08 06:43:10 --> Loader Class Initialized
INFO - 2023-03-08 06:43:10 --> Controller Class Initialized
DEBUG - 2023-03-08 06:43:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:43:10 --> Database Driver Class Initialized
INFO - 2023-03-08 06:43:10 --> Database Driver Class Initialized
INFO - 2023-03-08 06:43:10 --> Model "Login_model" initialized
INFO - 2023-03-08 06:43:10 --> Final output sent to browser
DEBUG - 2023-03-08 06:43:10 --> Total execution time: 0.0281
INFO - 2023-03-08 06:46:17 --> Config Class Initialized
INFO - 2023-03-08 06:46:17 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:46:17 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:46:17 --> Utf8 Class Initialized
INFO - 2023-03-08 06:46:17 --> URI Class Initialized
INFO - 2023-03-08 06:46:17 --> Router Class Initialized
INFO - 2023-03-08 06:46:17 --> Output Class Initialized
INFO - 2023-03-08 06:46:17 --> Security Class Initialized
DEBUG - 2023-03-08 06:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:46:17 --> Input Class Initialized
INFO - 2023-03-08 06:46:17 --> Language Class Initialized
INFO - 2023-03-08 06:46:17 --> Loader Class Initialized
INFO - 2023-03-08 06:46:17 --> Controller Class Initialized
DEBUG - 2023-03-08 06:46:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:46:17 --> Database Driver Class Initialized
INFO - 2023-03-08 06:46:17 --> Final output sent to browser
DEBUG - 2023-03-08 06:46:17 --> Total execution time: 0.0152
INFO - 2023-03-08 06:46:17 --> Config Class Initialized
INFO - 2023-03-08 06:46:17 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:46:17 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:46:17 --> Utf8 Class Initialized
INFO - 2023-03-08 06:46:17 --> URI Class Initialized
INFO - 2023-03-08 06:46:17 --> Router Class Initialized
INFO - 2023-03-08 06:46:17 --> Output Class Initialized
INFO - 2023-03-08 06:46:17 --> Security Class Initialized
DEBUG - 2023-03-08 06:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:46:17 --> Input Class Initialized
INFO - 2023-03-08 06:46:17 --> Language Class Initialized
INFO - 2023-03-08 06:46:17 --> Loader Class Initialized
INFO - 2023-03-08 06:46:17 --> Controller Class Initialized
DEBUG - 2023-03-08 06:46:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:46:17 --> Database Driver Class Initialized
INFO - 2023-03-08 06:46:17 --> Database Driver Class Initialized
INFO - 2023-03-08 06:46:17 --> Model "Login_model" initialized
INFO - 2023-03-08 06:46:17 --> Final output sent to browser
DEBUG - 2023-03-08 06:46:17 --> Total execution time: 0.0428
INFO - 2023-03-08 06:46:17 --> Config Class Initialized
INFO - 2023-03-08 06:46:17 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:46:17 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:46:17 --> Utf8 Class Initialized
INFO - 2023-03-08 06:46:17 --> URI Class Initialized
INFO - 2023-03-08 06:46:17 --> Router Class Initialized
INFO - 2023-03-08 06:46:17 --> Output Class Initialized
INFO - 2023-03-08 06:46:17 --> Security Class Initialized
DEBUG - 2023-03-08 06:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:46:17 --> Input Class Initialized
INFO - 2023-03-08 06:46:17 --> Language Class Initialized
INFO - 2023-03-08 06:46:17 --> Loader Class Initialized
INFO - 2023-03-08 06:46:17 --> Controller Class Initialized
DEBUG - 2023-03-08 06:46:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:46:17 --> Database Driver Class Initialized
INFO - 2023-03-08 06:46:17 --> Database Driver Class Initialized
INFO - 2023-03-08 06:46:17 --> Model "Login_model" initialized
INFO - 2023-03-08 06:46:17 --> Final output sent to browser
DEBUG - 2023-03-08 06:46:17 --> Total execution time: 0.0725
INFO - 2023-03-08 06:46:17 --> Config Class Initialized
INFO - 2023-03-08 06:46:17 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:46:17 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:46:17 --> Utf8 Class Initialized
INFO - 2023-03-08 06:46:17 --> URI Class Initialized
INFO - 2023-03-08 06:46:17 --> Router Class Initialized
INFO - 2023-03-08 06:46:17 --> Output Class Initialized
INFO - 2023-03-08 06:46:17 --> Security Class Initialized
DEBUG - 2023-03-08 06:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:46:17 --> Input Class Initialized
INFO - 2023-03-08 06:46:17 --> Language Class Initialized
INFO - 2023-03-08 06:46:17 --> Loader Class Initialized
INFO - 2023-03-08 06:46:17 --> Controller Class Initialized
DEBUG - 2023-03-08 06:46:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:46:17 --> Database Driver Class Initialized
INFO - 2023-03-08 06:46:17 --> Database Driver Class Initialized
INFO - 2023-03-08 06:46:17 --> Model "Login_model" initialized
INFO - 2023-03-08 06:46:17 --> Final output sent to browser
DEBUG - 2023-03-08 06:46:17 --> Total execution time: 0.0650
INFO - 2023-03-08 06:49:42 --> Config Class Initialized
INFO - 2023-03-08 06:49:42 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:49:42 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:49:42 --> Utf8 Class Initialized
INFO - 2023-03-08 06:49:42 --> URI Class Initialized
INFO - 2023-03-08 06:49:42 --> Router Class Initialized
INFO - 2023-03-08 06:49:42 --> Output Class Initialized
INFO - 2023-03-08 06:49:42 --> Security Class Initialized
DEBUG - 2023-03-08 06:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:49:42 --> Input Class Initialized
INFO - 2023-03-08 06:49:42 --> Language Class Initialized
INFO - 2023-03-08 06:49:42 --> Loader Class Initialized
INFO - 2023-03-08 06:49:42 --> Controller Class Initialized
DEBUG - 2023-03-08 06:49:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:49:42 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:42 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:42 --> Model "Login_model" initialized
INFO - 2023-03-08 06:49:42 --> Final output sent to browser
DEBUG - 2023-03-08 06:49:42 --> Total execution time: 0.1525
INFO - 2023-03-08 06:49:43 --> Config Class Initialized
INFO - 2023-03-08 06:49:43 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:49:43 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:49:43 --> Utf8 Class Initialized
INFO - 2023-03-08 06:49:43 --> URI Class Initialized
INFO - 2023-03-08 06:49:43 --> Router Class Initialized
INFO - 2023-03-08 06:49:43 --> Output Class Initialized
INFO - 2023-03-08 06:49:43 --> Security Class Initialized
DEBUG - 2023-03-08 06:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:49:43 --> Input Class Initialized
INFO - 2023-03-08 06:49:43 --> Language Class Initialized
INFO - 2023-03-08 06:49:43 --> Loader Class Initialized
INFO - 2023-03-08 06:49:43 --> Controller Class Initialized
DEBUG - 2023-03-08 06:49:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:49:43 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:43 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:43 --> Model "Login_model" initialized
INFO - 2023-03-08 06:49:43 --> Final output sent to browser
DEBUG - 2023-03-08 06:49:43 --> Total execution time: 0.0294
INFO - 2023-03-08 06:49:48 --> Config Class Initialized
INFO - 2023-03-08 06:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:49:48 --> Utf8 Class Initialized
INFO - 2023-03-08 06:49:48 --> URI Class Initialized
INFO - 2023-03-08 06:49:48 --> Router Class Initialized
INFO - 2023-03-08 06:49:48 --> Output Class Initialized
INFO - 2023-03-08 06:49:48 --> Security Class Initialized
DEBUG - 2023-03-08 06:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:49:48 --> Input Class Initialized
INFO - 2023-03-08 06:49:48 --> Language Class Initialized
INFO - 2023-03-08 06:49:48 --> Loader Class Initialized
INFO - 2023-03-08 06:49:48 --> Controller Class Initialized
DEBUG - 2023-03-08 06:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:49:48 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:48 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:49:48 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:48 --> Model "Login_model" initialized
INFO - 2023-03-08 06:49:48 --> Final output sent to browser
DEBUG - 2023-03-08 06:49:48 --> Total execution time: 0.1036
INFO - 2023-03-08 06:49:48 --> Config Class Initialized
INFO - 2023-03-08 06:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:49:48 --> Utf8 Class Initialized
INFO - 2023-03-08 06:49:48 --> URI Class Initialized
INFO - 2023-03-08 06:49:48 --> Router Class Initialized
INFO - 2023-03-08 06:49:48 --> Output Class Initialized
INFO - 2023-03-08 06:49:48 --> Security Class Initialized
DEBUG - 2023-03-08 06:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:49:48 --> Input Class Initialized
INFO - 2023-03-08 06:49:48 --> Language Class Initialized
INFO - 2023-03-08 06:49:48 --> Loader Class Initialized
INFO - 2023-03-08 06:49:48 --> Controller Class Initialized
DEBUG - 2023-03-08 06:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:49:48 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:48 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:49:48 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:48 --> Model "Login_model" initialized
INFO - 2023-03-08 06:49:49 --> Final output sent to browser
DEBUG - 2023-03-08 06:49:49 --> Total execution time: 0.1201
INFO - 2023-03-08 06:49:57 --> Config Class Initialized
INFO - 2023-03-08 06:49:57 --> Hooks Class Initialized
INFO - 2023-03-08 06:49:57 --> Config Class Initialized
INFO - 2023-03-08 06:49:57 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:49:57 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:49:57 --> Utf8 Class Initialized
DEBUG - 2023-03-08 06:49:57 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:49:57 --> Utf8 Class Initialized
INFO - 2023-03-08 06:49:57 --> URI Class Initialized
INFO - 2023-03-08 06:49:57 --> URI Class Initialized
INFO - 2023-03-08 06:49:57 --> Router Class Initialized
INFO - 2023-03-08 06:49:57 --> Router Class Initialized
INFO - 2023-03-08 06:49:57 --> Output Class Initialized
INFO - 2023-03-08 06:49:57 --> Output Class Initialized
INFO - 2023-03-08 06:49:57 --> Security Class Initialized
INFO - 2023-03-08 06:49:57 --> Security Class Initialized
DEBUG - 2023-03-08 06:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-08 06:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:49:57 --> Input Class Initialized
INFO - 2023-03-08 06:49:57 --> Input Class Initialized
INFO - 2023-03-08 06:49:57 --> Language Class Initialized
INFO - 2023-03-08 06:49:57 --> Language Class Initialized
INFO - 2023-03-08 06:49:57 --> Loader Class Initialized
INFO - 2023-03-08 06:49:57 --> Loader Class Initialized
INFO - 2023-03-08 06:49:57 --> Controller Class Initialized
INFO - 2023-03-08 06:49:57 --> Controller Class Initialized
DEBUG - 2023-03-08 06:49:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-08 06:49:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:49:57 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:57 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:57 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:49:57 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:49:57 --> Final output sent to browser
DEBUG - 2023-03-08 06:49:57 --> Total execution time: 0.0182
INFO - 2023-03-08 06:49:57 --> Config Class Initialized
INFO - 2023-03-08 06:49:57 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:49:57 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:49:57 --> Utf8 Class Initialized
INFO - 2023-03-08 06:49:57 --> URI Class Initialized
INFO - 2023-03-08 06:49:57 --> Router Class Initialized
INFO - 2023-03-08 06:49:57 --> Output Class Initialized
INFO - 2023-03-08 06:49:57 --> Security Class Initialized
DEBUG - 2023-03-08 06:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:49:57 --> Input Class Initialized
INFO - 2023-03-08 06:49:57 --> Language Class Initialized
INFO - 2023-03-08 06:49:57 --> Loader Class Initialized
INFO - 2023-03-08 06:49:57 --> Controller Class Initialized
DEBUG - 2023-03-08 06:49:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:49:57 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:57 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:49:57 --> Final output sent to browser
DEBUG - 2023-03-08 06:49:57 --> Total execution time: 0.0507
INFO - 2023-03-08 06:49:58 --> Config Class Initialized
INFO - 2023-03-08 06:49:58 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:49:58 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:49:58 --> Utf8 Class Initialized
INFO - 2023-03-08 06:49:58 --> URI Class Initialized
INFO - 2023-03-08 06:49:58 --> Router Class Initialized
INFO - 2023-03-08 06:49:58 --> Output Class Initialized
INFO - 2023-03-08 06:49:58 --> Security Class Initialized
DEBUG - 2023-03-08 06:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:49:58 --> Input Class Initialized
INFO - 2023-03-08 06:49:58 --> Language Class Initialized
INFO - 2023-03-08 06:49:58 --> Loader Class Initialized
INFO - 2023-03-08 06:49:58 --> Controller Class Initialized
DEBUG - 2023-03-08 06:49:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:49:58 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:58 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:49:58 --> Config Class Initialized
INFO - 2023-03-08 06:49:58 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:49:58 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:49:58 --> Utf8 Class Initialized
INFO - 2023-03-08 06:49:58 --> URI Class Initialized
INFO - 2023-03-08 06:49:58 --> Router Class Initialized
INFO - 2023-03-08 06:49:58 --> Output Class Initialized
INFO - 2023-03-08 06:49:58 --> Security Class Initialized
DEBUG - 2023-03-08 06:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:49:58 --> Input Class Initialized
INFO - 2023-03-08 06:49:58 --> Language Class Initialized
INFO - 2023-03-08 06:49:58 --> Loader Class Initialized
INFO - 2023-03-08 06:49:58 --> Controller Class Initialized
DEBUG - 2023-03-08 06:49:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:49:58 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:58 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:49:58 --> Config Class Initialized
INFO - 2023-03-08 06:49:58 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:49:58 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:49:58 --> Utf8 Class Initialized
INFO - 2023-03-08 06:49:58 --> URI Class Initialized
INFO - 2023-03-08 06:49:58 --> Router Class Initialized
INFO - 2023-03-08 06:49:58 --> Output Class Initialized
INFO - 2023-03-08 06:49:58 --> Security Class Initialized
DEBUG - 2023-03-08 06:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:49:58 --> Input Class Initialized
INFO - 2023-03-08 06:49:58 --> Language Class Initialized
INFO - 2023-03-08 06:49:58 --> Loader Class Initialized
INFO - 2023-03-08 06:49:58 --> Controller Class Initialized
DEBUG - 2023-03-08 06:49:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:49:58 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:58 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:49:58 --> Config Class Initialized
INFO - 2023-03-08 06:49:58 --> Config Class Initialized
INFO - 2023-03-08 06:49:58 --> Hooks Class Initialized
INFO - 2023-03-08 06:49:58 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:49:58 --> UTF-8 Support Enabled
DEBUG - 2023-03-08 06:49:58 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:49:58 --> Utf8 Class Initialized
INFO - 2023-03-08 06:49:58 --> Utf8 Class Initialized
INFO - 2023-03-08 06:49:58 --> URI Class Initialized
INFO - 2023-03-08 06:49:58 --> URI Class Initialized
INFO - 2023-03-08 06:49:58 --> Router Class Initialized
INFO - 2023-03-08 06:49:58 --> Router Class Initialized
INFO - 2023-03-08 06:49:58 --> Output Class Initialized
INFO - 2023-03-08 06:49:58 --> Output Class Initialized
INFO - 2023-03-08 06:49:58 --> Security Class Initialized
INFO - 2023-03-08 06:49:58 --> Security Class Initialized
DEBUG - 2023-03-08 06:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-08 06:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:49:58 --> Input Class Initialized
INFO - 2023-03-08 06:49:58 --> Input Class Initialized
INFO - 2023-03-08 06:49:58 --> Language Class Initialized
INFO - 2023-03-08 06:49:58 --> Language Class Initialized
INFO - 2023-03-08 06:49:58 --> Loader Class Initialized
INFO - 2023-03-08 06:49:58 --> Loader Class Initialized
INFO - 2023-03-08 06:49:58 --> Controller Class Initialized
INFO - 2023-03-08 06:49:58 --> Controller Class Initialized
DEBUG - 2023-03-08 06:49:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-08 06:49:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:49:58 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:58 --> Database Driver Class Initialized
INFO - 2023-03-08 06:49:58 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:49:58 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:49:58 --> Final output sent to browser
DEBUG - 2023-03-08 06:49:58 --> Total execution time: 0.0165
INFO - 2023-03-08 06:50:01 --> Config Class Initialized
INFO - 2023-03-08 06:50:01 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:50:01 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:50:01 --> Utf8 Class Initialized
INFO - 2023-03-08 06:50:01 --> URI Class Initialized
INFO - 2023-03-08 06:50:01 --> Router Class Initialized
INFO - 2023-03-08 06:50:01 --> Output Class Initialized
INFO - 2023-03-08 06:50:01 --> Security Class Initialized
DEBUG - 2023-03-08 06:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:50:01 --> Input Class Initialized
INFO - 2023-03-08 06:50:01 --> Language Class Initialized
INFO - 2023-03-08 06:50:01 --> Loader Class Initialized
INFO - 2023-03-08 06:50:01 --> Controller Class Initialized
DEBUG - 2023-03-08 06:50:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:50:01 --> Database Driver Class Initialized
INFO - 2023-03-08 06:50:01 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:50:01 --> Final output sent to browser
DEBUG - 2023-03-08 06:50:01 --> Total execution time: 0.0453
INFO - 2023-03-08 06:50:01 --> Config Class Initialized
INFO - 2023-03-08 06:50:01 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:50:01 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:50:01 --> Utf8 Class Initialized
INFO - 2023-03-08 06:50:01 --> URI Class Initialized
INFO - 2023-03-08 06:50:01 --> Router Class Initialized
INFO - 2023-03-08 06:50:01 --> Output Class Initialized
INFO - 2023-03-08 06:50:01 --> Security Class Initialized
DEBUG - 2023-03-08 06:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:50:01 --> Input Class Initialized
INFO - 2023-03-08 06:50:01 --> Language Class Initialized
INFO - 2023-03-08 06:50:01 --> Loader Class Initialized
INFO - 2023-03-08 06:50:01 --> Controller Class Initialized
DEBUG - 2023-03-08 06:50:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:50:01 --> Database Driver Class Initialized
INFO - 2023-03-08 06:50:01 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:50:01 --> Final output sent to browser
DEBUG - 2023-03-08 06:50:01 --> Total execution time: 0.0521
INFO - 2023-03-08 06:50:02 --> Config Class Initialized
INFO - 2023-03-08 06:50:02 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:50:02 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:50:02 --> Utf8 Class Initialized
INFO - 2023-03-08 06:50:02 --> URI Class Initialized
INFO - 2023-03-08 06:50:02 --> Router Class Initialized
INFO - 2023-03-08 06:50:02 --> Output Class Initialized
INFO - 2023-03-08 06:50:02 --> Security Class Initialized
DEBUG - 2023-03-08 06:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:50:02 --> Input Class Initialized
INFO - 2023-03-08 06:50:02 --> Language Class Initialized
INFO - 2023-03-08 06:50:02 --> Loader Class Initialized
INFO - 2023-03-08 06:50:02 --> Controller Class Initialized
DEBUG - 2023-03-08 06:50:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:50:02 --> Database Driver Class Initialized
INFO - 2023-03-08 06:50:02 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:50:02 --> Database Driver Class Initialized
INFO - 2023-03-08 06:50:02 --> Model "Login_model" initialized
INFO - 2023-03-08 06:50:02 --> Final output sent to browser
DEBUG - 2023-03-08 06:50:02 --> Total execution time: 0.0480
INFO - 2023-03-08 06:50:02 --> Config Class Initialized
INFO - 2023-03-08 06:50:02 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:50:02 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:50:02 --> Utf8 Class Initialized
INFO - 2023-03-08 06:50:02 --> URI Class Initialized
INFO - 2023-03-08 06:50:02 --> Router Class Initialized
INFO - 2023-03-08 06:50:02 --> Output Class Initialized
INFO - 2023-03-08 06:50:02 --> Security Class Initialized
DEBUG - 2023-03-08 06:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:50:02 --> Input Class Initialized
INFO - 2023-03-08 06:50:02 --> Language Class Initialized
INFO - 2023-03-08 06:50:02 --> Loader Class Initialized
INFO - 2023-03-08 06:50:02 --> Controller Class Initialized
DEBUG - 2023-03-08 06:50:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:50:02 --> Database Driver Class Initialized
INFO - 2023-03-08 06:50:02 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:50:02 --> Database Driver Class Initialized
INFO - 2023-03-08 06:50:02 --> Model "Login_model" initialized
INFO - 2023-03-08 06:50:02 --> Final output sent to browser
DEBUG - 2023-03-08 06:50:02 --> Total execution time: 0.0403
INFO - 2023-03-08 06:50:03 --> Config Class Initialized
INFO - 2023-03-08 06:50:03 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:50:03 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:50:03 --> Utf8 Class Initialized
INFO - 2023-03-08 06:50:03 --> URI Class Initialized
INFO - 2023-03-08 06:50:03 --> Router Class Initialized
INFO - 2023-03-08 06:50:03 --> Output Class Initialized
INFO - 2023-03-08 06:50:03 --> Security Class Initialized
DEBUG - 2023-03-08 06:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:50:03 --> Input Class Initialized
INFO - 2023-03-08 06:50:03 --> Language Class Initialized
INFO - 2023-03-08 06:50:03 --> Loader Class Initialized
INFO - 2023-03-08 06:50:03 --> Controller Class Initialized
DEBUG - 2023-03-08 06:50:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:50:03 --> Database Driver Class Initialized
INFO - 2023-03-08 06:50:03 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:50:03 --> Final output sent to browser
DEBUG - 2023-03-08 06:50:03 --> Total execution time: 0.0700
INFO - 2023-03-08 06:50:03 --> Config Class Initialized
INFO - 2023-03-08 06:50:03 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:50:03 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:50:03 --> Utf8 Class Initialized
INFO - 2023-03-08 06:50:03 --> URI Class Initialized
INFO - 2023-03-08 06:50:03 --> Router Class Initialized
INFO - 2023-03-08 06:50:03 --> Output Class Initialized
INFO - 2023-03-08 06:50:03 --> Security Class Initialized
DEBUG - 2023-03-08 06:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:50:03 --> Input Class Initialized
INFO - 2023-03-08 06:50:03 --> Language Class Initialized
INFO - 2023-03-08 06:50:03 --> Loader Class Initialized
INFO - 2023-03-08 06:50:03 --> Controller Class Initialized
DEBUG - 2023-03-08 06:50:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:50:03 --> Database Driver Class Initialized
INFO - 2023-03-08 06:50:03 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:50:03 --> Final output sent to browser
DEBUG - 2023-03-08 06:50:03 --> Total execution time: 0.0770
INFO - 2023-03-08 06:50:08 --> Config Class Initialized
INFO - 2023-03-08 06:50:08 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:50:08 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:50:08 --> Utf8 Class Initialized
INFO - 2023-03-08 06:50:08 --> URI Class Initialized
INFO - 2023-03-08 06:50:08 --> Router Class Initialized
INFO - 2023-03-08 06:50:08 --> Output Class Initialized
INFO - 2023-03-08 06:50:08 --> Security Class Initialized
DEBUG - 2023-03-08 06:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:50:08 --> Input Class Initialized
INFO - 2023-03-08 06:50:08 --> Language Class Initialized
INFO - 2023-03-08 06:50:08 --> Loader Class Initialized
INFO - 2023-03-08 06:50:08 --> Controller Class Initialized
DEBUG - 2023-03-08 06:50:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:50:08 --> Database Driver Class Initialized
INFO - 2023-03-08 06:50:08 --> Database Driver Class Initialized
INFO - 2023-03-08 06:50:08 --> Model "Login_model" initialized
INFO - 2023-03-08 06:50:08 --> Final output sent to browser
DEBUG - 2023-03-08 06:50:08 --> Total execution time: 0.0251
INFO - 2023-03-08 06:50:08 --> Config Class Initialized
INFO - 2023-03-08 06:50:08 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:50:08 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:50:08 --> Utf8 Class Initialized
INFO - 2023-03-08 06:50:08 --> URI Class Initialized
INFO - 2023-03-08 06:50:08 --> Router Class Initialized
INFO - 2023-03-08 06:50:08 --> Output Class Initialized
INFO - 2023-03-08 06:50:08 --> Security Class Initialized
DEBUG - 2023-03-08 06:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:50:08 --> Input Class Initialized
INFO - 2023-03-08 06:50:08 --> Language Class Initialized
INFO - 2023-03-08 06:50:08 --> Loader Class Initialized
INFO - 2023-03-08 06:50:08 --> Controller Class Initialized
DEBUG - 2023-03-08 06:50:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:50:08 --> Database Driver Class Initialized
INFO - 2023-03-08 06:50:08 --> Database Driver Class Initialized
INFO - 2023-03-08 06:50:08 --> Model "Login_model" initialized
INFO - 2023-03-08 06:50:08 --> Final output sent to browser
DEBUG - 2023-03-08 06:50:08 --> Total execution time: 0.0597
INFO - 2023-03-08 06:57:12 --> Config Class Initialized
INFO - 2023-03-08 06:57:12 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:57:12 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:57:12 --> Utf8 Class Initialized
INFO - 2023-03-08 06:57:12 --> URI Class Initialized
INFO - 2023-03-08 06:57:12 --> Router Class Initialized
INFO - 2023-03-08 06:57:12 --> Output Class Initialized
INFO - 2023-03-08 06:57:12 --> Security Class Initialized
DEBUG - 2023-03-08 06:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:57:12 --> Input Class Initialized
INFO - 2023-03-08 06:57:12 --> Language Class Initialized
INFO - 2023-03-08 06:57:12 --> Loader Class Initialized
INFO - 2023-03-08 06:57:12 --> Controller Class Initialized
DEBUG - 2023-03-08 06:57:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:57:12 --> Database Driver Class Initialized
INFO - 2023-03-08 06:57:12 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:57:12 --> Database Driver Class Initialized
INFO - 2023-03-08 06:57:12 --> Model "Login_model" initialized
INFO - 2023-03-08 06:57:12 --> Final output sent to browser
DEBUG - 2023-03-08 06:57:12 --> Total execution time: 0.0440
INFO - 2023-03-08 06:57:12 --> Config Class Initialized
INFO - 2023-03-08 06:57:12 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:57:12 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:57:12 --> Utf8 Class Initialized
INFO - 2023-03-08 06:57:12 --> URI Class Initialized
INFO - 2023-03-08 06:57:12 --> Router Class Initialized
INFO - 2023-03-08 06:57:12 --> Output Class Initialized
INFO - 2023-03-08 06:57:12 --> Security Class Initialized
DEBUG - 2023-03-08 06:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:57:12 --> Input Class Initialized
INFO - 2023-03-08 06:57:12 --> Language Class Initialized
INFO - 2023-03-08 06:57:12 --> Loader Class Initialized
INFO - 2023-03-08 06:57:12 --> Controller Class Initialized
DEBUG - 2023-03-08 06:57:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:57:12 --> Database Driver Class Initialized
INFO - 2023-03-08 06:57:12 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:57:12 --> Database Driver Class Initialized
INFO - 2023-03-08 06:57:12 --> Model "Login_model" initialized
INFO - 2023-03-08 06:57:12 --> Final output sent to browser
DEBUG - 2023-03-08 06:57:12 --> Total execution time: 0.0827
INFO - 2023-03-08 06:57:59 --> Config Class Initialized
INFO - 2023-03-08 06:57:59 --> Hooks Class Initialized
INFO - 2023-03-08 06:57:59 --> Config Class Initialized
DEBUG - 2023-03-08 06:57:59 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:57:59 --> Hooks Class Initialized
INFO - 2023-03-08 06:57:59 --> Utf8 Class Initialized
INFO - 2023-03-08 06:57:59 --> URI Class Initialized
DEBUG - 2023-03-08 06:57:59 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:57:59 --> Router Class Initialized
INFO - 2023-03-08 06:57:59 --> Utf8 Class Initialized
INFO - 2023-03-08 06:57:59 --> Output Class Initialized
INFO - 2023-03-08 06:57:59 --> URI Class Initialized
INFO - 2023-03-08 06:57:59 --> Security Class Initialized
INFO - 2023-03-08 06:57:59 --> Router Class Initialized
DEBUG - 2023-03-08 06:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:57:59 --> Output Class Initialized
INFO - 2023-03-08 06:57:59 --> Input Class Initialized
INFO - 2023-03-08 06:57:59 --> Security Class Initialized
INFO - 2023-03-08 06:57:59 --> Language Class Initialized
DEBUG - 2023-03-08 06:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:57:59 --> Input Class Initialized
INFO - 2023-03-08 06:57:59 --> Loader Class Initialized
INFO - 2023-03-08 06:57:59 --> Language Class Initialized
INFO - 2023-03-08 06:57:59 --> Controller Class Initialized
DEBUG - 2023-03-08 06:57:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:57:59 --> Loader Class Initialized
INFO - 2023-03-08 06:57:59 --> Database Driver Class Initialized
INFO - 2023-03-08 06:57:59 --> Controller Class Initialized
DEBUG - 2023-03-08 06:57:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:57:59 --> Database Driver Class Initialized
INFO - 2023-03-08 06:57:59 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:57:59 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:57:59 --> Final output sent to browser
DEBUG - 2023-03-08 06:57:59 --> Total execution time: 0.0140
INFO - 2023-03-08 06:57:59 --> Config Class Initialized
INFO - 2023-03-08 06:57:59 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:57:59 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:57:59 --> Utf8 Class Initialized
INFO - 2023-03-08 06:57:59 --> URI Class Initialized
INFO - 2023-03-08 06:57:59 --> Router Class Initialized
INFO - 2023-03-08 06:57:59 --> Output Class Initialized
INFO - 2023-03-08 06:57:59 --> Security Class Initialized
DEBUG - 2023-03-08 06:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:57:59 --> Input Class Initialized
INFO - 2023-03-08 06:57:59 --> Language Class Initialized
INFO - 2023-03-08 06:57:59 --> Loader Class Initialized
INFO - 2023-03-08 06:57:59 --> Controller Class Initialized
DEBUG - 2023-03-08 06:57:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:57:59 --> Database Driver Class Initialized
INFO - 2023-03-08 06:57:59 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:57:59 --> Final output sent to browser
DEBUG - 2023-03-08 06:57:59 --> Total execution time: 0.0502
INFO - 2023-03-08 06:57:59 --> Config Class Initialized
INFO - 2023-03-08 06:57:59 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:57:59 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:57:59 --> Utf8 Class Initialized
INFO - 2023-03-08 06:57:59 --> URI Class Initialized
INFO - 2023-03-08 06:57:59 --> Router Class Initialized
INFO - 2023-03-08 06:57:59 --> Output Class Initialized
INFO - 2023-03-08 06:57:59 --> Security Class Initialized
DEBUG - 2023-03-08 06:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:57:59 --> Input Class Initialized
INFO - 2023-03-08 06:57:59 --> Language Class Initialized
INFO - 2023-03-08 06:57:59 --> Loader Class Initialized
INFO - 2023-03-08 06:57:59 --> Controller Class Initialized
DEBUG - 2023-03-08 06:57:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:57:59 --> Database Driver Class Initialized
INFO - 2023-03-08 06:57:59 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:00 --> Config Class Initialized
INFO - 2023-03-08 06:58:00 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:00 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:00 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:00 --> URI Class Initialized
INFO - 2023-03-08 06:58:00 --> Router Class Initialized
INFO - 2023-03-08 06:58:00 --> Output Class Initialized
INFO - 2023-03-08 06:58:00 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:00 --> Input Class Initialized
INFO - 2023-03-08 06:58:00 --> Language Class Initialized
INFO - 2023-03-08 06:58:00 --> Loader Class Initialized
INFO - 2023-03-08 06:58:00 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:00 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:00 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:00 --> Config Class Initialized
INFO - 2023-03-08 06:58:00 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:00 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:00 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:00 --> URI Class Initialized
INFO - 2023-03-08 06:58:00 --> Router Class Initialized
INFO - 2023-03-08 06:58:00 --> Output Class Initialized
INFO - 2023-03-08 06:58:00 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:00 --> Input Class Initialized
INFO - 2023-03-08 06:58:00 --> Language Class Initialized
INFO - 2023-03-08 06:58:00 --> Loader Class Initialized
INFO - 2023-03-08 06:58:00 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:00 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:00 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:02 --> Config Class Initialized
INFO - 2023-03-08 06:58:02 --> Config Class Initialized
INFO - 2023-03-08 06:58:02 --> Hooks Class Initialized
INFO - 2023-03-08 06:58:02 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:02 --> UTF-8 Support Enabled
DEBUG - 2023-03-08 06:58:02 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:02 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:02 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:02 --> URI Class Initialized
INFO - 2023-03-08 06:58:02 --> URI Class Initialized
INFO - 2023-03-08 06:58:02 --> Router Class Initialized
INFO - 2023-03-08 06:58:02 --> Router Class Initialized
INFO - 2023-03-08 06:58:02 --> Output Class Initialized
INFO - 2023-03-08 06:58:02 --> Output Class Initialized
INFO - 2023-03-08 06:58:02 --> Security Class Initialized
INFO - 2023-03-08 06:58:02 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-08 06:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:02 --> Input Class Initialized
INFO - 2023-03-08 06:58:02 --> Input Class Initialized
INFO - 2023-03-08 06:58:02 --> Language Class Initialized
INFO - 2023-03-08 06:58:02 --> Language Class Initialized
INFO - 2023-03-08 06:58:02 --> Loader Class Initialized
INFO - 2023-03-08 06:58:02 --> Loader Class Initialized
INFO - 2023-03-08 06:58:02 --> Controller Class Initialized
INFO - 2023-03-08 06:58:02 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-08 06:58:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:02 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:02 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:02 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:02 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:02 --> Final output sent to browser
DEBUG - 2023-03-08 06:58:02 --> Total execution time: 0.0237
INFO - 2023-03-08 06:58:03 --> Config Class Initialized
INFO - 2023-03-08 06:58:03 --> Config Class Initialized
INFO - 2023-03-08 06:58:03 --> Hooks Class Initialized
INFO - 2023-03-08 06:58:03 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:03 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:03 --> Utf8 Class Initialized
DEBUG - 2023-03-08 06:58:03 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:03 --> URI Class Initialized
INFO - 2023-03-08 06:58:03 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:03 --> Router Class Initialized
INFO - 2023-03-08 06:58:03 --> URI Class Initialized
INFO - 2023-03-08 06:58:03 --> Output Class Initialized
INFO - 2023-03-08 06:58:03 --> Router Class Initialized
INFO - 2023-03-08 06:58:03 --> Security Class Initialized
INFO - 2023-03-08 06:58:03 --> Output Class Initialized
DEBUG - 2023-03-08 06:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:03 --> Input Class Initialized
INFO - 2023-03-08 06:58:03 --> Security Class Initialized
INFO - 2023-03-08 06:58:03 --> Language Class Initialized
DEBUG - 2023-03-08 06:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:03 --> Loader Class Initialized
INFO - 2023-03-08 06:58:03 --> Input Class Initialized
INFO - 2023-03-08 06:58:03 --> Controller Class Initialized
INFO - 2023-03-08 06:58:03 --> Language Class Initialized
DEBUG - 2023-03-08 06:58:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:03 --> Loader Class Initialized
INFO - 2023-03-08 06:58:03 --> Controller Class Initialized
INFO - 2023-03-08 06:58:03 --> Database Driver Class Initialized
DEBUG - 2023-03-08 06:58:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:04 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:04 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:04 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:04 --> Final output sent to browser
DEBUG - 2023-03-08 06:58:04 --> Total execution time: 0.0183
INFO - 2023-03-08 06:58:05 --> Config Class Initialized
INFO - 2023-03-08 06:58:05 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:05 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:05 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:05 --> URI Class Initialized
INFO - 2023-03-08 06:58:05 --> Router Class Initialized
INFO - 2023-03-08 06:58:05 --> Output Class Initialized
INFO - 2023-03-08 06:58:05 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:05 --> Input Class Initialized
INFO - 2023-03-08 06:58:05 --> Language Class Initialized
INFO - 2023-03-08 06:58:05 --> Loader Class Initialized
INFO - 2023-03-08 06:58:05 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:05 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:05 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:05 --> Config Class Initialized
INFO - 2023-03-08 06:58:05 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:05 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:05 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:05 --> URI Class Initialized
INFO - 2023-03-08 06:58:05 --> Router Class Initialized
INFO - 2023-03-08 06:58:05 --> Output Class Initialized
INFO - 2023-03-08 06:58:05 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:05 --> Input Class Initialized
INFO - 2023-03-08 06:58:05 --> Language Class Initialized
INFO - 2023-03-08 06:58:05 --> Loader Class Initialized
INFO - 2023-03-08 06:58:05 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:05 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:05 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:07 --> Config Class Initialized
INFO - 2023-03-08 06:58:07 --> Config Class Initialized
INFO - 2023-03-08 06:58:07 --> Hooks Class Initialized
INFO - 2023-03-08 06:58:07 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:07 --> UTF-8 Support Enabled
DEBUG - 2023-03-08 06:58:07 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:07 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:07 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:07 --> URI Class Initialized
INFO - 2023-03-08 06:58:07 --> URI Class Initialized
INFO - 2023-03-08 06:58:07 --> Router Class Initialized
INFO - 2023-03-08 06:58:07 --> Router Class Initialized
INFO - 2023-03-08 06:58:07 --> Output Class Initialized
INFO - 2023-03-08 06:58:07 --> Output Class Initialized
INFO - 2023-03-08 06:58:07 --> Security Class Initialized
INFO - 2023-03-08 06:58:07 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:07 --> Input Class Initialized
DEBUG - 2023-03-08 06:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:07 --> Language Class Initialized
INFO - 2023-03-08 06:58:07 --> Input Class Initialized
INFO - 2023-03-08 06:58:07 --> Language Class Initialized
INFO - 2023-03-08 06:58:07 --> Loader Class Initialized
INFO - 2023-03-08 06:58:07 --> Controller Class Initialized
INFO - 2023-03-08 06:58:07 --> Loader Class Initialized
DEBUG - 2023-03-08 06:58:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:07 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:07 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:07 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:07 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:07 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:07 --> Final output sent to browser
DEBUG - 2023-03-08 06:58:07 --> Total execution time: 0.0182
INFO - 2023-03-08 06:58:07 --> Config Class Initialized
INFO - 2023-03-08 06:58:07 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:07 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:07 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:07 --> URI Class Initialized
INFO - 2023-03-08 06:58:07 --> Router Class Initialized
INFO - 2023-03-08 06:58:07 --> Output Class Initialized
INFO - 2023-03-08 06:58:07 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:07 --> Input Class Initialized
INFO - 2023-03-08 06:58:07 --> Language Class Initialized
INFO - 2023-03-08 06:58:07 --> Loader Class Initialized
INFO - 2023-03-08 06:58:07 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:07 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:07 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:07 --> Final output sent to browser
DEBUG - 2023-03-08 06:58:07 --> Total execution time: 0.0156
INFO - 2023-03-08 06:58:08 --> Config Class Initialized
INFO - 2023-03-08 06:58:08 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:08 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:08 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:08 --> URI Class Initialized
INFO - 2023-03-08 06:58:08 --> Router Class Initialized
INFO - 2023-03-08 06:58:08 --> Output Class Initialized
INFO - 2023-03-08 06:58:08 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:08 --> Input Class Initialized
INFO - 2023-03-08 06:58:08 --> Language Class Initialized
INFO - 2023-03-08 06:58:08 --> Loader Class Initialized
INFO - 2023-03-08 06:58:08 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:08 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:08 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:08 --> Config Class Initialized
INFO - 2023-03-08 06:58:08 --> Hooks Class Initialized
INFO - 2023-03-08 06:58:08 --> Config Class Initialized
DEBUG - 2023-03-08 06:58:08 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:08 --> Hooks Class Initialized
INFO - 2023-03-08 06:58:08 --> Utf8 Class Initialized
DEBUG - 2023-03-08 06:58:08 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:08 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:08 --> URI Class Initialized
INFO - 2023-03-08 06:58:08 --> URI Class Initialized
INFO - 2023-03-08 06:58:08 --> Router Class Initialized
INFO - 2023-03-08 06:58:08 --> Router Class Initialized
INFO - 2023-03-08 06:58:08 --> Output Class Initialized
INFO - 2023-03-08 06:58:08 --> Output Class Initialized
INFO - 2023-03-08 06:58:08 --> Security Class Initialized
INFO - 2023-03-08 06:58:08 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-08 06:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:08 --> Input Class Initialized
INFO - 2023-03-08 06:58:08 --> Input Class Initialized
INFO - 2023-03-08 06:58:08 --> Language Class Initialized
INFO - 2023-03-08 06:58:08 --> Language Class Initialized
INFO - 2023-03-08 06:58:08 --> Loader Class Initialized
INFO - 2023-03-08 06:58:08 --> Loader Class Initialized
INFO - 2023-03-08 06:58:08 --> Controller Class Initialized
INFO - 2023-03-08 06:58:08 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-08 06:58:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:08 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:08 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:08 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:08 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:08 --> Final output sent to browser
DEBUG - 2023-03-08 06:58:08 --> Total execution time: 0.0144
INFO - 2023-03-08 06:58:08 --> Config Class Initialized
INFO - 2023-03-08 06:58:08 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:08 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:08 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:08 --> URI Class Initialized
INFO - 2023-03-08 06:58:08 --> Router Class Initialized
INFO - 2023-03-08 06:58:08 --> Output Class Initialized
INFO - 2023-03-08 06:58:08 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:08 --> Input Class Initialized
INFO - 2023-03-08 06:58:08 --> Language Class Initialized
INFO - 2023-03-08 06:58:08 --> Loader Class Initialized
INFO - 2023-03-08 06:58:08 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:08 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:08 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:36 --> Config Class Initialized
INFO - 2023-03-08 06:58:36 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:36 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:36 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:36 --> URI Class Initialized
INFO - 2023-03-08 06:58:36 --> Router Class Initialized
INFO - 2023-03-08 06:58:36 --> Output Class Initialized
INFO - 2023-03-08 06:58:36 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:36 --> Input Class Initialized
INFO - 2023-03-08 06:58:36 --> Language Class Initialized
INFO - 2023-03-08 06:58:36 --> Loader Class Initialized
INFO - 2023-03-08 06:58:36 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:36 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:36 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:36 --> Model "Login_model" initialized
INFO - 2023-03-08 06:58:36 --> Final output sent to browser
DEBUG - 2023-03-08 06:58:36 --> Total execution time: 0.0434
INFO - 2023-03-08 06:58:36 --> Config Class Initialized
INFO - 2023-03-08 06:58:37 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:37 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:37 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:37 --> URI Class Initialized
INFO - 2023-03-08 06:58:37 --> Router Class Initialized
INFO - 2023-03-08 06:58:37 --> Output Class Initialized
INFO - 2023-03-08 06:58:37 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:37 --> Input Class Initialized
INFO - 2023-03-08 06:58:37 --> Language Class Initialized
INFO - 2023-03-08 06:58:37 --> Loader Class Initialized
INFO - 2023-03-08 06:58:37 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:37 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:37 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:37 --> Model "Login_model" initialized
INFO - 2023-03-08 06:58:37 --> Final output sent to browser
DEBUG - 2023-03-08 06:58:37 --> Total execution time: 0.0639
INFO - 2023-03-08 06:58:40 --> Config Class Initialized
INFO - 2023-03-08 06:58:40 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:40 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:40 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:40 --> URI Class Initialized
INFO - 2023-03-08 06:58:40 --> Router Class Initialized
INFO - 2023-03-08 06:58:40 --> Output Class Initialized
INFO - 2023-03-08 06:58:40 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:40 --> Input Class Initialized
INFO - 2023-03-08 06:58:40 --> Language Class Initialized
INFO - 2023-03-08 06:58:40 --> Loader Class Initialized
INFO - 2023-03-08 06:58:40 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:40 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:40 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:40 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:40 --> Model "Login_model" initialized
INFO - 2023-03-08 06:58:40 --> Final output sent to browser
DEBUG - 2023-03-08 06:58:40 --> Total execution time: 0.0514
INFO - 2023-03-08 06:58:40 --> Config Class Initialized
INFO - 2023-03-08 06:58:40 --> Hooks Class Initialized
DEBUG - 2023-03-08 06:58:40 --> UTF-8 Support Enabled
INFO - 2023-03-08 06:58:40 --> Utf8 Class Initialized
INFO - 2023-03-08 06:58:40 --> URI Class Initialized
INFO - 2023-03-08 06:58:40 --> Router Class Initialized
INFO - 2023-03-08 06:58:40 --> Output Class Initialized
INFO - 2023-03-08 06:58:40 --> Security Class Initialized
DEBUG - 2023-03-08 06:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 06:58:40 --> Input Class Initialized
INFO - 2023-03-08 06:58:40 --> Language Class Initialized
INFO - 2023-03-08 06:58:40 --> Loader Class Initialized
INFO - 2023-03-08 06:58:40 --> Controller Class Initialized
DEBUG - 2023-03-08 06:58:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 06:58:40 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:40 --> Model "Cluster_model" initialized
INFO - 2023-03-08 06:58:40 --> Database Driver Class Initialized
INFO - 2023-03-08 06:58:40 --> Model "Login_model" initialized
INFO - 2023-03-08 06:58:40 --> Final output sent to browser
DEBUG - 2023-03-08 06:58:40 --> Total execution time: 0.0412
INFO - 2023-03-08 07:03:19 --> Config Class Initialized
INFO - 2023-03-08 07:03:19 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:03:19 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:03:19 --> Utf8 Class Initialized
INFO - 2023-03-08 07:03:19 --> URI Class Initialized
INFO - 2023-03-08 07:03:19 --> Router Class Initialized
INFO - 2023-03-08 07:03:19 --> Output Class Initialized
INFO - 2023-03-08 07:03:19 --> Security Class Initialized
DEBUG - 2023-03-08 07:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:03:19 --> Input Class Initialized
INFO - 2023-03-08 07:03:19 --> Language Class Initialized
INFO - 2023-03-08 07:03:19 --> Loader Class Initialized
INFO - 2023-03-08 07:03:19 --> Controller Class Initialized
DEBUG - 2023-03-08 07:03:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:03:19 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:19 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:03:19 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:19 --> Model "Login_model" initialized
INFO - 2023-03-08 07:03:19 --> Final output sent to browser
DEBUG - 2023-03-08 07:03:19 --> Total execution time: 0.0939
INFO - 2023-03-08 07:03:19 --> Config Class Initialized
INFO - 2023-03-08 07:03:19 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:03:19 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:03:19 --> Utf8 Class Initialized
INFO - 2023-03-08 07:03:19 --> URI Class Initialized
INFO - 2023-03-08 07:03:19 --> Router Class Initialized
INFO - 2023-03-08 07:03:19 --> Output Class Initialized
INFO - 2023-03-08 07:03:19 --> Security Class Initialized
DEBUG - 2023-03-08 07:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:03:19 --> Input Class Initialized
INFO - 2023-03-08 07:03:19 --> Language Class Initialized
INFO - 2023-03-08 07:03:19 --> Loader Class Initialized
INFO - 2023-03-08 07:03:19 --> Controller Class Initialized
DEBUG - 2023-03-08 07:03:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:03:19 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:19 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:03:19 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:19 --> Model "Login_model" initialized
INFO - 2023-03-08 07:03:19 --> Final output sent to browser
DEBUG - 2023-03-08 07:03:19 --> Total execution time: 0.0845
INFO - 2023-03-08 07:03:20 --> Config Class Initialized
INFO - 2023-03-08 07:03:20 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:03:20 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:03:20 --> Utf8 Class Initialized
INFO - 2023-03-08 07:03:20 --> URI Class Initialized
INFO - 2023-03-08 07:03:20 --> Router Class Initialized
INFO - 2023-03-08 07:03:20 --> Output Class Initialized
INFO - 2023-03-08 07:03:20 --> Security Class Initialized
DEBUG - 2023-03-08 07:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:03:20 --> Input Class Initialized
INFO - 2023-03-08 07:03:20 --> Language Class Initialized
INFO - 2023-03-08 07:03:20 --> Loader Class Initialized
INFO - 2023-03-08 07:03:20 --> Controller Class Initialized
DEBUG - 2023-03-08 07:03:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:03:20 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:20 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:03:20 --> Final output sent to browser
DEBUG - 2023-03-08 07:03:20 --> Total execution time: 0.0355
INFO - 2023-03-08 07:03:20 --> Config Class Initialized
INFO - 2023-03-08 07:03:20 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:03:20 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:03:20 --> Utf8 Class Initialized
INFO - 2023-03-08 07:03:20 --> URI Class Initialized
INFO - 2023-03-08 07:03:20 --> Router Class Initialized
INFO - 2023-03-08 07:03:20 --> Output Class Initialized
INFO - 2023-03-08 07:03:20 --> Security Class Initialized
DEBUG - 2023-03-08 07:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:03:20 --> Input Class Initialized
INFO - 2023-03-08 07:03:20 --> Language Class Initialized
INFO - 2023-03-08 07:03:20 --> Loader Class Initialized
INFO - 2023-03-08 07:03:20 --> Controller Class Initialized
DEBUG - 2023-03-08 07:03:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:03:20 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:20 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:03:20 --> Final output sent to browser
DEBUG - 2023-03-08 07:03:20 --> Total execution time: 0.0541
INFO - 2023-03-08 07:03:21 --> Config Class Initialized
INFO - 2023-03-08 07:03:21 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:03:21 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:03:21 --> Utf8 Class Initialized
INFO - 2023-03-08 07:03:21 --> URI Class Initialized
INFO - 2023-03-08 07:03:21 --> Router Class Initialized
INFO - 2023-03-08 07:03:21 --> Output Class Initialized
INFO - 2023-03-08 07:03:21 --> Security Class Initialized
DEBUG - 2023-03-08 07:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:03:21 --> Input Class Initialized
INFO - 2023-03-08 07:03:21 --> Language Class Initialized
INFO - 2023-03-08 07:03:21 --> Loader Class Initialized
INFO - 2023-03-08 07:03:21 --> Controller Class Initialized
DEBUG - 2023-03-08 07:03:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:03:21 --> Final output sent to browser
DEBUG - 2023-03-08 07:03:21 --> Total execution time: 0.0456
INFO - 2023-03-08 07:03:21 --> Config Class Initialized
INFO - 2023-03-08 07:03:21 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:03:21 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:03:21 --> Utf8 Class Initialized
INFO - 2023-03-08 07:03:21 --> URI Class Initialized
INFO - 2023-03-08 07:03:21 --> Router Class Initialized
INFO - 2023-03-08 07:03:21 --> Output Class Initialized
INFO - 2023-03-08 07:03:21 --> Security Class Initialized
DEBUG - 2023-03-08 07:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:03:21 --> Input Class Initialized
INFO - 2023-03-08 07:03:21 --> Language Class Initialized
INFO - 2023-03-08 07:03:21 --> Loader Class Initialized
INFO - 2023-03-08 07:03:21 --> Controller Class Initialized
DEBUG - 2023-03-08 07:03:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:03:21 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:21 --> Model "Login_model" initialized
INFO - 2023-03-08 07:03:21 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:21 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:03:21 --> Final output sent to browser
DEBUG - 2023-03-08 07:03:21 --> Total execution time: 0.0358
INFO - 2023-03-08 07:03:21 --> Config Class Initialized
INFO - 2023-03-08 07:03:21 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:03:21 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:03:21 --> Utf8 Class Initialized
INFO - 2023-03-08 07:03:21 --> URI Class Initialized
INFO - 2023-03-08 07:03:21 --> Router Class Initialized
INFO - 2023-03-08 07:03:21 --> Output Class Initialized
INFO - 2023-03-08 07:03:21 --> Security Class Initialized
DEBUG - 2023-03-08 07:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:03:21 --> Input Class Initialized
INFO - 2023-03-08 07:03:21 --> Language Class Initialized
INFO - 2023-03-08 07:03:21 --> Loader Class Initialized
INFO - 2023-03-08 07:03:21 --> Controller Class Initialized
DEBUG - 2023-03-08 07:03:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:03:21 --> Final output sent to browser
DEBUG - 2023-03-08 07:03:21 --> Total execution time: 0.0828
INFO - 2023-03-08 07:03:21 --> Config Class Initialized
INFO - 2023-03-08 07:03:21 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:03:21 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:03:21 --> Utf8 Class Initialized
INFO - 2023-03-08 07:03:21 --> URI Class Initialized
INFO - 2023-03-08 07:03:21 --> Router Class Initialized
INFO - 2023-03-08 07:03:21 --> Output Class Initialized
INFO - 2023-03-08 07:03:21 --> Security Class Initialized
DEBUG - 2023-03-08 07:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:03:21 --> Input Class Initialized
INFO - 2023-03-08 07:03:21 --> Language Class Initialized
INFO - 2023-03-08 07:03:21 --> Loader Class Initialized
INFO - 2023-03-08 07:03:21 --> Controller Class Initialized
DEBUG - 2023-03-08 07:03:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:03:21 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:21 --> Model "Login_model" initialized
INFO - 2023-03-08 07:03:21 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:21 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:03:21 --> Final output sent to browser
DEBUG - 2023-03-08 07:03:21 --> Total execution time: 0.0367
INFO - 2023-03-08 07:03:21 --> Config Class Initialized
INFO - 2023-03-08 07:03:21 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:03:21 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:03:21 --> Utf8 Class Initialized
INFO - 2023-03-08 07:03:21 --> URI Class Initialized
INFO - 2023-03-08 07:03:21 --> Router Class Initialized
INFO - 2023-03-08 07:03:21 --> Output Class Initialized
INFO - 2023-03-08 07:03:21 --> Security Class Initialized
DEBUG - 2023-03-08 07:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:03:21 --> Input Class Initialized
INFO - 2023-03-08 07:03:21 --> Language Class Initialized
INFO - 2023-03-08 07:03:21 --> Loader Class Initialized
INFO - 2023-03-08 07:03:21 --> Controller Class Initialized
DEBUG - 2023-03-08 07:03:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:03:21 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:21 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:03:21 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:21 --> Model "Login_model" initialized
INFO - 2023-03-08 07:03:21 --> Final output sent to browser
DEBUG - 2023-03-08 07:03:21 --> Total execution time: 0.0787
INFO - 2023-03-08 07:03:30 --> Config Class Initialized
INFO - 2023-03-08 07:03:30 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:03:30 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:03:30 --> Utf8 Class Initialized
INFO - 2023-03-08 07:03:30 --> URI Class Initialized
INFO - 2023-03-08 07:03:30 --> Router Class Initialized
INFO - 2023-03-08 07:03:30 --> Output Class Initialized
INFO - 2023-03-08 07:03:30 --> Security Class Initialized
DEBUG - 2023-03-08 07:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:03:30 --> Input Class Initialized
INFO - 2023-03-08 07:03:30 --> Language Class Initialized
INFO - 2023-03-08 07:03:30 --> Loader Class Initialized
INFO - 2023-03-08 07:03:30 --> Controller Class Initialized
DEBUG - 2023-03-08 07:03:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:03:30 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:30 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:30 --> Model "Login_model" initialized
INFO - 2023-03-08 07:03:30 --> Final output sent to browser
DEBUG - 2023-03-08 07:03:30 --> Total execution time: 0.0404
INFO - 2023-03-08 07:03:30 --> Config Class Initialized
INFO - 2023-03-08 07:03:30 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:03:30 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:03:30 --> Utf8 Class Initialized
INFO - 2023-03-08 07:03:30 --> URI Class Initialized
INFO - 2023-03-08 07:03:30 --> Router Class Initialized
INFO - 2023-03-08 07:03:30 --> Output Class Initialized
INFO - 2023-03-08 07:03:30 --> Security Class Initialized
DEBUG - 2023-03-08 07:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:03:30 --> Input Class Initialized
INFO - 2023-03-08 07:03:30 --> Language Class Initialized
INFO - 2023-03-08 07:03:30 --> Loader Class Initialized
INFO - 2023-03-08 07:03:30 --> Controller Class Initialized
DEBUG - 2023-03-08 07:03:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:03:30 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:30 --> Database Driver Class Initialized
INFO - 2023-03-08 07:03:30 --> Model "Login_model" initialized
INFO - 2023-03-08 07:03:30 --> Final output sent to browser
DEBUG - 2023-03-08 07:03:30 --> Total execution time: 0.0695
INFO - 2023-03-08 07:04:42 --> Config Class Initialized
INFO - 2023-03-08 07:04:42 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:04:42 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:04:42 --> Utf8 Class Initialized
INFO - 2023-03-08 07:04:42 --> URI Class Initialized
INFO - 2023-03-08 07:04:42 --> Router Class Initialized
INFO - 2023-03-08 07:04:42 --> Output Class Initialized
INFO - 2023-03-08 07:04:42 --> Security Class Initialized
DEBUG - 2023-03-08 07:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:04:42 --> Input Class Initialized
INFO - 2023-03-08 07:04:42 --> Language Class Initialized
INFO - 2023-03-08 07:04:42 --> Loader Class Initialized
INFO - 2023-03-08 07:04:42 --> Controller Class Initialized
DEBUG - 2023-03-08 07:04:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:04:42 --> Database Driver Class Initialized
INFO - 2023-03-08 07:04:42 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:04:42 --> Final output sent to browser
DEBUG - 2023-03-08 07:04:42 --> Total execution time: 0.0620
INFO - 2023-03-08 07:04:42 --> Config Class Initialized
INFO - 2023-03-08 07:04:42 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:04:42 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:04:42 --> Utf8 Class Initialized
INFO - 2023-03-08 07:04:42 --> URI Class Initialized
INFO - 2023-03-08 07:04:42 --> Router Class Initialized
INFO - 2023-03-08 07:04:42 --> Output Class Initialized
INFO - 2023-03-08 07:04:42 --> Security Class Initialized
DEBUG - 2023-03-08 07:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:04:42 --> Input Class Initialized
INFO - 2023-03-08 07:04:42 --> Language Class Initialized
INFO - 2023-03-08 07:04:42 --> Loader Class Initialized
INFO - 2023-03-08 07:04:42 --> Controller Class Initialized
DEBUG - 2023-03-08 07:04:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:04:42 --> Database Driver Class Initialized
INFO - 2023-03-08 07:04:42 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:04:42 --> Final output sent to browser
DEBUG - 2023-03-08 07:04:42 --> Total execution time: 0.0533
INFO - 2023-03-08 07:04:43 --> Config Class Initialized
INFO - 2023-03-08 07:04:43 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:04:43 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:04:43 --> Utf8 Class Initialized
INFO - 2023-03-08 07:04:43 --> URI Class Initialized
INFO - 2023-03-08 07:04:43 --> Router Class Initialized
INFO - 2023-03-08 07:04:43 --> Output Class Initialized
INFO - 2023-03-08 07:04:43 --> Security Class Initialized
DEBUG - 2023-03-08 07:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:04:43 --> Input Class Initialized
INFO - 2023-03-08 07:04:43 --> Language Class Initialized
INFO - 2023-03-08 07:04:43 --> Loader Class Initialized
INFO - 2023-03-08 07:04:43 --> Controller Class Initialized
DEBUG - 2023-03-08 07:04:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:04:43 --> Database Driver Class Initialized
INFO - 2023-03-08 07:04:43 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:04:43 --> Final output sent to browser
DEBUG - 2023-03-08 07:04:43 --> Total execution time: 0.0437
INFO - 2023-03-08 07:04:43 --> Config Class Initialized
INFO - 2023-03-08 07:04:43 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:04:43 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:04:43 --> Utf8 Class Initialized
INFO - 2023-03-08 07:04:43 --> URI Class Initialized
INFO - 2023-03-08 07:04:43 --> Router Class Initialized
INFO - 2023-03-08 07:04:43 --> Output Class Initialized
INFO - 2023-03-08 07:04:43 --> Security Class Initialized
DEBUG - 2023-03-08 07:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:04:43 --> Input Class Initialized
INFO - 2023-03-08 07:04:43 --> Language Class Initialized
INFO - 2023-03-08 07:04:43 --> Loader Class Initialized
INFO - 2023-03-08 07:04:43 --> Controller Class Initialized
DEBUG - 2023-03-08 07:04:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:04:43 --> Database Driver Class Initialized
INFO - 2023-03-08 07:04:43 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:04:43 --> Final output sent to browser
DEBUG - 2023-03-08 07:04:43 --> Total execution time: 0.0762
INFO - 2023-03-08 07:10:40 --> Config Class Initialized
INFO - 2023-03-08 07:10:40 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:10:40 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:10:40 --> Utf8 Class Initialized
INFO - 2023-03-08 07:10:40 --> URI Class Initialized
INFO - 2023-03-08 07:10:40 --> Router Class Initialized
INFO - 2023-03-08 07:10:40 --> Output Class Initialized
INFO - 2023-03-08 07:10:40 --> Security Class Initialized
DEBUG - 2023-03-08 07:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:10:40 --> Input Class Initialized
INFO - 2023-03-08 07:10:40 --> Language Class Initialized
INFO - 2023-03-08 07:10:40 --> Loader Class Initialized
INFO - 2023-03-08 07:10:40 --> Controller Class Initialized
DEBUG - 2023-03-08 07:10:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:10:40 --> Database Driver Class Initialized
INFO - 2023-03-08 07:10:40 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:10:40 --> Final output sent to browser
DEBUG - 2023-03-08 07:10:40 --> Total execution time: 0.0206
INFO - 2023-03-08 07:10:40 --> Config Class Initialized
INFO - 2023-03-08 07:10:40 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:10:40 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:10:40 --> Utf8 Class Initialized
INFO - 2023-03-08 07:10:40 --> URI Class Initialized
INFO - 2023-03-08 07:10:40 --> Router Class Initialized
INFO - 2023-03-08 07:10:40 --> Output Class Initialized
INFO - 2023-03-08 07:10:40 --> Security Class Initialized
DEBUG - 2023-03-08 07:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:10:40 --> Input Class Initialized
INFO - 2023-03-08 07:10:40 --> Language Class Initialized
INFO - 2023-03-08 07:10:40 --> Loader Class Initialized
INFO - 2023-03-08 07:10:40 --> Controller Class Initialized
DEBUG - 2023-03-08 07:10:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:10:40 --> Database Driver Class Initialized
INFO - 2023-03-08 07:10:40 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:10:40 --> Final output sent to browser
DEBUG - 2023-03-08 07:10:40 --> Total execution time: 0.0145
INFO - 2023-03-08 07:22:56 --> Config Class Initialized
INFO - 2023-03-08 07:22:56 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:22:56 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:22:56 --> Utf8 Class Initialized
INFO - 2023-03-08 07:22:56 --> URI Class Initialized
INFO - 2023-03-08 07:22:56 --> Router Class Initialized
INFO - 2023-03-08 07:22:56 --> Output Class Initialized
INFO - 2023-03-08 07:22:56 --> Security Class Initialized
DEBUG - 2023-03-08 07:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:22:56 --> Input Class Initialized
INFO - 2023-03-08 07:22:56 --> Language Class Initialized
INFO - 2023-03-08 07:22:56 --> Loader Class Initialized
INFO - 2023-03-08 07:22:56 --> Controller Class Initialized
DEBUG - 2023-03-08 07:22:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:22:56 --> Database Driver Class Initialized
INFO - 2023-03-08 07:22:56 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:22:56 --> Final output sent to browser
DEBUG - 2023-03-08 07:22:56 --> Total execution time: 0.0405
INFO - 2023-03-08 07:22:56 --> Config Class Initialized
INFO - 2023-03-08 07:22:56 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:22:56 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:22:56 --> Utf8 Class Initialized
INFO - 2023-03-08 07:22:56 --> URI Class Initialized
INFO - 2023-03-08 07:22:56 --> Router Class Initialized
INFO - 2023-03-08 07:22:56 --> Output Class Initialized
INFO - 2023-03-08 07:22:56 --> Security Class Initialized
DEBUG - 2023-03-08 07:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:22:56 --> Input Class Initialized
INFO - 2023-03-08 07:22:56 --> Language Class Initialized
INFO - 2023-03-08 07:22:56 --> Loader Class Initialized
INFO - 2023-03-08 07:22:56 --> Controller Class Initialized
DEBUG - 2023-03-08 07:22:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:22:56 --> Database Driver Class Initialized
INFO - 2023-03-08 07:22:56 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:22:56 --> Final output sent to browser
DEBUG - 2023-03-08 07:22:56 --> Total execution time: 0.0724
INFO - 2023-03-08 07:22:59 --> Config Class Initialized
INFO - 2023-03-08 07:22:59 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:22:59 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:22:59 --> Utf8 Class Initialized
INFO - 2023-03-08 07:22:59 --> URI Class Initialized
INFO - 2023-03-08 07:22:59 --> Router Class Initialized
INFO - 2023-03-08 07:22:59 --> Output Class Initialized
INFO - 2023-03-08 07:22:59 --> Security Class Initialized
DEBUG - 2023-03-08 07:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:22:59 --> Input Class Initialized
INFO - 2023-03-08 07:22:59 --> Language Class Initialized
INFO - 2023-03-08 07:22:59 --> Loader Class Initialized
INFO - 2023-03-08 07:22:59 --> Controller Class Initialized
DEBUG - 2023-03-08 07:22:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:22:59 --> Database Driver Class Initialized
INFO - 2023-03-08 07:22:59 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:22:59 --> Database Driver Class Initialized
INFO - 2023-03-08 07:22:59 --> Model "Login_model" initialized
INFO - 2023-03-08 07:22:59 --> Final output sent to browser
DEBUG - 2023-03-08 07:22:59 --> Total execution time: 0.1583
INFO - 2023-03-08 07:22:59 --> Config Class Initialized
INFO - 2023-03-08 07:22:59 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:22:59 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:22:59 --> Utf8 Class Initialized
INFO - 2023-03-08 07:22:59 --> URI Class Initialized
INFO - 2023-03-08 07:22:59 --> Router Class Initialized
INFO - 2023-03-08 07:22:59 --> Output Class Initialized
INFO - 2023-03-08 07:22:59 --> Security Class Initialized
DEBUG - 2023-03-08 07:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:22:59 --> Input Class Initialized
INFO - 2023-03-08 07:22:59 --> Language Class Initialized
INFO - 2023-03-08 07:22:59 --> Loader Class Initialized
INFO - 2023-03-08 07:22:59 --> Controller Class Initialized
DEBUG - 2023-03-08 07:22:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:22:59 --> Database Driver Class Initialized
INFO - 2023-03-08 07:22:59 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:22:59 --> Database Driver Class Initialized
INFO - 2023-03-08 07:22:59 --> Model "Login_model" initialized
INFO - 2023-03-08 07:22:59 --> Final output sent to browser
DEBUG - 2023-03-08 07:22:59 --> Total execution time: 0.0749
INFO - 2023-03-08 07:23:03 --> Config Class Initialized
INFO - 2023-03-08 07:23:03 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:23:03 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:23:03 --> Utf8 Class Initialized
INFO - 2023-03-08 07:23:03 --> URI Class Initialized
INFO - 2023-03-08 07:23:03 --> Router Class Initialized
INFO - 2023-03-08 07:23:03 --> Output Class Initialized
INFO - 2023-03-08 07:23:03 --> Security Class Initialized
DEBUG - 2023-03-08 07:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:23:03 --> Input Class Initialized
INFO - 2023-03-08 07:23:03 --> Language Class Initialized
INFO - 2023-03-08 07:23:03 --> Loader Class Initialized
INFO - 2023-03-08 07:23:03 --> Controller Class Initialized
DEBUG - 2023-03-08 07:23:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:23:03 --> Database Driver Class Initialized
INFO - 2023-03-08 07:23:03 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:23:03 --> Final output sent to browser
DEBUG - 2023-03-08 07:23:03 --> Total execution time: 0.0363
INFO - 2023-03-08 07:23:03 --> Config Class Initialized
INFO - 2023-03-08 07:23:03 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:23:03 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:23:03 --> Utf8 Class Initialized
INFO - 2023-03-08 07:23:03 --> URI Class Initialized
INFO - 2023-03-08 07:23:03 --> Router Class Initialized
INFO - 2023-03-08 07:23:03 --> Output Class Initialized
INFO - 2023-03-08 07:23:03 --> Security Class Initialized
DEBUG - 2023-03-08 07:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:23:03 --> Input Class Initialized
INFO - 2023-03-08 07:23:03 --> Language Class Initialized
INFO - 2023-03-08 07:23:03 --> Loader Class Initialized
INFO - 2023-03-08 07:23:03 --> Controller Class Initialized
DEBUG - 2023-03-08 07:23:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:23:03 --> Database Driver Class Initialized
INFO - 2023-03-08 07:23:03 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:23:03 --> Final output sent to browser
DEBUG - 2023-03-08 07:23:03 --> Total execution time: 0.0344
INFO - 2023-03-08 07:23:06 --> Config Class Initialized
INFO - 2023-03-08 07:23:06 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:23:06 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:23:06 --> Utf8 Class Initialized
INFO - 2023-03-08 07:23:06 --> URI Class Initialized
INFO - 2023-03-08 07:23:06 --> Router Class Initialized
INFO - 2023-03-08 07:23:06 --> Output Class Initialized
INFO - 2023-03-08 07:23:06 --> Security Class Initialized
DEBUG - 2023-03-08 07:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:23:06 --> Input Class Initialized
INFO - 2023-03-08 07:23:06 --> Language Class Initialized
INFO - 2023-03-08 07:23:06 --> Loader Class Initialized
INFO - 2023-03-08 07:23:06 --> Controller Class Initialized
DEBUG - 2023-03-08 07:23:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:23:06 --> Database Driver Class Initialized
INFO - 2023-03-08 07:23:06 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:23:06 --> Final output sent to browser
DEBUG - 2023-03-08 07:23:06 --> Total execution time: 0.0146
INFO - 2023-03-08 07:23:06 --> Config Class Initialized
INFO - 2023-03-08 07:23:06 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:23:06 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:23:06 --> Utf8 Class Initialized
INFO - 2023-03-08 07:23:06 --> URI Class Initialized
INFO - 2023-03-08 07:23:06 --> Router Class Initialized
INFO - 2023-03-08 07:23:06 --> Output Class Initialized
INFO - 2023-03-08 07:23:06 --> Security Class Initialized
DEBUG - 2023-03-08 07:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:23:06 --> Input Class Initialized
INFO - 2023-03-08 07:23:06 --> Language Class Initialized
INFO - 2023-03-08 07:23:06 --> Loader Class Initialized
INFO - 2023-03-08 07:23:06 --> Controller Class Initialized
DEBUG - 2023-03-08 07:23:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:23:06 --> Database Driver Class Initialized
INFO - 2023-03-08 07:23:06 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:23:06 --> Final output sent to browser
DEBUG - 2023-03-08 07:23:06 --> Total execution time: 0.0521
INFO - 2023-03-08 07:23:21 --> Config Class Initialized
INFO - 2023-03-08 07:23:21 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:23:21 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:23:21 --> Utf8 Class Initialized
INFO - 2023-03-08 07:23:21 --> URI Class Initialized
INFO - 2023-03-08 07:23:21 --> Router Class Initialized
INFO - 2023-03-08 07:23:21 --> Output Class Initialized
INFO - 2023-03-08 07:23:21 --> Security Class Initialized
DEBUG - 2023-03-08 07:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:23:21 --> Input Class Initialized
INFO - 2023-03-08 07:23:21 --> Language Class Initialized
INFO - 2023-03-08 07:23:21 --> Loader Class Initialized
INFO - 2023-03-08 07:23:21 --> Controller Class Initialized
DEBUG - 2023-03-08 07:23:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:23:21 --> Database Driver Class Initialized
INFO - 2023-03-08 07:23:21 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:23:21 --> Final output sent to browser
DEBUG - 2023-03-08 07:23:21 --> Total execution time: 0.0424
INFO - 2023-03-08 07:23:21 --> Config Class Initialized
INFO - 2023-03-08 07:23:21 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:23:21 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:23:21 --> Utf8 Class Initialized
INFO - 2023-03-08 07:23:21 --> URI Class Initialized
INFO - 2023-03-08 07:23:21 --> Router Class Initialized
INFO - 2023-03-08 07:23:21 --> Output Class Initialized
INFO - 2023-03-08 07:23:21 --> Security Class Initialized
DEBUG - 2023-03-08 07:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:23:21 --> Input Class Initialized
INFO - 2023-03-08 07:23:21 --> Language Class Initialized
INFO - 2023-03-08 07:23:21 --> Loader Class Initialized
INFO - 2023-03-08 07:23:21 --> Controller Class Initialized
DEBUG - 2023-03-08 07:23:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:23:21 --> Database Driver Class Initialized
INFO - 2023-03-08 07:23:21 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:23:21 --> Final output sent to browser
DEBUG - 2023-03-08 07:23:21 --> Total execution time: 0.0345
INFO - 2023-03-08 07:23:23 --> Config Class Initialized
INFO - 2023-03-08 07:23:23 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:23:23 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:23:23 --> Utf8 Class Initialized
INFO - 2023-03-08 07:23:23 --> URI Class Initialized
INFO - 2023-03-08 07:23:23 --> Router Class Initialized
INFO - 2023-03-08 07:23:23 --> Output Class Initialized
INFO - 2023-03-08 07:23:23 --> Security Class Initialized
DEBUG - 2023-03-08 07:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:23:23 --> Input Class Initialized
INFO - 2023-03-08 07:23:23 --> Language Class Initialized
INFO - 2023-03-08 07:23:23 --> Loader Class Initialized
INFO - 2023-03-08 07:23:23 --> Controller Class Initialized
DEBUG - 2023-03-08 07:23:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:23:23 --> Database Driver Class Initialized
INFO - 2023-03-08 07:23:23 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:23:23 --> Database Driver Class Initialized
INFO - 2023-03-08 07:23:23 --> Model "Login_model" initialized
INFO - 2023-03-08 07:23:23 --> Final output sent to browser
DEBUG - 2023-03-08 07:23:23 --> Total execution time: 0.0641
INFO - 2023-03-08 07:23:23 --> Config Class Initialized
INFO - 2023-03-08 07:23:23 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:23:23 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:23:23 --> Utf8 Class Initialized
INFO - 2023-03-08 07:23:23 --> URI Class Initialized
INFO - 2023-03-08 07:23:23 --> Router Class Initialized
INFO - 2023-03-08 07:23:23 --> Output Class Initialized
INFO - 2023-03-08 07:23:23 --> Security Class Initialized
DEBUG - 2023-03-08 07:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:23:23 --> Input Class Initialized
INFO - 2023-03-08 07:23:23 --> Language Class Initialized
INFO - 2023-03-08 07:23:23 --> Loader Class Initialized
INFO - 2023-03-08 07:23:23 --> Controller Class Initialized
DEBUG - 2023-03-08 07:23:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:23:23 --> Database Driver Class Initialized
INFO - 2023-03-08 07:23:23 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:23:23 --> Database Driver Class Initialized
INFO - 2023-03-08 07:23:23 --> Model "Login_model" initialized
INFO - 2023-03-08 07:23:23 --> Final output sent to browser
DEBUG - 2023-03-08 07:23:23 --> Total execution time: 0.0341
INFO - 2023-03-08 07:24:21 --> Config Class Initialized
INFO - 2023-03-08 07:24:21 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:24:21 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:24:21 --> Utf8 Class Initialized
INFO - 2023-03-08 07:24:21 --> URI Class Initialized
INFO - 2023-03-08 07:24:21 --> Router Class Initialized
INFO - 2023-03-08 07:24:21 --> Output Class Initialized
INFO - 2023-03-08 07:24:21 --> Security Class Initialized
DEBUG - 2023-03-08 07:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:24:21 --> Input Class Initialized
INFO - 2023-03-08 07:24:21 --> Language Class Initialized
INFO - 2023-03-08 07:24:21 --> Loader Class Initialized
INFO - 2023-03-08 07:24:21 --> Controller Class Initialized
DEBUG - 2023-03-08 07:24:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:24:21 --> Database Driver Class Initialized
INFO - 2023-03-08 07:24:21 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:24:21 --> Final output sent to browser
DEBUG - 2023-03-08 07:24:21 --> Total execution time: 0.0407
INFO - 2023-03-08 07:24:21 --> Config Class Initialized
INFO - 2023-03-08 07:24:21 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:24:21 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:24:21 --> Utf8 Class Initialized
INFO - 2023-03-08 07:24:21 --> URI Class Initialized
INFO - 2023-03-08 07:24:21 --> Router Class Initialized
INFO - 2023-03-08 07:24:21 --> Output Class Initialized
INFO - 2023-03-08 07:24:21 --> Security Class Initialized
DEBUG - 2023-03-08 07:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:24:21 --> Input Class Initialized
INFO - 2023-03-08 07:24:21 --> Language Class Initialized
INFO - 2023-03-08 07:24:21 --> Loader Class Initialized
INFO - 2023-03-08 07:24:21 --> Controller Class Initialized
DEBUG - 2023-03-08 07:24:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:24:21 --> Database Driver Class Initialized
INFO - 2023-03-08 07:24:21 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:24:21 --> Final output sent to browser
DEBUG - 2023-03-08 07:24:21 --> Total execution time: 0.0725
INFO - 2023-03-08 07:24:23 --> Config Class Initialized
INFO - 2023-03-08 07:24:23 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:24:23 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:24:23 --> Utf8 Class Initialized
INFO - 2023-03-08 07:24:23 --> URI Class Initialized
INFO - 2023-03-08 07:24:23 --> Router Class Initialized
INFO - 2023-03-08 07:24:23 --> Output Class Initialized
INFO - 2023-03-08 07:24:23 --> Security Class Initialized
DEBUG - 2023-03-08 07:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:24:23 --> Input Class Initialized
INFO - 2023-03-08 07:24:23 --> Language Class Initialized
INFO - 2023-03-08 07:24:23 --> Loader Class Initialized
INFO - 2023-03-08 07:24:23 --> Controller Class Initialized
DEBUG - 2023-03-08 07:24:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:24:23 --> Database Driver Class Initialized
INFO - 2023-03-08 07:24:23 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:24:23 --> Final output sent to browser
DEBUG - 2023-03-08 07:24:23 --> Total execution time: 0.0763
INFO - 2023-03-08 07:24:23 --> Config Class Initialized
INFO - 2023-03-08 07:24:23 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:24:23 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:24:23 --> Utf8 Class Initialized
INFO - 2023-03-08 07:24:23 --> URI Class Initialized
INFO - 2023-03-08 07:24:23 --> Router Class Initialized
INFO - 2023-03-08 07:24:23 --> Output Class Initialized
INFO - 2023-03-08 07:24:23 --> Security Class Initialized
DEBUG - 2023-03-08 07:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:24:23 --> Input Class Initialized
INFO - 2023-03-08 07:24:23 --> Language Class Initialized
INFO - 2023-03-08 07:24:23 --> Loader Class Initialized
INFO - 2023-03-08 07:24:23 --> Controller Class Initialized
DEBUG - 2023-03-08 07:24:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:24:23 --> Database Driver Class Initialized
INFO - 2023-03-08 07:24:23 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:24:23 --> Final output sent to browser
DEBUG - 2023-03-08 07:24:23 --> Total execution time: 0.0185
INFO - 2023-03-08 07:25:18 --> Config Class Initialized
INFO - 2023-03-08 07:25:18 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:25:18 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:25:18 --> Utf8 Class Initialized
INFO - 2023-03-08 07:25:18 --> URI Class Initialized
INFO - 2023-03-08 07:25:18 --> Router Class Initialized
INFO - 2023-03-08 07:25:18 --> Output Class Initialized
INFO - 2023-03-08 07:25:18 --> Security Class Initialized
DEBUG - 2023-03-08 07:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:25:18 --> Input Class Initialized
INFO - 2023-03-08 07:25:18 --> Language Class Initialized
INFO - 2023-03-08 07:25:18 --> Loader Class Initialized
INFO - 2023-03-08 07:25:18 --> Controller Class Initialized
DEBUG - 2023-03-08 07:25:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:25:18 --> Database Driver Class Initialized
INFO - 2023-03-08 07:25:18 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:25:18 --> Final output sent to browser
DEBUG - 2023-03-08 07:25:18 --> Total execution time: 0.0448
INFO - 2023-03-08 07:25:18 --> Config Class Initialized
INFO - 2023-03-08 07:25:18 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:25:18 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:25:18 --> Utf8 Class Initialized
INFO - 2023-03-08 07:25:18 --> URI Class Initialized
INFO - 2023-03-08 07:25:18 --> Router Class Initialized
INFO - 2023-03-08 07:25:18 --> Output Class Initialized
INFO - 2023-03-08 07:25:18 --> Security Class Initialized
DEBUG - 2023-03-08 07:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:25:18 --> Input Class Initialized
INFO - 2023-03-08 07:25:18 --> Language Class Initialized
INFO - 2023-03-08 07:25:18 --> Loader Class Initialized
INFO - 2023-03-08 07:25:18 --> Controller Class Initialized
DEBUG - 2023-03-08 07:25:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:25:18 --> Database Driver Class Initialized
INFO - 2023-03-08 07:25:18 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:25:18 --> Final output sent to browser
DEBUG - 2023-03-08 07:25:18 --> Total execution time: 0.0474
INFO - 2023-03-08 07:25:21 --> Config Class Initialized
INFO - 2023-03-08 07:25:21 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:25:21 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:25:21 --> Utf8 Class Initialized
INFO - 2023-03-08 07:25:21 --> URI Class Initialized
INFO - 2023-03-08 07:25:21 --> Router Class Initialized
INFO - 2023-03-08 07:25:21 --> Output Class Initialized
INFO - 2023-03-08 07:25:21 --> Security Class Initialized
DEBUG - 2023-03-08 07:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:25:21 --> Input Class Initialized
INFO - 2023-03-08 07:25:21 --> Language Class Initialized
INFO - 2023-03-08 07:25:21 --> Loader Class Initialized
INFO - 2023-03-08 07:25:21 --> Controller Class Initialized
DEBUG - 2023-03-08 07:25:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:25:21 --> Database Driver Class Initialized
INFO - 2023-03-08 07:25:21 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:25:21 --> Final output sent to browser
DEBUG - 2023-03-08 07:25:21 --> Total execution time: 0.0324
INFO - 2023-03-08 07:25:21 --> Config Class Initialized
INFO - 2023-03-08 07:25:21 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:25:21 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:25:21 --> Utf8 Class Initialized
INFO - 2023-03-08 07:25:21 --> URI Class Initialized
INFO - 2023-03-08 07:25:21 --> Router Class Initialized
INFO - 2023-03-08 07:25:21 --> Output Class Initialized
INFO - 2023-03-08 07:25:21 --> Security Class Initialized
DEBUG - 2023-03-08 07:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:25:21 --> Input Class Initialized
INFO - 2023-03-08 07:25:21 --> Language Class Initialized
INFO - 2023-03-08 07:25:21 --> Loader Class Initialized
INFO - 2023-03-08 07:25:21 --> Controller Class Initialized
DEBUG - 2023-03-08 07:25:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:25:21 --> Database Driver Class Initialized
INFO - 2023-03-08 07:25:21 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:25:21 --> Final output sent to browser
DEBUG - 2023-03-08 07:25:21 --> Total execution time: 0.0155
INFO - 2023-03-08 07:58:43 --> Config Class Initialized
INFO - 2023-03-08 07:58:43 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:58:43 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:58:43 --> Utf8 Class Initialized
INFO - 2023-03-08 07:58:43 --> URI Class Initialized
INFO - 2023-03-08 07:58:43 --> Router Class Initialized
INFO - 2023-03-08 07:58:43 --> Output Class Initialized
INFO - 2023-03-08 07:58:43 --> Security Class Initialized
DEBUG - 2023-03-08 07:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:58:43 --> Input Class Initialized
INFO - 2023-03-08 07:58:43 --> Language Class Initialized
INFO - 2023-03-08 07:58:43 --> Loader Class Initialized
INFO - 2023-03-08 07:58:43 --> Controller Class Initialized
DEBUG - 2023-03-08 07:58:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:58:44 --> Database Driver Class Initialized
INFO - 2023-03-08 07:58:44 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:58:44 --> Final output sent to browser
DEBUG - 2023-03-08 07:58:44 --> Total execution time: 0.1142
INFO - 2023-03-08 07:58:44 --> Config Class Initialized
INFO - 2023-03-08 07:58:44 --> Hooks Class Initialized
DEBUG - 2023-03-08 07:58:44 --> UTF-8 Support Enabled
INFO - 2023-03-08 07:58:44 --> Utf8 Class Initialized
INFO - 2023-03-08 07:58:44 --> URI Class Initialized
INFO - 2023-03-08 07:58:44 --> Router Class Initialized
INFO - 2023-03-08 07:58:44 --> Output Class Initialized
INFO - 2023-03-08 07:58:44 --> Security Class Initialized
DEBUG - 2023-03-08 07:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 07:58:44 --> Input Class Initialized
INFO - 2023-03-08 07:58:44 --> Language Class Initialized
INFO - 2023-03-08 07:58:44 --> Loader Class Initialized
INFO - 2023-03-08 07:58:44 --> Controller Class Initialized
DEBUG - 2023-03-08 07:58:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 07:58:44 --> Database Driver Class Initialized
INFO - 2023-03-08 07:58:44 --> Model "Cluster_model" initialized
INFO - 2023-03-08 07:58:44 --> Final output sent to browser
DEBUG - 2023-03-08 07:58:44 --> Total execution time: 0.0399
INFO - 2023-03-08 08:03:47 --> Config Class Initialized
INFO - 2023-03-08 08:03:47 --> Hooks Class Initialized
DEBUG - 2023-03-08 08:03:47 --> UTF-8 Support Enabled
INFO - 2023-03-08 08:03:47 --> Utf8 Class Initialized
INFO - 2023-03-08 08:03:47 --> URI Class Initialized
INFO - 2023-03-08 08:03:47 --> Router Class Initialized
INFO - 2023-03-08 08:03:47 --> Output Class Initialized
INFO - 2023-03-08 08:03:47 --> Security Class Initialized
DEBUG - 2023-03-08 08:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 08:03:47 --> Input Class Initialized
INFO - 2023-03-08 08:03:47 --> Language Class Initialized
INFO - 2023-03-08 08:03:47 --> Loader Class Initialized
INFO - 2023-03-08 08:03:47 --> Controller Class Initialized
DEBUG - 2023-03-08 08:03:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 08:03:47 --> Database Driver Class Initialized
INFO - 2023-03-08 08:03:47 --> Model "Cluster_model" initialized
INFO - 2023-03-08 08:03:47 --> Final output sent to browser
DEBUG - 2023-03-08 08:03:48 --> Total execution time: 0.0706
INFO - 2023-03-08 08:03:48 --> Config Class Initialized
INFO - 2023-03-08 08:03:48 --> Hooks Class Initialized
DEBUG - 2023-03-08 08:03:48 --> UTF-8 Support Enabled
INFO - 2023-03-08 08:03:48 --> Utf8 Class Initialized
INFO - 2023-03-08 08:03:48 --> URI Class Initialized
INFO - 2023-03-08 08:03:48 --> Router Class Initialized
INFO - 2023-03-08 08:03:48 --> Output Class Initialized
INFO - 2023-03-08 08:03:48 --> Security Class Initialized
DEBUG - 2023-03-08 08:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 08:03:48 --> Input Class Initialized
INFO - 2023-03-08 08:03:48 --> Language Class Initialized
INFO - 2023-03-08 08:03:48 --> Loader Class Initialized
INFO - 2023-03-08 08:03:48 --> Controller Class Initialized
DEBUG - 2023-03-08 08:03:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 08:03:48 --> Database Driver Class Initialized
INFO - 2023-03-08 08:03:48 --> Model "Cluster_model" initialized
INFO - 2023-03-08 08:03:48 --> Final output sent to browser
DEBUG - 2023-03-08 08:03:48 --> Total execution time: 0.0218
INFO - 2023-03-08 08:03:51 --> Config Class Initialized
INFO - 2023-03-08 08:03:51 --> Hooks Class Initialized
DEBUG - 2023-03-08 08:03:51 --> UTF-8 Support Enabled
INFO - 2023-03-08 08:03:51 --> Utf8 Class Initialized
INFO - 2023-03-08 08:03:51 --> URI Class Initialized
INFO - 2023-03-08 08:03:51 --> Router Class Initialized
INFO - 2023-03-08 08:03:51 --> Output Class Initialized
INFO - 2023-03-08 08:03:51 --> Security Class Initialized
DEBUG - 2023-03-08 08:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 08:03:51 --> Input Class Initialized
INFO - 2023-03-08 08:03:51 --> Language Class Initialized
INFO - 2023-03-08 08:03:51 --> Loader Class Initialized
INFO - 2023-03-08 08:03:51 --> Controller Class Initialized
DEBUG - 2023-03-08 08:03:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 08:03:51 --> Database Driver Class Initialized
INFO - 2023-03-08 08:03:51 --> Model "Cluster_model" initialized
INFO - 2023-03-08 08:03:51 --> Database Driver Class Initialized
INFO - 2023-03-08 08:03:51 --> Model "Login_model" initialized
INFO - 2023-03-08 08:03:51 --> Final output sent to browser
DEBUG - 2023-03-08 08:03:51 --> Total execution time: 0.0440
INFO - 2023-03-08 08:03:51 --> Config Class Initialized
INFO - 2023-03-08 08:03:51 --> Hooks Class Initialized
DEBUG - 2023-03-08 08:03:51 --> UTF-8 Support Enabled
INFO - 2023-03-08 08:03:51 --> Utf8 Class Initialized
INFO - 2023-03-08 08:03:51 --> URI Class Initialized
INFO - 2023-03-08 08:03:51 --> Router Class Initialized
INFO - 2023-03-08 08:03:51 --> Output Class Initialized
INFO - 2023-03-08 08:03:51 --> Security Class Initialized
DEBUG - 2023-03-08 08:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 08:03:51 --> Input Class Initialized
INFO - 2023-03-08 08:03:51 --> Language Class Initialized
INFO - 2023-03-08 08:03:51 --> Loader Class Initialized
INFO - 2023-03-08 08:03:51 --> Controller Class Initialized
DEBUG - 2023-03-08 08:03:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 08:03:51 --> Database Driver Class Initialized
INFO - 2023-03-08 08:03:51 --> Model "Cluster_model" initialized
INFO - 2023-03-08 08:03:51 --> Database Driver Class Initialized
INFO - 2023-03-08 08:03:51 --> Model "Login_model" initialized
INFO - 2023-03-08 08:03:51 --> Final output sent to browser
DEBUG - 2023-03-08 08:03:51 --> Total execution time: 0.0857
INFO - 2023-03-08 10:36:06 --> Config Class Initialized
INFO - 2023-03-08 10:36:06 --> Hooks Class Initialized
DEBUG - 2023-03-08 10:36:06 --> UTF-8 Support Enabled
INFO - 2023-03-08 10:36:06 --> Utf8 Class Initialized
INFO - 2023-03-08 10:36:06 --> URI Class Initialized
INFO - 2023-03-08 10:36:06 --> Router Class Initialized
INFO - 2023-03-08 10:36:06 --> Output Class Initialized
INFO - 2023-03-08 10:36:06 --> Security Class Initialized
DEBUG - 2023-03-08 10:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 10:36:06 --> Input Class Initialized
INFO - 2023-03-08 10:36:06 --> Language Class Initialized
INFO - 2023-03-08 10:36:06 --> Loader Class Initialized
INFO - 2023-03-08 10:36:06 --> Controller Class Initialized
DEBUG - 2023-03-08 10:36:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 10:36:06 --> Database Driver Class Initialized
INFO - 2023-03-08 10:36:06 --> Model "Cluster_model" initialized
INFO - 2023-03-08 10:36:06 --> Final output sent to browser
DEBUG - 2023-03-08 10:36:06 --> Total execution time: 0.0443
INFO - 2023-03-08 10:36:06 --> Config Class Initialized
INFO - 2023-03-08 10:36:06 --> Hooks Class Initialized
DEBUG - 2023-03-08 10:36:06 --> UTF-8 Support Enabled
INFO - 2023-03-08 10:36:06 --> Utf8 Class Initialized
INFO - 2023-03-08 10:36:06 --> URI Class Initialized
INFO - 2023-03-08 10:36:06 --> Router Class Initialized
INFO - 2023-03-08 10:36:06 --> Output Class Initialized
INFO - 2023-03-08 10:36:06 --> Security Class Initialized
DEBUG - 2023-03-08 10:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-08 10:36:06 --> Input Class Initialized
INFO - 2023-03-08 10:36:06 --> Language Class Initialized
INFO - 2023-03-08 10:36:06 --> Loader Class Initialized
INFO - 2023-03-08 10:36:06 --> Controller Class Initialized
DEBUG - 2023-03-08 10:36:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-08 10:36:06 --> Database Driver Class Initialized
INFO - 2023-03-08 10:36:06 --> Model "Cluster_model" initialized
INFO - 2023-03-08 10:36:06 --> Final output sent to browser
DEBUG - 2023-03-08 10:36:06 --> Total execution time: 0.0371
