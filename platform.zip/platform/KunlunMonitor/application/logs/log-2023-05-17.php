<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-17 02:12:28 --> Config Class Initialized
INFO - 2023-05-17 02:12:28 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:28 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:28 --> URI Class Initialized
INFO - 2023-05-17 02:12:28 --> Router Class Initialized
INFO - 2023-05-17 02:12:28 --> Output Class Initialized
INFO - 2023-05-17 02:12:28 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:28 --> Input Class Initialized
INFO - 2023-05-17 02:12:28 --> Language Class Initialized
INFO - 2023-05-17 02:12:28 --> Loader Class Initialized
INFO - 2023-05-17 02:12:29 --> Controller Class Initialized
INFO - 2023-05-17 02:12:29 --> Helper loaded: form_helper
INFO - 2023-05-17 02:12:29 --> Helper loaded: url_helper
DEBUG - 2023-05-17 02:12:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:29 --> Model "Change_model" initialized
INFO - 2023-05-17 02:12:29 --> Model "Grafana_model" initialized
INFO - 2023-05-17 02:12:29 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:29 --> Total execution time: 0.0805
INFO - 2023-05-17 02:12:29 --> Config Class Initialized
INFO - 2023-05-17 02:12:29 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:29 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:29 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:29 --> URI Class Initialized
INFO - 2023-05-17 02:12:29 --> Router Class Initialized
INFO - 2023-05-17 02:12:29 --> Output Class Initialized
INFO - 2023-05-17 02:12:29 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:29 --> Input Class Initialized
INFO - 2023-05-17 02:12:29 --> Language Class Initialized
INFO - 2023-05-17 02:12:29 --> Loader Class Initialized
INFO - 2023-05-17 02:12:29 --> Controller Class Initialized
INFO - 2023-05-17 02:12:29 --> Helper loaded: form_helper
INFO - 2023-05-17 02:12:29 --> Helper loaded: url_helper
DEBUG - 2023-05-17 02:12:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:29 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:29 --> Total execution time: 0.0445
INFO - 2023-05-17 02:12:29 --> Config Class Initialized
INFO - 2023-05-17 02:12:29 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:29 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:29 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:29 --> URI Class Initialized
INFO - 2023-05-17 02:12:29 --> Router Class Initialized
INFO - 2023-05-17 02:12:29 --> Output Class Initialized
INFO - 2023-05-17 02:12:29 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:29 --> Input Class Initialized
INFO - 2023-05-17 02:12:29 --> Language Class Initialized
INFO - 2023-05-17 02:12:29 --> Loader Class Initialized
INFO - 2023-05-17 02:12:29 --> Controller Class Initialized
INFO - 2023-05-17 02:12:29 --> Helper loaded: form_helper
INFO - 2023-05-17 02:12:29 --> Helper loaded: url_helper
DEBUG - 2023-05-17 02:12:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:29 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:29 --> Model "Login_model" initialized
INFO - 2023-05-17 02:12:29 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:29 --> Total execution time: 0.0362
INFO - 2023-05-17 02:12:29 --> Config Class Initialized
INFO - 2023-05-17 02:12:29 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:29 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:29 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:29 --> URI Class Initialized
INFO - 2023-05-17 02:12:29 --> Router Class Initialized
INFO - 2023-05-17 02:12:29 --> Output Class Initialized
INFO - 2023-05-17 02:12:29 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:29 --> Input Class Initialized
INFO - 2023-05-17 02:12:29 --> Language Class Initialized
INFO - 2023-05-17 02:12:29 --> Loader Class Initialized
INFO - 2023-05-17 02:12:29 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:29 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:29 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:29 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:29 --> Total execution time: 0.0418
INFO - 2023-05-17 02:12:29 --> Config Class Initialized
INFO - 2023-05-17 02:12:29 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:29 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:29 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:29 --> URI Class Initialized
INFO - 2023-05-17 02:12:29 --> Router Class Initialized
INFO - 2023-05-17 02:12:29 --> Output Class Initialized
INFO - 2023-05-17 02:12:29 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:29 --> Input Class Initialized
INFO - 2023-05-17 02:12:29 --> Language Class Initialized
INFO - 2023-05-17 02:12:29 --> Loader Class Initialized
INFO - 2023-05-17 02:12:29 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:29 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:29 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:29 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:29 --> Total execution time: 0.0190
INFO - 2023-05-17 02:12:29 --> Config Class Initialized
INFO - 2023-05-17 02:12:29 --> Config Class Initialized
INFO - 2023-05-17 02:12:29 --> Hooks Class Initialized
INFO - 2023-05-17 02:12:29 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:29 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 02:12:29 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:29 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:29 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:29 --> URI Class Initialized
INFO - 2023-05-17 02:12:29 --> URI Class Initialized
INFO - 2023-05-17 02:12:29 --> Router Class Initialized
INFO - 2023-05-17 02:12:29 --> Router Class Initialized
INFO - 2023-05-17 02:12:29 --> Output Class Initialized
INFO - 2023-05-17 02:12:29 --> Output Class Initialized
INFO - 2023-05-17 02:12:29 --> Security Class Initialized
INFO - 2023-05-17 02:12:29 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 02:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:29 --> Input Class Initialized
INFO - 2023-05-17 02:12:29 --> Input Class Initialized
INFO - 2023-05-17 02:12:29 --> Language Class Initialized
INFO - 2023-05-17 02:12:29 --> Language Class Initialized
INFO - 2023-05-17 02:12:29 --> Loader Class Initialized
INFO - 2023-05-17 02:12:29 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:29 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:29 --> Loader Class Initialized
INFO - 2023-05-17 02:12:29 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:29 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:29 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:29 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:29 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:29 --> Total execution time: 0.0193
INFO - 2023-05-17 02:12:29 --> Config Class Initialized
INFO - 2023-05-17 02:12:29 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:29 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:29 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:29 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:29 --> URI Class Initialized
INFO - 2023-05-17 02:12:29 --> Router Class Initialized
INFO - 2023-05-17 02:12:29 --> Output Class Initialized
INFO - 2023-05-17 02:12:29 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:29 --> Input Class Initialized
INFO - 2023-05-17 02:12:29 --> Language Class Initialized
INFO - 2023-05-17 02:12:29 --> Loader Class Initialized
INFO - 2023-05-17 02:12:29 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:29 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:29 --> Model "Login_model" initialized
INFO - 2023-05-17 02:12:29 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:29 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:29 --> Total execution time: 0.0556
INFO - 2023-05-17 02:12:29 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:29 --> Total execution time: 0.1382
INFO - 2023-05-17 02:12:29 --> Config Class Initialized
INFO - 2023-05-17 02:12:29 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:29 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:29 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:29 --> URI Class Initialized
INFO - 2023-05-17 02:12:29 --> Router Class Initialized
INFO - 2023-05-17 02:12:29 --> Output Class Initialized
INFO - 2023-05-17 02:12:29 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:29 --> Input Class Initialized
INFO - 2023-05-17 02:12:29 --> Language Class Initialized
INFO - 2023-05-17 02:12:29 --> Loader Class Initialized
INFO - 2023-05-17 02:12:29 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:29 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:29 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:29 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:29 --> Model "Login_model" initialized
INFO - 2023-05-17 02:12:29 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:29 --> Total execution time: 0.1526
INFO - 2023-05-17 02:12:35 --> Config Class Initialized
INFO - 2023-05-17 02:12:35 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:35 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:35 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:35 --> URI Class Initialized
INFO - 2023-05-17 02:12:35 --> Router Class Initialized
INFO - 2023-05-17 02:12:35 --> Output Class Initialized
INFO - 2023-05-17 02:12:35 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:35 --> Input Class Initialized
INFO - 2023-05-17 02:12:35 --> Language Class Initialized
INFO - 2023-05-17 02:12:35 --> Loader Class Initialized
INFO - 2023-05-17 02:12:35 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:35 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:35 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:35 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:35 --> Total execution time: 0.0121
INFO - 2023-05-17 02:12:35 --> Config Class Initialized
INFO - 2023-05-17 02:12:35 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:35 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:35 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:35 --> URI Class Initialized
INFO - 2023-05-17 02:12:35 --> Router Class Initialized
INFO - 2023-05-17 02:12:35 --> Output Class Initialized
INFO - 2023-05-17 02:12:35 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:35 --> Input Class Initialized
INFO - 2023-05-17 02:12:35 --> Language Class Initialized
INFO - 2023-05-17 02:12:35 --> Loader Class Initialized
INFO - 2023-05-17 02:12:35 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:35 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:35 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:35 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:35 --> Total execution time: 0.0181
INFO - 2023-05-17 02:12:36 --> Config Class Initialized
INFO - 2023-05-17 02:12:36 --> Config Class Initialized
INFO - 2023-05-17 02:12:36 --> Config Class Initialized
INFO - 2023-05-17 02:12:36 --> Hooks Class Initialized
INFO - 2023-05-17 02:12:36 --> Hooks Class Initialized
INFO - 2023-05-17 02:12:36 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:36 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 02:12:36 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 02:12:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:36 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:36 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:36 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:36 --> URI Class Initialized
INFO - 2023-05-17 02:12:36 --> URI Class Initialized
INFO - 2023-05-17 02:12:36 --> URI Class Initialized
INFO - 2023-05-17 02:12:36 --> Router Class Initialized
INFO - 2023-05-17 02:12:36 --> Router Class Initialized
INFO - 2023-05-17 02:12:36 --> Router Class Initialized
INFO - 2023-05-17 02:12:36 --> Output Class Initialized
INFO - 2023-05-17 02:12:36 --> Output Class Initialized
INFO - 2023-05-17 02:12:36 --> Output Class Initialized
INFO - 2023-05-17 02:12:36 --> Security Class Initialized
INFO - 2023-05-17 02:12:36 --> Security Class Initialized
INFO - 2023-05-17 02:12:36 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 02:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:36 --> Input Class Initialized
INFO - 2023-05-17 02:12:36 --> Input Class Initialized
DEBUG - 2023-05-17 02:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:36 --> Language Class Initialized
INFO - 2023-05-17 02:12:36 --> Input Class Initialized
INFO - 2023-05-17 02:12:36 --> Language Class Initialized
INFO - 2023-05-17 02:12:36 --> Language Class Initialized
INFO - 2023-05-17 02:12:36 --> Loader Class Initialized
INFO - 2023-05-17 02:12:36 --> Loader Class Initialized
INFO - 2023-05-17 02:12:36 --> Controller Class Initialized
INFO - 2023-05-17 02:12:36 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 02:12:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:36 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:36 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:36 --> Loader Class Initialized
INFO - 2023-05-17 02:12:36 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:36 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:36 --> Final output sent to browser
INFO - 2023-05-17 02:12:36 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:36 --> Total execution time: 0.0190
DEBUG - 2023-05-17 02:12:36 --> Total execution time: 0.0190
INFO - 2023-05-17 02:12:36 --> Config Class Initialized
INFO - 2023-05-17 02:12:36 --> Config Class Initialized
INFO - 2023-05-17 02:12:36 --> Hooks Class Initialized
INFO - 2023-05-17 02:12:36 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:36 --> Total execution time: 0.0238
INFO - 2023-05-17 02:12:36 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:36 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 02:12:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:36 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:36 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:36 --> URI Class Initialized
INFO - 2023-05-17 02:12:36 --> URI Class Initialized
INFO - 2023-05-17 02:12:36 --> Router Class Initialized
INFO - 2023-05-17 02:12:36 --> Router Class Initialized
INFO - 2023-05-17 02:12:36 --> Output Class Initialized
INFO - 2023-05-17 02:12:36 --> Output Class Initialized
INFO - 2023-05-17 02:12:36 --> Security Class Initialized
INFO - 2023-05-17 02:12:36 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:36 --> Input Class Initialized
DEBUG - 2023-05-17 02:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:36 --> Language Class Initialized
INFO - 2023-05-17 02:12:36 --> Input Class Initialized
INFO - 2023-05-17 02:12:36 --> Language Class Initialized
INFO - 2023-05-17 02:12:36 --> Loader Class Initialized
INFO - 2023-05-17 02:12:36 --> Controller Class Initialized
INFO - 2023-05-17 02:12:36 --> Loader Class Initialized
DEBUG - 2023-05-17 02:12:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:36 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:36 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:36 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:36 --> Final output sent to browser
INFO - 2023-05-17 02:12:36 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:36 --> Total execution time: 0.0620
DEBUG - 2023-05-17 02:12:36 --> Total execution time: 0.0620
INFO - 2023-05-17 02:12:36 --> Config Class Initialized
INFO - 2023-05-17 02:12:36 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:36 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:36 --> URI Class Initialized
INFO - 2023-05-17 02:12:36 --> Router Class Initialized
INFO - 2023-05-17 02:12:36 --> Output Class Initialized
INFO - 2023-05-17 02:12:36 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:36 --> Input Class Initialized
INFO - 2023-05-17 02:12:36 --> Language Class Initialized
INFO - 2023-05-17 02:12:36 --> Loader Class Initialized
INFO - 2023-05-17 02:12:36 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:36 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:36 --> Config Class Initialized
INFO - 2023-05-17 02:12:36 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:36 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:36 --> URI Class Initialized
INFO - 2023-05-17 02:12:36 --> Router Class Initialized
INFO - 2023-05-17 02:12:36 --> Output Class Initialized
INFO - 2023-05-17 02:12:36 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:36 --> Input Class Initialized
INFO - 2023-05-17 02:12:36 --> Language Class Initialized
INFO - 2023-05-17 02:12:36 --> Loader Class Initialized
INFO - 2023-05-17 02:12:36 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:36 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:40 --> Config Class Initialized
INFO - 2023-05-17 02:12:40 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:40 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:40 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:40 --> URI Class Initialized
INFO - 2023-05-17 02:12:40 --> Router Class Initialized
INFO - 2023-05-17 02:12:40 --> Output Class Initialized
INFO - 2023-05-17 02:12:40 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:40 --> Input Class Initialized
INFO - 2023-05-17 02:12:40 --> Language Class Initialized
INFO - 2023-05-17 02:12:40 --> Loader Class Initialized
INFO - 2023-05-17 02:12:40 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:40 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:40 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:40 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:40 --> Total execution time: 0.0190
INFO - 2023-05-17 02:12:41 --> Config Class Initialized
INFO - 2023-05-17 02:12:41 --> Config Class Initialized
INFO - 2023-05-17 02:12:41 --> Config Class Initialized
INFO - 2023-05-17 02:12:41 --> Hooks Class Initialized
INFO - 2023-05-17 02:12:41 --> Hooks Class Initialized
INFO - 2023-05-17 02:12:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 02:12:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 02:12:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:41 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:41 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:41 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:41 --> URI Class Initialized
INFO - 2023-05-17 02:12:41 --> URI Class Initialized
INFO - 2023-05-17 02:12:41 --> URI Class Initialized
INFO - 2023-05-17 02:12:41 --> Router Class Initialized
INFO - 2023-05-17 02:12:41 --> Router Class Initialized
INFO - 2023-05-17 02:12:41 --> Router Class Initialized
INFO - 2023-05-17 02:12:41 --> Output Class Initialized
INFO - 2023-05-17 02:12:41 --> Output Class Initialized
INFO - 2023-05-17 02:12:41 --> Output Class Initialized
INFO - 2023-05-17 02:12:41 --> Security Class Initialized
INFO - 2023-05-17 02:12:41 --> Security Class Initialized
INFO - 2023-05-17 02:12:41 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 02:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 02:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:41 --> Input Class Initialized
INFO - 2023-05-17 02:12:41 --> Input Class Initialized
INFO - 2023-05-17 02:12:41 --> Input Class Initialized
INFO - 2023-05-17 02:12:41 --> Language Class Initialized
INFO - 2023-05-17 02:12:41 --> Language Class Initialized
INFO - 2023-05-17 02:12:41 --> Language Class Initialized
INFO - 2023-05-17 02:12:41 --> Loader Class Initialized
INFO - 2023-05-17 02:12:41 --> Loader Class Initialized
INFO - 2023-05-17 02:12:41 --> Loader Class Initialized
INFO - 2023-05-17 02:12:41 --> Controller Class Initialized
INFO - 2023-05-17 02:12:41 --> Controller Class Initialized
INFO - 2023-05-17 02:12:41 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 02:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 02:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:41 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:41 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:41 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:41 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:41 --> Total execution time: 0.0155
INFO - 2023-05-17 02:12:41 --> Config Class Initialized
INFO - 2023-05-17 02:12:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:41 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:41 --> URI Class Initialized
INFO - 2023-05-17 02:12:41 --> Router Class Initialized
INFO - 2023-05-17 02:12:41 --> Output Class Initialized
INFO - 2023-05-17 02:12:41 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:41 --> Final output sent to browser
INFO - 2023-05-17 02:12:41 --> Final output sent to browser
INFO - 2023-05-17 02:12:41 --> Input Class Initialized
DEBUG - 2023-05-17 02:12:41 --> Total execution time: 0.0192
INFO - 2023-05-17 02:12:41 --> Language Class Initialized
DEBUG - 2023-05-17 02:12:41 --> Total execution time: 0.0192
INFO - 2023-05-17 02:12:41 --> Loader Class Initialized
INFO - 2023-05-17 02:12:41 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:41 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:41 --> Config Class Initialized
INFO - 2023-05-17 02:12:41 --> Config Class Initialized
INFO - 2023-05-17 02:12:41 --> Hooks Class Initialized
INFO - 2023-05-17 02:12:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:41 --> Utf8 Class Initialized
DEBUG - 2023-05-17 02:12:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:41 --> URI Class Initialized
INFO - 2023-05-17 02:12:41 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:41 --> Router Class Initialized
INFO - 2023-05-17 02:12:41 --> URI Class Initialized
INFO - 2023-05-17 02:12:41 --> Output Class Initialized
INFO - 2023-05-17 02:12:41 --> Router Class Initialized
INFO - 2023-05-17 02:12:41 --> Security Class Initialized
INFO - 2023-05-17 02:12:41 --> Output Class Initialized
DEBUG - 2023-05-17 02:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:41 --> Security Class Initialized
INFO - 2023-05-17 02:12:41 --> Input Class Initialized
DEBUG - 2023-05-17 02:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:41 --> Language Class Initialized
INFO - 2023-05-17 02:12:41 --> Input Class Initialized
INFO - 2023-05-17 02:12:41 --> Language Class Initialized
INFO - 2023-05-17 02:12:41 --> Loader Class Initialized
INFO - 2023-05-17 02:12:41 --> Loader Class Initialized
INFO - 2023-05-17 02:12:41 --> Controller Class Initialized
INFO - 2023-05-17 02:12:41 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 02:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:41 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:41 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:41 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:41 --> Total execution time: 0.0543
INFO - 2023-05-17 02:12:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:41 --> Final output sent to browser
INFO - 2023-05-17 02:12:41 --> Final output sent to browser
DEBUG - 2023-05-17 02:12:41 --> Total execution time: 0.0558
DEBUG - 2023-05-17 02:12:41 --> Total execution time: 0.0558
INFO - 2023-05-17 02:12:41 --> Config Class Initialized
INFO - 2023-05-17 02:12:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:41 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:41 --> URI Class Initialized
INFO - 2023-05-17 02:12:41 --> Router Class Initialized
INFO - 2023-05-17 02:12:41 --> Output Class Initialized
INFO - 2023-05-17 02:12:41 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:41 --> Input Class Initialized
INFO - 2023-05-17 02:12:41 --> Language Class Initialized
INFO - 2023-05-17 02:12:41 --> Loader Class Initialized
INFO - 2023-05-17 02:12:41 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:41 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:12:41 --> Config Class Initialized
INFO - 2023-05-17 02:12:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:12:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:12:41 --> Utf8 Class Initialized
INFO - 2023-05-17 02:12:41 --> URI Class Initialized
INFO - 2023-05-17 02:12:41 --> Router Class Initialized
INFO - 2023-05-17 02:12:41 --> Output Class Initialized
INFO - 2023-05-17 02:12:41 --> Security Class Initialized
DEBUG - 2023-05-17 02:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:12:41 --> Input Class Initialized
INFO - 2023-05-17 02:12:41 --> Language Class Initialized
INFO - 2023-05-17 02:12:41 --> Loader Class Initialized
INFO - 2023-05-17 02:12:41 --> Controller Class Initialized
DEBUG - 2023-05-17 02:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:12:41 --> Database Driver Class Initialized
INFO - 2023-05-17 02:12:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:32:07 --> Config Class Initialized
INFO - 2023-05-17 02:32:07 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:32:07 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:32:07 --> Utf8 Class Initialized
INFO - 2023-05-17 02:32:07 --> URI Class Initialized
INFO - 2023-05-17 02:32:07 --> Router Class Initialized
INFO - 2023-05-17 02:32:07 --> Output Class Initialized
INFO - 2023-05-17 02:32:07 --> Security Class Initialized
DEBUG - 2023-05-17 02:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:32:07 --> Input Class Initialized
INFO - 2023-05-17 02:32:07 --> Language Class Initialized
INFO - 2023-05-17 02:32:07 --> Loader Class Initialized
INFO - 2023-05-17 02:32:07 --> Controller Class Initialized
DEBUG - 2023-05-17 02:32:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:32:07 --> Database Driver Class Initialized
INFO - 2023-05-17 02:32:07 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:32:07 --> Final output sent to browser
DEBUG - 2023-05-17 02:32:07 --> Total execution time: 0.0201
INFO - 2023-05-17 02:32:07 --> Config Class Initialized
INFO - 2023-05-17 02:32:07 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:32:07 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:32:07 --> Utf8 Class Initialized
INFO - 2023-05-17 02:32:07 --> URI Class Initialized
INFO - 2023-05-17 02:32:07 --> Router Class Initialized
INFO - 2023-05-17 02:32:07 --> Output Class Initialized
INFO - 2023-05-17 02:32:07 --> Security Class Initialized
DEBUG - 2023-05-17 02:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:32:07 --> Input Class Initialized
INFO - 2023-05-17 02:32:07 --> Language Class Initialized
INFO - 2023-05-17 02:32:07 --> Loader Class Initialized
INFO - 2023-05-17 02:32:07 --> Controller Class Initialized
DEBUG - 2023-05-17 02:32:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:32:07 --> Database Driver Class Initialized
INFO - 2023-05-17 02:32:07 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:32:07 --> Final output sent to browser
DEBUG - 2023-05-17 02:32:07 --> Total execution time: 0.0226
INFO - 2023-05-17 02:32:08 --> Config Class Initialized
INFO - 2023-05-17 02:32:08 --> Config Class Initialized
INFO - 2023-05-17 02:32:08 --> Config Class Initialized
INFO - 2023-05-17 02:32:08 --> Hooks Class Initialized
INFO - 2023-05-17 02:32:08 --> Hooks Class Initialized
INFO - 2023-05-17 02:32:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 02:32:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:32:08 --> Utf8 Class Initialized
DEBUG - 2023-05-17 02:32:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:32:08 --> Utf8 Class Initialized
INFO - 2023-05-17 02:32:08 --> Utf8 Class Initialized
INFO - 2023-05-17 02:32:08 --> URI Class Initialized
INFO - 2023-05-17 02:32:08 --> URI Class Initialized
INFO - 2023-05-17 02:32:08 --> URI Class Initialized
INFO - 2023-05-17 02:32:08 --> Router Class Initialized
INFO - 2023-05-17 02:32:08 --> Router Class Initialized
INFO - 2023-05-17 02:32:08 --> Router Class Initialized
INFO - 2023-05-17 02:32:08 --> Output Class Initialized
INFO - 2023-05-17 02:32:08 --> Output Class Initialized
INFO - 2023-05-17 02:32:08 --> Output Class Initialized
INFO - 2023-05-17 02:32:08 --> Security Class Initialized
INFO - 2023-05-17 02:32:08 --> Security Class Initialized
INFO - 2023-05-17 02:32:08 --> Security Class Initialized
DEBUG - 2023-05-17 02:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 02:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:32:08 --> Input Class Initialized
DEBUG - 2023-05-17 02:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:32:08 --> Language Class Initialized
INFO - 2023-05-17 02:32:08 --> Input Class Initialized
INFO - 2023-05-17 02:32:08 --> Input Class Initialized
INFO - 2023-05-17 02:32:08 --> Language Class Initialized
INFO - 2023-05-17 02:32:08 --> Loader Class Initialized
INFO - 2023-05-17 02:32:08 --> Language Class Initialized
INFO - 2023-05-17 02:32:08 --> Controller Class Initialized
INFO - 2023-05-17 02:32:08 --> Loader Class Initialized
DEBUG - 2023-05-17 02:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:32:08 --> Loader Class Initialized
INFO - 2023-05-17 02:32:08 --> Controller Class Initialized
INFO - 2023-05-17 02:32:08 --> Controller Class Initialized
INFO - 2023-05-17 02:32:08 --> Database Driver Class Initialized
DEBUG - 2023-05-17 02:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 02:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:32:08 --> Database Driver Class Initialized
INFO - 2023-05-17 02:32:08 --> Database Driver Class Initialized
INFO - 2023-05-17 02:32:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:32:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:32:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:32:08 --> Final output sent to browser
INFO - 2023-05-17 02:32:08 --> Final output sent to browser
DEBUG - 2023-05-17 02:32:08 --> Total execution time: 0.0240
DEBUG - 2023-05-17 02:32:08 --> Total execution time: 0.0239
INFO - 2023-05-17 02:32:08 --> Config Class Initialized
INFO - 2023-05-17 02:32:08 --> Config Class Initialized
INFO - 2023-05-17 02:32:08 --> Hooks Class Initialized
INFO - 2023-05-17 02:32:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:32:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:32:08 --> Final output sent to browser
DEBUG - 2023-05-17 02:32:08 --> Total execution time: 0.0297
INFO - 2023-05-17 02:32:08 --> Utf8 Class Initialized
DEBUG - 2023-05-17 02:32:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:32:08 --> URI Class Initialized
INFO - 2023-05-17 02:32:08 --> Utf8 Class Initialized
INFO - 2023-05-17 02:32:08 --> URI Class Initialized
INFO - 2023-05-17 02:32:08 --> Router Class Initialized
INFO - 2023-05-17 02:32:08 --> Router Class Initialized
INFO - 2023-05-17 02:32:08 --> Output Class Initialized
INFO - 2023-05-17 02:32:08 --> Output Class Initialized
INFO - 2023-05-17 02:32:08 --> Security Class Initialized
DEBUG - 2023-05-17 02:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:32:08 --> Security Class Initialized
INFO - 2023-05-17 02:32:08 --> Input Class Initialized
DEBUG - 2023-05-17 02:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:32:08 --> Language Class Initialized
INFO - 2023-05-17 02:32:08 --> Input Class Initialized
INFO - 2023-05-17 02:32:08 --> Loader Class Initialized
INFO - 2023-05-17 02:32:08 --> Language Class Initialized
INFO - 2023-05-17 02:32:08 --> Controller Class Initialized
DEBUG - 2023-05-17 02:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:32:08 --> Loader Class Initialized
INFO - 2023-05-17 02:32:08 --> Controller Class Initialized
INFO - 2023-05-17 02:32:08 --> Database Driver Class Initialized
DEBUG - 2023-05-17 02:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:32:08 --> Database Driver Class Initialized
INFO - 2023-05-17 02:32:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:32:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:32:08 --> Final output sent to browser
INFO - 2023-05-17 02:32:08 --> Final output sent to browser
DEBUG - 2023-05-17 02:32:08 --> Total execution time: 0.0673
DEBUG - 2023-05-17 02:32:08 --> Total execution time: 0.0673
INFO - 2023-05-17 02:32:08 --> Config Class Initialized
INFO - 2023-05-17 02:32:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:32:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:32:08 --> Utf8 Class Initialized
INFO - 2023-05-17 02:32:08 --> URI Class Initialized
INFO - 2023-05-17 02:32:08 --> Router Class Initialized
INFO - 2023-05-17 02:32:08 --> Output Class Initialized
INFO - 2023-05-17 02:32:08 --> Security Class Initialized
DEBUG - 2023-05-17 02:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:32:08 --> Input Class Initialized
INFO - 2023-05-17 02:32:08 --> Language Class Initialized
INFO - 2023-05-17 02:32:08 --> Loader Class Initialized
INFO - 2023-05-17 02:32:08 --> Controller Class Initialized
DEBUG - 2023-05-17 02:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:32:08 --> Database Driver Class Initialized
INFO - 2023-05-17 02:32:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:32:09 --> Config Class Initialized
INFO - 2023-05-17 02:32:09 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:32:09 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:32:09 --> Utf8 Class Initialized
INFO - 2023-05-17 02:32:09 --> URI Class Initialized
INFO - 2023-05-17 02:32:09 --> Router Class Initialized
INFO - 2023-05-17 02:32:09 --> Output Class Initialized
INFO - 2023-05-17 02:32:09 --> Security Class Initialized
DEBUG - 2023-05-17 02:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:32:09 --> Input Class Initialized
INFO - 2023-05-17 02:32:09 --> Language Class Initialized
INFO - 2023-05-17 02:32:09 --> Loader Class Initialized
INFO - 2023-05-17 02:32:09 --> Controller Class Initialized
DEBUG - 2023-05-17 02:32:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:32:09 --> Database Driver Class Initialized
INFO - 2023-05-17 02:32:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:03 --> Config Class Initialized
INFO - 2023-05-17 02:44:03 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:03 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:03 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:03 --> URI Class Initialized
INFO - 2023-05-17 02:44:03 --> Router Class Initialized
INFO - 2023-05-17 02:44:03 --> Output Class Initialized
INFO - 2023-05-17 02:44:03 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:03 --> Input Class Initialized
INFO - 2023-05-17 02:44:03 --> Language Class Initialized
INFO - 2023-05-17 02:44:03 --> Loader Class Initialized
INFO - 2023-05-17 02:44:03 --> Controller Class Initialized
INFO - 2023-05-17 02:44:03 --> Helper loaded: form_helper
INFO - 2023-05-17 02:44:03 --> Helper loaded: url_helper
DEBUG - 2023-05-17 02:44:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:03 --> Model "Change_model" initialized
INFO - 2023-05-17 02:44:03 --> Model "Grafana_model" initialized
INFO - 2023-05-17 02:44:03 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:03 --> Total execution time: 0.0342
INFO - 2023-05-17 02:44:03 --> Config Class Initialized
INFO - 2023-05-17 02:44:03 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:03 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:03 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:03 --> URI Class Initialized
INFO - 2023-05-17 02:44:03 --> Router Class Initialized
INFO - 2023-05-17 02:44:03 --> Output Class Initialized
INFO - 2023-05-17 02:44:03 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:03 --> Input Class Initialized
INFO - 2023-05-17 02:44:03 --> Language Class Initialized
INFO - 2023-05-17 02:44:03 --> Loader Class Initialized
INFO - 2023-05-17 02:44:03 --> Controller Class Initialized
INFO - 2023-05-17 02:44:03 --> Helper loaded: form_helper
INFO - 2023-05-17 02:44:03 --> Helper loaded: url_helper
DEBUG - 2023-05-17 02:44:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:03 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:03 --> Total execution time: 0.1229
INFO - 2023-05-17 02:44:03 --> Config Class Initialized
INFO - 2023-05-17 02:44:03 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:03 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:03 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:03 --> URI Class Initialized
INFO - 2023-05-17 02:44:03 --> Router Class Initialized
INFO - 2023-05-17 02:44:03 --> Output Class Initialized
INFO - 2023-05-17 02:44:03 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:03 --> Input Class Initialized
INFO - 2023-05-17 02:44:03 --> Language Class Initialized
INFO - 2023-05-17 02:44:03 --> Loader Class Initialized
INFO - 2023-05-17 02:44:03 --> Controller Class Initialized
INFO - 2023-05-17 02:44:03 --> Helper loaded: form_helper
INFO - 2023-05-17 02:44:03 --> Helper loaded: url_helper
DEBUG - 2023-05-17 02:44:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:03 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:03 --> Model "Login_model" initialized
INFO - 2023-05-17 02:44:03 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:03 --> Total execution time: 0.0211
INFO - 2023-05-17 02:44:03 --> Config Class Initialized
INFO - 2023-05-17 02:44:03 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:03 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:03 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:03 --> URI Class Initialized
INFO - 2023-05-17 02:44:03 --> Router Class Initialized
INFO - 2023-05-17 02:44:03 --> Output Class Initialized
INFO - 2023-05-17 02:44:03 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:03 --> Input Class Initialized
INFO - 2023-05-17 02:44:03 --> Language Class Initialized
INFO - 2023-05-17 02:44:03 --> Loader Class Initialized
INFO - 2023-05-17 02:44:03 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:03 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:03 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:03 --> Total execution time: 0.0147
INFO - 2023-05-17 02:44:03 --> Config Class Initialized
INFO - 2023-05-17 02:44:03 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:03 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:03 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:03 --> URI Class Initialized
INFO - 2023-05-17 02:44:03 --> Router Class Initialized
INFO - 2023-05-17 02:44:03 --> Output Class Initialized
INFO - 2023-05-17 02:44:03 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:03 --> Input Class Initialized
INFO - 2023-05-17 02:44:03 --> Language Class Initialized
INFO - 2023-05-17 02:44:03 --> Loader Class Initialized
INFO - 2023-05-17 02:44:03 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:03 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:03 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:03 --> Total execution time: 0.0131
INFO - 2023-05-17 02:44:03 --> Config Class Initialized
INFO - 2023-05-17 02:44:03 --> Config Class Initialized
INFO - 2023-05-17 02:44:03 --> Hooks Class Initialized
INFO - 2023-05-17 02:44:03 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:03 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:03 --> Utf8 Class Initialized
DEBUG - 2023-05-17 02:44:03 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:03 --> URI Class Initialized
INFO - 2023-05-17 02:44:03 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:03 --> Router Class Initialized
INFO - 2023-05-17 02:44:03 --> URI Class Initialized
INFO - 2023-05-17 02:44:03 --> Output Class Initialized
INFO - 2023-05-17 02:44:03 --> Router Class Initialized
INFO - 2023-05-17 02:44:03 --> Security Class Initialized
INFO - 2023-05-17 02:44:03 --> Output Class Initialized
DEBUG - 2023-05-17 02:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:03 --> Security Class Initialized
INFO - 2023-05-17 02:44:03 --> Input Class Initialized
DEBUG - 2023-05-17 02:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:03 --> Language Class Initialized
INFO - 2023-05-17 02:44:03 --> Input Class Initialized
INFO - 2023-05-17 02:44:03 --> Language Class Initialized
INFO - 2023-05-17 02:44:03 --> Loader Class Initialized
INFO - 2023-05-17 02:44:03 --> Loader Class Initialized
INFO - 2023-05-17 02:44:03 --> Controller Class Initialized
INFO - 2023-05-17 02:44:03 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 02:44:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:03 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:03 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:03 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:03 --> Total execution time: 0.0165
INFO - 2023-05-17 02:44:03 --> Config Class Initialized
INFO - 2023-05-17 02:44:03 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:03 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:03 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:03 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:03 --> URI Class Initialized
INFO - 2023-05-17 02:44:03 --> Router Class Initialized
INFO - 2023-05-17 02:44:03 --> Output Class Initialized
INFO - 2023-05-17 02:44:03 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:03 --> Input Class Initialized
INFO - 2023-05-17 02:44:03 --> Language Class Initialized
INFO - 2023-05-17 02:44:03 --> Loader Class Initialized
INFO - 2023-05-17 02:44:03 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:03 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:03 --> Model "Login_model" initialized
INFO - 2023-05-17 02:44:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:03 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:03 --> Total execution time: 0.0577
INFO - 2023-05-17 02:44:04 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:04 --> Total execution time: 0.1442
INFO - 2023-05-17 02:44:04 --> Config Class Initialized
INFO - 2023-05-17 02:44:04 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:04 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:04 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:04 --> URI Class Initialized
INFO - 2023-05-17 02:44:04 --> Router Class Initialized
INFO - 2023-05-17 02:44:04 --> Output Class Initialized
INFO - 2023-05-17 02:44:04 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:04 --> Input Class Initialized
INFO - 2023-05-17 02:44:04 --> Language Class Initialized
INFO - 2023-05-17 02:44:04 --> Loader Class Initialized
INFO - 2023-05-17 02:44:04 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:04 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:04 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:04 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:04 --> Model "Login_model" initialized
INFO - 2023-05-17 02:44:04 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:04 --> Total execution time: 0.0987
INFO - 2023-05-17 02:44:13 --> Config Class Initialized
INFO - 2023-05-17 02:44:13 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:13 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:13 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:13 --> URI Class Initialized
INFO - 2023-05-17 02:44:13 --> Router Class Initialized
INFO - 2023-05-17 02:44:13 --> Output Class Initialized
INFO - 2023-05-17 02:44:13 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:13 --> Input Class Initialized
INFO - 2023-05-17 02:44:13 --> Language Class Initialized
INFO - 2023-05-17 02:44:13 --> Loader Class Initialized
INFO - 2023-05-17 02:44:13 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:13 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:13 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:13 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:13 --> Total execution time: 0.0189
INFO - 2023-05-17 02:44:13 --> Config Class Initialized
INFO - 2023-05-17 02:44:13 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:13 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:13 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:13 --> URI Class Initialized
INFO - 2023-05-17 02:44:13 --> Router Class Initialized
INFO - 2023-05-17 02:44:13 --> Output Class Initialized
INFO - 2023-05-17 02:44:13 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:13 --> Input Class Initialized
INFO - 2023-05-17 02:44:13 --> Language Class Initialized
INFO - 2023-05-17 02:44:13 --> Loader Class Initialized
INFO - 2023-05-17 02:44:13 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:13 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:13 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:13 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:13 --> Total execution time: 0.0611
INFO - 2023-05-17 02:44:14 --> Config Class Initialized
INFO - 2023-05-17 02:44:14 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:14 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:14 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:14 --> URI Class Initialized
INFO - 2023-05-17 02:44:14 --> Router Class Initialized
INFO - 2023-05-17 02:44:14 --> Output Class Initialized
INFO - 2023-05-17 02:44:14 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:14 --> Input Class Initialized
INFO - 2023-05-17 02:44:14 --> Language Class Initialized
INFO - 2023-05-17 02:44:14 --> Loader Class Initialized
INFO - 2023-05-17 02:44:14 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:14 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:14 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:14 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:14 --> Total execution time: 0.0597
INFO - 2023-05-17 02:44:14 --> Config Class Initialized
INFO - 2023-05-17 02:44:14 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:14 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:14 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:14 --> URI Class Initialized
INFO - 2023-05-17 02:44:14 --> Router Class Initialized
INFO - 2023-05-17 02:44:14 --> Output Class Initialized
INFO - 2023-05-17 02:44:14 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:14 --> Input Class Initialized
INFO - 2023-05-17 02:44:14 --> Language Class Initialized
INFO - 2023-05-17 02:44:14 --> Loader Class Initialized
INFO - 2023-05-17 02:44:14 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:14 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:15 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:15 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:15 --> Total execution time: 0.0963
INFO - 2023-05-17 02:44:16 --> Config Class Initialized
INFO - 2023-05-17 02:44:16 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:16 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:16 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:16 --> URI Class Initialized
INFO - 2023-05-17 02:44:16 --> Router Class Initialized
INFO - 2023-05-17 02:44:16 --> Output Class Initialized
INFO - 2023-05-17 02:44:16 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:16 --> Input Class Initialized
INFO - 2023-05-17 02:44:16 --> Language Class Initialized
INFO - 2023-05-17 02:44:16 --> Loader Class Initialized
INFO - 2023-05-17 02:44:16 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:16 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:16 --> Total execution time: 0.0433
INFO - 2023-05-17 02:44:16 --> Config Class Initialized
INFO - 2023-05-17 02:44:16 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:16 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:16 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:16 --> URI Class Initialized
INFO - 2023-05-17 02:44:16 --> Router Class Initialized
INFO - 2023-05-17 02:44:16 --> Output Class Initialized
INFO - 2023-05-17 02:44:16 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:16 --> Input Class Initialized
INFO - 2023-05-17 02:44:16 --> Language Class Initialized
INFO - 2023-05-17 02:44:16 --> Loader Class Initialized
INFO - 2023-05-17 02:44:16 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:16 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:16 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:16 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:16 --> Total execution time: 0.0541
INFO - 2023-05-17 02:44:18 --> Config Class Initialized
INFO - 2023-05-17 02:44:18 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:18 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:18 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:18 --> URI Class Initialized
INFO - 2023-05-17 02:44:18 --> Router Class Initialized
INFO - 2023-05-17 02:44:18 --> Output Class Initialized
INFO - 2023-05-17 02:44:18 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:18 --> Input Class Initialized
INFO - 2023-05-17 02:44:18 --> Language Class Initialized
INFO - 2023-05-17 02:44:18 --> Loader Class Initialized
INFO - 2023-05-17 02:44:18 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:18 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:18 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:18 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:18 --> Total execution time: 0.0178
INFO - 2023-05-17 02:44:18 --> Config Class Initialized
INFO - 2023-05-17 02:44:18 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:18 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:18 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:18 --> URI Class Initialized
INFO - 2023-05-17 02:44:18 --> Router Class Initialized
INFO - 2023-05-17 02:44:18 --> Output Class Initialized
INFO - 2023-05-17 02:44:18 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:18 --> Input Class Initialized
INFO - 2023-05-17 02:44:18 --> Language Class Initialized
INFO - 2023-05-17 02:44:18 --> Loader Class Initialized
INFO - 2023-05-17 02:44:18 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:18 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:18 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:18 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:18 --> Total execution time: 0.0195
INFO - 2023-05-17 02:44:21 --> Config Class Initialized
INFO - 2023-05-17 02:44:21 --> Config Class Initialized
INFO - 2023-05-17 02:44:21 --> Hooks Class Initialized
INFO - 2023-05-17 02:44:21 --> Config Class Initialized
INFO - 2023-05-17 02:44:21 --> Hooks Class Initialized
INFO - 2023-05-17 02:44:21 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 02:44:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 02:44:21 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:21 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:21 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:21 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:21 --> URI Class Initialized
INFO - 2023-05-17 02:44:21 --> URI Class Initialized
INFO - 2023-05-17 02:44:21 --> URI Class Initialized
INFO - 2023-05-17 02:44:21 --> Router Class Initialized
INFO - 2023-05-17 02:44:21 --> Router Class Initialized
INFO - 2023-05-17 02:44:21 --> Router Class Initialized
INFO - 2023-05-17 02:44:21 --> Output Class Initialized
INFO - 2023-05-17 02:44:21 --> Output Class Initialized
INFO - 2023-05-17 02:44:21 --> Output Class Initialized
INFO - 2023-05-17 02:44:21 --> Security Class Initialized
INFO - 2023-05-17 02:44:21 --> Security Class Initialized
INFO - 2023-05-17 02:44:21 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 02:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:21 --> Input Class Initialized
INFO - 2023-05-17 02:44:21 --> Input Class Initialized
INFO - 2023-05-17 02:44:21 --> Language Class Initialized
INFO - 2023-05-17 02:44:21 --> Language Class Initialized
INFO - 2023-05-17 02:44:21 --> Loader Class Initialized
DEBUG - 2023-05-17 02:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:21 --> Loader Class Initialized
INFO - 2023-05-17 02:44:21 --> Input Class Initialized
INFO - 2023-05-17 02:44:21 --> Controller Class Initialized
INFO - 2023-05-17 02:44:21 --> Controller Class Initialized
INFO - 2023-05-17 02:44:21 --> Language Class Initialized
DEBUG - 2023-05-17 02:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 02:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:21 --> Loader Class Initialized
INFO - 2023-05-17 02:44:21 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:21 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:21 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:21 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:21 --> Final output sent to browser
INFO - 2023-05-17 02:44:21 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:21 --> Total execution time: 0.0197
DEBUG - 2023-05-17 02:44:21 --> Total execution time: 0.0200
INFO - 2023-05-17 02:44:21 --> Config Class Initialized
INFO - 2023-05-17 02:44:21 --> Config Class Initialized
INFO - 2023-05-17 02:44:21 --> Hooks Class Initialized
INFO - 2023-05-17 02:44:21 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 02:44:21 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:21 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:21 --> Final output sent to browser
INFO - 2023-05-17 02:44:21 --> Utf8 Class Initialized
DEBUG - 2023-05-17 02:44:21 --> Total execution time: 0.0255
INFO - 2023-05-17 02:44:21 --> URI Class Initialized
INFO - 2023-05-17 02:44:21 --> URI Class Initialized
INFO - 2023-05-17 02:44:21 --> Router Class Initialized
INFO - 2023-05-17 02:44:21 --> Router Class Initialized
INFO - 2023-05-17 02:44:21 --> Output Class Initialized
INFO - 2023-05-17 02:44:21 --> Output Class Initialized
INFO - 2023-05-17 02:44:21 --> Security Class Initialized
INFO - 2023-05-17 02:44:21 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 02:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:21 --> Input Class Initialized
INFO - 2023-05-17 02:44:21 --> Input Class Initialized
INFO - 2023-05-17 02:44:21 --> Language Class Initialized
INFO - 2023-05-17 02:44:21 --> Language Class Initialized
INFO - 2023-05-17 02:44:21 --> Loader Class Initialized
INFO - 2023-05-17 02:44:21 --> Loader Class Initialized
INFO - 2023-05-17 02:44:21 --> Controller Class Initialized
INFO - 2023-05-17 02:44:21 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 02:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:21 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:21 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:21 --> Final output sent to browser
INFO - 2023-05-17 02:44:21 --> Final output sent to browser
DEBUG - 2023-05-17 02:44:21 --> Total execution time: 0.0129
DEBUG - 2023-05-17 02:44:21 --> Total execution time: 0.0129
INFO - 2023-05-17 02:44:21 --> Config Class Initialized
INFO - 2023-05-17 02:44:21 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:21 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:21 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:21 --> URI Class Initialized
INFO - 2023-05-17 02:44:21 --> Router Class Initialized
INFO - 2023-05-17 02:44:21 --> Output Class Initialized
INFO - 2023-05-17 02:44:21 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:21 --> Input Class Initialized
INFO - 2023-05-17 02:44:21 --> Language Class Initialized
INFO - 2023-05-17 02:44:21 --> Loader Class Initialized
INFO - 2023-05-17 02:44:21 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:21 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:44:21 --> Config Class Initialized
INFO - 2023-05-17 02:44:21 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:44:21 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:44:21 --> Utf8 Class Initialized
INFO - 2023-05-17 02:44:21 --> URI Class Initialized
INFO - 2023-05-17 02:44:21 --> Router Class Initialized
INFO - 2023-05-17 02:44:21 --> Output Class Initialized
INFO - 2023-05-17 02:44:21 --> Security Class Initialized
DEBUG - 2023-05-17 02:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:44:21 --> Input Class Initialized
INFO - 2023-05-17 02:44:21 --> Language Class Initialized
INFO - 2023-05-17 02:44:21 --> Loader Class Initialized
INFO - 2023-05-17 02:44:21 --> Controller Class Initialized
DEBUG - 2023-05-17 02:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:44:21 --> Database Driver Class Initialized
INFO - 2023-05-17 02:44:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:47:32 --> Config Class Initialized
INFO - 2023-05-17 02:47:32 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:47:32 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:47:32 --> Utf8 Class Initialized
INFO - 2023-05-17 02:47:32 --> URI Class Initialized
INFO - 2023-05-17 02:47:32 --> Router Class Initialized
INFO - 2023-05-17 02:47:32 --> Output Class Initialized
INFO - 2023-05-17 02:47:32 --> Security Class Initialized
DEBUG - 2023-05-17 02:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:47:32 --> Input Class Initialized
INFO - 2023-05-17 02:47:32 --> Language Class Initialized
INFO - 2023-05-17 02:47:32 --> Loader Class Initialized
INFO - 2023-05-17 02:47:32 --> Controller Class Initialized
DEBUG - 2023-05-17 02:47:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:47:32 --> Database Driver Class Initialized
INFO - 2023-05-17 02:47:32 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:47:32 --> Config Class Initialized
INFO - 2023-05-17 02:47:32 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:47:32 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:47:32 --> Utf8 Class Initialized
INFO - 2023-05-17 02:47:32 --> URI Class Initialized
INFO - 2023-05-17 02:47:32 --> Router Class Initialized
INFO - 2023-05-17 02:47:32 --> Output Class Initialized
INFO - 2023-05-17 02:47:32 --> Security Class Initialized
DEBUG - 2023-05-17 02:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:47:32 --> Input Class Initialized
INFO - 2023-05-17 02:47:32 --> Language Class Initialized
INFO - 2023-05-17 02:47:32 --> Loader Class Initialized
INFO - 2023-05-17 02:47:32 --> Controller Class Initialized
DEBUG - 2023-05-17 02:47:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:47:32 --> Database Driver Class Initialized
INFO - 2023-05-17 02:47:32 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:48:02 --> Config Class Initialized
INFO - 2023-05-17 02:48:02 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:48:02 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:48:02 --> Utf8 Class Initialized
INFO - 2023-05-17 02:48:02 --> URI Class Initialized
INFO - 2023-05-17 02:48:02 --> Router Class Initialized
INFO - 2023-05-17 02:48:02 --> Output Class Initialized
INFO - 2023-05-17 02:48:02 --> Security Class Initialized
DEBUG - 2023-05-17 02:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:48:02 --> Input Class Initialized
INFO - 2023-05-17 02:48:02 --> Language Class Initialized
INFO - 2023-05-17 02:48:02 --> Loader Class Initialized
INFO - 2023-05-17 02:48:02 --> Controller Class Initialized
DEBUG - 2023-05-17 02:48:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:48:02 --> Database Driver Class Initialized
INFO - 2023-05-17 02:48:02 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:48:02 --> Config Class Initialized
INFO - 2023-05-17 02:48:02 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:48:02 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:48:02 --> Utf8 Class Initialized
INFO - 2023-05-17 02:48:02 --> URI Class Initialized
INFO - 2023-05-17 02:48:02 --> Router Class Initialized
INFO - 2023-05-17 02:48:02 --> Output Class Initialized
INFO - 2023-05-17 02:48:02 --> Security Class Initialized
DEBUG - 2023-05-17 02:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:48:02 --> Input Class Initialized
INFO - 2023-05-17 02:48:02 --> Language Class Initialized
ERROR - 2023-05-17 02:48:02 --> 404 Page Not Found: Faviconico/index
INFO - 2023-05-17 02:48:39 --> Config Class Initialized
INFO - 2023-05-17 02:48:39 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:48:39 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:48:39 --> Utf8 Class Initialized
INFO - 2023-05-17 02:48:39 --> URI Class Initialized
INFO - 2023-05-17 02:48:39 --> Router Class Initialized
INFO - 2023-05-17 02:48:39 --> Output Class Initialized
INFO - 2023-05-17 02:48:39 --> Security Class Initialized
DEBUG - 2023-05-17 02:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:48:39 --> Input Class Initialized
INFO - 2023-05-17 02:48:39 --> Language Class Initialized
INFO - 2023-05-17 02:48:39 --> Loader Class Initialized
INFO - 2023-05-17 02:48:39 --> Controller Class Initialized
DEBUG - 2023-05-17 02:48:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:48:39 --> Database Driver Class Initialized
INFO - 2023-05-17 02:48:39 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:48:39 --> Final output sent to browser
DEBUG - 2023-05-17 02:48:39 --> Total execution time: 0.1172
INFO - 2023-05-17 02:48:39 --> Config Class Initialized
INFO - 2023-05-17 02:48:39 --> Hooks Class Initialized
DEBUG - 2023-05-17 02:48:39 --> UTF-8 Support Enabled
INFO - 2023-05-17 02:48:39 --> Utf8 Class Initialized
INFO - 2023-05-17 02:48:39 --> URI Class Initialized
INFO - 2023-05-17 02:48:39 --> Router Class Initialized
INFO - 2023-05-17 02:48:39 --> Output Class Initialized
INFO - 2023-05-17 02:48:39 --> Security Class Initialized
DEBUG - 2023-05-17 02:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 02:48:39 --> Input Class Initialized
INFO - 2023-05-17 02:48:39 --> Language Class Initialized
INFO - 2023-05-17 02:48:39 --> Loader Class Initialized
INFO - 2023-05-17 02:48:39 --> Controller Class Initialized
DEBUG - 2023-05-17 02:48:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 02:48:39 --> Database Driver Class Initialized
INFO - 2023-05-17 02:48:39 --> Model "Cluster_model" initialized
INFO - 2023-05-17 02:48:39 --> Final output sent to browser
DEBUG - 2023-05-17 02:48:39 --> Total execution time: 0.1543
INFO - 2023-05-17 03:28:41 --> Config Class Initialized
INFO - 2023-05-17 03:28:41 --> Config Class Initialized
INFO - 2023-05-17 03:28:41 --> Config Class Initialized
INFO - 2023-05-17 03:28:41 --> Hooks Class Initialized
INFO - 2023-05-17 03:28:41 --> Hooks Class Initialized
INFO - 2023-05-17 03:28:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:28:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:28:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:28:41 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:41 --> Utf8 Class Initialized
DEBUG - 2023-05-17 03:28:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:28:41 --> URI Class Initialized
INFO - 2023-05-17 03:28:41 --> URI Class Initialized
INFO - 2023-05-17 03:28:41 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:41 --> Router Class Initialized
INFO - 2023-05-17 03:28:41 --> Router Class Initialized
INFO - 2023-05-17 03:28:41 --> URI Class Initialized
INFO - 2023-05-17 03:28:41 --> Output Class Initialized
INFO - 2023-05-17 03:28:41 --> Output Class Initialized
INFO - 2023-05-17 03:28:41 --> Router Class Initialized
INFO - 2023-05-17 03:28:41 --> Security Class Initialized
INFO - 2023-05-17 03:28:41 --> Output Class Initialized
INFO - 2023-05-17 03:28:41 --> Security Class Initialized
INFO - 2023-05-17 03:28:41 --> Security Class Initialized
DEBUG - 2023-05-17 03:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:41 --> Input Class Initialized
DEBUG - 2023-05-17 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:41 --> Input Class Initialized
INFO - 2023-05-17 03:28:41 --> Language Class Initialized
INFO - 2023-05-17 03:28:41 --> Input Class Initialized
INFO - 2023-05-17 03:28:41 --> Language Class Initialized
INFO - 2023-05-17 03:28:41 --> Language Class Initialized
INFO - 2023-05-17 03:28:41 --> Loader Class Initialized
INFO - 2023-05-17 03:28:41 --> Loader Class Initialized
INFO - 2023-05-17 03:28:41 --> Loader Class Initialized
INFO - 2023-05-17 03:28:41 --> Controller Class Initialized
INFO - 2023-05-17 03:28:41 --> Controller Class Initialized
INFO - 2023-05-17 03:28:41 --> Controller Class Initialized
DEBUG - 2023-05-17 03:28:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 03:28:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 03:28:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:28:41 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:41 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:41 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:41 --> Final output sent to browser
INFO - 2023-05-17 03:28:41 --> Final output sent to browser
DEBUG - 2023-05-17 03:28:41 --> Total execution time: 0.1042
DEBUG - 2023-05-17 03:28:41 --> Total execution time: 0.1056
INFO - 2023-05-17 03:28:41 --> Final output sent to browser
DEBUG - 2023-05-17 03:28:41 --> Total execution time: 0.1063
INFO - 2023-05-17 03:28:41 --> Config Class Initialized
INFO - 2023-05-17 03:28:41 --> Config Class Initialized
INFO - 2023-05-17 03:28:41 --> Config Class Initialized
INFO - 2023-05-17 03:28:41 --> Hooks Class Initialized
INFO - 2023-05-17 03:28:41 --> Hooks Class Initialized
INFO - 2023-05-17 03:28:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:28:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:28:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:28:41 --> Utf8 Class Initialized
DEBUG - 2023-05-17 03:28:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:28:41 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:41 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:41 --> URI Class Initialized
INFO - 2023-05-17 03:28:41 --> URI Class Initialized
INFO - 2023-05-17 03:28:41 --> URI Class Initialized
INFO - 2023-05-17 03:28:41 --> Router Class Initialized
INFO - 2023-05-17 03:28:41 --> Router Class Initialized
INFO - 2023-05-17 03:28:41 --> Router Class Initialized
INFO - 2023-05-17 03:28:41 --> Output Class Initialized
INFO - 2023-05-17 03:28:41 --> Output Class Initialized
INFO - 2023-05-17 03:28:41 --> Output Class Initialized
INFO - 2023-05-17 03:28:41 --> Security Class Initialized
INFO - 2023-05-17 03:28:41 --> Security Class Initialized
INFO - 2023-05-17 03:28:41 --> Security Class Initialized
DEBUG - 2023-05-17 03:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:41 --> Input Class Initialized
INFO - 2023-05-17 03:28:41 --> Input Class Initialized
DEBUG - 2023-05-17 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:41 --> Language Class Initialized
INFO - 2023-05-17 03:28:41 --> Language Class Initialized
INFO - 2023-05-17 03:28:41 --> Input Class Initialized
INFO - 2023-05-17 03:28:41 --> Loader Class Initialized
INFO - 2023-05-17 03:28:41 --> Language Class Initialized
INFO - 2023-05-17 03:28:41 --> Loader Class Initialized
INFO - 2023-05-17 03:28:41 --> Controller Class Initialized
INFO - 2023-05-17 03:28:41 --> Controller Class Initialized
INFO - 2023-05-17 03:28:41 --> Loader Class Initialized
DEBUG - 2023-05-17 03:28:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 03:28:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:28:41 --> Controller Class Initialized
DEBUG - 2023-05-17 03:28:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:28:41 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:41 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:41 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:41 --> Final output sent to browser
INFO - 2023-05-17 03:28:41 --> Final output sent to browser
DEBUG - 2023-05-17 03:28:41 --> Total execution time: 0.0143
DEBUG - 2023-05-17 03:28:41 --> Total execution time: 0.0143
INFO - 2023-05-17 03:28:41 --> Final output sent to browser
INFO - 2023-05-17 03:28:41 --> Config Class Initialized
DEBUG - 2023-05-17 03:28:41 --> Total execution time: 0.0202
INFO - 2023-05-17 03:28:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:28:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:28:41 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:41 --> URI Class Initialized
INFO - 2023-05-17 03:28:41 --> Router Class Initialized
INFO - 2023-05-17 03:28:41 --> Output Class Initialized
INFO - 2023-05-17 03:28:41 --> Security Class Initialized
DEBUG - 2023-05-17 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:41 --> Input Class Initialized
INFO - 2023-05-17 03:28:41 --> Language Class Initialized
INFO - 2023-05-17 03:28:41 --> Loader Class Initialized
INFO - 2023-05-17 03:28:41 --> Controller Class Initialized
DEBUG - 2023-05-17 03:28:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:28:41 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:41 --> Config Class Initialized
INFO - 2023-05-17 03:28:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:28:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:28:41 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:41 --> URI Class Initialized
INFO - 2023-05-17 03:28:41 --> Router Class Initialized
INFO - 2023-05-17 03:28:41 --> Output Class Initialized
INFO - 2023-05-17 03:28:41 --> Security Class Initialized
DEBUG - 2023-05-17 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:41 --> Input Class Initialized
INFO - 2023-05-17 03:28:41 --> Language Class Initialized
INFO - 2023-05-17 03:28:41 --> Loader Class Initialized
INFO - 2023-05-17 03:28:41 --> Controller Class Initialized
DEBUG - 2023-05-17 03:28:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:28:41 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:47 --> Config Class Initialized
INFO - 2023-05-17 03:28:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:28:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:28:47 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:47 --> URI Class Initialized
INFO - 2023-05-17 03:28:47 --> Router Class Initialized
INFO - 2023-05-17 03:28:47 --> Output Class Initialized
INFO - 2023-05-17 03:28:47 --> Security Class Initialized
DEBUG - 2023-05-17 03:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:47 --> Input Class Initialized
INFO - 2023-05-17 03:28:47 --> Language Class Initialized
INFO - 2023-05-17 03:28:47 --> Loader Class Initialized
INFO - 2023-05-17 03:28:47 --> Controller Class Initialized
DEBUG - 2023-05-17 03:28:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:28:47 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:47 --> Final output sent to browser
DEBUG - 2023-05-17 03:28:47 --> Total execution time: 0.0234
INFO - 2023-05-17 03:28:47 --> Config Class Initialized
INFO - 2023-05-17 03:28:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:28:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:28:47 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:47 --> URI Class Initialized
INFO - 2023-05-17 03:28:47 --> Router Class Initialized
INFO - 2023-05-17 03:28:47 --> Output Class Initialized
INFO - 2023-05-17 03:28:47 --> Security Class Initialized
DEBUG - 2023-05-17 03:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:47 --> Input Class Initialized
INFO - 2023-05-17 03:28:47 --> Language Class Initialized
INFO - 2023-05-17 03:28:47 --> Loader Class Initialized
INFO - 2023-05-17 03:28:47 --> Controller Class Initialized
DEBUG - 2023-05-17 03:28:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:28:47 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:47 --> Final output sent to browser
DEBUG - 2023-05-17 03:28:47 --> Total execution time: 0.0305
INFO - 2023-05-17 03:28:48 --> Config Class Initialized
INFO - 2023-05-17 03:28:48 --> Config Class Initialized
INFO - 2023-05-17 03:28:48 --> Config Class Initialized
INFO - 2023-05-17 03:28:48 --> Hooks Class Initialized
INFO - 2023-05-17 03:28:48 --> Hooks Class Initialized
INFO - 2023-05-17 03:28:48 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:28:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:28:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:28:48 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:28:48 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:48 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:48 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:48 --> URI Class Initialized
INFO - 2023-05-17 03:28:48 --> URI Class Initialized
INFO - 2023-05-17 03:28:48 --> Router Class Initialized
INFO - 2023-05-17 03:28:48 --> Router Class Initialized
INFO - 2023-05-17 03:28:48 --> Output Class Initialized
INFO - 2023-05-17 03:28:48 --> URI Class Initialized
INFO - 2023-05-17 03:28:48 --> Security Class Initialized
INFO - 2023-05-17 03:28:48 --> Output Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:48 --> Security Class Initialized
INFO - 2023-05-17 03:28:48 --> Router Class Initialized
INFO - 2023-05-17 03:28:48 --> Input Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:48 --> Output Class Initialized
INFO - 2023-05-17 03:28:48 --> Language Class Initialized
INFO - 2023-05-17 03:28:48 --> Input Class Initialized
INFO - 2023-05-17 03:28:48 --> Loader Class Initialized
INFO - 2023-05-17 03:28:48 --> Language Class Initialized
INFO - 2023-05-17 03:28:48 --> Security Class Initialized
INFO - 2023-05-17 03:28:48 --> Loader Class Initialized
INFO - 2023-05-17 03:28:48 --> Controller Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:48 --> Controller Class Initialized
INFO - 2023-05-17 03:28:48 --> Input Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 03:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:28:48 --> Language Class Initialized
INFO - 2023-05-17 03:28:48 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:48 --> Loader Class Initialized
INFO - 2023-05-17 03:28:48 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:48 --> Controller Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:28:48 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:48 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:48 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:48 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:48 --> Final output sent to browser
DEBUG - 2023-05-17 03:28:48 --> Total execution time: 0.0379
INFO - 2023-05-17 03:28:48 --> Config Class Initialized
INFO - 2023-05-17 03:28:48 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:28:48 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:28:48 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:48 --> URI Class Initialized
INFO - 2023-05-17 03:28:48 --> Router Class Initialized
INFO - 2023-05-17 03:28:48 --> Output Class Initialized
INFO - 2023-05-17 03:28:48 --> Security Class Initialized
INFO - 2023-05-17 03:28:48 --> Final output sent to browser
INFO - 2023-05-17 03:28:48 --> Final output sent to browser
DEBUG - 2023-05-17 03:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 03:28:48 --> Total execution time: 0.0416
INFO - 2023-05-17 03:28:48 --> Input Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Total execution time: 0.0416
INFO - 2023-05-17 03:28:48 --> Language Class Initialized
INFO - 2023-05-17 03:28:48 --> Loader Class Initialized
INFO - 2023-05-17 03:28:48 --> Controller Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:28:48 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:48 --> Config Class Initialized
INFO - 2023-05-17 03:28:48 --> Config Class Initialized
INFO - 2023-05-17 03:28:48 --> Hooks Class Initialized
INFO - 2023-05-17 03:28:48 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:28:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:28:48 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:28:48 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:48 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:48 --> URI Class Initialized
INFO - 2023-05-17 03:28:48 --> URI Class Initialized
INFO - 2023-05-17 03:28:48 --> Router Class Initialized
INFO - 2023-05-17 03:28:48 --> Router Class Initialized
INFO - 2023-05-17 03:28:48 --> Output Class Initialized
INFO - 2023-05-17 03:28:48 --> Output Class Initialized
INFO - 2023-05-17 03:28:48 --> Security Class Initialized
INFO - 2023-05-17 03:28:48 --> Security Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 03:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:48 --> Input Class Initialized
INFO - 2023-05-17 03:28:48 --> Input Class Initialized
INFO - 2023-05-17 03:28:48 --> Language Class Initialized
INFO - 2023-05-17 03:28:48 --> Language Class Initialized
INFO - 2023-05-17 03:28:48 --> Loader Class Initialized
INFO - 2023-05-17 03:28:48 --> Loader Class Initialized
INFO - 2023-05-17 03:28:48 --> Controller Class Initialized
INFO - 2023-05-17 03:28:48 --> Controller Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 03:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:28:48 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:48 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:48 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:48 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:48 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:48 --> Final output sent to browser
DEBUG - 2023-05-17 03:28:48 --> Total execution time: 0.0253
INFO - 2023-05-17 03:28:48 --> Config Class Initialized
INFO - 2023-05-17 03:28:48 --> Final output sent to browser
INFO - 2023-05-17 03:28:48 --> Final output sent to browser
INFO - 2023-05-17 03:28:48 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Total execution time: 0.0337
DEBUG - 2023-05-17 03:28:48 --> Total execution time: 0.0405
DEBUG - 2023-05-17 03:28:48 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:28:48 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:48 --> URI Class Initialized
INFO - 2023-05-17 03:28:48 --> Router Class Initialized
INFO - 2023-05-17 03:28:48 --> Output Class Initialized
INFO - 2023-05-17 03:28:48 --> Security Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:48 --> Input Class Initialized
INFO - 2023-05-17 03:28:48 --> Language Class Initialized
INFO - 2023-05-17 03:28:48 --> Loader Class Initialized
INFO - 2023-05-17 03:28:48 --> Controller Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:28:48 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:48 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:28:48 --> Config Class Initialized
INFO - 2023-05-17 03:28:48 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:28:48 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:28:48 --> Utf8 Class Initialized
INFO - 2023-05-17 03:28:48 --> URI Class Initialized
INFO - 2023-05-17 03:28:48 --> Router Class Initialized
INFO - 2023-05-17 03:28:48 --> Output Class Initialized
INFO - 2023-05-17 03:28:48 --> Security Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:28:48 --> Input Class Initialized
INFO - 2023-05-17 03:28:48 --> Language Class Initialized
INFO - 2023-05-17 03:28:48 --> Loader Class Initialized
INFO - 2023-05-17 03:28:48 --> Controller Class Initialized
DEBUG - 2023-05-17 03:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:28:48 --> Database Driver Class Initialized
INFO - 2023-05-17 03:28:48 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:33:16 --> Config Class Initialized
INFO - 2023-05-17 03:33:16 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:33:16 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:33:16 --> Utf8 Class Initialized
INFO - 2023-05-17 03:33:16 --> URI Class Initialized
INFO - 2023-05-17 03:33:16 --> Router Class Initialized
INFO - 2023-05-17 03:33:16 --> Output Class Initialized
INFO - 2023-05-17 03:33:16 --> Security Class Initialized
DEBUG - 2023-05-17 03:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:33:16 --> Input Class Initialized
INFO - 2023-05-17 03:33:16 --> Language Class Initialized
INFO - 2023-05-17 03:33:16 --> Loader Class Initialized
INFO - 2023-05-17 03:33:16 --> Controller Class Initialized
DEBUG - 2023-05-17 03:33:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:33:16 --> Database Driver Class Initialized
INFO - 2023-05-17 03:33:16 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:33:16 --> Final output sent to browser
DEBUG - 2023-05-17 03:33:16 --> Total execution time: 0.0161
INFO - 2023-05-17 03:33:16 --> Config Class Initialized
INFO - 2023-05-17 03:33:16 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:33:16 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:33:16 --> Utf8 Class Initialized
INFO - 2023-05-17 03:33:16 --> URI Class Initialized
INFO - 2023-05-17 03:33:16 --> Router Class Initialized
INFO - 2023-05-17 03:33:16 --> Output Class Initialized
INFO - 2023-05-17 03:33:16 --> Security Class Initialized
DEBUG - 2023-05-17 03:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:33:16 --> Input Class Initialized
INFO - 2023-05-17 03:33:16 --> Language Class Initialized
INFO - 2023-05-17 03:33:16 --> Loader Class Initialized
INFO - 2023-05-17 03:33:16 --> Controller Class Initialized
DEBUG - 2023-05-17 03:33:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:33:16 --> Database Driver Class Initialized
INFO - 2023-05-17 03:33:16 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:33:16 --> Final output sent to browser
DEBUG - 2023-05-17 03:33:16 --> Total execution time: 0.0225
INFO - 2023-05-17 03:36:12 --> Config Class Initialized
INFO - 2023-05-17 03:36:12 --> Config Class Initialized
INFO - 2023-05-17 03:36:12 --> Config Class Initialized
INFO - 2023-05-17 03:36:12 --> Hooks Class Initialized
INFO - 2023-05-17 03:36:12 --> Hooks Class Initialized
INFO - 2023-05-17 03:36:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:36:12 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:36:12 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:36:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:36:12 --> Utf8 Class Initialized
INFO - 2023-05-17 03:36:12 --> Utf8 Class Initialized
INFO - 2023-05-17 03:36:12 --> Utf8 Class Initialized
INFO - 2023-05-17 03:36:12 --> URI Class Initialized
INFO - 2023-05-17 03:36:12 --> URI Class Initialized
INFO - 2023-05-17 03:36:12 --> URI Class Initialized
INFO - 2023-05-17 03:36:12 --> Router Class Initialized
INFO - 2023-05-17 03:36:12 --> Router Class Initialized
INFO - 2023-05-17 03:36:12 --> Router Class Initialized
INFO - 2023-05-17 03:36:12 --> Output Class Initialized
INFO - 2023-05-17 03:36:12 --> Output Class Initialized
INFO - 2023-05-17 03:36:12 --> Output Class Initialized
INFO - 2023-05-17 03:36:12 --> Security Class Initialized
INFO - 2023-05-17 03:36:12 --> Security Class Initialized
INFO - 2023-05-17 03:36:12 --> Security Class Initialized
DEBUG - 2023-05-17 03:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 03:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 03:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:36:12 --> Input Class Initialized
INFO - 2023-05-17 03:36:12 --> Input Class Initialized
INFO - 2023-05-17 03:36:12 --> Input Class Initialized
INFO - 2023-05-17 03:36:12 --> Language Class Initialized
INFO - 2023-05-17 03:36:12 --> Language Class Initialized
INFO - 2023-05-17 03:36:12 --> Language Class Initialized
INFO - 2023-05-17 03:36:12 --> Loader Class Initialized
INFO - 2023-05-17 03:36:12 --> Loader Class Initialized
INFO - 2023-05-17 03:36:12 --> Loader Class Initialized
INFO - 2023-05-17 03:36:12 --> Controller Class Initialized
INFO - 2023-05-17 03:36:12 --> Controller Class Initialized
INFO - 2023-05-17 03:36:12 --> Controller Class Initialized
DEBUG - 2023-05-17 03:36:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 03:36:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 03:36:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:36:12 --> Database Driver Class Initialized
INFO - 2023-05-17 03:36:12 --> Database Driver Class Initialized
INFO - 2023-05-17 03:36:12 --> Database Driver Class Initialized
INFO - 2023-05-17 03:36:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:36:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:36:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:36:12 --> Final output sent to browser
DEBUG - 2023-05-17 03:36:12 --> Total execution time: 0.0206
INFO - 2023-05-17 03:36:12 --> Final output sent to browser
INFO - 2023-05-17 03:36:12 --> Final output sent to browser
DEBUG - 2023-05-17 03:36:12 --> Total execution time: 0.0221
DEBUG - 2023-05-17 03:36:12 --> Total execution time: 0.0221
INFO - 2023-05-17 03:36:12 --> Config Class Initialized
INFO - 2023-05-17 03:36:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:36:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:36:12 --> Utf8 Class Initialized
INFO - 2023-05-17 03:36:12 --> URI Class Initialized
INFO - 2023-05-17 03:36:12 --> Router Class Initialized
INFO - 2023-05-17 03:36:12 --> Output Class Initialized
INFO - 2023-05-17 03:36:12 --> Security Class Initialized
DEBUG - 2023-05-17 03:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:36:12 --> Input Class Initialized
INFO - 2023-05-17 03:36:12 --> Config Class Initialized
INFO - 2023-05-17 03:36:12 --> Language Class Initialized
INFO - 2023-05-17 03:36:12 --> Config Class Initialized
INFO - 2023-05-17 03:36:12 --> Hooks Class Initialized
INFO - 2023-05-17 03:36:12 --> Hooks Class Initialized
INFO - 2023-05-17 03:36:12 --> Loader Class Initialized
DEBUG - 2023-05-17 03:36:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:36:12 --> Controller Class Initialized
INFO - 2023-05-17 03:36:12 --> Utf8 Class Initialized
DEBUG - 2023-05-17 03:36:12 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:36:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:36:12 --> URI Class Initialized
INFO - 2023-05-17 03:36:12 --> Utf8 Class Initialized
INFO - 2023-05-17 03:36:12 --> Database Driver Class Initialized
INFO - 2023-05-17 03:36:12 --> Router Class Initialized
INFO - 2023-05-17 03:36:12 --> URI Class Initialized
INFO - 2023-05-17 03:36:12 --> Output Class Initialized
INFO - 2023-05-17 03:36:12 --> Router Class Initialized
INFO - 2023-05-17 03:36:12 --> Security Class Initialized
INFO - 2023-05-17 03:36:12 --> Output Class Initialized
DEBUG - 2023-05-17 03:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:36:12 --> Input Class Initialized
INFO - 2023-05-17 03:36:12 --> Security Class Initialized
INFO - 2023-05-17 03:36:12 --> Language Class Initialized
DEBUG - 2023-05-17 03:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:36:12 --> Input Class Initialized
INFO - 2023-05-17 03:36:12 --> Loader Class Initialized
INFO - 2023-05-17 03:36:12 --> Language Class Initialized
INFO - 2023-05-17 03:36:12 --> Controller Class Initialized
INFO - 2023-05-17 03:36:12 --> Loader Class Initialized
DEBUG - 2023-05-17 03:36:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:36:12 --> Controller Class Initialized
INFO - 2023-05-17 03:36:12 --> Database Driver Class Initialized
DEBUG - 2023-05-17 03:36:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:36:12 --> Database Driver Class Initialized
INFO - 2023-05-17 03:36:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:36:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:36:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:36:12 --> Final output sent to browser
DEBUG - 2023-05-17 03:36:12 --> Total execution time: 0.0134
INFO - 2023-05-17 03:36:12 --> Final output sent to browser
DEBUG - 2023-05-17 03:36:12 --> Total execution time: 0.0139
INFO - 2023-05-17 03:36:12 --> Final output sent to browser
INFO - 2023-05-17 03:36:12 --> Config Class Initialized
INFO - 2023-05-17 03:36:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:36:12 --> Total execution time: 0.0201
DEBUG - 2023-05-17 03:36:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:36:12 --> Utf8 Class Initialized
INFO - 2023-05-17 03:36:12 --> URI Class Initialized
INFO - 2023-05-17 03:36:12 --> Router Class Initialized
INFO - 2023-05-17 03:36:12 --> Output Class Initialized
INFO - 2023-05-17 03:36:12 --> Security Class Initialized
DEBUG - 2023-05-17 03:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:36:12 --> Input Class Initialized
INFO - 2023-05-17 03:36:12 --> Language Class Initialized
INFO - 2023-05-17 03:36:12 --> Loader Class Initialized
INFO - 2023-05-17 03:36:12 --> Controller Class Initialized
DEBUG - 2023-05-17 03:36:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:36:12 --> Database Driver Class Initialized
INFO - 2023-05-17 03:36:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:36:12 --> Config Class Initialized
INFO - 2023-05-17 03:36:13 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:36:13 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:36:13 --> Utf8 Class Initialized
INFO - 2023-05-17 03:36:13 --> URI Class Initialized
INFO - 2023-05-17 03:36:13 --> Router Class Initialized
INFO - 2023-05-17 03:36:13 --> Output Class Initialized
INFO - 2023-05-17 03:36:13 --> Security Class Initialized
DEBUG - 2023-05-17 03:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:36:13 --> Input Class Initialized
INFO - 2023-05-17 03:36:13 --> Language Class Initialized
INFO - 2023-05-17 03:36:13 --> Loader Class Initialized
INFO - 2023-05-17 03:36:13 --> Controller Class Initialized
DEBUG - 2023-05-17 03:36:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:36:13 --> Database Driver Class Initialized
INFO - 2023-05-17 03:36:13 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:38:31 --> Config Class Initialized
INFO - 2023-05-17 03:38:31 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:38:31 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:38:31 --> Utf8 Class Initialized
INFO - 2023-05-17 03:38:31 --> URI Class Initialized
INFO - 2023-05-17 03:38:31 --> Router Class Initialized
INFO - 2023-05-17 03:38:31 --> Output Class Initialized
INFO - 2023-05-17 03:38:31 --> Security Class Initialized
DEBUG - 2023-05-17 03:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:38:31 --> Input Class Initialized
INFO - 2023-05-17 03:38:31 --> Language Class Initialized
INFO - 2023-05-17 03:38:31 --> Loader Class Initialized
INFO - 2023-05-17 03:38:31 --> Controller Class Initialized
DEBUG - 2023-05-17 03:38:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:38:31 --> Database Driver Class Initialized
INFO - 2023-05-17 03:38:31 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:38:31 --> Final output sent to browser
DEBUG - 2023-05-17 03:38:31 --> Total execution time: 0.0176
INFO - 2023-05-17 03:38:31 --> Config Class Initialized
INFO - 2023-05-17 03:38:31 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:38:31 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:38:31 --> Utf8 Class Initialized
INFO - 2023-05-17 03:38:31 --> URI Class Initialized
INFO - 2023-05-17 03:38:31 --> Router Class Initialized
INFO - 2023-05-17 03:38:31 --> Output Class Initialized
INFO - 2023-05-17 03:38:31 --> Security Class Initialized
DEBUG - 2023-05-17 03:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:38:31 --> Input Class Initialized
INFO - 2023-05-17 03:38:31 --> Language Class Initialized
INFO - 2023-05-17 03:38:31 --> Loader Class Initialized
INFO - 2023-05-17 03:38:31 --> Controller Class Initialized
DEBUG - 2023-05-17 03:38:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:38:31 --> Database Driver Class Initialized
INFO - 2023-05-17 03:38:31 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:38:31 --> Final output sent to browser
DEBUG - 2023-05-17 03:38:31 --> Total execution time: 0.0159
INFO - 2023-05-17 03:38:32 --> Config Class Initialized
INFO - 2023-05-17 03:38:32 --> Config Class Initialized
INFO - 2023-05-17 03:38:32 --> Hooks Class Initialized
INFO - 2023-05-17 03:38:32 --> Hooks Class Initialized
INFO - 2023-05-17 03:38:32 --> Config Class Initialized
DEBUG - 2023-05-17 03:38:32 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:38:32 --> Hooks Class Initialized
INFO - 2023-05-17 03:38:32 --> Utf8 Class Initialized
DEBUG - 2023-05-17 03:38:32 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:38:32 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:38:32 --> URI Class Initialized
INFO - 2023-05-17 03:38:32 --> Utf8 Class Initialized
INFO - 2023-05-17 03:38:32 --> Utf8 Class Initialized
INFO - 2023-05-17 03:38:32 --> Router Class Initialized
INFO - 2023-05-17 03:38:32 --> URI Class Initialized
INFO - 2023-05-17 03:38:32 --> URI Class Initialized
INFO - 2023-05-17 03:38:32 --> Output Class Initialized
INFO - 2023-05-17 03:38:32 --> Router Class Initialized
INFO - 2023-05-17 03:38:32 --> Router Class Initialized
INFO - 2023-05-17 03:38:32 --> Security Class Initialized
INFO - 2023-05-17 03:38:32 --> Output Class Initialized
DEBUG - 2023-05-17 03:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:38:32 --> Output Class Initialized
INFO - 2023-05-17 03:38:32 --> Input Class Initialized
INFO - 2023-05-17 03:38:32 --> Security Class Initialized
INFO - 2023-05-17 03:38:32 --> Security Class Initialized
INFO - 2023-05-17 03:38:32 --> Language Class Initialized
DEBUG - 2023-05-17 03:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 03:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:38:32 --> Input Class Initialized
INFO - 2023-05-17 03:38:32 --> Input Class Initialized
INFO - 2023-05-17 03:38:32 --> Language Class Initialized
INFO - 2023-05-17 03:38:32 --> Language Class Initialized
INFO - 2023-05-17 03:38:32 --> Loader Class Initialized
INFO - 2023-05-17 03:38:32 --> Loader Class Initialized
INFO - 2023-05-17 03:38:32 --> Loader Class Initialized
INFO - 2023-05-17 03:38:32 --> Controller Class Initialized
INFO - 2023-05-17 03:38:32 --> Controller Class Initialized
DEBUG - 2023-05-17 03:38:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 03:38:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:38:32 --> Controller Class Initialized
INFO - 2023-05-17 03:38:32 --> Database Driver Class Initialized
DEBUG - 2023-05-17 03:38:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:38:32 --> Database Driver Class Initialized
INFO - 2023-05-17 03:38:32 --> Database Driver Class Initialized
INFO - 2023-05-17 03:38:32 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:38:32 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:38:32 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:38:32 --> Final output sent to browser
DEBUG - 2023-05-17 03:38:32 --> Total execution time: 0.0175
INFO - 2023-05-17 03:38:32 --> Final output sent to browser
INFO - 2023-05-17 03:38:32 --> Final output sent to browser
DEBUG - 2023-05-17 03:38:32 --> Total execution time: 0.0194
DEBUG - 2023-05-17 03:38:32 --> Total execution time: 0.0191
INFO - 2023-05-17 03:38:32 --> Config Class Initialized
INFO - 2023-05-17 03:38:32 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:38:32 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:38:32 --> Utf8 Class Initialized
INFO - 2023-05-17 03:38:32 --> URI Class Initialized
INFO - 2023-05-17 03:38:32 --> Router Class Initialized
INFO - 2023-05-17 03:38:32 --> Output Class Initialized
INFO - 2023-05-17 03:38:32 --> Security Class Initialized
DEBUG - 2023-05-17 03:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:38:32 --> Config Class Initialized
INFO - 2023-05-17 03:38:32 --> Config Class Initialized
INFO - 2023-05-17 03:38:32 --> Input Class Initialized
INFO - 2023-05-17 03:38:32 --> Hooks Class Initialized
INFO - 2023-05-17 03:38:32 --> Hooks Class Initialized
INFO - 2023-05-17 03:38:32 --> Language Class Initialized
DEBUG - 2023-05-17 03:38:32 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:38:32 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:38:32 --> Utf8 Class Initialized
INFO - 2023-05-17 03:38:32 --> Utf8 Class Initialized
INFO - 2023-05-17 03:38:32 --> Loader Class Initialized
INFO - 2023-05-17 03:38:32 --> URI Class Initialized
INFO - 2023-05-17 03:38:32 --> URI Class Initialized
INFO - 2023-05-17 03:38:32 --> Controller Class Initialized
INFO - 2023-05-17 03:38:32 --> Router Class Initialized
INFO - 2023-05-17 03:38:32 --> Router Class Initialized
DEBUG - 2023-05-17 03:38:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:38:32 --> Output Class Initialized
INFO - 2023-05-17 03:38:32 --> Output Class Initialized
INFO - 2023-05-17 03:38:32 --> Security Class Initialized
INFO - 2023-05-17 03:38:32 --> Security Class Initialized
INFO - 2023-05-17 03:38:32 --> Database Driver Class Initialized
DEBUG - 2023-05-17 03:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 03:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:38:32 --> Input Class Initialized
INFO - 2023-05-17 03:38:32 --> Input Class Initialized
INFO - 2023-05-17 03:38:32 --> Language Class Initialized
INFO - 2023-05-17 03:38:32 --> Language Class Initialized
INFO - 2023-05-17 03:38:32 --> Loader Class Initialized
INFO - 2023-05-17 03:38:32 --> Loader Class Initialized
INFO - 2023-05-17 03:38:32 --> Controller Class Initialized
INFO - 2023-05-17 03:38:32 --> Controller Class Initialized
DEBUG - 2023-05-17 03:38:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 03:38:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:38:32 --> Database Driver Class Initialized
INFO - 2023-05-17 03:38:32 --> Database Driver Class Initialized
INFO - 2023-05-17 03:38:32 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:38:32 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:38:32 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:38:32 --> Final output sent to browser
DEBUG - 2023-05-17 03:38:32 --> Total execution time: 0.0185
INFO - 2023-05-17 03:38:32 --> Final output sent to browser
DEBUG - 2023-05-17 03:38:32 --> Total execution time: 0.0191
INFO - 2023-05-17 03:38:32 --> Final output sent to browser
INFO - 2023-05-17 03:38:32 --> Config Class Initialized
DEBUG - 2023-05-17 03:38:32 --> Total execution time: 0.0246
INFO - 2023-05-17 03:38:32 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:38:32 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:38:32 --> Utf8 Class Initialized
INFO - 2023-05-17 03:38:32 --> URI Class Initialized
INFO - 2023-05-17 03:38:32 --> Router Class Initialized
INFO - 2023-05-17 03:38:32 --> Output Class Initialized
INFO - 2023-05-17 03:38:32 --> Security Class Initialized
DEBUG - 2023-05-17 03:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:38:32 --> Input Class Initialized
INFO - 2023-05-17 03:38:32 --> Language Class Initialized
INFO - 2023-05-17 03:38:32 --> Loader Class Initialized
INFO - 2023-05-17 03:38:32 --> Controller Class Initialized
DEBUG - 2023-05-17 03:38:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:38:32 --> Database Driver Class Initialized
INFO - 2023-05-17 03:38:32 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:38:33 --> Config Class Initialized
INFO - 2023-05-17 03:38:33 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:38:33 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:38:33 --> Utf8 Class Initialized
INFO - 2023-05-17 03:38:33 --> URI Class Initialized
INFO - 2023-05-17 03:38:33 --> Router Class Initialized
INFO - 2023-05-17 03:38:33 --> Output Class Initialized
INFO - 2023-05-17 03:38:33 --> Security Class Initialized
DEBUG - 2023-05-17 03:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:38:33 --> Input Class Initialized
INFO - 2023-05-17 03:38:33 --> Language Class Initialized
INFO - 2023-05-17 03:38:33 --> Loader Class Initialized
INFO - 2023-05-17 03:38:33 --> Controller Class Initialized
DEBUG - 2023-05-17 03:38:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:38:33 --> Database Driver Class Initialized
INFO - 2023-05-17 03:38:33 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:54:02 --> Config Class Initialized
INFO - 2023-05-17 03:54:02 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:54:02 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:54:02 --> Utf8 Class Initialized
INFO - 2023-05-17 03:54:02 --> URI Class Initialized
INFO - 2023-05-17 03:54:02 --> Router Class Initialized
INFO - 2023-05-17 03:54:02 --> Output Class Initialized
INFO - 2023-05-17 03:54:02 --> Security Class Initialized
DEBUG - 2023-05-17 03:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:54:02 --> Input Class Initialized
INFO - 2023-05-17 03:54:02 --> Language Class Initialized
INFO - 2023-05-17 03:54:02 --> Loader Class Initialized
INFO - 2023-05-17 03:54:02 --> Controller Class Initialized
DEBUG - 2023-05-17 03:54:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:54:02 --> Database Driver Class Initialized
INFO - 2023-05-17 03:54:02 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:54:02 --> Final output sent to browser
DEBUG - 2023-05-17 03:54:02 --> Total execution time: 0.0153
INFO - 2023-05-17 03:54:02 --> Config Class Initialized
INFO - 2023-05-17 03:54:02 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:54:02 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:54:02 --> Utf8 Class Initialized
INFO - 2023-05-17 03:54:02 --> URI Class Initialized
INFO - 2023-05-17 03:54:02 --> Router Class Initialized
INFO - 2023-05-17 03:54:02 --> Output Class Initialized
INFO - 2023-05-17 03:54:02 --> Security Class Initialized
DEBUG - 2023-05-17 03:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:54:02 --> Input Class Initialized
INFO - 2023-05-17 03:54:02 --> Language Class Initialized
INFO - 2023-05-17 03:54:02 --> Loader Class Initialized
INFO - 2023-05-17 03:54:02 --> Controller Class Initialized
DEBUG - 2023-05-17 03:54:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:54:02 --> Database Driver Class Initialized
INFO - 2023-05-17 03:54:02 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:54:02 --> Final output sent to browser
DEBUG - 2023-05-17 03:54:02 --> Total execution time: 0.0156
INFO - 2023-05-17 03:54:03 --> Config Class Initialized
INFO - 2023-05-17 03:54:03 --> Config Class Initialized
INFO - 2023-05-17 03:54:03 --> Config Class Initialized
INFO - 2023-05-17 03:54:03 --> Hooks Class Initialized
INFO - 2023-05-17 03:54:03 --> Hooks Class Initialized
INFO - 2023-05-17 03:54:03 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:54:03 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:54:03 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:54:03 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:54:03 --> Utf8 Class Initialized
INFO - 2023-05-17 03:54:03 --> Utf8 Class Initialized
INFO - 2023-05-17 03:54:03 --> Utf8 Class Initialized
INFO - 2023-05-17 03:54:03 --> URI Class Initialized
INFO - 2023-05-17 03:54:03 --> URI Class Initialized
INFO - 2023-05-17 03:54:03 --> Router Class Initialized
INFO - 2023-05-17 03:54:03 --> Router Class Initialized
INFO - 2023-05-17 03:54:03 --> URI Class Initialized
INFO - 2023-05-17 03:54:03 --> Output Class Initialized
INFO - 2023-05-17 03:54:03 --> Security Class Initialized
INFO - 2023-05-17 03:54:03 --> Router Class Initialized
INFO - 2023-05-17 03:54:03 --> Output Class Initialized
DEBUG - 2023-05-17 03:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:54:03 --> Output Class Initialized
INFO - 2023-05-17 03:54:03 --> Input Class Initialized
INFO - 2023-05-17 03:54:03 --> Security Class Initialized
INFO - 2023-05-17 03:54:03 --> Security Class Initialized
INFO - 2023-05-17 03:54:03 --> Language Class Initialized
DEBUG - 2023-05-17 03:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 03:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:54:03 --> Input Class Initialized
INFO - 2023-05-17 03:54:03 --> Loader Class Initialized
INFO - 2023-05-17 03:54:03 --> Input Class Initialized
INFO - 2023-05-17 03:54:03 --> Language Class Initialized
INFO - 2023-05-17 03:54:03 --> Controller Class Initialized
INFO - 2023-05-17 03:54:03 --> Language Class Initialized
DEBUG - 2023-05-17 03:54:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:54:03 --> Loader Class Initialized
INFO - 2023-05-17 03:54:03 --> Loader Class Initialized
INFO - 2023-05-17 03:54:03 --> Database Driver Class Initialized
INFO - 2023-05-17 03:54:03 --> Controller Class Initialized
INFO - 2023-05-17 03:54:03 --> Controller Class Initialized
DEBUG - 2023-05-17 03:54:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 03:54:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:54:03 --> Database Driver Class Initialized
INFO - 2023-05-17 03:54:03 --> Database Driver Class Initialized
INFO - 2023-05-17 03:54:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:54:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:54:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:54:03 --> Final output sent to browser
DEBUG - 2023-05-17 03:54:03 --> Total execution time: 0.0156
INFO - 2023-05-17 03:54:03 --> Final output sent to browser
INFO - 2023-05-17 03:54:03 --> Final output sent to browser
DEBUG - 2023-05-17 03:54:03 --> Total execution time: 0.0171
DEBUG - 2023-05-17 03:54:03 --> Total execution time: 0.0172
INFO - 2023-05-17 03:54:03 --> Config Class Initialized
INFO - 2023-05-17 03:54:03 --> Config Class Initialized
INFO - 2023-05-17 03:54:03 --> Config Class Initialized
INFO - 2023-05-17 03:54:03 --> Hooks Class Initialized
INFO - 2023-05-17 03:54:03 --> Hooks Class Initialized
INFO - 2023-05-17 03:54:03 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:54:03 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:54:03 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 03:54:03 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:54:03 --> Utf8 Class Initialized
INFO - 2023-05-17 03:54:03 --> Utf8 Class Initialized
INFO - 2023-05-17 03:54:03 --> Utf8 Class Initialized
INFO - 2023-05-17 03:54:03 --> URI Class Initialized
INFO - 2023-05-17 03:54:03 --> URI Class Initialized
INFO - 2023-05-17 03:54:03 --> URI Class Initialized
INFO - 2023-05-17 03:54:03 --> Router Class Initialized
INFO - 2023-05-17 03:54:03 --> Router Class Initialized
INFO - 2023-05-17 03:54:03 --> Router Class Initialized
INFO - 2023-05-17 03:54:03 --> Output Class Initialized
INFO - 2023-05-17 03:54:03 --> Output Class Initialized
INFO - 2023-05-17 03:54:03 --> Output Class Initialized
INFO - 2023-05-17 03:54:03 --> Security Class Initialized
INFO - 2023-05-17 03:54:03 --> Security Class Initialized
INFO - 2023-05-17 03:54:03 --> Security Class Initialized
DEBUG - 2023-05-17 03:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 03:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:54:03 --> Input Class Initialized
DEBUG - 2023-05-17 03:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:54:03 --> Language Class Initialized
INFO - 2023-05-17 03:54:03 --> Input Class Initialized
INFO - 2023-05-17 03:54:03 --> Input Class Initialized
INFO - 2023-05-17 03:54:03 --> Language Class Initialized
INFO - 2023-05-17 03:54:03 --> Language Class Initialized
INFO - 2023-05-17 03:54:03 --> Loader Class Initialized
INFO - 2023-05-17 03:54:03 --> Loader Class Initialized
INFO - 2023-05-17 03:54:03 --> Loader Class Initialized
INFO - 2023-05-17 03:54:03 --> Controller Class Initialized
INFO - 2023-05-17 03:54:03 --> Controller Class Initialized
INFO - 2023-05-17 03:54:03 --> Controller Class Initialized
DEBUG - 2023-05-17 03:54:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 03:54:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 03:54:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:54:03 --> Database Driver Class Initialized
INFO - 2023-05-17 03:54:03 --> Database Driver Class Initialized
INFO - 2023-05-17 03:54:03 --> Database Driver Class Initialized
INFO - 2023-05-17 03:54:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:54:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:54:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:54:03 --> Final output sent to browser
DEBUG - 2023-05-17 03:54:03 --> Total execution time: 0.0504
INFO - 2023-05-17 03:54:03 --> Final output sent to browser
DEBUG - 2023-05-17 03:54:03 --> Total execution time: 0.0507
INFO - 2023-05-17 03:54:03 --> Final output sent to browser
INFO - 2023-05-17 03:54:03 --> Config Class Initialized
INFO - 2023-05-17 03:54:03 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:54:03 --> Total execution time: 0.0583
DEBUG - 2023-05-17 03:54:03 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:54:03 --> Utf8 Class Initialized
INFO - 2023-05-17 03:54:03 --> URI Class Initialized
INFO - 2023-05-17 03:54:03 --> Router Class Initialized
INFO - 2023-05-17 03:54:03 --> Output Class Initialized
INFO - 2023-05-17 03:54:03 --> Security Class Initialized
DEBUG - 2023-05-17 03:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:54:03 --> Input Class Initialized
INFO - 2023-05-17 03:54:03 --> Language Class Initialized
INFO - 2023-05-17 03:54:03 --> Loader Class Initialized
INFO - 2023-05-17 03:54:03 --> Controller Class Initialized
DEBUG - 2023-05-17 03:54:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:54:03 --> Database Driver Class Initialized
INFO - 2023-05-17 03:54:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:54:04 --> Config Class Initialized
INFO - 2023-05-17 03:54:04 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:54:04 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:54:04 --> Utf8 Class Initialized
INFO - 2023-05-17 03:54:04 --> URI Class Initialized
INFO - 2023-05-17 03:54:04 --> Router Class Initialized
INFO - 2023-05-17 03:54:04 --> Output Class Initialized
INFO - 2023-05-17 03:54:04 --> Security Class Initialized
DEBUG - 2023-05-17 03:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:54:04 --> Input Class Initialized
INFO - 2023-05-17 03:54:04 --> Language Class Initialized
INFO - 2023-05-17 03:54:04 --> Loader Class Initialized
INFO - 2023-05-17 03:54:04 --> Controller Class Initialized
DEBUG - 2023-05-17 03:54:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:54:04 --> Database Driver Class Initialized
INFO - 2023-05-17 03:54:04 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:55:50 --> Config Class Initialized
INFO - 2023-05-17 03:55:50 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:55:50 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:55:50 --> Utf8 Class Initialized
INFO - 2023-05-17 03:55:50 --> URI Class Initialized
INFO - 2023-05-17 03:55:50 --> Router Class Initialized
INFO - 2023-05-17 03:55:50 --> Output Class Initialized
INFO - 2023-05-17 03:55:50 --> Security Class Initialized
DEBUG - 2023-05-17 03:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:55:50 --> Input Class Initialized
INFO - 2023-05-17 03:55:50 --> Language Class Initialized
INFO - 2023-05-17 03:55:50 --> Loader Class Initialized
INFO - 2023-05-17 03:55:50 --> Controller Class Initialized
DEBUG - 2023-05-17 03:55:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:55:50 --> Database Driver Class Initialized
INFO - 2023-05-17 03:55:50 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:55:50 --> Final output sent to browser
DEBUG - 2023-05-17 03:55:50 --> Total execution time: 0.1106
INFO - 2023-05-17 03:55:50 --> Config Class Initialized
INFO - 2023-05-17 03:55:50 --> Hooks Class Initialized
DEBUG - 2023-05-17 03:55:50 --> UTF-8 Support Enabled
INFO - 2023-05-17 03:55:50 --> Utf8 Class Initialized
INFO - 2023-05-17 03:55:50 --> URI Class Initialized
INFO - 2023-05-17 03:55:50 --> Router Class Initialized
INFO - 2023-05-17 03:55:50 --> Output Class Initialized
INFO - 2023-05-17 03:55:50 --> Security Class Initialized
DEBUG - 2023-05-17 03:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 03:55:50 --> Input Class Initialized
INFO - 2023-05-17 03:55:50 --> Language Class Initialized
INFO - 2023-05-17 03:55:50 --> Loader Class Initialized
INFO - 2023-05-17 03:55:50 --> Controller Class Initialized
DEBUG - 2023-05-17 03:55:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 03:55:50 --> Database Driver Class Initialized
INFO - 2023-05-17 03:55:50 --> Model "Cluster_model" initialized
INFO - 2023-05-17 03:55:50 --> Final output sent to browser
DEBUG - 2023-05-17 03:55:50 --> Total execution time: 0.1531
INFO - 2023-05-17 05:33:54 --> Config Class Initialized
INFO - 2023-05-17 05:33:54 --> Hooks Class Initialized
DEBUG - 2023-05-17 05:33:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 05:33:54 --> Utf8 Class Initialized
INFO - 2023-05-17 05:33:54 --> URI Class Initialized
INFO - 2023-05-17 05:33:54 --> Router Class Initialized
INFO - 2023-05-17 05:33:54 --> Output Class Initialized
INFO - 2023-05-17 05:33:54 --> Security Class Initialized
DEBUG - 2023-05-17 05:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 05:33:54 --> Input Class Initialized
INFO - 2023-05-17 05:33:54 --> Language Class Initialized
INFO - 2023-05-17 05:33:54 --> Loader Class Initialized
INFO - 2023-05-17 05:33:54 --> Controller Class Initialized
DEBUG - 2023-05-17 05:33:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 05:33:54 --> Database Driver Class Initialized
INFO - 2023-05-17 05:33:54 --> Model "Cluster_model" initialized
INFO - 2023-05-17 05:33:54 --> Final output sent to browser
DEBUG - 2023-05-17 05:33:54 --> Total execution time: 0.0196
INFO - 2023-05-17 05:33:54 --> Config Class Initialized
INFO - 2023-05-17 05:33:54 --> Hooks Class Initialized
DEBUG - 2023-05-17 05:33:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 05:33:54 --> Utf8 Class Initialized
INFO - 2023-05-17 05:33:54 --> URI Class Initialized
INFO - 2023-05-17 05:33:54 --> Router Class Initialized
INFO - 2023-05-17 05:33:54 --> Output Class Initialized
INFO - 2023-05-17 05:33:54 --> Security Class Initialized
DEBUG - 2023-05-17 05:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 05:33:54 --> Input Class Initialized
INFO - 2023-05-17 05:33:54 --> Language Class Initialized
INFO - 2023-05-17 05:33:54 --> Loader Class Initialized
INFO - 2023-05-17 05:33:54 --> Controller Class Initialized
DEBUG - 2023-05-17 05:33:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 05:33:54 --> Database Driver Class Initialized
INFO - 2023-05-17 05:33:54 --> Model "Cluster_model" initialized
INFO - 2023-05-17 05:33:54 --> Final output sent to browser
DEBUG - 2023-05-17 05:33:54 --> Total execution time: 0.0628
INFO - 2023-05-17 05:33:56 --> Config Class Initialized
INFO - 2023-05-17 05:33:56 --> Config Class Initialized
INFO - 2023-05-17 05:33:56 --> Hooks Class Initialized
INFO - 2023-05-17 05:33:56 --> Hooks Class Initialized
DEBUG - 2023-05-17 05:33:56 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 05:33:56 --> UTF-8 Support Enabled
INFO - 2023-05-17 05:33:56 --> Utf8 Class Initialized
INFO - 2023-05-17 05:33:56 --> Utf8 Class Initialized
INFO - 2023-05-17 05:33:56 --> URI Class Initialized
INFO - 2023-05-17 05:33:56 --> URI Class Initialized
INFO - 2023-05-17 05:33:56 --> Router Class Initialized
INFO - 2023-05-17 05:33:56 --> Router Class Initialized
INFO - 2023-05-17 05:33:56 --> Output Class Initialized
INFO - 2023-05-17 05:33:56 --> Output Class Initialized
INFO - 2023-05-17 05:33:56 --> Security Class Initialized
INFO - 2023-05-17 05:33:56 --> Security Class Initialized
DEBUG - 2023-05-17 05:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 05:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 05:33:56 --> Input Class Initialized
INFO - 2023-05-17 05:33:56 --> Input Class Initialized
INFO - 2023-05-17 05:33:56 --> Language Class Initialized
INFO - 2023-05-17 05:33:56 --> Language Class Initialized
INFO - 2023-05-17 05:33:56 --> Loader Class Initialized
INFO - 2023-05-17 05:33:56 --> Controller Class Initialized
DEBUG - 2023-05-17 05:33:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 05:33:56 --> Database Driver Class Initialized
INFO - 2023-05-17 05:33:56 --> Loader Class Initialized
INFO - 2023-05-17 05:33:56 --> Controller Class Initialized
DEBUG - 2023-05-17 05:33:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 05:33:56 --> Final output sent to browser
DEBUG - 2023-05-17 05:33:56 --> Total execution time: 0.0094
INFO - 2023-05-17 05:33:56 --> Config Class Initialized
INFO - 2023-05-17 05:33:56 --> Model "Cluster_model" initialized
INFO - 2023-05-17 05:33:56 --> Hooks Class Initialized
DEBUG - 2023-05-17 05:33:56 --> UTF-8 Support Enabled
INFO - 2023-05-17 05:33:56 --> Utf8 Class Initialized
INFO - 2023-05-17 05:33:56 --> URI Class Initialized
INFO - 2023-05-17 05:33:56 --> Router Class Initialized
INFO - 2023-05-17 05:33:56 --> Output Class Initialized
INFO - 2023-05-17 05:33:56 --> Security Class Initialized
DEBUG - 2023-05-17 05:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 05:33:56 --> Input Class Initialized
INFO - 2023-05-17 05:33:56 --> Language Class Initialized
INFO - 2023-05-17 05:33:56 --> Loader Class Initialized
INFO - 2023-05-17 05:33:56 --> Controller Class Initialized
DEBUG - 2023-05-17 05:33:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 05:33:56 --> Database Driver Class Initialized
INFO - 2023-05-17 05:33:56 --> Final output sent to browser
DEBUG - 2023-05-17 05:33:56 --> Total execution time: 0.0604
INFO - 2023-05-17 05:33:56 --> Config Class Initialized
INFO - 2023-05-17 05:33:56 --> Hooks Class Initialized
DEBUG - 2023-05-17 05:33:56 --> UTF-8 Support Enabled
INFO - 2023-05-17 05:33:56 --> Utf8 Class Initialized
INFO - 2023-05-17 05:33:56 --> URI Class Initialized
INFO - 2023-05-17 05:33:56 --> Router Class Initialized
INFO - 2023-05-17 05:33:56 --> Output Class Initialized
INFO - 2023-05-17 05:33:56 --> Security Class Initialized
DEBUG - 2023-05-17 05:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 05:33:56 --> Input Class Initialized
INFO - 2023-05-17 05:33:56 --> Language Class Initialized
INFO - 2023-05-17 05:33:56 --> Loader Class Initialized
INFO - 2023-05-17 05:33:56 --> Controller Class Initialized
DEBUG - 2023-05-17 05:33:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 05:33:56 --> Database Driver Class Initialized
INFO - 2023-05-17 05:33:56 --> Model "Login_model" initialized
INFO - 2023-05-17 05:33:56 --> Database Driver Class Initialized
INFO - 2023-05-17 05:33:56 --> Model "Cluster_model" initialized
INFO - 2023-05-17 05:33:56 --> Model "Cluster_model" initialized
INFO - 2023-05-17 05:33:56 --> Final output sent to browser
DEBUG - 2023-05-17 05:33:56 --> Total execution time: 0.0650
INFO - 2023-05-17 05:33:56 --> Final output sent to browser
DEBUG - 2023-05-17 05:33:56 --> Total execution time: 0.0207
INFO - 2023-05-17 05:33:58 --> Config Class Initialized
INFO - 2023-05-17 05:33:58 --> Config Class Initialized
INFO - 2023-05-17 05:33:58 --> Hooks Class Initialized
INFO - 2023-05-17 05:33:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 05:33:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 05:33:58 --> Utf8 Class Initialized
DEBUG - 2023-05-17 05:33:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 05:33:58 --> URI Class Initialized
INFO - 2023-05-17 05:33:58 --> Utf8 Class Initialized
INFO - 2023-05-17 05:33:58 --> Router Class Initialized
INFO - 2023-05-17 05:33:58 --> URI Class Initialized
INFO - 2023-05-17 05:33:58 --> Output Class Initialized
INFO - 2023-05-17 05:33:58 --> Router Class Initialized
INFO - 2023-05-17 05:33:58 --> Security Class Initialized
INFO - 2023-05-17 05:33:58 --> Output Class Initialized
DEBUG - 2023-05-17 05:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 05:33:58 --> Security Class Initialized
INFO - 2023-05-17 05:33:58 --> Input Class Initialized
DEBUG - 2023-05-17 05:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 05:33:58 --> Language Class Initialized
INFO - 2023-05-17 05:33:58 --> Input Class Initialized
INFO - 2023-05-17 05:33:58 --> Language Class Initialized
INFO - 2023-05-17 05:33:58 --> Loader Class Initialized
INFO - 2023-05-17 05:33:58 --> Loader Class Initialized
INFO - 2023-05-17 05:33:58 --> Controller Class Initialized
INFO - 2023-05-17 05:33:58 --> Controller Class Initialized
DEBUG - 2023-05-17 05:33:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 05:33:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 05:33:58 --> Database Driver Class Initialized
INFO - 2023-05-17 05:33:58 --> Database Driver Class Initialized
INFO - 2023-05-17 05:33:58 --> Model "Cluster_model" initialized
INFO - 2023-05-17 05:33:58 --> Model "Cluster_model" initialized
INFO - 2023-05-17 05:33:58 --> Final output sent to browser
INFO - 2023-05-17 05:33:58 --> Database Driver Class Initialized
DEBUG - 2023-05-17 05:33:58 --> Total execution time: 0.0229
INFO - 2023-05-17 05:33:58 --> Model "Login_model" initialized
INFO - 2023-05-17 05:33:58 --> Config Class Initialized
INFO - 2023-05-17 05:33:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 05:33:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 05:33:58 --> Utf8 Class Initialized
INFO - 2023-05-17 05:33:58 --> URI Class Initialized
INFO - 2023-05-17 05:33:58 --> Router Class Initialized
INFO - 2023-05-17 05:33:58 --> Output Class Initialized
INFO - 2023-05-17 05:33:58 --> Security Class Initialized
DEBUG - 2023-05-17 05:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 05:33:58 --> Input Class Initialized
INFO - 2023-05-17 05:33:58 --> Language Class Initialized
INFO - 2023-05-17 05:33:58 --> Loader Class Initialized
INFO - 2023-05-17 05:33:58 --> Controller Class Initialized
DEBUG - 2023-05-17 05:33:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 05:33:58 --> Database Driver Class Initialized
INFO - 2023-05-17 05:33:58 --> Final output sent to browser
DEBUG - 2023-05-17 05:33:58 --> Total execution time: 0.3816
INFO - 2023-05-17 05:33:58 --> Config Class Initialized
INFO - 2023-05-17 05:33:58 --> Model "Cluster_model" initialized
INFO - 2023-05-17 05:33:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 05:33:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 05:33:58 --> Utf8 Class Initialized
INFO - 2023-05-17 05:33:58 --> URI Class Initialized
INFO - 2023-05-17 05:33:58 --> Router Class Initialized
INFO - 2023-05-17 05:33:58 --> Final output sent to browser
INFO - 2023-05-17 05:33:58 --> Output Class Initialized
DEBUG - 2023-05-17 05:33:58 --> Total execution time: 0.2772
INFO - 2023-05-17 05:33:58 --> Security Class Initialized
DEBUG - 2023-05-17 05:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 05:33:58 --> Input Class Initialized
INFO - 2023-05-17 05:33:58 --> Language Class Initialized
INFO - 2023-05-17 05:33:58 --> Loader Class Initialized
INFO - 2023-05-17 05:33:58 --> Controller Class Initialized
DEBUG - 2023-05-17 05:33:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 05:33:58 --> Database Driver Class Initialized
INFO - 2023-05-17 05:33:58 --> Model "Cluster_model" initialized
INFO - 2023-05-17 05:33:58 --> Database Driver Class Initialized
INFO - 2023-05-17 05:33:58 --> Model "Login_model" initialized
INFO - 2023-05-17 05:33:58 --> Final output sent to browser
DEBUG - 2023-05-17 05:33:58 --> Total execution time: 0.3088
INFO - 2023-05-17 06:12:54 --> Config Class Initialized
INFO - 2023-05-17 06:12:54 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:12:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:12:54 --> Utf8 Class Initialized
INFO - 2023-05-17 06:12:54 --> URI Class Initialized
INFO - 2023-05-17 06:12:54 --> Router Class Initialized
INFO - 2023-05-17 06:12:54 --> Output Class Initialized
INFO - 2023-05-17 06:12:54 --> Security Class Initialized
DEBUG - 2023-05-17 06:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:12:54 --> Input Class Initialized
INFO - 2023-05-17 06:12:54 --> Language Class Initialized
INFO - 2023-05-17 06:12:54 --> Loader Class Initialized
INFO - 2023-05-17 06:12:54 --> Controller Class Initialized
INFO - 2023-05-17 06:12:54 --> Helper loaded: form_helper
INFO - 2023-05-17 06:12:54 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:12:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:12:54 --> Model "Change_model" initialized
INFO - 2023-05-17 06:12:54 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:12:54 --> Final output sent to browser
DEBUG - 2023-05-17 06:12:54 --> Total execution time: 0.0331
INFO - 2023-05-17 06:12:54 --> Config Class Initialized
INFO - 2023-05-17 06:12:54 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:12:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:12:54 --> Utf8 Class Initialized
INFO - 2023-05-17 06:12:54 --> URI Class Initialized
INFO - 2023-05-17 06:12:54 --> Router Class Initialized
INFO - 2023-05-17 06:12:54 --> Output Class Initialized
INFO - 2023-05-17 06:12:54 --> Security Class Initialized
DEBUG - 2023-05-17 06:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:12:54 --> Input Class Initialized
INFO - 2023-05-17 06:12:54 --> Language Class Initialized
INFO - 2023-05-17 06:12:54 --> Loader Class Initialized
INFO - 2023-05-17 06:12:54 --> Controller Class Initialized
INFO - 2023-05-17 06:12:54 --> Helper loaded: form_helper
INFO - 2023-05-17 06:12:54 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:12:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:12:54 --> Final output sent to browser
DEBUG - 2023-05-17 06:12:54 --> Total execution time: 0.0444
INFO - 2023-05-17 06:12:54 --> Config Class Initialized
INFO - 2023-05-17 06:12:54 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:12:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:12:54 --> Utf8 Class Initialized
INFO - 2023-05-17 06:12:54 --> URI Class Initialized
INFO - 2023-05-17 06:12:54 --> Router Class Initialized
INFO - 2023-05-17 06:12:54 --> Output Class Initialized
INFO - 2023-05-17 06:12:54 --> Security Class Initialized
DEBUG - 2023-05-17 06:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:12:54 --> Input Class Initialized
INFO - 2023-05-17 06:12:54 --> Language Class Initialized
INFO - 2023-05-17 06:12:54 --> Loader Class Initialized
INFO - 2023-05-17 06:12:54 --> Controller Class Initialized
INFO - 2023-05-17 06:12:54 --> Helper loaded: form_helper
INFO - 2023-05-17 06:12:54 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:12:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:12:54 --> Database Driver Class Initialized
INFO - 2023-05-17 06:12:54 --> Model "Login_model" initialized
INFO - 2023-05-17 06:12:54 --> Final output sent to browser
DEBUG - 2023-05-17 06:12:54 --> Total execution time: 0.0137
INFO - 2023-05-17 06:13:02 --> Config Class Initialized
INFO - 2023-05-17 06:13:02 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:13:02 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:13:02 --> Utf8 Class Initialized
INFO - 2023-05-17 06:13:02 --> URI Class Initialized
INFO - 2023-05-17 06:13:02 --> Router Class Initialized
INFO - 2023-05-17 06:13:02 --> Output Class Initialized
INFO - 2023-05-17 06:13:02 --> Security Class Initialized
DEBUG - 2023-05-17 06:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:13:02 --> Input Class Initialized
INFO - 2023-05-17 06:13:02 --> Language Class Initialized
INFO - 2023-05-17 06:13:02 --> Loader Class Initialized
INFO - 2023-05-17 06:13:02 --> Controller Class Initialized
INFO - 2023-05-17 06:13:02 --> Helper loaded: form_helper
INFO - 2023-05-17 06:13:02 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:13:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:13:02 --> Model "Change_model" initialized
INFO - 2023-05-17 06:13:02 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:13:02 --> Final output sent to browser
DEBUG - 2023-05-17 06:13:02 --> Total execution time: 0.0248
INFO - 2023-05-17 06:13:02 --> Config Class Initialized
INFO - 2023-05-17 06:13:02 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:13:02 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:13:02 --> Utf8 Class Initialized
INFO - 2023-05-17 06:13:02 --> URI Class Initialized
INFO - 2023-05-17 06:13:02 --> Router Class Initialized
INFO - 2023-05-17 06:13:02 --> Output Class Initialized
INFO - 2023-05-17 06:13:02 --> Security Class Initialized
DEBUG - 2023-05-17 06:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:13:02 --> Input Class Initialized
INFO - 2023-05-17 06:13:02 --> Language Class Initialized
INFO - 2023-05-17 06:13:02 --> Loader Class Initialized
INFO - 2023-05-17 06:13:02 --> Controller Class Initialized
INFO - 2023-05-17 06:13:02 --> Helper loaded: form_helper
INFO - 2023-05-17 06:13:02 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:13:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:13:02 --> Final output sent to browser
DEBUG - 2023-05-17 06:13:02 --> Total execution time: 0.0470
INFO - 2023-05-17 06:13:02 --> Config Class Initialized
INFO - 2023-05-17 06:13:02 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:13:02 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:13:02 --> Utf8 Class Initialized
INFO - 2023-05-17 06:13:02 --> URI Class Initialized
INFO - 2023-05-17 06:13:02 --> Router Class Initialized
INFO - 2023-05-17 06:13:02 --> Output Class Initialized
INFO - 2023-05-17 06:13:02 --> Security Class Initialized
DEBUG - 2023-05-17 06:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:13:02 --> Input Class Initialized
INFO - 2023-05-17 06:13:02 --> Language Class Initialized
INFO - 2023-05-17 06:13:02 --> Loader Class Initialized
INFO - 2023-05-17 06:13:02 --> Controller Class Initialized
INFO - 2023-05-17 06:13:02 --> Helper loaded: form_helper
INFO - 2023-05-17 06:13:02 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:13:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:13:02 --> Database Driver Class Initialized
INFO - 2023-05-17 06:13:02 --> Model "Login_model" initialized
INFO - 2023-05-17 06:13:02 --> Final output sent to browser
DEBUG - 2023-05-17 06:13:02 --> Total execution time: 0.0117
INFO - 2023-05-17 06:13:15 --> Config Class Initialized
INFO - 2023-05-17 06:13:15 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:13:15 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:13:15 --> Utf8 Class Initialized
INFO - 2023-05-17 06:13:15 --> URI Class Initialized
INFO - 2023-05-17 06:13:15 --> Router Class Initialized
INFO - 2023-05-17 06:13:15 --> Output Class Initialized
INFO - 2023-05-17 06:13:15 --> Security Class Initialized
DEBUG - 2023-05-17 06:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:13:15 --> Input Class Initialized
INFO - 2023-05-17 06:13:15 --> Language Class Initialized
INFO - 2023-05-17 06:13:15 --> Loader Class Initialized
INFO - 2023-05-17 06:13:15 --> Controller Class Initialized
INFO - 2023-05-17 06:13:15 --> Helper loaded: form_helper
INFO - 2023-05-17 06:13:15 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:13:15 --> Model "Change_model" initialized
INFO - 2023-05-17 06:13:15 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:13:15 --> Final output sent to browser
DEBUG - 2023-05-17 06:13:15 --> Total execution time: 0.0349
INFO - 2023-05-17 06:13:15 --> Config Class Initialized
INFO - 2023-05-17 06:13:15 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:13:15 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:13:15 --> Utf8 Class Initialized
INFO - 2023-05-17 06:13:15 --> URI Class Initialized
INFO - 2023-05-17 06:13:15 --> Router Class Initialized
INFO - 2023-05-17 06:13:15 --> Output Class Initialized
INFO - 2023-05-17 06:13:15 --> Security Class Initialized
DEBUG - 2023-05-17 06:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:13:15 --> Input Class Initialized
INFO - 2023-05-17 06:13:15 --> Language Class Initialized
INFO - 2023-05-17 06:13:15 --> Loader Class Initialized
INFO - 2023-05-17 06:13:15 --> Controller Class Initialized
INFO - 2023-05-17 06:13:15 --> Helper loaded: form_helper
INFO - 2023-05-17 06:13:15 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:13:15 --> Final output sent to browser
DEBUG - 2023-05-17 06:13:15 --> Total execution time: 0.0023
INFO - 2023-05-17 06:13:15 --> Config Class Initialized
INFO - 2023-05-17 06:13:15 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:13:15 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:13:15 --> Utf8 Class Initialized
INFO - 2023-05-17 06:13:15 --> URI Class Initialized
INFO - 2023-05-17 06:13:15 --> Router Class Initialized
INFO - 2023-05-17 06:13:15 --> Output Class Initialized
INFO - 2023-05-17 06:13:15 --> Security Class Initialized
DEBUG - 2023-05-17 06:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:13:15 --> Input Class Initialized
INFO - 2023-05-17 06:13:15 --> Language Class Initialized
INFO - 2023-05-17 06:13:15 --> Loader Class Initialized
INFO - 2023-05-17 06:13:15 --> Controller Class Initialized
INFO - 2023-05-17 06:13:15 --> Helper loaded: form_helper
INFO - 2023-05-17 06:13:15 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:13:15 --> Database Driver Class Initialized
INFO - 2023-05-17 06:13:15 --> Model "Login_model" initialized
INFO - 2023-05-17 06:13:15 --> Final output sent to browser
DEBUG - 2023-05-17 06:13:15 --> Total execution time: 0.0155
INFO - 2023-05-17 06:13:15 --> Config Class Initialized
INFO - 2023-05-17 06:13:15 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:13:15 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:13:15 --> Utf8 Class Initialized
INFO - 2023-05-17 06:13:15 --> URI Class Initialized
INFO - 2023-05-17 06:13:15 --> Router Class Initialized
INFO - 2023-05-17 06:13:15 --> Output Class Initialized
INFO - 2023-05-17 06:13:15 --> Security Class Initialized
DEBUG - 2023-05-17 06:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:13:15 --> Input Class Initialized
INFO - 2023-05-17 06:13:15 --> Language Class Initialized
INFO - 2023-05-17 06:13:15 --> Loader Class Initialized
INFO - 2023-05-17 06:13:15 --> Controller Class Initialized
DEBUG - 2023-05-17 06:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:13:15 --> Database Driver Class Initialized
INFO - 2023-05-17 06:13:15 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:13:16 --> Final output sent to browser
DEBUG - 2023-05-17 06:13:16 --> Total execution time: 0.0294
INFO - 2023-05-17 06:13:16 --> Config Class Initialized
INFO - 2023-05-17 06:13:16 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:13:16 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:13:16 --> Utf8 Class Initialized
INFO - 2023-05-17 06:13:16 --> URI Class Initialized
INFO - 2023-05-17 06:13:16 --> Router Class Initialized
INFO - 2023-05-17 06:13:16 --> Output Class Initialized
INFO - 2023-05-17 06:13:16 --> Security Class Initialized
DEBUG - 2023-05-17 06:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:13:16 --> Input Class Initialized
INFO - 2023-05-17 06:13:16 --> Language Class Initialized
INFO - 2023-05-17 06:13:16 --> Loader Class Initialized
INFO - 2023-05-17 06:13:16 --> Controller Class Initialized
DEBUG - 2023-05-17 06:13:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:13:16 --> Database Driver Class Initialized
INFO - 2023-05-17 06:13:16 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:13:16 --> Final output sent to browser
DEBUG - 2023-05-17 06:13:16 --> Total execution time: 0.0142
INFO - 2023-05-17 06:13:16 --> Config Class Initialized
INFO - 2023-05-17 06:13:16 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:13:16 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:13:16 --> Utf8 Class Initialized
INFO - 2023-05-17 06:13:16 --> URI Class Initialized
INFO - 2023-05-17 06:13:16 --> Router Class Initialized
INFO - 2023-05-17 06:13:16 --> Output Class Initialized
INFO - 2023-05-17 06:13:16 --> Security Class Initialized
DEBUG - 2023-05-17 06:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:13:16 --> Input Class Initialized
INFO - 2023-05-17 06:13:16 --> Language Class Initialized
INFO - 2023-05-17 06:13:16 --> Loader Class Initialized
INFO - 2023-05-17 06:13:16 --> Controller Class Initialized
DEBUG - 2023-05-17 06:13:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:13:16 --> Database Driver Class Initialized
INFO - 2023-05-17 06:13:16 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:13:16 --> Database Driver Class Initialized
INFO - 2023-05-17 06:13:16 --> Model "Login_model" initialized
INFO - 2023-05-17 06:13:16 --> Final output sent to browser
DEBUG - 2023-05-17 06:13:16 --> Total execution time: 0.0542
INFO - 2023-05-17 06:13:16 --> Config Class Initialized
INFO - 2023-05-17 06:13:16 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:13:16 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:13:16 --> Utf8 Class Initialized
INFO - 2023-05-17 06:13:16 --> URI Class Initialized
INFO - 2023-05-17 06:13:16 --> Router Class Initialized
INFO - 2023-05-17 06:13:16 --> Output Class Initialized
INFO - 2023-05-17 06:13:16 --> Security Class Initialized
DEBUG - 2023-05-17 06:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:13:16 --> Input Class Initialized
INFO - 2023-05-17 06:13:16 --> Language Class Initialized
INFO - 2023-05-17 06:13:16 --> Loader Class Initialized
INFO - 2023-05-17 06:13:16 --> Controller Class Initialized
DEBUG - 2023-05-17 06:13:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:13:16 --> Database Driver Class Initialized
INFO - 2023-05-17 06:13:16 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:13:16 --> Database Driver Class Initialized
INFO - 2023-05-17 06:13:16 --> Model "Login_model" initialized
INFO - 2023-05-17 06:13:16 --> Final output sent to browser
DEBUG - 2023-05-17 06:13:16 --> Total execution time: 0.1302
INFO - 2023-05-17 06:15:34 --> Config Class Initialized
INFO - 2023-05-17 06:15:34 --> Config Class Initialized
INFO - 2023-05-17 06:15:34 --> Hooks Class Initialized
INFO - 2023-05-17 06:15:34 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:34 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 06:15:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:34 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:34 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:34 --> URI Class Initialized
INFO - 2023-05-17 06:15:34 --> URI Class Initialized
INFO - 2023-05-17 06:15:34 --> Router Class Initialized
INFO - 2023-05-17 06:15:34 --> Router Class Initialized
INFO - 2023-05-17 06:15:34 --> Output Class Initialized
INFO - 2023-05-17 06:15:34 --> Security Class Initialized
INFO - 2023-05-17 06:15:34 --> Output Class Initialized
DEBUG - 2023-05-17 06:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:34 --> Security Class Initialized
INFO - 2023-05-17 06:15:34 --> Input Class Initialized
DEBUG - 2023-05-17 06:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:34 --> Language Class Initialized
INFO - 2023-05-17 06:15:34 --> Input Class Initialized
INFO - 2023-05-17 06:15:34 --> Language Class Initialized
INFO - 2023-05-17 06:15:34 --> Loader Class Initialized
INFO - 2023-05-17 06:15:34 --> Loader Class Initialized
INFO - 2023-05-17 06:15:34 --> Controller Class Initialized
INFO - 2023-05-17 06:15:34 --> Controller Class Initialized
DEBUG - 2023-05-17 06:15:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 06:15:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:34 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:34 --> Total execution time: 0.0056
INFO - 2023-05-17 06:15:34 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:34 --> Config Class Initialized
INFO - 2023-05-17 06:15:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:15:34 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:34 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:34 --> URI Class Initialized
INFO - 2023-05-17 06:15:34 --> Router Class Initialized
INFO - 2023-05-17 06:15:34 --> Output Class Initialized
INFO - 2023-05-17 06:15:34 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:34 --> Input Class Initialized
INFO - 2023-05-17 06:15:34 --> Language Class Initialized
INFO - 2023-05-17 06:15:34 --> Loader Class Initialized
INFO - 2023-05-17 06:15:34 --> Controller Class Initialized
DEBUG - 2023-05-17 06:15:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:34 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:34 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:34 --> Total execution time: 0.0368
INFO - 2023-05-17 06:15:34 --> Config Class Initialized
INFO - 2023-05-17 06:15:34 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:34 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:34 --> URI Class Initialized
INFO - 2023-05-17 06:15:34 --> Router Class Initialized
INFO - 2023-05-17 06:15:34 --> Output Class Initialized
INFO - 2023-05-17 06:15:34 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:34 --> Input Class Initialized
INFO - 2023-05-17 06:15:34 --> Language Class Initialized
INFO - 2023-05-17 06:15:34 --> Loader Class Initialized
INFO - 2023-05-17 06:15:34 --> Controller Class Initialized
DEBUG - 2023-05-17 06:15:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:34 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:34 --> Model "Login_model" initialized
INFO - 2023-05-17 06:15:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:15:34 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:34 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:34 --> Total execution time: 0.0147
INFO - 2023-05-17 06:15:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:15:34 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:34 --> Total execution time: 0.0944
INFO - 2023-05-17 06:15:34 --> Config Class Initialized
INFO - 2023-05-17 06:15:34 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:34 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:34 --> URI Class Initialized
INFO - 2023-05-17 06:15:34 --> Router Class Initialized
INFO - 2023-05-17 06:15:34 --> Config Class Initialized
INFO - 2023-05-17 06:15:34 --> Output Class Initialized
INFO - 2023-05-17 06:15:34 --> Hooks Class Initialized
INFO - 2023-05-17 06:15:34 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:34 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 06:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:34 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:34 --> Input Class Initialized
INFO - 2023-05-17 06:15:34 --> Language Class Initialized
INFO - 2023-05-17 06:15:34 --> URI Class Initialized
INFO - 2023-05-17 06:15:34 --> Loader Class Initialized
INFO - 2023-05-17 06:15:34 --> Router Class Initialized
INFO - 2023-05-17 06:15:34 --> Controller Class Initialized
INFO - 2023-05-17 06:15:34 --> Output Class Initialized
DEBUG - 2023-05-17 06:15:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:34 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:34 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:34 --> Input Class Initialized
INFO - 2023-05-17 06:15:34 --> Language Class Initialized
INFO - 2023-05-17 06:15:34 --> Loader Class Initialized
INFO - 2023-05-17 06:15:34 --> Controller Class Initialized
DEBUG - 2023-05-17 06:15:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:34 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:15:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:15:34 --> Final output sent to browser
INFO - 2023-05-17 06:15:34 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:34 --> Total execution time: 0.0154
DEBUG - 2023-05-17 06:15:34 --> Total execution time: 0.0162
INFO - 2023-05-17 06:15:34 --> Config Class Initialized
INFO - 2023-05-17 06:15:34 --> Config Class Initialized
INFO - 2023-05-17 06:15:34 --> Hooks Class Initialized
INFO - 2023-05-17 06:15:34 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:34 --> Utf8 Class Initialized
DEBUG - 2023-05-17 06:15:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:34 --> URI Class Initialized
INFO - 2023-05-17 06:15:34 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:34 --> Router Class Initialized
INFO - 2023-05-17 06:15:34 --> URI Class Initialized
INFO - 2023-05-17 06:15:34 --> Output Class Initialized
INFO - 2023-05-17 06:15:34 --> Router Class Initialized
INFO - 2023-05-17 06:15:34 --> Security Class Initialized
INFO - 2023-05-17 06:15:34 --> Output Class Initialized
DEBUG - 2023-05-17 06:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:34 --> Security Class Initialized
INFO - 2023-05-17 06:15:34 --> Input Class Initialized
DEBUG - 2023-05-17 06:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:34 --> Language Class Initialized
INFO - 2023-05-17 06:15:34 --> Input Class Initialized
INFO - 2023-05-17 06:15:34 --> Language Class Initialized
INFO - 2023-05-17 06:15:34 --> Loader Class Initialized
INFO - 2023-05-17 06:15:34 --> Loader Class Initialized
INFO - 2023-05-17 06:15:34 --> Controller Class Initialized
INFO - 2023-05-17 06:15:34 --> Controller Class Initialized
DEBUG - 2023-05-17 06:15:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 06:15:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:34 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:34 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:15:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:15:35 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:35 --> Total execution time: 0.0573
INFO - 2023-05-17 06:15:35 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:35 --> Total execution time: 0.0591
INFO - 2023-05-17 06:15:36 --> Config Class Initialized
INFO - 2023-05-17 06:15:36 --> Config Class Initialized
INFO - 2023-05-17 06:15:36 --> Hooks Class Initialized
INFO - 2023-05-17 06:15:36 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:36 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 06:15:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:36 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:36 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:36 --> URI Class Initialized
INFO - 2023-05-17 06:15:36 --> URI Class Initialized
INFO - 2023-05-17 06:15:36 --> Router Class Initialized
INFO - 2023-05-17 06:15:36 --> Output Class Initialized
INFO - 2023-05-17 06:15:36 --> Router Class Initialized
INFO - 2023-05-17 06:15:36 --> Security Class Initialized
INFO - 2023-05-17 06:15:36 --> Output Class Initialized
DEBUG - 2023-05-17 06:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:36 --> Security Class Initialized
INFO - 2023-05-17 06:15:36 --> Input Class Initialized
DEBUG - 2023-05-17 06:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:36 --> Language Class Initialized
INFO - 2023-05-17 06:15:36 --> Input Class Initialized
INFO - 2023-05-17 06:15:36 --> Loader Class Initialized
INFO - 2023-05-17 06:15:36 --> Language Class Initialized
INFO - 2023-05-17 06:15:36 --> Controller Class Initialized
DEBUG - 2023-05-17 06:15:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:36 --> Loader Class Initialized
INFO - 2023-05-17 06:15:36 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:36 --> Controller Class Initialized
DEBUG - 2023-05-17 06:15:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:36 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:15:36 --> Model "Login_model" initialized
INFO - 2023-05-17 06:15:36 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:36 --> Total execution time: 0.0186
INFO - 2023-05-17 06:15:36 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:15:36 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:36 --> Total execution time: 0.0287
INFO - 2023-05-17 06:15:37 --> Config Class Initialized
INFO - 2023-05-17 06:15:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:37 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:37 --> URI Class Initialized
INFO - 2023-05-17 06:15:37 --> Router Class Initialized
INFO - 2023-05-17 06:15:37 --> Output Class Initialized
INFO - 2023-05-17 06:15:37 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:37 --> Input Class Initialized
INFO - 2023-05-17 06:15:37 --> Language Class Initialized
INFO - 2023-05-17 06:15:37 --> Loader Class Initialized
INFO - 2023-05-17 06:15:37 --> Controller Class Initialized
DEBUG - 2023-05-17 06:15:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:37 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:15:37 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:37 --> Model "Login_model" initialized
INFO - 2023-05-17 06:15:37 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:37 --> Total execution time: 0.0628
INFO - 2023-05-17 06:15:37 --> Config Class Initialized
INFO - 2023-05-17 06:15:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:37 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:37 --> URI Class Initialized
INFO - 2023-05-17 06:15:37 --> Router Class Initialized
INFO - 2023-05-17 06:15:37 --> Output Class Initialized
INFO - 2023-05-17 06:15:37 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:37 --> Input Class Initialized
INFO - 2023-05-17 06:15:37 --> Language Class Initialized
INFO - 2023-05-17 06:15:37 --> Loader Class Initialized
INFO - 2023-05-17 06:15:37 --> Controller Class Initialized
DEBUG - 2023-05-17 06:15:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:37 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:15:37 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:37 --> Model "Login_model" initialized
INFO - 2023-05-17 06:15:37 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:37 --> Total execution time: 0.0720
INFO - 2023-05-17 06:15:52 --> Config Class Initialized
INFO - 2023-05-17 06:15:52 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:52 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:52 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:52 --> URI Class Initialized
INFO - 2023-05-17 06:15:52 --> Router Class Initialized
INFO - 2023-05-17 06:15:52 --> Output Class Initialized
INFO - 2023-05-17 06:15:52 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:52 --> Input Class Initialized
INFO - 2023-05-17 06:15:52 --> Language Class Initialized
INFO - 2023-05-17 06:15:52 --> Loader Class Initialized
INFO - 2023-05-17 06:15:52 --> Controller Class Initialized
INFO - 2023-05-17 06:15:52 --> Helper loaded: form_helper
INFO - 2023-05-17 06:15:52 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:15:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:52 --> Model "Change_model" initialized
INFO - 2023-05-17 06:15:52 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:15:52 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:52 --> Total execution time: 0.0308
INFO - 2023-05-17 06:15:53 --> Config Class Initialized
INFO - 2023-05-17 06:15:53 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:53 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:53 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:53 --> URI Class Initialized
INFO - 2023-05-17 06:15:53 --> Router Class Initialized
INFO - 2023-05-17 06:15:53 --> Output Class Initialized
INFO - 2023-05-17 06:15:53 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:53 --> Input Class Initialized
INFO - 2023-05-17 06:15:53 --> Language Class Initialized
INFO - 2023-05-17 06:15:53 --> Loader Class Initialized
INFO - 2023-05-17 06:15:53 --> Controller Class Initialized
INFO - 2023-05-17 06:15:53 --> Helper loaded: form_helper
INFO - 2023-05-17 06:15:53 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:15:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:53 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:53 --> Total execution time: 0.0055
INFO - 2023-05-17 06:15:53 --> Config Class Initialized
INFO - 2023-05-17 06:15:53 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:53 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:53 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:53 --> URI Class Initialized
INFO - 2023-05-17 06:15:53 --> Router Class Initialized
INFO - 2023-05-17 06:15:53 --> Output Class Initialized
INFO - 2023-05-17 06:15:53 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:53 --> Input Class Initialized
INFO - 2023-05-17 06:15:53 --> Language Class Initialized
INFO - 2023-05-17 06:15:53 --> Loader Class Initialized
INFO - 2023-05-17 06:15:53 --> Controller Class Initialized
INFO - 2023-05-17 06:15:53 --> Helper loaded: form_helper
INFO - 2023-05-17 06:15:53 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:15:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:53 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:53 --> Model "Login_model" initialized
INFO - 2023-05-17 06:15:53 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:53 --> Total execution time: 0.0102
INFO - 2023-05-17 06:15:58 --> Config Class Initialized
INFO - 2023-05-17 06:15:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:58 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:58 --> URI Class Initialized
INFO - 2023-05-17 06:15:58 --> Router Class Initialized
INFO - 2023-05-17 06:15:58 --> Output Class Initialized
INFO - 2023-05-17 06:15:58 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:58 --> Input Class Initialized
INFO - 2023-05-17 06:15:58 --> Language Class Initialized
INFO - 2023-05-17 06:15:58 --> Loader Class Initialized
INFO - 2023-05-17 06:15:58 --> Controller Class Initialized
INFO - 2023-05-17 06:15:58 --> Helper loaded: form_helper
INFO - 2023-05-17 06:15:58 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:15:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:58 --> Model "Change_model" initialized
INFO - 2023-05-17 06:15:58 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:15:58 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:58 --> Total execution time: 0.0261
INFO - 2023-05-17 06:15:58 --> Config Class Initialized
INFO - 2023-05-17 06:15:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:58 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:58 --> URI Class Initialized
INFO - 2023-05-17 06:15:58 --> Router Class Initialized
INFO - 2023-05-17 06:15:58 --> Output Class Initialized
INFO - 2023-05-17 06:15:58 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:58 --> Input Class Initialized
INFO - 2023-05-17 06:15:58 --> Language Class Initialized
INFO - 2023-05-17 06:15:58 --> Loader Class Initialized
INFO - 2023-05-17 06:15:58 --> Controller Class Initialized
INFO - 2023-05-17 06:15:58 --> Helper loaded: form_helper
INFO - 2023-05-17 06:15:58 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:15:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:58 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:58 --> Total execution time: 0.0027
INFO - 2023-05-17 06:15:58 --> Config Class Initialized
INFO - 2023-05-17 06:15:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:58 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:58 --> URI Class Initialized
INFO - 2023-05-17 06:15:58 --> Router Class Initialized
INFO - 2023-05-17 06:15:58 --> Output Class Initialized
INFO - 2023-05-17 06:15:58 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:58 --> Input Class Initialized
INFO - 2023-05-17 06:15:58 --> Language Class Initialized
INFO - 2023-05-17 06:15:58 --> Loader Class Initialized
INFO - 2023-05-17 06:15:58 --> Controller Class Initialized
INFO - 2023-05-17 06:15:58 --> Helper loaded: form_helper
INFO - 2023-05-17 06:15:58 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:15:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:58 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:58 --> Model "Login_model" initialized
INFO - 2023-05-17 06:15:58 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:58 --> Total execution time: 0.0116
INFO - 2023-05-17 06:15:58 --> Config Class Initialized
INFO - 2023-05-17 06:15:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:58 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:58 --> URI Class Initialized
INFO - 2023-05-17 06:15:58 --> Router Class Initialized
INFO - 2023-05-17 06:15:58 --> Output Class Initialized
INFO - 2023-05-17 06:15:58 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:58 --> Input Class Initialized
INFO - 2023-05-17 06:15:58 --> Language Class Initialized
INFO - 2023-05-17 06:15:58 --> Loader Class Initialized
INFO - 2023-05-17 06:15:58 --> Controller Class Initialized
INFO - 2023-05-17 06:15:58 --> Helper loaded: form_helper
INFO - 2023-05-17 06:15:58 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:15:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:58 --> Model "Change_model" initialized
INFO - 2023-05-17 06:15:58 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:15:58 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:58 --> Total execution time: 0.0262
INFO - 2023-05-17 06:15:58 --> Config Class Initialized
INFO - 2023-05-17 06:15:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:58 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:58 --> URI Class Initialized
INFO - 2023-05-17 06:15:58 --> Router Class Initialized
INFO - 2023-05-17 06:15:58 --> Output Class Initialized
INFO - 2023-05-17 06:15:58 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:58 --> Input Class Initialized
INFO - 2023-05-17 06:15:58 --> Language Class Initialized
INFO - 2023-05-17 06:15:58 --> Loader Class Initialized
INFO - 2023-05-17 06:15:58 --> Controller Class Initialized
INFO - 2023-05-17 06:15:58 --> Helper loaded: form_helper
INFO - 2023-05-17 06:15:58 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:15:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:58 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:58 --> Total execution time: 0.0019
INFO - 2023-05-17 06:15:58 --> Config Class Initialized
INFO - 2023-05-17 06:15:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:15:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:15:58 --> Utf8 Class Initialized
INFO - 2023-05-17 06:15:58 --> URI Class Initialized
INFO - 2023-05-17 06:15:58 --> Router Class Initialized
INFO - 2023-05-17 06:15:58 --> Output Class Initialized
INFO - 2023-05-17 06:15:58 --> Security Class Initialized
DEBUG - 2023-05-17 06:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:15:58 --> Input Class Initialized
INFO - 2023-05-17 06:15:58 --> Language Class Initialized
INFO - 2023-05-17 06:15:58 --> Loader Class Initialized
INFO - 2023-05-17 06:15:58 --> Controller Class Initialized
INFO - 2023-05-17 06:15:58 --> Helper loaded: form_helper
INFO - 2023-05-17 06:15:58 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:15:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:15:58 --> Database Driver Class Initialized
INFO - 2023-05-17 06:15:58 --> Model "Login_model" initialized
INFO - 2023-05-17 06:15:58 --> Final output sent to browser
DEBUG - 2023-05-17 06:15:58 --> Total execution time: 0.0132
INFO - 2023-05-17 06:16:00 --> Config Class Initialized
INFO - 2023-05-17 06:16:00 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:16:00 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:16:00 --> Utf8 Class Initialized
INFO - 2023-05-17 06:16:00 --> URI Class Initialized
INFO - 2023-05-17 06:16:00 --> Router Class Initialized
INFO - 2023-05-17 06:16:00 --> Output Class Initialized
INFO - 2023-05-17 06:16:00 --> Security Class Initialized
DEBUG - 2023-05-17 06:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:16:00 --> Input Class Initialized
INFO - 2023-05-17 06:16:00 --> Language Class Initialized
INFO - 2023-05-17 06:16:00 --> Loader Class Initialized
INFO - 2023-05-17 06:16:00 --> Controller Class Initialized
INFO - 2023-05-17 06:16:00 --> Helper loaded: form_helper
INFO - 2023-05-17 06:16:00 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:16:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:16:00 --> Model "Change_model" initialized
INFO - 2023-05-17 06:16:00 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:16:00 --> Final output sent to browser
DEBUG - 2023-05-17 06:16:00 --> Total execution time: 0.0293
INFO - 2023-05-17 06:16:00 --> Config Class Initialized
INFO - 2023-05-17 06:16:00 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:16:00 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:16:00 --> Utf8 Class Initialized
INFO - 2023-05-17 06:16:00 --> URI Class Initialized
INFO - 2023-05-17 06:16:00 --> Router Class Initialized
INFO - 2023-05-17 06:16:00 --> Output Class Initialized
INFO - 2023-05-17 06:16:00 --> Security Class Initialized
DEBUG - 2023-05-17 06:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:16:00 --> Input Class Initialized
INFO - 2023-05-17 06:16:00 --> Language Class Initialized
INFO - 2023-05-17 06:16:00 --> Loader Class Initialized
INFO - 2023-05-17 06:16:00 --> Controller Class Initialized
INFO - 2023-05-17 06:16:00 --> Helper loaded: form_helper
INFO - 2023-05-17 06:16:00 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:16:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:16:00 --> Final output sent to browser
DEBUG - 2023-05-17 06:16:00 --> Total execution time: 0.0425
INFO - 2023-05-17 06:16:00 --> Config Class Initialized
INFO - 2023-05-17 06:16:00 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:16:00 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:16:00 --> Utf8 Class Initialized
INFO - 2023-05-17 06:16:00 --> URI Class Initialized
INFO - 2023-05-17 06:16:00 --> Router Class Initialized
INFO - 2023-05-17 06:16:00 --> Output Class Initialized
INFO - 2023-05-17 06:16:00 --> Security Class Initialized
DEBUG - 2023-05-17 06:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:16:00 --> Input Class Initialized
INFO - 2023-05-17 06:16:00 --> Language Class Initialized
INFO - 2023-05-17 06:16:00 --> Loader Class Initialized
INFO - 2023-05-17 06:16:00 --> Controller Class Initialized
INFO - 2023-05-17 06:16:00 --> Helper loaded: form_helper
INFO - 2023-05-17 06:16:00 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:16:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:16:00 --> Database Driver Class Initialized
INFO - 2023-05-17 06:16:00 --> Model "Login_model" initialized
INFO - 2023-05-17 06:16:00 --> Final output sent to browser
DEBUG - 2023-05-17 06:16:00 --> Total execution time: 0.0128
INFO - 2023-05-17 06:17:29 --> Config Class Initialized
INFO - 2023-05-17 06:17:29 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:17:29 --> Utf8 Class Initialized
INFO - 2023-05-17 06:17:29 --> URI Class Initialized
INFO - 2023-05-17 06:17:29 --> Router Class Initialized
INFO - 2023-05-17 06:17:29 --> Output Class Initialized
INFO - 2023-05-17 06:17:29 --> Security Class Initialized
DEBUG - 2023-05-17 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:17:29 --> Input Class Initialized
INFO - 2023-05-17 06:17:29 --> Language Class Initialized
INFO - 2023-05-17 06:17:29 --> Loader Class Initialized
INFO - 2023-05-17 06:17:29 --> Controller Class Initialized
INFO - 2023-05-17 06:17:29 --> Helper loaded: form_helper
INFO - 2023-05-17 06:17:29 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:17:29 --> Model "Change_model" initialized
INFO - 2023-05-17 06:17:29 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:17:29 --> Final output sent to browser
DEBUG - 2023-05-17 06:17:29 --> Total execution time: 0.0744
INFO - 2023-05-17 06:17:29 --> Config Class Initialized
INFO - 2023-05-17 06:17:29 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:17:29 --> Utf8 Class Initialized
INFO - 2023-05-17 06:17:29 --> URI Class Initialized
INFO - 2023-05-17 06:17:29 --> Router Class Initialized
INFO - 2023-05-17 06:17:29 --> Output Class Initialized
INFO - 2023-05-17 06:17:29 --> Security Class Initialized
DEBUG - 2023-05-17 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:17:29 --> Input Class Initialized
INFO - 2023-05-17 06:17:29 --> Language Class Initialized
INFO - 2023-05-17 06:17:29 --> Loader Class Initialized
INFO - 2023-05-17 06:17:29 --> Controller Class Initialized
INFO - 2023-05-17 06:17:29 --> Helper loaded: form_helper
INFO - 2023-05-17 06:17:29 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:17:29 --> Final output sent to browser
DEBUG - 2023-05-17 06:17:29 --> Total execution time: 0.0029
INFO - 2023-05-17 06:17:29 --> Config Class Initialized
INFO - 2023-05-17 06:17:29 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:17:29 --> Utf8 Class Initialized
INFO - 2023-05-17 06:17:29 --> URI Class Initialized
INFO - 2023-05-17 06:17:29 --> Router Class Initialized
INFO - 2023-05-17 06:17:29 --> Output Class Initialized
INFO - 2023-05-17 06:17:29 --> Security Class Initialized
DEBUG - 2023-05-17 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:17:29 --> Input Class Initialized
INFO - 2023-05-17 06:17:29 --> Language Class Initialized
INFO - 2023-05-17 06:17:29 --> Loader Class Initialized
INFO - 2023-05-17 06:17:29 --> Controller Class Initialized
INFO - 2023-05-17 06:17:29 --> Helper loaded: form_helper
INFO - 2023-05-17 06:17:29 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:17:29 --> Database Driver Class Initialized
INFO - 2023-05-17 06:17:29 --> Model "Login_model" initialized
INFO - 2023-05-17 06:17:29 --> Final output sent to browser
DEBUG - 2023-05-17 06:17:29 --> Total execution time: 0.0256
INFO - 2023-05-17 06:18:25 --> Config Class Initialized
INFO - 2023-05-17 06:18:25 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:18:25 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:18:25 --> Utf8 Class Initialized
INFO - 2023-05-17 06:18:25 --> URI Class Initialized
INFO - 2023-05-17 06:18:25 --> Router Class Initialized
INFO - 2023-05-17 06:18:25 --> Output Class Initialized
INFO - 2023-05-17 06:18:25 --> Security Class Initialized
DEBUG - 2023-05-17 06:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:18:25 --> Input Class Initialized
INFO - 2023-05-17 06:18:25 --> Language Class Initialized
INFO - 2023-05-17 06:18:25 --> Loader Class Initialized
INFO - 2023-05-17 06:18:25 --> Controller Class Initialized
INFO - 2023-05-17 06:18:25 --> Helper loaded: form_helper
INFO - 2023-05-17 06:18:25 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:18:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:18:25 --> Model "Change_model" initialized
INFO - 2023-05-17 06:18:25 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:18:25 --> Final output sent to browser
DEBUG - 2023-05-17 06:18:25 --> Total execution time: 0.0752
INFO - 2023-05-17 06:18:25 --> Config Class Initialized
INFO - 2023-05-17 06:18:25 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:18:25 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:18:25 --> Utf8 Class Initialized
INFO - 2023-05-17 06:18:25 --> URI Class Initialized
INFO - 2023-05-17 06:18:25 --> Router Class Initialized
INFO - 2023-05-17 06:18:25 --> Output Class Initialized
INFO - 2023-05-17 06:18:25 --> Security Class Initialized
DEBUG - 2023-05-17 06:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:18:25 --> Input Class Initialized
INFO - 2023-05-17 06:18:25 --> Language Class Initialized
INFO - 2023-05-17 06:18:25 --> Loader Class Initialized
INFO - 2023-05-17 06:18:25 --> Controller Class Initialized
INFO - 2023-05-17 06:18:25 --> Helper loaded: form_helper
INFO - 2023-05-17 06:18:25 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:18:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:18:25 --> Final output sent to browser
DEBUG - 2023-05-17 06:18:25 --> Total execution time: 0.0474
INFO - 2023-05-17 06:18:25 --> Config Class Initialized
INFO - 2023-05-17 06:18:25 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:18:25 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:18:25 --> Utf8 Class Initialized
INFO - 2023-05-17 06:18:25 --> URI Class Initialized
INFO - 2023-05-17 06:18:25 --> Router Class Initialized
INFO - 2023-05-17 06:18:25 --> Output Class Initialized
INFO - 2023-05-17 06:18:25 --> Security Class Initialized
DEBUG - 2023-05-17 06:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:18:25 --> Input Class Initialized
INFO - 2023-05-17 06:18:25 --> Language Class Initialized
INFO - 2023-05-17 06:18:25 --> Loader Class Initialized
INFO - 2023-05-17 06:18:25 --> Controller Class Initialized
INFO - 2023-05-17 06:18:25 --> Helper loaded: form_helper
INFO - 2023-05-17 06:18:25 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:18:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:18:25 --> Database Driver Class Initialized
INFO - 2023-05-17 06:18:25 --> Model "Login_model" initialized
INFO - 2023-05-17 06:18:25 --> Final output sent to browser
DEBUG - 2023-05-17 06:18:25 --> Total execution time: 0.0483
INFO - 2023-05-17 06:18:49 --> Config Class Initialized
INFO - 2023-05-17 06:18:49 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:18:49 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:18:49 --> Utf8 Class Initialized
INFO - 2023-05-17 06:18:49 --> URI Class Initialized
INFO - 2023-05-17 06:18:49 --> Router Class Initialized
INFO - 2023-05-17 06:18:49 --> Output Class Initialized
INFO - 2023-05-17 06:18:49 --> Security Class Initialized
DEBUG - 2023-05-17 06:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:18:49 --> Input Class Initialized
INFO - 2023-05-17 06:18:49 --> Language Class Initialized
INFO - 2023-05-17 06:18:49 --> Loader Class Initialized
INFO - 2023-05-17 06:18:49 --> Controller Class Initialized
INFO - 2023-05-17 06:18:49 --> Helper loaded: form_helper
INFO - 2023-05-17 06:18:49 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:18:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:18:49 --> Model "Change_model" initialized
INFO - 2023-05-17 06:18:50 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:18:50 --> Final output sent to browser
DEBUG - 2023-05-17 06:18:50 --> Total execution time: 0.2597
INFO - 2023-05-17 06:18:50 --> Config Class Initialized
INFO - 2023-05-17 06:18:50 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:18:50 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:18:50 --> Utf8 Class Initialized
INFO - 2023-05-17 06:18:50 --> URI Class Initialized
INFO - 2023-05-17 06:18:50 --> Router Class Initialized
INFO - 2023-05-17 06:18:50 --> Output Class Initialized
INFO - 2023-05-17 06:18:50 --> Security Class Initialized
DEBUG - 2023-05-17 06:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:18:50 --> Input Class Initialized
INFO - 2023-05-17 06:18:50 --> Language Class Initialized
INFO - 2023-05-17 06:18:50 --> Loader Class Initialized
INFO - 2023-05-17 06:18:50 --> Controller Class Initialized
INFO - 2023-05-17 06:18:50 --> Helper loaded: form_helper
INFO - 2023-05-17 06:18:50 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:18:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:18:50 --> Final output sent to browser
DEBUG - 2023-05-17 06:18:50 --> Total execution time: 0.0026
INFO - 2023-05-17 06:18:50 --> Config Class Initialized
INFO - 2023-05-17 06:18:50 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:18:50 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:18:50 --> Utf8 Class Initialized
INFO - 2023-05-17 06:18:50 --> URI Class Initialized
INFO - 2023-05-17 06:18:50 --> Router Class Initialized
INFO - 2023-05-17 06:18:50 --> Output Class Initialized
INFO - 2023-05-17 06:18:50 --> Security Class Initialized
DEBUG - 2023-05-17 06:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:18:50 --> Input Class Initialized
INFO - 2023-05-17 06:18:50 --> Language Class Initialized
INFO - 2023-05-17 06:18:50 --> Loader Class Initialized
INFO - 2023-05-17 06:18:50 --> Controller Class Initialized
INFO - 2023-05-17 06:18:50 --> Helper loaded: form_helper
INFO - 2023-05-17 06:18:50 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:18:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:18:50 --> Database Driver Class Initialized
INFO - 2023-05-17 06:18:50 --> Model "Login_model" initialized
INFO - 2023-05-17 06:18:50 --> Final output sent to browser
DEBUG - 2023-05-17 06:18:50 --> Total execution time: 0.0123
INFO - 2023-05-17 06:19:14 --> Config Class Initialized
INFO - 2023-05-17 06:19:14 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:19:14 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:19:14 --> Utf8 Class Initialized
INFO - 2023-05-17 06:19:14 --> URI Class Initialized
INFO - 2023-05-17 06:19:14 --> Router Class Initialized
INFO - 2023-05-17 06:19:14 --> Output Class Initialized
INFO - 2023-05-17 06:19:14 --> Security Class Initialized
DEBUG - 2023-05-17 06:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:19:14 --> Input Class Initialized
INFO - 2023-05-17 06:19:14 --> Language Class Initialized
INFO - 2023-05-17 06:19:14 --> Loader Class Initialized
INFO - 2023-05-17 06:19:14 --> Controller Class Initialized
INFO - 2023-05-17 06:19:14 --> Helper loaded: form_helper
INFO - 2023-05-17 06:19:14 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:19:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:19:14 --> Final output sent to browser
DEBUG - 2023-05-17 06:19:14 --> Total execution time: 0.0027
INFO - 2023-05-17 06:19:14 --> Config Class Initialized
INFO - 2023-05-17 06:19:14 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:19:14 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:19:14 --> Utf8 Class Initialized
INFO - 2023-05-17 06:19:14 --> URI Class Initialized
INFO - 2023-05-17 06:19:14 --> Router Class Initialized
INFO - 2023-05-17 06:19:14 --> Output Class Initialized
INFO - 2023-05-17 06:19:14 --> Security Class Initialized
DEBUG - 2023-05-17 06:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:19:14 --> Input Class Initialized
INFO - 2023-05-17 06:19:14 --> Language Class Initialized
INFO - 2023-05-17 06:19:14 --> Loader Class Initialized
INFO - 2023-05-17 06:19:14 --> Controller Class Initialized
INFO - 2023-05-17 06:19:14 --> Helper loaded: form_helper
INFO - 2023-05-17 06:19:14 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:19:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:19:14 --> Database Driver Class Initialized
INFO - 2023-05-17 06:19:14 --> Model "Login_model" initialized
ERROR - 2023-05-17 06:19:14 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: update kunlun_user set password='Aa_12345' where name='super_dba';
INFO - 2023-05-17 06:19:14 --> Final output sent to browser
DEBUG - 2023-05-17 06:19:14 --> Total execution time: 0.0225
INFO - 2023-05-17 06:19:19 --> Config Class Initialized
INFO - 2023-05-17 06:19:19 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:19:19 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:19:19 --> Utf8 Class Initialized
INFO - 2023-05-17 06:19:19 --> URI Class Initialized
INFO - 2023-05-17 06:19:19 --> Router Class Initialized
INFO - 2023-05-17 06:19:19 --> Output Class Initialized
INFO - 2023-05-17 06:19:19 --> Security Class Initialized
DEBUG - 2023-05-17 06:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:19:19 --> Input Class Initialized
INFO - 2023-05-17 06:19:19 --> Language Class Initialized
INFO - 2023-05-17 06:19:19 --> Loader Class Initialized
INFO - 2023-05-17 06:19:19 --> Controller Class Initialized
INFO - 2023-05-17 06:19:19 --> Helper loaded: form_helper
INFO - 2023-05-17 06:19:19 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:19:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:19:19 --> Final output sent to browser
DEBUG - 2023-05-17 06:19:19 --> Total execution time: 0.5500
INFO - 2023-05-17 06:20:38 --> Config Class Initialized
INFO - 2023-05-17 06:20:38 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:20:38 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:20:38 --> Utf8 Class Initialized
INFO - 2023-05-17 06:20:38 --> URI Class Initialized
INFO - 2023-05-17 06:20:38 --> Router Class Initialized
INFO - 2023-05-17 06:20:38 --> Output Class Initialized
INFO - 2023-05-17 06:20:38 --> Security Class Initialized
DEBUG - 2023-05-17 06:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:20:38 --> Input Class Initialized
INFO - 2023-05-17 06:20:38 --> Language Class Initialized
INFO - 2023-05-17 06:20:38 --> Loader Class Initialized
INFO - 2023-05-17 06:20:38 --> Controller Class Initialized
DEBUG - 2023-05-17 06:20:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:20:38 --> Database Driver Class Initialized
INFO - 2023-05-17 06:20:38 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:20:38 --> Final output sent to browser
DEBUG - 2023-05-17 06:20:38 --> Total execution time: 0.1012
INFO - 2023-05-17 06:20:38 --> Config Class Initialized
INFO - 2023-05-17 06:20:38 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:20:38 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:20:38 --> Utf8 Class Initialized
INFO - 2023-05-17 06:20:38 --> URI Class Initialized
INFO - 2023-05-17 06:20:38 --> Router Class Initialized
INFO - 2023-05-17 06:20:38 --> Output Class Initialized
INFO - 2023-05-17 06:20:38 --> Security Class Initialized
DEBUG - 2023-05-17 06:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:20:38 --> Input Class Initialized
INFO - 2023-05-17 06:20:38 --> Language Class Initialized
INFO - 2023-05-17 06:20:38 --> Loader Class Initialized
INFO - 2023-05-17 06:20:38 --> Controller Class Initialized
DEBUG - 2023-05-17 06:20:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:20:38 --> Database Driver Class Initialized
INFO - 2023-05-17 06:20:38 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:20:38 --> Final output sent to browser
DEBUG - 2023-05-17 06:20:38 --> Total execution time: 0.0571
INFO - 2023-05-17 06:20:45 --> Config Class Initialized
INFO - 2023-05-17 06:20:45 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:20:45 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:20:45 --> Utf8 Class Initialized
INFO - 2023-05-17 06:20:45 --> URI Class Initialized
INFO - 2023-05-17 06:20:45 --> Router Class Initialized
INFO - 2023-05-17 06:20:45 --> Output Class Initialized
INFO - 2023-05-17 06:20:45 --> Security Class Initialized
DEBUG - 2023-05-17 06:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:20:45 --> Input Class Initialized
INFO - 2023-05-17 06:20:45 --> Language Class Initialized
INFO - 2023-05-17 06:20:45 --> Loader Class Initialized
INFO - 2023-05-17 06:20:45 --> Controller Class Initialized
INFO - 2023-05-17 06:20:45 --> Helper loaded: form_helper
INFO - 2023-05-17 06:20:45 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:20:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:20:45 --> Model "Change_model" initialized
INFO - 2023-05-17 06:20:45 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:20:45 --> Final output sent to browser
DEBUG - 2023-05-17 06:20:45 --> Total execution time: 0.0250
INFO - 2023-05-17 06:20:45 --> Config Class Initialized
INFO - 2023-05-17 06:20:45 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:20:45 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:20:45 --> Utf8 Class Initialized
INFO - 2023-05-17 06:20:45 --> URI Class Initialized
INFO - 2023-05-17 06:20:45 --> Router Class Initialized
INFO - 2023-05-17 06:20:45 --> Output Class Initialized
INFO - 2023-05-17 06:20:45 --> Security Class Initialized
DEBUG - 2023-05-17 06:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:20:45 --> Input Class Initialized
INFO - 2023-05-17 06:20:45 --> Language Class Initialized
INFO - 2023-05-17 06:20:45 --> Loader Class Initialized
INFO - 2023-05-17 06:20:45 --> Controller Class Initialized
INFO - 2023-05-17 06:20:45 --> Helper loaded: form_helper
INFO - 2023-05-17 06:20:45 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:20:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:20:45 --> Final output sent to browser
DEBUG - 2023-05-17 06:20:45 --> Total execution time: 0.0427
INFO - 2023-05-17 06:20:45 --> Config Class Initialized
INFO - 2023-05-17 06:20:45 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:20:45 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:20:45 --> Utf8 Class Initialized
INFO - 2023-05-17 06:20:45 --> URI Class Initialized
INFO - 2023-05-17 06:20:45 --> Router Class Initialized
INFO - 2023-05-17 06:20:45 --> Output Class Initialized
INFO - 2023-05-17 06:20:45 --> Security Class Initialized
DEBUG - 2023-05-17 06:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:20:45 --> Input Class Initialized
INFO - 2023-05-17 06:20:45 --> Language Class Initialized
INFO - 2023-05-17 06:20:45 --> Loader Class Initialized
INFO - 2023-05-17 06:20:45 --> Controller Class Initialized
INFO - 2023-05-17 06:20:45 --> Helper loaded: form_helper
INFO - 2023-05-17 06:20:45 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:20:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:20:45 --> Database Driver Class Initialized
INFO - 2023-05-17 06:20:45 --> Model "Login_model" initialized
INFO - 2023-05-17 06:20:45 --> Final output sent to browser
DEBUG - 2023-05-17 06:20:45 --> Total execution time: 0.0125
INFO - 2023-05-17 06:21:12 --> Config Class Initialized
INFO - 2023-05-17 06:21:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:21:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:21:12 --> Utf8 Class Initialized
INFO - 2023-05-17 06:21:12 --> URI Class Initialized
INFO - 2023-05-17 06:21:12 --> Router Class Initialized
INFO - 2023-05-17 06:21:12 --> Output Class Initialized
INFO - 2023-05-17 06:21:12 --> Security Class Initialized
DEBUG - 2023-05-17 06:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:21:12 --> Input Class Initialized
INFO - 2023-05-17 06:21:12 --> Language Class Initialized
INFO - 2023-05-17 06:21:12 --> Loader Class Initialized
INFO - 2023-05-17 06:21:12 --> Controller Class Initialized
DEBUG - 2023-05-17 06:21:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:21:12 --> Database Driver Class Initialized
INFO - 2023-05-17 06:21:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:21:12 --> Final output sent to browser
DEBUG - 2023-05-17 06:21:12 --> Total execution time: 0.0582
INFO - 2023-05-17 06:21:12 --> Config Class Initialized
INFO - 2023-05-17 06:21:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:21:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:21:12 --> Utf8 Class Initialized
INFO - 2023-05-17 06:21:12 --> URI Class Initialized
INFO - 2023-05-17 06:21:12 --> Router Class Initialized
INFO - 2023-05-17 06:21:12 --> Output Class Initialized
INFO - 2023-05-17 06:21:12 --> Security Class Initialized
DEBUG - 2023-05-17 06:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:21:12 --> Input Class Initialized
INFO - 2023-05-17 06:21:12 --> Language Class Initialized
INFO - 2023-05-17 06:21:12 --> Loader Class Initialized
INFO - 2023-05-17 06:21:12 --> Controller Class Initialized
DEBUG - 2023-05-17 06:21:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:21:12 --> Database Driver Class Initialized
INFO - 2023-05-17 06:21:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:21:12 --> Final output sent to browser
DEBUG - 2023-05-17 06:21:12 --> Total execution time: 0.0545
INFO - 2023-05-17 06:21:39 --> Config Class Initialized
INFO - 2023-05-17 06:21:39 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:21:39 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:21:39 --> Utf8 Class Initialized
INFO - 2023-05-17 06:21:39 --> URI Class Initialized
INFO - 2023-05-17 06:21:39 --> Router Class Initialized
INFO - 2023-05-17 06:21:39 --> Output Class Initialized
INFO - 2023-05-17 06:21:39 --> Security Class Initialized
DEBUG - 2023-05-17 06:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:21:39 --> Input Class Initialized
INFO - 2023-05-17 06:21:39 --> Language Class Initialized
INFO - 2023-05-17 06:21:39 --> Loader Class Initialized
INFO - 2023-05-17 06:21:39 --> Controller Class Initialized
INFO - 2023-05-17 06:21:39 --> Helper loaded: form_helper
INFO - 2023-05-17 06:21:39 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:21:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:21:39 --> Model "Change_model" initialized
INFO - 2023-05-17 06:21:39 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:21:39 --> Final output sent to browser
DEBUG - 2023-05-17 06:21:39 --> Total execution time: 0.0279
INFO - 2023-05-17 06:21:39 --> Config Class Initialized
INFO - 2023-05-17 06:21:39 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:21:39 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:21:39 --> Utf8 Class Initialized
INFO - 2023-05-17 06:21:39 --> URI Class Initialized
INFO - 2023-05-17 06:21:39 --> Router Class Initialized
INFO - 2023-05-17 06:21:39 --> Output Class Initialized
INFO - 2023-05-17 06:21:39 --> Security Class Initialized
DEBUG - 2023-05-17 06:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:21:39 --> Input Class Initialized
INFO - 2023-05-17 06:21:39 --> Language Class Initialized
INFO - 2023-05-17 06:21:39 --> Loader Class Initialized
INFO - 2023-05-17 06:21:39 --> Controller Class Initialized
INFO - 2023-05-17 06:21:39 --> Helper loaded: form_helper
INFO - 2023-05-17 06:21:39 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:21:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:21:39 --> Final output sent to browser
DEBUG - 2023-05-17 06:21:39 --> Total execution time: 0.0030
INFO - 2023-05-17 06:21:39 --> Config Class Initialized
INFO - 2023-05-17 06:21:39 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:21:39 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:21:39 --> Utf8 Class Initialized
INFO - 2023-05-17 06:21:39 --> URI Class Initialized
INFO - 2023-05-17 06:21:39 --> Router Class Initialized
INFO - 2023-05-17 06:21:39 --> Output Class Initialized
INFO - 2023-05-17 06:21:39 --> Security Class Initialized
DEBUG - 2023-05-17 06:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:21:39 --> Input Class Initialized
INFO - 2023-05-17 06:21:39 --> Language Class Initialized
INFO - 2023-05-17 06:21:39 --> Loader Class Initialized
INFO - 2023-05-17 06:21:39 --> Controller Class Initialized
INFO - 2023-05-17 06:21:39 --> Helper loaded: form_helper
INFO - 2023-05-17 06:21:39 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:21:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:21:39 --> Database Driver Class Initialized
INFO - 2023-05-17 06:21:39 --> Model "Login_model" initialized
INFO - 2023-05-17 06:21:39 --> Final output sent to browser
DEBUG - 2023-05-17 06:21:39 --> Total execution time: 0.0966
INFO - 2023-05-17 06:22:11 --> Config Class Initialized
INFO - 2023-05-17 06:22:11 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:22:11 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:22:11 --> Utf8 Class Initialized
INFO - 2023-05-17 06:22:11 --> URI Class Initialized
INFO - 2023-05-17 06:22:11 --> Router Class Initialized
INFO - 2023-05-17 06:22:11 --> Output Class Initialized
INFO - 2023-05-17 06:22:11 --> Security Class Initialized
DEBUG - 2023-05-17 06:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:22:11 --> Input Class Initialized
INFO - 2023-05-17 06:22:11 --> Language Class Initialized
INFO - 2023-05-17 06:22:11 --> Loader Class Initialized
INFO - 2023-05-17 06:22:11 --> Controller Class Initialized
INFO - 2023-05-17 06:22:11 --> Helper loaded: form_helper
INFO - 2023-05-17 06:22:11 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:22:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:22:11 --> Model "Change_model" initialized
INFO - 2023-05-17 06:22:11 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:22:11 --> Final output sent to browser
DEBUG - 2023-05-17 06:22:11 --> Total execution time: 0.0353
INFO - 2023-05-17 06:22:11 --> Config Class Initialized
INFO - 2023-05-17 06:22:11 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:22:11 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:22:11 --> Utf8 Class Initialized
INFO - 2023-05-17 06:22:11 --> URI Class Initialized
INFO - 2023-05-17 06:22:11 --> Router Class Initialized
INFO - 2023-05-17 06:22:11 --> Output Class Initialized
INFO - 2023-05-17 06:22:11 --> Security Class Initialized
DEBUG - 2023-05-17 06:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:22:11 --> Input Class Initialized
INFO - 2023-05-17 06:22:11 --> Language Class Initialized
INFO - 2023-05-17 06:22:11 --> Loader Class Initialized
INFO - 2023-05-17 06:22:11 --> Controller Class Initialized
INFO - 2023-05-17 06:22:11 --> Helper loaded: form_helper
INFO - 2023-05-17 06:22:11 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:22:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:22:11 --> Final output sent to browser
DEBUG - 2023-05-17 06:22:11 --> Total execution time: 0.0436
INFO - 2023-05-17 06:22:11 --> Config Class Initialized
INFO - 2023-05-17 06:22:11 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:22:11 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:22:11 --> Utf8 Class Initialized
INFO - 2023-05-17 06:22:11 --> URI Class Initialized
INFO - 2023-05-17 06:22:11 --> Router Class Initialized
INFO - 2023-05-17 06:22:11 --> Output Class Initialized
INFO - 2023-05-17 06:22:11 --> Security Class Initialized
DEBUG - 2023-05-17 06:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:22:11 --> Input Class Initialized
INFO - 2023-05-17 06:22:11 --> Language Class Initialized
INFO - 2023-05-17 06:22:11 --> Loader Class Initialized
INFO - 2023-05-17 06:22:11 --> Controller Class Initialized
INFO - 2023-05-17 06:22:11 --> Helper loaded: form_helper
INFO - 2023-05-17 06:22:11 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:22:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:22:11 --> Database Driver Class Initialized
INFO - 2023-05-17 06:22:11 --> Model "Login_model" initialized
INFO - 2023-05-17 06:22:11 --> Final output sent to browser
DEBUG - 2023-05-17 06:22:11 --> Total execution time: 0.0188
INFO - 2023-05-17 06:22:16 --> Config Class Initialized
INFO - 2023-05-17 06:22:16 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:22:16 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:22:16 --> Utf8 Class Initialized
INFO - 2023-05-17 06:22:16 --> URI Class Initialized
INFO - 2023-05-17 06:22:16 --> Router Class Initialized
INFO - 2023-05-17 06:22:16 --> Output Class Initialized
INFO - 2023-05-17 06:22:16 --> Security Class Initialized
DEBUG - 2023-05-17 06:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:22:16 --> Input Class Initialized
INFO - 2023-05-17 06:22:16 --> Language Class Initialized
INFO - 2023-05-17 06:22:16 --> Loader Class Initialized
INFO - 2023-05-17 06:22:16 --> Controller Class Initialized
INFO - 2023-05-17 06:22:16 --> Helper loaded: form_helper
INFO - 2023-05-17 06:22:16 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:22:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:22:16 --> Model "Change_model" initialized
INFO - 2023-05-17 06:22:16 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:22:16 --> Final output sent to browser
DEBUG - 2023-05-17 06:22:16 --> Total execution time: 0.1173
INFO - 2023-05-17 06:22:16 --> Config Class Initialized
INFO - 2023-05-17 06:22:16 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:22:16 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:22:16 --> Utf8 Class Initialized
INFO - 2023-05-17 06:22:16 --> URI Class Initialized
INFO - 2023-05-17 06:22:16 --> Router Class Initialized
INFO - 2023-05-17 06:22:16 --> Output Class Initialized
INFO - 2023-05-17 06:22:16 --> Security Class Initialized
DEBUG - 2023-05-17 06:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:22:16 --> Input Class Initialized
INFO - 2023-05-17 06:22:16 --> Language Class Initialized
INFO - 2023-05-17 06:22:16 --> Loader Class Initialized
INFO - 2023-05-17 06:22:16 --> Controller Class Initialized
INFO - 2023-05-17 06:22:16 --> Helper loaded: form_helper
INFO - 2023-05-17 06:22:16 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:22:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:22:16 --> Final output sent to browser
DEBUG - 2023-05-17 06:22:16 --> Total execution time: 0.0029
INFO - 2023-05-17 06:22:16 --> Config Class Initialized
INFO - 2023-05-17 06:22:16 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:22:16 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:22:16 --> Utf8 Class Initialized
INFO - 2023-05-17 06:22:16 --> URI Class Initialized
INFO - 2023-05-17 06:22:16 --> Router Class Initialized
INFO - 2023-05-17 06:22:16 --> Output Class Initialized
INFO - 2023-05-17 06:22:16 --> Security Class Initialized
DEBUG - 2023-05-17 06:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:22:16 --> Input Class Initialized
INFO - 2023-05-17 06:22:16 --> Language Class Initialized
INFO - 2023-05-17 06:22:16 --> Loader Class Initialized
INFO - 2023-05-17 06:22:16 --> Controller Class Initialized
INFO - 2023-05-17 06:22:16 --> Helper loaded: form_helper
INFO - 2023-05-17 06:22:16 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:22:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:22:16 --> Database Driver Class Initialized
INFO - 2023-05-17 06:22:16 --> Model "Login_model" initialized
INFO - 2023-05-17 06:22:16 --> Final output sent to browser
DEBUG - 2023-05-17 06:22:16 --> Total execution time: 0.0170
INFO - 2023-05-17 06:22:22 --> Config Class Initialized
INFO - 2023-05-17 06:22:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:22:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:22:22 --> Utf8 Class Initialized
INFO - 2023-05-17 06:22:22 --> URI Class Initialized
INFO - 2023-05-17 06:22:22 --> Router Class Initialized
INFO - 2023-05-17 06:22:22 --> Output Class Initialized
INFO - 2023-05-17 06:22:22 --> Security Class Initialized
DEBUG - 2023-05-17 06:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:22:22 --> Input Class Initialized
INFO - 2023-05-17 06:22:22 --> Language Class Initialized
INFO - 2023-05-17 06:22:22 --> Loader Class Initialized
INFO - 2023-05-17 06:22:22 --> Controller Class Initialized
INFO - 2023-05-17 06:22:22 --> Helper loaded: form_helper
INFO - 2023-05-17 06:22:22 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:22:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:22:22 --> Model "Change_model" initialized
INFO - 2023-05-17 06:22:22 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:22:22 --> Final output sent to browser
DEBUG - 2023-05-17 06:22:22 --> Total execution time: 0.0336
INFO - 2023-05-17 06:22:22 --> Config Class Initialized
INFO - 2023-05-17 06:22:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:22:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:22:22 --> Utf8 Class Initialized
INFO - 2023-05-17 06:22:22 --> URI Class Initialized
INFO - 2023-05-17 06:22:22 --> Router Class Initialized
INFO - 2023-05-17 06:22:22 --> Output Class Initialized
INFO - 2023-05-17 06:22:22 --> Security Class Initialized
DEBUG - 2023-05-17 06:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:22:22 --> Input Class Initialized
INFO - 2023-05-17 06:22:22 --> Language Class Initialized
INFO - 2023-05-17 06:22:22 --> Loader Class Initialized
INFO - 2023-05-17 06:22:22 --> Controller Class Initialized
INFO - 2023-05-17 06:22:22 --> Helper loaded: form_helper
INFO - 2023-05-17 06:22:22 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:22:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:22:22 --> Final output sent to browser
DEBUG - 2023-05-17 06:22:22 --> Total execution time: 0.0023
INFO - 2023-05-17 06:22:22 --> Config Class Initialized
INFO - 2023-05-17 06:22:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:22:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:22:22 --> Utf8 Class Initialized
INFO - 2023-05-17 06:22:22 --> URI Class Initialized
INFO - 2023-05-17 06:22:22 --> Router Class Initialized
INFO - 2023-05-17 06:22:22 --> Output Class Initialized
INFO - 2023-05-17 06:22:22 --> Security Class Initialized
DEBUG - 2023-05-17 06:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:22:22 --> Input Class Initialized
INFO - 2023-05-17 06:22:22 --> Language Class Initialized
INFO - 2023-05-17 06:22:22 --> Loader Class Initialized
INFO - 2023-05-17 06:22:22 --> Controller Class Initialized
INFO - 2023-05-17 06:22:22 --> Helper loaded: form_helper
INFO - 2023-05-17 06:22:22 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:22:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:22:22 --> Database Driver Class Initialized
INFO - 2023-05-17 06:22:22 --> Model "Login_model" initialized
INFO - 2023-05-17 06:22:22 --> Final output sent to browser
DEBUG - 2023-05-17 06:22:22 --> Total execution time: 0.0141
INFO - 2023-05-17 06:27:12 --> Config Class Initialized
INFO - 2023-05-17 06:27:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:27:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:27:12 --> Utf8 Class Initialized
INFO - 2023-05-17 06:27:12 --> URI Class Initialized
INFO - 2023-05-17 06:27:12 --> Router Class Initialized
INFO - 2023-05-17 06:27:12 --> Output Class Initialized
INFO - 2023-05-17 06:27:12 --> Security Class Initialized
DEBUG - 2023-05-17 06:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:27:12 --> Input Class Initialized
INFO - 2023-05-17 06:27:12 --> Language Class Initialized
INFO - 2023-05-17 06:27:12 --> Loader Class Initialized
INFO - 2023-05-17 06:27:12 --> Controller Class Initialized
DEBUG - 2023-05-17 06:27:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:27:12 --> Database Driver Class Initialized
INFO - 2023-05-17 06:27:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:27:12 --> Final output sent to browser
DEBUG - 2023-05-17 06:27:12 --> Total execution time: 0.0980
INFO - 2023-05-17 06:27:12 --> Config Class Initialized
INFO - 2023-05-17 06:27:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:27:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:27:12 --> Utf8 Class Initialized
INFO - 2023-05-17 06:27:12 --> URI Class Initialized
INFO - 2023-05-17 06:27:12 --> Router Class Initialized
INFO - 2023-05-17 06:27:12 --> Output Class Initialized
INFO - 2023-05-17 06:27:12 --> Security Class Initialized
DEBUG - 2023-05-17 06:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:27:12 --> Input Class Initialized
INFO - 2023-05-17 06:27:12 --> Language Class Initialized
INFO - 2023-05-17 06:27:12 --> Loader Class Initialized
INFO - 2023-05-17 06:27:12 --> Controller Class Initialized
DEBUG - 2023-05-17 06:27:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:27:12 --> Database Driver Class Initialized
INFO - 2023-05-17 06:27:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 06:27:12 --> Final output sent to browser
DEBUG - 2023-05-17 06:27:12 --> Total execution time: 0.0561
INFO - 2023-05-17 06:27:27 --> Config Class Initialized
INFO - 2023-05-17 06:27:27 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:27:27 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:27:27 --> Utf8 Class Initialized
INFO - 2023-05-17 06:27:27 --> URI Class Initialized
INFO - 2023-05-17 06:27:27 --> Router Class Initialized
INFO - 2023-05-17 06:27:27 --> Output Class Initialized
INFO - 2023-05-17 06:27:27 --> Security Class Initialized
DEBUG - 2023-05-17 06:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:27:27 --> Input Class Initialized
INFO - 2023-05-17 06:27:27 --> Language Class Initialized
INFO - 2023-05-17 06:27:27 --> Loader Class Initialized
INFO - 2023-05-17 06:27:27 --> Controller Class Initialized
INFO - 2023-05-17 06:27:27 --> Helper loaded: form_helper
INFO - 2023-05-17 06:27:27 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:27:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:27:27 --> Model "Change_model" initialized
INFO - 2023-05-17 06:27:27 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:30:31 --> Config Class Initialized
INFO - 2023-05-17 06:30:31 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:30:31 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:30:31 --> Utf8 Class Initialized
INFO - 2023-05-17 06:30:31 --> URI Class Initialized
INFO - 2023-05-17 06:30:31 --> Router Class Initialized
INFO - 2023-05-17 06:30:31 --> Output Class Initialized
INFO - 2023-05-17 06:30:31 --> Security Class Initialized
DEBUG - 2023-05-17 06:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:30:31 --> Input Class Initialized
INFO - 2023-05-17 06:30:31 --> Language Class Initialized
INFO - 2023-05-17 06:30:31 --> Loader Class Initialized
INFO - 2023-05-17 06:30:31 --> Controller Class Initialized
INFO - 2023-05-17 06:30:31 --> Helper loaded: form_helper
INFO - 2023-05-17 06:30:31 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:30:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:30:31 --> Model "Change_model" initialized
INFO - 2023-05-17 06:30:31 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:31:22 --> Config Class Initialized
INFO - 2023-05-17 06:31:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:31:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:31:22 --> Utf8 Class Initialized
INFO - 2023-05-17 06:31:22 --> URI Class Initialized
INFO - 2023-05-17 06:31:22 --> Router Class Initialized
INFO - 2023-05-17 06:31:22 --> Output Class Initialized
INFO - 2023-05-17 06:31:22 --> Security Class Initialized
DEBUG - 2023-05-17 06:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:31:22 --> Input Class Initialized
INFO - 2023-05-17 06:31:22 --> Language Class Initialized
INFO - 2023-05-17 06:31:22 --> Loader Class Initialized
INFO - 2023-05-17 06:31:22 --> Controller Class Initialized
INFO - 2023-05-17 06:31:22 --> Helper loaded: form_helper
INFO - 2023-05-17 06:31:22 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:31:22 --> Model "Change_model" initialized
INFO - 2023-05-17 06:31:22 --> Model "Grafana_model" initialized
INFO - 2023-05-17 06:33:52 --> Config Class Initialized
INFO - 2023-05-17 06:33:52 --> Hooks Class Initialized
DEBUG - 2023-05-17 06:33:52 --> UTF-8 Support Enabled
INFO - 2023-05-17 06:33:52 --> Utf8 Class Initialized
INFO - 2023-05-17 06:33:52 --> URI Class Initialized
INFO - 2023-05-17 06:33:52 --> Router Class Initialized
INFO - 2023-05-17 06:33:52 --> Output Class Initialized
INFO - 2023-05-17 06:33:52 --> Security Class Initialized
DEBUG - 2023-05-17 06:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 06:33:52 --> Input Class Initialized
INFO - 2023-05-17 06:33:52 --> Language Class Initialized
INFO - 2023-05-17 06:33:52 --> Loader Class Initialized
INFO - 2023-05-17 06:33:52 --> Controller Class Initialized
INFO - 2023-05-17 06:33:52 --> Helper loaded: form_helper
INFO - 2023-05-17 06:33:52 --> Helper loaded: url_helper
DEBUG - 2023-05-17 06:33:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 06:33:52 --> Model "Change_model" initialized
INFO - 2023-05-17 06:33:52 --> Model "Grafana_model" initialized
INFO - 2023-05-17 07:16:10 --> Config Class Initialized
INFO - 2023-05-17 07:16:10 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:16:10 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:16:10 --> Utf8 Class Initialized
INFO - 2023-05-17 07:16:10 --> URI Class Initialized
INFO - 2023-05-17 07:16:10 --> Router Class Initialized
INFO - 2023-05-17 07:16:10 --> Output Class Initialized
INFO - 2023-05-17 07:16:10 --> Security Class Initialized
DEBUG - 2023-05-17 07:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:16:10 --> Input Class Initialized
INFO - 2023-05-17 07:16:10 --> Language Class Initialized
INFO - 2023-05-17 07:16:10 --> Loader Class Initialized
INFO - 2023-05-17 07:16:10 --> Controller Class Initialized
INFO - 2023-05-17 07:16:10 --> Helper loaded: form_helper
INFO - 2023-05-17 07:16:10 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:16:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:16:10 --> Model "Change_model" initialized
INFO - 2023-05-17 07:16:10 --> Model "Grafana_model" initialized
INFO - 2023-05-17 07:21:12 --> Config Class Initialized
INFO - 2023-05-17 07:21:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:21:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:21:12 --> Utf8 Class Initialized
INFO - 2023-05-17 07:21:12 --> URI Class Initialized
INFO - 2023-05-17 07:21:12 --> Router Class Initialized
INFO - 2023-05-17 07:21:12 --> Output Class Initialized
INFO - 2023-05-17 07:21:12 --> Security Class Initialized
DEBUG - 2023-05-17 07:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:21:12 --> Input Class Initialized
INFO - 2023-05-17 07:21:12 --> Language Class Initialized
INFO - 2023-05-17 07:21:12 --> Loader Class Initialized
INFO - 2023-05-17 07:21:12 --> Controller Class Initialized
INFO - 2023-05-17 07:21:12 --> Helper loaded: form_helper
INFO - 2023-05-17 07:21:12 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:21:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:21:12 --> Model "Change_model" initialized
INFO - 2023-05-17 07:21:12 --> Model "Grafana_model" initialized
INFO - 2023-05-17 07:24:18 --> Config Class Initialized
INFO - 2023-05-17 07:24:18 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:24:18 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:24:18 --> Utf8 Class Initialized
INFO - 2023-05-17 07:24:18 --> URI Class Initialized
INFO - 2023-05-17 07:24:18 --> Router Class Initialized
INFO - 2023-05-17 07:24:18 --> Output Class Initialized
INFO - 2023-05-17 07:24:18 --> Security Class Initialized
DEBUG - 2023-05-17 07:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:24:18 --> Input Class Initialized
INFO - 2023-05-17 07:24:18 --> Language Class Initialized
INFO - 2023-05-17 07:24:18 --> Loader Class Initialized
INFO - 2023-05-17 07:24:18 --> Controller Class Initialized
INFO - 2023-05-17 07:24:18 --> Helper loaded: form_helper
INFO - 2023-05-17 07:24:18 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:24:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:24:18 --> Model "Change_model" initialized
INFO - 2023-05-17 07:24:18 --> Model "Grafana_model" initialized
INFO - 2023-05-17 07:30:24 --> Config Class Initialized
INFO - 2023-05-17 07:30:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:30:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:30:24 --> Utf8 Class Initialized
INFO - 2023-05-17 07:30:24 --> URI Class Initialized
INFO - 2023-05-17 07:30:24 --> Router Class Initialized
INFO - 2023-05-17 07:30:24 --> Output Class Initialized
INFO - 2023-05-17 07:30:24 --> Security Class Initialized
DEBUG - 2023-05-17 07:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:30:24 --> Input Class Initialized
INFO - 2023-05-17 07:30:24 --> Language Class Initialized
INFO - 2023-05-17 07:30:24 --> Loader Class Initialized
INFO - 2023-05-17 07:30:24 --> Controller Class Initialized
INFO - 2023-05-17 07:30:24 --> Helper loaded: form_helper
INFO - 2023-05-17 07:30:24 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:30:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:30:24 --> Model "Change_model" initialized
INFO - 2023-05-17 07:30:24 --> Model "Grafana_model" initialized
INFO - 2023-05-17 07:30:24 --> Final output sent to browser
DEBUG - 2023-05-17 07:30:24 --> Total execution time: 0.0893
INFO - 2023-05-17 07:30:37 --> Config Class Initialized
INFO - 2023-05-17 07:30:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:30:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:30:37 --> Utf8 Class Initialized
INFO - 2023-05-17 07:30:37 --> URI Class Initialized
INFO - 2023-05-17 07:30:37 --> Router Class Initialized
INFO - 2023-05-17 07:30:37 --> Output Class Initialized
INFO - 2023-05-17 07:30:37 --> Security Class Initialized
DEBUG - 2023-05-17 07:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:30:37 --> Input Class Initialized
INFO - 2023-05-17 07:30:37 --> Language Class Initialized
INFO - 2023-05-17 07:30:37 --> Loader Class Initialized
INFO - 2023-05-17 07:30:37 --> Controller Class Initialized
INFO - 2023-05-17 07:30:37 --> Helper loaded: form_helper
INFO - 2023-05-17 07:30:37 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:30:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:30:37 --> Model "Change_model" initialized
INFO - 2023-05-17 07:30:37 --> Model "Grafana_model" initialized
INFO - 2023-05-17 07:30:37 --> Final output sent to browser
DEBUG - 2023-05-17 07:30:37 --> Total execution time: 0.0390
INFO - 2023-05-17 07:31:00 --> Config Class Initialized
INFO - 2023-05-17 07:31:00 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:31:00 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:31:00 --> Utf8 Class Initialized
INFO - 2023-05-17 07:31:00 --> URI Class Initialized
INFO - 2023-05-17 07:31:00 --> Router Class Initialized
INFO - 2023-05-17 07:31:00 --> Output Class Initialized
INFO - 2023-05-17 07:31:00 --> Security Class Initialized
DEBUG - 2023-05-17 07:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:31:00 --> Input Class Initialized
INFO - 2023-05-17 07:31:00 --> Language Class Initialized
INFO - 2023-05-17 07:31:00 --> Loader Class Initialized
INFO - 2023-05-17 07:31:00 --> Controller Class Initialized
INFO - 2023-05-17 07:31:00 --> Helper loaded: form_helper
INFO - 2023-05-17 07:31:00 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:31:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:31:00 --> Model "Change_model" initialized
INFO - 2023-05-17 07:31:00 --> Model "Grafana_model" initialized
INFO - 2023-05-17 07:31:00 --> Final output sent to browser
DEBUG - 2023-05-17 07:31:00 --> Total execution time: 0.0511
INFO - 2023-05-17 07:37:12 --> Config Class Initialized
INFO - 2023-05-17 07:37:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:37:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:37:12 --> Utf8 Class Initialized
INFO - 2023-05-17 07:37:12 --> URI Class Initialized
INFO - 2023-05-17 07:37:12 --> Router Class Initialized
INFO - 2023-05-17 07:37:12 --> Output Class Initialized
INFO - 2023-05-17 07:37:12 --> Security Class Initialized
DEBUG - 2023-05-17 07:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:37:12 --> Input Class Initialized
INFO - 2023-05-17 07:37:12 --> Language Class Initialized
INFO - 2023-05-17 07:37:12 --> Loader Class Initialized
INFO - 2023-05-17 07:37:12 --> Controller Class Initialized
INFO - 2023-05-17 07:37:12 --> Helper loaded: form_helper
INFO - 2023-05-17 07:37:12 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:37:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:37:12 --> Model "Change_model" initialized
INFO - 2023-05-17 07:37:12 --> Model "Grafana_model" initialized
INFO - 2023-05-17 07:37:12 --> Final output sent to browser
DEBUG - 2023-05-17 07:37:12 --> Total execution time: 0.0523
INFO - 2023-05-17 07:37:16 --> Config Class Initialized
INFO - 2023-05-17 07:37:16 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:37:16 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:37:16 --> Utf8 Class Initialized
INFO - 2023-05-17 07:37:16 --> URI Class Initialized
INFO - 2023-05-17 07:37:16 --> Router Class Initialized
INFO - 2023-05-17 07:37:16 --> Output Class Initialized
INFO - 2023-05-17 07:37:16 --> Security Class Initialized
DEBUG - 2023-05-17 07:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:37:16 --> Input Class Initialized
INFO - 2023-05-17 07:37:16 --> Language Class Initialized
INFO - 2023-05-17 07:37:16 --> Loader Class Initialized
INFO - 2023-05-17 07:37:16 --> Controller Class Initialized
INFO - 2023-05-17 07:37:16 --> Helper loaded: form_helper
INFO - 2023-05-17 07:37:16 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:37:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:37:16 --> Model "Change_model" initialized
INFO - 2023-05-17 07:37:16 --> Model "Grafana_model" initialized
INFO - 2023-05-17 07:37:16 --> Final output sent to browser
DEBUG - 2023-05-17 07:37:16 --> Total execution time: 0.0794
INFO - 2023-05-17 07:39:41 --> Config Class Initialized
INFO - 2023-05-17 07:39:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:39:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:39:41 --> Utf8 Class Initialized
INFO - 2023-05-17 07:39:41 --> URI Class Initialized
INFO - 2023-05-17 07:39:41 --> Router Class Initialized
INFO - 2023-05-17 07:39:41 --> Output Class Initialized
INFO - 2023-05-17 07:39:41 --> Security Class Initialized
DEBUG - 2023-05-17 07:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:39:41 --> Input Class Initialized
INFO - 2023-05-17 07:39:41 --> Language Class Initialized
INFO - 2023-05-17 07:39:41 --> Loader Class Initialized
INFO - 2023-05-17 07:39:41 --> Controller Class Initialized
INFO - 2023-05-17 07:39:41 --> Helper loaded: form_helper
INFO - 2023-05-17 07:39:41 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:39:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:39:41 --> Model "Change_model" initialized
INFO - 2023-05-17 07:39:41 --> Model "Grafana_model" initialized
INFO - 2023-05-17 07:39:41 --> Final output sent to browser
DEBUG - 2023-05-17 07:39:41 --> Total execution time: 0.0496
INFO - 2023-05-17 07:39:45 --> Config Class Initialized
INFO - 2023-05-17 07:39:45 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:39:45 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:39:45 --> Utf8 Class Initialized
INFO - 2023-05-17 07:39:45 --> URI Class Initialized
INFO - 2023-05-17 07:39:45 --> Router Class Initialized
INFO - 2023-05-17 07:39:45 --> Output Class Initialized
INFO - 2023-05-17 07:39:45 --> Security Class Initialized
DEBUG - 2023-05-17 07:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:39:45 --> Input Class Initialized
INFO - 2023-05-17 07:39:45 --> Language Class Initialized
INFO - 2023-05-17 07:39:45 --> Loader Class Initialized
INFO - 2023-05-17 07:39:45 --> Controller Class Initialized
INFO - 2023-05-17 07:39:45 --> Helper loaded: form_helper
INFO - 2023-05-17 07:39:45 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:39:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:39:45 --> Model "Change_model" initialized
INFO - 2023-05-17 07:39:45 --> Model "Grafana_model" initialized
INFO - 2023-05-17 07:39:45 --> Final output sent to browser
DEBUG - 2023-05-17 07:39:45 --> Total execution time: 0.0379
INFO - 2023-05-17 07:48:33 --> Config Class Initialized
INFO - 2023-05-17 07:48:33 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:48:33 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:48:33 --> Utf8 Class Initialized
INFO - 2023-05-17 07:48:33 --> URI Class Initialized
INFO - 2023-05-17 07:48:33 --> Router Class Initialized
INFO - 2023-05-17 07:48:33 --> Output Class Initialized
INFO - 2023-05-17 07:48:33 --> Security Class Initialized
DEBUG - 2023-05-17 07:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:48:33 --> Input Class Initialized
INFO - 2023-05-17 07:48:33 --> Language Class Initialized
INFO - 2023-05-17 07:48:33 --> Loader Class Initialized
INFO - 2023-05-17 07:48:33 --> Controller Class Initialized
INFO - 2023-05-17 07:48:33 --> Helper loaded: form_helper
INFO - 2023-05-17 07:48:33 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:48:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:48:33 --> Model "Change_model" initialized
INFO - 2023-05-17 07:48:33 --> Model "Grafana_model" initialized
INFO - 2023-05-17 07:48:33 --> Final output sent to browser
DEBUG - 2023-05-17 07:48:33 --> Total execution time: 0.0877
INFO - 2023-05-17 07:48:57 --> Config Class Initialized
INFO - 2023-05-17 07:48:57 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:48:57 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:48:57 --> Utf8 Class Initialized
INFO - 2023-05-17 07:48:57 --> URI Class Initialized
INFO - 2023-05-17 07:48:57 --> Router Class Initialized
INFO - 2023-05-17 07:48:57 --> Output Class Initialized
INFO - 2023-05-17 07:48:57 --> Security Class Initialized
DEBUG - 2023-05-17 07:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:48:57 --> Input Class Initialized
INFO - 2023-05-17 07:48:57 --> Language Class Initialized
INFO - 2023-05-17 07:48:57 --> Loader Class Initialized
INFO - 2023-05-17 07:48:57 --> Controller Class Initialized
INFO - 2023-05-17 07:48:57 --> Helper loaded: form_helper
INFO - 2023-05-17 07:48:57 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:48:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:48:57 --> Model "Change_model" initialized
INFO - 2023-05-17 07:48:57 --> Model "Grafana_model" initialized
INFO - 2023-05-17 07:48:57 --> Final output sent to browser
DEBUG - 2023-05-17 07:48:57 --> Total execution time: 0.0347
INFO - 2023-05-17 07:48:57 --> Config Class Initialized
INFO - 2023-05-17 07:48:57 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:48:57 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:48:57 --> Utf8 Class Initialized
INFO - 2023-05-17 07:48:57 --> URI Class Initialized
INFO - 2023-05-17 07:48:57 --> Router Class Initialized
INFO - 2023-05-17 07:48:57 --> Output Class Initialized
INFO - 2023-05-17 07:48:57 --> Security Class Initialized
DEBUG - 2023-05-17 07:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:48:57 --> Input Class Initialized
INFO - 2023-05-17 07:48:57 --> Language Class Initialized
INFO - 2023-05-17 07:48:57 --> Loader Class Initialized
INFO - 2023-05-17 07:48:57 --> Controller Class Initialized
INFO - 2023-05-17 07:48:57 --> Helper loaded: form_helper
INFO - 2023-05-17 07:48:57 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:48:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:48:57 --> Final output sent to browser
DEBUG - 2023-05-17 07:48:57 --> Total execution time: 0.0429
INFO - 2023-05-17 07:48:57 --> Config Class Initialized
INFO - 2023-05-17 07:48:57 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:48:57 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:48:57 --> Utf8 Class Initialized
INFO - 2023-05-17 07:48:57 --> URI Class Initialized
INFO - 2023-05-17 07:48:57 --> Router Class Initialized
INFO - 2023-05-17 07:48:57 --> Output Class Initialized
INFO - 2023-05-17 07:48:57 --> Security Class Initialized
DEBUG - 2023-05-17 07:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:48:57 --> Input Class Initialized
INFO - 2023-05-17 07:48:57 --> Language Class Initialized
INFO - 2023-05-17 07:48:57 --> Loader Class Initialized
INFO - 2023-05-17 07:48:57 --> Controller Class Initialized
INFO - 2023-05-17 07:48:57 --> Helper loaded: form_helper
INFO - 2023-05-17 07:48:57 --> Helper loaded: url_helper
DEBUG - 2023-05-17 07:48:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:48:57 --> Database Driver Class Initialized
INFO - 2023-05-17 07:48:57 --> Model "Login_model" initialized
INFO - 2023-05-17 07:48:57 --> Final output sent to browser
DEBUG - 2023-05-17 07:48:57 --> Total execution time: 0.0171
INFO - 2023-05-17 07:48:58 --> Config Class Initialized
INFO - 2023-05-17 07:48:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:48:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:48:58 --> Utf8 Class Initialized
INFO - 2023-05-17 07:48:58 --> URI Class Initialized
INFO - 2023-05-17 07:48:58 --> Router Class Initialized
INFO - 2023-05-17 07:48:58 --> Output Class Initialized
INFO - 2023-05-17 07:48:58 --> Security Class Initialized
DEBUG - 2023-05-17 07:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:48:58 --> Input Class Initialized
INFO - 2023-05-17 07:48:58 --> Language Class Initialized
INFO - 2023-05-17 07:48:58 --> Loader Class Initialized
INFO - 2023-05-17 07:48:58 --> Controller Class Initialized
DEBUG - 2023-05-17 07:48:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:48:58 --> Database Driver Class Initialized
INFO - 2023-05-17 07:48:58 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:48:58 --> Final output sent to browser
DEBUG - 2023-05-17 07:48:58 --> Total execution time: 0.0714
INFO - 2023-05-17 07:48:58 --> Config Class Initialized
INFO - 2023-05-17 07:48:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:48:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:48:58 --> Utf8 Class Initialized
INFO - 2023-05-17 07:48:58 --> URI Class Initialized
INFO - 2023-05-17 07:48:58 --> Router Class Initialized
INFO - 2023-05-17 07:48:58 --> Output Class Initialized
INFO - 2023-05-17 07:48:58 --> Security Class Initialized
DEBUG - 2023-05-17 07:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:48:58 --> Input Class Initialized
INFO - 2023-05-17 07:48:58 --> Language Class Initialized
INFO - 2023-05-17 07:48:58 --> Loader Class Initialized
INFO - 2023-05-17 07:48:58 --> Controller Class Initialized
DEBUG - 2023-05-17 07:48:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:48:58 --> Database Driver Class Initialized
INFO - 2023-05-17 07:48:58 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:48:58 --> Final output sent to browser
DEBUG - 2023-05-17 07:48:58 --> Total execution time: 0.0111
INFO - 2023-05-17 07:48:58 --> Config Class Initialized
INFO - 2023-05-17 07:48:58 --> Config Class Initialized
INFO - 2023-05-17 07:48:58 --> Hooks Class Initialized
INFO - 2023-05-17 07:48:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:48:58 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 07:48:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:48:58 --> Utf8 Class Initialized
INFO - 2023-05-17 07:48:58 --> Utf8 Class Initialized
INFO - 2023-05-17 07:48:58 --> URI Class Initialized
INFO - 2023-05-17 07:48:58 --> URI Class Initialized
INFO - 2023-05-17 07:48:58 --> Router Class Initialized
INFO - 2023-05-17 07:48:58 --> Router Class Initialized
INFO - 2023-05-17 07:48:58 --> Output Class Initialized
INFO - 2023-05-17 07:48:58 --> Output Class Initialized
INFO - 2023-05-17 07:48:58 --> Security Class Initialized
INFO - 2023-05-17 07:48:58 --> Security Class Initialized
DEBUG - 2023-05-17 07:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 07:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:48:58 --> Input Class Initialized
INFO - 2023-05-17 07:48:58 --> Input Class Initialized
INFO - 2023-05-17 07:48:58 --> Language Class Initialized
INFO - 2023-05-17 07:48:58 --> Language Class Initialized
INFO - 2023-05-17 07:48:58 --> Loader Class Initialized
INFO - 2023-05-17 07:48:58 --> Loader Class Initialized
INFO - 2023-05-17 07:48:58 --> Controller Class Initialized
DEBUG - 2023-05-17 07:48:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:48:58 --> Controller Class Initialized
DEBUG - 2023-05-17 07:48:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:48:58 --> Database Driver Class Initialized
INFO - 2023-05-17 07:48:58 --> Database Driver Class Initialized
INFO - 2023-05-17 07:48:58 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:48:58 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:48:58 --> Final output sent to browser
DEBUG - 2023-05-17 07:48:58 --> Total execution time: 0.0561
INFO - 2023-05-17 07:48:58 --> Config Class Initialized
INFO - 2023-05-17 07:48:58 --> Database Driver Class Initialized
INFO - 2023-05-17 07:48:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:48:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:48:58 --> Utf8 Class Initialized
INFO - 2023-05-17 07:48:58 --> URI Class Initialized
INFO - 2023-05-17 07:48:58 --> Router Class Initialized
INFO - 2023-05-17 07:48:58 --> Output Class Initialized
INFO - 2023-05-17 07:48:58 --> Security Class Initialized
DEBUG - 2023-05-17 07:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:48:58 --> Input Class Initialized
INFO - 2023-05-17 07:48:58 --> Language Class Initialized
INFO - 2023-05-17 07:48:58 --> Loader Class Initialized
INFO - 2023-05-17 07:48:58 --> Controller Class Initialized
DEBUG - 2023-05-17 07:48:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:48:58 --> Database Driver Class Initialized
INFO - 2023-05-17 07:48:58 --> Model "Login_model" initialized
INFO - 2023-05-17 07:48:58 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:48:58 --> Final output sent to browser
DEBUG - 2023-05-17 07:48:58 --> Total execution time: 0.0517
INFO - 2023-05-17 07:48:58 --> Final output sent to browser
DEBUG - 2023-05-17 07:48:58 --> Total execution time: 0.1637
INFO - 2023-05-17 07:48:58 --> Config Class Initialized
INFO - 2023-05-17 07:48:58 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:48:58 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:48:58 --> Utf8 Class Initialized
INFO - 2023-05-17 07:48:58 --> URI Class Initialized
INFO - 2023-05-17 07:48:58 --> Router Class Initialized
INFO - 2023-05-17 07:48:58 --> Output Class Initialized
INFO - 2023-05-17 07:48:58 --> Security Class Initialized
DEBUG - 2023-05-17 07:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:48:58 --> Input Class Initialized
INFO - 2023-05-17 07:48:58 --> Language Class Initialized
INFO - 2023-05-17 07:48:58 --> Loader Class Initialized
INFO - 2023-05-17 07:48:58 --> Controller Class Initialized
DEBUG - 2023-05-17 07:48:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:48:58 --> Database Driver Class Initialized
INFO - 2023-05-17 07:48:58 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:48:58 --> Database Driver Class Initialized
INFO - 2023-05-17 07:48:58 --> Model "Login_model" initialized
INFO - 2023-05-17 07:48:58 --> Final output sent to browser
DEBUG - 2023-05-17 07:48:58 --> Total execution time: 0.1213
INFO - 2023-05-17 07:49:03 --> Config Class Initialized
INFO - 2023-05-17 07:49:03 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:49:03 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:49:03 --> Utf8 Class Initialized
INFO - 2023-05-17 07:49:03 --> URI Class Initialized
INFO - 2023-05-17 07:49:03 --> Router Class Initialized
INFO - 2023-05-17 07:49:03 --> Output Class Initialized
INFO - 2023-05-17 07:49:03 --> Security Class Initialized
DEBUG - 2023-05-17 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:49:03 --> Input Class Initialized
INFO - 2023-05-17 07:49:03 --> Language Class Initialized
INFO - 2023-05-17 07:49:03 --> Loader Class Initialized
INFO - 2023-05-17 07:49:03 --> Controller Class Initialized
DEBUG - 2023-05-17 07:49:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:49:03 --> Database Driver Class Initialized
INFO - 2023-05-17 07:49:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:49:03 --> Final output sent to browser
DEBUG - 2023-05-17 07:49:03 --> Total execution time: 0.0124
INFO - 2023-05-17 07:49:03 --> Config Class Initialized
INFO - 2023-05-17 07:49:03 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:49:03 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:49:03 --> Utf8 Class Initialized
INFO - 2023-05-17 07:49:03 --> URI Class Initialized
INFO - 2023-05-17 07:49:03 --> Router Class Initialized
INFO - 2023-05-17 07:49:03 --> Output Class Initialized
INFO - 2023-05-17 07:49:03 --> Security Class Initialized
DEBUG - 2023-05-17 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:49:03 --> Input Class Initialized
INFO - 2023-05-17 07:49:03 --> Language Class Initialized
INFO - 2023-05-17 07:49:03 --> Loader Class Initialized
INFO - 2023-05-17 07:49:03 --> Controller Class Initialized
DEBUG - 2023-05-17 07:49:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:49:03 --> Database Driver Class Initialized
INFO - 2023-05-17 07:49:03 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:49:03 --> Final output sent to browser
DEBUG - 2023-05-17 07:49:03 --> Total execution time: 0.0161
INFO - 2023-05-17 07:56:38 --> Config Class Initialized
INFO - 2023-05-17 07:56:38 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:56:38 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:56:38 --> Utf8 Class Initialized
INFO - 2023-05-17 07:56:38 --> URI Class Initialized
INFO - 2023-05-17 07:56:38 --> Router Class Initialized
INFO - 2023-05-17 07:56:38 --> Output Class Initialized
INFO - 2023-05-17 07:56:38 --> Security Class Initialized
DEBUG - 2023-05-17 07:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:56:38 --> Input Class Initialized
INFO - 2023-05-17 07:56:38 --> Language Class Initialized
INFO - 2023-05-17 07:56:38 --> Loader Class Initialized
INFO - 2023-05-17 07:56:38 --> Controller Class Initialized
DEBUG - 2023-05-17 07:56:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:56:38 --> Database Driver Class Initialized
INFO - 2023-05-17 07:56:38 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:56:38 --> Final output sent to browser
DEBUG - 2023-05-17 07:56:38 --> Total execution time: 0.0331
INFO - 2023-05-17 07:56:38 --> Config Class Initialized
INFO - 2023-05-17 07:56:38 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:56:38 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:56:38 --> Utf8 Class Initialized
INFO - 2023-05-17 07:56:38 --> URI Class Initialized
INFO - 2023-05-17 07:56:38 --> Router Class Initialized
INFO - 2023-05-17 07:56:38 --> Output Class Initialized
INFO - 2023-05-17 07:56:38 --> Security Class Initialized
DEBUG - 2023-05-17 07:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:56:38 --> Input Class Initialized
INFO - 2023-05-17 07:56:38 --> Language Class Initialized
INFO - 2023-05-17 07:56:38 --> Loader Class Initialized
INFO - 2023-05-17 07:56:38 --> Controller Class Initialized
DEBUG - 2023-05-17 07:56:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:56:38 --> Database Driver Class Initialized
INFO - 2023-05-17 07:56:38 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:56:38 --> Final output sent to browser
DEBUG - 2023-05-17 07:56:38 --> Total execution time: 0.0539
INFO - 2023-05-17 07:56:41 --> Config Class Initialized
INFO - 2023-05-17 07:56:41 --> Hooks Class Initialized
INFO - 2023-05-17 07:56:41 --> Config Class Initialized
INFO - 2023-05-17 07:56:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:56:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 07:56:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:56:41 --> Utf8 Class Initialized
INFO - 2023-05-17 07:56:41 --> Utf8 Class Initialized
INFO - 2023-05-17 07:56:41 --> URI Class Initialized
INFO - 2023-05-17 07:56:41 --> URI Class Initialized
INFO - 2023-05-17 07:56:41 --> Router Class Initialized
INFO - 2023-05-17 07:56:41 --> Router Class Initialized
INFO - 2023-05-17 07:56:41 --> Output Class Initialized
INFO - 2023-05-17 07:56:41 --> Output Class Initialized
INFO - 2023-05-17 07:56:41 --> Security Class Initialized
INFO - 2023-05-17 07:56:41 --> Security Class Initialized
DEBUG - 2023-05-17 07:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 07:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:56:41 --> Input Class Initialized
INFO - 2023-05-17 07:56:41 --> Input Class Initialized
INFO - 2023-05-17 07:56:41 --> Language Class Initialized
INFO - 2023-05-17 07:56:41 --> Language Class Initialized
INFO - 2023-05-17 07:56:41 --> Loader Class Initialized
INFO - 2023-05-17 07:56:41 --> Loader Class Initialized
INFO - 2023-05-17 07:56:41 --> Controller Class Initialized
INFO - 2023-05-17 07:56:41 --> Controller Class Initialized
DEBUG - 2023-05-17 07:56:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 07:56:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:56:41 --> Database Driver Class Initialized
INFO - 2023-05-17 07:56:41 --> Database Driver Class Initialized
INFO - 2023-05-17 07:56:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:56:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:56:41 --> Final output sent to browser
DEBUG - 2023-05-17 07:56:41 --> Total execution time: 0.0565
INFO - 2023-05-17 07:56:41 --> Config Class Initialized
INFO - 2023-05-17 07:56:41 --> Final output sent to browser
INFO - 2023-05-17 07:56:41 --> Config Class Initialized
INFO - 2023-05-17 07:56:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:56:41 --> Total execution time: 0.0727
INFO - 2023-05-17 07:56:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:56:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:56:41 --> Utf8 Class Initialized
DEBUG - 2023-05-17 07:56:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:56:41 --> URI Class Initialized
INFO - 2023-05-17 07:56:41 --> Utf8 Class Initialized
INFO - 2023-05-17 07:56:41 --> Router Class Initialized
INFO - 2023-05-17 07:56:41 --> URI Class Initialized
INFO - 2023-05-17 07:56:41 --> Output Class Initialized
INFO - 2023-05-17 07:56:41 --> Router Class Initialized
INFO - 2023-05-17 07:56:41 --> Security Class Initialized
INFO - 2023-05-17 07:56:41 --> Output Class Initialized
DEBUG - 2023-05-17 07:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:56:41 --> Security Class Initialized
INFO - 2023-05-17 07:56:41 --> Input Class Initialized
DEBUG - 2023-05-17 07:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:56:41 --> Language Class Initialized
INFO - 2023-05-17 07:56:41 --> Input Class Initialized
INFO - 2023-05-17 07:56:41 --> Loader Class Initialized
INFO - 2023-05-17 07:56:41 --> Language Class Initialized
INFO - 2023-05-17 07:56:41 --> Controller Class Initialized
DEBUG - 2023-05-17 07:56:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:56:41 --> Loader Class Initialized
INFO - 2023-05-17 07:56:41 --> Database Driver Class Initialized
INFO - 2023-05-17 07:56:41 --> Controller Class Initialized
DEBUG - 2023-05-17 07:56:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:56:41 --> Database Driver Class Initialized
INFO - 2023-05-17 07:56:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:56:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:56:41 --> Final output sent to browser
DEBUG - 2023-05-17 07:56:41 --> Total execution time: 0.0813
INFO - 2023-05-17 07:56:41 --> Final output sent to browser
DEBUG - 2023-05-17 07:56:41 --> Total execution time: 0.0800
INFO - 2023-05-17 07:56:42 --> Config Class Initialized
INFO - 2023-05-17 07:56:42 --> Config Class Initialized
INFO - 2023-05-17 07:56:42 --> Hooks Class Initialized
INFO - 2023-05-17 07:56:42 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:56:42 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 07:56:42 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:56:42 --> Utf8 Class Initialized
INFO - 2023-05-17 07:56:42 --> Utf8 Class Initialized
INFO - 2023-05-17 07:56:42 --> URI Class Initialized
INFO - 2023-05-17 07:56:42 --> URI Class Initialized
INFO - 2023-05-17 07:56:42 --> Router Class Initialized
INFO - 2023-05-17 07:56:42 --> Router Class Initialized
INFO - 2023-05-17 07:56:42 --> Output Class Initialized
INFO - 2023-05-17 07:56:42 --> Output Class Initialized
INFO - 2023-05-17 07:56:42 --> Security Class Initialized
INFO - 2023-05-17 07:56:42 --> Security Class Initialized
DEBUG - 2023-05-17 07:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 07:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:56:42 --> Input Class Initialized
INFO - 2023-05-17 07:56:42 --> Input Class Initialized
INFO - 2023-05-17 07:56:42 --> Language Class Initialized
INFO - 2023-05-17 07:56:42 --> Language Class Initialized
INFO - 2023-05-17 07:56:42 --> Loader Class Initialized
INFO - 2023-05-17 07:56:42 --> Loader Class Initialized
INFO - 2023-05-17 07:56:42 --> Controller Class Initialized
INFO - 2023-05-17 07:56:42 --> Controller Class Initialized
DEBUG - 2023-05-17 07:56:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 07:56:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:56:42 --> Database Driver Class Initialized
INFO - 2023-05-17 07:56:42 --> Final output sent to browser
DEBUG - 2023-05-17 07:56:42 --> Total execution time: 0.0047
INFO - 2023-05-17 07:56:42 --> Config Class Initialized
INFO - 2023-05-17 07:56:42 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:56:42 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:56:42 --> Utf8 Class Initialized
INFO - 2023-05-17 07:56:42 --> URI Class Initialized
INFO - 2023-05-17 07:56:42 --> Router Class Initialized
INFO - 2023-05-17 07:56:42 --> Output Class Initialized
INFO - 2023-05-17 07:56:42 --> Security Class Initialized
DEBUG - 2023-05-17 07:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:56:42 --> Input Class Initialized
INFO - 2023-05-17 07:56:42 --> Language Class Initialized
INFO - 2023-05-17 07:56:42 --> Loader Class Initialized
INFO - 2023-05-17 07:56:42 --> Controller Class Initialized
DEBUG - 2023-05-17 07:56:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:56:42 --> Database Driver Class Initialized
INFO - 2023-05-17 07:56:42 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:56:42 --> Final output sent to browser
DEBUG - 2023-05-17 07:56:42 --> Total execution time: 0.0170
INFO - 2023-05-17 07:56:42 --> Model "Login_model" initialized
INFO - 2023-05-17 07:56:42 --> Config Class Initialized
INFO - 2023-05-17 07:56:42 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:56:42 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:56:42 --> Utf8 Class Initialized
INFO - 2023-05-17 07:56:42 --> URI Class Initialized
INFO - 2023-05-17 07:56:42 --> Router Class Initialized
INFO - 2023-05-17 07:56:42 --> Output Class Initialized
INFO - 2023-05-17 07:56:42 --> Database Driver Class Initialized
INFO - 2023-05-17 07:56:42 --> Security Class Initialized
DEBUG - 2023-05-17 07:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:56:42 --> Input Class Initialized
INFO - 2023-05-17 07:56:42 --> Language Class Initialized
INFO - 2023-05-17 07:56:42 --> Loader Class Initialized
INFO - 2023-05-17 07:56:42 --> Controller Class Initialized
DEBUG - 2023-05-17 07:56:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:56:42 --> Database Driver Class Initialized
INFO - 2023-05-17 07:56:43 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:56:43 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:56:43 --> Final output sent to browser
DEBUG - 2023-05-17 07:56:43 --> Total execution time: 0.0238
INFO - 2023-05-17 07:56:43 --> Final output sent to browser
DEBUG - 2023-05-17 07:56:43 --> Total execution time: 0.0157
INFO - 2023-05-17 07:59:11 --> Config Class Initialized
INFO - 2023-05-17 07:59:11 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:11 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:11 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:11 --> URI Class Initialized
INFO - 2023-05-17 07:59:11 --> Router Class Initialized
INFO - 2023-05-17 07:59:11 --> Output Class Initialized
INFO - 2023-05-17 07:59:11 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:11 --> Input Class Initialized
INFO - 2023-05-17 07:59:11 --> Language Class Initialized
INFO - 2023-05-17 07:59:11 --> Loader Class Initialized
INFO - 2023-05-17 07:59:11 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:11 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:11 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:11 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:11 --> Total execution time: 0.0186
INFO - 2023-05-17 07:59:11 --> Config Class Initialized
INFO - 2023-05-17 07:59:11 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:11 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:11 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:11 --> URI Class Initialized
INFO - 2023-05-17 07:59:11 --> Router Class Initialized
INFO - 2023-05-17 07:59:11 --> Output Class Initialized
INFO - 2023-05-17 07:59:11 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:11 --> Input Class Initialized
INFO - 2023-05-17 07:59:11 --> Language Class Initialized
INFO - 2023-05-17 07:59:11 --> Loader Class Initialized
INFO - 2023-05-17 07:59:11 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:11 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:11 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:11 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:11 --> Total execution time: 0.0161
INFO - 2023-05-17 07:59:13 --> Config Class Initialized
INFO - 2023-05-17 07:59:13 --> Config Class Initialized
INFO - 2023-05-17 07:59:13 --> Hooks Class Initialized
INFO - 2023-05-17 07:59:13 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:13 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 07:59:13 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:13 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:13 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:13 --> URI Class Initialized
INFO - 2023-05-17 07:59:13 --> Router Class Initialized
INFO - 2023-05-17 07:59:13 --> URI Class Initialized
INFO - 2023-05-17 07:59:13 --> Output Class Initialized
INFO - 2023-05-17 07:59:13 --> Router Class Initialized
INFO - 2023-05-17 07:59:13 --> Security Class Initialized
INFO - 2023-05-17 07:59:13 --> Output Class Initialized
INFO - 2023-05-17 07:59:13 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 07:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:13 --> Input Class Initialized
INFO - 2023-05-17 07:59:13 --> Input Class Initialized
INFO - 2023-05-17 07:59:13 --> Language Class Initialized
INFO - 2023-05-17 07:59:13 --> Language Class Initialized
INFO - 2023-05-17 07:59:13 --> Loader Class Initialized
INFO - 2023-05-17 07:59:13 --> Loader Class Initialized
INFO - 2023-05-17 07:59:13 --> Controller Class Initialized
INFO - 2023-05-17 07:59:13 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:13 --> Database Driver Class Initialized
DEBUG - 2023-05-17 07:59:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:13 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:13 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:13 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:13 --> Total execution time: 0.0338
INFO - 2023-05-17 07:59:13 --> Config Class Initialized
INFO - 2023-05-17 07:59:13 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:13 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:13 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:13 --> URI Class Initialized
INFO - 2023-05-17 07:59:13 --> Router Class Initialized
INFO - 2023-05-17 07:59:13 --> Output Class Initialized
INFO - 2023-05-17 07:59:13 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:13 --> Input Class Initialized
INFO - 2023-05-17 07:59:13 --> Language Class Initialized
INFO - 2023-05-17 07:59:13 --> Loader Class Initialized
INFO - 2023-05-17 07:59:13 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:13 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:13 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:13 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:13 --> Total execution time: 0.0261
INFO - 2023-05-17 07:59:14 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:14 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:14 --> Total execution time: 1.0482
INFO - 2023-05-17 07:59:14 --> Config Class Initialized
INFO - 2023-05-17 07:59:14 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:14 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:14 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:14 --> URI Class Initialized
INFO - 2023-05-17 07:59:14 --> Router Class Initialized
INFO - 2023-05-17 07:59:14 --> Output Class Initialized
INFO - 2023-05-17 07:59:14 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:14 --> Input Class Initialized
INFO - 2023-05-17 07:59:14 --> Language Class Initialized
INFO - 2023-05-17 07:59:14 --> Loader Class Initialized
INFO - 2023-05-17 07:59:14 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:14 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:14 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:14 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:14 --> Total execution time: 0.0453
INFO - 2023-05-17 07:59:35 --> Config Class Initialized
INFO - 2023-05-17 07:59:35 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:35 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:35 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:35 --> URI Class Initialized
INFO - 2023-05-17 07:59:35 --> Router Class Initialized
INFO - 2023-05-17 07:59:35 --> Output Class Initialized
INFO - 2023-05-17 07:59:35 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:35 --> Input Class Initialized
INFO - 2023-05-17 07:59:35 --> Language Class Initialized
INFO - 2023-05-17 07:59:35 --> Loader Class Initialized
INFO - 2023-05-17 07:59:35 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:35 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:35 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:35 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:35 --> Total execution time: 0.0333
INFO - 2023-05-17 07:59:35 --> Config Class Initialized
INFO - 2023-05-17 07:59:35 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:35 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:35 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:35 --> URI Class Initialized
INFO - 2023-05-17 07:59:35 --> Router Class Initialized
INFO - 2023-05-17 07:59:35 --> Output Class Initialized
INFO - 2023-05-17 07:59:35 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:35 --> Input Class Initialized
INFO - 2023-05-17 07:59:35 --> Language Class Initialized
INFO - 2023-05-17 07:59:35 --> Loader Class Initialized
INFO - 2023-05-17 07:59:35 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:35 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:35 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:35 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:35 --> Total execution time: 0.0127
INFO - 2023-05-17 07:59:37 --> Config Class Initialized
INFO - 2023-05-17 07:59:37 --> Hooks Class Initialized
INFO - 2023-05-17 07:59:37 --> Config Class Initialized
INFO - 2023-05-17 07:59:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:37 --> Utf8 Class Initialized
DEBUG - 2023-05-17 07:59:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:37 --> URI Class Initialized
INFO - 2023-05-17 07:59:37 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:37 --> Router Class Initialized
INFO - 2023-05-17 07:59:37 --> URI Class Initialized
INFO - 2023-05-17 07:59:37 --> Output Class Initialized
INFO - 2023-05-17 07:59:37 --> Router Class Initialized
INFO - 2023-05-17 07:59:37 --> Security Class Initialized
INFO - 2023-05-17 07:59:37 --> Output Class Initialized
DEBUG - 2023-05-17 07:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:37 --> Security Class Initialized
INFO - 2023-05-17 07:59:37 --> Input Class Initialized
DEBUG - 2023-05-17 07:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:37 --> Language Class Initialized
INFO - 2023-05-17 07:59:37 --> Input Class Initialized
INFO - 2023-05-17 07:59:37 --> Language Class Initialized
INFO - 2023-05-17 07:59:37 --> Loader Class Initialized
INFO - 2023-05-17 07:59:37 --> Loader Class Initialized
INFO - 2023-05-17 07:59:37 --> Controller Class Initialized
INFO - 2023-05-17 07:59:37 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 07:59:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:37 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:37 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:37 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:37 --> Total execution time: 0.0455
INFO - 2023-05-17 07:59:37 --> Config Class Initialized
INFO - 2023-05-17 07:59:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:37 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:37 --> URI Class Initialized
INFO - 2023-05-17 07:59:37 --> Router Class Initialized
INFO - 2023-05-17 07:59:37 --> Output Class Initialized
INFO - 2023-05-17 07:59:37 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:37 --> Input Class Initialized
INFO - 2023-05-17 07:59:37 --> Language Class Initialized
INFO - 2023-05-17 07:59:37 --> Loader Class Initialized
INFO - 2023-05-17 07:59:37 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:37 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:37 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:37 --> Total execution time: 0.0677
INFO - 2023-05-17 07:59:37 --> Config Class Initialized
INFO - 2023-05-17 07:59:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:37 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:37 --> URI Class Initialized
INFO - 2023-05-17 07:59:37 --> Router Class Initialized
INFO - 2023-05-17 07:59:37 --> Output Class Initialized
INFO - 2023-05-17 07:59:37 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:37 --> Input Class Initialized
INFO - 2023-05-17 07:59:37 --> Language Class Initialized
INFO - 2023-05-17 07:59:37 --> Loader Class Initialized
INFO - 2023-05-17 07:59:37 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:37 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:37 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:37 --> Total execution time: 0.0339
INFO - 2023-05-17 07:59:37 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:37 --> Total execution time: 0.0467
INFO - 2023-05-17 07:59:38 --> Config Class Initialized
INFO - 2023-05-17 07:59:38 --> Config Class Initialized
INFO - 2023-05-17 07:59:38 --> Hooks Class Initialized
INFO - 2023-05-17 07:59:38 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:38 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 07:59:38 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:38 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:38 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:38 --> URI Class Initialized
INFO - 2023-05-17 07:59:38 --> URI Class Initialized
INFO - 2023-05-17 07:59:38 --> Router Class Initialized
INFO - 2023-05-17 07:59:38 --> Output Class Initialized
INFO - 2023-05-17 07:59:38 --> Router Class Initialized
INFO - 2023-05-17 07:59:38 --> Security Class Initialized
INFO - 2023-05-17 07:59:38 --> Output Class Initialized
DEBUG - 2023-05-17 07:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:38 --> Security Class Initialized
INFO - 2023-05-17 07:59:38 --> Input Class Initialized
DEBUG - 2023-05-17 07:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:38 --> Language Class Initialized
INFO - 2023-05-17 07:59:38 --> Input Class Initialized
INFO - 2023-05-17 07:59:38 --> Language Class Initialized
INFO - 2023-05-17 07:59:38 --> Loader Class Initialized
INFO - 2023-05-17 07:59:38 --> Loader Class Initialized
INFO - 2023-05-17 07:59:38 --> Controller Class Initialized
INFO - 2023-05-17 07:59:38 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 07:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:38 --> Final output sent to browser
INFO - 2023-05-17 07:59:38 --> Database Driver Class Initialized
DEBUG - 2023-05-17 07:59:38 --> Total execution time: 0.0069
INFO - 2023-05-17 07:59:38 --> Config Class Initialized
INFO - 2023-05-17 07:59:38 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:38 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:38 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:38 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:38 --> URI Class Initialized
INFO - 2023-05-17 07:59:38 --> Router Class Initialized
INFO - 2023-05-17 07:59:38 --> Output Class Initialized
INFO - 2023-05-17 07:59:38 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:38 --> Input Class Initialized
INFO - 2023-05-17 07:59:38 --> Language Class Initialized
INFO - 2023-05-17 07:59:38 --> Loader Class Initialized
INFO - 2023-05-17 07:59:38 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:38 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:38 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:38 --> Total execution time: 0.0547
INFO - 2023-05-17 07:59:38 --> Config Class Initialized
INFO - 2023-05-17 07:59:38 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:38 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:38 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:38 --> URI Class Initialized
INFO - 2023-05-17 07:59:38 --> Router Class Initialized
INFO - 2023-05-17 07:59:38 --> Output Class Initialized
INFO - 2023-05-17 07:59:38 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:38 --> Input Class Initialized
INFO - 2023-05-17 07:59:38 --> Language Class Initialized
INFO - 2023-05-17 07:59:38 --> Loader Class Initialized
INFO - 2023-05-17 07:59:38 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:38 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:38 --> Model "Login_model" initialized
INFO - 2023-05-17 07:59:38 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:38 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:38 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:38 --> Total execution time: 0.0181
INFO - 2023-05-17 07:59:38 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:38 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:38 --> Total execution time: 0.0676
INFO - 2023-05-17 07:59:41 --> Config Class Initialized
INFO - 2023-05-17 07:59:41 --> Config Class Initialized
INFO - 2023-05-17 07:59:41 --> Hooks Class Initialized
INFO - 2023-05-17 07:59:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 07:59:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:41 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:41 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:41 --> URI Class Initialized
INFO - 2023-05-17 07:59:41 --> URI Class Initialized
INFO - 2023-05-17 07:59:41 --> Router Class Initialized
INFO - 2023-05-17 07:59:41 --> Router Class Initialized
INFO - 2023-05-17 07:59:41 --> Output Class Initialized
INFO - 2023-05-17 07:59:41 --> Output Class Initialized
INFO - 2023-05-17 07:59:41 --> Security Class Initialized
INFO - 2023-05-17 07:59:41 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 07:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:41 --> Input Class Initialized
INFO - 2023-05-17 07:59:41 --> Input Class Initialized
INFO - 2023-05-17 07:59:41 --> Language Class Initialized
INFO - 2023-05-17 07:59:41 --> Language Class Initialized
INFO - 2023-05-17 07:59:41 --> Loader Class Initialized
INFO - 2023-05-17 07:59:41 --> Loader Class Initialized
INFO - 2023-05-17 07:59:41 --> Controller Class Initialized
INFO - 2023-05-17 07:59:41 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 07:59:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:41 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:41 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:41 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:41 --> Total execution time: 0.0208
INFO - 2023-05-17 07:59:41 --> Config Class Initialized
INFO - 2023-05-17 07:59:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:41 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:41 --> URI Class Initialized
INFO - 2023-05-17 07:59:41 --> Router Class Initialized
INFO - 2023-05-17 07:59:41 --> Output Class Initialized
INFO - 2023-05-17 07:59:41 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:41 --> Input Class Initialized
INFO - 2023-05-17 07:59:41 --> Language Class Initialized
INFO - 2023-05-17 07:59:41 --> Loader Class Initialized
INFO - 2023-05-17 07:59:41 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:41 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:41 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:41 --> Model "Login_model" initialized
INFO - 2023-05-17 07:59:41 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:41 --> Total execution time: 0.0132
INFO - 2023-05-17 07:59:41 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:41 --> Total execution time: 0.0973
INFO - 2023-05-17 07:59:41 --> Config Class Initialized
INFO - 2023-05-17 07:59:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:41 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:41 --> URI Class Initialized
INFO - 2023-05-17 07:59:41 --> Router Class Initialized
INFO - 2023-05-17 07:59:41 --> Output Class Initialized
INFO - 2023-05-17 07:59:41 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:41 --> Input Class Initialized
INFO - 2023-05-17 07:59:41 --> Language Class Initialized
INFO - 2023-05-17 07:59:41 --> Loader Class Initialized
INFO - 2023-05-17 07:59:41 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:41 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:41 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:41 --> Model "Login_model" initialized
INFO - 2023-05-17 07:59:41 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:41 --> Total execution time: 0.0876
INFO - 2023-05-17 07:59:45 --> Config Class Initialized
INFO - 2023-05-17 07:59:45 --> Config Class Initialized
INFO - 2023-05-17 07:59:45 --> Hooks Class Initialized
INFO - 2023-05-17 07:59:45 --> Config Class Initialized
INFO - 2023-05-17 07:59:45 --> Hooks Class Initialized
INFO - 2023-05-17 07:59:45 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:45 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 07:59:45 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:45 --> Utf8 Class Initialized
DEBUG - 2023-05-17 07:59:45 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:45 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:45 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:45 --> URI Class Initialized
INFO - 2023-05-17 07:59:45 --> URI Class Initialized
INFO - 2023-05-17 07:59:45 --> URI Class Initialized
INFO - 2023-05-17 07:59:45 --> Router Class Initialized
INFO - 2023-05-17 07:59:45 --> Router Class Initialized
INFO - 2023-05-17 07:59:45 --> Router Class Initialized
INFO - 2023-05-17 07:59:45 --> Output Class Initialized
INFO - 2023-05-17 07:59:45 --> Output Class Initialized
INFO - 2023-05-17 07:59:45 --> Output Class Initialized
INFO - 2023-05-17 07:59:45 --> Security Class Initialized
INFO - 2023-05-17 07:59:45 --> Security Class Initialized
INFO - 2023-05-17 07:59:45 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 07:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 07:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:45 --> Input Class Initialized
INFO - 2023-05-17 07:59:45 --> Input Class Initialized
INFO - 2023-05-17 07:59:45 --> Input Class Initialized
INFO - 2023-05-17 07:59:45 --> Language Class Initialized
INFO - 2023-05-17 07:59:45 --> Language Class Initialized
INFO - 2023-05-17 07:59:45 --> Language Class Initialized
INFO - 2023-05-17 07:59:45 --> Loader Class Initialized
INFO - 2023-05-17 07:59:45 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:45 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:45 --> Loader Class Initialized
INFO - 2023-05-17 07:59:45 --> Loader Class Initialized
INFO - 2023-05-17 07:59:45 --> Controller Class Initialized
INFO - 2023-05-17 07:59:45 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 07:59:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:45 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:45 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:45 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:45 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:45 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:45 --> Model "Login_model" initialized
INFO - 2023-05-17 07:59:45 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:45 --> Total execution time: 0.0279
INFO - 2023-05-17 07:59:45 --> Config Class Initialized
INFO - 2023-05-17 07:59:45 --> Final output sent to browser
INFO - 2023-05-17 07:59:45 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:45 --> Total execution time: 0.0328
DEBUG - 2023-05-17 07:59:45 --> Total execution time: 0.0397
INFO - 2023-05-17 07:59:45 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:45 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:45 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:45 --> Config Class Initialized
INFO - 2023-05-17 07:59:45 --> URI Class Initialized
INFO - 2023-05-17 07:59:45 --> Hooks Class Initialized
INFO - 2023-05-17 07:59:45 --> Config Class Initialized
INFO - 2023-05-17 07:59:45 --> Router Class Initialized
INFO - 2023-05-17 07:59:45 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:45 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:45 --> Output Class Initialized
INFO - 2023-05-17 07:59:45 --> Utf8 Class Initialized
DEBUG - 2023-05-17 07:59:45 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:45 --> Security Class Initialized
INFO - 2023-05-17 07:59:45 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:45 --> URI Class Initialized
DEBUG - 2023-05-17 07:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:45 --> URI Class Initialized
INFO - 2023-05-17 07:59:45 --> Input Class Initialized
INFO - 2023-05-17 07:59:45 --> Router Class Initialized
INFO - 2023-05-17 07:59:45 --> Language Class Initialized
INFO - 2023-05-17 07:59:45 --> Router Class Initialized
INFO - 2023-05-17 07:59:45 --> Output Class Initialized
INFO - 2023-05-17 07:59:45 --> Output Class Initialized
INFO - 2023-05-17 07:59:45 --> Loader Class Initialized
INFO - 2023-05-17 07:59:45 --> Security Class Initialized
INFO - 2023-05-17 07:59:45 --> Security Class Initialized
INFO - 2023-05-17 07:59:45 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 07:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 07:59:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:45 --> Input Class Initialized
INFO - 2023-05-17 07:59:45 --> Input Class Initialized
INFO - 2023-05-17 07:59:45 --> Language Class Initialized
INFO - 2023-05-17 07:59:45 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:45 --> Language Class Initialized
INFO - 2023-05-17 07:59:45 --> Loader Class Initialized
INFO - 2023-05-17 07:59:45 --> Loader Class Initialized
INFO - 2023-05-17 07:59:45 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:45 --> Controller Class Initialized
INFO - 2023-05-17 07:59:45 --> Database Driver Class Initialized
DEBUG - 2023-05-17 07:59:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:45 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:45 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:45 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:45 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:45 --> Model "Login_model" initialized
INFO - 2023-05-17 07:59:45 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:45 --> Total execution time: 0.0309
INFO - 2023-05-17 07:59:45 --> Config Class Initialized
INFO - 2023-05-17 07:59:45 --> Final output sent to browser
INFO - 2023-05-17 07:59:45 --> Final output sent to browser
INFO - 2023-05-17 07:59:45 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:45 --> Total execution time: 0.0404
DEBUG - 2023-05-17 07:59:45 --> Total execution time: 0.0764
DEBUG - 2023-05-17 07:59:45 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:45 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:45 --> URI Class Initialized
INFO - 2023-05-17 07:59:45 --> Config Class Initialized
INFO - 2023-05-17 07:59:45 --> Hooks Class Initialized
INFO - 2023-05-17 07:59:45 --> Router Class Initialized
DEBUG - 2023-05-17 07:59:45 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:45 --> Output Class Initialized
INFO - 2023-05-17 07:59:45 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:45 --> Security Class Initialized
INFO - 2023-05-17 07:59:45 --> URI Class Initialized
DEBUG - 2023-05-17 07:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:45 --> Input Class Initialized
INFO - 2023-05-17 07:59:45 --> Router Class Initialized
INFO - 2023-05-17 07:59:45 --> Language Class Initialized
INFO - 2023-05-17 07:59:45 --> Output Class Initialized
INFO - 2023-05-17 07:59:45 --> Loader Class Initialized
INFO - 2023-05-17 07:59:45 --> Security Class Initialized
INFO - 2023-05-17 07:59:45 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 07:59:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:45 --> Input Class Initialized
INFO - 2023-05-17 07:59:45 --> Language Class Initialized
INFO - 2023-05-17 07:59:45 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:45 --> Loader Class Initialized
INFO - 2023-05-17 07:59:45 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:45 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:45 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:45 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:45 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:45 --> Total execution time: 0.1051
INFO - 2023-05-17 07:59:45 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:45 --> Total execution time: 0.0631
INFO - 2023-05-17 07:59:47 --> Config Class Initialized
INFO - 2023-05-17 07:59:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:47 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:47 --> URI Class Initialized
INFO - 2023-05-17 07:59:47 --> Router Class Initialized
INFO - 2023-05-17 07:59:47 --> Output Class Initialized
INFO - 2023-05-17 07:59:47 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:47 --> Input Class Initialized
INFO - 2023-05-17 07:59:47 --> Language Class Initialized
INFO - 2023-05-17 07:59:47 --> Loader Class Initialized
INFO - 2023-05-17 07:59:47 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:47 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:47 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:47 --> Total execution time: 0.0339
INFO - 2023-05-17 07:59:47 --> Config Class Initialized
INFO - 2023-05-17 07:59:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 07:59:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 07:59:47 --> Utf8 Class Initialized
INFO - 2023-05-17 07:59:47 --> URI Class Initialized
INFO - 2023-05-17 07:59:47 --> Router Class Initialized
INFO - 2023-05-17 07:59:47 --> Output Class Initialized
INFO - 2023-05-17 07:59:47 --> Security Class Initialized
DEBUG - 2023-05-17 07:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 07:59:47 --> Input Class Initialized
INFO - 2023-05-17 07:59:47 --> Language Class Initialized
INFO - 2023-05-17 07:59:47 --> Loader Class Initialized
INFO - 2023-05-17 07:59:47 --> Controller Class Initialized
DEBUG - 2023-05-17 07:59:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 07:59:47 --> Database Driver Class Initialized
INFO - 2023-05-17 07:59:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 07:59:47 --> Final output sent to browser
DEBUG - 2023-05-17 07:59:47 --> Total execution time: 0.0554
INFO - 2023-05-17 08:08:34 --> Config Class Initialized
INFO - 2023-05-17 08:08:34 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:34 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:34 --> URI Class Initialized
INFO - 2023-05-17 08:08:34 --> Router Class Initialized
INFO - 2023-05-17 08:08:34 --> Output Class Initialized
INFO - 2023-05-17 08:08:34 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:34 --> Input Class Initialized
INFO - 2023-05-17 08:08:34 --> Language Class Initialized
INFO - 2023-05-17 08:08:34 --> Loader Class Initialized
INFO - 2023-05-17 08:08:34 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:34 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:34 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:34 --> Total execution time: 0.0201
INFO - 2023-05-17 08:08:34 --> Config Class Initialized
INFO - 2023-05-17 08:08:34 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:34 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:34 --> URI Class Initialized
INFO - 2023-05-17 08:08:34 --> Router Class Initialized
INFO - 2023-05-17 08:08:34 --> Output Class Initialized
INFO - 2023-05-17 08:08:34 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:34 --> Input Class Initialized
INFO - 2023-05-17 08:08:34 --> Language Class Initialized
INFO - 2023-05-17 08:08:34 --> Loader Class Initialized
INFO - 2023-05-17 08:08:34 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:34 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:34 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:34 --> Total execution time: 0.0588
INFO - 2023-05-17 08:08:36 --> Config Class Initialized
INFO - 2023-05-17 08:08:36 --> Hooks Class Initialized
INFO - 2023-05-17 08:08:36 --> Config Class Initialized
DEBUG - 2023-05-17 08:08:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:36 --> Hooks Class Initialized
INFO - 2023-05-17 08:08:36 --> Utf8 Class Initialized
DEBUG - 2023-05-17 08:08:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:36 --> URI Class Initialized
INFO - 2023-05-17 08:08:36 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:36 --> Router Class Initialized
INFO - 2023-05-17 08:08:36 --> URI Class Initialized
INFO - 2023-05-17 08:08:36 --> Output Class Initialized
INFO - 2023-05-17 08:08:36 --> Router Class Initialized
INFO - 2023-05-17 08:08:36 --> Security Class Initialized
INFO - 2023-05-17 08:08:36 --> Output Class Initialized
DEBUG - 2023-05-17 08:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:36 --> Security Class Initialized
INFO - 2023-05-17 08:08:36 --> Input Class Initialized
DEBUG - 2023-05-17 08:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:36 --> Language Class Initialized
INFO - 2023-05-17 08:08:36 --> Input Class Initialized
INFO - 2023-05-17 08:08:36 --> Language Class Initialized
INFO - 2023-05-17 08:08:36 --> Loader Class Initialized
INFO - 2023-05-17 08:08:36 --> Loader Class Initialized
INFO - 2023-05-17 08:08:36 --> Controller Class Initialized
INFO - 2023-05-17 08:08:36 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:08:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:36 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:36 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:36 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:36 --> Total execution time: 0.0412
INFO - 2023-05-17 08:08:36 --> Config Class Initialized
INFO - 2023-05-17 08:08:36 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:36 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:36 --> URI Class Initialized
INFO - 2023-05-17 08:08:36 --> Router Class Initialized
INFO - 2023-05-17 08:08:36 --> Output Class Initialized
INFO - 2023-05-17 08:08:36 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:36 --> Input Class Initialized
INFO - 2023-05-17 08:08:36 --> Language Class Initialized
INFO - 2023-05-17 08:08:36 --> Loader Class Initialized
INFO - 2023-05-17 08:08:36 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:36 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:36 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:36 --> Total execution time: 0.0611
INFO - 2023-05-17 08:08:36 --> Config Class Initialized
INFO - 2023-05-17 08:08:36 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:36 --> Total execution time: 0.0336
INFO - 2023-05-17 08:08:36 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:36 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:36 --> URI Class Initialized
INFO - 2023-05-17 08:08:36 --> Router Class Initialized
INFO - 2023-05-17 08:08:36 --> Output Class Initialized
INFO - 2023-05-17 08:08:36 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:36 --> Input Class Initialized
INFO - 2023-05-17 08:08:36 --> Language Class Initialized
INFO - 2023-05-17 08:08:36 --> Loader Class Initialized
INFO - 2023-05-17 08:08:36 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:36 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:36 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:36 --> Total execution time: 0.2384
INFO - 2023-05-17 08:08:37 --> Config Class Initialized
INFO - 2023-05-17 08:08:37 --> Config Class Initialized
INFO - 2023-05-17 08:08:37 --> Hooks Class Initialized
INFO - 2023-05-17 08:08:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:37 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:08:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:37 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:37 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:37 --> URI Class Initialized
INFO - 2023-05-17 08:08:37 --> URI Class Initialized
INFO - 2023-05-17 08:08:37 --> Router Class Initialized
INFO - 2023-05-17 08:08:37 --> Router Class Initialized
INFO - 2023-05-17 08:08:37 --> Output Class Initialized
INFO - 2023-05-17 08:08:37 --> Output Class Initialized
INFO - 2023-05-17 08:08:37 --> Security Class Initialized
INFO - 2023-05-17 08:08:37 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:37 --> Input Class Initialized
INFO - 2023-05-17 08:08:37 --> Input Class Initialized
INFO - 2023-05-17 08:08:37 --> Language Class Initialized
INFO - 2023-05-17 08:08:37 --> Language Class Initialized
INFO - 2023-05-17 08:08:37 --> Loader Class Initialized
INFO - 2023-05-17 08:08:37 --> Loader Class Initialized
INFO - 2023-05-17 08:08:37 --> Controller Class Initialized
INFO - 2023-05-17 08:08:37 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:08:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:37 --> Final output sent to browser
INFO - 2023-05-17 08:08:37 --> Database Driver Class Initialized
DEBUG - 2023-05-17 08:08:37 --> Total execution time: 0.0048
INFO - 2023-05-17 08:08:37 --> Config Class Initialized
INFO - 2023-05-17 08:08:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:37 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:37 --> URI Class Initialized
INFO - 2023-05-17 08:08:37 --> Router Class Initialized
INFO - 2023-05-17 08:08:37 --> Output Class Initialized
INFO - 2023-05-17 08:08:37 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:37 --> Input Class Initialized
INFO - 2023-05-17 08:08:37 --> Language Class Initialized
INFO - 2023-05-17 08:08:37 --> Loader Class Initialized
INFO - 2023-05-17 08:08:37 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:37 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:37 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:37 --> Total execution time: 0.0522
INFO - 2023-05-17 08:08:37 --> Config Class Initialized
INFO - 2023-05-17 08:08:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:37 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:37 --> URI Class Initialized
INFO - 2023-05-17 08:08:37 --> Router Class Initialized
INFO - 2023-05-17 08:08:37 --> Output Class Initialized
INFO - 2023-05-17 08:08:37 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:37 --> Input Class Initialized
INFO - 2023-05-17 08:08:37 --> Language Class Initialized
INFO - 2023-05-17 08:08:37 --> Loader Class Initialized
INFO - 2023-05-17 08:08:37 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:37 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:37 --> Model "Login_model" initialized
INFO - 2023-05-17 08:08:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:37 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:37 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:37 --> Total execution time: 0.0156
INFO - 2023-05-17 08:08:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:37 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:37 --> Total execution time: 0.1071
INFO - 2023-05-17 08:08:53 --> Config Class Initialized
INFO - 2023-05-17 08:08:53 --> Config Class Initialized
INFO - 2023-05-17 08:08:53 --> Hooks Class Initialized
INFO - 2023-05-17 08:08:53 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:53 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:08:53 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:53 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:53 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:53 --> URI Class Initialized
INFO - 2023-05-17 08:08:53 --> URI Class Initialized
INFO - 2023-05-17 08:08:53 --> Router Class Initialized
INFO - 2023-05-17 08:08:53 --> Router Class Initialized
INFO - 2023-05-17 08:08:53 --> Output Class Initialized
INFO - 2023-05-17 08:08:53 --> Output Class Initialized
INFO - 2023-05-17 08:08:53 --> Security Class Initialized
INFO - 2023-05-17 08:08:53 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:53 --> Input Class Initialized
INFO - 2023-05-17 08:08:53 --> Input Class Initialized
INFO - 2023-05-17 08:08:53 --> Language Class Initialized
INFO - 2023-05-17 08:08:53 --> Language Class Initialized
INFO - 2023-05-17 08:08:53 --> Loader Class Initialized
INFO - 2023-05-17 08:08:53 --> Loader Class Initialized
INFO - 2023-05-17 08:08:53 --> Controller Class Initialized
INFO - 2023-05-17 08:08:53 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:08:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:53 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:53 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:53 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:53 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:53 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:53 --> Total execution time: 0.0209
INFO - 2023-05-17 08:08:53 --> Config Class Initialized
INFO - 2023-05-17 08:08:53 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:53 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:53 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:53 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:53 --> URI Class Initialized
INFO - 2023-05-17 08:08:53 --> Router Class Initialized
INFO - 2023-05-17 08:08:53 --> Output Class Initialized
INFO - 2023-05-17 08:08:53 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:53 --> Input Class Initialized
INFO - 2023-05-17 08:08:53 --> Language Class Initialized
INFO - 2023-05-17 08:08:53 --> Loader Class Initialized
INFO - 2023-05-17 08:08:53 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:53 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:53 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:53 --> Model "Login_model" initialized
INFO - 2023-05-17 08:08:53 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:53 --> Total execution time: 0.0575
INFO - 2023-05-17 08:08:53 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:53 --> Total execution time: 0.1893
INFO - 2023-05-17 08:08:53 --> Config Class Initialized
INFO - 2023-05-17 08:08:54 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:54 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:54 --> URI Class Initialized
INFO - 2023-05-17 08:08:54 --> Router Class Initialized
INFO - 2023-05-17 08:08:54 --> Output Class Initialized
INFO - 2023-05-17 08:08:54 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:54 --> Input Class Initialized
INFO - 2023-05-17 08:08:54 --> Language Class Initialized
INFO - 2023-05-17 08:08:54 --> Loader Class Initialized
INFO - 2023-05-17 08:08:54 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:54 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:54 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:54 --> Model "Login_model" initialized
INFO - 2023-05-17 08:08:54 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:54 --> Total execution time: 0.1457
INFO - 2023-05-17 08:08:54 --> Config Class Initialized
INFO - 2023-05-17 08:08:54 --> Config Class Initialized
INFO - 2023-05-17 08:08:54 --> Hooks Class Initialized
INFO - 2023-05-17 08:08:54 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:54 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:08:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:54 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:54 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:54 --> URI Class Initialized
INFO - 2023-05-17 08:08:54 --> URI Class Initialized
INFO - 2023-05-17 08:08:54 --> Router Class Initialized
INFO - 2023-05-17 08:08:54 --> Output Class Initialized
INFO - 2023-05-17 08:08:54 --> Router Class Initialized
INFO - 2023-05-17 08:08:54 --> Security Class Initialized
INFO - 2023-05-17 08:08:54 --> Output Class Initialized
DEBUG - 2023-05-17 08:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:54 --> Security Class Initialized
INFO - 2023-05-17 08:08:54 --> Input Class Initialized
DEBUG - 2023-05-17 08:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:54 --> Language Class Initialized
INFO - 2023-05-17 08:08:54 --> Input Class Initialized
INFO - 2023-05-17 08:08:54 --> Language Class Initialized
INFO - 2023-05-17 08:08:54 --> Loader Class Initialized
INFO - 2023-05-17 08:08:54 --> Loader Class Initialized
INFO - 2023-05-17 08:08:54 --> Controller Class Initialized
INFO - 2023-05-17 08:08:54 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:08:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:54 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:54 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:55 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:55 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:55 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:55 --> Total execution time: 0.0503
INFO - 2023-05-17 08:08:55 --> Config Class Initialized
INFO - 2023-05-17 08:08:55 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:55 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:55 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:55 --> URI Class Initialized
INFO - 2023-05-17 08:08:55 --> Router Class Initialized
INFO - 2023-05-17 08:08:55 --> Output Class Initialized
INFO - 2023-05-17 08:08:55 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:55 --> Input Class Initialized
INFO - 2023-05-17 08:08:55 --> Language Class Initialized
INFO - 2023-05-17 08:08:55 --> Loader Class Initialized
INFO - 2023-05-17 08:08:55 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:55 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:55 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:55 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:55 --> Total execution time: 0.0821
INFO - 2023-05-17 08:08:55 --> Config Class Initialized
INFO - 2023-05-17 08:08:55 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:55 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:55 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:55 --> URI Class Initialized
INFO - 2023-05-17 08:08:55 --> Router Class Initialized
INFO - 2023-05-17 08:08:55 --> Output Class Initialized
INFO - 2023-05-17 08:08:55 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:55 --> Input Class Initialized
INFO - 2023-05-17 08:08:55 --> Language Class Initialized
INFO - 2023-05-17 08:08:55 --> Loader Class Initialized
INFO - 2023-05-17 08:08:55 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:55 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:55 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:55 --> Total execution time: 0.0392
INFO - 2023-05-17 08:08:55 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:55 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:55 --> Total execution time: 0.0956
INFO - 2023-05-17 08:08:56 --> Config Class Initialized
INFO - 2023-05-17 08:08:56 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:56 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:56 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:56 --> URI Class Initialized
INFO - 2023-05-17 08:08:56 --> Router Class Initialized
INFO - 2023-05-17 08:08:56 --> Output Class Initialized
INFO - 2023-05-17 08:08:56 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:56 --> Input Class Initialized
INFO - 2023-05-17 08:08:56 --> Language Class Initialized
INFO - 2023-05-17 08:08:56 --> Loader Class Initialized
INFO - 2023-05-17 08:08:56 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:56 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:56 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:56 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:56 --> Total execution time: 0.0206
INFO - 2023-05-17 08:08:56 --> Config Class Initialized
INFO - 2023-05-17 08:08:56 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:08:56 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:08:56 --> Utf8 Class Initialized
INFO - 2023-05-17 08:08:56 --> URI Class Initialized
INFO - 2023-05-17 08:08:56 --> Router Class Initialized
INFO - 2023-05-17 08:08:56 --> Output Class Initialized
INFO - 2023-05-17 08:08:56 --> Security Class Initialized
DEBUG - 2023-05-17 08:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:08:56 --> Input Class Initialized
INFO - 2023-05-17 08:08:56 --> Language Class Initialized
INFO - 2023-05-17 08:08:56 --> Loader Class Initialized
INFO - 2023-05-17 08:08:56 --> Controller Class Initialized
DEBUG - 2023-05-17 08:08:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:08:56 --> Database Driver Class Initialized
INFO - 2023-05-17 08:08:56 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:08:56 --> Final output sent to browser
DEBUG - 2023-05-17 08:08:56 --> Total execution time: 0.0141
INFO - 2023-05-17 08:10:14 --> Config Class Initialized
INFO - 2023-05-17 08:10:14 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:14 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:14 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:14 --> URI Class Initialized
INFO - 2023-05-17 08:10:14 --> Router Class Initialized
INFO - 2023-05-17 08:10:14 --> Config Class Initialized
INFO - 2023-05-17 08:10:14 --> Output Class Initialized
INFO - 2023-05-17 08:10:14 --> Hooks Class Initialized
INFO - 2023-05-17 08:10:14 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:14 --> Input Class Initialized
DEBUG - 2023-05-17 08:10:14 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:14 --> Language Class Initialized
INFO - 2023-05-17 08:10:14 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:14 --> URI Class Initialized
INFO - 2023-05-17 08:10:14 --> Loader Class Initialized
INFO - 2023-05-17 08:10:14 --> Router Class Initialized
INFO - 2023-05-17 08:10:14 --> Controller Class Initialized
INFO - 2023-05-17 08:10:14 --> Output Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:14 --> Security Class Initialized
INFO - 2023-05-17 08:10:14 --> Database Driver Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:14 --> Input Class Initialized
INFO - 2023-05-17 08:10:14 --> Language Class Initialized
INFO - 2023-05-17 08:10:14 --> Loader Class Initialized
INFO - 2023-05-17 08:10:14 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:14 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:14 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:14 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:14 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:14 --> Total execution time: 0.0358
INFO - 2023-05-17 08:10:14 --> Config Class Initialized
INFO - 2023-05-17 08:10:14 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:14 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:14 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:14 --> URI Class Initialized
INFO - 2023-05-17 08:10:14 --> Router Class Initialized
INFO - 2023-05-17 08:10:14 --> Output Class Initialized
INFO - 2023-05-17 08:10:14 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:14 --> Input Class Initialized
INFO - 2023-05-17 08:10:14 --> Language Class Initialized
INFO - 2023-05-17 08:10:14 --> Loader Class Initialized
INFO - 2023-05-17 08:10:14 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:14 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:14 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:14 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:14 --> Total execution time: 0.0522
INFO - 2023-05-17 08:10:14 --> Config Class Initialized
INFO - 2023-05-17 08:10:14 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:14 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:14 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:14 --> URI Class Initialized
INFO - 2023-05-17 08:10:14 --> Router Class Initialized
INFO - 2023-05-17 08:10:14 --> Output Class Initialized
INFO - 2023-05-17 08:10:14 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:14 --> Input Class Initialized
INFO - 2023-05-17 08:10:14 --> Language Class Initialized
INFO - 2023-05-17 08:10:14 --> Loader Class Initialized
INFO - 2023-05-17 08:10:14 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:14 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:14 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:14 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:14 --> Total execution time: 0.0443
INFO - 2023-05-17 08:10:14 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:14 --> Total execution time: 0.0583
INFO - 2023-05-17 08:10:14 --> Config Class Initialized
INFO - 2023-05-17 08:10:14 --> Config Class Initialized
INFO - 2023-05-17 08:10:14 --> Hooks Class Initialized
INFO - 2023-05-17 08:10:14 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:14 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:10:14 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:14 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:14 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:14 --> URI Class Initialized
INFO - 2023-05-17 08:10:14 --> URI Class Initialized
INFO - 2023-05-17 08:10:14 --> Router Class Initialized
INFO - 2023-05-17 08:10:14 --> Router Class Initialized
INFO - 2023-05-17 08:10:14 --> Output Class Initialized
INFO - 2023-05-17 08:10:14 --> Output Class Initialized
INFO - 2023-05-17 08:10:14 --> Security Class Initialized
INFO - 2023-05-17 08:10:14 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:14 --> Input Class Initialized
INFO - 2023-05-17 08:10:14 --> Input Class Initialized
INFO - 2023-05-17 08:10:14 --> Language Class Initialized
INFO - 2023-05-17 08:10:14 --> Language Class Initialized
INFO - 2023-05-17 08:10:14 --> Loader Class Initialized
INFO - 2023-05-17 08:10:14 --> Controller Class Initialized
INFO - 2023-05-17 08:10:14 --> Loader Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:14 --> Controller Class Initialized
INFO - 2023-05-17 08:10:14 --> Database Driver Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:14 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:14 --> Total execution time: 0.0046
INFO - 2023-05-17 08:10:14 --> Config Class Initialized
INFO - 2023-05-17 08:10:14 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:14 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:14 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:14 --> URI Class Initialized
INFO - 2023-05-17 08:10:14 --> Router Class Initialized
INFO - 2023-05-17 08:10:14 --> Output Class Initialized
INFO - 2023-05-17 08:10:14 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:14 --> Input Class Initialized
INFO - 2023-05-17 08:10:14 --> Language Class Initialized
INFO - 2023-05-17 08:10:14 --> Loader Class Initialized
INFO - 2023-05-17 08:10:14 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:14 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:14 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:14 --> Final output sent to browser
INFO - 2023-05-17 08:10:14 --> Model "Login_model" initialized
DEBUG - 2023-05-17 08:10:14 --> Total execution time: 0.0211
INFO - 2023-05-17 08:10:14 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:14 --> Config Class Initialized
INFO - 2023-05-17 08:10:14 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:14 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:14 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:14 --> URI Class Initialized
INFO - 2023-05-17 08:10:14 --> Router Class Initialized
INFO - 2023-05-17 08:10:14 --> Output Class Initialized
INFO - 2023-05-17 08:10:14 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:14 --> Input Class Initialized
INFO - 2023-05-17 08:10:14 --> Language Class Initialized
INFO - 2023-05-17 08:10:14 --> Loader Class Initialized
INFO - 2023-05-17 08:10:14 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:14 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:14 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:14 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:14 --> Total execution time: 0.0244
INFO - 2023-05-17 08:10:14 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:14 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:14 --> Total execution time: 0.0549
INFO - 2023-05-17 08:10:17 --> Config Class Initialized
INFO - 2023-05-17 08:10:17 --> Hooks Class Initialized
INFO - 2023-05-17 08:10:17 --> Config Class Initialized
INFO - 2023-05-17 08:10:17 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:17 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:17 --> Utf8 Class Initialized
DEBUG - 2023-05-17 08:10:17 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:17 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:17 --> URI Class Initialized
INFO - 2023-05-17 08:10:17 --> URI Class Initialized
INFO - 2023-05-17 08:10:17 --> Router Class Initialized
INFO - 2023-05-17 08:10:17 --> Router Class Initialized
INFO - 2023-05-17 08:10:17 --> Output Class Initialized
INFO - 2023-05-17 08:10:17 --> Output Class Initialized
INFO - 2023-05-17 08:10:17 --> Security Class Initialized
INFO - 2023-05-17 08:10:17 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:17 --> Input Class Initialized
INFO - 2023-05-17 08:10:17 --> Input Class Initialized
INFO - 2023-05-17 08:10:17 --> Language Class Initialized
INFO - 2023-05-17 08:10:17 --> Language Class Initialized
INFO - 2023-05-17 08:10:17 --> Loader Class Initialized
INFO - 2023-05-17 08:10:17 --> Loader Class Initialized
INFO - 2023-05-17 08:10:17 --> Controller Class Initialized
INFO - 2023-05-17 08:10:17 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:10:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:17 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:17 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:17 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:17 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:17 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:17 --> Total execution time: 0.0478
INFO - 2023-05-17 08:10:17 --> Config Class Initialized
INFO - 2023-05-17 08:10:17 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:17 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:17 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:17 --> URI Class Initialized
INFO - 2023-05-17 08:10:17 --> Router Class Initialized
INFO - 2023-05-17 08:10:17 --> Output Class Initialized
INFO - 2023-05-17 08:10:17 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:17 --> Input Class Initialized
INFO - 2023-05-17 08:10:17 --> Language Class Initialized
INFO - 2023-05-17 08:10:17 --> Loader Class Initialized
INFO - 2023-05-17 08:10:17 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:17 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:18 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:18 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:18 --> Total execution time: 0.0711
INFO - 2023-05-17 08:10:18 --> Config Class Initialized
INFO - 2023-05-17 08:10:18 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:18 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:18 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:18 --> URI Class Initialized
INFO - 2023-05-17 08:10:18 --> Router Class Initialized
INFO - 2023-05-17 08:10:18 --> Output Class Initialized
INFO - 2023-05-17 08:10:18 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:18 --> Input Class Initialized
INFO - 2023-05-17 08:10:18 --> Language Class Initialized
INFO - 2023-05-17 08:10:18 --> Loader Class Initialized
INFO - 2023-05-17 08:10:18 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:18 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:18 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:18 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:18 --> Total execution time: 0.0400
INFO - 2023-05-17 08:10:18 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:18 --> Total execution time: 0.0606
INFO - 2023-05-17 08:10:18 --> Config Class Initialized
INFO - 2023-05-17 08:10:18 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:18 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:18 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:18 --> URI Class Initialized
INFO - 2023-05-17 08:10:18 --> Router Class Initialized
INFO - 2023-05-17 08:10:18 --> Output Class Initialized
INFO - 2023-05-17 08:10:18 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:18 --> Input Class Initialized
INFO - 2023-05-17 08:10:18 --> Language Class Initialized
INFO - 2023-05-17 08:10:18 --> Loader Class Initialized
INFO - 2023-05-17 08:10:18 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:18 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:18 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:18 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:18 --> Total execution time: 0.0306
INFO - 2023-05-17 08:10:18 --> Config Class Initialized
INFO - 2023-05-17 08:10:18 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:18 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:18 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:18 --> URI Class Initialized
INFO - 2023-05-17 08:10:18 --> Router Class Initialized
INFO - 2023-05-17 08:10:18 --> Output Class Initialized
INFO - 2023-05-17 08:10:18 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:18 --> Input Class Initialized
INFO - 2023-05-17 08:10:18 --> Language Class Initialized
INFO - 2023-05-17 08:10:18 --> Loader Class Initialized
INFO - 2023-05-17 08:10:18 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:18 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:18 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:18 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:18 --> Total execution time: 0.0118
INFO - 2023-05-17 08:10:24 --> Config Class Initialized
INFO - 2023-05-17 08:10:24 --> Hooks Class Initialized
INFO - 2023-05-17 08:10:24 --> Config Class Initialized
DEBUG - 2023-05-17 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:24 --> Hooks Class Initialized
INFO - 2023-05-17 08:10:24 --> Utf8 Class Initialized
DEBUG - 2023-05-17 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:24 --> URI Class Initialized
INFO - 2023-05-17 08:10:24 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:24 --> Router Class Initialized
INFO - 2023-05-17 08:10:24 --> URI Class Initialized
INFO - 2023-05-17 08:10:24 --> Output Class Initialized
INFO - 2023-05-17 08:10:24 --> Router Class Initialized
INFO - 2023-05-17 08:10:24 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:24 --> Output Class Initialized
INFO - 2023-05-17 08:10:24 --> Input Class Initialized
INFO - 2023-05-17 08:10:24 --> Security Class Initialized
INFO - 2023-05-17 08:10:24 --> Language Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:24 --> Input Class Initialized
INFO - 2023-05-17 08:10:24 --> Loader Class Initialized
INFO - 2023-05-17 08:10:24 --> Language Class Initialized
INFO - 2023-05-17 08:10:24 --> Controller Class Initialized
INFO - 2023-05-17 08:10:24 --> Loader Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:24 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:24 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:24 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:24 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:24 --> Total execution time: 0.0409
INFO - 2023-05-17 08:10:24 --> Config Class Initialized
INFO - 2023-05-17 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:24 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:24 --> URI Class Initialized
INFO - 2023-05-17 08:10:24 --> Router Class Initialized
INFO - 2023-05-17 08:10:24 --> Output Class Initialized
INFO - 2023-05-17 08:10:24 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:24 --> Input Class Initialized
INFO - 2023-05-17 08:10:24 --> Language Class Initialized
INFO - 2023-05-17 08:10:24 --> Loader Class Initialized
INFO - 2023-05-17 08:10:24 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:24 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:24 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:24 --> Total execution time: 0.0592
INFO - 2023-05-17 08:10:24 --> Config Class Initialized
INFO - 2023-05-17 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:24 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:24 --> URI Class Initialized
INFO - 2023-05-17 08:10:24 --> Router Class Initialized
INFO - 2023-05-17 08:10:24 --> Output Class Initialized
INFO - 2023-05-17 08:10:24 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:24 --> Input Class Initialized
INFO - 2023-05-17 08:10:24 --> Language Class Initialized
INFO - 2023-05-17 08:10:24 --> Loader Class Initialized
INFO - 2023-05-17 08:10:24 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:24 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:24 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:24 --> Total execution time: 0.0378
INFO - 2023-05-17 08:10:24 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:24 --> Total execution time: 0.0525
INFO - 2023-05-17 08:10:24 --> Config Class Initialized
INFO - 2023-05-17 08:10:24 --> Config Class Initialized
INFO - 2023-05-17 08:10:24 --> Hooks Class Initialized
INFO - 2023-05-17 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:24 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:24 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:24 --> URI Class Initialized
INFO - 2023-05-17 08:10:24 --> URI Class Initialized
INFO - 2023-05-17 08:10:24 --> Router Class Initialized
INFO - 2023-05-17 08:10:24 --> Router Class Initialized
INFO - 2023-05-17 08:10:24 --> Output Class Initialized
INFO - 2023-05-17 08:10:24 --> Output Class Initialized
INFO - 2023-05-17 08:10:24 --> Security Class Initialized
INFO - 2023-05-17 08:10:24 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:24 --> Input Class Initialized
INFO - 2023-05-17 08:10:24 --> Input Class Initialized
INFO - 2023-05-17 08:10:24 --> Language Class Initialized
INFO - 2023-05-17 08:10:24 --> Language Class Initialized
INFO - 2023-05-17 08:10:24 --> Loader Class Initialized
INFO - 2023-05-17 08:10:24 --> Loader Class Initialized
INFO - 2023-05-17 08:10:24 --> Controller Class Initialized
INFO - 2023-05-17 08:10:24 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:24 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:24 --> Total execution time: 0.0044
INFO - 2023-05-17 08:10:24 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:24 --> Config Class Initialized
INFO - 2023-05-17 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:24 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:24 --> URI Class Initialized
INFO - 2023-05-17 08:10:24 --> Router Class Initialized
INFO - 2023-05-17 08:10:24 --> Output Class Initialized
INFO - 2023-05-17 08:10:24 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:24 --> Input Class Initialized
INFO - 2023-05-17 08:10:24 --> Language Class Initialized
INFO - 2023-05-17 08:10:24 --> Loader Class Initialized
INFO - 2023-05-17 08:10:24 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:24 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:24 --> Model "Login_model" initialized
INFO - 2023-05-17 08:10:24 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:24 --> Total execution time: 0.0167
INFO - 2023-05-17 08:10:24 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:24 --> Config Class Initialized
INFO - 2023-05-17 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:10:24 --> Utf8 Class Initialized
INFO - 2023-05-17 08:10:24 --> URI Class Initialized
INFO - 2023-05-17 08:10:24 --> Router Class Initialized
INFO - 2023-05-17 08:10:24 --> Output Class Initialized
INFO - 2023-05-17 08:10:24 --> Security Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:10:24 --> Input Class Initialized
INFO - 2023-05-17 08:10:24 --> Language Class Initialized
INFO - 2023-05-17 08:10:24 --> Loader Class Initialized
INFO - 2023-05-17 08:10:24 --> Controller Class Initialized
DEBUG - 2023-05-17 08:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:10:24 --> Database Driver Class Initialized
INFO - 2023-05-17 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:10:24 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:24 --> Total execution time: 0.0221
INFO - 2023-05-17 08:10:24 --> Final output sent to browser
DEBUG - 2023-05-17 08:10:24 --> Total execution time: 0.0166
INFO - 2023-05-17 08:13:07 --> Config Class Initialized
INFO - 2023-05-17 08:13:07 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:07 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:07 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:07 --> URI Class Initialized
INFO - 2023-05-17 08:13:07 --> Router Class Initialized
INFO - 2023-05-17 08:13:07 --> Output Class Initialized
INFO - 2023-05-17 08:13:07 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:07 --> Input Class Initialized
INFO - 2023-05-17 08:13:07 --> Language Class Initialized
INFO - 2023-05-17 08:13:07 --> Loader Class Initialized
INFO - 2023-05-17 08:13:07 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:07 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:07 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:07 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:07 --> Total execution time: 0.0184
INFO - 2023-05-17 08:13:07 --> Config Class Initialized
INFO - 2023-05-17 08:13:07 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:07 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:07 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:07 --> URI Class Initialized
INFO - 2023-05-17 08:13:07 --> Router Class Initialized
INFO - 2023-05-17 08:13:07 --> Output Class Initialized
INFO - 2023-05-17 08:13:07 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:07 --> Input Class Initialized
INFO - 2023-05-17 08:13:07 --> Language Class Initialized
INFO - 2023-05-17 08:13:07 --> Loader Class Initialized
INFO - 2023-05-17 08:13:07 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:07 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:07 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:07 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:07 --> Total execution time: 0.0105
INFO - 2023-05-17 08:13:08 --> Config Class Initialized
INFO - 2023-05-17 08:13:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:08 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:08 --> URI Class Initialized
INFO - 2023-05-17 08:13:08 --> Router Class Initialized
INFO - 2023-05-17 08:13:08 --> Output Class Initialized
INFO - 2023-05-17 08:13:08 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:08 --> Input Class Initialized
INFO - 2023-05-17 08:13:08 --> Language Class Initialized
INFO - 2023-05-17 08:13:08 --> Loader Class Initialized
INFO - 2023-05-17 08:13:08 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:08 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:08 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:08 --> Total execution time: 0.0139
INFO - 2023-05-17 08:13:08 --> Config Class Initialized
INFO - 2023-05-17 08:13:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:08 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:08 --> URI Class Initialized
INFO - 2023-05-17 08:13:08 --> Router Class Initialized
INFO - 2023-05-17 08:13:08 --> Output Class Initialized
INFO - 2023-05-17 08:13:08 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:08 --> Input Class Initialized
INFO - 2023-05-17 08:13:08 --> Language Class Initialized
INFO - 2023-05-17 08:13:08 --> Loader Class Initialized
INFO - 2023-05-17 08:13:08 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:08 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:08 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:08 --> Total execution time: 0.0205
INFO - 2023-05-17 08:13:09 --> Config Class Initialized
INFO - 2023-05-17 08:13:09 --> Config Class Initialized
INFO - 2023-05-17 08:13:09 --> Config Class Initialized
INFO - 2023-05-17 08:13:09 --> Hooks Class Initialized
INFO - 2023-05-17 08:13:09 --> Hooks Class Initialized
INFO - 2023-05-17 08:13:09 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:13:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:13:09 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:09 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:09 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:09 --> URI Class Initialized
INFO - 2023-05-17 08:13:09 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:09 --> URI Class Initialized
INFO - 2023-05-17 08:13:09 --> Router Class Initialized
INFO - 2023-05-17 08:13:09 --> URI Class Initialized
INFO - 2023-05-17 08:13:09 --> Output Class Initialized
INFO - 2023-05-17 08:13:09 --> Router Class Initialized
INFO - 2023-05-17 08:13:09 --> Router Class Initialized
INFO - 2023-05-17 08:13:09 --> Security Class Initialized
INFO - 2023-05-17 08:13:09 --> Output Class Initialized
INFO - 2023-05-17 08:13:09 --> Output Class Initialized
DEBUG - 2023-05-17 08:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:09 --> Security Class Initialized
INFO - 2023-05-17 08:13:09 --> Input Class Initialized
INFO - 2023-05-17 08:13:09 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:09 --> Language Class Initialized
INFO - 2023-05-17 08:13:09 --> Input Class Initialized
DEBUG - 2023-05-17 08:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:09 --> Language Class Initialized
INFO - 2023-05-17 08:13:09 --> Input Class Initialized
INFO - 2023-05-17 08:13:09 --> Loader Class Initialized
INFO - 2023-05-17 08:13:09 --> Loader Class Initialized
INFO - 2023-05-17 08:13:09 --> Language Class Initialized
INFO - 2023-05-17 08:13:09 --> Controller Class Initialized
INFO - 2023-05-17 08:13:09 --> Controller Class Initialized
INFO - 2023-05-17 08:13:09 --> Loader Class Initialized
DEBUG - 2023-05-17 08:13:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:13:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:09 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:09 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:09 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:09 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:09 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:09 --> Total execution time: 0.0238
INFO - 2023-05-17 08:13:09 --> Config Class Initialized
INFO - 2023-05-17 08:13:09 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:09 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:09 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:09 --> URI Class Initialized
INFO - 2023-05-17 08:13:09 --> Router Class Initialized
INFO - 2023-05-17 08:13:09 --> Output Class Initialized
INFO - 2023-05-17 08:13:09 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:09 --> Input Class Initialized
INFO - 2023-05-17 08:13:09 --> Language Class Initialized
INFO - 2023-05-17 08:13:09 --> Loader Class Initialized
INFO - 2023-05-17 08:13:09 --> Controller Class Initialized
INFO - 2023-05-17 08:13:09 --> Final output sent to browser
INFO - 2023-05-17 08:13:09 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:13:09 --> Total execution time: 0.0288
DEBUG - 2023-05-17 08:13:09 --> Total execution time: 0.0290
INFO - 2023-05-17 08:13:09 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:09 --> Config Class Initialized
INFO - 2023-05-17 08:13:09 --> Config Class Initialized
INFO - 2023-05-17 08:13:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:09 --> Hooks Class Initialized
INFO - 2023-05-17 08:13:09 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:13:09 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:09 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:09 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:09 --> URI Class Initialized
INFO - 2023-05-17 08:13:09 --> URI Class Initialized
INFO - 2023-05-17 08:13:09 --> Router Class Initialized
INFO - 2023-05-17 08:13:09 --> Router Class Initialized
INFO - 2023-05-17 08:13:09 --> Output Class Initialized
INFO - 2023-05-17 08:13:09 --> Output Class Initialized
INFO - 2023-05-17 08:13:09 --> Security Class Initialized
INFO - 2023-05-17 08:13:09 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:09 --> Input Class Initialized
INFO - 2023-05-17 08:13:09 --> Input Class Initialized
INFO - 2023-05-17 08:13:09 --> Language Class Initialized
INFO - 2023-05-17 08:13:09 --> Language Class Initialized
INFO - 2023-05-17 08:13:09 --> Loader Class Initialized
INFO - 2023-05-17 08:13:09 --> Loader Class Initialized
INFO - 2023-05-17 08:13:09 --> Controller Class Initialized
INFO - 2023-05-17 08:13:09 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:13:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:09 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:09 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:09 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:09 --> Total execution time: 0.0553
INFO - 2023-05-17 08:13:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:09 --> Final output sent to browser
INFO - 2023-05-17 08:13:09 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:09 --> Total execution time: 0.0547
DEBUG - 2023-05-17 08:13:09 --> Total execution time: 0.0547
INFO - 2023-05-17 08:13:09 --> Config Class Initialized
INFO - 2023-05-17 08:13:09 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:09 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:09 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:09 --> URI Class Initialized
INFO - 2023-05-17 08:13:09 --> Router Class Initialized
INFO - 2023-05-17 08:13:09 --> Output Class Initialized
INFO - 2023-05-17 08:13:09 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:09 --> Input Class Initialized
INFO - 2023-05-17 08:13:09 --> Language Class Initialized
INFO - 2023-05-17 08:13:09 --> Loader Class Initialized
INFO - 2023-05-17 08:13:09 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:09 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:09 --> Config Class Initialized
INFO - 2023-05-17 08:13:09 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:09 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:09 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:09 --> URI Class Initialized
INFO - 2023-05-17 08:13:09 --> Router Class Initialized
INFO - 2023-05-17 08:13:09 --> Output Class Initialized
INFO - 2023-05-17 08:13:09 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:09 --> Input Class Initialized
INFO - 2023-05-17 08:13:09 --> Language Class Initialized
INFO - 2023-05-17 08:13:09 --> Loader Class Initialized
INFO - 2023-05-17 08:13:09 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:09 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:24 --> Config Class Initialized
INFO - 2023-05-17 08:13:24 --> Hooks Class Initialized
INFO - 2023-05-17 08:13:24 --> Config Class Initialized
INFO - 2023-05-17 08:13:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:13:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:24 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:24 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:24 --> URI Class Initialized
INFO - 2023-05-17 08:13:24 --> URI Class Initialized
INFO - 2023-05-17 08:13:24 --> Router Class Initialized
INFO - 2023-05-17 08:13:24 --> Router Class Initialized
INFO - 2023-05-17 08:13:24 --> Output Class Initialized
INFO - 2023-05-17 08:13:24 --> Output Class Initialized
INFO - 2023-05-17 08:13:24 --> Security Class Initialized
INFO - 2023-05-17 08:13:24 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:24 --> Input Class Initialized
INFO - 2023-05-17 08:13:24 --> Input Class Initialized
INFO - 2023-05-17 08:13:24 --> Language Class Initialized
INFO - 2023-05-17 08:13:24 --> Language Class Initialized
INFO - 2023-05-17 08:13:24 --> Loader Class Initialized
INFO - 2023-05-17 08:13:24 --> Loader Class Initialized
INFO - 2023-05-17 08:13:24 --> Controller Class Initialized
INFO - 2023-05-17 08:13:24 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:13:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:24 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:24 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:24 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:24 --> Total execution time: 0.0449
INFO - 2023-05-17 08:13:24 --> Config Class Initialized
INFO - 2023-05-17 08:13:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:24 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:24 --> URI Class Initialized
INFO - 2023-05-17 08:13:24 --> Router Class Initialized
INFO - 2023-05-17 08:13:24 --> Output Class Initialized
INFO - 2023-05-17 08:13:24 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:24 --> Input Class Initialized
INFO - 2023-05-17 08:13:24 --> Language Class Initialized
INFO - 2023-05-17 08:13:24 --> Loader Class Initialized
INFO - 2023-05-17 08:13:24 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:24 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:24 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:24 --> Total execution time: 0.0627
INFO - 2023-05-17 08:13:24 --> Config Class Initialized
INFO - 2023-05-17 08:13:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:24 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:24 --> URI Class Initialized
INFO - 2023-05-17 08:13:24 --> Router Class Initialized
INFO - 2023-05-17 08:13:24 --> Output Class Initialized
INFO - 2023-05-17 08:13:24 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:24 --> Input Class Initialized
INFO - 2023-05-17 08:13:24 --> Language Class Initialized
INFO - 2023-05-17 08:13:24 --> Loader Class Initialized
INFO - 2023-05-17 08:13:24 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:24 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:24 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:24 --> Total execution time: 0.0317
INFO - 2023-05-17 08:13:24 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:24 --> Total execution time: 0.0426
INFO - 2023-05-17 08:13:28 --> Config Class Initialized
INFO - 2023-05-17 08:13:28 --> Config Class Initialized
INFO - 2023-05-17 08:13:28 --> Hooks Class Initialized
INFO - 2023-05-17 08:13:28 --> Config Class Initialized
INFO - 2023-05-17 08:13:28 --> Hooks Class Initialized
INFO - 2023-05-17 08:13:28 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:28 --> Utf8 Class Initialized
DEBUG - 2023-05-17 08:13:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:13:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:28 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:28 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:28 --> URI Class Initialized
INFO - 2023-05-17 08:13:28 --> URI Class Initialized
INFO - 2023-05-17 08:13:28 --> URI Class Initialized
INFO - 2023-05-17 08:13:28 --> Router Class Initialized
INFO - 2023-05-17 08:13:28 --> Router Class Initialized
INFO - 2023-05-17 08:13:28 --> Router Class Initialized
INFO - 2023-05-17 08:13:28 --> Output Class Initialized
INFO - 2023-05-17 08:13:28 --> Output Class Initialized
INFO - 2023-05-17 08:13:28 --> Output Class Initialized
INFO - 2023-05-17 08:13:28 --> Security Class Initialized
INFO - 2023-05-17 08:13:28 --> Security Class Initialized
INFO - 2023-05-17 08:13:28 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:28 --> Input Class Initialized
INFO - 2023-05-17 08:13:28 --> Input Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:28 --> Language Class Initialized
INFO - 2023-05-17 08:13:28 --> Language Class Initialized
INFO - 2023-05-17 08:13:28 --> Input Class Initialized
INFO - 2023-05-17 08:13:28 --> Loader Class Initialized
INFO - 2023-05-17 08:13:28 --> Loader Class Initialized
INFO - 2023-05-17 08:13:28 --> Language Class Initialized
INFO - 2023-05-17 08:13:28 --> Controller Class Initialized
INFO - 2023-05-17 08:13:28 --> Controller Class Initialized
INFO - 2023-05-17 08:13:28 --> Loader Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:28 --> Controller Class Initialized
INFO - 2023-05-17 08:13:28 --> Database Driver Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:28 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:28 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:28 --> Final output sent to browser
INFO - 2023-05-17 08:13:28 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:28 --> Total execution time: 0.0427
DEBUG - 2023-05-17 08:13:28 --> Total execution time: 0.0404
INFO - 2023-05-17 08:13:28 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:28 --> Total execution time: 0.0428
INFO - 2023-05-17 08:13:28 --> Config Class Initialized
INFO - 2023-05-17 08:13:28 --> Config Class Initialized
INFO - 2023-05-17 08:13:28 --> Hooks Class Initialized
INFO - 2023-05-17 08:13:28 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:13:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:28 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:28 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:28 --> URI Class Initialized
INFO - 2023-05-17 08:13:28 --> URI Class Initialized
INFO - 2023-05-17 08:13:28 --> Router Class Initialized
INFO - 2023-05-17 08:13:28 --> Router Class Initialized
INFO - 2023-05-17 08:13:28 --> Output Class Initialized
INFO - 2023-05-17 08:13:28 --> Output Class Initialized
INFO - 2023-05-17 08:13:28 --> Security Class Initialized
INFO - 2023-05-17 08:13:28 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:28 --> Input Class Initialized
INFO - 2023-05-17 08:13:28 --> Input Class Initialized
INFO - 2023-05-17 08:13:28 --> Config Class Initialized
INFO - 2023-05-17 08:13:28 --> Language Class Initialized
INFO - 2023-05-17 08:13:28 --> Language Class Initialized
INFO - 2023-05-17 08:13:28 --> Hooks Class Initialized
INFO - 2023-05-17 08:13:28 --> Loader Class Initialized
INFO - 2023-05-17 08:13:28 --> Loader Class Initialized
DEBUG - 2023-05-17 08:13:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:28 --> Controller Class Initialized
INFO - 2023-05-17 08:13:28 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:28 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:28 --> URI Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:28 --> Router Class Initialized
INFO - 2023-05-17 08:13:28 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:28 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:28 --> Output Class Initialized
INFO - 2023-05-17 08:13:28 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:28 --> Input Class Initialized
INFO - 2023-05-17 08:13:28 --> Language Class Initialized
INFO - 2023-05-17 08:13:28 --> Loader Class Initialized
INFO - 2023-05-17 08:13:28 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:28 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:28 --> Final output sent to browser
INFO - 2023-05-17 08:13:28 --> Final output sent to browser
DEBUG - 2023-05-17 08:13:28 --> Total execution time: 0.0136
DEBUG - 2023-05-17 08:13:28 --> Total execution time: 0.0117
INFO - 2023-05-17 08:13:28 --> Final output sent to browser
INFO - 2023-05-17 08:13:28 --> Config Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Total execution time: 0.0202
INFO - 2023-05-17 08:13:28 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:28 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:28 --> URI Class Initialized
INFO - 2023-05-17 08:13:28 --> Router Class Initialized
INFO - 2023-05-17 08:13:28 --> Output Class Initialized
INFO - 2023-05-17 08:13:28 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:28 --> Input Class Initialized
INFO - 2023-05-17 08:13:28 --> Language Class Initialized
INFO - 2023-05-17 08:13:28 --> Loader Class Initialized
INFO - 2023-05-17 08:13:28 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:28 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:13:28 --> Config Class Initialized
INFO - 2023-05-17 08:13:28 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:13:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:13:28 --> Utf8 Class Initialized
INFO - 2023-05-17 08:13:28 --> URI Class Initialized
INFO - 2023-05-17 08:13:28 --> Router Class Initialized
INFO - 2023-05-17 08:13:28 --> Output Class Initialized
INFO - 2023-05-17 08:13:28 --> Security Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:13:28 --> Input Class Initialized
INFO - 2023-05-17 08:13:28 --> Language Class Initialized
INFO - 2023-05-17 08:13:28 --> Loader Class Initialized
INFO - 2023-05-17 08:13:28 --> Controller Class Initialized
DEBUG - 2023-05-17 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:13:28 --> Database Driver Class Initialized
INFO - 2023-05-17 08:13:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:20:37 --> Config Class Initialized
INFO - 2023-05-17 08:20:37 --> Hooks Class Initialized
INFO - 2023-05-17 08:20:37 --> Config Class Initialized
INFO - 2023-05-17 08:20:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:20:37 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:20:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:20:37 --> Utf8 Class Initialized
INFO - 2023-05-17 08:20:37 --> Utf8 Class Initialized
INFO - 2023-05-17 08:20:37 --> URI Class Initialized
INFO - 2023-05-17 08:20:37 --> URI Class Initialized
INFO - 2023-05-17 08:20:37 --> Router Class Initialized
INFO - 2023-05-17 08:20:37 --> Router Class Initialized
INFO - 2023-05-17 08:20:37 --> Output Class Initialized
INFO - 2023-05-17 08:20:37 --> Output Class Initialized
INFO - 2023-05-17 08:20:37 --> Security Class Initialized
INFO - 2023-05-17 08:20:37 --> Security Class Initialized
DEBUG - 2023-05-17 08:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:20:37 --> Input Class Initialized
INFO - 2023-05-17 08:20:37 --> Input Class Initialized
INFO - 2023-05-17 08:20:37 --> Language Class Initialized
INFO - 2023-05-17 08:20:37 --> Language Class Initialized
INFO - 2023-05-17 08:20:37 --> Loader Class Initialized
INFO - 2023-05-17 08:20:37 --> Loader Class Initialized
INFO - 2023-05-17 08:20:37 --> Controller Class Initialized
INFO - 2023-05-17 08:20:37 --> Controller Class Initialized
DEBUG - 2023-05-17 08:20:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:20:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:20:37 --> Database Driver Class Initialized
INFO - 2023-05-17 08:20:37 --> Database Driver Class Initialized
INFO - 2023-05-17 08:20:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:20:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:20:37 --> Final output sent to browser
DEBUG - 2023-05-17 08:20:37 --> Total execution time: 0.0417
INFO - 2023-05-17 08:20:37 --> Config Class Initialized
INFO - 2023-05-17 08:20:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:20:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:20:37 --> Utf8 Class Initialized
INFO - 2023-05-17 08:20:37 --> URI Class Initialized
INFO - 2023-05-17 08:20:37 --> Router Class Initialized
INFO - 2023-05-17 08:20:37 --> Output Class Initialized
INFO - 2023-05-17 08:20:37 --> Security Class Initialized
DEBUG - 2023-05-17 08:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:20:37 --> Input Class Initialized
INFO - 2023-05-17 08:20:37 --> Language Class Initialized
INFO - 2023-05-17 08:20:37 --> Loader Class Initialized
INFO - 2023-05-17 08:20:37 --> Controller Class Initialized
DEBUG - 2023-05-17 08:20:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:20:37 --> Database Driver Class Initialized
INFO - 2023-05-17 08:20:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:20:37 --> Final output sent to browser
DEBUG - 2023-05-17 08:20:37 --> Total execution time: 0.0614
INFO - 2023-05-17 08:20:37 --> Config Class Initialized
INFO - 2023-05-17 08:20:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:20:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:20:37 --> Utf8 Class Initialized
INFO - 2023-05-17 08:20:37 --> URI Class Initialized
INFO - 2023-05-17 08:20:37 --> Router Class Initialized
INFO - 2023-05-17 08:20:37 --> Output Class Initialized
INFO - 2023-05-17 08:20:37 --> Security Class Initialized
DEBUG - 2023-05-17 08:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:20:37 --> Input Class Initialized
INFO - 2023-05-17 08:20:37 --> Language Class Initialized
INFO - 2023-05-17 08:20:37 --> Loader Class Initialized
INFO - 2023-05-17 08:20:37 --> Controller Class Initialized
DEBUG - 2023-05-17 08:20:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:20:37 --> Database Driver Class Initialized
INFO - 2023-05-17 08:20:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:20:37 --> Final output sent to browser
DEBUG - 2023-05-17 08:20:37 --> Total execution time: 0.0380
INFO - 2023-05-17 08:20:37 --> Final output sent to browser
DEBUG - 2023-05-17 08:20:37 --> Total execution time: 0.0531
INFO - 2023-05-17 08:20:41 --> Config Class Initialized
INFO - 2023-05-17 08:20:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:20:42 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:20:42 --> Utf8 Class Initialized
INFO - 2023-05-17 08:20:42 --> URI Class Initialized
INFO - 2023-05-17 08:20:42 --> Router Class Initialized
INFO - 2023-05-17 08:20:42 --> Output Class Initialized
INFO - 2023-05-17 08:20:42 --> Security Class Initialized
DEBUG - 2023-05-17 08:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:20:42 --> Input Class Initialized
INFO - 2023-05-17 08:20:42 --> Language Class Initialized
INFO - 2023-05-17 08:20:42 --> Loader Class Initialized
INFO - 2023-05-17 08:20:42 --> Controller Class Initialized
DEBUG - 2023-05-17 08:20:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:20:42 --> Database Driver Class Initialized
INFO - 2023-05-17 08:20:42 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:20:42 --> Final output sent to browser
DEBUG - 2023-05-17 08:20:42 --> Total execution time: 0.0381
INFO - 2023-05-17 08:20:42 --> Config Class Initialized
INFO - 2023-05-17 08:20:42 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:20:42 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:20:42 --> Utf8 Class Initialized
INFO - 2023-05-17 08:20:42 --> URI Class Initialized
INFO - 2023-05-17 08:20:42 --> Router Class Initialized
INFO - 2023-05-17 08:20:42 --> Output Class Initialized
INFO - 2023-05-17 08:20:42 --> Security Class Initialized
DEBUG - 2023-05-17 08:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:20:42 --> Input Class Initialized
INFO - 2023-05-17 08:20:42 --> Language Class Initialized
INFO - 2023-05-17 08:20:42 --> Loader Class Initialized
INFO - 2023-05-17 08:20:42 --> Controller Class Initialized
DEBUG - 2023-05-17 08:20:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:20:42 --> Database Driver Class Initialized
INFO - 2023-05-17 08:20:42 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:20:42 --> Final output sent to browser
DEBUG - 2023-05-17 08:20:42 --> Total execution time: 0.0114
INFO - 2023-05-17 08:47:12 --> Config Class Initialized
INFO - 2023-05-17 08:47:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:47:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:47:12 --> Utf8 Class Initialized
INFO - 2023-05-17 08:47:12 --> URI Class Initialized
INFO - 2023-05-17 08:47:12 --> Router Class Initialized
INFO - 2023-05-17 08:47:12 --> Output Class Initialized
INFO - 2023-05-17 08:47:12 --> Security Class Initialized
DEBUG - 2023-05-17 08:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:47:12 --> Input Class Initialized
INFO - 2023-05-17 08:47:12 --> Language Class Initialized
INFO - 2023-05-17 08:47:12 --> Loader Class Initialized
INFO - 2023-05-17 08:47:12 --> Controller Class Initialized
DEBUG - 2023-05-17 08:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:47:12 --> Database Driver Class Initialized
INFO - 2023-05-17 08:47:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:47:12 --> Final output sent to browser
DEBUG - 2023-05-17 08:47:12 --> Total execution time: 0.0214
INFO - 2023-05-17 08:47:12 --> Config Class Initialized
INFO - 2023-05-17 08:47:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:47:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:47:12 --> Utf8 Class Initialized
INFO - 2023-05-17 08:47:12 --> URI Class Initialized
INFO - 2023-05-17 08:47:12 --> Router Class Initialized
INFO - 2023-05-17 08:47:12 --> Output Class Initialized
INFO - 2023-05-17 08:47:12 --> Security Class Initialized
DEBUG - 2023-05-17 08:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:47:12 --> Input Class Initialized
INFO - 2023-05-17 08:47:12 --> Language Class Initialized
INFO - 2023-05-17 08:47:12 --> Loader Class Initialized
INFO - 2023-05-17 08:47:12 --> Controller Class Initialized
DEBUG - 2023-05-17 08:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:47:12 --> Database Driver Class Initialized
INFO - 2023-05-17 08:47:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:47:12 --> Final output sent to browser
DEBUG - 2023-05-17 08:47:12 --> Total execution time: 0.0234
INFO - 2023-05-17 08:47:13 --> Config Class Initialized
INFO - 2023-05-17 08:47:13 --> Config Class Initialized
INFO - 2023-05-17 08:47:13 --> Hooks Class Initialized
INFO - 2023-05-17 08:47:13 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:47:13 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:47:13 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:47:13 --> Config Class Initialized
INFO - 2023-05-17 08:47:13 --> Utf8 Class Initialized
INFO - 2023-05-17 08:47:13 --> Utf8 Class Initialized
INFO - 2023-05-17 08:47:13 --> Hooks Class Initialized
INFO - 2023-05-17 08:47:13 --> URI Class Initialized
INFO - 2023-05-17 08:47:13 --> URI Class Initialized
INFO - 2023-05-17 08:47:13 --> Router Class Initialized
INFO - 2023-05-17 08:47:13 --> Router Class Initialized
DEBUG - 2023-05-17 08:47:13 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:47:13 --> Output Class Initialized
INFO - 2023-05-17 08:47:13 --> Utf8 Class Initialized
INFO - 2023-05-17 08:47:13 --> Output Class Initialized
INFO - 2023-05-17 08:47:13 --> Security Class Initialized
INFO - 2023-05-17 08:47:13 --> Security Class Initialized
INFO - 2023-05-17 08:47:13 --> URI Class Initialized
DEBUG - 2023-05-17 08:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:47:13 --> Input Class Initialized
INFO - 2023-05-17 08:47:13 --> Input Class Initialized
INFO - 2023-05-17 08:47:13 --> Router Class Initialized
INFO - 2023-05-17 08:47:13 --> Language Class Initialized
INFO - 2023-05-17 08:47:13 --> Language Class Initialized
INFO - 2023-05-17 08:47:13 --> Output Class Initialized
INFO - 2023-05-17 08:47:13 --> Loader Class Initialized
INFO - 2023-05-17 08:47:13 --> Security Class Initialized
INFO - 2023-05-17 08:47:13 --> Loader Class Initialized
INFO - 2023-05-17 08:47:13 --> Controller Class Initialized
DEBUG - 2023-05-17 08:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:47:13 --> Controller Class Initialized
DEBUG - 2023-05-17 08:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:47:13 --> Input Class Initialized
DEBUG - 2023-05-17 08:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:47:13 --> Language Class Initialized
INFO - 2023-05-17 08:47:13 --> Database Driver Class Initialized
INFO - 2023-05-17 08:47:13 --> Database Driver Class Initialized
INFO - 2023-05-17 08:47:13 --> Loader Class Initialized
INFO - 2023-05-17 08:47:13 --> Controller Class Initialized
DEBUG - 2023-05-17 08:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:47:13 --> Database Driver Class Initialized
INFO - 2023-05-17 08:47:13 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:47:13 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:47:13 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:47:13 --> Final output sent to browser
DEBUG - 2023-05-17 08:47:13 --> Total execution time: 0.0139
INFO - 2023-05-17 08:47:13 --> Final output sent to browser
DEBUG - 2023-05-17 08:47:13 --> Total execution time: 0.0161
INFO - 2023-05-17 08:47:13 --> Final output sent to browser
DEBUG - 2023-05-17 08:47:13 --> Total execution time: 0.0165
INFO - 2023-05-17 08:47:13 --> Config Class Initialized
INFO - 2023-05-17 08:47:13 --> Config Class Initialized
INFO - 2023-05-17 08:47:13 --> Config Class Initialized
INFO - 2023-05-17 08:47:13 --> Hooks Class Initialized
INFO - 2023-05-17 08:47:13 --> Hooks Class Initialized
INFO - 2023-05-17 08:47:13 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:47:13 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:47:13 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:47:13 --> Utf8 Class Initialized
INFO - 2023-05-17 08:47:13 --> Utf8 Class Initialized
DEBUG - 2023-05-17 08:47:13 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:47:13 --> URI Class Initialized
INFO - 2023-05-17 08:47:13 --> Utf8 Class Initialized
INFO - 2023-05-17 08:47:13 --> URI Class Initialized
INFO - 2023-05-17 08:47:13 --> URI Class Initialized
INFO - 2023-05-17 08:47:13 --> Router Class Initialized
INFO - 2023-05-17 08:47:13 --> Router Class Initialized
INFO - 2023-05-17 08:47:13 --> Router Class Initialized
INFO - 2023-05-17 08:47:13 --> Output Class Initialized
INFO - 2023-05-17 08:47:13 --> Output Class Initialized
INFO - 2023-05-17 08:47:13 --> Output Class Initialized
INFO - 2023-05-17 08:47:13 --> Security Class Initialized
INFO - 2023-05-17 08:47:13 --> Security Class Initialized
INFO - 2023-05-17 08:47:13 --> Security Class Initialized
DEBUG - 2023-05-17 08:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:47:13 --> Input Class Initialized
INFO - 2023-05-17 08:47:13 --> Input Class Initialized
INFO - 2023-05-17 08:47:13 --> Input Class Initialized
INFO - 2023-05-17 08:47:13 --> Language Class Initialized
INFO - 2023-05-17 08:47:13 --> Language Class Initialized
INFO - 2023-05-17 08:47:13 --> Language Class Initialized
INFO - 2023-05-17 08:47:13 --> Loader Class Initialized
INFO - 2023-05-17 08:47:13 --> Loader Class Initialized
INFO - 2023-05-17 08:47:13 --> Controller Class Initialized
INFO - 2023-05-17 08:47:13 --> Controller Class Initialized
INFO - 2023-05-17 08:47:13 --> Loader Class Initialized
DEBUG - 2023-05-17 08:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:47:13 --> Controller Class Initialized
INFO - 2023-05-17 08:47:13 --> Database Driver Class Initialized
INFO - 2023-05-17 08:47:13 --> Database Driver Class Initialized
DEBUG - 2023-05-17 08:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:47:13 --> Database Driver Class Initialized
INFO - 2023-05-17 08:47:13 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:47:13 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:47:13 --> Final output sent to browser
INFO - 2023-05-17 08:47:13 --> Model "Cluster_model" initialized
DEBUG - 2023-05-17 08:47:13 --> Total execution time: 0.0545
INFO - 2023-05-17 08:47:13 --> Final output sent to browser
INFO - 2023-05-17 08:47:13 --> Final output sent to browser
DEBUG - 2023-05-17 08:47:13 --> Total execution time: 0.0710
DEBUG - 2023-05-17 08:47:13 --> Total execution time: 0.0598
INFO - 2023-05-17 08:47:13 --> Config Class Initialized
INFO - 2023-05-17 08:47:13 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:47:13 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:47:13 --> Utf8 Class Initialized
INFO - 2023-05-17 08:47:13 --> URI Class Initialized
INFO - 2023-05-17 08:47:13 --> Router Class Initialized
INFO - 2023-05-17 08:47:13 --> Output Class Initialized
INFO - 2023-05-17 08:47:13 --> Security Class Initialized
DEBUG - 2023-05-17 08:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:47:13 --> Input Class Initialized
INFO - 2023-05-17 08:47:13 --> Language Class Initialized
INFO - 2023-05-17 08:47:13 --> Loader Class Initialized
INFO - 2023-05-17 08:47:13 --> Controller Class Initialized
DEBUG - 2023-05-17 08:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:47:13 --> Database Driver Class Initialized
INFO - 2023-05-17 08:47:13 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:47:13 --> Config Class Initialized
INFO - 2023-05-17 08:47:13 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:47:13 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:47:13 --> Utf8 Class Initialized
INFO - 2023-05-17 08:47:13 --> URI Class Initialized
INFO - 2023-05-17 08:47:13 --> Router Class Initialized
INFO - 2023-05-17 08:47:13 --> Output Class Initialized
INFO - 2023-05-17 08:47:13 --> Security Class Initialized
DEBUG - 2023-05-17 08:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:47:13 --> Input Class Initialized
INFO - 2023-05-17 08:47:13 --> Language Class Initialized
INFO - 2023-05-17 08:47:13 --> Loader Class Initialized
INFO - 2023-05-17 08:47:13 --> Controller Class Initialized
DEBUG - 2023-05-17 08:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:47:13 --> Database Driver Class Initialized
INFO - 2023-05-17 08:47:13 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:48:52 --> Config Class Initialized
INFO - 2023-05-17 08:48:52 --> Config Class Initialized
INFO - 2023-05-17 08:48:52 --> Config Class Initialized
INFO - 2023-05-17 08:48:52 --> Hooks Class Initialized
INFO - 2023-05-17 08:48:52 --> Hooks Class Initialized
INFO - 2023-05-17 08:48:52 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:48:52 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:48:52 --> Utf8 Class Initialized
INFO - 2023-05-17 08:48:52 --> Utf8 Class Initialized
DEBUG - 2023-05-17 08:48:52 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:48:52 --> URI Class Initialized
INFO - 2023-05-17 08:48:52 --> URI Class Initialized
INFO - 2023-05-17 08:48:52 --> Utf8 Class Initialized
INFO - 2023-05-17 08:48:52 --> Router Class Initialized
INFO - 2023-05-17 08:48:52 --> Router Class Initialized
INFO - 2023-05-17 08:48:52 --> URI Class Initialized
INFO - 2023-05-17 08:48:52 --> Output Class Initialized
INFO - 2023-05-17 08:48:52 --> Output Class Initialized
INFO - 2023-05-17 08:48:52 --> Router Class Initialized
INFO - 2023-05-17 08:48:52 --> Security Class Initialized
INFO - 2023-05-17 08:48:52 --> Security Class Initialized
INFO - 2023-05-17 08:48:52 --> Output Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:48:52 --> Security Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:48:52 --> Input Class Initialized
INFO - 2023-05-17 08:48:52 --> Input Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:48:52 --> Language Class Initialized
INFO - 2023-05-17 08:48:52 --> Language Class Initialized
INFO - 2023-05-17 08:48:52 --> Input Class Initialized
INFO - 2023-05-17 08:48:52 --> Loader Class Initialized
INFO - 2023-05-17 08:48:52 --> Loader Class Initialized
INFO - 2023-05-17 08:48:52 --> Language Class Initialized
INFO - 2023-05-17 08:48:52 --> Controller Class Initialized
INFO - 2023-05-17 08:48:52 --> Controller Class Initialized
INFO - 2023-05-17 08:48:52 --> Loader Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:48:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:48:52 --> Controller Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:48:52 --> Database Driver Class Initialized
INFO - 2023-05-17 08:48:52 --> Database Driver Class Initialized
INFO - 2023-05-17 08:48:52 --> Database Driver Class Initialized
INFO - 2023-05-17 08:48:52 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:48:52 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:48:52 --> Final output sent to browser
DEBUG - 2023-05-17 08:48:52 --> Total execution time: 0.0150
INFO - 2023-05-17 08:48:52 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:48:52 --> Final output sent to browser
INFO - 2023-05-17 08:48:52 --> Final output sent to browser
DEBUG - 2023-05-17 08:48:52 --> Total execution time: 0.0170
DEBUG - 2023-05-17 08:48:52 --> Total execution time: 0.0170
INFO - 2023-05-17 08:48:52 --> Config Class Initialized
INFO - 2023-05-17 08:48:52 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:48:52 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:48:52 --> Utf8 Class Initialized
INFO - 2023-05-17 08:48:52 --> URI Class Initialized
INFO - 2023-05-17 08:48:52 --> Router Class Initialized
INFO - 2023-05-17 08:48:52 --> Output Class Initialized
INFO - 2023-05-17 08:48:52 --> Security Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:48:52 --> Input Class Initialized
INFO - 2023-05-17 08:48:52 --> Language Class Initialized
INFO - 2023-05-17 08:48:52 --> Loader Class Initialized
INFO - 2023-05-17 08:48:52 --> Config Class Initialized
INFO - 2023-05-17 08:48:52 --> Controller Class Initialized
INFO - 2023-05-17 08:48:52 --> Config Class Initialized
INFO - 2023-05-17 08:48:52 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:48:52 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:48:52 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:48:52 --> Utf8 Class Initialized
INFO - 2023-05-17 08:48:52 --> Utf8 Class Initialized
INFO - 2023-05-17 08:48:52 --> Database Driver Class Initialized
INFO - 2023-05-17 08:48:52 --> URI Class Initialized
INFO - 2023-05-17 08:48:52 --> URI Class Initialized
INFO - 2023-05-17 08:48:52 --> Router Class Initialized
INFO - 2023-05-17 08:48:52 --> Router Class Initialized
INFO - 2023-05-17 08:48:52 --> Output Class Initialized
INFO - 2023-05-17 08:48:52 --> Output Class Initialized
INFO - 2023-05-17 08:48:52 --> Security Class Initialized
INFO - 2023-05-17 08:48:52 --> Security Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:48:52 --> Input Class Initialized
INFO - 2023-05-17 08:48:52 --> Input Class Initialized
INFO - 2023-05-17 08:48:52 --> Language Class Initialized
INFO - 2023-05-17 08:48:52 --> Language Class Initialized
INFO - 2023-05-17 08:48:52 --> Loader Class Initialized
INFO - 2023-05-17 08:48:52 --> Loader Class Initialized
INFO - 2023-05-17 08:48:52 --> Controller Class Initialized
INFO - 2023-05-17 08:48:52 --> Controller Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:48:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:48:52 --> Database Driver Class Initialized
INFO - 2023-05-17 08:48:52 --> Database Driver Class Initialized
INFO - 2023-05-17 08:48:52 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:48:52 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:48:52 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:48:52 --> Final output sent to browser
INFO - 2023-05-17 08:48:52 --> Final output sent to browser
DEBUG - 2023-05-17 08:48:52 --> Total execution time: 0.0191
DEBUG - 2023-05-17 08:48:52 --> Total execution time: 0.0190
INFO - 2023-05-17 08:48:52 --> Final output sent to browser
INFO - 2023-05-17 08:48:52 --> Config Class Initialized
INFO - 2023-05-17 08:48:52 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Total execution time: 0.0252
DEBUG - 2023-05-17 08:48:52 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:48:52 --> Utf8 Class Initialized
INFO - 2023-05-17 08:48:52 --> URI Class Initialized
INFO - 2023-05-17 08:48:52 --> Router Class Initialized
INFO - 2023-05-17 08:48:52 --> Output Class Initialized
INFO - 2023-05-17 08:48:52 --> Security Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:48:52 --> Input Class Initialized
INFO - 2023-05-17 08:48:52 --> Language Class Initialized
INFO - 2023-05-17 08:48:52 --> Loader Class Initialized
INFO - 2023-05-17 08:48:52 --> Controller Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:48:52 --> Database Driver Class Initialized
INFO - 2023-05-17 08:48:52 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:48:52 --> Config Class Initialized
INFO - 2023-05-17 08:48:52 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:48:52 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:48:52 --> Utf8 Class Initialized
INFO - 2023-05-17 08:48:52 --> URI Class Initialized
INFO - 2023-05-17 08:48:52 --> Router Class Initialized
INFO - 2023-05-17 08:48:52 --> Output Class Initialized
INFO - 2023-05-17 08:48:52 --> Security Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:48:52 --> Input Class Initialized
INFO - 2023-05-17 08:48:52 --> Language Class Initialized
INFO - 2023-05-17 08:48:52 --> Loader Class Initialized
INFO - 2023-05-17 08:48:52 --> Controller Class Initialized
DEBUG - 2023-05-17 08:48:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:48:52 --> Database Driver Class Initialized
INFO - 2023-05-17 08:48:52 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:49:15 --> Config Class Initialized
INFO - 2023-05-17 08:49:15 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:49:15 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:49:15 --> Utf8 Class Initialized
INFO - 2023-05-17 08:49:15 --> URI Class Initialized
INFO - 2023-05-17 08:49:15 --> Router Class Initialized
INFO - 2023-05-17 08:49:15 --> Output Class Initialized
INFO - 2023-05-17 08:49:15 --> Security Class Initialized
DEBUG - 2023-05-17 08:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:49:15 --> Input Class Initialized
INFO - 2023-05-17 08:49:15 --> Language Class Initialized
INFO - 2023-05-17 08:49:15 --> Loader Class Initialized
INFO - 2023-05-17 08:49:15 --> Controller Class Initialized
DEBUG - 2023-05-17 08:49:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:49:15 --> Database Driver Class Initialized
INFO - 2023-05-17 08:49:15 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:49:15 --> Config Class Initialized
INFO - 2023-05-17 08:49:15 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:49:15 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:49:16 --> Utf8 Class Initialized
INFO - 2023-05-17 08:49:16 --> URI Class Initialized
INFO - 2023-05-17 08:49:16 --> Router Class Initialized
INFO - 2023-05-17 08:49:16 --> Output Class Initialized
INFO - 2023-05-17 08:49:16 --> Security Class Initialized
DEBUG - 2023-05-17 08:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:49:16 --> Input Class Initialized
INFO - 2023-05-17 08:49:16 --> Language Class Initialized
INFO - 2023-05-17 08:49:16 --> Loader Class Initialized
INFO - 2023-05-17 08:49:16 --> Controller Class Initialized
DEBUG - 2023-05-17 08:49:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:49:16 --> Database Driver Class Initialized
INFO - 2023-05-17 08:49:16 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:49:17 --> Config Class Initialized
INFO - 2023-05-17 08:49:17 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:49:17 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:49:17 --> Utf8 Class Initialized
INFO - 2023-05-17 08:49:17 --> URI Class Initialized
INFO - 2023-05-17 08:49:17 --> Router Class Initialized
INFO - 2023-05-17 08:49:17 --> Output Class Initialized
INFO - 2023-05-17 08:49:17 --> Security Class Initialized
DEBUG - 2023-05-17 08:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:49:17 --> Input Class Initialized
INFO - 2023-05-17 08:49:17 --> Language Class Initialized
INFO - 2023-05-17 08:49:17 --> Loader Class Initialized
INFO - 2023-05-17 08:49:17 --> Controller Class Initialized
DEBUG - 2023-05-17 08:49:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:49:17 --> Database Driver Class Initialized
INFO - 2023-05-17 08:49:17 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:49:17 --> Config Class Initialized
INFO - 2023-05-17 08:49:17 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:49:17 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:49:17 --> Utf8 Class Initialized
INFO - 2023-05-17 08:49:17 --> URI Class Initialized
INFO - 2023-05-17 08:49:17 --> Router Class Initialized
INFO - 2023-05-17 08:49:17 --> Output Class Initialized
INFO - 2023-05-17 08:49:17 --> Security Class Initialized
DEBUG - 2023-05-17 08:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:49:17 --> Input Class Initialized
INFO - 2023-05-17 08:49:17 --> Language Class Initialized
INFO - 2023-05-17 08:49:17 --> Loader Class Initialized
INFO - 2023-05-17 08:49:17 --> Controller Class Initialized
DEBUG - 2023-05-17 08:49:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:49:17 --> Database Driver Class Initialized
INFO - 2023-05-17 08:49:17 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:49:41 --> Config Class Initialized
INFO - 2023-05-17 08:49:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:49:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:49:41 --> Utf8 Class Initialized
INFO - 2023-05-17 08:49:41 --> URI Class Initialized
INFO - 2023-05-17 08:49:41 --> Router Class Initialized
INFO - 2023-05-17 08:49:41 --> Output Class Initialized
INFO - 2023-05-17 08:49:41 --> Security Class Initialized
DEBUG - 2023-05-17 08:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:49:41 --> Input Class Initialized
INFO - 2023-05-17 08:49:41 --> Language Class Initialized
INFO - 2023-05-17 08:49:41 --> Loader Class Initialized
INFO - 2023-05-17 08:49:41 --> Controller Class Initialized
DEBUG - 2023-05-17 08:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:49:41 --> Database Driver Class Initialized
INFO - 2023-05-17 08:49:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:49:41 --> Final output sent to browser
DEBUG - 2023-05-17 08:49:41 --> Total execution time: 0.0150
INFO - 2023-05-17 08:49:41 --> Config Class Initialized
INFO - 2023-05-17 08:49:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:49:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:49:41 --> Utf8 Class Initialized
INFO - 2023-05-17 08:49:41 --> URI Class Initialized
INFO - 2023-05-17 08:49:41 --> Router Class Initialized
INFO - 2023-05-17 08:49:41 --> Output Class Initialized
INFO - 2023-05-17 08:49:41 --> Security Class Initialized
DEBUG - 2023-05-17 08:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:49:41 --> Input Class Initialized
INFO - 2023-05-17 08:49:41 --> Language Class Initialized
INFO - 2023-05-17 08:49:41 --> Loader Class Initialized
INFO - 2023-05-17 08:49:41 --> Controller Class Initialized
DEBUG - 2023-05-17 08:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:49:41 --> Database Driver Class Initialized
INFO - 2023-05-17 08:49:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:49:41 --> Final output sent to browser
DEBUG - 2023-05-17 08:49:41 --> Total execution time: 0.0172
INFO - 2023-05-17 08:52:33 --> Config Class Initialized
INFO - 2023-05-17 08:52:33 --> Config Class Initialized
INFO - 2023-05-17 08:52:33 --> Config Class Initialized
INFO - 2023-05-17 08:52:33 --> Hooks Class Initialized
INFO - 2023-05-17 08:52:33 --> Hooks Class Initialized
INFO - 2023-05-17 08:52:33 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 08:52:33 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:52:33 --> Utf8 Class Initialized
DEBUG - 2023-05-17 08:52:33 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:52:33 --> Utf8 Class Initialized
INFO - 2023-05-17 08:52:33 --> URI Class Initialized
INFO - 2023-05-17 08:52:33 --> URI Class Initialized
INFO - 2023-05-17 08:52:33 --> Utf8 Class Initialized
INFO - 2023-05-17 08:52:33 --> Router Class Initialized
INFO - 2023-05-17 08:52:33 --> Router Class Initialized
INFO - 2023-05-17 08:52:33 --> URI Class Initialized
INFO - 2023-05-17 08:52:33 --> Output Class Initialized
INFO - 2023-05-17 08:52:33 --> Output Class Initialized
INFO - 2023-05-17 08:52:33 --> Router Class Initialized
INFO - 2023-05-17 08:52:33 --> Security Class Initialized
INFO - 2023-05-17 08:52:33 --> Security Class Initialized
INFO - 2023-05-17 08:52:33 --> Output Class Initialized
DEBUG - 2023-05-17 08:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:52:33 --> Security Class Initialized
INFO - 2023-05-17 08:52:33 --> Input Class Initialized
INFO - 2023-05-17 08:52:33 --> Input Class Initialized
INFO - 2023-05-17 08:52:33 --> Language Class Initialized
DEBUG - 2023-05-17 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:52:33 --> Language Class Initialized
INFO - 2023-05-17 08:52:33 --> Input Class Initialized
INFO - 2023-05-17 08:52:33 --> Loader Class Initialized
INFO - 2023-05-17 08:52:33 --> Language Class Initialized
INFO - 2023-05-17 08:52:33 --> Loader Class Initialized
INFO - 2023-05-17 08:52:33 --> Controller Class Initialized
INFO - 2023-05-17 08:52:33 --> Controller Class Initialized
INFO - 2023-05-17 08:52:33 --> Loader Class Initialized
DEBUG - 2023-05-17 08:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:52:33 --> Controller Class Initialized
INFO - 2023-05-17 08:52:33 --> Database Driver Class Initialized
INFO - 2023-05-17 08:52:33 --> Database Driver Class Initialized
DEBUG - 2023-05-17 08:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:52:33 --> Database Driver Class Initialized
INFO - 2023-05-17 08:52:33 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:52:33 --> Final output sent to browser
DEBUG - 2023-05-17 08:52:33 --> Total execution time: 0.0968
INFO - 2023-05-17 08:52:33 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:52:33 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:52:33 --> Final output sent to browser
INFO - 2023-05-17 08:52:33 --> Final output sent to browser
DEBUG - 2023-05-17 08:52:33 --> Total execution time: 0.0991
DEBUG - 2023-05-17 08:52:33 --> Total execution time: 0.0988
INFO - 2023-05-17 08:52:33 --> Config Class Initialized
INFO - 2023-05-17 08:52:33 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:52:33 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:52:33 --> Utf8 Class Initialized
INFO - 2023-05-17 08:52:33 --> URI Class Initialized
INFO - 2023-05-17 08:52:33 --> Config Class Initialized
INFO - 2023-05-17 08:52:33 --> Config Class Initialized
INFO - 2023-05-17 08:52:33 --> Router Class Initialized
INFO - 2023-05-17 08:52:33 --> Hooks Class Initialized
INFO - 2023-05-17 08:52:33 --> Hooks Class Initialized
INFO - 2023-05-17 08:52:33 --> Output Class Initialized
DEBUG - 2023-05-17 08:52:33 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:52:33 --> Utf8 Class Initialized
DEBUG - 2023-05-17 08:52:33 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:52:33 --> URI Class Initialized
INFO - 2023-05-17 08:52:33 --> Utf8 Class Initialized
INFO - 2023-05-17 08:52:33 --> Security Class Initialized
INFO - 2023-05-17 08:52:33 --> Router Class Initialized
DEBUG - 2023-05-17 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:52:33 --> URI Class Initialized
INFO - 2023-05-17 08:52:33 --> Output Class Initialized
INFO - 2023-05-17 08:52:33 --> Input Class Initialized
INFO - 2023-05-17 08:52:33 --> Router Class Initialized
INFO - 2023-05-17 08:52:33 --> Security Class Initialized
INFO - 2023-05-17 08:52:33 --> Output Class Initialized
INFO - 2023-05-17 08:52:33 --> Language Class Initialized
DEBUG - 2023-05-17 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:52:33 --> Input Class Initialized
INFO - 2023-05-17 08:52:33 --> Security Class Initialized
INFO - 2023-05-17 08:52:33 --> Language Class Initialized
INFO - 2023-05-17 08:52:33 --> Loader Class Initialized
DEBUG - 2023-05-17 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:52:33 --> Loader Class Initialized
INFO - 2023-05-17 08:52:33 --> Controller Class Initialized
INFO - 2023-05-17 08:52:33 --> Input Class Initialized
INFO - 2023-05-17 08:52:33 --> Controller Class Initialized
INFO - 2023-05-17 08:52:33 --> Language Class Initialized
DEBUG - 2023-05-17 08:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 08:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:52:33 --> Loader Class Initialized
INFO - 2023-05-17 08:52:33 --> Controller Class Initialized
INFO - 2023-05-17 08:52:33 --> Database Driver Class Initialized
INFO - 2023-05-17 08:52:33 --> Database Driver Class Initialized
DEBUG - 2023-05-17 08:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:52:33 --> Database Driver Class Initialized
INFO - 2023-05-17 08:52:33 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:52:33 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:52:33 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:52:33 --> Final output sent to browser
DEBUG - 2023-05-17 08:52:33 --> Total execution time: 0.0965
INFO - 2023-05-17 08:52:33 --> Final output sent to browser
INFO - 2023-05-17 08:52:33 --> Final output sent to browser
DEBUG - 2023-05-17 08:52:33 --> Total execution time: 0.1700
DEBUG - 2023-05-17 08:52:33 --> Total execution time: 0.1421
INFO - 2023-05-17 08:52:33 --> Config Class Initialized
INFO - 2023-05-17 08:52:33 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:52:33 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:52:33 --> Utf8 Class Initialized
INFO - 2023-05-17 08:52:33 --> URI Class Initialized
INFO - 2023-05-17 08:52:33 --> Router Class Initialized
INFO - 2023-05-17 08:52:33 --> Output Class Initialized
INFO - 2023-05-17 08:52:33 --> Security Class Initialized
DEBUG - 2023-05-17 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:52:33 --> Input Class Initialized
INFO - 2023-05-17 08:52:33 --> Language Class Initialized
INFO - 2023-05-17 08:52:33 --> Loader Class Initialized
INFO - 2023-05-17 08:52:33 --> Controller Class Initialized
DEBUG - 2023-05-17 08:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:52:33 --> Database Driver Class Initialized
INFO - 2023-05-17 08:52:33 --> Model "Cluster_model" initialized
INFO - 2023-05-17 08:52:33 --> Config Class Initialized
INFO - 2023-05-17 08:52:33 --> Hooks Class Initialized
DEBUG - 2023-05-17 08:52:33 --> UTF-8 Support Enabled
INFO - 2023-05-17 08:52:33 --> Utf8 Class Initialized
INFO - 2023-05-17 08:52:33 --> URI Class Initialized
INFO - 2023-05-17 08:52:33 --> Router Class Initialized
INFO - 2023-05-17 08:52:33 --> Output Class Initialized
INFO - 2023-05-17 08:52:33 --> Security Class Initialized
DEBUG - 2023-05-17 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 08:52:33 --> Input Class Initialized
INFO - 2023-05-17 08:52:33 --> Language Class Initialized
INFO - 2023-05-17 08:52:33 --> Loader Class Initialized
INFO - 2023-05-17 08:52:33 --> Controller Class Initialized
DEBUG - 2023-05-17 08:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 08:52:33 --> Database Driver Class Initialized
INFO - 2023-05-17 08:52:33 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:15 --> Config Class Initialized
INFO - 2023-05-17 09:03:15 --> Hooks Class Initialized
INFO - 2023-05-17 09:03:15 --> Config Class Initialized
INFO - 2023-05-17 09:03:15 --> Config Class Initialized
INFO - 2023-05-17 09:03:15 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:03:15 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:15 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:03:15 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:15 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:15 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:15 --> URI Class Initialized
DEBUG - 2023-05-17 09:03:15 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:15 --> Router Class Initialized
INFO - 2023-05-17 09:03:15 --> URI Class Initialized
INFO - 2023-05-17 09:03:15 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:15 --> Output Class Initialized
INFO - 2023-05-17 09:03:15 --> Router Class Initialized
INFO - 2023-05-17 09:03:15 --> URI Class Initialized
INFO - 2023-05-17 09:03:15 --> Security Class Initialized
INFO - 2023-05-17 09:03:15 --> Output Class Initialized
INFO - 2023-05-17 09:03:15 --> Router Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:15 --> Security Class Initialized
INFO - 2023-05-17 09:03:15 --> Input Class Initialized
INFO - 2023-05-17 09:03:15 --> Output Class Initialized
INFO - 2023-05-17 09:03:15 --> Language Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:15 --> Security Class Initialized
INFO - 2023-05-17 09:03:15 --> Input Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:15 --> Loader Class Initialized
INFO - 2023-05-17 09:03:15 --> Language Class Initialized
INFO - 2023-05-17 09:03:15 --> Input Class Initialized
INFO - 2023-05-17 09:03:15 --> Controller Class Initialized
INFO - 2023-05-17 09:03:15 --> Language Class Initialized
INFO - 2023-05-17 09:03:15 --> Loader Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:15 --> Controller Class Initialized
INFO - 2023-05-17 09:03:15 --> Loader Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:15 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:15 --> Controller Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:15 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:15 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:15 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:15 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:15 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:15 --> Final output sent to browser
DEBUG - 2023-05-17 09:03:15 --> Total execution time: 0.0264
INFO - 2023-05-17 09:03:15 --> Final output sent to browser
DEBUG - 2023-05-17 09:03:15 --> Total execution time: 0.0262
INFO - 2023-05-17 09:03:15 --> Final output sent to browser
DEBUG - 2023-05-17 09:03:15 --> Total execution time: 0.0263
INFO - 2023-05-17 09:03:15 --> Config Class Initialized
INFO - 2023-05-17 09:03:15 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:03:15 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:15 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:15 --> URI Class Initialized
INFO - 2023-05-17 09:03:15 --> Router Class Initialized
INFO - 2023-05-17 09:03:15 --> Output Class Initialized
INFO - 2023-05-17 09:03:15 --> Security Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:15 --> Input Class Initialized
INFO - 2023-05-17 09:03:15 --> Language Class Initialized
INFO - 2023-05-17 09:03:15 --> Config Class Initialized
INFO - 2023-05-17 09:03:15 --> Config Class Initialized
INFO - 2023-05-17 09:03:15 --> Hooks Class Initialized
INFO - 2023-05-17 09:03:15 --> Hooks Class Initialized
INFO - 2023-05-17 09:03:15 --> Loader Class Initialized
DEBUG - 2023-05-17 09:03:15 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:03:15 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:15 --> Controller Class Initialized
INFO - 2023-05-17 09:03:15 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:15 --> Utf8 Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:15 --> URI Class Initialized
INFO - 2023-05-17 09:03:15 --> URI Class Initialized
INFO - 2023-05-17 09:03:15 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:15 --> Router Class Initialized
INFO - 2023-05-17 09:03:15 --> Router Class Initialized
INFO - 2023-05-17 09:03:15 --> Output Class Initialized
INFO - 2023-05-17 09:03:15 --> Output Class Initialized
INFO - 2023-05-17 09:03:15 --> Security Class Initialized
INFO - 2023-05-17 09:03:15 --> Security Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:15 --> Input Class Initialized
INFO - 2023-05-17 09:03:15 --> Input Class Initialized
INFO - 2023-05-17 09:03:15 --> Language Class Initialized
INFO - 2023-05-17 09:03:15 --> Language Class Initialized
INFO - 2023-05-17 09:03:15 --> Loader Class Initialized
INFO - 2023-05-17 09:03:15 --> Loader Class Initialized
INFO - 2023-05-17 09:03:15 --> Controller Class Initialized
INFO - 2023-05-17 09:03:15 --> Controller Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:15 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:15 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:15 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:15 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:15 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:15 --> Final output sent to browser
INFO - 2023-05-17 09:03:15 --> Final output sent to browser
DEBUG - 2023-05-17 09:03:15 --> Total execution time: 0.0141
DEBUG - 2023-05-17 09:03:15 --> Total execution time: 0.0141
INFO - 2023-05-17 09:03:15 --> Final output sent to browser
INFO - 2023-05-17 09:03:15 --> Config Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Total execution time: 0.0195
INFO - 2023-05-17 09:03:15 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:03:15 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:15 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:15 --> URI Class Initialized
INFO - 2023-05-17 09:03:15 --> Router Class Initialized
INFO - 2023-05-17 09:03:15 --> Output Class Initialized
INFO - 2023-05-17 09:03:15 --> Security Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:15 --> Input Class Initialized
INFO - 2023-05-17 09:03:15 --> Language Class Initialized
INFO - 2023-05-17 09:03:15 --> Loader Class Initialized
INFO - 2023-05-17 09:03:15 --> Controller Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:15 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:15 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:15 --> Config Class Initialized
INFO - 2023-05-17 09:03:15 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:03:15 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:15 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:15 --> URI Class Initialized
INFO - 2023-05-17 09:03:15 --> Router Class Initialized
INFO - 2023-05-17 09:03:15 --> Output Class Initialized
INFO - 2023-05-17 09:03:15 --> Security Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:15 --> Input Class Initialized
INFO - 2023-05-17 09:03:15 --> Language Class Initialized
INFO - 2023-05-17 09:03:15 --> Loader Class Initialized
INFO - 2023-05-17 09:03:15 --> Controller Class Initialized
DEBUG - 2023-05-17 09:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:15 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:16 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:20 --> Config Class Initialized
INFO - 2023-05-17 09:03:20 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:03:20 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:20 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:20 --> URI Class Initialized
INFO - 2023-05-17 09:03:20 --> Router Class Initialized
INFO - 2023-05-17 09:03:20 --> Output Class Initialized
INFO - 2023-05-17 09:03:20 --> Security Class Initialized
DEBUG - 2023-05-17 09:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:20 --> Input Class Initialized
INFO - 2023-05-17 09:03:20 --> Language Class Initialized
INFO - 2023-05-17 09:03:20 --> Loader Class Initialized
INFO - 2023-05-17 09:03:20 --> Controller Class Initialized
DEBUG - 2023-05-17 09:03:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:20 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:20 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:20 --> Final output sent to browser
DEBUG - 2023-05-17 09:03:20 --> Total execution time: 0.0165
INFO - 2023-05-17 09:03:20 --> Config Class Initialized
INFO - 2023-05-17 09:03:20 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:03:20 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:20 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:20 --> URI Class Initialized
INFO - 2023-05-17 09:03:20 --> Router Class Initialized
INFO - 2023-05-17 09:03:20 --> Output Class Initialized
INFO - 2023-05-17 09:03:20 --> Security Class Initialized
DEBUG - 2023-05-17 09:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:20 --> Input Class Initialized
INFO - 2023-05-17 09:03:20 --> Language Class Initialized
INFO - 2023-05-17 09:03:20 --> Loader Class Initialized
INFO - 2023-05-17 09:03:20 --> Controller Class Initialized
DEBUG - 2023-05-17 09:03:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:20 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:20 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:20 --> Final output sent to browser
DEBUG - 2023-05-17 09:03:20 --> Total execution time: 0.0563
INFO - 2023-05-17 09:03:22 --> Config Class Initialized
INFO - 2023-05-17 09:03:22 --> Config Class Initialized
INFO - 2023-05-17 09:03:22 --> Config Class Initialized
INFO - 2023-05-17 09:03:22 --> Hooks Class Initialized
INFO - 2023-05-17 09:03:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:03:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:03:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:22 --> URI Class Initialized
DEBUG - 2023-05-17 09:03:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:22 --> Router Class Initialized
INFO - 2023-05-17 09:03:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:22 --> Output Class Initialized
INFO - 2023-05-17 09:03:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:22 --> Security Class Initialized
INFO - 2023-05-17 09:03:22 --> URI Class Initialized
INFO - 2023-05-17 09:03:22 --> URI Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:22 --> Router Class Initialized
INFO - 2023-05-17 09:03:22 --> Input Class Initialized
INFO - 2023-05-17 09:03:22 --> Router Class Initialized
INFO - 2023-05-17 09:03:22 --> Output Class Initialized
INFO - 2023-05-17 09:03:22 --> Language Class Initialized
INFO - 2023-05-17 09:03:22 --> Output Class Initialized
INFO - 2023-05-17 09:03:22 --> Security Class Initialized
INFO - 2023-05-17 09:03:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:22 --> Loader Class Initialized
INFO - 2023-05-17 09:03:22 --> Input Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:22 --> Language Class Initialized
INFO - 2023-05-17 09:03:22 --> Controller Class Initialized
INFO - 2023-05-17 09:03:22 --> Input Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:22 --> Loader Class Initialized
INFO - 2023-05-17 09:03:22 --> Language Class Initialized
INFO - 2023-05-17 09:03:22 --> Controller Class Initialized
INFO - 2023-05-17 09:03:22 --> Database Driver Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:22 --> Loader Class Initialized
INFO - 2023-05-17 09:03:22 --> Controller Class Initialized
INFO - 2023-05-17 09:03:22 --> Database Driver Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:22 --> Model "Login_model" initialized
INFO - 2023-05-17 09:03:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:03:22 --> Total execution time: 0.0686
INFO - 2023-05-17 09:03:22 --> Config Class Initialized
INFO - 2023-05-17 09:03:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:03:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:22 --> Final output sent to browser
INFO - 2023-05-17 09:03:22 --> Utf8 Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Total execution time: 0.1101
INFO - 2023-05-17 09:03:22 --> URI Class Initialized
INFO - 2023-05-17 09:03:22 --> Router Class Initialized
INFO - 2023-05-17 09:03:22 --> Output Class Initialized
INFO - 2023-05-17 09:03:22 --> Security Class Initialized
INFO - 2023-05-17 09:03:22 --> Config Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:22 --> Hooks Class Initialized
INFO - 2023-05-17 09:03:22 --> Input Class Initialized
DEBUG - 2023-05-17 09:03:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:22 --> Language Class Initialized
INFO - 2023-05-17 09:03:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:22 --> URI Class Initialized
INFO - 2023-05-17 09:03:22 --> Loader Class Initialized
INFO - 2023-05-17 09:03:22 --> Controller Class Initialized
INFO - 2023-05-17 09:03:22 --> Router Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:22 --> Output Class Initialized
INFO - 2023-05-17 09:03:22 --> Security Class Initialized
INFO - 2023-05-17 09:03:22 --> Database Driver Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:22 --> Input Class Initialized
INFO - 2023-05-17 09:03:22 --> Language Class Initialized
INFO - 2023-05-17 09:03:22 --> Loader Class Initialized
INFO - 2023-05-17 09:03:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:03:22 --> Total execution time: 0.1172
INFO - 2023-05-17 09:03:22 --> Config Class Initialized
INFO - 2023-05-17 09:03:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:03:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:22 --> URI Class Initialized
INFO - 2023-05-17 09:03:22 --> Router Class Initialized
INFO - 2023-05-17 09:03:22 --> Output Class Initialized
INFO - 2023-05-17 09:03:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:22 --> Input Class Initialized
INFO - 2023-05-17 09:03:22 --> Language Class Initialized
INFO - 2023-05-17 09:03:22 --> Loader Class Initialized
INFO - 2023-05-17 09:03:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:22 --> Model "Login_model" initialized
INFO - 2023-05-17 09:03:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:03:22 --> Total execution time: 0.0590
INFO - 2023-05-17 09:03:22 --> Config Class Initialized
INFO - 2023-05-17 09:03:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:03:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:22 --> URI Class Initialized
INFO - 2023-05-17 09:03:22 --> Router Class Initialized
INFO - 2023-05-17 09:03:22 --> Output Class Initialized
INFO - 2023-05-17 09:03:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:22 --> Input Class Initialized
INFO - 2023-05-17 09:03:22 --> Language Class Initialized
INFO - 2023-05-17 09:03:22 --> Loader Class Initialized
INFO - 2023-05-17 09:03:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:03:22 --> Total execution time: 0.1009
INFO - 2023-05-17 09:03:22 --> Final output sent to browser
INFO - 2023-05-17 09:03:22 --> Model "Cluster_model" initialized
DEBUG - 2023-05-17 09:03:22 --> Total execution time: 0.1537
INFO - 2023-05-17 09:03:22 --> Config Class Initialized
INFO - 2023-05-17 09:03:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:03:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:03:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:03:22 --> URI Class Initialized
INFO - 2023-05-17 09:03:22 --> Router Class Initialized
INFO - 2023-05-17 09:03:22 --> Output Class Initialized
INFO - 2023-05-17 09:03:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:03:22 --> Input Class Initialized
INFO - 2023-05-17 09:03:22 --> Language Class Initialized
INFO - 2023-05-17 09:03:22 --> Loader Class Initialized
INFO - 2023-05-17 09:03:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:03:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:03:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:03:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:03:22 --> Total execution time: 0.1530
INFO - 2023-05-17 09:03:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:03:22 --> Total execution time: 0.0692
INFO - 2023-05-17 09:04:22 --> Config Class Initialized
INFO - 2023-05-17 09:04:22 --> Config Class Initialized
INFO - 2023-05-17 09:04:22 --> Hooks Class Initialized
INFO - 2023-05-17 09:04:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:04:22 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:04:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:04:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:04:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:04:22 --> URI Class Initialized
INFO - 2023-05-17 09:04:22 --> URI Class Initialized
INFO - 2023-05-17 09:04:22 --> Router Class Initialized
INFO - 2023-05-17 09:04:22 --> Router Class Initialized
INFO - 2023-05-17 09:04:22 --> Output Class Initialized
INFO - 2023-05-17 09:04:22 --> Output Class Initialized
INFO - 2023-05-17 09:04:22 --> Security Class Initialized
INFO - 2023-05-17 09:04:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:04:22 --> Input Class Initialized
INFO - 2023-05-17 09:04:22 --> Input Class Initialized
INFO - 2023-05-17 09:04:22 --> Language Class Initialized
INFO - 2023-05-17 09:04:22 --> Language Class Initialized
INFO - 2023-05-17 09:04:22 --> Loader Class Initialized
INFO - 2023-05-17 09:04:22 --> Loader Class Initialized
INFO - 2023-05-17 09:04:22 --> Controller Class Initialized
INFO - 2023-05-17 09:04:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:04:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:04:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:04:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:04:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:04:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:04:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:04:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:04:22 --> Model "Login_model" initialized
INFO - 2023-05-17 09:04:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:04:22 --> Total execution time: 0.0407
INFO - 2023-05-17 09:04:22 --> Config Class Initialized
INFO - 2023-05-17 09:04:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:04:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:04:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:04:22 --> URI Class Initialized
INFO - 2023-05-17 09:04:22 --> Router Class Initialized
INFO - 2023-05-17 09:04:22 --> Output Class Initialized
INFO - 2023-05-17 09:04:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:04:22 --> Input Class Initialized
INFO - 2023-05-17 09:04:22 --> Language Class Initialized
INFO - 2023-05-17 09:04:22 --> Loader Class Initialized
INFO - 2023-05-17 09:04:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:04:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:04:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:04:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:04:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:04:22 --> Total execution time: 0.0341
INFO - 2023-05-17 09:04:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:04:22 --> Total execution time: 0.8772
INFO - 2023-05-17 09:04:22 --> Config Class Initialized
INFO - 2023-05-17 09:04:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:04:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:04:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:04:22 --> URI Class Initialized
INFO - 2023-05-17 09:04:22 --> Router Class Initialized
INFO - 2023-05-17 09:04:22 --> Output Class Initialized
INFO - 2023-05-17 09:04:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:04:22 --> Input Class Initialized
INFO - 2023-05-17 09:04:22 --> Language Class Initialized
INFO - 2023-05-17 09:04:22 --> Loader Class Initialized
INFO - 2023-05-17 09:04:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:04:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:04:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:04:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:04:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:04:22 --> Model "Login_model" initialized
INFO - 2023-05-17 09:04:23 --> Final output sent to browser
DEBUG - 2023-05-17 09:04:23 --> Total execution time: 0.8863
INFO - 2023-05-17 09:05:22 --> Config Class Initialized
INFO - 2023-05-17 09:05:22 --> Config Class Initialized
INFO - 2023-05-17 09:05:22 --> Hooks Class Initialized
INFO - 2023-05-17 09:05:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:05:22 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:05:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:05:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:05:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:05:22 --> URI Class Initialized
INFO - 2023-05-17 09:05:22 --> URI Class Initialized
INFO - 2023-05-17 09:05:22 --> Router Class Initialized
INFO - 2023-05-17 09:05:22 --> Router Class Initialized
INFO - 2023-05-17 09:05:22 --> Output Class Initialized
INFO - 2023-05-17 09:05:22 --> Output Class Initialized
INFO - 2023-05-17 09:05:22 --> Security Class Initialized
INFO - 2023-05-17 09:05:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:05:22 --> Input Class Initialized
INFO - 2023-05-17 09:05:22 --> Input Class Initialized
INFO - 2023-05-17 09:05:22 --> Language Class Initialized
INFO - 2023-05-17 09:05:22 --> Language Class Initialized
INFO - 2023-05-17 09:05:22 --> Loader Class Initialized
INFO - 2023-05-17 09:05:22 --> Loader Class Initialized
INFO - 2023-05-17 09:05:22 --> Controller Class Initialized
INFO - 2023-05-17 09:05:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:05:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:05:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:05:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:05:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:05:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:05:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:05:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:05:22 --> Model "Login_model" initialized
INFO - 2023-05-17 09:05:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:05:22 --> Total execution time: 0.0519
INFO - 2023-05-17 09:05:22 --> Config Class Initialized
INFO - 2023-05-17 09:05:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:05:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:05:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:05:22 --> URI Class Initialized
INFO - 2023-05-17 09:05:22 --> Router Class Initialized
INFO - 2023-05-17 09:05:22 --> Output Class Initialized
INFO - 2023-05-17 09:05:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:05:22 --> Input Class Initialized
INFO - 2023-05-17 09:05:22 --> Language Class Initialized
INFO - 2023-05-17 09:05:22 --> Loader Class Initialized
INFO - 2023-05-17 09:05:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:05:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:05:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:05:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:05:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:05:22 --> Total execution time: 0.0394
INFO - 2023-05-17 09:05:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:05:23 --> Total execution time: 0.9296
INFO - 2023-05-17 09:05:23 --> Config Class Initialized
INFO - 2023-05-17 09:05:23 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:05:23 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:05:23 --> Utf8 Class Initialized
INFO - 2023-05-17 09:05:23 --> URI Class Initialized
INFO - 2023-05-17 09:05:23 --> Router Class Initialized
INFO - 2023-05-17 09:05:23 --> Output Class Initialized
INFO - 2023-05-17 09:05:23 --> Security Class Initialized
DEBUG - 2023-05-17 09:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:05:23 --> Input Class Initialized
INFO - 2023-05-17 09:05:23 --> Language Class Initialized
INFO - 2023-05-17 09:05:23 --> Loader Class Initialized
INFO - 2023-05-17 09:05:23 --> Controller Class Initialized
DEBUG - 2023-05-17 09:05:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:05:23 --> Database Driver Class Initialized
INFO - 2023-05-17 09:05:23 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:05:23 --> Database Driver Class Initialized
INFO - 2023-05-17 09:05:23 --> Model "Login_model" initialized
INFO - 2023-05-17 09:05:23 --> Final output sent to browser
DEBUG - 2023-05-17 09:05:23 --> Total execution time: 0.8328
INFO - 2023-05-17 09:06:22 --> Config Class Initialized
INFO - 2023-05-17 09:06:22 --> Config Class Initialized
INFO - 2023-05-17 09:06:22 --> Hooks Class Initialized
INFO - 2023-05-17 09:06:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:06:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:06:22 --> Utf8 Class Initialized
DEBUG - 2023-05-17 09:06:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:06:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:06:22 --> URI Class Initialized
INFO - 2023-05-17 09:06:22 --> URI Class Initialized
INFO - 2023-05-17 09:06:22 --> Router Class Initialized
INFO - 2023-05-17 09:06:22 --> Router Class Initialized
INFO - 2023-05-17 09:06:22 --> Output Class Initialized
INFO - 2023-05-17 09:06:22 --> Output Class Initialized
INFO - 2023-05-17 09:06:22 --> Security Class Initialized
INFO - 2023-05-17 09:06:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:06:22 --> Input Class Initialized
INFO - 2023-05-17 09:06:22 --> Input Class Initialized
INFO - 2023-05-17 09:06:22 --> Language Class Initialized
INFO - 2023-05-17 09:06:22 --> Language Class Initialized
INFO - 2023-05-17 09:06:22 --> Loader Class Initialized
INFO - 2023-05-17 09:06:22 --> Loader Class Initialized
INFO - 2023-05-17 09:06:22 --> Controller Class Initialized
INFO - 2023-05-17 09:06:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:06:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:06:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:06:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:06:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:06:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:06:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:06:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:06:22 --> Model "Login_model" initialized
INFO - 2023-05-17 09:06:22 --> Final output sent to browser
INFO - 2023-05-17 09:06:22 --> Config Class Initialized
DEBUG - 2023-05-17 09:06:22 --> Total execution time: 0.1147
INFO - 2023-05-17 09:06:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:06:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:06:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:06:22 --> URI Class Initialized
INFO - 2023-05-17 09:06:22 --> Router Class Initialized
INFO - 2023-05-17 09:06:22 --> Output Class Initialized
INFO - 2023-05-17 09:06:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:06:22 --> Input Class Initialized
INFO - 2023-05-17 09:06:22 --> Language Class Initialized
INFO - 2023-05-17 09:06:22 --> Loader Class Initialized
INFO - 2023-05-17 09:06:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:06:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:06:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:06:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:06:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:06:22 --> Total execution time: 0.1863
INFO - 2023-05-17 09:06:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:06:23 --> Total execution time: 0.9616
INFO - 2023-05-17 09:06:23 --> Config Class Initialized
INFO - 2023-05-17 09:06:23 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:06:23 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:06:23 --> Utf8 Class Initialized
INFO - 2023-05-17 09:06:23 --> URI Class Initialized
INFO - 2023-05-17 09:06:23 --> Router Class Initialized
INFO - 2023-05-17 09:06:23 --> Output Class Initialized
INFO - 2023-05-17 09:06:23 --> Security Class Initialized
DEBUG - 2023-05-17 09:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:06:23 --> Input Class Initialized
INFO - 2023-05-17 09:06:23 --> Language Class Initialized
INFO - 2023-05-17 09:06:23 --> Loader Class Initialized
INFO - 2023-05-17 09:06:23 --> Controller Class Initialized
DEBUG - 2023-05-17 09:06:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:06:23 --> Database Driver Class Initialized
INFO - 2023-05-17 09:06:23 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:06:23 --> Database Driver Class Initialized
INFO - 2023-05-17 09:06:23 --> Model "Login_model" initialized
INFO - 2023-05-17 09:06:23 --> Final output sent to browser
DEBUG - 2023-05-17 09:06:23 --> Total execution time: 0.7880
INFO - 2023-05-17 09:07:22 --> Config Class Initialized
INFO - 2023-05-17 09:07:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:07:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:07:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:07:22 --> URI Class Initialized
INFO - 2023-05-17 09:07:22 --> Router Class Initialized
INFO - 2023-05-17 09:07:22 --> Output Class Initialized
INFO - 2023-05-17 09:07:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:07:22 --> Input Class Initialized
INFO - 2023-05-17 09:07:22 --> Language Class Initialized
INFO - 2023-05-17 09:07:22 --> Loader Class Initialized
INFO - 2023-05-17 09:07:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:07:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:07:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:07:22 --> Config Class Initialized
INFO - 2023-05-17 09:07:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:07:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:07:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:07:22 --> URI Class Initialized
INFO - 2023-05-17 09:07:22 --> Router Class Initialized
INFO - 2023-05-17 09:07:22 --> Output Class Initialized
INFO - 2023-05-17 09:07:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:07:22 --> Input Class Initialized
INFO - 2023-05-17 09:07:22 --> Language Class Initialized
INFO - 2023-05-17 09:07:22 --> Loader Class Initialized
INFO - 2023-05-17 09:07:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:07:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:07:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:07:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:07:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:07:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:07:22 --> Model "Login_model" initialized
INFO - 2023-05-17 09:07:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:07:22 --> Total execution time: 0.0714
INFO - 2023-05-17 09:07:22 --> Config Class Initialized
INFO - 2023-05-17 09:07:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:07:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:07:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:07:22 --> URI Class Initialized
INFO - 2023-05-17 09:07:22 --> Router Class Initialized
INFO - 2023-05-17 09:07:22 --> Output Class Initialized
INFO - 2023-05-17 09:07:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:07:22 --> Input Class Initialized
INFO - 2023-05-17 09:07:22 --> Language Class Initialized
INFO - 2023-05-17 09:07:22 --> Loader Class Initialized
INFO - 2023-05-17 09:07:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:07:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:07:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:07:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:07:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:07:22 --> Total execution time: 0.0374
INFO - 2023-05-17 09:07:23 --> Final output sent to browser
DEBUG - 2023-05-17 09:07:23 --> Total execution time: 1.6476
INFO - 2023-05-17 09:07:23 --> Config Class Initialized
INFO - 2023-05-17 09:07:23 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:07:23 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:07:23 --> Utf8 Class Initialized
INFO - 2023-05-17 09:07:23 --> URI Class Initialized
INFO - 2023-05-17 09:07:23 --> Router Class Initialized
INFO - 2023-05-17 09:07:23 --> Output Class Initialized
INFO - 2023-05-17 09:07:23 --> Security Class Initialized
DEBUG - 2023-05-17 09:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:07:23 --> Input Class Initialized
INFO - 2023-05-17 09:07:23 --> Language Class Initialized
INFO - 2023-05-17 09:07:23 --> Loader Class Initialized
INFO - 2023-05-17 09:07:23 --> Controller Class Initialized
DEBUG - 2023-05-17 09:07:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:07:23 --> Database Driver Class Initialized
INFO - 2023-05-17 09:07:23 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:07:23 --> Database Driver Class Initialized
INFO - 2023-05-17 09:07:23 --> Model "Login_model" initialized
INFO - 2023-05-17 09:07:24 --> Final output sent to browser
DEBUG - 2023-05-17 09:07:24 --> Total execution time: 1.1933
INFO - 2023-05-17 09:08:22 --> Config Class Initialized
INFO - 2023-05-17 09:08:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:08:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:22 --> URI Class Initialized
INFO - 2023-05-17 09:08:22 --> Router Class Initialized
INFO - 2023-05-17 09:08:22 --> Output Class Initialized
INFO - 2023-05-17 09:08:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:22 --> Input Class Initialized
INFO - 2023-05-17 09:08:22 --> Language Class Initialized
INFO - 2023-05-17 09:08:22 --> Loader Class Initialized
INFO - 2023-05-17 09:08:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:08:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:22 --> Config Class Initialized
INFO - 2023-05-17 09:08:22 --> Hooks Class Initialized
INFO - 2023-05-17 09:08:22 --> Database Driver Class Initialized
DEBUG - 2023-05-17 09:08:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:22 --> URI Class Initialized
INFO - 2023-05-17 09:08:22 --> Router Class Initialized
INFO - 2023-05-17 09:08:22 --> Output Class Initialized
INFO - 2023-05-17 09:08:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:22 --> Input Class Initialized
INFO - 2023-05-17 09:08:22 --> Language Class Initialized
INFO - 2023-05-17 09:08:22 --> Loader Class Initialized
INFO - 2023-05-17 09:08:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:08:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:22 --> Model "Login_model" initialized
INFO - 2023-05-17 09:08:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:08:22 --> Total execution time: 0.0437
INFO - 2023-05-17 09:08:22 --> Config Class Initialized
INFO - 2023-05-17 09:08:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:08:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:22 --> URI Class Initialized
INFO - 2023-05-17 09:08:22 --> Router Class Initialized
INFO - 2023-05-17 09:08:22 --> Output Class Initialized
INFO - 2023-05-17 09:08:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:22 --> Input Class Initialized
INFO - 2023-05-17 09:08:22 --> Language Class Initialized
INFO - 2023-05-17 09:08:22 --> Loader Class Initialized
INFO - 2023-05-17 09:08:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:08:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:22 --> Final output sent to browser
DEBUG - 2023-05-17 09:08:22 --> Total execution time: 0.0818
INFO - 2023-05-17 09:08:23 --> Final output sent to browser
DEBUG - 2023-05-17 09:08:23 --> Total execution time: 1.0160
INFO - 2023-05-17 09:08:23 --> Config Class Initialized
INFO - 2023-05-17 09:08:23 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:08:23 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:23 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:23 --> URI Class Initialized
INFO - 2023-05-17 09:08:23 --> Router Class Initialized
INFO - 2023-05-17 09:08:23 --> Output Class Initialized
INFO - 2023-05-17 09:08:23 --> Security Class Initialized
DEBUG - 2023-05-17 09:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:23 --> Input Class Initialized
INFO - 2023-05-17 09:08:23 --> Language Class Initialized
INFO - 2023-05-17 09:08:23 --> Loader Class Initialized
INFO - 2023-05-17 09:08:23 --> Controller Class Initialized
DEBUG - 2023-05-17 09:08:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:23 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:23 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:23 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:23 --> Model "Login_model" initialized
INFO - 2023-05-17 09:08:23 --> Final output sent to browser
DEBUG - 2023-05-17 09:08:23 --> Total execution time: 0.8926
INFO - 2023-05-17 09:08:53 --> Config Class Initialized
INFO - 2023-05-17 09:08:53 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:08:53 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:53 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:53 --> URI Class Initialized
INFO - 2023-05-17 09:08:53 --> Router Class Initialized
INFO - 2023-05-17 09:08:53 --> Output Class Initialized
INFO - 2023-05-17 09:08:53 --> Security Class Initialized
DEBUG - 2023-05-17 09:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:53 --> Input Class Initialized
INFO - 2023-05-17 09:08:53 --> Language Class Initialized
INFO - 2023-05-17 09:08:53 --> Loader Class Initialized
INFO - 2023-05-17 09:08:53 --> Controller Class Initialized
DEBUG - 2023-05-17 09:08:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:53 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:53 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:53 --> Final output sent to browser
DEBUG - 2023-05-17 09:08:53 --> Total execution time: 0.0203
INFO - 2023-05-17 09:08:53 --> Config Class Initialized
INFO - 2023-05-17 09:08:53 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:08:53 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:53 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:53 --> URI Class Initialized
INFO - 2023-05-17 09:08:53 --> Router Class Initialized
INFO - 2023-05-17 09:08:53 --> Output Class Initialized
INFO - 2023-05-17 09:08:53 --> Security Class Initialized
DEBUG - 2023-05-17 09:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:53 --> Input Class Initialized
INFO - 2023-05-17 09:08:53 --> Language Class Initialized
INFO - 2023-05-17 09:08:53 --> Loader Class Initialized
INFO - 2023-05-17 09:08:53 --> Controller Class Initialized
DEBUG - 2023-05-17 09:08:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:53 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:53 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:53 --> Final output sent to browser
DEBUG - 2023-05-17 09:08:53 --> Total execution time: 0.0137
INFO - 2023-05-17 09:08:54 --> Config Class Initialized
INFO - 2023-05-17 09:08:54 --> Config Class Initialized
INFO - 2023-05-17 09:08:54 --> Config Class Initialized
INFO - 2023-05-17 09:08:54 --> Hooks Class Initialized
INFO - 2023-05-17 09:08:54 --> Hooks Class Initialized
INFO - 2023-05-17 09:08:54 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:08:54 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:08:54 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:08:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:54 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:54 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:54 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:54 --> URI Class Initialized
INFO - 2023-05-17 09:08:54 --> URI Class Initialized
INFO - 2023-05-17 09:08:54 --> URI Class Initialized
INFO - 2023-05-17 09:08:54 --> Router Class Initialized
INFO - 2023-05-17 09:08:54 --> Router Class Initialized
INFO - 2023-05-17 09:08:54 --> Output Class Initialized
INFO - 2023-05-17 09:08:54 --> Router Class Initialized
INFO - 2023-05-17 09:08:54 --> Output Class Initialized
INFO - 2023-05-17 09:08:54 --> Security Class Initialized
INFO - 2023-05-17 09:08:54 --> Output Class Initialized
INFO - 2023-05-17 09:08:54 --> Security Class Initialized
DEBUG - 2023-05-17 09:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:54 --> Input Class Initialized
INFO - 2023-05-17 09:08:54 --> Security Class Initialized
INFO - 2023-05-17 09:08:54 --> Input Class Initialized
INFO - 2023-05-17 09:08:54 --> Language Class Initialized
INFO - 2023-05-17 09:08:54 --> Language Class Initialized
DEBUG - 2023-05-17 09:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:54 --> Loader Class Initialized
INFO - 2023-05-17 09:08:54 --> Input Class Initialized
INFO - 2023-05-17 09:08:54 --> Loader Class Initialized
INFO - 2023-05-17 09:08:54 --> Controller Class Initialized
INFO - 2023-05-17 09:08:54 --> Language Class Initialized
INFO - 2023-05-17 09:08:54 --> Controller Class Initialized
DEBUG - 2023-05-17 09:08:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:08:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:54 --> Loader Class Initialized
INFO - 2023-05-17 09:08:54 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:54 --> Controller Class Initialized
INFO - 2023-05-17 09:08:54 --> Database Driver Class Initialized
DEBUG - 2023-05-17 09:08:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:54 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:54 --> Final output sent to browser
DEBUG - 2023-05-17 09:08:54 --> Total execution time: 0.0192
INFO - 2023-05-17 09:08:54 --> Final output sent to browser
INFO - 2023-05-17 09:08:54 --> Final output sent to browser
DEBUG - 2023-05-17 09:08:54 --> Total execution time: 0.0211
DEBUG - 2023-05-17 09:08:54 --> Total execution time: 0.0212
INFO - 2023-05-17 09:08:54 --> Config Class Initialized
INFO - 2023-05-17 09:08:54 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:08:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:54 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:54 --> URI Class Initialized
INFO - 2023-05-17 09:08:54 --> Router Class Initialized
INFO - 2023-05-17 09:08:54 --> Output Class Initialized
INFO - 2023-05-17 09:08:54 --> Security Class Initialized
DEBUG - 2023-05-17 09:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:54 --> Input Class Initialized
INFO - 2023-05-17 09:08:54 --> Language Class Initialized
INFO - 2023-05-17 09:08:54 --> Loader Class Initialized
INFO - 2023-05-17 09:08:54 --> Config Class Initialized
INFO - 2023-05-17 09:08:54 --> Controller Class Initialized
INFO - 2023-05-17 09:08:54 --> Hooks Class Initialized
INFO - 2023-05-17 09:08:54 --> Config Class Initialized
DEBUG - 2023-05-17 09:08:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:08:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:54 --> Hooks Class Initialized
INFO - 2023-05-17 09:08:54 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:54 --> Database Driver Class Initialized
DEBUG - 2023-05-17 09:08:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:54 --> URI Class Initialized
INFO - 2023-05-17 09:08:54 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:54 --> Router Class Initialized
INFO - 2023-05-17 09:08:54 --> URI Class Initialized
INFO - 2023-05-17 09:08:54 --> Output Class Initialized
INFO - 2023-05-17 09:08:54 --> Router Class Initialized
INFO - 2023-05-17 09:08:54 --> Security Class Initialized
INFO - 2023-05-17 09:08:54 --> Output Class Initialized
DEBUG - 2023-05-17 09:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:54 --> Security Class Initialized
INFO - 2023-05-17 09:08:54 --> Input Class Initialized
DEBUG - 2023-05-17 09:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:54 --> Language Class Initialized
INFO - 2023-05-17 09:08:54 --> Input Class Initialized
INFO - 2023-05-17 09:08:54 --> Loader Class Initialized
INFO - 2023-05-17 09:08:54 --> Language Class Initialized
INFO - 2023-05-17 09:08:54 --> Controller Class Initialized
DEBUG - 2023-05-17 09:08:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:54 --> Loader Class Initialized
INFO - 2023-05-17 09:08:54 --> Controller Class Initialized
INFO - 2023-05-17 09:08:54 --> Database Driver Class Initialized
DEBUG - 2023-05-17 09:08:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:54 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:54 --> Final output sent to browser
INFO - 2023-05-17 09:08:54 --> Final output sent to browser
DEBUG - 2023-05-17 09:08:54 --> Total execution time: 0.0159
DEBUG - 2023-05-17 09:08:54 --> Total execution time: 0.0160
INFO - 2023-05-17 09:08:54 --> Final output sent to browser
INFO - 2023-05-17 09:08:54 --> Config Class Initialized
INFO - 2023-05-17 09:08:54 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:08:54 --> Total execution time: 0.0247
DEBUG - 2023-05-17 09:08:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:54 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:54 --> URI Class Initialized
INFO - 2023-05-17 09:08:54 --> Router Class Initialized
INFO - 2023-05-17 09:08:54 --> Output Class Initialized
INFO - 2023-05-17 09:08:54 --> Security Class Initialized
DEBUG - 2023-05-17 09:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:54 --> Input Class Initialized
INFO - 2023-05-17 09:08:54 --> Language Class Initialized
INFO - 2023-05-17 09:08:54 --> Loader Class Initialized
INFO - 2023-05-17 09:08:54 --> Controller Class Initialized
DEBUG - 2023-05-17 09:08:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:54 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:55 --> Config Class Initialized
INFO - 2023-05-17 09:08:55 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:08:55 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:55 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:55 --> URI Class Initialized
INFO - 2023-05-17 09:08:55 --> Router Class Initialized
INFO - 2023-05-17 09:08:55 --> Output Class Initialized
INFO - 2023-05-17 09:08:55 --> Security Class Initialized
DEBUG - 2023-05-17 09:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:55 --> Input Class Initialized
INFO - 2023-05-17 09:08:55 --> Language Class Initialized
INFO - 2023-05-17 09:08:55 --> Loader Class Initialized
INFO - 2023-05-17 09:08:55 --> Controller Class Initialized
DEBUG - 2023-05-17 09:08:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:55 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:55 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:55 --> Config Class Initialized
INFO - 2023-05-17 09:08:55 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:08:55 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:55 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:55 --> URI Class Initialized
INFO - 2023-05-17 09:08:55 --> Router Class Initialized
INFO - 2023-05-17 09:08:55 --> Output Class Initialized
INFO - 2023-05-17 09:08:55 --> Security Class Initialized
DEBUG - 2023-05-17 09:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:55 --> Input Class Initialized
INFO - 2023-05-17 09:08:55 --> Language Class Initialized
INFO - 2023-05-17 09:08:55 --> Loader Class Initialized
INFO - 2023-05-17 09:08:55 --> Controller Class Initialized
DEBUG - 2023-05-17 09:08:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:55 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:55 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:55 --> Final output sent to browser
DEBUG - 2023-05-17 09:08:55 --> Total execution time: 0.0139
INFO - 2023-05-17 09:08:55 --> Config Class Initialized
INFO - 2023-05-17 09:08:55 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:08:55 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:08:55 --> Utf8 Class Initialized
INFO - 2023-05-17 09:08:55 --> URI Class Initialized
INFO - 2023-05-17 09:08:55 --> Router Class Initialized
INFO - 2023-05-17 09:08:55 --> Output Class Initialized
INFO - 2023-05-17 09:08:55 --> Security Class Initialized
DEBUG - 2023-05-17 09:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:08:55 --> Input Class Initialized
INFO - 2023-05-17 09:08:55 --> Language Class Initialized
INFO - 2023-05-17 09:08:55 --> Loader Class Initialized
INFO - 2023-05-17 09:08:55 --> Controller Class Initialized
DEBUG - 2023-05-17 09:08:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:08:55 --> Database Driver Class Initialized
INFO - 2023-05-17 09:08:55 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:08:55 --> Final output sent to browser
DEBUG - 2023-05-17 09:08:55 --> Total execution time: 0.0153
INFO - 2023-05-17 09:11:47 --> Config Class Initialized
INFO - 2023-05-17 09:11:47 --> Config Class Initialized
INFO - 2023-05-17 09:11:47 --> Config Class Initialized
INFO - 2023-05-17 09:11:47 --> Hooks Class Initialized
INFO - 2023-05-17 09:11:47 --> Hooks Class Initialized
INFO - 2023-05-17 09:11:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:11:47 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:11:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:11:47 --> Utf8 Class Initialized
INFO - 2023-05-17 09:11:47 --> Utf8 Class Initialized
DEBUG - 2023-05-17 09:11:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:11:47 --> URI Class Initialized
INFO - 2023-05-17 09:11:47 --> Utf8 Class Initialized
INFO - 2023-05-17 09:11:47 --> URI Class Initialized
INFO - 2023-05-17 09:11:47 --> URI Class Initialized
INFO - 2023-05-17 09:11:47 --> Router Class Initialized
INFO - 2023-05-17 09:11:47 --> Router Class Initialized
INFO - 2023-05-17 09:11:47 --> Router Class Initialized
INFO - 2023-05-17 09:11:47 --> Output Class Initialized
INFO - 2023-05-17 09:11:47 --> Output Class Initialized
INFO - 2023-05-17 09:11:47 --> Security Class Initialized
INFO - 2023-05-17 09:11:47 --> Output Class Initialized
INFO - 2023-05-17 09:11:47 --> Security Class Initialized
DEBUG - 2023-05-17 09:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:11:47 --> Security Class Initialized
DEBUG - 2023-05-17 09:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:11:47 --> Input Class Initialized
INFO - 2023-05-17 09:11:47 --> Input Class Initialized
INFO - 2023-05-17 09:11:47 --> Input Class Initialized
INFO - 2023-05-17 09:11:47 --> Language Class Initialized
INFO - 2023-05-17 09:11:47 --> Language Class Initialized
INFO - 2023-05-17 09:11:47 --> Language Class Initialized
INFO - 2023-05-17 09:11:47 --> Loader Class Initialized
INFO - 2023-05-17 09:11:47 --> Loader Class Initialized
INFO - 2023-05-17 09:11:47 --> Loader Class Initialized
INFO - 2023-05-17 09:11:47 --> Controller Class Initialized
INFO - 2023-05-17 09:11:47 --> Controller Class Initialized
INFO - 2023-05-17 09:11:47 --> Controller Class Initialized
DEBUG - 2023-05-17 09:11:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:11:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:11:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:11:47 --> Database Driver Class Initialized
INFO - 2023-05-17 09:11:47 --> Database Driver Class Initialized
INFO - 2023-05-17 09:11:47 --> Database Driver Class Initialized
INFO - 2023-05-17 09:11:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:11:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:11:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:11:47 --> Final output sent to browser
DEBUG - 2023-05-17 09:11:47 --> Total execution time: 0.0155
INFO - 2023-05-17 09:11:47 --> Final output sent to browser
DEBUG - 2023-05-17 09:11:47 --> Total execution time: 0.0171
INFO - 2023-05-17 09:11:47 --> Final output sent to browser
DEBUG - 2023-05-17 09:11:47 --> Total execution time: 0.0178
INFO - 2023-05-17 09:11:47 --> Config Class Initialized
INFO - 2023-05-17 09:11:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:11:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:11:47 --> Utf8 Class Initialized
INFO - 2023-05-17 09:11:47 --> URI Class Initialized
INFO - 2023-05-17 09:11:47 --> Router Class Initialized
INFO - 2023-05-17 09:11:47 --> Output Class Initialized
INFO - 2023-05-17 09:11:47 --> Security Class Initialized
DEBUG - 2023-05-17 09:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:11:47 --> Input Class Initialized
INFO - 2023-05-17 09:11:47 --> Config Class Initialized
INFO - 2023-05-17 09:11:47 --> Language Class Initialized
INFO - 2023-05-17 09:11:47 --> Config Class Initialized
INFO - 2023-05-17 09:11:47 --> Hooks Class Initialized
INFO - 2023-05-17 09:11:47 --> Hooks Class Initialized
INFO - 2023-05-17 09:11:47 --> Loader Class Initialized
DEBUG - 2023-05-17 09:11:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:11:47 --> Controller Class Initialized
DEBUG - 2023-05-17 09:11:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:11:47 --> Utf8 Class Initialized
DEBUG - 2023-05-17 09:11:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:11:47 --> Utf8 Class Initialized
INFO - 2023-05-17 09:11:47 --> URI Class Initialized
INFO - 2023-05-17 09:11:47 --> Database Driver Class Initialized
INFO - 2023-05-17 09:11:47 --> URI Class Initialized
INFO - 2023-05-17 09:11:47 --> Router Class Initialized
INFO - 2023-05-17 09:11:47 --> Router Class Initialized
INFO - 2023-05-17 09:11:47 --> Output Class Initialized
INFO - 2023-05-17 09:11:47 --> Output Class Initialized
INFO - 2023-05-17 09:11:47 --> Security Class Initialized
INFO - 2023-05-17 09:11:47 --> Security Class Initialized
DEBUG - 2023-05-17 09:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:11:47 --> Input Class Initialized
INFO - 2023-05-17 09:11:47 --> Input Class Initialized
INFO - 2023-05-17 09:11:47 --> Language Class Initialized
INFO - 2023-05-17 09:11:47 --> Language Class Initialized
INFO - 2023-05-17 09:11:47 --> Loader Class Initialized
INFO - 2023-05-17 09:11:47 --> Loader Class Initialized
INFO - 2023-05-17 09:11:47 --> Controller Class Initialized
INFO - 2023-05-17 09:11:47 --> Controller Class Initialized
DEBUG - 2023-05-17 09:11:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:11:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:11:47 --> Database Driver Class Initialized
INFO - 2023-05-17 09:11:47 --> Database Driver Class Initialized
INFO - 2023-05-17 09:11:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:11:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:11:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:11:47 --> Final output sent to browser
DEBUG - 2023-05-17 09:11:47 --> Total execution time: 0.0205
INFO - 2023-05-17 09:11:47 --> Final output sent to browser
DEBUG - 2023-05-17 09:11:47 --> Total execution time: 0.0208
INFO - 2023-05-17 09:11:47 --> Final output sent to browser
INFO - 2023-05-17 09:11:47 --> Config Class Initialized
DEBUG - 2023-05-17 09:11:47 --> Total execution time: 0.0277
INFO - 2023-05-17 09:11:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:11:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:11:47 --> Utf8 Class Initialized
INFO - 2023-05-17 09:11:47 --> URI Class Initialized
INFO - 2023-05-17 09:11:47 --> Router Class Initialized
INFO - 2023-05-17 09:11:47 --> Output Class Initialized
INFO - 2023-05-17 09:11:47 --> Security Class Initialized
DEBUG - 2023-05-17 09:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:11:47 --> Input Class Initialized
INFO - 2023-05-17 09:11:47 --> Language Class Initialized
INFO - 2023-05-17 09:11:47 --> Loader Class Initialized
INFO - 2023-05-17 09:11:47 --> Controller Class Initialized
DEBUG - 2023-05-17 09:11:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:11:47 --> Database Driver Class Initialized
INFO - 2023-05-17 09:11:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:11:47 --> Config Class Initialized
INFO - 2023-05-17 09:11:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:11:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:11:47 --> Utf8 Class Initialized
INFO - 2023-05-17 09:11:47 --> URI Class Initialized
INFO - 2023-05-17 09:11:47 --> Router Class Initialized
INFO - 2023-05-17 09:11:47 --> Output Class Initialized
INFO - 2023-05-17 09:11:47 --> Security Class Initialized
DEBUG - 2023-05-17 09:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:11:47 --> Input Class Initialized
INFO - 2023-05-17 09:11:47 --> Language Class Initialized
INFO - 2023-05-17 09:11:47 --> Loader Class Initialized
INFO - 2023-05-17 09:11:47 --> Controller Class Initialized
DEBUG - 2023-05-17 09:11:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:11:47 --> Database Driver Class Initialized
INFO - 2023-05-17 09:11:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:44:06 --> Config Class Initialized
INFO - 2023-05-17 09:44:06 --> Config Class Initialized
INFO - 2023-05-17 09:44:06 --> Hooks Class Initialized
INFO - 2023-05-17 09:44:06 --> Config Class Initialized
INFO - 2023-05-17 09:44:06 --> Hooks Class Initialized
INFO - 2023-05-17 09:44:06 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:44:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:44:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:44:06 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:44:06 --> Utf8 Class Initialized
INFO - 2023-05-17 09:44:06 --> Utf8 Class Initialized
INFO - 2023-05-17 09:44:06 --> Utf8 Class Initialized
INFO - 2023-05-17 09:44:06 --> URI Class Initialized
INFO - 2023-05-17 09:44:06 --> URI Class Initialized
INFO - 2023-05-17 09:44:06 --> URI Class Initialized
INFO - 2023-05-17 09:44:06 --> Router Class Initialized
INFO - 2023-05-17 09:44:06 --> Router Class Initialized
INFO - 2023-05-17 09:44:06 --> Router Class Initialized
INFO - 2023-05-17 09:44:06 --> Output Class Initialized
INFO - 2023-05-17 09:44:06 --> Output Class Initialized
INFO - 2023-05-17 09:44:06 --> Output Class Initialized
INFO - 2023-05-17 09:44:06 --> Security Class Initialized
INFO - 2023-05-17 09:44:06 --> Security Class Initialized
INFO - 2023-05-17 09:44:06 --> Security Class Initialized
DEBUG - 2023-05-17 09:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:44:06 --> Input Class Initialized
DEBUG - 2023-05-17 09:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:44:06 --> Input Class Initialized
INFO - 2023-05-17 09:44:06 --> Language Class Initialized
INFO - 2023-05-17 09:44:06 --> Input Class Initialized
INFO - 2023-05-17 09:44:06 --> Language Class Initialized
INFO - 2023-05-17 09:44:06 --> Language Class Initialized
INFO - 2023-05-17 09:44:06 --> Loader Class Initialized
INFO - 2023-05-17 09:44:06 --> Loader Class Initialized
INFO - 2023-05-17 09:44:06 --> Controller Class Initialized
INFO - 2023-05-17 09:44:06 --> Loader Class Initialized
INFO - 2023-05-17 09:44:06 --> Controller Class Initialized
DEBUG - 2023-05-17 09:44:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:44:06 --> Controller Class Initialized
DEBUG - 2023-05-17 09:44:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:44:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:44:06 --> Database Driver Class Initialized
INFO - 2023-05-17 09:44:06 --> Database Driver Class Initialized
INFO - 2023-05-17 09:44:06 --> Database Driver Class Initialized
INFO - 2023-05-17 09:44:06 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:44:06 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:44:06 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:44:06 --> Final output sent to browser
DEBUG - 2023-05-17 09:44:06 --> Total execution time: 0.0187
INFO - 2023-05-17 09:44:06 --> Final output sent to browser
INFO - 2023-05-17 09:44:06 --> Final output sent to browser
DEBUG - 2023-05-17 09:44:06 --> Total execution time: 0.0205
DEBUG - 2023-05-17 09:44:06 --> Total execution time: 0.0206
INFO - 2023-05-17 09:44:06 --> Config Class Initialized
INFO - 2023-05-17 09:44:06 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:44:06 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:44:06 --> Utf8 Class Initialized
INFO - 2023-05-17 09:44:06 --> URI Class Initialized
INFO - 2023-05-17 09:44:06 --> Router Class Initialized
INFO - 2023-05-17 09:44:06 --> Config Class Initialized
INFO - 2023-05-17 09:44:06 --> Config Class Initialized
INFO - 2023-05-17 09:44:06 --> Output Class Initialized
INFO - 2023-05-17 09:44:06 --> Hooks Class Initialized
INFO - 2023-05-17 09:44:06 --> Hooks Class Initialized
INFO - 2023-05-17 09:44:06 --> Security Class Initialized
DEBUG - 2023-05-17 09:44:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:44:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:44:06 --> Utf8 Class Initialized
INFO - 2023-05-17 09:44:06 --> Input Class Initialized
INFO - 2023-05-17 09:44:06 --> Utf8 Class Initialized
INFO - 2023-05-17 09:44:06 --> Language Class Initialized
INFO - 2023-05-17 09:44:06 --> URI Class Initialized
INFO - 2023-05-17 09:44:06 --> URI Class Initialized
INFO - 2023-05-17 09:44:06 --> Router Class Initialized
INFO - 2023-05-17 09:44:06 --> Loader Class Initialized
INFO - 2023-05-17 09:44:06 --> Router Class Initialized
INFO - 2023-05-17 09:44:06 --> Output Class Initialized
INFO - 2023-05-17 09:44:06 --> Output Class Initialized
INFO - 2023-05-17 09:44:06 --> Controller Class Initialized
INFO - 2023-05-17 09:44:06 --> Security Class Initialized
DEBUG - 2023-05-17 09:44:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:44:06 --> Security Class Initialized
DEBUG - 2023-05-17 09:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:44:06 --> Database Driver Class Initialized
DEBUG - 2023-05-17 09:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:44:06 --> Input Class Initialized
INFO - 2023-05-17 09:44:06 --> Input Class Initialized
INFO - 2023-05-17 09:44:06 --> Language Class Initialized
INFO - 2023-05-17 09:44:06 --> Language Class Initialized
INFO - 2023-05-17 09:44:06 --> Loader Class Initialized
INFO - 2023-05-17 09:44:06 --> Loader Class Initialized
INFO - 2023-05-17 09:44:06 --> Controller Class Initialized
INFO - 2023-05-17 09:44:06 --> Controller Class Initialized
DEBUG - 2023-05-17 09:44:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:44:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:44:06 --> Database Driver Class Initialized
INFO - 2023-05-17 09:44:06 --> Database Driver Class Initialized
INFO - 2023-05-17 09:44:06 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:44:06 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:44:06 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:44:06 --> Final output sent to browser
DEBUG - 2023-05-17 09:44:06 --> Total execution time: 0.0128
INFO - 2023-05-17 09:44:06 --> Final output sent to browser
DEBUG - 2023-05-17 09:44:06 --> Total execution time: 0.0130
INFO - 2023-05-17 09:44:06 --> Final output sent to browser
INFO - 2023-05-17 09:44:06 --> Config Class Initialized
DEBUG - 2023-05-17 09:44:06 --> Total execution time: 0.0192
INFO - 2023-05-17 09:44:06 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:44:06 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:44:06 --> Utf8 Class Initialized
INFO - 2023-05-17 09:44:06 --> URI Class Initialized
INFO - 2023-05-17 09:44:06 --> Router Class Initialized
INFO - 2023-05-17 09:44:06 --> Output Class Initialized
INFO - 2023-05-17 09:44:06 --> Security Class Initialized
DEBUG - 2023-05-17 09:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:44:06 --> Input Class Initialized
INFO - 2023-05-17 09:44:06 --> Language Class Initialized
INFO - 2023-05-17 09:44:06 --> Loader Class Initialized
INFO - 2023-05-17 09:44:06 --> Controller Class Initialized
DEBUG - 2023-05-17 09:44:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:44:06 --> Database Driver Class Initialized
INFO - 2023-05-17 09:44:06 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:44:06 --> Config Class Initialized
INFO - 2023-05-17 09:44:06 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:44:06 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:44:06 --> Utf8 Class Initialized
INFO - 2023-05-17 09:44:06 --> URI Class Initialized
INFO - 2023-05-17 09:44:06 --> Router Class Initialized
INFO - 2023-05-17 09:44:06 --> Output Class Initialized
INFO - 2023-05-17 09:44:06 --> Security Class Initialized
DEBUG - 2023-05-17 09:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:44:06 --> Input Class Initialized
INFO - 2023-05-17 09:44:06 --> Language Class Initialized
INFO - 2023-05-17 09:44:06 --> Loader Class Initialized
INFO - 2023-05-17 09:44:06 --> Controller Class Initialized
DEBUG - 2023-05-17 09:44:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:44:06 --> Database Driver Class Initialized
INFO - 2023-05-17 09:44:07 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:46:06 --> Config Class Initialized
INFO - 2023-05-17 09:46:06 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:46:06 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:46:06 --> Utf8 Class Initialized
INFO - 2023-05-17 09:46:06 --> URI Class Initialized
INFO - 2023-05-17 09:46:06 --> Router Class Initialized
INFO - 2023-05-17 09:46:06 --> Output Class Initialized
INFO - 2023-05-17 09:46:06 --> Security Class Initialized
DEBUG - 2023-05-17 09:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:46:06 --> Input Class Initialized
INFO - 2023-05-17 09:46:06 --> Language Class Initialized
INFO - 2023-05-17 09:46:06 --> Loader Class Initialized
INFO - 2023-05-17 09:46:06 --> Controller Class Initialized
DEBUG - 2023-05-17 09:46:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:46:06 --> Database Driver Class Initialized
INFO - 2023-05-17 09:46:06 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:46:06 --> Final output sent to browser
DEBUG - 2023-05-17 09:46:06 --> Total execution time: 0.0178
INFO - 2023-05-17 09:46:06 --> Config Class Initialized
INFO - 2023-05-17 09:46:06 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:46:06 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:46:06 --> Utf8 Class Initialized
INFO - 2023-05-17 09:46:06 --> URI Class Initialized
INFO - 2023-05-17 09:46:06 --> Router Class Initialized
INFO - 2023-05-17 09:46:06 --> Output Class Initialized
INFO - 2023-05-17 09:46:06 --> Security Class Initialized
DEBUG - 2023-05-17 09:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:46:06 --> Input Class Initialized
INFO - 2023-05-17 09:46:06 --> Language Class Initialized
INFO - 2023-05-17 09:46:06 --> Loader Class Initialized
INFO - 2023-05-17 09:46:06 --> Controller Class Initialized
DEBUG - 2023-05-17 09:46:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:46:06 --> Database Driver Class Initialized
INFO - 2023-05-17 09:46:06 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:46:06 --> Final output sent to browser
DEBUG - 2023-05-17 09:46:06 --> Total execution time: 0.0178
INFO - 2023-05-17 09:46:08 --> Config Class Initialized
INFO - 2023-05-17 09:46:08 --> Config Class Initialized
INFO - 2023-05-17 09:46:08 --> Hooks Class Initialized
INFO - 2023-05-17 09:46:08 --> Hooks Class Initialized
INFO - 2023-05-17 09:46:08 --> Config Class Initialized
DEBUG - 2023-05-17 09:46:08 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:46:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:46:08 --> Hooks Class Initialized
INFO - 2023-05-17 09:46:08 --> Utf8 Class Initialized
INFO - 2023-05-17 09:46:08 --> Utf8 Class Initialized
DEBUG - 2023-05-17 09:46:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:46:08 --> URI Class Initialized
INFO - 2023-05-17 09:46:08 --> URI Class Initialized
INFO - 2023-05-17 09:46:08 --> Utf8 Class Initialized
INFO - 2023-05-17 09:46:08 --> Router Class Initialized
INFO - 2023-05-17 09:46:08 --> Router Class Initialized
INFO - 2023-05-17 09:46:08 --> URI Class Initialized
INFO - 2023-05-17 09:46:08 --> Output Class Initialized
INFO - 2023-05-17 09:46:08 --> Output Class Initialized
INFO - 2023-05-17 09:46:08 --> Router Class Initialized
INFO - 2023-05-17 09:46:08 --> Security Class Initialized
INFO - 2023-05-17 09:46:08 --> Output Class Initialized
INFO - 2023-05-17 09:46:08 --> Security Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:46:08 --> Security Class Initialized
INFO - 2023-05-17 09:46:08 --> Input Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:46:08 --> Language Class Initialized
INFO - 2023-05-17 09:46:08 --> Input Class Initialized
INFO - 2023-05-17 09:46:08 --> Input Class Initialized
INFO - 2023-05-17 09:46:08 --> Language Class Initialized
INFO - 2023-05-17 09:46:08 --> Loader Class Initialized
INFO - 2023-05-17 09:46:08 --> Language Class Initialized
INFO - 2023-05-17 09:46:08 --> Controller Class Initialized
INFO - 2023-05-17 09:46:08 --> Loader Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:46:08 --> Controller Class Initialized
INFO - 2023-05-17 09:46:08 --> Loader Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:46:08 --> Controller Class Initialized
INFO - 2023-05-17 09:46:08 --> Database Driver Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:46:08 --> Database Driver Class Initialized
INFO - 2023-05-17 09:46:08 --> Database Driver Class Initialized
INFO - 2023-05-17 09:46:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:46:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:46:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:46:08 --> Final output sent to browser
INFO - 2023-05-17 09:46:08 --> Final output sent to browser
DEBUG - 2023-05-17 09:46:08 --> Total execution time: 0.0228
DEBUG - 2023-05-17 09:46:08 --> Total execution time: 0.0228
INFO - 2023-05-17 09:46:08 --> Config Class Initialized
INFO - 2023-05-17 09:46:08 --> Config Class Initialized
INFO - 2023-05-17 09:46:08 --> Hooks Class Initialized
INFO - 2023-05-17 09:46:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:46:08 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:46:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:46:08 --> Utf8 Class Initialized
INFO - 2023-05-17 09:46:08 --> Utf8 Class Initialized
INFO - 2023-05-17 09:46:08 --> URI Class Initialized
INFO - 2023-05-17 09:46:08 --> URI Class Initialized
INFO - 2023-05-17 09:46:08 --> Router Class Initialized
INFO - 2023-05-17 09:46:08 --> Router Class Initialized
INFO - 2023-05-17 09:46:08 --> Output Class Initialized
INFO - 2023-05-17 09:46:08 --> Output Class Initialized
INFO - 2023-05-17 09:46:08 --> Security Class Initialized
INFO - 2023-05-17 09:46:08 --> Security Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:46:08 --> Input Class Initialized
INFO - 2023-05-17 09:46:08 --> Input Class Initialized
INFO - 2023-05-17 09:46:08 --> Language Class Initialized
INFO - 2023-05-17 09:46:08 --> Language Class Initialized
INFO - 2023-05-17 09:46:08 --> Loader Class Initialized
INFO - 2023-05-17 09:46:08 --> Loader Class Initialized
INFO - 2023-05-17 09:46:08 --> Controller Class Initialized
INFO - 2023-05-17 09:46:08 --> Controller Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:46:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:46:08 --> Database Driver Class Initialized
INFO - 2023-05-17 09:46:08 --> Database Driver Class Initialized
INFO - 2023-05-17 09:46:08 --> Final output sent to browser
DEBUG - 2023-05-17 09:46:08 --> Total execution time: 0.0268
INFO - 2023-05-17 09:46:08 --> Config Class Initialized
INFO - 2023-05-17 09:46:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:46:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:46:08 --> Utf8 Class Initialized
INFO - 2023-05-17 09:46:08 --> URI Class Initialized
INFO - 2023-05-17 09:46:08 --> Router Class Initialized
INFO - 2023-05-17 09:46:08 --> Output Class Initialized
INFO - 2023-05-17 09:46:08 --> Security Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:46:08 --> Input Class Initialized
INFO - 2023-05-17 09:46:08 --> Language Class Initialized
INFO - 2023-05-17 09:46:08 --> Loader Class Initialized
INFO - 2023-05-17 09:46:08 --> Controller Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:46:08 --> Database Driver Class Initialized
INFO - 2023-05-17 09:46:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:46:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:46:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:46:08 --> Final output sent to browser
DEBUG - 2023-05-17 09:46:08 --> Total execution time: 0.0174
INFO - 2023-05-17 09:46:08 --> Final output sent to browser
INFO - 2023-05-17 09:46:08 --> Final output sent to browser
INFO - 2023-05-17 09:46:08 --> Config Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Total execution time: 0.0156
DEBUG - 2023-05-17 09:46:08 --> Total execution time: 0.0226
INFO - 2023-05-17 09:46:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:46:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:46:08 --> Utf8 Class Initialized
INFO - 2023-05-17 09:46:08 --> URI Class Initialized
INFO - 2023-05-17 09:46:08 --> Router Class Initialized
INFO - 2023-05-17 09:46:08 --> Output Class Initialized
INFO - 2023-05-17 09:46:08 --> Security Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:46:08 --> Input Class Initialized
INFO - 2023-05-17 09:46:08 --> Language Class Initialized
INFO - 2023-05-17 09:46:08 --> Loader Class Initialized
INFO - 2023-05-17 09:46:08 --> Controller Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:46:08 --> Database Driver Class Initialized
INFO - 2023-05-17 09:46:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:46:08 --> Config Class Initialized
INFO - 2023-05-17 09:46:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:46:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:46:08 --> Utf8 Class Initialized
INFO - 2023-05-17 09:46:08 --> URI Class Initialized
INFO - 2023-05-17 09:46:08 --> Router Class Initialized
INFO - 2023-05-17 09:46:08 --> Output Class Initialized
INFO - 2023-05-17 09:46:08 --> Security Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:46:08 --> Input Class Initialized
INFO - 2023-05-17 09:46:08 --> Language Class Initialized
INFO - 2023-05-17 09:46:08 --> Loader Class Initialized
INFO - 2023-05-17 09:46:08 --> Controller Class Initialized
DEBUG - 2023-05-17 09:46:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:46:08 --> Database Driver Class Initialized
INFO - 2023-05-17 09:46:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:47:08 --> Config Class Initialized
INFO - 2023-05-17 09:47:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:47:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:47:08 --> Utf8 Class Initialized
INFO - 2023-05-17 09:47:08 --> URI Class Initialized
INFO - 2023-05-17 09:47:08 --> Router Class Initialized
INFO - 2023-05-17 09:47:08 --> Output Class Initialized
INFO - 2023-05-17 09:47:08 --> Security Class Initialized
DEBUG - 2023-05-17 09:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:47:08 --> Input Class Initialized
INFO - 2023-05-17 09:47:08 --> Language Class Initialized
INFO - 2023-05-17 09:47:08 --> Loader Class Initialized
INFO - 2023-05-17 09:47:08 --> Controller Class Initialized
DEBUG - 2023-05-17 09:47:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:47:08 --> Database Driver Class Initialized
INFO - 2023-05-17 09:47:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:47:08 --> Final output sent to browser
DEBUG - 2023-05-17 09:47:08 --> Total execution time: 0.0127
INFO - 2023-05-17 09:47:08 --> Config Class Initialized
INFO - 2023-05-17 09:47:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:47:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:47:08 --> Utf8 Class Initialized
INFO - 2023-05-17 09:47:08 --> URI Class Initialized
INFO - 2023-05-17 09:47:08 --> Router Class Initialized
INFO - 2023-05-17 09:47:08 --> Output Class Initialized
INFO - 2023-05-17 09:47:08 --> Security Class Initialized
DEBUG - 2023-05-17 09:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:47:08 --> Input Class Initialized
INFO - 2023-05-17 09:47:08 --> Language Class Initialized
INFO - 2023-05-17 09:47:08 --> Loader Class Initialized
INFO - 2023-05-17 09:47:08 --> Controller Class Initialized
DEBUG - 2023-05-17 09:47:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:47:08 --> Database Driver Class Initialized
INFO - 2023-05-17 09:47:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:47:08 --> Final output sent to browser
DEBUG - 2023-05-17 09:47:08 --> Total execution time: 0.1161
INFO - 2023-05-17 09:47:12 --> Config Class Initialized
INFO - 2023-05-17 09:47:12 --> Config Class Initialized
INFO - 2023-05-17 09:47:12 --> Config Class Initialized
INFO - 2023-05-17 09:47:12 --> Hooks Class Initialized
INFO - 2023-05-17 09:47:12 --> Hooks Class Initialized
INFO - 2023-05-17 09:47:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:47:12 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:47:12 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:47:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:47:12 --> Utf8 Class Initialized
INFO - 2023-05-17 09:47:12 --> Utf8 Class Initialized
INFO - 2023-05-17 09:47:12 --> Utf8 Class Initialized
INFO - 2023-05-17 09:47:12 --> URI Class Initialized
INFO - 2023-05-17 09:47:12 --> URI Class Initialized
INFO - 2023-05-17 09:47:12 --> URI Class Initialized
INFO - 2023-05-17 09:47:12 --> Router Class Initialized
INFO - 2023-05-17 09:47:12 --> Router Class Initialized
INFO - 2023-05-17 09:47:12 --> Router Class Initialized
INFO - 2023-05-17 09:47:12 --> Output Class Initialized
INFO - 2023-05-17 09:47:12 --> Output Class Initialized
INFO - 2023-05-17 09:47:12 --> Output Class Initialized
INFO - 2023-05-17 09:47:12 --> Security Class Initialized
INFO - 2023-05-17 09:47:12 --> Security Class Initialized
INFO - 2023-05-17 09:47:12 --> Security Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:47:12 --> Input Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:47:12 --> Language Class Initialized
INFO - 2023-05-17 09:47:12 --> Input Class Initialized
INFO - 2023-05-17 09:47:12 --> Input Class Initialized
INFO - 2023-05-17 09:47:12 --> Language Class Initialized
INFO - 2023-05-17 09:47:12 --> Loader Class Initialized
INFO - 2023-05-17 09:47:12 --> Language Class Initialized
INFO - 2023-05-17 09:47:12 --> Loader Class Initialized
INFO - 2023-05-17 09:47:12 --> Controller Class Initialized
INFO - 2023-05-17 09:47:12 --> Controller Class Initialized
INFO - 2023-05-17 09:47:12 --> Loader Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:47:12 --> Controller Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:47:12 --> Database Driver Class Initialized
INFO - 2023-05-17 09:47:12 --> Database Driver Class Initialized
INFO - 2023-05-17 09:47:12 --> Database Driver Class Initialized
INFO - 2023-05-17 09:47:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:47:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:47:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:47:12 --> Final output sent to browser
DEBUG - 2023-05-17 09:47:12 --> Total execution time: 0.0217
INFO - 2023-05-17 09:47:12 --> Final output sent to browser
INFO - 2023-05-17 09:47:12 --> Final output sent to browser
DEBUG - 2023-05-17 09:47:12 --> Total execution time: 0.0240
DEBUG - 2023-05-17 09:47:12 --> Total execution time: 0.0241
INFO - 2023-05-17 09:47:12 --> Config Class Initialized
INFO - 2023-05-17 09:47:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:47:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:47:12 --> Utf8 Class Initialized
INFO - 2023-05-17 09:47:12 --> URI Class Initialized
INFO - 2023-05-17 09:47:12 --> Router Class Initialized
INFO - 2023-05-17 09:47:12 --> Output Class Initialized
INFO - 2023-05-17 09:47:12 --> Security Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:47:12 --> Config Class Initialized
INFO - 2023-05-17 09:47:12 --> Config Class Initialized
INFO - 2023-05-17 09:47:12 --> Input Class Initialized
INFO - 2023-05-17 09:47:12 --> Hooks Class Initialized
INFO - 2023-05-17 09:47:12 --> Hooks Class Initialized
INFO - 2023-05-17 09:47:12 --> Language Class Initialized
DEBUG - 2023-05-17 09:47:12 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:47:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:47:12 --> Utf8 Class Initialized
INFO - 2023-05-17 09:47:12 --> Loader Class Initialized
INFO - 2023-05-17 09:47:12 --> Utf8 Class Initialized
INFO - 2023-05-17 09:47:12 --> Controller Class Initialized
INFO - 2023-05-17 09:47:12 --> URI Class Initialized
INFO - 2023-05-17 09:47:12 --> URI Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:47:12 --> Router Class Initialized
INFO - 2023-05-17 09:47:12 --> Router Class Initialized
INFO - 2023-05-17 09:47:12 --> Output Class Initialized
INFO - 2023-05-17 09:47:12 --> Database Driver Class Initialized
INFO - 2023-05-17 09:47:12 --> Security Class Initialized
INFO - 2023-05-17 09:47:12 --> Output Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:47:12 --> Security Class Initialized
INFO - 2023-05-17 09:47:12 --> Input Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:47:12 --> Language Class Initialized
INFO - 2023-05-17 09:47:12 --> Input Class Initialized
INFO - 2023-05-17 09:47:12 --> Language Class Initialized
INFO - 2023-05-17 09:47:12 --> Loader Class Initialized
INFO - 2023-05-17 09:47:12 --> Loader Class Initialized
INFO - 2023-05-17 09:47:12 --> Controller Class Initialized
INFO - 2023-05-17 09:47:12 --> Controller Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:47:12 --> Database Driver Class Initialized
INFO - 2023-05-17 09:47:12 --> Database Driver Class Initialized
INFO - 2023-05-17 09:47:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:47:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:47:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:47:12 --> Final output sent to browser
DEBUG - 2023-05-17 09:47:12 --> Total execution time: 0.0138
INFO - 2023-05-17 09:47:12 --> Final output sent to browser
DEBUG - 2023-05-17 09:47:12 --> Total execution time: 0.0144
INFO - 2023-05-17 09:47:12 --> Config Class Initialized
INFO - 2023-05-17 09:47:12 --> Final output sent to browser
INFO - 2023-05-17 09:47:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Total execution time: 0.0247
DEBUG - 2023-05-17 09:47:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:47:12 --> Utf8 Class Initialized
INFO - 2023-05-17 09:47:12 --> URI Class Initialized
INFO - 2023-05-17 09:47:12 --> Router Class Initialized
INFO - 2023-05-17 09:47:12 --> Output Class Initialized
INFO - 2023-05-17 09:47:12 --> Security Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:47:12 --> Input Class Initialized
INFO - 2023-05-17 09:47:12 --> Language Class Initialized
INFO - 2023-05-17 09:47:12 --> Loader Class Initialized
INFO - 2023-05-17 09:47:12 --> Controller Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:47:12 --> Database Driver Class Initialized
INFO - 2023-05-17 09:47:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:47:12 --> Config Class Initialized
INFO - 2023-05-17 09:47:12 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:47:12 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:47:12 --> Utf8 Class Initialized
INFO - 2023-05-17 09:47:12 --> URI Class Initialized
INFO - 2023-05-17 09:47:12 --> Router Class Initialized
INFO - 2023-05-17 09:47:12 --> Output Class Initialized
INFO - 2023-05-17 09:47:12 --> Security Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:47:12 --> Input Class Initialized
INFO - 2023-05-17 09:47:12 --> Language Class Initialized
INFO - 2023-05-17 09:47:12 --> Loader Class Initialized
INFO - 2023-05-17 09:47:12 --> Controller Class Initialized
DEBUG - 2023-05-17 09:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:47:12 --> Database Driver Class Initialized
INFO - 2023-05-17 09:47:12 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:37 --> Config Class Initialized
INFO - 2023-05-17 09:49:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:37 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:37 --> URI Class Initialized
INFO - 2023-05-17 09:49:37 --> Router Class Initialized
INFO - 2023-05-17 09:49:37 --> Output Class Initialized
INFO - 2023-05-17 09:49:37 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:37 --> Input Class Initialized
INFO - 2023-05-17 09:49:37 --> Language Class Initialized
INFO - 2023-05-17 09:49:37 --> Loader Class Initialized
INFO - 2023-05-17 09:49:37 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:37 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:37 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:37 --> Total execution time: 0.0381
INFO - 2023-05-17 09:49:37 --> Config Class Initialized
INFO - 2023-05-17 09:49:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:37 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:37 --> URI Class Initialized
INFO - 2023-05-17 09:49:37 --> Router Class Initialized
INFO - 2023-05-17 09:49:37 --> Output Class Initialized
INFO - 2023-05-17 09:49:37 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:37 --> Input Class Initialized
INFO - 2023-05-17 09:49:37 --> Language Class Initialized
INFO - 2023-05-17 09:49:37 --> Loader Class Initialized
INFO - 2023-05-17 09:49:37 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:37 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:37 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:37 --> Total execution time: 0.0611
INFO - 2023-05-17 09:49:39 --> Config Class Initialized
INFO - 2023-05-17 09:49:39 --> Hooks Class Initialized
INFO - 2023-05-17 09:49:39 --> Config Class Initialized
DEBUG - 2023-05-17 09:49:39 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:39 --> Hooks Class Initialized
INFO - 2023-05-17 09:49:39 --> Utf8 Class Initialized
DEBUG - 2023-05-17 09:49:39 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:39 --> URI Class Initialized
INFO - 2023-05-17 09:49:39 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:39 --> Router Class Initialized
INFO - 2023-05-17 09:49:39 --> URI Class Initialized
INFO - 2023-05-17 09:49:39 --> Output Class Initialized
INFO - 2023-05-17 09:49:39 --> Router Class Initialized
INFO - 2023-05-17 09:49:39 --> Security Class Initialized
INFO - 2023-05-17 09:49:39 --> Output Class Initialized
DEBUG - 2023-05-17 09:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:39 --> Security Class Initialized
INFO - 2023-05-17 09:49:39 --> Input Class Initialized
DEBUG - 2023-05-17 09:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:39 --> Language Class Initialized
INFO - 2023-05-17 09:49:39 --> Input Class Initialized
INFO - 2023-05-17 09:49:39 --> Language Class Initialized
INFO - 2023-05-17 09:49:39 --> Loader Class Initialized
INFO - 2023-05-17 09:49:39 --> Loader Class Initialized
INFO - 2023-05-17 09:49:39 --> Controller Class Initialized
INFO - 2023-05-17 09:49:39 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:49:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:39 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:39 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:39 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:39 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:39 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:39 --> Total execution time: 0.0653
INFO - 2023-05-17 09:49:39 --> Config Class Initialized
INFO - 2023-05-17 09:49:39 --> Final output sent to browser
INFO - 2023-05-17 09:49:39 --> Config Class Initialized
INFO - 2023-05-17 09:49:39 --> Hooks Class Initialized
INFO - 2023-05-17 09:49:39 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:39 --> Total execution time: 0.0866
DEBUG - 2023-05-17 09:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:49:39 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:39 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:39 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:39 --> URI Class Initialized
INFO - 2023-05-17 09:49:39 --> URI Class Initialized
INFO - 2023-05-17 09:49:39 --> Router Class Initialized
INFO - 2023-05-17 09:49:39 --> Router Class Initialized
INFO - 2023-05-17 09:49:39 --> Output Class Initialized
INFO - 2023-05-17 09:49:39 --> Output Class Initialized
INFO - 2023-05-17 09:49:39 --> Security Class Initialized
INFO - 2023-05-17 09:49:39 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:39 --> Input Class Initialized
INFO - 2023-05-17 09:49:39 --> Input Class Initialized
INFO - 2023-05-17 09:49:39 --> Language Class Initialized
INFO - 2023-05-17 09:49:39 --> Language Class Initialized
INFO - 2023-05-17 09:49:39 --> Loader Class Initialized
INFO - 2023-05-17 09:49:39 --> Loader Class Initialized
INFO - 2023-05-17 09:49:39 --> Controller Class Initialized
INFO - 2023-05-17 09:49:39 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:49:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:39 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:39 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:39 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:39 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:39 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:39 --> Total execution time: 0.1328
INFO - 2023-05-17 09:49:39 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:39 --> Total execution time: 0.1371
INFO - 2023-05-17 09:49:41 --> Config Class Initialized
INFO - 2023-05-17 09:49:41 --> Config Class Initialized
INFO - 2023-05-17 09:49:41 --> Hooks Class Initialized
INFO - 2023-05-17 09:49:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:49:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:41 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:41 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:41 --> URI Class Initialized
INFO - 2023-05-17 09:49:41 --> URI Class Initialized
INFO - 2023-05-17 09:49:41 --> Router Class Initialized
INFO - 2023-05-17 09:49:41 --> Router Class Initialized
INFO - 2023-05-17 09:49:41 --> Output Class Initialized
INFO - 2023-05-17 09:49:41 --> Output Class Initialized
INFO - 2023-05-17 09:49:41 --> Security Class Initialized
INFO - 2023-05-17 09:49:41 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:41 --> Input Class Initialized
INFO - 2023-05-17 09:49:41 --> Input Class Initialized
INFO - 2023-05-17 09:49:41 --> Language Class Initialized
INFO - 2023-05-17 09:49:41 --> Language Class Initialized
INFO - 2023-05-17 09:49:41 --> Loader Class Initialized
INFO - 2023-05-17 09:49:41 --> Loader Class Initialized
INFO - 2023-05-17 09:49:41 --> Controller Class Initialized
INFO - 2023-05-17 09:49:41 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:41 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:41 --> Total execution time: 0.0045
INFO - 2023-05-17 09:49:41 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:41 --> Config Class Initialized
INFO - 2023-05-17 09:49:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:41 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:41 --> URI Class Initialized
INFO - 2023-05-17 09:49:41 --> Router Class Initialized
INFO - 2023-05-17 09:49:41 --> Output Class Initialized
INFO - 2023-05-17 09:49:41 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:41 --> Input Class Initialized
INFO - 2023-05-17 09:49:41 --> Language Class Initialized
INFO - 2023-05-17 09:49:41 --> Loader Class Initialized
INFO - 2023-05-17 09:49:41 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:41 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:41 --> Model "Login_model" initialized
INFO - 2023-05-17 09:49:41 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:41 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:41 --> Total execution time: 0.0247
INFO - 2023-05-17 09:49:41 --> Config Class Initialized
INFO - 2023-05-17 09:49:41 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:41 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:41 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:41 --> URI Class Initialized
INFO - 2023-05-17 09:49:41 --> Router Class Initialized
INFO - 2023-05-17 09:49:41 --> Output Class Initialized
INFO - 2023-05-17 09:49:41 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:41 --> Input Class Initialized
INFO - 2023-05-17 09:49:41 --> Language Class Initialized
INFO - 2023-05-17 09:49:41 --> Loader Class Initialized
INFO - 2023-05-17 09:49:41 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:41 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:41 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:41 --> Total execution time: 0.0361
INFO - 2023-05-17 09:49:41 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:41 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:41 --> Total execution time: 0.0617
INFO - 2023-05-17 09:49:43 --> Config Class Initialized
INFO - 2023-05-17 09:49:43 --> Config Class Initialized
INFO - 2023-05-17 09:49:43 --> Hooks Class Initialized
INFO - 2023-05-17 09:49:43 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:43 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:49:43 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:43 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:43 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:43 --> URI Class Initialized
INFO - 2023-05-17 09:49:43 --> URI Class Initialized
INFO - 2023-05-17 09:49:43 --> Router Class Initialized
INFO - 2023-05-17 09:49:43 --> Router Class Initialized
INFO - 2023-05-17 09:49:43 --> Output Class Initialized
INFO - 2023-05-17 09:49:43 --> Output Class Initialized
INFO - 2023-05-17 09:49:43 --> Security Class Initialized
INFO - 2023-05-17 09:49:43 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:43 --> Input Class Initialized
INFO - 2023-05-17 09:49:43 --> Input Class Initialized
INFO - 2023-05-17 09:49:43 --> Language Class Initialized
INFO - 2023-05-17 09:49:43 --> Language Class Initialized
INFO - 2023-05-17 09:49:43 --> Loader Class Initialized
INFO - 2023-05-17 09:49:43 --> Loader Class Initialized
INFO - 2023-05-17 09:49:43 --> Controller Class Initialized
INFO - 2023-05-17 09:49:43 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:49:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:43 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:43 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:43 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:43 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:43 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:43 --> Total execution time: 0.0231
INFO - 2023-05-17 09:49:43 --> Config Class Initialized
INFO - 2023-05-17 09:49:43 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:43 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:43 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:43 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:43 --> URI Class Initialized
INFO - 2023-05-17 09:49:43 --> Router Class Initialized
INFO - 2023-05-17 09:49:43 --> Output Class Initialized
INFO - 2023-05-17 09:49:43 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:43 --> Input Class Initialized
INFO - 2023-05-17 09:49:43 --> Language Class Initialized
INFO - 2023-05-17 09:49:43 --> Loader Class Initialized
INFO - 2023-05-17 09:49:43 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:43 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:43 --> Model "Login_model" initialized
INFO - 2023-05-17 09:49:43 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:43 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:43 --> Total execution time: 0.1108
INFO - 2023-05-17 09:49:43 --> Final output sent to browser
INFO - 2023-05-17 09:49:43 --> Config Class Initialized
DEBUG - 2023-05-17 09:49:43 --> Total execution time: 0.1991
INFO - 2023-05-17 09:49:43 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:43 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:43 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:43 --> URI Class Initialized
INFO - 2023-05-17 09:49:43 --> Router Class Initialized
INFO - 2023-05-17 09:49:43 --> Output Class Initialized
INFO - 2023-05-17 09:49:43 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:43 --> Input Class Initialized
INFO - 2023-05-17 09:49:43 --> Language Class Initialized
INFO - 2023-05-17 09:49:43 --> Loader Class Initialized
INFO - 2023-05-17 09:49:43 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:43 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:43 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:43 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:43 --> Model "Login_model" initialized
INFO - 2023-05-17 09:49:43 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:43 --> Total execution time: 0.1573
INFO - 2023-05-17 09:49:46 --> Config Class Initialized
INFO - 2023-05-17 09:49:46 --> Hooks Class Initialized
INFO - 2023-05-17 09:49:46 --> Config Class Initialized
INFO - 2023-05-17 09:49:46 --> Config Class Initialized
INFO - 2023-05-17 09:49:46 --> Hooks Class Initialized
INFO - 2023-05-17 09:49:46 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:49:46 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:46 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:46 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:46 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:46 --> URI Class Initialized
INFO - 2023-05-17 09:49:46 --> URI Class Initialized
INFO - 2023-05-17 09:49:46 --> URI Class Initialized
INFO - 2023-05-17 09:49:46 --> Router Class Initialized
INFO - 2023-05-17 09:49:46 --> Router Class Initialized
INFO - 2023-05-17 09:49:46 --> Router Class Initialized
INFO - 2023-05-17 09:49:46 --> Output Class Initialized
INFO - 2023-05-17 09:49:46 --> Output Class Initialized
INFO - 2023-05-17 09:49:46 --> Output Class Initialized
INFO - 2023-05-17 09:49:46 --> Security Class Initialized
INFO - 2023-05-17 09:49:46 --> Security Class Initialized
INFO - 2023-05-17 09:49:46 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:46 --> Input Class Initialized
INFO - 2023-05-17 09:49:46 --> Input Class Initialized
INFO - 2023-05-17 09:49:46 --> Input Class Initialized
INFO - 2023-05-17 09:49:46 --> Language Class Initialized
INFO - 2023-05-17 09:49:46 --> Language Class Initialized
INFO - 2023-05-17 09:49:46 --> Language Class Initialized
INFO - 2023-05-17 09:49:46 --> Loader Class Initialized
INFO - 2023-05-17 09:49:46 --> Loader Class Initialized
INFO - 2023-05-17 09:49:46 --> Loader Class Initialized
INFO - 2023-05-17 09:49:46 --> Controller Class Initialized
INFO - 2023-05-17 09:49:46 --> Controller Class Initialized
INFO - 2023-05-17 09:49:46 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:46 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:46 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:46 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:46 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:46 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:46 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:46 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:46 --> Total execution time: 0.0149
INFO - 2023-05-17 09:49:46 --> Final output sent to browser
INFO - 2023-05-17 09:49:46 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:46 --> Total execution time: 0.0161
DEBUG - 2023-05-17 09:49:46 --> Total execution time: 0.0162
INFO - 2023-05-17 09:49:46 --> Config Class Initialized
INFO - 2023-05-17 09:49:46 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:46 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:46 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:46 --> URI Class Initialized
INFO - 2023-05-17 09:49:46 --> Router Class Initialized
INFO - 2023-05-17 09:49:46 --> Output Class Initialized
INFO - 2023-05-17 09:49:46 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:46 --> Input Class Initialized
INFO - 2023-05-17 09:49:46 --> Language Class Initialized
INFO - 2023-05-17 09:49:46 --> Loader Class Initialized
INFO - 2023-05-17 09:49:46 --> Config Class Initialized
INFO - 2023-05-17 09:49:46 --> Config Class Initialized
INFO - 2023-05-17 09:49:46 --> Hooks Class Initialized
INFO - 2023-05-17 09:49:46 --> Hooks Class Initialized
INFO - 2023-05-17 09:49:46 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:46 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:46 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:46 --> URI Class Initialized
INFO - 2023-05-17 09:49:46 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:46 --> URI Class Initialized
INFO - 2023-05-17 09:49:46 --> Router Class Initialized
INFO - 2023-05-17 09:49:46 --> Router Class Initialized
INFO - 2023-05-17 09:49:46 --> Output Class Initialized
INFO - 2023-05-17 09:49:46 --> Output Class Initialized
INFO - 2023-05-17 09:49:46 --> Security Class Initialized
INFO - 2023-05-17 09:49:46 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:46 --> Input Class Initialized
INFO - 2023-05-17 09:49:46 --> Input Class Initialized
INFO - 2023-05-17 09:49:46 --> Language Class Initialized
INFO - 2023-05-17 09:49:46 --> Language Class Initialized
INFO - 2023-05-17 09:49:46 --> Loader Class Initialized
INFO - 2023-05-17 09:49:46 --> Loader Class Initialized
INFO - 2023-05-17 09:49:46 --> Controller Class Initialized
INFO - 2023-05-17 09:49:46 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:46 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:46 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:46 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:46 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:46 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:46 --> Final output sent to browser
INFO - 2023-05-17 09:49:46 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:46 --> Total execution time: 0.0227
DEBUG - 2023-05-17 09:49:46 --> Total execution time: 0.0226
INFO - 2023-05-17 09:49:46 --> Final output sent to browser
INFO - 2023-05-17 09:49:46 --> Config Class Initialized
DEBUG - 2023-05-17 09:49:46 --> Total execution time: 0.0304
INFO - 2023-05-17 09:49:46 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:46 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:46 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:46 --> URI Class Initialized
INFO - 2023-05-17 09:49:46 --> Router Class Initialized
INFO - 2023-05-17 09:49:46 --> Output Class Initialized
INFO - 2023-05-17 09:49:46 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:46 --> Input Class Initialized
INFO - 2023-05-17 09:49:46 --> Language Class Initialized
INFO - 2023-05-17 09:49:46 --> Loader Class Initialized
INFO - 2023-05-17 09:49:46 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:46 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:46 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:47 --> Config Class Initialized
INFO - 2023-05-17 09:49:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:47 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:47 --> URI Class Initialized
INFO - 2023-05-17 09:49:47 --> Router Class Initialized
INFO - 2023-05-17 09:49:47 --> Output Class Initialized
INFO - 2023-05-17 09:49:47 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:47 --> Input Class Initialized
INFO - 2023-05-17 09:49:47 --> Language Class Initialized
INFO - 2023-05-17 09:49:47 --> Loader Class Initialized
INFO - 2023-05-17 09:49:47 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:47 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:59 --> Config Class Initialized
INFO - 2023-05-17 09:49:59 --> Config Class Initialized
INFO - 2023-05-17 09:49:59 --> Hooks Class Initialized
INFO - 2023-05-17 09:49:59 --> Config Class Initialized
INFO - 2023-05-17 09:49:59 --> Hooks Class Initialized
INFO - 2023-05-17 09:49:59 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:59 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:49:59 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:49:59 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:59 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:59 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:59 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:59 --> URI Class Initialized
INFO - 2023-05-17 09:49:59 --> URI Class Initialized
INFO - 2023-05-17 09:49:59 --> URI Class Initialized
INFO - 2023-05-17 09:49:59 --> Router Class Initialized
INFO - 2023-05-17 09:49:59 --> Router Class Initialized
INFO - 2023-05-17 09:49:59 --> Router Class Initialized
INFO - 2023-05-17 09:49:59 --> Output Class Initialized
INFO - 2023-05-17 09:49:59 --> Output Class Initialized
INFO - 2023-05-17 09:49:59 --> Output Class Initialized
INFO - 2023-05-17 09:49:59 --> Security Class Initialized
INFO - 2023-05-17 09:49:59 --> Security Class Initialized
INFO - 2023-05-17 09:49:59 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:59 --> Input Class Initialized
INFO - 2023-05-17 09:49:59 --> Input Class Initialized
INFO - 2023-05-17 09:49:59 --> Input Class Initialized
INFO - 2023-05-17 09:49:59 --> Language Class Initialized
INFO - 2023-05-17 09:49:59 --> Language Class Initialized
INFO - 2023-05-17 09:49:59 --> Language Class Initialized
INFO - 2023-05-17 09:49:59 --> Loader Class Initialized
INFO - 2023-05-17 09:49:59 --> Loader Class Initialized
INFO - 2023-05-17 09:49:59 --> Loader Class Initialized
INFO - 2023-05-17 09:49:59 --> Controller Class Initialized
INFO - 2023-05-17 09:49:59 --> Controller Class Initialized
INFO - 2023-05-17 09:49:59 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:59 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:59 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:59 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:59 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:59 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:59 --> Final output sent to browser
INFO - 2023-05-17 09:49:59 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:59 --> Total execution time: 0.1057
INFO - 2023-05-17 09:49:59 --> Model "Cluster_model" initialized
DEBUG - 2023-05-17 09:49:59 --> Total execution time: 0.1058
INFO - 2023-05-17 09:49:59 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:59 --> Total execution time: 0.1060
INFO - 2023-05-17 09:49:59 --> Config Class Initialized
INFO - 2023-05-17 09:49:59 --> Config Class Initialized
INFO - 2023-05-17 09:49:59 --> Hooks Class Initialized
INFO - 2023-05-17 09:49:59 --> Config Class Initialized
INFO - 2023-05-17 09:49:59 --> Hooks Class Initialized
INFO - 2023-05-17 09:49:59 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:59 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:49:59 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:49:59 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:59 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:59 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:59 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:59 --> URI Class Initialized
INFO - 2023-05-17 09:49:59 --> URI Class Initialized
INFO - 2023-05-17 09:49:59 --> URI Class Initialized
INFO - 2023-05-17 09:49:59 --> Router Class Initialized
INFO - 2023-05-17 09:49:59 --> Router Class Initialized
INFO - 2023-05-17 09:49:59 --> Output Class Initialized
INFO - 2023-05-17 09:49:59 --> Router Class Initialized
INFO - 2023-05-17 09:49:59 --> Output Class Initialized
INFO - 2023-05-17 09:49:59 --> Security Class Initialized
INFO - 2023-05-17 09:49:59 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:59 --> Output Class Initialized
INFO - 2023-05-17 09:49:59 --> Input Class Initialized
DEBUG - 2023-05-17 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:59 --> Security Class Initialized
INFO - 2023-05-17 09:49:59 --> Language Class Initialized
INFO - 2023-05-17 09:49:59 --> Input Class Initialized
DEBUG - 2023-05-17 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:59 --> Language Class Initialized
INFO - 2023-05-17 09:49:59 --> Loader Class Initialized
INFO - 2023-05-17 09:49:59 --> Input Class Initialized
INFO - 2023-05-17 09:49:59 --> Controller Class Initialized
INFO - 2023-05-17 09:49:59 --> Language Class Initialized
INFO - 2023-05-17 09:49:59 --> Loader Class Initialized
DEBUG - 2023-05-17 09:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:59 --> Controller Class Initialized
INFO - 2023-05-17 09:49:59 --> Loader Class Initialized
DEBUG - 2023-05-17 09:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:59 --> Controller Class Initialized
INFO - 2023-05-17 09:49:59 --> Database Driver Class Initialized
DEBUG - 2023-05-17 09:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:59 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:59 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:59 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:59 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:59 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:59 --> Final output sent to browser
INFO - 2023-05-17 09:49:59 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:59 --> Total execution time: 0.0294
DEBUG - 2023-05-17 09:49:59 --> Total execution time: 0.0293
INFO - 2023-05-17 09:49:59 --> Config Class Initialized
INFO - 2023-05-17 09:49:59 --> Final output sent to browser
DEBUG - 2023-05-17 09:49:59 --> Total execution time: 0.0563
INFO - 2023-05-17 09:49:59 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:59 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:59 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:59 --> URI Class Initialized
INFO - 2023-05-17 09:49:59 --> Router Class Initialized
INFO - 2023-05-17 09:49:59 --> Output Class Initialized
INFO - 2023-05-17 09:49:59 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:59 --> Input Class Initialized
INFO - 2023-05-17 09:49:59 --> Language Class Initialized
INFO - 2023-05-17 09:49:59 --> Loader Class Initialized
INFO - 2023-05-17 09:49:59 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:59 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:59 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:49:59 --> Config Class Initialized
INFO - 2023-05-17 09:49:59 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:49:59 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:49:59 --> Utf8 Class Initialized
INFO - 2023-05-17 09:49:59 --> URI Class Initialized
INFO - 2023-05-17 09:49:59 --> Router Class Initialized
INFO - 2023-05-17 09:49:59 --> Output Class Initialized
INFO - 2023-05-17 09:49:59 --> Security Class Initialized
DEBUG - 2023-05-17 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:49:59 --> Input Class Initialized
INFO - 2023-05-17 09:49:59 --> Language Class Initialized
INFO - 2023-05-17 09:49:59 --> Loader Class Initialized
INFO - 2023-05-17 09:49:59 --> Controller Class Initialized
DEBUG - 2023-05-17 09:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:49:59 --> Database Driver Class Initialized
INFO - 2023-05-17 09:49:59 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:50:21 --> Config Class Initialized
INFO - 2023-05-17 09:50:21 --> Config Class Initialized
INFO - 2023-05-17 09:50:21 --> Config Class Initialized
INFO - 2023-05-17 09:50:21 --> Hooks Class Initialized
INFO - 2023-05-17 09:50:21 --> Hooks Class Initialized
INFO - 2023-05-17 09:50:21 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:50:21 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:50:21 --> Utf8 Class Initialized
INFO - 2023-05-17 09:50:21 --> Utf8 Class Initialized
INFO - 2023-05-17 09:50:21 --> Utf8 Class Initialized
INFO - 2023-05-17 09:50:21 --> URI Class Initialized
INFO - 2023-05-17 09:50:21 --> URI Class Initialized
INFO - 2023-05-17 09:50:21 --> URI Class Initialized
INFO - 2023-05-17 09:50:21 --> Router Class Initialized
INFO - 2023-05-17 09:50:21 --> Router Class Initialized
INFO - 2023-05-17 09:50:21 --> Router Class Initialized
INFO - 2023-05-17 09:50:21 --> Output Class Initialized
INFO - 2023-05-17 09:50:21 --> Output Class Initialized
INFO - 2023-05-17 09:50:21 --> Output Class Initialized
INFO - 2023-05-17 09:50:21 --> Security Class Initialized
INFO - 2023-05-17 09:50:21 --> Security Class Initialized
INFO - 2023-05-17 09:50:21 --> Security Class Initialized
DEBUG - 2023-05-17 09:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:50:21 --> Input Class Initialized
INFO - 2023-05-17 09:50:21 --> Input Class Initialized
INFO - 2023-05-17 09:50:21 --> Input Class Initialized
INFO - 2023-05-17 09:50:21 --> Language Class Initialized
INFO - 2023-05-17 09:50:21 --> Language Class Initialized
INFO - 2023-05-17 09:50:21 --> Language Class Initialized
INFO - 2023-05-17 09:50:21 --> Loader Class Initialized
INFO - 2023-05-17 09:50:21 --> Loader Class Initialized
INFO - 2023-05-17 09:50:21 --> Loader Class Initialized
INFO - 2023-05-17 09:50:21 --> Controller Class Initialized
INFO - 2023-05-17 09:50:21 --> Controller Class Initialized
DEBUG - 2023-05-17 09:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:50:21 --> Controller Class Initialized
DEBUG - 2023-05-17 09:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:50:21 --> Database Driver Class Initialized
INFO - 2023-05-17 09:50:21 --> Database Driver Class Initialized
INFO - 2023-05-17 09:50:21 --> Database Driver Class Initialized
INFO - 2023-05-17 09:50:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:50:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:50:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:50:21 --> Final output sent to browser
DEBUG - 2023-05-17 09:50:21 --> Total execution time: 0.1024
INFO - 2023-05-17 09:50:21 --> Config Class Initialized
INFO - 2023-05-17 09:50:21 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:50:21 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:50:21 --> Utf8 Class Initialized
INFO - 2023-05-17 09:50:21 --> URI Class Initialized
INFO - 2023-05-17 09:50:21 --> Router Class Initialized
INFO - 2023-05-17 09:50:21 --> Output Class Initialized
INFO - 2023-05-17 09:50:21 --> Security Class Initialized
DEBUG - 2023-05-17 09:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:50:21 --> Input Class Initialized
INFO - 2023-05-17 09:50:21 --> Final output sent to browser
INFO - 2023-05-17 09:50:21 --> Language Class Initialized
DEBUG - 2023-05-17 09:50:21 --> Total execution time: 0.1060
INFO - 2023-05-17 09:50:21 --> Final output sent to browser
INFO - 2023-05-17 09:50:21 --> Loader Class Initialized
DEBUG - 2023-05-17 09:50:21 --> Total execution time: 0.1064
INFO - 2023-05-17 09:50:21 --> Controller Class Initialized
DEBUG - 2023-05-17 09:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:50:21 --> Database Driver Class Initialized
INFO - 2023-05-17 09:50:21 --> Config Class Initialized
INFO - 2023-05-17 09:50:21 --> Hooks Class Initialized
INFO - 2023-05-17 09:50:21 --> Config Class Initialized
DEBUG - 2023-05-17 09:50:21 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:50:21 --> Hooks Class Initialized
INFO - 2023-05-17 09:50:21 --> Utf8 Class Initialized
DEBUG - 2023-05-17 09:50:21 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:50:21 --> URI Class Initialized
INFO - 2023-05-17 09:50:21 --> Utf8 Class Initialized
INFO - 2023-05-17 09:50:21 --> Router Class Initialized
INFO - 2023-05-17 09:50:21 --> URI Class Initialized
INFO - 2023-05-17 09:50:21 --> Output Class Initialized
INFO - 2023-05-17 09:50:21 --> Router Class Initialized
INFO - 2023-05-17 09:50:21 --> Security Class Initialized
INFO - 2023-05-17 09:50:21 --> Output Class Initialized
DEBUG - 2023-05-17 09:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:50:21 --> Security Class Initialized
INFO - 2023-05-17 09:50:21 --> Input Class Initialized
DEBUG - 2023-05-17 09:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:50:21 --> Language Class Initialized
INFO - 2023-05-17 09:50:21 --> Input Class Initialized
INFO - 2023-05-17 09:50:21 --> Loader Class Initialized
INFO - 2023-05-17 09:50:21 --> Language Class Initialized
INFO - 2023-05-17 09:50:21 --> Controller Class Initialized
DEBUG - 2023-05-17 09:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:50:21 --> Loader Class Initialized
INFO - 2023-05-17 09:50:21 --> Database Driver Class Initialized
INFO - 2023-05-17 09:50:21 --> Controller Class Initialized
DEBUG - 2023-05-17 09:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:50:21 --> Database Driver Class Initialized
INFO - 2023-05-17 09:50:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:50:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:50:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:50:21 --> Final output sent to browser
INFO - 2023-05-17 09:50:21 --> Final output sent to browser
DEBUG - 2023-05-17 09:50:21 --> Total execution time: 0.0209
DEBUG - 2023-05-17 09:50:21 --> Total execution time: 0.0281
INFO - 2023-05-17 09:50:21 --> Final output sent to browser
DEBUG - 2023-05-17 09:50:21 --> Total execution time: 0.0222
INFO - 2023-05-17 09:50:21 --> Config Class Initialized
INFO - 2023-05-17 09:50:21 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:50:21 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:50:21 --> Utf8 Class Initialized
INFO - 2023-05-17 09:50:21 --> URI Class Initialized
INFO - 2023-05-17 09:50:21 --> Router Class Initialized
INFO - 2023-05-17 09:50:21 --> Output Class Initialized
INFO - 2023-05-17 09:50:21 --> Security Class Initialized
DEBUG - 2023-05-17 09:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:50:21 --> Input Class Initialized
INFO - 2023-05-17 09:50:21 --> Language Class Initialized
INFO - 2023-05-17 09:50:21 --> Loader Class Initialized
INFO - 2023-05-17 09:50:21 --> Controller Class Initialized
DEBUG - 2023-05-17 09:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:50:21 --> Database Driver Class Initialized
INFO - 2023-05-17 09:50:21 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:50:22 --> Config Class Initialized
INFO - 2023-05-17 09:50:22 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:50:22 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:50:22 --> Utf8 Class Initialized
INFO - 2023-05-17 09:50:22 --> URI Class Initialized
INFO - 2023-05-17 09:50:22 --> Router Class Initialized
INFO - 2023-05-17 09:50:22 --> Output Class Initialized
INFO - 2023-05-17 09:50:22 --> Security Class Initialized
DEBUG - 2023-05-17 09:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:50:22 --> Input Class Initialized
INFO - 2023-05-17 09:50:22 --> Language Class Initialized
INFO - 2023-05-17 09:50:22 --> Loader Class Initialized
INFO - 2023-05-17 09:50:22 --> Controller Class Initialized
DEBUG - 2023-05-17 09:50:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:50:22 --> Database Driver Class Initialized
INFO - 2023-05-17 09:50:22 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:51:07 --> Config Class Initialized
INFO - 2023-05-17 09:51:07 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:51:07 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:51:07 --> Utf8 Class Initialized
INFO - 2023-05-17 09:51:07 --> URI Class Initialized
INFO - 2023-05-17 09:51:07 --> Router Class Initialized
INFO - 2023-05-17 09:51:07 --> Output Class Initialized
INFO - 2023-05-17 09:51:07 --> Security Class Initialized
DEBUG - 2023-05-17 09:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:51:07 --> Input Class Initialized
INFO - 2023-05-17 09:51:07 --> Language Class Initialized
INFO - 2023-05-17 09:51:07 --> Loader Class Initialized
INFO - 2023-05-17 09:51:07 --> Controller Class Initialized
DEBUG - 2023-05-17 09:51:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:51:07 --> Database Driver Class Initialized
INFO - 2023-05-17 09:51:07 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:51:07 --> Final output sent to browser
DEBUG - 2023-05-17 09:51:07 --> Total execution time: 0.0146
INFO - 2023-05-17 09:51:07 --> Config Class Initialized
INFO - 2023-05-17 09:51:07 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:51:07 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:51:07 --> Utf8 Class Initialized
INFO - 2023-05-17 09:51:07 --> URI Class Initialized
INFO - 2023-05-17 09:51:07 --> Router Class Initialized
INFO - 2023-05-17 09:51:07 --> Output Class Initialized
INFO - 2023-05-17 09:51:07 --> Security Class Initialized
DEBUG - 2023-05-17 09:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:51:07 --> Input Class Initialized
INFO - 2023-05-17 09:51:07 --> Language Class Initialized
INFO - 2023-05-17 09:51:07 --> Loader Class Initialized
INFO - 2023-05-17 09:51:07 --> Controller Class Initialized
DEBUG - 2023-05-17 09:51:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:51:08 --> Database Driver Class Initialized
INFO - 2023-05-17 09:51:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:51:08 --> Final output sent to browser
DEBUG - 2023-05-17 09:51:08 --> Total execution time: 0.0202
INFO - 2023-05-17 09:51:10 --> Config Class Initialized
INFO - 2023-05-17 09:51:10 --> Hooks Class Initialized
INFO - 2023-05-17 09:51:10 --> Config Class Initialized
INFO - 2023-05-17 09:51:10 --> Config Class Initialized
INFO - 2023-05-17 09:51:10 --> Hooks Class Initialized
INFO - 2023-05-17 09:51:10 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:51:10 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:51:10 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:51:10 --> Utf8 Class Initialized
DEBUG - 2023-05-17 09:51:10 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:51:10 --> Utf8 Class Initialized
INFO - 2023-05-17 09:51:10 --> Utf8 Class Initialized
INFO - 2023-05-17 09:51:10 --> URI Class Initialized
INFO - 2023-05-17 09:51:10 --> URI Class Initialized
INFO - 2023-05-17 09:51:10 --> URI Class Initialized
INFO - 2023-05-17 09:51:10 --> Router Class Initialized
INFO - 2023-05-17 09:51:10 --> Router Class Initialized
INFO - 2023-05-17 09:51:10 --> Router Class Initialized
INFO - 2023-05-17 09:51:10 --> Output Class Initialized
INFO - 2023-05-17 09:51:10 --> Output Class Initialized
INFO - 2023-05-17 09:51:10 --> Security Class Initialized
INFO - 2023-05-17 09:51:10 --> Output Class Initialized
INFO - 2023-05-17 09:51:10 --> Security Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:51:10 --> Security Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:51:10 --> Input Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:51:10 --> Input Class Initialized
INFO - 2023-05-17 09:51:10 --> Input Class Initialized
INFO - 2023-05-17 09:51:10 --> Language Class Initialized
INFO - 2023-05-17 09:51:10 --> Language Class Initialized
INFO - 2023-05-17 09:51:10 --> Language Class Initialized
INFO - 2023-05-17 09:51:10 --> Loader Class Initialized
INFO - 2023-05-17 09:51:10 --> Loader Class Initialized
INFO - 2023-05-17 09:51:10 --> Loader Class Initialized
INFO - 2023-05-17 09:51:10 --> Controller Class Initialized
INFO - 2023-05-17 09:51:10 --> Controller Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:51:10 --> Controller Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:51:10 --> Database Driver Class Initialized
INFO - 2023-05-17 09:51:10 --> Database Driver Class Initialized
INFO - 2023-05-17 09:51:10 --> Database Driver Class Initialized
INFO - 2023-05-17 09:51:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:51:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:51:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:51:10 --> Final output sent to browser
DEBUG - 2023-05-17 09:51:10 --> Total execution time: 0.0147
INFO - 2023-05-17 09:51:10 --> Final output sent to browser
DEBUG - 2023-05-17 09:51:10 --> Total execution time: 0.0169
INFO - 2023-05-17 09:51:10 --> Final output sent to browser
DEBUG - 2023-05-17 09:51:10 --> Total execution time: 0.0167
INFO - 2023-05-17 09:51:10 --> Config Class Initialized
INFO - 2023-05-17 09:51:10 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:51:10 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:51:10 --> Config Class Initialized
INFO - 2023-05-17 09:51:10 --> Utf8 Class Initialized
INFO - 2023-05-17 09:51:10 --> Hooks Class Initialized
INFO - 2023-05-17 09:51:10 --> Config Class Initialized
INFO - 2023-05-17 09:51:10 --> URI Class Initialized
INFO - 2023-05-17 09:51:10 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:51:10 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:51:10 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:51:10 --> Router Class Initialized
INFO - 2023-05-17 09:51:10 --> Utf8 Class Initialized
INFO - 2023-05-17 09:51:10 --> Utf8 Class Initialized
INFO - 2023-05-17 09:51:10 --> Output Class Initialized
INFO - 2023-05-17 09:51:10 --> URI Class Initialized
INFO - 2023-05-17 09:51:10 --> URI Class Initialized
INFO - 2023-05-17 09:51:10 --> Security Class Initialized
INFO - 2023-05-17 09:51:10 --> Router Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:51:10 --> Router Class Initialized
INFO - 2023-05-17 09:51:10 --> Output Class Initialized
INFO - 2023-05-17 09:51:10 --> Input Class Initialized
INFO - 2023-05-17 09:51:10 --> Output Class Initialized
INFO - 2023-05-17 09:51:10 --> Security Class Initialized
INFO - 2023-05-17 09:51:10 --> Language Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:51:10 --> Security Class Initialized
INFO - 2023-05-17 09:51:10 --> Input Class Initialized
INFO - 2023-05-17 09:51:10 --> Loader Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:51:10 --> Language Class Initialized
INFO - 2023-05-17 09:51:10 --> Controller Class Initialized
INFO - 2023-05-17 09:51:10 --> Input Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:51:10 --> Language Class Initialized
INFO - 2023-05-17 09:51:10 --> Loader Class Initialized
INFO - 2023-05-17 09:51:10 --> Database Driver Class Initialized
INFO - 2023-05-17 09:51:10 --> Loader Class Initialized
INFO - 2023-05-17 09:51:10 --> Controller Class Initialized
INFO - 2023-05-17 09:51:10 --> Controller Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:51:10 --> Database Driver Class Initialized
INFO - 2023-05-17 09:51:10 --> Database Driver Class Initialized
INFO - 2023-05-17 09:51:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:51:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:51:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:51:10 --> Final output sent to browser
INFO - 2023-05-17 09:51:10 --> Final output sent to browser
DEBUG - 2023-05-17 09:51:10 --> Total execution time: 0.0233
DEBUG - 2023-05-17 09:51:10 --> Total execution time: 0.0234
INFO - 2023-05-17 09:51:10 --> Config Class Initialized
INFO - 2023-05-17 09:51:10 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:51:10 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:51:10 --> Utf8 Class Initialized
INFO - 2023-05-17 09:51:10 --> URI Class Initialized
INFO - 2023-05-17 09:51:10 --> Router Class Initialized
INFO - 2023-05-17 09:51:10 --> Output Class Initialized
INFO - 2023-05-17 09:51:10 --> Security Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:51:10 --> Input Class Initialized
INFO - 2023-05-17 09:51:10 --> Language Class Initialized
INFO - 2023-05-17 09:51:10 --> Loader Class Initialized
INFO - 2023-05-17 09:51:10 --> Controller Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:51:10 --> Final output sent to browser
INFO - 2023-05-17 09:51:10 --> Database Driver Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Total execution time: 0.1498
INFO - 2023-05-17 09:51:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:51:10 --> Config Class Initialized
INFO - 2023-05-17 09:51:10 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:51:10 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:51:10 --> Utf8 Class Initialized
INFO - 2023-05-17 09:51:10 --> URI Class Initialized
INFO - 2023-05-17 09:51:10 --> Router Class Initialized
INFO - 2023-05-17 09:51:10 --> Output Class Initialized
INFO - 2023-05-17 09:51:10 --> Security Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:51:10 --> Input Class Initialized
INFO - 2023-05-17 09:51:10 --> Language Class Initialized
INFO - 2023-05-17 09:51:10 --> Loader Class Initialized
INFO - 2023-05-17 09:51:10 --> Controller Class Initialized
DEBUG - 2023-05-17 09:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:51:10 --> Database Driver Class Initialized
INFO - 2023-05-17 09:51:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:51:59 --> Config Class Initialized
INFO - 2023-05-17 09:51:59 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:51:59 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:51:59 --> Utf8 Class Initialized
INFO - 2023-05-17 09:51:59 --> URI Class Initialized
INFO - 2023-05-17 09:51:59 --> Router Class Initialized
INFO - 2023-05-17 09:51:59 --> Output Class Initialized
INFO - 2023-05-17 09:51:59 --> Security Class Initialized
DEBUG - 2023-05-17 09:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:51:59 --> Input Class Initialized
INFO - 2023-05-17 09:51:59 --> Language Class Initialized
INFO - 2023-05-17 09:51:59 --> Loader Class Initialized
INFO - 2023-05-17 09:51:59 --> Controller Class Initialized
DEBUG - 2023-05-17 09:51:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:51:59 --> Database Driver Class Initialized
INFO - 2023-05-17 09:51:59 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:51:59 --> Config Class Initialized
INFO - 2023-05-17 09:51:59 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:51:59 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:51:59 --> Utf8 Class Initialized
INFO - 2023-05-17 09:51:59 --> URI Class Initialized
INFO - 2023-05-17 09:51:59 --> Router Class Initialized
INFO - 2023-05-17 09:51:59 --> Output Class Initialized
INFO - 2023-05-17 09:51:59 --> Security Class Initialized
DEBUG - 2023-05-17 09:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:51:59 --> Input Class Initialized
INFO - 2023-05-17 09:51:59 --> Language Class Initialized
INFO - 2023-05-17 09:51:59 --> Loader Class Initialized
INFO - 2023-05-17 09:51:59 --> Controller Class Initialized
DEBUG - 2023-05-17 09:51:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:51:59 --> Database Driver Class Initialized
INFO - 2023-05-17 09:51:59 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:53:24 --> Config Class Initialized
INFO - 2023-05-17 09:53:24 --> Hooks Class Initialized
INFO - 2023-05-17 09:53:24 --> Config Class Initialized
INFO - 2023-05-17 09:53:24 --> Config Class Initialized
INFO - 2023-05-17 09:53:24 --> Hooks Class Initialized
INFO - 2023-05-17 09:53:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:53:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:53:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:53:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:53:24 --> Utf8 Class Initialized
INFO - 2023-05-17 09:53:24 --> Utf8 Class Initialized
INFO - 2023-05-17 09:53:24 --> URI Class Initialized
INFO - 2023-05-17 09:53:24 --> URI Class Initialized
INFO - 2023-05-17 09:53:24 --> Utf8 Class Initialized
INFO - 2023-05-17 09:53:24 --> Router Class Initialized
INFO - 2023-05-17 09:53:24 --> Router Class Initialized
INFO - 2023-05-17 09:53:24 --> URI Class Initialized
INFO - 2023-05-17 09:53:24 --> Output Class Initialized
INFO - 2023-05-17 09:53:24 --> Output Class Initialized
INFO - 2023-05-17 09:53:24 --> Router Class Initialized
INFO - 2023-05-17 09:53:24 --> Security Class Initialized
INFO - 2023-05-17 09:53:24 --> Security Class Initialized
INFO - 2023-05-17 09:53:24 --> Output Class Initialized
DEBUG - 2023-05-17 09:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:53:24 --> Security Class Initialized
INFO - 2023-05-17 09:53:24 --> Input Class Initialized
INFO - 2023-05-17 09:53:24 --> Input Class Initialized
DEBUG - 2023-05-17 09:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:53:24 --> Language Class Initialized
INFO - 2023-05-17 09:53:24 --> Input Class Initialized
INFO - 2023-05-17 09:53:24 --> Language Class Initialized
INFO - 2023-05-17 09:53:24 --> Language Class Initialized
INFO - 2023-05-17 09:53:24 --> Loader Class Initialized
INFO - 2023-05-17 09:53:24 --> Loader Class Initialized
INFO - 2023-05-17 09:53:24 --> Loader Class Initialized
INFO - 2023-05-17 09:53:24 --> Controller Class Initialized
INFO - 2023-05-17 09:53:24 --> Controller Class Initialized
INFO - 2023-05-17 09:53:24 --> Controller Class Initialized
DEBUG - 2023-05-17 09:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:53:24 --> Database Driver Class Initialized
INFO - 2023-05-17 09:53:24 --> Database Driver Class Initialized
INFO - 2023-05-17 09:53:24 --> Database Driver Class Initialized
INFO - 2023-05-17 09:53:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:53:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:53:24 --> Final output sent to browser
INFO - 2023-05-17 09:53:24 --> Model "Cluster_model" initialized
DEBUG - 2023-05-17 09:53:24 --> Total execution time: 0.0164
INFO - 2023-05-17 09:53:24 --> Config Class Initialized
INFO - 2023-05-17 09:53:24 --> Final output sent to browser
INFO - 2023-05-17 09:53:24 --> Final output sent to browser
INFO - 2023-05-17 09:53:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:53:24 --> Total execution time: 0.0177
DEBUG - 2023-05-17 09:53:24 --> Total execution time: 0.0177
DEBUG - 2023-05-17 09:53:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:53:24 --> Utf8 Class Initialized
INFO - 2023-05-17 09:53:24 --> URI Class Initialized
INFO - 2023-05-17 09:53:24 --> Router Class Initialized
INFO - 2023-05-17 09:53:24 --> Output Class Initialized
INFO - 2023-05-17 09:53:24 --> Security Class Initialized
DEBUG - 2023-05-17 09:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:53:24 --> Input Class Initialized
INFO - 2023-05-17 09:53:24 --> Language Class Initialized
INFO - 2023-05-17 09:53:24 --> Loader Class Initialized
INFO - 2023-05-17 09:53:24 --> Controller Class Initialized
DEBUG - 2023-05-17 09:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:53:24 --> Config Class Initialized
INFO - 2023-05-17 09:53:24 --> Config Class Initialized
INFO - 2023-05-17 09:53:24 --> Hooks Class Initialized
INFO - 2023-05-17 09:53:24 --> Hooks Class Initialized
INFO - 2023-05-17 09:53:24 --> Database Driver Class Initialized
DEBUG - 2023-05-17 09:53:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 09:53:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:53:24 --> Utf8 Class Initialized
INFO - 2023-05-17 09:53:24 --> Utf8 Class Initialized
INFO - 2023-05-17 09:53:24 --> URI Class Initialized
INFO - 2023-05-17 09:53:24 --> URI Class Initialized
INFO - 2023-05-17 09:53:24 --> Router Class Initialized
INFO - 2023-05-17 09:53:24 --> Router Class Initialized
INFO - 2023-05-17 09:53:24 --> Output Class Initialized
INFO - 2023-05-17 09:53:24 --> Output Class Initialized
INFO - 2023-05-17 09:53:24 --> Security Class Initialized
INFO - 2023-05-17 09:53:24 --> Security Class Initialized
DEBUG - 2023-05-17 09:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 09:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:53:24 --> Input Class Initialized
INFO - 2023-05-17 09:53:24 --> Input Class Initialized
INFO - 2023-05-17 09:53:24 --> Language Class Initialized
INFO - 2023-05-17 09:53:24 --> Language Class Initialized
INFO - 2023-05-17 09:53:24 --> Loader Class Initialized
INFO - 2023-05-17 09:53:24 --> Loader Class Initialized
INFO - 2023-05-17 09:53:24 --> Controller Class Initialized
INFO - 2023-05-17 09:53:24 --> Controller Class Initialized
DEBUG - 2023-05-17 09:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 09:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:53:24 --> Database Driver Class Initialized
INFO - 2023-05-17 09:53:24 --> Database Driver Class Initialized
INFO - 2023-05-17 09:53:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:53:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:53:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:53:24 --> Final output sent to browser
INFO - 2023-05-17 09:53:24 --> Final output sent to browser
DEBUG - 2023-05-17 09:53:24 --> Total execution time: 0.0171
DEBUG - 2023-05-17 09:53:24 --> Total execution time: 0.0171
INFO - 2023-05-17 09:53:24 --> Config Class Initialized
INFO - 2023-05-17 09:53:24 --> Final output sent to browser
DEBUG - 2023-05-17 09:53:24 --> Total execution time: 0.0405
INFO - 2023-05-17 09:53:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:53:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:53:24 --> Utf8 Class Initialized
INFO - 2023-05-17 09:53:24 --> URI Class Initialized
INFO - 2023-05-17 09:53:24 --> Router Class Initialized
INFO - 2023-05-17 09:53:24 --> Output Class Initialized
INFO - 2023-05-17 09:53:24 --> Security Class Initialized
DEBUG - 2023-05-17 09:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:53:24 --> Input Class Initialized
INFO - 2023-05-17 09:53:24 --> Language Class Initialized
INFO - 2023-05-17 09:53:24 --> Loader Class Initialized
INFO - 2023-05-17 09:53:24 --> Controller Class Initialized
DEBUG - 2023-05-17 09:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:53:24 --> Database Driver Class Initialized
INFO - 2023-05-17 09:53:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:53:24 --> Config Class Initialized
INFO - 2023-05-17 09:53:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:53:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:53:24 --> Utf8 Class Initialized
INFO - 2023-05-17 09:53:24 --> URI Class Initialized
INFO - 2023-05-17 09:53:24 --> Router Class Initialized
INFO - 2023-05-17 09:53:24 --> Output Class Initialized
INFO - 2023-05-17 09:53:24 --> Security Class Initialized
DEBUG - 2023-05-17 09:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:53:24 --> Input Class Initialized
INFO - 2023-05-17 09:53:24 --> Language Class Initialized
INFO - 2023-05-17 09:53:24 --> Loader Class Initialized
INFO - 2023-05-17 09:53:24 --> Controller Class Initialized
DEBUG - 2023-05-17 09:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:53:24 --> Database Driver Class Initialized
INFO - 2023-05-17 09:53:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:56:00 --> Config Class Initialized
INFO - 2023-05-17 09:56:00 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:56:00 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:56:00 --> Utf8 Class Initialized
INFO - 2023-05-17 09:56:00 --> URI Class Initialized
INFO - 2023-05-17 09:56:00 --> Router Class Initialized
INFO - 2023-05-17 09:56:00 --> Output Class Initialized
INFO - 2023-05-17 09:56:00 --> Security Class Initialized
DEBUG - 2023-05-17 09:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:56:00 --> Input Class Initialized
INFO - 2023-05-17 09:56:00 --> Language Class Initialized
INFO - 2023-05-17 09:56:00 --> Loader Class Initialized
INFO - 2023-05-17 09:56:00 --> Controller Class Initialized
DEBUG - 2023-05-17 09:56:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:56:00 --> Database Driver Class Initialized
INFO - 2023-05-17 09:56:00 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:56:01 --> Config Class Initialized
INFO - 2023-05-17 09:56:01 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:56:01 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:56:01 --> Utf8 Class Initialized
INFO - 2023-05-17 09:56:01 --> URI Class Initialized
INFO - 2023-05-17 09:56:01 --> Router Class Initialized
INFO - 2023-05-17 09:56:01 --> Output Class Initialized
INFO - 2023-05-17 09:56:01 --> Security Class Initialized
DEBUG - 2023-05-17 09:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:56:01 --> Input Class Initialized
INFO - 2023-05-17 09:56:01 --> Language Class Initialized
INFO - 2023-05-17 09:56:01 --> Loader Class Initialized
INFO - 2023-05-17 09:56:01 --> Controller Class Initialized
DEBUG - 2023-05-17 09:56:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:56:01 --> Database Driver Class Initialized
INFO - 2023-05-17 09:56:01 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:56:32 --> Config Class Initialized
INFO - 2023-05-17 09:56:32 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:56:32 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:56:32 --> Utf8 Class Initialized
INFO - 2023-05-17 09:56:32 --> URI Class Initialized
INFO - 2023-05-17 09:56:32 --> Router Class Initialized
INFO - 2023-05-17 09:56:32 --> Output Class Initialized
INFO - 2023-05-17 09:56:32 --> Security Class Initialized
DEBUG - 2023-05-17 09:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:56:32 --> Input Class Initialized
INFO - 2023-05-17 09:56:32 --> Language Class Initialized
INFO - 2023-05-17 09:56:32 --> Loader Class Initialized
INFO - 2023-05-17 09:56:32 --> Controller Class Initialized
DEBUG - 2023-05-17 09:56:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:56:32 --> Database Driver Class Initialized
INFO - 2023-05-17 09:56:32 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:56:32 --> Final output sent to browser
DEBUG - 2023-05-17 09:56:32 --> Total execution time: 0.0162
INFO - 2023-05-17 09:56:32 --> Config Class Initialized
INFO - 2023-05-17 09:56:32 --> Hooks Class Initialized
DEBUG - 2023-05-17 09:56:32 --> UTF-8 Support Enabled
INFO - 2023-05-17 09:56:32 --> Utf8 Class Initialized
INFO - 2023-05-17 09:56:32 --> URI Class Initialized
INFO - 2023-05-17 09:56:32 --> Router Class Initialized
INFO - 2023-05-17 09:56:32 --> Output Class Initialized
INFO - 2023-05-17 09:56:32 --> Security Class Initialized
DEBUG - 2023-05-17 09:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 09:56:32 --> Input Class Initialized
INFO - 2023-05-17 09:56:32 --> Language Class Initialized
INFO - 2023-05-17 09:56:32 --> Loader Class Initialized
INFO - 2023-05-17 09:56:32 --> Controller Class Initialized
DEBUG - 2023-05-17 09:56:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 09:56:32 --> Database Driver Class Initialized
INFO - 2023-05-17 09:56:32 --> Model "Cluster_model" initialized
INFO - 2023-05-17 09:56:32 --> Final output sent to browser
DEBUG - 2023-05-17 09:56:32 --> Total execution time: 0.0150
INFO - 2023-05-17 10:00:37 --> Config Class Initialized
INFO - 2023-05-17 10:00:37 --> Config Class Initialized
INFO - 2023-05-17 10:00:37 --> Config Class Initialized
INFO - 2023-05-17 10:00:37 --> Hooks Class Initialized
INFO - 2023-05-17 10:00:37 --> Hooks Class Initialized
INFO - 2023-05-17 10:00:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:00:37 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:00:37 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:00:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:00:37 --> Utf8 Class Initialized
INFO - 2023-05-17 10:00:37 --> Utf8 Class Initialized
INFO - 2023-05-17 10:00:37 --> Utf8 Class Initialized
INFO - 2023-05-17 10:00:37 --> URI Class Initialized
INFO - 2023-05-17 10:00:37 --> URI Class Initialized
INFO - 2023-05-17 10:00:37 --> URI Class Initialized
INFO - 2023-05-17 10:00:37 --> Router Class Initialized
INFO - 2023-05-17 10:00:37 --> Router Class Initialized
INFO - 2023-05-17 10:00:37 --> Router Class Initialized
INFO - 2023-05-17 10:00:37 --> Output Class Initialized
INFO - 2023-05-17 10:00:37 --> Output Class Initialized
INFO - 2023-05-17 10:00:37 --> Output Class Initialized
INFO - 2023-05-17 10:00:37 --> Security Class Initialized
INFO - 2023-05-17 10:00:37 --> Security Class Initialized
INFO - 2023-05-17 10:00:37 --> Security Class Initialized
DEBUG - 2023-05-17 10:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 10:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:00:37 --> Input Class Initialized
DEBUG - 2023-05-17 10:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:00:37 --> Input Class Initialized
INFO - 2023-05-17 10:00:37 --> Input Class Initialized
INFO - 2023-05-17 10:00:37 --> Language Class Initialized
INFO - 2023-05-17 10:00:37 --> Language Class Initialized
INFO - 2023-05-17 10:00:37 --> Language Class Initialized
INFO - 2023-05-17 10:00:37 --> Loader Class Initialized
INFO - 2023-05-17 10:00:37 --> Loader Class Initialized
INFO - 2023-05-17 10:00:37 --> Loader Class Initialized
INFO - 2023-05-17 10:00:37 --> Controller Class Initialized
INFO - 2023-05-17 10:00:37 --> Controller Class Initialized
INFO - 2023-05-17 10:00:37 --> Controller Class Initialized
DEBUG - 2023-05-17 10:00:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:00:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:00:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:00:37 --> Database Driver Class Initialized
INFO - 2023-05-17 10:00:37 --> Database Driver Class Initialized
INFO - 2023-05-17 10:00:37 --> Database Driver Class Initialized
INFO - 2023-05-17 10:00:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:00:37 --> Final output sent to browser
DEBUG - 2023-05-17 10:00:37 --> Total execution time: 0.1018
INFO - 2023-05-17 10:00:37 --> Config Class Initialized
INFO - 2023-05-17 10:00:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:00:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:00:37 --> Utf8 Class Initialized
INFO - 2023-05-17 10:00:37 --> URI Class Initialized
INFO - 2023-05-17 10:00:37 --> Router Class Initialized
INFO - 2023-05-17 10:00:37 --> Output Class Initialized
INFO - 2023-05-17 10:00:37 --> Security Class Initialized
DEBUG - 2023-05-17 10:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:00:37 --> Input Class Initialized
INFO - 2023-05-17 10:00:37 --> Language Class Initialized
INFO - 2023-05-17 10:00:37 --> Loader Class Initialized
INFO - 2023-05-17 10:00:37 --> Controller Class Initialized
DEBUG - 2023-05-17 10:00:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:00:37 --> Database Driver Class Initialized
INFO - 2023-05-17 10:00:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:00:37 --> Final output sent to browser
DEBUG - 2023-05-17 10:00:37 --> Total execution time: 0.0295
INFO - 2023-05-17 10:00:38 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:00:38 --> Final output sent to browser
DEBUG - 2023-05-17 10:00:38 --> Total execution time: 1.1031
INFO - 2023-05-17 10:00:38 --> Config Class Initialized
INFO - 2023-05-17 10:00:38 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:00:38 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:00:38 --> Utf8 Class Initialized
INFO - 2023-05-17 10:00:38 --> URI Class Initialized
INFO - 2023-05-17 10:00:38 --> Router Class Initialized
INFO - 2023-05-17 10:00:38 --> Output Class Initialized
INFO - 2023-05-17 10:00:38 --> Security Class Initialized
DEBUG - 2023-05-17 10:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:00:38 --> Input Class Initialized
INFO - 2023-05-17 10:00:38 --> Language Class Initialized
INFO - 2023-05-17 10:00:38 --> Loader Class Initialized
INFO - 2023-05-17 10:00:38 --> Controller Class Initialized
DEBUG - 2023-05-17 10:00:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:00:38 --> Database Driver Class Initialized
INFO - 2023-05-17 10:00:38 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:00:38 --> Final output sent to browser
DEBUG - 2023-05-17 10:00:38 --> Total execution time: 0.0110
INFO - 2023-05-17 10:00:38 --> Config Class Initialized
INFO - 2023-05-17 10:00:38 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:00:38 --> Final output sent to browser
DEBUG - 2023-05-17 10:00:38 --> Total execution time: 1.1601
INFO - 2023-05-17 10:00:38 --> Config Class Initialized
INFO - 2023-05-17 10:00:38 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:00:38 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:00:38 --> Utf8 Class Initialized
INFO - 2023-05-17 10:00:38 --> URI Class Initialized
INFO - 2023-05-17 10:00:38 --> Router Class Initialized
INFO - 2023-05-17 10:00:38 --> Output Class Initialized
INFO - 2023-05-17 10:00:38 --> Security Class Initialized
DEBUG - 2023-05-17 10:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:00:38 --> Input Class Initialized
INFO - 2023-05-17 10:00:38 --> Language Class Initialized
INFO - 2023-05-17 10:00:38 --> Loader Class Initialized
INFO - 2023-05-17 10:00:38 --> Controller Class Initialized
DEBUG - 2023-05-17 10:00:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:00:38 --> Database Driver Class Initialized
INFO - 2023-05-17 10:00:38 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:00:38 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:00:38 --> Utf8 Class Initialized
INFO - 2023-05-17 10:00:38 --> URI Class Initialized
INFO - 2023-05-17 10:00:38 --> Router Class Initialized
INFO - 2023-05-17 10:00:38 --> Output Class Initialized
INFO - 2023-05-17 10:00:38 --> Security Class Initialized
DEBUG - 2023-05-17 10:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:00:38 --> Input Class Initialized
INFO - 2023-05-17 10:00:38 --> Language Class Initialized
INFO - 2023-05-17 10:00:38 --> Loader Class Initialized
INFO - 2023-05-17 10:00:38 --> Controller Class Initialized
DEBUG - 2023-05-17 10:00:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:00:38 --> Database Driver Class Initialized
INFO - 2023-05-17 10:00:38 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:00:38 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:00:38 --> Final output sent to browser
DEBUG - 2023-05-17 10:00:38 --> Total execution time: 0.0163
INFO - 2023-05-17 10:00:39 --> Config Class Initialized
INFO - 2023-05-17 10:00:39 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:00:39 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:00:39 --> Utf8 Class Initialized
INFO - 2023-05-17 10:00:39 --> URI Class Initialized
INFO - 2023-05-17 10:00:39 --> Router Class Initialized
INFO - 2023-05-17 10:00:39 --> Output Class Initialized
INFO - 2023-05-17 10:00:39 --> Security Class Initialized
DEBUG - 2023-05-17 10:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:00:39 --> Input Class Initialized
INFO - 2023-05-17 10:00:39 --> Language Class Initialized
INFO - 2023-05-17 10:00:39 --> Loader Class Initialized
INFO - 2023-05-17 10:00:39 --> Controller Class Initialized
DEBUG - 2023-05-17 10:00:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:00:39 --> Database Driver Class Initialized
INFO - 2023-05-17 10:00:39 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:28 --> Config Class Initialized
INFO - 2023-05-17 10:01:28 --> Config Class Initialized
INFO - 2023-05-17 10:01:28 --> Config Class Initialized
INFO - 2023-05-17 10:01:28 --> Hooks Class Initialized
INFO - 2023-05-17 10:01:28 --> Hooks Class Initialized
INFO - 2023-05-17 10:01:28 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:01:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:28 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:28 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:28 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:28 --> URI Class Initialized
INFO - 2023-05-17 10:01:28 --> URI Class Initialized
INFO - 2023-05-17 10:01:28 --> URI Class Initialized
INFO - 2023-05-17 10:01:28 --> Router Class Initialized
INFO - 2023-05-17 10:01:28 --> Router Class Initialized
INFO - 2023-05-17 10:01:28 --> Router Class Initialized
INFO - 2023-05-17 10:01:28 --> Output Class Initialized
INFO - 2023-05-17 10:01:28 --> Output Class Initialized
INFO - 2023-05-17 10:01:28 --> Output Class Initialized
INFO - 2023-05-17 10:01:28 --> Security Class Initialized
INFO - 2023-05-17 10:01:28 --> Security Class Initialized
INFO - 2023-05-17 10:01:28 --> Security Class Initialized
DEBUG - 2023-05-17 10:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:28 --> Input Class Initialized
DEBUG - 2023-05-17 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:28 --> Input Class Initialized
INFO - 2023-05-17 10:01:28 --> Input Class Initialized
INFO - 2023-05-17 10:01:28 --> Language Class Initialized
INFO - 2023-05-17 10:01:28 --> Language Class Initialized
INFO - 2023-05-17 10:01:28 --> Language Class Initialized
INFO - 2023-05-17 10:01:28 --> Loader Class Initialized
INFO - 2023-05-17 10:01:28 --> Loader Class Initialized
INFO - 2023-05-17 10:01:28 --> Loader Class Initialized
INFO - 2023-05-17 10:01:28 --> Controller Class Initialized
INFO - 2023-05-17 10:01:28 --> Controller Class Initialized
INFO - 2023-05-17 10:01:28 --> Controller Class Initialized
DEBUG - 2023-05-17 10:01:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:01:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:01:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:28 --> Final output sent to browser
DEBUG - 2023-05-17 10:01:28 --> Total execution time: 0.1027
INFO - 2023-05-17 10:01:28 --> Final output sent to browser
INFO - 2023-05-17 10:01:28 --> Final output sent to browser
DEBUG - 2023-05-17 10:01:28 --> Total execution time: 0.1004
DEBUG - 2023-05-17 10:01:28 --> Total execution time: 0.1024
INFO - 2023-05-17 10:01:28 --> Config Class Initialized
INFO - 2023-05-17 10:01:28 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:01:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:28 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:28 --> URI Class Initialized
INFO - 2023-05-17 10:01:28 --> Router Class Initialized
INFO - 2023-05-17 10:01:28 --> Output Class Initialized
INFO - 2023-05-17 10:01:28 --> Security Class Initialized
INFO - 2023-05-17 10:01:28 --> Config Class Initialized
DEBUG - 2023-05-17 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:28 --> Config Class Initialized
INFO - 2023-05-17 10:01:28 --> Hooks Class Initialized
INFO - 2023-05-17 10:01:28 --> Input Class Initialized
INFO - 2023-05-17 10:01:28 --> Hooks Class Initialized
INFO - 2023-05-17 10:01:28 --> Language Class Initialized
DEBUG - 2023-05-17 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:01:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:28 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:28 --> Loader Class Initialized
INFO - 2023-05-17 10:01:28 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:28 --> URI Class Initialized
INFO - 2023-05-17 10:01:28 --> Controller Class Initialized
INFO - 2023-05-17 10:01:28 --> URI Class Initialized
INFO - 2023-05-17 10:01:28 --> Router Class Initialized
DEBUG - 2023-05-17 10:01:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:28 --> Router Class Initialized
INFO - 2023-05-17 10:01:28 --> Output Class Initialized
INFO - 2023-05-17 10:01:28 --> Output Class Initialized
INFO - 2023-05-17 10:01:28 --> Security Class Initialized
INFO - 2023-05-17 10:01:28 --> Database Driver Class Initialized
DEBUG - 2023-05-17 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:28 --> Security Class Initialized
INFO - 2023-05-17 10:01:28 --> Input Class Initialized
DEBUG - 2023-05-17 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:28 --> Language Class Initialized
INFO - 2023-05-17 10:01:28 --> Input Class Initialized
INFO - 2023-05-17 10:01:28 --> Language Class Initialized
INFO - 2023-05-17 10:01:28 --> Loader Class Initialized
INFO - 2023-05-17 10:01:28 --> Loader Class Initialized
INFO - 2023-05-17 10:01:28 --> Controller Class Initialized
INFO - 2023-05-17 10:01:28 --> Controller Class Initialized
DEBUG - 2023-05-17 10:01:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:01:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:28 --> Final output sent to browser
INFO - 2023-05-17 10:01:28 --> Final output sent to browser
DEBUG - 2023-05-17 10:01:28 --> Total execution time: 0.0172
DEBUG - 2023-05-17 10:01:28 --> Total execution time: 0.0171
INFO - 2023-05-17 10:01:28 --> Final output sent to browser
DEBUG - 2023-05-17 10:01:28 --> Total execution time: 0.0321
INFO - 2023-05-17 10:01:28 --> Config Class Initialized
INFO - 2023-05-17 10:01:28 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:01:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:28 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:28 --> URI Class Initialized
INFO - 2023-05-17 10:01:28 --> Router Class Initialized
INFO - 2023-05-17 10:01:28 --> Output Class Initialized
INFO - 2023-05-17 10:01:28 --> Security Class Initialized
DEBUG - 2023-05-17 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:28 --> Input Class Initialized
INFO - 2023-05-17 10:01:28 --> Language Class Initialized
INFO - 2023-05-17 10:01:28 --> Loader Class Initialized
INFO - 2023-05-17 10:01:28 --> Controller Class Initialized
DEBUG - 2023-05-17 10:01:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:29 --> Config Class Initialized
INFO - 2023-05-17 10:01:29 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:01:29 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:29 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:29 --> URI Class Initialized
INFO - 2023-05-17 10:01:29 --> Router Class Initialized
INFO - 2023-05-17 10:01:29 --> Output Class Initialized
INFO - 2023-05-17 10:01:29 --> Security Class Initialized
DEBUG - 2023-05-17 10:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:29 --> Input Class Initialized
INFO - 2023-05-17 10:01:29 --> Language Class Initialized
INFO - 2023-05-17 10:01:29 --> Loader Class Initialized
INFO - 2023-05-17 10:01:29 --> Controller Class Initialized
DEBUG - 2023-05-17 10:01:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:29 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:29 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:32 --> Config Class Initialized
INFO - 2023-05-17 10:01:32 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:01:32 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:32 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:32 --> URI Class Initialized
INFO - 2023-05-17 10:01:32 --> Router Class Initialized
INFO - 2023-05-17 10:01:32 --> Output Class Initialized
INFO - 2023-05-17 10:01:32 --> Security Class Initialized
DEBUG - 2023-05-17 10:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:32 --> Input Class Initialized
INFO - 2023-05-17 10:01:32 --> Language Class Initialized
INFO - 2023-05-17 10:01:32 --> Loader Class Initialized
INFO - 2023-05-17 10:01:32 --> Controller Class Initialized
DEBUG - 2023-05-17 10:01:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:32 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:32 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:32 --> Final output sent to browser
DEBUG - 2023-05-17 10:01:32 --> Total execution time: 0.0153
INFO - 2023-05-17 10:01:32 --> Config Class Initialized
INFO - 2023-05-17 10:01:32 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:01:32 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:32 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:32 --> URI Class Initialized
INFO - 2023-05-17 10:01:32 --> Router Class Initialized
INFO - 2023-05-17 10:01:32 --> Output Class Initialized
INFO - 2023-05-17 10:01:32 --> Security Class Initialized
DEBUG - 2023-05-17 10:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:32 --> Input Class Initialized
INFO - 2023-05-17 10:01:32 --> Language Class Initialized
INFO - 2023-05-17 10:01:32 --> Loader Class Initialized
INFO - 2023-05-17 10:01:32 --> Controller Class Initialized
DEBUG - 2023-05-17 10:01:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:32 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:32 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:32 --> Final output sent to browser
DEBUG - 2023-05-17 10:01:32 --> Total execution time: 0.0154
INFO - 2023-05-17 10:01:34 --> Config Class Initialized
INFO - 2023-05-17 10:01:34 --> Config Class Initialized
INFO - 2023-05-17 10:01:34 --> Config Class Initialized
INFO - 2023-05-17 10:01:34 --> Hooks Class Initialized
INFO - 2023-05-17 10:01:34 --> Hooks Class Initialized
INFO - 2023-05-17 10:01:34 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:01:34 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:01:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:34 --> Utf8 Class Initialized
DEBUG - 2023-05-17 10:01:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:34 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:34 --> URI Class Initialized
INFO - 2023-05-17 10:01:34 --> URI Class Initialized
INFO - 2023-05-17 10:01:34 --> Router Class Initialized
INFO - 2023-05-17 10:01:34 --> Output Class Initialized
INFO - 2023-05-17 10:01:34 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:34 --> Security Class Initialized
INFO - 2023-05-17 10:01:34 --> Router Class Initialized
INFO - 2023-05-17 10:01:34 --> URI Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:34 --> Output Class Initialized
INFO - 2023-05-17 10:01:34 --> Security Class Initialized
INFO - 2023-05-17 10:01:34 --> Router Class Initialized
INFO - 2023-05-17 10:01:34 --> Input Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:34 --> Output Class Initialized
INFO - 2023-05-17 10:01:34 --> Language Class Initialized
INFO - 2023-05-17 10:01:34 --> Input Class Initialized
INFO - 2023-05-17 10:01:34 --> Security Class Initialized
INFO - 2023-05-17 10:01:34 --> Language Class Initialized
INFO - 2023-05-17 10:01:34 --> Loader Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:34 --> Loader Class Initialized
INFO - 2023-05-17 10:01:34 --> Input Class Initialized
INFO - 2023-05-17 10:01:34 --> Controller Class Initialized
INFO - 2023-05-17 10:01:34 --> Controller Class Initialized
INFO - 2023-05-17 10:01:34 --> Language Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:01:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:34 --> Loader Class Initialized
INFO - 2023-05-17 10:01:34 --> Controller Class Initialized
INFO - 2023-05-17 10:01:34 --> Database Driver Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:34 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:34 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:34 --> Final output sent to browser
INFO - 2023-05-17 10:01:34 --> Model "Cluster_model" initialized
DEBUG - 2023-05-17 10:01:34 --> Total execution time: 0.0163
INFO - 2023-05-17 10:01:34 --> Final output sent to browser
DEBUG - 2023-05-17 10:01:34 --> Total execution time: 0.0164
INFO - 2023-05-17 10:01:34 --> Final output sent to browser
DEBUG - 2023-05-17 10:01:34 --> Total execution time: 0.0183
INFO - 2023-05-17 10:01:34 --> Config Class Initialized
INFO - 2023-05-17 10:01:34 --> Config Class Initialized
INFO - 2023-05-17 10:01:34 --> Hooks Class Initialized
INFO - 2023-05-17 10:01:34 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:01:34 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:01:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:34 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:34 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:34 --> URI Class Initialized
INFO - 2023-05-17 10:01:34 --> Config Class Initialized
INFO - 2023-05-17 10:01:34 --> URI Class Initialized
INFO - 2023-05-17 10:01:34 --> Hooks Class Initialized
INFO - 2023-05-17 10:01:34 --> Router Class Initialized
INFO - 2023-05-17 10:01:34 --> Router Class Initialized
DEBUG - 2023-05-17 10:01:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:34 --> Output Class Initialized
INFO - 2023-05-17 10:01:34 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:34 --> Security Class Initialized
INFO - 2023-05-17 10:01:34 --> Output Class Initialized
INFO - 2023-05-17 10:01:34 --> URI Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:34 --> Security Class Initialized
INFO - 2023-05-17 10:01:34 --> Router Class Initialized
INFO - 2023-05-17 10:01:34 --> Input Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:34 --> Language Class Initialized
INFO - 2023-05-17 10:01:34 --> Output Class Initialized
INFO - 2023-05-17 10:01:34 --> Input Class Initialized
INFO - 2023-05-17 10:01:34 --> Security Class Initialized
INFO - 2023-05-17 10:01:34 --> Loader Class Initialized
INFO - 2023-05-17 10:01:34 --> Language Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:34 --> Controller Class Initialized
INFO - 2023-05-17 10:01:34 --> Loader Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:34 --> Controller Class Initialized
INFO - 2023-05-17 10:01:34 --> Input Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:34 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:34 --> Language Class Initialized
INFO - 2023-05-17 10:01:34 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:34 --> Loader Class Initialized
INFO - 2023-05-17 10:01:34 --> Controller Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:34 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:34 --> Final output sent to browser
DEBUG - 2023-05-17 10:01:34 --> Total execution time: 0.0139
INFO - 2023-05-17 10:01:34 --> Final output sent to browser
DEBUG - 2023-05-17 10:01:34 --> Total execution time: 0.0133
INFO - 2023-05-17 10:01:34 --> Final output sent to browser
INFO - 2023-05-17 10:01:34 --> Config Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Total execution time: 0.0199
INFO - 2023-05-17 10:01:34 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:01:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:34 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:34 --> URI Class Initialized
INFO - 2023-05-17 10:01:34 --> Router Class Initialized
INFO - 2023-05-17 10:01:34 --> Output Class Initialized
INFO - 2023-05-17 10:01:34 --> Security Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:34 --> Input Class Initialized
INFO - 2023-05-17 10:01:34 --> Language Class Initialized
INFO - 2023-05-17 10:01:34 --> Loader Class Initialized
INFO - 2023-05-17 10:01:34 --> Controller Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:34 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:34 --> Config Class Initialized
INFO - 2023-05-17 10:01:34 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:01:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:34 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:34 --> URI Class Initialized
INFO - 2023-05-17 10:01:34 --> Router Class Initialized
INFO - 2023-05-17 10:01:34 --> Output Class Initialized
INFO - 2023-05-17 10:01:34 --> Security Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:34 --> Input Class Initialized
INFO - 2023-05-17 10:01:34 --> Language Class Initialized
INFO - 2023-05-17 10:01:34 --> Loader Class Initialized
INFO - 2023-05-17 10:01:34 --> Controller Class Initialized
DEBUG - 2023-05-17 10:01:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:34 --> Database Driver Class Initialized
INFO - 2023-05-17 10:01:34 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:01:42 --> Config Class Initialized
INFO - 2023-05-17 10:01:42 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:01:42 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:01:42 --> Utf8 Class Initialized
INFO - 2023-05-17 10:01:42 --> URI Class Initialized
INFO - 2023-05-17 10:01:42 --> Router Class Initialized
INFO - 2023-05-17 10:01:42 --> Output Class Initialized
INFO - 2023-05-17 10:01:42 --> Security Class Initialized
DEBUG - 2023-05-17 10:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:01:42 --> Input Class Initialized
INFO - 2023-05-17 10:01:42 --> Language Class Initialized
INFO - 2023-05-17 10:01:42 --> Loader Class Initialized
INFO - 2023-05-17 10:01:42 --> Controller Class Initialized
INFO - 2023-05-17 10:01:42 --> Helper loaded: form_helper
INFO - 2023-05-17 10:01:42 --> Helper loaded: url_helper
DEBUG - 2023-05-17 10:01:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:01:42 --> Final output sent to browser
DEBUG - 2023-05-17 10:01:42 --> Total execution time: 0.0456
INFO - 2023-05-17 10:08:24 --> Config Class Initialized
INFO - 2023-05-17 10:08:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:08:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:08:24 --> Utf8 Class Initialized
INFO - 2023-05-17 10:08:24 --> URI Class Initialized
INFO - 2023-05-17 10:08:24 --> Router Class Initialized
INFO - 2023-05-17 10:08:24 --> Output Class Initialized
INFO - 2023-05-17 10:08:24 --> Security Class Initialized
DEBUG - 2023-05-17 10:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:08:24 --> Input Class Initialized
INFO - 2023-05-17 10:08:24 --> Language Class Initialized
INFO - 2023-05-17 10:08:24 --> Loader Class Initialized
INFO - 2023-05-17 10:08:24 --> Controller Class Initialized
DEBUG - 2023-05-17 10:08:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:08:24 --> Database Driver Class Initialized
INFO - 2023-05-17 10:08:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:08:24 --> Final output sent to browser
DEBUG - 2023-05-17 10:08:24 --> Total execution time: 0.0126
INFO - 2023-05-17 10:08:24 --> Config Class Initialized
INFO - 2023-05-17 10:08:24 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:08:24 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:08:24 --> Utf8 Class Initialized
INFO - 2023-05-17 10:08:24 --> URI Class Initialized
INFO - 2023-05-17 10:08:24 --> Router Class Initialized
INFO - 2023-05-17 10:08:24 --> Output Class Initialized
INFO - 2023-05-17 10:08:24 --> Security Class Initialized
DEBUG - 2023-05-17 10:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:08:24 --> Input Class Initialized
INFO - 2023-05-17 10:08:24 --> Language Class Initialized
INFO - 2023-05-17 10:08:24 --> Loader Class Initialized
INFO - 2023-05-17 10:08:24 --> Controller Class Initialized
DEBUG - 2023-05-17 10:08:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:08:24 --> Database Driver Class Initialized
INFO - 2023-05-17 10:08:24 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:08:24 --> Final output sent to browser
DEBUG - 2023-05-17 10:08:24 --> Total execution time: 0.0169
INFO - 2023-05-17 10:08:26 --> Config Class Initialized
INFO - 2023-05-17 10:08:26 --> Hooks Class Initialized
INFO - 2023-05-17 10:08:26 --> Config Class Initialized
INFO - 2023-05-17 10:08:26 --> Config Class Initialized
INFO - 2023-05-17 10:08:26 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:08:26 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:08:26 --> Hooks Class Initialized
INFO - 2023-05-17 10:08:26 --> Utf8 Class Initialized
DEBUG - 2023-05-17 10:08:26 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:08:26 --> Utf8 Class Initialized
DEBUG - 2023-05-17 10:08:26 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:08:26 --> URI Class Initialized
INFO - 2023-05-17 10:08:26 --> URI Class Initialized
INFO - 2023-05-17 10:08:26 --> Utf8 Class Initialized
INFO - 2023-05-17 10:08:26 --> Router Class Initialized
INFO - 2023-05-17 10:08:26 --> Router Class Initialized
INFO - 2023-05-17 10:08:26 --> URI Class Initialized
INFO - 2023-05-17 10:08:26 --> Output Class Initialized
INFO - 2023-05-17 10:08:26 --> Output Class Initialized
INFO - 2023-05-17 10:08:26 --> Router Class Initialized
INFO - 2023-05-17 10:08:26 --> Security Class Initialized
INFO - 2023-05-17 10:08:26 --> Output Class Initialized
INFO - 2023-05-17 10:08:26 --> Security Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:08:26 --> Security Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:08:26 --> Input Class Initialized
INFO - 2023-05-17 10:08:26 --> Input Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:08:26 --> Language Class Initialized
INFO - 2023-05-17 10:08:26 --> Input Class Initialized
INFO - 2023-05-17 10:08:26 --> Language Class Initialized
INFO - 2023-05-17 10:08:26 --> Language Class Initialized
INFO - 2023-05-17 10:08:26 --> Loader Class Initialized
INFO - 2023-05-17 10:08:26 --> Loader Class Initialized
INFO - 2023-05-17 10:08:26 --> Loader Class Initialized
INFO - 2023-05-17 10:08:26 --> Controller Class Initialized
INFO - 2023-05-17 10:08:26 --> Controller Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:08:26 --> Controller Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:08:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:08:26 --> Database Driver Class Initialized
INFO - 2023-05-17 10:08:26 --> Database Driver Class Initialized
INFO - 2023-05-17 10:08:26 --> Database Driver Class Initialized
INFO - 2023-05-17 10:08:26 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:08:26 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:08:26 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:08:26 --> Final output sent to browser
DEBUG - 2023-05-17 10:08:26 --> Total execution time: 0.0191
INFO - 2023-05-17 10:08:26 --> Config Class Initialized
INFO - 2023-05-17 10:08:26 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:08:26 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:08:26 --> Utf8 Class Initialized
INFO - 2023-05-17 10:08:26 --> URI Class Initialized
INFO - 2023-05-17 10:08:26 --> Router Class Initialized
INFO - 2023-05-17 10:08:26 --> Output Class Initialized
INFO - 2023-05-17 10:08:26 --> Security Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:08:26 --> Input Class Initialized
INFO - 2023-05-17 10:08:26 --> Language Class Initialized
INFO - 2023-05-17 10:08:26 --> Loader Class Initialized
INFO - 2023-05-17 10:08:26 --> Controller Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:08:26 --> Final output sent to browser
INFO - 2023-05-17 10:08:26 --> Database Driver Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Total execution time: 0.0231
INFO - 2023-05-17 10:08:26 --> Final output sent to browser
DEBUG - 2023-05-17 10:08:26 --> Total execution time: 0.0230
INFO - 2023-05-17 10:08:26 --> Config Class Initialized
INFO - 2023-05-17 10:08:26 --> Config Class Initialized
INFO - 2023-05-17 10:08:26 --> Hooks Class Initialized
INFO - 2023-05-17 10:08:26 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:08:26 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:08:26 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:08:26 --> Utf8 Class Initialized
INFO - 2023-05-17 10:08:26 --> Utf8 Class Initialized
INFO - 2023-05-17 10:08:26 --> URI Class Initialized
INFO - 2023-05-17 10:08:26 --> URI Class Initialized
INFO - 2023-05-17 10:08:26 --> Router Class Initialized
INFO - 2023-05-17 10:08:26 --> Router Class Initialized
INFO - 2023-05-17 10:08:26 --> Output Class Initialized
INFO - 2023-05-17 10:08:26 --> Output Class Initialized
INFO - 2023-05-17 10:08:26 --> Security Class Initialized
INFO - 2023-05-17 10:08:26 --> Security Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 10:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:08:26 --> Input Class Initialized
INFO - 2023-05-17 10:08:26 --> Input Class Initialized
INFO - 2023-05-17 10:08:26 --> Language Class Initialized
INFO - 2023-05-17 10:08:26 --> Language Class Initialized
INFO - 2023-05-17 10:08:26 --> Loader Class Initialized
INFO - 2023-05-17 10:08:26 --> Loader Class Initialized
INFO - 2023-05-17 10:08:26 --> Controller Class Initialized
INFO - 2023-05-17 10:08:26 --> Controller Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:08:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:08:26 --> Database Driver Class Initialized
INFO - 2023-05-17 10:08:26 --> Database Driver Class Initialized
INFO - 2023-05-17 10:08:26 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:08:26 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:08:26 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:08:26 --> Final output sent to browser
INFO - 2023-05-17 10:08:26 --> Final output sent to browser
DEBUG - 2023-05-17 10:08:26 --> Total execution time: 0.0148
DEBUG - 2023-05-17 10:08:26 --> Total execution time: 0.0148
INFO - 2023-05-17 10:08:26 --> Final output sent to browser
INFO - 2023-05-17 10:08:26 --> Config Class Initialized
INFO - 2023-05-17 10:08:26 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Total execution time: 0.0222
DEBUG - 2023-05-17 10:08:26 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:08:26 --> Utf8 Class Initialized
INFO - 2023-05-17 10:08:26 --> URI Class Initialized
INFO - 2023-05-17 10:08:26 --> Router Class Initialized
INFO - 2023-05-17 10:08:26 --> Output Class Initialized
INFO - 2023-05-17 10:08:26 --> Security Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:08:26 --> Input Class Initialized
INFO - 2023-05-17 10:08:26 --> Language Class Initialized
INFO - 2023-05-17 10:08:26 --> Loader Class Initialized
INFO - 2023-05-17 10:08:26 --> Controller Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:08:26 --> Database Driver Class Initialized
INFO - 2023-05-17 10:08:26 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:08:26 --> Config Class Initialized
INFO - 2023-05-17 10:08:26 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:08:26 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:08:26 --> Utf8 Class Initialized
INFO - 2023-05-17 10:08:26 --> URI Class Initialized
INFO - 2023-05-17 10:08:26 --> Router Class Initialized
INFO - 2023-05-17 10:08:26 --> Output Class Initialized
INFO - 2023-05-17 10:08:26 --> Security Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:08:26 --> Input Class Initialized
INFO - 2023-05-17 10:08:26 --> Language Class Initialized
INFO - 2023-05-17 10:08:26 --> Loader Class Initialized
INFO - 2023-05-17 10:08:26 --> Controller Class Initialized
DEBUG - 2023-05-17 10:08:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:08:26 --> Database Driver Class Initialized
INFO - 2023-05-17 10:08:26 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:11:31 --> Config Class Initialized
INFO - 2023-05-17 10:11:31 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:11:31 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:11:31 --> Utf8 Class Initialized
INFO - 2023-05-17 10:11:31 --> URI Class Initialized
INFO - 2023-05-17 10:11:31 --> Router Class Initialized
INFO - 2023-05-17 10:11:31 --> Output Class Initialized
INFO - 2023-05-17 10:11:31 --> Security Class Initialized
DEBUG - 2023-05-17 10:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:11:31 --> Input Class Initialized
INFO - 2023-05-17 10:11:31 --> Language Class Initialized
INFO - 2023-05-17 10:11:31 --> Loader Class Initialized
INFO - 2023-05-17 10:11:31 --> Controller Class Initialized
DEBUG - 2023-05-17 10:11:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:11:31 --> Database Driver Class Initialized
INFO - 2023-05-17 10:11:31 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:11:31 --> Final output sent to browser
DEBUG - 2023-05-17 10:11:31 --> Total execution time: 0.0247
INFO - 2023-05-17 10:11:31 --> Config Class Initialized
INFO - 2023-05-17 10:11:31 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:11:31 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:11:31 --> Utf8 Class Initialized
INFO - 2023-05-17 10:11:31 --> URI Class Initialized
INFO - 2023-05-17 10:11:31 --> Router Class Initialized
INFO - 2023-05-17 10:11:31 --> Output Class Initialized
INFO - 2023-05-17 10:11:31 --> Security Class Initialized
DEBUG - 2023-05-17 10:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:11:31 --> Input Class Initialized
INFO - 2023-05-17 10:11:31 --> Language Class Initialized
INFO - 2023-05-17 10:11:31 --> Loader Class Initialized
INFO - 2023-05-17 10:11:31 --> Controller Class Initialized
DEBUG - 2023-05-17 10:11:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:11:31 --> Database Driver Class Initialized
INFO - 2023-05-17 10:11:31 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:11:31 --> Final output sent to browser
DEBUG - 2023-05-17 10:11:31 --> Total execution time: 0.0207
INFO - 2023-05-17 10:11:36 --> Config Class Initialized
INFO - 2023-05-17 10:11:36 --> Config Class Initialized
INFO - 2023-05-17 10:11:36 --> Hooks Class Initialized
INFO - 2023-05-17 10:11:36 --> Hooks Class Initialized
INFO - 2023-05-17 10:11:36 --> Config Class Initialized
DEBUG - 2023-05-17 10:11:36 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:11:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:11:36 --> Hooks Class Initialized
INFO - 2023-05-17 10:11:36 --> Utf8 Class Initialized
INFO - 2023-05-17 10:11:36 --> Utf8 Class Initialized
INFO - 2023-05-17 10:11:36 --> URI Class Initialized
DEBUG - 2023-05-17 10:11:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:11:36 --> URI Class Initialized
INFO - 2023-05-17 10:11:36 --> Utf8 Class Initialized
INFO - 2023-05-17 10:11:36 --> Router Class Initialized
INFO - 2023-05-17 10:11:36 --> Router Class Initialized
INFO - 2023-05-17 10:11:36 --> URI Class Initialized
INFO - 2023-05-17 10:11:36 --> Output Class Initialized
INFO - 2023-05-17 10:11:36 --> Output Class Initialized
INFO - 2023-05-17 10:11:36 --> Security Class Initialized
INFO - 2023-05-17 10:11:36 --> Router Class Initialized
INFO - 2023-05-17 10:11:36 --> Security Class Initialized
DEBUG - 2023-05-17 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:11:36 --> Output Class Initialized
DEBUG - 2023-05-17 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:11:36 --> Input Class Initialized
INFO - 2023-05-17 10:11:36 --> Input Class Initialized
INFO - 2023-05-17 10:11:36 --> Security Class Initialized
INFO - 2023-05-17 10:11:36 --> Language Class Initialized
INFO - 2023-05-17 10:11:36 --> Language Class Initialized
DEBUG - 2023-05-17 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:11:36 --> Input Class Initialized
INFO - 2023-05-17 10:11:36 --> Loader Class Initialized
INFO - 2023-05-17 10:11:36 --> Loader Class Initialized
INFO - 2023-05-17 10:11:36 --> Language Class Initialized
INFO - 2023-05-17 10:11:36 --> Controller Class Initialized
INFO - 2023-05-17 10:11:36 --> Controller Class Initialized
DEBUG - 2023-05-17 10:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:11:36 --> Loader Class Initialized
DEBUG - 2023-05-17 10:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:11:36 --> Controller Class Initialized
INFO - 2023-05-17 10:11:36 --> Database Driver Class Initialized
DEBUG - 2023-05-17 10:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:11:36 --> Database Driver Class Initialized
INFO - 2023-05-17 10:11:36 --> Database Driver Class Initialized
INFO - 2023-05-17 10:11:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:11:36 --> Final output sent to browser
DEBUG - 2023-05-17 10:11:36 --> Total execution time: 0.0139
INFO - 2023-05-17 10:11:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:11:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:11:36 --> Config Class Initialized
INFO - 2023-05-17 10:11:36 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:11:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:11:36 --> Utf8 Class Initialized
INFO - 2023-05-17 10:11:36 --> URI Class Initialized
INFO - 2023-05-17 10:11:36 --> Final output sent to browser
INFO - 2023-05-17 10:11:36 --> Final output sent to browser
DEBUG - 2023-05-17 10:11:36 --> Total execution time: 0.0176
INFO - 2023-05-17 10:11:36 --> Router Class Initialized
DEBUG - 2023-05-17 10:11:36 --> Total execution time: 0.0175
INFO - 2023-05-17 10:11:36 --> Output Class Initialized
INFO - 2023-05-17 10:11:36 --> Security Class Initialized
DEBUG - 2023-05-17 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:11:36 --> Input Class Initialized
INFO - 2023-05-17 10:11:36 --> Language Class Initialized
INFO - 2023-05-17 10:11:36 --> Loader Class Initialized
INFO - 2023-05-17 10:11:36 --> Controller Class Initialized
DEBUG - 2023-05-17 10:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:11:36 --> Database Driver Class Initialized
INFO - 2023-05-17 10:11:36 --> Config Class Initialized
INFO - 2023-05-17 10:11:36 --> Config Class Initialized
INFO - 2023-05-17 10:11:36 --> Hooks Class Initialized
INFO - 2023-05-17 10:11:36 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:11:36 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:11:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:11:36 --> Utf8 Class Initialized
INFO - 2023-05-17 10:11:36 --> Utf8 Class Initialized
INFO - 2023-05-17 10:11:36 --> URI Class Initialized
INFO - 2023-05-17 10:11:36 --> URI Class Initialized
INFO - 2023-05-17 10:11:36 --> Router Class Initialized
INFO - 2023-05-17 10:11:36 --> Router Class Initialized
INFO - 2023-05-17 10:11:36 --> Output Class Initialized
INFO - 2023-05-17 10:11:36 --> Output Class Initialized
INFO - 2023-05-17 10:11:36 --> Security Class Initialized
INFO - 2023-05-17 10:11:36 --> Security Class Initialized
DEBUG - 2023-05-17 10:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:11:36 --> Input Class Initialized
INFO - 2023-05-17 10:11:36 --> Input Class Initialized
INFO - 2023-05-17 10:11:36 --> Language Class Initialized
INFO - 2023-05-17 10:11:36 --> Language Class Initialized
INFO - 2023-05-17 10:11:36 --> Loader Class Initialized
INFO - 2023-05-17 10:11:36 --> Loader Class Initialized
INFO - 2023-05-17 10:11:36 --> Controller Class Initialized
INFO - 2023-05-17 10:11:36 --> Controller Class Initialized
DEBUG - 2023-05-17 10:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:11:36 --> Database Driver Class Initialized
INFO - 2023-05-17 10:11:36 --> Database Driver Class Initialized
INFO - 2023-05-17 10:11:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:11:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:11:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:11:36 --> Final output sent to browser
DEBUG - 2023-05-17 10:11:36 --> Total execution time: 0.0260
INFO - 2023-05-17 10:11:36 --> Final output sent to browser
INFO - 2023-05-17 10:11:36 --> Final output sent to browser
DEBUG - 2023-05-17 10:11:36 --> Total execution time: 0.0221
DEBUG - 2023-05-17 10:11:36 --> Total execution time: 0.0221
INFO - 2023-05-17 10:11:36 --> Config Class Initialized
INFO - 2023-05-17 10:11:36 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:11:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:11:36 --> Utf8 Class Initialized
INFO - 2023-05-17 10:11:36 --> URI Class Initialized
INFO - 2023-05-17 10:11:36 --> Router Class Initialized
INFO - 2023-05-17 10:11:36 --> Output Class Initialized
INFO - 2023-05-17 10:11:36 --> Security Class Initialized
DEBUG - 2023-05-17 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:11:36 --> Input Class Initialized
INFO - 2023-05-17 10:11:36 --> Language Class Initialized
INFO - 2023-05-17 10:11:36 --> Loader Class Initialized
INFO - 2023-05-17 10:11:36 --> Controller Class Initialized
DEBUG - 2023-05-17 10:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:11:36 --> Database Driver Class Initialized
INFO - 2023-05-17 10:11:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:11:37 --> Config Class Initialized
INFO - 2023-05-17 10:11:37 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:11:37 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:11:37 --> Utf8 Class Initialized
INFO - 2023-05-17 10:11:37 --> URI Class Initialized
INFO - 2023-05-17 10:11:37 --> Router Class Initialized
INFO - 2023-05-17 10:11:37 --> Output Class Initialized
INFO - 2023-05-17 10:11:37 --> Security Class Initialized
DEBUG - 2023-05-17 10:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:11:37 --> Input Class Initialized
INFO - 2023-05-17 10:11:37 --> Language Class Initialized
INFO - 2023-05-17 10:11:37 --> Loader Class Initialized
INFO - 2023-05-17 10:11:37 --> Controller Class Initialized
DEBUG - 2023-05-17 10:11:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:11:37 --> Database Driver Class Initialized
INFO - 2023-05-17 10:11:37 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:11:54 --> Config Class Initialized
INFO - 2023-05-17 10:11:54 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:11:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:11:54 --> Utf8 Class Initialized
INFO - 2023-05-17 10:11:54 --> URI Class Initialized
INFO - 2023-05-17 10:11:54 --> Router Class Initialized
INFO - 2023-05-17 10:11:54 --> Output Class Initialized
INFO - 2023-05-17 10:11:54 --> Security Class Initialized
DEBUG - 2023-05-17 10:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:11:54 --> Input Class Initialized
INFO - 2023-05-17 10:11:54 --> Language Class Initialized
INFO - 2023-05-17 10:11:54 --> Loader Class Initialized
INFO - 2023-05-17 10:11:54 --> Controller Class Initialized
DEBUG - 2023-05-17 10:11:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:11:54 --> Database Driver Class Initialized
INFO - 2023-05-17 10:11:54 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:11:54 --> Config Class Initialized
INFO - 2023-05-17 10:11:54 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:11:54 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:11:54 --> Utf8 Class Initialized
INFO - 2023-05-17 10:11:54 --> URI Class Initialized
INFO - 2023-05-17 10:11:54 --> Router Class Initialized
INFO - 2023-05-17 10:11:54 --> Output Class Initialized
INFO - 2023-05-17 10:11:54 --> Security Class Initialized
DEBUG - 2023-05-17 10:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:11:54 --> Input Class Initialized
INFO - 2023-05-17 10:11:54 --> Language Class Initialized
INFO - 2023-05-17 10:11:54 --> Loader Class Initialized
INFO - 2023-05-17 10:11:54 --> Controller Class Initialized
DEBUG - 2023-05-17 10:11:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:11:54 --> Database Driver Class Initialized
INFO - 2023-05-17 10:11:54 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:12:26 --> Config Class Initialized
INFO - 2023-05-17 10:12:26 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:12:26 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:12:26 --> Utf8 Class Initialized
INFO - 2023-05-17 10:12:26 --> URI Class Initialized
INFO - 2023-05-17 10:12:26 --> Router Class Initialized
INFO - 2023-05-17 10:12:26 --> Output Class Initialized
INFO - 2023-05-17 10:12:26 --> Security Class Initialized
DEBUG - 2023-05-17 10:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:12:26 --> Input Class Initialized
INFO - 2023-05-17 10:12:26 --> Language Class Initialized
INFO - 2023-05-17 10:12:26 --> Loader Class Initialized
INFO - 2023-05-17 10:12:26 --> Controller Class Initialized
DEBUG - 2023-05-17 10:12:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:12:26 --> Database Driver Class Initialized
INFO - 2023-05-17 10:12:26 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:12:26 --> Final output sent to browser
DEBUG - 2023-05-17 10:12:26 --> Total execution time: 0.0127
INFO - 2023-05-17 10:12:26 --> Config Class Initialized
INFO - 2023-05-17 10:12:26 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:12:26 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:12:26 --> Utf8 Class Initialized
INFO - 2023-05-17 10:12:26 --> URI Class Initialized
INFO - 2023-05-17 10:12:26 --> Router Class Initialized
INFO - 2023-05-17 10:12:26 --> Output Class Initialized
INFO - 2023-05-17 10:12:26 --> Security Class Initialized
DEBUG - 2023-05-17 10:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:12:26 --> Input Class Initialized
INFO - 2023-05-17 10:12:26 --> Language Class Initialized
INFO - 2023-05-17 10:12:26 --> Loader Class Initialized
INFO - 2023-05-17 10:12:26 --> Controller Class Initialized
DEBUG - 2023-05-17 10:12:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:12:26 --> Database Driver Class Initialized
INFO - 2023-05-17 10:12:26 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:12:26 --> Final output sent to browser
DEBUG - 2023-05-17 10:12:26 --> Total execution time: 0.0161
INFO - 2023-05-17 10:14:36 --> Config Class Initialized
INFO - 2023-05-17 10:14:36 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:14:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:14:36 --> Utf8 Class Initialized
INFO - 2023-05-17 10:14:36 --> URI Class Initialized
INFO - 2023-05-17 10:14:36 --> Router Class Initialized
INFO - 2023-05-17 10:14:36 --> Output Class Initialized
INFO - 2023-05-17 10:14:36 --> Security Class Initialized
DEBUG - 2023-05-17 10:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:14:36 --> Input Class Initialized
INFO - 2023-05-17 10:14:36 --> Language Class Initialized
INFO - 2023-05-17 10:14:36 --> Loader Class Initialized
INFO - 2023-05-17 10:14:36 --> Controller Class Initialized
DEBUG - 2023-05-17 10:14:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:14:36 --> Database Driver Class Initialized
INFO - 2023-05-17 10:14:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:14:36 --> Final output sent to browser
DEBUG - 2023-05-17 10:14:36 --> Total execution time: 0.0206
INFO - 2023-05-17 10:14:36 --> Config Class Initialized
INFO - 2023-05-17 10:14:36 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:14:36 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:14:36 --> Utf8 Class Initialized
INFO - 2023-05-17 10:14:36 --> URI Class Initialized
INFO - 2023-05-17 10:14:36 --> Router Class Initialized
INFO - 2023-05-17 10:14:36 --> Output Class Initialized
INFO - 2023-05-17 10:14:36 --> Security Class Initialized
DEBUG - 2023-05-17 10:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:14:36 --> Input Class Initialized
INFO - 2023-05-17 10:14:36 --> Language Class Initialized
INFO - 2023-05-17 10:14:36 --> Loader Class Initialized
INFO - 2023-05-17 10:14:36 --> Controller Class Initialized
DEBUG - 2023-05-17 10:14:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:14:36 --> Database Driver Class Initialized
INFO - 2023-05-17 10:14:36 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:14:36 --> Final output sent to browser
DEBUG - 2023-05-17 10:14:36 --> Total execution time: 0.0172
INFO - 2023-05-17 10:30:25 --> Config Class Initialized
INFO - 2023-05-17 10:30:25 --> Config Class Initialized
INFO - 2023-05-17 10:30:25 --> Config Class Initialized
INFO - 2023-05-17 10:30:25 --> Hooks Class Initialized
INFO - 2023-05-17 10:30:25 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:30:25 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:30:25 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:30:25 --> Hooks Class Initialized
INFO - 2023-05-17 10:30:25 --> Utf8 Class Initialized
INFO - 2023-05-17 10:30:25 --> Utf8 Class Initialized
INFO - 2023-05-17 10:30:25 --> URI Class Initialized
DEBUG - 2023-05-17 10:30:25 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:30:25 --> URI Class Initialized
INFO - 2023-05-17 10:30:25 --> Utf8 Class Initialized
INFO - 2023-05-17 10:30:25 --> Router Class Initialized
INFO - 2023-05-17 10:30:25 --> URI Class Initialized
INFO - 2023-05-17 10:30:25 --> Router Class Initialized
INFO - 2023-05-17 10:30:25 --> Output Class Initialized
INFO - 2023-05-17 10:30:25 --> Router Class Initialized
INFO - 2023-05-17 10:30:25 --> Security Class Initialized
INFO - 2023-05-17 10:30:25 --> Output Class Initialized
INFO - 2023-05-17 10:30:25 --> Output Class Initialized
DEBUG - 2023-05-17 10:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:30:25 --> Security Class Initialized
INFO - 2023-05-17 10:30:25 --> Input Class Initialized
INFO - 2023-05-17 10:30:25 --> Security Class Initialized
DEBUG - 2023-05-17 10:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:30:25 --> Language Class Initialized
INFO - 2023-05-17 10:30:25 --> Input Class Initialized
DEBUG - 2023-05-17 10:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:30:25 --> Language Class Initialized
INFO - 2023-05-17 10:30:25 --> Input Class Initialized
INFO - 2023-05-17 10:30:25 --> Loader Class Initialized
INFO - 2023-05-17 10:30:25 --> Language Class Initialized
INFO - 2023-05-17 10:30:25 --> Loader Class Initialized
INFO - 2023-05-17 10:30:25 --> Controller Class Initialized
INFO - 2023-05-17 10:30:25 --> Controller Class Initialized
DEBUG - 2023-05-17 10:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:30:25 --> Loader Class Initialized
INFO - 2023-05-17 10:30:25 --> Database Driver Class Initialized
INFO - 2023-05-17 10:30:25 --> Database Driver Class Initialized
INFO - 2023-05-17 10:30:25 --> Controller Class Initialized
DEBUG - 2023-05-17 10:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:30:25 --> Database Driver Class Initialized
INFO - 2023-05-17 10:30:25 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:30:25 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:30:25 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:30:25 --> Final output sent to browser
DEBUG - 2023-05-17 10:30:25 --> Total execution time: 0.0220
INFO - 2023-05-17 10:30:25 --> Final output sent to browser
INFO - 2023-05-17 10:30:25 --> Final output sent to browser
DEBUG - 2023-05-17 10:30:25 --> Total execution time: 0.0235
DEBUG - 2023-05-17 10:30:25 --> Total execution time: 0.0246
INFO - 2023-05-17 10:30:25 --> Config Class Initialized
INFO - 2023-05-17 10:30:25 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:30:25 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:30:25 --> Utf8 Class Initialized
INFO - 2023-05-17 10:30:25 --> Config Class Initialized
INFO - 2023-05-17 10:30:25 --> URI Class Initialized
INFO - 2023-05-17 10:30:25 --> Hooks Class Initialized
INFO - 2023-05-17 10:30:25 --> Config Class Initialized
INFO - 2023-05-17 10:30:25 --> Router Class Initialized
DEBUG - 2023-05-17 10:30:25 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:30:25 --> Hooks Class Initialized
INFO - 2023-05-17 10:30:25 --> Output Class Initialized
INFO - 2023-05-17 10:30:25 --> Utf8 Class Initialized
INFO - 2023-05-17 10:30:25 --> Security Class Initialized
DEBUG - 2023-05-17 10:30:25 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:30:25 --> URI Class Initialized
INFO - 2023-05-17 10:30:25 --> Utf8 Class Initialized
INFO - 2023-05-17 10:30:25 --> URI Class Initialized
INFO - 2023-05-17 10:30:25 --> Router Class Initialized
DEBUG - 2023-05-17 10:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:30:25 --> Output Class Initialized
INFO - 2023-05-17 10:30:25 --> Router Class Initialized
INFO - 2023-05-17 10:30:25 --> Input Class Initialized
INFO - 2023-05-17 10:30:25 --> Security Class Initialized
INFO - 2023-05-17 10:30:25 --> Output Class Initialized
INFO - 2023-05-17 10:30:25 --> Language Class Initialized
INFO - 2023-05-17 10:30:25 --> Security Class Initialized
DEBUG - 2023-05-17 10:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 10:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:30:25 --> Input Class Initialized
INFO - 2023-05-17 10:30:25 --> Loader Class Initialized
INFO - 2023-05-17 10:30:25 --> Input Class Initialized
INFO - 2023-05-17 10:30:25 --> Language Class Initialized
INFO - 2023-05-17 10:30:25 --> Controller Class Initialized
INFO - 2023-05-17 10:30:25 --> Language Class Initialized
DEBUG - 2023-05-17 10:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:30:25 --> Loader Class Initialized
INFO - 2023-05-17 10:30:25 --> Database Driver Class Initialized
INFO - 2023-05-17 10:30:25 --> Controller Class Initialized
DEBUG - 2023-05-17 10:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:30:25 --> Loader Class Initialized
INFO - 2023-05-17 10:30:25 --> Controller Class Initialized
DEBUG - 2023-05-17 10:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:30:25 --> Database Driver Class Initialized
INFO - 2023-05-17 10:30:25 --> Database Driver Class Initialized
INFO - 2023-05-17 10:30:25 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:30:25 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:30:25 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:30:25 --> Final output sent to browser
DEBUG - 2023-05-17 10:30:25 --> Total execution time: 0.0162
INFO - 2023-05-17 10:30:25 --> Final output sent to browser
DEBUG - 2023-05-17 10:30:25 --> Total execution time: 0.0169
INFO - 2023-05-17 10:30:25 --> Config Class Initialized
INFO - 2023-05-17 10:30:25 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:30:25 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:30:25 --> Utf8 Class Initialized
INFO - 2023-05-17 10:30:25 --> URI Class Initialized
INFO - 2023-05-17 10:30:25 --> Router Class Initialized
INFO - 2023-05-17 10:30:25 --> Output Class Initialized
INFO - 2023-05-17 10:30:25 --> Security Class Initialized
DEBUG - 2023-05-17 10:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:30:25 --> Input Class Initialized
INFO - 2023-05-17 10:30:25 --> Language Class Initialized
INFO - 2023-05-17 10:30:25 --> Loader Class Initialized
INFO - 2023-05-17 10:30:25 --> Controller Class Initialized
DEBUG - 2023-05-17 10:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:30:25 --> Database Driver Class Initialized
INFO - 2023-05-17 10:30:25 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:30:26 --> Config Class Initialized
INFO - 2023-05-17 10:30:26 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:30:26 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:30:26 --> Utf8 Class Initialized
INFO - 2023-05-17 10:30:26 --> URI Class Initialized
INFO - 2023-05-17 10:30:26 --> Router Class Initialized
INFO - 2023-05-17 10:30:26 --> Output Class Initialized
INFO - 2023-05-17 10:30:26 --> Security Class Initialized
DEBUG - 2023-05-17 10:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:30:26 --> Input Class Initialized
INFO - 2023-05-17 10:30:26 --> Language Class Initialized
INFO - 2023-05-17 10:30:26 --> Loader Class Initialized
INFO - 2023-05-17 10:30:26 --> Controller Class Initialized
DEBUG - 2023-05-17 10:30:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:30:26 --> Database Driver Class Initialized
INFO - 2023-05-17 10:30:26 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:30:29 --> Final output sent to browser
DEBUG - 2023-05-17 10:30:29 --> Total execution time: 3.3497
INFO - 2023-05-17 10:34:28 --> Config Class Initialized
INFO - 2023-05-17 10:34:28 --> Config Class Initialized
INFO - 2023-05-17 10:34:28 --> Hooks Class Initialized
INFO - 2023-05-17 10:34:28 --> Hooks Class Initialized
INFO - 2023-05-17 10:34:28 --> Config Class Initialized
DEBUG - 2023-05-17 10:34:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:34:28 --> Hooks Class Initialized
INFO - 2023-05-17 10:34:28 --> Utf8 Class Initialized
DEBUG - 2023-05-17 10:34:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:34:28 --> Utf8 Class Initialized
DEBUG - 2023-05-17 10:34:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:34:28 --> URI Class Initialized
INFO - 2023-05-17 10:34:28 --> Utf8 Class Initialized
INFO - 2023-05-17 10:34:28 --> URI Class Initialized
INFO - 2023-05-17 10:34:28 --> URI Class Initialized
INFO - 2023-05-17 10:34:28 --> Router Class Initialized
INFO - 2023-05-17 10:34:28 --> Router Class Initialized
INFO - 2023-05-17 10:34:28 --> Output Class Initialized
INFO - 2023-05-17 10:34:28 --> Router Class Initialized
INFO - 2023-05-17 10:34:28 --> Output Class Initialized
INFO - 2023-05-17 10:34:28 --> Security Class Initialized
INFO - 2023-05-17 10:34:28 --> Output Class Initialized
INFO - 2023-05-17 10:34:28 --> Security Class Initialized
DEBUG - 2023-05-17 10:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:34:28 --> Security Class Initialized
DEBUG - 2023-05-17 10:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 10:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:34:28 --> Input Class Initialized
INFO - 2023-05-17 10:34:28 --> Input Class Initialized
INFO - 2023-05-17 10:34:28 --> Language Class Initialized
INFO - 2023-05-17 10:34:28 --> Language Class Initialized
INFO - 2023-05-17 10:34:28 --> Input Class Initialized
INFO - 2023-05-17 10:34:28 --> Language Class Initialized
INFO - 2023-05-17 10:34:28 --> Loader Class Initialized
INFO - 2023-05-17 10:34:28 --> Loader Class Initialized
INFO - 2023-05-17 10:34:28 --> Loader Class Initialized
INFO - 2023-05-17 10:34:28 --> Controller Class Initialized
INFO - 2023-05-17 10:34:28 --> Controller Class Initialized
INFO - 2023-05-17 10:34:28 --> Controller Class Initialized
DEBUG - 2023-05-17 10:34:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:34:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:34:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:34:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:34:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:34:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:34:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:34:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:34:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:34:28 --> Final output sent to browser
DEBUG - 2023-05-17 10:34:28 --> Total execution time: 0.0568
INFO - 2023-05-17 10:34:28 --> Final output sent to browser
DEBUG - 2023-05-17 10:34:28 --> Total execution time: 0.0591
INFO - 2023-05-17 10:34:28 --> Final output sent to browser
DEBUG - 2023-05-17 10:34:28 --> Total execution time: 0.0595
INFO - 2023-05-17 10:34:28 --> Config Class Initialized
INFO - 2023-05-17 10:34:28 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:34:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:34:28 --> Utf8 Class Initialized
INFO - 2023-05-17 10:34:28 --> URI Class Initialized
INFO - 2023-05-17 10:34:28 --> Config Class Initialized
INFO - 2023-05-17 10:34:28 --> Hooks Class Initialized
INFO - 2023-05-17 10:34:28 --> Router Class Initialized
DEBUG - 2023-05-17 10:34:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:34:28 --> Output Class Initialized
INFO - 2023-05-17 10:34:28 --> Security Class Initialized
INFO - 2023-05-17 10:34:28 --> Utf8 Class Initialized
DEBUG - 2023-05-17 10:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:34:28 --> Input Class Initialized
INFO - 2023-05-17 10:34:28 --> URI Class Initialized
INFO - 2023-05-17 10:34:28 --> Language Class Initialized
INFO - 2023-05-17 10:34:28 --> Router Class Initialized
INFO - 2023-05-17 10:34:28 --> Config Class Initialized
INFO - 2023-05-17 10:34:28 --> Output Class Initialized
INFO - 2023-05-17 10:34:28 --> Loader Class Initialized
INFO - 2023-05-17 10:34:28 --> Security Class Initialized
DEBUG - 2023-05-17 10:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:34:28 --> Input Class Initialized
INFO - 2023-05-17 10:34:28 --> Language Class Initialized
INFO - 2023-05-17 10:34:28 --> Hooks Class Initialized
INFO - 2023-05-17 10:34:28 --> Loader Class Initialized
DEBUG - 2023-05-17 10:34:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:34:28 --> Controller Class Initialized
INFO - 2023-05-17 10:34:28 --> Utf8 Class Initialized
INFO - 2023-05-17 10:34:28 --> Controller Class Initialized
DEBUG - 2023-05-17 10:34:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:34:28 --> URI Class Initialized
DEBUG - 2023-05-17 10:34:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:34:28 --> Router Class Initialized
INFO - 2023-05-17 10:34:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:34:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:34:28 --> Output Class Initialized
INFO - 2023-05-17 10:34:28 --> Security Class Initialized
DEBUG - 2023-05-17 10:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:34:28 --> Input Class Initialized
INFO - 2023-05-17 10:34:28 --> Language Class Initialized
INFO - 2023-05-17 10:34:28 --> Loader Class Initialized
INFO - 2023-05-17 10:34:28 --> Controller Class Initialized
DEBUG - 2023-05-17 10:34:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:34:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:34:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:34:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:34:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:34:28 --> Final output sent to browser
DEBUG - 2023-05-17 10:34:28 --> Total execution time: 0.0176
INFO - 2023-05-17 10:34:28 --> Final output sent to browser
DEBUG - 2023-05-17 10:34:28 --> Total execution time: 0.0172
INFO - 2023-05-17 10:34:28 --> Config Class Initialized
INFO - 2023-05-17 10:34:28 --> Final output sent to browser
DEBUG - 2023-05-17 10:34:28 --> Total execution time: 0.0957
INFO - 2023-05-17 10:34:28 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:34:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:34:28 --> Utf8 Class Initialized
INFO - 2023-05-17 10:34:28 --> URI Class Initialized
INFO - 2023-05-17 10:34:28 --> Router Class Initialized
INFO - 2023-05-17 10:34:28 --> Output Class Initialized
INFO - 2023-05-17 10:34:28 --> Security Class Initialized
DEBUG - 2023-05-17 10:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:34:28 --> Input Class Initialized
INFO - 2023-05-17 10:34:28 --> Language Class Initialized
INFO - 2023-05-17 10:34:28 --> Loader Class Initialized
INFO - 2023-05-17 10:34:28 --> Controller Class Initialized
DEBUG - 2023-05-17 10:34:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:34:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:34:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:34:28 --> Config Class Initialized
INFO - 2023-05-17 10:34:28 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:34:28 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:34:28 --> Utf8 Class Initialized
INFO - 2023-05-17 10:34:28 --> URI Class Initialized
INFO - 2023-05-17 10:34:28 --> Router Class Initialized
INFO - 2023-05-17 10:34:28 --> Output Class Initialized
INFO - 2023-05-17 10:34:28 --> Security Class Initialized
DEBUG - 2023-05-17 10:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:34:28 --> Input Class Initialized
INFO - 2023-05-17 10:34:28 --> Language Class Initialized
INFO - 2023-05-17 10:34:28 --> Loader Class Initialized
INFO - 2023-05-17 10:34:28 --> Controller Class Initialized
DEBUG - 2023-05-17 10:34:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:34:28 --> Database Driver Class Initialized
INFO - 2023-05-17 10:34:28 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:36:34 --> Config Class Initialized
INFO - 2023-05-17 10:36:34 --> Config Class Initialized
INFO - 2023-05-17 10:36:34 --> Config Class Initialized
INFO - 2023-05-17 10:36:34 --> Hooks Class Initialized
INFO - 2023-05-17 10:36:34 --> Hooks Class Initialized
INFO - 2023-05-17 10:36:34 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:36:34 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:36:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:36:34 --> Utf8 Class Initialized
DEBUG - 2023-05-17 10:36:34 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:36:34 --> Utf8 Class Initialized
INFO - 2023-05-17 10:36:34 --> URI Class Initialized
INFO - 2023-05-17 10:36:34 --> Utf8 Class Initialized
INFO - 2023-05-17 10:36:34 --> URI Class Initialized
INFO - 2023-05-17 10:36:34 --> Router Class Initialized
INFO - 2023-05-17 10:36:34 --> URI Class Initialized
INFO - 2023-05-17 10:36:34 --> Router Class Initialized
INFO - 2023-05-17 10:36:34 --> Output Class Initialized
INFO - 2023-05-17 10:36:34 --> Router Class Initialized
INFO - 2023-05-17 10:36:34 --> Output Class Initialized
INFO - 2023-05-17 10:36:34 --> Security Class Initialized
INFO - 2023-05-17 10:36:34 --> Output Class Initialized
INFO - 2023-05-17 10:36:34 --> Security Class Initialized
DEBUG - 2023-05-17 10:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 10:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:36:34 --> Input Class Initialized
INFO - 2023-05-17 10:36:34 --> Input Class Initialized
INFO - 2023-05-17 10:36:34 --> Security Class Initialized
INFO - 2023-05-17 10:36:34 --> Language Class Initialized
INFO - 2023-05-17 10:36:34 --> Language Class Initialized
DEBUG - 2023-05-17 10:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:36:34 --> Input Class Initialized
INFO - 2023-05-17 10:36:34 --> Loader Class Initialized
INFO - 2023-05-17 10:36:34 --> Loader Class Initialized
INFO - 2023-05-17 10:36:34 --> Language Class Initialized
INFO - 2023-05-17 10:36:34 --> Controller Class Initialized
INFO - 2023-05-17 10:36:34 --> Controller Class Initialized
DEBUG - 2023-05-17 10:36:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:36:34 --> Loader Class Initialized
DEBUG - 2023-05-17 10:36:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:36:34 --> Controller Class Initialized
INFO - 2023-05-17 10:36:34 --> Database Driver Class Initialized
INFO - 2023-05-17 10:36:34 --> Database Driver Class Initialized
DEBUG - 2023-05-17 10:36:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:36:34 --> Database Driver Class Initialized
INFO - 2023-05-17 10:36:35 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:36:35 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:36:35 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:36:35 --> Final output sent to browser
DEBUG - 2023-05-17 10:36:35 --> Total execution time: 0.0213
INFO - 2023-05-17 10:36:35 --> Final output sent to browser
INFO - 2023-05-17 10:36:35 --> Final output sent to browser
DEBUG - 2023-05-17 10:36:35 --> Total execution time: 0.0231
DEBUG - 2023-05-17 10:36:35 --> Total execution time: 0.0224
INFO - 2023-05-17 10:36:35 --> Config Class Initialized
INFO - 2023-05-17 10:36:35 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:36:35 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:36:35 --> Utf8 Class Initialized
INFO - 2023-05-17 10:36:35 --> URI Class Initialized
INFO - 2023-05-17 10:36:35 --> Router Class Initialized
INFO - 2023-05-17 10:36:35 --> Config Class Initialized
INFO - 2023-05-17 10:36:35 --> Config Class Initialized
INFO - 2023-05-17 10:36:35 --> Hooks Class Initialized
INFO - 2023-05-17 10:36:35 --> Hooks Class Initialized
INFO - 2023-05-17 10:36:35 --> Output Class Initialized
DEBUG - 2023-05-17 10:36:35 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:36:35 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:36:35 --> Utf8 Class Initialized
INFO - 2023-05-17 10:36:35 --> Utf8 Class Initialized
INFO - 2023-05-17 10:36:35 --> Security Class Initialized
INFO - 2023-05-17 10:36:35 --> URI Class Initialized
INFO - 2023-05-17 10:36:35 --> URI Class Initialized
DEBUG - 2023-05-17 10:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:36:35 --> Router Class Initialized
INFO - 2023-05-17 10:36:35 --> Router Class Initialized
INFO - 2023-05-17 10:36:35 --> Input Class Initialized
INFO - 2023-05-17 10:36:35 --> Output Class Initialized
INFO - 2023-05-17 10:36:35 --> Language Class Initialized
INFO - 2023-05-17 10:36:35 --> Output Class Initialized
INFO - 2023-05-17 10:36:35 --> Security Class Initialized
INFO - 2023-05-17 10:36:35 --> Loader Class Initialized
INFO - 2023-05-17 10:36:35 --> Security Class Initialized
DEBUG - 2023-05-17 10:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:36:35 --> Controller Class Initialized
DEBUG - 2023-05-17 10:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:36:35 --> Input Class Initialized
INFO - 2023-05-17 10:36:35 --> Input Class Initialized
DEBUG - 2023-05-17 10:36:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:36:35 --> Language Class Initialized
INFO - 2023-05-17 10:36:35 --> Language Class Initialized
INFO - 2023-05-17 10:36:35 --> Loader Class Initialized
INFO - 2023-05-17 10:36:35 --> Database Driver Class Initialized
INFO - 2023-05-17 10:36:35 --> Loader Class Initialized
INFO - 2023-05-17 10:36:35 --> Controller Class Initialized
INFO - 2023-05-17 10:36:35 --> Controller Class Initialized
DEBUG - 2023-05-17 10:36:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:36:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:36:35 --> Database Driver Class Initialized
INFO - 2023-05-17 10:36:35 --> Database Driver Class Initialized
INFO - 2023-05-17 10:36:35 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:36:35 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:36:35 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:36:35 --> Final output sent to browser
DEBUG - 2023-05-17 10:36:35 --> Total execution time: 0.0525
INFO - 2023-05-17 10:36:35 --> Final output sent to browser
DEBUG - 2023-05-17 10:36:35 --> Total execution time: 0.0530
INFO - 2023-05-17 10:36:35 --> Final output sent to browser
INFO - 2023-05-17 10:36:35 --> Config Class Initialized
INFO - 2023-05-17 10:36:35 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:36:35 --> Total execution time: 0.0613
DEBUG - 2023-05-17 10:36:35 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:36:35 --> Utf8 Class Initialized
INFO - 2023-05-17 10:36:35 --> URI Class Initialized
INFO - 2023-05-17 10:36:35 --> Router Class Initialized
INFO - 2023-05-17 10:36:35 --> Output Class Initialized
INFO - 2023-05-17 10:36:35 --> Security Class Initialized
DEBUG - 2023-05-17 10:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:36:35 --> Input Class Initialized
INFO - 2023-05-17 10:36:35 --> Language Class Initialized
INFO - 2023-05-17 10:36:35 --> Loader Class Initialized
INFO - 2023-05-17 10:36:35 --> Controller Class Initialized
DEBUG - 2023-05-17 10:36:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:36:35 --> Database Driver Class Initialized
INFO - 2023-05-17 10:36:35 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:36:35 --> Config Class Initialized
INFO - 2023-05-17 10:36:35 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:36:35 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:36:35 --> Utf8 Class Initialized
INFO - 2023-05-17 10:36:35 --> URI Class Initialized
INFO - 2023-05-17 10:36:35 --> Router Class Initialized
INFO - 2023-05-17 10:36:35 --> Output Class Initialized
INFO - 2023-05-17 10:36:35 --> Security Class Initialized
DEBUG - 2023-05-17 10:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:36:35 --> Input Class Initialized
INFO - 2023-05-17 10:36:35 --> Language Class Initialized
INFO - 2023-05-17 10:36:35 --> Loader Class Initialized
INFO - 2023-05-17 10:36:35 --> Controller Class Initialized
DEBUG - 2023-05-17 10:36:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:36:35 --> Database Driver Class Initialized
INFO - 2023-05-17 10:36:35 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:37:08 --> Config Class Initialized
INFO - 2023-05-17 10:37:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:37:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:37:08 --> Utf8 Class Initialized
INFO - 2023-05-17 10:37:08 --> URI Class Initialized
INFO - 2023-05-17 10:37:08 --> Router Class Initialized
INFO - 2023-05-17 10:37:08 --> Output Class Initialized
INFO - 2023-05-17 10:37:08 --> Security Class Initialized
DEBUG - 2023-05-17 10:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:37:08 --> Input Class Initialized
INFO - 2023-05-17 10:37:08 --> Language Class Initialized
INFO - 2023-05-17 10:37:08 --> Loader Class Initialized
INFO - 2023-05-17 10:37:08 --> Controller Class Initialized
DEBUG - 2023-05-17 10:37:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:37:08 --> Database Driver Class Initialized
INFO - 2023-05-17 10:37:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:37:08 --> Final output sent to browser
DEBUG - 2023-05-17 10:37:08 --> Total execution time: 0.0109
INFO - 2023-05-17 10:37:08 --> Config Class Initialized
INFO - 2023-05-17 10:37:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:37:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:37:08 --> Utf8 Class Initialized
INFO - 2023-05-17 10:37:08 --> URI Class Initialized
INFO - 2023-05-17 10:37:08 --> Router Class Initialized
INFO - 2023-05-17 10:37:08 --> Output Class Initialized
INFO - 2023-05-17 10:37:08 --> Security Class Initialized
DEBUG - 2023-05-17 10:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:37:08 --> Input Class Initialized
INFO - 2023-05-17 10:37:08 --> Language Class Initialized
INFO - 2023-05-17 10:37:08 --> Loader Class Initialized
INFO - 2023-05-17 10:37:08 --> Controller Class Initialized
DEBUG - 2023-05-17 10:37:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:37:08 --> Database Driver Class Initialized
INFO - 2023-05-17 10:37:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:37:08 --> Final output sent to browser
DEBUG - 2023-05-17 10:37:08 --> Total execution time: 0.0200
INFO - 2023-05-17 10:37:09 --> Config Class Initialized
INFO - 2023-05-17 10:37:09 --> Config Class Initialized
INFO - 2023-05-17 10:37:09 --> Config Class Initialized
INFO - 2023-05-17 10:37:09 --> Hooks Class Initialized
INFO - 2023-05-17 10:37:09 --> Hooks Class Initialized
INFO - 2023-05-17 10:37:09 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:37:09 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:37:09 --> Utf8 Class Initialized
INFO - 2023-05-17 10:37:09 --> Utf8 Class Initialized
DEBUG - 2023-05-17 10:37:09 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:37:09 --> URI Class Initialized
INFO - 2023-05-17 10:37:09 --> URI Class Initialized
INFO - 2023-05-17 10:37:09 --> Utf8 Class Initialized
INFO - 2023-05-17 10:37:09 --> Router Class Initialized
INFO - 2023-05-17 10:37:09 --> Router Class Initialized
INFO - 2023-05-17 10:37:09 --> URI Class Initialized
INFO - 2023-05-17 10:37:09 --> Output Class Initialized
INFO - 2023-05-17 10:37:09 --> Output Class Initialized
INFO - 2023-05-17 10:37:09 --> Router Class Initialized
INFO - 2023-05-17 10:37:09 --> Security Class Initialized
INFO - 2023-05-17 10:37:09 --> Security Class Initialized
DEBUG - 2023-05-17 10:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:37:09 --> Output Class Initialized
INFO - 2023-05-17 10:37:09 --> Input Class Initialized
DEBUG - 2023-05-17 10:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:37:09 --> Security Class Initialized
INFO - 2023-05-17 10:37:09 --> Language Class Initialized
INFO - 2023-05-17 10:37:09 --> Input Class Initialized
DEBUG - 2023-05-17 10:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:37:09 --> Language Class Initialized
INFO - 2023-05-17 10:37:09 --> Loader Class Initialized
INFO - 2023-05-17 10:37:09 --> Input Class Initialized
INFO - 2023-05-17 10:37:09 --> Loader Class Initialized
INFO - 2023-05-17 10:37:09 --> Controller Class Initialized
INFO - 2023-05-17 10:37:09 --> Language Class Initialized
INFO - 2023-05-17 10:37:09 --> Controller Class Initialized
DEBUG - 2023-05-17 10:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:37:09 --> Loader Class Initialized
INFO - 2023-05-17 10:37:09 --> Database Driver Class Initialized
INFO - 2023-05-17 10:37:09 --> Controller Class Initialized
INFO - 2023-05-17 10:37:09 --> Database Driver Class Initialized
DEBUG - 2023-05-17 10:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:37:09 --> Database Driver Class Initialized
INFO - 2023-05-17 10:37:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:37:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:37:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:37:09 --> Final output sent to browser
DEBUG - 2023-05-17 10:37:09 --> Total execution time: 0.0145
INFO - 2023-05-17 10:37:09 --> Final output sent to browser
INFO - 2023-05-17 10:37:09 --> Final output sent to browser
DEBUG - 2023-05-17 10:37:09 --> Total execution time: 0.0161
DEBUG - 2023-05-17 10:37:09 --> Total execution time: 0.0161
INFO - 2023-05-17 10:37:09 --> Config Class Initialized
INFO - 2023-05-17 10:37:09 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:37:09 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:37:09 --> Utf8 Class Initialized
INFO - 2023-05-17 10:37:09 --> URI Class Initialized
INFO - 2023-05-17 10:37:09 --> Router Class Initialized
INFO - 2023-05-17 10:37:09 --> Config Class Initialized
INFO - 2023-05-17 10:37:09 --> Output Class Initialized
INFO - 2023-05-17 10:37:09 --> Config Class Initialized
INFO - 2023-05-17 10:37:09 --> Hooks Class Initialized
INFO - 2023-05-17 10:37:09 --> Hooks Class Initialized
INFO - 2023-05-17 10:37:09 --> Security Class Initialized
DEBUG - 2023-05-17 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:37:09 --> Utf8 Class Initialized
INFO - 2023-05-17 10:37:09 --> Utf8 Class Initialized
INFO - 2023-05-17 10:37:09 --> Input Class Initialized
INFO - 2023-05-17 10:37:09 --> URI Class Initialized
INFO - 2023-05-17 10:37:09 --> URI Class Initialized
INFO - 2023-05-17 10:37:09 --> Language Class Initialized
INFO - 2023-05-17 10:37:09 --> Router Class Initialized
INFO - 2023-05-17 10:37:09 --> Router Class Initialized
INFO - 2023-05-17 10:37:09 --> Output Class Initialized
INFO - 2023-05-17 10:37:09 --> Output Class Initialized
INFO - 2023-05-17 10:37:09 --> Loader Class Initialized
INFO - 2023-05-17 10:37:09 --> Security Class Initialized
INFO - 2023-05-17 10:37:09 --> Security Class Initialized
INFO - 2023-05-17 10:37:09 --> Controller Class Initialized
DEBUG - 2023-05-17 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 10:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:37:09 --> Input Class Initialized
INFO - 2023-05-17 10:37:09 --> Input Class Initialized
INFO - 2023-05-17 10:37:09 --> Language Class Initialized
INFO - 2023-05-17 10:37:09 --> Database Driver Class Initialized
INFO - 2023-05-17 10:37:09 --> Language Class Initialized
INFO - 2023-05-17 10:37:09 --> Loader Class Initialized
INFO - 2023-05-17 10:37:09 --> Controller Class Initialized
INFO - 2023-05-17 10:37:09 --> Loader Class Initialized
DEBUG - 2023-05-17 10:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:37:09 --> Controller Class Initialized
DEBUG - 2023-05-17 10:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:37:09 --> Database Driver Class Initialized
INFO - 2023-05-17 10:37:09 --> Database Driver Class Initialized
INFO - 2023-05-17 10:37:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:37:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:37:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:37:09 --> Final output sent to browser
INFO - 2023-05-17 10:37:09 --> Final output sent to browser
DEBUG - 2023-05-17 10:37:09 --> Total execution time: 0.0160
DEBUG - 2023-05-17 10:37:09 --> Total execution time: 0.0160
INFO - 2023-05-17 10:37:09 --> Final output sent to browser
INFO - 2023-05-17 10:37:09 --> Config Class Initialized
INFO - 2023-05-17 10:37:09 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:37:09 --> Total execution time: 0.0229
DEBUG - 2023-05-17 10:37:09 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:37:09 --> Utf8 Class Initialized
INFO - 2023-05-17 10:37:09 --> URI Class Initialized
INFO - 2023-05-17 10:37:09 --> Router Class Initialized
INFO - 2023-05-17 10:37:09 --> Output Class Initialized
INFO - 2023-05-17 10:37:09 --> Security Class Initialized
DEBUG - 2023-05-17 10:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:37:09 --> Input Class Initialized
INFO - 2023-05-17 10:37:09 --> Language Class Initialized
INFO - 2023-05-17 10:37:09 --> Loader Class Initialized
INFO - 2023-05-17 10:37:09 --> Controller Class Initialized
DEBUG - 2023-05-17 10:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:37:09 --> Database Driver Class Initialized
INFO - 2023-05-17 10:37:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:37:09 --> Config Class Initialized
INFO - 2023-05-17 10:37:09 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:37:09 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:37:09 --> Utf8 Class Initialized
INFO - 2023-05-17 10:37:09 --> URI Class Initialized
INFO - 2023-05-17 10:37:09 --> Router Class Initialized
INFO - 2023-05-17 10:37:09 --> Output Class Initialized
INFO - 2023-05-17 10:37:09 --> Security Class Initialized
DEBUG - 2023-05-17 10:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:37:09 --> Input Class Initialized
INFO - 2023-05-17 10:37:09 --> Language Class Initialized
INFO - 2023-05-17 10:37:09 --> Loader Class Initialized
INFO - 2023-05-17 10:37:09 --> Controller Class Initialized
DEBUG - 2023-05-17 10:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:37:09 --> Database Driver Class Initialized
INFO - 2023-05-17 10:37:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:38:08 --> Config Class Initialized
INFO - 2023-05-17 10:38:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:38:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:38:08 --> Utf8 Class Initialized
INFO - 2023-05-17 10:38:08 --> URI Class Initialized
INFO - 2023-05-17 10:38:08 --> Router Class Initialized
INFO - 2023-05-17 10:38:08 --> Output Class Initialized
INFO - 2023-05-17 10:38:08 --> Security Class Initialized
DEBUG - 2023-05-17 10:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:38:08 --> Input Class Initialized
INFO - 2023-05-17 10:38:08 --> Language Class Initialized
INFO - 2023-05-17 10:38:08 --> Loader Class Initialized
INFO - 2023-05-17 10:38:08 --> Controller Class Initialized
DEBUG - 2023-05-17 10:38:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:38:08 --> Database Driver Class Initialized
INFO - 2023-05-17 10:38:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:38:08 --> Config Class Initialized
INFO - 2023-05-17 10:38:08 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:38:08 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:38:08 --> Utf8 Class Initialized
INFO - 2023-05-17 10:38:08 --> URI Class Initialized
INFO - 2023-05-17 10:38:08 --> Router Class Initialized
INFO - 2023-05-17 10:38:08 --> Output Class Initialized
INFO - 2023-05-17 10:38:08 --> Security Class Initialized
DEBUG - 2023-05-17 10:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:38:08 --> Input Class Initialized
INFO - 2023-05-17 10:38:08 --> Language Class Initialized
INFO - 2023-05-17 10:38:08 --> Loader Class Initialized
INFO - 2023-05-17 10:38:08 --> Controller Class Initialized
DEBUG - 2023-05-17 10:38:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:38:08 --> Database Driver Class Initialized
INFO - 2023-05-17 10:38:08 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:39:09 --> Config Class Initialized
INFO - 2023-05-17 10:39:09 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:39:09 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:39:09 --> Utf8 Class Initialized
INFO - 2023-05-17 10:39:09 --> URI Class Initialized
INFO - 2023-05-17 10:39:09 --> Router Class Initialized
INFO - 2023-05-17 10:39:09 --> Output Class Initialized
INFO - 2023-05-17 10:39:09 --> Security Class Initialized
DEBUG - 2023-05-17 10:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:39:09 --> Input Class Initialized
INFO - 2023-05-17 10:39:09 --> Language Class Initialized
INFO - 2023-05-17 10:39:09 --> Loader Class Initialized
INFO - 2023-05-17 10:39:09 --> Controller Class Initialized
DEBUG - 2023-05-17 10:39:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:39:09 --> Database Driver Class Initialized
INFO - 2023-05-17 10:39:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:39:09 --> Final output sent to browser
DEBUG - 2023-05-17 10:39:09 --> Total execution time: 0.0136
INFO - 2023-05-17 10:39:09 --> Config Class Initialized
INFO - 2023-05-17 10:39:09 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:39:09 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:39:09 --> Utf8 Class Initialized
INFO - 2023-05-17 10:39:09 --> URI Class Initialized
INFO - 2023-05-17 10:39:09 --> Router Class Initialized
INFO - 2023-05-17 10:39:09 --> Output Class Initialized
INFO - 2023-05-17 10:39:09 --> Security Class Initialized
DEBUG - 2023-05-17 10:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:39:09 --> Input Class Initialized
INFO - 2023-05-17 10:39:09 --> Language Class Initialized
INFO - 2023-05-17 10:39:09 --> Loader Class Initialized
INFO - 2023-05-17 10:39:09 --> Controller Class Initialized
DEBUG - 2023-05-17 10:39:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:39:09 --> Database Driver Class Initialized
INFO - 2023-05-17 10:39:09 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:39:09 --> Final output sent to browser
DEBUG - 2023-05-17 10:39:09 --> Total execution time: 0.0189
INFO - 2023-05-17 10:41:47 --> Config Class Initialized
INFO - 2023-05-17 10:41:47 --> Hooks Class Initialized
INFO - 2023-05-17 10:41:47 --> Config Class Initialized
INFO - 2023-05-17 10:41:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:41:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:41:47 --> Config Class Initialized
INFO - 2023-05-17 10:41:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:41:47 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:41:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:41:47 --> Utf8 Class Initialized
INFO - 2023-05-17 10:41:47 --> Utf8 Class Initialized
INFO - 2023-05-17 10:41:47 --> URI Class Initialized
INFO - 2023-05-17 10:41:47 --> URI Class Initialized
INFO - 2023-05-17 10:41:47 --> Utf8 Class Initialized
INFO - 2023-05-17 10:41:47 --> Router Class Initialized
INFO - 2023-05-17 10:41:47 --> URI Class Initialized
INFO - 2023-05-17 10:41:47 --> Router Class Initialized
INFO - 2023-05-17 10:41:47 --> Output Class Initialized
INFO - 2023-05-17 10:41:47 --> Router Class Initialized
INFO - 2023-05-17 10:41:47 --> Output Class Initialized
INFO - 2023-05-17 10:41:47 --> Output Class Initialized
INFO - 2023-05-17 10:41:47 --> Security Class Initialized
INFO - 2023-05-17 10:41:47 --> Security Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:41:47 --> Security Class Initialized
INFO - 2023-05-17 10:41:47 --> Input Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:41:47 --> Language Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:41:47 --> Input Class Initialized
INFO - 2023-05-17 10:41:47 --> Input Class Initialized
INFO - 2023-05-17 10:41:47 --> Loader Class Initialized
INFO - 2023-05-17 10:41:47 --> Language Class Initialized
INFO - 2023-05-17 10:41:47 --> Controller Class Initialized
INFO - 2023-05-17 10:41:47 --> Loader Class Initialized
INFO - 2023-05-17 10:41:47 --> Controller Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:41:47 --> Language Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:41:47 --> Loader Class Initialized
INFO - 2023-05-17 10:41:47 --> Controller Class Initialized
INFO - 2023-05-17 10:41:47 --> Database Driver Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:41:47 --> Database Driver Class Initialized
INFO - 2023-05-17 10:41:47 --> Database Driver Class Initialized
INFO - 2023-05-17 10:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:41:47 --> Final output sent to browser
DEBUG - 2023-05-17 10:41:47 --> Total execution time: 0.0185
INFO - 2023-05-17 10:41:47 --> Final output sent to browser
INFO - 2023-05-17 10:41:47 --> Final output sent to browser
DEBUG - 2023-05-17 10:41:47 --> Total execution time: 0.0200
DEBUG - 2023-05-17 10:41:47 --> Total execution time: 0.0200
INFO - 2023-05-17 10:41:47 --> Config Class Initialized
INFO - 2023-05-17 10:41:47 --> Config Class Initialized
INFO - 2023-05-17 10:41:47 --> Hooks Class Initialized
INFO - 2023-05-17 10:41:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:41:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:41:47 --> Utf8 Class Initialized
DEBUG - 2023-05-17 10:41:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:41:47 --> Utf8 Class Initialized
INFO - 2023-05-17 10:41:47 --> URI Class Initialized
INFO - 2023-05-17 10:41:47 --> Router Class Initialized
INFO - 2023-05-17 10:41:47 --> Output Class Initialized
INFO - 2023-05-17 10:41:47 --> Security Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:41:47 --> Config Class Initialized
INFO - 2023-05-17 10:41:47 --> Input Class Initialized
INFO - 2023-05-17 10:41:47 --> URI Class Initialized
INFO - 2023-05-17 10:41:47 --> Hooks Class Initialized
INFO - 2023-05-17 10:41:47 --> Language Class Initialized
INFO - 2023-05-17 10:41:47 --> Loader Class Initialized
DEBUG - 2023-05-17 10:41:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:41:47 --> Controller Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:41:47 --> Utf8 Class Initialized
INFO - 2023-05-17 10:41:47 --> Router Class Initialized
INFO - 2023-05-17 10:41:47 --> Database Driver Class Initialized
INFO - 2023-05-17 10:41:47 --> Output Class Initialized
INFO - 2023-05-17 10:41:47 --> URI Class Initialized
INFO - 2023-05-17 10:41:47 --> Security Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:41:47 --> Input Class Initialized
INFO - 2023-05-17 10:41:47 --> Router Class Initialized
INFO - 2023-05-17 10:41:47 --> Language Class Initialized
INFO - 2023-05-17 10:41:47 --> Output Class Initialized
INFO - 2023-05-17 10:41:47 --> Security Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:41:47 --> Loader Class Initialized
INFO - 2023-05-17 10:41:47 --> Input Class Initialized
INFO - 2023-05-17 10:41:47 --> Language Class Initialized
INFO - 2023-05-17 10:41:47 --> Loader Class Initialized
INFO - 2023-05-17 10:41:47 --> Controller Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:41:47 --> Controller Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:41:47 --> Database Driver Class Initialized
INFO - 2023-05-17 10:41:47 --> Database Driver Class Initialized
INFO - 2023-05-17 10:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:41:47 --> Final output sent to browser
DEBUG - 2023-05-17 10:41:47 --> Total execution time: 0.0174
INFO - 2023-05-17 10:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:41:47 --> Config Class Initialized
INFO - 2023-05-17 10:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:41:47 --> Final output sent to browser
INFO - 2023-05-17 10:41:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Total execution time: 0.0631
DEBUG - 2023-05-17 10:41:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:41:47 --> Utf8 Class Initialized
INFO - 2023-05-17 10:41:47 --> URI Class Initialized
INFO - 2023-05-17 10:41:47 --> Router Class Initialized
INFO - 2023-05-17 10:41:47 --> Final output sent to browser
DEBUG - 2023-05-17 10:41:47 --> Total execution time: 0.0709
INFO - 2023-05-17 10:41:47 --> Output Class Initialized
INFO - 2023-05-17 10:41:47 --> Security Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:41:47 --> Input Class Initialized
INFO - 2023-05-17 10:41:47 --> Language Class Initialized
INFO - 2023-05-17 10:41:47 --> Loader Class Initialized
INFO - 2023-05-17 10:41:47 --> Controller Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:41:47 --> Database Driver Class Initialized
INFO - 2023-05-17 10:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:41:47 --> Config Class Initialized
INFO - 2023-05-17 10:41:47 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:41:47 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:41:47 --> Utf8 Class Initialized
INFO - 2023-05-17 10:41:47 --> URI Class Initialized
INFO - 2023-05-17 10:41:47 --> Router Class Initialized
INFO - 2023-05-17 10:41:47 --> Output Class Initialized
INFO - 2023-05-17 10:41:47 --> Security Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:41:47 --> Input Class Initialized
INFO - 2023-05-17 10:41:47 --> Language Class Initialized
INFO - 2023-05-17 10:41:47 --> Loader Class Initialized
INFO - 2023-05-17 10:41:47 --> Controller Class Initialized
DEBUG - 2023-05-17 10:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:41:47 --> Database Driver Class Initialized
INFO - 2023-05-17 10:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:42:44 --> Config Class Initialized
INFO - 2023-05-17 10:42:44 --> Config Class Initialized
INFO - 2023-05-17 10:42:44 --> Hooks Class Initialized
INFO - 2023-05-17 10:42:44 --> Config Class Initialized
INFO - 2023-05-17 10:42:44 --> Hooks Class Initialized
INFO - 2023-05-17 10:42:44 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:42:44 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:42:44 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:42:44 --> Utf8 Class Initialized
INFO - 2023-05-17 10:42:44 --> URI Class Initialized
DEBUG - 2023-05-17 10:42:44 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:42:44 --> Utf8 Class Initialized
INFO - 2023-05-17 10:42:44 --> Utf8 Class Initialized
INFO - 2023-05-17 10:42:44 --> Router Class Initialized
INFO - 2023-05-17 10:42:44 --> URI Class Initialized
INFO - 2023-05-17 10:42:44 --> Output Class Initialized
INFO - 2023-05-17 10:42:44 --> URI Class Initialized
INFO - 2023-05-17 10:42:44 --> Router Class Initialized
INFO - 2023-05-17 10:42:44 --> Security Class Initialized
INFO - 2023-05-17 10:42:44 --> Router Class Initialized
INFO - 2023-05-17 10:42:44 --> Output Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:42:44 --> Security Class Initialized
INFO - 2023-05-17 10:42:44 --> Input Class Initialized
INFO - 2023-05-17 10:42:44 --> Output Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:42:44 --> Language Class Initialized
INFO - 2023-05-17 10:42:44 --> Input Class Initialized
INFO - 2023-05-17 10:42:44 --> Security Class Initialized
INFO - 2023-05-17 10:42:44 --> Language Class Initialized
INFO - 2023-05-17 10:42:44 --> Loader Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:42:44 --> Loader Class Initialized
INFO - 2023-05-17 10:42:44 --> Input Class Initialized
INFO - 2023-05-17 10:42:44 --> Controller Class Initialized
INFO - 2023-05-17 10:42:44 --> Language Class Initialized
INFO - 2023-05-17 10:42:44 --> Controller Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:42:44 --> Loader Class Initialized
INFO - 2023-05-17 10:42:44 --> Database Driver Class Initialized
INFO - 2023-05-17 10:42:44 --> Controller Class Initialized
INFO - 2023-05-17 10:42:44 --> Database Driver Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:42:44 --> Database Driver Class Initialized
INFO - 2023-05-17 10:42:44 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:42:44 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:42:44 --> Final output sent to browser
DEBUG - 2023-05-17 10:42:44 --> Total execution time: 0.0275
INFO - 2023-05-17 10:42:44 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:42:44 --> Final output sent to browser
DEBUG - 2023-05-17 10:42:44 --> Total execution time: 0.0296
INFO - 2023-05-17 10:42:44 --> Config Class Initialized
INFO - 2023-05-17 10:42:44 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:42:44 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:42:44 --> Utf8 Class Initialized
INFO - 2023-05-17 10:42:44 --> Final output sent to browser
INFO - 2023-05-17 10:42:44 --> URI Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Total execution time: 0.0321
INFO - 2023-05-17 10:42:44 --> Router Class Initialized
INFO - 2023-05-17 10:42:44 --> Output Class Initialized
INFO - 2023-05-17 10:42:44 --> Security Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:42:44 --> Input Class Initialized
INFO - 2023-05-17 10:42:44 --> Language Class Initialized
INFO - 2023-05-17 10:42:44 --> Config Class Initialized
INFO - 2023-05-17 10:42:44 --> Loader Class Initialized
INFO - 2023-05-17 10:42:44 --> Hooks Class Initialized
INFO - 2023-05-17 10:42:44 --> Controller Class Initialized
DEBUG - 2023-05-17 10:42:44 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:42:44 --> Utf8 Class Initialized
INFO - 2023-05-17 10:42:44 --> Config Class Initialized
INFO - 2023-05-17 10:42:44 --> URI Class Initialized
INFO - 2023-05-17 10:42:44 --> Database Driver Class Initialized
INFO - 2023-05-17 10:42:44 --> Hooks Class Initialized
INFO - 2023-05-17 10:42:44 --> Router Class Initialized
DEBUG - 2023-05-17 10:42:44 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:42:44 --> Output Class Initialized
INFO - 2023-05-17 10:42:44 --> Utf8 Class Initialized
INFO - 2023-05-17 10:42:44 --> Security Class Initialized
INFO - 2023-05-17 10:42:44 --> URI Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:42:44 --> Router Class Initialized
INFO - 2023-05-17 10:42:44 --> Input Class Initialized
INFO - 2023-05-17 10:42:44 --> Language Class Initialized
INFO - 2023-05-17 10:42:44 --> Output Class Initialized
INFO - 2023-05-17 10:42:44 --> Loader Class Initialized
INFO - 2023-05-17 10:42:44 --> Security Class Initialized
INFO - 2023-05-17 10:42:44 --> Controller Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 10:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:42:44 --> Input Class Initialized
INFO - 2023-05-17 10:42:44 --> Language Class Initialized
INFO - 2023-05-17 10:42:44 --> Database Driver Class Initialized
INFO - 2023-05-17 10:42:44 --> Loader Class Initialized
INFO - 2023-05-17 10:42:44 --> Controller Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:42:44 --> Database Driver Class Initialized
INFO - 2023-05-17 10:42:44 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:42:44 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:42:44 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:42:44 --> Final output sent to browser
INFO - 2023-05-17 10:42:44 --> Final output sent to browser
DEBUG - 2023-05-17 10:42:44 --> Total execution time: 0.0139
DEBUG - 2023-05-17 10:42:44 --> Total execution time: 0.0156
INFO - 2023-05-17 10:42:44 --> Final output sent to browser
INFO - 2023-05-17 10:42:44 --> Config Class Initialized
INFO - 2023-05-17 10:42:44 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Total execution time: 0.0205
DEBUG - 2023-05-17 10:42:44 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:42:44 --> Utf8 Class Initialized
INFO - 2023-05-17 10:42:44 --> URI Class Initialized
INFO - 2023-05-17 10:42:44 --> Router Class Initialized
INFO - 2023-05-17 10:42:44 --> Output Class Initialized
INFO - 2023-05-17 10:42:44 --> Security Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:42:44 --> Input Class Initialized
INFO - 2023-05-17 10:42:44 --> Language Class Initialized
INFO - 2023-05-17 10:42:44 --> Loader Class Initialized
INFO - 2023-05-17 10:42:44 --> Controller Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:42:44 --> Database Driver Class Initialized
INFO - 2023-05-17 10:42:44 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:42:44 --> Config Class Initialized
INFO - 2023-05-17 10:42:44 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:42:44 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:42:44 --> Utf8 Class Initialized
INFO - 2023-05-17 10:42:44 --> URI Class Initialized
INFO - 2023-05-17 10:42:44 --> Router Class Initialized
INFO - 2023-05-17 10:42:44 --> Output Class Initialized
INFO - 2023-05-17 10:42:44 --> Security Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:42:44 --> Input Class Initialized
INFO - 2023-05-17 10:42:44 --> Language Class Initialized
INFO - 2023-05-17 10:42:44 --> Loader Class Initialized
INFO - 2023-05-17 10:42:44 --> Controller Class Initialized
DEBUG - 2023-05-17 10:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:42:44 --> Database Driver Class Initialized
INFO - 2023-05-17 10:42:44 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:43:57 --> Config Class Initialized
INFO - 2023-05-17 10:43:57 --> Config Class Initialized
INFO - 2023-05-17 10:43:57 --> Config Class Initialized
INFO - 2023-05-17 10:43:57 --> Hooks Class Initialized
INFO - 2023-05-17 10:43:57 --> Hooks Class Initialized
INFO - 2023-05-17 10:43:57 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:43:57 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:43:57 --> Utf8 Class Initialized
DEBUG - 2023-05-17 10:43:57 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:43:57 --> Utf8 Class Initialized
INFO - 2023-05-17 10:43:57 --> URI Class Initialized
DEBUG - 2023-05-17 10:43:57 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:43:57 --> URI Class Initialized
INFO - 2023-05-17 10:43:57 --> Utf8 Class Initialized
INFO - 2023-05-17 10:43:57 --> Router Class Initialized
INFO - 2023-05-17 10:43:57 --> Router Class Initialized
INFO - 2023-05-17 10:43:57 --> URI Class Initialized
INFO - 2023-05-17 10:43:57 --> Output Class Initialized
INFO - 2023-05-17 10:43:57 --> Output Class Initialized
INFO - 2023-05-17 10:43:57 --> Router Class Initialized
INFO - 2023-05-17 10:43:57 --> Security Class Initialized
INFO - 2023-05-17 10:43:57 --> Security Class Initialized
INFO - 2023-05-17 10:43:57 --> Output Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:43:57 --> Security Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 10:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:43:57 --> Input Class Initialized
INFO - 2023-05-17 10:43:57 --> Input Class Initialized
INFO - 2023-05-17 10:43:57 --> Input Class Initialized
INFO - 2023-05-17 10:43:57 --> Language Class Initialized
INFO - 2023-05-17 10:43:57 --> Language Class Initialized
INFO - 2023-05-17 10:43:57 --> Language Class Initialized
INFO - 2023-05-17 10:43:57 --> Loader Class Initialized
INFO - 2023-05-17 10:43:57 --> Loader Class Initialized
INFO - 2023-05-17 10:43:57 --> Loader Class Initialized
INFO - 2023-05-17 10:43:57 --> Controller Class Initialized
INFO - 2023-05-17 10:43:57 --> Controller Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:43:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:43:57 --> Controller Class Initialized
INFO - 2023-05-17 10:43:57 --> Database Driver Class Initialized
INFO - 2023-05-17 10:43:57 --> Database Driver Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:43:57 --> Database Driver Class Initialized
INFO - 2023-05-17 10:43:57 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:43:57 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:43:57 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:43:57 --> Final output sent to browser
DEBUG - 2023-05-17 10:43:57 --> Total execution time: 0.1184
INFO - 2023-05-17 10:43:57 --> Final output sent to browser
DEBUG - 2023-05-17 10:43:57 --> Total execution time: 0.1200
INFO - 2023-05-17 10:43:57 --> Config Class Initialized
INFO - 2023-05-17 10:43:57 --> Hooks Class Initialized
INFO - 2023-05-17 10:43:57 --> Final output sent to browser
DEBUG - 2023-05-17 10:43:57 --> Total execution time: 0.1210
DEBUG - 2023-05-17 10:43:57 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:43:57 --> Utf8 Class Initialized
INFO - 2023-05-17 10:43:57 --> URI Class Initialized
INFO - 2023-05-17 10:43:57 --> Router Class Initialized
INFO - 2023-05-17 10:43:57 --> Output Class Initialized
INFO - 2023-05-17 10:43:57 --> Security Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:43:57 --> Input Class Initialized
INFO - 2023-05-17 10:43:57 --> Language Class Initialized
INFO - 2023-05-17 10:43:57 --> Loader Class Initialized
INFO - 2023-05-17 10:43:57 --> Controller Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:43:57 --> Config Class Initialized
INFO - 2023-05-17 10:43:57 --> Config Class Initialized
INFO - 2023-05-17 10:43:57 --> Hooks Class Initialized
INFO - 2023-05-17 10:43:57 --> Database Driver Class Initialized
DEBUG - 2023-05-17 10:43:57 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:43:57 --> Hooks Class Initialized
INFO - 2023-05-17 10:43:57 --> Utf8 Class Initialized
INFO - 2023-05-17 10:43:57 --> URI Class Initialized
INFO - 2023-05-17 10:43:57 --> Router Class Initialized
DEBUG - 2023-05-17 10:43:57 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:43:57 --> Utf8 Class Initialized
INFO - 2023-05-17 10:43:57 --> Output Class Initialized
INFO - 2023-05-17 10:43:57 --> URI Class Initialized
INFO - 2023-05-17 10:43:57 --> Security Class Initialized
INFO - 2023-05-17 10:43:57 --> Router Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:43:57 --> Output Class Initialized
INFO - 2023-05-17 10:43:57 --> Input Class Initialized
INFO - 2023-05-17 10:43:57 --> Security Class Initialized
INFO - 2023-05-17 10:43:57 --> Language Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:43:57 --> Input Class Initialized
INFO - 2023-05-17 10:43:57 --> Loader Class Initialized
INFO - 2023-05-17 10:43:57 --> Language Class Initialized
INFO - 2023-05-17 10:43:57 --> Loader Class Initialized
INFO - 2023-05-17 10:43:57 --> Controller Class Initialized
INFO - 2023-05-17 10:43:57 --> Controller Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:43:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:43:57 --> Database Driver Class Initialized
INFO - 2023-05-17 10:43:57 --> Database Driver Class Initialized
INFO - 2023-05-17 10:43:57 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:43:57 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:43:57 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:43:57 --> Final output sent to browser
DEBUG - 2023-05-17 10:43:57 --> Total execution time: 0.0265
INFO - 2023-05-17 10:43:57 --> Final output sent to browser
DEBUG - 2023-05-17 10:43:57 --> Total execution time: 0.0261
INFO - 2023-05-17 10:43:57 --> Final output sent to browser
INFO - 2023-05-17 10:43:57 --> Config Class Initialized
INFO - 2023-05-17 10:43:57 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:43:57 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:43:57 --> Utf8 Class Initialized
INFO - 2023-05-17 10:43:57 --> URI Class Initialized
INFO - 2023-05-17 10:43:57 --> Router Class Initialized
INFO - 2023-05-17 10:43:57 --> Output Class Initialized
INFO - 2023-05-17 10:43:57 --> Security Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:43:57 --> Input Class Initialized
INFO - 2023-05-17 10:43:57 --> Language Class Initialized
INFO - 2023-05-17 10:43:57 --> Loader Class Initialized
INFO - 2023-05-17 10:43:57 --> Controller Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:43:57 --> Database Driver Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Total execution time: 0.0280
INFO - 2023-05-17 10:43:57 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:43:57 --> Config Class Initialized
INFO - 2023-05-17 10:43:57 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:43:57 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:43:57 --> Utf8 Class Initialized
INFO - 2023-05-17 10:43:57 --> URI Class Initialized
INFO - 2023-05-17 10:43:57 --> Router Class Initialized
INFO - 2023-05-17 10:43:57 --> Output Class Initialized
INFO - 2023-05-17 10:43:57 --> Security Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:43:57 --> Input Class Initialized
INFO - 2023-05-17 10:43:57 --> Language Class Initialized
INFO - 2023-05-17 10:43:57 --> Loader Class Initialized
INFO - 2023-05-17 10:43:57 --> Controller Class Initialized
DEBUG - 2023-05-17 10:43:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:43:57 --> Database Driver Class Initialized
INFO - 2023-05-17 10:43:57 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:44:06 --> Config Class Initialized
INFO - 2023-05-17 10:44:06 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:44:06 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:44:06 --> Utf8 Class Initialized
INFO - 2023-05-17 10:44:06 --> URI Class Initialized
INFO - 2023-05-17 10:44:06 --> Router Class Initialized
INFO - 2023-05-17 10:44:06 --> Output Class Initialized
INFO - 2023-05-17 10:44:06 --> Security Class Initialized
DEBUG - 2023-05-17 10:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:44:06 --> Input Class Initialized
INFO - 2023-05-17 10:44:06 --> Language Class Initialized
INFO - 2023-05-17 10:44:06 --> Loader Class Initialized
INFO - 2023-05-17 10:44:06 --> Controller Class Initialized
DEBUG - 2023-05-17 10:44:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:44:06 --> Database Driver Class Initialized
INFO - 2023-05-17 10:44:06 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:44:06 --> Final output sent to browser
DEBUG - 2023-05-17 10:44:06 --> Total execution time: 0.0140
INFO - 2023-05-17 10:44:06 --> Config Class Initialized
INFO - 2023-05-17 10:44:06 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:44:06 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:44:06 --> Utf8 Class Initialized
INFO - 2023-05-17 10:44:06 --> URI Class Initialized
INFO - 2023-05-17 10:44:06 --> Router Class Initialized
INFO - 2023-05-17 10:44:06 --> Output Class Initialized
INFO - 2023-05-17 10:44:06 --> Security Class Initialized
DEBUG - 2023-05-17 10:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:44:06 --> Input Class Initialized
INFO - 2023-05-17 10:44:06 --> Language Class Initialized
INFO - 2023-05-17 10:44:06 --> Loader Class Initialized
INFO - 2023-05-17 10:44:06 --> Controller Class Initialized
DEBUG - 2023-05-17 10:44:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:44:06 --> Database Driver Class Initialized
INFO - 2023-05-17 10:44:06 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:44:06 --> Final output sent to browser
DEBUG - 2023-05-17 10:44:06 --> Total execution time: 0.0181
INFO - 2023-05-17 10:44:10 --> Config Class Initialized
INFO - 2023-05-17 10:44:10 --> Config Class Initialized
INFO - 2023-05-17 10:44:10 --> Config Class Initialized
INFO - 2023-05-17 10:44:10 --> Hooks Class Initialized
INFO - 2023-05-17 10:44:10 --> Hooks Class Initialized
INFO - 2023-05-17 10:44:10 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:44:10 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:44:10 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:44:10 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:44:10 --> Utf8 Class Initialized
INFO - 2023-05-17 10:44:10 --> Utf8 Class Initialized
INFO - 2023-05-17 10:44:10 --> Utf8 Class Initialized
INFO - 2023-05-17 10:44:10 --> URI Class Initialized
INFO - 2023-05-17 10:44:10 --> URI Class Initialized
INFO - 2023-05-17 10:44:10 --> URI Class Initialized
INFO - 2023-05-17 10:44:10 --> Router Class Initialized
INFO - 2023-05-17 10:44:10 --> Router Class Initialized
INFO - 2023-05-17 10:44:10 --> Output Class Initialized
INFO - 2023-05-17 10:44:10 --> Router Class Initialized
INFO - 2023-05-17 10:44:10 --> Output Class Initialized
INFO - 2023-05-17 10:44:10 --> Security Class Initialized
INFO - 2023-05-17 10:44:10 --> Output Class Initialized
INFO - 2023-05-17 10:44:10 --> Security Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:44:10 --> Security Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:44:10 --> Input Class Initialized
INFO - 2023-05-17 10:44:10 --> Input Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:44:10 --> Language Class Initialized
INFO - 2023-05-17 10:44:10 --> Language Class Initialized
INFO - 2023-05-17 10:44:10 --> Input Class Initialized
INFO - 2023-05-17 10:44:10 --> Language Class Initialized
INFO - 2023-05-17 10:44:10 --> Loader Class Initialized
INFO - 2023-05-17 10:44:10 --> Loader Class Initialized
INFO - 2023-05-17 10:44:10 --> Controller Class Initialized
INFO - 2023-05-17 10:44:10 --> Controller Class Initialized
INFO - 2023-05-17 10:44:10 --> Loader Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:44:10 --> Controller Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:44:10 --> Database Driver Class Initialized
INFO - 2023-05-17 10:44:10 --> Database Driver Class Initialized
INFO - 2023-05-17 10:44:10 --> Database Driver Class Initialized
INFO - 2023-05-17 10:44:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:44:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:44:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:44:10 --> Final output sent to browser
DEBUG - 2023-05-17 10:44:10 --> Total execution time: 0.0195
INFO - 2023-05-17 10:44:10 --> Final output sent to browser
INFO - 2023-05-17 10:44:10 --> Final output sent to browser
DEBUG - 2023-05-17 10:44:10 --> Total execution time: 0.0208
DEBUG - 2023-05-17 10:44:10 --> Total execution time: 0.0207
INFO - 2023-05-17 10:44:10 --> Config Class Initialized
INFO - 2023-05-17 10:44:10 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:44:10 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:44:10 --> Utf8 Class Initialized
INFO - 2023-05-17 10:44:10 --> URI Class Initialized
INFO - 2023-05-17 10:44:10 --> Config Class Initialized
INFO - 2023-05-17 10:44:10 --> Config Class Initialized
INFO - 2023-05-17 10:44:10 --> Hooks Class Initialized
INFO - 2023-05-17 10:44:10 --> Router Class Initialized
INFO - 2023-05-17 10:44:10 --> Hooks Class Initialized
INFO - 2023-05-17 10:44:10 --> Output Class Initialized
INFO - 2023-05-17 10:44:10 --> Security Class Initialized
DEBUG - 2023-05-17 10:44:10 --> UTF-8 Support Enabled
DEBUG - 2023-05-17 10:44:10 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:44:10 --> Utf8 Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:44:10 --> Utf8 Class Initialized
INFO - 2023-05-17 10:44:10 --> URI Class Initialized
INFO - 2023-05-17 10:44:10 --> Input Class Initialized
INFO - 2023-05-17 10:44:10 --> URI Class Initialized
INFO - 2023-05-17 10:44:10 --> Router Class Initialized
INFO - 2023-05-17 10:44:10 --> Language Class Initialized
INFO - 2023-05-17 10:44:10 --> Router Class Initialized
INFO - 2023-05-17 10:44:10 --> Output Class Initialized
INFO - 2023-05-17 10:44:10 --> Output Class Initialized
INFO - 2023-05-17 10:44:10 --> Loader Class Initialized
INFO - 2023-05-17 10:44:10 --> Security Class Initialized
INFO - 2023-05-17 10:44:10 --> Security Class Initialized
INFO - 2023-05-17 10:44:10 --> Controller Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-17 10:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:44:10 --> Input Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:44:10 --> Language Class Initialized
INFO - 2023-05-17 10:44:10 --> Input Class Initialized
INFO - 2023-05-17 10:44:10 --> Database Driver Class Initialized
INFO - 2023-05-17 10:44:10 --> Language Class Initialized
INFO - 2023-05-17 10:44:10 --> Loader Class Initialized
INFO - 2023-05-17 10:44:10 --> Loader Class Initialized
INFO - 2023-05-17 10:44:10 --> Controller Class Initialized
INFO - 2023-05-17 10:44:10 --> Controller Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-17 10:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:44:10 --> Database Driver Class Initialized
INFO - 2023-05-17 10:44:10 --> Database Driver Class Initialized
INFO - 2023-05-17 10:44:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:44:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:44:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:44:10 --> Final output sent to browser
INFO - 2023-05-17 10:44:10 --> Final output sent to browser
DEBUG - 2023-05-17 10:44:10 --> Total execution time: 0.0144
DEBUG - 2023-05-17 10:44:10 --> Total execution time: 0.0144
INFO - 2023-05-17 10:44:10 --> Final output sent to browser
INFO - 2023-05-17 10:44:10 --> Config Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Total execution time: 0.0198
INFO - 2023-05-17 10:44:10 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:44:10 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:44:10 --> Utf8 Class Initialized
INFO - 2023-05-17 10:44:10 --> URI Class Initialized
INFO - 2023-05-17 10:44:10 --> Router Class Initialized
INFO - 2023-05-17 10:44:10 --> Output Class Initialized
INFO - 2023-05-17 10:44:10 --> Security Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:44:10 --> Input Class Initialized
INFO - 2023-05-17 10:44:10 --> Language Class Initialized
INFO - 2023-05-17 10:44:10 --> Loader Class Initialized
INFO - 2023-05-17 10:44:10 --> Controller Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:44:10 --> Database Driver Class Initialized
INFO - 2023-05-17 10:44:10 --> Model "Cluster_model" initialized
INFO - 2023-05-17 10:44:10 --> Config Class Initialized
INFO - 2023-05-17 10:44:10 --> Hooks Class Initialized
DEBUG - 2023-05-17 10:44:10 --> UTF-8 Support Enabled
INFO - 2023-05-17 10:44:10 --> Utf8 Class Initialized
INFO - 2023-05-17 10:44:10 --> URI Class Initialized
INFO - 2023-05-17 10:44:10 --> Router Class Initialized
INFO - 2023-05-17 10:44:10 --> Output Class Initialized
INFO - 2023-05-17 10:44:10 --> Security Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-17 10:44:10 --> Input Class Initialized
INFO - 2023-05-17 10:44:10 --> Language Class Initialized
INFO - 2023-05-17 10:44:10 --> Loader Class Initialized
INFO - 2023-05-17 10:44:10 --> Controller Class Initialized
DEBUG - 2023-05-17 10:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-17 10:44:10 --> Database Driver Class Initialized
INFO - 2023-05-17 10:44:10 --> Model "Cluster_model" initialized
