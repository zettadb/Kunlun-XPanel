<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-22 07:12:28 --> Config Class Initialized
INFO - 2023-03-22 07:12:28 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:12:28 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:12:28 --> Utf8 Class Initialized
INFO - 2023-03-22 07:12:28 --> URI Class Initialized
INFO - 2023-03-22 07:12:28 --> Router Class Initialized
INFO - 2023-03-22 07:12:28 --> Output Class Initialized
INFO - 2023-03-22 07:12:28 --> Security Class Initialized
DEBUG - 2023-03-22 07:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:12:28 --> Input Class Initialized
INFO - 2023-03-22 07:12:28 --> Language Class Initialized
INFO - 2023-03-22 07:12:28 --> Loader Class Initialized
INFO - 2023-03-22 07:12:28 --> Controller Class Initialized
INFO - 2023-03-22 07:12:28 --> Helper loaded: form_helper
INFO - 2023-03-22 07:12:28 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:12:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:12:28 --> Model "Change_model" initialized
INFO - 2023-03-22 07:12:28 --> Model "Grafana_model" initialized
INFO - 2023-03-22 07:12:28 --> Final output sent to browser
DEBUG - 2023-03-22 07:12:28 --> Total execution time: 0.0458
INFO - 2023-03-22 07:12:28 --> Config Class Initialized
INFO - 2023-03-22 07:12:28 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:12:28 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:12:28 --> Utf8 Class Initialized
INFO - 2023-03-22 07:12:28 --> URI Class Initialized
INFO - 2023-03-22 07:12:28 --> Router Class Initialized
INFO - 2023-03-22 07:12:28 --> Output Class Initialized
INFO - 2023-03-22 07:12:28 --> Security Class Initialized
DEBUG - 2023-03-22 07:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:12:28 --> Input Class Initialized
INFO - 2023-03-22 07:12:28 --> Language Class Initialized
INFO - 2023-03-22 07:12:28 --> Loader Class Initialized
INFO - 2023-03-22 07:12:28 --> Controller Class Initialized
INFO - 2023-03-22 07:12:28 --> Helper loaded: form_helper
INFO - 2023-03-22 07:12:28 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:12:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:12:28 --> Final output sent to browser
DEBUG - 2023-03-22 07:12:28 --> Total execution time: 0.0058
INFO - 2023-03-22 07:12:28 --> Config Class Initialized
INFO - 2023-03-22 07:12:28 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:12:28 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:12:28 --> Utf8 Class Initialized
INFO - 2023-03-22 07:12:28 --> URI Class Initialized
INFO - 2023-03-22 07:12:28 --> Router Class Initialized
INFO - 2023-03-22 07:12:28 --> Output Class Initialized
INFO - 2023-03-22 07:12:28 --> Security Class Initialized
DEBUG - 2023-03-22 07:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:12:28 --> Input Class Initialized
INFO - 2023-03-22 07:12:28 --> Language Class Initialized
INFO - 2023-03-22 07:12:28 --> Loader Class Initialized
INFO - 2023-03-22 07:12:28 --> Controller Class Initialized
INFO - 2023-03-22 07:12:28 --> Helper loaded: form_helper
INFO - 2023-03-22 07:12:28 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:12:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:12:28 --> Database Driver Class Initialized
INFO - 2023-03-22 07:12:28 --> Model "Login_model" initialized
INFO - 2023-03-22 07:12:28 --> Final output sent to browser
DEBUG - 2023-03-22 07:12:28 --> Total execution time: 0.0614
INFO - 2023-03-22 07:12:38 --> Config Class Initialized
INFO - 2023-03-22 07:12:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:12:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:12:38 --> Utf8 Class Initialized
INFO - 2023-03-22 07:12:38 --> URI Class Initialized
INFO - 2023-03-22 07:12:38 --> Router Class Initialized
INFO - 2023-03-22 07:12:38 --> Output Class Initialized
INFO - 2023-03-22 07:12:38 --> Security Class Initialized
DEBUG - 2023-03-22 07:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:12:38 --> Input Class Initialized
INFO - 2023-03-22 07:12:38 --> Language Class Initialized
INFO - 2023-03-22 07:12:38 --> Loader Class Initialized
INFO - 2023-03-22 07:12:38 --> Controller Class Initialized
INFO - 2023-03-22 07:12:38 --> Helper loaded: form_helper
INFO - 2023-03-22 07:12:38 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:12:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:12:38 --> Model "Change_model" initialized
INFO - 2023-03-22 07:12:38 --> Model "Grafana_model" initialized
INFO - 2023-03-22 07:12:38 --> Final output sent to browser
DEBUG - 2023-03-22 07:12:38 --> Total execution time: 0.0272
INFO - 2023-03-22 07:12:38 --> Config Class Initialized
INFO - 2023-03-22 07:12:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:12:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:12:38 --> Utf8 Class Initialized
INFO - 2023-03-22 07:12:38 --> URI Class Initialized
INFO - 2023-03-22 07:12:38 --> Router Class Initialized
INFO - 2023-03-22 07:12:38 --> Output Class Initialized
INFO - 2023-03-22 07:12:38 --> Security Class Initialized
DEBUG - 2023-03-22 07:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:12:38 --> Input Class Initialized
INFO - 2023-03-22 07:12:38 --> Language Class Initialized
INFO - 2023-03-22 07:12:38 --> Loader Class Initialized
INFO - 2023-03-22 07:12:38 --> Controller Class Initialized
INFO - 2023-03-22 07:12:38 --> Helper loaded: form_helper
INFO - 2023-03-22 07:12:38 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:12:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:12:38 --> Final output sent to browser
DEBUG - 2023-03-22 07:12:38 --> Total execution time: 0.0028
INFO - 2023-03-22 07:12:38 --> Config Class Initialized
INFO - 2023-03-22 07:12:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:12:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:12:38 --> Utf8 Class Initialized
INFO - 2023-03-22 07:12:38 --> URI Class Initialized
INFO - 2023-03-22 07:12:38 --> Router Class Initialized
INFO - 2023-03-22 07:12:38 --> Output Class Initialized
INFO - 2023-03-22 07:12:38 --> Security Class Initialized
DEBUG - 2023-03-22 07:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:12:38 --> Input Class Initialized
INFO - 2023-03-22 07:12:38 --> Language Class Initialized
INFO - 2023-03-22 07:12:38 --> Loader Class Initialized
INFO - 2023-03-22 07:12:38 --> Controller Class Initialized
INFO - 2023-03-22 07:12:38 --> Helper loaded: form_helper
INFO - 2023-03-22 07:12:38 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:12:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:12:38 --> Database Driver Class Initialized
INFO - 2023-03-22 07:12:38 --> Model "Login_model" initialized
INFO - 2023-03-22 07:12:38 --> Final output sent to browser
DEBUG - 2023-03-22 07:12:38 --> Total execution time: 0.0104
INFO - 2023-03-22 07:13:01 --> Config Class Initialized
INFO - 2023-03-22 07:13:01 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:01 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:01 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:01 --> URI Class Initialized
INFO - 2023-03-22 07:13:01 --> Router Class Initialized
INFO - 2023-03-22 07:13:01 --> Output Class Initialized
INFO - 2023-03-22 07:13:01 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:01 --> Input Class Initialized
INFO - 2023-03-22 07:13:01 --> Language Class Initialized
INFO - 2023-03-22 07:13:01 --> Loader Class Initialized
INFO - 2023-03-22 07:13:01 --> Controller Class Initialized
INFO - 2023-03-22 07:13:01 --> Helper loaded: form_helper
INFO - 2023-03-22 07:13:01 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:13:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:01 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:01 --> Total execution time: 0.0041
INFO - 2023-03-22 07:13:01 --> Config Class Initialized
INFO - 2023-03-22 07:13:01 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:01 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:01 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:01 --> URI Class Initialized
INFO - 2023-03-22 07:13:01 --> Router Class Initialized
INFO - 2023-03-22 07:13:01 --> Output Class Initialized
INFO - 2023-03-22 07:13:01 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:01 --> Input Class Initialized
INFO - 2023-03-22 07:13:01 --> Language Class Initialized
INFO - 2023-03-22 07:13:01 --> Loader Class Initialized
INFO - 2023-03-22 07:13:01 --> Controller Class Initialized
INFO - 2023-03-22 07:13:01 --> Helper loaded: form_helper
INFO - 2023-03-22 07:13:01 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:13:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:01 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:01 --> Model "Login_model" initialized
INFO - 2023-03-22 07:13:01 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:01 --> Total execution time: 0.0185
INFO - 2023-03-22 07:13:05 --> Config Class Initialized
INFO - 2023-03-22 07:13:05 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:05 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:05 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:05 --> URI Class Initialized
INFO - 2023-03-22 07:13:05 --> Router Class Initialized
INFO - 2023-03-22 07:13:05 --> Output Class Initialized
INFO - 2023-03-22 07:13:05 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:05 --> Input Class Initialized
INFO - 2023-03-22 07:13:05 --> Language Class Initialized
INFO - 2023-03-22 07:13:05 --> Loader Class Initialized
INFO - 2023-03-22 07:13:05 --> Controller Class Initialized
INFO - 2023-03-22 07:13:05 --> Helper loaded: form_helper
INFO - 2023-03-22 07:13:05 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:13:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:05 --> Model "Change_model" initialized
INFO - 2023-03-22 07:13:05 --> Model "Grafana_model" initialized
INFO - 2023-03-22 07:13:05 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:05 --> Total execution time: 0.0294
INFO - 2023-03-22 07:13:05 --> Config Class Initialized
INFO - 2023-03-22 07:13:05 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:05 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:05 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:05 --> URI Class Initialized
INFO - 2023-03-22 07:13:05 --> Router Class Initialized
INFO - 2023-03-22 07:13:05 --> Output Class Initialized
INFO - 2023-03-22 07:13:05 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:05 --> Input Class Initialized
INFO - 2023-03-22 07:13:05 --> Language Class Initialized
INFO - 2023-03-22 07:13:05 --> Loader Class Initialized
INFO - 2023-03-22 07:13:05 --> Controller Class Initialized
INFO - 2023-03-22 07:13:05 --> Helper loaded: form_helper
INFO - 2023-03-22 07:13:05 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:13:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:05 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:05 --> Total execution time: 0.0017
INFO - 2023-03-22 07:13:05 --> Config Class Initialized
INFO - 2023-03-22 07:13:05 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:05 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:05 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:05 --> URI Class Initialized
INFO - 2023-03-22 07:13:05 --> Router Class Initialized
INFO - 2023-03-22 07:13:05 --> Output Class Initialized
INFO - 2023-03-22 07:13:05 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:05 --> Input Class Initialized
INFO - 2023-03-22 07:13:05 --> Language Class Initialized
INFO - 2023-03-22 07:13:05 --> Loader Class Initialized
INFO - 2023-03-22 07:13:05 --> Controller Class Initialized
INFO - 2023-03-22 07:13:05 --> Helper loaded: form_helper
INFO - 2023-03-22 07:13:05 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:13:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:05 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:05 --> Model "Login_model" initialized
INFO - 2023-03-22 07:13:05 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:05 --> Total execution time: 0.0157
INFO - 2023-03-22 07:13:05 --> Config Class Initialized
INFO - 2023-03-22 07:13:05 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:05 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:05 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:05 --> URI Class Initialized
INFO - 2023-03-22 07:13:05 --> Router Class Initialized
INFO - 2023-03-22 07:13:05 --> Output Class Initialized
INFO - 2023-03-22 07:13:05 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:05 --> Input Class Initialized
INFO - 2023-03-22 07:13:05 --> Language Class Initialized
INFO - 2023-03-22 07:13:05 --> Loader Class Initialized
INFO - 2023-03-22 07:13:05 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:05 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:05 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:05 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:05 --> Total execution time: 0.0306
INFO - 2023-03-22 07:13:05 --> Config Class Initialized
INFO - 2023-03-22 07:13:05 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:05 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:05 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:05 --> URI Class Initialized
INFO - 2023-03-22 07:13:05 --> Router Class Initialized
INFO - 2023-03-22 07:13:05 --> Output Class Initialized
INFO - 2023-03-22 07:13:05 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:05 --> Input Class Initialized
INFO - 2023-03-22 07:13:05 --> Language Class Initialized
INFO - 2023-03-22 07:13:05 --> Loader Class Initialized
INFO - 2023-03-22 07:13:05 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:05 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:05 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:05 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:05 --> Total execution time: 0.0139
INFO - 2023-03-22 07:13:06 --> Config Class Initialized
INFO - 2023-03-22 07:13:06 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:06 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:06 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:06 --> URI Class Initialized
INFO - 2023-03-22 07:13:06 --> Router Class Initialized
INFO - 2023-03-22 07:13:06 --> Output Class Initialized
INFO - 2023-03-22 07:13:06 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:06 --> Input Class Initialized
INFO - 2023-03-22 07:13:06 --> Language Class Initialized
INFO - 2023-03-22 07:13:06 --> Loader Class Initialized
INFO - 2023-03-22 07:13:06 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:06 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:06 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:06 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:06 --> Total execution time: 0.0215
INFO - 2023-03-22 07:13:06 --> Config Class Initialized
INFO - 2023-03-22 07:13:06 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:06 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:06 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:06 --> URI Class Initialized
INFO - 2023-03-22 07:13:06 --> Router Class Initialized
INFO - 2023-03-22 07:13:06 --> Output Class Initialized
INFO - 2023-03-22 07:13:06 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:06 --> Input Class Initialized
INFO - 2023-03-22 07:13:06 --> Language Class Initialized
INFO - 2023-03-22 07:13:06 --> Loader Class Initialized
INFO - 2023-03-22 07:13:06 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:06 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:06 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:06 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:06 --> Total execution time: 0.0624
INFO - 2023-03-22 07:13:09 --> Config Class Initialized
INFO - 2023-03-22 07:13:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:09 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:09 --> URI Class Initialized
INFO - 2023-03-22 07:13:09 --> Router Class Initialized
INFO - 2023-03-22 07:13:09 --> Output Class Initialized
INFO - 2023-03-22 07:13:09 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:09 --> Input Class Initialized
INFO - 2023-03-22 07:13:09 --> Language Class Initialized
INFO - 2023-03-22 07:13:09 --> Loader Class Initialized
INFO - 2023-03-22 07:13:09 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:09 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:09 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:09 --> Total execution time: 0.0141
INFO - 2023-03-22 07:13:09 --> Config Class Initialized
INFO - 2023-03-22 07:13:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:09 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:09 --> URI Class Initialized
INFO - 2023-03-22 07:13:09 --> Router Class Initialized
INFO - 2023-03-22 07:13:09 --> Output Class Initialized
INFO - 2023-03-22 07:13:09 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:09 --> Input Class Initialized
INFO - 2023-03-22 07:13:09 --> Language Class Initialized
INFO - 2023-03-22 07:13:09 --> Loader Class Initialized
INFO - 2023-03-22 07:13:09 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:09 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:09 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:09 --> Total execution time: 0.0517
INFO - 2023-03-22 07:13:11 --> Config Class Initialized
INFO - 2023-03-22 07:13:11 --> Config Class Initialized
INFO - 2023-03-22 07:13:11 --> Hooks Class Initialized
INFO - 2023-03-22 07:13:11 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 07:13:11 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:11 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:11 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:11 --> URI Class Initialized
INFO - 2023-03-22 07:13:11 --> URI Class Initialized
INFO - 2023-03-22 07:13:11 --> Router Class Initialized
INFO - 2023-03-22 07:13:11 --> Router Class Initialized
INFO - 2023-03-22 07:13:11 --> Output Class Initialized
INFO - 2023-03-22 07:13:11 --> Output Class Initialized
INFO - 2023-03-22 07:13:11 --> Security Class Initialized
INFO - 2023-03-22 07:13:11 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 07:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:11 --> Input Class Initialized
INFO - 2023-03-22 07:13:11 --> Input Class Initialized
INFO - 2023-03-22 07:13:11 --> Language Class Initialized
INFO - 2023-03-22 07:13:11 --> Language Class Initialized
INFO - 2023-03-22 07:13:11 --> Loader Class Initialized
INFO - 2023-03-22 07:13:11 --> Controller Class Initialized
INFO - 2023-03-22 07:13:11 --> Loader Class Initialized
DEBUG - 2023-03-22 07:13:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:11 --> Controller Class Initialized
INFO - 2023-03-22 07:13:11 --> Database Driver Class Initialized
DEBUG - 2023-03-22 07:13:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:11 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:11 --> Total execution time: 0.0044
INFO - 2023-03-22 07:13:11 --> Config Class Initialized
INFO - 2023-03-22 07:13:11 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:11 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:11 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:11 --> URI Class Initialized
INFO - 2023-03-22 07:13:11 --> Router Class Initialized
INFO - 2023-03-22 07:13:11 --> Output Class Initialized
INFO - 2023-03-22 07:13:11 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:11 --> Input Class Initialized
INFO - 2023-03-22 07:13:11 --> Language Class Initialized
INFO - 2023-03-22 07:13:11 --> Loader Class Initialized
INFO - 2023-03-22 07:13:11 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:11 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:11 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:11 --> Model "Login_model" initialized
INFO - 2023-03-22 07:13:11 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:11 --> Total execution time: 0.0391
INFO - 2023-03-22 07:13:11 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:11 --> Config Class Initialized
INFO - 2023-03-22 07:13:11 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:11 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:11 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:11 --> URI Class Initialized
INFO - 2023-03-22 07:13:11 --> Router Class Initialized
INFO - 2023-03-22 07:13:11 --> Output Class Initialized
INFO - 2023-03-22 07:13:11 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:11 --> Input Class Initialized
INFO - 2023-03-22 07:13:11 --> Language Class Initialized
INFO - 2023-03-22 07:13:11 --> Loader Class Initialized
INFO - 2023-03-22 07:13:11 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:11 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:11 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:11 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:11 --> Total execution time: 0.0444
INFO - 2023-03-22 07:13:11 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:11 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:11 --> Total execution time: 0.0521
INFO - 2023-03-22 07:13:11 --> Config Class Initialized
INFO - 2023-03-22 07:13:11 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:11 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:11 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:11 --> URI Class Initialized
INFO - 2023-03-22 07:13:11 --> Router Class Initialized
INFO - 2023-03-22 07:13:11 --> Output Class Initialized
INFO - 2023-03-22 07:13:11 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:11 --> Input Class Initialized
INFO - 2023-03-22 07:13:11 --> Language Class Initialized
INFO - 2023-03-22 07:13:11 --> Loader Class Initialized
INFO - 2023-03-22 07:13:11 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:11 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:11 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:11 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:11 --> Total execution time: 0.0137
INFO - 2023-03-22 07:13:11 --> Config Class Initialized
INFO - 2023-03-22 07:13:11 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:11 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:11 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:11 --> URI Class Initialized
INFO - 2023-03-22 07:13:11 --> Router Class Initialized
INFO - 2023-03-22 07:13:11 --> Output Class Initialized
INFO - 2023-03-22 07:13:11 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:11 --> Input Class Initialized
INFO - 2023-03-22 07:13:11 --> Language Class Initialized
INFO - 2023-03-22 07:13:11 --> Loader Class Initialized
INFO - 2023-03-22 07:13:11 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:11 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:11 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:12 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:12 --> Total execution time: 0.0104
INFO - 2023-03-22 07:13:15 --> Config Class Initialized
INFO - 2023-03-22 07:13:15 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:15 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:15 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:15 --> URI Class Initialized
INFO - 2023-03-22 07:13:15 --> Router Class Initialized
INFO - 2023-03-22 07:13:15 --> Output Class Initialized
INFO - 2023-03-22 07:13:15 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:15 --> Input Class Initialized
INFO - 2023-03-22 07:13:15 --> Language Class Initialized
INFO - 2023-03-22 07:13:15 --> Loader Class Initialized
INFO - 2023-03-22 07:13:15 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:15 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:15 --> Total execution time: 0.0037
INFO - 2023-03-22 07:13:15 --> Config Class Initialized
INFO - 2023-03-22 07:13:15 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:15 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:15 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:15 --> URI Class Initialized
INFO - 2023-03-22 07:13:15 --> Router Class Initialized
INFO - 2023-03-22 07:13:15 --> Output Class Initialized
INFO - 2023-03-22 07:13:15 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:15 --> Input Class Initialized
INFO - 2023-03-22 07:13:15 --> Language Class Initialized
INFO - 2023-03-22 07:13:15 --> Loader Class Initialized
INFO - 2023-03-22 07:13:15 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:15 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:15 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:15 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:15 --> Total execution time: 0.0548
INFO - 2023-03-22 07:13:15 --> Config Class Initialized
INFO - 2023-03-22 07:13:15 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:15 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:15 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:15 --> URI Class Initialized
INFO - 2023-03-22 07:13:15 --> Router Class Initialized
INFO - 2023-03-22 07:13:15 --> Output Class Initialized
INFO - 2023-03-22 07:13:15 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:15 --> Input Class Initialized
INFO - 2023-03-22 07:13:15 --> Language Class Initialized
INFO - 2023-03-22 07:13:15 --> Loader Class Initialized
INFO - 2023-03-22 07:13:15 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:15 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:15 --> Total execution time: 0.0833
INFO - 2023-03-22 07:13:15 --> Config Class Initialized
INFO - 2023-03-22 07:13:15 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:15 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:15 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:15 --> URI Class Initialized
INFO - 2023-03-22 07:13:15 --> Router Class Initialized
INFO - 2023-03-22 07:13:15 --> Output Class Initialized
INFO - 2023-03-22 07:13:15 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:15 --> Input Class Initialized
INFO - 2023-03-22 07:13:15 --> Language Class Initialized
INFO - 2023-03-22 07:13:15 --> Loader Class Initialized
INFO - 2023-03-22 07:13:15 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:15 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:15 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:15 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:15 --> Total execution time: 0.0552
INFO - 2023-03-22 07:13:36 --> Config Class Initialized
INFO - 2023-03-22 07:13:36 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:36 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:36 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:36 --> URI Class Initialized
INFO - 2023-03-22 07:13:36 --> Router Class Initialized
INFO - 2023-03-22 07:13:36 --> Output Class Initialized
INFO - 2023-03-22 07:13:36 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:36 --> Input Class Initialized
INFO - 2023-03-22 07:13:36 --> Language Class Initialized
INFO - 2023-03-22 07:13:36 --> Loader Class Initialized
INFO - 2023-03-22 07:13:36 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:36 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:36 --> Total execution time: 0.0036
INFO - 2023-03-22 07:13:36 --> Config Class Initialized
INFO - 2023-03-22 07:13:36 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:36 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:36 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:36 --> URI Class Initialized
INFO - 2023-03-22 07:13:36 --> Router Class Initialized
INFO - 2023-03-22 07:13:36 --> Output Class Initialized
INFO - 2023-03-22 07:13:36 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:36 --> Input Class Initialized
INFO - 2023-03-22 07:13:36 --> Language Class Initialized
INFO - 2023-03-22 07:13:36 --> Loader Class Initialized
INFO - 2023-03-22 07:13:36 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:36 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:36 --> Model "Login_model" initialized
INFO - 2023-03-22 07:13:36 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:36 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:36 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:36 --> Total execution time: 0.0361
INFO - 2023-03-22 07:13:36 --> Config Class Initialized
INFO - 2023-03-22 07:13:36 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:36 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:36 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:36 --> URI Class Initialized
INFO - 2023-03-22 07:13:36 --> Router Class Initialized
INFO - 2023-03-22 07:13:36 --> Output Class Initialized
INFO - 2023-03-22 07:13:36 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:36 --> Input Class Initialized
INFO - 2023-03-22 07:13:36 --> Language Class Initialized
INFO - 2023-03-22 07:13:36 --> Loader Class Initialized
INFO - 2023-03-22 07:13:36 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:36 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:36 --> Total execution time: 0.0040
INFO - 2023-03-22 07:13:36 --> Config Class Initialized
INFO - 2023-03-22 07:13:36 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:36 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:36 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:36 --> URI Class Initialized
INFO - 2023-03-22 07:13:36 --> Router Class Initialized
INFO - 2023-03-22 07:13:36 --> Output Class Initialized
INFO - 2023-03-22 07:13:36 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:36 --> Input Class Initialized
INFO - 2023-03-22 07:13:36 --> Language Class Initialized
INFO - 2023-03-22 07:13:36 --> Loader Class Initialized
INFO - 2023-03-22 07:13:36 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:36 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:36 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:36 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:36 --> Total execution time: 0.0204
INFO - 2023-03-22 07:13:41 --> Config Class Initialized
INFO - 2023-03-22 07:13:41 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:13:41 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:13:41 --> Utf8 Class Initialized
INFO - 2023-03-22 07:13:41 --> URI Class Initialized
INFO - 2023-03-22 07:13:41 --> Router Class Initialized
INFO - 2023-03-22 07:13:41 --> Output Class Initialized
INFO - 2023-03-22 07:13:41 --> Security Class Initialized
DEBUG - 2023-03-22 07:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:13:41 --> Input Class Initialized
INFO - 2023-03-22 07:13:41 --> Language Class Initialized
INFO - 2023-03-22 07:13:41 --> Loader Class Initialized
INFO - 2023-03-22 07:13:41 --> Controller Class Initialized
DEBUG - 2023-03-22 07:13:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:13:41 --> Database Driver Class Initialized
INFO - 2023-03-22 07:13:41 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:13:41 --> Final output sent to browser
DEBUG - 2023-03-22 07:13:41 --> Total execution time: 0.0190
INFO - 2023-03-22 07:27:21 --> Config Class Initialized
INFO - 2023-03-22 07:27:21 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:27:21 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:27:21 --> Utf8 Class Initialized
INFO - 2023-03-22 07:27:21 --> URI Class Initialized
INFO - 2023-03-22 07:27:21 --> Router Class Initialized
INFO - 2023-03-22 07:27:21 --> Output Class Initialized
INFO - 2023-03-22 07:27:21 --> Security Class Initialized
DEBUG - 2023-03-22 07:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:27:21 --> Input Class Initialized
INFO - 2023-03-22 07:27:21 --> Language Class Initialized
INFO - 2023-03-22 07:27:21 --> Loader Class Initialized
INFO - 2023-03-22 07:27:21 --> Controller Class Initialized
DEBUG - 2023-03-22 07:27:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:27:21 --> Database Driver Class Initialized
INFO - 2023-03-22 07:27:21 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:27:21 --> Final output sent to browser
DEBUG - 2023-03-22 07:27:21 --> Total execution time: 0.0160
INFO - 2023-03-22 07:27:21 --> Config Class Initialized
INFO - 2023-03-22 07:27:21 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:27:21 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:27:21 --> Utf8 Class Initialized
INFO - 2023-03-22 07:27:21 --> URI Class Initialized
INFO - 2023-03-22 07:27:21 --> Router Class Initialized
INFO - 2023-03-22 07:27:21 --> Output Class Initialized
INFO - 2023-03-22 07:27:21 --> Security Class Initialized
DEBUG - 2023-03-22 07:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:27:21 --> Input Class Initialized
INFO - 2023-03-22 07:27:21 --> Language Class Initialized
INFO - 2023-03-22 07:27:21 --> Loader Class Initialized
INFO - 2023-03-22 07:27:21 --> Controller Class Initialized
DEBUG - 2023-03-22 07:27:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:27:21 --> Database Driver Class Initialized
INFO - 2023-03-22 07:27:21 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:27:21 --> Final output sent to browser
DEBUG - 2023-03-22 07:27:21 --> Total execution time: 0.0554
INFO - 2023-03-22 07:27:29 --> Config Class Initialized
INFO - 2023-03-22 07:27:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:27:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:27:29 --> Utf8 Class Initialized
INFO - 2023-03-22 07:27:29 --> URI Class Initialized
INFO - 2023-03-22 07:27:29 --> Router Class Initialized
INFO - 2023-03-22 07:27:29 --> Output Class Initialized
INFO - 2023-03-22 07:27:29 --> Security Class Initialized
DEBUG - 2023-03-22 07:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:27:29 --> Input Class Initialized
INFO - 2023-03-22 07:27:29 --> Language Class Initialized
INFO - 2023-03-22 07:27:29 --> Loader Class Initialized
INFO - 2023-03-22 07:27:29 --> Controller Class Initialized
DEBUG - 2023-03-22 07:27:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:27:29 --> Database Driver Class Initialized
INFO - 2023-03-22 07:27:29 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:27:29 --> Final output sent to browser
DEBUG - 2023-03-22 07:27:29 --> Total execution time: 0.0935
INFO - 2023-03-22 07:27:29 --> Config Class Initialized
INFO - 2023-03-22 07:27:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:27:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:27:29 --> Utf8 Class Initialized
INFO - 2023-03-22 07:27:29 --> URI Class Initialized
INFO - 2023-03-22 07:27:29 --> Router Class Initialized
INFO - 2023-03-22 07:27:29 --> Output Class Initialized
INFO - 2023-03-22 07:27:29 --> Security Class Initialized
DEBUG - 2023-03-22 07:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:27:29 --> Input Class Initialized
INFO - 2023-03-22 07:27:30 --> Language Class Initialized
INFO - 2023-03-22 07:27:30 --> Loader Class Initialized
INFO - 2023-03-22 07:27:30 --> Controller Class Initialized
DEBUG - 2023-03-22 07:27:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:27:30 --> Database Driver Class Initialized
INFO - 2023-03-22 07:27:30 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:27:30 --> Final output sent to browser
DEBUG - 2023-03-22 07:27:30 --> Total execution time: 0.1400
INFO - 2023-03-22 07:27:40 --> Config Class Initialized
INFO - 2023-03-22 07:27:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:27:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:27:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:27:40 --> URI Class Initialized
INFO - 2023-03-22 07:27:40 --> Router Class Initialized
INFO - 2023-03-22 07:27:40 --> Output Class Initialized
INFO - 2023-03-22 07:27:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:27:40 --> Input Class Initialized
INFO - 2023-03-22 07:27:40 --> Language Class Initialized
INFO - 2023-03-22 07:27:40 --> Loader Class Initialized
INFO - 2023-03-22 07:27:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:27:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:27:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:27:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:27:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:27:40 --> Total execution time: 0.1803
INFO - 2023-03-22 07:27:40 --> Config Class Initialized
INFO - 2023-03-22 07:27:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:27:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:27:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:27:40 --> URI Class Initialized
INFO - 2023-03-22 07:27:40 --> Router Class Initialized
INFO - 2023-03-22 07:27:40 --> Output Class Initialized
INFO - 2023-03-22 07:27:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:27:40 --> Input Class Initialized
INFO - 2023-03-22 07:27:40 --> Language Class Initialized
INFO - 2023-03-22 07:27:40 --> Loader Class Initialized
INFO - 2023-03-22 07:27:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:27:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:27:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:27:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:27:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:27:40 --> Total execution time: 0.0145
INFO - 2023-03-22 07:28:40 --> Config Class Initialized
INFO - 2023-03-22 07:28:40 --> Config Class Initialized
INFO - 2023-03-22 07:28:40 --> Hooks Class Initialized
INFO - 2023-03-22 07:28:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:28:40 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 07:28:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:28:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:28:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:28:40 --> URI Class Initialized
INFO - 2023-03-22 07:28:40 --> URI Class Initialized
INFO - 2023-03-22 07:28:40 --> Router Class Initialized
INFO - 2023-03-22 07:28:40 --> Router Class Initialized
INFO - 2023-03-22 07:28:40 --> Output Class Initialized
INFO - 2023-03-22 07:28:40 --> Output Class Initialized
INFO - 2023-03-22 07:28:40 --> Security Class Initialized
INFO - 2023-03-22 07:28:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 07:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:28:40 --> Input Class Initialized
INFO - 2023-03-22 07:28:40 --> Input Class Initialized
INFO - 2023-03-22 07:28:40 --> Language Class Initialized
INFO - 2023-03-22 07:28:40 --> Language Class Initialized
INFO - 2023-03-22 07:28:40 --> Loader Class Initialized
INFO - 2023-03-22 07:28:40 --> Loader Class Initialized
INFO - 2023-03-22 07:28:40 --> Controller Class Initialized
INFO - 2023-03-22 07:28:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:28:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 07:28:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:28:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:28:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:28:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:28:40 --> Model "Login_model" initialized
INFO - 2023-03-22 07:28:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:28:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:28:40 --> Total execution time: 0.0150
INFO - 2023-03-22 07:28:40 --> Config Class Initialized
INFO - 2023-03-22 07:28:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:28:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:28:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:28:40 --> URI Class Initialized
INFO - 2023-03-22 07:28:40 --> Router Class Initialized
INFO - 2023-03-22 07:28:40 --> Output Class Initialized
INFO - 2023-03-22 07:28:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:28:40 --> Input Class Initialized
INFO - 2023-03-22 07:28:40 --> Language Class Initialized
INFO - 2023-03-22 07:28:40 --> Loader Class Initialized
INFO - 2023-03-22 07:28:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:28:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:28:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:28:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:28:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:28:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:28:40 --> Total execution time: 0.0176
ERROR - 2023-03-22 07:28:40 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 07:28:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 07:29:40 --> Config Class Initialized
INFO - 2023-03-22 07:29:40 --> Config Class Initialized
INFO - 2023-03-22 07:29:40 --> Hooks Class Initialized
INFO - 2023-03-22 07:29:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:29:40 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 07:29:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:29:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:29:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:29:40 --> URI Class Initialized
INFO - 2023-03-22 07:29:40 --> URI Class Initialized
INFO - 2023-03-22 07:29:40 --> Router Class Initialized
INFO - 2023-03-22 07:29:40 --> Router Class Initialized
INFO - 2023-03-22 07:29:40 --> Output Class Initialized
INFO - 2023-03-22 07:29:40 --> Output Class Initialized
INFO - 2023-03-22 07:29:40 --> Security Class Initialized
INFO - 2023-03-22 07:29:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 07:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:29:40 --> Input Class Initialized
INFO - 2023-03-22 07:29:40 --> Input Class Initialized
INFO - 2023-03-22 07:29:40 --> Language Class Initialized
INFO - 2023-03-22 07:29:40 --> Language Class Initialized
INFO - 2023-03-22 07:29:40 --> Loader Class Initialized
INFO - 2023-03-22 07:29:40 --> Loader Class Initialized
INFO - 2023-03-22 07:29:40 --> Controller Class Initialized
INFO - 2023-03-22 07:29:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:29:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 07:29:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:29:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:29:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:29:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:29:40 --> Model "Login_model" initialized
INFO - 2023-03-22 07:29:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:29:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:29:40 --> Total execution time: 0.0209
INFO - 2023-03-22 07:29:40 --> Config Class Initialized
INFO - 2023-03-22 07:29:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:29:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:29:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:29:40 --> URI Class Initialized
INFO - 2023-03-22 07:29:40 --> Router Class Initialized
INFO - 2023-03-22 07:29:40 --> Output Class Initialized
INFO - 2023-03-22 07:29:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:29:40 --> Input Class Initialized
INFO - 2023-03-22 07:29:40 --> Language Class Initialized
INFO - 2023-03-22 07:29:40 --> Loader Class Initialized
INFO - 2023-03-22 07:29:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:29:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:29:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:29:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:29:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:29:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:29:40 --> Total execution time: 0.0129
ERROR - 2023-03-22 07:29:40 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 07:29:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 07:30:40 --> Config Class Initialized
INFO - 2023-03-22 07:30:40 --> Config Class Initialized
INFO - 2023-03-22 07:30:40 --> Hooks Class Initialized
INFO - 2023-03-22 07:30:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 07:30:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:30:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:30:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:30:40 --> URI Class Initialized
INFO - 2023-03-22 07:30:40 --> URI Class Initialized
INFO - 2023-03-22 07:30:40 --> Router Class Initialized
INFO - 2023-03-22 07:30:40 --> Router Class Initialized
INFO - 2023-03-22 07:30:40 --> Output Class Initialized
INFO - 2023-03-22 07:30:40 --> Output Class Initialized
INFO - 2023-03-22 07:30:40 --> Security Class Initialized
INFO - 2023-03-22 07:30:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 07:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:30:40 --> Input Class Initialized
INFO - 2023-03-22 07:30:40 --> Input Class Initialized
INFO - 2023-03-22 07:30:40 --> Language Class Initialized
INFO - 2023-03-22 07:30:40 --> Language Class Initialized
INFO - 2023-03-22 07:30:40 --> Loader Class Initialized
INFO - 2023-03-22 07:30:40 --> Loader Class Initialized
INFO - 2023-03-22 07:30:40 --> Controller Class Initialized
INFO - 2023-03-22 07:30:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:30:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 07:30:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:30:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:30:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:30:40 --> Model "Login_model" initialized
INFO - 2023-03-22 07:30:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:30:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:30:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:30:40 --> Total execution time: 0.0173
INFO - 2023-03-22 07:30:40 --> Config Class Initialized
INFO - 2023-03-22 07:30:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:30:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:30:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:30:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:30:40 --> URI Class Initialized
INFO - 2023-03-22 07:30:40 --> Router Class Initialized
INFO - 2023-03-22 07:30:40 --> Output Class Initialized
INFO - 2023-03-22 07:30:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:30:40 --> Input Class Initialized
INFO - 2023-03-22 07:30:40 --> Language Class Initialized
INFO - 2023-03-22 07:30:40 --> Loader Class Initialized
INFO - 2023-03-22 07:30:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:30:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:30:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:30:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:30:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:30:40 --> Total execution time: 0.0519
ERROR - 2023-03-22 07:30:40 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 07:30:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 07:31:40 --> Config Class Initialized
INFO - 2023-03-22 07:31:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:31:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:31:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:31:40 --> URI Class Initialized
INFO - 2023-03-22 07:31:40 --> Router Class Initialized
INFO - 2023-03-22 07:31:40 --> Output Class Initialized
INFO - 2023-03-22 07:31:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:31:40 --> Input Class Initialized
INFO - 2023-03-22 07:31:40 --> Config Class Initialized
INFO - 2023-03-22 07:31:40 --> Language Class Initialized
INFO - 2023-03-22 07:31:40 --> Hooks Class Initialized
INFO - 2023-03-22 07:31:40 --> Loader Class Initialized
DEBUG - 2023-03-22 07:31:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:31:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:31:40 --> Controller Class Initialized
INFO - 2023-03-22 07:31:40 --> URI Class Initialized
DEBUG - 2023-03-22 07:31:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:31:40 --> Router Class Initialized
INFO - 2023-03-22 07:31:40 --> Output Class Initialized
INFO - 2023-03-22 07:31:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:31:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:31:40 --> Input Class Initialized
INFO - 2023-03-22 07:31:40 --> Language Class Initialized
INFO - 2023-03-22 07:31:40 --> Loader Class Initialized
INFO - 2023-03-22 07:31:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:31:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:31:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:31:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:31:40 --> Model "Login_model" initialized
INFO - 2023-03-22 07:31:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:31:40 --> Total execution time: 0.0158
INFO - 2023-03-22 07:31:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:31:40 --> Config Class Initialized
INFO - 2023-03-22 07:31:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:31:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:31:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:31:40 --> URI Class Initialized
INFO - 2023-03-22 07:31:40 --> Router Class Initialized
INFO - 2023-03-22 07:31:40 --> Output Class Initialized
INFO - 2023-03-22 07:31:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:31:40 --> Input Class Initialized
INFO - 2023-03-22 07:31:40 --> Language Class Initialized
INFO - 2023-03-22 07:31:40 --> Loader Class Initialized
INFO - 2023-03-22 07:31:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:31:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:31:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:31:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:31:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:31:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:31:40 --> Total execution time: 0.0247
ERROR - 2023-03-22 07:31:40 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 07:31:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 07:32:40 --> Config Class Initialized
INFO - 2023-03-22 07:32:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:32:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:32:40 --> Config Class Initialized
INFO - 2023-03-22 07:32:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:32:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:32:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:32:40 --> URI Class Initialized
INFO - 2023-03-22 07:32:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:32:40 --> URI Class Initialized
INFO - 2023-03-22 07:32:40 --> Router Class Initialized
INFO - 2023-03-22 07:32:40 --> Router Class Initialized
INFO - 2023-03-22 07:32:40 --> Output Class Initialized
INFO - 2023-03-22 07:32:40 --> Output Class Initialized
INFO - 2023-03-22 07:32:40 --> Security Class Initialized
INFO - 2023-03-22 07:32:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 07:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:32:40 --> Input Class Initialized
INFO - 2023-03-22 07:32:40 --> Input Class Initialized
INFO - 2023-03-22 07:32:40 --> Language Class Initialized
INFO - 2023-03-22 07:32:40 --> Language Class Initialized
INFO - 2023-03-22 07:32:40 --> Loader Class Initialized
INFO - 2023-03-22 07:32:40 --> Loader Class Initialized
INFO - 2023-03-22 07:32:40 --> Controller Class Initialized
INFO - 2023-03-22 07:32:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:32:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 07:32:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:32:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:32:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:32:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:32:40 --> Model "Login_model" initialized
INFO - 2023-03-22 07:32:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:32:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:32:40 --> Total execution time: 0.0156
INFO - 2023-03-22 07:32:40 --> Config Class Initialized
INFO - 2023-03-22 07:32:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:32:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:32:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:32:40 --> URI Class Initialized
INFO - 2023-03-22 07:32:40 --> Router Class Initialized
INFO - 2023-03-22 07:32:40 --> Output Class Initialized
INFO - 2023-03-22 07:32:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:32:40 --> Input Class Initialized
INFO - 2023-03-22 07:32:40 --> Language Class Initialized
INFO - 2023-03-22 07:32:40 --> Loader Class Initialized
INFO - 2023-03-22 07:32:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:32:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:32:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:32:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:32:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:32:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:32:40 --> Total execution time: 0.0139
ERROR - 2023-03-22 07:32:40 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 07:32:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 07:33:08 --> Config Class Initialized
INFO - 2023-03-22 07:33:08 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:33:08 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:33:08 --> Utf8 Class Initialized
INFO - 2023-03-22 07:33:08 --> URI Class Initialized
INFO - 2023-03-22 07:33:08 --> Router Class Initialized
INFO - 2023-03-22 07:33:08 --> Output Class Initialized
INFO - 2023-03-22 07:33:08 --> Security Class Initialized
DEBUG - 2023-03-22 07:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:33:08 --> Input Class Initialized
INFO - 2023-03-22 07:33:08 --> Language Class Initialized
INFO - 2023-03-22 07:33:08 --> Loader Class Initialized
INFO - 2023-03-22 07:33:08 --> Controller Class Initialized
DEBUG - 2023-03-22 07:33:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:33:08 --> Database Driver Class Initialized
INFO - 2023-03-22 07:33:08 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:33:08 --> Final output sent to browser
DEBUG - 2023-03-22 07:33:08 --> Total execution time: 0.0964
INFO - 2023-03-22 07:33:08 --> Config Class Initialized
INFO - 2023-03-22 07:33:08 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:33:08 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:33:08 --> Utf8 Class Initialized
INFO - 2023-03-22 07:33:08 --> URI Class Initialized
INFO - 2023-03-22 07:33:08 --> Router Class Initialized
INFO - 2023-03-22 07:33:08 --> Output Class Initialized
INFO - 2023-03-22 07:33:08 --> Security Class Initialized
DEBUG - 2023-03-22 07:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:33:08 --> Input Class Initialized
INFO - 2023-03-22 07:33:08 --> Language Class Initialized
INFO - 2023-03-22 07:33:08 --> Loader Class Initialized
INFO - 2023-03-22 07:33:08 --> Controller Class Initialized
DEBUG - 2023-03-22 07:33:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:33:08 --> Database Driver Class Initialized
INFO - 2023-03-22 07:33:08 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:33:08 --> Final output sent to browser
DEBUG - 2023-03-22 07:33:08 --> Total execution time: 0.0134
INFO - 2023-03-22 07:33:19 --> Config Class Initialized
INFO - 2023-03-22 07:33:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:33:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:33:19 --> Utf8 Class Initialized
INFO - 2023-03-22 07:33:19 --> URI Class Initialized
INFO - 2023-03-22 07:33:19 --> Router Class Initialized
INFO - 2023-03-22 07:33:19 --> Output Class Initialized
INFO - 2023-03-22 07:33:19 --> Security Class Initialized
DEBUG - 2023-03-22 07:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:33:19 --> Input Class Initialized
INFO - 2023-03-22 07:33:19 --> Language Class Initialized
INFO - 2023-03-22 07:33:19 --> Loader Class Initialized
INFO - 2023-03-22 07:33:19 --> Controller Class Initialized
DEBUG - 2023-03-22 07:33:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:33:19 --> Database Driver Class Initialized
INFO - 2023-03-22 07:33:19 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:33:19 --> Final output sent to browser
DEBUG - 2023-03-22 07:33:19 --> Total execution time: 0.0160
INFO - 2023-03-22 07:33:19 --> Config Class Initialized
INFO - 2023-03-22 07:33:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:33:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:33:19 --> Utf8 Class Initialized
INFO - 2023-03-22 07:33:19 --> URI Class Initialized
INFO - 2023-03-22 07:33:19 --> Router Class Initialized
INFO - 2023-03-22 07:33:19 --> Output Class Initialized
INFO - 2023-03-22 07:33:19 --> Security Class Initialized
DEBUG - 2023-03-22 07:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:33:19 --> Input Class Initialized
INFO - 2023-03-22 07:33:19 --> Language Class Initialized
INFO - 2023-03-22 07:33:19 --> Loader Class Initialized
INFO - 2023-03-22 07:33:19 --> Controller Class Initialized
DEBUG - 2023-03-22 07:33:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:33:19 --> Database Driver Class Initialized
INFO - 2023-03-22 07:33:19 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:33:19 --> Final output sent to browser
DEBUG - 2023-03-22 07:33:19 --> Total execution time: 0.0123
INFO - 2023-03-22 07:34:09 --> Config Class Initialized
INFO - 2023-03-22 07:34:09 --> Config Class Initialized
INFO - 2023-03-22 07:34:09 --> Hooks Class Initialized
INFO - 2023-03-22 07:34:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:34:09 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 07:34:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:34:09 --> Utf8 Class Initialized
INFO - 2023-03-22 07:34:09 --> Utf8 Class Initialized
INFO - 2023-03-22 07:34:09 --> URI Class Initialized
INFO - 2023-03-22 07:34:09 --> URI Class Initialized
INFO - 2023-03-22 07:34:09 --> Router Class Initialized
INFO - 2023-03-22 07:34:09 --> Router Class Initialized
INFO - 2023-03-22 07:34:09 --> Output Class Initialized
INFO - 2023-03-22 07:34:09 --> Output Class Initialized
INFO - 2023-03-22 07:34:09 --> Security Class Initialized
INFO - 2023-03-22 07:34:09 --> Security Class Initialized
DEBUG - 2023-03-22 07:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 07:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:34:09 --> Input Class Initialized
INFO - 2023-03-22 07:34:09 --> Input Class Initialized
INFO - 2023-03-22 07:34:09 --> Language Class Initialized
INFO - 2023-03-22 07:34:09 --> Language Class Initialized
INFO - 2023-03-22 07:34:09 --> Loader Class Initialized
INFO - 2023-03-22 07:34:09 --> Loader Class Initialized
INFO - 2023-03-22 07:34:09 --> Controller Class Initialized
INFO - 2023-03-22 07:34:09 --> Controller Class Initialized
DEBUG - 2023-03-22 07:34:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 07:34:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:34:09 --> Database Driver Class Initialized
INFO - 2023-03-22 07:34:09 --> Database Driver Class Initialized
INFO - 2023-03-22 07:34:09 --> Model "Login_model" initialized
INFO - 2023-03-22 07:34:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:34:09 --> Final output sent to browser
INFO - 2023-03-22 07:34:09 --> Database Driver Class Initialized
DEBUG - 2023-03-22 07:34:09 --> Total execution time: 0.0223
INFO - 2023-03-22 07:34:09 --> Config Class Initialized
INFO - 2023-03-22 07:34:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:34:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:34:09 --> Utf8 Class Initialized
INFO - 2023-03-22 07:34:09 --> URI Class Initialized
INFO - 2023-03-22 07:34:09 --> Router Class Initialized
INFO - 2023-03-22 07:34:09 --> Output Class Initialized
INFO - 2023-03-22 07:34:09 --> Security Class Initialized
DEBUG - 2023-03-22 07:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:34:09 --> Input Class Initialized
INFO - 2023-03-22 07:34:09 --> Language Class Initialized
INFO - 2023-03-22 07:34:09 --> Loader Class Initialized
INFO - 2023-03-22 07:34:09 --> Controller Class Initialized
DEBUG - 2023-03-22 07:34:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:34:09 --> Database Driver Class Initialized
INFO - 2023-03-22 07:34:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:34:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:34:09 --> Final output sent to browser
DEBUG - 2023-03-22 07:34:09 --> Total execution time: 0.0124
ERROR - 2023-03-22 07:34:09 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 07:34:09 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 07:35:09 --> Config Class Initialized
INFO - 2023-03-22 07:35:09 --> Config Class Initialized
INFO - 2023-03-22 07:35:09 --> Hooks Class Initialized
INFO - 2023-03-22 07:35:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:09 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 07:35:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:09 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:09 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:09 --> URI Class Initialized
INFO - 2023-03-22 07:35:09 --> URI Class Initialized
INFO - 2023-03-22 07:35:09 --> Router Class Initialized
INFO - 2023-03-22 07:35:09 --> Router Class Initialized
INFO - 2023-03-22 07:35:09 --> Output Class Initialized
INFO - 2023-03-22 07:35:09 --> Output Class Initialized
INFO - 2023-03-22 07:35:09 --> Security Class Initialized
INFO - 2023-03-22 07:35:09 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 07:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:09 --> Input Class Initialized
INFO - 2023-03-22 07:35:09 --> Input Class Initialized
INFO - 2023-03-22 07:35:09 --> Language Class Initialized
INFO - 2023-03-22 07:35:09 --> Language Class Initialized
INFO - 2023-03-22 07:35:09 --> Loader Class Initialized
INFO - 2023-03-22 07:35:09 --> Loader Class Initialized
INFO - 2023-03-22 07:35:09 --> Controller Class Initialized
INFO - 2023-03-22 07:35:09 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 07:35:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:09 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:09 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:09 --> Model "Login_model" initialized
INFO - 2023-03-22 07:35:09 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:09 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:09 --> Total execution time: 0.0529
INFO - 2023-03-22 07:35:09 --> Config Class Initialized
INFO - 2023-03-22 07:35:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:09 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:09 --> URI Class Initialized
INFO - 2023-03-22 07:35:09 --> Router Class Initialized
INFO - 2023-03-22 07:35:09 --> Output Class Initialized
INFO - 2023-03-22 07:35:09 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:09 --> Input Class Initialized
INFO - 2023-03-22 07:35:09 --> Language Class Initialized
INFO - 2023-03-22 07:35:09 --> Loader Class Initialized
INFO - 2023-03-22 07:35:09 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:09 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:09 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:09 --> Total execution time: 0.0130
ERROR - 2023-03-22 07:35:09 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 07:35:09 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 07:35:27 --> Config Class Initialized
INFO - 2023-03-22 07:35:27 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:27 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:27 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:27 --> URI Class Initialized
INFO - 2023-03-22 07:35:27 --> Router Class Initialized
INFO - 2023-03-22 07:35:27 --> Output Class Initialized
INFO - 2023-03-22 07:35:27 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:27 --> Input Class Initialized
INFO - 2023-03-22 07:35:27 --> Language Class Initialized
INFO - 2023-03-22 07:35:27 --> Loader Class Initialized
INFO - 2023-03-22 07:35:27 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:27 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:27 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:27 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:27 --> Total execution time: 0.0285
INFO - 2023-03-22 07:35:27 --> Config Class Initialized
INFO - 2023-03-22 07:35:27 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:27 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:27 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:27 --> URI Class Initialized
INFO - 2023-03-22 07:35:27 --> Router Class Initialized
INFO - 2023-03-22 07:35:27 --> Output Class Initialized
INFO - 2023-03-22 07:35:27 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:27 --> Input Class Initialized
INFO - 2023-03-22 07:35:27 --> Language Class Initialized
INFO - 2023-03-22 07:35:27 --> Loader Class Initialized
INFO - 2023-03-22 07:35:27 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:27 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:27 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:27 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:27 --> Total execution time: 0.0517
INFO - 2023-03-22 07:35:29 --> Config Class Initialized
INFO - 2023-03-22 07:35:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:29 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:29 --> URI Class Initialized
INFO - 2023-03-22 07:35:29 --> Router Class Initialized
INFO - 2023-03-22 07:35:29 --> Output Class Initialized
INFO - 2023-03-22 07:35:29 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:29 --> Input Class Initialized
INFO - 2023-03-22 07:35:29 --> Language Class Initialized
INFO - 2023-03-22 07:35:29 --> Loader Class Initialized
INFO - 2023-03-22 07:35:29 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:29 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:29 --> Total execution time: 0.0621
INFO - 2023-03-22 07:35:29 --> Config Class Initialized
INFO - 2023-03-22 07:35:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:29 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:29 --> URI Class Initialized
INFO - 2023-03-22 07:35:29 --> Router Class Initialized
INFO - 2023-03-22 07:35:29 --> Output Class Initialized
INFO - 2023-03-22 07:35:29 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:29 --> Input Class Initialized
INFO - 2023-03-22 07:35:29 --> Language Class Initialized
INFO - 2023-03-22 07:35:29 --> Loader Class Initialized
INFO - 2023-03-22 07:35:29 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:29 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:29 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:29 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:29 --> Total execution time: 0.0559
INFO - 2023-03-22 07:35:33 --> Config Class Initialized
INFO - 2023-03-22 07:35:33 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:33 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:33 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:33 --> URI Class Initialized
INFO - 2023-03-22 07:35:33 --> Router Class Initialized
INFO - 2023-03-22 07:35:33 --> Output Class Initialized
INFO - 2023-03-22 07:35:33 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:33 --> Input Class Initialized
INFO - 2023-03-22 07:35:33 --> Language Class Initialized
INFO - 2023-03-22 07:35:33 --> Loader Class Initialized
INFO - 2023-03-22 07:35:33 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:33 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:33 --> Total execution time: 0.0039
INFO - 2023-03-22 07:35:33 --> Config Class Initialized
INFO - 2023-03-22 07:35:33 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:33 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:33 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:33 --> URI Class Initialized
INFO - 2023-03-22 07:35:33 --> Router Class Initialized
INFO - 2023-03-22 07:35:33 --> Output Class Initialized
INFO - 2023-03-22 07:35:33 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:33 --> Input Class Initialized
INFO - 2023-03-22 07:35:33 --> Language Class Initialized
INFO - 2023-03-22 07:35:33 --> Loader Class Initialized
INFO - 2023-03-22 07:35:33 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:33 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:33 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:33 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:33 --> Total execution time: 0.0179
INFO - 2023-03-22 07:35:34 --> Config Class Initialized
INFO - 2023-03-22 07:35:34 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:34 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:34 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:34 --> URI Class Initialized
INFO - 2023-03-22 07:35:34 --> Router Class Initialized
INFO - 2023-03-22 07:35:34 --> Output Class Initialized
INFO - 2023-03-22 07:35:34 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:34 --> Input Class Initialized
INFO - 2023-03-22 07:35:34 --> Language Class Initialized
INFO - 2023-03-22 07:35:34 --> Loader Class Initialized
INFO - 2023-03-22 07:35:34 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:34 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:34 --> Total execution time: 0.0039
INFO - 2023-03-22 07:35:34 --> Config Class Initialized
INFO - 2023-03-22 07:35:34 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:34 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:34 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:34 --> URI Class Initialized
INFO - 2023-03-22 07:35:34 --> Router Class Initialized
INFO - 2023-03-22 07:35:34 --> Output Class Initialized
INFO - 2023-03-22 07:35:34 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:34 --> Input Class Initialized
INFO - 2023-03-22 07:35:34 --> Language Class Initialized
INFO - 2023-03-22 07:35:34 --> Loader Class Initialized
INFO - 2023-03-22 07:35:34 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:34 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:34 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:34 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:34 --> Total execution time: 0.0132
INFO - 2023-03-22 07:35:40 --> Config Class Initialized
INFO - 2023-03-22 07:35:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:40 --> URI Class Initialized
INFO - 2023-03-22 07:35:40 --> Router Class Initialized
INFO - 2023-03-22 07:35:40 --> Output Class Initialized
INFO - 2023-03-22 07:35:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:40 --> Input Class Initialized
INFO - 2023-03-22 07:35:40 --> Language Class Initialized
INFO - 2023-03-22 07:35:40 --> Loader Class Initialized
INFO - 2023-03-22 07:35:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:40 --> Total execution time: 0.0816
INFO - 2023-03-22 07:35:40 --> Config Class Initialized
INFO - 2023-03-22 07:35:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:40 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:40 --> URI Class Initialized
INFO - 2023-03-22 07:35:40 --> Router Class Initialized
INFO - 2023-03-22 07:35:40 --> Output Class Initialized
INFO - 2023-03-22 07:35:40 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:40 --> Input Class Initialized
INFO - 2023-03-22 07:35:40 --> Language Class Initialized
INFO - 2023-03-22 07:35:40 --> Loader Class Initialized
INFO - 2023-03-22 07:35:40 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:40 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:40 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:41 --> Total execution time: 0.0197
INFO - 2023-03-22 07:35:48 --> Config Class Initialized
INFO - 2023-03-22 07:35:48 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:48 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:48 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:48 --> URI Class Initialized
INFO - 2023-03-22 07:35:48 --> Router Class Initialized
INFO - 2023-03-22 07:35:48 --> Output Class Initialized
INFO - 2023-03-22 07:35:48 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:48 --> Input Class Initialized
INFO - 2023-03-22 07:35:48 --> Language Class Initialized
INFO - 2023-03-22 07:35:48 --> Loader Class Initialized
INFO - 2023-03-22 07:35:48 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:48 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:49 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:49 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:49 --> Total execution time: 0.0179
INFO - 2023-03-22 07:35:49 --> Config Class Initialized
INFO - 2023-03-22 07:35:49 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:49 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:49 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:49 --> URI Class Initialized
INFO - 2023-03-22 07:35:49 --> Router Class Initialized
INFO - 2023-03-22 07:35:49 --> Output Class Initialized
INFO - 2023-03-22 07:35:49 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:49 --> Input Class Initialized
INFO - 2023-03-22 07:35:49 --> Language Class Initialized
INFO - 2023-03-22 07:35:49 --> Loader Class Initialized
INFO - 2023-03-22 07:35:49 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:49 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:49 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:49 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:49 --> Total execution time: 0.0157
INFO - 2023-03-22 07:35:50 --> Config Class Initialized
INFO - 2023-03-22 07:35:50 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:50 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:50 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:50 --> URI Class Initialized
INFO - 2023-03-22 07:35:50 --> Router Class Initialized
INFO - 2023-03-22 07:35:50 --> Output Class Initialized
INFO - 2023-03-22 07:35:50 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:50 --> Input Class Initialized
INFO - 2023-03-22 07:35:50 --> Language Class Initialized
INFO - 2023-03-22 07:35:50 --> Loader Class Initialized
INFO - 2023-03-22 07:35:50 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:50 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:50 --> Total execution time: 0.0037
INFO - 2023-03-22 07:35:50 --> Config Class Initialized
INFO - 2023-03-22 07:35:50 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:50 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:50 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:50 --> URI Class Initialized
INFO - 2023-03-22 07:35:50 --> Router Class Initialized
INFO - 2023-03-22 07:35:50 --> Output Class Initialized
INFO - 2023-03-22 07:35:50 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:50 --> Input Class Initialized
INFO - 2023-03-22 07:35:50 --> Language Class Initialized
INFO - 2023-03-22 07:35:50 --> Loader Class Initialized
INFO - 2023-03-22 07:35:50 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:50 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:50 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:50 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:50 --> Total execution time: 0.0103
INFO - 2023-03-22 07:35:53 --> Config Class Initialized
INFO - 2023-03-22 07:35:53 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:53 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:53 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:53 --> URI Class Initialized
INFO - 2023-03-22 07:35:53 --> Router Class Initialized
INFO - 2023-03-22 07:35:53 --> Output Class Initialized
INFO - 2023-03-22 07:35:53 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:53 --> Input Class Initialized
INFO - 2023-03-22 07:35:53 --> Language Class Initialized
INFO - 2023-03-22 07:35:53 --> Loader Class Initialized
INFO - 2023-03-22 07:35:53 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:53 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:53 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:53 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:53 --> Total execution time: 0.0203
INFO - 2023-03-22 07:35:53 --> Config Class Initialized
INFO - 2023-03-22 07:35:53 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:35:53 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:35:53 --> Utf8 Class Initialized
INFO - 2023-03-22 07:35:53 --> URI Class Initialized
INFO - 2023-03-22 07:35:53 --> Router Class Initialized
INFO - 2023-03-22 07:35:53 --> Output Class Initialized
INFO - 2023-03-22 07:35:53 --> Security Class Initialized
DEBUG - 2023-03-22 07:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:35:53 --> Input Class Initialized
INFO - 2023-03-22 07:35:53 --> Language Class Initialized
INFO - 2023-03-22 07:35:53 --> Loader Class Initialized
INFO - 2023-03-22 07:35:53 --> Controller Class Initialized
DEBUG - 2023-03-22 07:35:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:35:53 --> Database Driver Class Initialized
INFO - 2023-03-22 07:35:53 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:35:53 --> Final output sent to browser
DEBUG - 2023-03-22 07:35:53 --> Total execution time: 0.0538
INFO - 2023-03-22 07:36:08 --> Config Class Initialized
INFO - 2023-03-22 07:36:08 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:08 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:08 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:08 --> URI Class Initialized
INFO - 2023-03-22 07:36:08 --> Router Class Initialized
INFO - 2023-03-22 07:36:08 --> Output Class Initialized
INFO - 2023-03-22 07:36:08 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:08 --> Input Class Initialized
INFO - 2023-03-22 07:36:08 --> Language Class Initialized
INFO - 2023-03-22 07:36:08 --> Loader Class Initialized
INFO - 2023-03-22 07:36:08 --> Controller Class Initialized
INFO - 2023-03-22 07:36:08 --> Helper loaded: form_helper
INFO - 2023-03-22 07:36:08 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:36:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:08 --> Model "Change_model" initialized
INFO - 2023-03-22 07:36:08 --> Model "Grafana_model" initialized
INFO - 2023-03-22 07:36:08 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:08 --> Total execution time: 0.0239
INFO - 2023-03-22 07:36:08 --> Config Class Initialized
INFO - 2023-03-22 07:36:08 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:08 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:08 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:08 --> URI Class Initialized
INFO - 2023-03-22 07:36:08 --> Router Class Initialized
INFO - 2023-03-22 07:36:08 --> Output Class Initialized
INFO - 2023-03-22 07:36:08 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:08 --> Input Class Initialized
INFO - 2023-03-22 07:36:08 --> Language Class Initialized
INFO - 2023-03-22 07:36:08 --> Loader Class Initialized
INFO - 2023-03-22 07:36:08 --> Controller Class Initialized
INFO - 2023-03-22 07:36:08 --> Helper loaded: form_helper
INFO - 2023-03-22 07:36:08 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:36:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:08 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:08 --> Total execution time: 0.0036
INFO - 2023-03-22 07:36:08 --> Config Class Initialized
INFO - 2023-03-22 07:36:08 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:08 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:08 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:08 --> URI Class Initialized
INFO - 2023-03-22 07:36:08 --> Router Class Initialized
INFO - 2023-03-22 07:36:08 --> Output Class Initialized
INFO - 2023-03-22 07:36:08 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:08 --> Input Class Initialized
INFO - 2023-03-22 07:36:08 --> Language Class Initialized
INFO - 2023-03-22 07:36:08 --> Loader Class Initialized
INFO - 2023-03-22 07:36:08 --> Controller Class Initialized
INFO - 2023-03-22 07:36:08 --> Helper loaded: form_helper
INFO - 2023-03-22 07:36:08 --> Helper loaded: url_helper
DEBUG - 2023-03-22 07:36:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:08 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:08 --> Model "Login_model" initialized
INFO - 2023-03-22 07:36:08 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:08 --> Total execution time: 0.0174
INFO - 2023-03-22 07:36:08 --> Config Class Initialized
INFO - 2023-03-22 07:36:08 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:08 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:08 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:08 --> URI Class Initialized
INFO - 2023-03-22 07:36:08 --> Router Class Initialized
INFO - 2023-03-22 07:36:08 --> Output Class Initialized
INFO - 2023-03-22 07:36:08 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:08 --> Input Class Initialized
INFO - 2023-03-22 07:36:08 --> Language Class Initialized
INFO - 2023-03-22 07:36:08 --> Loader Class Initialized
INFO - 2023-03-22 07:36:08 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:08 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:08 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:08 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:08 --> Total execution time: 0.0508
INFO - 2023-03-22 07:36:08 --> Config Class Initialized
INFO - 2023-03-22 07:36:08 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:08 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:08 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:08 --> URI Class Initialized
INFO - 2023-03-22 07:36:08 --> Router Class Initialized
INFO - 2023-03-22 07:36:08 --> Output Class Initialized
INFO - 2023-03-22 07:36:08 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:08 --> Input Class Initialized
INFO - 2023-03-22 07:36:08 --> Language Class Initialized
INFO - 2023-03-22 07:36:08 --> Loader Class Initialized
INFO - 2023-03-22 07:36:08 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:08 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:08 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:08 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:08 --> Total execution time: 0.0112
INFO - 2023-03-22 07:36:08 --> Config Class Initialized
INFO - 2023-03-22 07:36:08 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:08 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:08 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:08 --> URI Class Initialized
INFO - 2023-03-22 07:36:08 --> Router Class Initialized
INFO - 2023-03-22 07:36:08 --> Output Class Initialized
INFO - 2023-03-22 07:36:08 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:08 --> Input Class Initialized
INFO - 2023-03-22 07:36:08 --> Language Class Initialized
INFO - 2023-03-22 07:36:08 --> Loader Class Initialized
INFO - 2023-03-22 07:36:08 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:08 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:08 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:08 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:08 --> Total execution time: 0.0488
INFO - 2023-03-22 07:36:09 --> Config Class Initialized
INFO - 2023-03-22 07:36:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:09 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:09 --> URI Class Initialized
INFO - 2023-03-22 07:36:09 --> Router Class Initialized
INFO - 2023-03-22 07:36:09 --> Output Class Initialized
INFO - 2023-03-22 07:36:09 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:09 --> Input Class Initialized
INFO - 2023-03-22 07:36:09 --> Language Class Initialized
INFO - 2023-03-22 07:36:09 --> Loader Class Initialized
INFO - 2023-03-22 07:36:09 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:09 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:09 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:09 --> Total execution time: 0.0510
INFO - 2023-03-22 07:36:11 --> Config Class Initialized
INFO - 2023-03-22 07:36:11 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:11 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:11 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:11 --> URI Class Initialized
INFO - 2023-03-22 07:36:11 --> Router Class Initialized
INFO - 2023-03-22 07:36:11 --> Output Class Initialized
INFO - 2023-03-22 07:36:11 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:11 --> Input Class Initialized
INFO - 2023-03-22 07:36:11 --> Language Class Initialized
INFO - 2023-03-22 07:36:11 --> Loader Class Initialized
INFO - 2023-03-22 07:36:11 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:11 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:11 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:11 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:11 --> Total execution time: 0.0216
INFO - 2023-03-22 07:36:11 --> Config Class Initialized
INFO - 2023-03-22 07:36:11 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:11 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:11 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:11 --> URI Class Initialized
INFO - 2023-03-22 07:36:11 --> Router Class Initialized
INFO - 2023-03-22 07:36:11 --> Output Class Initialized
INFO - 2023-03-22 07:36:11 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:11 --> Input Class Initialized
INFO - 2023-03-22 07:36:11 --> Language Class Initialized
INFO - 2023-03-22 07:36:11 --> Loader Class Initialized
INFO - 2023-03-22 07:36:11 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:11 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:11 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:11 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:11 --> Total execution time: 0.0582
INFO - 2023-03-22 07:36:16 --> Config Class Initialized
INFO - 2023-03-22 07:36:16 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:16 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:16 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:16 --> URI Class Initialized
INFO - 2023-03-22 07:36:16 --> Router Class Initialized
INFO - 2023-03-22 07:36:16 --> Output Class Initialized
INFO - 2023-03-22 07:36:16 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:16 --> Input Class Initialized
INFO - 2023-03-22 07:36:16 --> Language Class Initialized
INFO - 2023-03-22 07:36:16 --> Loader Class Initialized
INFO - 2023-03-22 07:36:16 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:16 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:16 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:16 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:16 --> Total execution time: 0.0202
INFO - 2023-03-22 07:36:16 --> Config Class Initialized
INFO - 2023-03-22 07:36:16 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:16 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:16 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:16 --> URI Class Initialized
INFO - 2023-03-22 07:36:16 --> Router Class Initialized
INFO - 2023-03-22 07:36:16 --> Output Class Initialized
INFO - 2023-03-22 07:36:16 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:16 --> Input Class Initialized
INFO - 2023-03-22 07:36:16 --> Language Class Initialized
INFO - 2023-03-22 07:36:16 --> Loader Class Initialized
INFO - 2023-03-22 07:36:16 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:16 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:16 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:16 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:16 --> Total execution time: 0.0121
INFO - 2023-03-22 07:36:18 --> Config Class Initialized
INFO - 2023-03-22 07:36:18 --> Config Class Initialized
INFO - 2023-03-22 07:36:18 --> Hooks Class Initialized
INFO - 2023-03-22 07:36:18 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:18 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 07:36:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:18 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:18 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:18 --> URI Class Initialized
INFO - 2023-03-22 07:36:18 --> URI Class Initialized
INFO - 2023-03-22 07:36:18 --> Router Class Initialized
INFO - 2023-03-22 07:36:18 --> Output Class Initialized
INFO - 2023-03-22 07:36:18 --> Router Class Initialized
INFO - 2023-03-22 07:36:18 --> Security Class Initialized
INFO - 2023-03-22 07:36:18 --> Output Class Initialized
DEBUG - 2023-03-22 07:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:18 --> Security Class Initialized
INFO - 2023-03-22 07:36:18 --> Input Class Initialized
DEBUG - 2023-03-22 07:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:18 --> Language Class Initialized
INFO - 2023-03-22 07:36:18 --> Input Class Initialized
INFO - 2023-03-22 07:36:18 --> Language Class Initialized
INFO - 2023-03-22 07:36:18 --> Loader Class Initialized
INFO - 2023-03-22 07:36:18 --> Controller Class Initialized
INFO - 2023-03-22 07:36:18 --> Loader Class Initialized
DEBUG - 2023-03-22 07:36:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:18 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:18 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:18 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:18 --> Total execution time: 0.0048
INFO - 2023-03-22 07:36:18 --> Config Class Initialized
INFO - 2023-03-22 07:36:18 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:18 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:18 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:18 --> URI Class Initialized
INFO - 2023-03-22 07:36:18 --> Router Class Initialized
INFO - 2023-03-22 07:36:18 --> Output Class Initialized
INFO - 2023-03-22 07:36:18 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:18 --> Input Class Initialized
INFO - 2023-03-22 07:36:18 --> Language Class Initialized
INFO - 2023-03-22 07:36:18 --> Loader Class Initialized
INFO - 2023-03-22 07:36:18 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:18 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:18 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:18 --> Total execution time: 0.0510
INFO - 2023-03-22 07:36:18 --> Config Class Initialized
INFO - 2023-03-22 07:36:18 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:18 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:18 --> URI Class Initialized
INFO - 2023-03-22 07:36:18 --> Router Class Initialized
INFO - 2023-03-22 07:36:18 --> Output Class Initialized
INFO - 2023-03-22 07:36:18 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:18 --> Input Class Initialized
INFO - 2023-03-22 07:36:18 --> Language Class Initialized
INFO - 2023-03-22 07:36:18 --> Loader Class Initialized
INFO - 2023-03-22 07:36:18 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:18 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:18 --> Model "Login_model" initialized
INFO - 2023-03-22 07:36:18 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:18 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:18 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:18 --> Total execution time: 0.0144
INFO - 2023-03-22 07:36:18 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:18 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:18 --> Total execution time: 0.1050
INFO - 2023-03-22 07:36:20 --> Config Class Initialized
INFO - 2023-03-22 07:36:20 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:20 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:20 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:20 --> URI Class Initialized
INFO - 2023-03-22 07:36:20 --> Router Class Initialized
INFO - 2023-03-22 07:36:20 --> Output Class Initialized
INFO - 2023-03-22 07:36:20 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:20 --> Input Class Initialized
INFO - 2023-03-22 07:36:20 --> Language Class Initialized
INFO - 2023-03-22 07:36:20 --> Loader Class Initialized
INFO - 2023-03-22 07:36:20 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:20 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:20 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:20 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:20 --> Total execution time: 0.0149
INFO - 2023-03-22 07:36:20 --> Config Class Initialized
INFO - 2023-03-22 07:36:20 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:20 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:20 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:20 --> URI Class Initialized
INFO - 2023-03-22 07:36:20 --> Router Class Initialized
INFO - 2023-03-22 07:36:20 --> Output Class Initialized
INFO - 2023-03-22 07:36:20 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:20 --> Input Class Initialized
INFO - 2023-03-22 07:36:20 --> Language Class Initialized
INFO - 2023-03-22 07:36:20 --> Loader Class Initialized
INFO - 2023-03-22 07:36:20 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:20 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:20 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:20 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:20 --> Total execution time: 0.0117
INFO - 2023-03-22 07:36:22 --> Config Class Initialized
INFO - 2023-03-22 07:36:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:22 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:22 --> URI Class Initialized
INFO - 2023-03-22 07:36:22 --> Router Class Initialized
INFO - 2023-03-22 07:36:22 --> Output Class Initialized
INFO - 2023-03-22 07:36:22 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:22 --> Input Class Initialized
INFO - 2023-03-22 07:36:22 --> Language Class Initialized
INFO - 2023-03-22 07:36:22 --> Loader Class Initialized
INFO - 2023-03-22 07:36:22 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:22 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:22 --> Total execution time: 0.0036
INFO - 2023-03-22 07:36:22 --> Config Class Initialized
INFO - 2023-03-22 07:36:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:22 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:22 --> URI Class Initialized
INFO - 2023-03-22 07:36:22 --> Router Class Initialized
INFO - 2023-03-22 07:36:22 --> Output Class Initialized
INFO - 2023-03-22 07:36:22 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:22 --> Input Class Initialized
INFO - 2023-03-22 07:36:22 --> Language Class Initialized
INFO - 2023-03-22 07:36:22 --> Loader Class Initialized
INFO - 2023-03-22 07:36:22 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:22 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:22 --> Model "Login_model" initialized
INFO - 2023-03-22 07:36:22 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:22 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:22 --> Total execution time: 0.0193
INFO - 2023-03-22 07:36:23 --> Config Class Initialized
INFO - 2023-03-22 07:36:23 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:23 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:23 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:23 --> URI Class Initialized
INFO - 2023-03-22 07:36:23 --> Router Class Initialized
INFO - 2023-03-22 07:36:23 --> Output Class Initialized
INFO - 2023-03-22 07:36:23 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:23 --> Input Class Initialized
INFO - 2023-03-22 07:36:23 --> Language Class Initialized
INFO - 2023-03-22 07:36:23 --> Loader Class Initialized
INFO - 2023-03-22 07:36:23 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:23 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:23 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:23 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:23 --> Total execution time: 0.0215
INFO - 2023-03-22 07:36:23 --> Config Class Initialized
INFO - 2023-03-22 07:36:23 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:23 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:23 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:23 --> URI Class Initialized
INFO - 2023-03-22 07:36:23 --> Router Class Initialized
INFO - 2023-03-22 07:36:23 --> Output Class Initialized
INFO - 2023-03-22 07:36:23 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:23 --> Input Class Initialized
INFO - 2023-03-22 07:36:23 --> Language Class Initialized
INFO - 2023-03-22 07:36:23 --> Loader Class Initialized
INFO - 2023-03-22 07:36:23 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:23 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:23 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:23 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:23 --> Total execution time: 0.0526
INFO - 2023-03-22 07:36:26 --> Config Class Initialized
INFO - 2023-03-22 07:36:26 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:26 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:26 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:26 --> URI Class Initialized
INFO - 2023-03-22 07:36:26 --> Router Class Initialized
INFO - 2023-03-22 07:36:26 --> Output Class Initialized
INFO - 2023-03-22 07:36:26 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:26 --> Input Class Initialized
INFO - 2023-03-22 07:36:26 --> Language Class Initialized
INFO - 2023-03-22 07:36:26 --> Loader Class Initialized
INFO - 2023-03-22 07:36:26 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:26 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:26 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:26 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:26 --> Total execution time: 0.0361
INFO - 2023-03-22 07:36:26 --> Config Class Initialized
INFO - 2023-03-22 07:36:26 --> Hooks Class Initialized
DEBUG - 2023-03-22 07:36:26 --> UTF-8 Support Enabled
INFO - 2023-03-22 07:36:26 --> Utf8 Class Initialized
INFO - 2023-03-22 07:36:26 --> URI Class Initialized
INFO - 2023-03-22 07:36:26 --> Router Class Initialized
INFO - 2023-03-22 07:36:26 --> Output Class Initialized
INFO - 2023-03-22 07:36:26 --> Security Class Initialized
DEBUG - 2023-03-22 07:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 07:36:26 --> Input Class Initialized
INFO - 2023-03-22 07:36:26 --> Language Class Initialized
INFO - 2023-03-22 07:36:26 --> Loader Class Initialized
INFO - 2023-03-22 07:36:26 --> Controller Class Initialized
DEBUG - 2023-03-22 07:36:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 07:36:26 --> Database Driver Class Initialized
INFO - 2023-03-22 07:36:26 --> Model "Cluster_model" initialized
INFO - 2023-03-22 07:36:26 --> Final output sent to browser
DEBUG - 2023-03-22 07:36:26 --> Total execution time: 0.0554
INFO - 2023-03-22 08:03:32 --> Config Class Initialized
INFO - 2023-03-22 08:03:32 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:03:32 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:03:32 --> Utf8 Class Initialized
INFO - 2023-03-22 08:03:32 --> URI Class Initialized
INFO - 2023-03-22 08:03:32 --> Router Class Initialized
INFO - 2023-03-22 08:03:32 --> Output Class Initialized
INFO - 2023-03-22 08:03:32 --> Security Class Initialized
DEBUG - 2023-03-22 08:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:03:32 --> Input Class Initialized
INFO - 2023-03-22 08:03:32 --> Language Class Initialized
INFO - 2023-03-22 08:03:32 --> Loader Class Initialized
INFO - 2023-03-22 08:03:32 --> Controller Class Initialized
DEBUG - 2023-03-22 08:03:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:03:32 --> Database Driver Class Initialized
INFO - 2023-03-22 08:03:32 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:03:32 --> Final output sent to browser
DEBUG - 2023-03-22 08:03:32 --> Total execution time: 0.0944
INFO - 2023-03-22 08:03:32 --> Config Class Initialized
INFO - 2023-03-22 08:03:32 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:03:32 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:03:32 --> Utf8 Class Initialized
INFO - 2023-03-22 08:03:32 --> URI Class Initialized
INFO - 2023-03-22 08:03:32 --> Router Class Initialized
INFO - 2023-03-22 08:03:32 --> Output Class Initialized
INFO - 2023-03-22 08:03:32 --> Security Class Initialized
DEBUG - 2023-03-22 08:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:03:32 --> Input Class Initialized
INFO - 2023-03-22 08:03:32 --> Language Class Initialized
INFO - 2023-03-22 08:03:32 --> Loader Class Initialized
INFO - 2023-03-22 08:03:32 --> Controller Class Initialized
DEBUG - 2023-03-22 08:03:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:03:32 --> Database Driver Class Initialized
INFO - 2023-03-22 08:03:32 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:03:32 --> Final output sent to browser
DEBUG - 2023-03-22 08:03:32 --> Total execution time: 0.0501
INFO - 2023-03-22 08:06:06 --> Config Class Initialized
INFO - 2023-03-22 08:06:06 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:06:06 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:06:06 --> Utf8 Class Initialized
INFO - 2023-03-22 08:06:06 --> URI Class Initialized
INFO - 2023-03-22 08:06:06 --> Router Class Initialized
INFO - 2023-03-22 08:06:06 --> Output Class Initialized
INFO - 2023-03-22 08:06:06 --> Security Class Initialized
DEBUG - 2023-03-22 08:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:06:06 --> Input Class Initialized
INFO - 2023-03-22 08:06:06 --> Language Class Initialized
INFO - 2023-03-22 08:06:06 --> Loader Class Initialized
INFO - 2023-03-22 08:06:06 --> Controller Class Initialized
INFO - 2023-03-22 08:06:06 --> Helper loaded: form_helper
INFO - 2023-03-22 08:06:06 --> Helper loaded: url_helper
DEBUG - 2023-03-22 08:06:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:06:06 --> Model "Change_model" initialized
INFO - 2023-03-22 08:06:06 --> Model "Grafana_model" initialized
INFO - 2023-03-22 08:06:06 --> Final output sent to browser
DEBUG - 2023-03-22 08:06:06 --> Total execution time: 0.0347
INFO - 2023-03-22 08:06:06 --> Config Class Initialized
INFO - 2023-03-22 08:06:06 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:06:06 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:06:06 --> Utf8 Class Initialized
INFO - 2023-03-22 08:06:06 --> URI Class Initialized
INFO - 2023-03-22 08:06:06 --> Router Class Initialized
INFO - 2023-03-22 08:06:06 --> Output Class Initialized
INFO - 2023-03-22 08:06:06 --> Security Class Initialized
DEBUG - 2023-03-22 08:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:06:06 --> Input Class Initialized
INFO - 2023-03-22 08:06:06 --> Language Class Initialized
INFO - 2023-03-22 08:06:06 --> Loader Class Initialized
INFO - 2023-03-22 08:06:06 --> Controller Class Initialized
INFO - 2023-03-22 08:06:06 --> Helper loaded: form_helper
INFO - 2023-03-22 08:06:06 --> Helper loaded: url_helper
DEBUG - 2023-03-22 08:06:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:06:06 --> Final output sent to browser
DEBUG - 2023-03-22 08:06:06 --> Total execution time: 0.0021
INFO - 2023-03-22 08:06:06 --> Config Class Initialized
INFO - 2023-03-22 08:06:06 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:06:06 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:06:06 --> Utf8 Class Initialized
INFO - 2023-03-22 08:06:06 --> URI Class Initialized
INFO - 2023-03-22 08:06:06 --> Router Class Initialized
INFO - 2023-03-22 08:06:06 --> Output Class Initialized
INFO - 2023-03-22 08:06:06 --> Security Class Initialized
DEBUG - 2023-03-22 08:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:06:06 --> Input Class Initialized
INFO - 2023-03-22 08:06:06 --> Language Class Initialized
INFO - 2023-03-22 08:06:06 --> Loader Class Initialized
INFO - 2023-03-22 08:06:06 --> Controller Class Initialized
INFO - 2023-03-22 08:06:06 --> Helper loaded: form_helper
INFO - 2023-03-22 08:06:06 --> Helper loaded: url_helper
DEBUG - 2023-03-22 08:06:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:06:06 --> Database Driver Class Initialized
INFO - 2023-03-22 08:06:06 --> Model "Login_model" initialized
INFO - 2023-03-22 08:06:06 --> Final output sent to browser
DEBUG - 2023-03-22 08:06:06 --> Total execution time: 0.0608
INFO - 2023-03-22 08:06:06 --> Config Class Initialized
INFO - 2023-03-22 08:06:06 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:06:06 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:06:06 --> Utf8 Class Initialized
INFO - 2023-03-22 08:06:06 --> URI Class Initialized
INFO - 2023-03-22 08:06:06 --> Router Class Initialized
INFO - 2023-03-22 08:06:06 --> Output Class Initialized
INFO - 2023-03-22 08:06:06 --> Security Class Initialized
DEBUG - 2023-03-22 08:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:06:06 --> Input Class Initialized
INFO - 2023-03-22 08:06:06 --> Language Class Initialized
INFO - 2023-03-22 08:06:06 --> Loader Class Initialized
INFO - 2023-03-22 08:06:06 --> Controller Class Initialized
DEBUG - 2023-03-22 08:06:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:06:06 --> Database Driver Class Initialized
INFO - 2023-03-22 08:06:06 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:06:06 --> Final output sent to browser
DEBUG - 2023-03-22 08:06:06 --> Total execution time: 0.0191
INFO - 2023-03-22 08:06:06 --> Config Class Initialized
INFO - 2023-03-22 08:06:06 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:06:06 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:06:06 --> Utf8 Class Initialized
INFO - 2023-03-22 08:06:06 --> URI Class Initialized
INFO - 2023-03-22 08:06:06 --> Router Class Initialized
INFO - 2023-03-22 08:06:06 --> Output Class Initialized
INFO - 2023-03-22 08:06:06 --> Security Class Initialized
DEBUG - 2023-03-22 08:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:06:06 --> Input Class Initialized
INFO - 2023-03-22 08:06:06 --> Language Class Initialized
INFO - 2023-03-22 08:06:06 --> Loader Class Initialized
INFO - 2023-03-22 08:06:06 --> Controller Class Initialized
DEBUG - 2023-03-22 08:06:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:06:06 --> Database Driver Class Initialized
INFO - 2023-03-22 08:06:06 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:06:06 --> Final output sent to browser
DEBUG - 2023-03-22 08:06:06 --> Total execution time: 0.0137
INFO - 2023-03-22 08:06:06 --> Config Class Initialized
INFO - 2023-03-22 08:06:06 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:06:06 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:06:06 --> Utf8 Class Initialized
INFO - 2023-03-22 08:06:06 --> URI Class Initialized
INFO - 2023-03-22 08:06:06 --> Router Class Initialized
INFO - 2023-03-22 08:06:06 --> Output Class Initialized
INFO - 2023-03-22 08:06:06 --> Security Class Initialized
DEBUG - 2023-03-22 08:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:06:06 --> Input Class Initialized
INFO - 2023-03-22 08:06:06 --> Language Class Initialized
INFO - 2023-03-22 08:06:06 --> Loader Class Initialized
INFO - 2023-03-22 08:06:06 --> Controller Class Initialized
DEBUG - 2023-03-22 08:06:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:06:06 --> Database Driver Class Initialized
INFO - 2023-03-22 08:06:06 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:06:06 --> Final output sent to browser
DEBUG - 2023-03-22 08:06:06 --> Total execution time: 0.0178
INFO - 2023-03-22 08:06:06 --> Config Class Initialized
INFO - 2023-03-22 08:06:06 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:06:06 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:06:06 --> Utf8 Class Initialized
INFO - 2023-03-22 08:06:06 --> URI Class Initialized
INFO - 2023-03-22 08:06:06 --> Router Class Initialized
INFO - 2023-03-22 08:06:06 --> Output Class Initialized
INFO - 2023-03-22 08:06:06 --> Security Class Initialized
DEBUG - 2023-03-22 08:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:06:06 --> Input Class Initialized
INFO - 2023-03-22 08:06:06 --> Language Class Initialized
INFO - 2023-03-22 08:06:06 --> Loader Class Initialized
INFO - 2023-03-22 08:06:06 --> Controller Class Initialized
DEBUG - 2023-03-22 08:06:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:06:06 --> Database Driver Class Initialized
INFO - 2023-03-22 08:06:06 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:06:06 --> Final output sent to browser
DEBUG - 2023-03-22 08:06:06 --> Total execution time: 0.0145
INFO - 2023-03-22 08:06:09 --> Config Class Initialized
INFO - 2023-03-22 08:06:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:06:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:06:09 --> Utf8 Class Initialized
INFO - 2023-03-22 08:06:09 --> URI Class Initialized
INFO - 2023-03-22 08:06:09 --> Router Class Initialized
INFO - 2023-03-22 08:06:09 --> Output Class Initialized
INFO - 2023-03-22 08:06:09 --> Security Class Initialized
DEBUG - 2023-03-22 08:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:06:09 --> Input Class Initialized
INFO - 2023-03-22 08:06:09 --> Language Class Initialized
INFO - 2023-03-22 08:06:09 --> Loader Class Initialized
INFO - 2023-03-22 08:06:09 --> Controller Class Initialized
DEBUG - 2023-03-22 08:06:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:06:09 --> Database Driver Class Initialized
INFO - 2023-03-22 08:06:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:06:09 --> Final output sent to browser
DEBUG - 2023-03-22 08:06:09 --> Total execution time: 0.0729
INFO - 2023-03-22 08:06:09 --> Config Class Initialized
INFO - 2023-03-22 08:06:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:06:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:06:09 --> Utf8 Class Initialized
INFO - 2023-03-22 08:06:09 --> URI Class Initialized
INFO - 2023-03-22 08:06:09 --> Router Class Initialized
INFO - 2023-03-22 08:06:09 --> Output Class Initialized
INFO - 2023-03-22 08:06:09 --> Security Class Initialized
DEBUG - 2023-03-22 08:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:06:09 --> Input Class Initialized
INFO - 2023-03-22 08:06:09 --> Language Class Initialized
INFO - 2023-03-22 08:06:09 --> Loader Class Initialized
INFO - 2023-03-22 08:06:09 --> Controller Class Initialized
DEBUG - 2023-03-22 08:06:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:06:09 --> Database Driver Class Initialized
INFO - 2023-03-22 08:06:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:06:09 --> Final output sent to browser
DEBUG - 2023-03-22 08:06:09 --> Total execution time: 0.0293
INFO - 2023-03-22 08:06:11 --> Config Class Initialized
INFO - 2023-03-22 08:06:11 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:06:11 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:06:11 --> Utf8 Class Initialized
INFO - 2023-03-22 08:06:11 --> URI Class Initialized
INFO - 2023-03-22 08:06:11 --> Router Class Initialized
INFO - 2023-03-22 08:06:11 --> Output Class Initialized
INFO - 2023-03-22 08:06:11 --> Security Class Initialized
DEBUG - 2023-03-22 08:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:06:11 --> Input Class Initialized
INFO - 2023-03-22 08:06:11 --> Language Class Initialized
INFO - 2023-03-22 08:06:11 --> Loader Class Initialized
INFO - 2023-03-22 08:06:11 --> Controller Class Initialized
DEBUG - 2023-03-22 08:06:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:06:11 --> Database Driver Class Initialized
INFO - 2023-03-22 08:06:11 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:06:11 --> Final output sent to browser
DEBUG - 2023-03-22 08:06:11 --> Total execution time: 0.0530
INFO - 2023-03-22 08:06:35 --> Config Class Initialized
INFO - 2023-03-22 08:06:35 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:06:35 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:06:35 --> Utf8 Class Initialized
INFO - 2023-03-22 08:06:35 --> URI Class Initialized
INFO - 2023-03-22 08:06:35 --> Router Class Initialized
INFO - 2023-03-22 08:06:35 --> Output Class Initialized
INFO - 2023-03-22 08:06:35 --> Security Class Initialized
DEBUG - 2023-03-22 08:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:06:35 --> Input Class Initialized
INFO - 2023-03-22 08:06:35 --> Language Class Initialized
INFO - 2023-03-22 08:06:35 --> Loader Class Initialized
INFO - 2023-03-22 08:06:35 --> Controller Class Initialized
DEBUG - 2023-03-22 08:06:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:06:35 --> Database Driver Class Initialized
INFO - 2023-03-22 08:06:35 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:06:35 --> Final output sent to browser
DEBUG - 2023-03-22 08:06:35 --> Total execution time: 0.0235
INFO - 2023-03-22 08:06:35 --> Config Class Initialized
INFO - 2023-03-22 08:06:35 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:06:35 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:06:35 --> Utf8 Class Initialized
INFO - 2023-03-22 08:06:35 --> URI Class Initialized
INFO - 2023-03-22 08:06:35 --> Router Class Initialized
INFO - 2023-03-22 08:06:35 --> Output Class Initialized
INFO - 2023-03-22 08:06:35 --> Security Class Initialized
DEBUG - 2023-03-22 08:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:06:35 --> Input Class Initialized
INFO - 2023-03-22 08:06:35 --> Language Class Initialized
INFO - 2023-03-22 08:06:35 --> Loader Class Initialized
INFO - 2023-03-22 08:06:35 --> Controller Class Initialized
DEBUG - 2023-03-22 08:06:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:06:35 --> Database Driver Class Initialized
INFO - 2023-03-22 08:06:35 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:06:35 --> Final output sent to browser
DEBUG - 2023-03-22 08:06:35 --> Total execution time: 0.0114
INFO - 2023-03-22 08:07:22 --> Config Class Initialized
INFO - 2023-03-22 08:07:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:07:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:07:22 --> Utf8 Class Initialized
INFO - 2023-03-22 08:07:22 --> URI Class Initialized
INFO - 2023-03-22 08:07:22 --> Router Class Initialized
INFO - 2023-03-22 08:07:22 --> Output Class Initialized
INFO - 2023-03-22 08:07:22 --> Security Class Initialized
DEBUG - 2023-03-22 08:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:07:22 --> Input Class Initialized
INFO - 2023-03-22 08:07:22 --> Language Class Initialized
INFO - 2023-03-22 08:07:22 --> Loader Class Initialized
INFO - 2023-03-22 08:07:22 --> Controller Class Initialized
DEBUG - 2023-03-22 08:07:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:07:22 --> Database Driver Class Initialized
INFO - 2023-03-22 08:07:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:07:22 --> Final output sent to browser
DEBUG - 2023-03-22 08:07:22 --> Total execution time: 0.0140
INFO - 2023-03-22 08:07:22 --> Config Class Initialized
INFO - 2023-03-22 08:07:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:07:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:07:22 --> Utf8 Class Initialized
INFO - 2023-03-22 08:07:22 --> URI Class Initialized
INFO - 2023-03-22 08:07:22 --> Router Class Initialized
INFO - 2023-03-22 08:07:22 --> Output Class Initialized
INFO - 2023-03-22 08:07:22 --> Security Class Initialized
DEBUG - 2023-03-22 08:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:07:22 --> Input Class Initialized
INFO - 2023-03-22 08:07:22 --> Language Class Initialized
INFO - 2023-03-22 08:07:22 --> Loader Class Initialized
INFO - 2023-03-22 08:07:22 --> Controller Class Initialized
DEBUG - 2023-03-22 08:07:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:07:22 --> Database Driver Class Initialized
INFO - 2023-03-22 08:07:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:07:22 --> Final output sent to browser
DEBUG - 2023-03-22 08:07:22 --> Total execution time: 0.0113
INFO - 2023-03-22 08:08:22 --> Config Class Initialized
INFO - 2023-03-22 08:08:22 --> Hooks Class Initialized
INFO - 2023-03-22 08:08:22 --> Config Class Initialized
INFO - 2023-03-22 08:08:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:08:22 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 08:08:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:08:22 --> Utf8 Class Initialized
INFO - 2023-03-22 08:08:22 --> Utf8 Class Initialized
INFO - 2023-03-22 08:08:22 --> URI Class Initialized
INFO - 2023-03-22 08:08:22 --> URI Class Initialized
INFO - 2023-03-22 08:08:22 --> Router Class Initialized
INFO - 2023-03-22 08:08:22 --> Router Class Initialized
INFO - 2023-03-22 08:08:22 --> Output Class Initialized
INFO - 2023-03-22 08:08:22 --> Output Class Initialized
INFO - 2023-03-22 08:08:22 --> Security Class Initialized
INFO - 2023-03-22 08:08:22 --> Security Class Initialized
DEBUG - 2023-03-22 08:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 08:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:08:22 --> Input Class Initialized
INFO - 2023-03-22 08:08:22 --> Input Class Initialized
INFO - 2023-03-22 08:08:22 --> Language Class Initialized
INFO - 2023-03-22 08:08:22 --> Language Class Initialized
INFO - 2023-03-22 08:08:22 --> Loader Class Initialized
INFO - 2023-03-22 08:08:22 --> Loader Class Initialized
INFO - 2023-03-22 08:08:22 --> Controller Class Initialized
INFO - 2023-03-22 08:08:22 --> Controller Class Initialized
DEBUG - 2023-03-22 08:08:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 08:08:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:08:22 --> Database Driver Class Initialized
INFO - 2023-03-22 08:08:22 --> Database Driver Class Initialized
INFO - 2023-03-22 08:08:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:08:22 --> Model "Login_model" initialized
INFO - 2023-03-22 08:08:22 --> Database Driver Class Initialized
INFO - 2023-03-22 08:08:22 --> Final output sent to browser
DEBUG - 2023-03-22 08:08:22 --> Total execution time: 0.0185
INFO - 2023-03-22 08:08:22 --> Config Class Initialized
INFO - 2023-03-22 08:08:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:08:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:08:22 --> Utf8 Class Initialized
INFO - 2023-03-22 08:08:22 --> URI Class Initialized
INFO - 2023-03-22 08:08:22 --> Router Class Initialized
INFO - 2023-03-22 08:08:22 --> Output Class Initialized
INFO - 2023-03-22 08:08:22 --> Security Class Initialized
DEBUG - 2023-03-22 08:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:08:22 --> Input Class Initialized
INFO - 2023-03-22 08:08:22 --> Language Class Initialized
INFO - 2023-03-22 08:08:22 --> Loader Class Initialized
INFO - 2023-03-22 08:08:22 --> Controller Class Initialized
DEBUG - 2023-03-22 08:08:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:08:22 --> Database Driver Class Initialized
INFO - 2023-03-22 08:08:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:08:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:08:22 --> Final output sent to browser
DEBUG - 2023-03-22 08:08:22 --> Total execution time: 0.0109
ERROR - 2023-03-22 08:08:22 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:08:22 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:08:27 --> Config Class Initialized
INFO - 2023-03-22 08:08:27 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:08:27 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:08:27 --> Utf8 Class Initialized
INFO - 2023-03-22 08:08:27 --> URI Class Initialized
INFO - 2023-03-22 08:08:27 --> Router Class Initialized
INFO - 2023-03-22 08:08:27 --> Output Class Initialized
INFO - 2023-03-22 08:08:27 --> Security Class Initialized
DEBUG - 2023-03-22 08:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:08:27 --> Input Class Initialized
INFO - 2023-03-22 08:08:27 --> Language Class Initialized
INFO - 2023-03-22 08:08:27 --> Loader Class Initialized
INFO - 2023-03-22 08:08:27 --> Controller Class Initialized
DEBUG - 2023-03-22 08:08:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:08:27 --> Database Driver Class Initialized
INFO - 2023-03-22 08:08:27 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:08:27 --> Final output sent to browser
DEBUG - 2023-03-22 08:08:27 --> Total execution time: 0.1012
INFO - 2023-03-22 08:09:27 --> Config Class Initialized
INFO - 2023-03-22 08:09:27 --> Config Class Initialized
INFO - 2023-03-22 08:09:27 --> Hooks Class Initialized
INFO - 2023-03-22 08:09:27 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:09:27 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 08:09:27 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:09:27 --> Utf8 Class Initialized
INFO - 2023-03-22 08:09:27 --> Utf8 Class Initialized
INFO - 2023-03-22 08:09:27 --> URI Class Initialized
INFO - 2023-03-22 08:09:27 --> URI Class Initialized
INFO - 2023-03-22 08:09:27 --> Router Class Initialized
INFO - 2023-03-22 08:09:27 --> Router Class Initialized
INFO - 2023-03-22 08:09:27 --> Output Class Initialized
INFO - 2023-03-22 08:09:27 --> Output Class Initialized
INFO - 2023-03-22 08:09:27 --> Security Class Initialized
INFO - 2023-03-22 08:09:27 --> Security Class Initialized
DEBUG - 2023-03-22 08:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 08:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:09:27 --> Input Class Initialized
INFO - 2023-03-22 08:09:27 --> Input Class Initialized
INFO - 2023-03-22 08:09:27 --> Language Class Initialized
INFO - 2023-03-22 08:09:27 --> Language Class Initialized
INFO - 2023-03-22 08:09:27 --> Loader Class Initialized
INFO - 2023-03-22 08:09:27 --> Loader Class Initialized
INFO - 2023-03-22 08:09:27 --> Controller Class Initialized
INFO - 2023-03-22 08:09:27 --> Controller Class Initialized
DEBUG - 2023-03-22 08:09:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 08:09:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:09:27 --> Database Driver Class Initialized
INFO - 2023-03-22 08:09:27 --> Database Driver Class Initialized
INFO - 2023-03-22 08:09:27 --> Model "Login_model" initialized
INFO - 2023-03-22 08:09:27 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:09:27 --> Database Driver Class Initialized
INFO - 2023-03-22 08:09:27 --> Final output sent to browser
DEBUG - 2023-03-22 08:09:27 --> Total execution time: 0.0167
INFO - 2023-03-22 08:09:27 --> Config Class Initialized
INFO - 2023-03-22 08:09:27 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:09:27 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:09:27 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:09:27 --> Utf8 Class Initialized
INFO - 2023-03-22 08:09:27 --> URI Class Initialized
INFO - 2023-03-22 08:09:27 --> Router Class Initialized
INFO - 2023-03-22 08:09:27 --> Output Class Initialized
INFO - 2023-03-22 08:09:27 --> Security Class Initialized
DEBUG - 2023-03-22 08:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:09:27 --> Input Class Initialized
INFO - 2023-03-22 08:09:27 --> Language Class Initialized
INFO - 2023-03-22 08:09:27 --> Loader Class Initialized
INFO - 2023-03-22 08:09:27 --> Controller Class Initialized
DEBUG - 2023-03-22 08:09:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:09:27 --> Database Driver Class Initialized
INFO - 2023-03-22 08:09:27 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:09:27 --> Final output sent to browser
DEBUG - 2023-03-22 08:09:27 --> Total execution time: 0.0519
ERROR - 2023-03-22 08:09:27 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:09:27 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:10:27 --> Config Class Initialized
INFO - 2023-03-22 08:10:27 --> Config Class Initialized
INFO - 2023-03-22 08:10:27 --> Hooks Class Initialized
INFO - 2023-03-22 08:10:27 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:10:27 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 08:10:27 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:10:27 --> Utf8 Class Initialized
INFO - 2023-03-22 08:10:27 --> Utf8 Class Initialized
INFO - 2023-03-22 08:10:27 --> URI Class Initialized
INFO - 2023-03-22 08:10:27 --> URI Class Initialized
INFO - 2023-03-22 08:10:27 --> Router Class Initialized
INFO - 2023-03-22 08:10:27 --> Router Class Initialized
INFO - 2023-03-22 08:10:27 --> Output Class Initialized
INFO - 2023-03-22 08:10:27 --> Output Class Initialized
INFO - 2023-03-22 08:10:27 --> Security Class Initialized
INFO - 2023-03-22 08:10:27 --> Security Class Initialized
DEBUG - 2023-03-22 08:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:10:27 --> Input Class Initialized
INFO - 2023-03-22 08:10:27 --> Input Class Initialized
INFO - 2023-03-22 08:10:27 --> Language Class Initialized
INFO - 2023-03-22 08:10:27 --> Language Class Initialized
INFO - 2023-03-22 08:10:27 --> Loader Class Initialized
INFO - 2023-03-22 08:10:27 --> Loader Class Initialized
INFO - 2023-03-22 08:10:27 --> Controller Class Initialized
INFO - 2023-03-22 08:10:27 --> Controller Class Initialized
DEBUG - 2023-03-22 08:10:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 08:10:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:10:27 --> Database Driver Class Initialized
INFO - 2023-03-22 08:10:27 --> Database Driver Class Initialized
INFO - 2023-03-22 08:10:27 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:10:27 --> Model "Login_model" initialized
INFO - 2023-03-22 08:10:27 --> Database Driver Class Initialized
INFO - 2023-03-22 08:10:27 --> Final output sent to browser
DEBUG - 2023-03-22 08:10:27 --> Total execution time: 0.0164
INFO - 2023-03-22 08:10:27 --> Config Class Initialized
INFO - 2023-03-22 08:10:27 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:10:27 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:10:27 --> Utf8 Class Initialized
INFO - 2023-03-22 08:10:27 --> URI Class Initialized
INFO - 2023-03-22 08:10:27 --> Router Class Initialized
INFO - 2023-03-22 08:10:27 --> Output Class Initialized
INFO - 2023-03-22 08:10:27 --> Security Class Initialized
DEBUG - 2023-03-22 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:10:27 --> Input Class Initialized
INFO - 2023-03-22 08:10:27 --> Language Class Initialized
INFO - 2023-03-22 08:10:27 --> Loader Class Initialized
INFO - 2023-03-22 08:10:27 --> Controller Class Initialized
DEBUG - 2023-03-22 08:10:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:10:27 --> Database Driver Class Initialized
INFO - 2023-03-22 08:10:27 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:10:27 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:10:27 --> Final output sent to browser
DEBUG - 2023-03-22 08:10:27 --> Total execution time: 0.0125
ERROR - 2023-03-22 08:10:27 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:10:27 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:10:36 --> Config Class Initialized
INFO - 2023-03-22 08:10:36 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:10:36 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:10:36 --> Utf8 Class Initialized
INFO - 2023-03-22 08:10:36 --> URI Class Initialized
INFO - 2023-03-22 08:10:36 --> Router Class Initialized
INFO - 2023-03-22 08:10:36 --> Output Class Initialized
INFO - 2023-03-22 08:10:36 --> Security Class Initialized
DEBUG - 2023-03-22 08:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:10:36 --> Input Class Initialized
INFO - 2023-03-22 08:10:36 --> Language Class Initialized
INFO - 2023-03-22 08:10:36 --> Loader Class Initialized
INFO - 2023-03-22 08:10:36 --> Controller Class Initialized
DEBUG - 2023-03-22 08:10:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:10:36 --> Database Driver Class Initialized
INFO - 2023-03-22 08:10:36 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:10:36 --> Final output sent to browser
DEBUG - 2023-03-22 08:10:36 --> Total execution time: 0.0209
INFO - 2023-03-22 08:10:36 --> Config Class Initialized
INFO - 2023-03-22 08:10:36 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:10:36 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:10:36 --> Utf8 Class Initialized
INFO - 2023-03-22 08:10:36 --> URI Class Initialized
INFO - 2023-03-22 08:10:36 --> Router Class Initialized
INFO - 2023-03-22 08:10:36 --> Output Class Initialized
INFO - 2023-03-22 08:10:36 --> Security Class Initialized
DEBUG - 2023-03-22 08:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:10:36 --> Input Class Initialized
INFO - 2023-03-22 08:10:36 --> Language Class Initialized
INFO - 2023-03-22 08:10:36 --> Loader Class Initialized
INFO - 2023-03-22 08:10:36 --> Controller Class Initialized
DEBUG - 2023-03-22 08:10:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:10:36 --> Database Driver Class Initialized
INFO - 2023-03-22 08:10:36 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:10:36 --> Final output sent to browser
DEBUG - 2023-03-22 08:10:36 --> Total execution time: 0.0194
INFO - 2023-03-22 08:11:36 --> Config Class Initialized
INFO - 2023-03-22 08:11:36 --> Config Class Initialized
INFO - 2023-03-22 08:11:36 --> Hooks Class Initialized
INFO - 2023-03-22 08:11:36 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:11:36 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 08:11:36 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:11:36 --> Utf8 Class Initialized
INFO - 2023-03-22 08:11:36 --> Utf8 Class Initialized
INFO - 2023-03-22 08:11:36 --> URI Class Initialized
INFO - 2023-03-22 08:11:36 --> URI Class Initialized
INFO - 2023-03-22 08:11:36 --> Router Class Initialized
INFO - 2023-03-22 08:11:36 --> Router Class Initialized
INFO - 2023-03-22 08:11:36 --> Output Class Initialized
INFO - 2023-03-22 08:11:36 --> Output Class Initialized
INFO - 2023-03-22 08:11:36 --> Security Class Initialized
INFO - 2023-03-22 08:11:36 --> Security Class Initialized
DEBUG - 2023-03-22 08:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 08:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:11:36 --> Input Class Initialized
INFO - 2023-03-22 08:11:36 --> Input Class Initialized
INFO - 2023-03-22 08:11:36 --> Language Class Initialized
INFO - 2023-03-22 08:11:36 --> Language Class Initialized
INFO - 2023-03-22 08:11:36 --> Loader Class Initialized
INFO - 2023-03-22 08:11:36 --> Loader Class Initialized
INFO - 2023-03-22 08:11:36 --> Controller Class Initialized
INFO - 2023-03-22 08:11:36 --> Controller Class Initialized
DEBUG - 2023-03-22 08:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 08:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:11:36 --> Database Driver Class Initialized
INFO - 2023-03-22 08:11:36 --> Database Driver Class Initialized
INFO - 2023-03-22 08:11:36 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:11:36 --> Model "Login_model" initialized
INFO - 2023-03-22 08:11:36 --> Database Driver Class Initialized
INFO - 2023-03-22 08:11:36 --> Final output sent to browser
DEBUG - 2023-03-22 08:11:36 --> Total execution time: 0.0149
INFO - 2023-03-22 08:11:36 --> Config Class Initialized
INFO - 2023-03-22 08:11:36 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:11:36 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:11:36 --> Utf8 Class Initialized
INFO - 2023-03-22 08:11:36 --> URI Class Initialized
INFO - 2023-03-22 08:11:36 --> Router Class Initialized
INFO - 2023-03-22 08:11:36 --> Output Class Initialized
INFO - 2023-03-22 08:11:36 --> Security Class Initialized
DEBUG - 2023-03-22 08:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:11:36 --> Input Class Initialized
INFO - 2023-03-22 08:11:36 --> Language Class Initialized
INFO - 2023-03-22 08:11:36 --> Loader Class Initialized
INFO - 2023-03-22 08:11:36 --> Controller Class Initialized
DEBUG - 2023-03-22 08:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:11:36 --> Database Driver Class Initialized
INFO - 2023-03-22 08:11:36 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:11:36 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:11:36 --> Final output sent to browser
DEBUG - 2023-03-22 08:11:36 --> Total execution time: 0.0141
ERROR - 2023-03-22 08:11:36 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:11:36 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:11:48 --> Config Class Initialized
INFO - 2023-03-22 08:11:48 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:11:48 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:11:48 --> Utf8 Class Initialized
INFO - 2023-03-22 08:11:48 --> URI Class Initialized
INFO - 2023-03-22 08:11:48 --> Router Class Initialized
INFO - 2023-03-22 08:11:48 --> Output Class Initialized
INFO - 2023-03-22 08:11:48 --> Security Class Initialized
DEBUG - 2023-03-22 08:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:11:48 --> Input Class Initialized
INFO - 2023-03-22 08:11:48 --> Language Class Initialized
INFO - 2023-03-22 08:11:48 --> Loader Class Initialized
INFO - 2023-03-22 08:11:48 --> Controller Class Initialized
DEBUG - 2023-03-22 08:11:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:11:48 --> Database Driver Class Initialized
INFO - 2023-03-22 08:11:48 --> Model "Login_model" initialized
INFO - 2023-03-22 08:11:48 --> Database Driver Class Initialized
INFO - 2023-03-22 08:11:48 --> Model "Cluster_model" initialized
ERROR - 2023-03-22 08:11:48 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:11:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:11:48 --> Config Class Initialized
INFO - 2023-03-22 08:11:48 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:11:48 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:11:48 --> Utf8 Class Initialized
INFO - 2023-03-22 08:11:48 --> URI Class Initialized
INFO - 2023-03-22 08:11:48 --> Router Class Initialized
INFO - 2023-03-22 08:11:48 --> Output Class Initialized
INFO - 2023-03-22 08:11:48 --> Security Class Initialized
DEBUG - 2023-03-22 08:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:11:48 --> Input Class Initialized
INFO - 2023-03-22 08:11:48 --> Language Class Initialized
ERROR - 2023-03-22 08:11:48 --> 404 Page Not Found: Faviconico/index
INFO - 2023-03-22 08:12:37 --> Config Class Initialized
INFO - 2023-03-22 08:12:37 --> Config Class Initialized
INFO - 2023-03-22 08:12:37 --> Hooks Class Initialized
INFO - 2023-03-22 08:12:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:12:37 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 08:12:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:12:37 --> Utf8 Class Initialized
INFO - 2023-03-22 08:12:37 --> Utf8 Class Initialized
INFO - 2023-03-22 08:12:37 --> URI Class Initialized
INFO - 2023-03-22 08:12:37 --> URI Class Initialized
INFO - 2023-03-22 08:12:37 --> Router Class Initialized
INFO - 2023-03-22 08:12:37 --> Router Class Initialized
INFO - 2023-03-22 08:12:37 --> Output Class Initialized
INFO - 2023-03-22 08:12:37 --> Output Class Initialized
INFO - 2023-03-22 08:12:37 --> Security Class Initialized
INFO - 2023-03-22 08:12:37 --> Security Class Initialized
DEBUG - 2023-03-22 08:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 08:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:12:37 --> Input Class Initialized
INFO - 2023-03-22 08:12:37 --> Input Class Initialized
INFO - 2023-03-22 08:12:37 --> Language Class Initialized
INFO - 2023-03-22 08:12:37 --> Language Class Initialized
INFO - 2023-03-22 08:12:37 --> Loader Class Initialized
INFO - 2023-03-22 08:12:37 --> Loader Class Initialized
INFO - 2023-03-22 08:12:37 --> Controller Class Initialized
INFO - 2023-03-22 08:12:37 --> Controller Class Initialized
DEBUG - 2023-03-22 08:12:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 08:12:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:12:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:12:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:12:37 --> Model "Login_model" initialized
INFO - 2023-03-22 08:12:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:12:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:12:37 --> Final output sent to browser
DEBUG - 2023-03-22 08:12:37 --> Total execution time: 0.0209
INFO - 2023-03-22 08:12:37 --> Config Class Initialized
INFO - 2023-03-22 08:12:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:12:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:12:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:12:37 --> Utf8 Class Initialized
INFO - 2023-03-22 08:12:37 --> URI Class Initialized
INFO - 2023-03-22 08:12:37 --> Router Class Initialized
INFO - 2023-03-22 08:12:37 --> Output Class Initialized
INFO - 2023-03-22 08:12:37 --> Security Class Initialized
DEBUG - 2023-03-22 08:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:12:37 --> Input Class Initialized
INFO - 2023-03-22 08:12:37 --> Language Class Initialized
INFO - 2023-03-22 08:12:37 --> Loader Class Initialized
INFO - 2023-03-22 08:12:37 --> Controller Class Initialized
DEBUG - 2023-03-22 08:12:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:12:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:12:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:12:37 --> Final output sent to browser
DEBUG - 2023-03-22 08:12:37 --> Total execution time: 0.0550
ERROR - 2023-03-22 08:12:37 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:12:37 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:13:37 --> Config Class Initialized
INFO - 2023-03-22 08:13:37 --> Hooks Class Initialized
INFO - 2023-03-22 08:13:37 --> Config Class Initialized
INFO - 2023-03-22 08:13:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:13:37 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 08:13:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:13:37 --> Utf8 Class Initialized
INFO - 2023-03-22 08:13:37 --> Utf8 Class Initialized
INFO - 2023-03-22 08:13:37 --> URI Class Initialized
INFO - 2023-03-22 08:13:37 --> URI Class Initialized
INFO - 2023-03-22 08:13:37 --> Router Class Initialized
INFO - 2023-03-22 08:13:37 --> Router Class Initialized
INFO - 2023-03-22 08:13:37 --> Output Class Initialized
INFO - 2023-03-22 08:13:37 --> Output Class Initialized
INFO - 2023-03-22 08:13:37 --> Security Class Initialized
INFO - 2023-03-22 08:13:37 --> Security Class Initialized
DEBUG - 2023-03-22 08:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 08:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:13:37 --> Input Class Initialized
INFO - 2023-03-22 08:13:37 --> Input Class Initialized
INFO - 2023-03-22 08:13:37 --> Language Class Initialized
INFO - 2023-03-22 08:13:37 --> Language Class Initialized
INFO - 2023-03-22 08:13:37 --> Loader Class Initialized
INFO - 2023-03-22 08:13:37 --> Loader Class Initialized
INFO - 2023-03-22 08:13:37 --> Controller Class Initialized
INFO - 2023-03-22 08:13:37 --> Controller Class Initialized
DEBUG - 2023-03-22 08:13:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 08:13:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:13:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:13:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:13:37 --> Model "Login_model" initialized
INFO - 2023-03-22 08:13:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:13:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:13:37 --> Final output sent to browser
DEBUG - 2023-03-22 08:13:37 --> Total execution time: 0.1794
INFO - 2023-03-22 08:13:37 --> Config Class Initialized
INFO - 2023-03-22 08:13:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:13:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:13:37 --> Utf8 Class Initialized
INFO - 2023-03-22 08:13:37 --> URI Class Initialized
INFO - 2023-03-22 08:13:37 --> Router Class Initialized
INFO - 2023-03-22 08:13:37 --> Output Class Initialized
INFO - 2023-03-22 08:13:37 --> Security Class Initialized
DEBUG - 2023-03-22 08:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:13:37 --> Input Class Initialized
INFO - 2023-03-22 08:13:37 --> Language Class Initialized
INFO - 2023-03-22 08:13:37 --> Loader Class Initialized
INFO - 2023-03-22 08:13:37 --> Controller Class Initialized
DEBUG - 2023-03-22 08:13:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:13:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:13:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:13:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:13:37 --> Final output sent to browser
DEBUG - 2023-03-22 08:13:37 --> Total execution time: 0.0108
ERROR - 2023-03-22 08:13:37 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:13:37 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:14:38 --> Config Class Initialized
INFO - 2023-03-22 08:14:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:14:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:14:38 --> Utf8 Class Initialized
INFO - 2023-03-22 08:14:38 --> URI Class Initialized
INFO - 2023-03-22 08:14:38 --> Router Class Initialized
INFO - 2023-03-22 08:14:38 --> Output Class Initialized
INFO - 2023-03-22 08:14:38 --> Security Class Initialized
DEBUG - 2023-03-22 08:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:14:38 --> Input Class Initialized
INFO - 2023-03-22 08:14:38 --> Language Class Initialized
INFO - 2023-03-22 08:14:38 --> Loader Class Initialized
INFO - 2023-03-22 08:14:38 --> Controller Class Initialized
DEBUG - 2023-03-22 08:14:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:14:38 --> Database Driver Class Initialized
INFO - 2023-03-22 08:14:38 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:14:38 --> Final output sent to browser
DEBUG - 2023-03-22 08:14:38 --> Total execution time: 0.0153
INFO - 2023-03-22 08:14:38 --> Config Class Initialized
INFO - 2023-03-22 08:14:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:14:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:14:38 --> Utf8 Class Initialized
INFO - 2023-03-22 08:14:38 --> URI Class Initialized
INFO - 2023-03-22 08:14:38 --> Router Class Initialized
INFO - 2023-03-22 08:14:38 --> Output Class Initialized
INFO - 2023-03-22 08:14:38 --> Security Class Initialized
DEBUG - 2023-03-22 08:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:14:38 --> Input Class Initialized
INFO - 2023-03-22 08:14:38 --> Language Class Initialized
INFO - 2023-03-22 08:14:38 --> Loader Class Initialized
INFO - 2023-03-22 08:14:38 --> Controller Class Initialized
DEBUG - 2023-03-22 08:14:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:14:38 --> Database Driver Class Initialized
INFO - 2023-03-22 08:14:38 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:14:38 --> Final output sent to browser
DEBUG - 2023-03-22 08:14:38 --> Total execution time: 0.0112
INFO - 2023-03-22 08:14:38 --> Config Class Initialized
INFO - 2023-03-22 08:14:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:14:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:14:38 --> Utf8 Class Initialized
INFO - 2023-03-22 08:14:38 --> URI Class Initialized
INFO - 2023-03-22 08:14:38 --> Router Class Initialized
INFO - 2023-03-22 08:14:38 --> Output Class Initialized
INFO - 2023-03-22 08:14:38 --> Security Class Initialized
DEBUG - 2023-03-22 08:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:14:38 --> Input Class Initialized
INFO - 2023-03-22 08:14:38 --> Language Class Initialized
INFO - 2023-03-22 08:14:38 --> Loader Class Initialized
INFO - 2023-03-22 08:14:38 --> Controller Class Initialized
DEBUG - 2023-03-22 08:14:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:14:38 --> Database Driver Class Initialized
INFO - 2023-03-22 08:14:38 --> Model "Login_model" initialized
INFO - 2023-03-22 08:14:38 --> Database Driver Class Initialized
INFO - 2023-03-22 08:14:38 --> Model "Cluster_model" initialized
ERROR - 2023-03-22 08:14:38 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:14:38 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:15:37 --> Config Class Initialized
INFO - 2023-03-22 08:15:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:15:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:15:37 --> Utf8 Class Initialized
INFO - 2023-03-22 08:15:37 --> URI Class Initialized
INFO - 2023-03-22 08:15:37 --> Router Class Initialized
INFO - 2023-03-22 08:15:37 --> Output Class Initialized
INFO - 2023-03-22 08:15:37 --> Security Class Initialized
DEBUG - 2023-03-22 08:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:15:37 --> Input Class Initialized
INFO - 2023-03-22 08:15:37 --> Language Class Initialized
INFO - 2023-03-22 08:15:37 --> Loader Class Initialized
INFO - 2023-03-22 08:15:37 --> Controller Class Initialized
DEBUG - 2023-03-22 08:15:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:15:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:15:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:15:37 --> Final output sent to browser
DEBUG - 2023-03-22 08:15:37 --> Total execution time: 0.0131
INFO - 2023-03-22 08:15:37 --> Config Class Initialized
INFO - 2023-03-22 08:15:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:15:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:15:37 --> Utf8 Class Initialized
INFO - 2023-03-22 08:15:37 --> URI Class Initialized
INFO - 2023-03-22 08:15:37 --> Router Class Initialized
INFO - 2023-03-22 08:15:37 --> Output Class Initialized
INFO - 2023-03-22 08:15:37 --> Security Class Initialized
DEBUG - 2023-03-22 08:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:15:37 --> Input Class Initialized
INFO - 2023-03-22 08:15:37 --> Language Class Initialized
INFO - 2023-03-22 08:15:37 --> Loader Class Initialized
INFO - 2023-03-22 08:15:37 --> Controller Class Initialized
DEBUG - 2023-03-22 08:15:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:15:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:15:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:15:37 --> Final output sent to browser
DEBUG - 2023-03-22 08:15:37 --> Total execution time: 0.0113
INFO - 2023-03-22 08:15:38 --> Config Class Initialized
INFO - 2023-03-22 08:15:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:15:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:15:38 --> Utf8 Class Initialized
INFO - 2023-03-22 08:15:38 --> URI Class Initialized
INFO - 2023-03-22 08:15:38 --> Router Class Initialized
INFO - 2023-03-22 08:15:38 --> Output Class Initialized
INFO - 2023-03-22 08:15:38 --> Security Class Initialized
DEBUG - 2023-03-22 08:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:15:38 --> Input Class Initialized
INFO - 2023-03-22 08:15:38 --> Language Class Initialized
INFO - 2023-03-22 08:15:38 --> Loader Class Initialized
INFO - 2023-03-22 08:15:38 --> Controller Class Initialized
DEBUG - 2023-03-22 08:15:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:15:38 --> Database Driver Class Initialized
INFO - 2023-03-22 08:15:38 --> Model "Login_model" initialized
INFO - 2023-03-22 08:15:38 --> Database Driver Class Initialized
INFO - 2023-03-22 08:15:38 --> Model "Cluster_model" initialized
ERROR - 2023-03-22 08:15:38 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:15:38 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:16:37 --> Config Class Initialized
INFO - 2023-03-22 08:16:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:16:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:16:37 --> Utf8 Class Initialized
INFO - 2023-03-22 08:16:37 --> URI Class Initialized
INFO - 2023-03-22 08:16:37 --> Router Class Initialized
INFO - 2023-03-22 08:16:37 --> Output Class Initialized
INFO - 2023-03-22 08:16:37 --> Security Class Initialized
DEBUG - 2023-03-22 08:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:16:37 --> Input Class Initialized
INFO - 2023-03-22 08:16:37 --> Language Class Initialized
INFO - 2023-03-22 08:16:37 --> Loader Class Initialized
INFO - 2023-03-22 08:16:37 --> Controller Class Initialized
DEBUG - 2023-03-22 08:16:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:16:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:16:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:16:37 --> Final output sent to browser
DEBUG - 2023-03-22 08:16:37 --> Total execution time: 0.0115
INFO - 2023-03-22 08:16:37 --> Config Class Initialized
INFO - 2023-03-22 08:16:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:16:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:16:37 --> Utf8 Class Initialized
INFO - 2023-03-22 08:16:37 --> URI Class Initialized
INFO - 2023-03-22 08:16:37 --> Router Class Initialized
INFO - 2023-03-22 08:16:37 --> Output Class Initialized
INFO - 2023-03-22 08:16:37 --> Security Class Initialized
DEBUG - 2023-03-22 08:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:16:37 --> Input Class Initialized
INFO - 2023-03-22 08:16:37 --> Language Class Initialized
INFO - 2023-03-22 08:16:37 --> Loader Class Initialized
INFO - 2023-03-22 08:16:37 --> Controller Class Initialized
DEBUG - 2023-03-22 08:16:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:16:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:16:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:16:37 --> Final output sent to browser
DEBUG - 2023-03-22 08:16:37 --> Total execution time: 0.0101
INFO - 2023-03-22 08:16:37 --> Config Class Initialized
INFO - 2023-03-22 08:16:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:16:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:16:37 --> Utf8 Class Initialized
INFO - 2023-03-22 08:16:37 --> URI Class Initialized
INFO - 2023-03-22 08:16:37 --> Router Class Initialized
INFO - 2023-03-22 08:16:37 --> Output Class Initialized
INFO - 2023-03-22 08:16:37 --> Security Class Initialized
DEBUG - 2023-03-22 08:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:16:37 --> Input Class Initialized
INFO - 2023-03-22 08:16:37 --> Language Class Initialized
INFO - 2023-03-22 08:16:37 --> Loader Class Initialized
INFO - 2023-03-22 08:16:37 --> Controller Class Initialized
DEBUG - 2023-03-22 08:16:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:16:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:16:37 --> Model "Login_model" initialized
INFO - 2023-03-22 08:16:37 --> Database Driver Class Initialized
INFO - 2023-03-22 08:16:37 --> Model "Cluster_model" initialized
ERROR - 2023-03-22 08:16:37 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:16:37 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:18:29 --> Config Class Initialized
INFO - 2023-03-22 08:18:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:18:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:18:29 --> Utf8 Class Initialized
INFO - 2023-03-22 08:18:29 --> URI Class Initialized
INFO - 2023-03-22 08:18:29 --> Router Class Initialized
INFO - 2023-03-22 08:18:29 --> Output Class Initialized
INFO - 2023-03-22 08:18:29 --> Security Class Initialized
DEBUG - 2023-03-22 08:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:18:29 --> Input Class Initialized
INFO - 2023-03-22 08:18:29 --> Language Class Initialized
INFO - 2023-03-22 08:18:29 --> Loader Class Initialized
INFO - 2023-03-22 08:18:29 --> Controller Class Initialized
DEBUG - 2023-03-22 08:18:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:18:29 --> Database Driver Class Initialized
INFO - 2023-03-22 08:18:29 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:18:29 --> Final output sent to browser
DEBUG - 2023-03-22 08:18:29 --> Total execution time: 0.0146
INFO - 2023-03-22 08:18:29 --> Config Class Initialized
INFO - 2023-03-22 08:18:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:18:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:18:29 --> Utf8 Class Initialized
INFO - 2023-03-22 08:18:29 --> URI Class Initialized
INFO - 2023-03-22 08:18:29 --> Router Class Initialized
INFO - 2023-03-22 08:18:29 --> Output Class Initialized
INFO - 2023-03-22 08:18:29 --> Security Class Initialized
DEBUG - 2023-03-22 08:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:18:29 --> Input Class Initialized
INFO - 2023-03-22 08:18:29 --> Language Class Initialized
INFO - 2023-03-22 08:18:29 --> Loader Class Initialized
INFO - 2023-03-22 08:18:29 --> Controller Class Initialized
DEBUG - 2023-03-22 08:18:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:18:29 --> Database Driver Class Initialized
INFO - 2023-03-22 08:18:29 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:18:29 --> Final output sent to browser
DEBUG - 2023-03-22 08:18:29 --> Total execution time: 0.0520
INFO - 2023-03-22 08:19:29 --> Config Class Initialized
INFO - 2023-03-22 08:19:29 --> Config Class Initialized
INFO - 2023-03-22 08:19:29 --> Hooks Class Initialized
INFO - 2023-03-22 08:19:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:19:29 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 08:19:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:19:29 --> Utf8 Class Initialized
INFO - 2023-03-22 08:19:29 --> Utf8 Class Initialized
INFO - 2023-03-22 08:19:29 --> URI Class Initialized
INFO - 2023-03-22 08:19:29 --> URI Class Initialized
INFO - 2023-03-22 08:19:29 --> Router Class Initialized
INFO - 2023-03-22 08:19:29 --> Router Class Initialized
INFO - 2023-03-22 08:19:29 --> Output Class Initialized
INFO - 2023-03-22 08:19:29 --> Output Class Initialized
INFO - 2023-03-22 08:19:29 --> Security Class Initialized
INFO - 2023-03-22 08:19:29 --> Security Class Initialized
DEBUG - 2023-03-22 08:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 08:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:19:29 --> Input Class Initialized
INFO - 2023-03-22 08:19:29 --> Input Class Initialized
INFO - 2023-03-22 08:19:29 --> Language Class Initialized
INFO - 2023-03-22 08:19:29 --> Language Class Initialized
INFO - 2023-03-22 08:19:29 --> Loader Class Initialized
INFO - 2023-03-22 08:19:29 --> Loader Class Initialized
INFO - 2023-03-22 08:19:29 --> Controller Class Initialized
INFO - 2023-03-22 08:19:29 --> Controller Class Initialized
DEBUG - 2023-03-22 08:19:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 08:19:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:19:29 --> Database Driver Class Initialized
INFO - 2023-03-22 08:19:29 --> Database Driver Class Initialized
INFO - 2023-03-22 08:19:29 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:19:29 --> Model "Login_model" initialized
INFO - 2023-03-22 08:19:29 --> Database Driver Class Initialized
INFO - 2023-03-22 08:19:29 --> Final output sent to browser
DEBUG - 2023-03-22 08:19:29 --> Total execution time: 0.0165
INFO - 2023-03-22 08:19:29 --> Config Class Initialized
INFO - 2023-03-22 08:19:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:19:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:19:29 --> Utf8 Class Initialized
INFO - 2023-03-22 08:19:29 --> URI Class Initialized
INFO - 2023-03-22 08:19:29 --> Router Class Initialized
INFO - 2023-03-22 08:19:29 --> Output Class Initialized
INFO - 2023-03-22 08:19:29 --> Security Class Initialized
DEBUG - 2023-03-22 08:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:19:29 --> Input Class Initialized
INFO - 2023-03-22 08:19:29 --> Language Class Initialized
INFO - 2023-03-22 08:19:29 --> Loader Class Initialized
INFO - 2023-03-22 08:19:29 --> Controller Class Initialized
DEBUG - 2023-03-22 08:19:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:19:29 --> Database Driver Class Initialized
INFO - 2023-03-22 08:19:29 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:19:29 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:19:29 --> Final output sent to browser
DEBUG - 2023-03-22 08:19:29 --> Total execution time: 0.0146
ERROR - 2023-03-22 08:19:29 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:19:29 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:20:39 --> Config Class Initialized
INFO - 2023-03-22 08:20:39 --> Config Class Initialized
INFO - 2023-03-22 08:20:39 --> Hooks Class Initialized
INFO - 2023-03-22 08:20:39 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:20:39 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 08:20:39 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:20:39 --> Utf8 Class Initialized
INFO - 2023-03-22 08:20:39 --> Utf8 Class Initialized
INFO - 2023-03-22 08:20:39 --> URI Class Initialized
INFO - 2023-03-22 08:20:39 --> URI Class Initialized
INFO - 2023-03-22 08:20:39 --> Router Class Initialized
INFO - 2023-03-22 08:20:39 --> Router Class Initialized
INFO - 2023-03-22 08:20:39 --> Output Class Initialized
INFO - 2023-03-22 08:20:39 --> Output Class Initialized
INFO - 2023-03-22 08:20:39 --> Security Class Initialized
INFO - 2023-03-22 08:20:39 --> Security Class Initialized
DEBUG - 2023-03-22 08:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 08:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:20:39 --> Input Class Initialized
INFO - 2023-03-22 08:20:39 --> Input Class Initialized
INFO - 2023-03-22 08:20:39 --> Language Class Initialized
INFO - 2023-03-22 08:20:39 --> Language Class Initialized
INFO - 2023-03-22 08:20:39 --> Loader Class Initialized
INFO - 2023-03-22 08:20:39 --> Loader Class Initialized
INFO - 2023-03-22 08:20:39 --> Controller Class Initialized
INFO - 2023-03-22 08:20:39 --> Controller Class Initialized
DEBUG - 2023-03-22 08:20:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 08:20:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:20:39 --> Database Driver Class Initialized
INFO - 2023-03-22 08:20:39 --> Database Driver Class Initialized
INFO - 2023-03-22 08:20:39 --> Model "Login_model" initialized
INFO - 2023-03-22 08:20:39 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:20:39 --> Database Driver Class Initialized
INFO - 2023-03-22 08:20:39 --> Final output sent to browser
DEBUG - 2023-03-22 08:20:39 --> Total execution time: 0.0176
INFO - 2023-03-22 08:20:39 --> Config Class Initialized
INFO - 2023-03-22 08:20:39 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:20:39 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:20:39 --> Utf8 Class Initialized
INFO - 2023-03-22 08:20:39 --> URI Class Initialized
INFO - 2023-03-22 08:20:39 --> Router Class Initialized
INFO - 2023-03-22 08:20:39 --> Output Class Initialized
INFO - 2023-03-22 08:20:39 --> Security Class Initialized
DEBUG - 2023-03-22 08:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:20:39 --> Input Class Initialized
INFO - 2023-03-22 08:20:39 --> Language Class Initialized
INFO - 2023-03-22 08:20:39 --> Loader Class Initialized
INFO - 2023-03-22 08:20:39 --> Controller Class Initialized
DEBUG - 2023-03-22 08:20:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:20:39 --> Database Driver Class Initialized
INFO - 2023-03-22 08:20:39 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:20:39 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:20:39 --> Final output sent to browser
DEBUG - 2023-03-22 08:20:39 --> Total execution time: 0.0114
ERROR - 2023-03-22 08:20:39 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:20:39 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:21:01 --> Config Class Initialized
INFO - 2023-03-22 08:21:01 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:21:01 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:21:01 --> Utf8 Class Initialized
INFO - 2023-03-22 08:21:01 --> URI Class Initialized
INFO - 2023-03-22 08:21:01 --> Router Class Initialized
INFO - 2023-03-22 08:21:01 --> Output Class Initialized
INFO - 2023-03-22 08:21:01 --> Security Class Initialized
DEBUG - 2023-03-22 08:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:21:01 --> Input Class Initialized
INFO - 2023-03-22 08:21:01 --> Language Class Initialized
INFO - 2023-03-22 08:21:01 --> Loader Class Initialized
INFO - 2023-03-22 08:21:01 --> Controller Class Initialized
DEBUG - 2023-03-22 08:21:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:21:01 --> Database Driver Class Initialized
INFO - 2023-03-22 08:21:01 --> Model "Login_model" initialized
INFO - 2023-03-22 08:21:01 --> Database Driver Class Initialized
INFO - 2023-03-22 08:21:01 --> Model "Cluster_model" initialized
ERROR - 2023-03-22 08:21:01 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:21:01 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:21:36 --> Config Class Initialized
INFO - 2023-03-22 08:21:36 --> Config Class Initialized
INFO - 2023-03-22 08:21:36 --> Hooks Class Initialized
INFO - 2023-03-22 08:21:36 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:21:36 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:21:36 --> Utf8 Class Initialized
DEBUG - 2023-03-22 08:21:36 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:21:36 --> URI Class Initialized
INFO - 2023-03-22 08:21:36 --> Utf8 Class Initialized
INFO - 2023-03-22 08:21:36 --> Router Class Initialized
INFO - 2023-03-22 08:21:36 --> URI Class Initialized
INFO - 2023-03-22 08:21:36 --> Output Class Initialized
INFO - 2023-03-22 08:21:36 --> Router Class Initialized
INFO - 2023-03-22 08:21:36 --> Security Class Initialized
INFO - 2023-03-22 08:21:36 --> Output Class Initialized
DEBUG - 2023-03-22 08:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:21:36 --> Security Class Initialized
INFO - 2023-03-22 08:21:36 --> Input Class Initialized
DEBUG - 2023-03-22 08:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:21:36 --> Language Class Initialized
INFO - 2023-03-22 08:21:36 --> Input Class Initialized
INFO - 2023-03-22 08:21:36 --> Language Class Initialized
INFO - 2023-03-22 08:21:36 --> Loader Class Initialized
INFO - 2023-03-22 08:21:36 --> Loader Class Initialized
INFO - 2023-03-22 08:21:36 --> Controller Class Initialized
INFO - 2023-03-22 08:21:36 --> Controller Class Initialized
DEBUG - 2023-03-22 08:21:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 08:21:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:21:36 --> Database Driver Class Initialized
INFO - 2023-03-22 08:21:36 --> Database Driver Class Initialized
INFO - 2023-03-22 08:21:36 --> Model "Login_model" initialized
INFO - 2023-03-22 08:21:36 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:21:36 --> Database Driver Class Initialized
INFO - 2023-03-22 08:21:36 --> Final output sent to browser
DEBUG - 2023-03-22 08:21:36 --> Total execution time: 0.0166
INFO - 2023-03-22 08:21:36 --> Config Class Initialized
INFO - 2023-03-22 08:21:36 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:21:36 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:21:36 --> Utf8 Class Initialized
INFO - 2023-03-22 08:21:36 --> URI Class Initialized
INFO - 2023-03-22 08:21:36 --> Router Class Initialized
INFO - 2023-03-22 08:21:36 --> Output Class Initialized
INFO - 2023-03-22 08:21:36 --> Security Class Initialized
DEBUG - 2023-03-22 08:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:21:36 --> Input Class Initialized
INFO - 2023-03-22 08:21:36 --> Language Class Initialized
INFO - 2023-03-22 08:21:36 --> Loader Class Initialized
INFO - 2023-03-22 08:21:36 --> Controller Class Initialized
DEBUG - 2023-03-22 08:21:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:21:36 --> Database Driver Class Initialized
INFO - 2023-03-22 08:21:36 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:21:36 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:21:36 --> Final output sent to browser
DEBUG - 2023-03-22 08:21:36 --> Total execution time: 0.0120
ERROR - 2023-03-22 08:21:36 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:21:36 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:22:38 --> Config Class Initialized
INFO - 2023-03-22 08:22:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:22:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:22:38 --> Utf8 Class Initialized
INFO - 2023-03-22 08:22:38 --> URI Class Initialized
INFO - 2023-03-22 08:22:38 --> Router Class Initialized
INFO - 2023-03-22 08:22:38 --> Output Class Initialized
INFO - 2023-03-22 08:22:38 --> Security Class Initialized
DEBUG - 2023-03-22 08:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:22:38 --> Input Class Initialized
INFO - 2023-03-22 08:22:38 --> Language Class Initialized
INFO - 2023-03-22 08:22:38 --> Loader Class Initialized
INFO - 2023-03-22 08:22:38 --> Controller Class Initialized
DEBUG - 2023-03-22 08:22:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:22:38 --> Database Driver Class Initialized
INFO - 2023-03-22 08:22:38 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:22:38 --> Final output sent to browser
DEBUG - 2023-03-22 08:22:38 --> Total execution time: 0.0158
INFO - 2023-03-22 08:22:38 --> Config Class Initialized
INFO - 2023-03-22 08:22:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:22:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:22:38 --> Utf8 Class Initialized
INFO - 2023-03-22 08:22:38 --> URI Class Initialized
INFO - 2023-03-22 08:22:38 --> Router Class Initialized
INFO - 2023-03-22 08:22:38 --> Output Class Initialized
INFO - 2023-03-22 08:22:38 --> Security Class Initialized
DEBUG - 2023-03-22 08:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:22:38 --> Input Class Initialized
INFO - 2023-03-22 08:22:38 --> Language Class Initialized
INFO - 2023-03-22 08:22:38 --> Loader Class Initialized
INFO - 2023-03-22 08:22:38 --> Controller Class Initialized
DEBUG - 2023-03-22 08:22:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:22:38 --> Database Driver Class Initialized
INFO - 2023-03-22 08:22:38 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:22:38 --> Final output sent to browser
DEBUG - 2023-03-22 08:22:38 --> Total execution time: 0.0570
INFO - 2023-03-22 08:22:38 --> Config Class Initialized
INFO - 2023-03-22 08:22:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:22:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:22:38 --> Utf8 Class Initialized
INFO - 2023-03-22 08:22:38 --> URI Class Initialized
INFO - 2023-03-22 08:22:38 --> Router Class Initialized
INFO - 2023-03-22 08:22:38 --> Output Class Initialized
INFO - 2023-03-22 08:22:38 --> Security Class Initialized
DEBUG - 2023-03-22 08:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:22:38 --> Input Class Initialized
INFO - 2023-03-22 08:22:38 --> Language Class Initialized
INFO - 2023-03-22 08:22:38 --> Loader Class Initialized
INFO - 2023-03-22 08:22:38 --> Controller Class Initialized
DEBUG - 2023-03-22 08:22:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:22:38 --> Database Driver Class Initialized
INFO - 2023-03-22 08:22:38 --> Model "Login_model" initialized
INFO - 2023-03-22 08:22:38 --> Database Driver Class Initialized
INFO - 2023-03-22 08:22:38 --> Model "Cluster_model" initialized
ERROR - 2023-03-22 08:22:38 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 08:22:38 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 08:23:23 --> Config Class Initialized
INFO - 2023-03-22 08:23:23 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:23:23 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:23:23 --> Utf8 Class Initialized
INFO - 2023-03-22 08:23:23 --> URI Class Initialized
INFO - 2023-03-22 08:23:23 --> Router Class Initialized
INFO - 2023-03-22 08:23:23 --> Output Class Initialized
INFO - 2023-03-22 08:23:23 --> Security Class Initialized
DEBUG - 2023-03-22 08:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:23:23 --> Input Class Initialized
INFO - 2023-03-22 08:23:23 --> Language Class Initialized
INFO - 2023-03-22 08:23:23 --> Loader Class Initialized
INFO - 2023-03-22 08:23:23 --> Controller Class Initialized
DEBUG - 2023-03-22 08:23:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:23:23 --> Database Driver Class Initialized
INFO - 2023-03-22 08:23:23 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:23:23 --> Final output sent to browser
DEBUG - 2023-03-22 08:23:23 --> Total execution time: 0.0167
INFO - 2023-03-22 08:23:23 --> Config Class Initialized
INFO - 2023-03-22 08:23:23 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:23:23 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:23:23 --> Utf8 Class Initialized
INFO - 2023-03-22 08:23:23 --> URI Class Initialized
INFO - 2023-03-22 08:23:23 --> Router Class Initialized
INFO - 2023-03-22 08:23:23 --> Output Class Initialized
INFO - 2023-03-22 08:23:23 --> Security Class Initialized
DEBUG - 2023-03-22 08:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:23:23 --> Input Class Initialized
INFO - 2023-03-22 08:23:23 --> Language Class Initialized
INFO - 2023-03-22 08:23:23 --> Loader Class Initialized
INFO - 2023-03-22 08:23:23 --> Controller Class Initialized
DEBUG - 2023-03-22 08:23:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:23:23 --> Database Driver Class Initialized
INFO - 2023-03-22 08:23:23 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:23:23 --> Final output sent to browser
DEBUG - 2023-03-22 08:23:23 --> Total execution time: 0.0813
INFO - 2023-03-22 08:23:25 --> Config Class Initialized
INFO - 2023-03-22 08:23:25 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:23:25 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:23:25 --> Utf8 Class Initialized
INFO - 2023-03-22 08:23:25 --> URI Class Initialized
INFO - 2023-03-22 08:23:25 --> Router Class Initialized
INFO - 2023-03-22 08:23:25 --> Output Class Initialized
INFO - 2023-03-22 08:23:25 --> Security Class Initialized
DEBUG - 2023-03-22 08:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:23:25 --> Input Class Initialized
INFO - 2023-03-22 08:23:25 --> Language Class Initialized
INFO - 2023-03-22 08:23:25 --> Loader Class Initialized
INFO - 2023-03-22 08:23:25 --> Controller Class Initialized
DEBUG - 2023-03-22 08:23:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:23:25 --> Final output sent to browser
DEBUG - 2023-03-22 08:23:25 --> Total execution time: 0.0441
INFO - 2023-03-22 08:23:25 --> Config Class Initialized
INFO - 2023-03-22 08:23:25 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:23:25 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:23:25 --> Utf8 Class Initialized
INFO - 2023-03-22 08:23:25 --> URI Class Initialized
INFO - 2023-03-22 08:23:25 --> Router Class Initialized
INFO - 2023-03-22 08:23:25 --> Output Class Initialized
INFO - 2023-03-22 08:23:25 --> Security Class Initialized
DEBUG - 2023-03-22 08:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:23:25 --> Input Class Initialized
INFO - 2023-03-22 08:23:25 --> Language Class Initialized
INFO - 2023-03-22 08:23:25 --> Loader Class Initialized
INFO - 2023-03-22 08:23:25 --> Controller Class Initialized
DEBUG - 2023-03-22 08:23:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:23:25 --> Database Driver Class Initialized
INFO - 2023-03-22 08:23:25 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:23:25 --> Final output sent to browser
DEBUG - 2023-03-22 08:23:25 --> Total execution time: 0.0526
INFO - 2023-03-22 08:23:25 --> Config Class Initialized
INFO - 2023-03-22 08:23:25 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:23:25 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:23:25 --> Utf8 Class Initialized
INFO - 2023-03-22 08:23:25 --> URI Class Initialized
INFO - 2023-03-22 08:23:25 --> Router Class Initialized
INFO - 2023-03-22 08:23:25 --> Output Class Initialized
INFO - 2023-03-22 08:23:25 --> Security Class Initialized
DEBUG - 2023-03-22 08:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:23:25 --> Input Class Initialized
INFO - 2023-03-22 08:23:25 --> Language Class Initialized
INFO - 2023-03-22 08:23:25 --> Loader Class Initialized
INFO - 2023-03-22 08:23:25 --> Controller Class Initialized
DEBUG - 2023-03-22 08:23:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:23:25 --> Final output sent to browser
DEBUG - 2023-03-22 08:23:25 --> Total execution time: 0.0069
INFO - 2023-03-22 08:23:25 --> Config Class Initialized
INFO - 2023-03-22 08:23:25 --> Hooks Class Initialized
DEBUG - 2023-03-22 08:23:25 --> UTF-8 Support Enabled
INFO - 2023-03-22 08:23:25 --> Utf8 Class Initialized
INFO - 2023-03-22 08:23:25 --> URI Class Initialized
INFO - 2023-03-22 08:23:25 --> Router Class Initialized
INFO - 2023-03-22 08:23:25 --> Output Class Initialized
INFO - 2023-03-22 08:23:25 --> Security Class Initialized
DEBUG - 2023-03-22 08:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 08:23:25 --> Input Class Initialized
INFO - 2023-03-22 08:23:25 --> Language Class Initialized
INFO - 2023-03-22 08:23:25 --> Loader Class Initialized
INFO - 2023-03-22 08:23:25 --> Controller Class Initialized
DEBUG - 2023-03-22 08:23:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 08:23:25 --> Database Driver Class Initialized
INFO - 2023-03-22 08:23:25 --> Model "Cluster_model" initialized
INFO - 2023-03-22 08:23:25 --> Final output sent to browser
DEBUG - 2023-03-22 08:23:25 --> Total execution time: 0.0546
INFO - 2023-03-22 09:03:22 --> Config Class Initialized
INFO - 2023-03-22 09:03:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:03:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:03:22 --> Utf8 Class Initialized
INFO - 2023-03-22 09:03:22 --> URI Class Initialized
INFO - 2023-03-22 09:03:22 --> Router Class Initialized
INFO - 2023-03-22 09:03:22 --> Output Class Initialized
INFO - 2023-03-22 09:03:22 --> Security Class Initialized
DEBUG - 2023-03-22 09:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:03:22 --> Input Class Initialized
INFO - 2023-03-22 09:03:22 --> Language Class Initialized
INFO - 2023-03-22 09:03:22 --> Loader Class Initialized
INFO - 2023-03-22 09:03:22 --> Controller Class Initialized
DEBUG - 2023-03-22 09:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:03:22 --> Database Driver Class Initialized
INFO - 2023-03-22 09:03:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:03:22 --> Final output sent to browser
DEBUG - 2023-03-22 09:03:22 --> Total execution time: 0.0185
INFO - 2023-03-22 09:03:22 --> Config Class Initialized
INFO - 2023-03-22 09:03:23 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:03:23 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:03:23 --> Utf8 Class Initialized
INFO - 2023-03-22 09:03:23 --> URI Class Initialized
INFO - 2023-03-22 09:03:23 --> Router Class Initialized
INFO - 2023-03-22 09:03:23 --> Output Class Initialized
INFO - 2023-03-22 09:03:23 --> Security Class Initialized
DEBUG - 2023-03-22 09:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:03:23 --> Input Class Initialized
INFO - 2023-03-22 09:03:23 --> Language Class Initialized
INFO - 2023-03-22 09:03:23 --> Loader Class Initialized
INFO - 2023-03-22 09:03:23 --> Controller Class Initialized
DEBUG - 2023-03-22 09:03:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:03:23 --> Database Driver Class Initialized
INFO - 2023-03-22 09:03:23 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:03:23 --> Final output sent to browser
DEBUG - 2023-03-22 09:03:23 --> Total execution time: 0.1367
INFO - 2023-03-22 09:10:53 --> Config Class Initialized
INFO - 2023-03-22 09:10:53 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:10:53 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:10:53 --> Utf8 Class Initialized
INFO - 2023-03-22 09:10:53 --> URI Class Initialized
INFO - 2023-03-22 09:10:53 --> Router Class Initialized
INFO - 2023-03-22 09:10:53 --> Output Class Initialized
INFO - 2023-03-22 09:10:53 --> Security Class Initialized
DEBUG - 2023-03-22 09:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:10:53 --> Input Class Initialized
INFO - 2023-03-22 09:10:53 --> Language Class Initialized
INFO - 2023-03-22 09:10:53 --> Loader Class Initialized
INFO - 2023-03-22 09:10:53 --> Controller Class Initialized
DEBUG - 2023-03-22 09:10:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:10:53 --> Final output sent to browser
DEBUG - 2023-03-22 09:10:53 --> Total execution time: 0.0038
INFO - 2023-03-22 09:10:53 --> Config Class Initialized
INFO - 2023-03-22 09:10:53 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:10:53 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:10:53 --> Utf8 Class Initialized
INFO - 2023-03-22 09:10:53 --> URI Class Initialized
INFO - 2023-03-22 09:10:53 --> Router Class Initialized
INFO - 2023-03-22 09:10:53 --> Output Class Initialized
INFO - 2023-03-22 09:10:53 --> Security Class Initialized
DEBUG - 2023-03-22 09:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:10:53 --> Input Class Initialized
INFO - 2023-03-22 09:10:53 --> Language Class Initialized
INFO - 2023-03-22 09:10:53 --> Loader Class Initialized
INFO - 2023-03-22 09:10:53 --> Controller Class Initialized
DEBUG - 2023-03-22 09:10:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:10:53 --> Database Driver Class Initialized
INFO - 2023-03-22 09:10:53 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:10:53 --> Final output sent to browser
DEBUG - 2023-03-22 09:10:53 --> Total execution time: 0.0490
INFO - 2023-03-22 09:10:53 --> Config Class Initialized
INFO - 2023-03-22 09:10:54 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:10:54 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:10:54 --> Utf8 Class Initialized
INFO - 2023-03-22 09:10:54 --> URI Class Initialized
INFO - 2023-03-22 09:10:54 --> Router Class Initialized
INFO - 2023-03-22 09:10:54 --> Output Class Initialized
INFO - 2023-03-22 09:10:54 --> Security Class Initialized
DEBUG - 2023-03-22 09:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:10:54 --> Input Class Initialized
INFO - 2023-03-22 09:10:54 --> Language Class Initialized
INFO - 2023-03-22 09:10:54 --> Loader Class Initialized
INFO - 2023-03-22 09:10:54 --> Controller Class Initialized
DEBUG - 2023-03-22 09:10:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:10:54 --> Final output sent to browser
DEBUG - 2023-03-22 09:10:54 --> Total execution time: 0.0319
INFO - 2023-03-22 09:10:54 --> Config Class Initialized
INFO - 2023-03-22 09:10:54 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:10:54 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:10:54 --> Utf8 Class Initialized
INFO - 2023-03-22 09:10:54 --> URI Class Initialized
INFO - 2023-03-22 09:10:54 --> Router Class Initialized
INFO - 2023-03-22 09:10:54 --> Output Class Initialized
INFO - 2023-03-22 09:10:54 --> Security Class Initialized
DEBUG - 2023-03-22 09:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:10:54 --> Input Class Initialized
INFO - 2023-03-22 09:10:54 --> Language Class Initialized
INFO - 2023-03-22 09:10:54 --> Loader Class Initialized
INFO - 2023-03-22 09:10:54 --> Controller Class Initialized
DEBUG - 2023-03-22 09:10:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:10:54 --> Database Driver Class Initialized
INFO - 2023-03-22 09:10:54 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:10:54 --> Final output sent to browser
DEBUG - 2023-03-22 09:10:54 --> Total execution time: 0.0574
INFO - 2023-03-22 09:12:00 --> Config Class Initialized
INFO - 2023-03-22 09:12:00 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:12:00 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:12:00 --> Utf8 Class Initialized
INFO - 2023-03-22 09:12:00 --> URI Class Initialized
INFO - 2023-03-22 09:12:00 --> Router Class Initialized
INFO - 2023-03-22 09:12:00 --> Output Class Initialized
INFO - 2023-03-22 09:12:00 --> Security Class Initialized
DEBUG - 2023-03-22 09:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:12:00 --> Input Class Initialized
INFO - 2023-03-22 09:12:00 --> Language Class Initialized
INFO - 2023-03-22 09:12:00 --> Loader Class Initialized
INFO - 2023-03-22 09:12:00 --> Controller Class Initialized
DEBUG - 2023-03-22 09:12:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:12:00 --> Database Driver Class Initialized
INFO - 2023-03-22 09:12:00 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:12:00 --> Final output sent to browser
DEBUG - 2023-03-22 09:12:00 --> Total execution time: 0.0854
INFO - 2023-03-22 09:12:00 --> Config Class Initialized
INFO - 2023-03-22 09:12:00 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:12:00 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:12:00 --> Utf8 Class Initialized
INFO - 2023-03-22 09:12:00 --> URI Class Initialized
INFO - 2023-03-22 09:12:00 --> Router Class Initialized
INFO - 2023-03-22 09:12:00 --> Output Class Initialized
INFO - 2023-03-22 09:12:00 --> Security Class Initialized
DEBUG - 2023-03-22 09:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:12:00 --> Input Class Initialized
INFO - 2023-03-22 09:12:00 --> Language Class Initialized
INFO - 2023-03-22 09:12:00 --> Loader Class Initialized
INFO - 2023-03-22 09:12:00 --> Controller Class Initialized
DEBUG - 2023-03-22 09:12:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:12:00 --> Database Driver Class Initialized
INFO - 2023-03-22 09:12:00 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:12:00 --> Final output sent to browser
DEBUG - 2023-03-22 09:12:00 --> Total execution time: 0.0532
INFO - 2023-03-22 09:12:15 --> Config Class Initialized
INFO - 2023-03-22 09:12:15 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:12:15 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:12:15 --> Utf8 Class Initialized
INFO - 2023-03-22 09:12:15 --> URI Class Initialized
INFO - 2023-03-22 09:12:15 --> Router Class Initialized
INFO - 2023-03-22 09:12:15 --> Output Class Initialized
INFO - 2023-03-22 09:12:15 --> Security Class Initialized
DEBUG - 2023-03-22 09:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:12:15 --> Input Class Initialized
INFO - 2023-03-22 09:12:15 --> Language Class Initialized
INFO - 2023-03-22 09:12:15 --> Loader Class Initialized
INFO - 2023-03-22 09:12:15 --> Controller Class Initialized
DEBUG - 2023-03-22 09:12:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:12:15 --> Final output sent to browser
DEBUG - 2023-03-22 09:12:15 --> Total execution time: 0.0048
INFO - 2023-03-22 09:12:15 --> Config Class Initialized
INFO - 2023-03-22 09:12:15 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:12:15 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:12:15 --> Utf8 Class Initialized
INFO - 2023-03-22 09:12:15 --> URI Class Initialized
INFO - 2023-03-22 09:12:15 --> Router Class Initialized
INFO - 2023-03-22 09:12:15 --> Output Class Initialized
INFO - 2023-03-22 09:12:15 --> Security Class Initialized
DEBUG - 2023-03-22 09:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:12:15 --> Input Class Initialized
INFO - 2023-03-22 09:12:15 --> Language Class Initialized
INFO - 2023-03-22 09:12:15 --> Loader Class Initialized
INFO - 2023-03-22 09:12:15 --> Controller Class Initialized
DEBUG - 2023-03-22 09:12:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:12:15 --> Database Driver Class Initialized
INFO - 2023-03-22 09:12:15 --> Model "Login_model" initialized
INFO - 2023-03-22 09:12:15 --> Database Driver Class Initialized
INFO - 2023-03-22 09:12:15 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:12:15 --> Final output sent to browser
DEBUG - 2023-03-22 09:12:15 --> Total execution time: 0.0278
INFO - 2023-03-22 09:12:16 --> Config Class Initialized
INFO - 2023-03-22 09:12:16 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:12:16 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:12:16 --> Utf8 Class Initialized
INFO - 2023-03-22 09:12:16 --> URI Class Initialized
INFO - 2023-03-22 09:12:16 --> Router Class Initialized
INFO - 2023-03-22 09:12:16 --> Output Class Initialized
INFO - 2023-03-22 09:12:16 --> Security Class Initialized
DEBUG - 2023-03-22 09:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:12:16 --> Input Class Initialized
INFO - 2023-03-22 09:12:16 --> Language Class Initialized
INFO - 2023-03-22 09:12:16 --> Loader Class Initialized
INFO - 2023-03-22 09:12:16 --> Controller Class Initialized
DEBUG - 2023-03-22 09:12:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:12:16 --> Database Driver Class Initialized
INFO - 2023-03-22 09:12:16 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:12:16 --> Final output sent to browser
DEBUG - 2023-03-22 09:12:16 --> Total execution time: 0.0277
INFO - 2023-03-22 09:12:16 --> Config Class Initialized
INFO - 2023-03-22 09:12:16 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:12:16 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:12:16 --> Utf8 Class Initialized
INFO - 2023-03-22 09:12:16 --> URI Class Initialized
INFO - 2023-03-22 09:12:16 --> Router Class Initialized
INFO - 2023-03-22 09:12:16 --> Output Class Initialized
INFO - 2023-03-22 09:12:16 --> Security Class Initialized
DEBUG - 2023-03-22 09:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:12:16 --> Input Class Initialized
INFO - 2023-03-22 09:12:16 --> Language Class Initialized
INFO - 2023-03-22 09:12:16 --> Loader Class Initialized
INFO - 2023-03-22 09:12:16 --> Controller Class Initialized
DEBUG - 2023-03-22 09:12:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:12:16 --> Database Driver Class Initialized
INFO - 2023-03-22 09:12:16 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:12:16 --> Final output sent to browser
DEBUG - 2023-03-22 09:12:16 --> Total execution time: 0.0603
INFO - 2023-03-22 09:12:18 --> Config Class Initialized
INFO - 2023-03-22 09:12:18 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:12:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:12:18 --> Utf8 Class Initialized
INFO - 2023-03-22 09:12:18 --> URI Class Initialized
INFO - 2023-03-22 09:12:18 --> Router Class Initialized
INFO - 2023-03-22 09:12:18 --> Output Class Initialized
INFO - 2023-03-22 09:12:18 --> Security Class Initialized
DEBUG - 2023-03-22 09:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:12:18 --> Input Class Initialized
INFO - 2023-03-22 09:12:18 --> Language Class Initialized
INFO - 2023-03-22 09:12:18 --> Loader Class Initialized
INFO - 2023-03-22 09:12:18 --> Controller Class Initialized
DEBUG - 2023-03-22 09:12:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:12:18 --> Database Driver Class Initialized
INFO - 2023-03-22 09:12:18 --> Model "Login_model" initialized
INFO - 2023-03-22 09:12:18 --> Database Driver Class Initialized
INFO - 2023-03-22 09:12:18 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:12:18 --> Final output sent to browser
DEBUG - 2023-03-22 09:12:18 --> Total execution time: 0.0701
INFO - 2023-03-22 09:12:19 --> Config Class Initialized
INFO - 2023-03-22 09:12:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:12:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:12:19 --> Utf8 Class Initialized
INFO - 2023-03-22 09:12:19 --> URI Class Initialized
INFO - 2023-03-22 09:12:19 --> Router Class Initialized
INFO - 2023-03-22 09:12:19 --> Output Class Initialized
INFO - 2023-03-22 09:12:19 --> Security Class Initialized
DEBUG - 2023-03-22 09:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:12:19 --> Input Class Initialized
INFO - 2023-03-22 09:12:19 --> Language Class Initialized
INFO - 2023-03-22 09:12:19 --> Loader Class Initialized
INFO - 2023-03-22 09:12:19 --> Controller Class Initialized
DEBUG - 2023-03-22 09:12:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:12:19 --> Database Driver Class Initialized
INFO - 2023-03-22 09:12:19 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:12:19 --> Final output sent to browser
DEBUG - 2023-03-22 09:12:19 --> Total execution time: 0.0519
INFO - 2023-03-22 09:12:19 --> Config Class Initialized
INFO - 2023-03-22 09:12:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:12:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:12:19 --> Utf8 Class Initialized
INFO - 2023-03-22 09:12:19 --> URI Class Initialized
INFO - 2023-03-22 09:12:19 --> Router Class Initialized
INFO - 2023-03-22 09:12:19 --> Output Class Initialized
INFO - 2023-03-22 09:12:19 --> Security Class Initialized
DEBUG - 2023-03-22 09:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:12:19 --> Input Class Initialized
INFO - 2023-03-22 09:12:19 --> Language Class Initialized
INFO - 2023-03-22 09:12:19 --> Loader Class Initialized
INFO - 2023-03-22 09:12:19 --> Controller Class Initialized
DEBUG - 2023-03-22 09:12:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:12:19 --> Database Driver Class Initialized
INFO - 2023-03-22 09:12:19 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:12:19 --> Final output sent to browser
DEBUG - 2023-03-22 09:12:19 --> Total execution time: 0.0322
INFO - 2023-03-22 09:13:11 --> Config Class Initialized
INFO - 2023-03-22 09:13:11 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:13:11 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:13:11 --> Utf8 Class Initialized
INFO - 2023-03-22 09:13:11 --> URI Class Initialized
INFO - 2023-03-22 09:13:11 --> Router Class Initialized
INFO - 2023-03-22 09:13:11 --> Output Class Initialized
INFO - 2023-03-22 09:13:11 --> Security Class Initialized
DEBUG - 2023-03-22 09:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:13:11 --> Input Class Initialized
INFO - 2023-03-22 09:13:11 --> Language Class Initialized
INFO - 2023-03-22 09:13:11 --> Loader Class Initialized
INFO - 2023-03-22 09:13:11 --> Controller Class Initialized
DEBUG - 2023-03-22 09:13:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:13:11 --> Final output sent to browser
DEBUG - 2023-03-22 09:13:11 --> Total execution time: 0.0047
INFO - 2023-03-22 09:13:11 --> Config Class Initialized
INFO - 2023-03-22 09:13:11 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:13:11 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:13:11 --> Utf8 Class Initialized
INFO - 2023-03-22 09:13:11 --> URI Class Initialized
INFO - 2023-03-22 09:13:11 --> Router Class Initialized
INFO - 2023-03-22 09:13:11 --> Output Class Initialized
INFO - 2023-03-22 09:13:11 --> Security Class Initialized
DEBUG - 2023-03-22 09:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:13:11 --> Input Class Initialized
INFO - 2023-03-22 09:13:11 --> Language Class Initialized
INFO - 2023-03-22 09:13:11 --> Loader Class Initialized
INFO - 2023-03-22 09:13:11 --> Controller Class Initialized
DEBUG - 2023-03-22 09:13:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:13:11 --> Database Driver Class Initialized
INFO - 2023-03-22 09:13:11 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:13:11 --> Final output sent to browser
DEBUG - 2023-03-22 09:13:11 --> Total execution time: 0.0572
INFO - 2023-03-22 09:13:11 --> Config Class Initialized
INFO - 2023-03-22 09:13:11 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:13:11 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:13:11 --> Utf8 Class Initialized
INFO - 2023-03-22 09:13:11 --> URI Class Initialized
INFO - 2023-03-22 09:13:11 --> Router Class Initialized
INFO - 2023-03-22 09:13:11 --> Output Class Initialized
INFO - 2023-03-22 09:13:11 --> Security Class Initialized
DEBUG - 2023-03-22 09:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:13:11 --> Input Class Initialized
INFO - 2023-03-22 09:13:11 --> Language Class Initialized
INFO - 2023-03-22 09:13:11 --> Loader Class Initialized
INFO - 2023-03-22 09:13:11 --> Controller Class Initialized
DEBUG - 2023-03-22 09:13:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:13:11 --> Final output sent to browser
DEBUG - 2023-03-22 09:13:11 --> Total execution time: 0.0154
INFO - 2023-03-22 09:13:11 --> Config Class Initialized
INFO - 2023-03-22 09:13:12 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:13:12 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:13:12 --> Utf8 Class Initialized
INFO - 2023-03-22 09:13:12 --> URI Class Initialized
INFO - 2023-03-22 09:13:12 --> Router Class Initialized
INFO - 2023-03-22 09:13:12 --> Output Class Initialized
INFO - 2023-03-22 09:13:12 --> Security Class Initialized
DEBUG - 2023-03-22 09:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:13:12 --> Input Class Initialized
INFO - 2023-03-22 09:13:12 --> Language Class Initialized
INFO - 2023-03-22 09:13:12 --> Loader Class Initialized
INFO - 2023-03-22 09:13:12 --> Controller Class Initialized
DEBUG - 2023-03-22 09:13:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:13:12 --> Database Driver Class Initialized
INFO - 2023-03-22 09:13:12 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:13:12 --> Final output sent to browser
DEBUG - 2023-03-22 09:13:12 --> Total execution time: 0.0365
INFO - 2023-03-22 09:14:00 --> Config Class Initialized
INFO - 2023-03-22 09:14:00 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:14:00 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:14:00 --> Utf8 Class Initialized
INFO - 2023-03-22 09:14:00 --> URI Class Initialized
INFO - 2023-03-22 09:14:00 --> Router Class Initialized
INFO - 2023-03-22 09:14:00 --> Output Class Initialized
INFO - 2023-03-22 09:14:00 --> Security Class Initialized
DEBUG - 2023-03-22 09:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:14:00 --> Input Class Initialized
INFO - 2023-03-22 09:14:00 --> Language Class Initialized
INFO - 2023-03-22 09:14:00 --> Loader Class Initialized
INFO - 2023-03-22 09:14:00 --> Controller Class Initialized
DEBUG - 2023-03-22 09:14:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:14:00 --> Database Driver Class Initialized
INFO - 2023-03-22 09:14:00 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:14:00 --> Final output sent to browser
DEBUG - 2023-03-22 09:14:00 --> Total execution time: 0.0378
INFO - 2023-03-22 09:14:00 --> Config Class Initialized
INFO - 2023-03-22 09:14:00 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:14:00 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:14:00 --> Utf8 Class Initialized
INFO - 2023-03-22 09:14:00 --> URI Class Initialized
INFO - 2023-03-22 09:14:00 --> Router Class Initialized
INFO - 2023-03-22 09:14:00 --> Output Class Initialized
INFO - 2023-03-22 09:14:00 --> Security Class Initialized
DEBUG - 2023-03-22 09:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:14:00 --> Input Class Initialized
INFO - 2023-03-22 09:14:00 --> Language Class Initialized
INFO - 2023-03-22 09:14:00 --> Loader Class Initialized
INFO - 2023-03-22 09:14:00 --> Controller Class Initialized
DEBUG - 2023-03-22 09:14:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:14:00 --> Database Driver Class Initialized
INFO - 2023-03-22 09:14:00 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:14:00 --> Final output sent to browser
DEBUG - 2023-03-22 09:14:00 --> Total execution time: 0.0125
INFO - 2023-03-22 09:14:03 --> Config Class Initialized
INFO - 2023-03-22 09:14:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:14:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:14:03 --> Utf8 Class Initialized
INFO - 2023-03-22 09:14:03 --> URI Class Initialized
INFO - 2023-03-22 09:14:03 --> Router Class Initialized
INFO - 2023-03-22 09:14:03 --> Output Class Initialized
INFO - 2023-03-22 09:14:03 --> Security Class Initialized
DEBUG - 2023-03-22 09:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:14:03 --> Input Class Initialized
INFO - 2023-03-22 09:14:03 --> Language Class Initialized
INFO - 2023-03-22 09:14:03 --> Loader Class Initialized
INFO - 2023-03-22 09:14:03 --> Controller Class Initialized
DEBUG - 2023-03-22 09:14:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:14:03 --> Final output sent to browser
DEBUG - 2023-03-22 09:14:03 --> Total execution time: 0.0037
INFO - 2023-03-22 09:14:03 --> Config Class Initialized
INFO - 2023-03-22 09:14:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:14:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:14:03 --> Utf8 Class Initialized
INFO - 2023-03-22 09:14:03 --> URI Class Initialized
INFO - 2023-03-22 09:14:03 --> Router Class Initialized
INFO - 2023-03-22 09:14:03 --> Output Class Initialized
INFO - 2023-03-22 09:14:03 --> Security Class Initialized
DEBUG - 2023-03-22 09:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:14:03 --> Input Class Initialized
INFO - 2023-03-22 09:14:03 --> Language Class Initialized
INFO - 2023-03-22 09:14:03 --> Loader Class Initialized
INFO - 2023-03-22 09:14:03 --> Controller Class Initialized
DEBUG - 2023-03-22 09:14:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:14:03 --> Database Driver Class Initialized
INFO - 2023-03-22 09:14:03 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:14:04 --> Final output sent to browser
DEBUG - 2023-03-22 09:14:04 --> Total execution time: 0.0960
INFO - 2023-03-22 09:14:04 --> Config Class Initialized
INFO - 2023-03-22 09:14:04 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:14:04 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:14:04 --> Utf8 Class Initialized
INFO - 2023-03-22 09:14:04 --> URI Class Initialized
INFO - 2023-03-22 09:14:04 --> Router Class Initialized
INFO - 2023-03-22 09:14:04 --> Output Class Initialized
INFO - 2023-03-22 09:14:04 --> Security Class Initialized
DEBUG - 2023-03-22 09:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:14:04 --> Input Class Initialized
INFO - 2023-03-22 09:14:04 --> Language Class Initialized
INFO - 2023-03-22 09:14:04 --> Loader Class Initialized
INFO - 2023-03-22 09:14:04 --> Controller Class Initialized
DEBUG - 2023-03-22 09:14:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:14:04 --> Final output sent to browser
DEBUG - 2023-03-22 09:14:04 --> Total execution time: 0.0860
INFO - 2023-03-22 09:14:04 --> Config Class Initialized
INFO - 2023-03-22 09:14:04 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:14:04 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:14:04 --> Utf8 Class Initialized
INFO - 2023-03-22 09:14:04 --> URI Class Initialized
INFO - 2023-03-22 09:14:04 --> Router Class Initialized
INFO - 2023-03-22 09:14:04 --> Output Class Initialized
INFO - 2023-03-22 09:14:04 --> Security Class Initialized
DEBUG - 2023-03-22 09:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:14:04 --> Input Class Initialized
INFO - 2023-03-22 09:14:04 --> Language Class Initialized
INFO - 2023-03-22 09:14:04 --> Loader Class Initialized
INFO - 2023-03-22 09:14:04 --> Controller Class Initialized
DEBUG - 2023-03-22 09:14:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:14:04 --> Database Driver Class Initialized
INFO - 2023-03-22 09:14:04 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:14:04 --> Final output sent to browser
DEBUG - 2023-03-22 09:14:04 --> Total execution time: 0.0357
INFO - 2023-03-22 09:20:29 --> Config Class Initialized
INFO - 2023-03-22 09:20:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:20:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:20:29 --> Utf8 Class Initialized
INFO - 2023-03-22 09:20:29 --> URI Class Initialized
INFO - 2023-03-22 09:20:29 --> Router Class Initialized
INFO - 2023-03-22 09:20:29 --> Output Class Initialized
INFO - 2023-03-22 09:20:29 --> Security Class Initialized
DEBUG - 2023-03-22 09:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:20:29 --> Input Class Initialized
INFO - 2023-03-22 09:20:29 --> Language Class Initialized
INFO - 2023-03-22 09:20:29 --> Loader Class Initialized
INFO - 2023-03-22 09:20:29 --> Controller Class Initialized
DEBUG - 2023-03-22 09:20:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:20:29 --> Database Driver Class Initialized
INFO - 2023-03-22 09:20:29 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:20:29 --> Final output sent to browser
DEBUG - 2023-03-22 09:20:29 --> Total execution time: 0.0214
INFO - 2023-03-22 09:20:29 --> Config Class Initialized
INFO - 2023-03-22 09:20:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:20:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:20:29 --> Utf8 Class Initialized
INFO - 2023-03-22 09:20:29 --> URI Class Initialized
INFO - 2023-03-22 09:20:29 --> Router Class Initialized
INFO - 2023-03-22 09:20:29 --> Output Class Initialized
INFO - 2023-03-22 09:20:29 --> Security Class Initialized
DEBUG - 2023-03-22 09:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:20:29 --> Input Class Initialized
INFO - 2023-03-22 09:20:29 --> Language Class Initialized
INFO - 2023-03-22 09:20:29 --> Loader Class Initialized
INFO - 2023-03-22 09:20:29 --> Controller Class Initialized
DEBUG - 2023-03-22 09:20:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:20:29 --> Database Driver Class Initialized
INFO - 2023-03-22 09:20:29 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:20:29 --> Final output sent to browser
DEBUG - 2023-03-22 09:20:29 --> Total execution time: 0.0627
INFO - 2023-03-22 09:21:12 --> Config Class Initialized
INFO - 2023-03-22 09:21:12 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:21:12 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:21:12 --> Utf8 Class Initialized
INFO - 2023-03-22 09:21:12 --> URI Class Initialized
INFO - 2023-03-22 09:21:12 --> Router Class Initialized
INFO - 2023-03-22 09:21:12 --> Output Class Initialized
INFO - 2023-03-22 09:21:12 --> Security Class Initialized
DEBUG - 2023-03-22 09:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:21:12 --> Input Class Initialized
INFO - 2023-03-22 09:21:12 --> Language Class Initialized
INFO - 2023-03-22 09:21:12 --> Loader Class Initialized
INFO - 2023-03-22 09:21:12 --> Controller Class Initialized
DEBUG - 2023-03-22 09:21:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:21:12 --> Final output sent to browser
DEBUG - 2023-03-22 09:21:12 --> Total execution time: 0.0038
INFO - 2023-03-22 09:21:12 --> Config Class Initialized
INFO - 2023-03-22 09:21:12 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:21:12 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:21:12 --> Utf8 Class Initialized
INFO - 2023-03-22 09:21:12 --> URI Class Initialized
INFO - 2023-03-22 09:21:12 --> Router Class Initialized
INFO - 2023-03-22 09:21:12 --> Output Class Initialized
INFO - 2023-03-22 09:21:12 --> Security Class Initialized
DEBUG - 2023-03-22 09:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:21:12 --> Input Class Initialized
INFO - 2023-03-22 09:21:12 --> Language Class Initialized
INFO - 2023-03-22 09:21:12 --> Loader Class Initialized
INFO - 2023-03-22 09:21:12 --> Controller Class Initialized
DEBUG - 2023-03-22 09:21:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:21:12 --> Database Driver Class Initialized
INFO - 2023-03-22 09:21:12 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:21:12 --> Final output sent to browser
DEBUG - 2023-03-22 09:21:12 --> Total execution time: 0.0201
INFO - 2023-03-22 09:21:12 --> Config Class Initialized
INFO - 2023-03-22 09:21:12 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:21:12 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:21:12 --> Utf8 Class Initialized
INFO - 2023-03-22 09:21:12 --> URI Class Initialized
INFO - 2023-03-22 09:21:12 --> Router Class Initialized
INFO - 2023-03-22 09:21:12 --> Output Class Initialized
INFO - 2023-03-22 09:21:12 --> Security Class Initialized
DEBUG - 2023-03-22 09:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:21:12 --> Input Class Initialized
INFO - 2023-03-22 09:21:12 --> Language Class Initialized
INFO - 2023-03-22 09:21:12 --> Loader Class Initialized
INFO - 2023-03-22 09:21:12 --> Controller Class Initialized
DEBUG - 2023-03-22 09:21:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:21:12 --> Final output sent to browser
DEBUG - 2023-03-22 09:21:12 --> Total execution time: 0.0419
INFO - 2023-03-22 09:21:12 --> Config Class Initialized
INFO - 2023-03-22 09:21:12 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:21:12 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:21:12 --> Utf8 Class Initialized
INFO - 2023-03-22 09:21:12 --> URI Class Initialized
INFO - 2023-03-22 09:21:12 --> Router Class Initialized
INFO - 2023-03-22 09:21:12 --> Output Class Initialized
INFO - 2023-03-22 09:21:12 --> Security Class Initialized
DEBUG - 2023-03-22 09:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:21:12 --> Input Class Initialized
INFO - 2023-03-22 09:21:12 --> Language Class Initialized
INFO - 2023-03-22 09:21:12 --> Loader Class Initialized
INFO - 2023-03-22 09:21:12 --> Controller Class Initialized
DEBUG - 2023-03-22 09:21:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:21:12 --> Database Driver Class Initialized
INFO - 2023-03-22 09:21:12 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:21:12 --> Final output sent to browser
DEBUG - 2023-03-22 09:21:12 --> Total execution time: 0.0133
INFO - 2023-03-22 09:22:03 --> Config Class Initialized
INFO - 2023-03-22 09:22:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:22:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:22:03 --> Utf8 Class Initialized
INFO - 2023-03-22 09:22:03 --> URI Class Initialized
INFO - 2023-03-22 09:22:03 --> Router Class Initialized
INFO - 2023-03-22 09:22:03 --> Output Class Initialized
INFO - 2023-03-22 09:22:03 --> Security Class Initialized
DEBUG - 2023-03-22 09:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:22:03 --> Input Class Initialized
INFO - 2023-03-22 09:22:03 --> Language Class Initialized
INFO - 2023-03-22 09:22:03 --> Loader Class Initialized
INFO - 2023-03-22 09:22:03 --> Controller Class Initialized
DEBUG - 2023-03-22 09:22:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:22:03 --> Database Driver Class Initialized
INFO - 2023-03-22 09:22:03 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:22:03 --> Final output sent to browser
DEBUG - 2023-03-22 09:22:03 --> Total execution time: 0.0549
INFO - 2023-03-22 09:22:03 --> Config Class Initialized
INFO - 2023-03-22 09:22:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:22:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:22:03 --> Utf8 Class Initialized
INFO - 2023-03-22 09:22:03 --> URI Class Initialized
INFO - 2023-03-22 09:22:03 --> Router Class Initialized
INFO - 2023-03-22 09:22:03 --> Output Class Initialized
INFO - 2023-03-22 09:22:03 --> Security Class Initialized
DEBUG - 2023-03-22 09:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:22:03 --> Input Class Initialized
INFO - 2023-03-22 09:22:03 --> Language Class Initialized
INFO - 2023-03-22 09:22:03 --> Loader Class Initialized
INFO - 2023-03-22 09:22:03 --> Controller Class Initialized
DEBUG - 2023-03-22 09:22:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:22:03 --> Database Driver Class Initialized
INFO - 2023-03-22 09:22:03 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:22:03 --> Final output sent to browser
DEBUG - 2023-03-22 09:22:03 --> Total execution time: 0.0157
INFO - 2023-03-22 09:22:10 --> Config Class Initialized
INFO - 2023-03-22 09:22:10 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:22:10 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:22:10 --> Utf8 Class Initialized
INFO - 2023-03-22 09:22:10 --> URI Class Initialized
INFO - 2023-03-22 09:22:10 --> Router Class Initialized
INFO - 2023-03-22 09:22:10 --> Output Class Initialized
INFO - 2023-03-22 09:22:10 --> Security Class Initialized
DEBUG - 2023-03-22 09:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:22:10 --> Input Class Initialized
INFO - 2023-03-22 09:22:10 --> Language Class Initialized
INFO - 2023-03-22 09:22:10 --> Loader Class Initialized
INFO - 2023-03-22 09:22:10 --> Controller Class Initialized
DEBUG - 2023-03-22 09:22:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:22:10 --> Final output sent to browser
DEBUG - 2023-03-22 09:22:10 --> Total execution time: 0.0037
INFO - 2023-03-22 09:22:10 --> Config Class Initialized
INFO - 2023-03-22 09:22:10 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:22:10 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:22:10 --> Utf8 Class Initialized
INFO - 2023-03-22 09:22:10 --> URI Class Initialized
INFO - 2023-03-22 09:22:10 --> Router Class Initialized
INFO - 2023-03-22 09:22:10 --> Output Class Initialized
INFO - 2023-03-22 09:22:10 --> Security Class Initialized
DEBUG - 2023-03-22 09:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:22:10 --> Input Class Initialized
INFO - 2023-03-22 09:22:10 --> Language Class Initialized
INFO - 2023-03-22 09:22:10 --> Loader Class Initialized
INFO - 2023-03-22 09:22:10 --> Controller Class Initialized
DEBUG - 2023-03-22 09:22:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:22:10 --> Database Driver Class Initialized
INFO - 2023-03-22 09:22:10 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:22:10 --> Final output sent to browser
DEBUG - 2023-03-22 09:22:10 --> Total execution time: 0.0541
INFO - 2023-03-22 09:22:10 --> Config Class Initialized
INFO - 2023-03-22 09:22:10 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:22:10 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:22:10 --> Utf8 Class Initialized
INFO - 2023-03-22 09:22:10 --> URI Class Initialized
INFO - 2023-03-22 09:22:10 --> Router Class Initialized
INFO - 2023-03-22 09:22:10 --> Output Class Initialized
INFO - 2023-03-22 09:22:10 --> Security Class Initialized
DEBUG - 2023-03-22 09:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:22:10 --> Input Class Initialized
INFO - 2023-03-22 09:22:10 --> Language Class Initialized
INFO - 2023-03-22 09:22:10 --> Loader Class Initialized
INFO - 2023-03-22 09:22:10 --> Controller Class Initialized
DEBUG - 2023-03-22 09:22:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:22:10 --> Final output sent to browser
DEBUG - 2023-03-22 09:22:10 --> Total execution time: 0.0425
INFO - 2023-03-22 09:22:10 --> Config Class Initialized
INFO - 2023-03-22 09:22:10 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:22:10 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:22:10 --> Utf8 Class Initialized
INFO - 2023-03-22 09:22:10 --> URI Class Initialized
INFO - 2023-03-22 09:22:10 --> Router Class Initialized
INFO - 2023-03-22 09:22:10 --> Output Class Initialized
INFO - 2023-03-22 09:22:10 --> Security Class Initialized
DEBUG - 2023-03-22 09:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:22:10 --> Input Class Initialized
INFO - 2023-03-22 09:22:10 --> Language Class Initialized
INFO - 2023-03-22 09:22:10 --> Loader Class Initialized
INFO - 2023-03-22 09:22:10 --> Controller Class Initialized
DEBUG - 2023-03-22 09:22:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:22:10 --> Database Driver Class Initialized
INFO - 2023-03-22 09:22:10 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:22:10 --> Final output sent to browser
DEBUG - 2023-03-22 09:22:10 --> Total execution time: 0.0605
INFO - 2023-03-22 09:22:49 --> Config Class Initialized
INFO - 2023-03-22 09:22:49 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:22:49 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:22:49 --> Utf8 Class Initialized
INFO - 2023-03-22 09:22:49 --> URI Class Initialized
INFO - 2023-03-22 09:22:49 --> Router Class Initialized
INFO - 2023-03-22 09:22:49 --> Output Class Initialized
INFO - 2023-03-22 09:22:49 --> Security Class Initialized
DEBUG - 2023-03-22 09:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:22:49 --> Input Class Initialized
INFO - 2023-03-22 09:22:49 --> Language Class Initialized
INFO - 2023-03-22 09:22:49 --> Loader Class Initialized
INFO - 2023-03-22 09:22:49 --> Controller Class Initialized
DEBUG - 2023-03-22 09:22:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:22:49 --> Database Driver Class Initialized
INFO - 2023-03-22 09:22:49 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:22:49 --> Final output sent to browser
DEBUG - 2023-03-22 09:22:49 --> Total execution time: 0.0584
INFO - 2023-03-22 09:22:49 --> Config Class Initialized
INFO - 2023-03-22 09:22:49 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:22:49 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:22:49 --> Utf8 Class Initialized
INFO - 2023-03-22 09:22:49 --> URI Class Initialized
INFO - 2023-03-22 09:22:49 --> Router Class Initialized
INFO - 2023-03-22 09:22:49 --> Output Class Initialized
INFO - 2023-03-22 09:22:49 --> Security Class Initialized
DEBUG - 2023-03-22 09:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:22:49 --> Input Class Initialized
INFO - 2023-03-22 09:22:49 --> Language Class Initialized
INFO - 2023-03-22 09:22:49 --> Loader Class Initialized
INFO - 2023-03-22 09:22:49 --> Controller Class Initialized
DEBUG - 2023-03-22 09:22:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:22:49 --> Database Driver Class Initialized
INFO - 2023-03-22 09:22:49 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:22:49 --> Final output sent to browser
DEBUG - 2023-03-22 09:22:49 --> Total execution time: 0.0169
INFO - 2023-03-22 09:23:03 --> Config Class Initialized
INFO - 2023-03-22 09:23:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:23:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:23:03 --> Utf8 Class Initialized
INFO - 2023-03-22 09:23:03 --> URI Class Initialized
INFO - 2023-03-22 09:23:03 --> Router Class Initialized
INFO - 2023-03-22 09:23:03 --> Output Class Initialized
INFO - 2023-03-22 09:23:03 --> Security Class Initialized
DEBUG - 2023-03-22 09:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:23:03 --> Input Class Initialized
INFO - 2023-03-22 09:23:03 --> Language Class Initialized
INFO - 2023-03-22 09:23:03 --> Loader Class Initialized
INFO - 2023-03-22 09:23:03 --> Controller Class Initialized
DEBUG - 2023-03-22 09:23:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:23:03 --> Database Driver Class Initialized
INFO - 2023-03-22 09:23:03 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:23:03 --> Final output sent to browser
DEBUG - 2023-03-22 09:23:03 --> Total execution time: 0.1087
INFO - 2023-03-22 09:23:03 --> Config Class Initialized
INFO - 2023-03-22 09:23:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:23:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:23:03 --> Utf8 Class Initialized
INFO - 2023-03-22 09:23:03 --> URI Class Initialized
INFO - 2023-03-22 09:23:03 --> Router Class Initialized
INFO - 2023-03-22 09:23:03 --> Output Class Initialized
INFO - 2023-03-22 09:23:03 --> Security Class Initialized
DEBUG - 2023-03-22 09:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:23:03 --> Input Class Initialized
INFO - 2023-03-22 09:23:03 --> Language Class Initialized
INFO - 2023-03-22 09:23:03 --> Loader Class Initialized
INFO - 2023-03-22 09:23:03 --> Controller Class Initialized
DEBUG - 2023-03-22 09:23:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:23:03 --> Database Driver Class Initialized
INFO - 2023-03-22 09:23:03 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:23:03 --> Final output sent to browser
DEBUG - 2023-03-22 09:23:03 --> Total execution time: 0.0120
INFO - 2023-03-22 09:23:06 --> Config Class Initialized
INFO - 2023-03-22 09:23:06 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:23:06 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:23:06 --> Utf8 Class Initialized
INFO - 2023-03-22 09:23:06 --> URI Class Initialized
INFO - 2023-03-22 09:23:06 --> Router Class Initialized
INFO - 2023-03-22 09:23:06 --> Output Class Initialized
INFO - 2023-03-22 09:23:06 --> Security Class Initialized
DEBUG - 2023-03-22 09:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:23:06 --> Input Class Initialized
INFO - 2023-03-22 09:23:06 --> Language Class Initialized
INFO - 2023-03-22 09:23:06 --> Loader Class Initialized
INFO - 2023-03-22 09:23:06 --> Controller Class Initialized
DEBUG - 2023-03-22 09:23:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:23:06 --> Final output sent to browser
DEBUG - 2023-03-22 09:23:06 --> Total execution time: 0.0037
INFO - 2023-03-22 09:23:06 --> Config Class Initialized
INFO - 2023-03-22 09:23:06 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:23:06 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:23:06 --> Utf8 Class Initialized
INFO - 2023-03-22 09:23:06 --> URI Class Initialized
INFO - 2023-03-22 09:23:06 --> Router Class Initialized
INFO - 2023-03-22 09:23:06 --> Output Class Initialized
INFO - 2023-03-22 09:23:06 --> Security Class Initialized
DEBUG - 2023-03-22 09:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:23:06 --> Input Class Initialized
INFO - 2023-03-22 09:23:06 --> Language Class Initialized
INFO - 2023-03-22 09:23:06 --> Loader Class Initialized
INFO - 2023-03-22 09:23:06 --> Controller Class Initialized
DEBUG - 2023-03-22 09:23:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:23:06 --> Database Driver Class Initialized
INFO - 2023-03-22 09:23:06 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:23:06 --> Final output sent to browser
DEBUG - 2023-03-22 09:23:06 --> Total execution time: 0.0115
INFO - 2023-03-22 09:23:06 --> Config Class Initialized
INFO - 2023-03-22 09:23:06 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:23:06 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:23:06 --> Utf8 Class Initialized
INFO - 2023-03-22 09:23:06 --> URI Class Initialized
INFO - 2023-03-22 09:23:06 --> Router Class Initialized
INFO - 2023-03-22 09:23:06 --> Output Class Initialized
INFO - 2023-03-22 09:23:06 --> Security Class Initialized
DEBUG - 2023-03-22 09:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:23:06 --> Input Class Initialized
INFO - 2023-03-22 09:23:06 --> Language Class Initialized
INFO - 2023-03-22 09:23:06 --> Loader Class Initialized
INFO - 2023-03-22 09:23:06 --> Controller Class Initialized
DEBUG - 2023-03-22 09:23:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:23:06 --> Final output sent to browser
DEBUG - 2023-03-22 09:23:06 --> Total execution time: 0.0423
INFO - 2023-03-22 09:23:06 --> Config Class Initialized
INFO - 2023-03-22 09:23:06 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:23:06 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:23:06 --> Utf8 Class Initialized
INFO - 2023-03-22 09:23:06 --> URI Class Initialized
INFO - 2023-03-22 09:23:06 --> Router Class Initialized
INFO - 2023-03-22 09:23:06 --> Output Class Initialized
INFO - 2023-03-22 09:23:06 --> Security Class Initialized
DEBUG - 2023-03-22 09:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:23:06 --> Input Class Initialized
INFO - 2023-03-22 09:23:06 --> Language Class Initialized
INFO - 2023-03-22 09:23:06 --> Loader Class Initialized
INFO - 2023-03-22 09:23:06 --> Controller Class Initialized
DEBUG - 2023-03-22 09:23:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:23:06 --> Database Driver Class Initialized
INFO - 2023-03-22 09:23:06 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:23:06 --> Final output sent to browser
DEBUG - 2023-03-22 09:23:06 --> Total execution time: 0.0111
INFO - 2023-03-22 09:24:07 --> Config Class Initialized
INFO - 2023-03-22 09:24:07 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:24:07 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:24:07 --> Utf8 Class Initialized
INFO - 2023-03-22 09:24:07 --> URI Class Initialized
INFO - 2023-03-22 09:24:07 --> Router Class Initialized
INFO - 2023-03-22 09:24:07 --> Output Class Initialized
INFO - 2023-03-22 09:24:07 --> Security Class Initialized
DEBUG - 2023-03-22 09:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:24:07 --> Input Class Initialized
INFO - 2023-03-22 09:24:07 --> Language Class Initialized
INFO - 2023-03-22 09:24:07 --> Loader Class Initialized
INFO - 2023-03-22 09:24:07 --> Controller Class Initialized
DEBUG - 2023-03-22 09:24:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:24:07 --> Database Driver Class Initialized
INFO - 2023-03-22 09:24:07 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:24:07 --> Final output sent to browser
DEBUG - 2023-03-22 09:24:07 --> Total execution time: 0.0163
INFO - 2023-03-22 09:24:07 --> Config Class Initialized
INFO - 2023-03-22 09:24:07 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:24:07 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:24:07 --> Utf8 Class Initialized
INFO - 2023-03-22 09:24:07 --> URI Class Initialized
INFO - 2023-03-22 09:24:07 --> Router Class Initialized
INFO - 2023-03-22 09:24:07 --> Output Class Initialized
INFO - 2023-03-22 09:24:07 --> Security Class Initialized
DEBUG - 2023-03-22 09:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:24:07 --> Input Class Initialized
INFO - 2023-03-22 09:24:07 --> Language Class Initialized
INFO - 2023-03-22 09:24:07 --> Loader Class Initialized
INFO - 2023-03-22 09:24:07 --> Controller Class Initialized
DEBUG - 2023-03-22 09:24:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:24:07 --> Database Driver Class Initialized
INFO - 2023-03-22 09:24:07 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:24:07 --> Final output sent to browser
DEBUG - 2023-03-22 09:24:07 --> Total execution time: 0.0132
INFO - 2023-03-22 09:24:37 --> Config Class Initialized
INFO - 2023-03-22 09:24:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:24:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:24:37 --> Utf8 Class Initialized
INFO - 2023-03-22 09:24:37 --> URI Class Initialized
INFO - 2023-03-22 09:24:37 --> Router Class Initialized
INFO - 2023-03-22 09:24:37 --> Output Class Initialized
INFO - 2023-03-22 09:24:37 --> Security Class Initialized
DEBUG - 2023-03-22 09:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:24:37 --> Input Class Initialized
INFO - 2023-03-22 09:24:37 --> Language Class Initialized
INFO - 2023-03-22 09:24:37 --> Loader Class Initialized
INFO - 2023-03-22 09:24:37 --> Controller Class Initialized
DEBUG - 2023-03-22 09:24:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:24:37 --> Database Driver Class Initialized
INFO - 2023-03-22 09:24:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:24:37 --> Final output sent to browser
DEBUG - 2023-03-22 09:24:37 --> Total execution time: 0.0149
INFO - 2023-03-22 09:24:37 --> Config Class Initialized
INFO - 2023-03-22 09:24:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:24:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:24:37 --> Utf8 Class Initialized
INFO - 2023-03-22 09:24:37 --> URI Class Initialized
INFO - 2023-03-22 09:24:37 --> Router Class Initialized
INFO - 2023-03-22 09:24:37 --> Output Class Initialized
INFO - 2023-03-22 09:24:37 --> Security Class Initialized
DEBUG - 2023-03-22 09:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:24:37 --> Input Class Initialized
INFO - 2023-03-22 09:24:37 --> Language Class Initialized
INFO - 2023-03-22 09:24:37 --> Loader Class Initialized
INFO - 2023-03-22 09:24:37 --> Controller Class Initialized
DEBUG - 2023-03-22 09:24:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:24:37 --> Database Driver Class Initialized
INFO - 2023-03-22 09:24:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:24:37 --> Final output sent to browser
DEBUG - 2023-03-22 09:24:37 --> Total execution time: 0.0111
INFO - 2023-03-22 09:24:43 --> Config Class Initialized
INFO - 2023-03-22 09:24:43 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:24:43 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:24:43 --> Utf8 Class Initialized
INFO - 2023-03-22 09:24:43 --> URI Class Initialized
INFO - 2023-03-22 09:24:43 --> Router Class Initialized
INFO - 2023-03-22 09:24:43 --> Output Class Initialized
INFO - 2023-03-22 09:24:43 --> Security Class Initialized
DEBUG - 2023-03-22 09:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:24:43 --> Input Class Initialized
INFO - 2023-03-22 09:24:43 --> Language Class Initialized
INFO - 2023-03-22 09:24:43 --> Loader Class Initialized
INFO - 2023-03-22 09:24:43 --> Controller Class Initialized
DEBUG - 2023-03-22 09:24:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:24:43 --> Final output sent to browser
DEBUG - 2023-03-22 09:24:43 --> Total execution time: 0.0040
INFO - 2023-03-22 09:24:43 --> Config Class Initialized
INFO - 2023-03-22 09:24:43 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:24:43 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:24:43 --> Utf8 Class Initialized
INFO - 2023-03-22 09:24:43 --> URI Class Initialized
INFO - 2023-03-22 09:24:43 --> Router Class Initialized
INFO - 2023-03-22 09:24:43 --> Output Class Initialized
INFO - 2023-03-22 09:24:43 --> Security Class Initialized
DEBUG - 2023-03-22 09:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:24:43 --> Input Class Initialized
INFO - 2023-03-22 09:24:43 --> Language Class Initialized
INFO - 2023-03-22 09:24:43 --> Loader Class Initialized
INFO - 2023-03-22 09:24:43 --> Controller Class Initialized
DEBUG - 2023-03-22 09:24:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:24:43 --> Database Driver Class Initialized
INFO - 2023-03-22 09:24:43 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:24:43 --> Final output sent to browser
DEBUG - 2023-03-22 09:24:43 --> Total execution time: 0.0191
INFO - 2023-03-22 09:24:43 --> Config Class Initialized
INFO - 2023-03-22 09:24:43 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:24:43 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:24:43 --> Utf8 Class Initialized
INFO - 2023-03-22 09:24:43 --> URI Class Initialized
INFO - 2023-03-22 09:24:43 --> Router Class Initialized
INFO - 2023-03-22 09:24:43 --> Output Class Initialized
INFO - 2023-03-22 09:24:43 --> Security Class Initialized
DEBUG - 2023-03-22 09:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:24:43 --> Input Class Initialized
INFO - 2023-03-22 09:24:43 --> Language Class Initialized
INFO - 2023-03-22 09:24:43 --> Loader Class Initialized
INFO - 2023-03-22 09:24:43 --> Controller Class Initialized
DEBUG - 2023-03-22 09:24:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:24:43 --> Final output sent to browser
DEBUG - 2023-03-22 09:24:43 --> Total execution time: 0.0451
INFO - 2023-03-22 09:24:43 --> Config Class Initialized
INFO - 2023-03-22 09:24:43 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:24:43 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:24:43 --> Utf8 Class Initialized
INFO - 2023-03-22 09:24:43 --> URI Class Initialized
INFO - 2023-03-22 09:24:43 --> Router Class Initialized
INFO - 2023-03-22 09:24:43 --> Output Class Initialized
INFO - 2023-03-22 09:24:43 --> Security Class Initialized
DEBUG - 2023-03-22 09:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:24:43 --> Input Class Initialized
INFO - 2023-03-22 09:24:43 --> Language Class Initialized
INFO - 2023-03-22 09:24:43 --> Loader Class Initialized
INFO - 2023-03-22 09:24:43 --> Controller Class Initialized
DEBUG - 2023-03-22 09:24:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:24:43 --> Database Driver Class Initialized
INFO - 2023-03-22 09:24:43 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:24:43 --> Final output sent to browser
DEBUG - 2023-03-22 09:24:43 --> Total execution time: 0.0126
INFO - 2023-03-22 09:25:23 --> Config Class Initialized
INFO - 2023-03-22 09:25:23 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:25:23 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:25:23 --> Utf8 Class Initialized
INFO - 2023-03-22 09:25:23 --> URI Class Initialized
INFO - 2023-03-22 09:25:23 --> Router Class Initialized
INFO - 2023-03-22 09:25:23 --> Output Class Initialized
INFO - 2023-03-22 09:25:23 --> Security Class Initialized
DEBUG - 2023-03-22 09:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:25:23 --> Input Class Initialized
INFO - 2023-03-22 09:25:23 --> Language Class Initialized
INFO - 2023-03-22 09:25:23 --> Loader Class Initialized
INFO - 2023-03-22 09:25:23 --> Controller Class Initialized
DEBUG - 2023-03-22 09:25:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:25:23 --> Database Driver Class Initialized
INFO - 2023-03-22 09:25:23 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:25:23 --> Final output sent to browser
DEBUG - 2023-03-22 09:25:23 --> Total execution time: 0.0558
INFO - 2023-03-22 09:25:23 --> Config Class Initialized
INFO - 2023-03-22 09:25:23 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:25:23 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:25:23 --> Utf8 Class Initialized
INFO - 2023-03-22 09:25:23 --> URI Class Initialized
INFO - 2023-03-22 09:25:23 --> Router Class Initialized
INFO - 2023-03-22 09:25:23 --> Output Class Initialized
INFO - 2023-03-22 09:25:23 --> Security Class Initialized
DEBUG - 2023-03-22 09:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:25:23 --> Input Class Initialized
INFO - 2023-03-22 09:25:23 --> Language Class Initialized
INFO - 2023-03-22 09:25:23 --> Loader Class Initialized
INFO - 2023-03-22 09:25:23 --> Controller Class Initialized
DEBUG - 2023-03-22 09:25:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:25:23 --> Database Driver Class Initialized
INFO - 2023-03-22 09:25:23 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:25:23 --> Final output sent to browser
DEBUG - 2023-03-22 09:25:23 --> Total execution time: 0.0138
INFO - 2023-03-22 09:25:29 --> Config Class Initialized
INFO - 2023-03-22 09:25:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:25:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:25:29 --> Utf8 Class Initialized
INFO - 2023-03-22 09:25:29 --> URI Class Initialized
INFO - 2023-03-22 09:25:29 --> Router Class Initialized
INFO - 2023-03-22 09:25:29 --> Output Class Initialized
INFO - 2023-03-22 09:25:29 --> Security Class Initialized
DEBUG - 2023-03-22 09:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:25:29 --> Input Class Initialized
INFO - 2023-03-22 09:25:29 --> Language Class Initialized
INFO - 2023-03-22 09:25:29 --> Loader Class Initialized
INFO - 2023-03-22 09:25:29 --> Controller Class Initialized
DEBUG - 2023-03-22 09:25:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:25:29 --> Database Driver Class Initialized
INFO - 2023-03-22 09:25:29 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:25:29 --> Final output sent to browser
DEBUG - 2023-03-22 09:25:29 --> Total execution time: 0.0563
INFO - 2023-03-22 09:25:29 --> Config Class Initialized
INFO - 2023-03-22 09:25:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:25:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:25:29 --> Utf8 Class Initialized
INFO - 2023-03-22 09:25:29 --> URI Class Initialized
INFO - 2023-03-22 09:25:29 --> Router Class Initialized
INFO - 2023-03-22 09:25:29 --> Output Class Initialized
INFO - 2023-03-22 09:25:29 --> Security Class Initialized
DEBUG - 2023-03-22 09:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:25:29 --> Input Class Initialized
INFO - 2023-03-22 09:25:29 --> Language Class Initialized
INFO - 2023-03-22 09:25:29 --> Loader Class Initialized
INFO - 2023-03-22 09:25:29 --> Controller Class Initialized
DEBUG - 2023-03-22 09:25:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:25:29 --> Database Driver Class Initialized
INFO - 2023-03-22 09:25:29 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:25:29 --> Final output sent to browser
DEBUG - 2023-03-22 09:25:29 --> Total execution time: 0.0144
INFO - 2023-03-22 09:26:53 --> Config Class Initialized
INFO - 2023-03-22 09:26:54 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:26:54 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:26:54 --> Utf8 Class Initialized
INFO - 2023-03-22 09:26:54 --> URI Class Initialized
INFO - 2023-03-22 09:26:54 --> Router Class Initialized
INFO - 2023-03-22 09:26:54 --> Output Class Initialized
INFO - 2023-03-22 09:26:54 --> Security Class Initialized
DEBUG - 2023-03-22 09:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:26:54 --> Input Class Initialized
INFO - 2023-03-22 09:26:54 --> Language Class Initialized
INFO - 2023-03-22 09:26:54 --> Loader Class Initialized
INFO - 2023-03-22 09:26:54 --> Controller Class Initialized
DEBUG - 2023-03-22 09:26:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:26:54 --> Database Driver Class Initialized
INFO - 2023-03-22 09:26:54 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:26:54 --> Final output sent to browser
DEBUG - 2023-03-22 09:26:54 --> Total execution time: 0.0535
INFO - 2023-03-22 09:26:54 --> Config Class Initialized
INFO - 2023-03-22 09:26:54 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:26:54 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:26:54 --> Utf8 Class Initialized
INFO - 2023-03-22 09:26:54 --> URI Class Initialized
INFO - 2023-03-22 09:26:54 --> Router Class Initialized
INFO - 2023-03-22 09:26:54 --> Output Class Initialized
INFO - 2023-03-22 09:26:54 --> Security Class Initialized
DEBUG - 2023-03-22 09:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:26:54 --> Input Class Initialized
INFO - 2023-03-22 09:26:54 --> Language Class Initialized
INFO - 2023-03-22 09:26:54 --> Loader Class Initialized
INFO - 2023-03-22 09:26:54 --> Controller Class Initialized
DEBUG - 2023-03-22 09:26:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:26:54 --> Database Driver Class Initialized
INFO - 2023-03-22 09:26:54 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:26:54 --> Final output sent to browser
DEBUG - 2023-03-22 09:26:54 --> Total execution time: 0.0129
INFO - 2023-03-22 09:26:58 --> Config Class Initialized
INFO - 2023-03-22 09:26:58 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:26:58 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:26:58 --> Utf8 Class Initialized
INFO - 2023-03-22 09:26:58 --> URI Class Initialized
INFO - 2023-03-22 09:26:58 --> Router Class Initialized
INFO - 2023-03-22 09:26:58 --> Output Class Initialized
INFO - 2023-03-22 09:26:58 --> Security Class Initialized
DEBUG - 2023-03-22 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:26:58 --> Input Class Initialized
INFO - 2023-03-22 09:26:58 --> Language Class Initialized
INFO - 2023-03-22 09:26:58 --> Loader Class Initialized
INFO - 2023-03-22 09:26:58 --> Controller Class Initialized
DEBUG - 2023-03-22 09:26:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:26:58 --> Final output sent to browser
DEBUG - 2023-03-22 09:26:58 --> Total execution time: 0.0038
INFO - 2023-03-22 09:26:58 --> Config Class Initialized
INFO - 2023-03-22 09:26:58 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:26:58 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:26:58 --> Utf8 Class Initialized
INFO - 2023-03-22 09:26:58 --> URI Class Initialized
INFO - 2023-03-22 09:26:58 --> Router Class Initialized
INFO - 2023-03-22 09:26:58 --> Output Class Initialized
INFO - 2023-03-22 09:26:58 --> Security Class Initialized
DEBUG - 2023-03-22 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:26:58 --> Input Class Initialized
INFO - 2023-03-22 09:26:58 --> Language Class Initialized
INFO - 2023-03-22 09:26:58 --> Loader Class Initialized
INFO - 2023-03-22 09:26:58 --> Controller Class Initialized
DEBUG - 2023-03-22 09:26:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:26:58 --> Database Driver Class Initialized
INFO - 2023-03-22 09:26:58 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:26:58 --> Final output sent to browser
DEBUG - 2023-03-22 09:26:58 --> Total execution time: 0.0157
INFO - 2023-03-22 09:26:58 --> Config Class Initialized
INFO - 2023-03-22 09:26:58 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:26:58 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:26:58 --> Utf8 Class Initialized
INFO - 2023-03-22 09:26:58 --> URI Class Initialized
INFO - 2023-03-22 09:26:58 --> Router Class Initialized
INFO - 2023-03-22 09:26:58 --> Output Class Initialized
INFO - 2023-03-22 09:26:58 --> Security Class Initialized
DEBUG - 2023-03-22 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:26:58 --> Input Class Initialized
INFO - 2023-03-22 09:26:58 --> Language Class Initialized
INFO - 2023-03-22 09:26:58 --> Loader Class Initialized
INFO - 2023-03-22 09:26:58 --> Controller Class Initialized
DEBUG - 2023-03-22 09:26:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:26:58 --> Final output sent to browser
DEBUG - 2023-03-22 09:26:58 --> Total execution time: 0.0426
INFO - 2023-03-22 09:26:58 --> Config Class Initialized
INFO - 2023-03-22 09:26:58 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:26:58 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:26:58 --> Utf8 Class Initialized
INFO - 2023-03-22 09:26:58 --> URI Class Initialized
INFO - 2023-03-22 09:26:58 --> Router Class Initialized
INFO - 2023-03-22 09:26:58 --> Output Class Initialized
INFO - 2023-03-22 09:26:58 --> Security Class Initialized
DEBUG - 2023-03-22 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:26:58 --> Input Class Initialized
INFO - 2023-03-22 09:26:58 --> Language Class Initialized
INFO - 2023-03-22 09:26:58 --> Loader Class Initialized
INFO - 2023-03-22 09:26:58 --> Controller Class Initialized
DEBUG - 2023-03-22 09:26:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:26:58 --> Database Driver Class Initialized
INFO - 2023-03-22 09:26:58 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:26:58 --> Final output sent to browser
DEBUG - 2023-03-22 09:26:58 --> Total execution time: 0.0127
INFO - 2023-03-22 09:35:15 --> Config Class Initialized
INFO - 2023-03-22 09:35:15 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:35:15 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:35:15 --> Utf8 Class Initialized
INFO - 2023-03-22 09:35:15 --> URI Class Initialized
INFO - 2023-03-22 09:35:15 --> Router Class Initialized
INFO - 2023-03-22 09:35:15 --> Output Class Initialized
INFO - 2023-03-22 09:35:15 --> Security Class Initialized
DEBUG - 2023-03-22 09:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:35:15 --> Input Class Initialized
INFO - 2023-03-22 09:35:15 --> Language Class Initialized
INFO - 2023-03-22 09:35:15 --> Loader Class Initialized
INFO - 2023-03-22 09:35:15 --> Controller Class Initialized
DEBUG - 2023-03-22 09:35:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:35:15 --> Database Driver Class Initialized
INFO - 2023-03-22 09:35:15 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:35:15 --> Final output sent to browser
DEBUG - 2023-03-22 09:35:15 --> Total execution time: 0.0581
INFO - 2023-03-22 09:35:15 --> Config Class Initialized
INFO - 2023-03-22 09:35:15 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:35:15 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:35:15 --> Utf8 Class Initialized
INFO - 2023-03-22 09:35:15 --> URI Class Initialized
INFO - 2023-03-22 09:35:15 --> Router Class Initialized
INFO - 2023-03-22 09:35:15 --> Output Class Initialized
INFO - 2023-03-22 09:35:15 --> Security Class Initialized
DEBUG - 2023-03-22 09:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:35:15 --> Input Class Initialized
INFO - 2023-03-22 09:35:15 --> Language Class Initialized
INFO - 2023-03-22 09:35:15 --> Loader Class Initialized
INFO - 2023-03-22 09:35:15 --> Controller Class Initialized
DEBUG - 2023-03-22 09:35:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:35:15 --> Database Driver Class Initialized
INFO - 2023-03-22 09:35:15 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:35:15 --> Final output sent to browser
DEBUG - 2023-03-22 09:35:15 --> Total execution time: 0.0548
INFO - 2023-03-22 09:35:19 --> Config Class Initialized
INFO - 2023-03-22 09:35:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:35:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:35:19 --> Utf8 Class Initialized
INFO - 2023-03-22 09:35:19 --> URI Class Initialized
INFO - 2023-03-22 09:35:19 --> Router Class Initialized
INFO - 2023-03-22 09:35:19 --> Output Class Initialized
INFO - 2023-03-22 09:35:19 --> Security Class Initialized
DEBUG - 2023-03-22 09:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:35:19 --> Input Class Initialized
INFO - 2023-03-22 09:35:19 --> Language Class Initialized
INFO - 2023-03-22 09:35:19 --> Loader Class Initialized
INFO - 2023-03-22 09:35:19 --> Controller Class Initialized
DEBUG - 2023-03-22 09:35:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:35:19 --> Final output sent to browser
DEBUG - 2023-03-22 09:35:19 --> Total execution time: 0.0041
INFO - 2023-03-22 09:35:19 --> Config Class Initialized
INFO - 2023-03-22 09:35:20 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:35:20 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:35:20 --> Utf8 Class Initialized
INFO - 2023-03-22 09:35:20 --> URI Class Initialized
INFO - 2023-03-22 09:35:20 --> Router Class Initialized
INFO - 2023-03-22 09:35:20 --> Output Class Initialized
INFO - 2023-03-22 09:35:20 --> Security Class Initialized
DEBUG - 2023-03-22 09:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:35:20 --> Input Class Initialized
INFO - 2023-03-22 09:35:20 --> Language Class Initialized
INFO - 2023-03-22 09:35:20 --> Loader Class Initialized
INFO - 2023-03-22 09:35:20 --> Controller Class Initialized
DEBUG - 2023-03-22 09:35:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:35:20 --> Database Driver Class Initialized
INFO - 2023-03-22 09:35:20 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:35:20 --> Final output sent to browser
DEBUG - 2023-03-22 09:35:20 --> Total execution time: 0.0598
INFO - 2023-03-22 09:35:20 --> Config Class Initialized
INFO - 2023-03-22 09:35:20 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:35:20 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:35:20 --> Utf8 Class Initialized
INFO - 2023-03-22 09:35:20 --> URI Class Initialized
INFO - 2023-03-22 09:35:20 --> Router Class Initialized
INFO - 2023-03-22 09:35:20 --> Output Class Initialized
INFO - 2023-03-22 09:35:20 --> Security Class Initialized
DEBUG - 2023-03-22 09:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:35:20 --> Input Class Initialized
INFO - 2023-03-22 09:35:20 --> Language Class Initialized
INFO - 2023-03-22 09:35:20 --> Loader Class Initialized
INFO - 2023-03-22 09:35:20 --> Controller Class Initialized
DEBUG - 2023-03-22 09:35:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:35:20 --> Final output sent to browser
DEBUG - 2023-03-22 09:35:20 --> Total execution time: 0.0457
INFO - 2023-03-22 09:35:20 --> Config Class Initialized
INFO - 2023-03-22 09:35:20 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:35:20 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:35:20 --> Utf8 Class Initialized
INFO - 2023-03-22 09:35:20 --> URI Class Initialized
INFO - 2023-03-22 09:35:20 --> Router Class Initialized
INFO - 2023-03-22 09:35:20 --> Output Class Initialized
INFO - 2023-03-22 09:35:20 --> Security Class Initialized
DEBUG - 2023-03-22 09:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:35:20 --> Input Class Initialized
INFO - 2023-03-22 09:35:20 --> Language Class Initialized
INFO - 2023-03-22 09:35:20 --> Loader Class Initialized
INFO - 2023-03-22 09:35:20 --> Controller Class Initialized
DEBUG - 2023-03-22 09:35:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:35:20 --> Database Driver Class Initialized
INFO - 2023-03-22 09:35:20 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:35:20 --> Final output sent to browser
DEBUG - 2023-03-22 09:35:20 --> Total execution time: 0.0537
INFO - 2023-03-22 09:35:59 --> Config Class Initialized
INFO - 2023-03-22 09:35:59 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:35:59 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:35:59 --> Utf8 Class Initialized
INFO - 2023-03-22 09:35:59 --> URI Class Initialized
INFO - 2023-03-22 09:35:59 --> Router Class Initialized
INFO - 2023-03-22 09:35:59 --> Output Class Initialized
INFO - 2023-03-22 09:35:59 --> Security Class Initialized
DEBUG - 2023-03-22 09:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:35:59 --> Input Class Initialized
INFO - 2023-03-22 09:35:59 --> Language Class Initialized
INFO - 2023-03-22 09:35:59 --> Loader Class Initialized
INFO - 2023-03-22 09:35:59 --> Controller Class Initialized
DEBUG - 2023-03-22 09:35:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:35:59 --> Database Driver Class Initialized
INFO - 2023-03-22 09:35:59 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:35:59 --> Final output sent to browser
DEBUG - 2023-03-22 09:35:59 --> Total execution time: 0.0528
INFO - 2023-03-22 09:35:59 --> Config Class Initialized
INFO - 2023-03-22 09:35:59 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:35:59 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:35:59 --> Utf8 Class Initialized
INFO - 2023-03-22 09:35:59 --> URI Class Initialized
INFO - 2023-03-22 09:35:59 --> Router Class Initialized
INFO - 2023-03-22 09:35:59 --> Output Class Initialized
INFO - 2023-03-22 09:35:59 --> Security Class Initialized
DEBUG - 2023-03-22 09:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:35:59 --> Input Class Initialized
INFO - 2023-03-22 09:35:59 --> Language Class Initialized
INFO - 2023-03-22 09:35:59 --> Loader Class Initialized
INFO - 2023-03-22 09:35:59 --> Controller Class Initialized
DEBUG - 2023-03-22 09:35:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:35:59 --> Database Driver Class Initialized
INFO - 2023-03-22 09:35:59 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:35:59 --> Final output sent to browser
DEBUG - 2023-03-22 09:35:59 --> Total execution time: 0.0119
INFO - 2023-03-22 09:39:41 --> Config Class Initialized
INFO - 2023-03-22 09:39:41 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:39:41 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:39:41 --> Utf8 Class Initialized
INFO - 2023-03-22 09:39:41 --> URI Class Initialized
INFO - 2023-03-22 09:39:41 --> Router Class Initialized
INFO - 2023-03-22 09:39:41 --> Output Class Initialized
INFO - 2023-03-22 09:39:41 --> Security Class Initialized
DEBUG - 2023-03-22 09:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:39:41 --> Input Class Initialized
INFO - 2023-03-22 09:39:41 --> Language Class Initialized
INFO - 2023-03-22 09:39:41 --> Loader Class Initialized
INFO - 2023-03-22 09:39:41 --> Controller Class Initialized
DEBUG - 2023-03-22 09:39:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:39:41 --> Database Driver Class Initialized
INFO - 2023-03-22 09:39:41 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:39:41 --> Final output sent to browser
DEBUG - 2023-03-22 09:39:41 --> Total execution time: 0.1477
INFO - 2023-03-22 09:39:41 --> Config Class Initialized
INFO - 2023-03-22 09:39:41 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:39:41 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:39:41 --> Utf8 Class Initialized
INFO - 2023-03-22 09:39:41 --> URI Class Initialized
INFO - 2023-03-22 09:39:41 --> Router Class Initialized
INFO - 2023-03-22 09:39:41 --> Output Class Initialized
INFO - 2023-03-22 09:39:41 --> Security Class Initialized
DEBUG - 2023-03-22 09:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:39:41 --> Input Class Initialized
INFO - 2023-03-22 09:39:41 --> Language Class Initialized
INFO - 2023-03-22 09:39:41 --> Loader Class Initialized
INFO - 2023-03-22 09:39:41 --> Controller Class Initialized
DEBUG - 2023-03-22 09:39:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:39:41 --> Database Driver Class Initialized
INFO - 2023-03-22 09:39:41 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:39:41 --> Final output sent to browser
DEBUG - 2023-03-22 09:39:41 --> Total execution time: 0.0572
INFO - 2023-03-22 09:40:50 --> Config Class Initialized
INFO - 2023-03-22 09:40:50 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:40:50 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:40:50 --> Utf8 Class Initialized
INFO - 2023-03-22 09:40:50 --> URI Class Initialized
INFO - 2023-03-22 09:40:50 --> Router Class Initialized
INFO - 2023-03-22 09:40:50 --> Output Class Initialized
INFO - 2023-03-22 09:40:50 --> Security Class Initialized
DEBUG - 2023-03-22 09:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:40:50 --> Input Class Initialized
INFO - 2023-03-22 09:40:50 --> Language Class Initialized
INFO - 2023-03-22 09:40:50 --> Loader Class Initialized
INFO - 2023-03-22 09:40:50 --> Controller Class Initialized
DEBUG - 2023-03-22 09:40:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:40:50 --> Database Driver Class Initialized
INFO - 2023-03-22 09:40:50 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:40:50 --> Final output sent to browser
DEBUG - 2023-03-22 09:40:50 --> Total execution time: 0.0629
INFO - 2023-03-22 09:40:50 --> Config Class Initialized
INFO - 2023-03-22 09:40:50 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:40:50 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:40:50 --> Utf8 Class Initialized
INFO - 2023-03-22 09:40:50 --> URI Class Initialized
INFO - 2023-03-22 09:40:50 --> Router Class Initialized
INFO - 2023-03-22 09:40:50 --> Output Class Initialized
INFO - 2023-03-22 09:40:50 --> Security Class Initialized
DEBUG - 2023-03-22 09:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:40:50 --> Input Class Initialized
INFO - 2023-03-22 09:40:50 --> Language Class Initialized
INFO - 2023-03-22 09:40:50 --> Loader Class Initialized
INFO - 2023-03-22 09:40:50 --> Controller Class Initialized
DEBUG - 2023-03-22 09:40:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:40:50 --> Database Driver Class Initialized
INFO - 2023-03-22 09:40:50 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:40:50 --> Final output sent to browser
DEBUG - 2023-03-22 09:40:50 --> Total execution time: 0.0614
INFO - 2023-03-22 09:40:56 --> Config Class Initialized
INFO - 2023-03-22 09:40:56 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:40:56 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:40:56 --> Utf8 Class Initialized
INFO - 2023-03-22 09:40:56 --> URI Class Initialized
INFO - 2023-03-22 09:40:56 --> Router Class Initialized
INFO - 2023-03-22 09:40:56 --> Output Class Initialized
INFO - 2023-03-22 09:40:56 --> Security Class Initialized
DEBUG - 2023-03-22 09:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:40:56 --> Input Class Initialized
INFO - 2023-03-22 09:40:56 --> Language Class Initialized
INFO - 2023-03-22 09:40:56 --> Loader Class Initialized
INFO - 2023-03-22 09:40:56 --> Controller Class Initialized
DEBUG - 2023-03-22 09:40:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:40:56 --> Database Driver Class Initialized
INFO - 2023-03-22 09:40:56 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:40:56 --> Final output sent to browser
DEBUG - 2023-03-22 09:40:56 --> Total execution time: 0.0972
INFO - 2023-03-22 09:40:56 --> Config Class Initialized
INFO - 2023-03-22 09:40:56 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:40:56 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:40:56 --> Utf8 Class Initialized
INFO - 2023-03-22 09:40:56 --> URI Class Initialized
INFO - 2023-03-22 09:40:56 --> Router Class Initialized
INFO - 2023-03-22 09:40:56 --> Output Class Initialized
INFO - 2023-03-22 09:40:56 --> Security Class Initialized
DEBUG - 2023-03-22 09:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:40:56 --> Input Class Initialized
INFO - 2023-03-22 09:40:56 --> Language Class Initialized
INFO - 2023-03-22 09:40:56 --> Loader Class Initialized
INFO - 2023-03-22 09:40:56 --> Controller Class Initialized
DEBUG - 2023-03-22 09:40:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:40:56 --> Database Driver Class Initialized
INFO - 2023-03-22 09:40:56 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:40:56 --> Final output sent to browser
DEBUG - 2023-03-22 09:40:56 --> Total execution time: 0.0645
INFO - 2023-03-22 09:42:21 --> Config Class Initialized
INFO - 2023-03-22 09:42:21 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:21 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:21 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:21 --> URI Class Initialized
INFO - 2023-03-22 09:42:21 --> Router Class Initialized
INFO - 2023-03-22 09:42:21 --> Output Class Initialized
INFO - 2023-03-22 09:42:21 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:21 --> Input Class Initialized
INFO - 2023-03-22 09:42:21 --> Language Class Initialized
INFO - 2023-03-22 09:42:21 --> Loader Class Initialized
INFO - 2023-03-22 09:42:21 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:21 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:21 --> Total execution time: 0.0038
INFO - 2023-03-22 09:42:21 --> Config Class Initialized
INFO - 2023-03-22 09:42:21 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:21 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:21 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:21 --> URI Class Initialized
INFO - 2023-03-22 09:42:21 --> Router Class Initialized
INFO - 2023-03-22 09:42:21 --> Output Class Initialized
INFO - 2023-03-22 09:42:21 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:21 --> Input Class Initialized
INFO - 2023-03-22 09:42:21 --> Language Class Initialized
INFO - 2023-03-22 09:42:21 --> Loader Class Initialized
INFO - 2023-03-22 09:42:21 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:21 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:21 --> Model "Login_model" initialized
INFO - 2023-03-22 09:42:21 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:21 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:21 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:21 --> Total execution time: 0.0243
INFO - 2023-03-22 09:42:22 --> Config Class Initialized
INFO - 2023-03-22 09:42:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:22 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:22 --> URI Class Initialized
INFO - 2023-03-22 09:42:22 --> Router Class Initialized
INFO - 2023-03-22 09:42:22 --> Output Class Initialized
INFO - 2023-03-22 09:42:22 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:22 --> Input Class Initialized
INFO - 2023-03-22 09:42:22 --> Language Class Initialized
INFO - 2023-03-22 09:42:22 --> Loader Class Initialized
INFO - 2023-03-22 09:42:22 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:22 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:22 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:22 --> Total execution time: 0.0181
INFO - 2023-03-22 09:42:22 --> Config Class Initialized
INFO - 2023-03-22 09:42:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:22 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:22 --> URI Class Initialized
INFO - 2023-03-22 09:42:22 --> Router Class Initialized
INFO - 2023-03-22 09:42:22 --> Output Class Initialized
INFO - 2023-03-22 09:42:22 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:22 --> Input Class Initialized
INFO - 2023-03-22 09:42:22 --> Language Class Initialized
INFO - 2023-03-22 09:42:22 --> Loader Class Initialized
INFO - 2023-03-22 09:42:22 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:22 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:22 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:22 --> Total execution time: 0.0566
INFO - 2023-03-22 09:42:23 --> Config Class Initialized
INFO - 2023-03-22 09:42:23 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:23 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:23 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:23 --> URI Class Initialized
INFO - 2023-03-22 09:42:23 --> Router Class Initialized
INFO - 2023-03-22 09:42:23 --> Output Class Initialized
INFO - 2023-03-22 09:42:23 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:23 --> Input Class Initialized
INFO - 2023-03-22 09:42:23 --> Language Class Initialized
INFO - 2023-03-22 09:42:23 --> Loader Class Initialized
INFO - 2023-03-22 09:42:23 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:23 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:23 --> Model "Login_model" initialized
INFO - 2023-03-22 09:42:23 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:23 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:23 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:23 --> Total execution time: 0.0229
INFO - 2023-03-22 09:42:24 --> Config Class Initialized
INFO - 2023-03-22 09:42:24 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:24 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:24 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:24 --> URI Class Initialized
INFO - 2023-03-22 09:42:24 --> Router Class Initialized
INFO - 2023-03-22 09:42:24 --> Output Class Initialized
INFO - 2023-03-22 09:42:24 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:24 --> Input Class Initialized
INFO - 2023-03-22 09:42:24 --> Language Class Initialized
INFO - 2023-03-22 09:42:24 --> Loader Class Initialized
INFO - 2023-03-22 09:42:24 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:24 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:24 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:24 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:24 --> Total execution time: 0.0149
INFO - 2023-03-22 09:42:24 --> Config Class Initialized
INFO - 2023-03-22 09:42:24 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:24 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:24 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:24 --> URI Class Initialized
INFO - 2023-03-22 09:42:24 --> Router Class Initialized
INFO - 2023-03-22 09:42:24 --> Output Class Initialized
INFO - 2023-03-22 09:42:24 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:24 --> Input Class Initialized
INFO - 2023-03-22 09:42:24 --> Language Class Initialized
INFO - 2023-03-22 09:42:24 --> Loader Class Initialized
INFO - 2023-03-22 09:42:24 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:24 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:24 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:24 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:24 --> Total execution time: 0.0113
INFO - 2023-03-22 09:42:28 --> Config Class Initialized
INFO - 2023-03-22 09:42:28 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:28 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:28 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:28 --> URI Class Initialized
INFO - 2023-03-22 09:42:28 --> Router Class Initialized
INFO - 2023-03-22 09:42:28 --> Output Class Initialized
INFO - 2023-03-22 09:42:28 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:28 --> Input Class Initialized
INFO - 2023-03-22 09:42:28 --> Language Class Initialized
INFO - 2023-03-22 09:42:28 --> Loader Class Initialized
INFO - 2023-03-22 09:42:28 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:28 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:28 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:28 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:28 --> Total execution time: 0.2052
INFO - 2023-03-22 09:42:30 --> Config Class Initialized
INFO - 2023-03-22 09:42:30 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:30 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:30 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:30 --> URI Class Initialized
INFO - 2023-03-22 09:42:30 --> Router Class Initialized
INFO - 2023-03-22 09:42:30 --> Output Class Initialized
INFO - 2023-03-22 09:42:30 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:30 --> Input Class Initialized
INFO - 2023-03-22 09:42:30 --> Language Class Initialized
INFO - 2023-03-22 09:42:30 --> Loader Class Initialized
INFO - 2023-03-22 09:42:30 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:30 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:30 --> Total execution time: 0.0446
INFO - 2023-03-22 09:42:30 --> Config Class Initialized
INFO - 2023-03-22 09:42:30 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:30 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:30 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:30 --> URI Class Initialized
INFO - 2023-03-22 09:42:30 --> Router Class Initialized
INFO - 2023-03-22 09:42:30 --> Output Class Initialized
INFO - 2023-03-22 09:42:30 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:30 --> Input Class Initialized
INFO - 2023-03-22 09:42:30 --> Language Class Initialized
INFO - 2023-03-22 09:42:30 --> Loader Class Initialized
INFO - 2023-03-22 09:42:30 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:30 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:30 --> Model "Login_model" initialized
INFO - 2023-03-22 09:42:30 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:30 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:30 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:30 --> Total execution time: 0.1014
INFO - 2023-03-22 09:42:31 --> Config Class Initialized
INFO - 2023-03-22 09:42:31 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:31 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:31 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:31 --> URI Class Initialized
INFO - 2023-03-22 09:42:31 --> Router Class Initialized
INFO - 2023-03-22 09:42:31 --> Output Class Initialized
INFO - 2023-03-22 09:42:31 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:31 --> Input Class Initialized
INFO - 2023-03-22 09:42:31 --> Language Class Initialized
INFO - 2023-03-22 09:42:31 --> Loader Class Initialized
INFO - 2023-03-22 09:42:31 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:31 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:31 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:31 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:31 --> Total execution time: 0.0174
INFO - 2023-03-22 09:42:31 --> Config Class Initialized
INFO - 2023-03-22 09:42:31 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:31 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:31 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:31 --> URI Class Initialized
INFO - 2023-03-22 09:42:31 --> Router Class Initialized
INFO - 2023-03-22 09:42:31 --> Output Class Initialized
INFO - 2023-03-22 09:42:31 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:31 --> Input Class Initialized
INFO - 2023-03-22 09:42:31 --> Language Class Initialized
INFO - 2023-03-22 09:42:31 --> Loader Class Initialized
INFO - 2023-03-22 09:42:31 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:31 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:31 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:31 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:31 --> Total execution time: 0.0128
INFO - 2023-03-22 09:42:36 --> Config Class Initialized
INFO - 2023-03-22 09:42:36 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:36 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:36 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:36 --> URI Class Initialized
INFO - 2023-03-22 09:42:36 --> Router Class Initialized
INFO - 2023-03-22 09:42:36 --> Output Class Initialized
INFO - 2023-03-22 09:42:36 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:36 --> Input Class Initialized
INFO - 2023-03-22 09:42:36 --> Language Class Initialized
INFO - 2023-03-22 09:42:36 --> Loader Class Initialized
INFO - 2023-03-22 09:42:36 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:36 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:36 --> Total execution time: 0.0040
INFO - 2023-03-22 09:42:36 --> Config Class Initialized
INFO - 2023-03-22 09:42:36 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:36 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:36 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:36 --> URI Class Initialized
INFO - 2023-03-22 09:42:36 --> Router Class Initialized
INFO - 2023-03-22 09:42:36 --> Output Class Initialized
INFO - 2023-03-22 09:42:36 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:36 --> Input Class Initialized
INFO - 2023-03-22 09:42:36 --> Language Class Initialized
INFO - 2023-03-22 09:42:36 --> Loader Class Initialized
INFO - 2023-03-22 09:42:36 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:36 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:36 --> Model "Login_model" initialized
INFO - 2023-03-22 09:42:36 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:36 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:36 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:36 --> Total execution time: 0.0209
INFO - 2023-03-22 09:42:37 --> Config Class Initialized
INFO - 2023-03-22 09:42:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:37 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:37 --> URI Class Initialized
INFO - 2023-03-22 09:42:37 --> Router Class Initialized
INFO - 2023-03-22 09:42:37 --> Output Class Initialized
INFO - 2023-03-22 09:42:37 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:37 --> Input Class Initialized
INFO - 2023-03-22 09:42:37 --> Language Class Initialized
INFO - 2023-03-22 09:42:37 --> Loader Class Initialized
INFO - 2023-03-22 09:42:37 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:37 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:37 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:37 --> Total execution time: 0.0185
INFO - 2023-03-22 09:42:37 --> Config Class Initialized
INFO - 2023-03-22 09:42:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:37 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:37 --> URI Class Initialized
INFO - 2023-03-22 09:42:37 --> Router Class Initialized
INFO - 2023-03-22 09:42:37 --> Output Class Initialized
INFO - 2023-03-22 09:42:37 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:37 --> Input Class Initialized
INFO - 2023-03-22 09:42:37 --> Language Class Initialized
INFO - 2023-03-22 09:42:37 --> Loader Class Initialized
INFO - 2023-03-22 09:42:37 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:37 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:37 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:37 --> Total execution time: 0.0139
INFO - 2023-03-22 09:42:41 --> Config Class Initialized
INFO - 2023-03-22 09:42:41 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:41 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:41 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:41 --> URI Class Initialized
INFO - 2023-03-22 09:42:41 --> Router Class Initialized
INFO - 2023-03-22 09:42:41 --> Output Class Initialized
INFO - 2023-03-22 09:42:41 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:41 --> Input Class Initialized
INFO - 2023-03-22 09:42:41 --> Language Class Initialized
INFO - 2023-03-22 09:42:41 --> Loader Class Initialized
INFO - 2023-03-22 09:42:41 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:41 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:41 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:41 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:41 --> Total execution time: 0.0958
INFO - 2023-03-22 09:42:44 --> Config Class Initialized
INFO - 2023-03-22 09:42:44 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:44 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:44 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:44 --> URI Class Initialized
INFO - 2023-03-22 09:42:44 --> Router Class Initialized
INFO - 2023-03-22 09:42:44 --> Output Class Initialized
INFO - 2023-03-22 09:42:44 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:44 --> Input Class Initialized
INFO - 2023-03-22 09:42:44 --> Language Class Initialized
INFO - 2023-03-22 09:42:44 --> Loader Class Initialized
INFO - 2023-03-22 09:42:44 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:44 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:44 --> Total execution time: 0.1268
INFO - 2023-03-22 09:42:44 --> Config Class Initialized
INFO - 2023-03-22 09:42:44 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:44 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:44 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:44 --> URI Class Initialized
INFO - 2023-03-22 09:42:44 --> Router Class Initialized
INFO - 2023-03-22 09:42:44 --> Output Class Initialized
INFO - 2023-03-22 09:42:44 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:44 --> Input Class Initialized
INFO - 2023-03-22 09:42:44 --> Language Class Initialized
INFO - 2023-03-22 09:42:44 --> Loader Class Initialized
INFO - 2023-03-22 09:42:44 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:44 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:44 --> Model "Login_model" initialized
INFO - 2023-03-22 09:42:44 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:44 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:44 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:44 --> Total execution time: 0.0309
INFO - 2023-03-22 09:42:44 --> Config Class Initialized
INFO - 2023-03-22 09:42:44 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:44 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:44 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:44 --> URI Class Initialized
INFO - 2023-03-22 09:42:44 --> Router Class Initialized
INFO - 2023-03-22 09:42:44 --> Output Class Initialized
INFO - 2023-03-22 09:42:44 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:44 --> Input Class Initialized
INFO - 2023-03-22 09:42:44 --> Language Class Initialized
INFO - 2023-03-22 09:42:44 --> Loader Class Initialized
INFO - 2023-03-22 09:42:44 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:44 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:44 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:44 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:44 --> Total execution time: 0.0195
INFO - 2023-03-22 09:42:44 --> Config Class Initialized
INFO - 2023-03-22 09:42:44 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:42:44 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:42:44 --> Utf8 Class Initialized
INFO - 2023-03-22 09:42:44 --> URI Class Initialized
INFO - 2023-03-22 09:42:44 --> Router Class Initialized
INFO - 2023-03-22 09:42:44 --> Output Class Initialized
INFO - 2023-03-22 09:42:44 --> Security Class Initialized
DEBUG - 2023-03-22 09:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:42:44 --> Input Class Initialized
INFO - 2023-03-22 09:42:44 --> Language Class Initialized
INFO - 2023-03-22 09:42:44 --> Loader Class Initialized
INFO - 2023-03-22 09:42:44 --> Controller Class Initialized
DEBUG - 2023-03-22 09:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:42:44 --> Database Driver Class Initialized
INFO - 2023-03-22 09:42:44 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:42:44 --> Final output sent to browser
DEBUG - 2023-03-22 09:42:44 --> Total execution time: 0.0140
INFO - 2023-03-22 09:44:42 --> Config Class Initialized
INFO - 2023-03-22 09:44:42 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:44:42 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:44:42 --> Utf8 Class Initialized
INFO - 2023-03-22 09:44:42 --> URI Class Initialized
INFO - 2023-03-22 09:44:42 --> Router Class Initialized
INFO - 2023-03-22 09:44:42 --> Output Class Initialized
INFO - 2023-03-22 09:44:42 --> Security Class Initialized
DEBUG - 2023-03-22 09:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:44:42 --> Input Class Initialized
INFO - 2023-03-22 09:44:42 --> Language Class Initialized
INFO - 2023-03-22 09:44:42 --> Loader Class Initialized
INFO - 2023-03-22 09:44:42 --> Controller Class Initialized
DEBUG - 2023-03-22 09:44:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:44:42 --> Database Driver Class Initialized
INFO - 2023-03-22 09:44:42 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:44:42 --> Final output sent to browser
DEBUG - 2023-03-22 09:44:42 --> Total execution time: 0.1382
INFO - 2023-03-22 09:44:42 --> Config Class Initialized
INFO - 2023-03-22 09:44:42 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:44:42 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:44:42 --> Utf8 Class Initialized
INFO - 2023-03-22 09:44:42 --> URI Class Initialized
INFO - 2023-03-22 09:44:42 --> Router Class Initialized
INFO - 2023-03-22 09:44:42 --> Output Class Initialized
INFO - 2023-03-22 09:44:42 --> Security Class Initialized
DEBUG - 2023-03-22 09:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:44:42 --> Input Class Initialized
INFO - 2023-03-22 09:44:42 --> Language Class Initialized
INFO - 2023-03-22 09:44:42 --> Loader Class Initialized
INFO - 2023-03-22 09:44:42 --> Controller Class Initialized
DEBUG - 2023-03-22 09:44:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:44:42 --> Database Driver Class Initialized
INFO - 2023-03-22 09:44:42 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:44:42 --> Final output sent to browser
DEBUG - 2023-03-22 09:44:42 --> Total execution time: 0.0527
INFO - 2023-03-22 09:44:46 --> Config Class Initialized
INFO - 2023-03-22 09:44:46 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:44:46 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:44:46 --> Utf8 Class Initialized
INFO - 2023-03-22 09:44:46 --> URI Class Initialized
INFO - 2023-03-22 09:44:46 --> Router Class Initialized
INFO - 2023-03-22 09:44:46 --> Output Class Initialized
INFO - 2023-03-22 09:44:46 --> Security Class Initialized
DEBUG - 2023-03-22 09:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:44:46 --> Input Class Initialized
INFO - 2023-03-22 09:44:46 --> Language Class Initialized
INFO - 2023-03-22 09:44:46 --> Loader Class Initialized
INFO - 2023-03-22 09:44:46 --> Controller Class Initialized
DEBUG - 2023-03-22 09:44:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:44:46 --> Final output sent to browser
DEBUG - 2023-03-22 09:44:46 --> Total execution time: 0.0046
INFO - 2023-03-22 09:44:46 --> Config Class Initialized
INFO - 2023-03-22 09:44:46 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:44:46 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:44:46 --> Utf8 Class Initialized
INFO - 2023-03-22 09:44:46 --> URI Class Initialized
INFO - 2023-03-22 09:44:46 --> Router Class Initialized
INFO - 2023-03-22 09:44:46 --> Output Class Initialized
INFO - 2023-03-22 09:44:46 --> Security Class Initialized
DEBUG - 2023-03-22 09:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:44:46 --> Input Class Initialized
INFO - 2023-03-22 09:44:46 --> Language Class Initialized
INFO - 2023-03-22 09:44:46 --> Loader Class Initialized
INFO - 2023-03-22 09:44:46 --> Controller Class Initialized
DEBUG - 2023-03-22 09:44:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:44:46 --> Database Driver Class Initialized
INFO - 2023-03-22 09:44:46 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:44:46 --> Final output sent to browser
DEBUG - 2023-03-22 09:44:46 --> Total execution time: 0.0586
INFO - 2023-03-22 09:44:46 --> Config Class Initialized
INFO - 2023-03-22 09:44:46 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:44:46 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:44:46 --> Utf8 Class Initialized
INFO - 2023-03-22 09:44:46 --> URI Class Initialized
INFO - 2023-03-22 09:44:46 --> Router Class Initialized
INFO - 2023-03-22 09:44:46 --> Output Class Initialized
INFO - 2023-03-22 09:44:46 --> Security Class Initialized
DEBUG - 2023-03-22 09:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:44:46 --> Input Class Initialized
INFO - 2023-03-22 09:44:46 --> Language Class Initialized
INFO - 2023-03-22 09:44:46 --> Loader Class Initialized
INFO - 2023-03-22 09:44:46 --> Controller Class Initialized
DEBUG - 2023-03-22 09:44:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:44:46 --> Final output sent to browser
DEBUG - 2023-03-22 09:44:46 --> Total execution time: 0.0417
INFO - 2023-03-22 09:44:46 --> Config Class Initialized
INFO - 2023-03-22 09:44:46 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:44:46 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:44:46 --> Utf8 Class Initialized
INFO - 2023-03-22 09:44:46 --> URI Class Initialized
INFO - 2023-03-22 09:44:46 --> Router Class Initialized
INFO - 2023-03-22 09:44:46 --> Output Class Initialized
INFO - 2023-03-22 09:44:46 --> Security Class Initialized
DEBUG - 2023-03-22 09:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:44:46 --> Input Class Initialized
INFO - 2023-03-22 09:44:46 --> Language Class Initialized
INFO - 2023-03-22 09:44:46 --> Loader Class Initialized
INFO - 2023-03-22 09:44:46 --> Controller Class Initialized
DEBUG - 2023-03-22 09:44:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:44:46 --> Database Driver Class Initialized
INFO - 2023-03-22 09:44:46 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:44:46 --> Final output sent to browser
DEBUG - 2023-03-22 09:44:46 --> Total execution time: 0.0510
INFO - 2023-03-22 09:45:17 --> Config Class Initialized
INFO - 2023-03-22 09:45:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:17 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:17 --> URI Class Initialized
INFO - 2023-03-22 09:45:17 --> Router Class Initialized
INFO - 2023-03-22 09:45:17 --> Output Class Initialized
INFO - 2023-03-22 09:45:17 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:17 --> Input Class Initialized
INFO - 2023-03-22 09:45:17 --> Language Class Initialized
INFO - 2023-03-22 09:45:17 --> Loader Class Initialized
INFO - 2023-03-22 09:45:17 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:17 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:17 --> Total execution time: 0.0050
INFO - 2023-03-22 09:45:17 --> Config Class Initialized
INFO - 2023-03-22 09:45:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:17 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:17 --> URI Class Initialized
INFO - 2023-03-22 09:45:17 --> Router Class Initialized
INFO - 2023-03-22 09:45:17 --> Output Class Initialized
INFO - 2023-03-22 09:45:17 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:17 --> Input Class Initialized
INFO - 2023-03-22 09:45:17 --> Language Class Initialized
INFO - 2023-03-22 09:45:17 --> Loader Class Initialized
INFO - 2023-03-22 09:45:17 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:17 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:17 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:17 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:17 --> Total execution time: 0.0122
INFO - 2023-03-22 09:45:17 --> Config Class Initialized
INFO - 2023-03-22 09:45:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:17 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:17 --> URI Class Initialized
INFO - 2023-03-22 09:45:17 --> Router Class Initialized
INFO - 2023-03-22 09:45:17 --> Output Class Initialized
INFO - 2023-03-22 09:45:17 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:17 --> Input Class Initialized
INFO - 2023-03-22 09:45:17 --> Language Class Initialized
INFO - 2023-03-22 09:45:17 --> Loader Class Initialized
INFO - 2023-03-22 09:45:17 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:17 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:17 --> Total execution time: 0.0420
INFO - 2023-03-22 09:45:17 --> Config Class Initialized
INFO - 2023-03-22 09:45:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:17 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:17 --> URI Class Initialized
INFO - 2023-03-22 09:45:17 --> Router Class Initialized
INFO - 2023-03-22 09:45:17 --> Output Class Initialized
INFO - 2023-03-22 09:45:17 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:17 --> Input Class Initialized
INFO - 2023-03-22 09:45:17 --> Language Class Initialized
INFO - 2023-03-22 09:45:17 --> Loader Class Initialized
INFO - 2023-03-22 09:45:17 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:17 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:17 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:17 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:17 --> Total execution time: 0.0103
INFO - 2023-03-22 09:45:31 --> Config Class Initialized
INFO - 2023-03-22 09:45:31 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:31 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:31 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:31 --> URI Class Initialized
INFO - 2023-03-22 09:45:31 --> Router Class Initialized
INFO - 2023-03-22 09:45:31 --> Output Class Initialized
INFO - 2023-03-22 09:45:31 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:31 --> Input Class Initialized
INFO - 2023-03-22 09:45:31 --> Language Class Initialized
INFO - 2023-03-22 09:45:31 --> Loader Class Initialized
INFO - 2023-03-22 09:45:31 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:31 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:31 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:31 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:31 --> Total execution time: 0.0243
INFO - 2023-03-22 09:45:31 --> Config Class Initialized
INFO - 2023-03-22 09:45:31 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:31 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:31 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:31 --> URI Class Initialized
INFO - 2023-03-22 09:45:31 --> Router Class Initialized
INFO - 2023-03-22 09:45:31 --> Output Class Initialized
INFO - 2023-03-22 09:45:31 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:31 --> Input Class Initialized
INFO - 2023-03-22 09:45:31 --> Language Class Initialized
INFO - 2023-03-22 09:45:31 --> Loader Class Initialized
INFO - 2023-03-22 09:45:31 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:31 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:31 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:31 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:31 --> Total execution time: 0.0517
INFO - 2023-03-22 09:45:34 --> Config Class Initialized
INFO - 2023-03-22 09:45:34 --> Config Class Initialized
INFO - 2023-03-22 09:45:34 --> Hooks Class Initialized
INFO - 2023-03-22 09:45:34 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:34 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 09:45:34 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:34 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:34 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:34 --> URI Class Initialized
INFO - 2023-03-22 09:45:34 --> URI Class Initialized
INFO - 2023-03-22 09:45:34 --> Router Class Initialized
INFO - 2023-03-22 09:45:34 --> Router Class Initialized
INFO - 2023-03-22 09:45:34 --> Output Class Initialized
INFO - 2023-03-22 09:45:34 --> Output Class Initialized
INFO - 2023-03-22 09:45:34 --> Security Class Initialized
INFO - 2023-03-22 09:45:34 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:34 --> Input Class Initialized
DEBUG - 2023-03-22 09:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:34 --> Language Class Initialized
INFO - 2023-03-22 09:45:34 --> Input Class Initialized
INFO - 2023-03-22 09:45:34 --> Language Class Initialized
INFO - 2023-03-22 09:45:34 --> Loader Class Initialized
INFO - 2023-03-22 09:45:34 --> Loader Class Initialized
INFO - 2023-03-22 09:45:34 --> Controller Class Initialized
INFO - 2023-03-22 09:45:34 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 09:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:34 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:34 --> Total execution time: 0.0061
INFO - 2023-03-22 09:45:34 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:34 --> Config Class Initialized
INFO - 2023-03-22 09:45:34 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:34 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:34 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:34 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:34 --> URI Class Initialized
INFO - 2023-03-22 09:45:34 --> Router Class Initialized
INFO - 2023-03-22 09:45:34 --> Output Class Initialized
INFO - 2023-03-22 09:45:34 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:34 --> Input Class Initialized
INFO - 2023-03-22 09:45:34 --> Language Class Initialized
INFO - 2023-03-22 09:45:34 --> Loader Class Initialized
INFO - 2023-03-22 09:45:34 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:34 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:34 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:34 --> Total execution time: 0.0527
INFO - 2023-03-22 09:45:34 --> Config Class Initialized
INFO - 2023-03-22 09:45:34 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:34 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:34 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:34 --> URI Class Initialized
INFO - 2023-03-22 09:45:34 --> Router Class Initialized
INFO - 2023-03-22 09:45:34 --> Output Class Initialized
INFO - 2023-03-22 09:45:34 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:34 --> Input Class Initialized
INFO - 2023-03-22 09:45:34 --> Language Class Initialized
INFO - 2023-03-22 09:45:34 --> Model "Login_model" initialized
INFO - 2023-03-22 09:45:34 --> Loader Class Initialized
INFO - 2023-03-22 09:45:34 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:34 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:34 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:34 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:34 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:34 --> Final output sent to browser
INFO - 2023-03-22 09:45:34 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:34 --> Total execution time: 0.0625
DEBUG - 2023-03-22 09:45:34 --> Total execution time: 0.0148
INFO - 2023-03-22 09:45:38 --> Config Class Initialized
INFO - 2023-03-22 09:45:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:38 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:38 --> URI Class Initialized
INFO - 2023-03-22 09:45:38 --> Router Class Initialized
INFO - 2023-03-22 09:45:38 --> Output Class Initialized
INFO - 2023-03-22 09:45:38 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:38 --> Input Class Initialized
INFO - 2023-03-22 09:45:38 --> Language Class Initialized
INFO - 2023-03-22 09:45:38 --> Loader Class Initialized
INFO - 2023-03-22 09:45:38 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:38 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:38 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:38 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:38 --> Total execution time: 0.0401
INFO - 2023-03-22 09:45:38 --> Config Class Initialized
INFO - 2023-03-22 09:45:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:38 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:38 --> URI Class Initialized
INFO - 2023-03-22 09:45:38 --> Router Class Initialized
INFO - 2023-03-22 09:45:38 --> Output Class Initialized
INFO - 2023-03-22 09:45:38 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:38 --> Input Class Initialized
INFO - 2023-03-22 09:45:38 --> Language Class Initialized
INFO - 2023-03-22 09:45:38 --> Loader Class Initialized
INFO - 2023-03-22 09:45:38 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:38 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:38 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:38 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:38 --> Total execution time: 0.0130
INFO - 2023-03-22 09:45:43 --> Config Class Initialized
INFO - 2023-03-22 09:45:43 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:43 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:43 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:43 --> URI Class Initialized
INFO - 2023-03-22 09:45:43 --> Router Class Initialized
INFO - 2023-03-22 09:45:43 --> Output Class Initialized
INFO - 2023-03-22 09:45:43 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:43 --> Input Class Initialized
INFO - 2023-03-22 09:45:43 --> Language Class Initialized
INFO - 2023-03-22 09:45:43 --> Loader Class Initialized
INFO - 2023-03-22 09:45:43 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:43 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:43 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:43 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:43 --> Total execution time: 0.0175
INFO - 2023-03-22 09:45:43 --> Config Class Initialized
INFO - 2023-03-22 09:45:43 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:43 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:43 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:43 --> URI Class Initialized
INFO - 2023-03-22 09:45:43 --> Router Class Initialized
INFO - 2023-03-22 09:45:43 --> Output Class Initialized
INFO - 2023-03-22 09:45:43 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:43 --> Input Class Initialized
INFO - 2023-03-22 09:45:43 --> Language Class Initialized
INFO - 2023-03-22 09:45:43 --> Loader Class Initialized
INFO - 2023-03-22 09:45:43 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:43 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:43 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:43 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:43 --> Total execution time: 0.0112
INFO - 2023-03-22 09:45:45 --> Config Class Initialized
INFO - 2023-03-22 09:45:45 --> Config Class Initialized
INFO - 2023-03-22 09:45:45 --> Hooks Class Initialized
INFO - 2023-03-22 09:45:45 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:45 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 09:45:45 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:45 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:45 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:45 --> URI Class Initialized
INFO - 2023-03-22 09:45:45 --> URI Class Initialized
INFO - 2023-03-22 09:45:45 --> Router Class Initialized
INFO - 2023-03-22 09:45:45 --> Router Class Initialized
INFO - 2023-03-22 09:45:45 --> Output Class Initialized
INFO - 2023-03-22 09:45:45 --> Output Class Initialized
INFO - 2023-03-22 09:45:45 --> Security Class Initialized
INFO - 2023-03-22 09:45:45 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 09:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:45 --> Input Class Initialized
INFO - 2023-03-22 09:45:45 --> Input Class Initialized
INFO - 2023-03-22 09:45:45 --> Language Class Initialized
INFO - 2023-03-22 09:45:45 --> Language Class Initialized
INFO - 2023-03-22 09:45:45 --> Loader Class Initialized
INFO - 2023-03-22 09:45:45 --> Loader Class Initialized
INFO - 2023-03-22 09:45:45 --> Controller Class Initialized
INFO - 2023-03-22 09:45:45 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 09:45:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:45 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:45 --> Total execution time: 0.0049
INFO - 2023-03-22 09:45:45 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:45 --> Config Class Initialized
INFO - 2023-03-22 09:45:45 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:45 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:45 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:45 --> URI Class Initialized
INFO - 2023-03-22 09:45:45 --> Router Class Initialized
INFO - 2023-03-22 09:45:45 --> Output Class Initialized
INFO - 2023-03-22 09:45:45 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:45 --> Input Class Initialized
INFO - 2023-03-22 09:45:45 --> Language Class Initialized
INFO - 2023-03-22 09:45:45 --> Loader Class Initialized
INFO - 2023-03-22 09:45:45 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:45 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:45 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:45 --> Model "Login_model" initialized
INFO - 2023-03-22 09:45:45 --> Final output sent to browser
INFO - 2023-03-22 09:45:45 --> Database Driver Class Initialized
DEBUG - 2023-03-22 09:45:45 --> Total execution time: 0.0330
INFO - 2023-03-22 09:45:45 --> Config Class Initialized
INFO - 2023-03-22 09:45:45 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:45 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:45 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:45 --> URI Class Initialized
INFO - 2023-03-22 09:45:45 --> Router Class Initialized
INFO - 2023-03-22 09:45:45 --> Output Class Initialized
INFO - 2023-03-22 09:45:45 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:45 --> Input Class Initialized
INFO - 2023-03-22 09:45:45 --> Language Class Initialized
INFO - 2023-03-22 09:45:45 --> Loader Class Initialized
INFO - 2023-03-22 09:45:45 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:45 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:45 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:45 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:45 --> Total execution time: 0.0358
INFO - 2023-03-22 09:45:45 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:45 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:45 --> Total execution time: 0.0577
INFO - 2023-03-22 09:45:48 --> Config Class Initialized
INFO - 2023-03-22 09:45:48 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:48 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:48 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:48 --> URI Class Initialized
INFO - 2023-03-22 09:45:48 --> Router Class Initialized
INFO - 2023-03-22 09:45:48 --> Output Class Initialized
INFO - 2023-03-22 09:45:48 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:48 --> Input Class Initialized
INFO - 2023-03-22 09:45:48 --> Language Class Initialized
INFO - 2023-03-22 09:45:48 --> Loader Class Initialized
INFO - 2023-03-22 09:45:48 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:48 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:48 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:48 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:48 --> Total execution time: 0.0167
INFO - 2023-03-22 09:45:48 --> Config Class Initialized
INFO - 2023-03-22 09:45:48 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:48 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:48 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:48 --> URI Class Initialized
INFO - 2023-03-22 09:45:48 --> Router Class Initialized
INFO - 2023-03-22 09:45:48 --> Output Class Initialized
INFO - 2023-03-22 09:45:48 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:48 --> Input Class Initialized
INFO - 2023-03-22 09:45:48 --> Language Class Initialized
INFO - 2023-03-22 09:45:48 --> Loader Class Initialized
INFO - 2023-03-22 09:45:48 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:48 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:48 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:48 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:48 --> Total execution time: 0.0591
INFO - 2023-03-22 09:45:56 --> Config Class Initialized
INFO - 2023-03-22 09:45:56 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:56 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:56 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:56 --> URI Class Initialized
INFO - 2023-03-22 09:45:56 --> Router Class Initialized
INFO - 2023-03-22 09:45:56 --> Output Class Initialized
INFO - 2023-03-22 09:45:56 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:56 --> Input Class Initialized
INFO - 2023-03-22 09:45:56 --> Language Class Initialized
INFO - 2023-03-22 09:45:56 --> Loader Class Initialized
INFO - 2023-03-22 09:45:56 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:56 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:56 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:56 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:56 --> Total execution time: 0.0176
INFO - 2023-03-22 09:45:56 --> Config Class Initialized
INFO - 2023-03-22 09:45:56 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:56 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:56 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:56 --> URI Class Initialized
INFO - 2023-03-22 09:45:56 --> Router Class Initialized
INFO - 2023-03-22 09:45:56 --> Output Class Initialized
INFO - 2023-03-22 09:45:56 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:56 --> Input Class Initialized
INFO - 2023-03-22 09:45:56 --> Language Class Initialized
INFO - 2023-03-22 09:45:56 --> Loader Class Initialized
INFO - 2023-03-22 09:45:56 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:56 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:56 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:56 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:56 --> Total execution time: 0.0133
INFO - 2023-03-22 09:45:58 --> Config Class Initialized
INFO - 2023-03-22 09:45:58 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:58 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:58 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:58 --> URI Class Initialized
INFO - 2023-03-22 09:45:58 --> Config Class Initialized
INFO - 2023-03-22 09:45:58 --> Router Class Initialized
INFO - 2023-03-22 09:45:58 --> Output Class Initialized
INFO - 2023-03-22 09:45:58 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:58 --> Input Class Initialized
INFO - 2023-03-22 09:45:58 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:58 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:58 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:58 --> URI Class Initialized
INFO - 2023-03-22 09:45:58 --> Router Class Initialized
INFO - 2023-03-22 09:45:58 --> Language Class Initialized
INFO - 2023-03-22 09:45:58 --> Output Class Initialized
INFO - 2023-03-22 09:45:58 --> Loader Class Initialized
INFO - 2023-03-22 09:45:58 --> Security Class Initialized
INFO - 2023-03-22 09:45:58 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 09:45:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:58 --> Input Class Initialized
INFO - 2023-03-22 09:45:58 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:58 --> Language Class Initialized
INFO - 2023-03-22 09:45:58 --> Loader Class Initialized
INFO - 2023-03-22 09:45:58 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:58 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:58 --> Total execution time: 0.0237
INFO - 2023-03-22 09:45:58 --> Config Class Initialized
INFO - 2023-03-22 09:45:58 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:45:58 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:58 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:58 --> URI Class Initialized
INFO - 2023-03-22 09:45:58 --> Router Class Initialized
INFO - 2023-03-22 09:45:58 --> Output Class Initialized
INFO - 2023-03-22 09:45:58 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:58 --> Input Class Initialized
INFO - 2023-03-22 09:45:58 --> Language Class Initialized
INFO - 2023-03-22 09:45:58 --> Loader Class Initialized
INFO - 2023-03-22 09:45:58 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:58 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:58 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:58 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:58 --> Total execution time: 0.0360
INFO - 2023-03-22 09:45:58 --> Config Class Initialized
INFO - 2023-03-22 09:45:58 --> Hooks Class Initialized
INFO - 2023-03-22 09:45:58 --> Model "Login_model" initialized
INFO - 2023-03-22 09:45:58 --> Database Driver Class Initialized
DEBUG - 2023-03-22 09:45:58 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:45:58 --> Utf8 Class Initialized
INFO - 2023-03-22 09:45:58 --> URI Class Initialized
INFO - 2023-03-22 09:45:58 --> Router Class Initialized
INFO - 2023-03-22 09:45:58 --> Output Class Initialized
INFO - 2023-03-22 09:45:58 --> Security Class Initialized
DEBUG - 2023-03-22 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:45:58 --> Input Class Initialized
INFO - 2023-03-22 09:45:58 --> Language Class Initialized
INFO - 2023-03-22 09:45:58 --> Loader Class Initialized
INFO - 2023-03-22 09:45:58 --> Controller Class Initialized
DEBUG - 2023-03-22 09:45:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:45:58 --> Database Driver Class Initialized
INFO - 2023-03-22 09:45:58 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:45:58 --> Final output sent to browser
INFO - 2023-03-22 09:45:58 --> Model "Cluster_model" initialized
DEBUG - 2023-03-22 09:45:58 --> Total execution time: 0.1118
INFO - 2023-03-22 09:45:58 --> Final output sent to browser
DEBUG - 2023-03-22 09:45:58 --> Total execution time: 0.0945
INFO - 2023-03-22 09:46:01 --> Config Class Initialized
INFO - 2023-03-22 09:46:01 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:46:01 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:46:01 --> Utf8 Class Initialized
INFO - 2023-03-22 09:46:01 --> URI Class Initialized
INFO - 2023-03-22 09:46:01 --> Router Class Initialized
INFO - 2023-03-22 09:46:01 --> Output Class Initialized
INFO - 2023-03-22 09:46:01 --> Security Class Initialized
DEBUG - 2023-03-22 09:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:46:01 --> Input Class Initialized
INFO - 2023-03-22 09:46:01 --> Language Class Initialized
INFO - 2023-03-22 09:46:01 --> Loader Class Initialized
INFO - 2023-03-22 09:46:01 --> Controller Class Initialized
DEBUG - 2023-03-22 09:46:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:46:01 --> Database Driver Class Initialized
INFO - 2023-03-22 09:46:01 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:46:01 --> Final output sent to browser
DEBUG - 2023-03-22 09:46:01 --> Total execution time: 0.0601
INFO - 2023-03-22 09:46:01 --> Config Class Initialized
INFO - 2023-03-22 09:46:01 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:46:01 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:46:01 --> Utf8 Class Initialized
INFO - 2023-03-22 09:46:01 --> URI Class Initialized
INFO - 2023-03-22 09:46:01 --> Router Class Initialized
INFO - 2023-03-22 09:46:01 --> Output Class Initialized
INFO - 2023-03-22 09:46:01 --> Security Class Initialized
DEBUG - 2023-03-22 09:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:46:01 --> Input Class Initialized
INFO - 2023-03-22 09:46:01 --> Language Class Initialized
INFO - 2023-03-22 09:46:01 --> Loader Class Initialized
INFO - 2023-03-22 09:46:01 --> Controller Class Initialized
DEBUG - 2023-03-22 09:46:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:46:01 --> Database Driver Class Initialized
INFO - 2023-03-22 09:46:01 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:46:01 --> Final output sent to browser
DEBUG - 2023-03-22 09:46:01 --> Total execution time: 0.0616
INFO - 2023-03-22 09:46:04 --> Config Class Initialized
INFO - 2023-03-22 09:46:04 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:46:04 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:46:04 --> Utf8 Class Initialized
INFO - 2023-03-22 09:46:04 --> URI Class Initialized
INFO - 2023-03-22 09:46:04 --> Router Class Initialized
INFO - 2023-03-22 09:46:04 --> Output Class Initialized
INFO - 2023-03-22 09:46:04 --> Security Class Initialized
DEBUG - 2023-03-22 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:46:04 --> Input Class Initialized
INFO - 2023-03-22 09:46:04 --> Language Class Initialized
INFO - 2023-03-22 09:46:04 --> Loader Class Initialized
INFO - 2023-03-22 09:46:04 --> Controller Class Initialized
DEBUG - 2023-03-22 09:46:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:46:04 --> Final output sent to browser
DEBUG - 2023-03-22 09:46:04 --> Total execution time: 0.0041
INFO - 2023-03-22 09:46:04 --> Config Class Initialized
INFO - 2023-03-22 09:46:04 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:46:04 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:46:04 --> Utf8 Class Initialized
INFO - 2023-03-22 09:46:04 --> URI Class Initialized
INFO - 2023-03-22 09:46:04 --> Router Class Initialized
INFO - 2023-03-22 09:46:04 --> Output Class Initialized
INFO - 2023-03-22 09:46:04 --> Security Class Initialized
DEBUG - 2023-03-22 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:46:04 --> Input Class Initialized
INFO - 2023-03-22 09:46:04 --> Language Class Initialized
INFO - 2023-03-22 09:46:04 --> Loader Class Initialized
INFO - 2023-03-22 09:46:04 --> Controller Class Initialized
DEBUG - 2023-03-22 09:46:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:46:04 --> Database Driver Class Initialized
INFO - 2023-03-22 09:46:04 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:46:04 --> Final output sent to browser
DEBUG - 2023-03-22 09:46:04 --> Total execution time: 0.0122
INFO - 2023-03-22 09:46:04 --> Config Class Initialized
INFO - 2023-03-22 09:46:04 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:46:04 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:46:04 --> Utf8 Class Initialized
INFO - 2023-03-22 09:46:04 --> URI Class Initialized
INFO - 2023-03-22 09:46:04 --> Router Class Initialized
INFO - 2023-03-22 09:46:04 --> Output Class Initialized
INFO - 2023-03-22 09:46:04 --> Security Class Initialized
DEBUG - 2023-03-22 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:46:04 --> Input Class Initialized
INFO - 2023-03-22 09:46:04 --> Language Class Initialized
INFO - 2023-03-22 09:46:04 --> Loader Class Initialized
INFO - 2023-03-22 09:46:04 --> Controller Class Initialized
DEBUG - 2023-03-22 09:46:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:46:04 --> Final output sent to browser
DEBUG - 2023-03-22 09:46:04 --> Total execution time: 0.0423
INFO - 2023-03-22 09:46:04 --> Config Class Initialized
INFO - 2023-03-22 09:46:04 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:46:04 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:46:04 --> Utf8 Class Initialized
INFO - 2023-03-22 09:46:04 --> URI Class Initialized
INFO - 2023-03-22 09:46:04 --> Router Class Initialized
INFO - 2023-03-22 09:46:04 --> Output Class Initialized
INFO - 2023-03-22 09:46:04 --> Security Class Initialized
DEBUG - 2023-03-22 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:46:04 --> Input Class Initialized
INFO - 2023-03-22 09:46:04 --> Language Class Initialized
INFO - 2023-03-22 09:46:04 --> Loader Class Initialized
INFO - 2023-03-22 09:46:04 --> Controller Class Initialized
DEBUG - 2023-03-22 09:46:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:46:04 --> Database Driver Class Initialized
INFO - 2023-03-22 09:46:04 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:46:04 --> Final output sent to browser
DEBUG - 2023-03-22 09:46:04 --> Total execution time: 0.0108
INFO - 2023-03-22 09:55:22 --> Config Class Initialized
INFO - 2023-03-22 09:55:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:55:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:55:22 --> Utf8 Class Initialized
INFO - 2023-03-22 09:55:22 --> URI Class Initialized
INFO - 2023-03-22 09:55:22 --> Router Class Initialized
INFO - 2023-03-22 09:55:22 --> Output Class Initialized
INFO - 2023-03-22 09:55:22 --> Security Class Initialized
DEBUG - 2023-03-22 09:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:55:22 --> Input Class Initialized
INFO - 2023-03-22 09:55:22 --> Language Class Initialized
INFO - 2023-03-22 09:55:22 --> Loader Class Initialized
INFO - 2023-03-22 09:55:22 --> Controller Class Initialized
DEBUG - 2023-03-22 09:55:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:55:22 --> Database Driver Class Initialized
INFO - 2023-03-22 09:55:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:55:22 --> Final output sent to browser
DEBUG - 2023-03-22 09:55:22 --> Total execution time: 0.0325
INFO - 2023-03-22 09:55:22 --> Config Class Initialized
INFO - 2023-03-22 09:55:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:55:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:55:22 --> Utf8 Class Initialized
INFO - 2023-03-22 09:55:22 --> URI Class Initialized
INFO - 2023-03-22 09:55:22 --> Router Class Initialized
INFO - 2023-03-22 09:55:22 --> Output Class Initialized
INFO - 2023-03-22 09:55:22 --> Security Class Initialized
DEBUG - 2023-03-22 09:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:55:22 --> Input Class Initialized
INFO - 2023-03-22 09:55:22 --> Language Class Initialized
INFO - 2023-03-22 09:55:22 --> Loader Class Initialized
INFO - 2023-03-22 09:55:22 --> Controller Class Initialized
DEBUG - 2023-03-22 09:55:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:55:22 --> Database Driver Class Initialized
INFO - 2023-03-22 09:55:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:55:22 --> Final output sent to browser
DEBUG - 2023-03-22 09:55:22 --> Total execution time: 0.3110
INFO - 2023-03-22 09:59:00 --> Config Class Initialized
INFO - 2023-03-22 09:59:00 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:59:00 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:59:00 --> Utf8 Class Initialized
INFO - 2023-03-22 09:59:00 --> URI Class Initialized
INFO - 2023-03-22 09:59:00 --> Router Class Initialized
INFO - 2023-03-22 09:59:00 --> Output Class Initialized
INFO - 2023-03-22 09:59:00 --> Security Class Initialized
DEBUG - 2023-03-22 09:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:59:00 --> Input Class Initialized
INFO - 2023-03-22 09:59:00 --> Language Class Initialized
INFO - 2023-03-22 09:59:00 --> Loader Class Initialized
INFO - 2023-03-22 09:59:00 --> Controller Class Initialized
DEBUG - 2023-03-22 09:59:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:59:00 --> Database Driver Class Initialized
INFO - 2023-03-22 09:59:00 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:59:00 --> Final output sent to browser
DEBUG - 2023-03-22 09:59:00 --> Total execution time: 0.0867
INFO - 2023-03-22 09:59:00 --> Config Class Initialized
INFO - 2023-03-22 09:59:00 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:59:00 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:59:00 --> Utf8 Class Initialized
INFO - 2023-03-22 09:59:00 --> URI Class Initialized
INFO - 2023-03-22 09:59:00 --> Router Class Initialized
INFO - 2023-03-22 09:59:00 --> Output Class Initialized
INFO - 2023-03-22 09:59:00 --> Security Class Initialized
DEBUG - 2023-03-22 09:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:59:00 --> Input Class Initialized
INFO - 2023-03-22 09:59:00 --> Language Class Initialized
INFO - 2023-03-22 09:59:00 --> Loader Class Initialized
INFO - 2023-03-22 09:59:00 --> Controller Class Initialized
DEBUG - 2023-03-22 09:59:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:59:00 --> Database Driver Class Initialized
INFO - 2023-03-22 09:59:00 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:59:00 --> Final output sent to browser
DEBUG - 2023-03-22 09:59:00 --> Total execution time: 0.0472
INFO - 2023-03-22 09:59:40 --> Config Class Initialized
INFO - 2023-03-22 09:59:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:59:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:59:40 --> Utf8 Class Initialized
INFO - 2023-03-22 09:59:40 --> URI Class Initialized
INFO - 2023-03-22 09:59:40 --> Router Class Initialized
INFO - 2023-03-22 09:59:40 --> Output Class Initialized
INFO - 2023-03-22 09:59:40 --> Security Class Initialized
DEBUG - 2023-03-22 09:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:59:40 --> Input Class Initialized
INFO - 2023-03-22 09:59:40 --> Language Class Initialized
INFO - 2023-03-22 09:59:40 --> Loader Class Initialized
INFO - 2023-03-22 09:59:40 --> Controller Class Initialized
DEBUG - 2023-03-22 09:59:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:59:40 --> Final output sent to browser
DEBUG - 2023-03-22 09:59:40 --> Total execution time: 0.0037
INFO - 2023-03-22 09:59:40 --> Config Class Initialized
INFO - 2023-03-22 09:59:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:59:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:59:40 --> Utf8 Class Initialized
INFO - 2023-03-22 09:59:40 --> URI Class Initialized
INFO - 2023-03-22 09:59:40 --> Router Class Initialized
INFO - 2023-03-22 09:59:40 --> Output Class Initialized
INFO - 2023-03-22 09:59:40 --> Security Class Initialized
DEBUG - 2023-03-22 09:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:59:40 --> Input Class Initialized
INFO - 2023-03-22 09:59:40 --> Language Class Initialized
INFO - 2023-03-22 09:59:40 --> Loader Class Initialized
INFO - 2023-03-22 09:59:40 --> Controller Class Initialized
DEBUG - 2023-03-22 09:59:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:59:40 --> Database Driver Class Initialized
INFO - 2023-03-22 09:59:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:59:40 --> Final output sent to browser
DEBUG - 2023-03-22 09:59:40 --> Total execution time: 0.0524
INFO - 2023-03-22 09:59:40 --> Config Class Initialized
INFO - 2023-03-22 09:59:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:59:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:59:40 --> Utf8 Class Initialized
INFO - 2023-03-22 09:59:40 --> URI Class Initialized
INFO - 2023-03-22 09:59:40 --> Router Class Initialized
INFO - 2023-03-22 09:59:40 --> Output Class Initialized
INFO - 2023-03-22 09:59:40 --> Security Class Initialized
DEBUG - 2023-03-22 09:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:59:40 --> Input Class Initialized
INFO - 2023-03-22 09:59:40 --> Language Class Initialized
INFO - 2023-03-22 09:59:40 --> Loader Class Initialized
INFO - 2023-03-22 09:59:40 --> Controller Class Initialized
DEBUG - 2023-03-22 09:59:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:59:40 --> Final output sent to browser
DEBUG - 2023-03-22 09:59:40 --> Total execution time: 0.0423
INFO - 2023-03-22 09:59:40 --> Config Class Initialized
INFO - 2023-03-22 09:59:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:59:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:59:40 --> Utf8 Class Initialized
INFO - 2023-03-22 09:59:40 --> URI Class Initialized
INFO - 2023-03-22 09:59:40 --> Router Class Initialized
INFO - 2023-03-22 09:59:40 --> Output Class Initialized
INFO - 2023-03-22 09:59:40 --> Security Class Initialized
DEBUG - 2023-03-22 09:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:59:40 --> Input Class Initialized
INFO - 2023-03-22 09:59:40 --> Language Class Initialized
INFO - 2023-03-22 09:59:40 --> Loader Class Initialized
INFO - 2023-03-22 09:59:40 --> Controller Class Initialized
DEBUG - 2023-03-22 09:59:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:59:40 --> Database Driver Class Initialized
INFO - 2023-03-22 09:59:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:59:40 --> Final output sent to browser
DEBUG - 2023-03-22 09:59:40 --> Total execution time: 0.0501
INFO - 2023-03-22 09:59:54 --> Config Class Initialized
INFO - 2023-03-22 09:59:54 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:59:54 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:59:54 --> Utf8 Class Initialized
INFO - 2023-03-22 09:59:54 --> URI Class Initialized
INFO - 2023-03-22 09:59:54 --> Router Class Initialized
INFO - 2023-03-22 09:59:54 --> Output Class Initialized
INFO - 2023-03-22 09:59:54 --> Security Class Initialized
DEBUG - 2023-03-22 09:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:59:54 --> Input Class Initialized
INFO - 2023-03-22 09:59:54 --> Language Class Initialized
INFO - 2023-03-22 09:59:54 --> Loader Class Initialized
INFO - 2023-03-22 09:59:54 --> Controller Class Initialized
DEBUG - 2023-03-22 09:59:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:59:54 --> Final output sent to browser
DEBUG - 2023-03-22 09:59:54 --> Total execution time: 0.0036
INFO - 2023-03-22 09:59:54 --> Config Class Initialized
INFO - 2023-03-22 09:59:54 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:59:54 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:59:54 --> Utf8 Class Initialized
INFO - 2023-03-22 09:59:54 --> URI Class Initialized
INFO - 2023-03-22 09:59:54 --> Router Class Initialized
INFO - 2023-03-22 09:59:54 --> Output Class Initialized
INFO - 2023-03-22 09:59:54 --> Security Class Initialized
DEBUG - 2023-03-22 09:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:59:54 --> Input Class Initialized
INFO - 2023-03-22 09:59:54 --> Language Class Initialized
INFO - 2023-03-22 09:59:54 --> Loader Class Initialized
INFO - 2023-03-22 09:59:54 --> Controller Class Initialized
DEBUG - 2023-03-22 09:59:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:59:54 --> Database Driver Class Initialized
INFO - 2023-03-22 09:59:54 --> Model "Login_model" initialized
INFO - 2023-03-22 09:59:54 --> Database Driver Class Initialized
INFO - 2023-03-22 09:59:54 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:59:54 --> Final output sent to browser
DEBUG - 2023-03-22 09:59:54 --> Total execution time: 0.0319
INFO - 2023-03-22 09:59:54 --> Config Class Initialized
INFO - 2023-03-22 09:59:54 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:59:54 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:59:54 --> Utf8 Class Initialized
INFO - 2023-03-22 09:59:54 --> URI Class Initialized
INFO - 2023-03-22 09:59:54 --> Router Class Initialized
INFO - 2023-03-22 09:59:54 --> Output Class Initialized
INFO - 2023-03-22 09:59:54 --> Security Class Initialized
DEBUG - 2023-03-22 09:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:59:54 --> Input Class Initialized
INFO - 2023-03-22 09:59:54 --> Language Class Initialized
INFO - 2023-03-22 09:59:54 --> Loader Class Initialized
INFO - 2023-03-22 09:59:54 --> Controller Class Initialized
DEBUG - 2023-03-22 09:59:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:59:54 --> Final output sent to browser
DEBUG - 2023-03-22 09:59:54 --> Total execution time: 0.0064
INFO - 2023-03-22 09:59:54 --> Config Class Initialized
INFO - 2023-03-22 09:59:54 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:59:54 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:59:54 --> Utf8 Class Initialized
INFO - 2023-03-22 09:59:54 --> URI Class Initialized
INFO - 2023-03-22 09:59:54 --> Router Class Initialized
INFO - 2023-03-22 09:59:54 --> Output Class Initialized
INFO - 2023-03-22 09:59:54 --> Security Class Initialized
DEBUG - 2023-03-22 09:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:59:54 --> Input Class Initialized
INFO - 2023-03-22 09:59:54 --> Language Class Initialized
INFO - 2023-03-22 09:59:54 --> Loader Class Initialized
INFO - 2023-03-22 09:59:54 --> Controller Class Initialized
DEBUG - 2023-03-22 09:59:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:59:54 --> Database Driver Class Initialized
INFO - 2023-03-22 09:59:54 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:59:54 --> Final output sent to browser
DEBUG - 2023-03-22 09:59:54 --> Total execution time: 0.0136
INFO - 2023-03-22 09:59:59 --> Config Class Initialized
INFO - 2023-03-22 09:59:59 --> Hooks Class Initialized
DEBUG - 2023-03-22 09:59:59 --> UTF-8 Support Enabled
INFO - 2023-03-22 09:59:59 --> Utf8 Class Initialized
INFO - 2023-03-22 09:59:59 --> URI Class Initialized
INFO - 2023-03-22 09:59:59 --> Router Class Initialized
INFO - 2023-03-22 09:59:59 --> Output Class Initialized
INFO - 2023-03-22 09:59:59 --> Security Class Initialized
DEBUG - 2023-03-22 09:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 09:59:59 --> Input Class Initialized
INFO - 2023-03-22 09:59:59 --> Language Class Initialized
INFO - 2023-03-22 09:59:59 --> Loader Class Initialized
INFO - 2023-03-22 09:59:59 --> Controller Class Initialized
DEBUG - 2023-03-22 09:59:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 09:59:59 --> Database Driver Class Initialized
INFO - 2023-03-22 09:59:59 --> Model "Cluster_model" initialized
INFO - 2023-03-22 09:59:59 --> Final output sent to browser
DEBUG - 2023-03-22 09:59:59 --> Total execution time: 0.0480
INFO - 2023-03-22 10:07:12 --> Config Class Initialized
INFO - 2023-03-22 10:07:12 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:12 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:12 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:12 --> URI Class Initialized
INFO - 2023-03-22 10:07:12 --> Router Class Initialized
INFO - 2023-03-22 10:07:12 --> Output Class Initialized
INFO - 2023-03-22 10:07:12 --> Security Class Initialized
DEBUG - 2023-03-22 10:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:12 --> Input Class Initialized
INFO - 2023-03-22 10:07:12 --> Language Class Initialized
INFO - 2023-03-22 10:07:12 --> Loader Class Initialized
INFO - 2023-03-22 10:07:12 --> Controller Class Initialized
DEBUG - 2023-03-22 10:07:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:12 --> Database Driver Class Initialized
INFO - 2023-03-22 10:07:12 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:07:12 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:12 --> Total execution time: 0.0417
INFO - 2023-03-22 10:07:12 --> Config Class Initialized
INFO - 2023-03-22 10:07:12 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:12 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:12 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:12 --> URI Class Initialized
INFO - 2023-03-22 10:07:12 --> Router Class Initialized
INFO - 2023-03-22 10:07:12 --> Output Class Initialized
INFO - 2023-03-22 10:07:12 --> Security Class Initialized
DEBUG - 2023-03-22 10:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:12 --> Input Class Initialized
INFO - 2023-03-22 10:07:12 --> Language Class Initialized
INFO - 2023-03-22 10:07:12 --> Loader Class Initialized
INFO - 2023-03-22 10:07:12 --> Controller Class Initialized
DEBUG - 2023-03-22 10:07:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:12 --> Database Driver Class Initialized
INFO - 2023-03-22 10:07:12 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:07:12 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:12 --> Total execution time: 0.0148
INFO - 2023-03-22 10:07:16 --> Config Class Initialized
INFO - 2023-03-22 10:07:16 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:16 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:16 --> Config Class Initialized
INFO - 2023-03-22 10:07:16 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:16 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:16 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:16 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:16 --> URI Class Initialized
INFO - 2023-03-22 10:07:16 --> Router Class Initialized
INFO - 2023-03-22 10:07:16 --> URI Class Initialized
INFO - 2023-03-22 10:07:16 --> Output Class Initialized
INFO - 2023-03-22 10:07:16 --> Router Class Initialized
INFO - 2023-03-22 10:07:16 --> Security Class Initialized
DEBUG - 2023-03-22 10:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:16 --> Input Class Initialized
INFO - 2023-03-22 10:07:16 --> Output Class Initialized
INFO - 2023-03-22 10:07:16 --> Language Class Initialized
INFO - 2023-03-22 10:07:16 --> Security Class Initialized
INFO - 2023-03-22 10:07:16 --> Loader Class Initialized
DEBUG - 2023-03-22 10:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:16 --> Controller Class Initialized
INFO - 2023-03-22 10:07:16 --> Input Class Initialized
DEBUG - 2023-03-22 10:07:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:16 --> Language Class Initialized
INFO - 2023-03-22 10:07:16 --> Loader Class Initialized
INFO - 2023-03-22 10:07:16 --> Database Driver Class Initialized
INFO - 2023-03-22 10:07:16 --> Controller Class Initialized
DEBUG - 2023-03-22 10:07:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:16 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:16 --> Total execution time: 0.0081
INFO - 2023-03-22 10:07:16 --> Config Class Initialized
INFO - 2023-03-22 10:07:16 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:07:16 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:16 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:16 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:16 --> URI Class Initialized
INFO - 2023-03-22 10:07:16 --> Router Class Initialized
INFO - 2023-03-22 10:07:16 --> Output Class Initialized
INFO - 2023-03-22 10:07:16 --> Security Class Initialized
DEBUG - 2023-03-22 10:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:16 --> Input Class Initialized
INFO - 2023-03-22 10:07:16 --> Language Class Initialized
INFO - 2023-03-22 10:07:16 --> Loader Class Initialized
INFO - 2023-03-22 10:07:16 --> Controller Class Initialized
DEBUG - 2023-03-22 10:07:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:16 --> Database Driver Class Initialized
INFO - 2023-03-22 10:07:16 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:16 --> Total execution time: 0.0574
INFO - 2023-03-22 10:07:16 --> Config Class Initialized
INFO - 2023-03-22 10:07:16 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:16 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:16 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:16 --> URI Class Initialized
INFO - 2023-03-22 10:07:16 --> Router Class Initialized
INFO - 2023-03-22 10:07:16 --> Output Class Initialized
INFO - 2023-03-22 10:07:16 --> Security Class Initialized
DEBUG - 2023-03-22 10:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:16 --> Input Class Initialized
INFO - 2023-03-22 10:07:16 --> Language Class Initialized
INFO - 2023-03-22 10:07:16 --> Loader Class Initialized
INFO - 2023-03-22 10:07:16 --> Controller Class Initialized
DEBUG - 2023-03-22 10:07:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:16 --> Database Driver Class Initialized
INFO - 2023-03-22 10:07:16 --> Model "Login_model" initialized
INFO - 2023-03-22 10:07:16 --> Database Driver Class Initialized
INFO - 2023-03-22 10:07:16 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:07:16 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:07:16 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:16 --> Total execution time: 0.0756
INFO - 2023-03-22 10:07:16 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:16 --> Total execution time: 0.0280
INFO - 2023-03-22 10:07:17 --> Config Class Initialized
INFO - 2023-03-22 10:07:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:17 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:17 --> URI Class Initialized
INFO - 2023-03-22 10:07:17 --> Router Class Initialized
INFO - 2023-03-22 10:07:17 --> Output Class Initialized
INFO - 2023-03-22 10:07:17 --> Security Class Initialized
DEBUG - 2023-03-22 10:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:17 --> Input Class Initialized
INFO - 2023-03-22 10:07:17 --> Language Class Initialized
INFO - 2023-03-22 10:07:17 --> Loader Class Initialized
INFO - 2023-03-22 10:07:17 --> Controller Class Initialized
DEBUG - 2023-03-22 10:07:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:17 --> Database Driver Class Initialized
INFO - 2023-03-22 10:07:17 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:07:17 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:17 --> Total execution time: 0.0440
INFO - 2023-03-22 10:07:17 --> Config Class Initialized
INFO - 2023-03-22 10:07:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:17 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:17 --> URI Class Initialized
INFO - 2023-03-22 10:07:17 --> Router Class Initialized
INFO - 2023-03-22 10:07:17 --> Output Class Initialized
INFO - 2023-03-22 10:07:17 --> Security Class Initialized
DEBUG - 2023-03-22 10:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:17 --> Input Class Initialized
INFO - 2023-03-22 10:07:17 --> Language Class Initialized
INFO - 2023-03-22 10:07:17 --> Loader Class Initialized
INFO - 2023-03-22 10:07:17 --> Controller Class Initialized
DEBUG - 2023-03-22 10:07:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:17 --> Database Driver Class Initialized
INFO - 2023-03-22 10:07:17 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:07:17 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:17 --> Total execution time: 0.0605
INFO - 2023-03-22 10:07:38 --> Config Class Initialized
INFO - 2023-03-22 10:07:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:38 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:38 --> URI Class Initialized
INFO - 2023-03-22 10:07:38 --> Router Class Initialized
INFO - 2023-03-22 10:07:38 --> Output Class Initialized
INFO - 2023-03-22 10:07:38 --> Security Class Initialized
DEBUG - 2023-03-22 10:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:38 --> Input Class Initialized
INFO - 2023-03-22 10:07:38 --> Language Class Initialized
INFO - 2023-03-22 10:07:38 --> Loader Class Initialized
INFO - 2023-03-22 10:07:38 --> Controller Class Initialized
DEBUG - 2023-03-22 10:07:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:38 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:38 --> Total execution time: 0.0045
INFO - 2023-03-22 10:07:38 --> Config Class Initialized
INFO - 2023-03-22 10:07:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:38 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:38 --> URI Class Initialized
INFO - 2023-03-22 10:07:38 --> Router Class Initialized
INFO - 2023-03-22 10:07:38 --> Output Class Initialized
INFO - 2023-03-22 10:07:38 --> Security Class Initialized
DEBUG - 2023-03-22 10:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:38 --> Input Class Initialized
INFO - 2023-03-22 10:07:38 --> Language Class Initialized
INFO - 2023-03-22 10:07:38 --> Loader Class Initialized
INFO - 2023-03-22 10:07:38 --> Controller Class Initialized
DEBUG - 2023-03-22 10:07:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:38 --> Database Driver Class Initialized
INFO - 2023-03-22 10:07:38 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:07:38 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:38 --> Total execution time: 0.0611
INFO - 2023-03-22 10:07:38 --> Config Class Initialized
INFO - 2023-03-22 10:07:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:38 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:38 --> URI Class Initialized
INFO - 2023-03-22 10:07:38 --> Router Class Initialized
INFO - 2023-03-22 10:07:38 --> Output Class Initialized
INFO - 2023-03-22 10:07:38 --> Security Class Initialized
DEBUG - 2023-03-22 10:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:38 --> Input Class Initialized
INFO - 2023-03-22 10:07:38 --> Language Class Initialized
INFO - 2023-03-22 10:07:38 --> Loader Class Initialized
INFO - 2023-03-22 10:07:38 --> Controller Class Initialized
DEBUG - 2023-03-22 10:07:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:38 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:38 --> Total execution time: 0.0425
INFO - 2023-03-22 10:07:38 --> Config Class Initialized
INFO - 2023-03-22 10:07:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:38 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:38 --> URI Class Initialized
INFO - 2023-03-22 10:07:38 --> Router Class Initialized
INFO - 2023-03-22 10:07:38 --> Output Class Initialized
INFO - 2023-03-22 10:07:38 --> Security Class Initialized
DEBUG - 2023-03-22 10:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:38 --> Input Class Initialized
INFO - 2023-03-22 10:07:38 --> Language Class Initialized
INFO - 2023-03-22 10:07:38 --> Loader Class Initialized
INFO - 2023-03-22 10:07:38 --> Controller Class Initialized
DEBUG - 2023-03-22 10:07:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:38 --> Database Driver Class Initialized
INFO - 2023-03-22 10:07:38 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:07:38 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:38 --> Total execution time: 0.0121
INFO - 2023-03-22 10:07:54 --> Config Class Initialized
INFO - 2023-03-22 10:07:54 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:54 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:54 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:54 --> URI Class Initialized
INFO - 2023-03-22 10:07:54 --> Router Class Initialized
INFO - 2023-03-22 10:07:54 --> Output Class Initialized
INFO - 2023-03-22 10:07:54 --> Security Class Initialized
DEBUG - 2023-03-22 10:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:54 --> Input Class Initialized
INFO - 2023-03-22 10:07:54 --> Language Class Initialized
INFO - 2023-03-22 10:07:54 --> Loader Class Initialized
INFO - 2023-03-22 10:07:54 --> Controller Class Initialized
DEBUG - 2023-03-22 10:07:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:54 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:54 --> Total execution time: 0.0042
INFO - 2023-03-22 10:07:54 --> Config Class Initialized
INFO - 2023-03-22 10:07:54 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:07:54 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:07:54 --> Utf8 Class Initialized
INFO - 2023-03-22 10:07:54 --> URI Class Initialized
INFO - 2023-03-22 10:07:54 --> Router Class Initialized
INFO - 2023-03-22 10:07:54 --> Output Class Initialized
INFO - 2023-03-22 10:07:54 --> Security Class Initialized
DEBUG - 2023-03-22 10:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:07:54 --> Input Class Initialized
INFO - 2023-03-22 10:07:54 --> Language Class Initialized
INFO - 2023-03-22 10:07:54 --> Loader Class Initialized
INFO - 2023-03-22 10:07:54 --> Controller Class Initialized
DEBUG - 2023-03-22 10:07:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:07:54 --> Database Driver Class Initialized
INFO - 2023-03-22 10:07:54 --> Model "Login_model" initialized
INFO - 2023-03-22 10:07:54 --> Database Driver Class Initialized
INFO - 2023-03-22 10:07:54 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:07:54 --> Final output sent to browser
DEBUG - 2023-03-22 10:07:54 --> Total execution time: 0.0276
INFO - 2023-03-22 10:08:12 --> Config Class Initialized
INFO - 2023-03-22 10:08:12 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:12 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:12 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:12 --> URI Class Initialized
INFO - 2023-03-22 10:08:12 --> Router Class Initialized
INFO - 2023-03-22 10:08:12 --> Output Class Initialized
INFO - 2023-03-22 10:08:12 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:12 --> Input Class Initialized
INFO - 2023-03-22 10:08:12 --> Language Class Initialized
INFO - 2023-03-22 10:08:12 --> Loader Class Initialized
INFO - 2023-03-22 10:08:12 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:12 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:12 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:12 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:12 --> Total execution time: 0.1400
INFO - 2023-03-22 10:08:12 --> Config Class Initialized
INFO - 2023-03-22 10:08:12 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:12 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:12 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:12 --> URI Class Initialized
INFO - 2023-03-22 10:08:12 --> Router Class Initialized
INFO - 2023-03-22 10:08:12 --> Output Class Initialized
INFO - 2023-03-22 10:08:12 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:12 --> Input Class Initialized
INFO - 2023-03-22 10:08:12 --> Language Class Initialized
INFO - 2023-03-22 10:08:12 --> Loader Class Initialized
INFO - 2023-03-22 10:08:12 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:12 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:12 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:12 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:12 --> Total execution time: 0.0165
INFO - 2023-03-22 10:08:15 --> Config Class Initialized
INFO - 2023-03-22 10:08:15 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:15 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:15 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:15 --> URI Class Initialized
INFO - 2023-03-22 10:08:15 --> Router Class Initialized
INFO - 2023-03-22 10:08:15 --> Output Class Initialized
INFO - 2023-03-22 10:08:15 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:15 --> Input Class Initialized
INFO - 2023-03-22 10:08:15 --> Language Class Initialized
INFO - 2023-03-22 10:08:15 --> Loader Class Initialized
INFO - 2023-03-22 10:08:15 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:15 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:15 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:15 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:15 --> Total execution time: 0.0255
INFO - 2023-03-22 10:08:15 --> Config Class Initialized
INFO - 2023-03-22 10:08:15 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:15 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:15 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:15 --> URI Class Initialized
INFO - 2023-03-22 10:08:15 --> Router Class Initialized
INFO - 2023-03-22 10:08:15 --> Output Class Initialized
INFO - 2023-03-22 10:08:15 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:15 --> Input Class Initialized
INFO - 2023-03-22 10:08:15 --> Language Class Initialized
INFO - 2023-03-22 10:08:15 --> Loader Class Initialized
INFO - 2023-03-22 10:08:15 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:15 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:15 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:15 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:15 --> Total execution time: 0.0154
INFO - 2023-03-22 10:08:17 --> Config Class Initialized
INFO - 2023-03-22 10:08:17 --> Config Class Initialized
INFO - 2023-03-22 10:08:17 --> Hooks Class Initialized
INFO - 2023-03-22 10:08:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:17 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 10:08:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:17 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:17 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:17 --> URI Class Initialized
INFO - 2023-03-22 10:08:17 --> URI Class Initialized
INFO - 2023-03-22 10:08:17 --> Router Class Initialized
INFO - 2023-03-22 10:08:17 --> Router Class Initialized
INFO - 2023-03-22 10:08:17 --> Output Class Initialized
INFO - 2023-03-22 10:08:17 --> Output Class Initialized
INFO - 2023-03-22 10:08:17 --> Security Class Initialized
INFO - 2023-03-22 10:08:17 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:17 --> Input Class Initialized
INFO - 2023-03-22 10:08:17 --> Language Class Initialized
DEBUG - 2023-03-22 10:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:17 --> Loader Class Initialized
INFO - 2023-03-22 10:08:17 --> Input Class Initialized
INFO - 2023-03-22 10:08:17 --> Controller Class Initialized
INFO - 2023-03-22 10:08:17 --> Language Class Initialized
DEBUG - 2023-03-22 10:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:17 --> Loader Class Initialized
INFO - 2023-03-22 10:08:17 --> Controller Class Initialized
INFO - 2023-03-22 10:08:17 --> Database Driver Class Initialized
DEBUG - 2023-03-22 10:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:17 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:17 --> Total execution time: 0.0051
INFO - 2023-03-22 10:08:17 --> Config Class Initialized
INFO - 2023-03-22 10:08:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:17 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:17 --> URI Class Initialized
INFO - 2023-03-22 10:08:17 --> Router Class Initialized
INFO - 2023-03-22 10:08:17 --> Output Class Initialized
INFO - 2023-03-22 10:08:17 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:17 --> Input Class Initialized
INFO - 2023-03-22 10:08:17 --> Language Class Initialized
INFO - 2023-03-22 10:08:17 --> Loader Class Initialized
INFO - 2023-03-22 10:08:17 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:17 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:17 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:18 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:18 --> Total execution time: 0.0185
INFO - 2023-03-22 10:08:18 --> Model "Login_model" initialized
INFO - 2023-03-22 10:08:18 --> Config Class Initialized
INFO - 2023-03-22 10:08:18 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:18 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:18 --> URI Class Initialized
INFO - 2023-03-22 10:08:18 --> Router Class Initialized
INFO - 2023-03-22 10:08:18 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:18 --> Output Class Initialized
INFO - 2023-03-22 10:08:18 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:18 --> Input Class Initialized
INFO - 2023-03-22 10:08:18 --> Language Class Initialized
INFO - 2023-03-22 10:08:18 --> Loader Class Initialized
INFO - 2023-03-22 10:08:18 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:18 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:18 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:18 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:18 --> Total execution time: 0.0213
INFO - 2023-03-22 10:08:18 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:18 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:18 --> Total execution time: 0.0597
INFO - 2023-03-22 10:08:21 --> Config Class Initialized
INFO - 2023-03-22 10:08:21 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:21 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:21 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:21 --> URI Class Initialized
INFO - 2023-03-22 10:08:21 --> Router Class Initialized
INFO - 2023-03-22 10:08:21 --> Output Class Initialized
INFO - 2023-03-22 10:08:21 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:21 --> Input Class Initialized
INFO - 2023-03-22 10:08:21 --> Language Class Initialized
INFO - 2023-03-22 10:08:21 --> Loader Class Initialized
INFO - 2023-03-22 10:08:21 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:21 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:21 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:21 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:21 --> Total execution time: 0.0165
INFO - 2023-03-22 10:08:21 --> Config Class Initialized
INFO - 2023-03-22 10:08:21 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:21 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:21 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:21 --> URI Class Initialized
INFO - 2023-03-22 10:08:21 --> Router Class Initialized
INFO - 2023-03-22 10:08:21 --> Output Class Initialized
INFO - 2023-03-22 10:08:21 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:21 --> Input Class Initialized
INFO - 2023-03-22 10:08:21 --> Language Class Initialized
INFO - 2023-03-22 10:08:21 --> Loader Class Initialized
INFO - 2023-03-22 10:08:21 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:21 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:21 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:21 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:21 --> Total execution time: 0.0527
INFO - 2023-03-22 10:08:24 --> Config Class Initialized
INFO - 2023-03-22 10:08:24 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:24 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:24 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:24 --> URI Class Initialized
INFO - 2023-03-22 10:08:24 --> Router Class Initialized
INFO - 2023-03-22 10:08:24 --> Output Class Initialized
INFO - 2023-03-22 10:08:24 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:24 --> Input Class Initialized
INFO - 2023-03-22 10:08:24 --> Language Class Initialized
INFO - 2023-03-22 10:08:24 --> Loader Class Initialized
INFO - 2023-03-22 10:08:24 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:24 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:24 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:24 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:24 --> Total execution time: 0.0201
INFO - 2023-03-22 10:08:24 --> Config Class Initialized
INFO - 2023-03-22 10:08:24 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:24 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:24 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:24 --> URI Class Initialized
INFO - 2023-03-22 10:08:24 --> Router Class Initialized
INFO - 2023-03-22 10:08:24 --> Output Class Initialized
INFO - 2023-03-22 10:08:24 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:24 --> Input Class Initialized
INFO - 2023-03-22 10:08:24 --> Language Class Initialized
INFO - 2023-03-22 10:08:24 --> Loader Class Initialized
INFO - 2023-03-22 10:08:24 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:24 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:24 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:24 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:24 --> Total execution time: 0.1725
INFO - 2023-03-22 10:08:27 --> Config Class Initialized
INFO - 2023-03-22 10:08:27 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:27 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:27 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:27 --> URI Class Initialized
INFO - 2023-03-22 10:08:27 --> Router Class Initialized
INFO - 2023-03-22 10:08:27 --> Output Class Initialized
INFO - 2023-03-22 10:08:27 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:27 --> Input Class Initialized
INFO - 2023-03-22 10:08:27 --> Language Class Initialized
INFO - 2023-03-22 10:08:27 --> Loader Class Initialized
INFO - 2023-03-22 10:08:27 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:27 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:27 --> Total execution time: 0.0039
INFO - 2023-03-22 10:08:27 --> Config Class Initialized
INFO - 2023-03-22 10:08:27 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:27 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:27 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:27 --> URI Class Initialized
INFO - 2023-03-22 10:08:27 --> Router Class Initialized
INFO - 2023-03-22 10:08:27 --> Output Class Initialized
INFO - 2023-03-22 10:08:27 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:27 --> Input Class Initialized
INFO - 2023-03-22 10:08:27 --> Language Class Initialized
INFO - 2023-03-22 10:08:27 --> Loader Class Initialized
INFO - 2023-03-22 10:08:27 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:27 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:27 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:27 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:27 --> Total execution time: 0.0143
INFO - 2023-03-22 10:08:27 --> Config Class Initialized
INFO - 2023-03-22 10:08:27 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:27 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:27 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:27 --> URI Class Initialized
INFO - 2023-03-22 10:08:27 --> Router Class Initialized
INFO - 2023-03-22 10:08:27 --> Output Class Initialized
INFO - 2023-03-22 10:08:27 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:27 --> Input Class Initialized
INFO - 2023-03-22 10:08:27 --> Language Class Initialized
INFO - 2023-03-22 10:08:27 --> Loader Class Initialized
INFO - 2023-03-22 10:08:27 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:27 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:27 --> Total execution time: 0.0419
INFO - 2023-03-22 10:08:27 --> Config Class Initialized
INFO - 2023-03-22 10:08:27 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:27 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:27 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:27 --> URI Class Initialized
INFO - 2023-03-22 10:08:27 --> Router Class Initialized
INFO - 2023-03-22 10:08:27 --> Output Class Initialized
INFO - 2023-03-22 10:08:27 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:27 --> Input Class Initialized
INFO - 2023-03-22 10:08:27 --> Language Class Initialized
INFO - 2023-03-22 10:08:27 --> Loader Class Initialized
INFO - 2023-03-22 10:08:27 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:27 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:27 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:27 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:27 --> Total execution time: 0.0106
INFO - 2023-03-22 10:08:49 --> Config Class Initialized
INFO - 2023-03-22 10:08:49 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:49 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:49 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:49 --> URI Class Initialized
INFO - 2023-03-22 10:08:49 --> Router Class Initialized
INFO - 2023-03-22 10:08:49 --> Output Class Initialized
INFO - 2023-03-22 10:08:49 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:49 --> Input Class Initialized
INFO - 2023-03-22 10:08:49 --> Language Class Initialized
INFO - 2023-03-22 10:08:49 --> Loader Class Initialized
INFO - 2023-03-22 10:08:49 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:49 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:49 --> Total execution time: 0.0046
INFO - 2023-03-22 10:08:49 --> Config Class Initialized
INFO - 2023-03-22 10:08:49 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:49 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:49 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:49 --> URI Class Initialized
INFO - 2023-03-22 10:08:49 --> Router Class Initialized
INFO - 2023-03-22 10:08:49 --> Output Class Initialized
INFO - 2023-03-22 10:08:49 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:49 --> Input Class Initialized
INFO - 2023-03-22 10:08:49 --> Language Class Initialized
INFO - 2023-03-22 10:08:49 --> Loader Class Initialized
INFO - 2023-03-22 10:08:49 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:49 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:49 --> Model "Login_model" initialized
INFO - 2023-03-22 10:08:49 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:49 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:49 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:49 --> Total execution time: 0.0355
INFO - 2023-03-22 10:08:49 --> Config Class Initialized
INFO - 2023-03-22 10:08:49 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:49 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:49 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:49 --> URI Class Initialized
INFO - 2023-03-22 10:08:49 --> Router Class Initialized
INFO - 2023-03-22 10:08:49 --> Output Class Initialized
INFO - 2023-03-22 10:08:49 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:49 --> Input Class Initialized
INFO - 2023-03-22 10:08:49 --> Language Class Initialized
INFO - 2023-03-22 10:08:49 --> Loader Class Initialized
INFO - 2023-03-22 10:08:49 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:49 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:49 --> Total execution time: 0.0047
INFO - 2023-03-22 10:08:49 --> Config Class Initialized
INFO - 2023-03-22 10:08:49 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:49 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:49 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:49 --> URI Class Initialized
INFO - 2023-03-22 10:08:49 --> Router Class Initialized
INFO - 2023-03-22 10:08:49 --> Output Class Initialized
INFO - 2023-03-22 10:08:49 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:49 --> Input Class Initialized
INFO - 2023-03-22 10:08:49 --> Language Class Initialized
INFO - 2023-03-22 10:08:49 --> Loader Class Initialized
INFO - 2023-03-22 10:08:49 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:49 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:49 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:49 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:49 --> Total execution time: 0.1636
INFO - 2023-03-22 10:08:54 --> Config Class Initialized
INFO - 2023-03-22 10:08:54 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:54 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:54 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:54 --> URI Class Initialized
INFO - 2023-03-22 10:08:54 --> Router Class Initialized
INFO - 2023-03-22 10:08:54 --> Output Class Initialized
INFO - 2023-03-22 10:08:54 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:54 --> Input Class Initialized
INFO - 2023-03-22 10:08:54 --> Language Class Initialized
INFO - 2023-03-22 10:08:54 --> Loader Class Initialized
INFO - 2023-03-22 10:08:54 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:54 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:54 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:54 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:54 --> Total execution time: 0.0188
INFO - 2023-03-22 10:08:59 --> Config Class Initialized
INFO - 2023-03-22 10:08:59 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:59 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:59 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:59 --> URI Class Initialized
INFO - 2023-03-22 10:08:59 --> Router Class Initialized
INFO - 2023-03-22 10:08:59 --> Output Class Initialized
INFO - 2023-03-22 10:08:59 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:59 --> Input Class Initialized
INFO - 2023-03-22 10:08:59 --> Language Class Initialized
INFO - 2023-03-22 10:08:59 --> Loader Class Initialized
INFO - 2023-03-22 10:08:59 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:59 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:59 --> Total execution time: 0.0040
INFO - 2023-03-22 10:08:59 --> Config Class Initialized
INFO - 2023-03-22 10:08:59 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:08:59 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:08:59 --> Utf8 Class Initialized
INFO - 2023-03-22 10:08:59 --> URI Class Initialized
INFO - 2023-03-22 10:08:59 --> Router Class Initialized
INFO - 2023-03-22 10:08:59 --> Output Class Initialized
INFO - 2023-03-22 10:08:59 --> Security Class Initialized
DEBUG - 2023-03-22 10:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:08:59 --> Input Class Initialized
INFO - 2023-03-22 10:08:59 --> Language Class Initialized
INFO - 2023-03-22 10:08:59 --> Loader Class Initialized
INFO - 2023-03-22 10:08:59 --> Controller Class Initialized
DEBUG - 2023-03-22 10:08:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:08:59 --> Database Driver Class Initialized
INFO - 2023-03-22 10:08:59 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:08:59 --> Final output sent to browser
DEBUG - 2023-03-22 10:08:59 --> Total execution time: 0.0150
INFO - 2023-03-22 10:09:04 --> Config Class Initialized
INFO - 2023-03-22 10:09:04 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:04 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:04 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:04 --> URI Class Initialized
INFO - 2023-03-22 10:09:04 --> Router Class Initialized
INFO - 2023-03-22 10:09:04 --> Output Class Initialized
INFO - 2023-03-22 10:09:04 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:04 --> Input Class Initialized
INFO - 2023-03-22 10:09:04 --> Language Class Initialized
INFO - 2023-03-22 10:09:04 --> Loader Class Initialized
INFO - 2023-03-22 10:09:04 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:04 --> Database Driver Class Initialized
INFO - 2023-03-22 10:09:04 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:09:04 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:04 --> Total execution time: 0.0170
INFO - 2023-03-22 10:09:09 --> Config Class Initialized
INFO - 2023-03-22 10:09:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:09 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:09 --> URI Class Initialized
INFO - 2023-03-22 10:09:09 --> Router Class Initialized
INFO - 2023-03-22 10:09:09 --> Output Class Initialized
INFO - 2023-03-22 10:09:09 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:09 --> Input Class Initialized
INFO - 2023-03-22 10:09:09 --> Language Class Initialized
INFO - 2023-03-22 10:09:09 --> Loader Class Initialized
INFO - 2023-03-22 10:09:09 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:09 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:09 --> Total execution time: 0.0040
INFO - 2023-03-22 10:09:09 --> Config Class Initialized
INFO - 2023-03-22 10:09:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:09 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:09 --> URI Class Initialized
INFO - 2023-03-22 10:09:09 --> Router Class Initialized
INFO - 2023-03-22 10:09:09 --> Output Class Initialized
INFO - 2023-03-22 10:09:09 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:09 --> Input Class Initialized
INFO - 2023-03-22 10:09:09 --> Language Class Initialized
INFO - 2023-03-22 10:09:09 --> Loader Class Initialized
INFO - 2023-03-22 10:09:09 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:09 --> Database Driver Class Initialized
INFO - 2023-03-22 10:09:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:09:09 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:09 --> Total execution time: 0.0175
INFO - 2023-03-22 10:09:14 --> Config Class Initialized
INFO - 2023-03-22 10:09:14 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:14 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:14 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:14 --> URI Class Initialized
INFO - 2023-03-22 10:09:14 --> Router Class Initialized
INFO - 2023-03-22 10:09:14 --> Output Class Initialized
INFO - 2023-03-22 10:09:14 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:14 --> Input Class Initialized
INFO - 2023-03-22 10:09:14 --> Language Class Initialized
INFO - 2023-03-22 10:09:14 --> Loader Class Initialized
INFO - 2023-03-22 10:09:14 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:14 --> Database Driver Class Initialized
INFO - 2023-03-22 10:09:14 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:09:14 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:14 --> Total execution time: 0.0148
INFO - 2023-03-22 10:09:19 --> Config Class Initialized
INFO - 2023-03-22 10:09:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:19 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:19 --> URI Class Initialized
INFO - 2023-03-22 10:09:19 --> Router Class Initialized
INFO - 2023-03-22 10:09:19 --> Output Class Initialized
INFO - 2023-03-22 10:09:19 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:19 --> Input Class Initialized
INFO - 2023-03-22 10:09:19 --> Language Class Initialized
INFO - 2023-03-22 10:09:19 --> Loader Class Initialized
INFO - 2023-03-22 10:09:19 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:19 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:19 --> Total execution time: 0.0040
INFO - 2023-03-22 10:09:19 --> Config Class Initialized
INFO - 2023-03-22 10:09:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:19 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:19 --> URI Class Initialized
INFO - 2023-03-22 10:09:19 --> Router Class Initialized
INFO - 2023-03-22 10:09:19 --> Output Class Initialized
INFO - 2023-03-22 10:09:19 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:19 --> Input Class Initialized
INFO - 2023-03-22 10:09:19 --> Language Class Initialized
INFO - 2023-03-22 10:09:19 --> Loader Class Initialized
INFO - 2023-03-22 10:09:19 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:19 --> Database Driver Class Initialized
INFO - 2023-03-22 10:09:19 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:09:19 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:19 --> Total execution time: 0.0145
INFO - 2023-03-22 10:09:24 --> Config Class Initialized
INFO - 2023-03-22 10:09:24 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:24 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:24 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:24 --> URI Class Initialized
INFO - 2023-03-22 10:09:24 --> Router Class Initialized
INFO - 2023-03-22 10:09:24 --> Output Class Initialized
INFO - 2023-03-22 10:09:24 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:24 --> Input Class Initialized
INFO - 2023-03-22 10:09:24 --> Language Class Initialized
INFO - 2023-03-22 10:09:24 --> Loader Class Initialized
INFO - 2023-03-22 10:09:24 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:24 --> Database Driver Class Initialized
INFO - 2023-03-22 10:09:24 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:09:24 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:24 --> Total execution time: 0.0178
INFO - 2023-03-22 10:09:29 --> Config Class Initialized
INFO - 2023-03-22 10:09:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:29 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:29 --> URI Class Initialized
INFO - 2023-03-22 10:09:29 --> Router Class Initialized
INFO - 2023-03-22 10:09:29 --> Output Class Initialized
INFO - 2023-03-22 10:09:29 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:29 --> Input Class Initialized
INFO - 2023-03-22 10:09:29 --> Language Class Initialized
INFO - 2023-03-22 10:09:29 --> Loader Class Initialized
INFO - 2023-03-22 10:09:29 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:29 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:29 --> Total execution time: 0.0046
INFO - 2023-03-22 10:09:29 --> Config Class Initialized
INFO - 2023-03-22 10:09:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:29 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:29 --> URI Class Initialized
INFO - 2023-03-22 10:09:29 --> Router Class Initialized
INFO - 2023-03-22 10:09:29 --> Output Class Initialized
INFO - 2023-03-22 10:09:29 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:29 --> Input Class Initialized
INFO - 2023-03-22 10:09:29 --> Language Class Initialized
INFO - 2023-03-22 10:09:29 --> Loader Class Initialized
INFO - 2023-03-22 10:09:29 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:29 --> Database Driver Class Initialized
INFO - 2023-03-22 10:09:29 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:09:29 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:29 --> Total execution time: 0.0131
INFO - 2023-03-22 10:09:34 --> Config Class Initialized
INFO - 2023-03-22 10:09:34 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:34 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:34 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:34 --> URI Class Initialized
INFO - 2023-03-22 10:09:34 --> Router Class Initialized
INFO - 2023-03-22 10:09:34 --> Output Class Initialized
INFO - 2023-03-22 10:09:34 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:34 --> Input Class Initialized
INFO - 2023-03-22 10:09:34 --> Language Class Initialized
INFO - 2023-03-22 10:09:34 --> Loader Class Initialized
INFO - 2023-03-22 10:09:34 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:34 --> Database Driver Class Initialized
INFO - 2023-03-22 10:09:34 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:09:34 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:34 --> Total execution time: 0.0234
INFO - 2023-03-22 10:09:39 --> Config Class Initialized
INFO - 2023-03-22 10:09:39 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:39 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:39 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:39 --> URI Class Initialized
INFO - 2023-03-22 10:09:39 --> Router Class Initialized
INFO - 2023-03-22 10:09:39 --> Output Class Initialized
INFO - 2023-03-22 10:09:39 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:39 --> Input Class Initialized
INFO - 2023-03-22 10:09:39 --> Language Class Initialized
INFO - 2023-03-22 10:09:39 --> Loader Class Initialized
INFO - 2023-03-22 10:09:39 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:39 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:39 --> Total execution time: 0.0047
INFO - 2023-03-22 10:09:39 --> Config Class Initialized
INFO - 2023-03-22 10:09:39 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:39 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:39 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:39 --> URI Class Initialized
INFO - 2023-03-22 10:09:39 --> Router Class Initialized
INFO - 2023-03-22 10:09:39 --> Output Class Initialized
INFO - 2023-03-22 10:09:39 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:39 --> Input Class Initialized
INFO - 2023-03-22 10:09:39 --> Language Class Initialized
INFO - 2023-03-22 10:09:39 --> Loader Class Initialized
INFO - 2023-03-22 10:09:39 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:39 --> Database Driver Class Initialized
INFO - 2023-03-22 10:09:39 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:09:39 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:39 --> Total execution time: 0.0128
INFO - 2023-03-22 10:09:44 --> Config Class Initialized
INFO - 2023-03-22 10:09:44 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:44 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:44 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:44 --> URI Class Initialized
INFO - 2023-03-22 10:09:44 --> Router Class Initialized
INFO - 2023-03-22 10:09:44 --> Output Class Initialized
INFO - 2023-03-22 10:09:44 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:44 --> Input Class Initialized
INFO - 2023-03-22 10:09:44 --> Language Class Initialized
INFO - 2023-03-22 10:09:44 --> Loader Class Initialized
INFO - 2023-03-22 10:09:44 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:44 --> Database Driver Class Initialized
INFO - 2023-03-22 10:09:44 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:09:44 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:44 --> Total execution time: 0.0183
INFO - 2023-03-22 10:09:49 --> Config Class Initialized
INFO - 2023-03-22 10:09:49 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:49 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:49 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:49 --> URI Class Initialized
INFO - 2023-03-22 10:09:49 --> Router Class Initialized
INFO - 2023-03-22 10:09:49 --> Output Class Initialized
INFO - 2023-03-22 10:09:49 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:49 --> Input Class Initialized
INFO - 2023-03-22 10:09:49 --> Language Class Initialized
INFO - 2023-03-22 10:09:49 --> Loader Class Initialized
INFO - 2023-03-22 10:09:49 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:49 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:49 --> Total execution time: 0.0043
INFO - 2023-03-22 10:09:49 --> Config Class Initialized
INFO - 2023-03-22 10:09:49 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:49 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:49 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:49 --> URI Class Initialized
INFO - 2023-03-22 10:09:49 --> Router Class Initialized
INFO - 2023-03-22 10:09:49 --> Output Class Initialized
INFO - 2023-03-22 10:09:49 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:49 --> Input Class Initialized
INFO - 2023-03-22 10:09:49 --> Language Class Initialized
INFO - 2023-03-22 10:09:49 --> Loader Class Initialized
INFO - 2023-03-22 10:09:49 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:49 --> Database Driver Class Initialized
INFO - 2023-03-22 10:09:49 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:09:49 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:49 --> Total execution time: 0.0167
INFO - 2023-03-22 10:09:54 --> Config Class Initialized
INFO - 2023-03-22 10:09:54 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:54 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:54 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:54 --> URI Class Initialized
INFO - 2023-03-22 10:09:54 --> Router Class Initialized
INFO - 2023-03-22 10:09:54 --> Output Class Initialized
INFO - 2023-03-22 10:09:54 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:54 --> Input Class Initialized
INFO - 2023-03-22 10:09:54 --> Language Class Initialized
INFO - 2023-03-22 10:09:54 --> Loader Class Initialized
INFO - 2023-03-22 10:09:54 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:54 --> Database Driver Class Initialized
INFO - 2023-03-22 10:09:54 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:09:54 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:54 --> Total execution time: 0.0216
INFO - 2023-03-22 10:09:59 --> Config Class Initialized
INFO - 2023-03-22 10:09:59 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:59 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:59 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:59 --> URI Class Initialized
INFO - 2023-03-22 10:09:59 --> Router Class Initialized
INFO - 2023-03-22 10:09:59 --> Output Class Initialized
INFO - 2023-03-22 10:09:59 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:59 --> Input Class Initialized
INFO - 2023-03-22 10:09:59 --> Language Class Initialized
INFO - 2023-03-22 10:09:59 --> Loader Class Initialized
INFO - 2023-03-22 10:09:59 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:59 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:59 --> Total execution time: 0.0038
INFO - 2023-03-22 10:09:59 --> Config Class Initialized
INFO - 2023-03-22 10:09:59 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:09:59 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:09:59 --> Utf8 Class Initialized
INFO - 2023-03-22 10:09:59 --> URI Class Initialized
INFO - 2023-03-22 10:09:59 --> Router Class Initialized
INFO - 2023-03-22 10:09:59 --> Output Class Initialized
INFO - 2023-03-22 10:09:59 --> Security Class Initialized
DEBUG - 2023-03-22 10:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:09:59 --> Input Class Initialized
INFO - 2023-03-22 10:09:59 --> Language Class Initialized
INFO - 2023-03-22 10:09:59 --> Loader Class Initialized
INFO - 2023-03-22 10:09:59 --> Controller Class Initialized
DEBUG - 2023-03-22 10:09:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:09:59 --> Database Driver Class Initialized
INFO - 2023-03-22 10:09:59 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:09:59 --> Final output sent to browser
DEBUG - 2023-03-22 10:09:59 --> Total execution time: 0.0155
INFO - 2023-03-22 10:10:04 --> Config Class Initialized
INFO - 2023-03-22 10:10:04 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:04 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:04 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:04 --> URI Class Initialized
INFO - 2023-03-22 10:10:04 --> Router Class Initialized
INFO - 2023-03-22 10:10:04 --> Output Class Initialized
INFO - 2023-03-22 10:10:04 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:04 --> Input Class Initialized
INFO - 2023-03-22 10:10:04 --> Language Class Initialized
INFO - 2023-03-22 10:10:04 --> Loader Class Initialized
INFO - 2023-03-22 10:10:04 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:04 --> Database Driver Class Initialized
INFO - 2023-03-22 10:10:04 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:10:04 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:04 --> Total execution time: 0.0167
INFO - 2023-03-22 10:10:09 --> Config Class Initialized
INFO - 2023-03-22 10:10:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:09 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:09 --> URI Class Initialized
INFO - 2023-03-22 10:10:09 --> Router Class Initialized
INFO - 2023-03-22 10:10:09 --> Output Class Initialized
INFO - 2023-03-22 10:10:09 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:09 --> Input Class Initialized
INFO - 2023-03-22 10:10:09 --> Language Class Initialized
INFO - 2023-03-22 10:10:09 --> Loader Class Initialized
INFO - 2023-03-22 10:10:09 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:09 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:09 --> Total execution time: 0.0038
INFO - 2023-03-22 10:10:09 --> Config Class Initialized
INFO - 2023-03-22 10:10:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:09 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:09 --> URI Class Initialized
INFO - 2023-03-22 10:10:09 --> Router Class Initialized
INFO - 2023-03-22 10:10:09 --> Output Class Initialized
INFO - 2023-03-22 10:10:09 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:09 --> Input Class Initialized
INFO - 2023-03-22 10:10:09 --> Language Class Initialized
INFO - 2023-03-22 10:10:09 --> Loader Class Initialized
INFO - 2023-03-22 10:10:09 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:09 --> Database Driver Class Initialized
INFO - 2023-03-22 10:10:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:10:09 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:09 --> Total execution time: 0.0145
INFO - 2023-03-22 10:10:14 --> Config Class Initialized
INFO - 2023-03-22 10:10:14 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:14 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:14 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:14 --> URI Class Initialized
INFO - 2023-03-22 10:10:14 --> Router Class Initialized
INFO - 2023-03-22 10:10:14 --> Output Class Initialized
INFO - 2023-03-22 10:10:14 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:14 --> Input Class Initialized
INFO - 2023-03-22 10:10:14 --> Language Class Initialized
INFO - 2023-03-22 10:10:14 --> Loader Class Initialized
INFO - 2023-03-22 10:10:14 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:14 --> Database Driver Class Initialized
INFO - 2023-03-22 10:10:14 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:10:14 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:14 --> Total execution time: 0.0175
INFO - 2023-03-22 10:10:19 --> Config Class Initialized
INFO - 2023-03-22 10:10:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:19 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:19 --> URI Class Initialized
INFO - 2023-03-22 10:10:19 --> Router Class Initialized
INFO - 2023-03-22 10:10:19 --> Output Class Initialized
INFO - 2023-03-22 10:10:19 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:19 --> Input Class Initialized
INFO - 2023-03-22 10:10:19 --> Language Class Initialized
INFO - 2023-03-22 10:10:19 --> Loader Class Initialized
INFO - 2023-03-22 10:10:19 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:19 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:19 --> Total execution time: 0.0041
INFO - 2023-03-22 10:10:19 --> Config Class Initialized
INFO - 2023-03-22 10:10:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:19 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:19 --> URI Class Initialized
INFO - 2023-03-22 10:10:19 --> Router Class Initialized
INFO - 2023-03-22 10:10:19 --> Output Class Initialized
INFO - 2023-03-22 10:10:19 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:19 --> Input Class Initialized
INFO - 2023-03-22 10:10:19 --> Language Class Initialized
INFO - 2023-03-22 10:10:19 --> Loader Class Initialized
INFO - 2023-03-22 10:10:19 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:19 --> Database Driver Class Initialized
INFO - 2023-03-22 10:10:19 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:10:19 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:19 --> Total execution time: 0.0160
INFO - 2023-03-22 10:10:24 --> Config Class Initialized
INFO - 2023-03-22 10:10:24 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:24 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:24 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:24 --> URI Class Initialized
INFO - 2023-03-22 10:10:24 --> Router Class Initialized
INFO - 2023-03-22 10:10:24 --> Output Class Initialized
INFO - 2023-03-22 10:10:24 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:24 --> Input Class Initialized
INFO - 2023-03-22 10:10:24 --> Language Class Initialized
INFO - 2023-03-22 10:10:24 --> Loader Class Initialized
INFO - 2023-03-22 10:10:24 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:24 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:24 --> Total execution time: 0.0037
INFO - 2023-03-22 10:10:24 --> Config Class Initialized
INFO - 2023-03-22 10:10:24 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:24 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:24 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:24 --> URI Class Initialized
INFO - 2023-03-22 10:10:24 --> Router Class Initialized
INFO - 2023-03-22 10:10:24 --> Output Class Initialized
INFO - 2023-03-22 10:10:24 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:24 --> Input Class Initialized
INFO - 2023-03-22 10:10:24 --> Language Class Initialized
INFO - 2023-03-22 10:10:24 --> Loader Class Initialized
INFO - 2023-03-22 10:10:24 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:24 --> Database Driver Class Initialized
INFO - 2023-03-22 10:10:24 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:10:24 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:24 --> Total execution time: 0.0154
INFO - 2023-03-22 10:10:29 --> Config Class Initialized
INFO - 2023-03-22 10:10:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:29 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:29 --> URI Class Initialized
INFO - 2023-03-22 10:10:29 --> Router Class Initialized
INFO - 2023-03-22 10:10:29 --> Output Class Initialized
INFO - 2023-03-22 10:10:29 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:29 --> Input Class Initialized
INFO - 2023-03-22 10:10:29 --> Language Class Initialized
INFO - 2023-03-22 10:10:29 --> Loader Class Initialized
INFO - 2023-03-22 10:10:29 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:29 --> Database Driver Class Initialized
INFO - 2023-03-22 10:10:29 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:10:29 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:29 --> Total execution time: 0.0168
INFO - 2023-03-22 10:10:37 --> Config Class Initialized
INFO - 2023-03-22 10:10:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:37 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:37 --> URI Class Initialized
INFO - 2023-03-22 10:10:37 --> Router Class Initialized
INFO - 2023-03-22 10:10:37 --> Output Class Initialized
INFO - 2023-03-22 10:10:37 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:37 --> Input Class Initialized
INFO - 2023-03-22 10:10:37 --> Language Class Initialized
INFO - 2023-03-22 10:10:37 --> Loader Class Initialized
INFO - 2023-03-22 10:10:37 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:37 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:37 --> Total execution time: 0.0051
INFO - 2023-03-22 10:10:37 --> Config Class Initialized
INFO - 2023-03-22 10:10:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:37 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:37 --> URI Class Initialized
INFO - 2023-03-22 10:10:37 --> Router Class Initialized
INFO - 2023-03-22 10:10:37 --> Output Class Initialized
INFO - 2023-03-22 10:10:37 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:37 --> Input Class Initialized
INFO - 2023-03-22 10:10:37 --> Language Class Initialized
INFO - 2023-03-22 10:10:37 --> Loader Class Initialized
INFO - 2023-03-22 10:10:37 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:37 --> Database Driver Class Initialized
INFO - 2023-03-22 10:10:37 --> Model "Login_model" initialized
INFO - 2023-03-22 10:10:37 --> Database Driver Class Initialized
INFO - 2023-03-22 10:10:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:10:37 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:37 --> Total execution time: 0.0214
INFO - 2023-03-22 10:10:38 --> Config Class Initialized
INFO - 2023-03-22 10:10:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:38 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:38 --> URI Class Initialized
INFO - 2023-03-22 10:10:38 --> Router Class Initialized
INFO - 2023-03-22 10:10:38 --> Output Class Initialized
INFO - 2023-03-22 10:10:38 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:38 --> Input Class Initialized
INFO - 2023-03-22 10:10:38 --> Language Class Initialized
INFO - 2023-03-22 10:10:38 --> Loader Class Initialized
INFO - 2023-03-22 10:10:38 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:38 --> Database Driver Class Initialized
INFO - 2023-03-22 10:10:38 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:10:38 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:38 --> Total execution time: 0.0267
INFO - 2023-03-22 10:10:38 --> Config Class Initialized
INFO - 2023-03-22 10:10:38 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:38 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:38 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:38 --> URI Class Initialized
INFO - 2023-03-22 10:10:38 --> Router Class Initialized
INFO - 2023-03-22 10:10:38 --> Output Class Initialized
INFO - 2023-03-22 10:10:38 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:38 --> Input Class Initialized
INFO - 2023-03-22 10:10:38 --> Language Class Initialized
INFO - 2023-03-22 10:10:38 --> Loader Class Initialized
INFO - 2023-03-22 10:10:38 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:38 --> Database Driver Class Initialized
INFO - 2023-03-22 10:10:38 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:10:38 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:38 --> Total execution time: 0.0991
INFO - 2023-03-22 10:10:57 --> Config Class Initialized
INFO - 2023-03-22 10:10:57 --> Config Class Initialized
INFO - 2023-03-22 10:10:57 --> Hooks Class Initialized
INFO - 2023-03-22 10:10:57 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:57 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 10:10:57 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:57 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:57 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:57 --> URI Class Initialized
INFO - 2023-03-22 10:10:57 --> URI Class Initialized
INFO - 2023-03-22 10:10:57 --> Router Class Initialized
INFO - 2023-03-22 10:10:57 --> Router Class Initialized
INFO - 2023-03-22 10:10:57 --> Output Class Initialized
INFO - 2023-03-22 10:10:57 --> Output Class Initialized
INFO - 2023-03-22 10:10:57 --> Security Class Initialized
INFO - 2023-03-22 10:10:57 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 10:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:57 --> Input Class Initialized
INFO - 2023-03-22 10:10:57 --> Input Class Initialized
INFO - 2023-03-22 10:10:57 --> Language Class Initialized
INFO - 2023-03-22 10:10:57 --> Language Class Initialized
INFO - 2023-03-22 10:10:57 --> Loader Class Initialized
INFO - 2023-03-22 10:10:57 --> Loader Class Initialized
INFO - 2023-03-22 10:10:57 --> Controller Class Initialized
INFO - 2023-03-22 10:10:57 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 10:10:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:57 --> Final output sent to browser
INFO - 2023-03-22 10:10:57 --> Database Driver Class Initialized
DEBUG - 2023-03-22 10:10:57 --> Total execution time: 0.0064
INFO - 2023-03-22 10:10:57 --> Config Class Initialized
INFO - 2023-03-22 10:10:57 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:57 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:57 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:57 --> URI Class Initialized
INFO - 2023-03-22 10:10:57 --> Router Class Initialized
INFO - 2023-03-22 10:10:57 --> Output Class Initialized
INFO - 2023-03-22 10:10:57 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:57 --> Input Class Initialized
INFO - 2023-03-22 10:10:57 --> Language Class Initialized
INFO - 2023-03-22 10:10:57 --> Loader Class Initialized
INFO - 2023-03-22 10:10:57 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:57 --> Database Driver Class Initialized
INFO - 2023-03-22 10:10:57 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:10:57 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:57 --> Total execution time: 0.0186
INFO - 2023-03-22 10:10:57 --> Model "Login_model" initialized
INFO - 2023-03-22 10:10:57 --> Database Driver Class Initialized
INFO - 2023-03-22 10:10:57 --> Config Class Initialized
INFO - 2023-03-22 10:10:57 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:10:57 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:10:57 --> Utf8 Class Initialized
INFO - 2023-03-22 10:10:57 --> URI Class Initialized
INFO - 2023-03-22 10:10:57 --> Router Class Initialized
INFO - 2023-03-22 10:10:57 --> Output Class Initialized
INFO - 2023-03-22 10:10:57 --> Security Class Initialized
DEBUG - 2023-03-22 10:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:10:57 --> Input Class Initialized
INFO - 2023-03-22 10:10:57 --> Language Class Initialized
INFO - 2023-03-22 10:10:57 --> Loader Class Initialized
INFO - 2023-03-22 10:10:57 --> Controller Class Initialized
DEBUG - 2023-03-22 10:10:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:10:57 --> Database Driver Class Initialized
INFO - 2023-03-22 10:10:57 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:10:57 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:10:57 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:57 --> Total execution time: 0.0213
INFO - 2023-03-22 10:10:57 --> Final output sent to browser
DEBUG - 2023-03-22 10:10:57 --> Total execution time: 0.0135
INFO - 2023-03-22 10:11:01 --> Config Class Initialized
INFO - 2023-03-22 10:11:01 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:11:01 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:11:01 --> Utf8 Class Initialized
INFO - 2023-03-22 10:11:01 --> URI Class Initialized
INFO - 2023-03-22 10:11:01 --> Router Class Initialized
INFO - 2023-03-22 10:11:01 --> Output Class Initialized
INFO - 2023-03-22 10:11:01 --> Security Class Initialized
DEBUG - 2023-03-22 10:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:11:01 --> Input Class Initialized
INFO - 2023-03-22 10:11:01 --> Language Class Initialized
INFO - 2023-03-22 10:11:01 --> Loader Class Initialized
INFO - 2023-03-22 10:11:01 --> Controller Class Initialized
DEBUG - 2023-03-22 10:11:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:11:01 --> Database Driver Class Initialized
INFO - 2023-03-22 10:11:01 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:11:01 --> Final output sent to browser
DEBUG - 2023-03-22 10:11:01 --> Total execution time: 0.0174
INFO - 2023-03-22 10:11:01 --> Config Class Initialized
INFO - 2023-03-22 10:11:01 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:11:01 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:11:01 --> Utf8 Class Initialized
INFO - 2023-03-22 10:11:01 --> URI Class Initialized
INFO - 2023-03-22 10:11:01 --> Router Class Initialized
INFO - 2023-03-22 10:11:01 --> Output Class Initialized
INFO - 2023-03-22 10:11:01 --> Security Class Initialized
DEBUG - 2023-03-22 10:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:11:01 --> Input Class Initialized
INFO - 2023-03-22 10:11:01 --> Language Class Initialized
INFO - 2023-03-22 10:11:01 --> Loader Class Initialized
INFO - 2023-03-22 10:11:01 --> Controller Class Initialized
DEBUG - 2023-03-22 10:11:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:11:01 --> Database Driver Class Initialized
INFO - 2023-03-22 10:11:01 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:11:01 --> Final output sent to browser
DEBUG - 2023-03-22 10:11:01 --> Total execution time: 0.0116
INFO - 2023-03-22 10:11:03 --> Config Class Initialized
INFO - 2023-03-22 10:11:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:11:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:11:03 --> Utf8 Class Initialized
INFO - 2023-03-22 10:11:03 --> URI Class Initialized
INFO - 2023-03-22 10:11:03 --> Router Class Initialized
INFO - 2023-03-22 10:11:03 --> Output Class Initialized
INFO - 2023-03-22 10:11:03 --> Security Class Initialized
DEBUG - 2023-03-22 10:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:11:03 --> Input Class Initialized
INFO - 2023-03-22 10:11:03 --> Language Class Initialized
INFO - 2023-03-22 10:11:03 --> Loader Class Initialized
INFO - 2023-03-22 10:11:03 --> Controller Class Initialized
DEBUG - 2023-03-22 10:11:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:11:03 --> Database Driver Class Initialized
INFO - 2023-03-22 10:11:03 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:11:03 --> Final output sent to browser
DEBUG - 2023-03-22 10:11:03 --> Total execution time: 0.0195
INFO - 2023-03-22 10:11:03 --> Config Class Initialized
INFO - 2023-03-22 10:11:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:11:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:11:03 --> Utf8 Class Initialized
INFO - 2023-03-22 10:11:03 --> URI Class Initialized
INFO - 2023-03-22 10:11:03 --> Router Class Initialized
INFO - 2023-03-22 10:11:03 --> Output Class Initialized
INFO - 2023-03-22 10:11:03 --> Security Class Initialized
DEBUG - 2023-03-22 10:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:11:03 --> Input Class Initialized
INFO - 2023-03-22 10:11:03 --> Language Class Initialized
INFO - 2023-03-22 10:11:03 --> Loader Class Initialized
INFO - 2023-03-22 10:11:03 --> Controller Class Initialized
DEBUG - 2023-03-22 10:11:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:11:03 --> Database Driver Class Initialized
INFO - 2023-03-22 10:11:03 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:11:03 --> Final output sent to browser
DEBUG - 2023-03-22 10:11:03 --> Total execution time: 0.0117
INFO - 2023-03-22 10:12:24 --> Config Class Initialized
INFO - 2023-03-22 10:12:24 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:12:24 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:12:24 --> Utf8 Class Initialized
INFO - 2023-03-22 10:12:24 --> URI Class Initialized
INFO - 2023-03-22 10:12:24 --> Router Class Initialized
INFO - 2023-03-22 10:12:24 --> Output Class Initialized
INFO - 2023-03-22 10:12:24 --> Security Class Initialized
DEBUG - 2023-03-22 10:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:12:24 --> Input Class Initialized
INFO - 2023-03-22 10:12:24 --> Language Class Initialized
INFO - 2023-03-22 10:12:24 --> Loader Class Initialized
INFO - 2023-03-22 10:12:24 --> Controller Class Initialized
DEBUG - 2023-03-22 10:12:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:12:24 --> Database Driver Class Initialized
INFO - 2023-03-22 10:12:24 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:12:24 --> Final output sent to browser
DEBUG - 2023-03-22 10:12:24 --> Total execution time: 0.0152
INFO - 2023-03-22 10:12:24 --> Config Class Initialized
INFO - 2023-03-22 10:12:24 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:12:24 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:12:24 --> Utf8 Class Initialized
INFO - 2023-03-22 10:12:24 --> URI Class Initialized
INFO - 2023-03-22 10:12:24 --> Router Class Initialized
INFO - 2023-03-22 10:12:24 --> Output Class Initialized
INFO - 2023-03-22 10:12:24 --> Security Class Initialized
DEBUG - 2023-03-22 10:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:12:24 --> Input Class Initialized
INFO - 2023-03-22 10:12:24 --> Language Class Initialized
INFO - 2023-03-22 10:12:24 --> Loader Class Initialized
INFO - 2023-03-22 10:12:24 --> Controller Class Initialized
DEBUG - 2023-03-22 10:12:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:12:24 --> Database Driver Class Initialized
INFO - 2023-03-22 10:12:24 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:12:24 --> Final output sent to browser
DEBUG - 2023-03-22 10:12:24 --> Total execution time: 0.0118
INFO - 2023-03-22 10:12:26 --> Config Class Initialized
INFO - 2023-03-22 10:12:26 --> Config Class Initialized
INFO - 2023-03-22 10:12:26 --> Hooks Class Initialized
INFO - 2023-03-22 10:12:26 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:12:26 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 10:12:26 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:12:26 --> Utf8 Class Initialized
INFO - 2023-03-22 10:12:26 --> Utf8 Class Initialized
INFO - 2023-03-22 10:12:26 --> URI Class Initialized
INFO - 2023-03-22 10:12:26 --> URI Class Initialized
INFO - 2023-03-22 10:12:26 --> Router Class Initialized
INFO - 2023-03-22 10:12:26 --> Router Class Initialized
INFO - 2023-03-22 10:12:26 --> Output Class Initialized
INFO - 2023-03-22 10:12:26 --> Output Class Initialized
INFO - 2023-03-22 10:12:26 --> Security Class Initialized
INFO - 2023-03-22 10:12:26 --> Security Class Initialized
DEBUG - 2023-03-22 10:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 10:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:12:26 --> Input Class Initialized
INFO - 2023-03-22 10:12:26 --> Input Class Initialized
INFO - 2023-03-22 10:12:26 --> Language Class Initialized
INFO - 2023-03-22 10:12:26 --> Language Class Initialized
INFO - 2023-03-22 10:12:26 --> Loader Class Initialized
INFO - 2023-03-22 10:12:26 --> Loader Class Initialized
INFO - 2023-03-22 10:12:26 --> Controller Class Initialized
INFO - 2023-03-22 10:12:26 --> Controller Class Initialized
DEBUG - 2023-03-22 10:12:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 10:12:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:12:26 --> Final output sent to browser
DEBUG - 2023-03-22 10:12:26 --> Total execution time: 0.0050
INFO - 2023-03-22 10:12:26 --> Database Driver Class Initialized
INFO - 2023-03-22 10:12:26 --> Config Class Initialized
INFO - 2023-03-22 10:12:26 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:12:26 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:12:26 --> Utf8 Class Initialized
INFO - 2023-03-22 10:12:26 --> URI Class Initialized
INFO - 2023-03-22 10:12:26 --> Router Class Initialized
INFO - 2023-03-22 10:12:26 --> Output Class Initialized
INFO - 2023-03-22 10:12:26 --> Security Class Initialized
DEBUG - 2023-03-22 10:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:12:26 --> Input Class Initialized
INFO - 2023-03-22 10:12:26 --> Language Class Initialized
INFO - 2023-03-22 10:12:26 --> Loader Class Initialized
INFO - 2023-03-22 10:12:26 --> Controller Class Initialized
DEBUG - 2023-03-22 10:12:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:12:26 --> Database Driver Class Initialized
INFO - 2023-03-22 10:12:26 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:12:26 --> Model "Login_model" initialized
INFO - 2023-03-22 10:12:26 --> Database Driver Class Initialized
INFO - 2023-03-22 10:12:26 --> Final output sent to browser
DEBUG - 2023-03-22 10:12:26 --> Total execution time: 0.0920
INFO - 2023-03-22 10:12:26 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:12:26 --> Final output sent to browser
DEBUG - 2023-03-22 10:12:26 --> Total execution time: 0.0879
INFO - 2023-03-22 10:12:26 --> Config Class Initialized
INFO - 2023-03-22 10:12:26 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:12:26 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:12:26 --> Utf8 Class Initialized
INFO - 2023-03-22 10:12:26 --> URI Class Initialized
INFO - 2023-03-22 10:12:26 --> Router Class Initialized
INFO - 2023-03-22 10:12:26 --> Output Class Initialized
INFO - 2023-03-22 10:12:26 --> Security Class Initialized
DEBUG - 2023-03-22 10:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:12:26 --> Input Class Initialized
INFO - 2023-03-22 10:12:26 --> Language Class Initialized
INFO - 2023-03-22 10:12:26 --> Loader Class Initialized
INFO - 2023-03-22 10:12:26 --> Controller Class Initialized
DEBUG - 2023-03-22 10:12:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:12:26 --> Database Driver Class Initialized
INFO - 2023-03-22 10:12:26 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:12:26 --> Final output sent to browser
DEBUG - 2023-03-22 10:12:26 --> Total execution time: 0.0612
INFO - 2023-03-22 10:12:28 --> Config Class Initialized
INFO - 2023-03-22 10:12:28 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:12:28 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:12:28 --> Utf8 Class Initialized
INFO - 2023-03-22 10:12:28 --> URI Class Initialized
INFO - 2023-03-22 10:12:28 --> Router Class Initialized
INFO - 2023-03-22 10:12:28 --> Output Class Initialized
INFO - 2023-03-22 10:12:28 --> Security Class Initialized
DEBUG - 2023-03-22 10:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:12:28 --> Input Class Initialized
INFO - 2023-03-22 10:12:28 --> Language Class Initialized
INFO - 2023-03-22 10:12:28 --> Loader Class Initialized
INFO - 2023-03-22 10:12:28 --> Controller Class Initialized
DEBUG - 2023-03-22 10:12:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:12:28 --> Database Driver Class Initialized
INFO - 2023-03-22 10:12:28 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:12:28 --> Final output sent to browser
DEBUG - 2023-03-22 10:12:28 --> Total execution time: 0.0168
INFO - 2023-03-22 10:12:28 --> Config Class Initialized
INFO - 2023-03-22 10:12:28 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:12:28 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:12:28 --> Utf8 Class Initialized
INFO - 2023-03-22 10:12:28 --> URI Class Initialized
INFO - 2023-03-22 10:12:28 --> Router Class Initialized
INFO - 2023-03-22 10:12:28 --> Output Class Initialized
INFO - 2023-03-22 10:12:28 --> Security Class Initialized
DEBUG - 2023-03-22 10:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:12:28 --> Input Class Initialized
INFO - 2023-03-22 10:12:28 --> Language Class Initialized
INFO - 2023-03-22 10:12:28 --> Loader Class Initialized
INFO - 2023-03-22 10:12:28 --> Controller Class Initialized
DEBUG - 2023-03-22 10:12:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:12:28 --> Database Driver Class Initialized
INFO - 2023-03-22 10:12:28 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:12:28 --> Final output sent to browser
DEBUG - 2023-03-22 10:12:28 --> Total execution time: 0.0362
INFO - 2023-03-22 10:12:40 --> Config Class Initialized
INFO - 2023-03-22 10:12:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:12:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:12:40 --> Utf8 Class Initialized
INFO - 2023-03-22 10:12:40 --> URI Class Initialized
INFO - 2023-03-22 10:12:40 --> Router Class Initialized
INFO - 2023-03-22 10:12:40 --> Output Class Initialized
INFO - 2023-03-22 10:12:40 --> Security Class Initialized
DEBUG - 2023-03-22 10:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:12:40 --> Input Class Initialized
INFO - 2023-03-22 10:12:40 --> Language Class Initialized
INFO - 2023-03-22 10:12:40 --> Loader Class Initialized
INFO - 2023-03-22 10:12:40 --> Controller Class Initialized
DEBUG - 2023-03-22 10:12:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:12:40 --> Database Driver Class Initialized
INFO - 2023-03-22 10:12:40 --> Model "Login_model" initialized
INFO - 2023-03-22 10:12:40 --> Database Driver Class Initialized
INFO - 2023-03-22 10:12:40 --> Model "Cluster_model" initialized
ERROR - 2023-03-22 10:12:40 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 10:12:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 10:31:03 --> Config Class Initialized
INFO - 2023-03-22 10:31:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:03 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:03 --> URI Class Initialized
INFO - 2023-03-22 10:31:03 --> Router Class Initialized
INFO - 2023-03-22 10:31:03 --> Output Class Initialized
INFO - 2023-03-22 10:31:03 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:03 --> Input Class Initialized
INFO - 2023-03-22 10:31:03 --> Language Class Initialized
INFO - 2023-03-22 10:31:03 --> Loader Class Initialized
INFO - 2023-03-22 10:31:03 --> Controller Class Initialized
INFO - 2023-03-22 10:31:03 --> Helper loaded: form_helper
INFO - 2023-03-22 10:31:03 --> Helper loaded: url_helper
DEBUG - 2023-03-22 10:31:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:03 --> Model "Change_model" initialized
INFO - 2023-03-22 10:31:03 --> Model "Grafana_model" initialized
INFO - 2023-03-22 10:31:03 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:03 --> Total execution time: 0.0329
INFO - 2023-03-22 10:31:03 --> Config Class Initialized
INFO - 2023-03-22 10:31:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:03 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:03 --> URI Class Initialized
INFO - 2023-03-22 10:31:03 --> Router Class Initialized
INFO - 2023-03-22 10:31:03 --> Output Class Initialized
INFO - 2023-03-22 10:31:03 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:03 --> Input Class Initialized
INFO - 2023-03-22 10:31:03 --> Language Class Initialized
INFO - 2023-03-22 10:31:03 --> Loader Class Initialized
INFO - 2023-03-22 10:31:03 --> Controller Class Initialized
INFO - 2023-03-22 10:31:03 --> Helper loaded: form_helper
INFO - 2023-03-22 10:31:03 --> Helper loaded: url_helper
DEBUG - 2023-03-22 10:31:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:03 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:03 --> Total execution time: 0.0020
INFO - 2023-03-22 10:31:03 --> Config Class Initialized
INFO - 2023-03-22 10:31:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:03 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:03 --> URI Class Initialized
INFO - 2023-03-22 10:31:03 --> Router Class Initialized
INFO - 2023-03-22 10:31:03 --> Output Class Initialized
INFO - 2023-03-22 10:31:03 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:03 --> Input Class Initialized
INFO - 2023-03-22 10:31:03 --> Language Class Initialized
INFO - 2023-03-22 10:31:03 --> Loader Class Initialized
INFO - 2023-03-22 10:31:03 --> Controller Class Initialized
INFO - 2023-03-22 10:31:03 --> Helper loaded: form_helper
INFO - 2023-03-22 10:31:03 --> Helper loaded: url_helper
DEBUG - 2023-03-22 10:31:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:03 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:03 --> Model "Login_model" initialized
INFO - 2023-03-22 10:31:03 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:03 --> Total execution time: 0.0569
INFO - 2023-03-22 10:31:03 --> Config Class Initialized
INFO - 2023-03-22 10:31:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:03 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:03 --> URI Class Initialized
INFO - 2023-03-22 10:31:03 --> Router Class Initialized
INFO - 2023-03-22 10:31:03 --> Output Class Initialized
INFO - 2023-03-22 10:31:03 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:03 --> Input Class Initialized
INFO - 2023-03-22 10:31:03 --> Language Class Initialized
INFO - 2023-03-22 10:31:03 --> Loader Class Initialized
INFO - 2023-03-22 10:31:03 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:03 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:03 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:03 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:03 --> Total execution time: 0.0125
INFO - 2023-03-22 10:31:03 --> Config Class Initialized
INFO - 2023-03-22 10:31:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:03 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:03 --> URI Class Initialized
INFO - 2023-03-22 10:31:03 --> Router Class Initialized
INFO - 2023-03-22 10:31:03 --> Output Class Initialized
INFO - 2023-03-22 10:31:03 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:03 --> Input Class Initialized
INFO - 2023-03-22 10:31:03 --> Language Class Initialized
INFO - 2023-03-22 10:31:03 --> Loader Class Initialized
INFO - 2023-03-22 10:31:03 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:03 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:03 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:03 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:03 --> Total execution time: 0.0121
INFO - 2023-03-22 10:31:03 --> Config Class Initialized
INFO - 2023-03-22 10:31:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:03 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:03 --> URI Class Initialized
INFO - 2023-03-22 10:31:03 --> Router Class Initialized
INFO - 2023-03-22 10:31:03 --> Output Class Initialized
INFO - 2023-03-22 10:31:03 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:03 --> Input Class Initialized
INFO - 2023-03-22 10:31:03 --> Language Class Initialized
INFO - 2023-03-22 10:31:03 --> Loader Class Initialized
INFO - 2023-03-22 10:31:03 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:03 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:03 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:03 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:03 --> Total execution time: 0.0172
INFO - 2023-03-22 10:31:03 --> Config Class Initialized
INFO - 2023-03-22 10:31:03 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:03 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:03 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:03 --> URI Class Initialized
INFO - 2023-03-22 10:31:03 --> Router Class Initialized
INFO - 2023-03-22 10:31:03 --> Output Class Initialized
INFO - 2023-03-22 10:31:03 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:03 --> Input Class Initialized
INFO - 2023-03-22 10:31:03 --> Language Class Initialized
INFO - 2023-03-22 10:31:03 --> Loader Class Initialized
INFO - 2023-03-22 10:31:03 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:03 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:03 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:03 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:03 --> Total execution time: 0.0144
INFO - 2023-03-22 10:31:05 --> Config Class Initialized
INFO - 2023-03-22 10:31:05 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:05 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:05 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:05 --> URI Class Initialized
INFO - 2023-03-22 10:31:05 --> Router Class Initialized
INFO - 2023-03-22 10:31:05 --> Output Class Initialized
INFO - 2023-03-22 10:31:05 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:05 --> Input Class Initialized
INFO - 2023-03-22 10:31:05 --> Language Class Initialized
INFO - 2023-03-22 10:31:05 --> Loader Class Initialized
INFO - 2023-03-22 10:31:05 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:05 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:05 --> Total execution time: 0.0019
INFO - 2023-03-22 10:31:05 --> Config Class Initialized
INFO - 2023-03-22 10:31:05 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:05 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:05 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:05 --> URI Class Initialized
INFO - 2023-03-22 10:31:05 --> Router Class Initialized
INFO - 2023-03-22 10:31:05 --> Output Class Initialized
INFO - 2023-03-22 10:31:05 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:05 --> Input Class Initialized
INFO - 2023-03-22 10:31:05 --> Language Class Initialized
INFO - 2023-03-22 10:31:05 --> Loader Class Initialized
INFO - 2023-03-22 10:31:05 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:05 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:05 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:05 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:05 --> Total execution time: 0.0594
INFO - 2023-03-22 10:31:05 --> Config Class Initialized
INFO - 2023-03-22 10:31:05 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:05 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:05 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:05 --> URI Class Initialized
INFO - 2023-03-22 10:31:05 --> Router Class Initialized
INFO - 2023-03-22 10:31:05 --> Output Class Initialized
INFO - 2023-03-22 10:31:05 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:05 --> Input Class Initialized
INFO - 2023-03-22 10:31:05 --> Language Class Initialized
INFO - 2023-03-22 10:31:05 --> Loader Class Initialized
INFO - 2023-03-22 10:31:05 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:05 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:05 --> Total execution time: 0.0414
INFO - 2023-03-22 10:31:05 --> Config Class Initialized
INFO - 2023-03-22 10:31:05 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:05 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:05 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:05 --> URI Class Initialized
INFO - 2023-03-22 10:31:05 --> Router Class Initialized
INFO - 2023-03-22 10:31:05 --> Output Class Initialized
INFO - 2023-03-22 10:31:05 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:05 --> Input Class Initialized
INFO - 2023-03-22 10:31:05 --> Language Class Initialized
INFO - 2023-03-22 10:31:05 --> Loader Class Initialized
INFO - 2023-03-22 10:31:05 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:05 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:05 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:05 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:05 --> Total execution time: 0.0111
INFO - 2023-03-22 10:31:22 --> Config Class Initialized
INFO - 2023-03-22 10:31:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:22 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:22 --> URI Class Initialized
INFO - 2023-03-22 10:31:22 --> Router Class Initialized
INFO - 2023-03-22 10:31:22 --> Output Class Initialized
INFO - 2023-03-22 10:31:22 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:22 --> Input Class Initialized
INFO - 2023-03-22 10:31:22 --> Language Class Initialized
INFO - 2023-03-22 10:31:22 --> Loader Class Initialized
INFO - 2023-03-22 10:31:22 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:22 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:22 --> Total execution time: 0.0045
INFO - 2023-03-22 10:31:22 --> Config Class Initialized
INFO - 2023-03-22 10:31:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:22 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:22 --> URI Class Initialized
INFO - 2023-03-22 10:31:22 --> Router Class Initialized
INFO - 2023-03-22 10:31:22 --> Output Class Initialized
INFO - 2023-03-22 10:31:22 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:22 --> Input Class Initialized
INFO - 2023-03-22 10:31:22 --> Language Class Initialized
INFO - 2023-03-22 10:31:22 --> Loader Class Initialized
INFO - 2023-03-22 10:31:22 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:22 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:22 --> Model "Login_model" initialized
INFO - 2023-03-22 10:31:22 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:22 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:22 --> Total execution time: 0.0342
INFO - 2023-03-22 10:31:22 --> Config Class Initialized
INFO - 2023-03-22 10:31:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:22 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:22 --> URI Class Initialized
INFO - 2023-03-22 10:31:22 --> Router Class Initialized
INFO - 2023-03-22 10:31:22 --> Output Class Initialized
INFO - 2023-03-22 10:31:22 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:22 --> Input Class Initialized
INFO - 2023-03-22 10:31:22 --> Language Class Initialized
INFO - 2023-03-22 10:31:22 --> Loader Class Initialized
INFO - 2023-03-22 10:31:22 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:22 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:22 --> Total execution time: 0.0042
INFO - 2023-03-22 10:31:22 --> Config Class Initialized
INFO - 2023-03-22 10:31:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:22 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:22 --> URI Class Initialized
INFO - 2023-03-22 10:31:22 --> Router Class Initialized
INFO - 2023-03-22 10:31:22 --> Output Class Initialized
INFO - 2023-03-22 10:31:22 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:22 --> Input Class Initialized
INFO - 2023-03-22 10:31:22 --> Language Class Initialized
INFO - 2023-03-22 10:31:22 --> Loader Class Initialized
INFO - 2023-03-22 10:31:22 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:22 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:22 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:22 --> Total execution time: 0.1859
INFO - 2023-03-22 10:31:27 --> Config Class Initialized
INFO - 2023-03-22 10:31:27 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:27 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:27 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:27 --> URI Class Initialized
INFO - 2023-03-22 10:31:27 --> Router Class Initialized
INFO - 2023-03-22 10:31:27 --> Output Class Initialized
INFO - 2023-03-22 10:31:27 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:27 --> Input Class Initialized
INFO - 2023-03-22 10:31:27 --> Language Class Initialized
INFO - 2023-03-22 10:31:27 --> Loader Class Initialized
INFO - 2023-03-22 10:31:27 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:27 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:27 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:27 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:27 --> Total execution time: 0.0210
INFO - 2023-03-22 10:31:32 --> Config Class Initialized
INFO - 2023-03-22 10:31:32 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:32 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:32 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:32 --> URI Class Initialized
INFO - 2023-03-22 10:31:32 --> Router Class Initialized
INFO - 2023-03-22 10:31:32 --> Output Class Initialized
INFO - 2023-03-22 10:31:32 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:32 --> Input Class Initialized
INFO - 2023-03-22 10:31:32 --> Language Class Initialized
INFO - 2023-03-22 10:31:32 --> Loader Class Initialized
INFO - 2023-03-22 10:31:32 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:32 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:32 --> Total execution time: 0.0424
INFO - 2023-03-22 10:31:32 --> Config Class Initialized
INFO - 2023-03-22 10:31:32 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:32 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:32 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:32 --> URI Class Initialized
INFO - 2023-03-22 10:31:32 --> Router Class Initialized
INFO - 2023-03-22 10:31:32 --> Output Class Initialized
INFO - 2023-03-22 10:31:32 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:32 --> Input Class Initialized
INFO - 2023-03-22 10:31:32 --> Language Class Initialized
INFO - 2023-03-22 10:31:32 --> Loader Class Initialized
INFO - 2023-03-22 10:31:32 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:32 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:32 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:32 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:32 --> Total execution time: 0.0143
INFO - 2023-03-22 10:31:37 --> Config Class Initialized
INFO - 2023-03-22 10:31:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:37 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:37 --> URI Class Initialized
INFO - 2023-03-22 10:31:37 --> Router Class Initialized
INFO - 2023-03-22 10:31:37 --> Output Class Initialized
INFO - 2023-03-22 10:31:37 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:37 --> Input Class Initialized
INFO - 2023-03-22 10:31:37 --> Language Class Initialized
INFO - 2023-03-22 10:31:37 --> Loader Class Initialized
INFO - 2023-03-22 10:31:37 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:37 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:37 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:37 --> Total execution time: 0.0193
INFO - 2023-03-22 10:31:42 --> Config Class Initialized
INFO - 2023-03-22 10:31:42 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:42 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:42 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:42 --> URI Class Initialized
INFO - 2023-03-22 10:31:42 --> Router Class Initialized
INFO - 2023-03-22 10:31:42 --> Output Class Initialized
INFO - 2023-03-22 10:31:42 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:42 --> Input Class Initialized
INFO - 2023-03-22 10:31:42 --> Language Class Initialized
INFO - 2023-03-22 10:31:42 --> Loader Class Initialized
INFO - 2023-03-22 10:31:42 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:42 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:42 --> Total execution time: 0.0044
INFO - 2023-03-22 10:31:42 --> Config Class Initialized
INFO - 2023-03-22 10:31:42 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:42 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:42 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:42 --> URI Class Initialized
INFO - 2023-03-22 10:31:42 --> Router Class Initialized
INFO - 2023-03-22 10:31:42 --> Output Class Initialized
INFO - 2023-03-22 10:31:42 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:42 --> Input Class Initialized
INFO - 2023-03-22 10:31:42 --> Language Class Initialized
INFO - 2023-03-22 10:31:42 --> Loader Class Initialized
INFO - 2023-03-22 10:31:42 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:42 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:42 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:42 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:42 --> Total execution time: 0.0147
INFO - 2023-03-22 10:31:47 --> Config Class Initialized
INFO - 2023-03-22 10:31:47 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:47 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:47 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:47 --> URI Class Initialized
INFO - 2023-03-22 10:31:47 --> Router Class Initialized
INFO - 2023-03-22 10:31:47 --> Output Class Initialized
INFO - 2023-03-22 10:31:47 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:47 --> Input Class Initialized
INFO - 2023-03-22 10:31:47 --> Language Class Initialized
INFO - 2023-03-22 10:31:47 --> Loader Class Initialized
INFO - 2023-03-22 10:31:47 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:47 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:47 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:47 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:47 --> Total execution time: 0.0203
INFO - 2023-03-22 10:31:52 --> Config Class Initialized
INFO - 2023-03-22 10:31:52 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:52 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:52 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:52 --> URI Class Initialized
INFO - 2023-03-22 10:31:52 --> Router Class Initialized
INFO - 2023-03-22 10:31:52 --> Output Class Initialized
INFO - 2023-03-22 10:31:52 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:52 --> Input Class Initialized
INFO - 2023-03-22 10:31:52 --> Language Class Initialized
INFO - 2023-03-22 10:31:52 --> Loader Class Initialized
INFO - 2023-03-22 10:31:52 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:52 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:52 --> Total execution time: 0.0044
INFO - 2023-03-22 10:31:52 --> Config Class Initialized
INFO - 2023-03-22 10:31:52 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:52 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:52 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:52 --> URI Class Initialized
INFO - 2023-03-22 10:31:52 --> Router Class Initialized
INFO - 2023-03-22 10:31:52 --> Output Class Initialized
INFO - 2023-03-22 10:31:52 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:52 --> Input Class Initialized
INFO - 2023-03-22 10:31:52 --> Language Class Initialized
INFO - 2023-03-22 10:31:52 --> Loader Class Initialized
INFO - 2023-03-22 10:31:52 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:52 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:52 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:52 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:52 --> Total execution time: 0.0120
INFO - 2023-03-22 10:31:57 --> Config Class Initialized
INFO - 2023-03-22 10:31:57 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:31:57 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:31:57 --> Utf8 Class Initialized
INFO - 2023-03-22 10:31:57 --> URI Class Initialized
INFO - 2023-03-22 10:31:57 --> Router Class Initialized
INFO - 2023-03-22 10:31:57 --> Output Class Initialized
INFO - 2023-03-22 10:31:57 --> Security Class Initialized
DEBUG - 2023-03-22 10:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:31:57 --> Input Class Initialized
INFO - 2023-03-22 10:31:57 --> Language Class Initialized
INFO - 2023-03-22 10:31:57 --> Loader Class Initialized
INFO - 2023-03-22 10:31:57 --> Controller Class Initialized
DEBUG - 2023-03-22 10:31:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:31:57 --> Database Driver Class Initialized
INFO - 2023-03-22 10:31:57 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:31:57 --> Final output sent to browser
DEBUG - 2023-03-22 10:31:57 --> Total execution time: 0.0205
INFO - 2023-03-22 10:32:02 --> Config Class Initialized
INFO - 2023-03-22 10:32:02 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:02 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:02 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:02 --> URI Class Initialized
INFO - 2023-03-22 10:32:02 --> Router Class Initialized
INFO - 2023-03-22 10:32:02 --> Output Class Initialized
INFO - 2023-03-22 10:32:02 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:02 --> Input Class Initialized
INFO - 2023-03-22 10:32:02 --> Language Class Initialized
INFO - 2023-03-22 10:32:02 --> Loader Class Initialized
INFO - 2023-03-22 10:32:02 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:02 --> Final output sent to browser
DEBUG - 2023-03-22 10:32:02 --> Total execution time: 0.0044
INFO - 2023-03-22 10:32:02 --> Config Class Initialized
INFO - 2023-03-22 10:32:02 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:02 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:02 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:02 --> URI Class Initialized
INFO - 2023-03-22 10:32:02 --> Router Class Initialized
INFO - 2023-03-22 10:32:02 --> Output Class Initialized
INFO - 2023-03-22 10:32:02 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:02 --> Input Class Initialized
INFO - 2023-03-22 10:32:02 --> Language Class Initialized
INFO - 2023-03-22 10:32:02 --> Loader Class Initialized
INFO - 2023-03-22 10:32:02 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:02 --> Database Driver Class Initialized
INFO - 2023-03-22 10:32:02 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:32:02 --> Final output sent to browser
DEBUG - 2023-03-22 10:32:02 --> Total execution time: 0.0168
INFO - 2023-03-22 10:32:07 --> Config Class Initialized
INFO - 2023-03-22 10:32:07 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:07 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:07 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:07 --> URI Class Initialized
INFO - 2023-03-22 10:32:07 --> Router Class Initialized
INFO - 2023-03-22 10:32:07 --> Output Class Initialized
INFO - 2023-03-22 10:32:07 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:07 --> Input Class Initialized
INFO - 2023-03-22 10:32:07 --> Language Class Initialized
INFO - 2023-03-22 10:32:07 --> Loader Class Initialized
INFO - 2023-03-22 10:32:07 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:07 --> Database Driver Class Initialized
INFO - 2023-03-22 10:32:07 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:32:07 --> Final output sent to browser
DEBUG - 2023-03-22 10:32:07 --> Total execution time: 0.0153
INFO - 2023-03-22 10:32:12 --> Config Class Initialized
INFO - 2023-03-22 10:32:12 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:12 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:12 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:12 --> URI Class Initialized
INFO - 2023-03-22 10:32:12 --> Router Class Initialized
INFO - 2023-03-22 10:32:12 --> Output Class Initialized
INFO - 2023-03-22 10:32:12 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:12 --> Input Class Initialized
INFO - 2023-03-22 10:32:12 --> Language Class Initialized
INFO - 2023-03-22 10:32:12 --> Loader Class Initialized
INFO - 2023-03-22 10:32:12 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:12 --> Final output sent to browser
DEBUG - 2023-03-22 10:32:12 --> Total execution time: 0.0041
INFO - 2023-03-22 10:32:12 --> Config Class Initialized
INFO - 2023-03-22 10:32:12 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:12 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:12 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:12 --> URI Class Initialized
INFO - 2023-03-22 10:32:12 --> Router Class Initialized
INFO - 2023-03-22 10:32:12 --> Output Class Initialized
INFO - 2023-03-22 10:32:12 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:12 --> Input Class Initialized
INFO - 2023-03-22 10:32:12 --> Language Class Initialized
INFO - 2023-03-22 10:32:12 --> Loader Class Initialized
INFO - 2023-03-22 10:32:12 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:12 --> Database Driver Class Initialized
INFO - 2023-03-22 10:32:12 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:32:12 --> Final output sent to browser
DEBUG - 2023-03-22 10:32:12 --> Total execution time: 0.0179
INFO - 2023-03-22 10:32:17 --> Config Class Initialized
INFO - 2023-03-22 10:32:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:17 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:17 --> URI Class Initialized
INFO - 2023-03-22 10:32:17 --> Router Class Initialized
INFO - 2023-03-22 10:32:17 --> Output Class Initialized
INFO - 2023-03-22 10:32:17 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:17 --> Input Class Initialized
INFO - 2023-03-22 10:32:17 --> Language Class Initialized
INFO - 2023-03-22 10:32:17 --> Loader Class Initialized
INFO - 2023-03-22 10:32:17 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:17 --> Database Driver Class Initialized
INFO - 2023-03-22 10:32:17 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:32:22 --> Config Class Initialized
INFO - 2023-03-22 10:32:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:22 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:22 --> URI Class Initialized
INFO - 2023-03-22 10:32:22 --> Router Class Initialized
INFO - 2023-03-22 10:32:22 --> Output Class Initialized
INFO - 2023-03-22 10:32:22 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:22 --> Input Class Initialized
INFO - 2023-03-22 10:32:22 --> Language Class Initialized
INFO - 2023-03-22 10:32:22 --> Loader Class Initialized
INFO - 2023-03-22 10:32:22 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:22 --> Final output sent to browser
DEBUG - 2023-03-22 10:32:22 --> Total execution time: 0.0042
INFO - 2023-03-22 10:32:22 --> Config Class Initialized
INFO - 2023-03-22 10:32:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:22 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:22 --> URI Class Initialized
INFO - 2023-03-22 10:32:22 --> Router Class Initialized
INFO - 2023-03-22 10:32:22 --> Output Class Initialized
INFO - 2023-03-22 10:32:22 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:22 --> Input Class Initialized
INFO - 2023-03-22 10:32:22 --> Language Class Initialized
INFO - 2023-03-22 10:32:22 --> Loader Class Initialized
INFO - 2023-03-22 10:32:22 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:22 --> Database Driver Class Initialized
INFO - 2023-03-22 10:32:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:32:27 --> Config Class Initialized
INFO - 2023-03-22 10:32:27 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:27 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:27 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:27 --> URI Class Initialized
INFO - 2023-03-22 10:32:27 --> Router Class Initialized
INFO - 2023-03-22 10:32:27 --> Output Class Initialized
INFO - 2023-03-22 10:32:27 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:27 --> Input Class Initialized
INFO - 2023-03-22 10:32:27 --> Language Class Initialized
INFO - 2023-03-22 10:32:27 --> Loader Class Initialized
INFO - 2023-03-22 10:32:27 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:27 --> Database Driver Class Initialized
INFO - 2023-03-22 10:32:27 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:32:32 --> Config Class Initialized
INFO - 2023-03-22 10:32:32 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:32 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:32 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:32 --> URI Class Initialized
INFO - 2023-03-22 10:32:32 --> Router Class Initialized
INFO - 2023-03-22 10:32:32 --> Output Class Initialized
INFO - 2023-03-22 10:32:32 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:32 --> Input Class Initialized
INFO - 2023-03-22 10:32:32 --> Language Class Initialized
INFO - 2023-03-22 10:32:32 --> Loader Class Initialized
INFO - 2023-03-22 10:32:32 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:32 --> Final output sent to browser
DEBUG - 2023-03-22 10:32:32 --> Total execution time: 0.0077
INFO - 2023-03-22 10:32:32 --> Config Class Initialized
INFO - 2023-03-22 10:32:32 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:32 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:32 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:32 --> URI Class Initialized
INFO - 2023-03-22 10:32:32 --> Router Class Initialized
INFO - 2023-03-22 10:32:32 --> Output Class Initialized
INFO - 2023-03-22 10:32:32 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:32 --> Input Class Initialized
INFO - 2023-03-22 10:32:32 --> Language Class Initialized
INFO - 2023-03-22 10:32:32 --> Loader Class Initialized
INFO - 2023-03-22 10:32:32 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:32 --> Database Driver Class Initialized
INFO - 2023-03-22 10:32:37 --> Config Class Initialized
INFO - 2023-03-22 10:32:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:37 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:37 --> URI Class Initialized
INFO - 2023-03-22 10:32:37 --> Router Class Initialized
INFO - 2023-03-22 10:32:37 --> Output Class Initialized
INFO - 2023-03-22 10:32:37 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:37 --> Input Class Initialized
INFO - 2023-03-22 10:32:37 --> Language Class Initialized
INFO - 2023-03-22 10:32:37 --> Loader Class Initialized
INFO - 2023-03-22 10:32:37 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:37 --> Database Driver Class Initialized
ERROR - 2023-03-22 10:32:42 --> Unable to connect to the database
INFO - 2023-03-22 10:32:42 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 10:32:42 --> Config Class Initialized
INFO - 2023-03-22 10:32:42 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:42 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:42 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:42 --> URI Class Initialized
INFO - 2023-03-22 10:32:42 --> Router Class Initialized
INFO - 2023-03-22 10:32:42 --> Output Class Initialized
INFO - 2023-03-22 10:32:42 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:42 --> Input Class Initialized
INFO - 2023-03-22 10:32:42 --> Language Class Initialized
INFO - 2023-03-22 10:32:42 --> Loader Class Initialized
INFO - 2023-03-22 10:32:42 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:42 --> Final output sent to browser
DEBUG - 2023-03-22 10:32:42 --> Total execution time: 0.0030
INFO - 2023-03-22 10:32:42 --> Config Class Initialized
INFO - 2023-03-22 10:32:42 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:32:42 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:32:42 --> Utf8 Class Initialized
INFO - 2023-03-22 10:32:42 --> URI Class Initialized
INFO - 2023-03-22 10:32:42 --> Router Class Initialized
INFO - 2023-03-22 10:32:42 --> Output Class Initialized
INFO - 2023-03-22 10:32:42 --> Security Class Initialized
DEBUG - 2023-03-22 10:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:32:42 --> Input Class Initialized
INFO - 2023-03-22 10:32:42 --> Language Class Initialized
INFO - 2023-03-22 10:32:42 --> Loader Class Initialized
INFO - 2023-03-22 10:32:42 --> Controller Class Initialized
DEBUG - 2023-03-22 10:32:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:32:42 --> Database Driver Class Initialized
ERROR - 2023-03-22 10:34:18 --> Query error: MySQL server has gone away - Invalid query: select hostaddr,port from cluster_mgr_nodes 
ERROR - 2023-03-22 10:34:18 --> Query error: MySQL server has gone away - Invalid query: select hostaddr,port from cluster_mgr_nodes 
ERROR - 2023-03-22 10:34:18 --> Query error: MySQL server has gone away - Invalid query: select hostaddr,port from cluster_mgr_nodes 
INFO - 2023-03-22 10:34:18 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 10:34:18 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 10:34:18 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 10:34:18 --> Config Class Initialized
INFO - 2023-03-22 10:34:18 --> Config Class Initialized
INFO - 2023-03-22 10:34:18 --> Hooks Class Initialized
INFO - 2023-03-22 10:34:18 --> Config Class Initialized
INFO - 2023-03-22 10:34:18 --> Hooks Class Initialized
INFO - 2023-03-22 10:34:18 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:34:18 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 10:34:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:34:18 --> Utf8 Class Initialized
INFO - 2023-03-22 10:34:18 --> Utf8 Class Initialized
DEBUG - 2023-03-22 10:34:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:34:18 --> URI Class Initialized
INFO - 2023-03-22 10:34:18 --> Utf8 Class Initialized
INFO - 2023-03-22 10:34:18 --> URI Class Initialized
INFO - 2023-03-22 10:34:18 --> URI Class Initialized
INFO - 2023-03-22 10:34:18 --> Router Class Initialized
INFO - 2023-03-22 10:34:18 --> Router Class Initialized
INFO - 2023-03-22 10:34:18 --> Router Class Initialized
INFO - 2023-03-22 10:34:18 --> Output Class Initialized
INFO - 2023-03-22 10:34:18 --> Output Class Initialized
INFO - 2023-03-22 10:34:18 --> Output Class Initialized
INFO - 2023-03-22 10:34:18 --> Security Class Initialized
INFO - 2023-03-22 10:34:18 --> Security Class Initialized
INFO - 2023-03-22 10:34:18 --> Security Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 10:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 10:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:34:18 --> Input Class Initialized
INFO - 2023-03-22 10:34:18 --> Input Class Initialized
INFO - 2023-03-22 10:34:18 --> Input Class Initialized
INFO - 2023-03-22 10:34:18 --> Language Class Initialized
INFO - 2023-03-22 10:34:18 --> Language Class Initialized
INFO - 2023-03-22 10:34:18 --> Language Class Initialized
INFO - 2023-03-22 10:34:18 --> Loader Class Initialized
INFO - 2023-03-22 10:34:18 --> Loader Class Initialized
INFO - 2023-03-22 10:34:18 --> Loader Class Initialized
INFO - 2023-03-22 10:34:18 --> Controller Class Initialized
INFO - 2023-03-22 10:34:18 --> Controller Class Initialized
INFO - 2023-03-22 10:34:18 --> Controller Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 10:34:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 10:34:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:34:18 --> Final output sent to browser
INFO - 2023-03-22 10:34:18 --> Final output sent to browser
DEBUG - 2023-03-22 10:34:18 --> Total execution time: 0.0068
DEBUG - 2023-03-22 10:34:18 --> Total execution time: 0.0069
INFO - 2023-03-22 10:34:18 --> Database Driver Class Initialized
INFO - 2023-03-22 10:34:18 --> Config Class Initialized
INFO - 2023-03-22 10:34:18 --> Hooks Class Initialized
INFO - 2023-03-22 10:34:18 --> Config Class Initialized
DEBUG - 2023-03-22 10:34:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:34:18 --> Hooks Class Initialized
INFO - 2023-03-22 10:34:18 --> Utf8 Class Initialized
DEBUG - 2023-03-22 10:34:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:34:18 --> URI Class Initialized
INFO - 2023-03-22 10:34:18 --> Utf8 Class Initialized
INFO - 2023-03-22 10:34:18 --> Router Class Initialized
INFO - 2023-03-22 10:34:18 --> URI Class Initialized
INFO - 2023-03-22 10:34:18 --> Output Class Initialized
INFO - 2023-03-22 10:34:18 --> Security Class Initialized
INFO - 2023-03-22 10:34:18 --> Router Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:34:18 --> Output Class Initialized
INFO - 2023-03-22 10:34:18 --> Input Class Initialized
INFO - 2023-03-22 10:34:18 --> Security Class Initialized
INFO - 2023-03-22 10:34:18 --> Language Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:34:18 --> Input Class Initialized
INFO - 2023-03-22 10:34:18 --> Loader Class Initialized
INFO - 2023-03-22 10:34:18 --> Language Class Initialized
INFO - 2023-03-22 10:34:18 --> Controller Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:34:18 --> Loader Class Initialized
INFO - 2023-03-22 10:34:18 --> Final output sent to browser
INFO - 2023-03-22 10:34:18 --> Controller Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Total execution time: 0.0033
DEBUG - 2023-03-22 10:34:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:34:18 --> Final output sent to browser
DEBUG - 2023-03-22 10:34:18 --> Total execution time: 0.0034
INFO - 2023-03-22 10:34:18 --> Config Class Initialized
INFO - 2023-03-22 10:34:18 --> Hooks Class Initialized
INFO - 2023-03-22 10:34:18 --> Config Class Initialized
DEBUG - 2023-03-22 10:34:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:34:18 --> Hooks Class Initialized
INFO - 2023-03-22 10:34:18 --> Utf8 Class Initialized
DEBUG - 2023-03-22 10:34:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:34:18 --> URI Class Initialized
INFO - 2023-03-22 10:34:18 --> Utf8 Class Initialized
INFO - 2023-03-22 10:34:18 --> Router Class Initialized
INFO - 2023-03-22 10:34:18 --> URI Class Initialized
INFO - 2023-03-22 10:34:18 --> Output Class Initialized
INFO - 2023-03-22 10:34:18 --> Router Class Initialized
INFO - 2023-03-22 10:34:18 --> Security Class Initialized
INFO - 2023-03-22 10:34:18 --> Output Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:34:18 --> Security Class Initialized
INFO - 2023-03-22 10:34:18 --> Input Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:34:18 --> Language Class Initialized
INFO - 2023-03-22 10:34:18 --> Input Class Initialized
INFO - 2023-03-22 10:34:18 --> Loader Class Initialized
INFO - 2023-03-22 10:34:18 --> Language Class Initialized
INFO - 2023-03-22 10:34:18 --> Controller Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:34:18 --> Loader Class Initialized
INFO - 2023-03-22 10:34:18 --> Final output sent to browser
INFO - 2023-03-22 10:34:18 --> Controller Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Total execution time: 0.0040
DEBUG - 2023-03-22 10:34:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:34:18 --> Final output sent to browser
DEBUG - 2023-03-22 10:34:18 --> Total execution time: 0.0030
INFO - 2023-03-22 10:34:18 --> Config Class Initialized
INFO - 2023-03-22 10:34:18 --> Hooks Class Initialized
INFO - 2023-03-22 10:34:18 --> Config Class Initialized
DEBUG - 2023-03-22 10:34:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:34:18 --> Hooks Class Initialized
INFO - 2023-03-22 10:34:18 --> Utf8 Class Initialized
DEBUG - 2023-03-22 10:34:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:34:18 --> URI Class Initialized
INFO - 2023-03-22 10:34:18 --> Utf8 Class Initialized
INFO - 2023-03-22 10:34:18 --> Router Class Initialized
INFO - 2023-03-22 10:34:18 --> URI Class Initialized
INFO - 2023-03-22 10:34:18 --> Output Class Initialized
INFO - 2023-03-22 10:34:18 --> Security Class Initialized
INFO - 2023-03-22 10:34:18 --> Router Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:34:18 --> Output Class Initialized
INFO - 2023-03-22 10:34:18 --> Input Class Initialized
INFO - 2023-03-22 10:34:18 --> Security Class Initialized
INFO - 2023-03-22 10:34:18 --> Language Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:34:18 --> Input Class Initialized
INFO - 2023-03-22 10:34:18 --> Loader Class Initialized
INFO - 2023-03-22 10:34:18 --> Language Class Initialized
INFO - 2023-03-22 10:34:18 --> Controller Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:34:18 --> Loader Class Initialized
INFO - 2023-03-22 10:34:18 --> Controller Class Initialized
INFO - 2023-03-22 10:34:18 --> Database Driver Class Initialized
DEBUG - 2023-03-22 10:34:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:34:18 --> Database Driver Class Initialized
ERROR - 2023-03-22 10:34:19 --> Unable to connect to the database
ERROR - 2023-03-22 10:34:19 --> Unable to connect to the database
ERROR - 2023-03-22 10:34:19 --> Unable to connect to the database
INFO - 2023-03-22 10:34:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-22 10:34:19 --> Unable to connect to the database
ERROR - 2023-03-22 10:34:19 --> Unable to connect to the database
INFO - 2023-03-22 10:34:19 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 10:34:19 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 10:34:19 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 10:34:19 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 10:37:41 --> Config Class Initialized
INFO - 2023-03-22 10:37:41 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:37:41 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:37:41 --> Utf8 Class Initialized
INFO - 2023-03-22 10:37:41 --> URI Class Initialized
INFO - 2023-03-22 10:37:41 --> Router Class Initialized
INFO - 2023-03-22 10:37:41 --> Output Class Initialized
INFO - 2023-03-22 10:37:41 --> Security Class Initialized
DEBUG - 2023-03-22 10:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:37:41 --> Input Class Initialized
INFO - 2023-03-22 10:37:41 --> Language Class Initialized
INFO - 2023-03-22 10:37:41 --> Loader Class Initialized
INFO - 2023-03-22 10:37:41 --> Controller Class Initialized
DEBUG - 2023-03-22 10:37:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:37:41 --> Database Driver Class Initialized
INFO - 2023-03-22 10:37:41 --> Model "Login_model" initialized
INFO - 2023-03-22 10:37:41 --> Database Driver Class Initialized
INFO - 2023-03-22 10:37:41 --> Model "Cluster_model" initialized
ERROR - 2023-03-22 10:37:41 --> Query error: Table 'kunlun_metadata_db.cluster_alarm_info' doesn't exist - Invalid query: select job_id from cluster_alarm_info where job_id='2' 
INFO - 2023-03-22 10:37:41 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-22 10:51:09 --> Config Class Initialized
INFO - 2023-03-22 10:51:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:51:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:51:09 --> Utf8 Class Initialized
INFO - 2023-03-22 10:51:09 --> URI Class Initialized
INFO - 2023-03-22 10:51:09 --> Router Class Initialized
INFO - 2023-03-22 10:51:09 --> Output Class Initialized
INFO - 2023-03-22 10:51:09 --> Security Class Initialized
DEBUG - 2023-03-22 10:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:51:09 --> Input Class Initialized
INFO - 2023-03-22 10:51:09 --> Language Class Initialized
INFO - 2023-03-22 10:51:09 --> Loader Class Initialized
INFO - 2023-03-22 10:51:09 --> Controller Class Initialized
DEBUG - 2023-03-22 10:51:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:51:09 --> Database Driver Class Initialized
INFO - 2023-03-22 10:51:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:51:09 --> Final output sent to browser
DEBUG - 2023-03-22 10:51:09 --> Total execution time: 0.0779
INFO - 2023-03-22 10:51:09 --> Config Class Initialized
INFO - 2023-03-22 10:51:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:51:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:51:09 --> Utf8 Class Initialized
INFO - 2023-03-22 10:51:09 --> URI Class Initialized
INFO - 2023-03-22 10:51:09 --> Router Class Initialized
INFO - 2023-03-22 10:51:09 --> Output Class Initialized
INFO - 2023-03-22 10:51:09 --> Security Class Initialized
DEBUG - 2023-03-22 10:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:51:09 --> Input Class Initialized
INFO - 2023-03-22 10:51:09 --> Language Class Initialized
INFO - 2023-03-22 10:51:09 --> Loader Class Initialized
INFO - 2023-03-22 10:51:09 --> Controller Class Initialized
DEBUG - 2023-03-22 10:51:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:51:09 --> Database Driver Class Initialized
INFO - 2023-03-22 10:51:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:51:09 --> Final output sent to browser
DEBUG - 2023-03-22 10:51:09 --> Total execution time: 0.0534
INFO - 2023-03-22 10:55:18 --> Config Class Initialized
INFO - 2023-03-22 10:55:18 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:18 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:18 --> URI Class Initialized
INFO - 2023-03-22 10:55:18 --> Router Class Initialized
INFO - 2023-03-22 10:55:18 --> Output Class Initialized
INFO - 2023-03-22 10:55:18 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:18 --> Input Class Initialized
INFO - 2023-03-22 10:55:18 --> Language Class Initialized
INFO - 2023-03-22 10:55:18 --> Loader Class Initialized
INFO - 2023-03-22 10:55:18 --> Controller Class Initialized
INFO - 2023-03-22 10:55:18 --> Helper loaded: form_helper
INFO - 2023-03-22 10:55:18 --> Helper loaded: url_helper
DEBUG - 2023-03-22 10:55:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:18 --> Model "Change_model" initialized
INFO - 2023-03-22 10:55:18 --> Model "Grafana_model" initialized
INFO - 2023-03-22 10:55:19 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:19 --> Total execution time: 0.0611
INFO - 2023-03-22 10:55:19 --> Config Class Initialized
INFO - 2023-03-22 10:55:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:19 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:19 --> URI Class Initialized
INFO - 2023-03-22 10:55:19 --> Router Class Initialized
INFO - 2023-03-22 10:55:19 --> Output Class Initialized
INFO - 2023-03-22 10:55:19 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:19 --> Input Class Initialized
INFO - 2023-03-22 10:55:19 --> Language Class Initialized
INFO - 2023-03-22 10:55:19 --> Loader Class Initialized
INFO - 2023-03-22 10:55:19 --> Controller Class Initialized
INFO - 2023-03-22 10:55:19 --> Helper loaded: form_helper
INFO - 2023-03-22 10:55:19 --> Helper loaded: url_helper
DEBUG - 2023-03-22 10:55:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:19 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:19 --> Total execution time: 0.0022
INFO - 2023-03-22 10:55:19 --> Config Class Initialized
INFO - 2023-03-22 10:55:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:19 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:19 --> URI Class Initialized
INFO - 2023-03-22 10:55:19 --> Router Class Initialized
INFO - 2023-03-22 10:55:19 --> Output Class Initialized
INFO - 2023-03-22 10:55:19 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:19 --> Input Class Initialized
INFO - 2023-03-22 10:55:19 --> Language Class Initialized
INFO - 2023-03-22 10:55:19 --> Loader Class Initialized
INFO - 2023-03-22 10:55:19 --> Controller Class Initialized
INFO - 2023-03-22 10:55:19 --> Helper loaded: form_helper
INFO - 2023-03-22 10:55:19 --> Helper loaded: url_helper
DEBUG - 2023-03-22 10:55:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:19 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:19 --> Model "Login_model" initialized
INFO - 2023-03-22 10:55:19 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:19 --> Total execution time: 0.0581
INFO - 2023-03-22 10:55:19 --> Config Class Initialized
INFO - 2023-03-22 10:55:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:19 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:19 --> URI Class Initialized
INFO - 2023-03-22 10:55:19 --> Router Class Initialized
INFO - 2023-03-22 10:55:19 --> Output Class Initialized
INFO - 2023-03-22 10:55:19 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:19 --> Input Class Initialized
INFO - 2023-03-22 10:55:19 --> Language Class Initialized
INFO - 2023-03-22 10:55:19 --> Loader Class Initialized
INFO - 2023-03-22 10:55:19 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:19 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:19 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:55:19 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:19 --> Total execution time: 0.0120
INFO - 2023-03-22 10:55:19 --> Config Class Initialized
INFO - 2023-03-22 10:55:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:19 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:19 --> URI Class Initialized
INFO - 2023-03-22 10:55:19 --> Router Class Initialized
INFO - 2023-03-22 10:55:19 --> Output Class Initialized
INFO - 2023-03-22 10:55:19 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:19 --> Input Class Initialized
INFO - 2023-03-22 10:55:19 --> Language Class Initialized
INFO - 2023-03-22 10:55:19 --> Loader Class Initialized
INFO - 2023-03-22 10:55:19 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:19 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:19 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:55:19 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:19 --> Total execution time: 0.0118
INFO - 2023-03-22 10:55:19 --> Config Class Initialized
INFO - 2023-03-22 10:55:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:19 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:19 --> URI Class Initialized
INFO - 2023-03-22 10:55:19 --> Router Class Initialized
INFO - 2023-03-22 10:55:19 --> Output Class Initialized
INFO - 2023-03-22 10:55:19 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:19 --> Input Class Initialized
INFO - 2023-03-22 10:55:19 --> Language Class Initialized
INFO - 2023-03-22 10:55:19 --> Loader Class Initialized
INFO - 2023-03-22 10:55:19 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:19 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:19 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:55:19 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:19 --> Total execution time: 0.0144
INFO - 2023-03-22 10:55:19 --> Config Class Initialized
INFO - 2023-03-22 10:55:19 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:19 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:19 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:19 --> URI Class Initialized
INFO - 2023-03-22 10:55:19 --> Router Class Initialized
INFO - 2023-03-22 10:55:19 --> Output Class Initialized
INFO - 2023-03-22 10:55:19 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:19 --> Input Class Initialized
INFO - 2023-03-22 10:55:19 --> Language Class Initialized
INFO - 2023-03-22 10:55:19 --> Loader Class Initialized
INFO - 2023-03-22 10:55:19 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:19 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:19 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:55:19 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:19 --> Total execution time: 0.0575
INFO - 2023-03-22 10:55:22 --> Config Class Initialized
INFO - 2023-03-22 10:55:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:22 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:22 --> URI Class Initialized
INFO - 2023-03-22 10:55:22 --> Router Class Initialized
INFO - 2023-03-22 10:55:22 --> Output Class Initialized
INFO - 2023-03-22 10:55:22 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:22 --> Input Class Initialized
INFO - 2023-03-22 10:55:22 --> Language Class Initialized
INFO - 2023-03-22 10:55:22 --> Loader Class Initialized
INFO - 2023-03-22 10:55:22 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:22 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:55:22 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:22 --> Total execution time: 0.0138
INFO - 2023-03-22 10:55:22 --> Config Class Initialized
INFO - 2023-03-22 10:55:22 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:22 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:22 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:22 --> URI Class Initialized
INFO - 2023-03-22 10:55:22 --> Router Class Initialized
INFO - 2023-03-22 10:55:22 --> Output Class Initialized
INFO - 2023-03-22 10:55:22 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:22 --> Input Class Initialized
INFO - 2023-03-22 10:55:22 --> Language Class Initialized
INFO - 2023-03-22 10:55:22 --> Loader Class Initialized
INFO - 2023-03-22 10:55:22 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:22 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:22 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:55:22 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:22 --> Total execution time: 0.0549
INFO - 2023-03-22 10:55:24 --> Config Class Initialized
INFO - 2023-03-22 10:55:24 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:24 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:24 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:24 --> URI Class Initialized
INFO - 2023-03-22 10:55:24 --> Router Class Initialized
INFO - 2023-03-22 10:55:24 --> Output Class Initialized
INFO - 2023-03-22 10:55:24 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:24 --> Input Class Initialized
INFO - 2023-03-22 10:55:24 --> Language Class Initialized
INFO - 2023-03-22 10:55:24 --> Loader Class Initialized
INFO - 2023-03-22 10:55:24 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:24 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:24 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:55:24 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:24 --> Total execution time: 0.0210
INFO - 2023-03-22 10:55:24 --> Config Class Initialized
INFO - 2023-03-22 10:55:24 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:24 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:24 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:24 --> URI Class Initialized
INFO - 2023-03-22 10:55:24 --> Router Class Initialized
INFO - 2023-03-22 10:55:24 --> Output Class Initialized
INFO - 2023-03-22 10:55:24 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:24 --> Input Class Initialized
INFO - 2023-03-22 10:55:24 --> Language Class Initialized
INFO - 2023-03-22 10:55:24 --> Loader Class Initialized
INFO - 2023-03-22 10:55:24 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:24 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:24 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:55:24 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:24 --> Total execution time: 0.0132
INFO - 2023-03-22 10:55:26 --> Config Class Initialized
INFO - 2023-03-22 10:55:26 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:26 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:26 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:26 --> URI Class Initialized
INFO - 2023-03-22 10:55:26 --> Router Class Initialized
INFO - 2023-03-22 10:55:26 --> Output Class Initialized
INFO - 2023-03-22 10:55:26 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:26 --> Input Class Initialized
INFO - 2023-03-22 10:55:26 --> Language Class Initialized
INFO - 2023-03-22 10:55:26 --> Loader Class Initialized
INFO - 2023-03-22 10:55:26 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:26 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:26 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:55:26 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:26 --> Total execution time: 0.0191
INFO - 2023-03-22 10:55:26 --> Config Class Initialized
INFO - 2023-03-22 10:55:26 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:26 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:26 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:26 --> URI Class Initialized
INFO - 2023-03-22 10:55:26 --> Router Class Initialized
INFO - 2023-03-22 10:55:26 --> Output Class Initialized
INFO - 2023-03-22 10:55:26 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:26 --> Input Class Initialized
INFO - 2023-03-22 10:55:26 --> Language Class Initialized
INFO - 2023-03-22 10:55:26 --> Loader Class Initialized
INFO - 2023-03-22 10:55:26 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:26 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:26 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:55:26 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:26 --> Total execution time: 0.0566
INFO - 2023-03-22 10:55:37 --> Config Class Initialized
INFO - 2023-03-22 10:55:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:37 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:37 --> URI Class Initialized
INFO - 2023-03-22 10:55:37 --> Router Class Initialized
INFO - 2023-03-22 10:55:37 --> Output Class Initialized
INFO - 2023-03-22 10:55:37 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:37 --> Input Class Initialized
INFO - 2023-03-22 10:55:37 --> Language Class Initialized
INFO - 2023-03-22 10:55:37 --> Loader Class Initialized
INFO - 2023-03-22 10:55:37 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:37 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:37 --> Total execution time: 0.0429
INFO - 2023-03-22 10:55:37 --> Config Class Initialized
INFO - 2023-03-22 10:55:37 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:37 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:37 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:37 --> URI Class Initialized
INFO - 2023-03-22 10:55:37 --> Router Class Initialized
INFO - 2023-03-22 10:55:37 --> Output Class Initialized
INFO - 2023-03-22 10:55:37 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:37 --> Input Class Initialized
INFO - 2023-03-22 10:55:37 --> Language Class Initialized
INFO - 2023-03-22 10:55:37 --> Loader Class Initialized
INFO - 2023-03-22 10:55:37 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:37 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:37 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:55:37 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:37 --> Total execution time: 0.0568
INFO - 2023-03-22 10:55:40 --> Config Class Initialized
INFO - 2023-03-22 10:55:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:40 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:40 --> URI Class Initialized
INFO - 2023-03-22 10:55:40 --> Router Class Initialized
INFO - 2023-03-22 10:55:40 --> Output Class Initialized
INFO - 2023-03-22 10:55:40 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:40 --> Input Class Initialized
INFO - 2023-03-22 10:55:40 --> Language Class Initialized
INFO - 2023-03-22 10:55:40 --> Loader Class Initialized
INFO - 2023-03-22 10:55:40 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:40 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:55:40 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:40 --> Total execution time: 0.0395
INFO - 2023-03-22 10:55:40 --> Config Class Initialized
INFO - 2023-03-22 10:55:40 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:55:40 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:55:40 --> Utf8 Class Initialized
INFO - 2023-03-22 10:55:40 --> URI Class Initialized
INFO - 2023-03-22 10:55:40 --> Router Class Initialized
INFO - 2023-03-22 10:55:40 --> Output Class Initialized
INFO - 2023-03-22 10:55:40 --> Security Class Initialized
DEBUG - 2023-03-22 10:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:55:40 --> Input Class Initialized
INFO - 2023-03-22 10:55:40 --> Language Class Initialized
INFO - 2023-03-22 10:55:40 --> Loader Class Initialized
INFO - 2023-03-22 10:55:40 --> Controller Class Initialized
DEBUG - 2023-03-22 10:55:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:55:40 --> Database Driver Class Initialized
INFO - 2023-03-22 10:55:40 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:55:40 --> Final output sent to browser
DEBUG - 2023-03-22 10:55:40 --> Total execution time: 0.0766
INFO - 2023-03-22 10:56:09 --> Config Class Initialized
INFO - 2023-03-22 10:56:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:09 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:09 --> URI Class Initialized
INFO - 2023-03-22 10:56:09 --> Router Class Initialized
INFO - 2023-03-22 10:56:09 --> Output Class Initialized
INFO - 2023-03-22 10:56:09 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:09 --> Input Class Initialized
INFO - 2023-03-22 10:56:09 --> Language Class Initialized
INFO - 2023-03-22 10:56:09 --> Loader Class Initialized
INFO - 2023-03-22 10:56:09 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:09 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:56:09 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:09 --> Total execution time: 0.0195
INFO - 2023-03-22 10:56:09 --> Config Class Initialized
INFO - 2023-03-22 10:56:09 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:09 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:09 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:09 --> URI Class Initialized
INFO - 2023-03-22 10:56:09 --> Router Class Initialized
INFO - 2023-03-22 10:56:09 --> Output Class Initialized
INFO - 2023-03-22 10:56:09 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:09 --> Input Class Initialized
INFO - 2023-03-22 10:56:09 --> Language Class Initialized
INFO - 2023-03-22 10:56:09 --> Loader Class Initialized
INFO - 2023-03-22 10:56:09 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:09 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:09 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:56:09 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:09 --> Total execution time: 0.0589
INFO - 2023-03-22 10:56:13 --> Config Class Initialized
INFO - 2023-03-22 10:56:13 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:13 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:13 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:13 --> URI Class Initialized
INFO - 2023-03-22 10:56:13 --> Router Class Initialized
INFO - 2023-03-22 10:56:13 --> Output Class Initialized
INFO - 2023-03-22 10:56:13 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:13 --> Input Class Initialized
INFO - 2023-03-22 10:56:13 --> Language Class Initialized
INFO - 2023-03-22 10:56:13 --> Loader Class Initialized
INFO - 2023-03-22 10:56:13 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:13 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:13 --> Total execution time: 0.0034
INFO - 2023-03-22 10:56:13 --> Config Class Initialized
INFO - 2023-03-22 10:56:13 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:13 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:13 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:13 --> URI Class Initialized
INFO - 2023-03-22 10:56:13 --> Router Class Initialized
INFO - 2023-03-22 10:56:13 --> Output Class Initialized
INFO - 2023-03-22 10:56:13 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:13 --> Input Class Initialized
INFO - 2023-03-22 10:56:13 --> Language Class Initialized
INFO - 2023-03-22 10:56:13 --> Loader Class Initialized
INFO - 2023-03-22 10:56:13 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:13 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:13 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:56:13 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:13 --> Total execution time: 0.0100
INFO - 2023-03-22 10:56:16 --> Config Class Initialized
INFO - 2023-03-22 10:56:16 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:16 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:16 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:16 --> URI Class Initialized
INFO - 2023-03-22 10:56:16 --> Router Class Initialized
INFO - 2023-03-22 10:56:16 --> Output Class Initialized
INFO - 2023-03-22 10:56:16 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:16 --> Input Class Initialized
INFO - 2023-03-22 10:56:16 --> Language Class Initialized
INFO - 2023-03-22 10:56:16 --> Loader Class Initialized
INFO - 2023-03-22 10:56:16 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:16 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:16 --> Total execution time: 0.0022
INFO - 2023-03-22 10:56:16 --> Config Class Initialized
INFO - 2023-03-22 10:56:16 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:16 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:16 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:16 --> URI Class Initialized
INFO - 2023-03-22 10:56:16 --> Router Class Initialized
INFO - 2023-03-22 10:56:16 --> Output Class Initialized
INFO - 2023-03-22 10:56:16 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:16 --> Input Class Initialized
INFO - 2023-03-22 10:56:16 --> Language Class Initialized
INFO - 2023-03-22 10:56:16 --> Loader Class Initialized
INFO - 2023-03-22 10:56:16 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:16 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:16 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:56:16 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:16 --> Total execution time: 0.0142
INFO - 2023-03-22 10:56:18 --> Config Class Initialized
INFO - 2023-03-22 10:56:18 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:18 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:18 --> URI Class Initialized
INFO - 2023-03-22 10:56:18 --> Router Class Initialized
INFO - 2023-03-22 10:56:18 --> Output Class Initialized
INFO - 2023-03-22 10:56:18 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:18 --> Input Class Initialized
INFO - 2023-03-22 10:56:18 --> Language Class Initialized
INFO - 2023-03-22 10:56:18 --> Loader Class Initialized
INFO - 2023-03-22 10:56:18 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:18 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:18 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:56:18 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:18 --> Total execution time: 0.0383
INFO - 2023-03-22 10:56:18 --> Config Class Initialized
INFO - 2023-03-22 10:56:18 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:18 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:18 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:18 --> URI Class Initialized
INFO - 2023-03-22 10:56:18 --> Router Class Initialized
INFO - 2023-03-22 10:56:18 --> Output Class Initialized
INFO - 2023-03-22 10:56:18 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:18 --> Input Class Initialized
INFO - 2023-03-22 10:56:18 --> Language Class Initialized
INFO - 2023-03-22 10:56:18 --> Loader Class Initialized
INFO - 2023-03-22 10:56:18 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:18 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:18 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:56:18 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:18 --> Total execution time: 0.0880
INFO - 2023-03-22 10:56:26 --> Config Class Initialized
INFO - 2023-03-22 10:56:26 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:26 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:26 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:26 --> URI Class Initialized
INFO - 2023-03-22 10:56:26 --> Router Class Initialized
INFO - 2023-03-22 10:56:26 --> Output Class Initialized
INFO - 2023-03-22 10:56:26 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:26 --> Input Class Initialized
INFO - 2023-03-22 10:56:26 --> Language Class Initialized
INFO - 2023-03-22 10:56:26 --> Loader Class Initialized
INFO - 2023-03-22 10:56:26 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:26 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:26 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:26 --> Model "Login_model" initialized
INFO - 2023-03-22 10:56:26 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:26 --> Total execution time: 0.0238
INFO - 2023-03-22 10:56:26 --> Config Class Initialized
INFO - 2023-03-22 10:56:26 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:26 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:26 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:26 --> URI Class Initialized
INFO - 2023-03-22 10:56:26 --> Router Class Initialized
INFO - 2023-03-22 10:56:26 --> Output Class Initialized
INFO - 2023-03-22 10:56:26 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:26 --> Input Class Initialized
INFO - 2023-03-22 10:56:26 --> Language Class Initialized
INFO - 2023-03-22 10:56:26 --> Loader Class Initialized
INFO - 2023-03-22 10:56:26 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:26 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:26 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:26 --> Model "Login_model" initialized
INFO - 2023-03-22 10:56:26 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:26 --> Total execution time: 0.0636
INFO - 2023-03-22 10:56:29 --> Config Class Initialized
INFO - 2023-03-22 10:56:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:29 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:29 --> URI Class Initialized
INFO - 2023-03-22 10:56:29 --> Router Class Initialized
INFO - 2023-03-22 10:56:29 --> Output Class Initialized
INFO - 2023-03-22 10:56:29 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:29 --> Input Class Initialized
INFO - 2023-03-22 10:56:29 --> Language Class Initialized
INFO - 2023-03-22 10:56:29 --> Loader Class Initialized
INFO - 2023-03-22 10:56:29 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:29 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:29 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:29 --> Model "Login_model" initialized
INFO - 2023-03-22 10:56:29 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:29 --> Total execution time: 0.0252
INFO - 2023-03-22 10:56:29 --> Config Class Initialized
INFO - 2023-03-22 10:56:29 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:29 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:29 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:29 --> URI Class Initialized
INFO - 2023-03-22 10:56:29 --> Router Class Initialized
INFO - 2023-03-22 10:56:29 --> Output Class Initialized
INFO - 2023-03-22 10:56:29 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:29 --> Input Class Initialized
INFO - 2023-03-22 10:56:29 --> Language Class Initialized
INFO - 2023-03-22 10:56:29 --> Loader Class Initialized
INFO - 2023-03-22 10:56:29 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:29 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:29 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:29 --> Model "Login_model" initialized
INFO - 2023-03-22 10:56:29 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:29 --> Total execution time: 0.0186
INFO - 2023-03-22 10:56:34 --> Config Class Initialized
INFO - 2023-03-22 10:56:34 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:34 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:34 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:34 --> URI Class Initialized
INFO - 2023-03-22 10:56:34 --> Router Class Initialized
INFO - 2023-03-22 10:56:34 --> Output Class Initialized
INFO - 2023-03-22 10:56:34 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:34 --> Input Class Initialized
INFO - 2023-03-22 10:56:34 --> Language Class Initialized
INFO - 2023-03-22 10:56:34 --> Loader Class Initialized
INFO - 2023-03-22 10:56:34 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:34 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:34 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:56:34 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:34 --> Total execution time: 0.0144
INFO - 2023-03-22 10:56:34 --> Config Class Initialized
INFO - 2023-03-22 10:56:34 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:34 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:34 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:34 --> URI Class Initialized
INFO - 2023-03-22 10:56:34 --> Router Class Initialized
INFO - 2023-03-22 10:56:34 --> Output Class Initialized
INFO - 2023-03-22 10:56:34 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:34 --> Input Class Initialized
INFO - 2023-03-22 10:56:34 --> Language Class Initialized
INFO - 2023-03-22 10:56:34 --> Loader Class Initialized
INFO - 2023-03-22 10:56:34 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:34 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:34 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:56:34 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:34 --> Total execution time: 0.0504
INFO - 2023-03-22 10:56:35 --> Config Class Initialized
INFO - 2023-03-22 10:56:35 --> Config Class Initialized
INFO - 2023-03-22 10:56:35 --> Hooks Class Initialized
INFO - 2023-03-22 10:56:35 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:35 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 10:56:35 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:35 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:35 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:35 --> URI Class Initialized
INFO - 2023-03-22 10:56:35 --> URI Class Initialized
INFO - 2023-03-22 10:56:35 --> Router Class Initialized
INFO - 2023-03-22 10:56:35 --> Router Class Initialized
INFO - 2023-03-22 10:56:35 --> Output Class Initialized
INFO - 2023-03-22 10:56:35 --> Output Class Initialized
INFO - 2023-03-22 10:56:35 --> Security Class Initialized
INFO - 2023-03-22 10:56:35 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 10:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:35 --> Input Class Initialized
INFO - 2023-03-22 10:56:35 --> Input Class Initialized
INFO - 2023-03-22 10:56:35 --> Language Class Initialized
INFO - 2023-03-22 10:56:35 --> Language Class Initialized
INFO - 2023-03-22 10:56:35 --> Loader Class Initialized
INFO - 2023-03-22 10:56:35 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:35 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:35 --> Loader Class Initialized
INFO - 2023-03-22 10:56:35 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:35 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:35 --> Total execution time: 0.0066
INFO - 2023-03-22 10:56:35 --> Config Class Initialized
INFO - 2023-03-22 10:56:35 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:56:35 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:35 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:35 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:35 --> URI Class Initialized
INFO - 2023-03-22 10:56:35 --> Router Class Initialized
INFO - 2023-03-22 10:56:35 --> Output Class Initialized
INFO - 2023-03-22 10:56:35 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:35 --> Input Class Initialized
INFO - 2023-03-22 10:56:35 --> Language Class Initialized
INFO - 2023-03-22 10:56:35 --> Loader Class Initialized
INFO - 2023-03-22 10:56:35 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:35 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:35 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:35 --> Total execution time: 0.0532
INFO - 2023-03-22 10:56:35 --> Config Class Initialized
INFO - 2023-03-22 10:56:35 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:35 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:35 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:35 --> URI Class Initialized
INFO - 2023-03-22 10:56:35 --> Router Class Initialized
INFO - 2023-03-22 10:56:35 --> Output Class Initialized
INFO - 2023-03-22 10:56:35 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:35 --> Input Class Initialized
INFO - 2023-03-22 10:56:35 --> Language Class Initialized
INFO - 2023-03-22 10:56:35 --> Loader Class Initialized
INFO - 2023-03-22 10:56:35 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:35 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:35 --> Model "Login_model" initialized
INFO - 2023-03-22 10:56:35 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:35 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:56:35 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:35 --> Total execution time: 0.0129
INFO - 2023-03-22 10:56:35 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:56:35 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:35 --> Total execution time: 0.1043
INFO - 2023-03-22 10:56:42 --> Config Class Initialized
INFO - 2023-03-22 10:56:42 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:42 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:42 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:42 --> URI Class Initialized
INFO - 2023-03-22 10:56:42 --> Router Class Initialized
INFO - 2023-03-22 10:56:42 --> Output Class Initialized
INFO - 2023-03-22 10:56:42 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:42 --> Input Class Initialized
INFO - 2023-03-22 10:56:42 --> Language Class Initialized
INFO - 2023-03-22 10:56:42 --> Loader Class Initialized
INFO - 2023-03-22 10:56:42 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:42 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:42 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:56:42 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:42 --> Total execution time: 0.0151
INFO - 2023-03-22 10:56:42 --> Config Class Initialized
INFO - 2023-03-22 10:56:42 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:56:42 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:56:42 --> Utf8 Class Initialized
INFO - 2023-03-22 10:56:42 --> URI Class Initialized
INFO - 2023-03-22 10:56:42 --> Router Class Initialized
INFO - 2023-03-22 10:56:42 --> Output Class Initialized
INFO - 2023-03-22 10:56:42 --> Security Class Initialized
DEBUG - 2023-03-22 10:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:56:42 --> Input Class Initialized
INFO - 2023-03-22 10:56:42 --> Language Class Initialized
INFO - 2023-03-22 10:56:42 --> Loader Class Initialized
INFO - 2023-03-22 10:56:42 --> Controller Class Initialized
DEBUG - 2023-03-22 10:56:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:56:42 --> Database Driver Class Initialized
INFO - 2023-03-22 10:56:42 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:56:42 --> Final output sent to browser
DEBUG - 2023-03-22 10:56:42 --> Total execution time: 0.0113
INFO - 2023-03-22 10:57:07 --> Config Class Initialized
INFO - 2023-03-22 10:57:07 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:57:07 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:57:07 --> Utf8 Class Initialized
INFO - 2023-03-22 10:57:07 --> URI Class Initialized
INFO - 2023-03-22 10:57:07 --> Router Class Initialized
INFO - 2023-03-22 10:57:07 --> Output Class Initialized
INFO - 2023-03-22 10:57:07 --> Security Class Initialized
DEBUG - 2023-03-22 10:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:57:07 --> Input Class Initialized
INFO - 2023-03-22 10:57:07 --> Language Class Initialized
INFO - 2023-03-22 10:57:07 --> Loader Class Initialized
INFO - 2023-03-22 10:57:07 --> Controller Class Initialized
DEBUG - 2023-03-22 10:57:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:57:07 --> Final output sent to browser
DEBUG - 2023-03-22 10:57:07 --> Total execution time: 0.0042
INFO - 2023-03-22 10:57:07 --> Config Class Initialized
INFO - 2023-03-22 10:57:07 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:57:07 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:57:07 --> Utf8 Class Initialized
INFO - 2023-03-22 10:57:07 --> URI Class Initialized
INFO - 2023-03-22 10:57:07 --> Router Class Initialized
INFO - 2023-03-22 10:57:07 --> Output Class Initialized
INFO - 2023-03-22 10:57:07 --> Security Class Initialized
DEBUG - 2023-03-22 10:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:57:07 --> Input Class Initialized
INFO - 2023-03-22 10:57:07 --> Language Class Initialized
INFO - 2023-03-22 10:57:07 --> Loader Class Initialized
INFO - 2023-03-22 10:57:07 --> Controller Class Initialized
DEBUG - 2023-03-22 10:57:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:57:07 --> Database Driver Class Initialized
INFO - 2023-03-22 10:57:07 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:57:07 --> Final output sent to browser
DEBUG - 2023-03-22 10:57:07 --> Total execution time: 0.0107
INFO - 2023-03-22 10:57:10 --> Config Class Initialized
INFO - 2023-03-22 10:57:10 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:57:10 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:57:10 --> Utf8 Class Initialized
INFO - 2023-03-22 10:57:10 --> URI Class Initialized
INFO - 2023-03-22 10:57:10 --> Router Class Initialized
INFO - 2023-03-22 10:57:10 --> Output Class Initialized
INFO - 2023-03-22 10:57:10 --> Security Class Initialized
DEBUG - 2023-03-22 10:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:57:10 --> Input Class Initialized
INFO - 2023-03-22 10:57:10 --> Language Class Initialized
INFO - 2023-03-22 10:57:10 --> Loader Class Initialized
INFO - 2023-03-22 10:57:10 --> Controller Class Initialized
DEBUG - 2023-03-22 10:57:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:57:10 --> Database Driver Class Initialized
INFO - 2023-03-22 10:57:10 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:57:10 --> Final output sent to browser
DEBUG - 2023-03-22 10:57:10 --> Total execution time: 0.0400
INFO - 2023-03-22 10:57:10 --> Config Class Initialized
INFO - 2023-03-22 10:57:10 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:57:10 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:57:10 --> Utf8 Class Initialized
INFO - 2023-03-22 10:57:10 --> URI Class Initialized
INFO - 2023-03-22 10:57:10 --> Router Class Initialized
INFO - 2023-03-22 10:57:10 --> Output Class Initialized
INFO - 2023-03-22 10:57:10 --> Security Class Initialized
DEBUG - 2023-03-22 10:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:57:10 --> Input Class Initialized
INFO - 2023-03-22 10:57:10 --> Language Class Initialized
INFO - 2023-03-22 10:57:10 --> Loader Class Initialized
INFO - 2023-03-22 10:57:10 --> Controller Class Initialized
DEBUG - 2023-03-22 10:57:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:57:10 --> Database Driver Class Initialized
INFO - 2023-03-22 10:57:10 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:57:10 --> Final output sent to browser
DEBUG - 2023-03-22 10:57:10 --> Total execution time: 0.0353
INFO - 2023-03-22 10:57:15 --> Config Class Initialized
INFO - 2023-03-22 10:57:15 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:57:15 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:57:15 --> Utf8 Class Initialized
INFO - 2023-03-22 10:57:15 --> URI Class Initialized
INFO - 2023-03-22 10:57:15 --> Router Class Initialized
INFO - 2023-03-22 10:57:15 --> Output Class Initialized
INFO - 2023-03-22 10:57:15 --> Security Class Initialized
DEBUG - 2023-03-22 10:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:57:15 --> Input Class Initialized
INFO - 2023-03-22 10:57:15 --> Language Class Initialized
INFO - 2023-03-22 10:57:15 --> Loader Class Initialized
INFO - 2023-03-22 10:57:15 --> Controller Class Initialized
DEBUG - 2023-03-22 10:57:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:57:15 --> Database Driver Class Initialized
INFO - 2023-03-22 10:57:15 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:57:15 --> Final output sent to browser
DEBUG - 2023-03-22 10:57:15 --> Total execution time: 0.0342
INFO - 2023-03-22 10:57:15 --> Config Class Initialized
INFO - 2023-03-22 10:57:15 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:57:15 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:57:15 --> Utf8 Class Initialized
INFO - 2023-03-22 10:57:15 --> URI Class Initialized
INFO - 2023-03-22 10:57:15 --> Router Class Initialized
INFO - 2023-03-22 10:57:15 --> Output Class Initialized
INFO - 2023-03-22 10:57:15 --> Security Class Initialized
DEBUG - 2023-03-22 10:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:57:15 --> Input Class Initialized
INFO - 2023-03-22 10:57:15 --> Language Class Initialized
INFO - 2023-03-22 10:57:15 --> Loader Class Initialized
INFO - 2023-03-22 10:57:15 --> Controller Class Initialized
DEBUG - 2023-03-22 10:57:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:57:15 --> Database Driver Class Initialized
INFO - 2023-03-22 10:57:15 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:57:15 --> Final output sent to browser
DEBUG - 2023-03-22 10:57:15 --> Total execution time: 0.0096
INFO - 2023-03-22 10:57:17 --> Config Class Initialized
INFO - 2023-03-22 10:57:17 --> Config Class Initialized
INFO - 2023-03-22 10:57:17 --> Hooks Class Initialized
INFO - 2023-03-22 10:57:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:57:17 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 10:57:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:57:17 --> Utf8 Class Initialized
INFO - 2023-03-22 10:57:17 --> Utf8 Class Initialized
INFO - 2023-03-22 10:57:17 --> URI Class Initialized
INFO - 2023-03-22 10:57:17 --> URI Class Initialized
INFO - 2023-03-22 10:57:17 --> Router Class Initialized
INFO - 2023-03-22 10:57:17 --> Router Class Initialized
INFO - 2023-03-22 10:57:17 --> Output Class Initialized
INFO - 2023-03-22 10:57:17 --> Output Class Initialized
INFO - 2023-03-22 10:57:17 --> Security Class Initialized
INFO - 2023-03-22 10:57:17 --> Security Class Initialized
DEBUG - 2023-03-22 10:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 10:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:57:17 --> Input Class Initialized
INFO - 2023-03-22 10:57:17 --> Input Class Initialized
INFO - 2023-03-22 10:57:17 --> Language Class Initialized
INFO - 2023-03-22 10:57:17 --> Language Class Initialized
INFO - 2023-03-22 10:57:17 --> Loader Class Initialized
INFO - 2023-03-22 10:57:17 --> Loader Class Initialized
INFO - 2023-03-22 10:57:17 --> Controller Class Initialized
INFO - 2023-03-22 10:57:17 --> Controller Class Initialized
DEBUG - 2023-03-22 10:57:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 10:57:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:57:17 --> Database Driver Class Initialized
INFO - 2023-03-22 10:57:17 --> Final output sent to browser
DEBUG - 2023-03-22 10:57:17 --> Total execution time: 0.0044
INFO - 2023-03-22 10:57:17 --> Config Class Initialized
INFO - 2023-03-22 10:57:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:57:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:57:17 --> Utf8 Class Initialized
INFO - 2023-03-22 10:57:17 --> URI Class Initialized
INFO - 2023-03-22 10:57:17 --> Router Class Initialized
INFO - 2023-03-22 10:57:17 --> Output Class Initialized
INFO - 2023-03-22 10:57:17 --> Security Class Initialized
DEBUG - 2023-03-22 10:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:57:17 --> Input Class Initialized
INFO - 2023-03-22 10:57:17 --> Language Class Initialized
INFO - 2023-03-22 10:57:17 --> Loader Class Initialized
INFO - 2023-03-22 10:57:17 --> Controller Class Initialized
DEBUG - 2023-03-22 10:57:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:57:17 --> Database Driver Class Initialized
INFO - 2023-03-22 10:57:17 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:57:17 --> Model "Login_model" initialized
INFO - 2023-03-22 10:57:17 --> Final output sent to browser
DEBUG - 2023-03-22 10:57:17 --> Total execution time: 0.0163
INFO - 2023-03-22 10:57:17 --> Database Driver Class Initialized
INFO - 2023-03-22 10:57:17 --> Config Class Initialized
INFO - 2023-03-22 10:57:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:57:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:57:17 --> Utf8 Class Initialized
INFO - 2023-03-22 10:57:17 --> URI Class Initialized
INFO - 2023-03-22 10:57:17 --> Router Class Initialized
INFO - 2023-03-22 10:57:17 --> Output Class Initialized
INFO - 2023-03-22 10:57:17 --> Security Class Initialized
DEBUG - 2023-03-22 10:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:57:17 --> Input Class Initialized
INFO - 2023-03-22 10:57:17 --> Language Class Initialized
INFO - 2023-03-22 10:57:17 --> Loader Class Initialized
INFO - 2023-03-22 10:57:17 --> Controller Class Initialized
DEBUG - 2023-03-22 10:57:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:57:17 --> Database Driver Class Initialized
INFO - 2023-03-22 10:57:17 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:57:17 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:57:17 --> Final output sent to browser
DEBUG - 2023-03-22 10:57:17 --> Total execution time: 0.0242
INFO - 2023-03-22 10:57:17 --> Final output sent to browser
DEBUG - 2023-03-22 10:57:17 --> Total execution time: 0.0557
INFO - 2023-03-22 10:58:16 --> Config Class Initialized
INFO - 2023-03-22 10:58:16 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:58:16 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:58:16 --> Utf8 Class Initialized
INFO - 2023-03-22 10:58:16 --> URI Class Initialized
INFO - 2023-03-22 10:58:16 --> Router Class Initialized
INFO - 2023-03-22 10:58:16 --> Output Class Initialized
INFO - 2023-03-22 10:58:16 --> Security Class Initialized
DEBUG - 2023-03-22 10:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:58:16 --> Input Class Initialized
INFO - 2023-03-22 10:58:16 --> Language Class Initialized
INFO - 2023-03-22 10:58:16 --> Loader Class Initialized
INFO - 2023-03-22 10:58:16 --> Controller Class Initialized
DEBUG - 2023-03-22 10:58:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:58:16 --> Database Driver Class Initialized
INFO - 2023-03-22 10:58:16 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:58:16 --> Final output sent to browser
DEBUG - 2023-03-22 10:58:16 --> Total execution time: 0.0176
INFO - 2023-03-22 10:58:16 --> Config Class Initialized
INFO - 2023-03-22 10:58:16 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:58:16 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:58:16 --> Utf8 Class Initialized
INFO - 2023-03-22 10:58:16 --> URI Class Initialized
INFO - 2023-03-22 10:58:16 --> Router Class Initialized
INFO - 2023-03-22 10:58:16 --> Output Class Initialized
INFO - 2023-03-22 10:58:16 --> Security Class Initialized
DEBUG - 2023-03-22 10:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:58:16 --> Input Class Initialized
INFO - 2023-03-22 10:58:16 --> Language Class Initialized
INFO - 2023-03-22 10:58:16 --> Loader Class Initialized
INFO - 2023-03-22 10:58:16 --> Controller Class Initialized
DEBUG - 2023-03-22 10:58:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:58:16 --> Database Driver Class Initialized
INFO - 2023-03-22 10:58:16 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:58:16 --> Final output sent to browser
DEBUG - 2023-03-22 10:58:16 --> Total execution time: 0.0537
INFO - 2023-03-22 10:58:17 --> Config Class Initialized
INFO - 2023-03-22 10:58:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:58:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:58:17 --> Utf8 Class Initialized
INFO - 2023-03-22 10:58:17 --> URI Class Initialized
INFO - 2023-03-22 10:58:17 --> Router Class Initialized
INFO - 2023-03-22 10:58:17 --> Output Class Initialized
INFO - 2023-03-22 10:58:17 --> Security Class Initialized
DEBUG - 2023-03-22 10:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:58:17 --> Input Class Initialized
INFO - 2023-03-22 10:58:17 --> Language Class Initialized
INFO - 2023-03-22 10:58:17 --> Loader Class Initialized
INFO - 2023-03-22 10:58:17 --> Controller Class Initialized
DEBUG - 2023-03-22 10:58:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:58:17 --> Database Driver Class Initialized
INFO - 2023-03-22 10:58:17 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:58:17 --> Final output sent to browser
DEBUG - 2023-03-22 10:58:17 --> Total execution time: 0.0124
INFO - 2023-03-22 10:58:17 --> Config Class Initialized
INFO - 2023-03-22 10:58:17 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:58:17 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:58:17 --> Utf8 Class Initialized
INFO - 2023-03-22 10:58:17 --> URI Class Initialized
INFO - 2023-03-22 10:58:17 --> Router Class Initialized
INFO - 2023-03-22 10:58:17 --> Output Class Initialized
INFO - 2023-03-22 10:58:17 --> Security Class Initialized
DEBUG - 2023-03-22 10:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:58:17 --> Input Class Initialized
INFO - 2023-03-22 10:58:17 --> Language Class Initialized
INFO - 2023-03-22 10:58:17 --> Loader Class Initialized
INFO - 2023-03-22 10:58:17 --> Controller Class Initialized
DEBUG - 2023-03-22 10:58:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:58:17 --> Database Driver Class Initialized
INFO - 2023-03-22 10:58:17 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:58:17 --> Final output sent to browser
DEBUG - 2023-03-22 10:58:17 --> Total execution time: 0.0102
INFO - 2023-03-22 10:58:20 --> Config Class Initialized
INFO - 2023-03-22 10:58:20 --> Config Class Initialized
INFO - 2023-03-22 10:58:20 --> Hooks Class Initialized
INFO - 2023-03-22 10:58:20 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2023-03-22 10:58:20 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:58:20 --> Utf8 Class Initialized
INFO - 2023-03-22 10:58:20 --> Utf8 Class Initialized
INFO - 2023-03-22 10:58:20 --> URI Class Initialized
INFO - 2023-03-22 10:58:20 --> URI Class Initialized
INFO - 2023-03-22 10:58:20 --> Router Class Initialized
INFO - 2023-03-22 10:58:20 --> Router Class Initialized
INFO - 2023-03-22 10:58:20 --> Output Class Initialized
INFO - 2023-03-22 10:58:20 --> Output Class Initialized
INFO - 2023-03-22 10:58:20 --> Security Class Initialized
INFO - 2023-03-22 10:58:20 --> Security Class Initialized
DEBUG - 2023-03-22 10:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-22 10:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:58:20 --> Input Class Initialized
INFO - 2023-03-22 10:58:20 --> Input Class Initialized
INFO - 2023-03-22 10:58:20 --> Language Class Initialized
INFO - 2023-03-22 10:58:20 --> Language Class Initialized
INFO - 2023-03-22 10:58:20 --> Loader Class Initialized
INFO - 2023-03-22 10:58:20 --> Loader Class Initialized
INFO - 2023-03-22 10:58:20 --> Controller Class Initialized
INFO - 2023-03-22 10:58:20 --> Controller Class Initialized
DEBUG - 2023-03-22 10:58:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-22 10:58:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:58:20 --> Final output sent to browser
DEBUG - 2023-03-22 10:58:20 --> Total execution time: 0.0046
INFO - 2023-03-22 10:58:20 --> Database Driver Class Initialized
INFO - 2023-03-22 10:58:20 --> Config Class Initialized
INFO - 2023-03-22 10:58:20 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:58:20 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:58:20 --> Utf8 Class Initialized
INFO - 2023-03-22 10:58:20 --> URI Class Initialized
INFO - 2023-03-22 10:58:20 --> Router Class Initialized
INFO - 2023-03-22 10:58:20 --> Output Class Initialized
INFO - 2023-03-22 10:58:20 --> Security Class Initialized
DEBUG - 2023-03-22 10:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:58:20 --> Input Class Initialized
INFO - 2023-03-22 10:58:20 --> Language Class Initialized
INFO - 2023-03-22 10:58:20 --> Loader Class Initialized
INFO - 2023-03-22 10:58:20 --> Controller Class Initialized
DEBUG - 2023-03-22 10:58:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:58:20 --> Database Driver Class Initialized
INFO - 2023-03-22 10:58:20 --> Model "Login_model" initialized
INFO - 2023-03-22 10:58:20 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:58:20 --> Database Driver Class Initialized
INFO - 2023-03-22 10:58:20 --> Final output sent to browser
DEBUG - 2023-03-22 10:58:20 --> Total execution time: 0.0184
INFO - 2023-03-22 10:58:20 --> Config Class Initialized
INFO - 2023-03-22 10:58:20 --> Hooks Class Initialized
DEBUG - 2023-03-22 10:58:20 --> UTF-8 Support Enabled
INFO - 2023-03-22 10:58:20 --> Utf8 Class Initialized
INFO - 2023-03-22 10:58:20 --> URI Class Initialized
INFO - 2023-03-22 10:58:20 --> Router Class Initialized
INFO - 2023-03-22 10:58:20 --> Output Class Initialized
INFO - 2023-03-22 10:58:20 --> Security Class Initialized
DEBUG - 2023-03-22 10:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 10:58:20 --> Input Class Initialized
INFO - 2023-03-22 10:58:20 --> Language Class Initialized
INFO - 2023-03-22 10:58:20 --> Loader Class Initialized
INFO - 2023-03-22 10:58:20 --> Controller Class Initialized
DEBUG - 2023-03-22 10:58:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 10:58:20 --> Database Driver Class Initialized
INFO - 2023-03-22 10:58:20 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:58:20 --> Final output sent to browser
DEBUG - 2023-03-22 10:58:20 --> Total execution time: 0.0217
INFO - 2023-03-22 10:58:20 --> Model "Cluster_model" initialized
INFO - 2023-03-22 10:58:20 --> Final output sent to browser
DEBUG - 2023-03-22 10:58:20 --> Total execution time: 0.0553
INFO - 2023-03-22 11:02:56 --> Config Class Initialized
INFO - 2023-03-22 11:02:56 --> Hooks Class Initialized
DEBUG - 2023-03-22 11:02:56 --> UTF-8 Support Enabled
INFO - 2023-03-22 11:02:56 --> Utf8 Class Initialized
INFO - 2023-03-22 11:02:56 --> URI Class Initialized
INFO - 2023-03-22 11:02:56 --> Router Class Initialized
INFO - 2023-03-22 11:02:56 --> Output Class Initialized
INFO - 2023-03-22 11:02:56 --> Security Class Initialized
DEBUG - 2023-03-22 11:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 11:02:56 --> Input Class Initialized
INFO - 2023-03-22 11:02:56 --> Language Class Initialized
INFO - 2023-03-22 11:02:56 --> Loader Class Initialized
INFO - 2023-03-22 11:02:56 --> Controller Class Initialized
DEBUG - 2023-03-22 11:02:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 11:02:56 --> Database Driver Class Initialized
INFO - 2023-03-22 11:02:56 --> Model "Cluster_model" initialized
INFO - 2023-03-22 11:02:56 --> Final output sent to browser
DEBUG - 2023-03-22 11:02:56 --> Total execution time: 0.0145
INFO - 2023-03-22 11:02:57 --> Config Class Initialized
INFO - 2023-03-22 11:02:57 --> Hooks Class Initialized
DEBUG - 2023-03-22 11:02:57 --> UTF-8 Support Enabled
INFO - 2023-03-22 11:02:57 --> Utf8 Class Initialized
INFO - 2023-03-22 11:02:57 --> URI Class Initialized
INFO - 2023-03-22 11:02:57 --> Router Class Initialized
INFO - 2023-03-22 11:02:57 --> Output Class Initialized
INFO - 2023-03-22 11:02:57 --> Security Class Initialized
DEBUG - 2023-03-22 11:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 11:02:57 --> Input Class Initialized
INFO - 2023-03-22 11:02:57 --> Language Class Initialized
INFO - 2023-03-22 11:02:57 --> Loader Class Initialized
INFO - 2023-03-22 11:02:57 --> Controller Class Initialized
DEBUG - 2023-03-22 11:02:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 11:02:57 --> Database Driver Class Initialized
INFO - 2023-03-22 11:02:57 --> Model "Cluster_model" initialized
INFO - 2023-03-22 11:02:57 --> Final output sent to browser
DEBUG - 2023-03-22 11:02:57 --> Total execution time: 0.0095
INFO - 2023-03-22 11:02:58 --> Config Class Initialized
INFO - 2023-03-22 11:02:58 --> Hooks Class Initialized
DEBUG - 2023-03-22 11:02:58 --> UTF-8 Support Enabled
INFO - 2023-03-22 11:02:58 --> Utf8 Class Initialized
INFO - 2023-03-22 11:02:58 --> URI Class Initialized
INFO - 2023-03-22 11:02:58 --> Router Class Initialized
INFO - 2023-03-22 11:02:58 --> Output Class Initialized
INFO - 2023-03-22 11:02:58 --> Security Class Initialized
DEBUG - 2023-03-22 11:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 11:02:58 --> Input Class Initialized
INFO - 2023-03-22 11:02:58 --> Language Class Initialized
INFO - 2023-03-22 11:02:58 --> Loader Class Initialized
INFO - 2023-03-22 11:02:58 --> Controller Class Initialized
DEBUG - 2023-03-22 11:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 11:02:58 --> Database Driver Class Initialized
INFO - 2023-03-22 11:02:58 --> Model "Cluster_model" initialized
INFO - 2023-03-22 11:02:58 --> Final output sent to browser
DEBUG - 2023-03-22 11:02:58 --> Total execution time: 0.0142
INFO - 2023-03-22 11:02:58 --> Config Class Initialized
INFO - 2023-03-22 11:02:58 --> Hooks Class Initialized
DEBUG - 2023-03-22 11:02:58 --> UTF-8 Support Enabled
INFO - 2023-03-22 11:02:58 --> Utf8 Class Initialized
INFO - 2023-03-22 11:02:58 --> URI Class Initialized
INFO - 2023-03-22 11:02:58 --> Router Class Initialized
INFO - 2023-03-22 11:02:58 --> Output Class Initialized
INFO - 2023-03-22 11:02:58 --> Security Class Initialized
DEBUG - 2023-03-22 11:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 11:02:58 --> Input Class Initialized
INFO - 2023-03-22 11:02:58 --> Language Class Initialized
INFO - 2023-03-22 11:02:58 --> Loader Class Initialized
INFO - 2023-03-22 11:02:58 --> Controller Class Initialized
DEBUG - 2023-03-22 11:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 11:02:58 --> Database Driver Class Initialized
INFO - 2023-03-22 11:02:58 --> Model "Cluster_model" initialized
INFO - 2023-03-22 11:02:58 --> Final output sent to browser
DEBUG - 2023-03-22 11:02:58 --> Total execution time: 0.0100
INFO - 2023-03-22 13:18:23 --> Config Class Initialized
INFO - 2023-03-22 13:18:23 --> Hooks Class Initialized
DEBUG - 2023-03-22 13:18:23 --> UTF-8 Support Enabled
INFO - 2023-03-22 13:18:23 --> Utf8 Class Initialized
INFO - 2023-03-22 13:18:23 --> URI Class Initialized
INFO - 2023-03-22 13:18:23 --> Router Class Initialized
INFO - 2023-03-22 13:18:23 --> Output Class Initialized
INFO - 2023-03-22 13:18:23 --> Security Class Initialized
DEBUG - 2023-03-22 13:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-22 13:18:23 --> Input Class Initialized
INFO - 2023-03-22 13:18:23 --> Language Class Initialized
INFO - 2023-03-22 13:18:23 --> Loader Class Initialized
INFO - 2023-03-22 13:18:23 --> Controller Class Initialized
DEBUG - 2023-03-22 13:18:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-22 13:18:23 --> Database Driver Class Initialized
ERROR - 2023-03-22 13:18:33 --> Unable to connect to the database
INFO - 2023-03-22 13:18:33 --> Language file loaded: language/english/db_lang.php
