<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-26 03:17:48 --> Config Class Initialized
INFO - 2023-05-26 03:17:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:48 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:48 --> URI Class Initialized
INFO - 2023-05-26 03:17:48 --> Router Class Initialized
INFO - 2023-05-26 03:17:48 --> Output Class Initialized
INFO - 2023-05-26 03:17:48 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:48 --> Input Class Initialized
INFO - 2023-05-26 03:17:48 --> Language Class Initialized
INFO - 2023-05-26 03:17:48 --> Loader Class Initialized
INFO - 2023-05-26 03:17:48 --> Controller Class Initialized
INFO - 2023-05-26 03:17:48 --> Helper loaded: form_helper
INFO - 2023-05-26 03:17:48 --> Helper loaded: url_helper
DEBUG - 2023-05-26 03:17:48 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:48 --> Model "Change_model" initialized
INFO - 2023-05-26 03:17:51 --> Model "Grafana_model" initialized
INFO - 2023-05-26 03:17:51 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:51 --> Total execution time: 3.1815
INFO - 2023-05-26 03:17:51 --> Config Class Initialized
INFO - 2023-05-26 03:17:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:51 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:51 --> URI Class Initialized
INFO - 2023-05-26 03:17:51 --> Router Class Initialized
INFO - 2023-05-26 03:17:51 --> Output Class Initialized
INFO - 2023-05-26 03:17:51 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:51 --> Input Class Initialized
INFO - 2023-05-26 03:17:51 --> Language Class Initialized
INFO - 2023-05-26 03:17:51 --> Loader Class Initialized
INFO - 2023-05-26 03:17:51 --> Controller Class Initialized
INFO - 2023-05-26 03:17:51 --> Helper loaded: form_helper
INFO - 2023-05-26 03:17:51 --> Helper loaded: url_helper
DEBUG - 2023-05-26 03:17:51 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:51 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:51 --> Total execution time: 0.0289
INFO - 2023-05-26 03:17:51 --> Config Class Initialized
INFO - 2023-05-26 03:17:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:51 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:51 --> URI Class Initialized
INFO - 2023-05-26 03:17:51 --> Router Class Initialized
INFO - 2023-05-26 03:17:51 --> Output Class Initialized
INFO - 2023-05-26 03:17:51 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:51 --> Input Class Initialized
INFO - 2023-05-26 03:17:51 --> Language Class Initialized
INFO - 2023-05-26 03:17:51 --> Loader Class Initialized
INFO - 2023-05-26 03:17:51 --> Controller Class Initialized
INFO - 2023-05-26 03:17:51 --> Helper loaded: form_helper
INFO - 2023-05-26 03:17:51 --> Helper loaded: url_helper
DEBUG - 2023-05-26 03:17:51 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:51 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:51 --> Model "Login_model" initialized
INFO - 2023-05-26 03:17:51 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:51 --> Total execution time: 0.0757
INFO - 2023-05-26 03:17:51 --> Config Class Initialized
INFO - 2023-05-26 03:17:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:51 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:51 --> URI Class Initialized
INFO - 2023-05-26 03:17:51 --> Router Class Initialized
INFO - 2023-05-26 03:17:51 --> Output Class Initialized
INFO - 2023-05-26 03:17:51 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:51 --> Input Class Initialized
INFO - 2023-05-26 03:17:51 --> Language Class Initialized
INFO - 2023-05-26 03:17:51 --> Loader Class Initialized
INFO - 2023-05-26 03:17:51 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:51 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:51 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:51 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:51 --> Total execution time: 0.0615
INFO - 2023-05-26 03:17:51 --> Config Class Initialized
INFO - 2023-05-26 03:17:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:51 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:51 --> URI Class Initialized
INFO - 2023-05-26 03:17:51 --> Router Class Initialized
INFO - 2023-05-26 03:17:51 --> Output Class Initialized
INFO - 2023-05-26 03:17:51 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:51 --> Input Class Initialized
INFO - 2023-05-26 03:17:51 --> Language Class Initialized
INFO - 2023-05-26 03:17:51 --> Loader Class Initialized
INFO - 2023-05-26 03:17:51 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:51 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:51 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:51 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:51 --> Total execution time: 0.0937
INFO - 2023-05-26 03:17:52 --> Config Class Initialized
INFO - 2023-05-26 03:17:52 --> Config Class Initialized
INFO - 2023-05-26 03:17:52 --> Hooks Class Initialized
INFO - 2023-05-26 03:17:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:17:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:52 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:52 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:52 --> URI Class Initialized
INFO - 2023-05-26 03:17:52 --> URI Class Initialized
INFO - 2023-05-26 03:17:52 --> Router Class Initialized
INFO - 2023-05-26 03:17:52 --> Router Class Initialized
INFO - 2023-05-26 03:17:52 --> Output Class Initialized
INFO - 2023-05-26 03:17:52 --> Output Class Initialized
INFO - 2023-05-26 03:17:52 --> Security Class Initialized
INFO - 2023-05-26 03:17:52 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:52 --> Input Class Initialized
DEBUG - 2023-05-26 03:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:52 --> Language Class Initialized
INFO - 2023-05-26 03:17:52 --> Input Class Initialized
INFO - 2023-05-26 03:17:52 --> Language Class Initialized
INFO - 2023-05-26 03:17:52 --> Loader Class Initialized
INFO - 2023-05-26 03:17:52 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:52 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:52 --> Loader Class Initialized
INFO - 2023-05-26 03:17:52 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:52 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:52 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:52 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:52 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:52 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:52 --> Total execution time: 0.0681
INFO - 2023-05-26 03:17:52 --> Config Class Initialized
INFO - 2023-05-26 03:17:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:52 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:52 --> URI Class Initialized
INFO - 2023-05-26 03:17:52 --> Router Class Initialized
INFO - 2023-05-26 03:17:52 --> Output Class Initialized
INFO - 2023-05-26 03:17:52 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:52 --> Input Class Initialized
INFO - 2023-05-26 03:17:52 --> Model "Login_model" initialized
INFO - 2023-05-26 03:17:52 --> Language Class Initialized
INFO - 2023-05-26 03:17:52 --> Loader Class Initialized
INFO - 2023-05-26 03:17:52 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:52 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:52 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:52 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:52 --> Total execution time: 0.0778
INFO - 2023-05-26 03:17:52 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:52 --> Total execution time: 0.2285
INFO - 2023-05-26 03:17:52 --> Config Class Initialized
INFO - 2023-05-26 03:17:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:52 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:52 --> URI Class Initialized
INFO - 2023-05-26 03:17:52 --> Router Class Initialized
INFO - 2023-05-26 03:17:52 --> Output Class Initialized
INFO - 2023-05-26 03:17:52 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:52 --> Input Class Initialized
INFO - 2023-05-26 03:17:52 --> Language Class Initialized
INFO - 2023-05-26 03:17:52 --> Loader Class Initialized
INFO - 2023-05-26 03:17:52 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:52 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:52 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:52 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:52 --> Model "Login_model" initialized
INFO - 2023-05-26 03:17:52 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:52 --> Total execution time: 0.2940
INFO - 2023-05-26 03:17:56 --> Config Class Initialized
INFO - 2023-05-26 03:17:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:56 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:56 --> URI Class Initialized
INFO - 2023-05-26 03:17:56 --> Router Class Initialized
INFO - 2023-05-26 03:17:56 --> Output Class Initialized
INFO - 2023-05-26 03:17:56 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:56 --> Input Class Initialized
INFO - 2023-05-26 03:17:56 --> Language Class Initialized
INFO - 2023-05-26 03:17:56 --> Loader Class Initialized
INFO - 2023-05-26 03:17:56 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:56 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:56 --> Model "Login_model" initialized
INFO - 2023-05-26 03:17:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:56 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:56 --> Total execution time: 0.0858
INFO - 2023-05-26 03:17:56 --> Config Class Initialized
INFO - 2023-05-26 03:17:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:56 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:56 --> URI Class Initialized
INFO - 2023-05-26 03:17:56 --> Router Class Initialized
INFO - 2023-05-26 03:17:56 --> Output Class Initialized
INFO - 2023-05-26 03:17:56 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:56 --> Input Class Initialized
INFO - 2023-05-26 03:17:56 --> Language Class Initialized
INFO - 2023-05-26 03:17:56 --> Loader Class Initialized
INFO - 2023-05-26 03:17:56 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:56 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:56 --> Model "Login_model" initialized
INFO - 2023-05-26 03:17:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:56 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:56 --> Total execution time: 0.1052
INFO - 2023-05-26 03:17:56 --> Config Class Initialized
INFO - 2023-05-26 03:17:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:56 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:56 --> URI Class Initialized
INFO - 2023-05-26 03:17:56 --> Router Class Initialized
INFO - 2023-05-26 03:17:56 --> Output Class Initialized
INFO - 2023-05-26 03:17:56 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:56 --> Input Class Initialized
INFO - 2023-05-26 03:17:56 --> Language Class Initialized
INFO - 2023-05-26 03:17:56 --> Loader Class Initialized
INFO - 2023-05-26 03:17:56 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:56 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:56 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:56 --> Total execution time: 0.0338
INFO - 2023-05-26 03:17:56 --> Config Class Initialized
INFO - 2023-05-26 03:17:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:56 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:56 --> URI Class Initialized
INFO - 2023-05-26 03:17:56 --> Router Class Initialized
INFO - 2023-05-26 03:17:56 --> Output Class Initialized
INFO - 2023-05-26 03:17:56 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:56 --> Input Class Initialized
INFO - 2023-05-26 03:17:56 --> Language Class Initialized
INFO - 2023-05-26 03:17:56 --> Loader Class Initialized
INFO - 2023-05-26 03:17:56 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:56 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:56 --> Model "Login_model" initialized
INFO - 2023-05-26 03:17:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:56 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:56 --> Total execution time: 0.0867
INFO - 2023-05-26 03:17:58 --> Config Class Initialized
INFO - 2023-05-26 03:17:58 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:58 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:58 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:58 --> URI Class Initialized
INFO - 2023-05-26 03:17:58 --> Router Class Initialized
INFO - 2023-05-26 03:17:58 --> Output Class Initialized
INFO - 2023-05-26 03:17:58 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:58 --> Input Class Initialized
INFO - 2023-05-26 03:17:58 --> Language Class Initialized
INFO - 2023-05-26 03:17:58 --> Loader Class Initialized
INFO - 2023-05-26 03:17:58 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:58 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:58 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:58 --> Model "Login_model" initialized
INFO - 2023-05-26 03:17:58 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:58 --> Total execution time: 0.0723
INFO - 2023-05-26 03:17:58 --> Config Class Initialized
INFO - 2023-05-26 03:17:58 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:58 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:58 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:58 --> URI Class Initialized
INFO - 2023-05-26 03:17:58 --> Router Class Initialized
INFO - 2023-05-26 03:17:58 --> Output Class Initialized
INFO - 2023-05-26 03:17:58 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:58 --> Input Class Initialized
INFO - 2023-05-26 03:17:58 --> Language Class Initialized
INFO - 2023-05-26 03:17:58 --> Loader Class Initialized
INFO - 2023-05-26 03:17:58 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:58 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:17:58 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:58 --> Model "Login_model" initialized
INFO - 2023-05-26 03:17:58 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:58 --> Total execution time: 0.1243
INFO - 2023-05-26 03:18:02 --> Config Class Initialized
INFO - 2023-05-26 03:18:02 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:02 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:02 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:02 --> URI Class Initialized
INFO - 2023-05-26 03:18:02 --> Router Class Initialized
INFO - 2023-05-26 03:18:02 --> Output Class Initialized
INFO - 2023-05-26 03:18:02 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:02 --> Input Class Initialized
INFO - 2023-05-26 03:18:02 --> Language Class Initialized
INFO - 2023-05-26 03:18:02 --> Loader Class Initialized
INFO - 2023-05-26 03:18:02 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:02 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:02 --> Total execution time: 0.0245
INFO - 2023-05-26 03:18:02 --> Config Class Initialized
INFO - 2023-05-26 03:18:02 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:02 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:02 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:02 --> URI Class Initialized
INFO - 2023-05-26 03:18:02 --> Router Class Initialized
INFO - 2023-05-26 03:18:02 --> Output Class Initialized
INFO - 2023-05-26 03:18:02 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:02 --> Input Class Initialized
INFO - 2023-05-26 03:18:02 --> Language Class Initialized
INFO - 2023-05-26 03:18:02 --> Loader Class Initialized
INFO - 2023-05-26 03:18:02 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:02 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:02 --> Model "Login_model" initialized
INFO - 2023-05-26 03:18:02 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:02 --> Total execution time: 0.0968
INFO - 2023-05-26 03:18:04 --> Config Class Initialized
INFO - 2023-05-26 03:18:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:04 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:04 --> URI Class Initialized
INFO - 2023-05-26 03:18:04 --> Router Class Initialized
INFO - 2023-05-26 03:18:04 --> Output Class Initialized
INFO - 2023-05-26 03:18:04 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:04 --> Input Class Initialized
INFO - 2023-05-26 03:18:04 --> Language Class Initialized
INFO - 2023-05-26 03:18:04 --> Loader Class Initialized
INFO - 2023-05-26 03:18:04 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:04 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:04 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:04 --> Total execution time: 0.0499
INFO - 2023-05-26 03:18:04 --> Config Class Initialized
INFO - 2023-05-26 03:18:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:04 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:04 --> URI Class Initialized
INFO - 2023-05-26 03:18:04 --> Router Class Initialized
INFO - 2023-05-26 03:18:04 --> Output Class Initialized
INFO - 2023-05-26 03:18:04 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:04 --> Input Class Initialized
INFO - 2023-05-26 03:18:04 --> Language Class Initialized
INFO - 2023-05-26 03:18:04 --> Loader Class Initialized
INFO - 2023-05-26 03:18:04 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:04 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:04 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:04 --> Total execution time: 0.0550
INFO - 2023-05-26 03:18:04 --> Config Class Initialized
INFO - 2023-05-26 03:18:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:04 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:04 --> URI Class Initialized
INFO - 2023-05-26 03:18:04 --> Router Class Initialized
INFO - 2023-05-26 03:18:04 --> Output Class Initialized
INFO - 2023-05-26 03:18:04 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:04 --> Input Class Initialized
INFO - 2023-05-26 03:18:04 --> Language Class Initialized
INFO - 2023-05-26 03:18:04 --> Loader Class Initialized
INFO - 2023-05-26 03:18:04 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:04 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:04 --> Total execution time: 0.0253
INFO - 2023-05-26 03:18:04 --> Config Class Initialized
INFO - 2023-05-26 03:18:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:04 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:04 --> URI Class Initialized
INFO - 2023-05-26 03:18:04 --> Router Class Initialized
INFO - 2023-05-26 03:18:04 --> Output Class Initialized
INFO - 2023-05-26 03:18:04 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:04 --> Input Class Initialized
INFO - 2023-05-26 03:18:04 --> Language Class Initialized
INFO - 2023-05-26 03:18:04 --> Loader Class Initialized
INFO - 2023-05-26 03:18:04 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:04 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:04 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:04 --> Total execution time: 0.0497
INFO - 2023-05-26 03:18:07 --> Config Class Initialized
INFO - 2023-05-26 03:18:07 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:07 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:07 --> URI Class Initialized
INFO - 2023-05-26 03:18:07 --> Router Class Initialized
INFO - 2023-05-26 03:18:07 --> Output Class Initialized
INFO - 2023-05-26 03:18:07 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:07 --> Input Class Initialized
INFO - 2023-05-26 03:18:07 --> Language Class Initialized
INFO - 2023-05-26 03:18:07 --> Loader Class Initialized
INFO - 2023-05-26 03:18:07 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:07 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:07 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:07 --> Total execution time: 0.0613
INFO - 2023-05-26 03:18:07 --> Config Class Initialized
INFO - 2023-05-26 03:18:07 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:07 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:07 --> URI Class Initialized
INFO - 2023-05-26 03:18:07 --> Router Class Initialized
INFO - 2023-05-26 03:18:07 --> Output Class Initialized
INFO - 2023-05-26 03:18:07 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:07 --> Input Class Initialized
INFO - 2023-05-26 03:18:07 --> Language Class Initialized
INFO - 2023-05-26 03:18:07 --> Loader Class Initialized
INFO - 2023-05-26 03:18:07 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:07 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:07 --> Total execution time: 0.0274
INFO - 2023-05-26 03:18:07 --> Config Class Initialized
INFO - 2023-05-26 03:18:07 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:07 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:07 --> URI Class Initialized
INFO - 2023-05-26 03:18:07 --> Router Class Initialized
INFO - 2023-05-26 03:18:07 --> Output Class Initialized
INFO - 2023-05-26 03:18:07 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:07 --> Input Class Initialized
INFO - 2023-05-26 03:18:07 --> Language Class Initialized
INFO - 2023-05-26 03:18:07 --> Loader Class Initialized
INFO - 2023-05-26 03:18:07 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:07 --> Model "Change_model" initialized
INFO - 2023-05-26 03:18:08 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:08 --> Total execution time: 1.0481
INFO - 2023-05-26 03:18:09 --> Config Class Initialized
INFO - 2023-05-26 03:18:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:09 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:09 --> URI Class Initialized
INFO - 2023-05-26 03:18:09 --> Router Class Initialized
INFO - 2023-05-26 03:18:09 --> Output Class Initialized
INFO - 2023-05-26 03:18:09 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:09 --> Input Class Initialized
INFO - 2023-05-26 03:18:09 --> Language Class Initialized
INFO - 2023-05-26 03:18:09 --> Loader Class Initialized
INFO - 2023-05-26 03:18:09 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:09 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:09 --> Total execution time: 0.0238
INFO - 2023-05-26 03:18:09 --> Config Class Initialized
INFO - 2023-05-26 03:18:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:09 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:09 --> URI Class Initialized
INFO - 2023-05-26 03:18:09 --> Router Class Initialized
INFO - 2023-05-26 03:18:09 --> Output Class Initialized
INFO - 2023-05-26 03:18:09 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:09 --> Input Class Initialized
INFO - 2023-05-26 03:18:09 --> Language Class Initialized
INFO - 2023-05-26 03:18:09 --> Loader Class Initialized
INFO - 2023-05-26 03:18:09 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:09 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:09 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:09 --> Total execution time: 0.0575
INFO - 2023-05-26 03:18:10 --> Config Class Initialized
INFO - 2023-05-26 03:18:10 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:10 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:10 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:10 --> URI Class Initialized
INFO - 2023-05-26 03:18:10 --> Router Class Initialized
INFO - 2023-05-26 03:18:10 --> Output Class Initialized
INFO - 2023-05-26 03:18:10 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:10 --> Input Class Initialized
INFO - 2023-05-26 03:18:10 --> Language Class Initialized
INFO - 2023-05-26 03:18:10 --> Loader Class Initialized
INFO - 2023-05-26 03:18:10 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:10 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:10 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:10 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:10 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:10 --> Total execution time: 0.0693
INFO - 2023-05-26 03:18:10 --> Config Class Initialized
INFO - 2023-05-26 03:18:10 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:10 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:10 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:10 --> URI Class Initialized
INFO - 2023-05-26 03:18:10 --> Router Class Initialized
INFO - 2023-05-26 03:18:10 --> Output Class Initialized
INFO - 2023-05-26 03:18:10 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:10 --> Input Class Initialized
INFO - 2023-05-26 03:18:10 --> Language Class Initialized
INFO - 2023-05-26 03:18:10 --> Loader Class Initialized
INFO - 2023-05-26 03:18:10 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:10 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:10 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:11 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:11 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:11 --> Total execution time: 0.0674
INFO - 2023-05-26 03:18:11 --> Config Class Initialized
INFO - 2023-05-26 03:18:11 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:11 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:11 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:11 --> URI Class Initialized
INFO - 2023-05-26 03:18:11 --> Router Class Initialized
INFO - 2023-05-26 03:18:11 --> Output Class Initialized
INFO - 2023-05-26 03:18:11 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:11 --> Input Class Initialized
INFO - 2023-05-26 03:18:11 --> Language Class Initialized
INFO - 2023-05-26 03:18:11 --> Loader Class Initialized
INFO - 2023-05-26 03:18:11 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:11 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:11 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:11 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:11 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:11 --> Total execution time: 0.0778
INFO - 2023-05-26 03:18:20 --> Config Class Initialized
INFO - 2023-05-26 03:18:20 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:20 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:20 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:20 --> URI Class Initialized
INFO - 2023-05-26 03:18:20 --> Router Class Initialized
INFO - 2023-05-26 03:18:20 --> Output Class Initialized
INFO - 2023-05-26 03:18:20 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:20 --> Input Class Initialized
INFO - 2023-05-26 03:18:20 --> Language Class Initialized
INFO - 2023-05-26 03:18:20 --> Loader Class Initialized
INFO - 2023-05-26 03:18:20 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:20 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:20 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:20 --> Total execution time: 0.0225
INFO - 2023-05-26 03:18:20 --> Config Class Initialized
INFO - 2023-05-26 03:18:20 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:20 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:20 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:20 --> URI Class Initialized
INFO - 2023-05-26 03:18:20 --> Router Class Initialized
INFO - 2023-05-26 03:18:20 --> Output Class Initialized
INFO - 2023-05-26 03:18:20 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:20 --> Input Class Initialized
INFO - 2023-05-26 03:18:20 --> Language Class Initialized
INFO - 2023-05-26 03:18:20 --> Loader Class Initialized
INFO - 2023-05-26 03:18:20 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:20 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:20 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:20 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:20 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:20 --> Total execution time: 0.1046
INFO - 2023-05-26 03:18:21 --> Config Class Initialized
INFO - 2023-05-26 03:18:21 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:21 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:21 --> URI Class Initialized
INFO - 2023-05-26 03:18:21 --> Router Class Initialized
INFO - 2023-05-26 03:18:21 --> Output Class Initialized
INFO - 2023-05-26 03:18:21 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:21 --> Input Class Initialized
INFO - 2023-05-26 03:18:21 --> Language Class Initialized
INFO - 2023-05-26 03:18:21 --> Loader Class Initialized
INFO - 2023-05-26 03:18:21 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:21 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:21 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:21 --> Total execution time: 0.0650
INFO - 2023-05-26 03:18:21 --> Config Class Initialized
INFO - 2023-05-26 03:18:21 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:21 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:21 --> URI Class Initialized
INFO - 2023-05-26 03:18:21 --> Router Class Initialized
INFO - 2023-05-26 03:18:21 --> Output Class Initialized
INFO - 2023-05-26 03:18:21 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:21 --> Input Class Initialized
INFO - 2023-05-26 03:18:21 --> Language Class Initialized
INFO - 2023-05-26 03:18:21 --> Loader Class Initialized
INFO - 2023-05-26 03:18:21 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:21 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:21 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:21 --> Total execution time: 0.0802
INFO - 2023-05-26 03:18:22 --> Config Class Initialized
INFO - 2023-05-26 03:18:22 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:22 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:22 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:22 --> URI Class Initialized
INFO - 2023-05-26 03:18:22 --> Router Class Initialized
INFO - 2023-05-26 03:18:22 --> Output Class Initialized
INFO - 2023-05-26 03:18:22 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:22 --> Input Class Initialized
INFO - 2023-05-26 03:18:22 --> Language Class Initialized
INFO - 2023-05-26 03:18:22 --> Loader Class Initialized
INFO - 2023-05-26 03:18:22 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:22 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:22 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:22 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:22 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:22 --> Total execution time: 0.0848
INFO - 2023-05-26 03:18:23 --> Config Class Initialized
INFO - 2023-05-26 03:18:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:23 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:23 --> URI Class Initialized
INFO - 2023-05-26 03:18:23 --> Router Class Initialized
INFO - 2023-05-26 03:18:23 --> Output Class Initialized
INFO - 2023-05-26 03:18:23 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:23 --> Input Class Initialized
INFO - 2023-05-26 03:18:23 --> Language Class Initialized
INFO - 2023-05-26 03:18:23 --> Loader Class Initialized
INFO - 2023-05-26 03:18:23 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:23 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:23 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:23 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:23 --> Total execution time: 0.0918
INFO - 2023-05-26 03:18:24 --> Config Class Initialized
INFO - 2023-05-26 03:18:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:24 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:24 --> URI Class Initialized
INFO - 2023-05-26 03:18:24 --> Router Class Initialized
INFO - 2023-05-26 03:18:24 --> Output Class Initialized
INFO - 2023-05-26 03:18:24 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:24 --> Input Class Initialized
INFO - 2023-05-26 03:18:24 --> Language Class Initialized
INFO - 2023-05-26 03:18:24 --> Loader Class Initialized
INFO - 2023-05-26 03:18:24 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:24 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:24 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:24 --> Total execution time: 0.0848
INFO - 2023-05-26 03:18:25 --> Config Class Initialized
INFO - 2023-05-26 03:18:25 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:25 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:25 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:25 --> URI Class Initialized
INFO - 2023-05-26 03:18:25 --> Router Class Initialized
INFO - 2023-05-26 03:18:25 --> Output Class Initialized
INFO - 2023-05-26 03:18:25 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:25 --> Input Class Initialized
INFO - 2023-05-26 03:18:25 --> Language Class Initialized
INFO - 2023-05-26 03:18:25 --> Loader Class Initialized
INFO - 2023-05-26 03:18:25 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:25 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:25 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:25 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:25 --> Total execution time: 0.0707
INFO - 2023-05-26 03:18:26 --> Config Class Initialized
INFO - 2023-05-26 03:18:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:26 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:26 --> URI Class Initialized
INFO - 2023-05-26 03:18:26 --> Router Class Initialized
INFO - 2023-05-26 03:18:26 --> Output Class Initialized
INFO - 2023-05-26 03:18:26 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:26 --> Input Class Initialized
INFO - 2023-05-26 03:18:26 --> Language Class Initialized
INFO - 2023-05-26 03:18:26 --> Loader Class Initialized
INFO - 2023-05-26 03:18:26 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:26 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:26 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:26 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:26 --> Total execution time: 0.0845
INFO - 2023-05-26 03:18:27 --> Config Class Initialized
INFO - 2023-05-26 03:18:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:27 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:27 --> URI Class Initialized
INFO - 2023-05-26 03:18:27 --> Router Class Initialized
INFO - 2023-05-26 03:18:27 --> Output Class Initialized
INFO - 2023-05-26 03:18:27 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:27 --> Input Class Initialized
INFO - 2023-05-26 03:18:27 --> Language Class Initialized
INFO - 2023-05-26 03:18:27 --> Loader Class Initialized
INFO - 2023-05-26 03:18:27 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:27 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:27 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:27 --> Total execution time: 0.0825
INFO - 2023-05-26 03:18:27 --> Config Class Initialized
INFO - 2023-05-26 03:18:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:27 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:27 --> URI Class Initialized
INFO - 2023-05-26 03:18:27 --> Router Class Initialized
INFO - 2023-05-26 03:18:27 --> Output Class Initialized
INFO - 2023-05-26 03:18:27 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:27 --> Input Class Initialized
INFO - 2023-05-26 03:18:27 --> Language Class Initialized
INFO - 2023-05-26 03:18:27 --> Loader Class Initialized
INFO - 2023-05-26 03:18:27 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:27 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:27 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:27 --> Total execution time: 0.0768
INFO - 2023-05-26 03:18:28 --> Config Class Initialized
INFO - 2023-05-26 03:18:28 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:28 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:28 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:28 --> URI Class Initialized
INFO - 2023-05-26 03:18:28 --> Router Class Initialized
INFO - 2023-05-26 03:18:28 --> Output Class Initialized
INFO - 2023-05-26 03:18:28 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:28 --> Input Class Initialized
INFO - 2023-05-26 03:18:28 --> Language Class Initialized
INFO - 2023-05-26 03:18:28 --> Loader Class Initialized
INFO - 2023-05-26 03:18:28 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:28 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:28 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:28 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:28 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:28 --> Total execution time: 0.0851
INFO - 2023-05-26 03:18:29 --> Config Class Initialized
INFO - 2023-05-26 03:18:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:29 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:29 --> URI Class Initialized
INFO - 2023-05-26 03:18:29 --> Router Class Initialized
INFO - 2023-05-26 03:18:29 --> Output Class Initialized
INFO - 2023-05-26 03:18:29 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:29 --> Input Class Initialized
INFO - 2023-05-26 03:18:29 --> Language Class Initialized
INFO - 2023-05-26 03:18:29 --> Loader Class Initialized
INFO - 2023-05-26 03:18:29 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:29 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:29 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:29 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:29 --> Total execution time: 0.0861
INFO - 2023-05-26 03:18:30 --> Config Class Initialized
INFO - 2023-05-26 03:18:30 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:30 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:30 --> URI Class Initialized
INFO - 2023-05-26 03:18:30 --> Router Class Initialized
INFO - 2023-05-26 03:18:30 --> Output Class Initialized
INFO - 2023-05-26 03:18:30 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:30 --> Input Class Initialized
INFO - 2023-05-26 03:18:30 --> Language Class Initialized
INFO - 2023-05-26 03:18:30 --> Loader Class Initialized
INFO - 2023-05-26 03:18:30 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:30 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:30 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:30 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:30 --> Total execution time: 0.0900
INFO - 2023-05-26 03:18:31 --> Config Class Initialized
INFO - 2023-05-26 03:18:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:31 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:31 --> URI Class Initialized
INFO - 2023-05-26 03:18:31 --> Router Class Initialized
INFO - 2023-05-26 03:18:31 --> Output Class Initialized
INFO - 2023-05-26 03:18:31 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:31 --> Input Class Initialized
INFO - 2023-05-26 03:18:31 --> Language Class Initialized
INFO - 2023-05-26 03:18:31 --> Loader Class Initialized
INFO - 2023-05-26 03:18:31 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:31 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:31 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:31 --> Total execution time: 0.0892
INFO - 2023-05-26 03:18:32 --> Config Class Initialized
INFO - 2023-05-26 03:18:32 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:32 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:32 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:32 --> URI Class Initialized
INFO - 2023-05-26 03:18:32 --> Router Class Initialized
INFO - 2023-05-26 03:18:32 --> Output Class Initialized
INFO - 2023-05-26 03:18:32 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:32 --> Input Class Initialized
INFO - 2023-05-26 03:18:32 --> Language Class Initialized
INFO - 2023-05-26 03:18:32 --> Loader Class Initialized
INFO - 2023-05-26 03:18:32 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:32 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:32 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:32 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:32 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:32 --> Total execution time: 0.0871
INFO - 2023-05-26 03:18:33 --> Config Class Initialized
INFO - 2023-05-26 03:18:33 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:33 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:33 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:33 --> URI Class Initialized
INFO - 2023-05-26 03:18:33 --> Router Class Initialized
INFO - 2023-05-26 03:18:33 --> Output Class Initialized
INFO - 2023-05-26 03:18:33 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:33 --> Input Class Initialized
INFO - 2023-05-26 03:18:33 --> Language Class Initialized
INFO - 2023-05-26 03:18:33 --> Loader Class Initialized
INFO - 2023-05-26 03:18:33 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:33 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:33 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:33 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:33 --> Total execution time: 0.0800
INFO - 2023-05-26 03:18:33 --> Config Class Initialized
INFO - 2023-05-26 03:18:33 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:33 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:33 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:33 --> URI Class Initialized
INFO - 2023-05-26 03:18:33 --> Router Class Initialized
INFO - 2023-05-26 03:18:33 --> Output Class Initialized
INFO - 2023-05-26 03:18:33 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:33 --> Input Class Initialized
INFO - 2023-05-26 03:18:33 --> Language Class Initialized
INFO - 2023-05-26 03:18:33 --> Loader Class Initialized
INFO - 2023-05-26 03:18:33 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:33 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:33 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:33 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:33 --> Total execution time: 0.0719
INFO - 2023-05-26 03:18:34 --> Config Class Initialized
INFO - 2023-05-26 03:18:34 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:34 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:34 --> URI Class Initialized
INFO - 2023-05-26 03:18:34 --> Router Class Initialized
INFO - 2023-05-26 03:18:34 --> Output Class Initialized
INFO - 2023-05-26 03:18:34 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:34 --> Input Class Initialized
INFO - 2023-05-26 03:18:34 --> Language Class Initialized
INFO - 2023-05-26 03:18:34 --> Loader Class Initialized
INFO - 2023-05-26 03:18:34 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:34 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:34 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:34 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:34 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:34 --> Total execution time: 0.0825
INFO - 2023-05-26 03:18:35 --> Config Class Initialized
INFO - 2023-05-26 03:18:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:35 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:35 --> URI Class Initialized
INFO - 2023-05-26 03:18:35 --> Router Class Initialized
INFO - 2023-05-26 03:18:35 --> Output Class Initialized
INFO - 2023-05-26 03:18:35 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:35 --> Input Class Initialized
INFO - 2023-05-26 03:18:35 --> Language Class Initialized
INFO - 2023-05-26 03:18:35 --> Loader Class Initialized
INFO - 2023-05-26 03:18:35 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:35 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:35 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:35 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:35 --> Total execution time: 0.0973
INFO - 2023-05-26 03:18:36 --> Config Class Initialized
INFO - 2023-05-26 03:18:36 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:36 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:36 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:36 --> URI Class Initialized
INFO - 2023-05-26 03:18:36 --> Router Class Initialized
INFO - 2023-05-26 03:18:36 --> Output Class Initialized
INFO - 2023-05-26 03:18:36 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:36 --> Input Class Initialized
INFO - 2023-05-26 03:18:36 --> Language Class Initialized
INFO - 2023-05-26 03:18:36 --> Loader Class Initialized
INFO - 2023-05-26 03:18:36 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:36 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:36 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:36 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:36 --> Total execution time: 0.0977
INFO - 2023-05-26 03:18:37 --> Config Class Initialized
INFO - 2023-05-26 03:18:37 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:37 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:37 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:37 --> URI Class Initialized
INFO - 2023-05-26 03:18:37 --> Router Class Initialized
INFO - 2023-05-26 03:18:37 --> Output Class Initialized
INFO - 2023-05-26 03:18:37 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:37 --> Input Class Initialized
INFO - 2023-05-26 03:18:37 --> Language Class Initialized
INFO - 2023-05-26 03:18:37 --> Loader Class Initialized
INFO - 2023-05-26 03:18:37 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:37 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:37 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:37 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:37 --> Total execution time: 0.0784
INFO - 2023-05-26 03:18:38 --> Config Class Initialized
INFO - 2023-05-26 03:18:38 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:38 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:38 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:38 --> URI Class Initialized
INFO - 2023-05-26 03:18:38 --> Router Class Initialized
INFO - 2023-05-26 03:18:38 --> Output Class Initialized
INFO - 2023-05-26 03:18:38 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:38 --> Input Class Initialized
INFO - 2023-05-26 03:18:38 --> Language Class Initialized
INFO - 2023-05-26 03:18:38 --> Loader Class Initialized
INFO - 2023-05-26 03:18:38 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:38 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:38 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:38 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:38 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:38 --> Total execution time: 0.0914
INFO - 2023-05-26 03:18:39 --> Config Class Initialized
INFO - 2023-05-26 03:18:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:39 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:39 --> URI Class Initialized
INFO - 2023-05-26 03:18:39 --> Router Class Initialized
INFO - 2023-05-26 03:18:39 --> Output Class Initialized
INFO - 2023-05-26 03:18:39 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:39 --> Input Class Initialized
INFO - 2023-05-26 03:18:39 --> Language Class Initialized
INFO - 2023-05-26 03:18:39 --> Loader Class Initialized
INFO - 2023-05-26 03:18:39 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:39 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:39 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:39 --> Total execution time: 0.0677
INFO - 2023-05-26 03:18:39 --> Config Class Initialized
INFO - 2023-05-26 03:18:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:39 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:39 --> URI Class Initialized
INFO - 2023-05-26 03:18:39 --> Router Class Initialized
INFO - 2023-05-26 03:18:39 --> Output Class Initialized
INFO - 2023-05-26 03:18:39 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:39 --> Input Class Initialized
INFO - 2023-05-26 03:18:39 --> Language Class Initialized
INFO - 2023-05-26 03:18:39 --> Loader Class Initialized
INFO - 2023-05-26 03:18:39 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:39 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:39 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:39 --> Total execution time: 0.0776
INFO - 2023-05-26 03:18:40 --> Config Class Initialized
INFO - 2023-05-26 03:18:40 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:40 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:40 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:40 --> URI Class Initialized
INFO - 2023-05-26 03:18:40 --> Router Class Initialized
INFO - 2023-05-26 03:18:40 --> Output Class Initialized
INFO - 2023-05-26 03:18:40 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:40 --> Input Class Initialized
INFO - 2023-05-26 03:18:40 --> Language Class Initialized
INFO - 2023-05-26 03:18:40 --> Loader Class Initialized
INFO - 2023-05-26 03:18:40 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:40 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:40 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:40 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:40 --> Total execution time: 0.0756
INFO - 2023-05-26 03:18:41 --> Config Class Initialized
INFO - 2023-05-26 03:18:41 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:41 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:41 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:41 --> URI Class Initialized
INFO - 2023-05-26 03:18:41 --> Router Class Initialized
INFO - 2023-05-26 03:18:41 --> Output Class Initialized
INFO - 2023-05-26 03:18:41 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:41 --> Input Class Initialized
INFO - 2023-05-26 03:18:41 --> Language Class Initialized
INFO - 2023-05-26 03:18:41 --> Loader Class Initialized
INFO - 2023-05-26 03:18:41 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:41 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:41 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:41 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:41 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:41 --> Total execution time: 0.1017
INFO - 2023-05-26 03:18:42 --> Config Class Initialized
INFO - 2023-05-26 03:18:42 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:42 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:42 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:42 --> URI Class Initialized
INFO - 2023-05-26 03:18:42 --> Router Class Initialized
INFO - 2023-05-26 03:18:42 --> Output Class Initialized
INFO - 2023-05-26 03:18:42 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:42 --> Input Class Initialized
INFO - 2023-05-26 03:18:42 --> Language Class Initialized
INFO - 2023-05-26 03:18:42 --> Loader Class Initialized
INFO - 2023-05-26 03:18:42 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:42 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:42 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:42 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:42 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:42 --> Total execution time: 0.0854
INFO - 2023-05-26 03:18:43 --> Config Class Initialized
INFO - 2023-05-26 03:18:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:43 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:43 --> URI Class Initialized
INFO - 2023-05-26 03:18:43 --> Router Class Initialized
INFO - 2023-05-26 03:18:43 --> Output Class Initialized
INFO - 2023-05-26 03:18:43 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:43 --> Input Class Initialized
INFO - 2023-05-26 03:18:43 --> Language Class Initialized
INFO - 2023-05-26 03:18:43 --> Loader Class Initialized
INFO - 2023-05-26 03:18:43 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:43 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:43 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:43 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:43 --> Total execution time: 0.0782
INFO - 2023-05-26 03:18:44 --> Config Class Initialized
INFO - 2023-05-26 03:18:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:44 --> URI Class Initialized
INFO - 2023-05-26 03:18:44 --> Router Class Initialized
INFO - 2023-05-26 03:18:44 --> Output Class Initialized
INFO - 2023-05-26 03:18:44 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:44 --> Input Class Initialized
INFO - 2023-05-26 03:18:44 --> Language Class Initialized
INFO - 2023-05-26 03:18:44 --> Loader Class Initialized
INFO - 2023-05-26 03:18:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:44 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:44 --> Total execution time: 0.0894
INFO - 2023-05-26 03:18:45 --> Config Class Initialized
INFO - 2023-05-26 03:18:45 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:45 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:45 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:45 --> URI Class Initialized
INFO - 2023-05-26 03:18:45 --> Router Class Initialized
INFO - 2023-05-26 03:18:45 --> Output Class Initialized
INFO - 2023-05-26 03:18:45 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:45 --> Input Class Initialized
INFO - 2023-05-26 03:18:45 --> Language Class Initialized
INFO - 2023-05-26 03:18:45 --> Loader Class Initialized
INFO - 2023-05-26 03:18:45 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:45 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:45 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:45 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:45 --> Total execution time: 0.0640
INFO - 2023-05-26 03:18:45 --> Config Class Initialized
INFO - 2023-05-26 03:18:45 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:45 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:45 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:45 --> URI Class Initialized
INFO - 2023-05-26 03:18:45 --> Router Class Initialized
INFO - 2023-05-26 03:18:45 --> Output Class Initialized
INFO - 2023-05-26 03:18:45 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:45 --> Input Class Initialized
INFO - 2023-05-26 03:18:45 --> Language Class Initialized
INFO - 2023-05-26 03:18:45 --> Loader Class Initialized
INFO - 2023-05-26 03:18:45 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:45 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:45 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:45 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:45 --> Total execution time: 0.1099
INFO - 2023-05-26 03:18:46 --> Config Class Initialized
INFO - 2023-05-26 03:18:46 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:46 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:46 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:46 --> URI Class Initialized
INFO - 2023-05-26 03:18:46 --> Router Class Initialized
INFO - 2023-05-26 03:18:46 --> Output Class Initialized
INFO - 2023-05-26 03:18:46 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:46 --> Input Class Initialized
INFO - 2023-05-26 03:18:46 --> Language Class Initialized
INFO - 2023-05-26 03:18:46 --> Loader Class Initialized
INFO - 2023-05-26 03:18:46 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:46 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:46 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:46 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:46 --> Total execution time: 0.0896
INFO - 2023-05-26 03:18:47 --> Config Class Initialized
INFO - 2023-05-26 03:18:47 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:47 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:47 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:47 --> URI Class Initialized
INFO - 2023-05-26 03:18:47 --> Router Class Initialized
INFO - 2023-05-26 03:18:47 --> Output Class Initialized
INFO - 2023-05-26 03:18:47 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:47 --> Input Class Initialized
INFO - 2023-05-26 03:18:47 --> Language Class Initialized
INFO - 2023-05-26 03:18:47 --> Loader Class Initialized
INFO - 2023-05-26 03:18:47 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:47 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:47 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:47 --> Total execution time: 0.0823
INFO - 2023-05-26 03:18:48 --> Config Class Initialized
INFO - 2023-05-26 03:18:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:48 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:48 --> URI Class Initialized
INFO - 2023-05-26 03:18:48 --> Router Class Initialized
INFO - 2023-05-26 03:18:48 --> Output Class Initialized
INFO - 2023-05-26 03:18:48 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:48 --> Input Class Initialized
INFO - 2023-05-26 03:18:48 --> Language Class Initialized
INFO - 2023-05-26 03:18:48 --> Loader Class Initialized
INFO - 2023-05-26 03:18:48 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:48 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:48 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:48 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:48 --> Total execution time: 0.0901
INFO - 2023-05-26 03:18:49 --> Config Class Initialized
INFO - 2023-05-26 03:18:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:49 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:49 --> URI Class Initialized
INFO - 2023-05-26 03:18:49 --> Router Class Initialized
INFO - 2023-05-26 03:18:49 --> Output Class Initialized
INFO - 2023-05-26 03:18:49 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:49 --> Input Class Initialized
INFO - 2023-05-26 03:18:49 --> Language Class Initialized
INFO - 2023-05-26 03:18:49 --> Loader Class Initialized
INFO - 2023-05-26 03:18:49 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:49 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:49 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:49 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:49 --> Total execution time: 0.0745
INFO - 2023-05-26 03:18:50 --> Config Class Initialized
INFO - 2023-05-26 03:18:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:50 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:50 --> URI Class Initialized
INFO - 2023-05-26 03:18:50 --> Router Class Initialized
INFO - 2023-05-26 03:18:50 --> Output Class Initialized
INFO - 2023-05-26 03:18:50 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:50 --> Input Class Initialized
INFO - 2023-05-26 03:18:50 --> Language Class Initialized
INFO - 2023-05-26 03:18:50 --> Loader Class Initialized
INFO - 2023-05-26 03:18:50 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:50 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:50 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:50 --> Total execution time: 0.0865
INFO - 2023-05-26 03:18:51 --> Config Class Initialized
INFO - 2023-05-26 03:18:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:51 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:51 --> URI Class Initialized
INFO - 2023-05-26 03:18:51 --> Router Class Initialized
INFO - 2023-05-26 03:18:51 --> Output Class Initialized
INFO - 2023-05-26 03:18:51 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:51 --> Input Class Initialized
INFO - 2023-05-26 03:18:51 --> Language Class Initialized
INFO - 2023-05-26 03:18:51 --> Loader Class Initialized
INFO - 2023-05-26 03:18:51 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:51 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:51 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:51 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:51 --> Total execution time: 0.0812
INFO - 2023-05-26 03:18:51 --> Config Class Initialized
INFO - 2023-05-26 03:18:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:51 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:51 --> URI Class Initialized
INFO - 2023-05-26 03:18:51 --> Router Class Initialized
INFO - 2023-05-26 03:18:51 --> Output Class Initialized
INFO - 2023-05-26 03:18:51 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:51 --> Input Class Initialized
INFO - 2023-05-26 03:18:51 --> Language Class Initialized
INFO - 2023-05-26 03:18:51 --> Loader Class Initialized
INFO - 2023-05-26 03:18:51 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:51 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:51 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:51 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:51 --> Total execution time: 0.0930
INFO - 2023-05-26 03:18:52 --> Config Class Initialized
INFO - 2023-05-26 03:18:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:52 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:52 --> URI Class Initialized
INFO - 2023-05-26 03:18:52 --> Router Class Initialized
INFO - 2023-05-26 03:18:52 --> Output Class Initialized
INFO - 2023-05-26 03:18:52 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:52 --> Input Class Initialized
INFO - 2023-05-26 03:18:52 --> Language Class Initialized
INFO - 2023-05-26 03:18:52 --> Loader Class Initialized
INFO - 2023-05-26 03:18:52 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:52 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:52 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:52 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:52 --> Total execution time: 0.0872
INFO - 2023-05-26 03:18:53 --> Config Class Initialized
INFO - 2023-05-26 03:18:53 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:53 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:53 --> URI Class Initialized
INFO - 2023-05-26 03:18:53 --> Router Class Initialized
INFO - 2023-05-26 03:18:53 --> Output Class Initialized
INFO - 2023-05-26 03:18:53 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:53 --> Input Class Initialized
INFO - 2023-05-26 03:18:53 --> Language Class Initialized
INFO - 2023-05-26 03:18:53 --> Loader Class Initialized
INFO - 2023-05-26 03:18:53 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:53 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:53 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:53 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:53 --> Total execution time: 0.0707
INFO - 2023-05-26 03:18:54 --> Config Class Initialized
INFO - 2023-05-26 03:18:54 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:54 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:54 --> URI Class Initialized
INFO - 2023-05-26 03:18:54 --> Router Class Initialized
INFO - 2023-05-26 03:18:54 --> Output Class Initialized
INFO - 2023-05-26 03:18:54 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:54 --> Input Class Initialized
INFO - 2023-05-26 03:18:54 --> Language Class Initialized
INFO - 2023-05-26 03:18:54 --> Loader Class Initialized
INFO - 2023-05-26 03:18:54 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:54 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:54 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:54 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:54 --> Total execution time: 0.0537
INFO - 2023-05-26 03:18:55 --> Config Class Initialized
INFO - 2023-05-26 03:18:55 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:55 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:55 --> URI Class Initialized
INFO - 2023-05-26 03:18:55 --> Router Class Initialized
INFO - 2023-05-26 03:18:55 --> Output Class Initialized
INFO - 2023-05-26 03:18:55 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:55 --> Input Class Initialized
INFO - 2023-05-26 03:18:55 --> Language Class Initialized
INFO - 2023-05-26 03:18:55 --> Loader Class Initialized
INFO - 2023-05-26 03:18:55 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:55 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:55 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:55 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:55 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:55 --> Total execution time: 0.1003
INFO - 2023-05-26 03:18:56 --> Config Class Initialized
INFO - 2023-05-26 03:18:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:56 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:56 --> URI Class Initialized
INFO - 2023-05-26 03:18:56 --> Router Class Initialized
INFO - 2023-05-26 03:18:56 --> Output Class Initialized
INFO - 2023-05-26 03:18:56 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:56 --> Input Class Initialized
INFO - 2023-05-26 03:18:56 --> Language Class Initialized
INFO - 2023-05-26 03:18:56 --> Loader Class Initialized
INFO - 2023-05-26 03:18:56 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:56 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:56 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:56 --> Total execution time: 0.0854
INFO - 2023-05-26 03:18:57 --> Config Class Initialized
INFO - 2023-05-26 03:18:57 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:57 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:57 --> URI Class Initialized
INFO - 2023-05-26 03:18:57 --> Router Class Initialized
INFO - 2023-05-26 03:18:57 --> Output Class Initialized
INFO - 2023-05-26 03:18:57 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:57 --> Input Class Initialized
INFO - 2023-05-26 03:18:57 --> Language Class Initialized
INFO - 2023-05-26 03:18:57 --> Loader Class Initialized
INFO - 2023-05-26 03:18:57 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:57 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:57 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:57 --> Total execution time: 0.0768
INFO - 2023-05-26 03:18:57 --> Config Class Initialized
INFO - 2023-05-26 03:18:57 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:57 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:57 --> URI Class Initialized
INFO - 2023-05-26 03:18:57 --> Router Class Initialized
INFO - 2023-05-26 03:18:57 --> Output Class Initialized
INFO - 2023-05-26 03:18:57 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:57 --> Input Class Initialized
INFO - 2023-05-26 03:18:57 --> Language Class Initialized
INFO - 2023-05-26 03:18:57 --> Loader Class Initialized
INFO - 2023-05-26 03:18:57 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:57 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:57 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:57 --> Total execution time: 0.0726
INFO - 2023-05-26 03:18:58 --> Config Class Initialized
INFO - 2023-05-26 03:18:58 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:58 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:58 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:58 --> URI Class Initialized
INFO - 2023-05-26 03:18:58 --> Router Class Initialized
INFO - 2023-05-26 03:18:58 --> Output Class Initialized
INFO - 2023-05-26 03:18:58 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:58 --> Input Class Initialized
INFO - 2023-05-26 03:18:58 --> Language Class Initialized
INFO - 2023-05-26 03:18:58 --> Loader Class Initialized
INFO - 2023-05-26 03:18:58 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:58 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:58 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:58 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:58 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:58 --> Total execution time: 0.0878
INFO - 2023-05-26 03:18:59 --> Config Class Initialized
INFO - 2023-05-26 03:18:59 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:18:59 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:18:59 --> Utf8 Class Initialized
INFO - 2023-05-26 03:18:59 --> URI Class Initialized
INFO - 2023-05-26 03:18:59 --> Router Class Initialized
INFO - 2023-05-26 03:18:59 --> Output Class Initialized
INFO - 2023-05-26 03:18:59 --> Security Class Initialized
DEBUG - 2023-05-26 03:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:18:59 --> Input Class Initialized
INFO - 2023-05-26 03:18:59 --> Language Class Initialized
INFO - 2023-05-26 03:18:59 --> Loader Class Initialized
INFO - 2023-05-26 03:18:59 --> Controller Class Initialized
DEBUG - 2023-05-26 03:18:59 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:18:59 --> Database Driver Class Initialized
INFO - 2023-05-26 03:18:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:18:59 --> Final output sent to browser
DEBUG - 2023-05-26 03:18:59 --> Total execution time: 0.0772
INFO - 2023-05-26 03:19:00 --> Config Class Initialized
INFO - 2023-05-26 03:19:00 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:00 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:00 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:00 --> URI Class Initialized
INFO - 2023-05-26 03:19:00 --> Router Class Initialized
INFO - 2023-05-26 03:19:00 --> Output Class Initialized
INFO - 2023-05-26 03:19:00 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:00 --> Input Class Initialized
INFO - 2023-05-26 03:19:00 --> Language Class Initialized
INFO - 2023-05-26 03:19:00 --> Loader Class Initialized
INFO - 2023-05-26 03:19:00 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:00 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:00 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:00 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:00 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:00 --> Total execution time: 0.0848
INFO - 2023-05-26 03:19:01 --> Config Class Initialized
INFO - 2023-05-26 03:19:01 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:01 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:01 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:01 --> URI Class Initialized
INFO - 2023-05-26 03:19:01 --> Router Class Initialized
INFO - 2023-05-26 03:19:01 --> Output Class Initialized
INFO - 2023-05-26 03:19:01 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:01 --> Input Class Initialized
INFO - 2023-05-26 03:19:01 --> Language Class Initialized
INFO - 2023-05-26 03:19:01 --> Loader Class Initialized
INFO - 2023-05-26 03:19:01 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:01 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:01 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:01 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:01 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:01 --> Total execution time: 0.0934
INFO - 2023-05-26 03:19:02 --> Config Class Initialized
INFO - 2023-05-26 03:19:02 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:02 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:02 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:02 --> URI Class Initialized
INFO - 2023-05-26 03:19:02 --> Router Class Initialized
INFO - 2023-05-26 03:19:02 --> Output Class Initialized
INFO - 2023-05-26 03:19:02 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:02 --> Input Class Initialized
INFO - 2023-05-26 03:19:02 --> Language Class Initialized
INFO - 2023-05-26 03:19:02 --> Loader Class Initialized
INFO - 2023-05-26 03:19:02 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:02 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:02 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:02 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:02 --> Total execution time: 0.0683
INFO - 2023-05-26 03:19:03 --> Config Class Initialized
INFO - 2023-05-26 03:19:03 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:03 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:03 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:03 --> URI Class Initialized
INFO - 2023-05-26 03:19:03 --> Router Class Initialized
INFO - 2023-05-26 03:19:03 --> Output Class Initialized
INFO - 2023-05-26 03:19:03 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:03 --> Input Class Initialized
INFO - 2023-05-26 03:19:03 --> Language Class Initialized
INFO - 2023-05-26 03:19:03 --> Loader Class Initialized
INFO - 2023-05-26 03:19:03 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:03 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:03 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:03 --> Total execution time: 0.0582
INFO - 2023-05-26 03:19:03 --> Config Class Initialized
INFO - 2023-05-26 03:19:03 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:03 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:03 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:03 --> URI Class Initialized
INFO - 2023-05-26 03:19:03 --> Router Class Initialized
INFO - 2023-05-26 03:19:03 --> Output Class Initialized
INFO - 2023-05-26 03:19:03 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:03 --> Input Class Initialized
INFO - 2023-05-26 03:19:03 --> Language Class Initialized
INFO - 2023-05-26 03:19:03 --> Loader Class Initialized
INFO - 2023-05-26 03:19:03 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:03 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:03 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:03 --> Total execution time: 0.0652
INFO - 2023-05-26 03:19:04 --> Config Class Initialized
INFO - 2023-05-26 03:19:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:04 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:04 --> URI Class Initialized
INFO - 2023-05-26 03:19:04 --> Router Class Initialized
INFO - 2023-05-26 03:19:04 --> Output Class Initialized
INFO - 2023-05-26 03:19:04 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:04 --> Input Class Initialized
INFO - 2023-05-26 03:19:04 --> Language Class Initialized
INFO - 2023-05-26 03:19:04 --> Loader Class Initialized
INFO - 2023-05-26 03:19:04 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:04 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:04 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:04 --> Total execution time: 0.0911
INFO - 2023-05-26 03:19:05 --> Config Class Initialized
INFO - 2023-05-26 03:19:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:05 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:05 --> URI Class Initialized
INFO - 2023-05-26 03:19:05 --> Router Class Initialized
INFO - 2023-05-26 03:19:05 --> Output Class Initialized
INFO - 2023-05-26 03:19:05 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:05 --> Input Class Initialized
INFO - 2023-05-26 03:19:05 --> Language Class Initialized
INFO - 2023-05-26 03:19:05 --> Loader Class Initialized
INFO - 2023-05-26 03:19:05 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:05 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:05 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:05 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:05 --> Total execution time: 0.0811
INFO - 2023-05-26 03:19:06 --> Config Class Initialized
INFO - 2023-05-26 03:19:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:06 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:06 --> URI Class Initialized
INFO - 2023-05-26 03:19:06 --> Router Class Initialized
INFO - 2023-05-26 03:19:06 --> Output Class Initialized
INFO - 2023-05-26 03:19:06 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:06 --> Input Class Initialized
INFO - 2023-05-26 03:19:06 --> Language Class Initialized
INFO - 2023-05-26 03:19:06 --> Loader Class Initialized
INFO - 2023-05-26 03:19:06 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:06 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:06 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:06 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:06 --> Total execution time: 0.0737
INFO - 2023-05-26 03:19:07 --> Config Class Initialized
INFO - 2023-05-26 03:19:07 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:07 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:07 --> URI Class Initialized
INFO - 2023-05-26 03:19:07 --> Router Class Initialized
INFO - 2023-05-26 03:19:07 --> Output Class Initialized
INFO - 2023-05-26 03:19:07 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:07 --> Input Class Initialized
INFO - 2023-05-26 03:19:07 --> Language Class Initialized
INFO - 2023-05-26 03:19:07 --> Loader Class Initialized
INFO - 2023-05-26 03:19:07 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:07 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:07 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:07 --> Total execution time: 0.0855
INFO - 2023-05-26 03:19:08 --> Config Class Initialized
INFO - 2023-05-26 03:19:08 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:08 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:08 --> URI Class Initialized
INFO - 2023-05-26 03:19:08 --> Router Class Initialized
INFO - 2023-05-26 03:19:08 --> Output Class Initialized
INFO - 2023-05-26 03:19:08 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:08 --> Input Class Initialized
INFO - 2023-05-26 03:19:08 --> Language Class Initialized
INFO - 2023-05-26 03:19:08 --> Loader Class Initialized
INFO - 2023-05-26 03:19:08 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:08 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:08 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:08 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:08 --> Total execution time: 0.0871
INFO - 2023-05-26 03:19:09 --> Config Class Initialized
INFO - 2023-05-26 03:19:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:09 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:09 --> URI Class Initialized
INFO - 2023-05-26 03:19:09 --> Router Class Initialized
INFO - 2023-05-26 03:19:09 --> Output Class Initialized
INFO - 2023-05-26 03:19:09 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:09 --> Input Class Initialized
INFO - 2023-05-26 03:19:09 --> Language Class Initialized
INFO - 2023-05-26 03:19:09 --> Loader Class Initialized
INFO - 2023-05-26 03:19:09 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:09 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:09 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:09 --> Total execution time: 0.0639
INFO - 2023-05-26 03:19:09 --> Config Class Initialized
INFO - 2023-05-26 03:19:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:09 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:09 --> URI Class Initialized
INFO - 2023-05-26 03:19:09 --> Router Class Initialized
INFO - 2023-05-26 03:19:09 --> Output Class Initialized
INFO - 2023-05-26 03:19:09 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:09 --> Input Class Initialized
INFO - 2023-05-26 03:19:09 --> Language Class Initialized
INFO - 2023-05-26 03:19:09 --> Loader Class Initialized
INFO - 2023-05-26 03:19:09 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:09 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:09 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:09 --> Total execution time: 0.0750
INFO - 2023-05-26 03:19:10 --> Config Class Initialized
INFO - 2023-05-26 03:19:10 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:10 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:10 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:10 --> URI Class Initialized
INFO - 2023-05-26 03:19:10 --> Router Class Initialized
INFO - 2023-05-26 03:19:10 --> Output Class Initialized
INFO - 2023-05-26 03:19:10 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:10 --> Input Class Initialized
INFO - 2023-05-26 03:19:10 --> Language Class Initialized
INFO - 2023-05-26 03:19:10 --> Loader Class Initialized
INFO - 2023-05-26 03:19:10 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:10 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:10 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:10 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:10 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:10 --> Total execution time: 0.0870
INFO - 2023-05-26 03:19:11 --> Config Class Initialized
INFO - 2023-05-26 03:19:11 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:11 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:11 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:11 --> URI Class Initialized
INFO - 2023-05-26 03:19:11 --> Router Class Initialized
INFO - 2023-05-26 03:19:11 --> Output Class Initialized
INFO - 2023-05-26 03:19:11 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:11 --> Input Class Initialized
INFO - 2023-05-26 03:19:11 --> Language Class Initialized
INFO - 2023-05-26 03:19:11 --> Loader Class Initialized
INFO - 2023-05-26 03:19:11 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:11 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:11 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:11 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:11 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:11 --> Total execution time: 0.1011
INFO - 2023-05-26 03:19:12 --> Config Class Initialized
INFO - 2023-05-26 03:19:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:12 --> URI Class Initialized
INFO - 2023-05-26 03:19:12 --> Router Class Initialized
INFO - 2023-05-26 03:19:12 --> Output Class Initialized
INFO - 2023-05-26 03:19:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:12 --> Input Class Initialized
INFO - 2023-05-26 03:19:12 --> Language Class Initialized
INFO - 2023-05-26 03:19:12 --> Loader Class Initialized
INFO - 2023-05-26 03:19:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:12 --> Total execution time: 0.0818
INFO - 2023-05-26 03:19:13 --> Config Class Initialized
INFO - 2023-05-26 03:19:13 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:13 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:13 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:13 --> URI Class Initialized
INFO - 2023-05-26 03:19:13 --> Router Class Initialized
INFO - 2023-05-26 03:19:13 --> Output Class Initialized
INFO - 2023-05-26 03:19:13 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:13 --> Input Class Initialized
INFO - 2023-05-26 03:19:13 --> Language Class Initialized
INFO - 2023-05-26 03:19:13 --> Loader Class Initialized
INFO - 2023-05-26 03:19:13 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:13 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:13 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:13 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:13 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:13 --> Total execution time: 0.0854
INFO - 2023-05-26 03:19:14 --> Config Class Initialized
INFO - 2023-05-26 03:19:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:14 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:14 --> URI Class Initialized
INFO - 2023-05-26 03:19:14 --> Router Class Initialized
INFO - 2023-05-26 03:19:14 --> Output Class Initialized
INFO - 2023-05-26 03:19:14 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:14 --> Input Class Initialized
INFO - 2023-05-26 03:19:14 --> Language Class Initialized
INFO - 2023-05-26 03:19:14 --> Loader Class Initialized
INFO - 2023-05-26 03:19:14 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:14 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:14 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:14 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:14 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:14 --> Total execution time: 0.0634
INFO - 2023-05-26 03:19:15 --> Config Class Initialized
INFO - 2023-05-26 03:19:15 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:15 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:15 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:15 --> URI Class Initialized
INFO - 2023-05-26 03:19:15 --> Router Class Initialized
INFO - 2023-05-26 03:19:15 --> Output Class Initialized
INFO - 2023-05-26 03:19:15 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:15 --> Input Class Initialized
INFO - 2023-05-26 03:19:15 --> Language Class Initialized
INFO - 2023-05-26 03:19:15 --> Loader Class Initialized
INFO - 2023-05-26 03:19:15 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:15 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:15 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:15 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:15 --> Total execution time: 0.0582
INFO - 2023-05-26 03:19:15 --> Config Class Initialized
INFO - 2023-05-26 03:19:15 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:15 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:15 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:15 --> URI Class Initialized
INFO - 2023-05-26 03:19:15 --> Router Class Initialized
INFO - 2023-05-26 03:19:15 --> Output Class Initialized
INFO - 2023-05-26 03:19:15 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:15 --> Input Class Initialized
INFO - 2023-05-26 03:19:15 --> Language Class Initialized
INFO - 2023-05-26 03:19:15 --> Loader Class Initialized
INFO - 2023-05-26 03:19:15 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:15 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:15 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:15 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:15 --> Total execution time: 0.0656
INFO - 2023-05-26 03:19:16 --> Config Class Initialized
INFO - 2023-05-26 03:19:16 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:16 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:16 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:16 --> URI Class Initialized
INFO - 2023-05-26 03:19:16 --> Router Class Initialized
INFO - 2023-05-26 03:19:16 --> Output Class Initialized
INFO - 2023-05-26 03:19:16 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:16 --> Input Class Initialized
INFO - 2023-05-26 03:19:16 --> Language Class Initialized
INFO - 2023-05-26 03:19:16 --> Loader Class Initialized
INFO - 2023-05-26 03:19:16 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:16 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:16 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:16 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:16 --> Total execution time: 0.0668
INFO - 2023-05-26 03:19:17 --> Config Class Initialized
INFO - 2023-05-26 03:19:17 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:17 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:17 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:17 --> URI Class Initialized
INFO - 2023-05-26 03:19:17 --> Router Class Initialized
INFO - 2023-05-26 03:19:17 --> Output Class Initialized
INFO - 2023-05-26 03:19:17 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:17 --> Input Class Initialized
INFO - 2023-05-26 03:19:17 --> Language Class Initialized
INFO - 2023-05-26 03:19:17 --> Loader Class Initialized
INFO - 2023-05-26 03:19:17 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:17 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:17 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:17 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:17 --> Total execution time: 0.0854
INFO - 2023-05-26 03:19:18 --> Config Class Initialized
INFO - 2023-05-26 03:19:18 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:18 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:18 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:18 --> URI Class Initialized
INFO - 2023-05-26 03:19:18 --> Router Class Initialized
INFO - 2023-05-26 03:19:18 --> Output Class Initialized
INFO - 2023-05-26 03:19:18 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:18 --> Input Class Initialized
INFO - 2023-05-26 03:19:18 --> Language Class Initialized
INFO - 2023-05-26 03:19:18 --> Loader Class Initialized
INFO - 2023-05-26 03:19:18 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:18 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:18 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:18 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:18 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:18 --> Total execution time: 0.0775
INFO - 2023-05-26 03:19:19 --> Config Class Initialized
INFO - 2023-05-26 03:19:19 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:19 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:19 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:19 --> URI Class Initialized
INFO - 2023-05-26 03:19:19 --> Router Class Initialized
INFO - 2023-05-26 03:19:19 --> Output Class Initialized
INFO - 2023-05-26 03:19:19 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:19 --> Input Class Initialized
INFO - 2023-05-26 03:19:19 --> Language Class Initialized
INFO - 2023-05-26 03:19:19 --> Loader Class Initialized
INFO - 2023-05-26 03:19:19 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:19 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:19 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:19 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:19 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:19 --> Total execution time: 0.0856
INFO - 2023-05-26 03:19:20 --> Config Class Initialized
INFO - 2023-05-26 03:19:20 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:20 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:20 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:20 --> URI Class Initialized
INFO - 2023-05-26 03:19:20 --> Router Class Initialized
INFO - 2023-05-26 03:19:20 --> Output Class Initialized
INFO - 2023-05-26 03:19:20 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:20 --> Input Class Initialized
INFO - 2023-05-26 03:19:20 --> Language Class Initialized
INFO - 2023-05-26 03:19:20 --> Loader Class Initialized
INFO - 2023-05-26 03:19:20 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:20 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:20 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:20 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:20 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:20 --> Total execution time: 0.0864
INFO - 2023-05-26 03:19:21 --> Config Class Initialized
INFO - 2023-05-26 03:19:21 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:21 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:21 --> URI Class Initialized
INFO - 2023-05-26 03:19:21 --> Router Class Initialized
INFO - 2023-05-26 03:19:21 --> Output Class Initialized
INFO - 2023-05-26 03:19:21 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:21 --> Input Class Initialized
INFO - 2023-05-26 03:19:21 --> Language Class Initialized
INFO - 2023-05-26 03:19:21 --> Loader Class Initialized
INFO - 2023-05-26 03:19:21 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:21 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:21 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:21 --> Total execution time: 0.0574
INFO - 2023-05-26 03:19:21 --> Config Class Initialized
INFO - 2023-05-26 03:19:21 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:21 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:21 --> URI Class Initialized
INFO - 2023-05-26 03:19:21 --> Router Class Initialized
INFO - 2023-05-26 03:19:21 --> Output Class Initialized
INFO - 2023-05-26 03:19:21 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:21 --> Input Class Initialized
INFO - 2023-05-26 03:19:21 --> Language Class Initialized
INFO - 2023-05-26 03:19:21 --> Loader Class Initialized
INFO - 2023-05-26 03:19:21 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:21 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:21 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:21 --> Total execution time: 0.0491
INFO - 2023-05-26 03:19:22 --> Config Class Initialized
INFO - 2023-05-26 03:19:22 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:22 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:22 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:22 --> URI Class Initialized
INFO - 2023-05-26 03:19:22 --> Router Class Initialized
INFO - 2023-05-26 03:19:22 --> Output Class Initialized
INFO - 2023-05-26 03:19:22 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:22 --> Input Class Initialized
INFO - 2023-05-26 03:19:22 --> Language Class Initialized
INFO - 2023-05-26 03:19:22 --> Loader Class Initialized
INFO - 2023-05-26 03:19:22 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:22 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:22 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:22 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:22 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:22 --> Total execution time: 0.0862
INFO - 2023-05-26 03:19:23 --> Config Class Initialized
INFO - 2023-05-26 03:19:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:23 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:23 --> URI Class Initialized
INFO - 2023-05-26 03:19:23 --> Router Class Initialized
INFO - 2023-05-26 03:19:23 --> Output Class Initialized
INFO - 2023-05-26 03:19:23 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:23 --> Input Class Initialized
INFO - 2023-05-26 03:19:23 --> Language Class Initialized
INFO - 2023-05-26 03:19:23 --> Loader Class Initialized
INFO - 2023-05-26 03:19:23 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:23 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:23 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:23 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:23 --> Total execution time: 0.0846
INFO - 2023-05-26 03:19:24 --> Config Class Initialized
INFO - 2023-05-26 03:19:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:24 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:24 --> URI Class Initialized
INFO - 2023-05-26 03:19:24 --> Router Class Initialized
INFO - 2023-05-26 03:19:24 --> Output Class Initialized
INFO - 2023-05-26 03:19:24 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:24 --> Input Class Initialized
INFO - 2023-05-26 03:19:24 --> Language Class Initialized
INFO - 2023-05-26 03:19:24 --> Loader Class Initialized
INFO - 2023-05-26 03:19:24 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:24 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:24 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:24 --> Total execution time: 0.0852
INFO - 2023-05-26 03:19:25 --> Config Class Initialized
INFO - 2023-05-26 03:19:25 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:25 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:25 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:25 --> URI Class Initialized
INFO - 2023-05-26 03:19:25 --> Router Class Initialized
INFO - 2023-05-26 03:19:25 --> Output Class Initialized
INFO - 2023-05-26 03:19:25 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:25 --> Input Class Initialized
INFO - 2023-05-26 03:19:25 --> Language Class Initialized
INFO - 2023-05-26 03:19:25 --> Loader Class Initialized
INFO - 2023-05-26 03:19:25 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:25 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:25 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:25 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:25 --> Total execution time: 0.0689
INFO - 2023-05-26 03:19:26 --> Config Class Initialized
INFO - 2023-05-26 03:19:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:26 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:26 --> URI Class Initialized
INFO - 2023-05-26 03:19:26 --> Router Class Initialized
INFO - 2023-05-26 03:19:26 --> Output Class Initialized
INFO - 2023-05-26 03:19:26 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:26 --> Input Class Initialized
INFO - 2023-05-26 03:19:26 --> Language Class Initialized
INFO - 2023-05-26 03:19:26 --> Loader Class Initialized
INFO - 2023-05-26 03:19:26 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:26 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:26 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:26 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:26 --> Total execution time: 0.0881
INFO - 2023-05-26 03:19:27 --> Config Class Initialized
INFO - 2023-05-26 03:19:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:27 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:27 --> URI Class Initialized
INFO - 2023-05-26 03:19:27 --> Router Class Initialized
INFO - 2023-05-26 03:19:27 --> Output Class Initialized
INFO - 2023-05-26 03:19:27 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:27 --> Input Class Initialized
INFO - 2023-05-26 03:19:27 --> Language Class Initialized
INFO - 2023-05-26 03:19:27 --> Loader Class Initialized
INFO - 2023-05-26 03:19:27 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:27 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:27 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:27 --> Total execution time: 0.0726
INFO - 2023-05-26 03:19:27 --> Config Class Initialized
INFO - 2023-05-26 03:19:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:27 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:27 --> URI Class Initialized
INFO - 2023-05-26 03:19:27 --> Router Class Initialized
INFO - 2023-05-26 03:19:27 --> Output Class Initialized
INFO - 2023-05-26 03:19:27 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:27 --> Input Class Initialized
INFO - 2023-05-26 03:19:27 --> Language Class Initialized
INFO - 2023-05-26 03:19:27 --> Loader Class Initialized
INFO - 2023-05-26 03:19:27 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:27 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:27 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:27 --> Total execution time: 0.0996
INFO - 2023-05-26 03:19:28 --> Config Class Initialized
INFO - 2023-05-26 03:19:28 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:28 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:28 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:28 --> URI Class Initialized
INFO - 2023-05-26 03:19:28 --> Router Class Initialized
INFO - 2023-05-26 03:19:28 --> Output Class Initialized
INFO - 2023-05-26 03:19:28 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:28 --> Input Class Initialized
INFO - 2023-05-26 03:19:28 --> Language Class Initialized
INFO - 2023-05-26 03:19:28 --> Loader Class Initialized
INFO - 2023-05-26 03:19:28 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:28 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:28 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:28 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:28 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:28 --> Total execution time: 0.0784
INFO - 2023-05-26 03:19:29 --> Config Class Initialized
INFO - 2023-05-26 03:19:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:29 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:29 --> URI Class Initialized
INFO - 2023-05-26 03:19:29 --> Router Class Initialized
INFO - 2023-05-26 03:19:29 --> Output Class Initialized
INFO - 2023-05-26 03:19:29 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:29 --> Input Class Initialized
INFO - 2023-05-26 03:19:29 --> Language Class Initialized
INFO - 2023-05-26 03:19:29 --> Loader Class Initialized
INFO - 2023-05-26 03:19:29 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:29 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:29 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:29 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:29 --> Total execution time: 0.0872
INFO - 2023-05-26 03:19:30 --> Config Class Initialized
INFO - 2023-05-26 03:19:30 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:30 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:30 --> URI Class Initialized
INFO - 2023-05-26 03:19:30 --> Router Class Initialized
INFO - 2023-05-26 03:19:30 --> Output Class Initialized
INFO - 2023-05-26 03:19:30 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:30 --> Input Class Initialized
INFO - 2023-05-26 03:19:30 --> Language Class Initialized
INFO - 2023-05-26 03:19:30 --> Loader Class Initialized
INFO - 2023-05-26 03:19:30 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:30 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:30 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:30 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:30 --> Total execution time: 0.0863
INFO - 2023-05-26 03:19:31 --> Config Class Initialized
INFO - 2023-05-26 03:19:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:31 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:31 --> URI Class Initialized
INFO - 2023-05-26 03:19:31 --> Router Class Initialized
INFO - 2023-05-26 03:19:31 --> Output Class Initialized
INFO - 2023-05-26 03:19:31 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:31 --> Input Class Initialized
INFO - 2023-05-26 03:19:31 --> Language Class Initialized
INFO - 2023-05-26 03:19:31 --> Loader Class Initialized
INFO - 2023-05-26 03:19:31 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:31 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:31 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:31 --> Total execution time: 0.0710
INFO - 2023-05-26 03:19:32 --> Config Class Initialized
INFO - 2023-05-26 03:19:32 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:32 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:32 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:32 --> URI Class Initialized
INFO - 2023-05-26 03:19:32 --> Router Class Initialized
INFO - 2023-05-26 03:19:32 --> Output Class Initialized
INFO - 2023-05-26 03:19:32 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:32 --> Input Class Initialized
INFO - 2023-05-26 03:19:32 --> Language Class Initialized
INFO - 2023-05-26 03:19:32 --> Loader Class Initialized
INFO - 2023-05-26 03:19:32 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:32 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:32 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:32 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:32 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:32 --> Total execution time: 0.0832
INFO - 2023-05-26 03:19:33 --> Config Class Initialized
INFO - 2023-05-26 03:19:33 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:33 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:33 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:33 --> URI Class Initialized
INFO - 2023-05-26 03:19:33 --> Router Class Initialized
INFO - 2023-05-26 03:19:33 --> Output Class Initialized
INFO - 2023-05-26 03:19:33 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:33 --> Input Class Initialized
INFO - 2023-05-26 03:19:33 --> Language Class Initialized
INFO - 2023-05-26 03:19:33 --> Loader Class Initialized
INFO - 2023-05-26 03:19:33 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:33 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:33 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:33 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:33 --> Total execution time: 0.0431
INFO - 2023-05-26 03:19:33 --> Config Class Initialized
INFO - 2023-05-26 03:19:33 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:33 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:33 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:33 --> URI Class Initialized
INFO - 2023-05-26 03:19:33 --> Router Class Initialized
INFO - 2023-05-26 03:19:33 --> Output Class Initialized
INFO - 2023-05-26 03:19:33 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:33 --> Input Class Initialized
INFO - 2023-05-26 03:19:33 --> Language Class Initialized
INFO - 2023-05-26 03:19:33 --> Loader Class Initialized
INFO - 2023-05-26 03:19:33 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:33 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:33 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:33 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:33 --> Total execution time: 0.0931
INFO - 2023-05-26 03:19:34 --> Config Class Initialized
INFO - 2023-05-26 03:19:34 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:34 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:34 --> URI Class Initialized
INFO - 2023-05-26 03:19:34 --> Router Class Initialized
INFO - 2023-05-26 03:19:34 --> Output Class Initialized
INFO - 2023-05-26 03:19:34 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:34 --> Input Class Initialized
INFO - 2023-05-26 03:19:34 --> Language Class Initialized
INFO - 2023-05-26 03:19:34 --> Loader Class Initialized
INFO - 2023-05-26 03:19:34 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:34 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:34 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:34 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:34 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:34 --> Total execution time: 0.0858
INFO - 2023-05-26 03:19:35 --> Config Class Initialized
INFO - 2023-05-26 03:19:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:35 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:35 --> URI Class Initialized
INFO - 2023-05-26 03:19:35 --> Router Class Initialized
INFO - 2023-05-26 03:19:35 --> Output Class Initialized
INFO - 2023-05-26 03:19:35 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:35 --> Input Class Initialized
INFO - 2023-05-26 03:19:35 --> Language Class Initialized
INFO - 2023-05-26 03:19:35 --> Loader Class Initialized
INFO - 2023-05-26 03:19:35 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:35 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:35 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:35 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:35 --> Total execution time: 0.0889
INFO - 2023-05-26 03:19:36 --> Config Class Initialized
INFO - 2023-05-26 03:19:36 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:36 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:36 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:36 --> URI Class Initialized
INFO - 2023-05-26 03:19:36 --> Router Class Initialized
INFO - 2023-05-26 03:19:36 --> Output Class Initialized
INFO - 2023-05-26 03:19:36 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:36 --> Input Class Initialized
INFO - 2023-05-26 03:19:36 --> Language Class Initialized
INFO - 2023-05-26 03:19:36 --> Loader Class Initialized
INFO - 2023-05-26 03:19:36 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:36 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:36 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:36 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:36 --> Total execution time: 0.0888
INFO - 2023-05-26 03:19:37 --> Config Class Initialized
INFO - 2023-05-26 03:19:37 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:37 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:37 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:37 --> URI Class Initialized
INFO - 2023-05-26 03:19:37 --> Router Class Initialized
INFO - 2023-05-26 03:19:37 --> Output Class Initialized
INFO - 2023-05-26 03:19:37 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:37 --> Input Class Initialized
INFO - 2023-05-26 03:19:37 --> Language Class Initialized
INFO - 2023-05-26 03:19:37 --> Loader Class Initialized
INFO - 2023-05-26 03:19:37 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:37 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:37 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:37 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:37 --> Total execution time: 0.0898
INFO - 2023-05-26 03:19:38 --> Config Class Initialized
INFO - 2023-05-26 03:19:38 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:38 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:38 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:38 --> URI Class Initialized
INFO - 2023-05-26 03:19:38 --> Router Class Initialized
INFO - 2023-05-26 03:19:38 --> Output Class Initialized
INFO - 2023-05-26 03:19:38 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:38 --> Input Class Initialized
INFO - 2023-05-26 03:19:38 --> Language Class Initialized
INFO - 2023-05-26 03:19:38 --> Loader Class Initialized
INFO - 2023-05-26 03:19:38 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:38 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:38 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:38 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:38 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:38 --> Total execution time: 0.1350
INFO - 2023-05-26 03:19:39 --> Config Class Initialized
INFO - 2023-05-26 03:19:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:39 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:39 --> URI Class Initialized
INFO - 2023-05-26 03:19:39 --> Router Class Initialized
INFO - 2023-05-26 03:19:39 --> Output Class Initialized
INFO - 2023-05-26 03:19:39 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:39 --> Input Class Initialized
INFO - 2023-05-26 03:19:39 --> Language Class Initialized
INFO - 2023-05-26 03:19:39 --> Loader Class Initialized
INFO - 2023-05-26 03:19:39 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:39 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:39 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:39 --> Total execution time: 0.0577
INFO - 2023-05-26 03:19:39 --> Config Class Initialized
INFO - 2023-05-26 03:19:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:39 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:39 --> URI Class Initialized
INFO - 2023-05-26 03:19:39 --> Router Class Initialized
INFO - 2023-05-26 03:19:39 --> Output Class Initialized
INFO - 2023-05-26 03:19:39 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:39 --> Input Class Initialized
INFO - 2023-05-26 03:19:39 --> Language Class Initialized
INFO - 2023-05-26 03:19:39 --> Loader Class Initialized
INFO - 2023-05-26 03:19:39 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:39 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:39 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:39 --> Total execution time: 0.0521
INFO - 2023-05-26 03:19:40 --> Config Class Initialized
INFO - 2023-05-26 03:19:40 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:40 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:40 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:40 --> URI Class Initialized
INFO - 2023-05-26 03:19:40 --> Router Class Initialized
INFO - 2023-05-26 03:19:40 --> Output Class Initialized
INFO - 2023-05-26 03:19:40 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:40 --> Input Class Initialized
INFO - 2023-05-26 03:19:40 --> Language Class Initialized
INFO - 2023-05-26 03:19:40 --> Loader Class Initialized
INFO - 2023-05-26 03:19:40 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:40 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:40 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:40 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:40 --> Total execution time: 0.0945
INFO - 2023-05-26 03:19:41 --> Config Class Initialized
INFO - 2023-05-26 03:19:41 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:41 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:41 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:41 --> URI Class Initialized
INFO - 2023-05-26 03:19:41 --> Router Class Initialized
INFO - 2023-05-26 03:19:41 --> Output Class Initialized
INFO - 2023-05-26 03:19:41 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:41 --> Input Class Initialized
INFO - 2023-05-26 03:19:41 --> Language Class Initialized
INFO - 2023-05-26 03:19:41 --> Loader Class Initialized
INFO - 2023-05-26 03:19:41 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:41 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:41 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:41 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:41 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:41 --> Total execution time: 0.0886
INFO - 2023-05-26 03:19:42 --> Config Class Initialized
INFO - 2023-05-26 03:19:42 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:42 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:42 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:42 --> URI Class Initialized
INFO - 2023-05-26 03:19:42 --> Router Class Initialized
INFO - 2023-05-26 03:19:42 --> Output Class Initialized
INFO - 2023-05-26 03:19:42 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:42 --> Input Class Initialized
INFO - 2023-05-26 03:19:42 --> Language Class Initialized
INFO - 2023-05-26 03:19:42 --> Loader Class Initialized
INFO - 2023-05-26 03:19:42 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:42 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:42 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:42 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:42 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:42 --> Total execution time: 0.0631
INFO - 2023-05-26 03:19:43 --> Config Class Initialized
INFO - 2023-05-26 03:19:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:43 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:43 --> URI Class Initialized
INFO - 2023-05-26 03:19:43 --> Router Class Initialized
INFO - 2023-05-26 03:19:43 --> Output Class Initialized
INFO - 2023-05-26 03:19:43 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:43 --> Input Class Initialized
INFO - 2023-05-26 03:19:43 --> Language Class Initialized
INFO - 2023-05-26 03:19:43 --> Loader Class Initialized
INFO - 2023-05-26 03:19:43 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:43 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:43 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:43 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:43 --> Total execution time: 0.0843
INFO - 2023-05-26 03:19:44 --> Config Class Initialized
INFO - 2023-05-26 03:19:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:44 --> URI Class Initialized
INFO - 2023-05-26 03:19:44 --> Router Class Initialized
INFO - 2023-05-26 03:19:44 --> Output Class Initialized
INFO - 2023-05-26 03:19:44 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:44 --> Input Class Initialized
INFO - 2023-05-26 03:19:44 --> Language Class Initialized
INFO - 2023-05-26 03:19:44 --> Loader Class Initialized
INFO - 2023-05-26 03:19:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:44 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:44 --> Total execution time: 0.0623
INFO - 2023-05-26 03:19:45 --> Config Class Initialized
INFO - 2023-05-26 03:19:45 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:45 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:45 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:45 --> URI Class Initialized
INFO - 2023-05-26 03:19:45 --> Router Class Initialized
INFO - 2023-05-26 03:19:45 --> Output Class Initialized
INFO - 2023-05-26 03:19:45 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:45 --> Input Class Initialized
INFO - 2023-05-26 03:19:45 --> Language Class Initialized
INFO - 2023-05-26 03:19:45 --> Loader Class Initialized
INFO - 2023-05-26 03:19:45 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:45 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:45 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:45 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:45 --> Total execution time: 0.0621
INFO - 2023-05-26 03:19:45 --> Config Class Initialized
INFO - 2023-05-26 03:19:45 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:45 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:45 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:45 --> URI Class Initialized
INFO - 2023-05-26 03:19:45 --> Router Class Initialized
INFO - 2023-05-26 03:19:45 --> Output Class Initialized
INFO - 2023-05-26 03:19:45 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:45 --> Input Class Initialized
INFO - 2023-05-26 03:19:45 --> Language Class Initialized
INFO - 2023-05-26 03:19:45 --> Loader Class Initialized
INFO - 2023-05-26 03:19:45 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:45 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:45 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:45 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:45 --> Total execution time: 0.0950
INFO - 2023-05-26 03:19:46 --> Config Class Initialized
INFO - 2023-05-26 03:19:46 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:46 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:46 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:46 --> URI Class Initialized
INFO - 2023-05-26 03:19:46 --> Router Class Initialized
INFO - 2023-05-26 03:19:46 --> Output Class Initialized
INFO - 2023-05-26 03:19:46 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:46 --> Input Class Initialized
INFO - 2023-05-26 03:19:46 --> Language Class Initialized
INFO - 2023-05-26 03:19:46 --> Loader Class Initialized
INFO - 2023-05-26 03:19:46 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:46 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:46 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:46 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:46 --> Total execution time: 0.0806
INFO - 2023-05-26 03:19:47 --> Config Class Initialized
INFO - 2023-05-26 03:19:47 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:47 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:47 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:47 --> URI Class Initialized
INFO - 2023-05-26 03:19:47 --> Router Class Initialized
INFO - 2023-05-26 03:19:47 --> Output Class Initialized
INFO - 2023-05-26 03:19:47 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:47 --> Input Class Initialized
INFO - 2023-05-26 03:19:47 --> Language Class Initialized
INFO - 2023-05-26 03:19:47 --> Loader Class Initialized
INFO - 2023-05-26 03:19:47 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:47 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:47 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:47 --> Total execution time: 0.0730
INFO - 2023-05-26 03:19:48 --> Config Class Initialized
INFO - 2023-05-26 03:19:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:48 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:48 --> URI Class Initialized
INFO - 2023-05-26 03:19:48 --> Router Class Initialized
INFO - 2023-05-26 03:19:48 --> Output Class Initialized
INFO - 2023-05-26 03:19:48 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:48 --> Input Class Initialized
INFO - 2023-05-26 03:19:48 --> Language Class Initialized
INFO - 2023-05-26 03:19:48 --> Loader Class Initialized
INFO - 2023-05-26 03:19:48 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:48 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:48 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:48 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:48 --> Total execution time: 0.0849
INFO - 2023-05-26 03:19:49 --> Config Class Initialized
INFO - 2023-05-26 03:19:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:49 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:49 --> URI Class Initialized
INFO - 2023-05-26 03:19:49 --> Router Class Initialized
INFO - 2023-05-26 03:19:49 --> Output Class Initialized
INFO - 2023-05-26 03:19:49 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:49 --> Input Class Initialized
INFO - 2023-05-26 03:19:49 --> Language Class Initialized
INFO - 2023-05-26 03:19:49 --> Loader Class Initialized
INFO - 2023-05-26 03:19:49 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:49 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:49 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:49 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:49 --> Total execution time: 0.0879
INFO - 2023-05-26 03:19:50 --> Config Class Initialized
INFO - 2023-05-26 03:19:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:50 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:50 --> URI Class Initialized
INFO - 2023-05-26 03:19:50 --> Router Class Initialized
INFO - 2023-05-26 03:19:50 --> Output Class Initialized
INFO - 2023-05-26 03:19:50 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:50 --> Input Class Initialized
INFO - 2023-05-26 03:19:50 --> Language Class Initialized
INFO - 2023-05-26 03:19:50 --> Loader Class Initialized
INFO - 2023-05-26 03:19:50 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:50 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:50 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:50 --> Total execution time: 0.1017
INFO - 2023-05-26 03:19:51 --> Config Class Initialized
INFO - 2023-05-26 03:19:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:51 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:51 --> URI Class Initialized
INFO - 2023-05-26 03:19:51 --> Router Class Initialized
INFO - 2023-05-26 03:19:51 --> Output Class Initialized
INFO - 2023-05-26 03:19:51 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:51 --> Input Class Initialized
INFO - 2023-05-26 03:19:51 --> Language Class Initialized
INFO - 2023-05-26 03:19:51 --> Loader Class Initialized
INFO - 2023-05-26 03:19:51 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:51 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:51 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:51 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:51 --> Total execution time: 0.0583
INFO - 2023-05-26 03:19:51 --> Config Class Initialized
INFO - 2023-05-26 03:19:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:51 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:51 --> URI Class Initialized
INFO - 2023-05-26 03:19:51 --> Router Class Initialized
INFO - 2023-05-26 03:19:51 --> Output Class Initialized
INFO - 2023-05-26 03:19:51 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:51 --> Input Class Initialized
INFO - 2023-05-26 03:19:51 --> Language Class Initialized
INFO - 2023-05-26 03:19:51 --> Loader Class Initialized
INFO - 2023-05-26 03:19:51 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:51 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:51 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:51 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:51 --> Total execution time: 0.0498
INFO - 2023-05-26 03:19:52 --> Config Class Initialized
INFO - 2023-05-26 03:19:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:52 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:52 --> URI Class Initialized
INFO - 2023-05-26 03:19:52 --> Router Class Initialized
INFO - 2023-05-26 03:19:52 --> Output Class Initialized
INFO - 2023-05-26 03:19:52 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:52 --> Input Class Initialized
INFO - 2023-05-26 03:19:52 --> Language Class Initialized
INFO - 2023-05-26 03:19:52 --> Loader Class Initialized
INFO - 2023-05-26 03:19:52 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:52 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:52 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:52 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:52 --> Total execution time: 0.0860
INFO - 2023-05-26 03:19:53 --> Config Class Initialized
INFO - 2023-05-26 03:19:53 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:53 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:53 --> URI Class Initialized
INFO - 2023-05-26 03:19:53 --> Router Class Initialized
INFO - 2023-05-26 03:19:53 --> Output Class Initialized
INFO - 2023-05-26 03:19:53 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:53 --> Input Class Initialized
INFO - 2023-05-26 03:19:53 --> Language Class Initialized
INFO - 2023-05-26 03:19:53 --> Loader Class Initialized
INFO - 2023-05-26 03:19:53 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:53 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:53 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:53 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:53 --> Total execution time: 0.0989
INFO - 2023-05-26 03:19:54 --> Config Class Initialized
INFO - 2023-05-26 03:19:54 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:54 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:54 --> URI Class Initialized
INFO - 2023-05-26 03:19:54 --> Router Class Initialized
INFO - 2023-05-26 03:19:54 --> Output Class Initialized
INFO - 2023-05-26 03:19:54 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:54 --> Input Class Initialized
INFO - 2023-05-26 03:19:54 --> Language Class Initialized
INFO - 2023-05-26 03:19:54 --> Loader Class Initialized
INFO - 2023-05-26 03:19:54 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:54 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:54 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:54 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:54 --> Total execution time: 0.0656
INFO - 2023-05-26 03:19:55 --> Config Class Initialized
INFO - 2023-05-26 03:19:55 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:55 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:55 --> URI Class Initialized
INFO - 2023-05-26 03:19:55 --> Router Class Initialized
INFO - 2023-05-26 03:19:55 --> Output Class Initialized
INFO - 2023-05-26 03:19:55 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:55 --> Input Class Initialized
INFO - 2023-05-26 03:19:55 --> Language Class Initialized
INFO - 2023-05-26 03:19:55 --> Loader Class Initialized
INFO - 2023-05-26 03:19:55 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:55 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:55 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:55 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:55 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:55 --> Total execution time: 0.0622
INFO - 2023-05-26 03:19:56 --> Config Class Initialized
INFO - 2023-05-26 03:19:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:56 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:56 --> URI Class Initialized
INFO - 2023-05-26 03:19:56 --> Router Class Initialized
INFO - 2023-05-26 03:19:56 --> Output Class Initialized
INFO - 2023-05-26 03:19:56 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:56 --> Input Class Initialized
INFO - 2023-05-26 03:19:56 --> Language Class Initialized
INFO - 2023-05-26 03:19:56 --> Loader Class Initialized
INFO - 2023-05-26 03:19:56 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:56 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:56 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:56 --> Total execution time: 0.0693
INFO - 2023-05-26 03:19:57 --> Config Class Initialized
INFO - 2023-05-26 03:19:57 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:57 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:57 --> URI Class Initialized
INFO - 2023-05-26 03:19:57 --> Router Class Initialized
INFO - 2023-05-26 03:19:57 --> Output Class Initialized
INFO - 2023-05-26 03:19:57 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:57 --> Input Class Initialized
INFO - 2023-05-26 03:19:57 --> Language Class Initialized
INFO - 2023-05-26 03:19:57 --> Loader Class Initialized
INFO - 2023-05-26 03:19:57 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:57 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:57 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:57 --> Total execution time: 0.0608
INFO - 2023-05-26 03:19:57 --> Config Class Initialized
INFO - 2023-05-26 03:19:57 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:57 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:57 --> URI Class Initialized
INFO - 2023-05-26 03:19:57 --> Router Class Initialized
INFO - 2023-05-26 03:19:57 --> Output Class Initialized
INFO - 2023-05-26 03:19:57 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:57 --> Input Class Initialized
INFO - 2023-05-26 03:19:57 --> Language Class Initialized
INFO - 2023-05-26 03:19:57 --> Loader Class Initialized
INFO - 2023-05-26 03:19:57 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:57 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:57 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:57 --> Total execution time: 0.0839
INFO - 2023-05-26 03:19:58 --> Config Class Initialized
INFO - 2023-05-26 03:19:58 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:58 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:58 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:58 --> URI Class Initialized
INFO - 2023-05-26 03:19:58 --> Router Class Initialized
INFO - 2023-05-26 03:19:58 --> Output Class Initialized
INFO - 2023-05-26 03:19:58 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:58 --> Input Class Initialized
INFO - 2023-05-26 03:19:58 --> Language Class Initialized
INFO - 2023-05-26 03:19:58 --> Loader Class Initialized
INFO - 2023-05-26 03:19:58 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:58 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:58 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:58 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:58 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:58 --> Total execution time: 0.0639
INFO - 2023-05-26 03:19:59 --> Config Class Initialized
INFO - 2023-05-26 03:19:59 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:19:59 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:19:59 --> Utf8 Class Initialized
INFO - 2023-05-26 03:19:59 --> URI Class Initialized
INFO - 2023-05-26 03:19:59 --> Router Class Initialized
INFO - 2023-05-26 03:19:59 --> Output Class Initialized
INFO - 2023-05-26 03:19:59 --> Security Class Initialized
DEBUG - 2023-05-26 03:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:19:59 --> Input Class Initialized
INFO - 2023-05-26 03:19:59 --> Language Class Initialized
INFO - 2023-05-26 03:19:59 --> Loader Class Initialized
INFO - 2023-05-26 03:19:59 --> Controller Class Initialized
DEBUG - 2023-05-26 03:19:59 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:19:59 --> Database Driver Class Initialized
INFO - 2023-05-26 03:19:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:19:59 --> Final output sent to browser
DEBUG - 2023-05-26 03:19:59 --> Total execution time: 0.0841
INFO - 2023-05-26 03:20:00 --> Config Class Initialized
INFO - 2023-05-26 03:20:00 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:00 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:00 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:00 --> URI Class Initialized
INFO - 2023-05-26 03:20:00 --> Router Class Initialized
INFO - 2023-05-26 03:20:00 --> Output Class Initialized
INFO - 2023-05-26 03:20:00 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:00 --> Input Class Initialized
INFO - 2023-05-26 03:20:00 --> Language Class Initialized
INFO - 2023-05-26 03:20:00 --> Loader Class Initialized
INFO - 2023-05-26 03:20:00 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:00 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:00 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:00 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:00 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:00 --> Total execution time: 0.0894
INFO - 2023-05-26 03:20:01 --> Config Class Initialized
INFO - 2023-05-26 03:20:01 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:01 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:01 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:01 --> URI Class Initialized
INFO - 2023-05-26 03:20:01 --> Router Class Initialized
INFO - 2023-05-26 03:20:01 --> Output Class Initialized
INFO - 2023-05-26 03:20:01 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:01 --> Input Class Initialized
INFO - 2023-05-26 03:20:01 --> Language Class Initialized
INFO - 2023-05-26 03:20:01 --> Loader Class Initialized
INFO - 2023-05-26 03:20:01 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:01 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:01 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:01 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:01 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:01 --> Total execution time: 0.0859
INFO - 2023-05-26 03:20:02 --> Config Class Initialized
INFO - 2023-05-26 03:20:02 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:02 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:02 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:02 --> URI Class Initialized
INFO - 2023-05-26 03:20:02 --> Router Class Initialized
INFO - 2023-05-26 03:20:02 --> Output Class Initialized
INFO - 2023-05-26 03:20:02 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:02 --> Input Class Initialized
INFO - 2023-05-26 03:20:02 --> Language Class Initialized
INFO - 2023-05-26 03:20:02 --> Loader Class Initialized
INFO - 2023-05-26 03:20:02 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:02 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:02 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:02 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:02 --> Total execution time: 0.0862
INFO - 2023-05-26 03:20:03 --> Config Class Initialized
INFO - 2023-05-26 03:20:03 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:03 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:03 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:03 --> URI Class Initialized
INFO - 2023-05-26 03:20:03 --> Router Class Initialized
INFO - 2023-05-26 03:20:03 --> Output Class Initialized
INFO - 2023-05-26 03:20:03 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:03 --> Input Class Initialized
INFO - 2023-05-26 03:20:03 --> Language Class Initialized
INFO - 2023-05-26 03:20:03 --> Loader Class Initialized
INFO - 2023-05-26 03:20:03 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:03 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:03 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:03 --> Total execution time: 0.0539
INFO - 2023-05-26 03:20:03 --> Config Class Initialized
INFO - 2023-05-26 03:20:03 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:03 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:03 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:03 --> URI Class Initialized
INFO - 2023-05-26 03:20:03 --> Router Class Initialized
INFO - 2023-05-26 03:20:03 --> Output Class Initialized
INFO - 2023-05-26 03:20:03 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:03 --> Input Class Initialized
INFO - 2023-05-26 03:20:03 --> Language Class Initialized
INFO - 2023-05-26 03:20:03 --> Loader Class Initialized
INFO - 2023-05-26 03:20:03 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:03 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:03 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:03 --> Total execution time: 0.0836
INFO - 2023-05-26 03:20:04 --> Config Class Initialized
INFO - 2023-05-26 03:20:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:04 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:04 --> URI Class Initialized
INFO - 2023-05-26 03:20:04 --> Router Class Initialized
INFO - 2023-05-26 03:20:04 --> Output Class Initialized
INFO - 2023-05-26 03:20:04 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:04 --> Input Class Initialized
INFO - 2023-05-26 03:20:04 --> Language Class Initialized
INFO - 2023-05-26 03:20:04 --> Loader Class Initialized
INFO - 2023-05-26 03:20:04 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:04 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:04 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:04 --> Total execution time: 0.0836
INFO - 2023-05-26 03:20:05 --> Config Class Initialized
INFO - 2023-05-26 03:20:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:05 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:05 --> URI Class Initialized
INFO - 2023-05-26 03:20:05 --> Router Class Initialized
INFO - 2023-05-26 03:20:05 --> Output Class Initialized
INFO - 2023-05-26 03:20:05 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:05 --> Input Class Initialized
INFO - 2023-05-26 03:20:05 --> Language Class Initialized
INFO - 2023-05-26 03:20:05 --> Loader Class Initialized
INFO - 2023-05-26 03:20:05 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:05 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:05 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:05 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:05 --> Total execution time: 0.0758
INFO - 2023-05-26 03:20:06 --> Config Class Initialized
INFO - 2023-05-26 03:20:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:06 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:06 --> URI Class Initialized
INFO - 2023-05-26 03:20:06 --> Router Class Initialized
INFO - 2023-05-26 03:20:06 --> Output Class Initialized
INFO - 2023-05-26 03:20:06 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:06 --> Input Class Initialized
INFO - 2023-05-26 03:20:06 --> Language Class Initialized
INFO - 2023-05-26 03:20:06 --> Loader Class Initialized
INFO - 2023-05-26 03:20:06 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:06 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:06 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:06 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:06 --> Total execution time: 0.0642
INFO - 2023-05-26 03:20:07 --> Config Class Initialized
INFO - 2023-05-26 03:20:07 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:07 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:07 --> URI Class Initialized
INFO - 2023-05-26 03:20:07 --> Router Class Initialized
INFO - 2023-05-26 03:20:07 --> Output Class Initialized
INFO - 2023-05-26 03:20:07 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:07 --> Input Class Initialized
INFO - 2023-05-26 03:20:07 --> Language Class Initialized
INFO - 2023-05-26 03:20:07 --> Loader Class Initialized
INFO - 2023-05-26 03:20:07 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:07 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:07 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:07 --> Total execution time: 0.0820
INFO - 2023-05-26 03:20:08 --> Config Class Initialized
INFO - 2023-05-26 03:20:08 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:08 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:08 --> URI Class Initialized
INFO - 2023-05-26 03:20:08 --> Router Class Initialized
INFO - 2023-05-26 03:20:08 --> Output Class Initialized
INFO - 2023-05-26 03:20:08 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:08 --> Input Class Initialized
INFO - 2023-05-26 03:20:08 --> Language Class Initialized
INFO - 2023-05-26 03:20:08 --> Loader Class Initialized
INFO - 2023-05-26 03:20:08 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:08 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:08 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:08 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:08 --> Total execution time: 0.0857
INFO - 2023-05-26 03:20:09 --> Config Class Initialized
INFO - 2023-05-26 03:20:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:09 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:09 --> URI Class Initialized
INFO - 2023-05-26 03:20:09 --> Router Class Initialized
INFO - 2023-05-26 03:20:09 --> Output Class Initialized
INFO - 2023-05-26 03:20:09 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:09 --> Input Class Initialized
INFO - 2023-05-26 03:20:09 --> Language Class Initialized
INFO - 2023-05-26 03:20:09 --> Loader Class Initialized
INFO - 2023-05-26 03:20:09 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:09 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:09 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:09 --> Total execution time: 0.0595
INFO - 2023-05-26 03:20:09 --> Config Class Initialized
INFO - 2023-05-26 03:20:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:09 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:09 --> URI Class Initialized
INFO - 2023-05-26 03:20:09 --> Router Class Initialized
INFO - 2023-05-26 03:20:09 --> Output Class Initialized
INFO - 2023-05-26 03:20:09 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:09 --> Input Class Initialized
INFO - 2023-05-26 03:20:09 --> Language Class Initialized
INFO - 2023-05-26 03:20:09 --> Loader Class Initialized
INFO - 2023-05-26 03:20:09 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:09 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:09 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:09 --> Total execution time: 0.0826
INFO - 2023-05-26 03:20:10 --> Config Class Initialized
INFO - 2023-05-26 03:20:10 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:10 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:10 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:10 --> URI Class Initialized
INFO - 2023-05-26 03:20:10 --> Router Class Initialized
INFO - 2023-05-26 03:20:10 --> Output Class Initialized
INFO - 2023-05-26 03:20:10 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:10 --> Input Class Initialized
INFO - 2023-05-26 03:20:10 --> Language Class Initialized
INFO - 2023-05-26 03:20:10 --> Loader Class Initialized
INFO - 2023-05-26 03:20:10 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:10 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:10 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:10 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:10 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:10 --> Total execution time: 0.0715
INFO - 2023-05-26 03:20:11 --> Config Class Initialized
INFO - 2023-05-26 03:20:11 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:11 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:11 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:11 --> URI Class Initialized
INFO - 2023-05-26 03:20:11 --> Router Class Initialized
INFO - 2023-05-26 03:20:11 --> Output Class Initialized
INFO - 2023-05-26 03:20:11 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:11 --> Input Class Initialized
INFO - 2023-05-26 03:20:11 --> Language Class Initialized
INFO - 2023-05-26 03:20:11 --> Loader Class Initialized
INFO - 2023-05-26 03:20:11 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:11 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:11 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:11 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:11 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:11 --> Total execution time: 0.0871
INFO - 2023-05-26 03:20:12 --> Config Class Initialized
INFO - 2023-05-26 03:20:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:12 --> URI Class Initialized
INFO - 2023-05-26 03:20:12 --> Router Class Initialized
INFO - 2023-05-26 03:20:12 --> Output Class Initialized
INFO - 2023-05-26 03:20:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:12 --> Input Class Initialized
INFO - 2023-05-26 03:20:12 --> Language Class Initialized
INFO - 2023-05-26 03:20:12 --> Loader Class Initialized
INFO - 2023-05-26 03:20:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:12 --> Total execution time: 0.0877
INFO - 2023-05-26 03:20:12 --> Config Class Initialized
INFO - 2023-05-26 03:20:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:12 --> URI Class Initialized
INFO - 2023-05-26 03:20:12 --> Router Class Initialized
INFO - 2023-05-26 03:20:12 --> Output Class Initialized
INFO - 2023-05-26 03:20:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:12 --> Input Class Initialized
INFO - 2023-05-26 03:20:12 --> Language Class Initialized
INFO - 2023-05-26 03:20:12 --> Loader Class Initialized
INFO - 2023-05-26 03:20:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:12 --> Model "Login_model" initialized
INFO - 2023-05-26 03:20:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:12 --> Total execution time: 0.1079
INFO - 2023-05-26 03:20:12 --> Config Class Initialized
INFO - 2023-05-26 03:20:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:12 --> URI Class Initialized
INFO - 2023-05-26 03:20:12 --> Router Class Initialized
INFO - 2023-05-26 03:20:12 --> Output Class Initialized
INFO - 2023-05-26 03:20:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:12 --> Input Class Initialized
INFO - 2023-05-26 03:20:12 --> Language Class Initialized
INFO - 2023-05-26 03:20:12 --> Loader Class Initialized
INFO - 2023-05-26 03:20:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:12 --> Model "Login_model" initialized
INFO - 2023-05-26 03:20:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:12 --> Total execution time: 0.1016
INFO - 2023-05-26 03:20:12 --> Config Class Initialized
INFO - 2023-05-26 03:20:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:12 --> URI Class Initialized
INFO - 2023-05-26 03:20:12 --> Router Class Initialized
INFO - 2023-05-26 03:20:12 --> Output Class Initialized
INFO - 2023-05-26 03:20:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:12 --> Input Class Initialized
INFO - 2023-05-26 03:20:12 --> Language Class Initialized
INFO - 2023-05-26 03:20:12 --> Loader Class Initialized
INFO - 2023-05-26 03:20:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:12 --> Total execution time: 0.0239
INFO - 2023-05-26 03:20:12 --> Config Class Initialized
INFO - 2023-05-26 03:20:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:12 --> URI Class Initialized
INFO - 2023-05-26 03:20:12 --> Router Class Initialized
INFO - 2023-05-26 03:20:12 --> Output Class Initialized
INFO - 2023-05-26 03:20:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:12 --> Input Class Initialized
INFO - 2023-05-26 03:20:12 --> Language Class Initialized
INFO - 2023-05-26 03:20:12 --> Loader Class Initialized
INFO - 2023-05-26 03:20:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:12 --> Model "Login_model" initialized
INFO - 2023-05-26 03:20:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:12 --> Total execution time: 0.0958
INFO - 2023-05-26 03:20:23 --> Config Class Initialized
INFO - 2023-05-26 03:20:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:23 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:23 --> URI Class Initialized
INFO - 2023-05-26 03:20:23 --> Router Class Initialized
INFO - 2023-05-26 03:20:23 --> Output Class Initialized
INFO - 2023-05-26 03:20:23 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:23 --> Input Class Initialized
INFO - 2023-05-26 03:20:23 --> Language Class Initialized
INFO - 2023-05-26 03:20:23 --> Loader Class Initialized
INFO - 2023-05-26 03:20:23 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:23 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:23 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:23 --> Total execution time: 0.0230
INFO - 2023-05-26 03:20:23 --> Config Class Initialized
INFO - 2023-05-26 03:20:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:23 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:23 --> URI Class Initialized
INFO - 2023-05-26 03:20:23 --> Router Class Initialized
INFO - 2023-05-26 03:20:23 --> Output Class Initialized
INFO - 2023-05-26 03:20:23 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:23 --> Input Class Initialized
INFO - 2023-05-26 03:20:23 --> Language Class Initialized
INFO - 2023-05-26 03:20:23 --> Loader Class Initialized
INFO - 2023-05-26 03:20:23 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:23 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:23 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:23 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:23 --> Total execution time: 0.0896
INFO - 2023-05-26 03:20:24 --> Config Class Initialized
INFO - 2023-05-26 03:20:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:24 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:24 --> URI Class Initialized
INFO - 2023-05-26 03:20:24 --> Router Class Initialized
INFO - 2023-05-26 03:20:24 --> Output Class Initialized
INFO - 2023-05-26 03:20:24 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:24 --> Input Class Initialized
INFO - 2023-05-26 03:20:24 --> Language Class Initialized
INFO - 2023-05-26 03:20:24 --> Loader Class Initialized
INFO - 2023-05-26 03:20:24 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:24 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:24 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:24 --> Total execution time: 0.0610
INFO - 2023-05-26 03:20:24 --> Config Class Initialized
INFO - 2023-05-26 03:20:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:24 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:24 --> URI Class Initialized
INFO - 2023-05-26 03:20:24 --> Router Class Initialized
INFO - 2023-05-26 03:20:24 --> Output Class Initialized
INFO - 2023-05-26 03:20:24 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:24 --> Input Class Initialized
INFO - 2023-05-26 03:20:24 --> Language Class Initialized
INFO - 2023-05-26 03:20:24 --> Loader Class Initialized
INFO - 2023-05-26 03:20:24 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:24 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:24 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:24 --> Total execution time: 0.1002
INFO - 2023-05-26 03:20:25 --> Config Class Initialized
INFO - 2023-05-26 03:20:25 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:25 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:25 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:25 --> URI Class Initialized
INFO - 2023-05-26 03:20:25 --> Router Class Initialized
INFO - 2023-05-26 03:20:25 --> Output Class Initialized
INFO - 2023-05-26 03:20:25 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:25 --> Input Class Initialized
INFO - 2023-05-26 03:20:25 --> Language Class Initialized
INFO - 2023-05-26 03:20:25 --> Loader Class Initialized
INFO - 2023-05-26 03:20:25 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:25 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:25 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:25 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:25 --> Total execution time: 0.0879
INFO - 2023-05-26 03:20:26 --> Config Class Initialized
INFO - 2023-05-26 03:20:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:26 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:26 --> URI Class Initialized
INFO - 2023-05-26 03:20:26 --> Router Class Initialized
INFO - 2023-05-26 03:20:26 --> Output Class Initialized
INFO - 2023-05-26 03:20:26 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:26 --> Input Class Initialized
INFO - 2023-05-26 03:20:26 --> Language Class Initialized
INFO - 2023-05-26 03:20:26 --> Loader Class Initialized
INFO - 2023-05-26 03:20:26 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:26 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:26 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:26 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:26 --> Total execution time: 0.0684
INFO - 2023-05-26 03:20:27 --> Config Class Initialized
INFO - 2023-05-26 03:20:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:27 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:27 --> URI Class Initialized
INFO - 2023-05-26 03:20:27 --> Router Class Initialized
INFO - 2023-05-26 03:20:27 --> Output Class Initialized
INFO - 2023-05-26 03:20:27 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:27 --> Input Class Initialized
INFO - 2023-05-26 03:20:27 --> Language Class Initialized
INFO - 2023-05-26 03:20:27 --> Loader Class Initialized
INFO - 2023-05-26 03:20:27 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:27 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:27 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:27 --> Total execution time: 0.0862
INFO - 2023-05-26 03:20:28 --> Config Class Initialized
INFO - 2023-05-26 03:20:28 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:28 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:28 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:28 --> URI Class Initialized
INFO - 2023-05-26 03:20:28 --> Router Class Initialized
INFO - 2023-05-26 03:20:28 --> Output Class Initialized
INFO - 2023-05-26 03:20:28 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:28 --> Input Class Initialized
INFO - 2023-05-26 03:20:28 --> Language Class Initialized
INFO - 2023-05-26 03:20:28 --> Loader Class Initialized
INFO - 2023-05-26 03:20:28 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:28 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:28 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:28 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:28 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:28 --> Total execution time: 0.0874
INFO - 2023-05-26 03:20:29 --> Config Class Initialized
INFO - 2023-05-26 03:20:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:29 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:29 --> URI Class Initialized
INFO - 2023-05-26 03:20:29 --> Router Class Initialized
INFO - 2023-05-26 03:20:29 --> Output Class Initialized
INFO - 2023-05-26 03:20:29 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:29 --> Input Class Initialized
INFO - 2023-05-26 03:20:29 --> Language Class Initialized
INFO - 2023-05-26 03:20:29 --> Loader Class Initialized
INFO - 2023-05-26 03:20:29 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:29 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:29 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:29 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:29 --> Total execution time: 0.0818
INFO - 2023-05-26 03:20:30 --> Config Class Initialized
INFO - 2023-05-26 03:20:30 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:30 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:30 --> URI Class Initialized
INFO - 2023-05-26 03:20:30 --> Router Class Initialized
INFO - 2023-05-26 03:20:30 --> Output Class Initialized
INFO - 2023-05-26 03:20:30 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:30 --> Input Class Initialized
INFO - 2023-05-26 03:20:30 --> Language Class Initialized
INFO - 2023-05-26 03:20:30 --> Loader Class Initialized
INFO - 2023-05-26 03:20:30 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:30 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:30 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:30 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:30 --> Total execution time: 0.0565
INFO - 2023-05-26 03:20:30 --> Config Class Initialized
INFO - 2023-05-26 03:20:30 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:30 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:30 --> URI Class Initialized
INFO - 2023-05-26 03:20:30 --> Router Class Initialized
INFO - 2023-05-26 03:20:30 --> Output Class Initialized
INFO - 2023-05-26 03:20:30 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:30 --> Input Class Initialized
INFO - 2023-05-26 03:20:30 --> Language Class Initialized
INFO - 2023-05-26 03:20:30 --> Loader Class Initialized
INFO - 2023-05-26 03:20:30 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:30 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:30 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:30 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:30 --> Total execution time: 0.0859
INFO - 2023-05-26 03:20:31 --> Config Class Initialized
INFO - 2023-05-26 03:20:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:31 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:31 --> URI Class Initialized
INFO - 2023-05-26 03:20:31 --> Router Class Initialized
INFO - 2023-05-26 03:20:31 --> Output Class Initialized
INFO - 2023-05-26 03:20:31 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:31 --> Input Class Initialized
INFO - 2023-05-26 03:20:31 --> Language Class Initialized
INFO - 2023-05-26 03:20:31 --> Loader Class Initialized
INFO - 2023-05-26 03:20:31 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:31 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:31 --> Total execution time: 0.1318
INFO - 2023-05-26 03:20:31 --> Config Class Initialized
INFO - 2023-05-26 03:20:31 --> Hooks Class Initialized
INFO - 2023-05-26 03:20:31 --> Config Class Initialized
INFO - 2023-05-26 03:20:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:31 --> Utf8 Class Initialized
DEBUG - 2023-05-26 03:20:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:31 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:31 --> URI Class Initialized
INFO - 2023-05-26 03:20:31 --> URI Class Initialized
INFO - 2023-05-26 03:20:31 --> Router Class Initialized
INFO - 2023-05-26 03:20:31 --> Router Class Initialized
INFO - 2023-05-26 03:20:31 --> Output Class Initialized
INFO - 2023-05-26 03:20:31 --> Output Class Initialized
INFO - 2023-05-26 03:20:31 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:31 --> Security Class Initialized
INFO - 2023-05-26 03:20:31 --> Input Class Initialized
INFO - 2023-05-26 03:20:31 --> Language Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:31 --> Input Class Initialized
INFO - 2023-05-26 03:20:31 --> Language Class Initialized
INFO - 2023-05-26 03:20:31 --> Loader Class Initialized
INFO - 2023-05-26 03:20:31 --> Loader Class Initialized
INFO - 2023-05-26 03:20:31 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:31 --> Total execution time: 0.0287
INFO - 2023-05-26 03:20:31 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:31 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:31 --> Config Class Initialized
INFO - 2023-05-26 03:20:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:31 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:31 --> URI Class Initialized
INFO - 2023-05-26 03:20:31 --> Router Class Initialized
INFO - 2023-05-26 03:20:31 --> Output Class Initialized
INFO - 2023-05-26 03:20:31 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:31 --> Input Class Initialized
INFO - 2023-05-26 03:20:31 --> Language Class Initialized
INFO - 2023-05-26 03:20:31 --> Loader Class Initialized
INFO - 2023-05-26 03:20:31 --> Model "Login_model" initialized
INFO - 2023-05-26 03:20:31 --> Controller Class Initialized
INFO - 2023-05-26 03:20:31 --> Database Driver Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:31 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:31 --> Model "Login_model" initialized
INFO - 2023-05-26 03:20:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:31 --> Total execution time: 0.1078
INFO - 2023-05-26 03:20:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:31 --> Total execution time: 0.0730
INFO - 2023-05-26 03:20:31 --> Config Class Initialized
INFO - 2023-05-26 03:20:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:31 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:31 --> URI Class Initialized
INFO - 2023-05-26 03:20:31 --> Router Class Initialized
INFO - 2023-05-26 03:20:31 --> Output Class Initialized
INFO - 2023-05-26 03:20:31 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:31 --> Input Class Initialized
INFO - 2023-05-26 03:20:31 --> Language Class Initialized
INFO - 2023-05-26 03:20:31 --> Loader Class Initialized
INFO - 2023-05-26 03:20:31 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:31 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:31 --> Model "Login_model" initialized
INFO - 2023-05-26 03:20:31 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:31 --> Total execution time: 0.0977
INFO - 2023-05-26 03:20:31 --> Config Class Initialized
INFO - 2023-05-26 03:20:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:31 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:31 --> URI Class Initialized
INFO - 2023-05-26 03:20:31 --> Router Class Initialized
INFO - 2023-05-26 03:20:31 --> Output Class Initialized
INFO - 2023-05-26 03:20:31 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:31 --> Input Class Initialized
INFO - 2023-05-26 03:20:31 --> Language Class Initialized
INFO - 2023-05-26 03:20:31 --> Loader Class Initialized
INFO - 2023-05-26 03:20:31 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:31 --> Total execution time: 0.0246
INFO - 2023-05-26 03:20:31 --> Config Class Initialized
INFO - 2023-05-26 03:20:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:31 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:31 --> URI Class Initialized
INFO - 2023-05-26 03:20:31 --> Router Class Initialized
INFO - 2023-05-26 03:20:31 --> Output Class Initialized
INFO - 2023-05-26 03:20:31 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:31 --> Input Class Initialized
INFO - 2023-05-26 03:20:31 --> Language Class Initialized
INFO - 2023-05-26 03:20:31 --> Loader Class Initialized
INFO - 2023-05-26 03:20:31 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:31 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:31 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:31 --> Model "Login_model" initialized
INFO - 2023-05-26 03:20:31 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:31 --> Total execution time: 0.0918
INFO - 2023-05-26 03:20:44 --> Config Class Initialized
INFO - 2023-05-26 03:20:44 --> Hooks Class Initialized
INFO - 2023-05-26 03:20:44 --> Config Class Initialized
INFO - 2023-05-26 03:20:44 --> Hooks Class Initialized
INFO - 2023-05-26 03:20:44 --> Config Class Initialized
DEBUG - 2023-05-26 03:20:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:44 --> Hooks Class Initialized
INFO - 2023-05-26 03:20:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:44 --> Config Class Initialized
INFO - 2023-05-26 03:20:44 --> Hooks Class Initialized
INFO - 2023-05-26 03:20:44 --> URI Class Initialized
DEBUG - 2023-05-26 03:20:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:44 --> Router Class Initialized
DEBUG - 2023-05-26 03:20:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:44 --> URI Class Initialized
INFO - 2023-05-26 03:20:44 --> Utf8 Class Initialized
DEBUG - 2023-05-26 03:20:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:44 --> Output Class Initialized
INFO - 2023-05-26 03:20:44 --> URI Class Initialized
INFO - 2023-05-26 03:20:44 --> Router Class Initialized
INFO - 2023-05-26 03:20:44 --> URI Class Initialized
INFO - 2023-05-26 03:20:44 --> Security Class Initialized
INFO - 2023-05-26 03:20:44 --> Router Class Initialized
INFO - 2023-05-26 03:20:44 --> Output Class Initialized
INFO - 2023-05-26 03:20:44 --> Router Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:44 --> Input Class Initialized
INFO - 2023-05-26 03:20:44 --> Output Class Initialized
INFO - 2023-05-26 03:20:44 --> Security Class Initialized
INFO - 2023-05-26 03:20:44 --> Language Class Initialized
INFO - 2023-05-26 03:20:44 --> Output Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:44 --> Security Class Initialized
INFO - 2023-05-26 03:20:44 --> Input Class Initialized
INFO - 2023-05-26 03:20:44 --> Security Class Initialized
INFO - 2023-05-26 03:20:44 --> Language Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:44 --> Input Class Initialized
INFO - 2023-05-26 03:20:44 --> Language Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:44 --> Loader Class Initialized
INFO - 2023-05-26 03:20:44 --> Input Class Initialized
INFO - 2023-05-26 03:20:44 --> Language Class Initialized
INFO - 2023-05-26 03:20:44 --> Controller Class Initialized
INFO - 2023-05-26 03:20:44 --> Loader Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:44 --> Loader Class Initialized
INFO - 2023-05-26 03:20:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:44 --> Controller Class Initialized
INFO - 2023-05-26 03:20:44 --> Loader Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:44 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:44 --> Total execution time: 0.0696
INFO - 2023-05-26 03:20:44 --> Model "Login_model" initialized
INFO - 2023-05-26 03:20:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:44 --> Final output sent to browser
INFO - 2023-05-26 03:20:44 --> Config Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Total execution time: 0.0818
INFO - 2023-05-26 03:20:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:44 --> URI Class Initialized
INFO - 2023-05-26 03:20:44 --> Router Class Initialized
INFO - 2023-05-26 03:20:44 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:44 --> Total execution time: 0.0919
INFO - 2023-05-26 03:20:44 --> Output Class Initialized
INFO - 2023-05-26 03:20:44 --> Security Class Initialized
INFO - 2023-05-26 03:20:44 --> Config Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:44 --> Hooks Class Initialized
INFO - 2023-05-26 03:20:44 --> Input Class Initialized
INFO - 2023-05-26 03:20:44 --> Language Class Initialized
INFO - 2023-05-26 03:20:44 --> Config Class Initialized
INFO - 2023-05-26 03:20:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:44 --> Loader Class Initialized
INFO - 2023-05-26 03:20:44 --> URI Class Initialized
INFO - 2023-05-26 03:20:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:44 --> Router Class Initialized
INFO - 2023-05-26 03:20:44 --> Config Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:44 --> Hooks Class Initialized
INFO - 2023-05-26 03:20:44 --> URI Class Initialized
INFO - 2023-05-26 03:20:44 --> Output Class Initialized
INFO - 2023-05-26 03:20:44 --> Security Class Initialized
INFO - 2023-05-26 03:20:44 --> Router Class Initialized
DEBUG - 2023-05-26 03:20:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:44 --> Utf8 Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:44 --> Input Class Initialized
INFO - 2023-05-26 03:20:44 --> Output Class Initialized
INFO - 2023-05-26 03:20:44 --> URI Class Initialized
INFO - 2023-05-26 03:20:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:44 --> Language Class Initialized
INFO - 2023-05-26 03:20:44 --> Security Class Initialized
INFO - 2023-05-26 03:20:44 --> Router Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:44 --> Input Class Initialized
INFO - 2023-05-26 03:20:44 --> Loader Class Initialized
INFO - 2023-05-26 03:20:44 --> Language Class Initialized
INFO - 2023-05-26 03:20:44 --> Output Class Initialized
INFO - 2023-05-26 03:20:44 --> Controller Class Initialized
INFO - 2023-05-26 03:20:44 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-05-26 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:44 --> Input Class Initialized
INFO - 2023-05-26 03:20:44 --> Loader Class Initialized
INFO - 2023-05-26 03:20:44 --> Language Class Initialized
INFO - 2023-05-26 03:20:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:44 --> Loader Class Initialized
INFO - 2023-05-26 03:20:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:44 --> Model "Login_model" initialized
INFO - 2023-05-26 03:20:44 --> Final output sent to browser
INFO - 2023-05-26 03:20:44 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:44 --> Total execution time: 0.0834
DEBUG - 2023-05-26 03:20:44 --> Total execution time: 0.0987
INFO - 2023-05-26 03:20:44 --> Final output sent to browser
DEBUG - 2023-05-26 03:20:44 --> Total execution time: 0.0822
INFO - 2023-05-26 03:20:54 --> Config Class Initialized
INFO - 2023-05-26 03:20:54 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:54 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:54 --> URI Class Initialized
INFO - 2023-05-26 03:20:54 --> Router Class Initialized
INFO - 2023-05-26 03:20:54 --> Output Class Initialized
INFO - 2023-05-26 03:20:54 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:54 --> Input Class Initialized
INFO - 2023-05-26 03:20:54 --> Language Class Initialized
INFO - 2023-05-26 03:20:54 --> Loader Class Initialized
INFO - 2023-05-26 03:20:54 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:54 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:54 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:54 --> Config Class Initialized
INFO - 2023-05-26 03:20:54 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:54 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:54 --> URI Class Initialized
INFO - 2023-05-26 03:20:54 --> Router Class Initialized
INFO - 2023-05-26 03:20:54 --> Output Class Initialized
INFO - 2023-05-26 03:20:54 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:54 --> Input Class Initialized
INFO - 2023-05-26 03:20:54 --> Language Class Initialized
INFO - 2023-05-26 03:20:54 --> Loader Class Initialized
INFO - 2023-05-26 03:20:54 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:54 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:54 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:20:56 --> Config Class Initialized
INFO - 2023-05-26 03:20:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:20:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:20:56 --> Utf8 Class Initialized
INFO - 2023-05-26 03:20:56 --> URI Class Initialized
INFO - 2023-05-26 03:20:56 --> Router Class Initialized
INFO - 2023-05-26 03:20:56 --> Output Class Initialized
INFO - 2023-05-26 03:20:56 --> Security Class Initialized
DEBUG - 2023-05-26 03:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:20:56 --> Input Class Initialized
INFO - 2023-05-26 03:20:56 --> Language Class Initialized
INFO - 2023-05-26 03:20:56 --> Loader Class Initialized
INFO - 2023-05-26 03:20:56 --> Controller Class Initialized
DEBUG - 2023-05-26 03:20:56 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:20:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:20:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:21:01 --> Config Class Initialized
INFO - 2023-05-26 03:21:01 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:21:01 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:21:01 --> Utf8 Class Initialized
INFO - 2023-05-26 03:21:01 --> URI Class Initialized
INFO - 2023-05-26 03:21:01 --> Router Class Initialized
INFO - 2023-05-26 03:21:01 --> Output Class Initialized
INFO - 2023-05-26 03:21:01 --> Security Class Initialized
DEBUG - 2023-05-26 03:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:21:01 --> Input Class Initialized
INFO - 2023-05-26 03:21:01 --> Language Class Initialized
INFO - 2023-05-26 03:21:01 --> Loader Class Initialized
INFO - 2023-05-26 03:21:01 --> Controller Class Initialized
DEBUG - 2023-05-26 03:21:01 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:21:01 --> Database Driver Class Initialized
INFO - 2023-05-26 03:21:01 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:21:01 --> Config Class Initialized
INFO - 2023-05-26 03:21:01 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:21:01 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:21:01 --> Utf8 Class Initialized
INFO - 2023-05-26 03:21:01 --> URI Class Initialized
INFO - 2023-05-26 03:21:01 --> Router Class Initialized
INFO - 2023-05-26 03:21:01 --> Output Class Initialized
INFO - 2023-05-26 03:21:01 --> Security Class Initialized
DEBUG - 2023-05-26 03:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:21:01 --> Input Class Initialized
INFO - 2023-05-26 03:21:01 --> Language Class Initialized
INFO - 2023-05-26 03:21:01 --> Loader Class Initialized
INFO - 2023-05-26 03:21:01 --> Controller Class Initialized
DEBUG - 2023-05-26 03:21:01 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:21:01 --> Database Driver Class Initialized
INFO - 2023-05-26 03:21:01 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:21:03 --> Config Class Initialized
INFO - 2023-05-26 03:21:03 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:21:03 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:21:03 --> Utf8 Class Initialized
INFO - 2023-05-26 03:21:03 --> URI Class Initialized
INFO - 2023-05-26 03:21:03 --> Router Class Initialized
INFO - 2023-05-26 03:21:03 --> Output Class Initialized
INFO - 2023-05-26 03:21:03 --> Security Class Initialized
DEBUG - 2023-05-26 03:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:21:03 --> Input Class Initialized
INFO - 2023-05-26 03:21:03 --> Language Class Initialized
INFO - 2023-05-26 03:21:03 --> Loader Class Initialized
INFO - 2023-05-26 03:21:03 --> Controller Class Initialized
DEBUG - 2023-05-26 03:21:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:21:03 --> Database Driver Class Initialized
INFO - 2023-05-26 03:21:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:21:11 --> Config Class Initialized
INFO - 2023-05-26 03:21:11 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:21:11 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:21:11 --> Utf8 Class Initialized
INFO - 2023-05-26 03:21:11 --> URI Class Initialized
INFO - 2023-05-26 03:21:11 --> Router Class Initialized
INFO - 2023-05-26 03:21:11 --> Output Class Initialized
INFO - 2023-05-26 03:21:11 --> Security Class Initialized
DEBUG - 2023-05-26 03:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:21:11 --> Input Class Initialized
INFO - 2023-05-26 03:21:11 --> Language Class Initialized
INFO - 2023-05-26 03:21:11 --> Loader Class Initialized
INFO - 2023-05-26 03:21:11 --> Controller Class Initialized
DEBUG - 2023-05-26 03:21:11 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:21:11 --> Database Driver Class Initialized
INFO - 2023-05-26 03:21:11 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:21:11 --> Config Class Initialized
INFO - 2023-05-26 03:21:11 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:21:11 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:21:11 --> Utf8 Class Initialized
INFO - 2023-05-26 03:21:11 --> URI Class Initialized
INFO - 2023-05-26 03:21:11 --> Router Class Initialized
INFO - 2023-05-26 03:21:11 --> Output Class Initialized
INFO - 2023-05-26 03:21:11 --> Security Class Initialized
DEBUG - 2023-05-26 03:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:21:11 --> Input Class Initialized
INFO - 2023-05-26 03:21:11 --> Language Class Initialized
INFO - 2023-05-26 03:21:11 --> Loader Class Initialized
INFO - 2023-05-26 03:21:11 --> Controller Class Initialized
DEBUG - 2023-05-26 03:21:11 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:21:11 --> Database Driver Class Initialized
INFO - 2023-05-26 03:21:11 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:21:44 --> Config Class Initialized
INFO - 2023-05-26 03:21:44 --> Hooks Class Initialized
INFO - 2023-05-26 03:21:44 --> Config Class Initialized
INFO - 2023-05-26 03:21:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:21:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:21:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:21:44 --> URI Class Initialized
DEBUG - 2023-05-26 03:21:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:21:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:21:44 --> URI Class Initialized
INFO - 2023-05-26 03:21:44 --> Router Class Initialized
INFO - 2023-05-26 03:21:44 --> Router Class Initialized
INFO - 2023-05-26 03:21:44 --> Output Class Initialized
INFO - 2023-05-26 03:21:44 --> Output Class Initialized
INFO - 2023-05-26 03:21:44 --> Security Class Initialized
INFO - 2023-05-26 03:21:44 --> Security Class Initialized
DEBUG - 2023-05-26 03:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:21:44 --> Input Class Initialized
INFO - 2023-05-26 03:21:44 --> Language Class Initialized
DEBUG - 2023-05-26 03:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:21:44 --> Input Class Initialized
INFO - 2023-05-26 03:21:44 --> Language Class Initialized
INFO - 2023-05-26 03:21:44 --> Loader Class Initialized
INFO - 2023-05-26 03:21:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:21:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:21:44 --> Loader Class Initialized
INFO - 2023-05-26 03:21:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:21:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:21:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:21:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:21:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:21:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:21:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:21:44 --> Config Class Initialized
INFO - 2023-05-26 03:21:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:21:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:21:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:21:44 --> URI Class Initialized
INFO - 2023-05-26 03:21:44 --> Router Class Initialized
INFO - 2023-05-26 03:21:44 --> Output Class Initialized
INFO - 2023-05-26 03:21:44 --> Security Class Initialized
DEBUG - 2023-05-26 03:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:21:44 --> Input Class Initialized
INFO - 2023-05-26 03:21:44 --> Model "Login_model" initialized
INFO - 2023-05-26 03:21:44 --> Language Class Initialized
INFO - 2023-05-26 03:21:44 --> Loader Class Initialized
INFO - 2023-05-26 03:21:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:21:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:21:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:21:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:21:44 --> Final output sent to browser
DEBUG - 2023-05-26 03:21:44 --> Total execution time: 0.6458
INFO - 2023-05-26 03:21:44 --> Config Class Initialized
INFO - 2023-05-26 03:21:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:21:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:21:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:21:44 --> URI Class Initialized
INFO - 2023-05-26 03:21:44 --> Router Class Initialized
INFO - 2023-05-26 03:21:44 --> Output Class Initialized
INFO - 2023-05-26 03:21:44 --> Security Class Initialized
DEBUG - 2023-05-26 03:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:21:44 --> Input Class Initialized
INFO - 2023-05-26 03:21:44 --> Language Class Initialized
INFO - 2023-05-26 03:21:45 --> Loader Class Initialized
INFO - 2023-05-26 03:21:45 --> Controller Class Initialized
DEBUG - 2023-05-26 03:21:45 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:21:45 --> Database Driver Class Initialized
INFO - 2023-05-26 03:21:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:21:45 --> Database Driver Class Initialized
INFO - 2023-05-26 03:21:45 --> Model "Login_model" initialized
INFO - 2023-05-26 03:21:45 --> Final output sent to browser
DEBUG - 2023-05-26 03:21:45 --> Total execution time: 0.6234
INFO - 2023-05-26 03:22:05 --> Config Class Initialized
INFO - 2023-05-26 03:22:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:22:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:22:05 --> Utf8 Class Initialized
INFO - 2023-05-26 03:22:05 --> URI Class Initialized
INFO - 2023-05-26 03:22:05 --> Router Class Initialized
INFO - 2023-05-26 03:22:05 --> Output Class Initialized
INFO - 2023-05-26 03:22:05 --> Security Class Initialized
DEBUG - 2023-05-26 03:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:22:05 --> Input Class Initialized
INFO - 2023-05-26 03:22:05 --> Language Class Initialized
INFO - 2023-05-26 03:22:05 --> Loader Class Initialized
INFO - 2023-05-26 03:22:05 --> Controller Class Initialized
DEBUG - 2023-05-26 03:22:05 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:22:05 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:22:05 --> Final output sent to browser
DEBUG - 2023-05-26 03:22:05 --> Total execution time: 0.1007
INFO - 2023-05-26 03:22:05 --> Config Class Initialized
INFO - 2023-05-26 03:22:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:22:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:22:05 --> Utf8 Class Initialized
INFO - 2023-05-26 03:22:05 --> URI Class Initialized
INFO - 2023-05-26 03:22:05 --> Router Class Initialized
INFO - 2023-05-26 03:22:05 --> Output Class Initialized
INFO - 2023-05-26 03:22:05 --> Security Class Initialized
DEBUG - 2023-05-26 03:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:22:05 --> Input Class Initialized
INFO - 2023-05-26 03:22:05 --> Language Class Initialized
INFO - 2023-05-26 03:22:05 --> Loader Class Initialized
INFO - 2023-05-26 03:22:05 --> Controller Class Initialized
DEBUG - 2023-05-26 03:22:05 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:22:05 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:22:05 --> Final output sent to browser
DEBUG - 2023-05-26 03:22:05 --> Total execution time: 0.0872
INFO - 2023-05-26 03:22:14 --> Config Class Initialized
INFO - 2023-05-26 03:22:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:22:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:22:14 --> Utf8 Class Initialized
INFO - 2023-05-26 03:22:14 --> URI Class Initialized
INFO - 2023-05-26 03:22:14 --> Router Class Initialized
INFO - 2023-05-26 03:22:14 --> Output Class Initialized
INFO - 2023-05-26 03:22:14 --> Security Class Initialized
DEBUG - 2023-05-26 03:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:22:14 --> Input Class Initialized
INFO - 2023-05-26 03:22:14 --> Language Class Initialized
INFO - 2023-05-26 03:22:14 --> Loader Class Initialized
INFO - 2023-05-26 03:22:14 --> Controller Class Initialized
DEBUG - 2023-05-26 03:22:14 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:22:14 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:14 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:22:14 --> Final output sent to browser
DEBUG - 2023-05-26 03:22:14 --> Total execution time: 0.1722
INFO - 2023-05-26 03:22:14 --> Config Class Initialized
INFO - 2023-05-26 03:22:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:22:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:22:14 --> Utf8 Class Initialized
INFO - 2023-05-26 03:22:14 --> URI Class Initialized
INFO - 2023-05-26 03:22:14 --> Router Class Initialized
INFO - 2023-05-26 03:22:14 --> Output Class Initialized
INFO - 2023-05-26 03:22:14 --> Security Class Initialized
DEBUG - 2023-05-26 03:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:22:14 --> Input Class Initialized
INFO - 2023-05-26 03:22:14 --> Language Class Initialized
INFO - 2023-05-26 03:22:14 --> Loader Class Initialized
INFO - 2023-05-26 03:22:14 --> Controller Class Initialized
DEBUG - 2023-05-26 03:22:14 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:22:14 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:14 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:22:15 --> Final output sent to browser
DEBUG - 2023-05-26 03:22:15 --> Total execution time: 0.1801
INFO - 2023-05-26 03:22:44 --> Config Class Initialized
INFO - 2023-05-26 03:22:44 --> Hooks Class Initialized
INFO - 2023-05-26 03:22:44 --> Config Class Initialized
INFO - 2023-05-26 03:22:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:22:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:22:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:22:44 --> URI Class Initialized
DEBUG - 2023-05-26 03:22:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:22:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:22:44 --> URI Class Initialized
INFO - 2023-05-26 03:22:44 --> Router Class Initialized
INFO - 2023-05-26 03:22:44 --> Output Class Initialized
INFO - 2023-05-26 03:22:44 --> Router Class Initialized
INFO - 2023-05-26 03:22:44 --> Security Class Initialized
INFO - 2023-05-26 03:22:44 --> Output Class Initialized
DEBUG - 2023-05-26 03:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:22:44 --> Input Class Initialized
INFO - 2023-05-26 03:22:44 --> Security Class Initialized
INFO - 2023-05-26 03:22:44 --> Language Class Initialized
DEBUG - 2023-05-26 03:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:22:44 --> Input Class Initialized
INFO - 2023-05-26 03:22:44 --> Language Class Initialized
INFO - 2023-05-26 03:22:44 --> Loader Class Initialized
INFO - 2023-05-26 03:22:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:22:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:22:44 --> Loader Class Initialized
INFO - 2023-05-26 03:22:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:22:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:22:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:22:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:22:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:44 --> Model "Login_model" initialized
INFO - 2023-05-26 03:22:44 --> Final output sent to browser
DEBUG - 2023-05-26 03:22:44 --> Total execution time: 0.1682
INFO - 2023-05-26 03:22:44 --> Config Class Initialized
INFO - 2023-05-26 03:22:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:22:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:22:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:22:44 --> URI Class Initialized
INFO - 2023-05-26 03:22:44 --> Router Class Initialized
INFO - 2023-05-26 03:22:44 --> Output Class Initialized
INFO - 2023-05-26 03:22:44 --> Security Class Initialized
DEBUG - 2023-05-26 03:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:22:44 --> Input Class Initialized
INFO - 2023-05-26 03:22:44 --> Language Class Initialized
INFO - 2023-05-26 03:22:44 --> Loader Class Initialized
INFO - 2023-05-26 03:22:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:22:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:22:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:22:44 --> Final output sent to browser
DEBUG - 2023-05-26 03:22:44 --> Total execution time: 0.1050
INFO - 2023-05-26 03:22:45 --> Final output sent to browser
DEBUG - 2023-05-26 03:22:45 --> Total execution time: 0.7510
INFO - 2023-05-26 03:22:45 --> Config Class Initialized
INFO - 2023-05-26 03:22:45 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:22:45 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:22:45 --> Utf8 Class Initialized
INFO - 2023-05-26 03:22:45 --> URI Class Initialized
INFO - 2023-05-26 03:22:45 --> Router Class Initialized
INFO - 2023-05-26 03:22:45 --> Output Class Initialized
INFO - 2023-05-26 03:22:45 --> Security Class Initialized
DEBUG - 2023-05-26 03:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:22:45 --> Input Class Initialized
INFO - 2023-05-26 03:22:45 --> Language Class Initialized
INFO - 2023-05-26 03:22:45 --> Loader Class Initialized
INFO - 2023-05-26 03:22:45 --> Controller Class Initialized
DEBUG - 2023-05-26 03:22:45 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:22:45 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:22:45 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:45 --> Model "Login_model" initialized
INFO - 2023-05-26 03:22:45 --> Final output sent to browser
DEBUG - 2023-05-26 03:22:45 --> Total execution time: 0.6773
INFO - 2023-05-26 03:22:53 --> Config Class Initialized
INFO - 2023-05-26 03:22:53 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:22:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:22:53 --> Utf8 Class Initialized
INFO - 2023-05-26 03:22:53 --> URI Class Initialized
INFO - 2023-05-26 03:22:53 --> Router Class Initialized
INFO - 2023-05-26 03:22:53 --> Output Class Initialized
INFO - 2023-05-26 03:22:53 --> Security Class Initialized
DEBUG - 2023-05-26 03:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:22:53 --> Input Class Initialized
INFO - 2023-05-26 03:22:53 --> Language Class Initialized
INFO - 2023-05-26 03:22:53 --> Loader Class Initialized
INFO - 2023-05-26 03:22:53 --> Controller Class Initialized
DEBUG - 2023-05-26 03:22:53 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:22:53 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:22:53 --> Final output sent to browser
DEBUG - 2023-05-26 03:22:53 --> Total execution time: 0.1141
INFO - 2023-05-26 03:22:53 --> Config Class Initialized
INFO - 2023-05-26 03:22:53 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:22:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:22:53 --> Utf8 Class Initialized
INFO - 2023-05-26 03:22:53 --> URI Class Initialized
INFO - 2023-05-26 03:22:53 --> Router Class Initialized
INFO - 2023-05-26 03:22:53 --> Output Class Initialized
INFO - 2023-05-26 03:22:53 --> Security Class Initialized
DEBUG - 2023-05-26 03:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:22:53 --> Input Class Initialized
INFO - 2023-05-26 03:22:53 --> Language Class Initialized
INFO - 2023-05-26 03:22:53 --> Loader Class Initialized
INFO - 2023-05-26 03:22:53 --> Controller Class Initialized
DEBUG - 2023-05-26 03:22:53 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:22:53 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:22:53 --> Final output sent to browser
DEBUG - 2023-05-26 03:22:53 --> Total execution time: 0.1030
INFO - 2023-05-26 03:22:54 --> Config Class Initialized
INFO - 2023-05-26 03:22:54 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:22:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:22:54 --> Utf8 Class Initialized
INFO - 2023-05-26 03:22:54 --> URI Class Initialized
INFO - 2023-05-26 03:22:54 --> Router Class Initialized
INFO - 2023-05-26 03:22:54 --> Output Class Initialized
INFO - 2023-05-26 03:22:54 --> Security Class Initialized
DEBUG - 2023-05-26 03:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:22:54 --> Input Class Initialized
INFO - 2023-05-26 03:22:54 --> Language Class Initialized
INFO - 2023-05-26 03:22:54 --> Loader Class Initialized
INFO - 2023-05-26 03:22:54 --> Controller Class Initialized
DEBUG - 2023-05-26 03:22:54 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:22:54 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:22:54 --> Final output sent to browser
DEBUG - 2023-05-26 03:22:54 --> Total execution time: 0.1028
INFO - 2023-05-26 03:22:54 --> Config Class Initialized
INFO - 2023-05-26 03:22:54 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:22:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:22:54 --> Utf8 Class Initialized
INFO - 2023-05-26 03:22:54 --> URI Class Initialized
INFO - 2023-05-26 03:22:54 --> Router Class Initialized
INFO - 2023-05-26 03:22:54 --> Output Class Initialized
INFO - 2023-05-26 03:22:54 --> Security Class Initialized
DEBUG - 2023-05-26 03:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:22:54 --> Input Class Initialized
INFO - 2023-05-26 03:22:54 --> Language Class Initialized
INFO - 2023-05-26 03:22:54 --> Loader Class Initialized
INFO - 2023-05-26 03:22:54 --> Controller Class Initialized
DEBUG - 2023-05-26 03:22:54 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:22:54 --> Database Driver Class Initialized
INFO - 2023-05-26 03:22:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:22:54 --> Final output sent to browser
DEBUG - 2023-05-26 03:22:54 --> Total execution time: 0.1023
INFO - 2023-05-26 03:23:11 --> Config Class Initialized
INFO - 2023-05-26 03:23:11 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:23:11 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:11 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:11 --> Config Class Initialized
INFO - 2023-05-26 03:23:11 --> Config Class Initialized
INFO - 2023-05-26 03:23:11 --> Hooks Class Initialized
INFO - 2023-05-26 03:23:11 --> Hooks Class Initialized
INFO - 2023-05-26 03:23:11 --> Config Class Initialized
INFO - 2023-05-26 03:23:11 --> URI Class Initialized
INFO - 2023-05-26 03:23:11 --> Hooks Class Initialized
INFO - 2023-05-26 03:23:11 --> Router Class Initialized
INFO - 2023-05-26 03:23:11 --> Output Class Initialized
DEBUG - 2023-05-26 03:23:11 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:11 --> Utf8 Class Initialized
DEBUG - 2023-05-26 03:23:11 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:23:11 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:11 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:11 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:11 --> URI Class Initialized
INFO - 2023-05-26 03:23:11 --> Security Class Initialized
INFO - 2023-05-26 03:23:11 --> URI Class Initialized
INFO - 2023-05-26 03:23:11 --> URI Class Initialized
DEBUG - 2023-05-26 03:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:11 --> Input Class Initialized
INFO - 2023-05-26 03:23:11 --> Router Class Initialized
INFO - 2023-05-26 03:23:11 --> Router Class Initialized
INFO - 2023-05-26 03:23:11 --> Language Class Initialized
INFO - 2023-05-26 03:23:11 --> Router Class Initialized
INFO - 2023-05-26 03:23:11 --> Output Class Initialized
INFO - 2023-05-26 03:23:11 --> Output Class Initialized
INFO - 2023-05-26 03:23:11 --> Output Class Initialized
INFO - 2023-05-26 03:23:11 --> Security Class Initialized
INFO - 2023-05-26 03:23:11 --> Security Class Initialized
INFO - 2023-05-26 03:23:11 --> Security Class Initialized
INFO - 2023-05-26 03:23:11 --> Loader Class Initialized
DEBUG - 2023-05-26 03:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:11 --> Input Class Initialized
DEBUG - 2023-05-26 03:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:11 --> Input Class Initialized
INFO - 2023-05-26 03:23:11 --> Input Class Initialized
INFO - 2023-05-26 03:23:11 --> Controller Class Initialized
INFO - 2023-05-26 03:23:11 --> Language Class Initialized
INFO - 2023-05-26 03:23:11 --> Language Class Initialized
DEBUG - 2023-05-26 03:23:11 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:23:11 --> Language Class Initialized
INFO - 2023-05-26 03:23:11 --> Loader Class Initialized
INFO - 2023-05-26 03:23:11 --> Controller Class Initialized
INFO - 2023-05-26 03:23:11 --> Loader Class Initialized
INFO - 2023-05-26 03:23:11 --> Loader Class Initialized
DEBUG - 2023-05-26 03:23:11 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:23:11 --> Controller Class Initialized
INFO - 2023-05-26 03:23:11 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:11 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-05-26 03:23:11 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:23:11 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:11 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:11 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:11 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:11 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:11 --> Model "Login_model" initialized
INFO - 2023-05-26 03:23:11 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:11 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:11 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:11 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:11 --> Total execution time: 0.0909
INFO - 2023-05-26 03:23:11 --> Config Class Initialized
INFO - 2023-05-26 03:23:11 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:23:11 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:11 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:11 --> URI Class Initialized
INFO - 2023-05-26 03:23:12 --> Router Class Initialized
INFO - 2023-05-26 03:23:12 --> Output Class Initialized
INFO - 2023-05-26 03:23:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:12 --> Input Class Initialized
INFO - 2023-05-26 03:23:12 --> Language Class Initialized
INFO - 2023-05-26 03:23:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:12 --> Total execution time: 0.1204
INFO - 2023-05-26 03:23:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:12 --> Total execution time: 0.1197
INFO - 2023-05-26 03:23:12 --> Loader Class Initialized
INFO - 2023-05-26 03:23:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:23:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:12 --> Total execution time: 0.1405
INFO - 2023-05-26 03:23:12 --> Config Class Initialized
INFO - 2023-05-26 03:23:12 --> Config Class Initialized
INFO - 2023-05-26 03:23:12 --> Hooks Class Initialized
INFO - 2023-05-26 03:23:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:23:12 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:23:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:12 --> URI Class Initialized
INFO - 2023-05-26 03:23:12 --> URI Class Initialized
INFO - 2023-05-26 03:23:12 --> Router Class Initialized
INFO - 2023-05-26 03:23:12 --> Router Class Initialized
INFO - 2023-05-26 03:23:12 --> Config Class Initialized
INFO - 2023-05-26 03:23:12 --> Hooks Class Initialized
INFO - 2023-05-26 03:23:12 --> Output Class Initialized
INFO - 2023-05-26 03:23:12 --> Output Class Initialized
INFO - 2023-05-26 03:23:12 --> Security Class Initialized
INFO - 2023-05-26 03:23:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:12 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:12 --> Input Class Initialized
INFO - 2023-05-26 03:23:12 --> Input Class Initialized
INFO - 2023-05-26 03:23:12 --> Language Class Initialized
INFO - 2023-05-26 03:23:12 --> Language Class Initialized
INFO - 2023-05-26 03:23:12 --> URI Class Initialized
INFO - 2023-05-26 03:23:12 --> Router Class Initialized
INFO - 2023-05-26 03:23:12 --> Loader Class Initialized
INFO - 2023-05-26 03:23:12 --> Loader Class Initialized
INFO - 2023-05-26 03:23:12 --> Output Class Initialized
INFO - 2023-05-26 03:23:12 --> Model "Login_model" initialized
INFO - 2023-05-26 03:23:12 --> Controller Class Initialized
INFO - 2023-05-26 03:23:12 --> Controller Class Initialized
INFO - 2023-05-26 03:23:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-05-26 03:23:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-05-26 03:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:12 --> Input Class Initialized
INFO - 2023-05-26 03:23:12 --> Language Class Initialized
INFO - 2023-05-26 03:23:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:12 --> Total execution time: 0.0813
INFO - 2023-05-26 03:23:12 --> Loader Class Initialized
INFO - 2023-05-26 03:23:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:23:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:12 --> Final output sent to browser
INFO - 2023-05-26 03:23:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:12 --> Total execution time: 0.0813
DEBUG - 2023-05-26 03:23:12 --> Total execution time: 0.0812
INFO - 2023-05-26 03:23:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:12 --> Total execution time: 0.0909
INFO - 2023-05-26 03:23:44 --> Config Class Initialized
INFO - 2023-05-26 03:23:44 --> Config Class Initialized
INFO - 2023-05-26 03:23:44 --> Hooks Class Initialized
INFO - 2023-05-26 03:23:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:23:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:44 --> Utf8 Class Initialized
DEBUG - 2023-05-26 03:23:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:44 --> URI Class Initialized
INFO - 2023-05-26 03:23:44 --> URI Class Initialized
INFO - 2023-05-26 03:23:44 --> Router Class Initialized
INFO - 2023-05-26 03:23:44 --> Router Class Initialized
INFO - 2023-05-26 03:23:44 --> Output Class Initialized
INFO - 2023-05-26 03:23:44 --> Output Class Initialized
INFO - 2023-05-26 03:23:44 --> Security Class Initialized
INFO - 2023-05-26 03:23:44 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:44 --> Input Class Initialized
DEBUG - 2023-05-26 03:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:44 --> Input Class Initialized
INFO - 2023-05-26 03:23:44 --> Language Class Initialized
INFO - 2023-05-26 03:23:44 --> Language Class Initialized
INFO - 2023-05-26 03:23:44 --> Loader Class Initialized
INFO - 2023-05-26 03:23:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:23:44 --> Loader Class Initialized
INFO - 2023-05-26 03:23:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:23:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:44 --> Model "Login_model" initialized
INFO - 2023-05-26 03:23:44 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:44 --> Total execution time: 0.1052
INFO - 2023-05-26 03:23:44 --> Config Class Initialized
INFO - 2023-05-26 03:23:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:23:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:44 --> URI Class Initialized
INFO - 2023-05-26 03:23:44 --> Router Class Initialized
INFO - 2023-05-26 03:23:44 --> Output Class Initialized
INFO - 2023-05-26 03:23:44 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:44 --> Input Class Initialized
INFO - 2023-05-26 03:23:44 --> Language Class Initialized
INFO - 2023-05-26 03:23:44 --> Loader Class Initialized
INFO - 2023-05-26 03:23:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:23:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:44 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:44 --> Total execution time: 0.1484
INFO - 2023-05-26 03:23:45 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:45 --> Total execution time: 0.7441
INFO - 2023-05-26 03:23:45 --> Config Class Initialized
INFO - 2023-05-26 03:23:45 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:23:45 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:45 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:45 --> URI Class Initialized
INFO - 2023-05-26 03:23:45 --> Router Class Initialized
INFO - 2023-05-26 03:23:45 --> Output Class Initialized
INFO - 2023-05-26 03:23:45 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:45 --> Input Class Initialized
INFO - 2023-05-26 03:23:45 --> Language Class Initialized
INFO - 2023-05-26 03:23:45 --> Loader Class Initialized
INFO - 2023-05-26 03:23:45 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:45 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:23:45 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:45 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:45 --> Model "Login_model" initialized
INFO - 2023-05-26 03:23:45 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:45 --> Total execution time: 0.5998
INFO - 2023-05-26 03:24:12 --> Config Class Initialized
INFO - 2023-05-26 03:24:12 --> Hooks Class Initialized
INFO - 2023-05-26 03:24:12 --> Config Class Initialized
INFO - 2023-05-26 03:24:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:24:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:24:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:24:12 --> URI Class Initialized
DEBUG - 2023-05-26 03:24:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:24:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:24:12 --> Router Class Initialized
INFO - 2023-05-26 03:24:12 --> URI Class Initialized
INFO - 2023-05-26 03:24:12 --> Output Class Initialized
INFO - 2023-05-26 03:24:12 --> Router Class Initialized
INFO - 2023-05-26 03:24:12 --> Security Class Initialized
INFO - 2023-05-26 03:24:12 --> Output Class Initialized
DEBUG - 2023-05-26 03:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:24:12 --> Input Class Initialized
INFO - 2023-05-26 03:24:12 --> Language Class Initialized
INFO - 2023-05-26 03:24:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:24:12 --> Input Class Initialized
INFO - 2023-05-26 03:24:12 --> Language Class Initialized
INFO - 2023-05-26 03:24:12 --> Loader Class Initialized
INFO - 2023-05-26 03:24:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:24:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:24:12 --> Loader Class Initialized
INFO - 2023-05-26 03:24:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:24:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:24:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:24:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:24:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:12 --> Model "Login_model" initialized
INFO - 2023-05-26 03:24:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:24:12 --> Total execution time: 0.0900
INFO - 2023-05-26 03:24:12 --> Config Class Initialized
INFO - 2023-05-26 03:24:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:24:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:24:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:24:12 --> URI Class Initialized
INFO - 2023-05-26 03:24:12 --> Router Class Initialized
INFO - 2023-05-26 03:24:12 --> Output Class Initialized
INFO - 2023-05-26 03:24:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:24:12 --> Input Class Initialized
INFO - 2023-05-26 03:24:12 --> Language Class Initialized
INFO - 2023-05-26 03:24:12 --> Loader Class Initialized
INFO - 2023-05-26 03:24:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:24:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:24:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:24:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:24:12 --> Total execution time: 0.0960
INFO - 2023-05-26 03:24:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:24:12 --> Total execution time: 0.8499
INFO - 2023-05-26 03:24:12 --> Config Class Initialized
INFO - 2023-05-26 03:24:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:24:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:24:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:24:12 --> URI Class Initialized
INFO - 2023-05-26 03:24:12 --> Router Class Initialized
INFO - 2023-05-26 03:24:12 --> Output Class Initialized
INFO - 2023-05-26 03:24:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:24:12 --> Input Class Initialized
INFO - 2023-05-26 03:24:12 --> Language Class Initialized
INFO - 2023-05-26 03:24:12 --> Loader Class Initialized
INFO - 2023-05-26 03:24:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:24:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:24:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:24:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:12 --> Model "Login_model" initialized
INFO - 2023-05-26 03:24:13 --> Final output sent to browser
DEBUG - 2023-05-26 03:24:13 --> Total execution time: 0.6395
INFO - 2023-05-26 03:24:44 --> Config Class Initialized
INFO - 2023-05-26 03:24:44 --> Hooks Class Initialized
INFO - 2023-05-26 03:24:44 --> Config Class Initialized
INFO - 2023-05-26 03:24:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:24:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:24:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:24:44 --> URI Class Initialized
DEBUG - 2023-05-26 03:24:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:24:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:24:44 --> URI Class Initialized
INFO - 2023-05-26 03:24:44 --> Router Class Initialized
INFO - 2023-05-26 03:24:44 --> Router Class Initialized
INFO - 2023-05-26 03:24:44 --> Output Class Initialized
INFO - 2023-05-26 03:24:44 --> Security Class Initialized
INFO - 2023-05-26 03:24:44 --> Output Class Initialized
DEBUG - 2023-05-26 03:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:24:44 --> Input Class Initialized
INFO - 2023-05-26 03:24:44 --> Security Class Initialized
INFO - 2023-05-26 03:24:44 --> Language Class Initialized
DEBUG - 2023-05-26 03:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:24:44 --> Input Class Initialized
INFO - 2023-05-26 03:24:44 --> Language Class Initialized
INFO - 2023-05-26 03:24:44 --> Loader Class Initialized
INFO - 2023-05-26 03:24:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:24:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:24:44 --> Loader Class Initialized
INFO - 2023-05-26 03:24:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:24:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:24:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:24:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:24:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:44 --> Final output sent to browser
DEBUG - 2023-05-26 03:24:44 --> Total execution time: 0.0885
INFO - 2023-05-26 03:24:44 --> Config Class Initialized
INFO - 2023-05-26 03:24:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:24:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:24:44 --> Utf8 Class Initialized
INFO - 2023-05-26 03:24:44 --> Model "Login_model" initialized
INFO - 2023-05-26 03:24:44 --> URI Class Initialized
INFO - 2023-05-26 03:24:44 --> Router Class Initialized
INFO - 2023-05-26 03:24:44 --> Output Class Initialized
INFO - 2023-05-26 03:24:44 --> Security Class Initialized
DEBUG - 2023-05-26 03:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:24:44 --> Input Class Initialized
INFO - 2023-05-26 03:24:44 --> Language Class Initialized
INFO - 2023-05-26 03:24:44 --> Loader Class Initialized
INFO - 2023-05-26 03:24:44 --> Controller Class Initialized
DEBUG - 2023-05-26 03:24:44 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:24:44 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:24:44 --> Final output sent to browser
DEBUG - 2023-05-26 03:24:44 --> Total execution time: 0.1422
INFO - 2023-05-26 03:24:45 --> Final output sent to browser
DEBUG - 2023-05-26 03:24:45 --> Total execution time: 0.7694
INFO - 2023-05-26 03:24:45 --> Config Class Initialized
INFO - 2023-05-26 03:24:45 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:24:45 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:24:45 --> Utf8 Class Initialized
INFO - 2023-05-26 03:24:45 --> URI Class Initialized
INFO - 2023-05-26 03:24:45 --> Router Class Initialized
INFO - 2023-05-26 03:24:45 --> Output Class Initialized
INFO - 2023-05-26 03:24:45 --> Security Class Initialized
DEBUG - 2023-05-26 03:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:24:45 --> Input Class Initialized
INFO - 2023-05-26 03:24:45 --> Language Class Initialized
INFO - 2023-05-26 03:24:45 --> Loader Class Initialized
INFO - 2023-05-26 03:24:45 --> Controller Class Initialized
DEBUG - 2023-05-26 03:24:45 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:24:45 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:24:45 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:45 --> Model "Login_model" initialized
INFO - 2023-05-26 03:24:45 --> Final output sent to browser
DEBUG - 2023-05-26 03:24:45 --> Total execution time: 0.6455
INFO - 2023-05-26 03:25:12 --> Config Class Initialized
INFO - 2023-05-26 03:25:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:12 --> URI Class Initialized
INFO - 2023-05-26 03:25:12 --> Config Class Initialized
INFO - 2023-05-26 03:25:12 --> Hooks Class Initialized
INFO - 2023-05-26 03:25:12 --> Router Class Initialized
INFO - 2023-05-26 03:25:12 --> Output Class Initialized
DEBUG - 2023-05-26 03:25:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:12 --> Security Class Initialized
INFO - 2023-05-26 03:25:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:12 --> URI Class Initialized
DEBUG - 2023-05-26 03:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:12 --> Input Class Initialized
INFO - 2023-05-26 03:25:12 --> Language Class Initialized
INFO - 2023-05-26 03:25:12 --> Router Class Initialized
INFO - 2023-05-26 03:25:12 --> Output Class Initialized
INFO - 2023-05-26 03:25:12 --> Security Class Initialized
INFO - 2023-05-26 03:25:12 --> Loader Class Initialized
DEBUG - 2023-05-26 03:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:12 --> Input Class Initialized
INFO - 2023-05-26 03:25:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:12 --> Language Class Initialized
INFO - 2023-05-26 03:25:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:12 --> Loader Class Initialized
INFO - 2023-05-26 03:25:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:12 --> Total execution time: 0.0832
INFO - 2023-05-26 03:25:12 --> Config Class Initialized
INFO - 2023-05-26 03:25:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:12 --> URI Class Initialized
INFO - 2023-05-26 03:25:12 --> Router Class Initialized
INFO - 2023-05-26 03:25:12 --> Model "Login_model" initialized
INFO - 2023-05-26 03:25:12 --> Output Class Initialized
INFO - 2023-05-26 03:25:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:12 --> Input Class Initialized
INFO - 2023-05-26 03:25:12 --> Language Class Initialized
INFO - 2023-05-26 03:25:12 --> Loader Class Initialized
INFO - 2023-05-26 03:25:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:12 --> Total execution time: 0.0926
INFO - 2023-05-26 03:25:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:12 --> Total execution time: 0.7688
INFO - 2023-05-26 03:25:12 --> Config Class Initialized
INFO - 2023-05-26 03:25:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:12 --> URI Class Initialized
INFO - 2023-05-26 03:25:12 --> Router Class Initialized
INFO - 2023-05-26 03:25:12 --> Output Class Initialized
INFO - 2023-05-26 03:25:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:12 --> Input Class Initialized
INFO - 2023-05-26 03:25:12 --> Language Class Initialized
INFO - 2023-05-26 03:25:12 --> Loader Class Initialized
INFO - 2023-05-26 03:25:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:12 --> Model "Login_model" initialized
INFO - 2023-05-26 03:25:13 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:13 --> Total execution time: 0.7353
INFO - 2023-05-26 03:25:24 --> Config Class Initialized
INFO - 2023-05-26 03:25:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:24 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:24 --> URI Class Initialized
INFO - 2023-05-26 03:25:24 --> Router Class Initialized
INFO - 2023-05-26 03:25:24 --> Output Class Initialized
INFO - 2023-05-26 03:25:24 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:24 --> Input Class Initialized
INFO - 2023-05-26 03:25:24 --> Language Class Initialized
INFO - 2023-05-26 03:25:24 --> Loader Class Initialized
INFO - 2023-05-26 03:25:24 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:24 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:24 --> Model "Login_model" initialized
INFO - 2023-05-26 03:25:24 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:25 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:25 --> Total execution time: 0.1056
INFO - 2023-05-26 03:25:25 --> Config Class Initialized
INFO - 2023-05-26 03:25:25 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:25 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:25 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:25 --> URI Class Initialized
INFO - 2023-05-26 03:25:25 --> Router Class Initialized
INFO - 2023-05-26 03:25:25 --> Output Class Initialized
INFO - 2023-05-26 03:25:25 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:25 --> Input Class Initialized
INFO - 2023-05-26 03:25:25 --> Language Class Initialized
INFO - 2023-05-26 03:25:25 --> Loader Class Initialized
INFO - 2023-05-26 03:25:25 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:25 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:25 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:25 --> Model "Login_model" initialized
INFO - 2023-05-26 03:25:25 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:25 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:25 --> Total execution time: 0.1051
INFO - 2023-05-26 03:25:25 --> Config Class Initialized
INFO - 2023-05-26 03:25:25 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:25 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:25 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:25 --> URI Class Initialized
INFO - 2023-05-26 03:25:25 --> Router Class Initialized
INFO - 2023-05-26 03:25:25 --> Output Class Initialized
INFO - 2023-05-26 03:25:25 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:25 --> Input Class Initialized
INFO - 2023-05-26 03:25:25 --> Language Class Initialized
INFO - 2023-05-26 03:25:25 --> Loader Class Initialized
INFO - 2023-05-26 03:25:25 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:25 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:25 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:25 --> Total execution time: 0.0239
INFO - 2023-05-26 03:25:25 --> Config Class Initialized
INFO - 2023-05-26 03:25:25 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:25 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:25 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:25 --> URI Class Initialized
INFO - 2023-05-26 03:25:25 --> Router Class Initialized
INFO - 2023-05-26 03:25:25 --> Output Class Initialized
INFO - 2023-05-26 03:25:25 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:25 --> Input Class Initialized
INFO - 2023-05-26 03:25:25 --> Language Class Initialized
INFO - 2023-05-26 03:25:25 --> Loader Class Initialized
INFO - 2023-05-26 03:25:25 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:25 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:25 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:25 --> Model "Login_model" initialized
INFO - 2023-05-26 03:25:25 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:25 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:25 --> Total execution time: 0.1047
INFO - 2023-05-26 03:25:27 --> Config Class Initialized
INFO - 2023-05-26 03:25:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:27 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:27 --> URI Class Initialized
INFO - 2023-05-26 03:25:27 --> Router Class Initialized
INFO - 2023-05-26 03:25:27 --> Output Class Initialized
INFO - 2023-05-26 03:25:27 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:27 --> Input Class Initialized
INFO - 2023-05-26 03:25:28 --> Language Class Initialized
INFO - 2023-05-26 03:25:28 --> Loader Class Initialized
INFO - 2023-05-26 03:25:28 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:28 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:28 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:28 --> Total execution time: 0.0225
INFO - 2023-05-26 03:25:28 --> Config Class Initialized
INFO - 2023-05-26 03:25:28 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:28 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:28 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:28 --> URI Class Initialized
INFO - 2023-05-26 03:25:28 --> Router Class Initialized
INFO - 2023-05-26 03:25:28 --> Output Class Initialized
INFO - 2023-05-26 03:25:28 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:28 --> Input Class Initialized
INFO - 2023-05-26 03:25:28 --> Language Class Initialized
INFO - 2023-05-26 03:25:28 --> Loader Class Initialized
INFO - 2023-05-26 03:25:28 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:28 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:28 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:28 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:28 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:28 --> Total execution time: 0.0994
INFO - 2023-05-26 03:25:29 --> Config Class Initialized
INFO - 2023-05-26 03:25:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:29 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:29 --> URI Class Initialized
INFO - 2023-05-26 03:25:29 --> Router Class Initialized
INFO - 2023-05-26 03:25:29 --> Output Class Initialized
INFO - 2023-05-26 03:25:29 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:29 --> Input Class Initialized
INFO - 2023-05-26 03:25:29 --> Language Class Initialized
INFO - 2023-05-26 03:25:29 --> Loader Class Initialized
INFO - 2023-05-26 03:25:29 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:29 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:29 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:29 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:29 --> Total execution time: 0.0597
INFO - 2023-05-26 03:25:29 --> Config Class Initialized
INFO - 2023-05-26 03:25:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:29 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:29 --> URI Class Initialized
INFO - 2023-05-26 03:25:29 --> Router Class Initialized
INFO - 2023-05-26 03:25:29 --> Output Class Initialized
INFO - 2023-05-26 03:25:29 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:29 --> Input Class Initialized
INFO - 2023-05-26 03:25:29 --> Language Class Initialized
INFO - 2023-05-26 03:25:29 --> Loader Class Initialized
INFO - 2023-05-26 03:25:29 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:29 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:29 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:29 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:29 --> Total execution time: 0.0663
INFO - 2023-05-26 03:25:30 --> Config Class Initialized
INFO - 2023-05-26 03:25:30 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:30 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:30 --> URI Class Initialized
INFO - 2023-05-26 03:25:30 --> Router Class Initialized
INFO - 2023-05-26 03:25:30 --> Output Class Initialized
INFO - 2023-05-26 03:25:30 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:30 --> Input Class Initialized
INFO - 2023-05-26 03:25:30 --> Language Class Initialized
INFO - 2023-05-26 03:25:30 --> Loader Class Initialized
INFO - 2023-05-26 03:25:30 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:30 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:30 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:30 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:30 --> Total execution time: 0.0859
INFO - 2023-05-26 03:25:31 --> Config Class Initialized
INFO - 2023-05-26 03:25:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:31 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:31 --> URI Class Initialized
INFO - 2023-05-26 03:25:31 --> Router Class Initialized
INFO - 2023-05-26 03:25:31 --> Output Class Initialized
INFO - 2023-05-26 03:25:31 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:31 --> Input Class Initialized
INFO - 2023-05-26 03:25:31 --> Language Class Initialized
INFO - 2023-05-26 03:25:31 --> Loader Class Initialized
INFO - 2023-05-26 03:25:31 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:31 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:31 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:31 --> Total execution time: 0.0946
INFO - 2023-05-26 03:25:32 --> Config Class Initialized
INFO - 2023-05-26 03:25:32 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:32 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:32 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:32 --> URI Class Initialized
INFO - 2023-05-26 03:25:32 --> Router Class Initialized
INFO - 2023-05-26 03:25:32 --> Output Class Initialized
INFO - 2023-05-26 03:25:32 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:32 --> Input Class Initialized
INFO - 2023-05-26 03:25:32 --> Language Class Initialized
INFO - 2023-05-26 03:25:32 --> Loader Class Initialized
INFO - 2023-05-26 03:25:32 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:32 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:32 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:32 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:32 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:32 --> Total execution time: 0.0704
INFO - 2023-05-26 03:25:33 --> Config Class Initialized
INFO - 2023-05-26 03:25:33 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:33 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:33 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:33 --> URI Class Initialized
INFO - 2023-05-26 03:25:33 --> Router Class Initialized
INFO - 2023-05-26 03:25:33 --> Output Class Initialized
INFO - 2023-05-26 03:25:33 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:33 --> Input Class Initialized
INFO - 2023-05-26 03:25:33 --> Language Class Initialized
INFO - 2023-05-26 03:25:33 --> Loader Class Initialized
INFO - 2023-05-26 03:25:33 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:33 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:33 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:33 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:33 --> Total execution time: 0.0610
INFO - 2023-05-26 03:25:34 --> Config Class Initialized
INFO - 2023-05-26 03:25:34 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:34 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:34 --> URI Class Initialized
INFO - 2023-05-26 03:25:34 --> Router Class Initialized
INFO - 2023-05-26 03:25:34 --> Output Class Initialized
INFO - 2023-05-26 03:25:34 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:34 --> Input Class Initialized
INFO - 2023-05-26 03:25:34 --> Language Class Initialized
INFO - 2023-05-26 03:25:34 --> Loader Class Initialized
INFO - 2023-05-26 03:25:34 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:34 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:34 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:34 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:34 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:34 --> Total execution time: 0.0999
INFO - 2023-05-26 03:25:35 --> Config Class Initialized
INFO - 2023-05-26 03:25:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:35 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:35 --> URI Class Initialized
INFO - 2023-05-26 03:25:35 --> Router Class Initialized
INFO - 2023-05-26 03:25:35 --> Output Class Initialized
INFO - 2023-05-26 03:25:35 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:35 --> Input Class Initialized
INFO - 2023-05-26 03:25:35 --> Language Class Initialized
INFO - 2023-05-26 03:25:35 --> Loader Class Initialized
INFO - 2023-05-26 03:25:35 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:35 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:35 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:35 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:35 --> Total execution time: 0.0709
INFO - 2023-05-26 03:25:35 --> Config Class Initialized
INFO - 2023-05-26 03:25:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:35 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:35 --> URI Class Initialized
INFO - 2023-05-26 03:25:35 --> Router Class Initialized
INFO - 2023-05-26 03:25:35 --> Output Class Initialized
INFO - 2023-05-26 03:25:35 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:35 --> Input Class Initialized
INFO - 2023-05-26 03:25:35 --> Language Class Initialized
INFO - 2023-05-26 03:25:35 --> Loader Class Initialized
INFO - 2023-05-26 03:25:35 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:35 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:35 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:35 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:35 --> Total execution time: 0.1010
INFO - 2023-05-26 03:25:36 --> Config Class Initialized
INFO - 2023-05-26 03:25:36 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:36 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:36 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:36 --> URI Class Initialized
INFO - 2023-05-26 03:25:36 --> Router Class Initialized
INFO - 2023-05-26 03:25:36 --> Output Class Initialized
INFO - 2023-05-26 03:25:36 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:36 --> Input Class Initialized
INFO - 2023-05-26 03:25:36 --> Language Class Initialized
INFO - 2023-05-26 03:25:36 --> Loader Class Initialized
INFO - 2023-05-26 03:25:36 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:36 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:36 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:36 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:36 --> Total execution time: 0.1012
INFO - 2023-05-26 03:25:37 --> Config Class Initialized
INFO - 2023-05-26 03:25:37 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:37 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:37 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:37 --> URI Class Initialized
INFO - 2023-05-26 03:25:37 --> Router Class Initialized
INFO - 2023-05-26 03:25:37 --> Output Class Initialized
INFO - 2023-05-26 03:25:37 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:37 --> Input Class Initialized
INFO - 2023-05-26 03:25:37 --> Language Class Initialized
INFO - 2023-05-26 03:25:37 --> Loader Class Initialized
INFO - 2023-05-26 03:25:37 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:37 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:37 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:37 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:37 --> Total execution time: 0.0797
INFO - 2023-05-26 03:25:38 --> Config Class Initialized
INFO - 2023-05-26 03:25:38 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:25:38 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:25:38 --> Utf8 Class Initialized
INFO - 2023-05-26 03:25:38 --> URI Class Initialized
INFO - 2023-05-26 03:25:38 --> Router Class Initialized
INFO - 2023-05-26 03:25:38 --> Output Class Initialized
INFO - 2023-05-26 03:25:38 --> Security Class Initialized
DEBUG - 2023-05-26 03:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:25:38 --> Input Class Initialized
INFO - 2023-05-26 03:25:38 --> Language Class Initialized
INFO - 2023-05-26 03:25:38 --> Loader Class Initialized
INFO - 2023-05-26 03:25:38 --> Controller Class Initialized
DEBUG - 2023-05-26 03:25:38 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:25:38 --> Database Driver Class Initialized
INFO - 2023-05-26 03:25:38 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:25:38 --> Final output sent to browser
DEBUG - 2023-05-26 03:25:38 --> Total execution time: 0.0871
INFO - 2023-05-26 03:26:12 --> Config Class Initialized
INFO - 2023-05-26 03:26:12 --> Config Class Initialized
INFO - 2023-05-26 03:26:12 --> Hooks Class Initialized
INFO - 2023-05-26 03:26:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:26:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:26:12 --> Utf8 Class Initialized
DEBUG - 2023-05-26 03:26:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:26:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:26:12 --> URI Class Initialized
INFO - 2023-05-26 03:26:12 --> URI Class Initialized
INFO - 2023-05-26 03:26:12 --> Router Class Initialized
INFO - 2023-05-26 03:26:12 --> Router Class Initialized
INFO - 2023-05-26 03:26:12 --> Output Class Initialized
INFO - 2023-05-26 03:26:12 --> Output Class Initialized
INFO - 2023-05-26 03:26:12 --> Security Class Initialized
INFO - 2023-05-26 03:26:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:26:12 --> Input Class Initialized
INFO - 2023-05-26 03:26:12 --> Input Class Initialized
INFO - 2023-05-26 03:26:12 --> Language Class Initialized
INFO - 2023-05-26 03:26:12 --> Language Class Initialized
INFO - 2023-05-26 03:26:12 --> Loader Class Initialized
INFO - 2023-05-26 03:26:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:26:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:26:12 --> Loader Class Initialized
INFO - 2023-05-26 03:26:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:26:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:26:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:26:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:26:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:12 --> Model "Login_model" initialized
INFO - 2023-05-26 03:26:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:26:12 --> Total execution time: 0.0993
INFO - 2023-05-26 03:26:12 --> Config Class Initialized
INFO - 2023-05-26 03:26:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:26:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:26:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:26:12 --> URI Class Initialized
INFO - 2023-05-26 03:26:12 --> Router Class Initialized
INFO - 2023-05-26 03:26:12 --> Output Class Initialized
INFO - 2023-05-26 03:26:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:26:12 --> Input Class Initialized
INFO - 2023-05-26 03:26:12 --> Language Class Initialized
INFO - 2023-05-26 03:26:12 --> Loader Class Initialized
INFO - 2023-05-26 03:26:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:26:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:26:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:26:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:26:12 --> Total execution time: 0.0973
INFO - 2023-05-26 03:26:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:26:12 --> Total execution time: 0.7179
INFO - 2023-05-26 03:26:12 --> Config Class Initialized
INFO - 2023-05-26 03:26:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:26:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:26:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:26:12 --> URI Class Initialized
INFO - 2023-05-26 03:26:12 --> Router Class Initialized
INFO - 2023-05-26 03:26:12 --> Output Class Initialized
INFO - 2023-05-26 03:26:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:26:12 --> Input Class Initialized
INFO - 2023-05-26 03:26:12 --> Language Class Initialized
INFO - 2023-05-26 03:26:12 --> Loader Class Initialized
INFO - 2023-05-26 03:26:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:26:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:26:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:26:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:12 --> Model "Login_model" initialized
INFO - 2023-05-26 03:26:13 --> Final output sent to browser
DEBUG - 2023-05-26 03:26:13 --> Total execution time: 0.6487
INFO - 2023-05-26 03:26:31 --> Config Class Initialized
INFO - 2023-05-26 03:26:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:26:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:26:31 --> Utf8 Class Initialized
INFO - 2023-05-26 03:26:31 --> URI Class Initialized
INFO - 2023-05-26 03:26:31 --> Router Class Initialized
INFO - 2023-05-26 03:26:31 --> Output Class Initialized
INFO - 2023-05-26 03:26:31 --> Security Class Initialized
DEBUG - 2023-05-26 03:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:26:31 --> Input Class Initialized
INFO - 2023-05-26 03:26:31 --> Language Class Initialized
INFO - 2023-05-26 03:26:31 --> Loader Class Initialized
INFO - 2023-05-26 03:26:31 --> Controller Class Initialized
DEBUG - 2023-05-26 03:26:31 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:26:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:26:31 --> Total execution time: 0.0226
INFO - 2023-05-26 03:26:31 --> Config Class Initialized
INFO - 2023-05-26 03:26:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:26:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:26:31 --> Utf8 Class Initialized
INFO - 2023-05-26 03:26:31 --> URI Class Initialized
INFO - 2023-05-26 03:26:31 --> Router Class Initialized
INFO - 2023-05-26 03:26:31 --> Output Class Initialized
INFO - 2023-05-26 03:26:31 --> Security Class Initialized
DEBUG - 2023-05-26 03:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:26:31 --> Input Class Initialized
INFO - 2023-05-26 03:26:31 --> Language Class Initialized
INFO - 2023-05-26 03:26:31 --> Loader Class Initialized
INFO - 2023-05-26 03:26:31 --> Controller Class Initialized
DEBUG - 2023-05-26 03:26:31 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:26:31 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:26:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:26:31 --> Total execution time: 0.0908
INFO - 2023-05-26 03:26:32 --> Config Class Initialized
INFO - 2023-05-26 03:26:32 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:26:32 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:26:32 --> Utf8 Class Initialized
INFO - 2023-05-26 03:26:32 --> URI Class Initialized
INFO - 2023-05-26 03:26:32 --> Router Class Initialized
INFO - 2023-05-26 03:26:32 --> Output Class Initialized
INFO - 2023-05-26 03:26:32 --> Security Class Initialized
DEBUG - 2023-05-26 03:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:26:32 --> Input Class Initialized
INFO - 2023-05-26 03:26:32 --> Language Class Initialized
INFO - 2023-05-26 03:26:32 --> Loader Class Initialized
INFO - 2023-05-26 03:26:32 --> Controller Class Initialized
DEBUG - 2023-05-26 03:26:32 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:26:32 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:32 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:26:32 --> Final output sent to browser
DEBUG - 2023-05-26 03:26:32 --> Total execution time: 0.0654
INFO - 2023-05-26 03:26:32 --> Config Class Initialized
INFO - 2023-05-26 03:26:32 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:26:32 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:26:32 --> Utf8 Class Initialized
INFO - 2023-05-26 03:26:32 --> URI Class Initialized
INFO - 2023-05-26 03:26:32 --> Router Class Initialized
INFO - 2023-05-26 03:26:32 --> Output Class Initialized
INFO - 2023-05-26 03:26:32 --> Security Class Initialized
DEBUG - 2023-05-26 03:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:26:32 --> Input Class Initialized
INFO - 2023-05-26 03:26:32 --> Language Class Initialized
INFO - 2023-05-26 03:26:32 --> Loader Class Initialized
INFO - 2023-05-26 03:26:32 --> Controller Class Initialized
DEBUG - 2023-05-26 03:26:32 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:26:32 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:32 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:26:32 --> Final output sent to browser
DEBUG - 2023-05-26 03:26:32 --> Total execution time: 0.0767
INFO - 2023-05-26 03:26:35 --> Config Class Initialized
INFO - 2023-05-26 03:26:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:26:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:26:35 --> Utf8 Class Initialized
INFO - 2023-05-26 03:26:35 --> URI Class Initialized
INFO - 2023-05-26 03:26:35 --> Router Class Initialized
INFO - 2023-05-26 03:26:35 --> Output Class Initialized
INFO - 2023-05-26 03:26:35 --> Security Class Initialized
DEBUG - 2023-05-26 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:26:35 --> Input Class Initialized
INFO - 2023-05-26 03:26:35 --> Language Class Initialized
INFO - 2023-05-26 03:26:35 --> Loader Class Initialized
INFO - 2023-05-26 03:26:35 --> Controller Class Initialized
DEBUG - 2023-05-26 03:26:35 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:26:35 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:35 --> Model "Login_model" initialized
INFO - 2023-05-26 03:26:35 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:26:35 --> Final output sent to browser
DEBUG - 2023-05-26 03:26:35 --> Total execution time: 0.0880
INFO - 2023-05-26 03:26:35 --> Config Class Initialized
INFO - 2023-05-26 03:26:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:26:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:26:35 --> Utf8 Class Initialized
INFO - 2023-05-26 03:26:35 --> URI Class Initialized
INFO - 2023-05-26 03:26:35 --> Router Class Initialized
INFO - 2023-05-26 03:26:35 --> Output Class Initialized
INFO - 2023-05-26 03:26:35 --> Security Class Initialized
DEBUG - 2023-05-26 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:26:35 --> Input Class Initialized
INFO - 2023-05-26 03:26:35 --> Language Class Initialized
INFO - 2023-05-26 03:26:35 --> Loader Class Initialized
INFO - 2023-05-26 03:26:35 --> Controller Class Initialized
DEBUG - 2023-05-26 03:26:35 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:26:35 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:35 --> Model "Login_model" initialized
INFO - 2023-05-26 03:26:35 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:26:35 --> Final output sent to browser
DEBUG - 2023-05-26 03:26:35 --> Total execution time: 0.0785
INFO - 2023-05-26 03:26:35 --> Config Class Initialized
INFO - 2023-05-26 03:26:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:26:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:26:35 --> Utf8 Class Initialized
INFO - 2023-05-26 03:26:35 --> URI Class Initialized
INFO - 2023-05-26 03:26:35 --> Router Class Initialized
INFO - 2023-05-26 03:26:35 --> Output Class Initialized
INFO - 2023-05-26 03:26:35 --> Security Class Initialized
DEBUG - 2023-05-26 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:26:35 --> Input Class Initialized
INFO - 2023-05-26 03:26:35 --> Language Class Initialized
INFO - 2023-05-26 03:26:35 --> Loader Class Initialized
INFO - 2023-05-26 03:26:35 --> Controller Class Initialized
DEBUG - 2023-05-26 03:26:35 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:26:35 --> Final output sent to browser
DEBUG - 2023-05-26 03:26:35 --> Total execution time: 0.0266
INFO - 2023-05-26 03:26:35 --> Config Class Initialized
INFO - 2023-05-26 03:26:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:26:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:26:35 --> Utf8 Class Initialized
INFO - 2023-05-26 03:26:35 --> URI Class Initialized
INFO - 2023-05-26 03:26:35 --> Router Class Initialized
INFO - 2023-05-26 03:26:35 --> Output Class Initialized
INFO - 2023-05-26 03:26:35 --> Security Class Initialized
DEBUG - 2023-05-26 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:26:35 --> Input Class Initialized
INFO - 2023-05-26 03:26:35 --> Language Class Initialized
INFO - 2023-05-26 03:26:35 --> Loader Class Initialized
INFO - 2023-05-26 03:26:35 --> Controller Class Initialized
DEBUG - 2023-05-26 03:26:35 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:26:35 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:35 --> Model "Login_model" initialized
INFO - 2023-05-26 03:26:35 --> Database Driver Class Initialized
INFO - 2023-05-26 03:26:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:26:35 --> Final output sent to browser
DEBUG - 2023-05-26 03:26:35 --> Total execution time: 0.0826
INFO - 2023-05-26 03:27:12 --> Config Class Initialized
INFO - 2023-05-26 03:27:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:27:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:27:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:27:12 --> URI Class Initialized
INFO - 2023-05-26 03:27:12 --> Router Class Initialized
INFO - 2023-05-26 03:27:12 --> Output Class Initialized
INFO - 2023-05-26 03:27:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:27:12 --> Input Class Initialized
INFO - 2023-05-26 03:27:12 --> Language Class Initialized
INFO - 2023-05-26 03:27:12 --> Loader Class Initialized
INFO - 2023-05-26 03:27:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:27:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:27:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:27:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:27:12 --> Total execution time: 0.1013
INFO - 2023-05-26 03:27:12 --> Config Class Initialized
INFO - 2023-05-26 03:27:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:27:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:27:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:27:12 --> URI Class Initialized
INFO - 2023-05-26 03:27:12 --> Router Class Initialized
INFO - 2023-05-26 03:27:12 --> Output Class Initialized
INFO - 2023-05-26 03:27:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:27:12 --> Input Class Initialized
INFO - 2023-05-26 03:27:12 --> Language Class Initialized
INFO - 2023-05-26 03:27:12 --> Loader Class Initialized
INFO - 2023-05-26 03:27:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:27:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:27:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:27:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:27:12 --> Total execution time: 0.1035
INFO - 2023-05-26 03:27:13 --> Config Class Initialized
INFO - 2023-05-26 03:27:13 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:27:13 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:27:13 --> Utf8 Class Initialized
INFO - 2023-05-26 03:27:13 --> URI Class Initialized
INFO - 2023-05-26 03:27:13 --> Router Class Initialized
INFO - 2023-05-26 03:27:13 --> Output Class Initialized
INFO - 2023-05-26 03:27:13 --> Security Class Initialized
DEBUG - 2023-05-26 03:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:27:13 --> Input Class Initialized
INFO - 2023-05-26 03:27:13 --> Language Class Initialized
INFO - 2023-05-26 03:27:13 --> Loader Class Initialized
INFO - 2023-05-26 03:27:13 --> Controller Class Initialized
DEBUG - 2023-05-26 03:27:13 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:27:13 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:13 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:27:13 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:13 --> Model "Login_model" initialized
INFO - 2023-05-26 03:27:13 --> Final output sent to browser
DEBUG - 2023-05-26 03:27:13 --> Total execution time: 0.7970
INFO - 2023-05-26 03:27:13 --> Config Class Initialized
INFO - 2023-05-26 03:27:13 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:27:13 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:27:13 --> Utf8 Class Initialized
INFO - 2023-05-26 03:27:13 --> URI Class Initialized
INFO - 2023-05-26 03:27:13 --> Router Class Initialized
INFO - 2023-05-26 03:27:13 --> Output Class Initialized
INFO - 2023-05-26 03:27:13 --> Security Class Initialized
DEBUG - 2023-05-26 03:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:27:13 --> Input Class Initialized
INFO - 2023-05-26 03:27:13 --> Language Class Initialized
INFO - 2023-05-26 03:27:13 --> Loader Class Initialized
INFO - 2023-05-26 03:27:13 --> Controller Class Initialized
DEBUG - 2023-05-26 03:27:13 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:27:13 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:13 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:27:13 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:13 --> Model "Login_model" initialized
INFO - 2023-05-26 03:27:14 --> Final output sent to browser
DEBUG - 2023-05-26 03:27:14 --> Total execution time: 0.6582
INFO - 2023-05-26 03:28:12 --> Config Class Initialized
INFO - 2023-05-26 03:28:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:28:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:28:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:28:12 --> URI Class Initialized
INFO - 2023-05-26 03:28:12 --> Router Class Initialized
INFO - 2023-05-26 03:28:12 --> Output Class Initialized
INFO - 2023-05-26 03:28:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:28:12 --> Input Class Initialized
INFO - 2023-05-26 03:28:12 --> Language Class Initialized
INFO - 2023-05-26 03:28:12 --> Loader Class Initialized
INFO - 2023-05-26 03:28:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:28:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:28:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:28:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:28:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:28:12 --> Total execution time: 0.0956
INFO - 2023-05-26 03:28:12 --> Config Class Initialized
INFO - 2023-05-26 03:28:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:28:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:28:12 --> Utf8 Class Initialized
INFO - 2023-05-26 03:28:12 --> URI Class Initialized
INFO - 2023-05-26 03:28:12 --> Router Class Initialized
INFO - 2023-05-26 03:28:12 --> Output Class Initialized
INFO - 2023-05-26 03:28:12 --> Security Class Initialized
DEBUG - 2023-05-26 03:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:28:12 --> Input Class Initialized
INFO - 2023-05-26 03:28:12 --> Language Class Initialized
INFO - 2023-05-26 03:28:12 --> Loader Class Initialized
INFO - 2023-05-26 03:28:12 --> Controller Class Initialized
DEBUG - 2023-05-26 03:28:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:28:12 --> Database Driver Class Initialized
INFO - 2023-05-26 03:28:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:28:12 --> Final output sent to browser
DEBUG - 2023-05-26 03:28:12 --> Total execution time: 0.0933
INFO - 2023-05-26 03:28:13 --> Config Class Initialized
INFO - 2023-05-26 03:28:13 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:28:13 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:28:13 --> Utf8 Class Initialized
INFO - 2023-05-26 03:28:13 --> URI Class Initialized
INFO - 2023-05-26 03:28:13 --> Router Class Initialized
INFO - 2023-05-26 03:28:13 --> Output Class Initialized
INFO - 2023-05-26 03:28:13 --> Security Class Initialized
DEBUG - 2023-05-26 03:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:28:13 --> Input Class Initialized
INFO - 2023-05-26 03:28:13 --> Language Class Initialized
INFO - 2023-05-26 03:28:13 --> Loader Class Initialized
INFO - 2023-05-26 03:28:13 --> Controller Class Initialized
DEBUG - 2023-05-26 03:28:13 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:28:13 --> Database Driver Class Initialized
INFO - 2023-05-26 03:28:13 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:28:13 --> Database Driver Class Initialized
INFO - 2023-05-26 03:28:13 --> Model "Login_model" initialized
INFO - 2023-05-26 03:28:14 --> Final output sent to browser
DEBUG - 2023-05-26 03:28:14 --> Total execution time: 1.0944
INFO - 2023-05-26 03:28:14 --> Config Class Initialized
INFO - 2023-05-26 03:28:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:28:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:28:14 --> Utf8 Class Initialized
INFO - 2023-05-26 03:28:14 --> URI Class Initialized
INFO - 2023-05-26 03:28:14 --> Router Class Initialized
INFO - 2023-05-26 03:28:14 --> Output Class Initialized
INFO - 2023-05-26 03:28:14 --> Security Class Initialized
DEBUG - 2023-05-26 03:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:28:14 --> Input Class Initialized
INFO - 2023-05-26 03:28:14 --> Language Class Initialized
INFO - 2023-05-26 03:28:14 --> Loader Class Initialized
INFO - 2023-05-26 03:28:14 --> Controller Class Initialized
DEBUG - 2023-05-26 03:28:14 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:28:14 --> Database Driver Class Initialized
INFO - 2023-05-26 03:28:14 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:28:14 --> Database Driver Class Initialized
INFO - 2023-05-26 03:28:14 --> Model "Login_model" initialized
INFO - 2023-05-26 03:28:15 --> Final output sent to browser
DEBUG - 2023-05-26 03:28:15 --> Total execution time: 1.1940
INFO - 2023-05-26 03:29:14 --> Config Class Initialized
INFO - 2023-05-26 03:29:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:29:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:29:14 --> Utf8 Class Initialized
INFO - 2023-05-26 03:29:14 --> URI Class Initialized
INFO - 2023-05-26 03:29:14 --> Router Class Initialized
INFO - 2023-05-26 03:29:14 --> Output Class Initialized
INFO - 2023-05-26 03:29:14 --> Security Class Initialized
DEBUG - 2023-05-26 03:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:29:14 --> Input Class Initialized
INFO - 2023-05-26 03:29:14 --> Language Class Initialized
INFO - 2023-05-26 03:29:14 --> Loader Class Initialized
INFO - 2023-05-26 03:29:14 --> Controller Class Initialized
DEBUG - 2023-05-26 03:29:14 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:29:14 --> Database Driver Class Initialized
INFO - 2023-05-26 03:29:14 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:29:14 --> Final output sent to browser
DEBUG - 2023-05-26 03:29:14 --> Total execution time: 0.1598
INFO - 2023-05-26 03:29:14 --> Config Class Initialized
INFO - 2023-05-26 03:29:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:29:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:29:14 --> Utf8 Class Initialized
INFO - 2023-05-26 03:29:14 --> URI Class Initialized
INFO - 2023-05-26 03:29:14 --> Router Class Initialized
INFO - 2023-05-26 03:29:14 --> Output Class Initialized
INFO - 2023-05-26 03:29:14 --> Security Class Initialized
DEBUG - 2023-05-26 03:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:29:14 --> Input Class Initialized
INFO - 2023-05-26 03:29:14 --> Language Class Initialized
INFO - 2023-05-26 03:29:14 --> Loader Class Initialized
INFO - 2023-05-26 03:29:14 --> Controller Class Initialized
DEBUG - 2023-05-26 03:29:14 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:29:14 --> Database Driver Class Initialized
INFO - 2023-05-26 03:29:14 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:29:14 --> Final output sent to browser
DEBUG - 2023-05-26 03:29:14 --> Total execution time: 0.0926
INFO - 2023-05-26 03:29:42 --> Config Class Initialized
INFO - 2023-05-26 03:29:42 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:29:42 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:29:42 --> Utf8 Class Initialized
INFO - 2023-05-26 03:29:42 --> URI Class Initialized
INFO - 2023-05-26 03:29:42 --> Router Class Initialized
INFO - 2023-05-26 03:29:42 --> Output Class Initialized
INFO - 2023-05-26 03:29:42 --> Security Class Initialized
DEBUG - 2023-05-26 03:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:29:42 --> Input Class Initialized
INFO - 2023-05-26 03:29:42 --> Language Class Initialized
INFO - 2023-05-26 03:29:42 --> Loader Class Initialized
INFO - 2023-05-26 03:29:42 --> Controller Class Initialized
DEBUG - 2023-05-26 03:29:42 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:29:42 --> Database Driver Class Initialized
INFO - 2023-05-26 03:29:42 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:29:42 --> Database Driver Class Initialized
INFO - 2023-05-26 03:29:42 --> Model "Login_model" initialized
INFO - 2023-05-26 03:29:42 --> Final output sent to browser
DEBUG - 2023-05-26 03:29:42 --> Total execution time: 0.7309
INFO - 2023-05-26 03:29:42 --> Config Class Initialized
INFO - 2023-05-26 03:29:42 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:29:42 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:29:42 --> Utf8 Class Initialized
INFO - 2023-05-26 03:29:42 --> URI Class Initialized
INFO - 2023-05-26 03:29:42 --> Router Class Initialized
INFO - 2023-05-26 03:29:42 --> Output Class Initialized
INFO - 2023-05-26 03:29:42 --> Security Class Initialized
DEBUG - 2023-05-26 03:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:29:42 --> Input Class Initialized
INFO - 2023-05-26 03:29:42 --> Language Class Initialized
INFO - 2023-05-26 03:29:42 --> Loader Class Initialized
INFO - 2023-05-26 03:29:42 --> Controller Class Initialized
DEBUG - 2023-05-26 03:29:42 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-05-26 03:29:42 --> Database Driver Class Initialized
INFO - 2023-05-26 03:29:42 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:29:42 --> Database Driver Class Initialized
INFO - 2023-05-26 03:29:42 --> Model "Login_model" initialized
INFO - 2023-05-26 03:29:43 --> Final output sent to browser
DEBUG - 2023-05-26 03:29:43 --> Total execution time: 0.6917
