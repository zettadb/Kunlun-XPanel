<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-26 01:43:17 --> Config Class Initialized
INFO - 2023-05-26 01:43:17 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:43:17 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:17 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:17 --> URI Class Initialized
INFO - 2023-05-26 01:43:17 --> Router Class Initialized
INFO - 2023-05-26 01:43:17 --> Output Class Initialized
INFO - 2023-05-26 01:43:17 --> Security Class Initialized
DEBUG - 2023-05-26 01:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:17 --> Input Class Initialized
INFO - 2023-05-26 01:43:17 --> Language Class Initialized
INFO - 2023-05-26 01:43:17 --> Loader Class Initialized
INFO - 2023-05-26 01:43:17 --> Controller Class Initialized
INFO - 2023-05-26 01:43:17 --> Helper loaded: form_helper
INFO - 2023-05-26 01:43:17 --> Helper loaded: url_helper
DEBUG - 2023-05-26 01:43:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:43:17 --> Model "Change_model" initialized
INFO - 2023-05-26 01:43:17 --> Model "Grafana_model" initialized
INFO - 2023-05-26 01:43:18 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:18 --> Total execution time: 1.1711
INFO - 2023-05-26 01:43:18 --> Config Class Initialized
INFO - 2023-05-26 01:43:18 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:43:18 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:18 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:18 --> URI Class Initialized
INFO - 2023-05-26 01:43:18 --> Router Class Initialized
INFO - 2023-05-26 01:43:18 --> Output Class Initialized
INFO - 2023-05-26 01:43:18 --> Security Class Initialized
DEBUG - 2023-05-26 01:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:18 --> Input Class Initialized
INFO - 2023-05-26 01:43:18 --> Language Class Initialized
INFO - 2023-05-26 01:43:18 --> Loader Class Initialized
INFO - 2023-05-26 01:43:18 --> Controller Class Initialized
INFO - 2023-05-26 01:43:18 --> Helper loaded: form_helper
INFO - 2023-05-26 01:43:18 --> Helper loaded: url_helper
DEBUG - 2023-05-26 01:43:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:43:18 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:18 --> Total execution time: 0.2873
INFO - 2023-05-26 01:43:18 --> Config Class Initialized
INFO - 2023-05-26 01:43:18 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:43:18 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:18 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:18 --> URI Class Initialized
INFO - 2023-05-26 01:43:18 --> Router Class Initialized
INFO - 2023-05-26 01:43:18 --> Output Class Initialized
INFO - 2023-05-26 01:43:18 --> Security Class Initialized
DEBUG - 2023-05-26 01:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:18 --> Input Class Initialized
INFO - 2023-05-26 01:43:18 --> Language Class Initialized
INFO - 2023-05-26 01:43:18 --> Loader Class Initialized
INFO - 2023-05-26 01:43:18 --> Controller Class Initialized
INFO - 2023-05-26 01:43:18 --> Helper loaded: form_helper
INFO - 2023-05-26 01:43:18 --> Helper loaded: url_helper
DEBUG - 2023-05-26 01:43:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:43:19 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:19 --> Model "Login_model" initialized
INFO - 2023-05-26 01:43:19 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:19 --> Total execution time: 0.5335
INFO - 2023-05-26 01:43:19 --> Config Class Initialized
INFO - 2023-05-26 01:43:19 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:43:19 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:19 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:19 --> URI Class Initialized
INFO - 2023-05-26 01:43:19 --> Router Class Initialized
INFO - 2023-05-26 01:43:19 --> Output Class Initialized
INFO - 2023-05-26 01:43:19 --> Security Class Initialized
DEBUG - 2023-05-26 01:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:19 --> Input Class Initialized
INFO - 2023-05-26 01:43:19 --> Language Class Initialized
INFO - 2023-05-26 01:43:19 --> Loader Class Initialized
INFO - 2023-05-26 01:43:19 --> Controller Class Initialized
DEBUG - 2023-05-26 01:43:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:43:19 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:19 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:43:19 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:19 --> Total execution time: 0.2827
INFO - 2023-05-26 01:43:19 --> Config Class Initialized
INFO - 2023-05-26 01:43:19 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:43:19 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:19 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:19 --> URI Class Initialized
INFO - 2023-05-26 01:43:19 --> Router Class Initialized
INFO - 2023-05-26 01:43:19 --> Output Class Initialized
INFO - 2023-05-26 01:43:19 --> Security Class Initialized
DEBUG - 2023-05-26 01:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:19 --> Input Class Initialized
INFO - 2023-05-26 01:43:19 --> Language Class Initialized
INFO - 2023-05-26 01:43:19 --> Loader Class Initialized
INFO - 2023-05-26 01:43:19 --> Controller Class Initialized
DEBUG - 2023-05-26 01:43:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:43:19 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:19 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:43:19 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:19 --> Total execution time: 0.2511
INFO - 2023-05-26 01:43:19 --> Config Class Initialized
INFO - 2023-05-26 01:43:19 --> Config Class Initialized
INFO - 2023-05-26 01:43:20 --> Hooks Class Initialized
INFO - 2023-05-26 01:43:20 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:43:20 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:43:20 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:20 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:20 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:20 --> URI Class Initialized
INFO - 2023-05-26 01:43:20 --> URI Class Initialized
INFO - 2023-05-26 01:43:20 --> Router Class Initialized
INFO - 2023-05-26 01:43:20 --> Router Class Initialized
INFO - 2023-05-26 01:43:20 --> Output Class Initialized
INFO - 2023-05-26 01:43:20 --> Output Class Initialized
INFO - 2023-05-26 01:43:20 --> Security Class Initialized
INFO - 2023-05-26 01:43:20 --> Security Class Initialized
DEBUG - 2023-05-26 01:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:20 --> Input Class Initialized
INFO - 2023-05-26 01:43:20 --> Input Class Initialized
INFO - 2023-05-26 01:43:20 --> Language Class Initialized
INFO - 2023-05-26 01:43:20 --> Language Class Initialized
INFO - 2023-05-26 01:43:20 --> Loader Class Initialized
INFO - 2023-05-26 01:43:20 --> Loader Class Initialized
INFO - 2023-05-26 01:43:20 --> Controller Class Initialized
INFO - 2023-05-26 01:43:20 --> Controller Class Initialized
DEBUG - 2023-05-26 01:43:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 01:43:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:43:20 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:20 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:20 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:43:20 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:43:20 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:20 --> Total execution time: 0.2547
INFO - 2023-05-26 01:43:20 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:20 --> Config Class Initialized
INFO - 2023-05-26 01:43:20 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:43:20 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:20 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:20 --> URI Class Initialized
INFO - 2023-05-26 01:43:20 --> Router Class Initialized
INFO - 2023-05-26 01:43:20 --> Output Class Initialized
INFO - 2023-05-26 01:43:20 --> Security Class Initialized
DEBUG - 2023-05-26 01:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:20 --> Input Class Initialized
INFO - 2023-05-26 01:43:20 --> Language Class Initialized
INFO - 2023-05-26 01:43:20 --> Loader Class Initialized
INFO - 2023-05-26 01:43:20 --> Model "Login_model" initialized
INFO - 2023-05-26 01:43:20 --> Controller Class Initialized
DEBUG - 2023-05-26 01:43:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:43:20 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:20 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:43:20 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:20 --> Total execution time: 0.2679
INFO - 2023-05-26 01:43:20 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:20 --> Total execution time: 0.6403
INFO - 2023-05-26 01:43:20 --> Config Class Initialized
INFO - 2023-05-26 01:43:20 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:43:20 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:20 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:20 --> URI Class Initialized
INFO - 2023-05-26 01:43:20 --> Router Class Initialized
INFO - 2023-05-26 01:43:20 --> Output Class Initialized
INFO - 2023-05-26 01:43:20 --> Security Class Initialized
DEBUG - 2023-05-26 01:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:20 --> Input Class Initialized
INFO - 2023-05-26 01:43:20 --> Language Class Initialized
INFO - 2023-05-26 01:43:20 --> Loader Class Initialized
INFO - 2023-05-26 01:43:20 --> Controller Class Initialized
DEBUG - 2023-05-26 01:43:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:43:20 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:20 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:43:20 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:20 --> Model "Login_model" initialized
INFO - 2023-05-26 01:43:21 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:21 --> Total execution time: 0.4020
INFO - 2023-05-26 01:43:26 --> Config Class Initialized
INFO - 2023-05-26 01:43:26 --> Config Class Initialized
INFO - 2023-05-26 01:43:26 --> Config Class Initialized
INFO - 2023-05-26 01:43:26 --> Hooks Class Initialized
INFO - 2023-05-26 01:43:26 --> Hooks Class Initialized
INFO - 2023-05-26 01:43:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:43:26 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:43:26 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:43:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:26 --> URI Class Initialized
INFO - 2023-05-26 01:43:26 --> URI Class Initialized
INFO - 2023-05-26 01:43:26 --> URI Class Initialized
INFO - 2023-05-26 01:43:26 --> Router Class Initialized
INFO - 2023-05-26 01:43:26 --> Router Class Initialized
INFO - 2023-05-26 01:43:26 --> Router Class Initialized
INFO - 2023-05-26 01:43:26 --> Output Class Initialized
INFO - 2023-05-26 01:43:26 --> Output Class Initialized
INFO - 2023-05-26 01:43:26 --> Output Class Initialized
INFO - 2023-05-26 01:43:26 --> Security Class Initialized
INFO - 2023-05-26 01:43:26 --> Security Class Initialized
INFO - 2023-05-26 01:43:26 --> Security Class Initialized
DEBUG - 2023-05-26 01:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:26 --> Input Class Initialized
INFO - 2023-05-26 01:43:26 --> Input Class Initialized
INFO - 2023-05-26 01:43:26 --> Input Class Initialized
INFO - 2023-05-26 01:43:26 --> Language Class Initialized
INFO - 2023-05-26 01:43:26 --> Language Class Initialized
INFO - 2023-05-26 01:43:26 --> Language Class Initialized
INFO - 2023-05-26 01:43:26 --> Loader Class Initialized
INFO - 2023-05-26 01:43:26 --> Loader Class Initialized
INFO - 2023-05-26 01:43:26 --> Controller Class Initialized
INFO - 2023-05-26 01:43:26 --> Controller Class Initialized
DEBUG - 2023-05-26 01:43:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 01:43:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:43:26 --> Loader Class Initialized
INFO - 2023-05-26 01:43:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:26 --> Controller Class Initialized
DEBUG - 2023-05-26 01:43:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:43:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:43:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:43:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:26 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:26 --> Total execution time: 0.3118
INFO - 2023-05-26 01:43:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:26 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:26 --> Total execution time: 0.3698
INFO - 2023-05-26 01:43:26 --> Model "Login_model" initialized
INFO - 2023-05-26 01:43:26 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:26 --> Total execution time: 0.4080
INFO - 2023-05-26 01:43:26 --> Config Class Initialized
INFO - 2023-05-26 01:43:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:43:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:26 --> Config Class Initialized
INFO - 2023-05-26 01:43:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:26 --> Hooks Class Initialized
INFO - 2023-05-26 01:43:26 --> URI Class Initialized
INFO - 2023-05-26 01:43:26 --> Config Class Initialized
INFO - 2023-05-26 01:43:26 --> Hooks Class Initialized
INFO - 2023-05-26 01:43:26 --> Router Class Initialized
DEBUG - 2023-05-26 01:43:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:26 --> Output Class Initialized
INFO - 2023-05-26 01:43:26 --> URI Class Initialized
DEBUG - 2023-05-26 01:43:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:26 --> Security Class Initialized
INFO - 2023-05-26 01:43:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:26 --> Router Class Initialized
INFO - 2023-05-26 01:43:26 --> URI Class Initialized
DEBUG - 2023-05-26 01:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:26 --> Input Class Initialized
INFO - 2023-05-26 01:43:26 --> Language Class Initialized
INFO - 2023-05-26 01:43:26 --> Output Class Initialized
INFO - 2023-05-26 01:43:26 --> Router Class Initialized
INFO - 2023-05-26 01:43:26 --> Security Class Initialized
INFO - 2023-05-26 01:43:26 --> Output Class Initialized
DEBUG - 2023-05-26 01:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:26 --> Security Class Initialized
INFO - 2023-05-26 01:43:26 --> Loader Class Initialized
INFO - 2023-05-26 01:43:26 --> Input Class Initialized
INFO - 2023-05-26 01:43:26 --> Language Class Initialized
DEBUG - 2023-05-26 01:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:26 --> Controller Class Initialized
INFO - 2023-05-26 01:43:26 --> Input Class Initialized
INFO - 2023-05-26 01:43:26 --> Language Class Initialized
DEBUG - 2023-05-26 01:43:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:43:26 --> Loader Class Initialized
INFO - 2023-05-26 01:43:26 --> Loader Class Initialized
INFO - 2023-05-26 01:43:26 --> Controller Class Initialized
INFO - 2023-05-26 01:43:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:26 --> Controller Class Initialized
DEBUG - 2023-05-26 01:43:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 01:43:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:43:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:43:27 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:27 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:27 --> Final output sent to browser
INFO - 2023-05-26 01:43:27 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 01:43:27 --> Total execution time: 0.3953
INFO - 2023-05-26 01:43:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:43:27 --> Final output sent to browser
INFO - 2023-05-26 01:43:27 --> Config Class Initialized
DEBUG - 2023-05-26 01:43:27 --> Total execution time: 0.3749
INFO - 2023-05-26 01:43:27 --> Hooks Class Initialized
INFO - 2023-05-26 01:43:27 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:27 --> Total execution time: 0.3786
INFO - 2023-05-26 01:43:27 --> Config Class Initialized
INFO - 2023-05-26 01:43:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:43:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:27 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:27 --> URI Class Initialized
DEBUG - 2023-05-26 01:43:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:43:27 --> Utf8 Class Initialized
INFO - 2023-05-26 01:43:27 --> Router Class Initialized
INFO - 2023-05-26 01:43:27 --> URI Class Initialized
INFO - 2023-05-26 01:43:27 --> Router Class Initialized
INFO - 2023-05-26 01:43:27 --> Output Class Initialized
INFO - 2023-05-26 01:43:27 --> Security Class Initialized
INFO - 2023-05-26 01:43:27 --> Output Class Initialized
DEBUG - 2023-05-26 01:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:27 --> Security Class Initialized
INFO - 2023-05-26 01:43:27 --> Input Class Initialized
DEBUG - 2023-05-26 01:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:43:27 --> Language Class Initialized
INFO - 2023-05-26 01:43:27 --> Input Class Initialized
INFO - 2023-05-26 01:43:27 --> Language Class Initialized
INFO - 2023-05-26 01:43:27 --> Loader Class Initialized
INFO - 2023-05-26 01:43:27 --> Loader Class Initialized
INFO - 2023-05-26 01:43:27 --> Controller Class Initialized
INFO - 2023-05-26 01:43:27 --> Controller Class Initialized
DEBUG - 2023-05-26 01:43:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 01:43:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:43:27 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:27 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:43:27 --> Database Driver Class Initialized
INFO - 2023-05-26 01:43:27 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:27 --> Total execution time: 0.3088
INFO - 2023-05-26 01:43:27 --> Model "Login_model" initialized
INFO - 2023-05-26 01:43:27 --> Final output sent to browser
DEBUG - 2023-05-26 01:43:27 --> Total execution time: 0.4201
INFO - 2023-05-26 01:44:26 --> Config Class Initialized
INFO - 2023-05-26 01:44:26 --> Config Class Initialized
INFO - 2023-05-26 01:44:26 --> Hooks Class Initialized
INFO - 2023-05-26 01:44:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:44:26 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:44:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:44:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:44:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:44:26 --> URI Class Initialized
INFO - 2023-05-26 01:44:26 --> URI Class Initialized
INFO - 2023-05-26 01:44:26 --> Router Class Initialized
INFO - 2023-05-26 01:44:26 --> Router Class Initialized
INFO - 2023-05-26 01:44:26 --> Output Class Initialized
INFO - 2023-05-26 01:44:26 --> Output Class Initialized
INFO - 2023-05-26 01:44:26 --> Security Class Initialized
INFO - 2023-05-26 01:44:26 --> Security Class Initialized
DEBUG - 2023-05-26 01:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:44:26 --> Input Class Initialized
INFO - 2023-05-26 01:44:26 --> Input Class Initialized
INFO - 2023-05-26 01:44:26 --> Language Class Initialized
INFO - 2023-05-26 01:44:26 --> Language Class Initialized
INFO - 2023-05-26 01:44:26 --> Loader Class Initialized
INFO - 2023-05-26 01:44:26 --> Loader Class Initialized
INFO - 2023-05-26 01:44:26 --> Controller Class Initialized
DEBUG - 2023-05-26 01:44:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:44:26 --> Controller Class Initialized
DEBUG - 2023-05-26 01:44:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:44:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:44:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:44:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:44:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:44:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:44:26 --> Model "Login_model" initialized
INFO - 2023-05-26 01:44:26 --> Final output sent to browser
DEBUG - 2023-05-26 01:44:26 --> Total execution time: 0.2470
INFO - 2023-05-26 01:44:26 --> Config Class Initialized
INFO - 2023-05-26 01:44:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:44:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:44:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:44:26 --> URI Class Initialized
INFO - 2023-05-26 01:44:26 --> Router Class Initialized
INFO - 2023-05-26 01:44:26 --> Output Class Initialized
INFO - 2023-05-26 01:44:26 --> Security Class Initialized
DEBUG - 2023-05-26 01:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:44:26 --> Input Class Initialized
INFO - 2023-05-26 01:44:26 --> Language Class Initialized
INFO - 2023-05-26 01:44:26 --> Loader Class Initialized
INFO - 2023-05-26 01:44:26 --> Controller Class Initialized
DEBUG - 2023-05-26 01:44:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:44:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:44:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:44:26 --> Final output sent to browser
DEBUG - 2023-05-26 01:44:26 --> Total execution time: 0.2987
INFO - 2023-05-26 01:44:34 --> Final output sent to browser
DEBUG - 2023-05-26 01:44:34 --> Total execution time: 8.4826
INFO - 2023-05-26 01:44:34 --> Config Class Initialized
INFO - 2023-05-26 01:44:34 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:44:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:44:34 --> Utf8 Class Initialized
INFO - 2023-05-26 01:44:34 --> URI Class Initialized
INFO - 2023-05-26 01:44:34 --> Router Class Initialized
INFO - 2023-05-26 01:44:34 --> Output Class Initialized
INFO - 2023-05-26 01:44:34 --> Security Class Initialized
DEBUG - 2023-05-26 01:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:44:34 --> Input Class Initialized
INFO - 2023-05-26 01:44:34 --> Language Class Initialized
INFO - 2023-05-26 01:44:34 --> Loader Class Initialized
INFO - 2023-05-26 01:44:34 --> Controller Class Initialized
DEBUG - 2023-05-26 01:44:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:44:34 --> Database Driver Class Initialized
INFO - 2023-05-26 01:44:34 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:44:34 --> Database Driver Class Initialized
INFO - 2023-05-26 01:44:34 --> Model "Login_model" initialized
INFO - 2023-05-26 01:44:45 --> Final output sent to browser
DEBUG - 2023-05-26 01:44:45 --> Total execution time: 10.4454
INFO - 2023-05-26 01:45:26 --> Config Class Initialized
INFO - 2023-05-26 01:45:26 --> Config Class Initialized
INFO - 2023-05-26 01:45:26 --> Hooks Class Initialized
INFO - 2023-05-26 01:45:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:45:26 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:45:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:45:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:45:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:45:26 --> URI Class Initialized
INFO - 2023-05-26 01:45:26 --> URI Class Initialized
INFO - 2023-05-26 01:45:26 --> Router Class Initialized
INFO - 2023-05-26 01:45:26 --> Router Class Initialized
INFO - 2023-05-26 01:45:26 --> Output Class Initialized
INFO - 2023-05-26 01:45:26 --> Output Class Initialized
INFO - 2023-05-26 01:45:26 --> Security Class Initialized
INFO - 2023-05-26 01:45:26 --> Security Class Initialized
DEBUG - 2023-05-26 01:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:45:26 --> Input Class Initialized
INFO - 2023-05-26 01:45:26 --> Input Class Initialized
INFO - 2023-05-26 01:45:26 --> Language Class Initialized
INFO - 2023-05-26 01:45:26 --> Language Class Initialized
INFO - 2023-05-26 01:45:26 --> Loader Class Initialized
INFO - 2023-05-26 01:45:26 --> Loader Class Initialized
INFO - 2023-05-26 01:45:26 --> Controller Class Initialized
DEBUG - 2023-05-26 01:45:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:45:26 --> Controller Class Initialized
DEBUG - 2023-05-26 01:45:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:45:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:45:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:45:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:45:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:45:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:45:26 --> Final output sent to browser
DEBUG - 2023-05-26 01:45:26 --> Total execution time: 0.2079
INFO - 2023-05-26 01:45:26 --> Model "Login_model" initialized
INFO - 2023-05-26 01:45:26 --> Config Class Initialized
INFO - 2023-05-26 01:45:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:45:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:45:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:45:26 --> URI Class Initialized
INFO - 2023-05-26 01:45:26 --> Router Class Initialized
INFO - 2023-05-26 01:45:26 --> Output Class Initialized
INFO - 2023-05-26 01:45:26 --> Security Class Initialized
DEBUG - 2023-05-26 01:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:45:26 --> Input Class Initialized
INFO - 2023-05-26 01:45:26 --> Language Class Initialized
INFO - 2023-05-26 01:45:27 --> Loader Class Initialized
INFO - 2023-05-26 01:45:27 --> Controller Class Initialized
DEBUG - 2023-05-26 01:45:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:45:27 --> Database Driver Class Initialized
INFO - 2023-05-26 01:45:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:45:27 --> Final output sent to browser
DEBUG - 2023-05-26 01:45:27 --> Total execution time: 0.3707
INFO - 2023-05-26 01:45:35 --> Final output sent to browser
DEBUG - 2023-05-26 01:45:35 --> Total execution time: 8.7592
INFO - 2023-05-26 01:45:35 --> Config Class Initialized
INFO - 2023-05-26 01:45:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:45:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:45:35 --> Utf8 Class Initialized
INFO - 2023-05-26 01:45:35 --> URI Class Initialized
INFO - 2023-05-26 01:45:35 --> Router Class Initialized
INFO - 2023-05-26 01:45:35 --> Output Class Initialized
INFO - 2023-05-26 01:45:35 --> Security Class Initialized
DEBUG - 2023-05-26 01:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:45:35 --> Input Class Initialized
INFO - 2023-05-26 01:45:35 --> Language Class Initialized
INFO - 2023-05-26 01:45:35 --> Loader Class Initialized
INFO - 2023-05-26 01:45:35 --> Controller Class Initialized
DEBUG - 2023-05-26 01:45:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:45:35 --> Database Driver Class Initialized
INFO - 2023-05-26 01:45:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:45:35 --> Database Driver Class Initialized
INFO - 2023-05-26 01:45:35 --> Model "Login_model" initialized
INFO - 2023-05-26 01:45:45 --> Final output sent to browser
DEBUG - 2023-05-26 01:45:45 --> Total execution time: 9.6537
INFO - 2023-05-26 01:46:26 --> Config Class Initialized
INFO - 2023-05-26 01:46:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:46:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:46:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:46:26 --> URI Class Initialized
INFO - 2023-05-26 01:46:26 --> Router Class Initialized
INFO - 2023-05-26 01:46:26 --> Output Class Initialized
INFO - 2023-05-26 01:46:26 --> Security Class Initialized
DEBUG - 2023-05-26 01:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:46:26 --> Input Class Initialized
INFO - 2023-05-26 01:46:26 --> Language Class Initialized
INFO - 2023-05-26 01:46:26 --> Loader Class Initialized
INFO - 2023-05-26 01:46:26 --> Controller Class Initialized
DEBUG - 2023-05-26 01:46:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:46:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:46:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:46:26 --> Final output sent to browser
DEBUG - 2023-05-26 01:46:26 --> Total execution time: 0.2138
INFO - 2023-05-26 01:46:26 --> Config Class Initialized
INFO - 2023-05-26 01:46:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:46:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:46:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:46:26 --> URI Class Initialized
INFO - 2023-05-26 01:46:26 --> Router Class Initialized
INFO - 2023-05-26 01:46:26 --> Output Class Initialized
INFO - 2023-05-26 01:46:26 --> Security Class Initialized
DEBUG - 2023-05-26 01:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:46:26 --> Input Class Initialized
INFO - 2023-05-26 01:46:26 --> Language Class Initialized
INFO - 2023-05-26 01:46:26 --> Loader Class Initialized
INFO - 2023-05-26 01:46:26 --> Controller Class Initialized
DEBUG - 2023-05-26 01:46:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:46:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:46:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:46:27 --> Final output sent to browser
DEBUG - 2023-05-26 01:46:27 --> Total execution time: 0.2576
INFO - 2023-05-26 01:46:39 --> Config Class Initialized
INFO - 2023-05-26 01:46:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:46:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:46:39 --> Utf8 Class Initialized
INFO - 2023-05-26 01:46:39 --> URI Class Initialized
INFO - 2023-05-26 01:46:39 --> Router Class Initialized
INFO - 2023-05-26 01:46:39 --> Output Class Initialized
INFO - 2023-05-26 01:46:39 --> Security Class Initialized
DEBUG - 2023-05-26 01:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:46:39 --> Input Class Initialized
INFO - 2023-05-26 01:46:39 --> Language Class Initialized
INFO - 2023-05-26 01:46:39 --> Loader Class Initialized
INFO - 2023-05-26 01:46:39 --> Controller Class Initialized
DEBUG - 2023-05-26 01:46:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:46:39 --> Database Driver Class Initialized
INFO - 2023-05-26 01:46:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:46:39 --> Database Driver Class Initialized
INFO - 2023-05-26 01:46:39 --> Model "Login_model" initialized
INFO - 2023-05-26 01:46:50 --> Final output sent to browser
DEBUG - 2023-05-26 01:46:50 --> Total execution time: 10.8171
INFO - 2023-05-26 01:46:50 --> Config Class Initialized
INFO - 2023-05-26 01:46:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:46:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:46:50 --> Utf8 Class Initialized
INFO - 2023-05-26 01:46:50 --> URI Class Initialized
INFO - 2023-05-26 01:46:50 --> Router Class Initialized
INFO - 2023-05-26 01:46:50 --> Output Class Initialized
INFO - 2023-05-26 01:46:50 --> Security Class Initialized
DEBUG - 2023-05-26 01:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:46:50 --> Input Class Initialized
INFO - 2023-05-26 01:46:50 --> Language Class Initialized
INFO - 2023-05-26 01:46:50 --> Loader Class Initialized
INFO - 2023-05-26 01:46:50 --> Controller Class Initialized
DEBUG - 2023-05-26 01:46:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:46:50 --> Database Driver Class Initialized
INFO - 2023-05-26 01:46:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:46:50 --> Database Driver Class Initialized
INFO - 2023-05-26 01:46:50 --> Model "Login_model" initialized
INFO - 2023-05-26 01:46:59 --> Final output sent to browser
DEBUG - 2023-05-26 01:46:59 --> Total execution time: 9.3595
INFO - 2023-05-26 01:47:39 --> Config Class Initialized
INFO - 2023-05-26 01:47:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:47:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:47:39 --> Utf8 Class Initialized
INFO - 2023-05-26 01:47:39 --> URI Class Initialized
INFO - 2023-05-26 01:47:39 --> Router Class Initialized
INFO - 2023-05-26 01:47:39 --> Output Class Initialized
INFO - 2023-05-26 01:47:39 --> Security Class Initialized
DEBUG - 2023-05-26 01:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:47:39 --> Input Class Initialized
INFO - 2023-05-26 01:47:39 --> Language Class Initialized
INFO - 2023-05-26 01:47:39 --> Loader Class Initialized
INFO - 2023-05-26 01:47:39 --> Controller Class Initialized
DEBUG - 2023-05-26 01:47:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:47:39 --> Database Driver Class Initialized
INFO - 2023-05-26 01:47:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:47:39 --> Final output sent to browser
DEBUG - 2023-05-26 01:47:39 --> Total execution time: 0.2874
INFO - 2023-05-26 01:47:39 --> Config Class Initialized
INFO - 2023-05-26 01:47:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:47:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:47:39 --> Utf8 Class Initialized
INFO - 2023-05-26 01:47:39 --> URI Class Initialized
INFO - 2023-05-26 01:47:39 --> Router Class Initialized
INFO - 2023-05-26 01:47:39 --> Output Class Initialized
INFO - 2023-05-26 01:47:40 --> Security Class Initialized
DEBUG - 2023-05-26 01:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:47:40 --> Input Class Initialized
INFO - 2023-05-26 01:47:40 --> Language Class Initialized
INFO - 2023-05-26 01:47:40 --> Loader Class Initialized
INFO - 2023-05-26 01:47:40 --> Controller Class Initialized
DEBUG - 2023-05-26 01:47:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:47:40 --> Database Driver Class Initialized
INFO - 2023-05-26 01:47:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:47:40 --> Final output sent to browser
DEBUG - 2023-05-26 01:47:40 --> Total execution time: 0.7124
INFO - 2023-05-26 01:48:18 --> Config Class Initialized
INFO - 2023-05-26 01:48:18 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:48:18 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:48:18 --> Utf8 Class Initialized
INFO - 2023-05-26 01:48:18 --> URI Class Initialized
INFO - 2023-05-26 01:48:18 --> Router Class Initialized
INFO - 2023-05-26 01:48:18 --> Output Class Initialized
INFO - 2023-05-26 01:48:18 --> Security Class Initialized
DEBUG - 2023-05-26 01:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:48:18 --> Input Class Initialized
INFO - 2023-05-26 01:48:18 --> Language Class Initialized
INFO - 2023-05-26 01:48:18 --> Loader Class Initialized
INFO - 2023-05-26 01:48:18 --> Controller Class Initialized
DEBUG - 2023-05-26 01:48:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:48:18 --> Database Driver Class Initialized
INFO - 2023-05-26 01:48:18 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:48:18 --> Database Driver Class Initialized
INFO - 2023-05-26 01:48:18 --> Model "Login_model" initialized
INFO - 2023-05-26 01:48:26 --> Config Class Initialized
INFO - 2023-05-26 01:48:26 --> Config Class Initialized
INFO - 2023-05-26 01:48:26 --> Hooks Class Initialized
INFO - 2023-05-26 01:48:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:48:26 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:48:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:48:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:48:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:48:26 --> URI Class Initialized
INFO - 2023-05-26 01:48:26 --> URI Class Initialized
INFO - 2023-05-26 01:48:26 --> Router Class Initialized
INFO - 2023-05-26 01:48:26 --> Router Class Initialized
INFO - 2023-05-26 01:48:26 --> Output Class Initialized
INFO - 2023-05-26 01:48:26 --> Output Class Initialized
INFO - 2023-05-26 01:48:26 --> Security Class Initialized
INFO - 2023-05-26 01:48:26 --> Security Class Initialized
DEBUG - 2023-05-26 01:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:48:26 --> Input Class Initialized
INFO - 2023-05-26 01:48:26 --> Input Class Initialized
INFO - 2023-05-26 01:48:26 --> Language Class Initialized
INFO - 2023-05-26 01:48:26 --> Language Class Initialized
INFO - 2023-05-26 01:48:26 --> Loader Class Initialized
INFO - 2023-05-26 01:48:26 --> Loader Class Initialized
INFO - 2023-05-26 01:48:26 --> Controller Class Initialized
DEBUG - 2023-05-26 01:48:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:48:26 --> Controller Class Initialized
DEBUG - 2023-05-26 01:48:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:48:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:48:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:48:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:48:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:48:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:48:26 --> Model "Login_model" initialized
INFO - 2023-05-26 01:48:26 --> Final output sent to browser
DEBUG - 2023-05-26 01:48:26 --> Total execution time: 0.2143
INFO - 2023-05-26 01:48:26 --> Config Class Initialized
INFO - 2023-05-26 01:48:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:48:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:48:26 --> Utf8 Class Initialized
INFO - 2023-05-26 01:48:26 --> URI Class Initialized
INFO - 2023-05-26 01:48:26 --> Router Class Initialized
INFO - 2023-05-26 01:48:26 --> Output Class Initialized
INFO - 2023-05-26 01:48:26 --> Security Class Initialized
DEBUG - 2023-05-26 01:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:48:26 --> Input Class Initialized
INFO - 2023-05-26 01:48:26 --> Language Class Initialized
INFO - 2023-05-26 01:48:26 --> Loader Class Initialized
INFO - 2023-05-26 01:48:26 --> Controller Class Initialized
DEBUG - 2023-05-26 01:48:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:48:26 --> Database Driver Class Initialized
INFO - 2023-05-26 01:48:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:48:26 --> Final output sent to browser
DEBUG - 2023-05-26 01:48:26 --> Total execution time: 0.3303
INFO - 2023-05-26 01:48:27 --> Final output sent to browser
DEBUG - 2023-05-26 01:48:27 --> Total execution time: 8.5169
INFO - 2023-05-26 01:48:27 --> Config Class Initialized
INFO - 2023-05-26 01:48:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:48:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:48:27 --> Utf8 Class Initialized
INFO - 2023-05-26 01:48:27 --> URI Class Initialized
INFO - 2023-05-26 01:48:27 --> Router Class Initialized
INFO - 2023-05-26 01:48:27 --> Output Class Initialized
INFO - 2023-05-26 01:48:27 --> Security Class Initialized
DEBUG - 2023-05-26 01:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:48:27 --> Input Class Initialized
INFO - 2023-05-26 01:48:27 --> Language Class Initialized
INFO - 2023-05-26 01:48:27 --> Loader Class Initialized
INFO - 2023-05-26 01:48:27 --> Controller Class Initialized
DEBUG - 2023-05-26 01:48:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:48:27 --> Database Driver Class Initialized
INFO - 2023-05-26 01:48:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:48:27 --> Database Driver Class Initialized
INFO - 2023-05-26 01:48:27 --> Model "Login_model" initialized
INFO - 2023-05-26 01:48:32 --> Final output sent to browser
DEBUG - 2023-05-26 01:48:32 --> Total execution time: 5.7832
INFO - 2023-05-26 01:48:35 --> Final output sent to browser
DEBUG - 2023-05-26 01:48:35 --> Total execution time: 8.0163
INFO - 2023-05-26 01:48:35 --> Config Class Initialized
INFO - 2023-05-26 01:48:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:48:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:48:35 --> Utf8 Class Initialized
INFO - 2023-05-26 01:48:35 --> URI Class Initialized
INFO - 2023-05-26 01:48:35 --> Router Class Initialized
INFO - 2023-05-26 01:48:35 --> Output Class Initialized
INFO - 2023-05-26 01:48:35 --> Security Class Initialized
DEBUG - 2023-05-26 01:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:48:35 --> Input Class Initialized
INFO - 2023-05-26 01:48:35 --> Language Class Initialized
INFO - 2023-05-26 01:48:35 --> Loader Class Initialized
INFO - 2023-05-26 01:48:35 --> Controller Class Initialized
DEBUG - 2023-05-26 01:48:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:48:35 --> Database Driver Class Initialized
INFO - 2023-05-26 01:48:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:48:35 --> Database Driver Class Initialized
INFO - 2023-05-26 01:48:35 --> Model "Login_model" initialized
INFO - 2023-05-26 01:48:47 --> Final output sent to browser
DEBUG - 2023-05-26 01:48:47 --> Total execution time: 11.9632
INFO - 2023-05-26 01:49:08 --> Config Class Initialized
INFO - 2023-05-26 01:49:08 --> Config Class Initialized
INFO - 2023-05-26 01:49:08 --> Config Class Initialized
INFO - 2023-05-26 01:49:08 --> Hooks Class Initialized
INFO - 2023-05-26 01:49:08 --> Hooks Class Initialized
INFO - 2023-05-26 01:49:08 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:49:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:49:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:49:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:49:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:49:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:49:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:49:09 --> URI Class Initialized
INFO - 2023-05-26 01:49:09 --> URI Class Initialized
INFO - 2023-05-26 01:49:09 --> URI Class Initialized
INFO - 2023-05-26 01:49:09 --> Router Class Initialized
INFO - 2023-05-26 01:49:09 --> Router Class Initialized
INFO - 2023-05-26 01:49:09 --> Router Class Initialized
INFO - 2023-05-26 01:49:09 --> Output Class Initialized
INFO - 2023-05-26 01:49:09 --> Output Class Initialized
INFO - 2023-05-26 01:49:09 --> Output Class Initialized
INFO - 2023-05-26 01:49:09 --> Security Class Initialized
INFO - 2023-05-26 01:49:09 --> Security Class Initialized
INFO - 2023-05-26 01:49:09 --> Security Class Initialized
DEBUG - 2023-05-26 01:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:49:09 --> Input Class Initialized
INFO - 2023-05-26 01:49:09 --> Input Class Initialized
INFO - 2023-05-26 01:49:09 --> Input Class Initialized
INFO - 2023-05-26 01:49:09 --> Language Class Initialized
INFO - 2023-05-26 01:49:09 --> Language Class Initialized
INFO - 2023-05-26 01:49:09 --> Language Class Initialized
INFO - 2023-05-26 01:49:09 --> Loader Class Initialized
INFO - 2023-05-26 01:49:09 --> Loader Class Initialized
INFO - 2023-05-26 01:49:09 --> Loader Class Initialized
INFO - 2023-05-26 01:49:09 --> Controller Class Initialized
INFO - 2023-05-26 01:49:09 --> Controller Class Initialized
INFO - 2023-05-26 01:49:09 --> Controller Class Initialized
DEBUG - 2023-05-26 01:49:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 01:49:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 01:49:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:49:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:49:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:49:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:49:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:49:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:49:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:49:09 --> Final output sent to browser
INFO - 2023-05-26 01:49:09 --> Model "Login_model" initialized
DEBUG - 2023-05-26 01:49:09 --> Total execution time: 0.2546
INFO - 2023-05-26 01:49:09 --> Final output sent to browser
INFO - 2023-05-26 01:49:09 --> Final output sent to browser
DEBUG - 2023-05-26 01:49:09 --> Total execution time: 0.2772
DEBUG - 2023-05-26 01:49:09 --> Total execution time: 0.2745
INFO - 2023-05-26 01:49:09 --> Config Class Initialized
INFO - 2023-05-26 01:49:09 --> Config Class Initialized
INFO - 2023-05-26 01:49:09 --> Config Class Initialized
INFO - 2023-05-26 01:49:09 --> Hooks Class Initialized
INFO - 2023-05-26 01:49:09 --> Hooks Class Initialized
INFO - 2023-05-26 01:49:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:49:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:49:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:49:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:49:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:49:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:49:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:49:09 --> URI Class Initialized
INFO - 2023-05-26 01:49:09 --> URI Class Initialized
INFO - 2023-05-26 01:49:09 --> URI Class Initialized
INFO - 2023-05-26 01:49:09 --> Router Class Initialized
INFO - 2023-05-26 01:49:09 --> Router Class Initialized
INFO - 2023-05-26 01:49:09 --> Router Class Initialized
INFO - 2023-05-26 01:49:09 --> Output Class Initialized
INFO - 2023-05-26 01:49:09 --> Output Class Initialized
INFO - 2023-05-26 01:49:09 --> Output Class Initialized
INFO - 2023-05-26 01:49:09 --> Security Class Initialized
INFO - 2023-05-26 01:49:09 --> Security Class Initialized
INFO - 2023-05-26 01:49:09 --> Security Class Initialized
INFO - 2023-05-26 01:49:09 --> Config Class Initialized
INFO - 2023-05-26 01:49:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:49:09 --> Input Class Initialized
INFO - 2023-05-26 01:49:09 --> Input Class Initialized
INFO - 2023-05-26 01:49:09 --> Input Class Initialized
INFO - 2023-05-26 01:49:09 --> Language Class Initialized
INFO - 2023-05-26 01:49:09 --> Language Class Initialized
INFO - 2023-05-26 01:49:09 --> Language Class Initialized
INFO - 2023-05-26 01:49:09 --> Loader Class Initialized
INFO - 2023-05-26 01:49:09 --> Loader Class Initialized
INFO - 2023-05-26 01:49:09 --> Loader Class Initialized
DEBUG - 2023-05-26 01:49:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:49:09 --> Controller Class Initialized
INFO - 2023-05-26 01:49:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:49:09 --> Controller Class Initialized
INFO - 2023-05-26 01:49:09 --> Controller Class Initialized
DEBUG - 2023-05-26 01:49:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 01:49:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 01:49:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:49:09 --> URI Class Initialized
INFO - 2023-05-26 01:49:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:49:09 --> Router Class Initialized
INFO - 2023-05-26 01:49:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:49:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:49:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:49:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:49:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:49:09 --> Output Class Initialized
INFO - 2023-05-26 01:49:09 --> Security Class Initialized
INFO - 2023-05-26 01:49:09 --> Final output sent to browser
INFO - 2023-05-26 01:49:09 --> Final output sent to browser
DEBUG - 2023-05-26 01:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:49:09 --> Total execution time: 0.3095
DEBUG - 2023-05-26 01:49:09 --> Total execution time: 0.2989
INFO - 2023-05-26 01:49:09 --> Input Class Initialized
INFO - 2023-05-26 01:49:09 --> Language Class Initialized
INFO - 2023-05-26 01:49:09 --> Loader Class Initialized
INFO - 2023-05-26 01:49:09 --> Config Class Initialized
INFO - 2023-05-26 01:49:09 --> Hooks Class Initialized
INFO - 2023-05-26 01:49:09 --> Controller Class Initialized
DEBUG - 2023-05-26 01:49:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 01:49:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:49:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:49:09 --> URI Class Initialized
INFO - 2023-05-26 01:49:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:49:09 --> Router Class Initialized
INFO - 2023-05-26 01:49:09 --> Final output sent to browser
DEBUG - 2023-05-26 01:49:09 --> Total execution time: 0.4422
INFO - 2023-05-26 01:49:09 --> Output Class Initialized
INFO - 2023-05-26 01:49:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:49:09 --> Security Class Initialized
INFO - 2023-05-26 01:49:09 --> Model "Login_model" initialized
DEBUG - 2023-05-26 01:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:49:09 --> Input Class Initialized
INFO - 2023-05-26 01:49:09 --> Language Class Initialized
INFO - 2023-05-26 01:49:09 --> Final output sent to browser
DEBUG - 2023-05-26 01:49:09 --> Total execution time: 0.4296
INFO - 2023-05-26 01:49:09 --> Loader Class Initialized
INFO - 2023-05-26 01:49:09 --> Controller Class Initialized
DEBUG - 2023-05-26 01:49:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:49:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:49:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:49:09 --> Final output sent to browser
DEBUG - 2023-05-26 01:49:09 --> Total execution time: 0.3056
INFO - 2023-05-26 01:50:08 --> Config Class Initialized
INFO - 2023-05-26 01:50:08 --> Config Class Initialized
INFO - 2023-05-26 01:50:08 --> Hooks Class Initialized
INFO - 2023-05-26 01:50:08 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:50:08 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:50:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:50:08 --> Utf8 Class Initialized
INFO - 2023-05-26 01:50:08 --> Utf8 Class Initialized
INFO - 2023-05-26 01:50:08 --> URI Class Initialized
INFO - 2023-05-26 01:50:08 --> URI Class Initialized
INFO - 2023-05-26 01:50:09 --> Router Class Initialized
INFO - 2023-05-26 01:50:09 --> Router Class Initialized
INFO - 2023-05-26 01:50:09 --> Output Class Initialized
INFO - 2023-05-26 01:50:09 --> Output Class Initialized
INFO - 2023-05-26 01:50:09 --> Security Class Initialized
INFO - 2023-05-26 01:50:09 --> Security Class Initialized
DEBUG - 2023-05-26 01:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:50:09 --> Input Class Initialized
INFO - 2023-05-26 01:50:09 --> Input Class Initialized
INFO - 2023-05-26 01:50:09 --> Language Class Initialized
INFO - 2023-05-26 01:50:09 --> Language Class Initialized
INFO - 2023-05-26 01:50:09 --> Loader Class Initialized
INFO - 2023-05-26 01:50:09 --> Loader Class Initialized
INFO - 2023-05-26 01:50:09 --> Controller Class Initialized
DEBUG - 2023-05-26 01:50:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:50:09 --> Controller Class Initialized
DEBUG - 2023-05-26 01:50:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:50:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:50:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:50:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:50:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:50:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:50:09 --> Model "Login_model" initialized
INFO - 2023-05-26 01:50:09 --> Final output sent to browser
DEBUG - 2023-05-26 01:50:09 --> Total execution time: 0.1930
INFO - 2023-05-26 01:50:09 --> Config Class Initialized
INFO - 2023-05-26 01:50:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:50:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:50:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:50:09 --> URI Class Initialized
INFO - 2023-05-26 01:50:09 --> Router Class Initialized
INFO - 2023-05-26 01:50:09 --> Output Class Initialized
INFO - 2023-05-26 01:50:09 --> Security Class Initialized
DEBUG - 2023-05-26 01:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:50:09 --> Input Class Initialized
INFO - 2023-05-26 01:50:09 --> Language Class Initialized
INFO - 2023-05-26 01:50:09 --> Loader Class Initialized
INFO - 2023-05-26 01:50:09 --> Controller Class Initialized
DEBUG - 2023-05-26 01:50:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:50:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:50:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:50:09 --> Final output sent to browser
DEBUG - 2023-05-26 01:50:09 --> Total execution time: 0.4721
INFO - 2023-05-26 01:50:21 --> Final output sent to browser
DEBUG - 2023-05-26 01:50:21 --> Total execution time: 12.0609
INFO - 2023-05-26 01:50:21 --> Config Class Initialized
INFO - 2023-05-26 01:50:21 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:50:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:50:21 --> Utf8 Class Initialized
INFO - 2023-05-26 01:50:21 --> URI Class Initialized
INFO - 2023-05-26 01:50:21 --> Router Class Initialized
INFO - 2023-05-26 01:50:21 --> Output Class Initialized
INFO - 2023-05-26 01:50:21 --> Security Class Initialized
DEBUG - 2023-05-26 01:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:50:21 --> Input Class Initialized
INFO - 2023-05-26 01:50:21 --> Language Class Initialized
INFO - 2023-05-26 01:50:21 --> Loader Class Initialized
INFO - 2023-05-26 01:50:21 --> Controller Class Initialized
DEBUG - 2023-05-26 01:50:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:50:21 --> Database Driver Class Initialized
INFO - 2023-05-26 01:50:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:50:21 --> Database Driver Class Initialized
INFO - 2023-05-26 01:50:21 --> Model "Login_model" initialized
INFO - 2023-05-26 01:50:30 --> Final output sent to browser
DEBUG - 2023-05-26 01:50:30 --> Total execution time: 9.3326
INFO - 2023-05-26 01:51:08 --> Config Class Initialized
INFO - 2023-05-26 01:51:08 --> Config Class Initialized
INFO - 2023-05-26 01:51:08 --> Hooks Class Initialized
INFO - 2023-05-26 01:51:08 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:51:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:09 --> URI Class Initialized
INFO - 2023-05-26 01:51:09 --> URI Class Initialized
INFO - 2023-05-26 01:51:09 --> Router Class Initialized
INFO - 2023-05-26 01:51:09 --> Router Class Initialized
INFO - 2023-05-26 01:51:09 --> Output Class Initialized
INFO - 2023-05-26 01:51:09 --> Output Class Initialized
INFO - 2023-05-26 01:51:09 --> Security Class Initialized
INFO - 2023-05-26 01:51:09 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:09 --> Input Class Initialized
INFO - 2023-05-26 01:51:09 --> Input Class Initialized
INFO - 2023-05-26 01:51:09 --> Language Class Initialized
INFO - 2023-05-26 01:51:09 --> Language Class Initialized
INFO - 2023-05-26 01:51:09 --> Loader Class Initialized
INFO - 2023-05-26 01:51:09 --> Loader Class Initialized
INFO - 2023-05-26 01:51:09 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:09 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:09 --> Final output sent to browser
INFO - 2023-05-26 01:51:09 --> Model "Login_model" initialized
DEBUG - 2023-05-26 01:51:09 --> Total execution time: 0.2966
INFO - 2023-05-26 01:51:09 --> Config Class Initialized
INFO - 2023-05-26 01:51:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:09 --> URI Class Initialized
INFO - 2023-05-26 01:51:09 --> Router Class Initialized
INFO - 2023-05-26 01:51:09 --> Output Class Initialized
INFO - 2023-05-26 01:51:09 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:09 --> Input Class Initialized
INFO - 2023-05-26 01:51:09 --> Language Class Initialized
INFO - 2023-05-26 01:51:09 --> Loader Class Initialized
INFO - 2023-05-26 01:51:09 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:09 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:09 --> Total execution time: 0.3039
INFO - 2023-05-26 01:51:17 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:17 --> Total execution time: 8.9798
INFO - 2023-05-26 01:51:18 --> Config Class Initialized
INFO - 2023-05-26 01:51:18 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:18 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:18 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:18 --> URI Class Initialized
INFO - 2023-05-26 01:51:18 --> Router Class Initialized
INFO - 2023-05-26 01:51:18 --> Output Class Initialized
INFO - 2023-05-26 01:51:18 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:18 --> Input Class Initialized
INFO - 2023-05-26 01:51:18 --> Language Class Initialized
INFO - 2023-05-26 01:51:18 --> Loader Class Initialized
INFO - 2023-05-26 01:51:18 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:18 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:18 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:18 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:19 --> Model "Login_model" initialized
INFO - 2023-05-26 01:51:30 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:30 --> Total execution time: 12.7688
INFO - 2023-05-26 01:51:33 --> Config Class Initialized
INFO - 2023-05-26 01:51:33 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:33 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:33 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:33 --> URI Class Initialized
INFO - 2023-05-26 01:51:33 --> Router Class Initialized
INFO - 2023-05-26 01:51:33 --> Output Class Initialized
INFO - 2023-05-26 01:51:33 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:33 --> Input Class Initialized
INFO - 2023-05-26 01:51:33 --> Language Class Initialized
INFO - 2023-05-26 01:51:33 --> Loader Class Initialized
INFO - 2023-05-26 01:51:33 --> Controller Class Initialized
INFO - 2023-05-26 01:51:33 --> Helper loaded: form_helper
INFO - 2023-05-26 01:51:33 --> Helper loaded: url_helper
DEBUG - 2023-05-26 01:51:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:33 --> Model "Change_model" initialized
INFO - 2023-05-26 01:51:33 --> Model "Grafana_model" initialized
INFO - 2023-05-26 01:51:33 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:33 --> Total execution time: 0.2702
INFO - 2023-05-26 01:51:33 --> Config Class Initialized
INFO - 2023-05-26 01:51:33 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:33 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:33 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:33 --> URI Class Initialized
INFO - 2023-05-26 01:51:33 --> Router Class Initialized
INFO - 2023-05-26 01:51:33 --> Output Class Initialized
INFO - 2023-05-26 01:51:33 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:33 --> Input Class Initialized
INFO - 2023-05-26 01:51:33 --> Language Class Initialized
INFO - 2023-05-26 01:51:33 --> Loader Class Initialized
INFO - 2023-05-26 01:51:33 --> Controller Class Initialized
INFO - 2023-05-26 01:51:33 --> Helper loaded: form_helper
INFO - 2023-05-26 01:51:33 --> Helper loaded: url_helper
DEBUG - 2023-05-26 01:51:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:33 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:33 --> Total execution time: 0.1998
INFO - 2023-05-26 01:51:33 --> Config Class Initialized
INFO - 2023-05-26 01:51:33 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:33 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:33 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:33 --> URI Class Initialized
INFO - 2023-05-26 01:51:33 --> Router Class Initialized
INFO - 2023-05-26 01:51:33 --> Output Class Initialized
INFO - 2023-05-26 01:51:33 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:33 --> Input Class Initialized
INFO - 2023-05-26 01:51:33 --> Language Class Initialized
INFO - 2023-05-26 01:51:33 --> Loader Class Initialized
INFO - 2023-05-26 01:51:33 --> Controller Class Initialized
INFO - 2023-05-26 01:51:33 --> Helper loaded: form_helper
INFO - 2023-05-26 01:51:33 --> Helper loaded: url_helper
DEBUG - 2023-05-26 01:51:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:34 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:34 --> Model "Login_model" initialized
INFO - 2023-05-26 01:51:34 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:34 --> Total execution time: 0.2322
INFO - 2023-05-26 01:51:34 --> Config Class Initialized
INFO - 2023-05-26 01:51:34 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:34 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:34 --> URI Class Initialized
INFO - 2023-05-26 01:51:34 --> Router Class Initialized
INFO - 2023-05-26 01:51:34 --> Output Class Initialized
INFO - 2023-05-26 01:51:34 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:34 --> Input Class Initialized
INFO - 2023-05-26 01:51:34 --> Language Class Initialized
INFO - 2023-05-26 01:51:34 --> Loader Class Initialized
INFO - 2023-05-26 01:51:34 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:34 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:34 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:34 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:34 --> Total execution time: 0.2219
INFO - 2023-05-26 01:51:34 --> Config Class Initialized
INFO - 2023-05-26 01:51:34 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:34 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:34 --> URI Class Initialized
INFO - 2023-05-26 01:51:34 --> Router Class Initialized
INFO - 2023-05-26 01:51:34 --> Output Class Initialized
INFO - 2023-05-26 01:51:34 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:34 --> Input Class Initialized
INFO - 2023-05-26 01:51:34 --> Language Class Initialized
INFO - 2023-05-26 01:51:34 --> Loader Class Initialized
INFO - 2023-05-26 01:51:34 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:34 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:34 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:34 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:34 --> Total execution time: 0.2493
INFO - 2023-05-26 01:51:34 --> Config Class Initialized
INFO - 2023-05-26 01:51:34 --> Config Class Initialized
INFO - 2023-05-26 01:51:34 --> Hooks Class Initialized
INFO - 2023-05-26 01:51:34 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:34 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:51:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:34 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:34 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:34 --> URI Class Initialized
INFO - 2023-05-26 01:51:34 --> URI Class Initialized
INFO - 2023-05-26 01:51:34 --> Router Class Initialized
INFO - 2023-05-26 01:51:34 --> Router Class Initialized
INFO - 2023-05-26 01:51:34 --> Output Class Initialized
INFO - 2023-05-26 01:51:34 --> Output Class Initialized
INFO - 2023-05-26 01:51:34 --> Security Class Initialized
INFO - 2023-05-26 01:51:34 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:34 --> Input Class Initialized
INFO - 2023-05-26 01:51:34 --> Input Class Initialized
INFO - 2023-05-26 01:51:34 --> Language Class Initialized
INFO - 2023-05-26 01:51:34 --> Language Class Initialized
INFO - 2023-05-26 01:51:34 --> Loader Class Initialized
INFO - 2023-05-26 01:51:34 --> Loader Class Initialized
INFO - 2023-05-26 01:51:34 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:34 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:35 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:35 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:35 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:35 --> Total execution time: 0.2409
INFO - 2023-05-26 01:51:35 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:35 --> Model "Login_model" initialized
INFO - 2023-05-26 01:51:35 --> Config Class Initialized
INFO - 2023-05-26 01:51:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:35 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:35 --> URI Class Initialized
INFO - 2023-05-26 01:51:35 --> Router Class Initialized
INFO - 2023-05-26 01:51:35 --> Output Class Initialized
INFO - 2023-05-26 01:51:35 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:35 --> Input Class Initialized
INFO - 2023-05-26 01:51:35 --> Language Class Initialized
INFO - 2023-05-26 01:51:35 --> Loader Class Initialized
INFO - 2023-05-26 01:51:35 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:35 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:35 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:35 --> Total execution time: 0.2622
INFO - 2023-05-26 01:51:35 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:35 --> Total execution time: 0.6209
INFO - 2023-05-26 01:51:35 --> Config Class Initialized
INFO - 2023-05-26 01:51:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:35 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:35 --> URI Class Initialized
INFO - 2023-05-26 01:51:35 --> Router Class Initialized
INFO - 2023-05-26 01:51:35 --> Output Class Initialized
INFO - 2023-05-26 01:51:35 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:35 --> Input Class Initialized
INFO - 2023-05-26 01:51:35 --> Language Class Initialized
INFO - 2023-05-26 01:51:35 --> Loader Class Initialized
INFO - 2023-05-26 01:51:35 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:35 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:35 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:35 --> Model "Login_model" initialized
INFO - 2023-05-26 01:51:35 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:35 --> Total execution time: 0.3833
INFO - 2023-05-26 01:51:49 --> Config Class Initialized
INFO - 2023-05-26 01:51:49 --> Config Class Initialized
INFO - 2023-05-26 01:51:49 --> Hooks Class Initialized
INFO - 2023-05-26 01:51:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:49 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:51:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:49 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:49 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:49 --> URI Class Initialized
INFO - 2023-05-26 01:51:49 --> URI Class Initialized
INFO - 2023-05-26 01:51:49 --> Router Class Initialized
INFO - 2023-05-26 01:51:49 --> Router Class Initialized
INFO - 2023-05-26 01:51:49 --> Output Class Initialized
INFO - 2023-05-26 01:51:49 --> Output Class Initialized
INFO - 2023-05-26 01:51:49 --> Security Class Initialized
INFO - 2023-05-26 01:51:49 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:49 --> Input Class Initialized
INFO - 2023-05-26 01:51:49 --> Input Class Initialized
INFO - 2023-05-26 01:51:49 --> Language Class Initialized
INFO - 2023-05-26 01:51:49 --> Language Class Initialized
INFO - 2023-05-26 01:51:49 --> Loader Class Initialized
INFO - 2023-05-26 01:51:49 --> Loader Class Initialized
INFO - 2023-05-26 01:51:49 --> Controller Class Initialized
INFO - 2023-05-26 01:51:49 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 01:51:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:49 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:49 --> Total execution time: 0.1478
INFO - 2023-05-26 01:51:49 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:49 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:49 --> Total execution time: 0.1996
INFO - 2023-05-26 01:51:49 --> Config Class Initialized
INFO - 2023-05-26 01:51:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:49 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:49 --> Config Class Initialized
INFO - 2023-05-26 01:51:49 --> URI Class Initialized
INFO - 2023-05-26 01:51:49 --> Hooks Class Initialized
INFO - 2023-05-26 01:51:49 --> Router Class Initialized
DEBUG - 2023-05-26 01:51:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:49 --> Output Class Initialized
INFO - 2023-05-26 01:51:49 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:49 --> URI Class Initialized
INFO - 2023-05-26 01:51:49 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:49 --> Input Class Initialized
INFO - 2023-05-26 01:51:49 --> Router Class Initialized
INFO - 2023-05-26 01:51:49 --> Language Class Initialized
INFO - 2023-05-26 01:51:49 --> Output Class Initialized
INFO - 2023-05-26 01:51:49 --> Loader Class Initialized
INFO - 2023-05-26 01:51:49 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:49 --> Controller Class Initialized
INFO - 2023-05-26 01:51:49 --> Input Class Initialized
DEBUG - 2023-05-26 01:51:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:49 --> Language Class Initialized
INFO - 2023-05-26 01:51:49 --> Loader Class Initialized
INFO - 2023-05-26 01:51:49 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:49 --> Controller Class Initialized
INFO - 2023-05-26 01:51:49 --> Model "Login_model" initialized
DEBUG - 2023-05-26 01:51:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:49 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:49 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:49 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:49 --> Total execution time: 0.2987
INFO - 2023-05-26 01:51:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:50 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:50 --> Total execution time: 0.2625
INFO - 2023-05-26 01:51:53 --> Config Class Initialized
INFO - 2023-05-26 01:51:53 --> Config Class Initialized
INFO - 2023-05-26 01:51:53 --> Hooks Class Initialized
INFO - 2023-05-26 01:51:53 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:53 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:51:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:53 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:53 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:53 --> URI Class Initialized
INFO - 2023-05-26 01:51:53 --> URI Class Initialized
INFO - 2023-05-26 01:51:53 --> Router Class Initialized
INFO - 2023-05-26 01:51:53 --> Router Class Initialized
INFO - 2023-05-26 01:51:53 --> Output Class Initialized
INFO - 2023-05-26 01:51:53 --> Output Class Initialized
INFO - 2023-05-26 01:51:53 --> Security Class Initialized
INFO - 2023-05-26 01:51:53 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:53 --> Input Class Initialized
INFO - 2023-05-26 01:51:53 --> Input Class Initialized
INFO - 2023-05-26 01:51:53 --> Language Class Initialized
INFO - 2023-05-26 01:51:53 --> Language Class Initialized
INFO - 2023-05-26 01:51:53 --> Loader Class Initialized
INFO - 2023-05-26 01:51:53 --> Loader Class Initialized
INFO - 2023-05-26 01:51:53 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:53 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:53 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:53 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:53 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:53 --> Total execution time: 0.1685
INFO - 2023-05-26 01:51:53 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:53 --> Model "Login_model" initialized
INFO - 2023-05-26 01:51:53 --> Config Class Initialized
INFO - 2023-05-26 01:51:53 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:53 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:53 --> URI Class Initialized
INFO - 2023-05-26 01:51:53 --> Router Class Initialized
INFO - 2023-05-26 01:51:53 --> Output Class Initialized
INFO - 2023-05-26 01:51:53 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:53 --> Input Class Initialized
INFO - 2023-05-26 01:51:53 --> Language Class Initialized
INFO - 2023-05-26 01:51:53 --> Loader Class Initialized
INFO - 2023-05-26 01:51:53 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:53 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:53 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:53 --> Total execution time: 0.2156
INFO - 2023-05-26 01:51:53 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:53 --> Total execution time: 0.5582
INFO - 2023-05-26 01:51:53 --> Config Class Initialized
INFO - 2023-05-26 01:51:53 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:51:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:51:53 --> Utf8 Class Initialized
INFO - 2023-05-26 01:51:53 --> URI Class Initialized
INFO - 2023-05-26 01:51:53 --> Router Class Initialized
INFO - 2023-05-26 01:51:53 --> Output Class Initialized
INFO - 2023-05-26 01:51:53 --> Security Class Initialized
DEBUG - 2023-05-26 01:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:51:53 --> Input Class Initialized
INFO - 2023-05-26 01:51:53 --> Language Class Initialized
INFO - 2023-05-26 01:51:53 --> Loader Class Initialized
INFO - 2023-05-26 01:51:53 --> Controller Class Initialized
DEBUG - 2023-05-26 01:51:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:51:53 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:51:53 --> Database Driver Class Initialized
INFO - 2023-05-26 01:51:53 --> Model "Login_model" initialized
INFO - 2023-05-26 01:51:54 --> Final output sent to browser
DEBUG - 2023-05-26 01:51:54 --> Total execution time: 0.4016
INFO - 2023-05-26 01:52:18 --> Config Class Initialized
INFO - 2023-05-26 01:52:18 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:52:18 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:52:18 --> Utf8 Class Initialized
INFO - 2023-05-26 01:52:18 --> URI Class Initialized
INFO - 2023-05-26 01:52:18 --> Router Class Initialized
INFO - 2023-05-26 01:52:18 --> Output Class Initialized
INFO - 2023-05-26 01:52:19 --> Security Class Initialized
DEBUG - 2023-05-26 01:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:52:19 --> Input Class Initialized
INFO - 2023-05-26 01:52:19 --> Language Class Initialized
INFO - 2023-05-26 01:52:19 --> Loader Class Initialized
INFO - 2023-05-26 01:52:19 --> Controller Class Initialized
DEBUG - 2023-05-26 01:52:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:52:19 --> Database Driver Class Initialized
INFO - 2023-05-26 01:52:19 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:52:19 --> Final output sent to browser
DEBUG - 2023-05-26 01:52:19 --> Total execution time: 0.3419
INFO - 2023-05-26 01:52:19 --> Config Class Initialized
INFO - 2023-05-26 01:52:19 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:52:19 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:52:19 --> Utf8 Class Initialized
INFO - 2023-05-26 01:52:19 --> URI Class Initialized
INFO - 2023-05-26 01:52:19 --> Router Class Initialized
INFO - 2023-05-26 01:52:19 --> Output Class Initialized
INFO - 2023-05-26 01:52:19 --> Security Class Initialized
DEBUG - 2023-05-26 01:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:52:19 --> Input Class Initialized
INFO - 2023-05-26 01:52:19 --> Language Class Initialized
INFO - 2023-05-26 01:52:19 --> Loader Class Initialized
INFO - 2023-05-26 01:52:19 --> Controller Class Initialized
DEBUG - 2023-05-26 01:52:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:52:19 --> Database Driver Class Initialized
INFO - 2023-05-26 01:52:19 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:52:19 --> Final output sent to browser
DEBUG - 2023-05-26 01:52:19 --> Total execution time: 0.3244
INFO - 2023-05-26 01:58:08 --> Config Class Initialized
INFO - 2023-05-26 01:58:08 --> Config Class Initialized
INFO - 2023-05-26 01:58:08 --> Hooks Class Initialized
INFO - 2023-05-26 01:58:08 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:58:08 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:58:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:58:08 --> Utf8 Class Initialized
INFO - 2023-05-26 01:58:08 --> Utf8 Class Initialized
INFO - 2023-05-26 01:58:08 --> URI Class Initialized
INFO - 2023-05-26 01:58:08 --> URI Class Initialized
INFO - 2023-05-26 01:58:08 --> Router Class Initialized
INFO - 2023-05-26 01:58:08 --> Router Class Initialized
INFO - 2023-05-26 01:58:08 --> Output Class Initialized
INFO - 2023-05-26 01:58:08 --> Output Class Initialized
INFO - 2023-05-26 01:58:08 --> Security Class Initialized
INFO - 2023-05-26 01:58:08 --> Security Class Initialized
DEBUG - 2023-05-26 01:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:58:08 --> Config Class Initialized
INFO - 2023-05-26 01:58:08 --> Input Class Initialized
INFO - 2023-05-26 01:58:08 --> Input Class Initialized
INFO - 2023-05-26 01:58:08 --> Hooks Class Initialized
INFO - 2023-05-26 01:58:08 --> Language Class Initialized
INFO - 2023-05-26 01:58:08 --> Language Class Initialized
DEBUG - 2023-05-26 01:58:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:58:08 --> Loader Class Initialized
INFO - 2023-05-26 01:58:08 --> Utf8 Class Initialized
INFO - 2023-05-26 01:58:08 --> URI Class Initialized
INFO - 2023-05-26 01:58:08 --> Loader Class Initialized
INFO - 2023-05-26 01:58:08 --> Controller Class Initialized
DEBUG - 2023-05-26 01:58:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:58:08 --> Router Class Initialized
INFO - 2023-05-26 01:58:08 --> Controller Class Initialized
DEBUG - 2023-05-26 01:58:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:58:08 --> Output Class Initialized
INFO - 2023-05-26 01:58:08 --> Security Class Initialized
DEBUG - 2023-05-26 01:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:58:08 --> Input Class Initialized
INFO - 2023-05-26 01:58:08 --> Database Driver Class Initialized
INFO - 2023-05-26 01:58:08 --> Language Class Initialized
INFO - 2023-05-26 01:58:08 --> Database Driver Class Initialized
INFO - 2023-05-26 01:58:08 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:58:08 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:58:08 --> Loader Class Initialized
INFO - 2023-05-26 01:58:08 --> Final output sent to browser
DEBUG - 2023-05-26 01:58:08 --> Total execution time: 0.3312
INFO - 2023-05-26 01:58:08 --> Controller Class Initialized
INFO - 2023-05-26 01:58:08 --> Final output sent to browser
DEBUG - 2023-05-26 01:58:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 01:58:08 --> Total execution time: 0.3539
INFO - 2023-05-26 01:58:08 --> Config Class Initialized
INFO - 2023-05-26 01:58:08 --> Config Class Initialized
INFO - 2023-05-26 01:58:08 --> Hooks Class Initialized
INFO - 2023-05-26 01:58:08 --> Hooks Class Initialized
INFO - 2023-05-26 01:58:08 --> Database Driver Class Initialized
DEBUG - 2023-05-26 01:58:08 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:58:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:58:08 --> Utf8 Class Initialized
INFO - 2023-05-26 01:58:08 --> Utf8 Class Initialized
INFO - 2023-05-26 01:58:08 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:58:08 --> URI Class Initialized
INFO - 2023-05-26 01:58:08 --> URI Class Initialized
INFO - 2023-05-26 01:58:08 --> Router Class Initialized
INFO - 2023-05-26 01:58:08 --> Router Class Initialized
INFO - 2023-05-26 01:58:08 --> Output Class Initialized
INFO - 2023-05-26 01:58:08 --> Output Class Initialized
INFO - 2023-05-26 01:58:08 --> Security Class Initialized
INFO - 2023-05-26 01:58:08 --> Security Class Initialized
DEBUG - 2023-05-26 01:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:58:08 --> Input Class Initialized
INFO - 2023-05-26 01:58:08 --> Input Class Initialized
INFO - 2023-05-26 01:58:08 --> Final output sent to browser
DEBUG - 2023-05-26 01:58:08 --> Total execution time: 0.4267
INFO - 2023-05-26 01:58:08 --> Language Class Initialized
INFO - 2023-05-26 01:58:08 --> Language Class Initialized
INFO - 2023-05-26 01:58:08 --> Loader Class Initialized
INFO - 2023-05-26 01:58:08 --> Loader Class Initialized
INFO - 2023-05-26 01:58:08 --> Controller Class Initialized
INFO - 2023-05-26 01:58:08 --> Controller Class Initialized
DEBUG - 2023-05-26 01:58:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:58:08 --> Config Class Initialized
INFO - 2023-05-26 01:58:08 --> Final output sent to browser
INFO - 2023-05-26 01:58:08 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:58:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 01:58:08 --> Total execution time: 0.1842
DEBUG - 2023-05-26 01:58:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:58:08 --> Utf8 Class Initialized
INFO - 2023-05-26 01:58:08 --> URI Class Initialized
INFO - 2023-05-26 01:58:08 --> Database Driver Class Initialized
INFO - 2023-05-26 01:58:08 --> Config Class Initialized
INFO - 2023-05-26 01:58:08 --> Router Class Initialized
INFO - 2023-05-26 01:58:08 --> Hooks Class Initialized
INFO - 2023-05-26 01:58:08 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:58:08 --> Output Class Initialized
INFO - 2023-05-26 01:58:08 --> Security Class Initialized
DEBUG - 2023-05-26 01:58:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:58:08 --> Utf8 Class Initialized
DEBUG - 2023-05-26 01:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:58:08 --> URI Class Initialized
INFO - 2023-05-26 01:58:08 --> Input Class Initialized
INFO - 2023-05-26 01:58:08 --> Language Class Initialized
INFO - 2023-05-26 01:58:08 --> Router Class Initialized
INFO - 2023-05-26 01:58:08 --> Output Class Initialized
INFO - 2023-05-26 01:58:08 --> Loader Class Initialized
INFO - 2023-05-26 01:58:08 --> Security Class Initialized
DEBUG - 2023-05-26 01:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:58:08 --> Controller Class Initialized
INFO - 2023-05-26 01:58:08 --> Input Class Initialized
INFO - 2023-05-26 01:58:08 --> Final output sent to browser
DEBUG - 2023-05-26 01:58:08 --> Total execution time: 0.3537
DEBUG - 2023-05-26 01:58:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:58:08 --> Language Class Initialized
INFO - 2023-05-26 01:58:08 --> Database Driver Class Initialized
INFO - 2023-05-26 01:58:08 --> Loader Class Initialized
INFO - 2023-05-26 01:58:08 --> Config Class Initialized
INFO - 2023-05-26 01:58:08 --> Hooks Class Initialized
INFO - 2023-05-26 01:58:08 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:58:08 --> Controller Class Initialized
DEBUG - 2023-05-26 01:58:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 01:58:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:58:08 --> Utf8 Class Initialized
INFO - 2023-05-26 01:58:08 --> URI Class Initialized
INFO - 2023-05-26 01:58:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:58:09 --> Router Class Initialized
INFO - 2023-05-26 01:58:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:58:09 --> Output Class Initialized
INFO - 2023-05-26 01:58:09 --> Final output sent to browser
DEBUG - 2023-05-26 01:58:09 --> Total execution time: 0.3244
INFO - 2023-05-26 01:58:09 --> Final output sent to browser
INFO - 2023-05-26 01:58:09 --> Security Class Initialized
DEBUG - 2023-05-26 01:58:09 --> Total execution time: 0.4101
DEBUG - 2023-05-26 01:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:58:09 --> Input Class Initialized
INFO - 2023-05-26 01:58:09 --> Language Class Initialized
INFO - 2023-05-26 01:58:09 --> Config Class Initialized
INFO - 2023-05-26 01:58:09 --> Config Class Initialized
INFO - 2023-05-26 01:58:09 --> Loader Class Initialized
INFO - 2023-05-26 01:58:09 --> Hooks Class Initialized
INFO - 2023-05-26 01:58:09 --> Hooks Class Initialized
INFO - 2023-05-26 01:58:09 --> Controller Class Initialized
DEBUG - 2023-05-26 01:58:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:58:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 01:58:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:58:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:58:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:58:09 --> URI Class Initialized
INFO - 2023-05-26 01:58:09 --> URI Class Initialized
INFO - 2023-05-26 01:58:09 --> Router Class Initialized
INFO - 2023-05-26 01:58:09 --> Router Class Initialized
INFO - 2023-05-26 01:58:09 --> Output Class Initialized
INFO - 2023-05-26 01:58:09 --> Output Class Initialized
INFO - 2023-05-26 01:58:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:58:09 --> Security Class Initialized
INFO - 2023-05-26 01:58:09 --> Security Class Initialized
DEBUG - 2023-05-26 01:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 01:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:58:09 --> Model "Login_model" initialized
INFO - 2023-05-26 01:58:09 --> Input Class Initialized
INFO - 2023-05-26 01:58:09 --> Input Class Initialized
INFO - 2023-05-26 01:58:09 --> Language Class Initialized
INFO - 2023-05-26 01:58:09 --> Language Class Initialized
INFO - 2023-05-26 01:58:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:58:09 --> Loader Class Initialized
INFO - 2023-05-26 01:58:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:58:09 --> Controller Class Initialized
INFO - 2023-05-26 01:58:09 --> Loader Class Initialized
INFO - 2023-05-26 01:58:09 --> Final output sent to browser
DEBUG - 2023-05-26 01:58:09 --> Total execution time: 0.3709
DEBUG - 2023-05-26 01:58:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:58:09 --> Controller Class Initialized
DEBUG - 2023-05-26 01:58:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:58:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:58:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:58:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:58:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:58:09 --> Final output sent to browser
DEBUG - 2023-05-26 01:58:09 --> Total execution time: 0.2395
INFO - 2023-05-26 01:58:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:58:09 --> Model "Login_model" initialized
INFO - 2023-05-26 01:58:09 --> Config Class Initialized
INFO - 2023-05-26 01:58:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 01:58:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:58:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:58:09 --> URI Class Initialized
INFO - 2023-05-26 01:58:09 --> Router Class Initialized
INFO - 2023-05-26 01:58:09 --> Final output sent to browser
INFO - 2023-05-26 01:58:09 --> Output Class Initialized
DEBUG - 2023-05-26 01:58:09 --> Total execution time: 0.4442
INFO - 2023-05-26 01:58:09 --> Security Class Initialized
DEBUG - 2023-05-26 01:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:58:09 --> Input Class Initialized
INFO - 2023-05-26 01:58:09 --> Language Class Initialized
INFO - 2023-05-26 01:58:09 --> Config Class Initialized
INFO - 2023-05-26 01:58:09 --> Hooks Class Initialized
INFO - 2023-05-26 01:58:09 --> Loader Class Initialized
DEBUG - 2023-05-26 01:58:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 01:58:09 --> Utf8 Class Initialized
INFO - 2023-05-26 01:58:09 --> Controller Class Initialized
INFO - 2023-05-26 01:58:09 --> URI Class Initialized
DEBUG - 2023-05-26 01:58:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:58:09 --> Router Class Initialized
INFO - 2023-05-26 01:58:09 --> Output Class Initialized
INFO - 2023-05-26 01:58:09 --> Security Class Initialized
DEBUG - 2023-05-26 01:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 01:58:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:58:09 --> Input Class Initialized
INFO - 2023-05-26 01:58:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:58:09 --> Language Class Initialized
INFO - 2023-05-26 01:58:09 --> Final output sent to browser
DEBUG - 2023-05-26 01:58:09 --> Total execution time: 0.3352
INFO - 2023-05-26 01:58:09 --> Loader Class Initialized
INFO - 2023-05-26 01:58:09 --> Controller Class Initialized
DEBUG - 2023-05-26 01:58:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 01:58:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:58:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 01:58:09 --> Database Driver Class Initialized
INFO - 2023-05-26 01:58:09 --> Model "Login_model" initialized
INFO - 2023-05-26 01:58:10 --> Final output sent to browser
DEBUG - 2023-05-26 01:58:10 --> Total execution time: 0.4347
INFO - 2023-05-26 02:19:15 --> Config Class Initialized
INFO - 2023-05-26 02:19:15 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:19:15 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:19:15 --> Utf8 Class Initialized
INFO - 2023-05-26 02:19:15 --> URI Class Initialized
INFO - 2023-05-26 02:19:16 --> Router Class Initialized
INFO - 2023-05-26 02:19:16 --> Output Class Initialized
INFO - 2023-05-26 02:19:16 --> Security Class Initialized
DEBUG - 2023-05-26 02:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:19:16 --> Input Class Initialized
INFO - 2023-05-26 02:19:16 --> Language Class Initialized
INFO - 2023-05-26 02:19:16 --> Loader Class Initialized
INFO - 2023-05-26 02:19:16 --> Controller Class Initialized
DEBUG - 2023-05-26 02:19:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:19:16 --> Database Driver Class Initialized
INFO - 2023-05-26 02:19:16 --> Model "Login_model" initialized
INFO - 2023-05-26 02:19:16 --> Database Driver Class Initialized
INFO - 2023-05-26 02:19:16 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:19:16 --> Final output sent to browser
DEBUG - 2023-05-26 02:19:16 --> Total execution time: 0.8418
INFO - 2023-05-26 02:19:16 --> Config Class Initialized
INFO - 2023-05-26 02:19:16 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:19:16 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:19:16 --> Utf8 Class Initialized
INFO - 2023-05-26 02:19:16 --> URI Class Initialized
INFO - 2023-05-26 02:19:16 --> Router Class Initialized
INFO - 2023-05-26 02:19:16 --> Output Class Initialized
INFO - 2023-05-26 02:19:16 --> Security Class Initialized
DEBUG - 2023-05-26 02:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:19:16 --> Input Class Initialized
INFO - 2023-05-26 02:19:16 --> Language Class Initialized
INFO - 2023-05-26 02:19:16 --> Loader Class Initialized
INFO - 2023-05-26 02:19:16 --> Controller Class Initialized
DEBUG - 2023-05-26 02:19:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:19:17 --> Database Driver Class Initialized
INFO - 2023-05-26 02:19:17 --> Model "Login_model" initialized
INFO - 2023-05-26 02:19:17 --> Database Driver Class Initialized
INFO - 2023-05-26 02:19:17 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:19:17 --> Final output sent to browser
DEBUG - 2023-05-26 02:19:17 --> Total execution time: 0.6609
INFO - 2023-05-26 02:19:17 --> Config Class Initialized
INFO - 2023-05-26 02:19:17 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:19:17 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:19:17 --> Utf8 Class Initialized
INFO - 2023-05-26 02:19:17 --> URI Class Initialized
INFO - 2023-05-26 02:19:17 --> Router Class Initialized
INFO - 2023-05-26 02:19:17 --> Output Class Initialized
INFO - 2023-05-26 02:19:17 --> Security Class Initialized
DEBUG - 2023-05-26 02:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:19:17 --> Input Class Initialized
INFO - 2023-05-26 02:19:17 --> Language Class Initialized
INFO - 2023-05-26 02:19:17 --> Loader Class Initialized
INFO - 2023-05-26 02:19:17 --> Controller Class Initialized
DEBUG - 2023-05-26 02:19:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:19:17 --> Final output sent to browser
DEBUG - 2023-05-26 02:19:17 --> Total execution time: 0.2074
INFO - 2023-05-26 02:19:17 --> Config Class Initialized
INFO - 2023-05-26 02:19:17 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:19:17 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:19:17 --> Utf8 Class Initialized
INFO - 2023-05-26 02:19:17 --> URI Class Initialized
INFO - 2023-05-26 02:19:17 --> Router Class Initialized
INFO - 2023-05-26 02:19:17 --> Output Class Initialized
INFO - 2023-05-26 02:19:17 --> Security Class Initialized
DEBUG - 2023-05-26 02:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:19:17 --> Input Class Initialized
INFO - 2023-05-26 02:19:17 --> Language Class Initialized
INFO - 2023-05-26 02:19:17 --> Loader Class Initialized
INFO - 2023-05-26 02:19:17 --> Controller Class Initialized
DEBUG - 2023-05-26 02:19:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:19:17 --> Database Driver Class Initialized
INFO - 2023-05-26 02:19:18 --> Model "Login_model" initialized
INFO - 2023-05-26 02:19:18 --> Database Driver Class Initialized
INFO - 2023-05-26 02:19:18 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:19:18 --> Final output sent to browser
DEBUG - 2023-05-26 02:19:18 --> Total execution time: 0.9548
INFO - 2023-05-26 02:22:51 --> Config Class Initialized
INFO - 2023-05-26 02:22:51 --> Config Class Initialized
INFO - 2023-05-26 02:22:51 --> Hooks Class Initialized
INFO - 2023-05-26 02:22:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:22:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 02:22:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:22:51 --> Utf8 Class Initialized
INFO - 2023-05-26 02:22:51 --> Utf8 Class Initialized
INFO - 2023-05-26 02:22:51 --> URI Class Initialized
INFO - 2023-05-26 02:22:51 --> URI Class Initialized
INFO - 2023-05-26 02:22:51 --> Config Class Initialized
INFO - 2023-05-26 02:22:51 --> Hooks Class Initialized
INFO - 2023-05-26 02:22:51 --> Router Class Initialized
INFO - 2023-05-26 02:22:51 --> Router Class Initialized
INFO - 2023-05-26 02:22:51 --> Output Class Initialized
INFO - 2023-05-26 02:22:51 --> Output Class Initialized
INFO - 2023-05-26 02:22:51 --> Security Class Initialized
INFO - 2023-05-26 02:22:51 --> Security Class Initialized
DEBUG - 2023-05-26 02:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 02:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 02:22:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:22:51 --> Input Class Initialized
INFO - 2023-05-26 02:22:51 --> Input Class Initialized
INFO - 2023-05-26 02:22:51 --> Utf8 Class Initialized
INFO - 2023-05-26 02:22:51 --> URI Class Initialized
INFO - 2023-05-26 02:22:51 --> Language Class Initialized
INFO - 2023-05-26 02:22:51 --> Language Class Initialized
INFO - 2023-05-26 02:22:51 --> Router Class Initialized
INFO - 2023-05-26 02:22:51 --> Loader Class Initialized
INFO - 2023-05-26 02:22:51 --> Loader Class Initialized
INFO - 2023-05-26 02:22:51 --> Output Class Initialized
INFO - 2023-05-26 02:22:51 --> Controller Class Initialized
INFO - 2023-05-26 02:22:51 --> Controller Class Initialized
DEBUG - 2023-05-26 02:22:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 02:22:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:22:51 --> Security Class Initialized
DEBUG - 2023-05-26 02:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:22:51 --> Input Class Initialized
INFO - 2023-05-26 02:22:51 --> Language Class Initialized
INFO - 2023-05-26 02:22:51 --> Database Driver Class Initialized
INFO - 2023-05-26 02:22:51 --> Database Driver Class Initialized
INFO - 2023-05-26 02:22:51 --> Loader Class Initialized
INFO - 2023-05-26 02:22:51 --> Controller Class Initialized
DEBUG - 2023-05-26 02:22:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:22:51 --> Database Driver Class Initialized
INFO - 2023-05-26 02:22:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:22:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:22:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:22:51 --> Config Class Initialized
INFO - 2023-05-26 02:22:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:22:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:22:51 --> Utf8 Class Initialized
INFO - 2023-05-26 02:22:51 --> URI Class Initialized
INFO - 2023-05-26 02:22:51 --> Router Class Initialized
INFO - 2023-05-26 02:22:51 --> Output Class Initialized
INFO - 2023-05-26 02:22:51 --> Security Class Initialized
DEBUG - 2023-05-26 02:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:22:51 --> Input Class Initialized
INFO - 2023-05-26 02:22:51 --> Language Class Initialized
INFO - 2023-05-26 02:22:51 --> Loader Class Initialized
INFO - 2023-05-26 02:22:51 --> Controller Class Initialized
DEBUG - 2023-05-26 02:22:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:22:51 --> Database Driver Class Initialized
INFO - 2023-05-26 02:22:52 --> Final output sent to browser
DEBUG - 2023-05-26 02:22:52 --> Total execution time: 0.8229
INFO - 2023-05-26 02:22:52 --> Config Class Initialized
INFO - 2023-05-26 02:22:52 --> Hooks Class Initialized
INFO - 2023-05-26 02:22:52 --> Database Driver Class Initialized
DEBUG - 2023-05-26 02:22:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:22:52 --> Utf8 Class Initialized
INFO - 2023-05-26 02:22:52 --> URI Class Initialized
INFO - 2023-05-26 02:22:52 --> Final output sent to browser
INFO - 2023-05-26 02:22:52 --> Router Class Initialized
DEBUG - 2023-05-26 02:22:52 --> Total execution time: 0.9463
INFO - 2023-05-26 02:22:52 --> Output Class Initialized
INFO - 2023-05-26 02:22:52 --> Security Class Initialized
DEBUG - 2023-05-26 02:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:22:52 --> Input Class Initialized
INFO - 2023-05-26 02:22:52 --> Config Class Initialized
INFO - 2023-05-26 02:22:52 --> Language Class Initialized
INFO - 2023-05-26 02:22:52 --> Hooks Class Initialized
INFO - 2023-05-26 02:22:52 --> Loader Class Initialized
DEBUG - 2023-05-26 02:22:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:22:52 --> Utf8 Class Initialized
INFO - 2023-05-26 02:22:52 --> Controller Class Initialized
INFO - 2023-05-26 02:22:52 --> URI Class Initialized
DEBUG - 2023-05-26 02:22:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:22:52 --> Final output sent to browser
DEBUG - 2023-05-26 02:22:52 --> Total execution time: 1.0352
INFO - 2023-05-26 02:22:52 --> Router Class Initialized
INFO - 2023-05-26 02:22:52 --> Output Class Initialized
INFO - 2023-05-26 02:22:52 --> Security Class Initialized
INFO - 2023-05-26 02:22:52 --> Database Driver Class Initialized
DEBUG - 2023-05-26 02:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:22:52 --> Input Class Initialized
INFO - 2023-05-26 02:22:52 --> Model "Login_model" initialized
INFO - 2023-05-26 02:22:52 --> Language Class Initialized
INFO - 2023-05-26 02:22:52 --> Config Class Initialized
INFO - 2023-05-26 02:22:52 --> Hooks Class Initialized
INFO - 2023-05-26 02:22:52 --> Loader Class Initialized
DEBUG - 2023-05-26 02:22:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:22:52 --> Controller Class Initialized
INFO - 2023-05-26 02:22:52 --> Utf8 Class Initialized
DEBUG - 2023-05-26 02:22:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:22:52 --> URI Class Initialized
INFO - 2023-05-26 02:22:52 --> Router Class Initialized
INFO - 2023-05-26 02:22:52 --> Database Driver Class Initialized
INFO - 2023-05-26 02:22:52 --> Output Class Initialized
INFO - 2023-05-26 02:22:52 --> Final output sent to browser
DEBUG - 2023-05-26 02:22:52 --> Total execution time: 0.7240
INFO - 2023-05-26 02:22:52 --> Security Class Initialized
DEBUG - 2023-05-26 02:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:22:52 --> Input Class Initialized
INFO - 2023-05-26 02:22:52 --> Language Class Initialized
INFO - 2023-05-26 02:22:52 --> Loader Class Initialized
INFO - 2023-05-26 02:22:52 --> Config Class Initialized
INFO - 2023-05-26 02:22:52 --> Hooks Class Initialized
INFO - 2023-05-26 02:22:52 --> Controller Class Initialized
DEBUG - 2023-05-26 02:22:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 02:22:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:22:52 --> Utf8 Class Initialized
INFO - 2023-05-26 02:22:52 --> URI Class Initialized
INFO - 2023-05-26 02:22:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:22:52 --> Database Driver Class Initialized
INFO - 2023-05-26 02:22:52 --> Router Class Initialized
INFO - 2023-05-26 02:22:52 --> Output Class Initialized
INFO - 2023-05-26 02:22:52 --> Security Class Initialized
DEBUG - 2023-05-26 02:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:22:52 --> Input Class Initialized
INFO - 2023-05-26 02:22:52 --> Language Class Initialized
INFO - 2023-05-26 02:22:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:22:52 --> Loader Class Initialized
INFO - 2023-05-26 02:22:52 --> Controller Class Initialized
INFO - 2023-05-26 02:22:52 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 02:22:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:22:52 --> Database Driver Class Initialized
INFO - 2023-05-26 02:22:52 --> Database Driver Class Initialized
INFO - 2023-05-26 02:22:52 --> Model "Login_model" initialized
INFO - 2023-05-26 02:22:52 --> Final output sent to browser
DEBUG - 2023-05-26 02:22:52 --> Total execution time: 0.5063
INFO - 2023-05-26 02:22:53 --> Final output sent to browser
DEBUG - 2023-05-26 02:22:53 --> Total execution time: 1.2003
INFO - 2023-05-26 02:22:53 --> Final output sent to browser
DEBUG - 2023-05-26 02:22:53 --> Total execution time: 1.1283
INFO - 2023-05-26 02:22:53 --> Final output sent to browser
DEBUG - 2023-05-26 02:22:53 --> Total execution time: 1.2700
INFO - 2023-05-26 02:23:51 --> Config Class Initialized
INFO - 2023-05-26 02:23:51 --> Config Class Initialized
INFO - 2023-05-26 02:23:51 --> Hooks Class Initialized
INFO - 2023-05-26 02:23:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:23:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 02:23:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:23:51 --> Utf8 Class Initialized
INFO - 2023-05-26 02:23:51 --> Utf8 Class Initialized
INFO - 2023-05-26 02:23:51 --> URI Class Initialized
INFO - 2023-05-26 02:23:51 --> URI Class Initialized
INFO - 2023-05-26 02:23:51 --> Router Class Initialized
INFO - 2023-05-26 02:23:51 --> Router Class Initialized
INFO - 2023-05-26 02:23:51 --> Output Class Initialized
INFO - 2023-05-26 02:23:51 --> Output Class Initialized
INFO - 2023-05-26 02:23:51 --> Security Class Initialized
INFO - 2023-05-26 02:23:51 --> Security Class Initialized
DEBUG - 2023-05-26 02:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 02:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:23:51 --> Input Class Initialized
INFO - 2023-05-26 02:23:51 --> Input Class Initialized
INFO - 2023-05-26 02:23:51 --> Language Class Initialized
INFO - 2023-05-26 02:23:51 --> Language Class Initialized
INFO - 2023-05-26 02:23:51 --> Loader Class Initialized
INFO - 2023-05-26 02:23:51 --> Loader Class Initialized
INFO - 2023-05-26 02:23:51 --> Controller Class Initialized
INFO - 2023-05-26 02:23:51 --> Controller Class Initialized
DEBUG - 2023-05-26 02:23:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 02:23:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:23:51 --> Database Driver Class Initialized
INFO - 2023-05-26 02:23:51 --> Database Driver Class Initialized
INFO - 2023-05-26 02:23:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:23:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:23:51 --> Database Driver Class Initialized
INFO - 2023-05-26 02:23:52 --> Model "Login_model" initialized
INFO - 2023-05-26 02:23:52 --> Final output sent to browser
DEBUG - 2023-05-26 02:23:52 --> Total execution time: 0.5886
INFO - 2023-05-26 02:23:52 --> Config Class Initialized
INFO - 2023-05-26 02:23:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:23:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:23:52 --> Utf8 Class Initialized
INFO - 2023-05-26 02:23:52 --> URI Class Initialized
INFO - 2023-05-26 02:23:52 --> Router Class Initialized
INFO - 2023-05-26 02:23:52 --> Output Class Initialized
INFO - 2023-05-26 02:23:52 --> Security Class Initialized
DEBUG - 2023-05-26 02:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:23:52 --> Input Class Initialized
INFO - 2023-05-26 02:23:52 --> Language Class Initialized
INFO - 2023-05-26 02:23:52 --> Loader Class Initialized
INFO - 2023-05-26 02:23:52 --> Controller Class Initialized
DEBUG - 2023-05-26 02:23:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:23:52 --> Database Driver Class Initialized
INFO - 2023-05-26 02:23:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:23:52 --> Final output sent to browser
DEBUG - 2023-05-26 02:23:52 --> Total execution time: 0.7206
INFO - 2023-05-26 02:24:16 --> Final output sent to browser
DEBUG - 2023-05-26 02:24:16 --> Total execution time: 24.5890
INFO - 2023-05-26 02:24:16 --> Config Class Initialized
INFO - 2023-05-26 02:24:16 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:24:16 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:24:16 --> Utf8 Class Initialized
INFO - 2023-05-26 02:24:16 --> URI Class Initialized
INFO - 2023-05-26 02:24:16 --> Router Class Initialized
INFO - 2023-05-26 02:24:16 --> Output Class Initialized
INFO - 2023-05-26 02:24:16 --> Security Class Initialized
DEBUG - 2023-05-26 02:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:24:16 --> Input Class Initialized
INFO - 2023-05-26 02:24:16 --> Language Class Initialized
INFO - 2023-05-26 02:24:16 --> Loader Class Initialized
INFO - 2023-05-26 02:24:16 --> Controller Class Initialized
DEBUG - 2023-05-26 02:24:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:24:16 --> Database Driver Class Initialized
INFO - 2023-05-26 02:24:16 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:24:16 --> Database Driver Class Initialized
INFO - 2023-05-26 02:24:16 --> Model "Login_model" initialized
INFO - 2023-05-26 02:24:46 --> Final output sent to browser
DEBUG - 2023-05-26 02:24:46 --> Total execution time: 30.0163
INFO - 2023-05-26 02:24:51 --> Config Class Initialized
INFO - 2023-05-26 02:24:51 --> Config Class Initialized
INFO - 2023-05-26 02:24:51 --> Hooks Class Initialized
INFO - 2023-05-26 02:24:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:24:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 02:24:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:24:51 --> Utf8 Class Initialized
INFO - 2023-05-26 02:24:51 --> Utf8 Class Initialized
INFO - 2023-05-26 02:24:51 --> URI Class Initialized
INFO - 2023-05-26 02:24:51 --> URI Class Initialized
INFO - 2023-05-26 02:24:51 --> Router Class Initialized
INFO - 2023-05-26 02:24:51 --> Output Class Initialized
INFO - 2023-05-26 02:24:51 --> Router Class Initialized
INFO - 2023-05-26 02:24:51 --> Security Class Initialized
INFO - 2023-05-26 02:24:51 --> Output Class Initialized
DEBUG - 2023-05-26 02:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:24:51 --> Input Class Initialized
INFO - 2023-05-26 02:24:51 --> Security Class Initialized
INFO - 2023-05-26 02:24:51 --> Language Class Initialized
DEBUG - 2023-05-26 02:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:24:51 --> Input Class Initialized
INFO - 2023-05-26 02:24:51 --> Language Class Initialized
INFO - 2023-05-26 02:24:51 --> Loader Class Initialized
INFO - 2023-05-26 02:24:51 --> Controller Class Initialized
DEBUG - 2023-05-26 02:24:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:24:51 --> Loader Class Initialized
INFO - 2023-05-26 02:24:51 --> Controller Class Initialized
DEBUG - 2023-05-26 02:24:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:24:51 --> Database Driver Class Initialized
INFO - 2023-05-26 02:24:51 --> Database Driver Class Initialized
INFO - 2023-05-26 02:24:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:24:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:24:51 --> Database Driver Class Initialized
INFO - 2023-05-26 02:24:52 --> Model "Login_model" initialized
INFO - 2023-05-26 02:24:52 --> Final output sent to browser
DEBUG - 2023-05-26 02:24:52 --> Total execution time: 0.5965
INFO - 2023-05-26 02:24:52 --> Config Class Initialized
INFO - 2023-05-26 02:24:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:24:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:24:52 --> Utf8 Class Initialized
INFO - 2023-05-26 02:24:52 --> URI Class Initialized
INFO - 2023-05-26 02:24:52 --> Router Class Initialized
INFO - 2023-05-26 02:24:52 --> Output Class Initialized
INFO - 2023-05-26 02:24:52 --> Security Class Initialized
DEBUG - 2023-05-26 02:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:24:52 --> Input Class Initialized
INFO - 2023-05-26 02:24:52 --> Language Class Initialized
INFO - 2023-05-26 02:24:52 --> Loader Class Initialized
INFO - 2023-05-26 02:24:52 --> Controller Class Initialized
DEBUG - 2023-05-26 02:24:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:24:52 --> Database Driver Class Initialized
INFO - 2023-05-26 02:24:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:24:52 --> Final output sent to browser
DEBUG - 2023-05-26 02:24:52 --> Total execution time: 0.6912
INFO - 2023-05-26 02:25:18 --> Final output sent to browser
DEBUG - 2023-05-26 02:25:18 --> Total execution time: 26.8880
INFO - 2023-05-26 02:25:18 --> Config Class Initialized
INFO - 2023-05-26 02:25:18 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:25:18 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:25:18 --> Utf8 Class Initialized
INFO - 2023-05-26 02:25:18 --> URI Class Initialized
INFO - 2023-05-26 02:25:18 --> Router Class Initialized
INFO - 2023-05-26 02:25:18 --> Output Class Initialized
INFO - 2023-05-26 02:25:18 --> Security Class Initialized
DEBUG - 2023-05-26 02:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:25:18 --> Input Class Initialized
INFO - 2023-05-26 02:25:18 --> Language Class Initialized
INFO - 2023-05-26 02:25:18 --> Loader Class Initialized
INFO - 2023-05-26 02:25:18 --> Controller Class Initialized
DEBUG - 2023-05-26 02:25:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:25:18 --> Database Driver Class Initialized
INFO - 2023-05-26 02:25:18 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:25:18 --> Database Driver Class Initialized
INFO - 2023-05-26 02:25:18 --> Model "Login_model" initialized
INFO - 2023-05-26 02:25:47 --> Final output sent to browser
DEBUG - 2023-05-26 02:25:47 --> Total execution time: 29.3743
INFO - 2023-05-26 02:25:51 --> Config Class Initialized
INFO - 2023-05-26 02:25:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:25:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:25:51 --> Utf8 Class Initialized
INFO - 2023-05-26 02:25:51 --> URI Class Initialized
INFO - 2023-05-26 02:25:51 --> Router Class Initialized
INFO - 2023-05-26 02:25:51 --> Output Class Initialized
INFO - 2023-05-26 02:25:51 --> Security Class Initialized
DEBUG - 2023-05-26 02:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:25:51 --> Input Class Initialized
INFO - 2023-05-26 02:25:51 --> Language Class Initialized
INFO - 2023-05-26 02:25:51 --> Loader Class Initialized
INFO - 2023-05-26 02:25:51 --> Controller Class Initialized
DEBUG - 2023-05-26 02:25:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:25:51 --> Database Driver Class Initialized
INFO - 2023-05-26 02:25:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:25:51 --> Final output sent to browser
DEBUG - 2023-05-26 02:25:51 --> Total execution time: 0.3956
INFO - 2023-05-26 02:25:52 --> Config Class Initialized
INFO - 2023-05-26 02:25:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:25:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:25:52 --> Utf8 Class Initialized
INFO - 2023-05-26 02:25:52 --> URI Class Initialized
INFO - 2023-05-26 02:25:52 --> Router Class Initialized
INFO - 2023-05-26 02:25:52 --> Output Class Initialized
INFO - 2023-05-26 02:25:52 --> Security Class Initialized
DEBUG - 2023-05-26 02:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:25:52 --> Input Class Initialized
INFO - 2023-05-26 02:25:52 --> Language Class Initialized
INFO - 2023-05-26 02:25:52 --> Loader Class Initialized
INFO - 2023-05-26 02:25:52 --> Controller Class Initialized
DEBUG - 2023-05-26 02:25:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:25:52 --> Database Driver Class Initialized
INFO - 2023-05-26 02:25:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:25:52 --> Final output sent to browser
DEBUG - 2023-05-26 02:25:52 --> Total execution time: 0.6513
INFO - 2023-05-26 02:26:39 --> Config Class Initialized
INFO - 2023-05-26 02:26:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:26:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:26:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:26:39 --> URI Class Initialized
INFO - 2023-05-26 02:26:39 --> Router Class Initialized
INFO - 2023-05-26 02:26:39 --> Output Class Initialized
INFO - 2023-05-26 02:26:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:26:39 --> Input Class Initialized
INFO - 2023-05-26 02:26:39 --> Language Class Initialized
INFO - 2023-05-26 02:26:39 --> Loader Class Initialized
INFO - 2023-05-26 02:26:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:26:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:26:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:26:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:26:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:26:39 --> Model "Login_model" initialized
INFO - 2023-05-26 02:26:53 --> Final output sent to browser
DEBUG - 2023-05-26 02:26:53 --> Total execution time: 13.6736
INFO - 2023-05-26 02:26:53 --> Config Class Initialized
INFO - 2023-05-26 02:26:53 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:26:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:26:53 --> Utf8 Class Initialized
INFO - 2023-05-26 02:26:53 --> URI Class Initialized
INFO - 2023-05-26 02:26:53 --> Router Class Initialized
INFO - 2023-05-26 02:26:53 --> Output Class Initialized
INFO - 2023-05-26 02:26:53 --> Security Class Initialized
DEBUG - 2023-05-26 02:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:26:53 --> Input Class Initialized
INFO - 2023-05-26 02:26:53 --> Language Class Initialized
INFO - 2023-05-26 02:26:53 --> Loader Class Initialized
INFO - 2023-05-26 02:26:53 --> Controller Class Initialized
DEBUG - 2023-05-26 02:26:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:26:53 --> Database Driver Class Initialized
INFO - 2023-05-26 02:26:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:26:53 --> Database Driver Class Initialized
INFO - 2023-05-26 02:26:53 --> Model "Login_model" initialized
INFO - 2023-05-26 02:27:05 --> Final output sent to browser
DEBUG - 2023-05-26 02:27:05 --> Total execution time: 12.5052
INFO - 2023-05-26 02:27:39 --> Config Class Initialized
INFO - 2023-05-26 02:27:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:27:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:27:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:27:39 --> URI Class Initialized
INFO - 2023-05-26 02:27:39 --> Router Class Initialized
INFO - 2023-05-26 02:27:39 --> Output Class Initialized
INFO - 2023-05-26 02:27:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:27:39 --> Input Class Initialized
INFO - 2023-05-26 02:27:39 --> Language Class Initialized
INFO - 2023-05-26 02:27:39 --> Loader Class Initialized
INFO - 2023-05-26 02:27:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:27:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:27:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:27:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:27:39 --> Final output sent to browser
DEBUG - 2023-05-26 02:27:39 --> Total execution time: 0.4451
INFO - 2023-05-26 02:27:40 --> Config Class Initialized
INFO - 2023-05-26 02:27:40 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:27:40 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:27:40 --> Utf8 Class Initialized
INFO - 2023-05-26 02:27:40 --> URI Class Initialized
INFO - 2023-05-26 02:27:40 --> Router Class Initialized
INFO - 2023-05-26 02:27:40 --> Output Class Initialized
INFO - 2023-05-26 02:27:40 --> Security Class Initialized
DEBUG - 2023-05-26 02:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:27:40 --> Input Class Initialized
INFO - 2023-05-26 02:27:40 --> Language Class Initialized
INFO - 2023-05-26 02:27:40 --> Loader Class Initialized
INFO - 2023-05-26 02:27:40 --> Controller Class Initialized
DEBUG - 2023-05-26 02:27:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:27:40 --> Database Driver Class Initialized
INFO - 2023-05-26 02:27:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:27:40 --> Final output sent to browser
DEBUG - 2023-05-26 02:27:40 --> Total execution time: 0.2471
INFO - 2023-05-26 02:28:39 --> Config Class Initialized
INFO - 2023-05-26 02:28:39 --> Config Class Initialized
INFO - 2023-05-26 02:28:39 --> Hooks Class Initialized
INFO - 2023-05-26 02:28:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:28:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 02:28:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:28:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:28:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:28:39 --> URI Class Initialized
INFO - 2023-05-26 02:28:39 --> URI Class Initialized
INFO - 2023-05-26 02:28:39 --> Router Class Initialized
INFO - 2023-05-26 02:28:39 --> Router Class Initialized
INFO - 2023-05-26 02:28:39 --> Output Class Initialized
INFO - 2023-05-26 02:28:39 --> Output Class Initialized
INFO - 2023-05-26 02:28:39 --> Security Class Initialized
INFO - 2023-05-26 02:28:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 02:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:28:39 --> Input Class Initialized
INFO - 2023-05-26 02:28:39 --> Input Class Initialized
INFO - 2023-05-26 02:28:39 --> Language Class Initialized
INFO - 2023-05-26 02:28:39 --> Language Class Initialized
INFO - 2023-05-26 02:28:39 --> Loader Class Initialized
INFO - 2023-05-26 02:28:39 --> Loader Class Initialized
INFO - 2023-05-26 02:28:39 --> Controller Class Initialized
INFO - 2023-05-26 02:28:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:28:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 02:28:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:28:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:28:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:28:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:28:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:28:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:28:39 --> Model "Login_model" initialized
INFO - 2023-05-26 02:28:39 --> Final output sent to browser
DEBUG - 2023-05-26 02:28:39 --> Total execution time: 0.3873
INFO - 2023-05-26 02:28:39 --> Config Class Initialized
INFO - 2023-05-26 02:28:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:28:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:28:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:28:39 --> URI Class Initialized
INFO - 2023-05-26 02:28:40 --> Router Class Initialized
INFO - 2023-05-26 02:28:40 --> Output Class Initialized
INFO - 2023-05-26 02:28:40 --> Security Class Initialized
DEBUG - 2023-05-26 02:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:28:40 --> Input Class Initialized
INFO - 2023-05-26 02:28:40 --> Language Class Initialized
INFO - 2023-05-26 02:28:40 --> Loader Class Initialized
INFO - 2023-05-26 02:28:40 --> Controller Class Initialized
DEBUG - 2023-05-26 02:28:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:28:40 --> Database Driver Class Initialized
INFO - 2023-05-26 02:28:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:28:40 --> Final output sent to browser
DEBUG - 2023-05-26 02:28:40 --> Total execution time: 0.2391
INFO - 2023-05-26 02:28:49 --> Final output sent to browser
DEBUG - 2023-05-26 02:28:49 --> Total execution time: 9.6376
INFO - 2023-05-26 02:28:49 --> Config Class Initialized
INFO - 2023-05-26 02:28:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:28:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:28:49 --> Utf8 Class Initialized
INFO - 2023-05-26 02:28:49 --> URI Class Initialized
INFO - 2023-05-26 02:28:49 --> Router Class Initialized
INFO - 2023-05-26 02:28:49 --> Output Class Initialized
INFO - 2023-05-26 02:28:49 --> Security Class Initialized
DEBUG - 2023-05-26 02:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:28:49 --> Input Class Initialized
INFO - 2023-05-26 02:28:49 --> Language Class Initialized
INFO - 2023-05-26 02:28:49 --> Loader Class Initialized
INFO - 2023-05-26 02:28:49 --> Controller Class Initialized
DEBUG - 2023-05-26 02:28:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:28:49 --> Database Driver Class Initialized
INFO - 2023-05-26 02:28:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:28:49 --> Database Driver Class Initialized
INFO - 2023-05-26 02:28:49 --> Model "Login_model" initialized
INFO - 2023-05-26 02:28:57 --> Final output sent to browser
DEBUG - 2023-05-26 02:28:57 --> Total execution time: 8.5406
INFO - 2023-05-26 02:29:39 --> Config Class Initialized
INFO - 2023-05-26 02:29:39 --> Hooks Class Initialized
INFO - 2023-05-26 02:29:39 --> Config Class Initialized
INFO - 2023-05-26 02:29:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:29:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:29:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:29:39 --> URI Class Initialized
DEBUG - 2023-05-26 02:29:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:29:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:29:39 --> Router Class Initialized
INFO - 2023-05-26 02:29:39 --> URI Class Initialized
INFO - 2023-05-26 02:29:39 --> Output Class Initialized
INFO - 2023-05-26 02:29:39 --> Security Class Initialized
INFO - 2023-05-26 02:29:39 --> Router Class Initialized
DEBUG - 2023-05-26 02:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:29:39 --> Input Class Initialized
INFO - 2023-05-26 02:29:39 --> Output Class Initialized
INFO - 2023-05-26 02:29:39 --> Language Class Initialized
INFO - 2023-05-26 02:29:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:29:39 --> Input Class Initialized
INFO - 2023-05-26 02:29:39 --> Language Class Initialized
INFO - 2023-05-26 02:29:39 --> Loader Class Initialized
INFO - 2023-05-26 02:29:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:29:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:29:39 --> Loader Class Initialized
INFO - 2023-05-26 02:29:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:29:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:29:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:29:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:29:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:29:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:29:39 --> Model "Login_model" initialized
INFO - 2023-05-26 02:29:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:29:39 --> Final output sent to browser
DEBUG - 2023-05-26 02:29:39 --> Total execution time: 0.3492
INFO - 2023-05-26 02:29:39 --> Config Class Initialized
INFO - 2023-05-26 02:29:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:29:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:29:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:29:39 --> URI Class Initialized
INFO - 2023-05-26 02:29:39 --> Router Class Initialized
INFO - 2023-05-26 02:29:39 --> Output Class Initialized
INFO - 2023-05-26 02:29:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:29:39 --> Input Class Initialized
INFO - 2023-05-26 02:29:40 --> Language Class Initialized
INFO - 2023-05-26 02:29:40 --> Loader Class Initialized
INFO - 2023-05-26 02:29:40 --> Controller Class Initialized
DEBUG - 2023-05-26 02:29:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:29:40 --> Database Driver Class Initialized
INFO - 2023-05-26 02:29:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:29:40 --> Final output sent to browser
DEBUG - 2023-05-26 02:29:40 --> Total execution time: 0.2377
INFO - 2023-05-26 02:29:51 --> Final output sent to browser
DEBUG - 2023-05-26 02:29:51 --> Total execution time: 11.7487
INFO - 2023-05-26 02:29:51 --> Config Class Initialized
INFO - 2023-05-26 02:29:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:29:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:29:51 --> Utf8 Class Initialized
INFO - 2023-05-26 02:29:51 --> URI Class Initialized
INFO - 2023-05-26 02:29:51 --> Router Class Initialized
INFO - 2023-05-26 02:29:51 --> Output Class Initialized
INFO - 2023-05-26 02:29:51 --> Security Class Initialized
DEBUG - 2023-05-26 02:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:29:51 --> Input Class Initialized
INFO - 2023-05-26 02:29:51 --> Language Class Initialized
INFO - 2023-05-26 02:29:51 --> Loader Class Initialized
INFO - 2023-05-26 02:29:51 --> Controller Class Initialized
DEBUG - 2023-05-26 02:29:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:29:51 --> Database Driver Class Initialized
INFO - 2023-05-26 02:29:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:29:51 --> Database Driver Class Initialized
INFO - 2023-05-26 02:29:51 --> Model "Login_model" initialized
INFO - 2023-05-26 02:30:03 --> Final output sent to browser
DEBUG - 2023-05-26 02:30:03 --> Total execution time: 11.9808
INFO - 2023-05-26 02:30:39 --> Config Class Initialized
INFO - 2023-05-26 02:30:39 --> Config Class Initialized
INFO - 2023-05-26 02:30:39 --> Hooks Class Initialized
INFO - 2023-05-26 02:30:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:30:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 02:30:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:30:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:30:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:30:39 --> URI Class Initialized
INFO - 2023-05-26 02:30:39 --> URI Class Initialized
INFO - 2023-05-26 02:30:39 --> Router Class Initialized
INFO - 2023-05-26 02:30:39 --> Router Class Initialized
INFO - 2023-05-26 02:30:39 --> Output Class Initialized
INFO - 2023-05-26 02:30:39 --> Output Class Initialized
INFO - 2023-05-26 02:30:39 --> Security Class Initialized
INFO - 2023-05-26 02:30:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 02:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:30:39 --> Input Class Initialized
INFO - 2023-05-26 02:30:39 --> Input Class Initialized
INFO - 2023-05-26 02:30:39 --> Language Class Initialized
INFO - 2023-05-26 02:30:39 --> Language Class Initialized
INFO - 2023-05-26 02:30:39 --> Loader Class Initialized
INFO - 2023-05-26 02:30:39 --> Loader Class Initialized
INFO - 2023-05-26 02:30:39 --> Controller Class Initialized
INFO - 2023-05-26 02:30:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:30:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 02:30:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:30:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:30:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:30:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:30:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:30:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:30:39 --> Model "Login_model" initialized
INFO - 2023-05-26 02:30:39 --> Final output sent to browser
DEBUG - 2023-05-26 02:30:39 --> Total execution time: 0.2431
INFO - 2023-05-26 02:30:39 --> Config Class Initialized
INFO - 2023-05-26 02:30:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:30:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:30:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:30:39 --> URI Class Initialized
INFO - 2023-05-26 02:30:39 --> Router Class Initialized
INFO - 2023-05-26 02:30:39 --> Output Class Initialized
INFO - 2023-05-26 02:30:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:30:39 --> Input Class Initialized
INFO - 2023-05-26 02:30:39 --> Language Class Initialized
INFO - 2023-05-26 02:30:39 --> Loader Class Initialized
INFO - 2023-05-26 02:30:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:30:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:30:40 --> Database Driver Class Initialized
INFO - 2023-05-26 02:30:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:30:40 --> Final output sent to browser
DEBUG - 2023-05-26 02:30:40 --> Total execution time: 0.3261
INFO - 2023-05-26 02:30:49 --> Final output sent to browser
DEBUG - 2023-05-26 02:30:49 --> Total execution time: 9.9947
INFO - 2023-05-26 02:30:49 --> Config Class Initialized
INFO - 2023-05-26 02:30:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:30:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:30:49 --> Utf8 Class Initialized
INFO - 2023-05-26 02:30:49 --> URI Class Initialized
INFO - 2023-05-26 02:30:49 --> Router Class Initialized
INFO - 2023-05-26 02:30:49 --> Output Class Initialized
INFO - 2023-05-26 02:30:49 --> Security Class Initialized
DEBUG - 2023-05-26 02:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:30:49 --> Input Class Initialized
INFO - 2023-05-26 02:30:49 --> Language Class Initialized
INFO - 2023-05-26 02:30:49 --> Loader Class Initialized
INFO - 2023-05-26 02:30:49 --> Controller Class Initialized
DEBUG - 2023-05-26 02:30:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:30:49 --> Database Driver Class Initialized
INFO - 2023-05-26 02:30:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:30:49 --> Database Driver Class Initialized
INFO - 2023-05-26 02:30:49 --> Model "Login_model" initialized
INFO - 2023-05-26 02:31:01 --> Final output sent to browser
DEBUG - 2023-05-26 02:31:01 --> Total execution time: 11.5025
INFO - 2023-05-26 02:31:39 --> Config Class Initialized
INFO - 2023-05-26 02:31:39 --> Config Class Initialized
INFO - 2023-05-26 02:31:39 --> Hooks Class Initialized
INFO - 2023-05-26 02:31:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:31:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:31:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:31:39 --> URI Class Initialized
DEBUG - 2023-05-26 02:31:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:31:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:31:39 --> Router Class Initialized
INFO - 2023-05-26 02:31:39 --> URI Class Initialized
INFO - 2023-05-26 02:31:39 --> Output Class Initialized
INFO - 2023-05-26 02:31:39 --> Security Class Initialized
INFO - 2023-05-26 02:31:39 --> Router Class Initialized
DEBUG - 2023-05-26 02:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:31:39 --> Input Class Initialized
INFO - 2023-05-26 02:31:39 --> Output Class Initialized
INFO - 2023-05-26 02:31:39 --> Language Class Initialized
INFO - 2023-05-26 02:31:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:31:39 --> Input Class Initialized
INFO - 2023-05-26 02:31:39 --> Loader Class Initialized
INFO - 2023-05-26 02:31:39 --> Language Class Initialized
INFO - 2023-05-26 02:31:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:31:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:31:39 --> Loader Class Initialized
INFO - 2023-05-26 02:31:39 --> Controller Class Initialized
INFO - 2023-05-26 02:31:39 --> Database Driver Class Initialized
DEBUG - 2023-05-26 02:31:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:31:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:31:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:31:39 --> Model "Login_model" initialized
INFO - 2023-05-26 02:31:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:31:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:31:39 --> Final output sent to browser
DEBUG - 2023-05-26 02:31:39 --> Total execution time: 0.3025
INFO - 2023-05-26 02:31:39 --> Config Class Initialized
INFO - 2023-05-26 02:31:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:31:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:31:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:31:39 --> URI Class Initialized
INFO - 2023-05-26 02:31:39 --> Router Class Initialized
INFO - 2023-05-26 02:31:39 --> Output Class Initialized
INFO - 2023-05-26 02:31:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:31:39 --> Input Class Initialized
INFO - 2023-05-26 02:31:39 --> Language Class Initialized
INFO - 2023-05-26 02:31:39 --> Loader Class Initialized
INFO - 2023-05-26 02:31:40 --> Controller Class Initialized
DEBUG - 2023-05-26 02:31:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:31:40 --> Database Driver Class Initialized
INFO - 2023-05-26 02:31:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:31:40 --> Final output sent to browser
DEBUG - 2023-05-26 02:31:40 --> Total execution time: 0.2255
INFO - 2023-05-26 02:31:47 --> Final output sent to browser
DEBUG - 2023-05-26 02:31:47 --> Total execution time: 8.3625
INFO - 2023-05-26 02:31:47 --> Config Class Initialized
INFO - 2023-05-26 02:31:47 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:31:47 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:31:47 --> Utf8 Class Initialized
INFO - 2023-05-26 02:31:47 --> URI Class Initialized
INFO - 2023-05-26 02:31:48 --> Router Class Initialized
INFO - 2023-05-26 02:31:48 --> Output Class Initialized
INFO - 2023-05-26 02:31:48 --> Security Class Initialized
DEBUG - 2023-05-26 02:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:31:48 --> Input Class Initialized
INFO - 2023-05-26 02:31:48 --> Language Class Initialized
INFO - 2023-05-26 02:31:48 --> Loader Class Initialized
INFO - 2023-05-26 02:31:48 --> Controller Class Initialized
DEBUG - 2023-05-26 02:31:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:31:48 --> Database Driver Class Initialized
INFO - 2023-05-26 02:31:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:31:48 --> Database Driver Class Initialized
INFO - 2023-05-26 02:31:48 --> Model "Login_model" initialized
INFO - 2023-05-26 02:31:57 --> Final output sent to browser
DEBUG - 2023-05-26 02:31:57 --> Total execution time: 9.6664
INFO - 2023-05-26 02:32:39 --> Config Class Initialized
INFO - 2023-05-26 02:32:39 --> Config Class Initialized
INFO - 2023-05-26 02:32:39 --> Hooks Class Initialized
INFO - 2023-05-26 02:32:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:32:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 02:32:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:32:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:32:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:32:39 --> URI Class Initialized
INFO - 2023-05-26 02:32:39 --> URI Class Initialized
INFO - 2023-05-26 02:32:39 --> Router Class Initialized
INFO - 2023-05-26 02:32:39 --> Router Class Initialized
INFO - 2023-05-26 02:32:39 --> Output Class Initialized
INFO - 2023-05-26 02:32:39 --> Output Class Initialized
INFO - 2023-05-26 02:32:39 --> Security Class Initialized
INFO - 2023-05-26 02:32:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 02:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:32:39 --> Input Class Initialized
INFO - 2023-05-26 02:32:39 --> Input Class Initialized
INFO - 2023-05-26 02:32:39 --> Language Class Initialized
INFO - 2023-05-26 02:32:39 --> Language Class Initialized
INFO - 2023-05-26 02:32:39 --> Loader Class Initialized
INFO - 2023-05-26 02:32:39 --> Loader Class Initialized
INFO - 2023-05-26 02:32:39 --> Controller Class Initialized
INFO - 2023-05-26 02:32:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:32:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 02:32:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:32:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:32:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:32:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:32:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:32:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:32:39 --> Model "Login_model" initialized
INFO - 2023-05-26 02:32:39 --> Final output sent to browser
DEBUG - 2023-05-26 02:32:39 --> Total execution time: 0.1796
INFO - 2023-05-26 02:32:39 --> Config Class Initialized
INFO - 2023-05-26 02:32:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:32:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:32:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:32:39 --> URI Class Initialized
INFO - 2023-05-26 02:32:39 --> Router Class Initialized
INFO - 2023-05-26 02:32:39 --> Output Class Initialized
INFO - 2023-05-26 02:32:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:32:39 --> Input Class Initialized
INFO - 2023-05-26 02:32:39 --> Language Class Initialized
INFO - 2023-05-26 02:32:39 --> Loader Class Initialized
INFO - 2023-05-26 02:32:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:32:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:32:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:32:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:32:39 --> Final output sent to browser
DEBUG - 2023-05-26 02:32:39 --> Total execution time: 0.2234
INFO - 2023-05-26 02:32:49 --> Final output sent to browser
DEBUG - 2023-05-26 02:32:49 --> Total execution time: 9.6445
INFO - 2023-05-26 02:32:49 --> Config Class Initialized
INFO - 2023-05-26 02:32:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:32:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:32:49 --> Utf8 Class Initialized
INFO - 2023-05-26 02:32:49 --> URI Class Initialized
INFO - 2023-05-26 02:32:49 --> Router Class Initialized
INFO - 2023-05-26 02:32:49 --> Output Class Initialized
INFO - 2023-05-26 02:32:49 --> Security Class Initialized
DEBUG - 2023-05-26 02:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:32:49 --> Input Class Initialized
INFO - 2023-05-26 02:32:49 --> Language Class Initialized
INFO - 2023-05-26 02:32:49 --> Loader Class Initialized
INFO - 2023-05-26 02:32:49 --> Controller Class Initialized
DEBUG - 2023-05-26 02:32:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:32:49 --> Database Driver Class Initialized
INFO - 2023-05-26 02:32:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:32:49 --> Database Driver Class Initialized
INFO - 2023-05-26 02:32:49 --> Model "Login_model" initialized
INFO - 2023-05-26 02:33:00 --> Final output sent to browser
DEBUG - 2023-05-26 02:33:00 --> Total execution time: 10.8751
INFO - 2023-05-26 02:33:39 --> Config Class Initialized
INFO - 2023-05-26 02:33:39 --> Config Class Initialized
INFO - 2023-05-26 02:33:39 --> Hooks Class Initialized
INFO - 2023-05-26 02:33:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:33:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 02:33:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:33:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:33:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:33:39 --> URI Class Initialized
INFO - 2023-05-26 02:33:39 --> URI Class Initialized
INFO - 2023-05-26 02:33:39 --> Router Class Initialized
INFO - 2023-05-26 02:33:39 --> Output Class Initialized
INFO - 2023-05-26 02:33:39 --> Router Class Initialized
INFO - 2023-05-26 02:33:39 --> Security Class Initialized
INFO - 2023-05-26 02:33:39 --> Output Class Initialized
DEBUG - 2023-05-26 02:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:33:39 --> Input Class Initialized
INFO - 2023-05-26 02:33:39 --> Security Class Initialized
INFO - 2023-05-26 02:33:39 --> Language Class Initialized
DEBUG - 2023-05-26 02:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:33:39 --> Input Class Initialized
INFO - 2023-05-26 02:33:39 --> Language Class Initialized
INFO - 2023-05-26 02:33:39 --> Loader Class Initialized
INFO - 2023-05-26 02:33:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:33:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:33:39 --> Loader Class Initialized
INFO - 2023-05-26 02:33:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:33:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:33:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:33:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:33:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:33:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:33:39 --> Model "Login_model" initialized
INFO - 2023-05-26 02:33:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:33:39 --> Final output sent to browser
DEBUG - 2023-05-26 02:33:39 --> Total execution time: 0.2301
INFO - 2023-05-26 02:33:39 --> Config Class Initialized
INFO - 2023-05-26 02:33:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:33:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:33:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:33:39 --> URI Class Initialized
INFO - 2023-05-26 02:33:39 --> Router Class Initialized
INFO - 2023-05-26 02:33:39 --> Output Class Initialized
INFO - 2023-05-26 02:33:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:33:39 --> Input Class Initialized
INFO - 2023-05-26 02:33:39 --> Language Class Initialized
INFO - 2023-05-26 02:33:39 --> Loader Class Initialized
INFO - 2023-05-26 02:33:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:33:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:33:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:33:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:33:40 --> Final output sent to browser
DEBUG - 2023-05-26 02:33:40 --> Total execution time: 0.2356
INFO - 2023-05-26 02:33:48 --> Final output sent to browser
DEBUG - 2023-05-26 02:33:48 --> Total execution time: 8.9265
INFO - 2023-05-26 02:33:48 --> Config Class Initialized
INFO - 2023-05-26 02:33:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:33:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:33:48 --> Utf8 Class Initialized
INFO - 2023-05-26 02:33:48 --> URI Class Initialized
INFO - 2023-05-26 02:33:48 --> Router Class Initialized
INFO - 2023-05-26 02:33:48 --> Output Class Initialized
INFO - 2023-05-26 02:33:48 --> Security Class Initialized
DEBUG - 2023-05-26 02:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:33:48 --> Input Class Initialized
INFO - 2023-05-26 02:33:48 --> Language Class Initialized
INFO - 2023-05-26 02:33:48 --> Loader Class Initialized
INFO - 2023-05-26 02:33:48 --> Controller Class Initialized
DEBUG - 2023-05-26 02:33:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:33:48 --> Database Driver Class Initialized
INFO - 2023-05-26 02:33:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:33:48 --> Database Driver Class Initialized
INFO - 2023-05-26 02:33:48 --> Model "Login_model" initialized
INFO - 2023-05-26 02:33:57 --> Final output sent to browser
DEBUG - 2023-05-26 02:33:57 --> Total execution time: 9.0685
INFO - 2023-05-26 02:34:39 --> Config Class Initialized
INFO - 2023-05-26 02:34:39 --> Hooks Class Initialized
INFO - 2023-05-26 02:34:39 --> Config Class Initialized
DEBUG - 2023-05-26 02:34:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:34:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:34:39 --> Hooks Class Initialized
INFO - 2023-05-26 02:34:39 --> URI Class Initialized
INFO - 2023-05-26 02:34:39 --> Router Class Initialized
DEBUG - 2023-05-26 02:34:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:34:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:34:39 --> Output Class Initialized
INFO - 2023-05-26 02:34:39 --> Security Class Initialized
INFO - 2023-05-26 02:34:39 --> URI Class Initialized
DEBUG - 2023-05-26 02:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:34:39 --> Input Class Initialized
INFO - 2023-05-26 02:34:39 --> Router Class Initialized
INFO - 2023-05-26 02:34:39 --> Language Class Initialized
INFO - 2023-05-26 02:34:39 --> Output Class Initialized
INFO - 2023-05-26 02:34:39 --> Security Class Initialized
INFO - 2023-05-26 02:34:39 --> Loader Class Initialized
DEBUG - 2023-05-26 02:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:34:39 --> Input Class Initialized
INFO - 2023-05-26 02:34:39 --> Controller Class Initialized
INFO - 2023-05-26 02:34:39 --> Language Class Initialized
DEBUG - 2023-05-26 02:34:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:34:39 --> Loader Class Initialized
INFO - 2023-05-26 02:34:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:34:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:34:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:34:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:34:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:34:39 --> Model "Login_model" initialized
INFO - 2023-05-26 02:34:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:34:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:34:39 --> Final output sent to browser
DEBUG - 2023-05-26 02:34:39 --> Total execution time: 0.3314
INFO - 2023-05-26 02:34:39 --> Config Class Initialized
INFO - 2023-05-26 02:34:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:34:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:34:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:34:39 --> URI Class Initialized
INFO - 2023-05-26 02:34:40 --> Router Class Initialized
INFO - 2023-05-26 02:34:40 --> Output Class Initialized
INFO - 2023-05-26 02:34:40 --> Security Class Initialized
DEBUG - 2023-05-26 02:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:34:40 --> Input Class Initialized
INFO - 2023-05-26 02:34:40 --> Language Class Initialized
INFO - 2023-05-26 02:34:40 --> Loader Class Initialized
INFO - 2023-05-26 02:34:40 --> Controller Class Initialized
DEBUG - 2023-05-26 02:34:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:34:40 --> Database Driver Class Initialized
INFO - 2023-05-26 02:34:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:34:40 --> Final output sent to browser
DEBUG - 2023-05-26 02:34:40 --> Total execution time: 0.2703
INFO - 2023-05-26 02:34:49 --> Final output sent to browser
DEBUG - 2023-05-26 02:34:49 --> Total execution time: 9.6829
INFO - 2023-05-26 02:34:49 --> Config Class Initialized
INFO - 2023-05-26 02:34:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:34:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:34:49 --> Utf8 Class Initialized
INFO - 2023-05-26 02:34:49 --> URI Class Initialized
INFO - 2023-05-26 02:34:49 --> Router Class Initialized
INFO - 2023-05-26 02:34:49 --> Output Class Initialized
INFO - 2023-05-26 02:34:49 --> Security Class Initialized
DEBUG - 2023-05-26 02:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:34:49 --> Input Class Initialized
INFO - 2023-05-26 02:34:49 --> Language Class Initialized
INFO - 2023-05-26 02:34:49 --> Loader Class Initialized
INFO - 2023-05-26 02:34:49 --> Controller Class Initialized
DEBUG - 2023-05-26 02:34:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:34:49 --> Database Driver Class Initialized
INFO - 2023-05-26 02:34:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:34:49 --> Database Driver Class Initialized
INFO - 2023-05-26 02:34:49 --> Model "Login_model" initialized
INFO - 2023-05-26 02:34:59 --> Final output sent to browser
DEBUG - 2023-05-26 02:34:59 --> Total execution time: 10.0419
INFO - 2023-05-26 02:35:39 --> Config Class Initialized
INFO - 2023-05-26 02:35:39 --> Config Class Initialized
INFO - 2023-05-26 02:35:39 --> Hooks Class Initialized
INFO - 2023-05-26 02:35:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:35:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 02:35:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:35:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:35:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:35:39 --> URI Class Initialized
INFO - 2023-05-26 02:35:39 --> URI Class Initialized
INFO - 2023-05-26 02:35:39 --> Router Class Initialized
INFO - 2023-05-26 02:35:39 --> Router Class Initialized
INFO - 2023-05-26 02:35:39 --> Output Class Initialized
INFO - 2023-05-26 02:35:39 --> Output Class Initialized
INFO - 2023-05-26 02:35:39 --> Security Class Initialized
INFO - 2023-05-26 02:35:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 02:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:35:39 --> Input Class Initialized
INFO - 2023-05-26 02:35:39 --> Input Class Initialized
INFO - 2023-05-26 02:35:39 --> Language Class Initialized
INFO - 2023-05-26 02:35:39 --> Language Class Initialized
INFO - 2023-05-26 02:35:39 --> Loader Class Initialized
INFO - 2023-05-26 02:35:39 --> Loader Class Initialized
INFO - 2023-05-26 02:35:39 --> Controller Class Initialized
INFO - 2023-05-26 02:35:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:35:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 02:35:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:35:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:35:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:35:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:35:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:35:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:35:39 --> Model "Login_model" initialized
INFO - 2023-05-26 02:35:39 --> Final output sent to browser
DEBUG - 2023-05-26 02:35:39 --> Total execution time: 0.1790
INFO - 2023-05-26 02:35:39 --> Config Class Initialized
INFO - 2023-05-26 02:35:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:35:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:35:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:35:39 --> URI Class Initialized
INFO - 2023-05-26 02:35:39 --> Router Class Initialized
INFO - 2023-05-26 02:35:39 --> Output Class Initialized
INFO - 2023-05-26 02:35:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:35:39 --> Input Class Initialized
INFO - 2023-05-26 02:35:39 --> Language Class Initialized
INFO - 2023-05-26 02:35:39 --> Loader Class Initialized
INFO - 2023-05-26 02:35:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:35:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:35:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:35:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:35:39 --> Final output sent to browser
DEBUG - 2023-05-26 02:35:39 --> Total execution time: 0.2102
INFO - 2023-05-26 02:35:48 --> Final output sent to browser
DEBUG - 2023-05-26 02:35:48 --> Total execution time: 9.3677
INFO - 2023-05-26 02:35:48 --> Config Class Initialized
INFO - 2023-05-26 02:35:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:35:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:35:48 --> Utf8 Class Initialized
INFO - 2023-05-26 02:35:48 --> URI Class Initialized
INFO - 2023-05-26 02:35:49 --> Router Class Initialized
INFO - 2023-05-26 02:35:49 --> Output Class Initialized
INFO - 2023-05-26 02:35:49 --> Security Class Initialized
DEBUG - 2023-05-26 02:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:35:49 --> Input Class Initialized
INFO - 2023-05-26 02:35:49 --> Language Class Initialized
INFO - 2023-05-26 02:35:49 --> Loader Class Initialized
INFO - 2023-05-26 02:35:49 --> Controller Class Initialized
DEBUG - 2023-05-26 02:35:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:35:49 --> Database Driver Class Initialized
INFO - 2023-05-26 02:35:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:35:49 --> Database Driver Class Initialized
INFO - 2023-05-26 02:35:49 --> Model "Login_model" initialized
INFO - 2023-05-26 02:35:59 --> Final output sent to browser
DEBUG - 2023-05-26 02:35:59 --> Total execution time: 10.2407
INFO - 2023-05-26 02:36:39 --> Config Class Initialized
INFO - 2023-05-26 02:36:39 --> Hooks Class Initialized
INFO - 2023-05-26 02:36:39 --> Config Class Initialized
INFO - 2023-05-26 02:36:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:36:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:36:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:36:39 --> URI Class Initialized
INFO - 2023-05-26 02:36:39 --> Router Class Initialized
DEBUG - 2023-05-26 02:36:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:36:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:36:39 --> Output Class Initialized
INFO - 2023-05-26 02:36:39 --> URI Class Initialized
INFO - 2023-05-26 02:36:39 --> Security Class Initialized
INFO - 2023-05-26 02:36:39 --> Router Class Initialized
DEBUG - 2023-05-26 02:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:36:39 --> Input Class Initialized
INFO - 2023-05-26 02:36:39 --> Language Class Initialized
INFO - 2023-05-26 02:36:39 --> Output Class Initialized
INFO - 2023-05-26 02:36:39 --> Security Class Initialized
INFO - 2023-05-26 02:36:39 --> Loader Class Initialized
DEBUG - 2023-05-26 02:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:36:39 --> Input Class Initialized
INFO - 2023-05-26 02:36:39 --> Controller Class Initialized
INFO - 2023-05-26 02:36:39 --> Language Class Initialized
DEBUG - 2023-05-26 02:36:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:36:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:36:39 --> Loader Class Initialized
INFO - 2023-05-26 02:36:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:36:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:36:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:36:39 --> Final output sent to browser
DEBUG - 2023-05-26 02:36:39 --> Total execution time: 0.2314
INFO - 2023-05-26 02:36:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:36:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:36:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:36:39 --> Config Class Initialized
INFO - 2023-05-26 02:36:39 --> Hooks Class Initialized
INFO - 2023-05-26 02:36:39 --> Model "Login_model" initialized
DEBUG - 2023-05-26 02:36:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:36:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:36:39 --> URI Class Initialized
INFO - 2023-05-26 02:36:39 --> Router Class Initialized
INFO - 2023-05-26 02:36:39 --> Output Class Initialized
INFO - 2023-05-26 02:36:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:36:39 --> Input Class Initialized
INFO - 2023-05-26 02:36:39 --> Language Class Initialized
INFO - 2023-05-26 02:36:39 --> Loader Class Initialized
INFO - 2023-05-26 02:36:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:36:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:36:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:36:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:36:40 --> Final output sent to browser
DEBUG - 2023-05-26 02:36:40 --> Total execution time: 0.2235
INFO - 2023-05-26 02:36:49 --> Final output sent to browser
DEBUG - 2023-05-26 02:36:49 --> Total execution time: 10.1842
INFO - 2023-05-26 02:36:49 --> Config Class Initialized
INFO - 2023-05-26 02:36:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:36:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:36:49 --> Utf8 Class Initialized
INFO - 2023-05-26 02:36:49 --> URI Class Initialized
INFO - 2023-05-26 02:36:49 --> Router Class Initialized
INFO - 2023-05-26 02:36:49 --> Output Class Initialized
INFO - 2023-05-26 02:36:49 --> Security Class Initialized
DEBUG - 2023-05-26 02:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:36:49 --> Input Class Initialized
INFO - 2023-05-26 02:36:49 --> Language Class Initialized
INFO - 2023-05-26 02:36:49 --> Loader Class Initialized
INFO - 2023-05-26 02:36:49 --> Controller Class Initialized
DEBUG - 2023-05-26 02:36:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:36:49 --> Database Driver Class Initialized
INFO - 2023-05-26 02:36:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:36:49 --> Database Driver Class Initialized
INFO - 2023-05-26 02:36:50 --> Model "Login_model" initialized
INFO - 2023-05-26 02:36:59 --> Final output sent to browser
DEBUG - 2023-05-26 02:36:59 --> Total execution time: 9.7405
INFO - 2023-05-26 02:37:39 --> Config Class Initialized
INFO - 2023-05-26 02:37:39 --> Config Class Initialized
INFO - 2023-05-26 02:37:39 --> Hooks Class Initialized
INFO - 2023-05-26 02:37:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:37:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 02:37:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:37:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:39 --> URI Class Initialized
INFO - 2023-05-26 02:37:39 --> URI Class Initialized
INFO - 2023-05-26 02:37:39 --> Router Class Initialized
INFO - 2023-05-26 02:37:39 --> Router Class Initialized
INFO - 2023-05-26 02:37:39 --> Output Class Initialized
INFO - 2023-05-26 02:37:39 --> Output Class Initialized
INFO - 2023-05-26 02:37:39 --> Security Class Initialized
INFO - 2023-05-26 02:37:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 02:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:37:39 --> Input Class Initialized
INFO - 2023-05-26 02:37:39 --> Input Class Initialized
INFO - 2023-05-26 02:37:39 --> Language Class Initialized
INFO - 2023-05-26 02:37:39 --> Language Class Initialized
INFO - 2023-05-26 02:37:39 --> Loader Class Initialized
INFO - 2023-05-26 02:37:39 --> Loader Class Initialized
INFO - 2023-05-26 02:37:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:37:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:37:39 --> Controller Class Initialized
DEBUG - 2023-05-26 02:37:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:37:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:37:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:37:39 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:39 --> Final output sent to browser
INFO - 2023-05-26 02:37:39 --> Model "Login_model" initialized
DEBUG - 2023-05-26 02:37:39 --> Total execution time: 0.2388
INFO - 2023-05-26 02:37:39 --> Config Class Initialized
INFO - 2023-05-26 02:37:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:37:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:37:39 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:39 --> URI Class Initialized
INFO - 2023-05-26 02:37:39 --> Router Class Initialized
INFO - 2023-05-26 02:37:39 --> Output Class Initialized
INFO - 2023-05-26 02:37:39 --> Security Class Initialized
DEBUG - 2023-05-26 02:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:37:39 --> Input Class Initialized
INFO - 2023-05-26 02:37:39 --> Language Class Initialized
INFO - 2023-05-26 02:37:39 --> Loader Class Initialized
INFO - 2023-05-26 02:37:40 --> Controller Class Initialized
DEBUG - 2023-05-26 02:37:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:37:40 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:37:40 --> Final output sent to browser
DEBUG - 2023-05-26 02:37:40 --> Total execution time: 0.2768
INFO - 2023-05-26 02:37:48 --> Final output sent to browser
DEBUG - 2023-05-26 02:37:48 --> Total execution time: 8.6675
INFO - 2023-05-26 02:37:48 --> Config Class Initialized
INFO - 2023-05-26 02:37:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:37:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:37:48 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:48 --> URI Class Initialized
INFO - 2023-05-26 02:37:48 --> Router Class Initialized
INFO - 2023-05-26 02:37:48 --> Output Class Initialized
INFO - 2023-05-26 02:37:48 --> Security Class Initialized
DEBUG - 2023-05-26 02:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:37:48 --> Input Class Initialized
INFO - 2023-05-26 02:37:48 --> Language Class Initialized
INFO - 2023-05-26 02:37:48 --> Loader Class Initialized
INFO - 2023-05-26 02:37:48 --> Controller Class Initialized
DEBUG - 2023-05-26 02:37:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:37:48 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:37:48 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:48 --> Model "Login_model" initialized
INFO - 2023-05-26 02:37:54 --> Config Class Initialized
INFO - 2023-05-26 02:37:54 --> Config Class Initialized
INFO - 2023-05-26 02:37:54 --> Hooks Class Initialized
INFO - 2023-05-26 02:37:54 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:37:54 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 02:37:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:37:54 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:54 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:54 --> URI Class Initialized
INFO - 2023-05-26 02:37:54 --> URI Class Initialized
INFO - 2023-05-26 02:37:54 --> Router Class Initialized
INFO - 2023-05-26 02:37:54 --> Router Class Initialized
INFO - 2023-05-26 02:37:54 --> Output Class Initialized
INFO - 2023-05-26 02:37:54 --> Output Class Initialized
INFO - 2023-05-26 02:37:54 --> Security Class Initialized
INFO - 2023-05-26 02:37:54 --> Security Class Initialized
DEBUG - 2023-05-26 02:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 02:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:37:54 --> Input Class Initialized
INFO - 2023-05-26 02:37:54 --> Input Class Initialized
INFO - 2023-05-26 02:37:54 --> Language Class Initialized
INFO - 2023-05-26 02:37:54 --> Language Class Initialized
INFO - 2023-05-26 02:37:54 --> Loader Class Initialized
INFO - 2023-05-26 02:37:54 --> Controller Class Initialized
INFO - 2023-05-26 02:37:54 --> Loader Class Initialized
DEBUG - 2023-05-26 02:37:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:37:54 --> Controller Class Initialized
DEBUG - 2023-05-26 02:37:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:37:54 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:37:54 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:54 --> Final output sent to browser
DEBUG - 2023-05-26 02:37:54 --> Total execution time: 0.2473
INFO - 2023-05-26 02:37:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:37:54 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:54 --> Model "Login_model" initialized
INFO - 2023-05-26 02:37:54 --> Config Class Initialized
INFO - 2023-05-26 02:37:54 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:37:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:37:54 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:54 --> URI Class Initialized
INFO - 2023-05-26 02:37:54 --> Router Class Initialized
INFO - 2023-05-26 02:37:54 --> Output Class Initialized
INFO - 2023-05-26 02:37:54 --> Security Class Initialized
DEBUG - 2023-05-26 02:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:37:54 --> Input Class Initialized
INFO - 2023-05-26 02:37:54 --> Language Class Initialized
INFO - 2023-05-26 02:37:54 --> Loader Class Initialized
INFO - 2023-05-26 02:37:54 --> Config Class Initialized
INFO - 2023-05-26 02:37:54 --> Hooks Class Initialized
INFO - 2023-05-26 02:37:54 --> Controller Class Initialized
DEBUG - 2023-05-26 02:37:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 02:37:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:37:54 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:54 --> URI Class Initialized
INFO - 2023-05-26 02:37:54 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:37:54 --> Router Class Initialized
INFO - 2023-05-26 02:37:54 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:54 --> Output Class Initialized
INFO - 2023-05-26 02:37:54 --> Model "Login_model" initialized
INFO - 2023-05-26 02:37:54 --> Security Class Initialized
DEBUG - 2023-05-26 02:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:37:54 --> Input Class Initialized
INFO - 2023-05-26 02:37:54 --> Language Class Initialized
INFO - 2023-05-26 02:37:54 --> Loader Class Initialized
INFO - 2023-05-26 02:37:54 --> Controller Class Initialized
DEBUG - 2023-05-26 02:37:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:37:55 --> Final output sent to browser
DEBUG - 2023-05-26 02:37:55 --> Total execution time: 6.7494
INFO - 2023-05-26 02:37:55 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:55 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:37:55 --> Final output sent to browser
DEBUG - 2023-05-26 02:37:55 --> Total execution time: 0.4218
INFO - 2023-05-26 02:37:56 --> Config Class Initialized
INFO - 2023-05-26 02:37:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:37:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:37:56 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:56 --> URI Class Initialized
INFO - 2023-05-26 02:37:56 --> Router Class Initialized
INFO - 2023-05-26 02:37:56 --> Output Class Initialized
INFO - 2023-05-26 02:37:56 --> Security Class Initialized
DEBUG - 2023-05-26 02:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:37:56 --> Input Class Initialized
INFO - 2023-05-26 02:37:56 --> Language Class Initialized
INFO - 2023-05-26 02:37:56 --> Loader Class Initialized
INFO - 2023-05-26 02:37:56 --> Controller Class Initialized
DEBUG - 2023-05-26 02:37:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:37:56 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:56 --> Model "Login_model" initialized
INFO - 2023-05-26 02:37:56 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:37:56 --> Final output sent to browser
DEBUG - 2023-05-26 02:37:56 --> Total execution time: 0.3070
INFO - 2023-05-26 02:37:56 --> Config Class Initialized
INFO - 2023-05-26 02:37:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:37:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:37:56 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:56 --> URI Class Initialized
INFO - 2023-05-26 02:37:56 --> Router Class Initialized
INFO - 2023-05-26 02:37:56 --> Output Class Initialized
INFO - 2023-05-26 02:37:56 --> Security Class Initialized
DEBUG - 2023-05-26 02:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:37:56 --> Input Class Initialized
INFO - 2023-05-26 02:37:56 --> Language Class Initialized
INFO - 2023-05-26 02:37:56 --> Loader Class Initialized
INFO - 2023-05-26 02:37:56 --> Controller Class Initialized
DEBUG - 2023-05-26 02:37:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:37:57 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:57 --> Model "Login_model" initialized
INFO - 2023-05-26 02:37:57 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:37:57 --> Final output sent to browser
DEBUG - 2023-05-26 02:37:57 --> Total execution time: 0.4579
INFO - 2023-05-26 02:37:57 --> Config Class Initialized
INFO - 2023-05-26 02:37:57 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:37:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:37:57 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:57 --> URI Class Initialized
INFO - 2023-05-26 02:37:57 --> Router Class Initialized
INFO - 2023-05-26 02:37:57 --> Output Class Initialized
INFO - 2023-05-26 02:37:57 --> Config Class Initialized
INFO - 2023-05-26 02:37:57 --> Hooks Class Initialized
INFO - 2023-05-26 02:37:57 --> Security Class Initialized
DEBUG - 2023-05-26 02:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:37:57 --> Input Class Initialized
INFO - 2023-05-26 02:37:57 --> Language Class Initialized
DEBUG - 2023-05-26 02:37:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:37:57 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:57 --> URI Class Initialized
INFO - 2023-05-26 02:37:57 --> Loader Class Initialized
INFO - 2023-05-26 02:37:57 --> Router Class Initialized
INFO - 2023-05-26 02:37:57 --> Controller Class Initialized
INFO - 2023-05-26 02:37:57 --> Output Class Initialized
DEBUG - 2023-05-26 02:37:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:37:57 --> Final output sent to browser
DEBUG - 2023-05-26 02:37:57 --> Total execution time: 0.1768
INFO - 2023-05-26 02:37:57 --> Security Class Initialized
DEBUG - 2023-05-26 02:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:37:57 --> Input Class Initialized
INFO - 2023-05-26 02:37:57 --> Language Class Initialized
INFO - 2023-05-26 02:37:57 --> Loader Class Initialized
INFO - 2023-05-26 02:37:57 --> Config Class Initialized
INFO - 2023-05-26 02:37:57 --> Hooks Class Initialized
INFO - 2023-05-26 02:37:57 --> Controller Class Initialized
DEBUG - 2023-05-26 02:37:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 02:37:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:37:57 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:57 --> URI Class Initialized
INFO - 2023-05-26 02:37:57 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:57 --> Router Class Initialized
INFO - 2023-05-26 02:37:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:37:57 --> Output Class Initialized
INFO - 2023-05-26 02:37:57 --> Security Class Initialized
INFO - 2023-05-26 02:37:57 --> Final output sent to browser
DEBUG - 2023-05-26 02:37:57 --> Total execution time: 0.2659
DEBUG - 2023-05-26 02:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:37:57 --> Input Class Initialized
INFO - 2023-05-26 02:37:57 --> Language Class Initialized
INFO - 2023-05-26 02:37:57 --> Loader Class Initialized
INFO - 2023-05-26 02:37:57 --> Config Class Initialized
INFO - 2023-05-26 02:37:57 --> Controller Class Initialized
INFO - 2023-05-26 02:37:57 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:37:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 02:37:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:37:57 --> Utf8 Class Initialized
INFO - 2023-05-26 02:37:57 --> URI Class Initialized
INFO - 2023-05-26 02:37:57 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:57 --> Model "Login_model" initialized
INFO - 2023-05-26 02:37:57 --> Router Class Initialized
INFO - 2023-05-26 02:37:57 --> Output Class Initialized
INFO - 2023-05-26 02:37:57 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:57 --> Security Class Initialized
INFO - 2023-05-26 02:37:57 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 02:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:37:57 --> Final output sent to browser
INFO - 2023-05-26 02:37:57 --> Input Class Initialized
DEBUG - 2023-05-26 02:37:57 --> Total execution time: 0.3054
INFO - 2023-05-26 02:37:57 --> Language Class Initialized
INFO - 2023-05-26 02:37:57 --> Loader Class Initialized
INFO - 2023-05-26 02:37:57 --> Controller Class Initialized
DEBUG - 2023-05-26 02:37:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:37:57 --> Database Driver Class Initialized
INFO - 2023-05-26 02:37:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:37:57 --> Final output sent to browser
DEBUG - 2023-05-26 02:37:57 --> Total execution time: 0.2648
INFO - 2023-05-26 02:38:02 --> Final output sent to browser
DEBUG - 2023-05-26 02:38:02 --> Total execution time: 7.9977
INFO - 2023-05-26 02:38:02 --> Config Class Initialized
INFO - 2023-05-26 02:38:02 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:38:02 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:38:02 --> Utf8 Class Initialized
INFO - 2023-05-26 02:38:02 --> URI Class Initialized
INFO - 2023-05-26 02:38:02 --> Router Class Initialized
INFO - 2023-05-26 02:38:02 --> Output Class Initialized
INFO - 2023-05-26 02:38:02 --> Security Class Initialized
DEBUG - 2023-05-26 02:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:38:02 --> Input Class Initialized
INFO - 2023-05-26 02:38:02 --> Language Class Initialized
INFO - 2023-05-26 02:38:02 --> Loader Class Initialized
INFO - 2023-05-26 02:38:02 --> Controller Class Initialized
DEBUG - 2023-05-26 02:38:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:38:02 --> Database Driver Class Initialized
INFO - 2023-05-26 02:38:02 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:38:02 --> Database Driver Class Initialized
INFO - 2023-05-26 02:38:02 --> Model "Login_model" initialized
INFO - 2023-05-26 02:38:02 --> Final output sent to browser
DEBUG - 2023-05-26 02:38:02 --> Total execution time: 8.1790
INFO - 2023-05-26 02:38:06 --> Final output sent to browser
DEBUG - 2023-05-26 02:38:06 --> Total execution time: 3.8908
INFO - 2023-05-26 02:38:06 --> Config Class Initialized
INFO - 2023-05-26 02:38:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 02:38:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 02:38:06 --> Utf8 Class Initialized
INFO - 2023-05-26 02:38:06 --> URI Class Initialized
INFO - 2023-05-26 02:38:06 --> Router Class Initialized
INFO - 2023-05-26 02:38:06 --> Output Class Initialized
INFO - 2023-05-26 02:38:06 --> Security Class Initialized
DEBUG - 2023-05-26 02:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 02:38:06 --> Input Class Initialized
INFO - 2023-05-26 02:38:06 --> Language Class Initialized
INFO - 2023-05-26 02:38:06 --> Loader Class Initialized
INFO - 2023-05-26 02:38:06 --> Controller Class Initialized
DEBUG - 2023-05-26 02:38:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 02:38:06 --> Database Driver Class Initialized
INFO - 2023-05-26 02:38:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 02:38:06 --> Database Driver Class Initialized
INFO - 2023-05-26 02:38:06 --> Model "Login_model" initialized
INFO - 2023-05-26 02:38:13 --> Final output sent to browser
DEBUG - 2023-05-26 02:38:14 --> Total execution time: 7.7992
INFO - 2023-05-26 03:14:24 --> Config Class Initialized
INFO - 2023-05-26 03:14:24 --> Config Class Initialized
INFO - 2023-05-26 03:14:24 --> Hooks Class Initialized
INFO - 2023-05-26 03:14:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:14:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:14:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:14:24 --> Utf8 Class Initialized
INFO - 2023-05-26 03:14:24 --> Utf8 Class Initialized
INFO - 2023-05-26 03:14:24 --> URI Class Initialized
INFO - 2023-05-26 03:14:24 --> URI Class Initialized
INFO - 2023-05-26 03:14:24 --> Router Class Initialized
INFO - 2023-05-26 03:14:24 --> Router Class Initialized
INFO - 2023-05-26 03:14:24 --> Output Class Initialized
INFO - 2023-05-26 03:14:24 --> Output Class Initialized
INFO - 2023-05-26 03:14:24 --> Security Class Initialized
INFO - 2023-05-26 03:14:24 --> Security Class Initialized
DEBUG - 2023-05-26 03:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:14:24 --> Input Class Initialized
INFO - 2023-05-26 03:14:24 --> Input Class Initialized
INFO - 2023-05-26 03:14:24 --> Language Class Initialized
INFO - 2023-05-26 03:14:24 --> Language Class Initialized
INFO - 2023-05-26 03:14:24 --> Loader Class Initialized
INFO - 2023-05-26 03:14:24 --> Loader Class Initialized
INFO - 2023-05-26 03:14:24 --> Controller Class Initialized
INFO - 2023-05-26 03:14:24 --> Controller Class Initialized
DEBUG - 2023-05-26 03:14:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 03:14:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:14:24 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:24 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:14:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:14:25 --> Final output sent to browser
DEBUG - 2023-05-26 03:14:25 --> Total execution time: 0.2730
INFO - 2023-05-26 03:14:25 --> Final output sent to browser
DEBUG - 2023-05-26 03:14:25 --> Total execution time: 0.3058
INFO - 2023-05-26 03:14:25 --> Config Class Initialized
INFO - 2023-05-26 03:14:25 --> Config Class Initialized
INFO - 2023-05-26 03:14:25 --> Hooks Class Initialized
INFO - 2023-05-26 03:14:25 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:14:25 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:14:25 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:14:25 --> Utf8 Class Initialized
INFO - 2023-05-26 03:14:25 --> Utf8 Class Initialized
INFO - 2023-05-26 03:14:25 --> URI Class Initialized
INFO - 2023-05-26 03:14:25 --> URI Class Initialized
INFO - 2023-05-26 03:14:25 --> Router Class Initialized
INFO - 2023-05-26 03:14:25 --> Router Class Initialized
INFO - 2023-05-26 03:14:25 --> Output Class Initialized
INFO - 2023-05-26 03:14:25 --> Output Class Initialized
INFO - 2023-05-26 03:14:25 --> Security Class Initialized
INFO - 2023-05-26 03:14:25 --> Security Class Initialized
DEBUG - 2023-05-26 03:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:14:25 --> Input Class Initialized
INFO - 2023-05-26 03:14:25 --> Input Class Initialized
INFO - 2023-05-26 03:14:25 --> Language Class Initialized
INFO - 2023-05-26 03:14:25 --> Language Class Initialized
INFO - 2023-05-26 03:14:25 --> Loader Class Initialized
INFO - 2023-05-26 03:14:25 --> Loader Class Initialized
INFO - 2023-05-26 03:14:25 --> Controller Class Initialized
DEBUG - 2023-05-26 03:14:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:14:25 --> Controller Class Initialized
DEBUG - 2023-05-26 03:14:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:14:25 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:14:25 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:14:25 --> Final output sent to browser
DEBUG - 2023-05-26 03:14:25 --> Total execution time: 0.3475
INFO - 2023-05-26 03:14:25 --> Final output sent to browser
DEBUG - 2023-05-26 03:14:25 --> Total execution time: 0.5631
INFO - 2023-05-26 03:14:26 --> Config Class Initialized
INFO - 2023-05-26 03:14:26 --> Config Class Initialized
INFO - 2023-05-26 03:14:26 --> Hooks Class Initialized
INFO - 2023-05-26 03:14:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:14:26 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:14:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:14:26 --> Utf8 Class Initialized
INFO - 2023-05-26 03:14:26 --> Utf8 Class Initialized
INFO - 2023-05-26 03:14:26 --> URI Class Initialized
INFO - 2023-05-26 03:14:26 --> URI Class Initialized
INFO - 2023-05-26 03:14:26 --> Router Class Initialized
INFO - 2023-05-26 03:14:26 --> Router Class Initialized
INFO - 2023-05-26 03:14:26 --> Output Class Initialized
INFO - 2023-05-26 03:14:26 --> Output Class Initialized
INFO - 2023-05-26 03:14:26 --> Security Class Initialized
INFO - 2023-05-26 03:14:26 --> Security Class Initialized
DEBUG - 2023-05-26 03:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:14:26 --> Input Class Initialized
INFO - 2023-05-26 03:14:26 --> Input Class Initialized
INFO - 2023-05-26 03:14:26 --> Language Class Initialized
INFO - 2023-05-26 03:14:26 --> Language Class Initialized
INFO - 2023-05-26 03:14:26 --> Loader Class Initialized
INFO - 2023-05-26 03:14:26 --> Loader Class Initialized
INFO - 2023-05-26 03:14:26 --> Controller Class Initialized
DEBUG - 2023-05-26 03:14:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:14:26 --> Controller Class Initialized
INFO - 2023-05-26 03:14:26 --> Final output sent to browser
DEBUG - 2023-05-26 03:14:26 --> Total execution time: 0.1471
DEBUG - 2023-05-26 03:14:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:14:26 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:14:26 --> Config Class Initialized
INFO - 2023-05-26 03:14:26 --> Hooks Class Initialized
INFO - 2023-05-26 03:14:26 --> Final output sent to browser
DEBUG - 2023-05-26 03:14:26 --> Total execution time: 0.2188
DEBUG - 2023-05-26 03:14:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:14:26 --> Utf8 Class Initialized
INFO - 2023-05-26 03:14:26 --> URI Class Initialized
INFO - 2023-05-26 03:14:26 --> Router Class Initialized
INFO - 2023-05-26 03:14:26 --> Config Class Initialized
INFO - 2023-05-26 03:14:26 --> Hooks Class Initialized
INFO - 2023-05-26 03:14:26 --> Output Class Initialized
INFO - 2023-05-26 03:14:26 --> Security Class Initialized
DEBUG - 2023-05-26 03:14:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:14:26 --> Utf8 Class Initialized
DEBUG - 2023-05-26 03:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:14:26 --> Input Class Initialized
INFO - 2023-05-26 03:14:26 --> URI Class Initialized
INFO - 2023-05-26 03:14:26 --> Language Class Initialized
INFO - 2023-05-26 03:14:26 --> Router Class Initialized
INFO - 2023-05-26 03:14:26 --> Output Class Initialized
INFO - 2023-05-26 03:14:26 --> Loader Class Initialized
INFO - 2023-05-26 03:14:26 --> Security Class Initialized
INFO - 2023-05-26 03:14:26 --> Controller Class Initialized
DEBUG - 2023-05-26 03:14:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 03:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:14:26 --> Input Class Initialized
INFO - 2023-05-26 03:14:26 --> Language Class Initialized
INFO - 2023-05-26 03:14:26 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:26 --> Loader Class Initialized
INFO - 2023-05-26 03:14:26 --> Model "Login_model" initialized
INFO - 2023-05-26 03:14:26 --> Controller Class Initialized
DEBUG - 2023-05-26 03:14:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:14:26 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:14:26 --> Final output sent to browser
DEBUG - 2023-05-26 03:14:26 --> Total execution time: 0.3165
INFO - 2023-05-26 03:14:26 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:14:26 --> Final output sent to browser
DEBUG - 2023-05-26 03:14:26 --> Total execution time: 0.2742
INFO - 2023-05-26 03:14:29 --> Config Class Initialized
INFO - 2023-05-26 03:14:29 --> Config Class Initialized
INFO - 2023-05-26 03:14:29 --> Hooks Class Initialized
INFO - 2023-05-26 03:14:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:14:29 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:14:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:14:29 --> Utf8 Class Initialized
INFO - 2023-05-26 03:14:29 --> Utf8 Class Initialized
INFO - 2023-05-26 03:14:29 --> URI Class Initialized
INFO - 2023-05-26 03:14:29 --> URI Class Initialized
INFO - 2023-05-26 03:14:30 --> Router Class Initialized
INFO - 2023-05-26 03:14:30 --> Router Class Initialized
INFO - 2023-05-26 03:14:30 --> Output Class Initialized
INFO - 2023-05-26 03:14:30 --> Output Class Initialized
INFO - 2023-05-26 03:14:30 --> Security Class Initialized
INFO - 2023-05-26 03:14:30 --> Security Class Initialized
DEBUG - 2023-05-26 03:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:14:30 --> Input Class Initialized
INFO - 2023-05-26 03:14:30 --> Input Class Initialized
INFO - 2023-05-26 03:14:30 --> Language Class Initialized
INFO - 2023-05-26 03:14:30 --> Language Class Initialized
INFO - 2023-05-26 03:14:30 --> Loader Class Initialized
INFO - 2023-05-26 03:14:30 --> Loader Class Initialized
INFO - 2023-05-26 03:14:30 --> Controller Class Initialized
DEBUG - 2023-05-26 03:14:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:14:30 --> Controller Class Initialized
DEBUG - 2023-05-26 03:14:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:14:30 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:30 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:14:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:14:30 --> Final output sent to browser
DEBUG - 2023-05-26 03:14:30 --> Total execution time: 0.3640
INFO - 2023-05-26 03:14:30 --> Config Class Initialized
INFO - 2023-05-26 03:14:30 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:14:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:14:30 --> Utf8 Class Initialized
INFO - 2023-05-26 03:14:30 --> URI Class Initialized
INFO - 2023-05-26 03:14:30 --> Router Class Initialized
INFO - 2023-05-26 03:14:30 --> Output Class Initialized
INFO - 2023-05-26 03:14:30 --> Security Class Initialized
DEBUG - 2023-05-26 03:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:14:30 --> Input Class Initialized
INFO - 2023-05-26 03:14:30 --> Language Class Initialized
INFO - 2023-05-26 03:14:30 --> Loader Class Initialized
INFO - 2023-05-26 03:14:30 --> Controller Class Initialized
DEBUG - 2023-05-26 03:14:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:14:30 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:14:30 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:30 --> Final output sent to browser
DEBUG - 2023-05-26 03:14:30 --> Total execution time: 0.2544
INFO - 2023-05-26 03:14:30 --> Model "Login_model" initialized
INFO - 2023-05-26 03:14:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:14:31 --> Total execution time: 1.1220
INFO - 2023-05-26 03:14:31 --> Config Class Initialized
INFO - 2023-05-26 03:14:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:14:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:14:31 --> Utf8 Class Initialized
INFO - 2023-05-26 03:14:31 --> URI Class Initialized
INFO - 2023-05-26 03:14:31 --> Router Class Initialized
INFO - 2023-05-26 03:14:31 --> Output Class Initialized
INFO - 2023-05-26 03:14:31 --> Security Class Initialized
DEBUG - 2023-05-26 03:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:14:31 --> Input Class Initialized
INFO - 2023-05-26 03:14:31 --> Language Class Initialized
INFO - 2023-05-26 03:14:31 --> Loader Class Initialized
INFO - 2023-05-26 03:14:31 --> Controller Class Initialized
DEBUG - 2023-05-26 03:14:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:14:31 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:14:31 --> Database Driver Class Initialized
INFO - 2023-05-26 03:14:31 --> Model "Login_model" initialized
INFO - 2023-05-26 03:14:31 --> Final output sent to browser
DEBUG - 2023-05-26 03:14:31 --> Total execution time: 0.4435
INFO - 2023-05-26 03:17:26 --> Config Class Initialized
INFO - 2023-05-26 03:17:26 --> Config Class Initialized
INFO - 2023-05-26 03:17:26 --> Hooks Class Initialized
INFO - 2023-05-26 03:17:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:26 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:17:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:26 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:26 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:26 --> URI Class Initialized
INFO - 2023-05-26 03:17:26 --> URI Class Initialized
INFO - 2023-05-26 03:17:26 --> Router Class Initialized
INFO - 2023-05-26 03:17:26 --> Router Class Initialized
INFO - 2023-05-26 03:17:26 --> Output Class Initialized
INFO - 2023-05-26 03:17:26 --> Output Class Initialized
INFO - 2023-05-26 03:17:26 --> Security Class Initialized
INFO - 2023-05-26 03:17:26 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:26 --> Input Class Initialized
INFO - 2023-05-26 03:17:26 --> Input Class Initialized
INFO - 2023-05-26 03:17:26 --> Language Class Initialized
INFO - 2023-05-26 03:17:26 --> Language Class Initialized
INFO - 2023-05-26 03:17:26 --> Loader Class Initialized
INFO - 2023-05-26 03:17:26 --> Loader Class Initialized
INFO - 2023-05-26 03:17:26 --> Controller Class Initialized
INFO - 2023-05-26 03:17:26 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 03:17:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:17:26 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:26 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:26 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:26 --> Total execution time: 0.2248
INFO - 2023-05-26 03:17:26 --> Config Class Initialized
INFO - 2023-05-26 03:17:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:26 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:26 --> URI Class Initialized
INFO - 2023-05-26 03:17:26 --> Router Class Initialized
INFO - 2023-05-26 03:17:26 --> Output Class Initialized
INFO - 2023-05-26 03:17:26 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:26 --> Input Class Initialized
INFO - 2023-05-26 03:17:26 --> Language Class Initialized
INFO - 2023-05-26 03:17:26 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:26 --> Total execution time: 0.4577
INFO - 2023-05-26 03:17:26 --> Loader Class Initialized
INFO - 2023-05-26 03:17:26 --> Config Class Initialized
INFO - 2023-05-26 03:17:26 --> Controller Class Initialized
INFO - 2023-05-26 03:17:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 03:17:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:26 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:26 --> URI Class Initialized
INFO - 2023-05-26 03:17:26 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:26 --> Router Class Initialized
INFO - 2023-05-26 03:17:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:26 --> Output Class Initialized
INFO - 2023-05-26 03:17:26 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:26 --> Input Class Initialized
INFO - 2023-05-26 03:17:26 --> Language Class Initialized
INFO - 2023-05-26 03:17:26 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:26 --> Total execution time: 0.3610
INFO - 2023-05-26 03:17:27 --> Loader Class Initialized
INFO - 2023-05-26 03:17:27 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:17:27 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:27 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:27 --> Total execution time: 0.4892
INFO - 2023-05-26 03:17:29 --> Config Class Initialized
INFO - 2023-05-26 03:17:29 --> Config Class Initialized
INFO - 2023-05-26 03:17:29 --> Hooks Class Initialized
INFO - 2023-05-26 03:17:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:29 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:29 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:29 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:29 --> URI Class Initialized
INFO - 2023-05-26 03:17:29 --> URI Class Initialized
INFO - 2023-05-26 03:17:29 --> Router Class Initialized
INFO - 2023-05-26 03:17:29 --> Router Class Initialized
INFO - 2023-05-26 03:17:29 --> Output Class Initialized
INFO - 2023-05-26 03:17:29 --> Output Class Initialized
INFO - 2023-05-26 03:17:29 --> Security Class Initialized
INFO - 2023-05-26 03:17:29 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:29 --> Input Class Initialized
INFO - 2023-05-26 03:17:29 --> Input Class Initialized
INFO - 2023-05-26 03:17:29 --> Language Class Initialized
INFO - 2023-05-26 03:17:29 --> Language Class Initialized
INFO - 2023-05-26 03:17:29 --> Loader Class Initialized
INFO - 2023-05-26 03:17:29 --> Controller Class Initialized
INFO - 2023-05-26 03:17:29 --> Loader Class Initialized
DEBUG - 2023-05-26 03:17:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:17:29 --> Final output sent to browser
INFO - 2023-05-26 03:17:29 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:29 --> Total execution time: 0.1243
DEBUG - 2023-05-26 03:17:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:17:29 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:29 --> Config Class Initialized
INFO - 2023-05-26 03:17:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:29 --> Hooks Class Initialized
INFO - 2023-05-26 03:17:29 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:29 --> Total execution time: 0.1874
DEBUG - 2023-05-26 03:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:29 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:29 --> URI Class Initialized
INFO - 2023-05-26 03:17:29 --> Router Class Initialized
INFO - 2023-05-26 03:17:29 --> Config Class Initialized
INFO - 2023-05-26 03:17:29 --> Hooks Class Initialized
INFO - 2023-05-26 03:17:29 --> Output Class Initialized
INFO - 2023-05-26 03:17:29 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:29 --> Utf8 Class Initialized
DEBUG - 2023-05-26 03:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:29 --> Input Class Initialized
INFO - 2023-05-26 03:17:29 --> URI Class Initialized
INFO - 2023-05-26 03:17:29 --> Language Class Initialized
INFO - 2023-05-26 03:17:29 --> Router Class Initialized
INFO - 2023-05-26 03:17:29 --> Loader Class Initialized
INFO - 2023-05-26 03:17:29 --> Output Class Initialized
INFO - 2023-05-26 03:17:29 --> Security Class Initialized
INFO - 2023-05-26 03:17:29 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 03:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:29 --> Input Class Initialized
INFO - 2023-05-26 03:17:29 --> Language Class Initialized
INFO - 2023-05-26 03:17:29 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:30 --> Loader Class Initialized
INFO - 2023-05-26 03:17:30 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:17:30 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:30 --> Model "Login_model" initialized
INFO - 2023-05-26 03:17:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:30 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:30 --> Total execution time: 0.2435
INFO - 2023-05-26 03:17:30 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:30 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:30 --> Total execution time: 0.3584
INFO - 2023-05-26 03:17:33 --> Config Class Initialized
INFO - 2023-05-26 03:17:33 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:33 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:33 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:33 --> URI Class Initialized
INFO - 2023-05-26 03:17:33 --> Router Class Initialized
INFO - 2023-05-26 03:17:33 --> Output Class Initialized
INFO - 2023-05-26 03:17:33 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:33 --> Input Class Initialized
INFO - 2023-05-26 03:17:33 --> Language Class Initialized
INFO - 2023-05-26 03:17:33 --> Loader Class Initialized
INFO - 2023-05-26 03:17:33 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:17:33 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:33 --> Model "Login_model" initialized
INFO - 2023-05-26 03:17:33 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:34 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:34 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:34 --> Total execution time: 0.2432
INFO - 2023-05-26 03:17:34 --> Config Class Initialized
INFO - 2023-05-26 03:17:34 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:34 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:34 --> URI Class Initialized
INFO - 2023-05-26 03:17:34 --> Router Class Initialized
INFO - 2023-05-26 03:17:34 --> Output Class Initialized
INFO - 2023-05-26 03:17:34 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:34 --> Input Class Initialized
INFO - 2023-05-26 03:17:34 --> Language Class Initialized
INFO - 2023-05-26 03:17:34 --> Loader Class Initialized
INFO - 2023-05-26 03:17:34 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:17:34 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:34 --> Model "Login_model" initialized
INFO - 2023-05-26 03:17:34 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:34 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:34 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:34 --> Total execution time: 0.2616
INFO - 2023-05-26 03:17:34 --> Config Class Initialized
INFO - 2023-05-26 03:17:34 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:34 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:34 --> URI Class Initialized
INFO - 2023-05-26 03:17:34 --> Router Class Initialized
INFO - 2023-05-26 03:17:34 --> Output Class Initialized
INFO - 2023-05-26 03:17:34 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:34 --> Input Class Initialized
INFO - 2023-05-26 03:17:34 --> Language Class Initialized
INFO - 2023-05-26 03:17:34 --> Loader Class Initialized
INFO - 2023-05-26 03:17:34 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:17:34 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:34 --> Total execution time: 0.1776
INFO - 2023-05-26 03:17:34 --> Config Class Initialized
INFO - 2023-05-26 03:17:34 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:17:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:17:34 --> Utf8 Class Initialized
INFO - 2023-05-26 03:17:34 --> URI Class Initialized
INFO - 2023-05-26 03:17:34 --> Router Class Initialized
INFO - 2023-05-26 03:17:34 --> Output Class Initialized
INFO - 2023-05-26 03:17:34 --> Security Class Initialized
DEBUG - 2023-05-26 03:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:17:34 --> Input Class Initialized
INFO - 2023-05-26 03:17:34 --> Language Class Initialized
INFO - 2023-05-26 03:17:34 --> Loader Class Initialized
INFO - 2023-05-26 03:17:34 --> Controller Class Initialized
DEBUG - 2023-05-26 03:17:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:17:34 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:34 --> Model "Login_model" initialized
INFO - 2023-05-26 03:17:34 --> Database Driver Class Initialized
INFO - 2023-05-26 03:17:34 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:17:34 --> Final output sent to browser
DEBUG - 2023-05-26 03:17:34 --> Total execution time: 0.2596
INFO - 2023-05-26 03:23:50 --> Config Class Initialized
INFO - 2023-05-26 03:23:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:23:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:50 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:50 --> URI Class Initialized
INFO - 2023-05-26 03:23:50 --> Router Class Initialized
INFO - 2023-05-26 03:23:50 --> Output Class Initialized
INFO - 2023-05-26 03:23:50 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:50 --> Input Class Initialized
INFO - 2023-05-26 03:23:50 --> Language Class Initialized
INFO - 2023-05-26 03:23:50 --> Loader Class Initialized
INFO - 2023-05-26 03:23:50 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:23:50 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:50 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:50 --> Total execution time: 0.2590
INFO - 2023-05-26 03:23:50 --> Config Class Initialized
INFO - 2023-05-26 03:23:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:23:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:50 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:50 --> URI Class Initialized
INFO - 2023-05-26 03:23:50 --> Router Class Initialized
INFO - 2023-05-26 03:23:50 --> Output Class Initialized
INFO - 2023-05-26 03:23:50 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:51 --> Input Class Initialized
INFO - 2023-05-26 03:23:51 --> Language Class Initialized
INFO - 2023-05-26 03:23:51 --> Loader Class Initialized
INFO - 2023-05-26 03:23:51 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:23:51 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:51 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:51 --> Total execution time: 0.2692
INFO - 2023-05-26 03:23:52 --> Config Class Initialized
INFO - 2023-05-26 03:23:52 --> Config Class Initialized
INFO - 2023-05-26 03:23:52 --> Hooks Class Initialized
INFO - 2023-05-26 03:23:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:23:52 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:23:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:52 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:52 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:52 --> URI Class Initialized
INFO - 2023-05-26 03:23:52 --> URI Class Initialized
INFO - 2023-05-26 03:23:52 --> Router Class Initialized
INFO - 2023-05-26 03:23:52 --> Router Class Initialized
INFO - 2023-05-26 03:23:52 --> Output Class Initialized
INFO - 2023-05-26 03:23:52 --> Output Class Initialized
INFO - 2023-05-26 03:23:52 --> Security Class Initialized
INFO - 2023-05-26 03:23:52 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:52 --> Input Class Initialized
INFO - 2023-05-26 03:23:52 --> Input Class Initialized
INFO - 2023-05-26 03:23:52 --> Language Class Initialized
INFO - 2023-05-26 03:23:52 --> Language Class Initialized
INFO - 2023-05-26 03:23:52 --> Loader Class Initialized
INFO - 2023-05-26 03:23:52 --> Loader Class Initialized
INFO - 2023-05-26 03:23:52 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:23:52 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:52 --> Total execution time: 0.1613
INFO - 2023-05-26 03:23:52 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:23:52 --> Config Class Initialized
INFO - 2023-05-26 03:23:52 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:52 --> Hooks Class Initialized
INFO - 2023-05-26 03:23:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:52 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:52 --> Total execution time: 0.2662
DEBUG - 2023-05-26 03:23:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:52 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:52 --> URI Class Initialized
INFO - 2023-05-26 03:23:52 --> Router Class Initialized
INFO - 2023-05-26 03:23:52 --> Output Class Initialized
INFO - 2023-05-26 03:23:52 --> Config Class Initialized
INFO - 2023-05-26 03:23:52 --> Hooks Class Initialized
INFO - 2023-05-26 03:23:52 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:53 --> Input Class Initialized
INFO - 2023-05-26 03:23:53 --> Language Class Initialized
DEBUG - 2023-05-26 03:23:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:53 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:53 --> URI Class Initialized
INFO - 2023-05-26 03:23:53 --> Loader Class Initialized
INFO - 2023-05-26 03:23:53 --> Router Class Initialized
INFO - 2023-05-26 03:23:53 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:23:53 --> Output Class Initialized
INFO - 2023-05-26 03:23:53 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:53 --> Input Class Initialized
INFO - 2023-05-26 03:23:53 --> Language Class Initialized
INFO - 2023-05-26 03:23:53 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:53 --> Loader Class Initialized
INFO - 2023-05-26 03:23:53 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:23:53 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:53 --> Model "Login_model" initialized
INFO - 2023-05-26 03:23:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:53 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:53 --> Total execution time: 0.3211
INFO - 2023-05-26 03:23:53 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:53 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:53 --> Total execution time: 0.4852
INFO - 2023-05-26 03:23:56 --> Config Class Initialized
INFO - 2023-05-26 03:23:56 --> Config Class Initialized
INFO - 2023-05-26 03:23:56 --> Hooks Class Initialized
INFO - 2023-05-26 03:23:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:23:56 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:23:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:56 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:56 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:56 --> URI Class Initialized
INFO - 2023-05-26 03:23:56 --> URI Class Initialized
INFO - 2023-05-26 03:23:56 --> Router Class Initialized
INFO - 2023-05-26 03:23:56 --> Router Class Initialized
INFO - 2023-05-26 03:23:56 --> Output Class Initialized
INFO - 2023-05-26 03:23:56 --> Output Class Initialized
INFO - 2023-05-26 03:23:56 --> Security Class Initialized
INFO - 2023-05-26 03:23:56 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:56 --> Input Class Initialized
INFO - 2023-05-26 03:23:56 --> Input Class Initialized
INFO - 2023-05-26 03:23:56 --> Language Class Initialized
INFO - 2023-05-26 03:23:56 --> Language Class Initialized
INFO - 2023-05-26 03:23:56 --> Loader Class Initialized
INFO - 2023-05-26 03:23:56 --> Controller Class Initialized
INFO - 2023-05-26 03:23:56 --> Loader Class Initialized
DEBUG - 2023-05-26 03:23:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:23:56 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:23:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:56 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:56 --> Total execution time: 0.2016
INFO - 2023-05-26 03:23:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:56 --> Model "Login_model" initialized
INFO - 2023-05-26 03:23:56 --> Config Class Initialized
INFO - 2023-05-26 03:23:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:23:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:56 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:56 --> URI Class Initialized
INFO - 2023-05-26 03:23:56 --> Router Class Initialized
INFO - 2023-05-26 03:23:56 --> Output Class Initialized
INFO - 2023-05-26 03:23:56 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:56 --> Input Class Initialized
INFO - 2023-05-26 03:23:56 --> Language Class Initialized
INFO - 2023-05-26 03:23:56 --> Loader Class Initialized
INFO - 2023-05-26 03:23:56 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:23:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:56 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:56 --> Total execution time: 0.2140
INFO - 2023-05-26 03:23:56 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:56 --> Total execution time: 0.7321
INFO - 2023-05-26 03:23:56 --> Config Class Initialized
INFO - 2023-05-26 03:23:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:23:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:23:56 --> Utf8 Class Initialized
INFO - 2023-05-26 03:23:56 --> URI Class Initialized
INFO - 2023-05-26 03:23:56 --> Router Class Initialized
INFO - 2023-05-26 03:23:56 --> Output Class Initialized
INFO - 2023-05-26 03:23:56 --> Security Class Initialized
DEBUG - 2023-05-26 03:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:23:56 --> Input Class Initialized
INFO - 2023-05-26 03:23:56 --> Language Class Initialized
INFO - 2023-05-26 03:23:56 --> Loader Class Initialized
INFO - 2023-05-26 03:23:56 --> Controller Class Initialized
DEBUG - 2023-05-26 03:23:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:23:56 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:23:57 --> Database Driver Class Initialized
INFO - 2023-05-26 03:23:57 --> Model "Login_model" initialized
INFO - 2023-05-26 03:23:57 --> Final output sent to browser
DEBUG - 2023-05-26 03:23:57 --> Total execution time: 0.8085
INFO - 2023-05-26 03:24:29 --> Config Class Initialized
INFO - 2023-05-26 03:24:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:24:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:24:29 --> Utf8 Class Initialized
INFO - 2023-05-26 03:24:29 --> URI Class Initialized
INFO - 2023-05-26 03:24:29 --> Router Class Initialized
INFO - 2023-05-26 03:24:29 --> Output Class Initialized
INFO - 2023-05-26 03:24:29 --> Security Class Initialized
DEBUG - 2023-05-26 03:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:24:29 --> Input Class Initialized
INFO - 2023-05-26 03:24:29 --> Language Class Initialized
INFO - 2023-05-26 03:24:29 --> Loader Class Initialized
INFO - 2023-05-26 03:24:29 --> Controller Class Initialized
DEBUG - 2023-05-26 03:24:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:24:29 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:24:29 --> Final output sent to browser
DEBUG - 2023-05-26 03:24:29 --> Total execution time: 0.3662
INFO - 2023-05-26 03:24:29 --> Config Class Initialized
INFO - 2023-05-26 03:24:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:24:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:24:29 --> Utf8 Class Initialized
INFO - 2023-05-26 03:24:29 --> URI Class Initialized
INFO - 2023-05-26 03:24:29 --> Router Class Initialized
INFO - 2023-05-26 03:24:29 --> Output Class Initialized
INFO - 2023-05-26 03:24:29 --> Security Class Initialized
DEBUG - 2023-05-26 03:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:24:29 --> Input Class Initialized
INFO - 2023-05-26 03:24:29 --> Language Class Initialized
INFO - 2023-05-26 03:24:29 --> Loader Class Initialized
INFO - 2023-05-26 03:24:29 --> Controller Class Initialized
DEBUG - 2023-05-26 03:24:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:24:29 --> Database Driver Class Initialized
INFO - 2023-05-26 03:24:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:24:30 --> Final output sent to browser
DEBUG - 2023-05-26 03:24:30 --> Total execution time: 0.6617
INFO - 2023-05-26 03:27:23 --> Config Class Initialized
INFO - 2023-05-26 03:27:23 --> Hooks Class Initialized
INFO - 2023-05-26 03:27:23 --> Config Class Initialized
INFO - 2023-05-26 03:27:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:27:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:27:23 --> Utf8 Class Initialized
INFO - 2023-05-26 03:27:23 --> URI Class Initialized
DEBUG - 2023-05-26 03:27:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:27:23 --> Utf8 Class Initialized
INFO - 2023-05-26 03:27:23 --> URI Class Initialized
INFO - 2023-05-26 03:27:23 --> Router Class Initialized
INFO - 2023-05-26 03:27:23 --> Router Class Initialized
INFO - 2023-05-26 03:27:23 --> Output Class Initialized
INFO - 2023-05-26 03:27:23 --> Security Class Initialized
INFO - 2023-05-26 03:27:23 --> Output Class Initialized
INFO - 2023-05-26 03:27:23 --> Security Class Initialized
DEBUG - 2023-05-26 03:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:27:23 --> Input Class Initialized
DEBUG - 2023-05-26 03:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:27:23 --> Language Class Initialized
INFO - 2023-05-26 03:27:23 --> Input Class Initialized
INFO - 2023-05-26 03:27:23 --> Language Class Initialized
INFO - 2023-05-26 03:27:23 --> Loader Class Initialized
INFO - 2023-05-26 03:27:23 --> Loader Class Initialized
INFO - 2023-05-26 03:27:23 --> Controller Class Initialized
INFO - 2023-05-26 03:27:23 --> Controller Class Initialized
DEBUG - 2023-05-26 03:27:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 03:27:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:27:23 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:23 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:27:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:27:24 --> Final output sent to browser
DEBUG - 2023-05-26 03:27:24 --> Total execution time: 0.4880
INFO - 2023-05-26 03:27:24 --> Final output sent to browser
DEBUG - 2023-05-26 03:27:24 --> Total execution time: 0.5057
INFO - 2023-05-26 03:27:24 --> Config Class Initialized
INFO - 2023-05-26 03:27:24 --> Hooks Class Initialized
INFO - 2023-05-26 03:27:24 --> Config Class Initialized
INFO - 2023-05-26 03:27:24 --> Hooks Class Initialized
INFO - 2023-05-26 03:27:24 --> Config Class Initialized
DEBUG - 2023-05-26 03:27:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:27:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:27:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:27:24 --> Utf8 Class Initialized
INFO - 2023-05-26 03:27:24 --> Utf8 Class Initialized
INFO - 2023-05-26 03:27:24 --> URI Class Initialized
INFO - 2023-05-26 03:27:24 --> URI Class Initialized
INFO - 2023-05-26 03:27:24 --> Router Class Initialized
INFO - 2023-05-26 03:27:24 --> Router Class Initialized
DEBUG - 2023-05-26 03:27:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:27:24 --> Output Class Initialized
INFO - 2023-05-26 03:27:24 --> Utf8 Class Initialized
INFO - 2023-05-26 03:27:24 --> Output Class Initialized
INFO - 2023-05-26 03:27:24 --> URI Class Initialized
INFO - 2023-05-26 03:27:24 --> Security Class Initialized
INFO - 2023-05-26 03:27:24 --> Security Class Initialized
DEBUG - 2023-05-26 03:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:27:24 --> Input Class Initialized
INFO - 2023-05-26 03:27:24 --> Input Class Initialized
INFO - 2023-05-26 03:27:24 --> Language Class Initialized
INFO - 2023-05-26 03:27:24 --> Language Class Initialized
INFO - 2023-05-26 03:27:24 --> Router Class Initialized
INFO - 2023-05-26 03:27:24 --> Output Class Initialized
INFO - 2023-05-26 03:27:24 --> Security Class Initialized
INFO - 2023-05-26 03:27:24 --> Loader Class Initialized
INFO - 2023-05-26 03:27:24 --> Loader Class Initialized
INFO - 2023-05-26 03:27:24 --> Controller Class Initialized
INFO - 2023-05-26 03:27:24 --> Controller Class Initialized
DEBUG - 2023-05-26 03:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:27:24 --> Input Class Initialized
DEBUG - 2023-05-26 03:27:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 03:27:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:27:24 --> Language Class Initialized
INFO - 2023-05-26 03:27:24 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:24 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:27:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:27:24 --> Loader Class Initialized
INFO - 2023-05-26 03:27:24 --> Controller Class Initialized
DEBUG - 2023-05-26 03:27:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:27:24 --> Final output sent to browser
DEBUG - 2023-05-26 03:27:24 --> Total execution time: 0.3239
INFO - 2023-05-26 03:27:24 --> Final output sent to browser
DEBUG - 2023-05-26 03:27:24 --> Total execution time: 0.3359
INFO - 2023-05-26 03:27:24 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:27:24 --> Final output sent to browser
INFO - 2023-05-26 03:27:24 --> Config Class Initialized
DEBUG - 2023-05-26 03:27:24 --> Total execution time: 0.3440
INFO - 2023-05-26 03:27:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:27:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:27:24 --> Utf8 Class Initialized
INFO - 2023-05-26 03:27:24 --> URI Class Initialized
INFO - 2023-05-26 03:27:24 --> Config Class Initialized
INFO - 2023-05-26 03:27:24 --> Hooks Class Initialized
INFO - 2023-05-26 03:27:24 --> Router Class Initialized
INFO - 2023-05-26 03:27:24 --> Output Class Initialized
INFO - 2023-05-26 03:27:24 --> Security Class Initialized
DEBUG - 2023-05-26 03:27:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:27:24 --> Utf8 Class Initialized
DEBUG - 2023-05-26 03:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:27:24 --> URI Class Initialized
INFO - 2023-05-26 03:27:24 --> Input Class Initialized
INFO - 2023-05-26 03:27:24 --> Language Class Initialized
INFO - 2023-05-26 03:27:24 --> Router Class Initialized
INFO - 2023-05-26 03:27:24 --> Output Class Initialized
INFO - 2023-05-26 03:27:24 --> Loader Class Initialized
INFO - 2023-05-26 03:27:24 --> Security Class Initialized
INFO - 2023-05-26 03:27:24 --> Controller Class Initialized
DEBUG - 2023-05-26 03:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:27:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:27:24 --> Input Class Initialized
INFO - 2023-05-26 03:27:24 --> Final output sent to browser
DEBUG - 2023-05-26 03:27:24 --> Total execution time: 0.2029
INFO - 2023-05-26 03:27:24 --> Language Class Initialized
INFO - 2023-05-26 03:27:24 --> Loader Class Initialized
INFO - 2023-05-26 03:27:24 --> Controller Class Initialized
INFO - 2023-05-26 03:27:24 --> Config Class Initialized
INFO - 2023-05-26 03:27:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:27:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 03:27:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:27:24 --> Utf8 Class Initialized
INFO - 2023-05-26 03:27:24 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:24 --> URI Class Initialized
INFO - 2023-05-26 03:27:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:27:24 --> Router Class Initialized
INFO - 2023-05-26 03:27:24 --> Final output sent to browser
DEBUG - 2023-05-26 03:27:24 --> Total execution time: 0.2780
INFO - 2023-05-26 03:27:24 --> Output Class Initialized
INFO - 2023-05-26 03:27:24 --> Security Class Initialized
DEBUG - 2023-05-26 03:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:27:24 --> Input Class Initialized
INFO - 2023-05-26 03:27:24 --> Language Class Initialized
INFO - 2023-05-26 03:27:24 --> Loader Class Initialized
INFO - 2023-05-26 03:27:24 --> Controller Class Initialized
DEBUG - 2023-05-26 03:27:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:27:25 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:25 --> Model "Login_model" initialized
INFO - 2023-05-26 03:27:25 --> Database Driver Class Initialized
INFO - 2023-05-26 03:27:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:27:25 --> Final output sent to browser
DEBUG - 2023-05-26 03:27:25 --> Total execution time: 0.2959
INFO - 2023-05-26 03:50:05 --> Config Class Initialized
INFO - 2023-05-26 03:50:05 --> Config Class Initialized
INFO - 2023-05-26 03:50:05 --> Hooks Class Initialized
INFO - 2023-05-26 03:50:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:50:05 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:50:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:50:05 --> Utf8 Class Initialized
INFO - 2023-05-26 03:50:05 --> Utf8 Class Initialized
INFO - 2023-05-26 03:50:05 --> URI Class Initialized
INFO - 2023-05-26 03:50:05 --> URI Class Initialized
INFO - 2023-05-26 03:50:05 --> Router Class Initialized
INFO - 2023-05-26 03:50:05 --> Router Class Initialized
INFO - 2023-05-26 03:50:05 --> Output Class Initialized
INFO - 2023-05-26 03:50:05 --> Output Class Initialized
INFO - 2023-05-26 03:50:05 --> Security Class Initialized
INFO - 2023-05-26 03:50:05 --> Security Class Initialized
DEBUG - 2023-05-26 03:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:50:05 --> Input Class Initialized
INFO - 2023-05-26 03:50:05 --> Input Class Initialized
INFO - 2023-05-26 03:50:05 --> Language Class Initialized
INFO - 2023-05-26 03:50:05 --> Language Class Initialized
INFO - 2023-05-26 03:50:06 --> Loader Class Initialized
INFO - 2023-05-26 03:50:06 --> Loader Class Initialized
INFO - 2023-05-26 03:50:06 --> Controller Class Initialized
INFO - 2023-05-26 03:50:06 --> Controller Class Initialized
DEBUG - 2023-05-26 03:50:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 03:50:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:50:06 --> Database Driver Class Initialized
INFO - 2023-05-26 03:50:06 --> Database Driver Class Initialized
INFO - 2023-05-26 03:50:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:50:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:50:06 --> Final output sent to browser
DEBUG - 2023-05-26 03:50:06 --> Total execution time: 0.2644
INFO - 2023-05-26 03:50:06 --> Final output sent to browser
DEBUG - 2023-05-26 03:50:06 --> Total execution time: 0.2967
INFO - 2023-05-26 03:50:06 --> Config Class Initialized
INFO - 2023-05-26 03:50:06 --> Config Class Initialized
INFO - 2023-05-26 03:50:06 --> Hooks Class Initialized
INFO - 2023-05-26 03:50:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 03:50:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 03:50:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 03:50:06 --> Utf8 Class Initialized
INFO - 2023-05-26 03:50:06 --> Utf8 Class Initialized
INFO - 2023-05-26 03:50:06 --> URI Class Initialized
INFO - 2023-05-26 03:50:06 --> URI Class Initialized
INFO - 2023-05-26 03:50:06 --> Router Class Initialized
INFO - 2023-05-26 03:50:06 --> Router Class Initialized
INFO - 2023-05-26 03:50:06 --> Output Class Initialized
INFO - 2023-05-26 03:50:06 --> Output Class Initialized
INFO - 2023-05-26 03:50:06 --> Security Class Initialized
INFO - 2023-05-26 03:50:06 --> Security Class Initialized
DEBUG - 2023-05-26 03:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 03:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 03:50:06 --> Input Class Initialized
INFO - 2023-05-26 03:50:06 --> Input Class Initialized
INFO - 2023-05-26 03:50:06 --> Language Class Initialized
INFO - 2023-05-26 03:50:06 --> Language Class Initialized
INFO - 2023-05-26 03:50:06 --> Loader Class Initialized
INFO - 2023-05-26 03:50:06 --> Loader Class Initialized
INFO - 2023-05-26 03:50:06 --> Controller Class Initialized
INFO - 2023-05-26 03:50:06 --> Controller Class Initialized
DEBUG - 2023-05-26 03:50:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 03:50:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 03:50:06 --> Database Driver Class Initialized
INFO - 2023-05-26 03:50:06 --> Database Driver Class Initialized
INFO - 2023-05-26 03:50:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:50:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 03:50:06 --> Final output sent to browser
DEBUG - 2023-05-26 03:50:06 --> Total execution time: 0.2872
INFO - 2023-05-26 03:50:06 --> Final output sent to browser
DEBUG - 2023-05-26 03:50:06 --> Total execution time: 0.3753
INFO - 2023-05-26 05:54:51 --> Config Class Initialized
INFO - 2023-05-26 05:54:51 --> Config Class Initialized
INFO - 2023-05-26 05:54:51 --> Config Class Initialized
INFO - 2023-05-26 05:54:51 --> Hooks Class Initialized
INFO - 2023-05-26 05:54:51 --> Hooks Class Initialized
INFO - 2023-05-26 05:54:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:54:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 05:54:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 05:54:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:54:51 --> Utf8 Class Initialized
INFO - 2023-05-26 05:54:51 --> Utf8 Class Initialized
INFO - 2023-05-26 05:54:51 --> Utf8 Class Initialized
INFO - 2023-05-26 05:54:51 --> URI Class Initialized
INFO - 2023-05-26 05:54:51 --> URI Class Initialized
INFO - 2023-05-26 05:54:51 --> URI Class Initialized
INFO - 2023-05-26 05:54:51 --> Router Class Initialized
INFO - 2023-05-26 05:54:51 --> Router Class Initialized
INFO - 2023-05-26 05:54:51 --> Router Class Initialized
INFO - 2023-05-26 05:54:51 --> Output Class Initialized
INFO - 2023-05-26 05:54:51 --> Output Class Initialized
INFO - 2023-05-26 05:54:51 --> Output Class Initialized
INFO - 2023-05-26 05:54:51 --> Security Class Initialized
INFO - 2023-05-26 05:54:51 --> Security Class Initialized
INFO - 2023-05-26 05:54:51 --> Security Class Initialized
DEBUG - 2023-05-26 05:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 05:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 05:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:54:51 --> Input Class Initialized
INFO - 2023-05-26 05:54:51 --> Input Class Initialized
INFO - 2023-05-26 05:54:51 --> Input Class Initialized
INFO - 2023-05-26 05:54:51 --> Language Class Initialized
INFO - 2023-05-26 05:54:51 --> Language Class Initialized
INFO - 2023-05-26 05:54:51 --> Language Class Initialized
INFO - 2023-05-26 05:54:51 --> Loader Class Initialized
INFO - 2023-05-26 05:54:51 --> Loader Class Initialized
INFO - 2023-05-26 05:54:51 --> Loader Class Initialized
INFO - 2023-05-26 05:54:51 --> Controller Class Initialized
INFO - 2023-05-26 05:54:51 --> Controller Class Initialized
INFO - 2023-05-26 05:54:51 --> Controller Class Initialized
DEBUG - 2023-05-26 05:54:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 05:54:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 05:54:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:54:51 --> Database Driver Class Initialized
INFO - 2023-05-26 05:54:51 --> Database Driver Class Initialized
INFO - 2023-05-26 05:54:51 --> Database Driver Class Initialized
INFO - 2023-05-26 05:54:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:54:51 --> Final output sent to browser
DEBUG - 2023-05-26 05:54:51 --> Total execution time: 0.3028
INFO - 2023-05-26 05:54:51 --> Config Class Initialized
INFO - 2023-05-26 05:54:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:54:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:54:51 --> Utf8 Class Initialized
INFO - 2023-05-26 05:54:51 --> URI Class Initialized
INFO - 2023-05-26 05:54:51 --> Router Class Initialized
INFO - 2023-05-26 05:54:51 --> Output Class Initialized
INFO - 2023-05-26 05:54:51 --> Security Class Initialized
DEBUG - 2023-05-26 05:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:54:51 --> Input Class Initialized
INFO - 2023-05-26 05:54:51 --> Language Class Initialized
INFO - 2023-05-26 05:54:51 --> Loader Class Initialized
INFO - 2023-05-26 05:54:51 --> Controller Class Initialized
DEBUG - 2023-05-26 05:54:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:54:51 --> Database Driver Class Initialized
INFO - 2023-05-26 05:54:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:54:51 --> Final output sent to browser
DEBUG - 2023-05-26 05:54:51 --> Total execution time: 0.2527
INFO - 2023-05-26 05:54:51 --> Config Class Initialized
INFO - 2023-05-26 05:54:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:54:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:54:51 --> Utf8 Class Initialized
INFO - 2023-05-26 05:54:51 --> URI Class Initialized
INFO - 2023-05-26 05:54:51 --> Router Class Initialized
INFO - 2023-05-26 05:54:51 --> Output Class Initialized
INFO - 2023-05-26 05:54:51 --> Security Class Initialized
DEBUG - 2023-05-26 05:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:54:52 --> Input Class Initialized
INFO - 2023-05-26 05:54:52 --> Language Class Initialized
INFO - 2023-05-26 05:54:52 --> Loader Class Initialized
INFO - 2023-05-26 05:54:52 --> Controller Class Initialized
DEBUG - 2023-05-26 05:54:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:54:52 --> Database Driver Class Initialized
INFO - 2023-05-26 05:54:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:54:52 --> Final output sent to browser
DEBUG - 2023-05-26 05:54:52 --> Total execution time: 0.2417
INFO - 2023-05-26 05:54:52 --> Config Class Initialized
INFO - 2023-05-26 05:54:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:54:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:54:52 --> Utf8 Class Initialized
INFO - 2023-05-26 05:54:52 --> URI Class Initialized
INFO - 2023-05-26 05:54:52 --> Router Class Initialized
INFO - 2023-05-26 05:54:52 --> Output Class Initialized
INFO - 2023-05-26 05:54:52 --> Security Class Initialized
DEBUG - 2023-05-26 05:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:54:52 --> Input Class Initialized
INFO - 2023-05-26 05:54:52 --> Language Class Initialized
INFO - 2023-05-26 05:54:52 --> Loader Class Initialized
INFO - 2023-05-26 05:54:52 --> Controller Class Initialized
DEBUG - 2023-05-26 05:54:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:54:52 --> Database Driver Class Initialized
INFO - 2023-05-26 05:54:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:54:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:54:52 --> Final output sent to browser
INFO - 2023-05-26 05:54:52 --> Database Driver Class Initialized
DEBUG - 2023-05-26 05:54:52 --> Total execution time: 0.3555
INFO - 2023-05-26 05:54:52 --> Final output sent to browser
DEBUG - 2023-05-26 05:54:52 --> Total execution time: 1.2824
INFO - 2023-05-26 05:54:52 --> Model "Login_model" initialized
INFO - 2023-05-26 05:54:52 --> Final output sent to browser
DEBUG - 2023-05-26 05:54:52 --> Total execution time: 1.3261
INFO - 2023-05-26 05:54:52 --> Config Class Initialized
INFO - 2023-05-26 05:54:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:54:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:54:52 --> Utf8 Class Initialized
INFO - 2023-05-26 05:54:52 --> Config Class Initialized
INFO - 2023-05-26 05:54:52 --> Hooks Class Initialized
INFO - 2023-05-26 05:54:52 --> URI Class Initialized
INFO - 2023-05-26 05:54:52 --> Router Class Initialized
DEBUG - 2023-05-26 05:54:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:54:52 --> Utf8 Class Initialized
INFO - 2023-05-26 05:54:52 --> Output Class Initialized
INFO - 2023-05-26 05:54:52 --> URI Class Initialized
INFO - 2023-05-26 05:54:52 --> Security Class Initialized
DEBUG - 2023-05-26 05:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:54:52 --> Router Class Initialized
INFO - 2023-05-26 05:54:52 --> Input Class Initialized
INFO - 2023-05-26 05:54:52 --> Language Class Initialized
INFO - 2023-05-26 05:54:52 --> Output Class Initialized
INFO - 2023-05-26 05:54:52 --> Security Class Initialized
INFO - 2023-05-26 05:54:52 --> Loader Class Initialized
DEBUG - 2023-05-26 05:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:54:52 --> Input Class Initialized
INFO - 2023-05-26 05:54:52 --> Controller Class Initialized
INFO - 2023-05-26 05:54:52 --> Language Class Initialized
DEBUG - 2023-05-26 05:54:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:54:52 --> Loader Class Initialized
INFO - 2023-05-26 05:54:52 --> Controller Class Initialized
DEBUG - 2023-05-26 05:54:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:54:52 --> Database Driver Class Initialized
INFO - 2023-05-26 05:54:52 --> Database Driver Class Initialized
INFO - 2023-05-26 05:54:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:54:52 --> Database Driver Class Initialized
INFO - 2023-05-26 05:54:52 --> Final output sent to browser
DEBUG - 2023-05-26 05:54:52 --> Total execution time: 0.2945
INFO - 2023-05-26 05:54:52 --> Model "Login_model" initialized
INFO - 2023-05-26 05:54:52 --> Final output sent to browser
DEBUG - 2023-05-26 05:54:52 --> Total execution time: 0.3024
INFO - 2023-05-26 05:55:51 --> Config Class Initialized
INFO - 2023-05-26 05:55:51 --> Config Class Initialized
INFO - 2023-05-26 05:55:51 --> Hooks Class Initialized
INFO - 2023-05-26 05:55:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:55:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 05:55:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:55:51 --> Utf8 Class Initialized
INFO - 2023-05-26 05:55:51 --> Utf8 Class Initialized
INFO - 2023-05-26 05:55:51 --> URI Class Initialized
INFO - 2023-05-26 05:55:51 --> URI Class Initialized
INFO - 2023-05-26 05:55:51 --> Router Class Initialized
INFO - 2023-05-26 05:55:51 --> Router Class Initialized
INFO - 2023-05-26 05:55:51 --> Output Class Initialized
INFO - 2023-05-26 05:55:51 --> Output Class Initialized
INFO - 2023-05-26 05:55:51 --> Security Class Initialized
INFO - 2023-05-26 05:55:51 --> Security Class Initialized
DEBUG - 2023-05-26 05:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 05:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:55:51 --> Input Class Initialized
INFO - 2023-05-26 05:55:51 --> Input Class Initialized
INFO - 2023-05-26 05:55:51 --> Language Class Initialized
INFO - 2023-05-26 05:55:51 --> Language Class Initialized
INFO - 2023-05-26 05:55:51 --> Loader Class Initialized
INFO - 2023-05-26 05:55:51 --> Controller Class Initialized
INFO - 2023-05-26 05:55:51 --> Loader Class Initialized
DEBUG - 2023-05-26 05:55:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:55:51 --> Controller Class Initialized
DEBUG - 2023-05-26 05:55:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:55:51 --> Database Driver Class Initialized
INFO - 2023-05-26 05:55:51 --> Database Driver Class Initialized
INFO - 2023-05-26 05:55:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:55:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:55:51 --> Database Driver Class Initialized
INFO - 2023-05-26 05:55:51 --> Final output sent to browser
DEBUG - 2023-05-26 05:55:51 --> Total execution time: 0.2817
INFO - 2023-05-26 05:55:51 --> Model "Login_model" initialized
INFO - 2023-05-26 05:55:51 --> Config Class Initialized
INFO - 2023-05-26 05:55:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:55:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:55:51 --> Utf8 Class Initialized
INFO - 2023-05-26 05:55:51 --> URI Class Initialized
INFO - 2023-05-26 05:55:51 --> Router Class Initialized
INFO - 2023-05-26 05:55:51 --> Output Class Initialized
INFO - 2023-05-26 05:55:51 --> Security Class Initialized
DEBUG - 2023-05-26 05:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:55:51 --> Input Class Initialized
INFO - 2023-05-26 05:55:51 --> Language Class Initialized
INFO - 2023-05-26 05:55:51 --> Loader Class Initialized
INFO - 2023-05-26 05:55:51 --> Controller Class Initialized
DEBUG - 2023-05-26 05:55:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:55:51 --> Database Driver Class Initialized
INFO - 2023-05-26 05:55:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:55:52 --> Final output sent to browser
DEBUG - 2023-05-26 05:55:52 --> Total execution time: 0.4817
INFO - 2023-05-26 05:56:05 --> Final output sent to browser
DEBUG - 2023-05-26 05:56:05 --> Total execution time: 13.8218
INFO - 2023-05-26 05:56:05 --> Config Class Initialized
INFO - 2023-05-26 05:56:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:56:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:56:05 --> Utf8 Class Initialized
INFO - 2023-05-26 05:56:05 --> URI Class Initialized
INFO - 2023-05-26 05:56:05 --> Router Class Initialized
INFO - 2023-05-26 05:56:06 --> Output Class Initialized
INFO - 2023-05-26 05:56:06 --> Security Class Initialized
DEBUG - 2023-05-26 05:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:56:06 --> Input Class Initialized
INFO - 2023-05-26 05:56:06 --> Language Class Initialized
INFO - 2023-05-26 05:56:06 --> Loader Class Initialized
INFO - 2023-05-26 05:56:06 --> Controller Class Initialized
DEBUG - 2023-05-26 05:56:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:56:06 --> Database Driver Class Initialized
INFO - 2023-05-26 05:56:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:56:06 --> Database Driver Class Initialized
INFO - 2023-05-26 05:56:06 --> Model "Login_model" initialized
INFO - 2023-05-26 05:56:20 --> Final output sent to browser
DEBUG - 2023-05-26 05:56:20 --> Total execution time: 15.3484
INFO - 2023-05-26 05:56:51 --> Config Class Initialized
INFO - 2023-05-26 05:56:51 --> Config Class Initialized
INFO - 2023-05-26 05:56:51 --> Hooks Class Initialized
INFO - 2023-05-26 05:56:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:56:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 05:56:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:56:51 --> Utf8 Class Initialized
INFO - 2023-05-26 05:56:51 --> Utf8 Class Initialized
INFO - 2023-05-26 05:56:51 --> URI Class Initialized
INFO - 2023-05-26 05:56:51 --> URI Class Initialized
INFO - 2023-05-26 05:56:51 --> Router Class Initialized
INFO - 2023-05-26 05:56:51 --> Router Class Initialized
INFO - 2023-05-26 05:56:51 --> Output Class Initialized
INFO - 2023-05-26 05:56:51 --> Output Class Initialized
INFO - 2023-05-26 05:56:51 --> Security Class Initialized
INFO - 2023-05-26 05:56:51 --> Security Class Initialized
DEBUG - 2023-05-26 05:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 05:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:56:51 --> Input Class Initialized
INFO - 2023-05-26 05:56:51 --> Input Class Initialized
INFO - 2023-05-26 05:56:51 --> Language Class Initialized
INFO - 2023-05-26 05:56:51 --> Language Class Initialized
INFO - 2023-05-26 05:56:51 --> Loader Class Initialized
INFO - 2023-05-26 05:56:51 --> Controller Class Initialized
INFO - 2023-05-26 05:56:51 --> Loader Class Initialized
DEBUG - 2023-05-26 05:56:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:56:51 --> Controller Class Initialized
DEBUG - 2023-05-26 05:56:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:56:51 --> Database Driver Class Initialized
INFO - 2023-05-26 05:56:51 --> Database Driver Class Initialized
INFO - 2023-05-26 05:56:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:56:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:56:51 --> Database Driver Class Initialized
INFO - 2023-05-26 05:56:51 --> Model "Login_model" initialized
INFO - 2023-05-26 05:56:51 --> Final output sent to browser
DEBUG - 2023-05-26 05:56:51 --> Total execution time: 0.4026
INFO - 2023-05-26 05:56:51 --> Config Class Initialized
INFO - 2023-05-26 05:56:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:56:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:56:51 --> Utf8 Class Initialized
INFO - 2023-05-26 05:56:51 --> URI Class Initialized
INFO - 2023-05-26 05:56:51 --> Router Class Initialized
INFO - 2023-05-26 05:56:51 --> Output Class Initialized
INFO - 2023-05-26 05:56:51 --> Security Class Initialized
DEBUG - 2023-05-26 05:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:56:51 --> Input Class Initialized
INFO - 2023-05-26 05:56:51 --> Language Class Initialized
INFO - 2023-05-26 05:56:51 --> Loader Class Initialized
INFO - 2023-05-26 05:56:51 --> Controller Class Initialized
DEBUG - 2023-05-26 05:56:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:56:51 --> Database Driver Class Initialized
INFO - 2023-05-26 05:56:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:56:52 --> Final output sent to browser
DEBUG - 2023-05-26 05:56:52 --> Total execution time: 0.4413
INFO - 2023-05-26 05:57:02 --> Final output sent to browser
DEBUG - 2023-05-26 05:57:02 --> Total execution time: 11.6651
INFO - 2023-05-26 05:57:02 --> Config Class Initialized
INFO - 2023-05-26 05:57:02 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:57:03 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:57:03 --> Utf8 Class Initialized
INFO - 2023-05-26 05:57:03 --> URI Class Initialized
INFO - 2023-05-26 05:57:03 --> Router Class Initialized
INFO - 2023-05-26 05:57:03 --> Output Class Initialized
INFO - 2023-05-26 05:57:03 --> Security Class Initialized
DEBUG - 2023-05-26 05:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:57:03 --> Input Class Initialized
INFO - 2023-05-26 05:57:03 --> Language Class Initialized
INFO - 2023-05-26 05:57:03 --> Loader Class Initialized
INFO - 2023-05-26 05:57:03 --> Controller Class Initialized
DEBUG - 2023-05-26 05:57:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:57:03 --> Database Driver Class Initialized
INFO - 2023-05-26 05:57:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:57:03 --> Database Driver Class Initialized
INFO - 2023-05-26 05:57:03 --> Model "Login_model" initialized
INFO - 2023-05-26 05:57:16 --> Final output sent to browser
DEBUG - 2023-05-26 05:57:16 --> Total execution time: 13.6766
INFO - 2023-05-26 05:57:51 --> Config Class Initialized
INFO - 2023-05-26 05:57:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:57:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:57:51 --> Utf8 Class Initialized
INFO - 2023-05-26 05:57:51 --> URI Class Initialized
INFO - 2023-05-26 05:57:51 --> Router Class Initialized
INFO - 2023-05-26 05:57:51 --> Output Class Initialized
INFO - 2023-05-26 05:57:51 --> Security Class Initialized
DEBUG - 2023-05-26 05:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:57:51 --> Input Class Initialized
INFO - 2023-05-26 05:57:51 --> Language Class Initialized
INFO - 2023-05-26 05:57:51 --> Loader Class Initialized
INFO - 2023-05-26 05:57:51 --> Controller Class Initialized
DEBUG - 2023-05-26 05:57:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:57:51 --> Database Driver Class Initialized
INFO - 2023-05-26 05:57:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:57:51 --> Final output sent to browser
DEBUG - 2023-05-26 05:57:51 --> Total execution time: 0.2652
INFO - 2023-05-26 05:57:51 --> Config Class Initialized
INFO - 2023-05-26 05:57:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:57:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:57:51 --> Utf8 Class Initialized
INFO - 2023-05-26 05:57:51 --> URI Class Initialized
INFO - 2023-05-26 05:57:51 --> Router Class Initialized
INFO - 2023-05-26 05:57:51 --> Output Class Initialized
INFO - 2023-05-26 05:57:51 --> Security Class Initialized
DEBUG - 2023-05-26 05:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:57:51 --> Input Class Initialized
INFO - 2023-05-26 05:57:51 --> Language Class Initialized
INFO - 2023-05-26 05:57:51 --> Loader Class Initialized
INFO - 2023-05-26 05:57:51 --> Controller Class Initialized
DEBUG - 2023-05-26 05:57:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:57:52 --> Database Driver Class Initialized
INFO - 2023-05-26 05:57:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:57:52 --> Final output sent to browser
DEBUG - 2023-05-26 05:57:52 --> Total execution time: 0.3821
INFO - 2023-05-26 05:57:52 --> Config Class Initialized
INFO - 2023-05-26 05:57:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:57:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:57:52 --> Utf8 Class Initialized
INFO - 2023-05-26 05:57:52 --> URI Class Initialized
INFO - 2023-05-26 05:57:52 --> Router Class Initialized
INFO - 2023-05-26 05:57:52 --> Output Class Initialized
INFO - 2023-05-26 05:57:52 --> Security Class Initialized
DEBUG - 2023-05-26 05:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:57:52 --> Input Class Initialized
INFO - 2023-05-26 05:57:52 --> Language Class Initialized
INFO - 2023-05-26 05:57:52 --> Loader Class Initialized
INFO - 2023-05-26 05:57:52 --> Controller Class Initialized
DEBUG - 2023-05-26 05:57:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:57:52 --> Database Driver Class Initialized
INFO - 2023-05-26 05:57:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:57:52 --> Database Driver Class Initialized
INFO - 2023-05-26 05:57:52 --> Model "Login_model" initialized
INFO - 2023-05-26 05:58:01 --> Final output sent to browser
DEBUG - 2023-05-26 05:58:01 --> Total execution time: 8.9444
INFO - 2023-05-26 05:58:01 --> Config Class Initialized
INFO - 2023-05-26 05:58:01 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:58:01 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:58:01 --> Utf8 Class Initialized
INFO - 2023-05-26 05:58:01 --> URI Class Initialized
INFO - 2023-05-26 05:58:01 --> Router Class Initialized
INFO - 2023-05-26 05:58:01 --> Output Class Initialized
INFO - 2023-05-26 05:58:01 --> Security Class Initialized
DEBUG - 2023-05-26 05:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:58:01 --> Input Class Initialized
INFO - 2023-05-26 05:58:01 --> Language Class Initialized
INFO - 2023-05-26 05:58:01 --> Loader Class Initialized
INFO - 2023-05-26 05:58:01 --> Controller Class Initialized
DEBUG - 2023-05-26 05:58:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:58:01 --> Database Driver Class Initialized
INFO - 2023-05-26 05:58:01 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:58:01 --> Database Driver Class Initialized
INFO - 2023-05-26 05:58:01 --> Model "Login_model" initialized
INFO - 2023-05-26 05:58:11 --> Final output sent to browser
DEBUG - 2023-05-26 05:58:11 --> Total execution time: 10.4335
INFO - 2023-05-26 05:59:19 --> Config Class Initialized
INFO - 2023-05-26 05:59:19 --> Config Class Initialized
INFO - 2023-05-26 05:59:19 --> Hooks Class Initialized
INFO - 2023-05-26 05:59:19 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:59:19 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 05:59:19 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:59:19 --> Utf8 Class Initialized
INFO - 2023-05-26 05:59:19 --> Utf8 Class Initialized
INFO - 2023-05-26 05:59:19 --> URI Class Initialized
INFO - 2023-05-26 05:59:19 --> URI Class Initialized
INFO - 2023-05-26 05:59:19 --> Router Class Initialized
INFO - 2023-05-26 05:59:19 --> Router Class Initialized
INFO - 2023-05-26 05:59:19 --> Output Class Initialized
INFO - 2023-05-26 05:59:19 --> Output Class Initialized
INFO - 2023-05-26 05:59:19 --> Security Class Initialized
INFO - 2023-05-26 05:59:19 --> Security Class Initialized
DEBUG - 2023-05-26 05:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 05:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:59:19 --> Input Class Initialized
INFO - 2023-05-26 05:59:19 --> Input Class Initialized
INFO - 2023-05-26 05:59:19 --> Language Class Initialized
INFO - 2023-05-26 05:59:19 --> Language Class Initialized
INFO - 2023-05-26 05:59:19 --> Loader Class Initialized
INFO - 2023-05-26 05:59:19 --> Loader Class Initialized
INFO - 2023-05-26 05:59:19 --> Controller Class Initialized
INFO - 2023-05-26 05:59:19 --> Controller Class Initialized
DEBUG - 2023-05-26 05:59:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 05:59:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:59:19 --> Database Driver Class Initialized
INFO - 2023-05-26 05:59:19 --> Database Driver Class Initialized
INFO - 2023-05-26 05:59:19 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:59:19 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:59:19 --> Database Driver Class Initialized
INFO - 2023-05-26 05:59:19 --> Model "Login_model" initialized
INFO - 2023-05-26 05:59:19 --> Final output sent to browser
DEBUG - 2023-05-26 05:59:19 --> Total execution time: 0.2178
INFO - 2023-05-26 05:59:19 --> Config Class Initialized
INFO - 2023-05-26 05:59:19 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:59:19 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:59:19 --> Utf8 Class Initialized
INFO - 2023-05-26 05:59:19 --> URI Class Initialized
INFO - 2023-05-26 05:59:19 --> Router Class Initialized
INFO - 2023-05-26 05:59:19 --> Output Class Initialized
INFO - 2023-05-26 05:59:19 --> Security Class Initialized
DEBUG - 2023-05-26 05:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:59:19 --> Input Class Initialized
INFO - 2023-05-26 05:59:19 --> Language Class Initialized
INFO - 2023-05-26 05:59:19 --> Loader Class Initialized
INFO - 2023-05-26 05:59:19 --> Controller Class Initialized
DEBUG - 2023-05-26 05:59:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:59:19 --> Database Driver Class Initialized
INFO - 2023-05-26 05:59:19 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:59:19 --> Final output sent to browser
DEBUG - 2023-05-26 05:59:19 --> Total execution time: 0.2280
INFO - 2023-05-26 05:59:27 --> Config Class Initialized
INFO - 2023-05-26 05:59:27 --> Hooks Class Initialized
INFO - 2023-05-26 05:59:27 --> Config Class Initialized
INFO - 2023-05-26 05:59:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 05:59:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:59:27 --> Utf8 Class Initialized
INFO - 2023-05-26 05:59:27 --> URI Class Initialized
INFO - 2023-05-26 05:59:27 --> Router Class Initialized
DEBUG - 2023-05-26 05:59:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:59:27 --> Output Class Initialized
INFO - 2023-05-26 05:59:27 --> Utf8 Class Initialized
INFO - 2023-05-26 05:59:27 --> Security Class Initialized
INFO - 2023-05-26 05:59:27 --> URI Class Initialized
DEBUG - 2023-05-26 05:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:59:27 --> Input Class Initialized
INFO - 2023-05-26 05:59:27 --> Language Class Initialized
INFO - 2023-05-26 05:59:27 --> Router Class Initialized
INFO - 2023-05-26 05:59:27 --> Loader Class Initialized
INFO - 2023-05-26 05:59:27 --> Output Class Initialized
INFO - 2023-05-26 05:59:27 --> Controller Class Initialized
DEBUG - 2023-05-26 05:59:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:59:27 --> Security Class Initialized
DEBUG - 2023-05-26 05:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:59:27 --> Input Class Initialized
INFO - 2023-05-26 05:59:27 --> Database Driver Class Initialized
INFO - 2023-05-26 05:59:27 --> Language Class Initialized
INFO - 2023-05-26 05:59:28 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:59:28 --> Config Class Initialized
INFO - 2023-05-26 05:59:28 --> Hooks Class Initialized
INFO - 2023-05-26 05:59:28 --> Loader Class Initialized
INFO - 2023-05-26 05:59:28 --> Controller Class Initialized
DEBUG - 2023-05-26 05:59:28 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:59:28 --> Utf8 Class Initialized
DEBUG - 2023-05-26 05:59:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:59:28 --> URI Class Initialized
INFO - 2023-05-26 05:59:28 --> Final output sent to browser
DEBUG - 2023-05-26 05:59:28 --> Total execution time: 1.2888
INFO - 2023-05-26 05:59:28 --> Router Class Initialized
INFO - 2023-05-26 05:59:28 --> Output Class Initialized
INFO - 2023-05-26 05:59:28 --> Database Driver Class Initialized
INFO - 2023-05-26 05:59:28 --> Security Class Initialized
DEBUG - 2023-05-26 05:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:59:28 --> Input Class Initialized
INFO - 2023-05-26 05:59:28 --> Config Class Initialized
INFO - 2023-05-26 05:59:28 --> Language Class Initialized
INFO - 2023-05-26 05:59:28 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:59:28 --> Hooks Class Initialized
INFO - 2023-05-26 05:59:28 --> Config Class Initialized
INFO - 2023-05-26 05:59:28 --> Hooks Class Initialized
INFO - 2023-05-26 05:59:28 --> Final output sent to browser
DEBUG - 2023-05-26 05:59:28 --> Total execution time: 1.8312
INFO - 2023-05-26 05:59:29 --> Loader Class Initialized
DEBUG - 2023-05-26 05:59:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:59:29 --> Utf8 Class Initialized
INFO - 2023-05-26 05:59:29 --> URI Class Initialized
DEBUG - 2023-05-26 05:59:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:59:29 --> Utf8 Class Initialized
INFO - 2023-05-26 05:59:29 --> Controller Class Initialized
DEBUG - 2023-05-26 05:59:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:59:29 --> URI Class Initialized
INFO - 2023-05-26 05:59:29 --> Router Class Initialized
INFO - 2023-05-26 05:59:29 --> Config Class Initialized
INFO - 2023-05-26 05:59:29 --> Router Class Initialized
INFO - 2023-05-26 05:59:29 --> Hooks Class Initialized
INFO - 2023-05-26 05:59:29 --> Output Class Initialized
INFO - 2023-05-26 05:59:29 --> Security Class Initialized
INFO - 2023-05-26 05:59:29 --> Output Class Initialized
DEBUG - 2023-05-26 05:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 05:59:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:59:29 --> Database Driver Class Initialized
INFO - 2023-05-26 05:59:29 --> Security Class Initialized
INFO - 2023-05-26 05:59:29 --> Input Class Initialized
INFO - 2023-05-26 05:59:29 --> Utf8 Class Initialized
INFO - 2023-05-26 05:59:29 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 05:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:59:29 --> URI Class Initialized
INFO - 2023-05-26 05:59:29 --> Input Class Initialized
INFO - 2023-05-26 05:59:29 --> Language Class Initialized
INFO - 2023-05-26 05:59:29 --> Language Class Initialized
INFO - 2023-05-26 05:59:29 --> Router Class Initialized
INFO - 2023-05-26 05:59:29 --> Loader Class Initialized
INFO - 2023-05-26 05:59:29 --> Output Class Initialized
INFO - 2023-05-26 05:59:29 --> Security Class Initialized
INFO - 2023-05-26 05:59:29 --> Controller Class Initialized
DEBUG - 2023-05-26 05:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:59:29 --> Input Class Initialized
DEBUG - 2023-05-26 05:59:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:59:29 --> Language Class Initialized
INFO - 2023-05-26 05:59:29 --> Final output sent to browser
INFO - 2023-05-26 05:59:29 --> Loader Class Initialized
DEBUG - 2023-05-26 05:59:29 --> Total execution time: 1.9286
INFO - 2023-05-26 05:59:29 --> Loader Class Initialized
INFO - 2023-05-26 05:59:29 --> Database Driver Class Initialized
INFO - 2023-05-26 05:59:29 --> Controller Class Initialized
DEBUG - 2023-05-26 05:59:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:59:29 --> Controller Class Initialized
DEBUG - 2023-05-26 05:59:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:59:29 --> Database Driver Class Initialized
INFO - 2023-05-26 05:59:30 --> Model "Login_model" initialized
INFO - 2023-05-26 05:59:30 --> Config Class Initialized
INFO - 2023-05-26 05:59:30 --> Hooks Class Initialized
INFO - 2023-05-26 05:59:30 --> Final output sent to browser
INFO - 2023-05-26 05:59:30 --> Database Driver Class Initialized
DEBUG - 2023-05-26 05:59:30 --> Total execution time: 1.2449
INFO - 2023-05-26 05:59:30 --> Database Driver Class Initialized
INFO - 2023-05-26 05:59:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 05:59:30 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 05:59:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:59:30 --> Utf8 Class Initialized
INFO - 2023-05-26 05:59:30 --> URI Class Initialized
INFO - 2023-05-26 05:59:30 --> Final output sent to browser
INFO - 2023-05-26 05:59:30 --> Router Class Initialized
DEBUG - 2023-05-26 05:59:30 --> Total execution time: 1.2088
INFO - 2023-05-26 05:59:30 --> Final output sent to browser
INFO - 2023-05-26 05:59:30 --> Config Class Initialized
INFO - 2023-05-26 05:59:30 --> Hooks Class Initialized
INFO - 2023-05-26 05:59:30 --> Output Class Initialized
DEBUG - 2023-05-26 05:59:30 --> Total execution time: 1.4982
INFO - 2023-05-26 05:59:30 --> Security Class Initialized
DEBUG - 2023-05-26 05:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:59:30 --> Input Class Initialized
DEBUG - 2023-05-26 05:59:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 05:59:30 --> Language Class Initialized
INFO - 2023-05-26 05:59:30 --> Utf8 Class Initialized
INFO - 2023-05-26 05:59:30 --> URI Class Initialized
INFO - 2023-05-26 05:59:30 --> Router Class Initialized
INFO - 2023-05-26 05:59:30 --> Loader Class Initialized
INFO - 2023-05-26 05:59:30 --> Output Class Initialized
INFO - 2023-05-26 05:59:30 --> Security Class Initialized
INFO - 2023-05-26 05:59:30 --> Controller Class Initialized
DEBUG - 2023-05-26 05:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 05:59:30 --> Input Class Initialized
DEBUG - 2023-05-26 05:59:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:59:30 --> Language Class Initialized
INFO - 2023-05-26 05:59:30 --> Loader Class Initialized
INFO - 2023-05-26 05:59:30 --> Database Driver Class Initialized
INFO - 2023-05-26 05:59:30 --> Controller Class Initialized
INFO - 2023-05-26 05:59:30 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 05:59:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 05:59:31 --> Final output sent to browser
DEBUG - 2023-05-26 05:59:31 --> Total execution time: 1.0417
INFO - 2023-05-26 05:59:31 --> Database Driver Class Initialized
INFO - 2023-05-26 05:59:31 --> Database Driver Class Initialized
INFO - 2023-05-26 05:59:31 --> Model "Login_model" initialized
INFO - 2023-05-26 05:59:31 --> Final output sent to browser
DEBUG - 2023-05-26 05:59:31 --> Total execution time: 1.1928
INFO - 2023-05-26 05:59:34 --> Final output sent to browser
DEBUG - 2023-05-26 05:59:34 --> Total execution time: 15.1704
INFO - 2023-05-26 06:00:27 --> Config Class Initialized
INFO - 2023-05-26 06:00:27 --> Config Class Initialized
INFO - 2023-05-26 06:00:27 --> Hooks Class Initialized
INFO - 2023-05-26 06:00:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:00:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:00:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:00:27 --> Utf8 Class Initialized
INFO - 2023-05-26 06:00:27 --> Utf8 Class Initialized
INFO - 2023-05-26 06:00:27 --> URI Class Initialized
INFO - 2023-05-26 06:00:27 --> URI Class Initialized
INFO - 2023-05-26 06:00:27 --> Router Class Initialized
INFO - 2023-05-26 06:00:27 --> Router Class Initialized
INFO - 2023-05-26 06:00:27 --> Output Class Initialized
INFO - 2023-05-26 06:00:27 --> Output Class Initialized
INFO - 2023-05-26 06:00:27 --> Security Class Initialized
INFO - 2023-05-26 06:00:27 --> Security Class Initialized
DEBUG - 2023-05-26 06:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:00:27 --> Input Class Initialized
INFO - 2023-05-26 06:00:27 --> Input Class Initialized
INFO - 2023-05-26 06:00:27 --> Language Class Initialized
INFO - 2023-05-26 06:00:27 --> Language Class Initialized
INFO - 2023-05-26 06:00:27 --> Loader Class Initialized
INFO - 2023-05-26 06:00:27 --> Loader Class Initialized
INFO - 2023-05-26 06:00:27 --> Controller Class Initialized
DEBUG - 2023-05-26 06:00:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:00:27 --> Controller Class Initialized
DEBUG - 2023-05-26 06:00:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:00:27 --> Database Driver Class Initialized
INFO - 2023-05-26 06:00:27 --> Database Driver Class Initialized
INFO - 2023-05-26 06:00:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:00:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:00:27 --> Database Driver Class Initialized
INFO - 2023-05-26 06:00:27 --> Model "Login_model" initialized
INFO - 2023-05-26 06:00:27 --> Final output sent to browser
DEBUG - 2023-05-26 06:00:27 --> Total execution time: 0.2273
INFO - 2023-05-26 06:00:27 --> Config Class Initialized
INFO - 2023-05-26 06:00:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:00:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:00:27 --> Utf8 Class Initialized
INFO - 2023-05-26 06:00:27 --> URI Class Initialized
INFO - 2023-05-26 06:00:27 --> Router Class Initialized
INFO - 2023-05-26 06:00:27 --> Output Class Initialized
INFO - 2023-05-26 06:00:27 --> Security Class Initialized
DEBUG - 2023-05-26 06:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:00:27 --> Input Class Initialized
INFO - 2023-05-26 06:00:27 --> Language Class Initialized
INFO - 2023-05-26 06:00:27 --> Loader Class Initialized
INFO - 2023-05-26 06:00:27 --> Controller Class Initialized
DEBUG - 2023-05-26 06:00:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:00:27 --> Database Driver Class Initialized
INFO - 2023-05-26 06:00:28 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:00:28 --> Final output sent to browser
DEBUG - 2023-05-26 06:00:28 --> Total execution time: 0.5335
INFO - 2023-05-26 06:00:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:00:35 --> Total execution time: 8.0369
INFO - 2023-05-26 06:00:35 --> Config Class Initialized
INFO - 2023-05-26 06:00:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:00:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:00:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:00:35 --> URI Class Initialized
INFO - 2023-05-26 06:00:35 --> Router Class Initialized
INFO - 2023-05-26 06:00:35 --> Output Class Initialized
INFO - 2023-05-26 06:00:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:00:35 --> Input Class Initialized
INFO - 2023-05-26 06:00:35 --> Language Class Initialized
INFO - 2023-05-26 06:00:35 --> Loader Class Initialized
INFO - 2023-05-26 06:00:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:00:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:00:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:00:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:00:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:00:35 --> Model "Login_model" initialized
INFO - 2023-05-26 06:00:43 --> Final output sent to browser
DEBUG - 2023-05-26 06:00:43 --> Total execution time: 8.2202
INFO - 2023-05-26 06:01:26 --> Config Class Initialized
INFO - 2023-05-26 06:01:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:01:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:01:26 --> Utf8 Class Initialized
INFO - 2023-05-26 06:01:26 --> URI Class Initialized
INFO - 2023-05-26 06:01:26 --> Router Class Initialized
INFO - 2023-05-26 06:01:26 --> Output Class Initialized
INFO - 2023-05-26 06:01:26 --> Security Class Initialized
DEBUG - 2023-05-26 06:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:01:26 --> Input Class Initialized
INFO - 2023-05-26 06:01:26 --> Language Class Initialized
INFO - 2023-05-26 06:01:26 --> Loader Class Initialized
INFO - 2023-05-26 06:01:26 --> Controller Class Initialized
DEBUG - 2023-05-26 06:01:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:01:26 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:01:26 --> Final output sent to browser
DEBUG - 2023-05-26 06:01:26 --> Total execution time: 0.2303
INFO - 2023-05-26 06:01:26 --> Config Class Initialized
INFO - 2023-05-26 06:01:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:01:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:01:26 --> Utf8 Class Initialized
INFO - 2023-05-26 06:01:26 --> URI Class Initialized
INFO - 2023-05-26 06:01:26 --> Router Class Initialized
INFO - 2023-05-26 06:01:26 --> Output Class Initialized
INFO - 2023-05-26 06:01:26 --> Security Class Initialized
DEBUG - 2023-05-26 06:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:01:26 --> Input Class Initialized
INFO - 2023-05-26 06:01:26 --> Language Class Initialized
INFO - 2023-05-26 06:01:26 --> Loader Class Initialized
INFO - 2023-05-26 06:01:26 --> Controller Class Initialized
DEBUG - 2023-05-26 06:01:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:01:26 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:01:26 --> Final output sent to browser
DEBUG - 2023-05-26 06:01:26 --> Total execution time: 0.2301
INFO - 2023-05-26 06:01:30 --> Config Class Initialized
INFO - 2023-05-26 06:01:30 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:01:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:01:30 --> Utf8 Class Initialized
INFO - 2023-05-26 06:01:30 --> URI Class Initialized
INFO - 2023-05-26 06:01:30 --> Router Class Initialized
INFO - 2023-05-26 06:01:30 --> Output Class Initialized
INFO - 2023-05-26 06:01:30 --> Config Class Initialized
INFO - 2023-05-26 06:01:30 --> Hooks Class Initialized
INFO - 2023-05-26 06:01:30 --> Security Class Initialized
DEBUG - 2023-05-26 06:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:01:30 --> Input Class Initialized
DEBUG - 2023-05-26 06:01:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:01:30 --> Language Class Initialized
INFO - 2023-05-26 06:01:30 --> Utf8 Class Initialized
INFO - 2023-05-26 06:01:30 --> URI Class Initialized
INFO - 2023-05-26 06:01:30 --> Router Class Initialized
INFO - 2023-05-26 06:01:30 --> Loader Class Initialized
INFO - 2023-05-26 06:01:30 --> Output Class Initialized
INFO - 2023-05-26 06:01:30 --> Security Class Initialized
INFO - 2023-05-26 06:01:30 --> Controller Class Initialized
DEBUG - 2023-05-26 06:01:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:01:30 --> Input Class Initialized
INFO - 2023-05-26 06:01:30 --> Language Class Initialized
INFO - 2023-05-26 06:01:30 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:30 --> Loader Class Initialized
INFO - 2023-05-26 06:01:30 --> Controller Class Initialized
INFO - 2023-05-26 06:01:30 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:01:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:01:30 --> Final output sent to browser
INFO - 2023-05-26 06:01:30 --> Final output sent to browser
DEBUG - 2023-05-26 06:01:30 --> Total execution time: 0.3071
DEBUG - 2023-05-26 06:01:30 --> Total execution time: 0.2058
INFO - 2023-05-26 06:01:30 --> Config Class Initialized
INFO - 2023-05-26 06:01:30 --> Config Class Initialized
INFO - 2023-05-26 06:01:30 --> Hooks Class Initialized
INFO - 2023-05-26 06:01:30 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:01:31 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:01:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:01:31 --> Utf8 Class Initialized
INFO - 2023-05-26 06:01:31 --> Utf8 Class Initialized
INFO - 2023-05-26 06:01:31 --> URI Class Initialized
INFO - 2023-05-26 06:01:31 --> URI Class Initialized
INFO - 2023-05-26 06:01:31 --> Router Class Initialized
INFO - 2023-05-26 06:01:31 --> Router Class Initialized
INFO - 2023-05-26 06:01:31 --> Output Class Initialized
INFO - 2023-05-26 06:01:31 --> Output Class Initialized
INFO - 2023-05-26 06:01:31 --> Security Class Initialized
INFO - 2023-05-26 06:01:31 --> Security Class Initialized
DEBUG - 2023-05-26 06:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:01:31 --> Input Class Initialized
INFO - 2023-05-26 06:01:31 --> Input Class Initialized
INFO - 2023-05-26 06:01:31 --> Language Class Initialized
INFO - 2023-05-26 06:01:31 --> Language Class Initialized
INFO - 2023-05-26 06:01:31 --> Loader Class Initialized
INFO - 2023-05-26 06:01:31 --> Controller Class Initialized
INFO - 2023-05-26 06:01:31 --> Loader Class Initialized
DEBUG - 2023-05-26 06:01:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:01:31 --> Controller Class Initialized
DEBUG - 2023-05-26 06:01:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:01:31 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:01:31 --> Final output sent to browser
DEBUG - 2023-05-26 06:01:31 --> Total execution time: 0.1993
INFO - 2023-05-26 06:01:31 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:01:31 --> Final output sent to browser
DEBUG - 2023-05-26 06:01:31 --> Total execution time: 0.4320
INFO - 2023-05-26 06:01:34 --> Config Class Initialized
INFO - 2023-05-26 06:01:34 --> Config Class Initialized
INFO - 2023-05-26 06:01:34 --> Config Class Initialized
INFO - 2023-05-26 06:01:34 --> Hooks Class Initialized
INFO - 2023-05-26 06:01:34 --> Hooks Class Initialized
INFO - 2023-05-26 06:01:34 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:01:34 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:01:34 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:01:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:01:34 --> Utf8 Class Initialized
INFO - 2023-05-26 06:01:34 --> Utf8 Class Initialized
INFO - 2023-05-26 06:01:34 --> Utf8 Class Initialized
INFO - 2023-05-26 06:01:34 --> URI Class Initialized
INFO - 2023-05-26 06:01:34 --> URI Class Initialized
INFO - 2023-05-26 06:01:34 --> URI Class Initialized
INFO - 2023-05-26 06:01:34 --> Router Class Initialized
INFO - 2023-05-26 06:01:34 --> Router Class Initialized
INFO - 2023-05-26 06:01:34 --> Router Class Initialized
INFO - 2023-05-26 06:01:34 --> Output Class Initialized
INFO - 2023-05-26 06:01:34 --> Output Class Initialized
INFO - 2023-05-26 06:01:34 --> Output Class Initialized
INFO - 2023-05-26 06:01:34 --> Security Class Initialized
INFO - 2023-05-26 06:01:34 --> Security Class Initialized
INFO - 2023-05-26 06:01:34 --> Security Class Initialized
DEBUG - 2023-05-26 06:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:01:34 --> Input Class Initialized
INFO - 2023-05-26 06:01:34 --> Input Class Initialized
INFO - 2023-05-26 06:01:34 --> Input Class Initialized
INFO - 2023-05-26 06:01:34 --> Language Class Initialized
INFO - 2023-05-26 06:01:34 --> Language Class Initialized
INFO - 2023-05-26 06:01:34 --> Language Class Initialized
INFO - 2023-05-26 06:01:34 --> Loader Class Initialized
INFO - 2023-05-26 06:01:34 --> Loader Class Initialized
INFO - 2023-05-26 06:01:34 --> Loader Class Initialized
INFO - 2023-05-26 06:01:34 --> Controller Class Initialized
INFO - 2023-05-26 06:01:34 --> Controller Class Initialized
INFO - 2023-05-26 06:01:34 --> Controller Class Initialized
DEBUG - 2023-05-26 06:01:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:01:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:01:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:01:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:01:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:01:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:35 --> Model "Login_model" initialized
INFO - 2023-05-26 06:01:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:01:35 --> Total execution time: 0.2216
INFO - 2023-05-26 06:01:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:01:35 --> Total execution time: 0.2317
INFO - 2023-05-26 06:01:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:01:35 --> Total execution time: 0.2464
INFO - 2023-05-26 06:01:35 --> Config Class Initialized
INFO - 2023-05-26 06:01:35 --> Hooks Class Initialized
INFO - 2023-05-26 06:01:35 --> Config Class Initialized
INFO - 2023-05-26 06:01:35 --> Hooks Class Initialized
INFO - 2023-05-26 06:01:35 --> Config Class Initialized
INFO - 2023-05-26 06:01:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:01:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:01:35 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:01:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:01:35 --> URI Class Initialized
INFO - 2023-05-26 06:01:35 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:01:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:01:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:01:35 --> URI Class Initialized
INFO - 2023-05-26 06:01:35 --> Router Class Initialized
INFO - 2023-05-26 06:01:35 --> URI Class Initialized
INFO - 2023-05-26 06:01:35 --> Router Class Initialized
INFO - 2023-05-26 06:01:35 --> Output Class Initialized
INFO - 2023-05-26 06:01:35 --> Router Class Initialized
INFO - 2023-05-26 06:01:35 --> Security Class Initialized
INFO - 2023-05-26 06:01:35 --> Output Class Initialized
INFO - 2023-05-26 06:01:35 --> Output Class Initialized
INFO - 2023-05-26 06:01:35 --> Security Class Initialized
INFO - 2023-05-26 06:01:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:01:35 --> Input Class Initialized
DEBUG - 2023-05-26 06:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:01:35 --> Input Class Initialized
INFO - 2023-05-26 06:01:35 --> Input Class Initialized
INFO - 2023-05-26 06:01:35 --> Language Class Initialized
INFO - 2023-05-26 06:01:35 --> Language Class Initialized
INFO - 2023-05-26 06:01:35 --> Language Class Initialized
INFO - 2023-05-26 06:01:35 --> Loader Class Initialized
INFO - 2023-05-26 06:01:35 --> Loader Class Initialized
INFO - 2023-05-26 06:01:35 --> Loader Class Initialized
INFO - 2023-05-26 06:01:35 --> Controller Class Initialized
INFO - 2023-05-26 06:01:35 --> Controller Class Initialized
INFO - 2023-05-26 06:01:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:01:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:01:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:01:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:01:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:01:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:01:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:01:35 --> Final output sent to browser
INFO - 2023-05-26 06:01:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:01:35 --> Total execution time: 0.2716
DEBUG - 2023-05-26 06:01:35 --> Total execution time: 0.2599
INFO - 2023-05-26 06:01:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:01:35 --> Total execution time: 0.2639
INFO - 2023-05-26 06:01:35 --> Config Class Initialized
INFO - 2023-05-26 06:01:35 --> Config Class Initialized
INFO - 2023-05-26 06:01:35 --> Hooks Class Initialized
INFO - 2023-05-26 06:01:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:01:35 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:01:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:01:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:01:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:01:35 --> URI Class Initialized
INFO - 2023-05-26 06:01:35 --> URI Class Initialized
INFO - 2023-05-26 06:01:35 --> Router Class Initialized
INFO - 2023-05-26 06:01:35 --> Router Class Initialized
INFO - 2023-05-26 06:01:35 --> Output Class Initialized
INFO - 2023-05-26 06:01:35 --> Output Class Initialized
INFO - 2023-05-26 06:01:35 --> Security Class Initialized
INFO - 2023-05-26 06:01:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:01:35 --> Input Class Initialized
INFO - 2023-05-26 06:01:35 --> Input Class Initialized
INFO - 2023-05-26 06:01:35 --> Language Class Initialized
INFO - 2023-05-26 06:01:35 --> Language Class Initialized
INFO - 2023-05-26 06:01:35 --> Loader Class Initialized
INFO - 2023-05-26 06:01:35 --> Loader Class Initialized
INFO - 2023-05-26 06:01:35 --> Controller Class Initialized
INFO - 2023-05-26 06:01:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:01:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:01:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:01:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:01:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:01:35 --> Model "Login_model" initialized
INFO - 2023-05-26 06:01:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:01:35 --> Total execution time: 0.2341
INFO - 2023-05-26 06:01:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:01:35 --> Total execution time: 0.2447
INFO - 2023-05-26 06:02:35 --> Config Class Initialized
INFO - 2023-05-26 06:02:35 --> Config Class Initialized
INFO - 2023-05-26 06:02:35 --> Hooks Class Initialized
INFO - 2023-05-26 06:02:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:02:35 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:02:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:02:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:02:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:02:35 --> URI Class Initialized
INFO - 2023-05-26 06:02:35 --> URI Class Initialized
INFO - 2023-05-26 06:02:35 --> Router Class Initialized
INFO - 2023-05-26 06:02:35 --> Router Class Initialized
INFO - 2023-05-26 06:02:35 --> Output Class Initialized
INFO - 2023-05-26 06:02:35 --> Output Class Initialized
INFO - 2023-05-26 06:02:35 --> Security Class Initialized
INFO - 2023-05-26 06:02:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:02:35 --> Input Class Initialized
INFO - 2023-05-26 06:02:35 --> Input Class Initialized
INFO - 2023-05-26 06:02:35 --> Language Class Initialized
INFO - 2023-05-26 06:02:35 --> Language Class Initialized
INFO - 2023-05-26 06:02:35 --> Loader Class Initialized
INFO - 2023-05-26 06:02:35 --> Loader Class Initialized
INFO - 2023-05-26 06:02:35 --> Controller Class Initialized
INFO - 2023-05-26 06:02:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:02:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:02:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:02:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:02:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:02:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:35 --> Model "Login_model" initialized
INFO - 2023-05-26 06:02:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:02:35 --> Total execution time: 0.2089
INFO - 2023-05-26 06:02:35 --> Config Class Initialized
INFO - 2023-05-26 06:02:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:02:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:02:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:02:35 --> URI Class Initialized
INFO - 2023-05-26 06:02:35 --> Router Class Initialized
INFO - 2023-05-26 06:02:35 --> Output Class Initialized
INFO - 2023-05-26 06:02:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:02:35 --> Input Class Initialized
INFO - 2023-05-26 06:02:35 --> Language Class Initialized
INFO - 2023-05-26 06:02:35 --> Loader Class Initialized
INFO - 2023-05-26 06:02:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:02:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:02:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:02:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:02:35 --> Total execution time: 0.2438
INFO - 2023-05-26 06:02:46 --> Final output sent to browser
DEBUG - 2023-05-26 06:02:46 --> Total execution time: 10.9289
INFO - 2023-05-26 06:02:46 --> Config Class Initialized
INFO - 2023-05-26 06:02:46 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:02:46 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:02:46 --> Utf8 Class Initialized
INFO - 2023-05-26 06:02:46 --> URI Class Initialized
INFO - 2023-05-26 06:02:46 --> Router Class Initialized
INFO - 2023-05-26 06:02:46 --> Output Class Initialized
INFO - 2023-05-26 06:02:46 --> Security Class Initialized
DEBUG - 2023-05-26 06:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:02:46 --> Input Class Initialized
INFO - 2023-05-26 06:02:46 --> Language Class Initialized
INFO - 2023-05-26 06:02:46 --> Loader Class Initialized
INFO - 2023-05-26 06:02:46 --> Controller Class Initialized
DEBUG - 2023-05-26 06:02:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:02:46 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:46 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:02:46 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:46 --> Model "Login_model" initialized
INFO - 2023-05-26 06:02:50 --> Config Class Initialized
INFO - 2023-05-26 06:02:50 --> Config Class Initialized
INFO - 2023-05-26 06:02:50 --> Hooks Class Initialized
INFO - 2023-05-26 06:02:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:02:50 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:02:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:02:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:02:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:02:50 --> URI Class Initialized
INFO - 2023-05-26 06:02:50 --> URI Class Initialized
INFO - 2023-05-26 06:02:50 --> Router Class Initialized
INFO - 2023-05-26 06:02:50 --> Router Class Initialized
INFO - 2023-05-26 06:02:50 --> Output Class Initialized
INFO - 2023-05-26 06:02:50 --> Output Class Initialized
INFO - 2023-05-26 06:02:50 --> Security Class Initialized
INFO - 2023-05-26 06:02:50 --> Security Class Initialized
DEBUG - 2023-05-26 06:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:02:50 --> Input Class Initialized
INFO - 2023-05-26 06:02:50 --> Input Class Initialized
INFO - 2023-05-26 06:02:50 --> Language Class Initialized
INFO - 2023-05-26 06:02:50 --> Language Class Initialized
INFO - 2023-05-26 06:02:50 --> Loader Class Initialized
INFO - 2023-05-26 06:02:50 --> Loader Class Initialized
INFO - 2023-05-26 06:02:50 --> Controller Class Initialized
INFO - 2023-05-26 06:02:50 --> Controller Class Initialized
DEBUG - 2023-05-26 06:02:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:02:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:02:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:02:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:50 --> Model "Login_model" initialized
INFO - 2023-05-26 06:02:50 --> Final output sent to browser
INFO - 2023-05-26 06:02:50 --> Final output sent to browser
DEBUG - 2023-05-26 06:02:50 --> Total execution time: 0.3036
DEBUG - 2023-05-26 06:02:50 --> Total execution time: 0.3072
INFO - 2023-05-26 06:02:50 --> Config Class Initialized
INFO - 2023-05-26 06:02:50 --> Config Class Initialized
INFO - 2023-05-26 06:02:50 --> Hooks Class Initialized
INFO - 2023-05-26 06:02:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:02:50 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:02:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:02:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:02:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:02:50 --> URI Class Initialized
INFO - 2023-05-26 06:02:50 --> URI Class Initialized
INFO - 2023-05-26 06:02:50 --> Router Class Initialized
INFO - 2023-05-26 06:02:50 --> Router Class Initialized
INFO - 2023-05-26 06:02:50 --> Output Class Initialized
INFO - 2023-05-26 06:02:50 --> Output Class Initialized
INFO - 2023-05-26 06:02:50 --> Security Class Initialized
INFO - 2023-05-26 06:02:50 --> Security Class Initialized
DEBUG - 2023-05-26 06:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:02:50 --> Input Class Initialized
INFO - 2023-05-26 06:02:50 --> Input Class Initialized
INFO - 2023-05-26 06:02:50 --> Language Class Initialized
INFO - 2023-05-26 06:02:50 --> Language Class Initialized
INFO - 2023-05-26 06:02:50 --> Loader Class Initialized
INFO - 2023-05-26 06:02:50 --> Loader Class Initialized
INFO - 2023-05-26 06:02:50 --> Controller Class Initialized
INFO - 2023-05-26 06:02:50 --> Controller Class Initialized
DEBUG - 2023-05-26 06:02:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:02:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:02:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:02:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:02:50 --> Final output sent to browser
DEBUG - 2023-05-26 06:02:50 --> Total execution time: 0.2512
INFO - 2023-05-26 06:02:50 --> Final output sent to browser
DEBUG - 2023-05-26 06:02:50 --> Total execution time: 0.2604
INFO - 2023-05-26 06:02:50 --> Config Class Initialized
INFO - 2023-05-26 06:02:50 --> Config Class Initialized
INFO - 2023-05-26 06:02:50 --> Hooks Class Initialized
INFO - 2023-05-26 06:02:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:02:50 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:02:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:02:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:02:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:02:50 --> URI Class Initialized
INFO - 2023-05-26 06:02:50 --> URI Class Initialized
INFO - 2023-05-26 06:02:50 --> Router Class Initialized
INFO - 2023-05-26 06:02:50 --> Router Class Initialized
INFO - 2023-05-26 06:02:50 --> Output Class Initialized
INFO - 2023-05-26 06:02:50 --> Output Class Initialized
INFO - 2023-05-26 06:02:50 --> Security Class Initialized
INFO - 2023-05-26 06:02:50 --> Security Class Initialized
DEBUG - 2023-05-26 06:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:02:50 --> Config Class Initialized
INFO - 2023-05-26 06:02:50 --> Input Class Initialized
INFO - 2023-05-26 06:02:50 --> Input Class Initialized
INFO - 2023-05-26 06:02:50 --> Hooks Class Initialized
INFO - 2023-05-26 06:02:50 --> Language Class Initialized
INFO - 2023-05-26 06:02:50 --> Language Class Initialized
INFO - 2023-05-26 06:02:50 --> Loader Class Initialized
INFO - 2023-05-26 06:02:50 --> Loader Class Initialized
INFO - 2023-05-26 06:02:51 --> Controller Class Initialized
INFO - 2023-05-26 06:02:51 --> Controller Class Initialized
DEBUG - 2023-05-26 06:02:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:02:51 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:02:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:02:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:02:51 --> URI Class Initialized
INFO - 2023-05-26 06:02:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:51 --> Router Class Initialized
INFO - 2023-05-26 06:02:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:51 --> Output Class Initialized
INFO - 2023-05-26 06:02:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:51 --> Security Class Initialized
INFO - 2023-05-26 06:02:51 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:02:51 --> Input Class Initialized
INFO - 2023-05-26 06:02:51 --> Model "Login_model" initialized
INFO - 2023-05-26 06:02:51 --> Language Class Initialized
INFO - 2023-05-26 06:02:51 --> Final output sent to browser
DEBUG - 2023-05-26 06:02:51 --> Total execution time: 0.2762
INFO - 2023-05-26 06:02:51 --> Final output sent to browser
DEBUG - 2023-05-26 06:02:51 --> Total execution time: 0.2933
INFO - 2023-05-26 06:02:51 --> Loader Class Initialized
INFO - 2023-05-26 06:02:51 --> Controller Class Initialized
DEBUG - 2023-05-26 06:02:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:02:51 --> Config Class Initialized
INFO - 2023-05-26 06:02:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:02:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:02:51 --> Utf8 Class Initialized
INFO - 2023-05-26 06:02:51 --> URI Class Initialized
INFO - 2023-05-26 06:02:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:51 --> Router Class Initialized
INFO - 2023-05-26 06:02:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:02:51 --> Output Class Initialized
INFO - 2023-05-26 06:02:51 --> Security Class Initialized
DEBUG - 2023-05-26 06:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:02:51 --> Input Class Initialized
INFO - 2023-05-26 06:02:51 --> Final output sent to browser
DEBUG - 2023-05-26 06:02:51 --> Total execution time: 0.4219
INFO - 2023-05-26 06:02:51 --> Language Class Initialized
INFO - 2023-05-26 06:02:51 --> Loader Class Initialized
INFO - 2023-05-26 06:02:51 --> Controller Class Initialized
DEBUG - 2023-05-26 06:02:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:02:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:02:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:02:51 --> Final output sent to browser
DEBUG - 2023-05-26 06:02:51 --> Total execution time: 0.3119
INFO - 2023-05-26 06:02:54 --> Final output sent to browser
DEBUG - 2023-05-26 06:02:54 --> Total execution time: 8.5075
INFO - 2023-05-26 06:03:50 --> Config Class Initialized
INFO - 2023-05-26 06:03:50 --> Config Class Initialized
INFO - 2023-05-26 06:03:50 --> Hooks Class Initialized
INFO - 2023-05-26 06:03:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:03:50 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:03:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:03:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:03:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:03:50 --> URI Class Initialized
INFO - 2023-05-26 06:03:50 --> URI Class Initialized
INFO - 2023-05-26 06:03:50 --> Router Class Initialized
INFO - 2023-05-26 06:03:50 --> Router Class Initialized
INFO - 2023-05-26 06:03:50 --> Output Class Initialized
INFO - 2023-05-26 06:03:50 --> Output Class Initialized
INFO - 2023-05-26 06:03:50 --> Security Class Initialized
INFO - 2023-05-26 06:03:50 --> Security Class Initialized
DEBUG - 2023-05-26 06:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:03:50 --> Input Class Initialized
INFO - 2023-05-26 06:03:50 --> Input Class Initialized
INFO - 2023-05-26 06:03:50 --> Language Class Initialized
INFO - 2023-05-26 06:03:50 --> Language Class Initialized
INFO - 2023-05-26 06:03:50 --> Loader Class Initialized
INFO - 2023-05-26 06:03:50 --> Loader Class Initialized
INFO - 2023-05-26 06:03:50 --> Controller Class Initialized
INFO - 2023-05-26 06:03:50 --> Controller Class Initialized
DEBUG - 2023-05-26 06:03:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:03:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:03:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:03:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:03:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:03:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:03:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:03:50 --> Model "Login_model" initialized
INFO - 2023-05-26 06:03:50 --> Final output sent to browser
DEBUG - 2023-05-26 06:03:50 --> Total execution time: 0.2145
INFO - 2023-05-26 06:03:50 --> Config Class Initialized
INFO - 2023-05-26 06:03:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:03:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:03:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:03:50 --> URI Class Initialized
INFO - 2023-05-26 06:03:50 --> Router Class Initialized
INFO - 2023-05-26 06:03:50 --> Output Class Initialized
INFO - 2023-05-26 06:03:50 --> Security Class Initialized
DEBUG - 2023-05-26 06:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:03:50 --> Input Class Initialized
INFO - 2023-05-26 06:03:50 --> Language Class Initialized
INFO - 2023-05-26 06:03:50 --> Loader Class Initialized
INFO - 2023-05-26 06:03:50 --> Controller Class Initialized
DEBUG - 2023-05-26 06:03:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:03:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:03:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:03:51 --> Final output sent to browser
DEBUG - 2023-05-26 06:03:51 --> Total execution time: 0.3583
INFO - 2023-05-26 06:04:00 --> Final output sent to browser
DEBUG - 2023-05-26 06:04:00 --> Total execution time: 9.7732
INFO - 2023-05-26 06:04:00 --> Config Class Initialized
INFO - 2023-05-26 06:04:00 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:04:00 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:04:00 --> Utf8 Class Initialized
INFO - 2023-05-26 06:04:00 --> URI Class Initialized
INFO - 2023-05-26 06:04:00 --> Router Class Initialized
INFO - 2023-05-26 06:04:00 --> Output Class Initialized
INFO - 2023-05-26 06:04:00 --> Security Class Initialized
DEBUG - 2023-05-26 06:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:04:00 --> Input Class Initialized
INFO - 2023-05-26 06:04:00 --> Language Class Initialized
INFO - 2023-05-26 06:04:00 --> Loader Class Initialized
INFO - 2023-05-26 06:04:00 --> Controller Class Initialized
DEBUG - 2023-05-26 06:04:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:04:00 --> Database Driver Class Initialized
INFO - 2023-05-26 06:04:00 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:04:00 --> Database Driver Class Initialized
INFO - 2023-05-26 06:04:00 --> Model "Login_model" initialized
INFO - 2023-05-26 06:04:09 --> Final output sent to browser
DEBUG - 2023-05-26 06:04:09 --> Total execution time: 8.8699
INFO - 2023-05-26 06:04:50 --> Config Class Initialized
INFO - 2023-05-26 06:04:50 --> Config Class Initialized
INFO - 2023-05-26 06:04:50 --> Hooks Class Initialized
INFO - 2023-05-26 06:04:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:04:50 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:04:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:04:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:04:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:04:50 --> URI Class Initialized
INFO - 2023-05-26 06:04:50 --> URI Class Initialized
INFO - 2023-05-26 06:04:50 --> Router Class Initialized
INFO - 2023-05-26 06:04:50 --> Router Class Initialized
INFO - 2023-05-26 06:04:50 --> Output Class Initialized
INFO - 2023-05-26 06:04:50 --> Output Class Initialized
INFO - 2023-05-26 06:04:50 --> Security Class Initialized
INFO - 2023-05-26 06:04:50 --> Security Class Initialized
DEBUG - 2023-05-26 06:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:04:50 --> Input Class Initialized
INFO - 2023-05-26 06:04:50 --> Input Class Initialized
INFO - 2023-05-26 06:04:50 --> Language Class Initialized
INFO - 2023-05-26 06:04:50 --> Language Class Initialized
INFO - 2023-05-26 06:04:50 --> Loader Class Initialized
INFO - 2023-05-26 06:04:50 --> Loader Class Initialized
INFO - 2023-05-26 06:04:50 --> Controller Class Initialized
DEBUG - 2023-05-26 06:04:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:04:50 --> Controller Class Initialized
DEBUG - 2023-05-26 06:04:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:04:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:04:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:04:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:04:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:04:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:04:50 --> Model "Login_model" initialized
INFO - 2023-05-26 06:04:50 --> Final output sent to browser
DEBUG - 2023-05-26 06:04:50 --> Total execution time: 0.2977
INFO - 2023-05-26 06:04:50 --> Config Class Initialized
INFO - 2023-05-26 06:04:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:04:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:04:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:04:50 --> URI Class Initialized
INFO - 2023-05-26 06:04:50 --> Router Class Initialized
INFO - 2023-05-26 06:04:50 --> Output Class Initialized
INFO - 2023-05-26 06:04:50 --> Security Class Initialized
DEBUG - 2023-05-26 06:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:04:50 --> Input Class Initialized
INFO - 2023-05-26 06:04:50 --> Language Class Initialized
INFO - 2023-05-26 06:04:50 --> Loader Class Initialized
INFO - 2023-05-26 06:04:50 --> Controller Class Initialized
DEBUG - 2023-05-26 06:04:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:04:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:04:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:04:51 --> Final output sent to browser
DEBUG - 2023-05-26 06:04:51 --> Total execution time: 0.3076
INFO - 2023-05-26 06:05:00 --> Final output sent to browser
DEBUG - 2023-05-26 06:05:00 --> Total execution time: 9.6317
INFO - 2023-05-26 06:05:00 --> Config Class Initialized
INFO - 2023-05-26 06:05:00 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:05:00 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:05:00 --> Utf8 Class Initialized
INFO - 2023-05-26 06:05:00 --> URI Class Initialized
INFO - 2023-05-26 06:05:00 --> Router Class Initialized
INFO - 2023-05-26 06:05:00 --> Output Class Initialized
INFO - 2023-05-26 06:05:00 --> Security Class Initialized
DEBUG - 2023-05-26 06:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:05:00 --> Input Class Initialized
INFO - 2023-05-26 06:05:00 --> Language Class Initialized
INFO - 2023-05-26 06:05:00 --> Loader Class Initialized
INFO - 2023-05-26 06:05:00 --> Controller Class Initialized
DEBUG - 2023-05-26 06:05:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:05:00 --> Database Driver Class Initialized
INFO - 2023-05-26 06:05:00 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:05:00 --> Database Driver Class Initialized
INFO - 2023-05-26 06:05:00 --> Model "Login_model" initialized
INFO - 2023-05-26 06:05:13 --> Final output sent to browser
DEBUG - 2023-05-26 06:05:13 --> Total execution time: 13.4168
INFO - 2023-05-26 06:05:50 --> Config Class Initialized
INFO - 2023-05-26 06:05:50 --> Config Class Initialized
INFO - 2023-05-26 06:05:50 --> Hooks Class Initialized
INFO - 2023-05-26 06:05:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:05:50 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:05:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:05:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:05:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:05:50 --> URI Class Initialized
INFO - 2023-05-26 06:05:50 --> URI Class Initialized
INFO - 2023-05-26 06:05:50 --> Router Class Initialized
INFO - 2023-05-26 06:05:50 --> Router Class Initialized
INFO - 2023-05-26 06:05:50 --> Output Class Initialized
INFO - 2023-05-26 06:05:50 --> Output Class Initialized
INFO - 2023-05-26 06:05:50 --> Security Class Initialized
INFO - 2023-05-26 06:05:50 --> Security Class Initialized
DEBUG - 2023-05-26 06:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:05:50 --> Input Class Initialized
INFO - 2023-05-26 06:05:50 --> Input Class Initialized
INFO - 2023-05-26 06:05:50 --> Language Class Initialized
INFO - 2023-05-26 06:05:50 --> Language Class Initialized
INFO - 2023-05-26 06:05:50 --> Loader Class Initialized
INFO - 2023-05-26 06:05:50 --> Loader Class Initialized
INFO - 2023-05-26 06:05:50 --> Controller Class Initialized
DEBUG - 2023-05-26 06:05:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:05:50 --> Controller Class Initialized
DEBUG - 2023-05-26 06:05:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:05:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:05:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:05:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:05:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:05:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:05:50 --> Model "Login_model" initialized
INFO - 2023-05-26 06:05:50 --> Final output sent to browser
DEBUG - 2023-05-26 06:05:50 --> Total execution time: 0.2132
INFO - 2023-05-26 06:05:50 --> Config Class Initialized
INFO - 2023-05-26 06:05:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:05:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:05:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:05:50 --> URI Class Initialized
INFO - 2023-05-26 06:05:50 --> Router Class Initialized
INFO - 2023-05-26 06:05:50 --> Output Class Initialized
INFO - 2023-05-26 06:05:50 --> Security Class Initialized
DEBUG - 2023-05-26 06:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:05:50 --> Input Class Initialized
INFO - 2023-05-26 06:05:50 --> Language Class Initialized
INFO - 2023-05-26 06:05:50 --> Loader Class Initialized
INFO - 2023-05-26 06:05:50 --> Controller Class Initialized
DEBUG - 2023-05-26 06:05:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:05:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:05:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:05:50 --> Final output sent to browser
DEBUG - 2023-05-26 06:05:50 --> Total execution time: 0.3145
INFO - 2023-05-26 06:06:03 --> Final output sent to browser
DEBUG - 2023-05-26 06:06:03 --> Total execution time: 12.6304
INFO - 2023-05-26 06:06:03 --> Config Class Initialized
INFO - 2023-05-26 06:06:03 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:06:03 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:06:03 --> Utf8 Class Initialized
INFO - 2023-05-26 06:06:03 --> URI Class Initialized
INFO - 2023-05-26 06:06:03 --> Router Class Initialized
INFO - 2023-05-26 06:06:03 --> Output Class Initialized
INFO - 2023-05-26 06:06:03 --> Security Class Initialized
DEBUG - 2023-05-26 06:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:06:03 --> Input Class Initialized
INFO - 2023-05-26 06:06:03 --> Language Class Initialized
INFO - 2023-05-26 06:06:03 --> Loader Class Initialized
INFO - 2023-05-26 06:06:03 --> Controller Class Initialized
DEBUG - 2023-05-26 06:06:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:06:03 --> Database Driver Class Initialized
INFO - 2023-05-26 06:06:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:06:03 --> Database Driver Class Initialized
INFO - 2023-05-26 06:06:03 --> Model "Login_model" initialized
INFO - 2023-05-26 06:06:17 --> Final output sent to browser
DEBUG - 2023-05-26 06:06:17 --> Total execution time: 14.5227
INFO - 2023-05-26 06:06:25 --> Config Class Initialized
INFO - 2023-05-26 06:06:25 --> Config Class Initialized
INFO - 2023-05-26 06:06:25 --> Hooks Class Initialized
INFO - 2023-05-26 06:06:25 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:06:25 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:06:25 --> Config Class Initialized
DEBUG - 2023-05-26 06:06:25 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:06:25 --> Utf8 Class Initialized
INFO - 2023-05-26 06:06:25 --> Utf8 Class Initialized
INFO - 2023-05-26 06:06:25 --> Hooks Class Initialized
INFO - 2023-05-26 06:06:25 --> URI Class Initialized
INFO - 2023-05-26 06:06:25 --> URI Class Initialized
INFO - 2023-05-26 06:06:25 --> Router Class Initialized
INFO - 2023-05-26 06:06:25 --> Router Class Initialized
INFO - 2023-05-26 06:06:25 --> Output Class Initialized
INFO - 2023-05-26 06:06:25 --> Output Class Initialized
INFO - 2023-05-26 06:06:25 --> Security Class Initialized
DEBUG - 2023-05-26 06:06:25 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:06:25 --> Security Class Initialized
INFO - 2023-05-26 06:06:25 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:06:25 --> Input Class Initialized
INFO - 2023-05-26 06:06:25 --> Input Class Initialized
INFO - 2023-05-26 06:06:25 --> URI Class Initialized
INFO - 2023-05-26 06:06:25 --> Language Class Initialized
INFO - 2023-05-26 06:06:25 --> Language Class Initialized
INFO - 2023-05-26 06:06:25 --> Router Class Initialized
INFO - 2023-05-26 06:06:25 --> Loader Class Initialized
INFO - 2023-05-26 06:06:25 --> Loader Class Initialized
INFO - 2023-05-26 06:06:25 --> Output Class Initialized
INFO - 2023-05-26 06:06:25 --> Controller Class Initialized
INFO - 2023-05-26 06:06:25 --> Controller Class Initialized
DEBUG - 2023-05-26 06:06:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:06:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:06:25 --> Security Class Initialized
DEBUG - 2023-05-26 06:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:06:25 --> Input Class Initialized
INFO - 2023-05-26 06:06:25 --> Database Driver Class Initialized
INFO - 2023-05-26 06:06:25 --> Database Driver Class Initialized
INFO - 2023-05-26 06:06:25 --> Language Class Initialized
INFO - 2023-05-26 06:06:25 --> Loader Class Initialized
INFO - 2023-05-26 06:06:25 --> Controller Class Initialized
DEBUG - 2023-05-26 06:06:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:06:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:06:25 --> Database Driver Class Initialized
INFO - 2023-05-26 06:06:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:06:25 --> Final output sent to browser
INFO - 2023-05-26 06:06:25 --> Database Driver Class Initialized
DEBUG - 2023-05-26 06:06:25 --> Total execution time: 0.6970
INFO - 2023-05-26 06:06:25 --> Final output sent to browser
DEBUG - 2023-05-26 06:06:25 --> Total execution time: 0.7066
INFO - 2023-05-26 06:06:26 --> Model "Login_model" initialized
INFO - 2023-05-26 06:06:26 --> Final output sent to browser
DEBUG - 2023-05-26 06:06:26 --> Total execution time: 0.7285
INFO - 2023-05-26 06:06:26 --> Config Class Initialized
INFO - 2023-05-26 06:06:26 --> Config Class Initialized
INFO - 2023-05-26 06:06:26 --> Hooks Class Initialized
INFO - 2023-05-26 06:06:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:06:26 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:06:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:06:26 --> Utf8 Class Initialized
INFO - 2023-05-26 06:06:26 --> Utf8 Class Initialized
INFO - 2023-05-26 06:06:26 --> URI Class Initialized
INFO - 2023-05-26 06:06:26 --> URI Class Initialized
INFO - 2023-05-26 06:06:26 --> Config Class Initialized
INFO - 2023-05-26 06:06:26 --> Hooks Class Initialized
INFO - 2023-05-26 06:06:26 --> Router Class Initialized
INFO - 2023-05-26 06:06:26 --> Router Class Initialized
INFO - 2023-05-26 06:06:26 --> Output Class Initialized
INFO - 2023-05-26 06:06:26 --> Output Class Initialized
INFO - 2023-05-26 06:06:26 --> Security Class Initialized
INFO - 2023-05-26 06:06:26 --> Security Class Initialized
DEBUG - 2023-05-26 06:06:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:06:26 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:06:26 --> Input Class Initialized
INFO - 2023-05-26 06:06:26 --> Input Class Initialized
INFO - 2023-05-26 06:06:26 --> URI Class Initialized
INFO - 2023-05-26 06:06:26 --> Language Class Initialized
INFO - 2023-05-26 06:06:26 --> Language Class Initialized
INFO - 2023-05-26 06:06:26 --> Router Class Initialized
INFO - 2023-05-26 06:06:26 --> Config Class Initialized
INFO - 2023-05-26 06:06:26 --> Loader Class Initialized
INFO - 2023-05-26 06:06:26 --> Loader Class Initialized
INFO - 2023-05-26 06:06:26 --> Hooks Class Initialized
INFO - 2023-05-26 06:06:26 --> Output Class Initialized
INFO - 2023-05-26 06:06:26 --> Controller Class Initialized
INFO - 2023-05-26 06:06:26 --> Controller Class Initialized
DEBUG - 2023-05-26 06:06:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:06:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:06:26 --> Security Class Initialized
DEBUG - 2023-05-26 06:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:06:26 --> Input Class Initialized
DEBUG - 2023-05-26 06:06:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:06:26 --> Language Class Initialized
INFO - 2023-05-26 06:06:26 --> Utf8 Class Initialized
INFO - 2023-05-26 06:06:26 --> Database Driver Class Initialized
INFO - 2023-05-26 06:06:26 --> Database Driver Class Initialized
INFO - 2023-05-26 06:06:26 --> URI Class Initialized
INFO - 2023-05-26 06:06:26 --> Loader Class Initialized
INFO - 2023-05-26 06:06:26 --> Router Class Initialized
INFO - 2023-05-26 06:06:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:06:26 --> Controller Class Initialized
INFO - 2023-05-26 06:06:26 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:06:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:06:26 --> Output Class Initialized
INFO - 2023-05-26 06:06:26 --> Security Class Initialized
DEBUG - 2023-05-26 06:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:06:26 --> Input Class Initialized
INFO - 2023-05-26 06:06:26 --> Final output sent to browser
DEBUG - 2023-05-26 06:06:26 --> Total execution time: 0.4009
INFO - 2023-05-26 06:06:26 --> Language Class Initialized
INFO - 2023-05-26 06:06:26 --> Database Driver Class Initialized
INFO - 2023-05-26 06:06:26 --> Final output sent to browser
DEBUG - 2023-05-26 06:06:26 --> Total execution time: 0.4218
INFO - 2023-05-26 06:06:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:06:26 --> Loader Class Initialized
INFO - 2023-05-26 06:06:26 --> Config Class Initialized
INFO - 2023-05-26 06:06:26 --> Hooks Class Initialized
INFO - 2023-05-26 06:06:26 --> Controller Class Initialized
INFO - 2023-05-26 06:06:26 --> Final output sent to browser
DEBUG - 2023-05-26 06:06:26 --> Total execution time: 0.4464
DEBUG - 2023-05-26 06:06:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:06:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:06:26 --> Utf8 Class Initialized
INFO - 2023-05-26 06:06:26 --> URI Class Initialized
INFO - 2023-05-26 06:06:26 --> Database Driver Class Initialized
INFO - 2023-05-26 06:06:26 --> Router Class Initialized
INFO - 2023-05-26 06:06:26 --> Output Class Initialized
INFO - 2023-05-26 06:06:26 --> Security Class Initialized
DEBUG - 2023-05-26 06:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:06:26 --> Input Class Initialized
INFO - 2023-05-26 06:06:26 --> Language Class Initialized
INFO - 2023-05-26 06:06:26 --> Database Driver Class Initialized
INFO - 2023-05-26 06:06:26 --> Model "Login_model" initialized
INFO - 2023-05-26 06:06:26 --> Loader Class Initialized
INFO - 2023-05-26 06:06:26 --> Final output sent to browser
DEBUG - 2023-05-26 06:06:26 --> Total execution time: 0.5290
INFO - 2023-05-26 06:06:26 --> Controller Class Initialized
DEBUG - 2023-05-26 06:06:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:06:26 --> Database Driver Class Initialized
INFO - 2023-05-26 06:06:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:06:26 --> Final output sent to browser
DEBUG - 2023-05-26 06:06:26 --> Total execution time: 0.3709
INFO - 2023-05-26 06:07:25 --> Config Class Initialized
INFO - 2023-05-26 06:07:25 --> Config Class Initialized
INFO - 2023-05-26 06:07:25 --> Hooks Class Initialized
INFO - 2023-05-26 06:07:25 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:07:25 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:07:25 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:07:25 --> Utf8 Class Initialized
INFO - 2023-05-26 06:07:25 --> Utf8 Class Initialized
INFO - 2023-05-26 06:07:25 --> URI Class Initialized
INFO - 2023-05-26 06:07:25 --> URI Class Initialized
INFO - 2023-05-26 06:07:25 --> Router Class Initialized
INFO - 2023-05-26 06:07:25 --> Router Class Initialized
INFO - 2023-05-26 06:07:25 --> Output Class Initialized
INFO - 2023-05-26 06:07:25 --> Output Class Initialized
INFO - 2023-05-26 06:07:25 --> Security Class Initialized
INFO - 2023-05-26 06:07:25 --> Security Class Initialized
DEBUG - 2023-05-26 06:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:07:25 --> Input Class Initialized
INFO - 2023-05-26 06:07:25 --> Input Class Initialized
INFO - 2023-05-26 06:07:25 --> Language Class Initialized
INFO - 2023-05-26 06:07:25 --> Language Class Initialized
INFO - 2023-05-26 06:07:25 --> Loader Class Initialized
INFO - 2023-05-26 06:07:25 --> Loader Class Initialized
INFO - 2023-05-26 06:07:25 --> Controller Class Initialized
INFO - 2023-05-26 06:07:25 --> Controller Class Initialized
DEBUG - 2023-05-26 06:07:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:07:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:07:25 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:25 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:07:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:07:25 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:25 --> Final output sent to browser
INFO - 2023-05-26 06:07:25 --> Model "Login_model" initialized
DEBUG - 2023-05-26 06:07:25 --> Total execution time: 0.5124
INFO - 2023-05-26 06:07:26 --> Config Class Initialized
INFO - 2023-05-26 06:07:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:07:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:07:26 --> Utf8 Class Initialized
INFO - 2023-05-26 06:07:26 --> URI Class Initialized
INFO - 2023-05-26 06:07:26 --> Router Class Initialized
INFO - 2023-05-26 06:07:26 --> Output Class Initialized
INFO - 2023-05-26 06:07:26 --> Security Class Initialized
DEBUG - 2023-05-26 06:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:07:26 --> Input Class Initialized
INFO - 2023-05-26 06:07:26 --> Language Class Initialized
INFO - 2023-05-26 06:07:26 --> Loader Class Initialized
INFO - 2023-05-26 06:07:26 --> Controller Class Initialized
DEBUG - 2023-05-26 06:07:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:07:26 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:07:26 --> Final output sent to browser
DEBUG - 2023-05-26 06:07:26 --> Total execution time: 0.7977
INFO - 2023-05-26 06:07:34 --> Config Class Initialized
INFO - 2023-05-26 06:07:34 --> Hooks Class Initialized
INFO - 2023-05-26 06:07:34 --> Config Class Initialized
INFO - 2023-05-26 06:07:34 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:07:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:07:34 --> Utf8 Class Initialized
INFO - 2023-05-26 06:07:34 --> URI Class Initialized
DEBUG - 2023-05-26 06:07:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:07:34 --> Router Class Initialized
INFO - 2023-05-26 06:07:34 --> Utf8 Class Initialized
INFO - 2023-05-26 06:07:34 --> URI Class Initialized
INFO - 2023-05-26 06:07:35 --> Output Class Initialized
INFO - 2023-05-26 06:07:35 --> Security Class Initialized
INFO - 2023-05-26 06:07:35 --> Router Class Initialized
DEBUG - 2023-05-26 06:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:07:35 --> Output Class Initialized
INFO - 2023-05-26 06:07:35 --> Input Class Initialized
INFO - 2023-05-26 06:07:35 --> Language Class Initialized
INFO - 2023-05-26 06:07:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:07:35 --> Input Class Initialized
INFO - 2023-05-26 06:07:35 --> Language Class Initialized
INFO - 2023-05-26 06:07:35 --> Loader Class Initialized
INFO - 2023-05-26 06:07:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:07:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:07:35 --> Loader Class Initialized
INFO - 2023-05-26 06:07:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:07:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:07:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:35 --> Config Class Initialized
INFO - 2023-05-26 06:07:35 --> Hooks Class Initialized
INFO - 2023-05-26 06:07:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:07:35 --> Model "Login_model" initialized
DEBUG - 2023-05-26 06:07:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:07:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:07:35 --> URI Class Initialized
INFO - 2023-05-26 06:07:35 --> Final output sent to browser
INFO - 2023-05-26 06:07:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:07:35 --> Total execution time: 0.8756
DEBUG - 2023-05-26 06:07:35 --> Total execution time: 0.8872
INFO - 2023-05-26 06:07:35 --> Router Class Initialized
INFO - 2023-05-26 06:07:35 --> Output Class Initialized
INFO - 2023-05-26 06:07:35 --> Config Class Initialized
INFO - 2023-05-26 06:07:35 --> Security Class Initialized
INFO - 2023-05-26 06:07:35 --> Hooks Class Initialized
INFO - 2023-05-26 06:07:35 --> Config Class Initialized
DEBUG - 2023-05-26 06:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:07:35 --> Hooks Class Initialized
INFO - 2023-05-26 06:07:35 --> Input Class Initialized
INFO - 2023-05-26 06:07:35 --> Language Class Initialized
DEBUG - 2023-05-26 06:07:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:07:35 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:07:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:07:35 --> URI Class Initialized
INFO - 2023-05-26 06:07:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:07:35 --> URI Class Initialized
INFO - 2023-05-26 06:07:35 --> Loader Class Initialized
INFO - 2023-05-26 06:07:35 --> Router Class Initialized
INFO - 2023-05-26 06:07:35 --> Router Class Initialized
INFO - 2023-05-26 06:07:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:07:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:07:35 --> Output Class Initialized
INFO - 2023-05-26 06:07:36 --> Output Class Initialized
INFO - 2023-05-26 06:07:36 --> Security Class Initialized
DEBUG - 2023-05-26 06:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:07:36 --> Security Class Initialized
INFO - 2023-05-26 06:07:36 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:36 --> Input Class Initialized
INFO - 2023-05-26 06:07:36 --> Language Class Initialized
DEBUG - 2023-05-26 06:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:07:36 --> Input Class Initialized
INFO - 2023-05-26 06:07:36 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:07:36 --> Language Class Initialized
INFO - 2023-05-26 06:07:36 --> Loader Class Initialized
INFO - 2023-05-26 06:07:36 --> Loader Class Initialized
INFO - 2023-05-26 06:07:36 --> Final output sent to browser
DEBUG - 2023-05-26 06:07:36 --> Total execution time: 0.8728
INFO - 2023-05-26 06:07:36 --> Controller Class Initialized
INFO - 2023-05-26 06:07:36 --> Controller Class Initialized
DEBUG - 2023-05-26 06:07:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:07:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:07:36 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:36 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:36 --> Config Class Initialized
INFO - 2023-05-26 06:07:36 --> Config Class Initialized
INFO - 2023-05-26 06:07:36 --> Hooks Class Initialized
INFO - 2023-05-26 06:07:36 --> Hooks Class Initialized
INFO - 2023-05-26 06:07:36 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:07:36 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:07:36 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:07:36 --> Utf8 Class Initialized
INFO - 2023-05-26 06:07:36 --> Utf8 Class Initialized
INFO - 2023-05-26 06:07:36 --> URI Class Initialized
INFO - 2023-05-26 06:07:36 --> URI Class Initialized
INFO - 2023-05-26 06:07:36 --> Router Class Initialized
INFO - 2023-05-26 06:07:36 --> Final output sent to browser
DEBUG - 2023-05-26 06:07:36 --> Total execution time: 0.8183
INFO - 2023-05-26 06:07:36 --> Router Class Initialized
INFO - 2023-05-26 06:07:36 --> Final output sent to browser
DEBUG - 2023-05-26 06:07:36 --> Total execution time: 0.8675
INFO - 2023-05-26 06:07:36 --> Output Class Initialized
INFO - 2023-05-26 06:07:36 --> Security Class Initialized
INFO - 2023-05-26 06:07:36 --> Output Class Initialized
DEBUG - 2023-05-26 06:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:07:36 --> Input Class Initialized
INFO - 2023-05-26 06:07:36 --> Security Class Initialized
INFO - 2023-05-26 06:07:36 --> Language Class Initialized
DEBUG - 2023-05-26 06:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:07:36 --> Input Class Initialized
INFO - 2023-05-26 06:07:36 --> Language Class Initialized
INFO - 2023-05-26 06:07:36 --> Loader Class Initialized
INFO - 2023-05-26 06:07:36 --> Config Class Initialized
INFO - 2023-05-26 06:07:36 --> Hooks Class Initialized
INFO - 2023-05-26 06:07:36 --> Loader Class Initialized
INFO - 2023-05-26 06:07:36 --> Controller Class Initialized
DEBUG - 2023-05-26 06:07:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:07:36 --> Controller Class Initialized
DEBUG - 2023-05-26 06:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:07:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:07:36 --> Utf8 Class Initialized
INFO - 2023-05-26 06:07:36 --> URI Class Initialized
INFO - 2023-05-26 06:07:36 --> Router Class Initialized
INFO - 2023-05-26 06:07:37 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:37 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:37 --> Output Class Initialized
INFO - 2023-05-26 06:07:37 --> Security Class Initialized
INFO - 2023-05-26 06:07:37 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:07:37 --> Input Class Initialized
INFO - 2023-05-26 06:07:37 --> Language Class Initialized
INFO - 2023-05-26 06:07:37 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:37 --> Final output sent to browser
DEBUG - 2023-05-26 06:07:37 --> Total execution time: 0.7238
INFO - 2023-05-26 06:07:37 --> Model "Login_model" initialized
INFO - 2023-05-26 06:07:37 --> Loader Class Initialized
INFO - 2023-05-26 06:07:37 --> Final output sent to browser
DEBUG - 2023-05-26 06:07:37 --> Total execution time: 0.7690
INFO - 2023-05-26 06:07:37 --> Controller Class Initialized
DEBUG - 2023-05-26 06:07:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:07:37 --> Database Driver Class Initialized
INFO - 2023-05-26 06:07:37 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:07:37 --> Final output sent to browser
DEBUG - 2023-05-26 06:07:37 --> Total execution time: 0.6693
INFO - 2023-05-26 06:07:41 --> Final output sent to browser
DEBUG - 2023-05-26 06:07:41 --> Total execution time: 15.8974
INFO - 2023-05-26 06:08:35 --> Config Class Initialized
INFO - 2023-05-26 06:08:35 --> Config Class Initialized
INFO - 2023-05-26 06:08:35 --> Hooks Class Initialized
INFO - 2023-05-26 06:08:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:08:35 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:08:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:08:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:08:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:08:35 --> URI Class Initialized
INFO - 2023-05-26 06:08:35 --> URI Class Initialized
INFO - 2023-05-26 06:08:35 --> Router Class Initialized
INFO - 2023-05-26 06:08:35 --> Router Class Initialized
INFO - 2023-05-26 06:08:35 --> Output Class Initialized
INFO - 2023-05-26 06:08:35 --> Output Class Initialized
INFO - 2023-05-26 06:08:35 --> Security Class Initialized
INFO - 2023-05-26 06:08:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:08:35 --> Input Class Initialized
INFO - 2023-05-26 06:08:35 --> Input Class Initialized
INFO - 2023-05-26 06:08:35 --> Language Class Initialized
INFO - 2023-05-26 06:08:35 --> Language Class Initialized
INFO - 2023-05-26 06:08:35 --> Loader Class Initialized
INFO - 2023-05-26 06:08:35 --> Loader Class Initialized
INFO - 2023-05-26 06:08:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:08:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:08:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:08:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:08:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:08:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:08:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:08:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:08:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:08:35 --> Model "Login_model" initialized
INFO - 2023-05-26 06:08:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:08:35 --> Total execution time: 0.2002
INFO - 2023-05-26 06:08:35 --> Config Class Initialized
INFO - 2023-05-26 06:08:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:08:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:08:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:08:35 --> URI Class Initialized
INFO - 2023-05-26 06:08:35 --> Router Class Initialized
INFO - 2023-05-26 06:08:35 --> Output Class Initialized
INFO - 2023-05-26 06:08:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:08:35 --> Input Class Initialized
INFO - 2023-05-26 06:08:35 --> Language Class Initialized
INFO - 2023-05-26 06:08:35 --> Loader Class Initialized
INFO - 2023-05-26 06:08:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:08:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:08:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:08:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:08:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:08:35 --> Total execution time: 0.2725
INFO - 2023-05-26 06:08:45 --> Final output sent to browser
DEBUG - 2023-05-26 06:08:45 --> Total execution time: 10.0916
INFO - 2023-05-26 06:08:45 --> Config Class Initialized
INFO - 2023-05-26 06:08:45 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:08:45 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:08:45 --> Utf8 Class Initialized
INFO - 2023-05-26 06:08:45 --> URI Class Initialized
INFO - 2023-05-26 06:08:45 --> Router Class Initialized
INFO - 2023-05-26 06:08:45 --> Output Class Initialized
INFO - 2023-05-26 06:08:45 --> Security Class Initialized
DEBUG - 2023-05-26 06:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:08:45 --> Input Class Initialized
INFO - 2023-05-26 06:08:45 --> Language Class Initialized
INFO - 2023-05-26 06:08:45 --> Loader Class Initialized
INFO - 2023-05-26 06:08:45 --> Controller Class Initialized
DEBUG - 2023-05-26 06:08:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:08:45 --> Database Driver Class Initialized
INFO - 2023-05-26 06:08:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:08:45 --> Database Driver Class Initialized
INFO - 2023-05-26 06:08:45 --> Model "Login_model" initialized
INFO - 2023-05-26 06:08:55 --> Final output sent to browser
DEBUG - 2023-05-26 06:08:55 --> Total execution time: 9.5190
INFO - 2023-05-26 06:09:35 --> Config Class Initialized
INFO - 2023-05-26 06:09:35 --> Config Class Initialized
INFO - 2023-05-26 06:09:35 --> Hooks Class Initialized
INFO - 2023-05-26 06:09:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:09:35 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:09:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:09:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:09:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:09:35 --> URI Class Initialized
INFO - 2023-05-26 06:09:35 --> URI Class Initialized
INFO - 2023-05-26 06:09:35 --> Router Class Initialized
INFO - 2023-05-26 06:09:35 --> Router Class Initialized
INFO - 2023-05-26 06:09:35 --> Output Class Initialized
INFO - 2023-05-26 06:09:35 --> Output Class Initialized
INFO - 2023-05-26 06:09:35 --> Security Class Initialized
INFO - 2023-05-26 06:09:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:09:35 --> Input Class Initialized
INFO - 2023-05-26 06:09:35 --> Input Class Initialized
INFO - 2023-05-26 06:09:35 --> Language Class Initialized
INFO - 2023-05-26 06:09:35 --> Language Class Initialized
INFO - 2023-05-26 06:09:35 --> Loader Class Initialized
INFO - 2023-05-26 06:09:35 --> Loader Class Initialized
INFO - 2023-05-26 06:09:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:09:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:09:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:09:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:09:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:09:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:09:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:09:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:09:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:09:35 --> Model "Login_model" initialized
INFO - 2023-05-26 06:09:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:09:35 --> Total execution time: 0.1813
INFO - 2023-05-26 06:09:35 --> Config Class Initialized
INFO - 2023-05-26 06:09:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:09:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:09:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:09:35 --> URI Class Initialized
INFO - 2023-05-26 06:09:35 --> Router Class Initialized
INFO - 2023-05-26 06:09:35 --> Output Class Initialized
INFO - 2023-05-26 06:09:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:09:35 --> Input Class Initialized
INFO - 2023-05-26 06:09:35 --> Language Class Initialized
INFO - 2023-05-26 06:09:35 --> Loader Class Initialized
INFO - 2023-05-26 06:09:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:09:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:09:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:09:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:09:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:09:35 --> Total execution time: 0.2244
INFO - 2023-05-26 06:09:46 --> Final output sent to browser
DEBUG - 2023-05-26 06:09:46 --> Total execution time: 11.3973
INFO - 2023-05-26 06:09:46 --> Config Class Initialized
INFO - 2023-05-26 06:09:46 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:09:46 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:09:46 --> Utf8 Class Initialized
INFO - 2023-05-26 06:09:46 --> URI Class Initialized
INFO - 2023-05-26 06:09:46 --> Router Class Initialized
INFO - 2023-05-26 06:09:46 --> Output Class Initialized
INFO - 2023-05-26 06:09:46 --> Security Class Initialized
DEBUG - 2023-05-26 06:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:09:46 --> Input Class Initialized
INFO - 2023-05-26 06:09:46 --> Language Class Initialized
INFO - 2023-05-26 06:09:46 --> Loader Class Initialized
INFO - 2023-05-26 06:09:47 --> Controller Class Initialized
DEBUG - 2023-05-26 06:09:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:09:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:09:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:09:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:09:47 --> Model "Login_model" initialized
INFO - 2023-05-26 06:09:57 --> Final output sent to browser
DEBUG - 2023-05-26 06:09:57 --> Total execution time: 10.5135
INFO - 2023-05-26 06:10:35 --> Config Class Initialized
INFO - 2023-05-26 06:10:35 --> Config Class Initialized
INFO - 2023-05-26 06:10:35 --> Hooks Class Initialized
INFO - 2023-05-26 06:10:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:10:35 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:10:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:10:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:10:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:10:35 --> URI Class Initialized
INFO - 2023-05-26 06:10:35 --> URI Class Initialized
INFO - 2023-05-26 06:10:35 --> Router Class Initialized
INFO - 2023-05-26 06:10:35 --> Router Class Initialized
INFO - 2023-05-26 06:10:35 --> Output Class Initialized
INFO - 2023-05-26 06:10:35 --> Output Class Initialized
INFO - 2023-05-26 06:10:35 --> Security Class Initialized
INFO - 2023-05-26 06:10:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:10:35 --> Input Class Initialized
INFO - 2023-05-26 06:10:35 --> Input Class Initialized
INFO - 2023-05-26 06:10:35 --> Language Class Initialized
INFO - 2023-05-26 06:10:35 --> Language Class Initialized
INFO - 2023-05-26 06:10:35 --> Loader Class Initialized
INFO - 2023-05-26 06:10:35 --> Loader Class Initialized
INFO - 2023-05-26 06:10:35 --> Controller Class Initialized
INFO - 2023-05-26 06:10:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:10:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:10:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:10:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:10:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:10:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:10:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:10:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:10:35 --> Model "Login_model" initialized
INFO - 2023-05-26 06:10:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:10:35 --> Total execution time: 0.2250
INFO - 2023-05-26 06:10:35 --> Config Class Initialized
INFO - 2023-05-26 06:10:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:10:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:10:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:10:35 --> URI Class Initialized
INFO - 2023-05-26 06:10:35 --> Router Class Initialized
INFO - 2023-05-26 06:10:35 --> Output Class Initialized
INFO - 2023-05-26 06:10:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:10:35 --> Input Class Initialized
INFO - 2023-05-26 06:10:35 --> Language Class Initialized
INFO - 2023-05-26 06:10:35 --> Loader Class Initialized
INFO - 2023-05-26 06:10:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:10:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:10:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:10:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:10:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:10:35 --> Total execution time: 0.2479
INFO - 2023-05-26 06:10:46 --> Final output sent to browser
DEBUG - 2023-05-26 06:10:46 --> Total execution time: 10.9110
INFO - 2023-05-26 06:10:46 --> Config Class Initialized
INFO - 2023-05-26 06:10:46 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:10:46 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:10:46 --> Utf8 Class Initialized
INFO - 2023-05-26 06:10:46 --> URI Class Initialized
INFO - 2023-05-26 06:10:46 --> Router Class Initialized
INFO - 2023-05-26 06:10:46 --> Output Class Initialized
INFO - 2023-05-26 06:10:46 --> Security Class Initialized
DEBUG - 2023-05-26 06:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:10:46 --> Input Class Initialized
INFO - 2023-05-26 06:10:46 --> Language Class Initialized
INFO - 2023-05-26 06:10:46 --> Loader Class Initialized
INFO - 2023-05-26 06:10:46 --> Controller Class Initialized
DEBUG - 2023-05-26 06:10:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:10:46 --> Database Driver Class Initialized
INFO - 2023-05-26 06:10:46 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:10:46 --> Database Driver Class Initialized
INFO - 2023-05-26 06:10:46 --> Model "Login_model" initialized
INFO - 2023-05-26 06:10:57 --> Final output sent to browser
DEBUG - 2023-05-26 06:10:57 --> Total execution time: 10.9480
INFO - 2023-05-26 06:11:35 --> Config Class Initialized
INFO - 2023-05-26 06:11:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:11:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:11:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:11:35 --> URI Class Initialized
INFO - 2023-05-26 06:11:35 --> Router Class Initialized
INFO - 2023-05-26 06:11:35 --> Output Class Initialized
INFO - 2023-05-26 06:11:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:11:35 --> Input Class Initialized
INFO - 2023-05-26 06:11:35 --> Language Class Initialized
INFO - 2023-05-26 06:11:35 --> Loader Class Initialized
INFO - 2023-05-26 06:11:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:11:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:11:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:11:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:11:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:11:35 --> Total execution time: 0.2298
INFO - 2023-05-26 06:11:35 --> Config Class Initialized
INFO - 2023-05-26 06:11:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:11:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:11:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:11:35 --> URI Class Initialized
INFO - 2023-05-26 06:11:35 --> Router Class Initialized
INFO - 2023-05-26 06:11:35 --> Output Class Initialized
INFO - 2023-05-26 06:11:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:11:35 --> Input Class Initialized
INFO - 2023-05-26 06:11:35 --> Language Class Initialized
INFO - 2023-05-26 06:11:35 --> Loader Class Initialized
INFO - 2023-05-26 06:11:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:11:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:11:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:11:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:11:36 --> Final output sent to browser
DEBUG - 2023-05-26 06:11:36 --> Total execution time: 0.3392
INFO - 2023-05-26 06:11:39 --> Config Class Initialized
INFO - 2023-05-26 06:11:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:11:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:11:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:11:39 --> URI Class Initialized
INFO - 2023-05-26 06:11:39 --> Router Class Initialized
INFO - 2023-05-26 06:11:39 --> Output Class Initialized
INFO - 2023-05-26 06:11:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:11:39 --> Input Class Initialized
INFO - 2023-05-26 06:11:39 --> Language Class Initialized
INFO - 2023-05-26 06:11:39 --> Loader Class Initialized
INFO - 2023-05-26 06:11:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:11:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:11:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:11:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:11:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:11:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:11:48 --> Final output sent to browser
DEBUG - 2023-05-26 06:11:48 --> Total execution time: 9.5218
INFO - 2023-05-26 06:11:49 --> Config Class Initialized
INFO - 2023-05-26 06:11:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:11:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:11:49 --> Utf8 Class Initialized
INFO - 2023-05-26 06:11:49 --> URI Class Initialized
INFO - 2023-05-26 06:11:49 --> Router Class Initialized
INFO - 2023-05-26 06:11:49 --> Output Class Initialized
INFO - 2023-05-26 06:11:49 --> Security Class Initialized
DEBUG - 2023-05-26 06:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:11:49 --> Input Class Initialized
INFO - 2023-05-26 06:11:49 --> Language Class Initialized
INFO - 2023-05-26 06:11:49 --> Loader Class Initialized
INFO - 2023-05-26 06:11:49 --> Controller Class Initialized
DEBUG - 2023-05-26 06:11:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:11:49 --> Database Driver Class Initialized
INFO - 2023-05-26 06:11:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:11:49 --> Database Driver Class Initialized
INFO - 2023-05-26 06:11:49 --> Model "Login_model" initialized
INFO - 2023-05-26 06:11:58 --> Final output sent to browser
DEBUG - 2023-05-26 06:11:58 --> Total execution time: 9.1588
INFO - 2023-05-26 06:12:39 --> Config Class Initialized
INFO - 2023-05-26 06:12:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:12:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:12:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:12:39 --> URI Class Initialized
INFO - 2023-05-26 06:12:39 --> Router Class Initialized
INFO - 2023-05-26 06:12:39 --> Output Class Initialized
INFO - 2023-05-26 06:12:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:12:39 --> Input Class Initialized
INFO - 2023-05-26 06:12:39 --> Language Class Initialized
INFO - 2023-05-26 06:12:39 --> Loader Class Initialized
INFO - 2023-05-26 06:12:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:12:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:12:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:12:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:12:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:12:39 --> Total execution time: 0.2706
INFO - 2023-05-26 06:12:39 --> Config Class Initialized
INFO - 2023-05-26 06:12:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:12:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:12:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:12:39 --> URI Class Initialized
INFO - 2023-05-26 06:12:39 --> Router Class Initialized
INFO - 2023-05-26 06:12:39 --> Output Class Initialized
INFO - 2023-05-26 06:12:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:12:39 --> Input Class Initialized
INFO - 2023-05-26 06:12:39 --> Language Class Initialized
INFO - 2023-05-26 06:12:39 --> Loader Class Initialized
INFO - 2023-05-26 06:12:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:12:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:12:40 --> Database Driver Class Initialized
INFO - 2023-05-26 06:12:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:12:40 --> Final output sent to browser
DEBUG - 2023-05-26 06:12:40 --> Total execution time: 0.3143
INFO - 2023-05-26 06:13:39 --> Config Class Initialized
INFO - 2023-05-26 06:13:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:13:39 --> Config Class Initialized
INFO - 2023-05-26 06:13:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:13:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:13:39 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:13:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:13:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:13:39 --> URI Class Initialized
INFO - 2023-05-26 06:13:39 --> URI Class Initialized
INFO - 2023-05-26 06:13:39 --> Router Class Initialized
INFO - 2023-05-26 06:13:39 --> Router Class Initialized
INFO - 2023-05-26 06:13:39 --> Output Class Initialized
INFO - 2023-05-26 06:13:39 --> Output Class Initialized
INFO - 2023-05-26 06:13:39 --> Security Class Initialized
INFO - 2023-05-26 06:13:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:13:39 --> Input Class Initialized
INFO - 2023-05-26 06:13:39 --> Input Class Initialized
INFO - 2023-05-26 06:13:39 --> Language Class Initialized
INFO - 2023-05-26 06:13:39 --> Language Class Initialized
INFO - 2023-05-26 06:13:39 --> Loader Class Initialized
INFO - 2023-05-26 06:13:39 --> Loader Class Initialized
INFO - 2023-05-26 06:13:39 --> Controller Class Initialized
INFO - 2023-05-26 06:13:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:13:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:13:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:13:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:13:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:13:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:13:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:13:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:13:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:13:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:13:39 --> Total execution time: 0.2330
INFO - 2023-05-26 06:13:39 --> Config Class Initialized
INFO - 2023-05-26 06:13:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:13:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:13:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:13:39 --> URI Class Initialized
INFO - 2023-05-26 06:13:39 --> Router Class Initialized
INFO - 2023-05-26 06:13:39 --> Output Class Initialized
INFO - 2023-05-26 06:13:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:13:39 --> Input Class Initialized
INFO - 2023-05-26 06:13:39 --> Language Class Initialized
INFO - 2023-05-26 06:13:39 --> Loader Class Initialized
INFO - 2023-05-26 06:13:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:13:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:13:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:13:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:13:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:13:39 --> Total execution time: 0.2473
INFO - 2023-05-26 06:13:45 --> Final output sent to browser
DEBUG - 2023-05-26 06:13:45 --> Total execution time: 5.9387
INFO - 2023-05-26 06:13:45 --> Config Class Initialized
INFO - 2023-05-26 06:13:45 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:13:45 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:13:45 --> Utf8 Class Initialized
INFO - 2023-05-26 06:13:45 --> URI Class Initialized
INFO - 2023-05-26 06:13:45 --> Router Class Initialized
INFO - 2023-05-26 06:13:45 --> Output Class Initialized
INFO - 2023-05-26 06:13:45 --> Security Class Initialized
DEBUG - 2023-05-26 06:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:13:45 --> Input Class Initialized
INFO - 2023-05-26 06:13:45 --> Language Class Initialized
INFO - 2023-05-26 06:13:45 --> Loader Class Initialized
INFO - 2023-05-26 06:13:45 --> Controller Class Initialized
DEBUG - 2023-05-26 06:13:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:13:45 --> Database Driver Class Initialized
INFO - 2023-05-26 06:13:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:13:45 --> Database Driver Class Initialized
INFO - 2023-05-26 06:13:45 --> Model "Login_model" initialized
INFO - 2023-05-26 06:13:54 --> Final output sent to browser
DEBUG - 2023-05-26 06:13:54 --> Total execution time: 9.2675
INFO - 2023-05-26 06:14:39 --> Config Class Initialized
INFO - 2023-05-26 06:14:39 --> Config Class Initialized
INFO - 2023-05-26 06:14:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:14:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:14:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:14:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:14:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:14:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:14:39 --> URI Class Initialized
INFO - 2023-05-26 06:14:39 --> URI Class Initialized
INFO - 2023-05-26 06:14:39 --> Router Class Initialized
INFO - 2023-05-26 06:14:39 --> Router Class Initialized
INFO - 2023-05-26 06:14:39 --> Output Class Initialized
INFO - 2023-05-26 06:14:39 --> Output Class Initialized
INFO - 2023-05-26 06:14:39 --> Security Class Initialized
INFO - 2023-05-26 06:14:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:14:39 --> Input Class Initialized
INFO - 2023-05-26 06:14:39 --> Input Class Initialized
INFO - 2023-05-26 06:14:39 --> Language Class Initialized
INFO - 2023-05-26 06:14:39 --> Language Class Initialized
INFO - 2023-05-26 06:14:39 --> Loader Class Initialized
INFO - 2023-05-26 06:14:39 --> Controller Class Initialized
INFO - 2023-05-26 06:14:39 --> Loader Class Initialized
DEBUG - 2023-05-26 06:14:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:14:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:14:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:14:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:14:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:14:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:14:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:14:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:14:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:14:39 --> Total execution time: 0.1692
INFO - 2023-05-26 06:14:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:14:39 --> Config Class Initialized
INFO - 2023-05-26 06:14:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:14:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:14:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:14:39 --> URI Class Initialized
INFO - 2023-05-26 06:14:39 --> Router Class Initialized
INFO - 2023-05-26 06:14:39 --> Output Class Initialized
INFO - 2023-05-26 06:14:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:14:39 --> Input Class Initialized
INFO - 2023-05-26 06:14:39 --> Language Class Initialized
INFO - 2023-05-26 06:14:39 --> Loader Class Initialized
INFO - 2023-05-26 06:14:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:14:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:14:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:14:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:14:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:14:39 --> Total execution time: 0.2470
INFO - 2023-05-26 06:14:48 --> Final output sent to browser
DEBUG - 2023-05-26 06:14:48 --> Total execution time: 9.1202
INFO - 2023-05-26 06:14:48 --> Config Class Initialized
INFO - 2023-05-26 06:14:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:14:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:14:48 --> Utf8 Class Initialized
INFO - 2023-05-26 06:14:48 --> URI Class Initialized
INFO - 2023-05-26 06:14:48 --> Router Class Initialized
INFO - 2023-05-26 06:14:48 --> Output Class Initialized
INFO - 2023-05-26 06:14:48 --> Security Class Initialized
DEBUG - 2023-05-26 06:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:14:48 --> Input Class Initialized
INFO - 2023-05-26 06:14:48 --> Language Class Initialized
INFO - 2023-05-26 06:14:48 --> Loader Class Initialized
INFO - 2023-05-26 06:14:48 --> Controller Class Initialized
DEBUG - 2023-05-26 06:14:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:14:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:14:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:14:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:14:48 --> Model "Login_model" initialized
INFO - 2023-05-26 06:14:58 --> Final output sent to browser
DEBUG - 2023-05-26 06:14:58 --> Total execution time: 9.9741
INFO - 2023-05-26 06:15:39 --> Config Class Initialized
INFO - 2023-05-26 06:15:39 --> Config Class Initialized
INFO - 2023-05-26 06:15:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:15:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:15:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:15:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:15:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:15:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:15:39 --> URI Class Initialized
INFO - 2023-05-26 06:15:39 --> URI Class Initialized
INFO - 2023-05-26 06:15:39 --> Router Class Initialized
INFO - 2023-05-26 06:15:39 --> Router Class Initialized
INFO - 2023-05-26 06:15:39 --> Output Class Initialized
INFO - 2023-05-26 06:15:39 --> Output Class Initialized
INFO - 2023-05-26 06:15:39 --> Security Class Initialized
INFO - 2023-05-26 06:15:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:15:39 --> Input Class Initialized
INFO - 2023-05-26 06:15:39 --> Input Class Initialized
INFO - 2023-05-26 06:15:39 --> Language Class Initialized
INFO - 2023-05-26 06:15:39 --> Language Class Initialized
INFO - 2023-05-26 06:15:39 --> Loader Class Initialized
INFO - 2023-05-26 06:15:39 --> Loader Class Initialized
INFO - 2023-05-26 06:15:39 --> Controller Class Initialized
INFO - 2023-05-26 06:15:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:15:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:15:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:15:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:15:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:15:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:15:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:15:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:15:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:15:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:15:39 --> Total execution time: 0.5557
INFO - 2023-05-26 06:15:40 --> Config Class Initialized
INFO - 2023-05-26 06:15:40 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:15:40 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:15:40 --> Utf8 Class Initialized
INFO - 2023-05-26 06:15:40 --> URI Class Initialized
INFO - 2023-05-26 06:15:40 --> Router Class Initialized
INFO - 2023-05-26 06:15:40 --> Output Class Initialized
INFO - 2023-05-26 06:15:40 --> Security Class Initialized
DEBUG - 2023-05-26 06:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:15:40 --> Input Class Initialized
INFO - 2023-05-26 06:15:40 --> Language Class Initialized
INFO - 2023-05-26 06:15:40 --> Loader Class Initialized
INFO - 2023-05-26 06:15:40 --> Controller Class Initialized
DEBUG - 2023-05-26 06:15:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:15:40 --> Database Driver Class Initialized
INFO - 2023-05-26 06:15:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:15:40 --> Final output sent to browser
DEBUG - 2023-05-26 06:15:40 --> Total execution time: 0.2449
INFO - 2023-05-26 06:15:48 --> Final output sent to browser
DEBUG - 2023-05-26 06:15:48 --> Total execution time: 9.4935
INFO - 2023-05-26 06:15:48 --> Config Class Initialized
INFO - 2023-05-26 06:15:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:15:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:15:49 --> Utf8 Class Initialized
INFO - 2023-05-26 06:15:49 --> URI Class Initialized
INFO - 2023-05-26 06:15:49 --> Router Class Initialized
INFO - 2023-05-26 06:15:49 --> Output Class Initialized
INFO - 2023-05-26 06:15:49 --> Security Class Initialized
DEBUG - 2023-05-26 06:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:15:49 --> Input Class Initialized
INFO - 2023-05-26 06:15:49 --> Language Class Initialized
INFO - 2023-05-26 06:15:49 --> Loader Class Initialized
INFO - 2023-05-26 06:15:49 --> Controller Class Initialized
DEBUG - 2023-05-26 06:15:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:15:49 --> Database Driver Class Initialized
INFO - 2023-05-26 06:15:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:15:49 --> Database Driver Class Initialized
INFO - 2023-05-26 06:15:49 --> Model "Login_model" initialized
INFO - 2023-05-26 06:15:58 --> Final output sent to browser
DEBUG - 2023-05-26 06:15:58 --> Total execution time: 9.7779
INFO - 2023-05-26 06:16:39 --> Config Class Initialized
INFO - 2023-05-26 06:16:39 --> Config Class Initialized
INFO - 2023-05-26 06:16:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:16:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:16:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:16:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:16:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:16:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:16:39 --> URI Class Initialized
INFO - 2023-05-26 06:16:39 --> URI Class Initialized
INFO - 2023-05-26 06:16:39 --> Router Class Initialized
INFO - 2023-05-26 06:16:39 --> Router Class Initialized
INFO - 2023-05-26 06:16:39 --> Output Class Initialized
INFO - 2023-05-26 06:16:39 --> Output Class Initialized
INFO - 2023-05-26 06:16:39 --> Security Class Initialized
INFO - 2023-05-26 06:16:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:16:39 --> Input Class Initialized
INFO - 2023-05-26 06:16:39 --> Input Class Initialized
INFO - 2023-05-26 06:16:39 --> Language Class Initialized
INFO - 2023-05-26 06:16:39 --> Language Class Initialized
INFO - 2023-05-26 06:16:39 --> Loader Class Initialized
INFO - 2023-05-26 06:16:39 --> Loader Class Initialized
INFO - 2023-05-26 06:16:39 --> Controller Class Initialized
INFO - 2023-05-26 06:16:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:16:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:16:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:16:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:16:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:16:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:16:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:16:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:16:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:16:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:16:39 --> Total execution time: 0.1938
INFO - 2023-05-26 06:16:39 --> Config Class Initialized
INFO - 2023-05-26 06:16:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:16:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:16:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:16:39 --> URI Class Initialized
INFO - 2023-05-26 06:16:39 --> Router Class Initialized
INFO - 2023-05-26 06:16:39 --> Output Class Initialized
INFO - 2023-05-26 06:16:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:16:39 --> Input Class Initialized
INFO - 2023-05-26 06:16:39 --> Language Class Initialized
INFO - 2023-05-26 06:16:39 --> Loader Class Initialized
INFO - 2023-05-26 06:16:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:16:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:16:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:16:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:16:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:16:39 --> Total execution time: 0.2451
INFO - 2023-05-26 06:16:47 --> Final output sent to browser
DEBUG - 2023-05-26 06:16:47 --> Total execution time: 7.9016
INFO - 2023-05-26 06:16:47 --> Config Class Initialized
INFO - 2023-05-26 06:16:47 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:16:47 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:16:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:16:47 --> URI Class Initialized
INFO - 2023-05-26 06:16:47 --> Router Class Initialized
INFO - 2023-05-26 06:16:47 --> Output Class Initialized
INFO - 2023-05-26 06:16:47 --> Security Class Initialized
DEBUG - 2023-05-26 06:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:16:47 --> Input Class Initialized
INFO - 2023-05-26 06:16:47 --> Language Class Initialized
INFO - 2023-05-26 06:16:47 --> Loader Class Initialized
INFO - 2023-05-26 06:16:47 --> Controller Class Initialized
DEBUG - 2023-05-26 06:16:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:16:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:16:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:16:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:16:47 --> Model "Login_model" initialized
INFO - 2023-05-26 06:16:56 --> Final output sent to browser
DEBUG - 2023-05-26 06:16:56 --> Total execution time: 9.1757
INFO - 2023-05-26 06:17:39 --> Config Class Initialized
INFO - 2023-05-26 06:17:39 --> Config Class Initialized
INFO - 2023-05-26 06:17:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:17:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:17:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:17:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:17:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:17:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:17:39 --> URI Class Initialized
INFO - 2023-05-26 06:17:39 --> URI Class Initialized
INFO - 2023-05-26 06:17:39 --> Router Class Initialized
INFO - 2023-05-26 06:17:39 --> Router Class Initialized
INFO - 2023-05-26 06:17:39 --> Output Class Initialized
INFO - 2023-05-26 06:17:39 --> Output Class Initialized
INFO - 2023-05-26 06:17:39 --> Security Class Initialized
INFO - 2023-05-26 06:17:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:17:39 --> Input Class Initialized
INFO - 2023-05-26 06:17:39 --> Input Class Initialized
INFO - 2023-05-26 06:17:39 --> Language Class Initialized
INFO - 2023-05-26 06:17:39 --> Language Class Initialized
INFO - 2023-05-26 06:17:39 --> Loader Class Initialized
INFO - 2023-05-26 06:17:39 --> Loader Class Initialized
INFO - 2023-05-26 06:17:39 --> Controller Class Initialized
INFO - 2023-05-26 06:17:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:17:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:17:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:17:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:17:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:17:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:17:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:17:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:17:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:17:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:17:39 --> Total execution time: 0.1857
INFO - 2023-05-26 06:17:39 --> Config Class Initialized
INFO - 2023-05-26 06:17:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:17:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:17:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:17:39 --> URI Class Initialized
INFO - 2023-05-26 06:17:39 --> Router Class Initialized
INFO - 2023-05-26 06:17:39 --> Output Class Initialized
INFO - 2023-05-26 06:17:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:17:39 --> Input Class Initialized
INFO - 2023-05-26 06:17:39 --> Language Class Initialized
INFO - 2023-05-26 06:17:39 --> Loader Class Initialized
INFO - 2023-05-26 06:17:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:17:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:17:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:17:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:17:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:17:39 --> Total execution time: 0.2440
INFO - 2023-05-26 06:17:48 --> Final output sent to browser
DEBUG - 2023-05-26 06:17:48 --> Total execution time: 8.5786
INFO - 2023-05-26 06:17:48 --> Config Class Initialized
INFO - 2023-05-26 06:17:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:17:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:17:48 --> Utf8 Class Initialized
INFO - 2023-05-26 06:17:48 --> URI Class Initialized
INFO - 2023-05-26 06:17:48 --> Router Class Initialized
INFO - 2023-05-26 06:17:48 --> Output Class Initialized
INFO - 2023-05-26 06:17:48 --> Security Class Initialized
DEBUG - 2023-05-26 06:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:17:48 --> Input Class Initialized
INFO - 2023-05-26 06:17:48 --> Language Class Initialized
INFO - 2023-05-26 06:17:48 --> Loader Class Initialized
INFO - 2023-05-26 06:17:48 --> Controller Class Initialized
DEBUG - 2023-05-26 06:17:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:17:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:17:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:17:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:17:48 --> Model "Login_model" initialized
INFO - 2023-05-26 06:17:57 --> Final output sent to browser
DEBUG - 2023-05-26 06:17:57 --> Total execution time: 9.0715
INFO - 2023-05-26 06:18:39 --> Config Class Initialized
INFO - 2023-05-26 06:18:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:18:39 --> Config Class Initialized
INFO - 2023-05-26 06:18:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:18:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:18:39 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:18:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:18:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:18:39 --> URI Class Initialized
INFO - 2023-05-26 06:18:39 --> URI Class Initialized
INFO - 2023-05-26 06:18:39 --> Router Class Initialized
INFO - 2023-05-26 06:18:39 --> Router Class Initialized
INFO - 2023-05-26 06:18:39 --> Output Class Initialized
INFO - 2023-05-26 06:18:39 --> Output Class Initialized
INFO - 2023-05-26 06:18:39 --> Security Class Initialized
INFO - 2023-05-26 06:18:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:18:39 --> Input Class Initialized
INFO - 2023-05-26 06:18:39 --> Input Class Initialized
INFO - 2023-05-26 06:18:39 --> Language Class Initialized
INFO - 2023-05-26 06:18:39 --> Language Class Initialized
INFO - 2023-05-26 06:18:39 --> Loader Class Initialized
INFO - 2023-05-26 06:18:39 --> Loader Class Initialized
INFO - 2023-05-26 06:18:39 --> Controller Class Initialized
INFO - 2023-05-26 06:18:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:18:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:18:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:18:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:18:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:18:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:18:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:18:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:18:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:18:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:18:39 --> Total execution time: 0.2621
INFO - 2023-05-26 06:18:39 --> Config Class Initialized
INFO - 2023-05-26 06:18:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:18:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:18:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:18:39 --> URI Class Initialized
INFO - 2023-05-26 06:18:39 --> Router Class Initialized
INFO - 2023-05-26 06:18:39 --> Output Class Initialized
INFO - 2023-05-26 06:18:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:18:39 --> Input Class Initialized
INFO - 2023-05-26 06:18:39 --> Language Class Initialized
INFO - 2023-05-26 06:18:39 --> Loader Class Initialized
INFO - 2023-05-26 06:18:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:18:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:18:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:18:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:18:40 --> Final output sent to browser
DEBUG - 2023-05-26 06:18:40 --> Total execution time: 0.4515
INFO - 2023-05-26 06:18:42 --> Config Class Initialized
INFO - 2023-05-26 06:18:42 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:18:42 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:18:42 --> Utf8 Class Initialized
INFO - 2023-05-26 06:18:42 --> URI Class Initialized
INFO - 2023-05-26 06:18:42 --> Router Class Initialized
INFO - 2023-05-26 06:18:42 --> Output Class Initialized
INFO - 2023-05-26 06:18:42 --> Security Class Initialized
DEBUG - 2023-05-26 06:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:18:42 --> Input Class Initialized
INFO - 2023-05-26 06:18:42 --> Language Class Initialized
INFO - 2023-05-26 06:18:42 --> Loader Class Initialized
INFO - 2023-05-26 06:18:42 --> Controller Class Initialized
DEBUG - 2023-05-26 06:18:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:18:42 --> Database Driver Class Initialized
INFO - 2023-05-26 06:18:42 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:18:42 --> Database Driver Class Initialized
INFO - 2023-05-26 06:18:42 --> Model "Login_model" initialized
INFO - 2023-05-26 06:18:47 --> Final output sent to browser
DEBUG - 2023-05-26 06:18:47 --> Total execution time: 8.2592
INFO - 2023-05-26 06:18:47 --> Config Class Initialized
INFO - 2023-05-26 06:18:47 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:18:47 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:18:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:18:47 --> URI Class Initialized
INFO - 2023-05-26 06:18:47 --> Router Class Initialized
INFO - 2023-05-26 06:18:47 --> Output Class Initialized
INFO - 2023-05-26 06:18:47 --> Security Class Initialized
DEBUG - 2023-05-26 06:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:18:47 --> Input Class Initialized
INFO - 2023-05-26 06:18:47 --> Language Class Initialized
INFO - 2023-05-26 06:18:47 --> Loader Class Initialized
INFO - 2023-05-26 06:18:47 --> Controller Class Initialized
DEBUG - 2023-05-26 06:18:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:18:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:18:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:18:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:18:47 --> Model "Login_model" initialized
INFO - 2023-05-26 06:18:50 --> Final output sent to browser
DEBUG - 2023-05-26 06:18:50 --> Total execution time: 7.4167
INFO - 2023-05-26 06:18:56 --> Final output sent to browser
DEBUG - 2023-05-26 06:18:56 --> Total execution time: 8.7340
INFO - 2023-05-26 06:18:56 --> Config Class Initialized
INFO - 2023-05-26 06:18:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:18:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:18:56 --> Utf8 Class Initialized
INFO - 2023-05-26 06:18:56 --> URI Class Initialized
INFO - 2023-05-26 06:18:56 --> Router Class Initialized
INFO - 2023-05-26 06:18:56 --> Output Class Initialized
INFO - 2023-05-26 06:18:56 --> Security Class Initialized
DEBUG - 2023-05-26 06:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:18:56 --> Input Class Initialized
INFO - 2023-05-26 06:18:56 --> Language Class Initialized
INFO - 2023-05-26 06:18:56 --> Loader Class Initialized
INFO - 2023-05-26 06:18:56 --> Controller Class Initialized
DEBUG - 2023-05-26 06:18:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:18:56 --> Database Driver Class Initialized
INFO - 2023-05-26 06:18:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:18:56 --> Database Driver Class Initialized
INFO - 2023-05-26 06:18:56 --> Model "Login_model" initialized
INFO - 2023-05-26 06:19:06 --> Final output sent to browser
DEBUG - 2023-05-26 06:19:06 --> Total execution time: 9.5709
INFO - 2023-05-26 06:19:35 --> Config Class Initialized
INFO - 2023-05-26 06:19:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:19:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:19:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:19:35 --> URI Class Initialized
INFO - 2023-05-26 06:19:35 --> Router Class Initialized
INFO - 2023-05-26 06:19:35 --> Output Class Initialized
INFO - 2023-05-26 06:19:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:19:35 --> Input Class Initialized
INFO - 2023-05-26 06:19:35 --> Language Class Initialized
INFO - 2023-05-26 06:19:35 --> Loader Class Initialized
INFO - 2023-05-26 06:19:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:19:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:19:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:19:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:19:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:19:35 --> Total execution time: 0.2128
INFO - 2023-05-26 06:19:35 --> Config Class Initialized
INFO - 2023-05-26 06:19:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:19:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:19:35 --> Utf8 Class Initialized
INFO - 2023-05-26 06:19:35 --> URI Class Initialized
INFO - 2023-05-26 06:19:35 --> Router Class Initialized
INFO - 2023-05-26 06:19:35 --> Output Class Initialized
INFO - 2023-05-26 06:19:35 --> Security Class Initialized
DEBUG - 2023-05-26 06:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:19:35 --> Input Class Initialized
INFO - 2023-05-26 06:19:35 --> Language Class Initialized
INFO - 2023-05-26 06:19:35 --> Loader Class Initialized
INFO - 2023-05-26 06:19:35 --> Controller Class Initialized
DEBUG - 2023-05-26 06:19:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:19:35 --> Database Driver Class Initialized
INFO - 2023-05-26 06:19:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:19:35 --> Final output sent to browser
DEBUG - 2023-05-26 06:19:35 --> Total execution time: 0.2139
INFO - 2023-05-26 06:19:36 --> Config Class Initialized
INFO - 2023-05-26 06:19:36 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:19:36 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:19:36 --> Utf8 Class Initialized
INFO - 2023-05-26 06:19:36 --> URI Class Initialized
INFO - 2023-05-26 06:19:36 --> Router Class Initialized
INFO - 2023-05-26 06:19:36 --> Output Class Initialized
INFO - 2023-05-26 06:19:36 --> Security Class Initialized
DEBUG - 2023-05-26 06:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:19:36 --> Input Class Initialized
INFO - 2023-05-26 06:19:36 --> Language Class Initialized
INFO - 2023-05-26 06:19:36 --> Loader Class Initialized
INFO - 2023-05-26 06:19:36 --> Controller Class Initialized
DEBUG - 2023-05-26 06:19:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:19:36 --> Database Driver Class Initialized
INFO - 2023-05-26 06:19:36 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:19:36 --> Database Driver Class Initialized
INFO - 2023-05-26 06:19:36 --> Model "Login_model" initialized
INFO - 2023-05-26 06:19:46 --> Final output sent to browser
DEBUG - 2023-05-26 06:19:46 --> Total execution time: 10.5401
INFO - 2023-05-26 06:19:47 --> Config Class Initialized
INFO - 2023-05-26 06:19:47 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:19:47 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:19:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:19:47 --> URI Class Initialized
INFO - 2023-05-26 06:19:47 --> Router Class Initialized
INFO - 2023-05-26 06:19:47 --> Output Class Initialized
INFO - 2023-05-26 06:19:47 --> Security Class Initialized
DEBUG - 2023-05-26 06:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:19:47 --> Input Class Initialized
INFO - 2023-05-26 06:19:47 --> Language Class Initialized
INFO - 2023-05-26 06:19:47 --> Loader Class Initialized
INFO - 2023-05-26 06:19:47 --> Controller Class Initialized
DEBUG - 2023-05-26 06:19:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:19:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:19:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:19:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:19:47 --> Model "Login_model" initialized
INFO - 2023-05-26 06:19:54 --> Final output sent to browser
DEBUG - 2023-05-26 06:19:54 --> Total execution time: 7.7687
INFO - 2023-05-26 06:20:39 --> Config Class Initialized
INFO - 2023-05-26 06:20:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:20:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:20:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:20:39 --> URI Class Initialized
INFO - 2023-05-26 06:20:39 --> Router Class Initialized
INFO - 2023-05-26 06:20:39 --> Output Class Initialized
INFO - 2023-05-26 06:20:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:20:39 --> Input Class Initialized
INFO - 2023-05-26 06:20:39 --> Language Class Initialized
INFO - 2023-05-26 06:20:39 --> Loader Class Initialized
INFO - 2023-05-26 06:20:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:20:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:20:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:20:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:20:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:20:39 --> Total execution time: 0.2470
INFO - 2023-05-26 06:20:39 --> Config Class Initialized
INFO - 2023-05-26 06:20:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:20:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:20:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:20:39 --> URI Class Initialized
INFO - 2023-05-26 06:20:39 --> Router Class Initialized
INFO - 2023-05-26 06:20:39 --> Output Class Initialized
INFO - 2023-05-26 06:20:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:20:39 --> Input Class Initialized
INFO - 2023-05-26 06:20:39 --> Language Class Initialized
INFO - 2023-05-26 06:20:39 --> Loader Class Initialized
INFO - 2023-05-26 06:20:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:20:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:20:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:20:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:20:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:20:39 --> Total execution time: 0.2298
INFO - 2023-05-26 06:21:39 --> Config Class Initialized
INFO - 2023-05-26 06:21:39 --> Config Class Initialized
INFO - 2023-05-26 06:21:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:21:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:21:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:21:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:21:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:21:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:21:39 --> URI Class Initialized
INFO - 2023-05-26 06:21:39 --> URI Class Initialized
INFO - 2023-05-26 06:21:39 --> Router Class Initialized
INFO - 2023-05-26 06:21:39 --> Router Class Initialized
INFO - 2023-05-26 06:21:39 --> Output Class Initialized
INFO - 2023-05-26 06:21:39 --> Output Class Initialized
INFO - 2023-05-26 06:21:39 --> Security Class Initialized
INFO - 2023-05-26 06:21:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:21:39 --> Input Class Initialized
INFO - 2023-05-26 06:21:39 --> Input Class Initialized
INFO - 2023-05-26 06:21:39 --> Language Class Initialized
INFO - 2023-05-26 06:21:39 --> Language Class Initialized
INFO - 2023-05-26 06:21:39 --> Loader Class Initialized
INFO - 2023-05-26 06:21:39 --> Controller Class Initialized
INFO - 2023-05-26 06:21:39 --> Loader Class Initialized
DEBUG - 2023-05-26 06:21:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:21:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:21:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:21:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:21:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:21:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:21:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:21:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:21:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:21:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:21:39 --> Total execution time: 0.2014
INFO - 2023-05-26 06:21:39 --> Config Class Initialized
INFO - 2023-05-26 06:21:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:21:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:21:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:21:39 --> URI Class Initialized
INFO - 2023-05-26 06:21:39 --> Router Class Initialized
INFO - 2023-05-26 06:21:39 --> Output Class Initialized
INFO - 2023-05-26 06:21:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:21:39 --> Input Class Initialized
INFO - 2023-05-26 06:21:39 --> Language Class Initialized
INFO - 2023-05-26 06:21:39 --> Loader Class Initialized
INFO - 2023-05-26 06:21:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:21:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:21:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:21:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:21:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:21:39 --> Total execution time: 0.2908
INFO - 2023-05-26 06:21:48 --> Final output sent to browser
DEBUG - 2023-05-26 06:21:48 --> Total execution time: 9.2150
INFO - 2023-05-26 06:21:48 --> Config Class Initialized
INFO - 2023-05-26 06:21:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:21:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:21:48 --> Utf8 Class Initialized
INFO - 2023-05-26 06:21:48 --> URI Class Initialized
INFO - 2023-05-26 06:21:48 --> Router Class Initialized
INFO - 2023-05-26 06:21:48 --> Output Class Initialized
INFO - 2023-05-26 06:21:48 --> Security Class Initialized
DEBUG - 2023-05-26 06:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:21:48 --> Input Class Initialized
INFO - 2023-05-26 06:21:48 --> Language Class Initialized
INFO - 2023-05-26 06:21:48 --> Loader Class Initialized
INFO - 2023-05-26 06:21:48 --> Controller Class Initialized
DEBUG - 2023-05-26 06:21:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:21:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:21:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:21:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:21:48 --> Model "Login_model" initialized
INFO - 2023-05-26 06:21:58 --> Final output sent to browser
DEBUG - 2023-05-26 06:21:58 --> Total execution time: 10.1043
INFO - 2023-05-26 06:22:39 --> Config Class Initialized
INFO - 2023-05-26 06:22:39 --> Config Class Initialized
INFO - 2023-05-26 06:22:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:22:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:22:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:22:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:22:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:22:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:22:39 --> URI Class Initialized
INFO - 2023-05-26 06:22:39 --> URI Class Initialized
INFO - 2023-05-26 06:22:39 --> Router Class Initialized
INFO - 2023-05-26 06:22:39 --> Output Class Initialized
INFO - 2023-05-26 06:22:39 --> Router Class Initialized
INFO - 2023-05-26 06:22:39 --> Security Class Initialized
INFO - 2023-05-26 06:22:39 --> Output Class Initialized
DEBUG - 2023-05-26 06:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:22:39 --> Input Class Initialized
INFO - 2023-05-26 06:22:39 --> Security Class Initialized
INFO - 2023-05-26 06:22:39 --> Language Class Initialized
DEBUG - 2023-05-26 06:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:22:39 --> Input Class Initialized
INFO - 2023-05-26 06:22:39 --> Language Class Initialized
INFO - 2023-05-26 06:22:39 --> Loader Class Initialized
INFO - 2023-05-26 06:22:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:22:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:22:39 --> Loader Class Initialized
INFO - 2023-05-26 06:22:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:22:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:22:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:22:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:22:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:22:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:22:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:22:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:22:39 --> Total execution time: 0.1873
INFO - 2023-05-26 06:22:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:22:39 --> Config Class Initialized
INFO - 2023-05-26 06:22:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:22:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:22:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:22:39 --> URI Class Initialized
INFO - 2023-05-26 06:22:39 --> Router Class Initialized
INFO - 2023-05-26 06:22:39 --> Output Class Initialized
INFO - 2023-05-26 06:22:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:22:39 --> Input Class Initialized
INFO - 2023-05-26 06:22:39 --> Language Class Initialized
INFO - 2023-05-26 06:22:39 --> Loader Class Initialized
INFO - 2023-05-26 06:22:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:22:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:22:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:22:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:22:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:22:39 --> Total execution time: 0.2539
INFO - 2023-05-26 06:22:49 --> Final output sent to browser
DEBUG - 2023-05-26 06:22:49 --> Total execution time: 10.4205
INFO - 2023-05-26 06:22:49 --> Config Class Initialized
INFO - 2023-05-26 06:22:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:22:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:22:49 --> Utf8 Class Initialized
INFO - 2023-05-26 06:22:49 --> URI Class Initialized
INFO - 2023-05-26 06:22:49 --> Router Class Initialized
INFO - 2023-05-26 06:22:49 --> Output Class Initialized
INFO - 2023-05-26 06:22:49 --> Security Class Initialized
DEBUG - 2023-05-26 06:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:22:49 --> Input Class Initialized
INFO - 2023-05-26 06:22:49 --> Language Class Initialized
INFO - 2023-05-26 06:22:50 --> Loader Class Initialized
INFO - 2023-05-26 06:22:50 --> Controller Class Initialized
DEBUG - 2023-05-26 06:22:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:22:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:22:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:22:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:22:50 --> Model "Login_model" initialized
INFO - 2023-05-26 06:22:57 --> Final output sent to browser
DEBUG - 2023-05-26 06:22:57 --> Total execution time: 7.6690
INFO - 2023-05-26 06:23:39 --> Config Class Initialized
INFO - 2023-05-26 06:23:39 --> Config Class Initialized
INFO - 2023-05-26 06:23:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:23:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:23:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:23:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:23:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:23:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:23:39 --> URI Class Initialized
INFO - 2023-05-26 06:23:39 --> URI Class Initialized
INFO - 2023-05-26 06:23:39 --> Router Class Initialized
INFO - 2023-05-26 06:23:39 --> Router Class Initialized
INFO - 2023-05-26 06:23:39 --> Output Class Initialized
INFO - 2023-05-26 06:23:39 --> Output Class Initialized
INFO - 2023-05-26 06:23:39 --> Security Class Initialized
INFO - 2023-05-26 06:23:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:23:39 --> Input Class Initialized
INFO - 2023-05-26 06:23:39 --> Input Class Initialized
INFO - 2023-05-26 06:23:39 --> Language Class Initialized
INFO - 2023-05-26 06:23:39 --> Language Class Initialized
INFO - 2023-05-26 06:23:39 --> Loader Class Initialized
INFO - 2023-05-26 06:23:39 --> Controller Class Initialized
INFO - 2023-05-26 06:23:39 --> Loader Class Initialized
DEBUG - 2023-05-26 06:23:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:23:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:23:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:23:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:23:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:23:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:23:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:23:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:23:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:23:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:23:39 --> Total execution time: 0.1940
INFO - 2023-05-26 06:23:39 --> Config Class Initialized
INFO - 2023-05-26 06:23:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:23:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:23:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:23:39 --> URI Class Initialized
INFO - 2023-05-26 06:23:39 --> Router Class Initialized
INFO - 2023-05-26 06:23:39 --> Output Class Initialized
INFO - 2023-05-26 06:23:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:23:39 --> Input Class Initialized
INFO - 2023-05-26 06:23:39 --> Language Class Initialized
INFO - 2023-05-26 06:23:39 --> Loader Class Initialized
INFO - 2023-05-26 06:23:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:23:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:23:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:23:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:23:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:23:39 --> Total execution time: 0.2024
INFO - 2023-05-26 06:23:48 --> Final output sent to browser
DEBUG - 2023-05-26 06:23:48 --> Total execution time: 8.8146
INFO - 2023-05-26 06:23:48 --> Config Class Initialized
INFO - 2023-05-26 06:23:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:23:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:23:48 --> Utf8 Class Initialized
INFO - 2023-05-26 06:23:48 --> URI Class Initialized
INFO - 2023-05-26 06:23:48 --> Router Class Initialized
INFO - 2023-05-26 06:23:48 --> Output Class Initialized
INFO - 2023-05-26 06:23:48 --> Security Class Initialized
DEBUG - 2023-05-26 06:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:23:48 --> Input Class Initialized
INFO - 2023-05-26 06:23:48 --> Language Class Initialized
INFO - 2023-05-26 06:23:48 --> Loader Class Initialized
INFO - 2023-05-26 06:23:48 --> Controller Class Initialized
DEBUG - 2023-05-26 06:23:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:23:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:23:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:23:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:23:48 --> Model "Login_model" initialized
INFO - 2023-05-26 06:23:56 --> Final output sent to browser
DEBUG - 2023-05-26 06:23:56 --> Total execution time: 8.1425
INFO - 2023-05-26 06:24:39 --> Config Class Initialized
INFO - 2023-05-26 06:24:39 --> Config Class Initialized
INFO - 2023-05-26 06:24:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:24:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:24:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:24:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:24:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:24:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:24:39 --> URI Class Initialized
INFO - 2023-05-26 06:24:39 --> URI Class Initialized
INFO - 2023-05-26 06:24:39 --> Router Class Initialized
INFO - 2023-05-26 06:24:39 --> Router Class Initialized
INFO - 2023-05-26 06:24:39 --> Output Class Initialized
INFO - 2023-05-26 06:24:39 --> Output Class Initialized
INFO - 2023-05-26 06:24:39 --> Security Class Initialized
INFO - 2023-05-26 06:24:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:24:39 --> Input Class Initialized
INFO - 2023-05-26 06:24:39 --> Input Class Initialized
INFO - 2023-05-26 06:24:39 --> Language Class Initialized
INFO - 2023-05-26 06:24:39 --> Language Class Initialized
INFO - 2023-05-26 06:24:39 --> Loader Class Initialized
INFO - 2023-05-26 06:24:39 --> Controller Class Initialized
INFO - 2023-05-26 06:24:39 --> Loader Class Initialized
DEBUG - 2023-05-26 06:24:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:24:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:24:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:24:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:24:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:24:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:24:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:24:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:24:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:24:39 --> Total execution time: 0.2121
INFO - 2023-05-26 06:24:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:24:39 --> Config Class Initialized
INFO - 2023-05-26 06:24:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:24:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:24:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:24:39 --> URI Class Initialized
INFO - 2023-05-26 06:24:39 --> Router Class Initialized
INFO - 2023-05-26 06:24:39 --> Output Class Initialized
INFO - 2023-05-26 06:24:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:24:39 --> Input Class Initialized
INFO - 2023-05-26 06:24:39 --> Language Class Initialized
INFO - 2023-05-26 06:24:39 --> Loader Class Initialized
INFO - 2023-05-26 06:24:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:24:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:24:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:24:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:24:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:24:39 --> Total execution time: 0.2393
INFO - 2023-05-26 06:24:48 --> Final output sent to browser
DEBUG - 2023-05-26 06:24:48 --> Total execution time: 9.4167
INFO - 2023-05-26 06:24:48 --> Config Class Initialized
INFO - 2023-05-26 06:24:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:24:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:24:48 --> Utf8 Class Initialized
INFO - 2023-05-26 06:24:48 --> URI Class Initialized
INFO - 2023-05-26 06:24:48 --> Router Class Initialized
INFO - 2023-05-26 06:24:48 --> Output Class Initialized
INFO - 2023-05-26 06:24:48 --> Security Class Initialized
DEBUG - 2023-05-26 06:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:24:49 --> Input Class Initialized
INFO - 2023-05-26 06:24:49 --> Language Class Initialized
INFO - 2023-05-26 06:24:49 --> Loader Class Initialized
INFO - 2023-05-26 06:24:49 --> Controller Class Initialized
DEBUG - 2023-05-26 06:24:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:24:49 --> Database Driver Class Initialized
INFO - 2023-05-26 06:24:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:24:49 --> Database Driver Class Initialized
INFO - 2023-05-26 06:24:49 --> Model "Login_model" initialized
INFO - 2023-05-26 06:24:56 --> Final output sent to browser
DEBUG - 2023-05-26 06:24:56 --> Total execution time: 7.4767
INFO - 2023-05-26 06:25:39 --> Config Class Initialized
INFO - 2023-05-26 06:25:39 --> Config Class Initialized
INFO - 2023-05-26 06:25:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:25:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:25:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:25:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:39 --> URI Class Initialized
INFO - 2023-05-26 06:25:39 --> URI Class Initialized
INFO - 2023-05-26 06:25:39 --> Router Class Initialized
INFO - 2023-05-26 06:25:39 --> Router Class Initialized
INFO - 2023-05-26 06:25:39 --> Output Class Initialized
INFO - 2023-05-26 06:25:39 --> Output Class Initialized
INFO - 2023-05-26 06:25:39 --> Security Class Initialized
INFO - 2023-05-26 06:25:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:39 --> Input Class Initialized
INFO - 2023-05-26 06:25:39 --> Input Class Initialized
INFO - 2023-05-26 06:25:39 --> Language Class Initialized
INFO - 2023-05-26 06:25:39 --> Language Class Initialized
INFO - 2023-05-26 06:25:39 --> Loader Class Initialized
INFO - 2023-05-26 06:25:39 --> Controller Class Initialized
INFO - 2023-05-26 06:25:39 --> Loader Class Initialized
DEBUG - 2023-05-26 06:25:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:25:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:25:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:25:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:25:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:25:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:39 --> Final output sent to browser
INFO - 2023-05-26 06:25:39 --> Model "Login_model" initialized
DEBUG - 2023-05-26 06:25:39 --> Total execution time: 0.1814
INFO - 2023-05-26 06:25:39 --> Config Class Initialized
INFO - 2023-05-26 06:25:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:25:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:39 --> URI Class Initialized
INFO - 2023-05-26 06:25:39 --> Router Class Initialized
INFO - 2023-05-26 06:25:39 --> Output Class Initialized
INFO - 2023-05-26 06:25:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:39 --> Input Class Initialized
INFO - 2023-05-26 06:25:39 --> Language Class Initialized
INFO - 2023-05-26 06:25:39 --> Loader Class Initialized
INFO - 2023-05-26 06:25:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:25:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:25:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:25:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:25:39 --> Total execution time: 0.2187
INFO - 2023-05-26 06:25:48 --> Config Class Initialized
INFO - 2023-05-26 06:25:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:25:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:48 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:48 --> URI Class Initialized
INFO - 2023-05-26 06:25:48 --> Router Class Initialized
INFO - 2023-05-26 06:25:48 --> Output Class Initialized
INFO - 2023-05-26 06:25:48 --> Security Class Initialized
DEBUG - 2023-05-26 06:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:48 --> Input Class Initialized
INFO - 2023-05-26 06:25:48 --> Language Class Initialized
INFO - 2023-05-26 06:25:48 --> Loader Class Initialized
INFO - 2023-05-26 06:25:48 --> Controller Class Initialized
DEBUG - 2023-05-26 06:25:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:25:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:25:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:48 --> Model "Login_model" initialized
INFO - 2023-05-26 06:25:49 --> Final output sent to browser
DEBUG - 2023-05-26 06:25:49 --> Total execution time: 9.6699
INFO - 2023-05-26 06:25:49 --> Config Class Initialized
INFO - 2023-05-26 06:25:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:25:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:49 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:49 --> URI Class Initialized
INFO - 2023-05-26 06:25:49 --> Router Class Initialized
INFO - 2023-05-26 06:25:49 --> Output Class Initialized
INFO - 2023-05-26 06:25:49 --> Security Class Initialized
DEBUG - 2023-05-26 06:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:49 --> Input Class Initialized
INFO - 2023-05-26 06:25:49 --> Language Class Initialized
INFO - 2023-05-26 06:25:49 --> Loader Class Initialized
INFO - 2023-05-26 06:25:49 --> Controller Class Initialized
DEBUG - 2023-05-26 06:25:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:25:49 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:25:49 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:49 --> Model "Login_model" initialized
INFO - 2023-05-26 06:25:51 --> Config Class Initialized
INFO - 2023-05-26 06:25:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:25:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:51 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:51 --> URI Class Initialized
INFO - 2023-05-26 06:25:51 --> Router Class Initialized
INFO - 2023-05-26 06:25:51 --> Output Class Initialized
INFO - 2023-05-26 06:25:51 --> Security Class Initialized
DEBUG - 2023-05-26 06:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:51 --> Input Class Initialized
INFO - 2023-05-26 06:25:51 --> Language Class Initialized
INFO - 2023-05-26 06:25:51 --> Loader Class Initialized
INFO - 2023-05-26 06:25:51 --> Controller Class Initialized
DEBUG - 2023-05-26 06:25:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:25:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:51 --> Config Class Initialized
INFO - 2023-05-26 06:25:51 --> Hooks Class Initialized
INFO - 2023-05-26 06:25:51 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:25:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:51 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:51 --> URI Class Initialized
INFO - 2023-05-26 06:25:51 --> Router Class Initialized
INFO - 2023-05-26 06:25:51 --> Output Class Initialized
INFO - 2023-05-26 06:25:51 --> Security Class Initialized
DEBUG - 2023-05-26 06:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:51 --> Input Class Initialized
INFO - 2023-05-26 06:25:51 --> Language Class Initialized
INFO - 2023-05-26 06:25:51 --> Final output sent to browser
DEBUG - 2023-05-26 06:25:51 --> Total execution time: 0.4369
INFO - 2023-05-26 06:25:51 --> Loader Class Initialized
INFO - 2023-05-26 06:25:51 --> Controller Class Initialized
DEBUG - 2023-05-26 06:25:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:25:51 --> Config Class Initialized
INFO - 2023-05-26 06:25:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:25:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:51 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:51 --> URI Class Initialized
INFO - 2023-05-26 06:25:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:25:51 --> Router Class Initialized
INFO - 2023-05-26 06:25:51 --> Output Class Initialized
INFO - 2023-05-26 06:25:51 --> Security Class Initialized
DEBUG - 2023-05-26 06:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:51 --> Final output sent to browser
INFO - 2023-05-26 06:25:51 --> Input Class Initialized
DEBUG - 2023-05-26 06:25:51 --> Total execution time: 0.3582
INFO - 2023-05-26 06:25:51 --> Language Class Initialized
INFO - 2023-05-26 06:25:51 --> Loader Class Initialized
INFO - 2023-05-26 06:25:51 --> Controller Class Initialized
INFO - 2023-05-26 06:25:51 --> Config Class Initialized
INFO - 2023-05-26 06:25:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:25:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:25:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:51 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:51 --> URI Class Initialized
INFO - 2023-05-26 06:25:51 --> Router Class Initialized
INFO - 2023-05-26 06:25:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:51 --> Output Class Initialized
INFO - 2023-05-26 06:25:51 --> Security Class Initialized
DEBUG - 2023-05-26 06:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:51 --> Model "Login_model" initialized
INFO - 2023-05-26 06:25:51 --> Input Class Initialized
INFO - 2023-05-26 06:25:51 --> Language Class Initialized
INFO - 2023-05-26 06:25:51 --> Final output sent to browser
DEBUG - 2023-05-26 06:25:51 --> Total execution time: 0.3184
INFO - 2023-05-26 06:25:51 --> Loader Class Initialized
INFO - 2023-05-26 06:25:51 --> Controller Class Initialized
DEBUG - 2023-05-26 06:25:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:25:51 --> Config Class Initialized
INFO - 2023-05-26 06:25:51 --> Hooks Class Initialized
INFO - 2023-05-26 06:25:51 --> Database Driver Class Initialized
DEBUG - 2023-05-26 06:25:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:52 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:25:52 --> URI Class Initialized
INFO - 2023-05-26 06:25:52 --> Router Class Initialized
INFO - 2023-05-26 06:25:52 --> Output Class Initialized
INFO - 2023-05-26 06:25:52 --> Security Class Initialized
DEBUG - 2023-05-26 06:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:52 --> Input Class Initialized
INFO - 2023-05-26 06:25:52 --> Language Class Initialized
INFO - 2023-05-26 06:25:52 --> Loader Class Initialized
INFO - 2023-05-26 06:25:52 --> Final output sent to browser
INFO - 2023-05-26 06:25:52 --> Controller Class Initialized
DEBUG - 2023-05-26 06:25:52 --> Total execution time: 0.3796
DEBUG - 2023-05-26 06:25:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:25:52 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:52 --> Config Class Initialized
INFO - 2023-05-26 06:25:52 --> Hooks Class Initialized
INFO - 2023-05-26 06:25:52 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:25:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:52 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:52 --> Final output sent to browser
INFO - 2023-05-26 06:25:52 --> URI Class Initialized
DEBUG - 2023-05-26 06:25:52 --> Total execution time: 0.3141
INFO - 2023-05-26 06:25:52 --> Router Class Initialized
INFO - 2023-05-26 06:25:52 --> Output Class Initialized
INFO - 2023-05-26 06:25:52 --> Security Class Initialized
INFO - 2023-05-26 06:25:52 --> Config Class Initialized
DEBUG - 2023-05-26 06:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:52 --> Hooks Class Initialized
INFO - 2023-05-26 06:25:52 --> Input Class Initialized
INFO - 2023-05-26 06:25:52 --> Language Class Initialized
DEBUG - 2023-05-26 06:25:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:52 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:52 --> Loader Class Initialized
INFO - 2023-05-26 06:25:52 --> URI Class Initialized
INFO - 2023-05-26 06:25:52 --> Config Class Initialized
INFO - 2023-05-26 06:25:52 --> Hooks Class Initialized
INFO - 2023-05-26 06:25:52 --> Controller Class Initialized
DEBUG - 2023-05-26 06:25:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:25:52 --> Router Class Initialized
INFO - 2023-05-26 06:25:52 --> Output Class Initialized
INFO - 2023-05-26 06:25:52 --> Security Class Initialized
DEBUG - 2023-05-26 06:25:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:52 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:52 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:52 --> Input Class Initialized
INFO - 2023-05-26 06:25:52 --> URI Class Initialized
INFO - 2023-05-26 06:25:52 --> Language Class Initialized
INFO - 2023-05-26 06:25:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:25:52 --> Router Class Initialized
INFO - 2023-05-26 06:25:52 --> Loader Class Initialized
INFO - 2023-05-26 06:25:52 --> Output Class Initialized
INFO - 2023-05-26 06:25:52 --> Controller Class Initialized
INFO - 2023-05-26 06:25:52 --> Final output sent to browser
INFO - 2023-05-26 06:25:52 --> Security Class Initialized
DEBUG - 2023-05-26 06:25:52 --> Total execution time: 0.3302
DEBUG - 2023-05-26 06:25:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:52 --> Input Class Initialized
INFO - 2023-05-26 06:25:52 --> Language Class Initialized
INFO - 2023-05-26 06:25:52 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:52 --> Loader Class Initialized
INFO - 2023-05-26 06:25:52 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:52 --> Controller Class Initialized
DEBUG - 2023-05-26 06:25:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:25:52 --> Model "Login_model" initialized
INFO - 2023-05-26 06:25:52 --> Final output sent to browser
DEBUG - 2023-05-26 06:25:52 --> Total execution time: 0.3281
INFO - 2023-05-26 06:25:52 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:25:52 --> Final output sent to browser
DEBUG - 2023-05-26 06:25:52 --> Total execution time: 0.4464
INFO - 2023-05-26 06:25:55 --> Final output sent to browser
DEBUG - 2023-05-26 06:25:55 --> Total execution time: 7.5693
INFO - 2023-05-26 06:25:57 --> Final output sent to browser
DEBUG - 2023-05-26 06:25:57 --> Total execution time: 8.1806
INFO - 2023-05-26 06:25:58 --> Config Class Initialized
INFO - 2023-05-26 06:25:58 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:25:58 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:58 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:58 --> URI Class Initialized
INFO - 2023-05-26 06:25:58 --> Router Class Initialized
INFO - 2023-05-26 06:25:58 --> Output Class Initialized
INFO - 2023-05-26 06:25:58 --> Security Class Initialized
DEBUG - 2023-05-26 06:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:58 --> Input Class Initialized
INFO - 2023-05-26 06:25:58 --> Language Class Initialized
INFO - 2023-05-26 06:25:58 --> Loader Class Initialized
INFO - 2023-05-26 06:25:58 --> Controller Class Initialized
DEBUG - 2023-05-26 06:25:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:25:58 --> Final output sent to browser
DEBUG - 2023-05-26 06:25:58 --> Total execution time: 0.1465
INFO - 2023-05-26 06:25:58 --> Config Class Initialized
INFO - 2023-05-26 06:25:58 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:25:58 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:25:58 --> Utf8 Class Initialized
INFO - 2023-05-26 06:25:58 --> URI Class Initialized
INFO - 2023-05-26 06:25:58 --> Router Class Initialized
INFO - 2023-05-26 06:25:58 --> Output Class Initialized
INFO - 2023-05-26 06:25:58 --> Security Class Initialized
DEBUG - 2023-05-26 06:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:25:58 --> Input Class Initialized
INFO - 2023-05-26 06:25:58 --> Language Class Initialized
INFO - 2023-05-26 06:25:58 --> Loader Class Initialized
INFO - 2023-05-26 06:25:58 --> Controller Class Initialized
DEBUG - 2023-05-26 06:25:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:25:58 --> Database Driver Class Initialized
INFO - 2023-05-26 06:25:58 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:25:58 --> Final output sent to browser
DEBUG - 2023-05-26 06:25:58 --> Total execution time: 0.2075
INFO - 2023-05-26 06:34:02 --> Config Class Initialized
INFO - 2023-05-26 06:34:02 --> Config Class Initialized
INFO - 2023-05-26 06:34:02 --> Config Class Initialized
INFO - 2023-05-26 06:34:02 --> Hooks Class Initialized
INFO - 2023-05-26 06:34:02 --> Hooks Class Initialized
INFO - 2023-05-26 06:34:02 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:34:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:34:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:34:02 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:34:02 --> Utf8 Class Initialized
INFO - 2023-05-26 06:34:02 --> Utf8 Class Initialized
INFO - 2023-05-26 06:34:02 --> Utf8 Class Initialized
INFO - 2023-05-26 06:34:02 --> URI Class Initialized
INFO - 2023-05-26 06:34:02 --> URI Class Initialized
INFO - 2023-05-26 06:34:02 --> URI Class Initialized
INFO - 2023-05-26 06:34:02 --> Router Class Initialized
INFO - 2023-05-26 06:34:02 --> Router Class Initialized
INFO - 2023-05-26 06:34:02 --> Router Class Initialized
INFO - 2023-05-26 06:34:02 --> Output Class Initialized
INFO - 2023-05-26 06:34:02 --> Output Class Initialized
INFO - 2023-05-26 06:34:02 --> Output Class Initialized
INFO - 2023-05-26 06:34:02 --> Security Class Initialized
INFO - 2023-05-26 06:34:02 --> Security Class Initialized
INFO - 2023-05-26 06:34:02 --> Security Class Initialized
DEBUG - 2023-05-26 06:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:34:02 --> Input Class Initialized
INFO - 2023-05-26 06:34:02 --> Input Class Initialized
INFO - 2023-05-26 06:34:02 --> Input Class Initialized
INFO - 2023-05-26 06:34:02 --> Language Class Initialized
INFO - 2023-05-26 06:34:02 --> Language Class Initialized
INFO - 2023-05-26 06:34:02 --> Language Class Initialized
INFO - 2023-05-26 06:34:02 --> Loader Class Initialized
INFO - 2023-05-26 06:34:02 --> Loader Class Initialized
INFO - 2023-05-26 06:34:02 --> Controller Class Initialized
INFO - 2023-05-26 06:34:02 --> Controller Class Initialized
INFO - 2023-05-26 06:34:02 --> Loader Class Initialized
DEBUG - 2023-05-26 06:34:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:34:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:34:02 --> Controller Class Initialized
DEBUG - 2023-05-26 06:34:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:34:03 --> Database Driver Class Initialized
INFO - 2023-05-26 06:34:03 --> Database Driver Class Initialized
INFO - 2023-05-26 06:34:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:34:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:34:03 --> Final output sent to browser
INFO - 2023-05-26 06:34:03 --> Final output sent to browser
DEBUG - 2023-05-26 06:34:03 --> Total execution time: 0.2048
DEBUG - 2023-05-26 06:34:03 --> Total execution time: 0.2044
INFO - 2023-05-26 06:34:03 --> Database Driver Class Initialized
INFO - 2023-05-26 06:34:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:34:03 --> Final output sent to browser
DEBUG - 2023-05-26 06:34:03 --> Total execution time: 0.2413
INFO - 2023-05-26 06:34:03 --> Config Class Initialized
INFO - 2023-05-26 06:34:03 --> Config Class Initialized
INFO - 2023-05-26 06:34:03 --> Hooks Class Initialized
INFO - 2023-05-26 06:34:03 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:34:03 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:34:03 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:34:03 --> Utf8 Class Initialized
INFO - 2023-05-26 06:34:03 --> Utf8 Class Initialized
INFO - 2023-05-26 06:34:03 --> URI Class Initialized
INFO - 2023-05-26 06:34:03 --> URI Class Initialized
INFO - 2023-05-26 06:34:03 --> Config Class Initialized
INFO - 2023-05-26 06:34:03 --> Router Class Initialized
INFO - 2023-05-26 06:34:03 --> Router Class Initialized
INFO - 2023-05-26 06:34:03 --> Hooks Class Initialized
INFO - 2023-05-26 06:34:03 --> Output Class Initialized
INFO - 2023-05-26 06:34:03 --> Output Class Initialized
INFO - 2023-05-26 06:34:03 --> Security Class Initialized
INFO - 2023-05-26 06:34:03 --> Security Class Initialized
DEBUG - 2023-05-26 06:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:34:03 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:34:03 --> Input Class Initialized
INFO - 2023-05-26 06:34:03 --> Input Class Initialized
INFO - 2023-05-26 06:34:03 --> Utf8 Class Initialized
INFO - 2023-05-26 06:34:03 --> URI Class Initialized
INFO - 2023-05-26 06:34:03 --> Language Class Initialized
INFO - 2023-05-26 06:34:03 --> Language Class Initialized
INFO - 2023-05-26 06:34:03 --> Router Class Initialized
INFO - 2023-05-26 06:34:03 --> Loader Class Initialized
INFO - 2023-05-26 06:34:03 --> Loader Class Initialized
INFO - 2023-05-26 06:34:03 --> Output Class Initialized
INFO - 2023-05-26 06:34:03 --> Controller Class Initialized
INFO - 2023-05-26 06:34:03 --> Controller Class Initialized
DEBUG - 2023-05-26 06:34:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:34:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:34:03 --> Security Class Initialized
DEBUG - 2023-05-26 06:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:34:03 --> Input Class Initialized
INFO - 2023-05-26 06:34:03 --> Language Class Initialized
INFO - 2023-05-26 06:34:03 --> Database Driver Class Initialized
INFO - 2023-05-26 06:34:03 --> Database Driver Class Initialized
INFO - 2023-05-26 06:34:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:34:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:34:03 --> Loader Class Initialized
INFO - 2023-05-26 06:34:03 --> Final output sent to browser
INFO - 2023-05-26 06:34:03 --> Controller Class Initialized
DEBUG - 2023-05-26 06:34:03 --> Total execution time: 0.2179
DEBUG - 2023-05-26 06:34:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:34:03 --> Final output sent to browser
DEBUG - 2023-05-26 06:34:03 --> Total execution time: 0.2358
INFO - 2023-05-26 06:34:03 --> Database Driver Class Initialized
INFO - 2023-05-26 06:34:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:34:03 --> Final output sent to browser
INFO - 2023-05-26 06:34:03 --> Config Class Initialized
DEBUG - 2023-05-26 06:34:03 --> Total execution time: 0.2653
INFO - 2023-05-26 06:34:03 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:34:03 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:34:03 --> Utf8 Class Initialized
INFO - 2023-05-26 06:34:03 --> URI Class Initialized
INFO - 2023-05-26 06:34:03 --> Router Class Initialized
INFO - 2023-05-26 06:34:03 --> Output Class Initialized
INFO - 2023-05-26 06:34:03 --> Security Class Initialized
DEBUG - 2023-05-26 06:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:34:03 --> Input Class Initialized
INFO - 2023-05-26 06:34:03 --> Language Class Initialized
INFO - 2023-05-26 06:34:03 --> Loader Class Initialized
INFO - 2023-05-26 06:34:03 --> Controller Class Initialized
DEBUG - 2023-05-26 06:34:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:34:03 --> Database Driver Class Initialized
INFO - 2023-05-26 06:34:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:34:03 --> Config Class Initialized
INFO - 2023-05-26 06:34:03 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:34:03 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:34:03 --> Utf8 Class Initialized
INFO - 2023-05-26 06:34:03 --> URI Class Initialized
INFO - 2023-05-26 06:34:03 --> Router Class Initialized
INFO - 2023-05-26 06:34:03 --> Output Class Initialized
INFO - 2023-05-26 06:34:03 --> Security Class Initialized
DEBUG - 2023-05-26 06:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:34:03 --> Input Class Initialized
INFO - 2023-05-26 06:34:03 --> Language Class Initialized
INFO - 2023-05-26 06:34:03 --> Loader Class Initialized
INFO - 2023-05-26 06:34:03 --> Controller Class Initialized
DEBUG - 2023-05-26 06:34:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:34:03 --> Database Driver Class Initialized
INFO - 2023-05-26 06:34:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:43:49 --> Config Class Initialized
INFO - 2023-05-26 06:43:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:43:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:43:49 --> Utf8 Class Initialized
INFO - 2023-05-26 06:43:49 --> URI Class Initialized
INFO - 2023-05-26 06:43:49 --> Router Class Initialized
INFO - 2023-05-26 06:43:49 --> Output Class Initialized
INFO - 2023-05-26 06:43:49 --> Security Class Initialized
DEBUG - 2023-05-26 06:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:43:49 --> Input Class Initialized
INFO - 2023-05-26 06:43:49 --> Language Class Initialized
INFO - 2023-05-26 06:43:49 --> Loader Class Initialized
INFO - 2023-05-26 06:43:49 --> Controller Class Initialized
DEBUG - 2023-05-26 06:43:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:43:49 --> Final output sent to browser
DEBUG - 2023-05-26 06:43:49 --> Total execution time: 0.1662
INFO - 2023-05-26 06:43:49 --> Config Class Initialized
INFO - 2023-05-26 06:43:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:43:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:43:49 --> Utf8 Class Initialized
INFO - 2023-05-26 06:43:49 --> URI Class Initialized
INFO - 2023-05-26 06:43:49 --> Router Class Initialized
INFO - 2023-05-26 06:43:49 --> Output Class Initialized
INFO - 2023-05-26 06:43:50 --> Security Class Initialized
DEBUG - 2023-05-26 06:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:43:50 --> Input Class Initialized
INFO - 2023-05-26 06:43:50 --> Language Class Initialized
INFO - 2023-05-26 06:43:50 --> Loader Class Initialized
INFO - 2023-05-26 06:43:50 --> Controller Class Initialized
DEBUG - 2023-05-26 06:43:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:43:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:43:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:43:50 --> Final output sent to browser
DEBUG - 2023-05-26 06:43:50 --> Total execution time: 0.2553
INFO - 2023-05-26 06:43:53 --> Config Class Initialized
INFO - 2023-05-26 06:43:53 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:43:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:43:53 --> Utf8 Class Initialized
INFO - 2023-05-26 06:43:53 --> URI Class Initialized
INFO - 2023-05-26 06:43:53 --> Router Class Initialized
INFO - 2023-05-26 06:43:53 --> Output Class Initialized
INFO - 2023-05-26 06:43:53 --> Security Class Initialized
DEBUG - 2023-05-26 06:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:43:53 --> Input Class Initialized
INFO - 2023-05-26 06:43:53 --> Language Class Initialized
INFO - 2023-05-26 06:43:53 --> Loader Class Initialized
INFO - 2023-05-26 06:43:54 --> Controller Class Initialized
DEBUG - 2023-05-26 06:43:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:43:54 --> Database Driver Class Initialized
INFO - 2023-05-26 06:43:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:43:54 --> Final output sent to browser
DEBUG - 2023-05-26 06:43:54 --> Total execution time: 0.2746
INFO - 2023-05-26 06:43:54 --> Config Class Initialized
INFO - 2023-05-26 06:43:54 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:43:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:43:54 --> Utf8 Class Initialized
INFO - 2023-05-26 06:43:54 --> URI Class Initialized
INFO - 2023-05-26 06:43:54 --> Router Class Initialized
INFO - 2023-05-26 06:43:54 --> Output Class Initialized
INFO - 2023-05-26 06:43:54 --> Security Class Initialized
DEBUG - 2023-05-26 06:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:43:54 --> Input Class Initialized
INFO - 2023-05-26 06:43:54 --> Language Class Initialized
INFO - 2023-05-26 06:43:54 --> Loader Class Initialized
INFO - 2023-05-26 06:43:54 --> Controller Class Initialized
DEBUG - 2023-05-26 06:43:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:43:54 --> Database Driver Class Initialized
INFO - 2023-05-26 06:43:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:43:54 --> Final output sent to browser
DEBUG - 2023-05-26 06:43:54 --> Total execution time: 0.3536
INFO - 2023-05-26 06:43:59 --> Config Class Initialized
INFO - 2023-05-26 06:43:59 --> Config Class Initialized
INFO - 2023-05-26 06:43:59 --> Hooks Class Initialized
INFO - 2023-05-26 06:43:59 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:43:59 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:43:59 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:43:59 --> Utf8 Class Initialized
INFO - 2023-05-26 06:43:59 --> Utf8 Class Initialized
INFO - 2023-05-26 06:43:59 --> URI Class Initialized
INFO - 2023-05-26 06:43:59 --> URI Class Initialized
INFO - 2023-05-26 06:43:59 --> Router Class Initialized
INFO - 2023-05-26 06:43:59 --> Router Class Initialized
INFO - 2023-05-26 06:43:59 --> Output Class Initialized
INFO - 2023-05-26 06:43:59 --> Output Class Initialized
INFO - 2023-05-26 06:43:59 --> Security Class Initialized
INFO - 2023-05-26 06:43:59 --> Security Class Initialized
DEBUG - 2023-05-26 06:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:43:59 --> Input Class Initialized
INFO - 2023-05-26 06:43:59 --> Input Class Initialized
INFO - 2023-05-26 06:43:59 --> Language Class Initialized
INFO - 2023-05-26 06:43:59 --> Language Class Initialized
INFO - 2023-05-26 06:43:59 --> Loader Class Initialized
INFO - 2023-05-26 06:43:59 --> Controller Class Initialized
INFO - 2023-05-26 06:43:59 --> Loader Class Initialized
DEBUG - 2023-05-26 06:43:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:43:59 --> Controller Class Initialized
DEBUG - 2023-05-26 06:43:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:43:59 --> Database Driver Class Initialized
INFO - 2023-05-26 06:43:59 --> Database Driver Class Initialized
INFO - 2023-05-26 06:43:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:43:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:43:59 --> Final output sent to browser
DEBUG - 2023-05-26 06:43:59 --> Total execution time: 0.1855
INFO - 2023-05-26 06:43:59 --> Final output sent to browser
DEBUG - 2023-05-26 06:43:59 --> Total execution time: 0.1921
INFO - 2023-05-26 06:43:59 --> Config Class Initialized
INFO - 2023-05-26 06:43:59 --> Config Class Initialized
INFO - 2023-05-26 06:43:59 --> Hooks Class Initialized
INFO - 2023-05-26 06:43:59 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:43:59 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:43:59 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:43:59 --> Utf8 Class Initialized
INFO - 2023-05-26 06:43:59 --> Utf8 Class Initialized
INFO - 2023-05-26 06:43:59 --> URI Class Initialized
INFO - 2023-05-26 06:43:59 --> URI Class Initialized
INFO - 2023-05-26 06:43:59 --> Router Class Initialized
INFO - 2023-05-26 06:43:59 --> Router Class Initialized
INFO - 2023-05-26 06:43:59 --> Output Class Initialized
INFO - 2023-05-26 06:43:59 --> Output Class Initialized
INFO - 2023-05-26 06:43:59 --> Security Class Initialized
INFO - 2023-05-26 06:43:59 --> Security Class Initialized
DEBUG - 2023-05-26 06:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:43:59 --> Input Class Initialized
INFO - 2023-05-26 06:43:59 --> Input Class Initialized
INFO - 2023-05-26 06:43:59 --> Language Class Initialized
INFO - 2023-05-26 06:43:59 --> Language Class Initialized
INFO - 2023-05-26 06:43:59 --> Loader Class Initialized
INFO - 2023-05-26 06:43:59 --> Loader Class Initialized
INFO - 2023-05-26 06:43:59 --> Controller Class Initialized
DEBUG - 2023-05-26 06:43:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:43:59 --> Controller Class Initialized
DEBUG - 2023-05-26 06:43:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:43:59 --> Database Driver Class Initialized
INFO - 2023-05-26 06:43:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:43:59 --> Database Driver Class Initialized
INFO - 2023-05-26 06:43:59 --> Final output sent to browser
INFO - 2023-05-26 06:43:59 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:43:59 --> Total execution time: 0.1785
INFO - 2023-05-26 06:43:59 --> Final output sent to browser
DEBUG - 2023-05-26 06:43:59 --> Total execution time: 0.1952
INFO - 2023-05-26 06:44:04 --> Config Class Initialized
INFO - 2023-05-26 06:44:04 --> Config Class Initialized
INFO - 2023-05-26 06:44:04 --> Config Class Initialized
INFO - 2023-05-26 06:44:04 --> Hooks Class Initialized
INFO - 2023-05-26 06:44:04 --> Hooks Class Initialized
INFO - 2023-05-26 06:44:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:44:04 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:44:04 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:44:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:44:04 --> Utf8 Class Initialized
INFO - 2023-05-26 06:44:04 --> Utf8 Class Initialized
INFO - 2023-05-26 06:44:04 --> Utf8 Class Initialized
INFO - 2023-05-26 06:44:04 --> URI Class Initialized
INFO - 2023-05-26 06:44:04 --> URI Class Initialized
INFO - 2023-05-26 06:44:04 --> URI Class Initialized
INFO - 2023-05-26 06:44:04 --> Router Class Initialized
INFO - 2023-05-26 06:44:04 --> Router Class Initialized
INFO - 2023-05-26 06:44:04 --> Router Class Initialized
INFO - 2023-05-26 06:44:04 --> Output Class Initialized
INFO - 2023-05-26 06:44:04 --> Output Class Initialized
INFO - 2023-05-26 06:44:04 --> Output Class Initialized
INFO - 2023-05-26 06:44:04 --> Security Class Initialized
INFO - 2023-05-26 06:44:04 --> Security Class Initialized
INFO - 2023-05-26 06:44:04 --> Security Class Initialized
DEBUG - 2023-05-26 06:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:44:04 --> Config Class Initialized
INFO - 2023-05-26 06:44:04 --> Input Class Initialized
INFO - 2023-05-26 06:44:04 --> Input Class Initialized
INFO - 2023-05-26 06:44:04 --> Hooks Class Initialized
INFO - 2023-05-26 06:44:04 --> Input Class Initialized
INFO - 2023-05-26 06:44:04 --> Language Class Initialized
INFO - 2023-05-26 06:44:04 --> Language Class Initialized
INFO - 2023-05-26 06:44:04 --> Language Class Initialized
INFO - 2023-05-26 06:44:04 --> Loader Class Initialized
INFO - 2023-05-26 06:44:04 --> Loader Class Initialized
INFO - 2023-05-26 06:44:04 --> Loader Class Initialized
INFO - 2023-05-26 06:44:04 --> Controller Class Initialized
INFO - 2023-05-26 06:44:04 --> Controller Class Initialized
INFO - 2023-05-26 06:44:04 --> Controller Class Initialized
DEBUG - 2023-05-26 06:44:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:44:04 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:44:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:44:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:44:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:44:04 --> URI Class Initialized
INFO - 2023-05-26 06:44:04 --> Database Driver Class Initialized
INFO - 2023-05-26 06:44:04 --> Database Driver Class Initialized
INFO - 2023-05-26 06:44:04 --> Database Driver Class Initialized
INFO - 2023-05-26 06:44:04 --> Router Class Initialized
INFO - 2023-05-26 06:44:04 --> Output Class Initialized
INFO - 2023-05-26 06:44:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:44:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:44:04 --> Security Class Initialized
INFO - 2023-05-26 06:44:04 --> Database Driver Class Initialized
DEBUG - 2023-05-26 06:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:44:04 --> Input Class Initialized
INFO - 2023-05-26 06:44:04 --> Final output sent to browser
INFO - 2023-05-26 06:44:04 --> Model "Login_model" initialized
INFO - 2023-05-26 06:44:04 --> Language Class Initialized
DEBUG - 2023-05-26 06:44:04 --> Total execution time: 0.2549
INFO - 2023-05-26 06:44:04 --> Final output sent to browser
DEBUG - 2023-05-26 06:44:04 --> Total execution time: 0.2803
INFO - 2023-05-26 06:44:04 --> Final output sent to browser
DEBUG - 2023-05-26 06:44:04 --> Total execution time: 0.2930
INFO - 2023-05-26 06:44:04 --> Loader Class Initialized
INFO - 2023-05-26 06:44:04 --> Config Class Initialized
INFO - 2023-05-26 06:44:04 --> Controller Class Initialized
INFO - 2023-05-26 06:44:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:44:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:44:04 --> Config Class Initialized
INFO - 2023-05-26 06:44:04 --> Hooks Class Initialized
INFO - 2023-05-26 06:44:04 --> Config Class Initialized
DEBUG - 2023-05-26 06:44:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:44:04 --> Hooks Class Initialized
INFO - 2023-05-26 06:44:04 --> Utf8 Class Initialized
INFO - 2023-05-26 06:44:04 --> URI Class Initialized
DEBUG - 2023-05-26 06:44:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:44:04 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:44:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:44:04 --> Utf8 Class Initialized
INFO - 2023-05-26 06:44:04 --> Router Class Initialized
INFO - 2023-05-26 06:44:04 --> URI Class Initialized
INFO - 2023-05-26 06:44:04 --> URI Class Initialized
INFO - 2023-05-26 06:44:04 --> Output Class Initialized
INFO - 2023-05-26 06:44:04 --> Router Class Initialized
INFO - 2023-05-26 06:44:04 --> Router Class Initialized
INFO - 2023-05-26 06:44:04 --> Database Driver Class Initialized
INFO - 2023-05-26 06:44:04 --> Security Class Initialized
INFO - 2023-05-26 06:44:04 --> Output Class Initialized
INFO - 2023-05-26 06:44:04 --> Output Class Initialized
INFO - 2023-05-26 06:44:04 --> Security Class Initialized
INFO - 2023-05-26 06:44:04 --> Security Class Initialized
DEBUG - 2023-05-26 06:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:44:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:44:04 --> Input Class Initialized
DEBUG - 2023-05-26 06:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:44:04 --> Language Class Initialized
INFO - 2023-05-26 06:44:04 --> Input Class Initialized
INFO - 2023-05-26 06:44:04 --> Input Class Initialized
INFO - 2023-05-26 06:44:04 --> Language Class Initialized
INFO - 2023-05-26 06:44:04 --> Language Class Initialized
INFO - 2023-05-26 06:44:04 --> Final output sent to browser
INFO - 2023-05-26 06:44:04 --> Loader Class Initialized
INFO - 2023-05-26 06:44:04 --> Loader Class Initialized
INFO - 2023-05-26 06:44:04 --> Loader Class Initialized
DEBUG - 2023-05-26 06:44:04 --> Total execution time: 0.4210
INFO - 2023-05-26 06:44:04 --> Controller Class Initialized
INFO - 2023-05-26 06:44:04 --> Controller Class Initialized
INFO - 2023-05-26 06:44:04 --> Controller Class Initialized
DEBUG - 2023-05-26 06:44:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:44:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:44:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:44:04 --> Database Driver Class Initialized
INFO - 2023-05-26 06:44:04 --> Database Driver Class Initialized
INFO - 2023-05-26 06:44:04 --> Database Driver Class Initialized
INFO - 2023-05-26 06:44:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:44:05 --> Config Class Initialized
INFO - 2023-05-26 06:44:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:44:05 --> Hooks Class Initialized
INFO - 2023-05-26 06:44:05 --> Database Driver Class Initialized
INFO - 2023-05-26 06:44:05 --> Model "Login_model" initialized
DEBUG - 2023-05-26 06:44:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:44:05 --> Final output sent to browser
INFO - 2023-05-26 06:44:05 --> Utf8 Class Initialized
INFO - 2023-05-26 06:44:05 --> Final output sent to browser
INFO - 2023-05-26 06:44:05 --> Final output sent to browser
DEBUG - 2023-05-26 06:44:05 --> Total execution time: 0.3005
DEBUG - 2023-05-26 06:44:05 --> Total execution time: 0.2894
DEBUG - 2023-05-26 06:44:05 --> Total execution time: 0.2788
INFO - 2023-05-26 06:44:05 --> URI Class Initialized
INFO - 2023-05-26 06:44:05 --> Router Class Initialized
INFO - 2023-05-26 06:44:05 --> Output Class Initialized
INFO - 2023-05-26 06:44:05 --> Security Class Initialized
DEBUG - 2023-05-26 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:44:05 --> Input Class Initialized
INFO - 2023-05-26 06:44:05 --> Language Class Initialized
INFO - 2023-05-26 06:44:05 --> Loader Class Initialized
INFO - 2023-05-26 06:44:05 --> Controller Class Initialized
DEBUG - 2023-05-26 06:44:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:44:05 --> Database Driver Class Initialized
INFO - 2023-05-26 06:44:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:44:05 --> Final output sent to browser
DEBUG - 2023-05-26 06:44:05 --> Total execution time: 0.2933
INFO - 2023-05-26 06:45:04 --> Config Class Initialized
INFO - 2023-05-26 06:45:04 --> Config Class Initialized
INFO - 2023-05-26 06:45:04 --> Hooks Class Initialized
INFO - 2023-05-26 06:45:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:45:04 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:45:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:45:04 --> Utf8 Class Initialized
INFO - 2023-05-26 06:45:04 --> Utf8 Class Initialized
INFO - 2023-05-26 06:45:04 --> URI Class Initialized
INFO - 2023-05-26 06:45:04 --> URI Class Initialized
INFO - 2023-05-26 06:45:04 --> Router Class Initialized
INFO - 2023-05-26 06:45:04 --> Router Class Initialized
INFO - 2023-05-26 06:45:04 --> Output Class Initialized
INFO - 2023-05-26 06:45:04 --> Output Class Initialized
INFO - 2023-05-26 06:45:04 --> Security Class Initialized
INFO - 2023-05-26 06:45:04 --> Security Class Initialized
DEBUG - 2023-05-26 06:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:45:04 --> Input Class Initialized
INFO - 2023-05-26 06:45:04 --> Input Class Initialized
INFO - 2023-05-26 06:45:04 --> Language Class Initialized
INFO - 2023-05-26 06:45:04 --> Language Class Initialized
INFO - 2023-05-26 06:45:04 --> Loader Class Initialized
INFO - 2023-05-26 06:45:04 --> Loader Class Initialized
INFO - 2023-05-26 06:45:04 --> Controller Class Initialized
DEBUG - 2023-05-26 06:45:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:45:04 --> Controller Class Initialized
DEBUG - 2023-05-26 06:45:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:45:04 --> Database Driver Class Initialized
INFO - 2023-05-26 06:45:04 --> Database Driver Class Initialized
INFO - 2023-05-26 06:45:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:45:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:45:04 --> Database Driver Class Initialized
INFO - 2023-05-26 06:45:05 --> Model "Login_model" initialized
INFO - 2023-05-26 06:45:05 --> Final output sent to browser
DEBUG - 2023-05-26 06:45:05 --> Total execution time: 0.9987
INFO - 2023-05-26 06:45:05 --> Config Class Initialized
INFO - 2023-05-26 06:45:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:45:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:45:05 --> Utf8 Class Initialized
INFO - 2023-05-26 06:45:05 --> URI Class Initialized
INFO - 2023-05-26 06:45:05 --> Router Class Initialized
INFO - 2023-05-26 06:45:05 --> Output Class Initialized
INFO - 2023-05-26 06:45:05 --> Security Class Initialized
DEBUG - 2023-05-26 06:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:45:05 --> Input Class Initialized
INFO - 2023-05-26 06:45:05 --> Language Class Initialized
INFO - 2023-05-26 06:45:05 --> Loader Class Initialized
INFO - 2023-05-26 06:45:05 --> Controller Class Initialized
DEBUG - 2023-05-26 06:45:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:45:05 --> Database Driver Class Initialized
INFO - 2023-05-26 06:45:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:45:05 --> Final output sent to browser
DEBUG - 2023-05-26 06:45:05 --> Total execution time: 0.2763
INFO - 2023-05-26 06:45:15 --> Final output sent to browser
DEBUG - 2023-05-26 06:45:15 --> Total execution time: 10.6229
INFO - 2023-05-26 06:45:15 --> Config Class Initialized
INFO - 2023-05-26 06:45:15 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:45:15 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:45:15 --> Utf8 Class Initialized
INFO - 2023-05-26 06:45:15 --> URI Class Initialized
INFO - 2023-05-26 06:45:15 --> Router Class Initialized
INFO - 2023-05-26 06:45:15 --> Output Class Initialized
INFO - 2023-05-26 06:45:15 --> Security Class Initialized
DEBUG - 2023-05-26 06:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:45:15 --> Input Class Initialized
INFO - 2023-05-26 06:45:15 --> Language Class Initialized
INFO - 2023-05-26 06:45:15 --> Loader Class Initialized
INFO - 2023-05-26 06:45:15 --> Controller Class Initialized
DEBUG - 2023-05-26 06:45:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:45:15 --> Database Driver Class Initialized
INFO - 2023-05-26 06:45:15 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:45:15 --> Database Driver Class Initialized
INFO - 2023-05-26 06:45:15 --> Model "Login_model" initialized
INFO - 2023-05-26 06:45:24 --> Final output sent to browser
DEBUG - 2023-05-26 06:45:24 --> Total execution time: 9.7976
INFO - 2023-05-26 06:46:05 --> Config Class Initialized
INFO - 2023-05-26 06:46:05 --> Config Class Initialized
INFO - 2023-05-26 06:46:05 --> Hooks Class Initialized
INFO - 2023-05-26 06:46:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:46:05 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:46:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:46:05 --> Utf8 Class Initialized
INFO - 2023-05-26 06:46:05 --> Utf8 Class Initialized
INFO - 2023-05-26 06:46:05 --> URI Class Initialized
INFO - 2023-05-26 06:46:05 --> URI Class Initialized
INFO - 2023-05-26 06:46:05 --> Router Class Initialized
INFO - 2023-05-26 06:46:05 --> Router Class Initialized
INFO - 2023-05-26 06:46:05 --> Output Class Initialized
INFO - 2023-05-26 06:46:05 --> Output Class Initialized
INFO - 2023-05-26 06:46:05 --> Security Class Initialized
INFO - 2023-05-26 06:46:05 --> Security Class Initialized
DEBUG - 2023-05-26 06:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:46:05 --> Input Class Initialized
INFO - 2023-05-26 06:46:05 --> Input Class Initialized
INFO - 2023-05-26 06:46:05 --> Language Class Initialized
INFO - 2023-05-26 06:46:05 --> Language Class Initialized
INFO - 2023-05-26 06:46:05 --> Loader Class Initialized
INFO - 2023-05-26 06:46:05 --> Loader Class Initialized
INFO - 2023-05-26 06:46:05 --> Controller Class Initialized
INFO - 2023-05-26 06:46:05 --> Controller Class Initialized
DEBUG - 2023-05-26 06:46:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:46:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:46:05 --> Database Driver Class Initialized
INFO - 2023-05-26 06:46:05 --> Database Driver Class Initialized
INFO - 2023-05-26 06:46:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:46:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:46:05 --> Database Driver Class Initialized
INFO - 2023-05-26 06:46:05 --> Model "Login_model" initialized
INFO - 2023-05-26 06:46:05 --> Final output sent to browser
DEBUG - 2023-05-26 06:46:05 --> Total execution time: 0.2724
INFO - 2023-05-26 06:46:05 --> Config Class Initialized
INFO - 2023-05-26 06:46:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:46:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:46:05 --> Utf8 Class Initialized
INFO - 2023-05-26 06:46:05 --> URI Class Initialized
INFO - 2023-05-26 06:46:05 --> Router Class Initialized
INFO - 2023-05-26 06:46:05 --> Output Class Initialized
INFO - 2023-05-26 06:46:05 --> Security Class Initialized
DEBUG - 2023-05-26 06:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:46:05 --> Input Class Initialized
INFO - 2023-05-26 06:46:05 --> Language Class Initialized
INFO - 2023-05-26 06:46:05 --> Loader Class Initialized
INFO - 2023-05-26 06:46:05 --> Controller Class Initialized
DEBUG - 2023-05-26 06:46:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:46:06 --> Database Driver Class Initialized
INFO - 2023-05-26 06:46:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:46:06 --> Final output sent to browser
DEBUG - 2023-05-26 06:46:06 --> Total execution time: 0.3392
INFO - 2023-05-26 06:46:14 --> Final output sent to browser
DEBUG - 2023-05-26 06:46:14 --> Total execution time: 9.1621
INFO - 2023-05-26 06:46:14 --> Config Class Initialized
INFO - 2023-05-26 06:46:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:46:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:46:14 --> Utf8 Class Initialized
INFO - 2023-05-26 06:46:14 --> URI Class Initialized
INFO - 2023-05-26 06:46:14 --> Router Class Initialized
INFO - 2023-05-26 06:46:14 --> Output Class Initialized
INFO - 2023-05-26 06:46:14 --> Security Class Initialized
DEBUG - 2023-05-26 06:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:46:14 --> Input Class Initialized
INFO - 2023-05-26 06:46:14 --> Language Class Initialized
INFO - 2023-05-26 06:46:14 --> Loader Class Initialized
INFO - 2023-05-26 06:46:14 --> Controller Class Initialized
DEBUG - 2023-05-26 06:46:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:46:14 --> Database Driver Class Initialized
INFO - 2023-05-26 06:46:14 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:46:14 --> Database Driver Class Initialized
INFO - 2023-05-26 06:46:14 --> Model "Login_model" initialized
INFO - 2023-05-26 06:46:25 --> Final output sent to browser
DEBUG - 2023-05-26 06:46:25 --> Total execution time: 10.3593
INFO - 2023-05-26 06:47:05 --> Config Class Initialized
INFO - 2023-05-26 06:47:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:47:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:47:05 --> Utf8 Class Initialized
INFO - 2023-05-26 06:47:05 --> URI Class Initialized
INFO - 2023-05-26 06:47:05 --> Router Class Initialized
INFO - 2023-05-26 06:47:05 --> Output Class Initialized
INFO - 2023-05-26 06:47:05 --> Security Class Initialized
DEBUG - 2023-05-26 06:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:47:05 --> Input Class Initialized
INFO - 2023-05-26 06:47:05 --> Language Class Initialized
INFO - 2023-05-26 06:47:05 --> Loader Class Initialized
INFO - 2023-05-26 06:47:05 --> Controller Class Initialized
DEBUG - 2023-05-26 06:47:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:47:05 --> Database Driver Class Initialized
INFO - 2023-05-26 06:47:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:47:05 --> Final output sent to browser
DEBUG - 2023-05-26 06:47:05 --> Total execution time: 0.2334
INFO - 2023-05-26 06:47:05 --> Config Class Initialized
INFO - 2023-05-26 06:47:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:47:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:47:05 --> Utf8 Class Initialized
INFO - 2023-05-26 06:47:05 --> URI Class Initialized
INFO - 2023-05-26 06:47:05 --> Router Class Initialized
INFO - 2023-05-26 06:47:05 --> Output Class Initialized
INFO - 2023-05-26 06:47:05 --> Security Class Initialized
DEBUG - 2023-05-26 06:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:47:05 --> Input Class Initialized
INFO - 2023-05-26 06:47:05 --> Language Class Initialized
INFO - 2023-05-26 06:47:05 --> Loader Class Initialized
INFO - 2023-05-26 06:47:05 --> Controller Class Initialized
DEBUG - 2023-05-26 06:47:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:47:05 --> Database Driver Class Initialized
INFO - 2023-05-26 06:47:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:47:06 --> Final output sent to browser
DEBUG - 2023-05-26 06:47:06 --> Total execution time: 0.5104
INFO - 2023-05-26 06:47:31 --> Config Class Initialized
INFO - 2023-05-26 06:47:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:47:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:47:31 --> Utf8 Class Initialized
INFO - 2023-05-26 06:47:31 --> URI Class Initialized
INFO - 2023-05-26 06:47:31 --> Router Class Initialized
INFO - 2023-05-26 06:47:31 --> Output Class Initialized
INFO - 2023-05-26 06:47:31 --> Security Class Initialized
DEBUG - 2023-05-26 06:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:47:31 --> Input Class Initialized
INFO - 2023-05-26 06:47:31 --> Language Class Initialized
INFO - 2023-05-26 06:47:31 --> Loader Class Initialized
INFO - 2023-05-26 06:47:31 --> Controller Class Initialized
DEBUG - 2023-05-26 06:47:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:47:31 --> Database Driver Class Initialized
INFO - 2023-05-26 06:47:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:47:31 --> Database Driver Class Initialized
INFO - 2023-05-26 06:47:31 --> Model "Login_model" initialized
INFO - 2023-05-26 06:47:41 --> Final output sent to browser
DEBUG - 2023-05-26 06:47:41 --> Total execution time: 10.3783
INFO - 2023-05-26 06:47:41 --> Config Class Initialized
INFO - 2023-05-26 06:47:41 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:47:41 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:47:41 --> Utf8 Class Initialized
INFO - 2023-05-26 06:47:41 --> URI Class Initialized
INFO - 2023-05-26 06:47:42 --> Router Class Initialized
INFO - 2023-05-26 06:47:42 --> Output Class Initialized
INFO - 2023-05-26 06:47:42 --> Security Class Initialized
DEBUG - 2023-05-26 06:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:47:42 --> Input Class Initialized
INFO - 2023-05-26 06:47:42 --> Language Class Initialized
INFO - 2023-05-26 06:47:42 --> Loader Class Initialized
INFO - 2023-05-26 06:47:42 --> Controller Class Initialized
DEBUG - 2023-05-26 06:47:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:47:42 --> Database Driver Class Initialized
INFO - 2023-05-26 06:47:42 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:47:42 --> Database Driver Class Initialized
INFO - 2023-05-26 06:47:42 --> Model "Login_model" initialized
INFO - 2023-05-26 06:48:00 --> Final output sent to browser
DEBUG - 2023-05-26 06:48:00 --> Total execution time: 18.1972
INFO - 2023-05-26 06:48:32 --> Config Class Initialized
INFO - 2023-05-26 06:48:32 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:48:32 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:48:32 --> Utf8 Class Initialized
INFO - 2023-05-26 06:48:32 --> URI Class Initialized
INFO - 2023-05-26 06:48:32 --> Router Class Initialized
INFO - 2023-05-26 06:48:32 --> Output Class Initialized
INFO - 2023-05-26 06:48:32 --> Security Class Initialized
DEBUG - 2023-05-26 06:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:48:32 --> Input Class Initialized
INFO - 2023-05-26 06:48:32 --> Language Class Initialized
INFO - 2023-05-26 06:48:32 --> Loader Class Initialized
INFO - 2023-05-26 06:48:32 --> Controller Class Initialized
DEBUG - 2023-05-26 06:48:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:48:32 --> Database Driver Class Initialized
INFO - 2023-05-26 06:48:32 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:48:32 --> Final output sent to browser
DEBUG - 2023-05-26 06:48:32 --> Total execution time: 0.2416
INFO - 2023-05-26 06:48:32 --> Config Class Initialized
INFO - 2023-05-26 06:48:32 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:48:32 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:48:32 --> Utf8 Class Initialized
INFO - 2023-05-26 06:48:32 --> URI Class Initialized
INFO - 2023-05-26 06:48:32 --> Router Class Initialized
INFO - 2023-05-26 06:48:32 --> Output Class Initialized
INFO - 2023-05-26 06:48:32 --> Security Class Initialized
DEBUG - 2023-05-26 06:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:48:32 --> Input Class Initialized
INFO - 2023-05-26 06:48:32 --> Language Class Initialized
INFO - 2023-05-26 06:48:32 --> Loader Class Initialized
INFO - 2023-05-26 06:48:32 --> Controller Class Initialized
DEBUG - 2023-05-26 06:48:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:48:32 --> Database Driver Class Initialized
INFO - 2023-05-26 06:48:32 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:48:33 --> Final output sent to browser
DEBUG - 2023-05-26 06:48:33 --> Total execution time: 0.2853
INFO - 2023-05-26 06:48:39 --> Config Class Initialized
INFO - 2023-05-26 06:48:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:48:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:48:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:48:39 --> URI Class Initialized
INFO - 2023-05-26 06:48:39 --> Router Class Initialized
INFO - 2023-05-26 06:48:39 --> Output Class Initialized
INFO - 2023-05-26 06:48:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:48:39 --> Input Class Initialized
INFO - 2023-05-26 06:48:39 --> Language Class Initialized
INFO - 2023-05-26 06:48:39 --> Loader Class Initialized
INFO - 2023-05-26 06:48:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:48:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:48:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:48:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:48:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:48:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:48:49 --> Final output sent to browser
DEBUG - 2023-05-26 06:48:49 --> Total execution time: 9.7157
INFO - 2023-05-26 06:48:49 --> Config Class Initialized
INFO - 2023-05-26 06:48:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:48:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:48:49 --> Utf8 Class Initialized
INFO - 2023-05-26 06:48:49 --> URI Class Initialized
INFO - 2023-05-26 06:48:49 --> Router Class Initialized
INFO - 2023-05-26 06:48:49 --> Output Class Initialized
INFO - 2023-05-26 06:48:49 --> Security Class Initialized
DEBUG - 2023-05-26 06:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:48:49 --> Input Class Initialized
INFO - 2023-05-26 06:48:49 --> Language Class Initialized
INFO - 2023-05-26 06:48:49 --> Loader Class Initialized
INFO - 2023-05-26 06:48:49 --> Controller Class Initialized
DEBUG - 2023-05-26 06:48:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:48:49 --> Database Driver Class Initialized
INFO - 2023-05-26 06:48:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:48:49 --> Database Driver Class Initialized
INFO - 2023-05-26 06:48:49 --> Model "Login_model" initialized
INFO - 2023-05-26 06:48:57 --> Final output sent to browser
DEBUG - 2023-05-26 06:48:57 --> Total execution time: 8.7518
INFO - 2023-05-26 06:49:39 --> Config Class Initialized
INFO - 2023-05-26 06:49:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:49:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:49:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:49:39 --> URI Class Initialized
INFO - 2023-05-26 06:49:39 --> Router Class Initialized
INFO - 2023-05-26 06:49:39 --> Output Class Initialized
INFO - 2023-05-26 06:49:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:49:39 --> Input Class Initialized
INFO - 2023-05-26 06:49:39 --> Language Class Initialized
INFO - 2023-05-26 06:49:39 --> Loader Class Initialized
INFO - 2023-05-26 06:49:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:49:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:49:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:49:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:49:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:49:39 --> Total execution time: 0.1916
INFO - 2023-05-26 06:49:39 --> Config Class Initialized
INFO - 2023-05-26 06:49:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:49:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:49:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:49:39 --> URI Class Initialized
INFO - 2023-05-26 06:49:39 --> Router Class Initialized
INFO - 2023-05-26 06:49:39 --> Output Class Initialized
INFO - 2023-05-26 06:49:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:49:39 --> Input Class Initialized
INFO - 2023-05-26 06:49:39 --> Language Class Initialized
INFO - 2023-05-26 06:49:39 --> Loader Class Initialized
INFO - 2023-05-26 06:49:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:49:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:49:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:49:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:49:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:49:39 --> Total execution time: 0.2325
INFO - 2023-05-26 06:50:39 --> Config Class Initialized
INFO - 2023-05-26 06:50:39 --> Config Class Initialized
INFO - 2023-05-26 06:50:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:50:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:50:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:50:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:50:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:50:39 --> URI Class Initialized
INFO - 2023-05-26 06:50:39 --> URI Class Initialized
INFO - 2023-05-26 06:50:39 --> Router Class Initialized
INFO - 2023-05-26 06:50:39 --> Router Class Initialized
INFO - 2023-05-26 06:50:39 --> Output Class Initialized
INFO - 2023-05-26 06:50:39 --> Output Class Initialized
INFO - 2023-05-26 06:50:39 --> Security Class Initialized
INFO - 2023-05-26 06:50:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:50:39 --> Input Class Initialized
INFO - 2023-05-26 06:50:39 --> Input Class Initialized
INFO - 2023-05-26 06:50:39 --> Language Class Initialized
INFO - 2023-05-26 06:50:39 --> Language Class Initialized
INFO - 2023-05-26 06:50:39 --> Loader Class Initialized
INFO - 2023-05-26 06:50:39 --> Loader Class Initialized
INFO - 2023-05-26 06:50:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:50:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:50:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:50:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:50:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:50:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:50:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:50:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:50:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:50:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:50:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:50:39 --> Total execution time: 0.1961
INFO - 2023-05-26 06:50:39 --> Config Class Initialized
INFO - 2023-05-26 06:50:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:50:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:50:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:50:39 --> URI Class Initialized
INFO - 2023-05-26 06:50:39 --> Router Class Initialized
INFO - 2023-05-26 06:50:39 --> Output Class Initialized
INFO - 2023-05-26 06:50:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:50:39 --> Input Class Initialized
INFO - 2023-05-26 06:50:39 --> Language Class Initialized
INFO - 2023-05-26 06:50:39 --> Loader Class Initialized
INFO - 2023-05-26 06:50:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:50:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:50:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:50:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:50:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:50:39 --> Total execution time: 0.2154
INFO - 2023-05-26 06:50:49 --> Final output sent to browser
DEBUG - 2023-05-26 06:50:49 --> Total execution time: 10.0462
INFO - 2023-05-26 06:50:49 --> Config Class Initialized
INFO - 2023-05-26 06:50:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:50:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:50:49 --> Utf8 Class Initialized
INFO - 2023-05-26 06:50:49 --> URI Class Initialized
INFO - 2023-05-26 06:50:49 --> Router Class Initialized
INFO - 2023-05-26 06:50:49 --> Output Class Initialized
INFO - 2023-05-26 06:50:49 --> Security Class Initialized
DEBUG - 2023-05-26 06:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:50:49 --> Input Class Initialized
INFO - 2023-05-26 06:50:49 --> Language Class Initialized
INFO - 2023-05-26 06:50:49 --> Loader Class Initialized
INFO - 2023-05-26 06:50:49 --> Controller Class Initialized
DEBUG - 2023-05-26 06:50:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:50:49 --> Database Driver Class Initialized
INFO - 2023-05-26 06:50:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:50:49 --> Database Driver Class Initialized
INFO - 2023-05-26 06:50:49 --> Model "Login_model" initialized
INFO - 2023-05-26 06:50:59 --> Final output sent to browser
DEBUG - 2023-05-26 06:50:59 --> Total execution time: 9.8642
INFO - 2023-05-26 06:51:39 --> Config Class Initialized
INFO - 2023-05-26 06:51:39 --> Config Class Initialized
INFO - 2023-05-26 06:51:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:51:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:51:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:51:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:51:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:51:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:51:39 --> URI Class Initialized
INFO - 2023-05-26 06:51:39 --> URI Class Initialized
INFO - 2023-05-26 06:51:39 --> Router Class Initialized
INFO - 2023-05-26 06:51:39 --> Router Class Initialized
INFO - 2023-05-26 06:51:39 --> Output Class Initialized
INFO - 2023-05-26 06:51:39 --> Output Class Initialized
INFO - 2023-05-26 06:51:39 --> Security Class Initialized
INFO - 2023-05-26 06:51:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:51:39 --> Input Class Initialized
INFO - 2023-05-26 06:51:39 --> Input Class Initialized
INFO - 2023-05-26 06:51:39 --> Language Class Initialized
INFO - 2023-05-26 06:51:39 --> Language Class Initialized
INFO - 2023-05-26 06:51:39 --> Loader Class Initialized
INFO - 2023-05-26 06:51:39 --> Controller Class Initialized
INFO - 2023-05-26 06:51:39 --> Loader Class Initialized
DEBUG - 2023-05-26 06:51:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:51:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:51:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:51:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:51:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:51:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:51:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:51:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:51:39 --> Total execution time: 0.1913
INFO - 2023-05-26 06:51:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:51:39 --> Model "Login_model" initialized
INFO - 2023-05-26 06:51:39 --> Config Class Initialized
INFO - 2023-05-26 06:51:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:51:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:51:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:51:39 --> URI Class Initialized
INFO - 2023-05-26 06:51:39 --> Router Class Initialized
INFO - 2023-05-26 06:51:39 --> Output Class Initialized
INFO - 2023-05-26 06:51:39 --> Security Class Initialized
DEBUG - 2023-05-26 06:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:51:39 --> Input Class Initialized
INFO - 2023-05-26 06:51:39 --> Language Class Initialized
INFO - 2023-05-26 06:51:39 --> Loader Class Initialized
INFO - 2023-05-26 06:51:39 --> Controller Class Initialized
DEBUG - 2023-05-26 06:51:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:51:39 --> Database Driver Class Initialized
INFO - 2023-05-26 06:51:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:51:39 --> Final output sent to browser
DEBUG - 2023-05-26 06:51:39 --> Total execution time: 0.2444
INFO - 2023-05-26 06:51:48 --> Final output sent to browser
DEBUG - 2023-05-26 06:51:48 --> Total execution time: 9.2676
INFO - 2023-05-26 06:51:48 --> Config Class Initialized
INFO - 2023-05-26 06:51:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:51:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:51:48 --> Utf8 Class Initialized
INFO - 2023-05-26 06:51:48 --> URI Class Initialized
INFO - 2023-05-26 06:51:48 --> Router Class Initialized
INFO - 2023-05-26 06:51:48 --> Output Class Initialized
INFO - 2023-05-26 06:51:48 --> Security Class Initialized
DEBUG - 2023-05-26 06:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:51:48 --> Input Class Initialized
INFO - 2023-05-26 06:51:48 --> Language Class Initialized
INFO - 2023-05-26 06:51:48 --> Loader Class Initialized
INFO - 2023-05-26 06:51:48 --> Controller Class Initialized
DEBUG - 2023-05-26 06:51:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:51:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:51:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:51:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:51:49 --> Model "Login_model" initialized
INFO - 2023-05-26 06:51:59 --> Final output sent to browser
DEBUG - 2023-05-26 06:51:59 --> Total execution time: 10.2517
INFO - 2023-05-26 06:52:39 --> Config Class Initialized
INFO - 2023-05-26 06:52:39 --> Config Class Initialized
INFO - 2023-05-26 06:52:39 --> Hooks Class Initialized
INFO - 2023-05-26 06:52:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:52:39 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:52:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:52:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:52:39 --> Utf8 Class Initialized
INFO - 2023-05-26 06:52:39 --> URI Class Initialized
INFO - 2023-05-26 06:52:39 --> URI Class Initialized
INFO - 2023-05-26 06:52:39 --> Router Class Initialized
INFO - 2023-05-26 06:52:39 --> Router Class Initialized
INFO - 2023-05-26 06:52:39 --> Output Class Initialized
INFO - 2023-05-26 06:52:39 --> Output Class Initialized
INFO - 2023-05-26 06:52:40 --> Security Class Initialized
INFO - 2023-05-26 06:52:40 --> Security Class Initialized
DEBUG - 2023-05-26 06:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:52:40 --> Input Class Initialized
INFO - 2023-05-26 06:52:40 --> Input Class Initialized
INFO - 2023-05-26 06:52:40 --> Language Class Initialized
INFO - 2023-05-26 06:52:40 --> Language Class Initialized
INFO - 2023-05-26 06:52:40 --> Loader Class Initialized
INFO - 2023-05-26 06:52:40 --> Loader Class Initialized
INFO - 2023-05-26 06:52:40 --> Controller Class Initialized
INFO - 2023-05-26 06:52:40 --> Controller Class Initialized
DEBUG - 2023-05-26 06:52:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:52:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:52:40 --> Database Driver Class Initialized
INFO - 2023-05-26 06:52:40 --> Database Driver Class Initialized
INFO - 2023-05-26 06:52:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:52:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:52:40 --> Database Driver Class Initialized
INFO - 2023-05-26 06:52:40 --> Model "Login_model" initialized
INFO - 2023-05-26 06:52:40 --> Final output sent to browser
DEBUG - 2023-05-26 06:52:40 --> Total execution time: 0.6687
INFO - 2023-05-26 06:52:40 --> Config Class Initialized
INFO - 2023-05-26 06:52:40 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:52:40 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:52:40 --> Utf8 Class Initialized
INFO - 2023-05-26 06:52:40 --> URI Class Initialized
INFO - 2023-05-26 06:52:40 --> Router Class Initialized
INFO - 2023-05-26 06:52:41 --> Output Class Initialized
INFO - 2023-05-26 06:52:41 --> Security Class Initialized
DEBUG - 2023-05-26 06:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:52:41 --> Input Class Initialized
INFO - 2023-05-26 06:52:41 --> Language Class Initialized
INFO - 2023-05-26 06:52:41 --> Loader Class Initialized
INFO - 2023-05-26 06:52:41 --> Controller Class Initialized
DEBUG - 2023-05-26 06:52:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:52:41 --> Database Driver Class Initialized
INFO - 2023-05-26 06:52:41 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:52:41 --> Final output sent to browser
DEBUG - 2023-05-26 06:52:41 --> Total execution time: 0.9228
INFO - 2023-05-26 06:52:45 --> Config Class Initialized
INFO - 2023-05-26 06:52:45 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:52:45 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:52:45 --> Utf8 Class Initialized
INFO - 2023-05-26 06:52:45 --> URI Class Initialized
INFO - 2023-05-26 06:52:45 --> Router Class Initialized
INFO - 2023-05-26 06:52:45 --> Output Class Initialized
INFO - 2023-05-26 06:52:45 --> Security Class Initialized
DEBUG - 2023-05-26 06:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:52:45 --> Input Class Initialized
INFO - 2023-05-26 06:52:45 --> Language Class Initialized
INFO - 2023-05-26 06:52:45 --> Loader Class Initialized
INFO - 2023-05-26 06:52:45 --> Controller Class Initialized
DEBUG - 2023-05-26 06:52:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:52:45 --> Database Driver Class Initialized
INFO - 2023-05-26 06:52:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:52:46 --> Database Driver Class Initialized
INFO - 2023-05-26 06:52:46 --> Model "Login_model" initialized
INFO - 2023-05-26 06:52:50 --> Final output sent to browser
DEBUG - 2023-05-26 06:52:50 --> Total execution time: 10.2289
INFO - 2023-05-26 06:52:50 --> Config Class Initialized
INFO - 2023-05-26 06:52:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:52:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:52:50 --> Utf8 Class Initialized
INFO - 2023-05-26 06:52:50 --> URI Class Initialized
INFO - 2023-05-26 06:52:50 --> Router Class Initialized
INFO - 2023-05-26 06:52:50 --> Output Class Initialized
INFO - 2023-05-26 06:52:50 --> Security Class Initialized
DEBUG - 2023-05-26 06:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:52:50 --> Input Class Initialized
INFO - 2023-05-26 06:52:50 --> Language Class Initialized
INFO - 2023-05-26 06:52:50 --> Loader Class Initialized
INFO - 2023-05-26 06:52:50 --> Controller Class Initialized
DEBUG - 2023-05-26 06:52:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:52:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:52:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:52:50 --> Database Driver Class Initialized
INFO - 2023-05-26 06:52:50 --> Model "Login_model" initialized
INFO - 2023-05-26 06:52:52 --> Final output sent to browser
DEBUG - 2023-05-26 06:52:52 --> Total execution time: 7.0767
INFO - 2023-05-26 06:52:57 --> Final output sent to browser
DEBUG - 2023-05-26 06:52:57 --> Total execution time: 7.8137
INFO - 2023-05-26 06:52:57 --> Config Class Initialized
INFO - 2023-05-26 06:52:57 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:52:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:52:57 --> Utf8 Class Initialized
INFO - 2023-05-26 06:52:57 --> URI Class Initialized
INFO - 2023-05-26 06:52:57 --> Router Class Initialized
INFO - 2023-05-26 06:52:57 --> Output Class Initialized
INFO - 2023-05-26 06:52:57 --> Security Class Initialized
DEBUG - 2023-05-26 06:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:52:57 --> Input Class Initialized
INFO - 2023-05-26 06:52:58 --> Language Class Initialized
INFO - 2023-05-26 06:52:58 --> Loader Class Initialized
INFO - 2023-05-26 06:52:58 --> Controller Class Initialized
DEBUG - 2023-05-26 06:52:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:52:58 --> Database Driver Class Initialized
INFO - 2023-05-26 06:52:58 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:52:58 --> Database Driver Class Initialized
INFO - 2023-05-26 06:52:58 --> Model "Login_model" initialized
INFO - 2023-05-26 06:53:04 --> Config Class Initialized
INFO - 2023-05-26 06:53:04 --> Config Class Initialized
INFO - 2023-05-26 06:53:04 --> Hooks Class Initialized
INFO - 2023-05-26 06:53:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:53:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:53:04 --> Utf8 Class Initialized
INFO - 2023-05-26 06:53:04 --> Utf8 Class Initialized
INFO - 2023-05-26 06:53:04 --> URI Class Initialized
INFO - 2023-05-26 06:53:04 --> URI Class Initialized
INFO - 2023-05-26 06:53:04 --> Router Class Initialized
INFO - 2023-05-26 06:53:04 --> Router Class Initialized
INFO - 2023-05-26 06:53:04 --> Output Class Initialized
INFO - 2023-05-26 06:53:04 --> Output Class Initialized
INFO - 2023-05-26 06:53:04 --> Security Class Initialized
INFO - 2023-05-26 06:53:04 --> Security Class Initialized
DEBUG - 2023-05-26 06:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:53:04 --> Input Class Initialized
INFO - 2023-05-26 06:53:04 --> Input Class Initialized
INFO - 2023-05-26 06:53:04 --> Language Class Initialized
INFO - 2023-05-26 06:53:04 --> Language Class Initialized
INFO - 2023-05-26 06:53:04 --> Loader Class Initialized
INFO - 2023-05-26 06:53:04 --> Controller Class Initialized
INFO - 2023-05-26 06:53:04 --> Loader Class Initialized
DEBUG - 2023-05-26 06:53:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:53:04 --> Controller Class Initialized
DEBUG - 2023-05-26 06:53:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:53:04 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:04 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:53:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:53:04 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:04 --> Final output sent to browser
INFO - 2023-05-26 06:53:04 --> Model "Login_model" initialized
DEBUG - 2023-05-26 06:53:04 --> Total execution time: 0.2590
INFO - 2023-05-26 06:53:04 --> Config Class Initialized
INFO - 2023-05-26 06:53:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:53:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:53:04 --> Utf8 Class Initialized
INFO - 2023-05-26 06:53:04 --> URI Class Initialized
INFO - 2023-05-26 06:53:04 --> Router Class Initialized
INFO - 2023-05-26 06:53:04 --> Output Class Initialized
INFO - 2023-05-26 06:53:04 --> Security Class Initialized
DEBUG - 2023-05-26 06:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:53:04 --> Input Class Initialized
INFO - 2023-05-26 06:53:04 --> Language Class Initialized
INFO - 2023-05-26 06:53:04 --> Loader Class Initialized
INFO - 2023-05-26 06:53:04 --> Controller Class Initialized
DEBUG - 2023-05-26 06:53:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:53:05 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:53:05 --> Final output sent to browser
DEBUG - 2023-05-26 06:53:05 --> Total execution time: 0.3052
INFO - 2023-05-26 06:53:06 --> Final output sent to browser
DEBUG - 2023-05-26 06:53:06 --> Total execution time: 8.5430
INFO - 2023-05-26 06:53:12 --> Final output sent to browser
DEBUG - 2023-05-26 06:53:12 --> Total execution time: 7.9244
INFO - 2023-05-26 06:53:12 --> Config Class Initialized
INFO - 2023-05-26 06:53:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:53:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:53:12 --> Utf8 Class Initialized
INFO - 2023-05-26 06:53:12 --> URI Class Initialized
INFO - 2023-05-26 06:53:12 --> Router Class Initialized
INFO - 2023-05-26 06:53:12 --> Output Class Initialized
INFO - 2023-05-26 06:53:12 --> Security Class Initialized
DEBUG - 2023-05-26 06:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:53:12 --> Input Class Initialized
INFO - 2023-05-26 06:53:12 --> Language Class Initialized
INFO - 2023-05-26 06:53:12 --> Loader Class Initialized
INFO - 2023-05-26 06:53:12 --> Controller Class Initialized
DEBUG - 2023-05-26 06:53:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:53:12 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:53:12 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:12 --> Model "Login_model" initialized
INFO - 2023-05-26 06:53:21 --> Final output sent to browser
DEBUG - 2023-05-26 06:53:21 --> Total execution time: 8.8043
INFO - 2023-05-26 06:53:47 --> Config Class Initialized
INFO - 2023-05-26 06:53:47 --> Config Class Initialized
INFO - 2023-05-26 06:53:47 --> Config Class Initialized
INFO - 2023-05-26 06:53:47 --> Hooks Class Initialized
INFO - 2023-05-26 06:53:47 --> Hooks Class Initialized
INFO - 2023-05-26 06:53:47 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:53:47 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:53:47 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:53:47 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:53:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:53:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:53:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:53:47 --> URI Class Initialized
INFO - 2023-05-26 06:53:47 --> URI Class Initialized
INFO - 2023-05-26 06:53:47 --> URI Class Initialized
INFO - 2023-05-26 06:53:47 --> Router Class Initialized
INFO - 2023-05-26 06:53:47 --> Router Class Initialized
INFO - 2023-05-26 06:53:47 --> Router Class Initialized
INFO - 2023-05-26 06:53:47 --> Output Class Initialized
INFO - 2023-05-26 06:53:47 --> Output Class Initialized
INFO - 2023-05-26 06:53:47 --> Output Class Initialized
INFO - 2023-05-26 06:53:47 --> Security Class Initialized
INFO - 2023-05-26 06:53:47 --> Security Class Initialized
INFO - 2023-05-26 06:53:47 --> Security Class Initialized
DEBUG - 2023-05-26 06:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:53:47 --> Input Class Initialized
INFO - 2023-05-26 06:53:47 --> Input Class Initialized
INFO - 2023-05-26 06:53:47 --> Input Class Initialized
INFO - 2023-05-26 06:53:47 --> Language Class Initialized
INFO - 2023-05-26 06:53:47 --> Language Class Initialized
INFO - 2023-05-26 06:53:47 --> Language Class Initialized
INFO - 2023-05-26 06:53:47 --> Loader Class Initialized
INFO - 2023-05-26 06:53:47 --> Loader Class Initialized
INFO - 2023-05-26 06:53:47 --> Loader Class Initialized
INFO - 2023-05-26 06:53:47 --> Controller Class Initialized
INFO - 2023-05-26 06:53:47 --> Controller Class Initialized
INFO - 2023-05-26 06:53:47 --> Controller Class Initialized
DEBUG - 2023-05-26 06:53:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:53:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:53:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:53:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:53:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:53:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:47 --> Model "Login_model" initialized
INFO - 2023-05-26 06:53:47 --> Final output sent to browser
DEBUG - 2023-05-26 06:53:47 --> Total execution time: 0.3119
INFO - 2023-05-26 06:53:47 --> Final output sent to browser
DEBUG - 2023-05-26 06:53:47 --> Total execution time: 0.3199
INFO - 2023-05-26 06:53:47 --> Final output sent to browser
DEBUG - 2023-05-26 06:53:47 --> Total execution time: 0.3344
INFO - 2023-05-26 06:53:47 --> Config Class Initialized
INFO - 2023-05-26 06:53:47 --> Config Class Initialized
INFO - 2023-05-26 06:53:47 --> Hooks Class Initialized
INFO - 2023-05-26 06:53:47 --> Hooks Class Initialized
INFO - 2023-05-26 06:53:47 --> Config Class Initialized
DEBUG - 2023-05-26 06:53:47 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:53:47 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:53:47 --> Hooks Class Initialized
INFO - 2023-05-26 06:53:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:53:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:53:47 --> URI Class Initialized
INFO - 2023-05-26 06:53:47 --> URI Class Initialized
INFO - 2023-05-26 06:53:47 --> Router Class Initialized
INFO - 2023-05-26 06:53:47 --> Router Class Initialized
DEBUG - 2023-05-26 06:53:47 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:53:47 --> Output Class Initialized
INFO - 2023-05-26 06:53:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:53:47 --> Output Class Initialized
INFO - 2023-05-26 06:53:47 --> Security Class Initialized
INFO - 2023-05-26 06:53:47 --> Security Class Initialized
INFO - 2023-05-26 06:53:47 --> URI Class Initialized
DEBUG - 2023-05-26 06:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:53:47 --> Input Class Initialized
INFO - 2023-05-26 06:53:47 --> Input Class Initialized
INFO - 2023-05-26 06:53:47 --> Language Class Initialized
INFO - 2023-05-26 06:53:47 --> Router Class Initialized
INFO - 2023-05-26 06:53:47 --> Language Class Initialized
INFO - 2023-05-26 06:53:47 --> Output Class Initialized
INFO - 2023-05-26 06:53:47 --> Loader Class Initialized
INFO - 2023-05-26 06:53:47 --> Loader Class Initialized
INFO - 2023-05-26 06:53:47 --> Security Class Initialized
INFO - 2023-05-26 06:53:47 --> Controller Class Initialized
INFO - 2023-05-26 06:53:47 --> Controller Class Initialized
DEBUG - 2023-05-26 06:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:53:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:53:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:53:47 --> Input Class Initialized
INFO - 2023-05-26 06:53:47 --> Language Class Initialized
INFO - 2023-05-26 06:53:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:47 --> Loader Class Initialized
INFO - 2023-05-26 06:53:47 --> Controller Class Initialized
DEBUG - 2023-05-26 06:53:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:53:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:53:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:53:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:48 --> Final output sent to browser
DEBUG - 2023-05-26 06:53:48 --> Total execution time: 0.3284
INFO - 2023-05-26 06:53:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:53:48 --> Final output sent to browser
DEBUG - 2023-05-26 06:53:48 --> Total execution time: 0.3422
INFO - 2023-05-26 06:53:48 --> Final output sent to browser
INFO - 2023-05-26 06:53:48 --> Config Class Initialized
DEBUG - 2023-05-26 06:53:48 --> Total execution time: 0.3709
INFO - 2023-05-26 06:53:48 --> Hooks Class Initialized
INFO - 2023-05-26 06:53:48 --> Config Class Initialized
INFO - 2023-05-26 06:53:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:53:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:53:48 --> Utf8 Class Initialized
INFO - 2023-05-26 06:53:48 --> URI Class Initialized
DEBUG - 2023-05-26 06:53:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:53:48 --> Utf8 Class Initialized
INFO - 2023-05-26 06:53:48 --> Router Class Initialized
INFO - 2023-05-26 06:53:48 --> URI Class Initialized
INFO - 2023-05-26 06:53:48 --> Output Class Initialized
INFO - 2023-05-26 06:53:48 --> Router Class Initialized
INFO - 2023-05-26 06:53:48 --> Security Class Initialized
INFO - 2023-05-26 06:53:48 --> Output Class Initialized
DEBUG - 2023-05-26 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:53:48 --> Input Class Initialized
INFO - 2023-05-26 06:53:48 --> Security Class Initialized
DEBUG - 2023-05-26 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:53:48 --> Language Class Initialized
INFO - 2023-05-26 06:53:48 --> Input Class Initialized
INFO - 2023-05-26 06:53:48 --> Language Class Initialized
INFO - 2023-05-26 06:53:48 --> Loader Class Initialized
INFO - 2023-05-26 06:53:48 --> Loader Class Initialized
INFO - 2023-05-26 06:53:48 --> Controller Class Initialized
DEBUG - 2023-05-26 06:53:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:53:48 --> Controller Class Initialized
DEBUG - 2023-05-26 06:53:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:53:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:53:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:53:48 --> Model "Login_model" initialized
INFO - 2023-05-26 06:53:48 --> Final output sent to browser
DEBUG - 2023-05-26 06:53:48 --> Total execution time: 0.2996
INFO - 2023-05-26 06:53:48 --> Final output sent to browser
DEBUG - 2023-05-26 06:53:48 --> Total execution time: 0.3010
INFO - 2023-05-26 06:54:47 --> Config Class Initialized
INFO - 2023-05-26 06:54:47 --> Config Class Initialized
INFO - 2023-05-26 06:54:47 --> Hooks Class Initialized
INFO - 2023-05-26 06:54:47 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:54:47 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:54:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:54:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:54:47 --> URI Class Initialized
INFO - 2023-05-26 06:54:47 --> URI Class Initialized
INFO - 2023-05-26 06:54:47 --> Router Class Initialized
INFO - 2023-05-26 06:54:47 --> Router Class Initialized
INFO - 2023-05-26 06:54:47 --> Output Class Initialized
INFO - 2023-05-26 06:54:47 --> Output Class Initialized
INFO - 2023-05-26 06:54:47 --> Security Class Initialized
INFO - 2023-05-26 06:54:47 --> Security Class Initialized
DEBUG - 2023-05-26 06:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:54:47 --> Input Class Initialized
INFO - 2023-05-26 06:54:47 --> Input Class Initialized
INFO - 2023-05-26 06:54:47 --> Language Class Initialized
INFO - 2023-05-26 06:54:47 --> Language Class Initialized
INFO - 2023-05-26 06:54:47 --> Loader Class Initialized
INFO - 2023-05-26 06:54:47 --> Loader Class Initialized
INFO - 2023-05-26 06:54:47 --> Controller Class Initialized
INFO - 2023-05-26 06:54:47 --> Controller Class Initialized
DEBUG - 2023-05-26 06:54:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:54:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:54:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:54:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:54:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:54:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:54:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:54:47 --> Model "Login_model" initialized
INFO - 2023-05-26 06:54:47 --> Final output sent to browser
DEBUG - 2023-05-26 06:54:47 --> Total execution time: 0.1675
INFO - 2023-05-26 06:54:47 --> Config Class Initialized
INFO - 2023-05-26 06:54:47 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:54:47 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:54:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:54:47 --> URI Class Initialized
INFO - 2023-05-26 06:54:47 --> Router Class Initialized
INFO - 2023-05-26 06:54:47 --> Output Class Initialized
INFO - 2023-05-26 06:54:47 --> Security Class Initialized
DEBUG - 2023-05-26 06:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:54:47 --> Input Class Initialized
INFO - 2023-05-26 06:54:47 --> Language Class Initialized
INFO - 2023-05-26 06:54:47 --> Loader Class Initialized
INFO - 2023-05-26 06:54:47 --> Controller Class Initialized
DEBUG - 2023-05-26 06:54:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:54:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:54:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:54:47 --> Final output sent to browser
DEBUG - 2023-05-26 06:54:47 --> Total execution time: 0.3187
INFO - 2023-05-26 06:54:55 --> Final output sent to browser
DEBUG - 2023-05-26 06:54:55 --> Total execution time: 8.3803
INFO - 2023-05-26 06:54:55 --> Config Class Initialized
INFO - 2023-05-26 06:54:55 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:54:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:54:55 --> Utf8 Class Initialized
INFO - 2023-05-26 06:54:55 --> URI Class Initialized
INFO - 2023-05-26 06:54:55 --> Router Class Initialized
INFO - 2023-05-26 06:54:55 --> Output Class Initialized
INFO - 2023-05-26 06:54:55 --> Security Class Initialized
DEBUG - 2023-05-26 06:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:54:55 --> Input Class Initialized
INFO - 2023-05-26 06:54:55 --> Language Class Initialized
INFO - 2023-05-26 06:54:55 --> Loader Class Initialized
INFO - 2023-05-26 06:54:55 --> Controller Class Initialized
DEBUG - 2023-05-26 06:54:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:54:55 --> Database Driver Class Initialized
INFO - 2023-05-26 06:54:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:54:56 --> Database Driver Class Initialized
INFO - 2023-05-26 06:54:56 --> Model "Login_model" initialized
INFO - 2023-05-26 06:55:03 --> Final output sent to browser
DEBUG - 2023-05-26 06:55:03 --> Total execution time: 8.0285
INFO - 2023-05-26 06:55:47 --> Config Class Initialized
INFO - 2023-05-26 06:55:47 --> Config Class Initialized
INFO - 2023-05-26 06:55:47 --> Hooks Class Initialized
INFO - 2023-05-26 06:55:47 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:55:47 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:55:47 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:55:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:55:47 --> Utf8 Class Initialized
INFO - 2023-05-26 06:55:47 --> URI Class Initialized
INFO - 2023-05-26 06:55:47 --> URI Class Initialized
INFO - 2023-05-26 06:55:47 --> Router Class Initialized
INFO - 2023-05-26 06:55:47 --> Router Class Initialized
INFO - 2023-05-26 06:55:47 --> Output Class Initialized
INFO - 2023-05-26 06:55:47 --> Output Class Initialized
INFO - 2023-05-26 06:55:47 --> Security Class Initialized
INFO - 2023-05-26 06:55:47 --> Security Class Initialized
DEBUG - 2023-05-26 06:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:55:47 --> Input Class Initialized
INFO - 2023-05-26 06:55:47 --> Input Class Initialized
INFO - 2023-05-26 06:55:47 --> Language Class Initialized
INFO - 2023-05-26 06:55:47 --> Language Class Initialized
INFO - 2023-05-26 06:55:47 --> Loader Class Initialized
INFO - 2023-05-26 06:55:47 --> Loader Class Initialized
INFO - 2023-05-26 06:55:47 --> Controller Class Initialized
INFO - 2023-05-26 06:55:47 --> Controller Class Initialized
DEBUG - 2023-05-26 06:55:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:55:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:55:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:55:47 --> Database Driver Class Initialized
INFO - 2023-05-26 06:55:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:55:47 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:55:48 --> Database Driver Class Initialized
INFO - 2023-05-26 06:55:48 --> Model "Login_model" initialized
INFO - 2023-05-26 06:55:48 --> Final output sent to browser
DEBUG - 2023-05-26 06:55:48 --> Total execution time: 0.8577
INFO - 2023-05-26 06:55:48 --> Config Class Initialized
INFO - 2023-05-26 06:55:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:55:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:55:48 --> Utf8 Class Initialized
INFO - 2023-05-26 06:55:48 --> URI Class Initialized
INFO - 2023-05-26 06:55:48 --> Router Class Initialized
INFO - 2023-05-26 06:55:49 --> Output Class Initialized
INFO - 2023-05-26 06:55:49 --> Security Class Initialized
DEBUG - 2023-05-26 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:55:49 --> Input Class Initialized
INFO - 2023-05-26 06:55:49 --> Language Class Initialized
INFO - 2023-05-26 06:55:49 --> Loader Class Initialized
INFO - 2023-05-26 06:55:49 --> Controller Class Initialized
DEBUG - 2023-05-26 06:55:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:55:49 --> Database Driver Class Initialized
INFO - 2023-05-26 06:55:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:55:49 --> Final output sent to browser
DEBUG - 2023-05-26 06:55:49 --> Total execution time: 1.4089
INFO - 2023-05-26 06:56:01 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:01 --> Total execution time: 13.8387
INFO - 2023-05-26 06:56:01 --> Config Class Initialized
INFO - 2023-05-26 06:56:01 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:56:01 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:01 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:01 --> URI Class Initialized
INFO - 2023-05-26 06:56:01 --> Router Class Initialized
INFO - 2023-05-26 06:56:01 --> Output Class Initialized
INFO - 2023-05-26 06:56:01 --> Security Class Initialized
DEBUG - 2023-05-26 06:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:56:01 --> Input Class Initialized
INFO - 2023-05-26 06:56:01 --> Language Class Initialized
INFO - 2023-05-26 06:56:01 --> Loader Class Initialized
INFO - 2023-05-26 06:56:01 --> Controller Class Initialized
DEBUG - 2023-05-26 06:56:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:01 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:01 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:56:01 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:01 --> Model "Login_model" initialized
INFO - 2023-05-26 06:56:09 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:09 --> Total execution time: 7.7384
INFO - 2023-05-26 06:56:27 --> Config Class Initialized
INFO - 2023-05-26 06:56:27 --> Hooks Class Initialized
INFO - 2023-05-26 06:56:27 --> Config Class Initialized
INFO - 2023-05-26 06:56:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:56:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:27 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:27 --> Config Class Initialized
INFO - 2023-05-26 06:56:27 --> Hooks Class Initialized
INFO - 2023-05-26 06:56:27 --> URI Class Initialized
DEBUG - 2023-05-26 06:56:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:27 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:27 --> URI Class Initialized
INFO - 2023-05-26 06:56:27 --> Router Class Initialized
DEBUG - 2023-05-26 06:56:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:27 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:27 --> Router Class Initialized
INFO - 2023-05-26 06:56:27 --> Output Class Initialized
INFO - 2023-05-26 06:56:27 --> URI Class Initialized
INFO - 2023-05-26 06:56:27 --> Output Class Initialized
INFO - 2023-05-26 06:56:27 --> Security Class Initialized
DEBUG - 2023-05-26 06:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:56:28 --> Router Class Initialized
INFO - 2023-05-26 06:56:28 --> Security Class Initialized
INFO - 2023-05-26 06:56:28 --> Input Class Initialized
INFO - 2023-05-26 06:56:28 --> Language Class Initialized
DEBUG - 2023-05-26 06:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:56:28 --> Input Class Initialized
INFO - 2023-05-26 06:56:28 --> Language Class Initialized
INFO - 2023-05-26 06:56:28 --> Output Class Initialized
INFO - 2023-05-26 06:56:28 --> Security Class Initialized
INFO - 2023-05-26 06:56:28 --> Loader Class Initialized
INFO - 2023-05-26 06:56:28 --> Loader Class Initialized
INFO - 2023-05-26 06:56:28 --> Controller Class Initialized
INFO - 2023-05-26 06:56:28 --> Controller Class Initialized
DEBUG - 2023-05-26 06:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:56:28 --> Input Class Initialized
DEBUG - 2023-05-26 06:56:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:28 --> Language Class Initialized
DEBUG - 2023-05-26 06:56:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:28 --> Loader Class Initialized
INFO - 2023-05-26 06:56:28 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:28 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:28 --> Controller Class Initialized
DEBUG - 2023-05-26 06:56:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:28 --> Config Class Initialized
INFO - 2023-05-26 06:56:28 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:56:28 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:28 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:28 --> URI Class Initialized
INFO - 2023-05-26 06:56:28 --> Router Class Initialized
INFO - 2023-05-26 06:56:28 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:28 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:56:28 --> Output Class Initialized
INFO - 2023-05-26 06:56:29 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:29 --> Security Class Initialized
INFO - 2023-05-26 06:56:29 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:56:29 --> Input Class Initialized
INFO - 2023-05-26 06:56:29 --> Language Class Initialized
INFO - 2023-05-26 06:56:29 --> Model "Login_model" initialized
INFO - 2023-05-26 06:56:29 --> Final output sent to browser
INFO - 2023-05-26 06:56:29 --> Loader Class Initialized
DEBUG - 2023-05-26 06:56:29 --> Total execution time: 1.5117
INFO - 2023-05-26 06:56:29 --> Controller Class Initialized
DEBUG - 2023-05-26 06:56:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:29 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:29 --> Total execution time: 1.7017
INFO - 2023-05-26 06:56:29 --> Config Class Initialized
INFO - 2023-05-26 06:56:29 --> Hooks Class Initialized
INFO - 2023-05-26 06:56:29 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:29 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:29 --> Total execution time: 1.8893
INFO - 2023-05-26 06:56:29 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:56:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:29 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:29 --> URI Class Initialized
INFO - 2023-05-26 06:56:29 --> Config Class Initialized
INFO - 2023-05-26 06:56:29 --> Hooks Class Initialized
INFO - 2023-05-26 06:56:29 --> Config Class Initialized
INFO - 2023-05-26 06:56:29 --> Hooks Class Initialized
INFO - 2023-05-26 06:56:29 --> Router Class Initialized
DEBUG - 2023-05-26 06:56:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:29 --> Output Class Initialized
INFO - 2023-05-26 06:56:29 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:29 --> URI Class Initialized
DEBUG - 2023-05-26 06:56:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:29 --> Config Class Initialized
INFO - 2023-05-26 06:56:29 --> Hooks Class Initialized
INFO - 2023-05-26 06:56:29 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:29 --> Security Class Initialized
INFO - 2023-05-26 06:56:29 --> Router Class Initialized
INFO - 2023-05-26 06:56:29 --> URI Class Initialized
INFO - 2023-05-26 06:56:29 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:56:29 --> Total execution time: 1.2689
INFO - 2023-05-26 06:56:29 --> Input Class Initialized
INFO - 2023-05-26 06:56:29 --> Output Class Initialized
DEBUG - 2023-05-26 06:56:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:29 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:29 --> Security Class Initialized
INFO - 2023-05-26 06:56:29 --> Language Class Initialized
INFO - 2023-05-26 06:56:29 --> Router Class Initialized
INFO - 2023-05-26 06:56:29 --> URI Class Initialized
DEBUG - 2023-05-26 06:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:56:30 --> Input Class Initialized
INFO - 2023-05-26 06:56:30 --> Output Class Initialized
INFO - 2023-05-26 06:56:30 --> Router Class Initialized
INFO - 2023-05-26 06:56:30 --> Language Class Initialized
INFO - 2023-05-26 06:56:30 --> Loader Class Initialized
INFO - 2023-05-26 06:56:30 --> Security Class Initialized
INFO - 2023-05-26 06:56:30 --> Controller Class Initialized
INFO - 2023-05-26 06:56:30 --> Output Class Initialized
DEBUG - 2023-05-26 06:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:56:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:30 --> Input Class Initialized
INFO - 2023-05-26 06:56:30 --> Config Class Initialized
INFO - 2023-05-26 06:56:30 --> Hooks Class Initialized
INFO - 2023-05-26 06:56:30 --> Security Class Initialized
INFO - 2023-05-26 06:56:30 --> Language Class Initialized
INFO - 2023-05-26 06:56:30 --> Loader Class Initialized
DEBUG - 2023-05-26 06:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:56:30 --> Input Class Initialized
INFO - 2023-05-26 06:56:30 --> Language Class Initialized
DEBUG - 2023-05-26 06:56:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:30 --> Controller Class Initialized
INFO - 2023-05-26 06:56:30 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:56:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:30 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:30 --> Loader Class Initialized
INFO - 2023-05-26 06:56:30 --> URI Class Initialized
INFO - 2023-05-26 06:56:30 --> Loader Class Initialized
INFO - 2023-05-26 06:56:30 --> Controller Class Initialized
DEBUG - 2023-05-26 06:56:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:30 --> Controller Class Initialized
DEBUG - 2023-05-26 06:56:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:30 --> Router Class Initialized
INFO - 2023-05-26 06:56:30 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:30 --> Output Class Initialized
INFO - 2023-05-26 06:56:30 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:30 --> Security Class Initialized
INFO - 2023-05-26 06:56:30 --> Database Driver Class Initialized
DEBUG - 2023-05-26 06:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:56:30 --> Model "Login_model" initialized
INFO - 2023-05-26 06:56:30 --> Input Class Initialized
INFO - 2023-05-26 06:56:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:56:30 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:30 --> Language Class Initialized
INFO - 2023-05-26 06:56:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:56:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:56:30 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:30 --> Total execution time: 1.3274
INFO - 2023-05-26 06:56:30 --> Loader Class Initialized
INFO - 2023-05-26 06:56:30 --> Controller Class Initialized
DEBUG - 2023-05-26 06:56:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:30 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:30 --> Config Class Initialized
INFO - 2023-05-26 06:56:30 --> Hooks Class Initialized
INFO - 2023-05-26 06:56:30 --> Final output sent to browser
INFO - 2023-05-26 06:56:30 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:30 --> Total execution time: 1.2472
DEBUG - 2023-05-26 06:56:30 --> Total execution time: 1.3312
DEBUG - 2023-05-26 06:56:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:30 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:30 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:30 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:30 --> Total execution time: 1.1813
INFO - 2023-05-26 06:56:30 --> URI Class Initialized
INFO - 2023-05-26 06:56:30 --> Model "Login_model" initialized
INFO - 2023-05-26 06:56:30 --> Router Class Initialized
INFO - 2023-05-26 06:56:30 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:30 --> Total execution time: 0.9444
INFO - 2023-05-26 06:56:30 --> Config Class Initialized
INFO - 2023-05-26 06:56:31 --> Hooks Class Initialized
INFO - 2023-05-26 06:56:31 --> Config Class Initialized
INFO - 2023-05-26 06:56:31 --> Output Class Initialized
INFO - 2023-05-26 06:56:31 --> Hooks Class Initialized
INFO - 2023-05-26 06:56:31 --> Security Class Initialized
DEBUG - 2023-05-26 06:56:31 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:56:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:31 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:56:31 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:31 --> Input Class Initialized
INFO - 2023-05-26 06:56:31 --> URI Class Initialized
INFO - 2023-05-26 06:56:31 --> Config Class Initialized
INFO - 2023-05-26 06:56:31 --> URI Class Initialized
INFO - 2023-05-26 06:56:31 --> Hooks Class Initialized
INFO - 2023-05-26 06:56:31 --> Language Class Initialized
INFO - 2023-05-26 06:56:31 --> Router Class Initialized
INFO - 2023-05-26 06:56:31 --> Router Class Initialized
INFO - 2023-05-26 06:56:31 --> Output Class Initialized
DEBUG - 2023-05-26 06:56:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:31 --> Output Class Initialized
INFO - 2023-05-26 06:56:31 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:31 --> Loader Class Initialized
INFO - 2023-05-26 06:56:31 --> Security Class Initialized
INFO - 2023-05-26 06:56:31 --> Security Class Initialized
INFO - 2023-05-26 06:56:31 --> URI Class Initialized
INFO - 2023-05-26 06:56:31 --> Controller Class Initialized
DEBUG - 2023-05-26 06:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:56:31 --> Input Class Initialized
INFO - 2023-05-26 06:56:31 --> Input Class Initialized
INFO - 2023-05-26 06:56:31 --> Router Class Initialized
DEBUG - 2023-05-26 06:56:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:31 --> Language Class Initialized
INFO - 2023-05-26 06:56:31 --> Language Class Initialized
INFO - 2023-05-26 06:56:31 --> Output Class Initialized
INFO - 2023-05-26 06:56:31 --> Security Class Initialized
INFO - 2023-05-26 06:56:31 --> Loader Class Initialized
INFO - 2023-05-26 06:56:31 --> Loader Class Initialized
DEBUG - 2023-05-26 06:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:56:31 --> Controller Class Initialized
INFO - 2023-05-26 06:56:31 --> Controller Class Initialized
INFO - 2023-05-26 06:56:31 --> Input Class Initialized
DEBUG - 2023-05-26 06:56:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:56:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:31 --> Language Class Initialized
INFO - 2023-05-26 06:56:31 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:31 --> Loader Class Initialized
INFO - 2023-05-26 06:56:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:56:31 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:31 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:56:31 --> Controller Class Initialized
INFO - 2023-05-26 06:56:31 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:56:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:31 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:31 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:31 --> Total execution time: 1.1876
INFO - 2023-05-26 06:56:31 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:31 --> Model "Login_model" initialized
INFO - 2023-05-26 06:56:31 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:31 --> Total execution time: 0.8207
INFO - 2023-05-26 06:56:32 --> Final output sent to browser
INFO - 2023-05-26 06:56:32 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:32 --> Total execution time: 1.0634
DEBUG - 2023-05-26 06:56:32 --> Total execution time: 1.0698
INFO - 2023-05-26 06:56:32 --> Config Class Initialized
INFO - 2023-05-26 06:56:32 --> Hooks Class Initialized
INFO - 2023-05-26 06:56:32 --> Config Class Initialized
INFO - 2023-05-26 06:56:32 --> Config Class Initialized
INFO - 2023-05-26 06:56:32 --> Hooks Class Initialized
INFO - 2023-05-26 06:56:32 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:56:32 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:56:32 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:32 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:32 --> Utf8 Class Initialized
DEBUG - 2023-05-26 06:56:32 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:56:32 --> Utf8 Class Initialized
INFO - 2023-05-26 06:56:32 --> URI Class Initialized
INFO - 2023-05-26 06:56:32 --> URI Class Initialized
INFO - 2023-05-26 06:56:32 --> URI Class Initialized
INFO - 2023-05-26 06:56:32 --> Router Class Initialized
INFO - 2023-05-26 06:56:32 --> Router Class Initialized
INFO - 2023-05-26 06:56:32 --> Output Class Initialized
INFO - 2023-05-26 06:56:32 --> Output Class Initialized
INFO - 2023-05-26 06:56:32 --> Router Class Initialized
INFO - 2023-05-26 06:56:32 --> Security Class Initialized
INFO - 2023-05-26 06:56:32 --> Security Class Initialized
DEBUG - 2023-05-26 06:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:56:32 --> Output Class Initialized
INFO - 2023-05-26 06:56:32 --> Input Class Initialized
INFO - 2023-05-26 06:56:32 --> Input Class Initialized
INFO - 2023-05-26 06:56:32 --> Security Class Initialized
INFO - 2023-05-26 06:56:32 --> Language Class Initialized
INFO - 2023-05-26 06:56:32 --> Language Class Initialized
DEBUG - 2023-05-26 06:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:56:32 --> Input Class Initialized
INFO - 2023-05-26 06:56:32 --> Language Class Initialized
INFO - 2023-05-26 06:56:32 --> Loader Class Initialized
INFO - 2023-05-26 06:56:32 --> Loader Class Initialized
INFO - 2023-05-26 06:56:32 --> Controller Class Initialized
INFO - 2023-05-26 06:56:32 --> Controller Class Initialized
DEBUG - 2023-05-26 06:56:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:56:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:32 --> Loader Class Initialized
INFO - 2023-05-26 06:56:32 --> Controller Class Initialized
INFO - 2023-05-26 06:56:32 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:32 --> Database Driver Class Initialized
DEBUG - 2023-05-26 06:56:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:56:32 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:56:32 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:56:32 --> Database Driver Class Initialized
INFO - 2023-05-26 06:56:32 --> Final output sent to browser
INFO - 2023-05-26 06:56:32 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:56:32 --> Total execution time: 0.4467
INFO - 2023-05-26 06:56:32 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:32 --> Total execution time: 0.5695
INFO - 2023-05-26 06:56:32 --> Final output sent to browser
DEBUG - 2023-05-26 06:56:32 --> Total execution time: 0.5945
INFO - 2023-05-26 06:57:27 --> Config Class Initialized
INFO - 2023-05-26 06:57:27 --> Config Class Initialized
INFO - 2023-05-26 06:57:27 --> Hooks Class Initialized
INFO - 2023-05-26 06:57:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:57:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:57:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:57:27 --> Utf8 Class Initialized
INFO - 2023-05-26 06:57:27 --> Utf8 Class Initialized
INFO - 2023-05-26 06:57:27 --> URI Class Initialized
INFO - 2023-05-26 06:57:27 --> URI Class Initialized
INFO - 2023-05-26 06:57:27 --> Router Class Initialized
INFO - 2023-05-26 06:57:27 --> Router Class Initialized
INFO - 2023-05-26 06:57:27 --> Output Class Initialized
INFO - 2023-05-26 06:57:27 --> Output Class Initialized
INFO - 2023-05-26 06:57:27 --> Security Class Initialized
INFO - 2023-05-26 06:57:27 --> Security Class Initialized
DEBUG - 2023-05-26 06:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:57:27 --> Input Class Initialized
INFO - 2023-05-26 06:57:27 --> Input Class Initialized
INFO - 2023-05-26 06:57:27 --> Language Class Initialized
INFO - 2023-05-26 06:57:27 --> Language Class Initialized
INFO - 2023-05-26 06:57:27 --> Loader Class Initialized
INFO - 2023-05-26 06:57:27 --> Loader Class Initialized
INFO - 2023-05-26 06:57:27 --> Controller Class Initialized
DEBUG - 2023-05-26 06:57:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:57:27 --> Controller Class Initialized
DEBUG - 2023-05-26 06:57:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:57:27 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:27 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:57:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:57:27 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:27 --> Model "Login_model" initialized
INFO - 2023-05-26 06:57:27 --> Final output sent to browser
DEBUG - 2023-05-26 06:57:27 --> Total execution time: 0.1786
INFO - 2023-05-26 06:57:27 --> Config Class Initialized
INFO - 2023-05-26 06:57:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:57:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:57:27 --> Utf8 Class Initialized
INFO - 2023-05-26 06:57:27 --> URI Class Initialized
INFO - 2023-05-26 06:57:28 --> Router Class Initialized
INFO - 2023-05-26 06:57:28 --> Output Class Initialized
INFO - 2023-05-26 06:57:28 --> Security Class Initialized
DEBUG - 2023-05-26 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:57:28 --> Input Class Initialized
INFO - 2023-05-26 06:57:28 --> Language Class Initialized
INFO - 2023-05-26 06:57:28 --> Loader Class Initialized
INFO - 2023-05-26 06:57:28 --> Controller Class Initialized
DEBUG - 2023-05-26 06:57:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:57:28 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:28 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:57:28 --> Final output sent to browser
DEBUG - 2023-05-26 06:57:28 --> Total execution time: 0.2810
INFO - 2023-05-26 06:57:41 --> Final output sent to browser
DEBUG - 2023-05-26 06:57:41 --> Total execution time: 13.5272
INFO - 2023-05-26 06:57:41 --> Config Class Initialized
INFO - 2023-05-26 06:57:41 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:57:41 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:57:41 --> Utf8 Class Initialized
INFO - 2023-05-26 06:57:41 --> URI Class Initialized
INFO - 2023-05-26 06:57:41 --> Router Class Initialized
INFO - 2023-05-26 06:57:41 --> Output Class Initialized
INFO - 2023-05-26 06:57:41 --> Security Class Initialized
DEBUG - 2023-05-26 06:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:57:41 --> Input Class Initialized
INFO - 2023-05-26 06:57:41 --> Language Class Initialized
INFO - 2023-05-26 06:57:41 --> Loader Class Initialized
INFO - 2023-05-26 06:57:41 --> Controller Class Initialized
DEBUG - 2023-05-26 06:57:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:57:41 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:41 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:57:41 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:41 --> Model "Login_model" initialized
INFO - 2023-05-26 06:57:51 --> Config Class Initialized
INFO - 2023-05-26 06:57:51 --> Config Class Initialized
INFO - 2023-05-26 06:57:51 --> Hooks Class Initialized
INFO - 2023-05-26 06:57:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:57:52 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:57:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:57:52 --> Utf8 Class Initialized
INFO - 2023-05-26 06:57:52 --> Utf8 Class Initialized
INFO - 2023-05-26 06:57:52 --> URI Class Initialized
INFO - 2023-05-26 06:57:52 --> URI Class Initialized
INFO - 2023-05-26 06:57:52 --> Router Class Initialized
INFO - 2023-05-26 06:57:52 --> Router Class Initialized
INFO - 2023-05-26 06:57:52 --> Output Class Initialized
INFO - 2023-05-26 06:57:52 --> Output Class Initialized
INFO - 2023-05-26 06:57:52 --> Config Class Initialized
INFO - 2023-05-26 06:57:52 --> Hooks Class Initialized
INFO - 2023-05-26 06:57:52 --> Security Class Initialized
INFO - 2023-05-26 06:57:52 --> Security Class Initialized
DEBUG - 2023-05-26 06:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:57:52 --> Input Class Initialized
INFO - 2023-05-26 06:57:52 --> Input Class Initialized
INFO - 2023-05-26 06:57:53 --> Language Class Initialized
INFO - 2023-05-26 06:57:53 --> Language Class Initialized
DEBUG - 2023-05-26 06:57:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:57:53 --> Config Class Initialized
INFO - 2023-05-26 06:57:53 --> Hooks Class Initialized
INFO - 2023-05-26 06:57:53 --> Utf8 Class Initialized
INFO - 2023-05-26 06:57:53 --> Loader Class Initialized
INFO - 2023-05-26 06:57:53 --> Loader Class Initialized
INFO - 2023-05-26 06:57:53 --> URI Class Initialized
INFO - 2023-05-26 06:57:53 --> Controller Class Initialized
INFO - 2023-05-26 06:57:53 --> Controller Class Initialized
DEBUG - 2023-05-26 06:57:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:57:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:57:53 --> Router Class Initialized
DEBUG - 2023-05-26 06:57:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:57:53 --> Utf8 Class Initialized
INFO - 2023-05-26 06:57:53 --> Output Class Initialized
INFO - 2023-05-26 06:57:53 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:53 --> URI Class Initialized
INFO - 2023-05-26 06:57:53 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:53 --> Security Class Initialized
DEBUG - 2023-05-26 06:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:57:53 --> Input Class Initialized
INFO - 2023-05-26 06:57:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:57:54 --> Router Class Initialized
INFO - 2023-05-26 06:57:54 --> Final output sent to browser
INFO - 2023-05-26 06:57:54 --> Language Class Initialized
DEBUG - 2023-05-26 06:57:54 --> Total execution time: 12.5922
INFO - 2023-05-26 06:57:54 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:54 --> Loader Class Initialized
INFO - 2023-05-26 06:57:54 --> Final output sent to browser
INFO - 2023-05-26 06:57:54 --> Output Class Initialized
DEBUG - 2023-05-26 06:57:54 --> Total execution time: 3.1193
INFO - 2023-05-26 06:57:54 --> Model "Login_model" initialized
INFO - 2023-05-26 06:57:54 --> Controller Class Initialized
INFO - 2023-05-26 06:57:54 --> Security Class Initialized
DEBUG - 2023-05-26 06:57:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:57:55 --> Final output sent to browser
DEBUG - 2023-05-26 06:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:57:55 --> Total execution time: 3.6501
INFO - 2023-05-26 06:57:55 --> Input Class Initialized
INFO - 2023-05-26 06:57:55 --> Config Class Initialized
INFO - 2023-05-26 06:57:55 --> Hooks Class Initialized
INFO - 2023-05-26 06:57:55 --> Language Class Initialized
INFO - 2023-05-26 06:57:55 --> Config Class Initialized
DEBUG - 2023-05-26 06:57:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:57:55 --> Hooks Class Initialized
INFO - 2023-05-26 06:57:55 --> Utf8 Class Initialized
INFO - 2023-05-26 06:57:55 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:55 --> URI Class Initialized
INFO - 2023-05-26 06:57:55 --> Loader Class Initialized
INFO - 2023-05-26 06:57:55 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:57:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:57:55 --> Controller Class Initialized
INFO - 2023-05-26 06:57:55 --> Router Class Initialized
INFO - 2023-05-26 06:57:55 --> Utf8 Class Initialized
INFO - 2023-05-26 06:57:55 --> URI Class Initialized
DEBUG - 2023-05-26 06:57:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:57:55 --> Output Class Initialized
INFO - 2023-05-26 06:57:55 --> Security Class Initialized
INFO - 2023-05-26 06:57:55 --> Router Class Initialized
INFO - 2023-05-26 06:57:55 --> Final output sent to browser
DEBUG - 2023-05-26 06:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:57:55 --> Total execution time: 3.4208
INFO - 2023-05-26 06:57:55 --> Input Class Initialized
INFO - 2023-05-26 06:57:55 --> Output Class Initialized
INFO - 2023-05-26 06:57:55 --> Language Class Initialized
INFO - 2023-05-26 06:57:55 --> Security Class Initialized
DEBUG - 2023-05-26 06:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:57:55 --> Input Class Initialized
INFO - 2023-05-26 06:57:55 --> Loader Class Initialized
INFO - 2023-05-26 06:57:55 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:55 --> Language Class Initialized
INFO - 2023-05-26 06:57:55 --> Controller Class Initialized
INFO - 2023-05-26 06:57:55 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:57:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:57:55 --> Config Class Initialized
INFO - 2023-05-26 06:57:55 --> Loader Class Initialized
INFO - 2023-05-26 06:57:55 --> Hooks Class Initialized
INFO - 2023-05-26 06:57:55 --> Controller Class Initialized
INFO - 2023-05-26 06:57:55 --> Final output sent to browser
DEBUG - 2023-05-26 06:57:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 06:57:55 --> Total execution time: 2.8473
DEBUG - 2023-05-26 06:57:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:57:55 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:55 --> Utf8 Class Initialized
INFO - 2023-05-26 06:57:55 --> URI Class Initialized
INFO - 2023-05-26 06:57:55 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:57:55 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:55 --> Router Class Initialized
INFO - 2023-05-26 06:57:55 --> Config Class Initialized
INFO - 2023-05-26 06:57:55 --> Output Class Initialized
INFO - 2023-05-26 06:57:55 --> Hooks Class Initialized
INFO - 2023-05-26 06:57:55 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:55 --> Security Class Initialized
INFO - 2023-05-26 06:57:55 --> Final output sent to browser
DEBUG - 2023-05-26 06:57:55 --> Total execution time: 0.8030
DEBUG - 2023-05-26 06:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:57:55 --> Model "Login_model" initialized
INFO - 2023-05-26 06:57:55 --> Input Class Initialized
DEBUG - 2023-05-26 06:57:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:57:55 --> Language Class Initialized
INFO - 2023-05-26 06:57:55 --> Utf8 Class Initialized
INFO - 2023-05-26 06:57:55 --> Final output sent to browser
DEBUG - 2023-05-26 06:57:55 --> Total execution time: 0.5673
INFO - 2023-05-26 06:57:55 --> URI Class Initialized
INFO - 2023-05-26 06:57:56 --> Loader Class Initialized
INFO - 2023-05-26 06:57:56 --> Router Class Initialized
INFO - 2023-05-26 06:57:56 --> Controller Class Initialized
INFO - 2023-05-26 06:57:56 --> Output Class Initialized
DEBUG - 2023-05-26 06:57:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:57:56 --> Security Class Initialized
DEBUG - 2023-05-26 06:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:57:56 --> Input Class Initialized
INFO - 2023-05-26 06:57:56 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:56 --> Language Class Initialized
INFO - 2023-05-26 06:57:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:57:56 --> Loader Class Initialized
INFO - 2023-05-26 06:57:56 --> Controller Class Initialized
DEBUG - 2023-05-26 06:57:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:57:56 --> Final output sent to browser
DEBUG - 2023-05-26 06:57:56 --> Total execution time: 0.5072
INFO - 2023-05-26 06:57:56 --> Database Driver Class Initialized
INFO - 2023-05-26 06:57:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:57:56 --> Final output sent to browser
DEBUG - 2023-05-26 06:57:56 --> Total execution time: 0.7560
INFO - 2023-05-26 06:58:51 --> Config Class Initialized
INFO - 2023-05-26 06:58:51 --> Config Class Initialized
INFO - 2023-05-26 06:58:51 --> Hooks Class Initialized
INFO - 2023-05-26 06:58:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:58:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:58:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:58:51 --> Utf8 Class Initialized
INFO - 2023-05-26 06:58:51 --> Utf8 Class Initialized
INFO - 2023-05-26 06:58:51 --> URI Class Initialized
INFO - 2023-05-26 06:58:51 --> URI Class Initialized
INFO - 2023-05-26 06:58:51 --> Router Class Initialized
INFO - 2023-05-26 06:58:51 --> Router Class Initialized
INFO - 2023-05-26 06:58:51 --> Output Class Initialized
INFO - 2023-05-26 06:58:51 --> Output Class Initialized
INFO - 2023-05-26 06:58:51 --> Security Class Initialized
INFO - 2023-05-26 06:58:51 --> Security Class Initialized
DEBUG - 2023-05-26 06:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:58:51 --> Input Class Initialized
INFO - 2023-05-26 06:58:51 --> Input Class Initialized
INFO - 2023-05-26 06:58:51 --> Language Class Initialized
INFO - 2023-05-26 06:58:51 --> Language Class Initialized
INFO - 2023-05-26 06:58:51 --> Loader Class Initialized
INFO - 2023-05-26 06:58:51 --> Controller Class Initialized
INFO - 2023-05-26 06:58:51 --> Loader Class Initialized
DEBUG - 2023-05-26 06:58:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:58:51 --> Controller Class Initialized
DEBUG - 2023-05-26 06:58:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:58:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:58:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:58:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:58:51 --> Final output sent to browser
INFO - 2023-05-26 06:58:51 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 06:58:51 --> Total execution time: 0.1865
INFO - 2023-05-26 06:58:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:58:51 --> Model "Login_model" initialized
INFO - 2023-05-26 06:58:51 --> Config Class Initialized
INFO - 2023-05-26 06:58:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:58:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:58:51 --> Utf8 Class Initialized
INFO - 2023-05-26 06:58:51 --> URI Class Initialized
INFO - 2023-05-26 06:58:51 --> Router Class Initialized
INFO - 2023-05-26 06:58:51 --> Output Class Initialized
INFO - 2023-05-26 06:58:51 --> Security Class Initialized
DEBUG - 2023-05-26 06:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:58:51 --> Input Class Initialized
INFO - 2023-05-26 06:58:51 --> Language Class Initialized
INFO - 2023-05-26 06:58:51 --> Loader Class Initialized
INFO - 2023-05-26 06:58:51 --> Controller Class Initialized
DEBUG - 2023-05-26 06:58:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:58:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:58:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:58:51 --> Final output sent to browser
DEBUG - 2023-05-26 06:58:51 --> Total execution time: 0.2504
INFO - 2023-05-26 06:58:59 --> Final output sent to browser
DEBUG - 2023-05-26 06:58:59 --> Total execution time: 8.0675
INFO - 2023-05-26 06:58:59 --> Config Class Initialized
INFO - 2023-05-26 06:58:59 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:58:59 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:58:59 --> Utf8 Class Initialized
INFO - 2023-05-26 06:58:59 --> URI Class Initialized
INFO - 2023-05-26 06:58:59 --> Router Class Initialized
INFO - 2023-05-26 06:58:59 --> Output Class Initialized
INFO - 2023-05-26 06:58:59 --> Security Class Initialized
DEBUG - 2023-05-26 06:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:58:59 --> Input Class Initialized
INFO - 2023-05-26 06:58:59 --> Language Class Initialized
INFO - 2023-05-26 06:58:59 --> Loader Class Initialized
INFO - 2023-05-26 06:58:59 --> Controller Class Initialized
DEBUG - 2023-05-26 06:58:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:58:59 --> Database Driver Class Initialized
INFO - 2023-05-26 06:58:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:58:59 --> Database Driver Class Initialized
INFO - 2023-05-26 06:58:59 --> Model "Login_model" initialized
INFO - 2023-05-26 06:59:07 --> Final output sent to browser
DEBUG - 2023-05-26 06:59:07 --> Total execution time: 8.2641
INFO - 2023-05-26 06:59:51 --> Config Class Initialized
INFO - 2023-05-26 06:59:51 --> Config Class Initialized
INFO - 2023-05-26 06:59:51 --> Hooks Class Initialized
INFO - 2023-05-26 06:59:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:59:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 06:59:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:59:51 --> Utf8 Class Initialized
INFO - 2023-05-26 06:59:51 --> Utf8 Class Initialized
INFO - 2023-05-26 06:59:51 --> URI Class Initialized
INFO - 2023-05-26 06:59:51 --> URI Class Initialized
INFO - 2023-05-26 06:59:51 --> Router Class Initialized
INFO - 2023-05-26 06:59:51 --> Router Class Initialized
INFO - 2023-05-26 06:59:51 --> Output Class Initialized
INFO - 2023-05-26 06:59:51 --> Output Class Initialized
INFO - 2023-05-26 06:59:51 --> Security Class Initialized
INFO - 2023-05-26 06:59:51 --> Security Class Initialized
DEBUG - 2023-05-26 06:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 06:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:59:51 --> Input Class Initialized
INFO - 2023-05-26 06:59:51 --> Input Class Initialized
INFO - 2023-05-26 06:59:51 --> Language Class Initialized
INFO - 2023-05-26 06:59:51 --> Language Class Initialized
INFO - 2023-05-26 06:59:51 --> Loader Class Initialized
INFO - 2023-05-26 06:59:51 --> Loader Class Initialized
INFO - 2023-05-26 06:59:51 --> Controller Class Initialized
DEBUG - 2023-05-26 06:59:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:59:51 --> Controller Class Initialized
DEBUG - 2023-05-26 06:59:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:59:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:59:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:59:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:59:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:59:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:59:51 --> Model "Login_model" initialized
INFO - 2023-05-26 06:59:51 --> Final output sent to browser
DEBUG - 2023-05-26 06:59:51 --> Total execution time: 0.2446
INFO - 2023-05-26 06:59:51 --> Config Class Initialized
INFO - 2023-05-26 06:59:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 06:59:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 06:59:51 --> Utf8 Class Initialized
INFO - 2023-05-26 06:59:51 --> URI Class Initialized
INFO - 2023-05-26 06:59:51 --> Router Class Initialized
INFO - 2023-05-26 06:59:51 --> Output Class Initialized
INFO - 2023-05-26 06:59:51 --> Security Class Initialized
DEBUG - 2023-05-26 06:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 06:59:51 --> Input Class Initialized
INFO - 2023-05-26 06:59:51 --> Language Class Initialized
INFO - 2023-05-26 06:59:51 --> Loader Class Initialized
INFO - 2023-05-26 06:59:51 --> Controller Class Initialized
DEBUG - 2023-05-26 06:59:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 06:59:51 --> Database Driver Class Initialized
INFO - 2023-05-26 06:59:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 06:59:51 --> Final output sent to browser
DEBUG - 2023-05-26 06:59:51 --> Total execution time: 0.2685
INFO - 2023-05-26 07:00:00 --> Final output sent to browser
DEBUG - 2023-05-26 07:00:00 --> Total execution time: 9.0158
INFO - 2023-05-26 07:00:00 --> Config Class Initialized
INFO - 2023-05-26 07:00:00 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:00:00 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:00:00 --> Utf8 Class Initialized
INFO - 2023-05-26 07:00:00 --> URI Class Initialized
INFO - 2023-05-26 07:00:00 --> Router Class Initialized
INFO - 2023-05-26 07:00:00 --> Output Class Initialized
INFO - 2023-05-26 07:00:00 --> Security Class Initialized
DEBUG - 2023-05-26 07:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:00:00 --> Input Class Initialized
INFO - 2023-05-26 07:00:00 --> Language Class Initialized
INFO - 2023-05-26 07:00:00 --> Loader Class Initialized
INFO - 2023-05-26 07:00:00 --> Controller Class Initialized
DEBUG - 2023-05-26 07:00:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:00:00 --> Database Driver Class Initialized
INFO - 2023-05-26 07:00:00 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:00:00 --> Database Driver Class Initialized
INFO - 2023-05-26 07:00:00 --> Model "Login_model" initialized
INFO - 2023-05-26 07:00:08 --> Final output sent to browser
DEBUG - 2023-05-26 07:00:08 --> Total execution time: 8.7845
INFO - 2023-05-26 07:00:51 --> Config Class Initialized
INFO - 2023-05-26 07:00:51 --> Config Class Initialized
INFO - 2023-05-26 07:00:51 --> Hooks Class Initialized
INFO - 2023-05-26 07:00:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:00:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:00:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:00:51 --> Utf8 Class Initialized
INFO - 2023-05-26 07:00:51 --> Utf8 Class Initialized
INFO - 2023-05-26 07:00:51 --> URI Class Initialized
INFO - 2023-05-26 07:00:51 --> URI Class Initialized
INFO - 2023-05-26 07:00:51 --> Router Class Initialized
INFO - 2023-05-26 07:00:51 --> Router Class Initialized
INFO - 2023-05-26 07:00:51 --> Output Class Initialized
INFO - 2023-05-26 07:00:51 --> Output Class Initialized
INFO - 2023-05-26 07:00:51 --> Security Class Initialized
INFO - 2023-05-26 07:00:51 --> Security Class Initialized
DEBUG - 2023-05-26 07:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:00:51 --> Input Class Initialized
INFO - 2023-05-26 07:00:51 --> Input Class Initialized
INFO - 2023-05-26 07:00:51 --> Language Class Initialized
INFO - 2023-05-26 07:00:51 --> Language Class Initialized
INFO - 2023-05-26 07:00:51 --> Loader Class Initialized
INFO - 2023-05-26 07:00:51 --> Loader Class Initialized
INFO - 2023-05-26 07:00:51 --> Controller Class Initialized
INFO - 2023-05-26 07:00:51 --> Controller Class Initialized
DEBUG - 2023-05-26 07:00:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 07:00:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:00:51 --> Database Driver Class Initialized
INFO - 2023-05-26 07:00:51 --> Database Driver Class Initialized
INFO - 2023-05-26 07:00:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:00:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:00:51 --> Database Driver Class Initialized
INFO - 2023-05-26 07:00:51 --> Model "Login_model" initialized
INFO - 2023-05-26 07:00:51 --> Final output sent to browser
DEBUG - 2023-05-26 07:00:51 --> Total execution time: 0.1798
INFO - 2023-05-26 07:00:51 --> Config Class Initialized
INFO - 2023-05-26 07:00:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:00:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:00:51 --> Utf8 Class Initialized
INFO - 2023-05-26 07:00:51 --> URI Class Initialized
INFO - 2023-05-26 07:00:51 --> Router Class Initialized
INFO - 2023-05-26 07:00:51 --> Output Class Initialized
INFO - 2023-05-26 07:00:51 --> Security Class Initialized
DEBUG - 2023-05-26 07:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:00:51 --> Input Class Initialized
INFO - 2023-05-26 07:00:51 --> Language Class Initialized
INFO - 2023-05-26 07:00:51 --> Loader Class Initialized
INFO - 2023-05-26 07:00:51 --> Controller Class Initialized
DEBUG - 2023-05-26 07:00:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:00:51 --> Database Driver Class Initialized
INFO - 2023-05-26 07:00:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:00:51 --> Final output sent to browser
DEBUG - 2023-05-26 07:00:51 --> Total execution time: 0.4510
INFO - 2023-05-26 07:01:01 --> Final output sent to browser
DEBUG - 2023-05-26 07:01:01 --> Total execution time: 10.1381
INFO - 2023-05-26 07:01:01 --> Config Class Initialized
INFO - 2023-05-26 07:01:01 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:01:01 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:01:01 --> Utf8 Class Initialized
INFO - 2023-05-26 07:01:01 --> URI Class Initialized
INFO - 2023-05-26 07:01:01 --> Router Class Initialized
INFO - 2023-05-26 07:01:01 --> Output Class Initialized
INFO - 2023-05-26 07:01:01 --> Security Class Initialized
DEBUG - 2023-05-26 07:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:01:01 --> Input Class Initialized
INFO - 2023-05-26 07:01:01 --> Language Class Initialized
INFO - 2023-05-26 07:01:01 --> Loader Class Initialized
INFO - 2023-05-26 07:01:01 --> Controller Class Initialized
DEBUG - 2023-05-26 07:01:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:01:01 --> Database Driver Class Initialized
INFO - 2023-05-26 07:01:01 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:01:01 --> Database Driver Class Initialized
INFO - 2023-05-26 07:01:01 --> Model "Login_model" initialized
INFO - 2023-05-26 07:01:09 --> Final output sent to browser
DEBUG - 2023-05-26 07:01:09 --> Total execution time: 8.7345
INFO - 2023-05-26 07:01:51 --> Config Class Initialized
INFO - 2023-05-26 07:01:51 --> Config Class Initialized
INFO - 2023-05-26 07:01:51 --> Hooks Class Initialized
INFO - 2023-05-26 07:01:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:01:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:01:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:01:51 --> Utf8 Class Initialized
INFO - 2023-05-26 07:01:51 --> Utf8 Class Initialized
INFO - 2023-05-26 07:01:51 --> URI Class Initialized
INFO - 2023-05-26 07:01:51 --> URI Class Initialized
INFO - 2023-05-26 07:01:51 --> Router Class Initialized
INFO - 2023-05-26 07:01:51 --> Router Class Initialized
INFO - 2023-05-26 07:01:51 --> Output Class Initialized
INFO - 2023-05-26 07:01:51 --> Output Class Initialized
INFO - 2023-05-26 07:01:51 --> Security Class Initialized
INFO - 2023-05-26 07:01:51 --> Security Class Initialized
DEBUG - 2023-05-26 07:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:01:51 --> Input Class Initialized
INFO - 2023-05-26 07:01:51 --> Input Class Initialized
INFO - 2023-05-26 07:01:51 --> Language Class Initialized
INFO - 2023-05-26 07:01:51 --> Language Class Initialized
INFO - 2023-05-26 07:01:51 --> Loader Class Initialized
INFO - 2023-05-26 07:01:51 --> Loader Class Initialized
INFO - 2023-05-26 07:01:51 --> Controller Class Initialized
DEBUG - 2023-05-26 07:01:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:01:51 --> Controller Class Initialized
DEBUG - 2023-05-26 07:01:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:01:51 --> Database Driver Class Initialized
INFO - 2023-05-26 07:01:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:01:51 --> Database Driver Class Initialized
INFO - 2023-05-26 07:01:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:01:51 --> Final output sent to browser
DEBUG - 2023-05-26 07:01:51 --> Total execution time: 0.1794
INFO - 2023-05-26 07:01:51 --> Database Driver Class Initialized
INFO - 2023-05-26 07:01:51 --> Model "Login_model" initialized
INFO - 2023-05-26 07:01:51 --> Config Class Initialized
INFO - 2023-05-26 07:01:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:01:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:01:51 --> Utf8 Class Initialized
INFO - 2023-05-26 07:01:51 --> URI Class Initialized
INFO - 2023-05-26 07:01:51 --> Router Class Initialized
INFO - 2023-05-26 07:01:51 --> Output Class Initialized
INFO - 2023-05-26 07:01:51 --> Security Class Initialized
DEBUG - 2023-05-26 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:01:51 --> Input Class Initialized
INFO - 2023-05-26 07:01:51 --> Language Class Initialized
INFO - 2023-05-26 07:01:51 --> Loader Class Initialized
INFO - 2023-05-26 07:01:51 --> Controller Class Initialized
DEBUG - 2023-05-26 07:01:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:01:51 --> Database Driver Class Initialized
INFO - 2023-05-26 07:01:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:01:51 --> Final output sent to browser
DEBUG - 2023-05-26 07:01:51 --> Total execution time: 0.2458
INFO - 2023-05-26 07:02:02 --> Final output sent to browser
DEBUG - 2023-05-26 07:02:02 --> Total execution time: 10.9490
INFO - 2023-05-26 07:02:02 --> Config Class Initialized
INFO - 2023-05-26 07:02:02 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:02:02 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:02:02 --> Utf8 Class Initialized
INFO - 2023-05-26 07:02:02 --> URI Class Initialized
INFO - 2023-05-26 07:02:02 --> Router Class Initialized
INFO - 2023-05-26 07:02:02 --> Output Class Initialized
INFO - 2023-05-26 07:02:02 --> Security Class Initialized
DEBUG - 2023-05-26 07:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:02:02 --> Input Class Initialized
INFO - 2023-05-26 07:02:02 --> Language Class Initialized
INFO - 2023-05-26 07:02:02 --> Loader Class Initialized
INFO - 2023-05-26 07:02:02 --> Controller Class Initialized
DEBUG - 2023-05-26 07:02:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:02:02 --> Database Driver Class Initialized
INFO - 2023-05-26 07:02:02 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:02:02 --> Database Driver Class Initialized
INFO - 2023-05-26 07:02:02 --> Model "Login_model" initialized
INFO - 2023-05-26 07:02:13 --> Final output sent to browser
DEBUG - 2023-05-26 07:02:13 --> Total execution time: 11.3836
INFO - 2023-05-26 07:02:27 --> Config Class Initialized
INFO - 2023-05-26 07:02:27 --> Config Class Initialized
INFO - 2023-05-26 07:02:27 --> Hooks Class Initialized
INFO - 2023-05-26 07:02:27 --> Hooks Class Initialized
INFO - 2023-05-26 07:02:27 --> Config Class Initialized
INFO - 2023-05-26 07:02:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:02:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:02:28 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:02:28 --> Utf8 Class Initialized
INFO - 2023-05-26 07:02:28 --> Utf8 Class Initialized
INFO - 2023-05-26 07:02:28 --> URI Class Initialized
INFO - 2023-05-26 07:02:28 --> URI Class Initialized
DEBUG - 2023-05-26 07:02:28 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:02:28 --> Utf8 Class Initialized
INFO - 2023-05-26 07:02:28 --> Router Class Initialized
INFO - 2023-05-26 07:02:28 --> Router Class Initialized
INFO - 2023-05-26 07:02:28 --> URI Class Initialized
INFO - 2023-05-26 07:02:28 --> Output Class Initialized
INFO - 2023-05-26 07:02:28 --> Output Class Initialized
INFO - 2023-05-26 07:02:28 --> Router Class Initialized
INFO - 2023-05-26 07:02:28 --> Security Class Initialized
INFO - 2023-05-26 07:02:28 --> Security Class Initialized
DEBUG - 2023-05-26 07:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:02:28 --> Input Class Initialized
INFO - 2023-05-26 07:02:28 --> Output Class Initialized
DEBUG - 2023-05-26 07:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:02:28 --> Input Class Initialized
INFO - 2023-05-26 07:02:28 --> Language Class Initialized
INFO - 2023-05-26 07:02:28 --> Security Class Initialized
INFO - 2023-05-26 07:02:28 --> Language Class Initialized
DEBUG - 2023-05-26 07:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:02:28 --> Input Class Initialized
INFO - 2023-05-26 07:02:28 --> Language Class Initialized
INFO - 2023-05-26 07:02:28 --> Loader Class Initialized
INFO - 2023-05-26 07:02:28 --> Loader Class Initialized
INFO - 2023-05-26 07:02:28 --> Controller Class Initialized
INFO - 2023-05-26 07:02:28 --> Controller Class Initialized
DEBUG - 2023-05-26 07:02:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 07:02:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:02:28 --> Loader Class Initialized
INFO - 2023-05-26 07:02:28 --> Controller Class Initialized
DEBUG - 2023-05-26 07:02:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:02:28 --> Database Driver Class Initialized
INFO - 2023-05-26 07:02:28 --> Database Driver Class Initialized
INFO - 2023-05-26 07:02:28 --> Database Driver Class Initialized
INFO - 2023-05-26 07:02:28 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:02:28 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:02:28 --> Final output sent to browser
INFO - 2023-05-26 07:02:28 --> Final output sent to browser
DEBUG - 2023-05-26 07:02:28 --> Total execution time: 0.8031
DEBUG - 2023-05-26 07:02:28 --> Total execution time: 0.8018
INFO - 2023-05-26 07:02:28 --> Database Driver Class Initialized
INFO - 2023-05-26 07:02:28 --> Config Class Initialized
INFO - 2023-05-26 07:02:28 --> Config Class Initialized
INFO - 2023-05-26 07:02:28 --> Hooks Class Initialized
INFO - 2023-05-26 07:02:28 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:02:28 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:02:28 --> Model "Login_model" initialized
INFO - 2023-05-26 07:02:28 --> Config Class Initialized
INFO - 2023-05-26 07:02:28 --> Utf8 Class Initialized
DEBUG - 2023-05-26 07:02:28 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:02:28 --> Hooks Class Initialized
INFO - 2023-05-26 07:02:28 --> Utf8 Class Initialized
INFO - 2023-05-26 07:02:28 --> URI Class Initialized
INFO - 2023-05-26 07:02:28 --> URI Class Initialized
INFO - 2023-05-26 07:02:29 --> Final output sent to browser
INFO - 2023-05-26 07:02:29 --> Router Class Initialized
INFO - 2023-05-26 07:02:29 --> Router Class Initialized
DEBUG - 2023-05-26 07:02:29 --> Total execution time: 1.1443
INFO - 2023-05-26 07:02:29 --> Output Class Initialized
DEBUG - 2023-05-26 07:02:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:02:29 --> Utf8 Class Initialized
INFO - 2023-05-26 07:02:29 --> Output Class Initialized
INFO - 2023-05-26 07:02:29 --> Security Class Initialized
INFO - 2023-05-26 07:02:29 --> URI Class Initialized
DEBUG - 2023-05-26 07:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:02:29 --> Input Class Initialized
INFO - 2023-05-26 07:02:29 --> Security Class Initialized
INFO - 2023-05-26 07:02:29 --> Language Class Initialized
INFO - 2023-05-26 07:02:29 --> Router Class Initialized
DEBUG - 2023-05-26 07:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:02:29 --> Config Class Initialized
INFO - 2023-05-26 07:02:29 --> Hooks Class Initialized
INFO - 2023-05-26 07:02:29 --> Input Class Initialized
INFO - 2023-05-26 07:02:29 --> Output Class Initialized
INFO - 2023-05-26 07:02:29 --> Language Class Initialized
INFO - 2023-05-26 07:02:29 --> Loader Class Initialized
INFO - 2023-05-26 07:02:29 --> Security Class Initialized
INFO - 2023-05-26 07:02:29 --> Controller Class Initialized
DEBUG - 2023-05-26 07:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:02:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:02:29 --> Input Class Initialized
DEBUG - 2023-05-26 07:02:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:02:29 --> Utf8 Class Initialized
INFO - 2023-05-26 07:02:29 --> Loader Class Initialized
INFO - 2023-05-26 07:02:29 --> Language Class Initialized
INFO - 2023-05-26 07:02:29 --> URI Class Initialized
INFO - 2023-05-26 07:02:29 --> Controller Class Initialized
DEBUG - 2023-05-26 07:02:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:02:29 --> Database Driver Class Initialized
INFO - 2023-05-26 07:02:29 --> Loader Class Initialized
INFO - 2023-05-26 07:02:29 --> Router Class Initialized
INFO - 2023-05-26 07:02:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:02:29 --> Controller Class Initialized
INFO - 2023-05-26 07:02:29 --> Output Class Initialized
INFO - 2023-05-26 07:02:29 --> Database Driver Class Initialized
DEBUG - 2023-05-26 07:02:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:02:29 --> Security Class Initialized
INFO - 2023-05-26 07:02:29 --> Final output sent to browser
DEBUG - 2023-05-26 07:02:29 --> Total execution time: 0.8247
DEBUG - 2023-05-26 07:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:02:29 --> Input Class Initialized
INFO - 2023-05-26 07:02:29 --> Language Class Initialized
INFO - 2023-05-26 07:02:29 --> Loader Class Initialized
INFO - 2023-05-26 07:02:29 --> Database Driver Class Initialized
INFO - 2023-05-26 07:02:29 --> Controller Class Initialized
INFO - 2023-05-26 07:02:29 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 07:02:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:02:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:02:29 --> Final output sent to browser
INFO - 2023-05-26 07:02:29 --> Database Driver Class Initialized
INFO - 2023-05-26 07:02:29 --> Final output sent to browser
DEBUG - 2023-05-26 07:02:29 --> Total execution time: 1.0583
DEBUG - 2023-05-26 07:02:29 --> Total execution time: 0.9892
INFO - 2023-05-26 07:02:29 --> Database Driver Class Initialized
INFO - 2023-05-26 07:02:29 --> Config Class Initialized
INFO - 2023-05-26 07:02:29 --> Hooks Class Initialized
INFO - 2023-05-26 07:02:30 --> Model "Login_model" initialized
DEBUG - 2023-05-26 07:02:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:02:30 --> Utf8 Class Initialized
INFO - 2023-05-26 07:02:30 --> Final output sent to browser
DEBUG - 2023-05-26 07:02:30 --> Total execution time: 0.8934
INFO - 2023-05-26 07:02:30 --> URI Class Initialized
INFO - 2023-05-26 07:02:30 --> Router Class Initialized
INFO - 2023-05-26 07:02:30 --> Output Class Initialized
INFO - 2023-05-26 07:02:30 --> Security Class Initialized
DEBUG - 2023-05-26 07:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:02:30 --> Input Class Initialized
INFO - 2023-05-26 07:02:30 --> Language Class Initialized
INFO - 2023-05-26 07:02:30 --> Loader Class Initialized
INFO - 2023-05-26 07:02:30 --> Controller Class Initialized
DEBUG - 2023-05-26 07:02:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:02:30 --> Database Driver Class Initialized
INFO - 2023-05-26 07:02:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:02:30 --> Final output sent to browser
DEBUG - 2023-05-26 07:02:30 --> Total execution time: 0.6496
INFO - 2023-05-26 07:03:27 --> Config Class Initialized
INFO - 2023-05-26 07:03:27 --> Config Class Initialized
INFO - 2023-05-26 07:03:27 --> Hooks Class Initialized
INFO - 2023-05-26 07:03:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:03:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:03:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:03:27 --> Utf8 Class Initialized
INFO - 2023-05-26 07:03:27 --> Utf8 Class Initialized
INFO - 2023-05-26 07:03:27 --> URI Class Initialized
INFO - 2023-05-26 07:03:27 --> URI Class Initialized
INFO - 2023-05-26 07:03:27 --> Router Class Initialized
INFO - 2023-05-26 07:03:27 --> Router Class Initialized
INFO - 2023-05-26 07:03:27 --> Output Class Initialized
INFO - 2023-05-26 07:03:27 --> Output Class Initialized
INFO - 2023-05-26 07:03:27 --> Security Class Initialized
INFO - 2023-05-26 07:03:27 --> Security Class Initialized
DEBUG - 2023-05-26 07:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:03:27 --> Input Class Initialized
INFO - 2023-05-26 07:03:27 --> Input Class Initialized
INFO - 2023-05-26 07:03:27 --> Language Class Initialized
INFO - 2023-05-26 07:03:27 --> Language Class Initialized
INFO - 2023-05-26 07:03:27 --> Loader Class Initialized
INFO - 2023-05-26 07:03:27 --> Loader Class Initialized
INFO - 2023-05-26 07:03:27 --> Controller Class Initialized
DEBUG - 2023-05-26 07:03:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:03:27 --> Controller Class Initialized
DEBUG - 2023-05-26 07:03:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:03:27 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:27 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:03:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:03:27 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:27 --> Model "Login_model" initialized
INFO - 2023-05-26 07:03:30 --> Final output sent to browser
DEBUG - 2023-05-26 07:03:30 --> Total execution time: 2.5847
INFO - 2023-05-26 07:03:30 --> Config Class Initialized
INFO - 2023-05-26 07:03:30 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:03:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:03:30 --> Utf8 Class Initialized
INFO - 2023-05-26 07:03:30 --> URI Class Initialized
INFO - 2023-05-26 07:03:30 --> Router Class Initialized
INFO - 2023-05-26 07:03:30 --> Output Class Initialized
INFO - 2023-05-26 07:03:30 --> Security Class Initialized
DEBUG - 2023-05-26 07:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:03:30 --> Input Class Initialized
INFO - 2023-05-26 07:03:30 --> Language Class Initialized
INFO - 2023-05-26 07:03:30 --> Loader Class Initialized
INFO - 2023-05-26 07:03:30 --> Controller Class Initialized
DEBUG - 2023-05-26 07:03:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:03:30 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:03:32 --> Final output sent to browser
DEBUG - 2023-05-26 07:03:32 --> Total execution time: 1.8994
INFO - 2023-05-26 07:03:40 --> Final output sent to browser
DEBUG - 2023-05-26 07:03:40 --> Total execution time: 12.8850
INFO - 2023-05-26 07:03:40 --> Config Class Initialized
INFO - 2023-05-26 07:03:40 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:03:40 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:03:40 --> Utf8 Class Initialized
INFO - 2023-05-26 07:03:40 --> URI Class Initialized
INFO - 2023-05-26 07:03:40 --> Router Class Initialized
INFO - 2023-05-26 07:03:40 --> Output Class Initialized
INFO - 2023-05-26 07:03:40 --> Security Class Initialized
DEBUG - 2023-05-26 07:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:03:40 --> Input Class Initialized
INFO - 2023-05-26 07:03:40 --> Language Class Initialized
INFO - 2023-05-26 07:03:40 --> Loader Class Initialized
INFO - 2023-05-26 07:03:40 --> Controller Class Initialized
DEBUG - 2023-05-26 07:03:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:03:40 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:03:40 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:40 --> Model "Login_model" initialized
INFO - 2023-05-26 07:03:43 --> Config Class Initialized
INFO - 2023-05-26 07:03:43 --> Config Class Initialized
INFO - 2023-05-26 07:03:43 --> Hooks Class Initialized
INFO - 2023-05-26 07:03:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:03:43 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:03:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:03:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:03:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:03:43 --> URI Class Initialized
INFO - 2023-05-26 07:03:43 --> URI Class Initialized
INFO - 2023-05-26 07:03:43 --> Router Class Initialized
INFO - 2023-05-26 07:03:43 --> Router Class Initialized
INFO - 2023-05-26 07:03:43 --> Output Class Initialized
INFO - 2023-05-26 07:03:43 --> Output Class Initialized
INFO - 2023-05-26 07:03:43 --> Security Class Initialized
INFO - 2023-05-26 07:03:43 --> Security Class Initialized
DEBUG - 2023-05-26 07:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:03:43 --> Input Class Initialized
INFO - 2023-05-26 07:03:43 --> Input Class Initialized
INFO - 2023-05-26 07:03:43 --> Language Class Initialized
INFO - 2023-05-26 07:03:43 --> Language Class Initialized
INFO - 2023-05-26 07:03:43 --> Loader Class Initialized
INFO - 2023-05-26 07:03:43 --> Loader Class Initialized
INFO - 2023-05-26 07:03:43 --> Controller Class Initialized
INFO - 2023-05-26 07:03:43 --> Controller Class Initialized
DEBUG - 2023-05-26 07:03:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 07:03:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:03:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:03:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:43 --> Model "Login_model" initialized
INFO - 2023-05-26 07:03:43 --> Final output sent to browser
DEBUG - 2023-05-26 07:03:43 --> Total execution time: 0.2690
INFO - 2023-05-26 07:03:43 --> Config Class Initialized
INFO - 2023-05-26 07:03:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:03:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:03:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:03:43 --> URI Class Initialized
INFO - 2023-05-26 07:03:43 --> Router Class Initialized
INFO - 2023-05-26 07:03:43 --> Output Class Initialized
INFO - 2023-05-26 07:03:43 --> Security Class Initialized
DEBUG - 2023-05-26 07:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:03:43 --> Input Class Initialized
INFO - 2023-05-26 07:03:43 --> Language Class Initialized
INFO - 2023-05-26 07:03:43 --> Loader Class Initialized
INFO - 2023-05-26 07:03:43 --> Controller Class Initialized
DEBUG - 2023-05-26 07:03:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:03:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:03:43 --> Config Class Initialized
INFO - 2023-05-26 07:03:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:03:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:03:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:03:43 --> URI Class Initialized
INFO - 2023-05-26 07:03:43 --> Router Class Initialized
INFO - 2023-05-26 07:03:43 --> Output Class Initialized
INFO - 2023-05-26 07:03:43 --> Security Class Initialized
DEBUG - 2023-05-26 07:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:03:43 --> Input Class Initialized
INFO - 2023-05-26 07:03:43 --> Language Class Initialized
INFO - 2023-05-26 07:03:44 --> Loader Class Initialized
INFO - 2023-05-26 07:03:44 --> Final output sent to browser
DEBUG - 2023-05-26 07:03:44 --> Total execution time: 0.8637
INFO - 2023-05-26 07:03:44 --> Controller Class Initialized
DEBUG - 2023-05-26 07:03:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:03:44 --> Config Class Initialized
INFO - 2023-05-26 07:03:44 --> Hooks Class Initialized
INFO - 2023-05-26 07:03:44 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:44 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 07:03:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:03:44 --> Utf8 Class Initialized
INFO - 2023-05-26 07:03:44 --> URI Class Initialized
INFO - 2023-05-26 07:03:44 --> Router Class Initialized
INFO - 2023-05-26 07:03:44 --> Output Class Initialized
INFO - 2023-05-26 07:03:44 --> Security Class Initialized
DEBUG - 2023-05-26 07:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:03:44 --> Input Class Initialized
INFO - 2023-05-26 07:03:44 --> Language Class Initialized
INFO - 2023-05-26 07:03:44 --> Loader Class Initialized
INFO - 2023-05-26 07:03:44 --> Controller Class Initialized
DEBUG - 2023-05-26 07:03:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:03:44 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:44 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:44 --> Model "Login_model" initialized
INFO - 2023-05-26 07:03:44 --> Final output sent to browser
DEBUG - 2023-05-26 07:03:44 --> Total execution time: 0.3388
INFO - 2023-05-26 07:03:44 --> Config Class Initialized
INFO - 2023-05-26 07:03:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:03:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:03:44 --> Utf8 Class Initialized
INFO - 2023-05-26 07:03:44 --> URI Class Initialized
INFO - 2023-05-26 07:03:44 --> Router Class Initialized
INFO - 2023-05-26 07:03:44 --> Output Class Initialized
INFO - 2023-05-26 07:03:44 --> Security Class Initialized
DEBUG - 2023-05-26 07:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:03:44 --> Input Class Initialized
INFO - 2023-05-26 07:03:44 --> Language Class Initialized
INFO - 2023-05-26 07:03:44 --> Loader Class Initialized
INFO - 2023-05-26 07:03:44 --> Controller Class Initialized
DEBUG - 2023-05-26 07:03:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:03:44 --> Final output sent to browser
DEBUG - 2023-05-26 07:03:44 --> Total execution time: 1.1638
INFO - 2023-05-26 07:03:44 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:03:44 --> Config Class Initialized
INFO - 2023-05-26 07:03:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:03:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:03:44 --> Utf8 Class Initialized
INFO - 2023-05-26 07:03:44 --> URI Class Initialized
INFO - 2023-05-26 07:03:44 --> Router Class Initialized
INFO - 2023-05-26 07:03:44 --> Output Class Initialized
INFO - 2023-05-26 07:03:44 --> Security Class Initialized
DEBUG - 2023-05-26 07:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:03:44 --> Input Class Initialized
INFO - 2023-05-26 07:03:44 --> Language Class Initialized
INFO - 2023-05-26 07:03:44 --> Loader Class Initialized
INFO - 2023-05-26 07:03:44 --> Controller Class Initialized
DEBUG - 2023-05-26 07:03:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:03:44 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:44 --> Final output sent to browser
DEBUG - 2023-05-26 07:03:44 --> Total execution time: 1.0750
INFO - 2023-05-26 07:03:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:03:45 --> Config Class Initialized
INFO - 2023-05-26 07:03:45 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:03:45 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:03:45 --> Utf8 Class Initialized
INFO - 2023-05-26 07:03:45 --> URI Class Initialized
INFO - 2023-05-26 07:03:45 --> Router Class Initialized
INFO - 2023-05-26 07:03:45 --> Output Class Initialized
INFO - 2023-05-26 07:03:45 --> Security Class Initialized
DEBUG - 2023-05-26 07:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:03:45 --> Input Class Initialized
INFO - 2023-05-26 07:03:45 --> Language Class Initialized
INFO - 2023-05-26 07:03:45 --> Loader Class Initialized
INFO - 2023-05-26 07:03:45 --> Controller Class Initialized
DEBUG - 2023-05-26 07:03:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:03:45 --> Database Driver Class Initialized
INFO - 2023-05-26 07:03:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:03:47 --> Final output sent to browser
DEBUG - 2023-05-26 07:03:47 --> Total execution time: 2.3257
INFO - 2023-05-26 07:03:47 --> Final output sent to browser
DEBUG - 2023-05-26 07:03:47 --> Total execution time: 2.8219
INFO - 2023-05-26 07:03:48 --> Final output sent to browser
DEBUG - 2023-05-26 07:03:48 --> Total execution time: 3.3448
INFO - 2023-05-26 07:03:50 --> Final output sent to browser
DEBUG - 2023-05-26 07:03:50 --> Total execution time: 9.8349
INFO - 2023-05-26 07:04:43 --> Config Class Initialized
INFO - 2023-05-26 07:04:43 --> Config Class Initialized
INFO - 2023-05-26 07:04:43 --> Hooks Class Initialized
INFO - 2023-05-26 07:04:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:04:43 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:04:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:04:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:04:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:04:43 --> URI Class Initialized
INFO - 2023-05-26 07:04:43 --> URI Class Initialized
INFO - 2023-05-26 07:04:43 --> Router Class Initialized
INFO - 2023-05-26 07:04:43 --> Router Class Initialized
INFO - 2023-05-26 07:04:43 --> Output Class Initialized
INFO - 2023-05-26 07:04:43 --> Output Class Initialized
INFO - 2023-05-26 07:04:43 --> Security Class Initialized
INFO - 2023-05-26 07:04:43 --> Security Class Initialized
DEBUG - 2023-05-26 07:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:04:43 --> Input Class Initialized
INFO - 2023-05-26 07:04:43 --> Input Class Initialized
INFO - 2023-05-26 07:04:43 --> Language Class Initialized
INFO - 2023-05-26 07:04:43 --> Language Class Initialized
INFO - 2023-05-26 07:04:43 --> Loader Class Initialized
INFO - 2023-05-26 07:04:43 --> Loader Class Initialized
INFO - 2023-05-26 07:04:43 --> Controller Class Initialized
INFO - 2023-05-26 07:04:43 --> Controller Class Initialized
DEBUG - 2023-05-26 07:04:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 07:04:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:04:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:04:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:04:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:04:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:04:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:04:43 --> Model "Login_model" initialized
INFO - 2023-05-26 07:04:43 --> Final output sent to browser
DEBUG - 2023-05-26 07:04:43 --> Total execution time: 0.4343
INFO - 2023-05-26 07:04:43 --> Config Class Initialized
INFO - 2023-05-26 07:04:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:04:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:04:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:04:43 --> URI Class Initialized
INFO - 2023-05-26 07:04:43 --> Router Class Initialized
INFO - 2023-05-26 07:04:43 --> Output Class Initialized
INFO - 2023-05-26 07:04:43 --> Security Class Initialized
DEBUG - 2023-05-26 07:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:04:43 --> Input Class Initialized
INFO - 2023-05-26 07:04:43 --> Language Class Initialized
INFO - 2023-05-26 07:04:43 --> Loader Class Initialized
INFO - 2023-05-26 07:04:43 --> Controller Class Initialized
DEBUG - 2023-05-26 07:04:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:04:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:04:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:04:43 --> Final output sent to browser
DEBUG - 2023-05-26 07:04:43 --> Total execution time: 0.2975
INFO - 2023-05-26 07:04:51 --> Final output sent to browser
DEBUG - 2023-05-26 07:04:51 --> Total execution time: 8.5191
INFO - 2023-05-26 07:04:51 --> Config Class Initialized
INFO - 2023-05-26 07:04:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:04:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:04:51 --> Utf8 Class Initialized
INFO - 2023-05-26 07:04:51 --> URI Class Initialized
INFO - 2023-05-26 07:04:51 --> Router Class Initialized
INFO - 2023-05-26 07:04:51 --> Output Class Initialized
INFO - 2023-05-26 07:04:51 --> Security Class Initialized
DEBUG - 2023-05-26 07:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:04:51 --> Input Class Initialized
INFO - 2023-05-26 07:04:51 --> Language Class Initialized
INFO - 2023-05-26 07:04:51 --> Loader Class Initialized
INFO - 2023-05-26 07:04:51 --> Controller Class Initialized
DEBUG - 2023-05-26 07:04:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:04:51 --> Database Driver Class Initialized
INFO - 2023-05-26 07:04:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:04:51 --> Database Driver Class Initialized
INFO - 2023-05-26 07:04:51 --> Model "Login_model" initialized
INFO - 2023-05-26 07:05:00 --> Final output sent to browser
DEBUG - 2023-05-26 07:05:00 --> Total execution time: 9.1106
INFO - 2023-05-26 07:05:43 --> Config Class Initialized
INFO - 2023-05-26 07:05:43 --> Config Class Initialized
INFO - 2023-05-26 07:05:43 --> Hooks Class Initialized
INFO - 2023-05-26 07:05:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:05:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:05:43 --> Utf8 Class Initialized
DEBUG - 2023-05-26 07:05:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:05:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:05:43 --> URI Class Initialized
INFO - 2023-05-26 07:05:43 --> URI Class Initialized
INFO - 2023-05-26 07:05:43 --> Router Class Initialized
INFO - 2023-05-26 07:05:43 --> Router Class Initialized
INFO - 2023-05-26 07:05:43 --> Output Class Initialized
INFO - 2023-05-26 07:05:43 --> Output Class Initialized
INFO - 2023-05-26 07:05:43 --> Security Class Initialized
INFO - 2023-05-26 07:05:43 --> Security Class Initialized
DEBUG - 2023-05-26 07:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:05:43 --> Input Class Initialized
INFO - 2023-05-26 07:05:43 --> Input Class Initialized
INFO - 2023-05-26 07:05:43 --> Language Class Initialized
INFO - 2023-05-26 07:05:43 --> Language Class Initialized
INFO - 2023-05-26 07:05:43 --> Loader Class Initialized
INFO - 2023-05-26 07:05:43 --> Controller Class Initialized
INFO - 2023-05-26 07:05:43 --> Loader Class Initialized
DEBUG - 2023-05-26 07:05:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:05:43 --> Controller Class Initialized
DEBUG - 2023-05-26 07:05:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:05:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:05:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:05:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:05:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:05:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:05:43 --> Model "Login_model" initialized
INFO - 2023-05-26 07:05:44 --> Final output sent to browser
DEBUG - 2023-05-26 07:05:44 --> Total execution time: 0.6753
INFO - 2023-05-26 07:05:44 --> Config Class Initialized
INFO - 2023-05-26 07:05:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:05:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:05:44 --> Utf8 Class Initialized
INFO - 2023-05-26 07:05:44 --> URI Class Initialized
INFO - 2023-05-26 07:05:44 --> Router Class Initialized
INFO - 2023-05-26 07:05:44 --> Output Class Initialized
INFO - 2023-05-26 07:05:44 --> Security Class Initialized
DEBUG - 2023-05-26 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:05:44 --> Input Class Initialized
INFO - 2023-05-26 07:05:44 --> Language Class Initialized
INFO - 2023-05-26 07:05:44 --> Loader Class Initialized
INFO - 2023-05-26 07:05:44 --> Controller Class Initialized
DEBUG - 2023-05-26 07:05:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:05:44 --> Database Driver Class Initialized
INFO - 2023-05-26 07:05:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:05:44 --> Final output sent to browser
DEBUG - 2023-05-26 07:05:44 --> Total execution time: 0.3443
INFO - 2023-05-26 07:05:54 --> Final output sent to browser
DEBUG - 2023-05-26 07:05:54 --> Total execution time: 10.7505
INFO - 2023-05-26 07:05:54 --> Config Class Initialized
INFO - 2023-05-26 07:05:54 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:05:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:05:54 --> Utf8 Class Initialized
INFO - 2023-05-26 07:05:54 --> URI Class Initialized
INFO - 2023-05-26 07:05:54 --> Router Class Initialized
INFO - 2023-05-26 07:05:54 --> Output Class Initialized
INFO - 2023-05-26 07:05:54 --> Security Class Initialized
DEBUG - 2023-05-26 07:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:05:54 --> Input Class Initialized
INFO - 2023-05-26 07:05:54 --> Language Class Initialized
INFO - 2023-05-26 07:05:54 --> Loader Class Initialized
INFO - 2023-05-26 07:05:54 --> Controller Class Initialized
DEBUG - 2023-05-26 07:05:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:05:54 --> Database Driver Class Initialized
INFO - 2023-05-26 07:05:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:05:54 --> Database Driver Class Initialized
INFO - 2023-05-26 07:05:54 --> Model "Login_model" initialized
INFO - 2023-05-26 07:06:05 --> Final output sent to browser
DEBUG - 2023-05-26 07:06:05 --> Total execution time: 11.1059
INFO - 2023-05-26 07:06:43 --> Config Class Initialized
INFO - 2023-05-26 07:06:43 --> Config Class Initialized
INFO - 2023-05-26 07:06:43 --> Hooks Class Initialized
INFO - 2023-05-26 07:06:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:06:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:06:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:06:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:06:43 --> URI Class Initialized
INFO - 2023-05-26 07:06:43 --> URI Class Initialized
INFO - 2023-05-26 07:06:43 --> Router Class Initialized
INFO - 2023-05-26 07:06:43 --> Router Class Initialized
INFO - 2023-05-26 07:06:43 --> Output Class Initialized
INFO - 2023-05-26 07:06:43 --> Output Class Initialized
INFO - 2023-05-26 07:06:43 --> Security Class Initialized
DEBUG - 2023-05-26 07:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:06:43 --> Security Class Initialized
INFO - 2023-05-26 07:06:43 --> Input Class Initialized
INFO - 2023-05-26 07:06:43 --> Language Class Initialized
DEBUG - 2023-05-26 07:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:06:43 --> Input Class Initialized
INFO - 2023-05-26 07:06:43 --> Language Class Initialized
INFO - 2023-05-26 07:06:43 --> Loader Class Initialized
INFO - 2023-05-26 07:06:43 --> Loader Class Initialized
INFO - 2023-05-26 07:06:43 --> Controller Class Initialized
INFO - 2023-05-26 07:06:43 --> Controller Class Initialized
DEBUG - 2023-05-26 07:06:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 07:06:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:06:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:06:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:06:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:06:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:06:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:06:43 --> Model "Login_model" initialized
INFO - 2023-05-26 07:06:45 --> Final output sent to browser
DEBUG - 2023-05-26 07:06:45 --> Total execution time: 2.1063
INFO - 2023-05-26 07:06:45 --> Config Class Initialized
INFO - 2023-05-26 07:06:45 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:06:45 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:06:45 --> Utf8 Class Initialized
INFO - 2023-05-26 07:06:45 --> URI Class Initialized
INFO - 2023-05-26 07:06:45 --> Router Class Initialized
INFO - 2023-05-26 07:06:45 --> Output Class Initialized
INFO - 2023-05-26 07:06:45 --> Security Class Initialized
DEBUG - 2023-05-26 07:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:06:45 --> Input Class Initialized
INFO - 2023-05-26 07:06:45 --> Language Class Initialized
INFO - 2023-05-26 07:06:45 --> Loader Class Initialized
INFO - 2023-05-26 07:06:45 --> Controller Class Initialized
DEBUG - 2023-05-26 07:06:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:06:45 --> Database Driver Class Initialized
INFO - 2023-05-26 07:06:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:06:47 --> Final output sent to browser
DEBUG - 2023-05-26 07:06:47 --> Total execution time: 1.6543
INFO - 2023-05-26 07:06:59 --> Final output sent to browser
DEBUG - 2023-05-26 07:06:59 --> Total execution time: 15.6283
INFO - 2023-05-26 07:06:59 --> Config Class Initialized
INFO - 2023-05-26 07:06:59 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:06:59 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:06:59 --> Utf8 Class Initialized
INFO - 2023-05-26 07:06:59 --> URI Class Initialized
INFO - 2023-05-26 07:06:59 --> Router Class Initialized
INFO - 2023-05-26 07:06:59 --> Output Class Initialized
INFO - 2023-05-26 07:06:59 --> Security Class Initialized
DEBUG - 2023-05-26 07:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:06:59 --> Input Class Initialized
INFO - 2023-05-26 07:06:59 --> Language Class Initialized
INFO - 2023-05-26 07:06:59 --> Loader Class Initialized
INFO - 2023-05-26 07:06:59 --> Controller Class Initialized
DEBUG - 2023-05-26 07:06:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:06:59 --> Database Driver Class Initialized
INFO - 2023-05-26 07:06:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:06:59 --> Database Driver Class Initialized
INFO - 2023-05-26 07:06:59 --> Model "Login_model" initialized
INFO - 2023-05-26 07:07:18 --> Final output sent to browser
DEBUG - 2023-05-26 07:07:18 --> Total execution time: 18.9950
INFO - 2023-05-26 07:07:43 --> Config Class Initialized
INFO - 2023-05-26 07:07:43 --> Config Class Initialized
INFO - 2023-05-26 07:07:43 --> Hooks Class Initialized
INFO - 2023-05-26 07:07:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:07:43 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:07:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:07:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:07:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:07:43 --> URI Class Initialized
INFO - 2023-05-26 07:07:43 --> URI Class Initialized
INFO - 2023-05-26 07:07:43 --> Router Class Initialized
INFO - 2023-05-26 07:07:43 --> Router Class Initialized
INFO - 2023-05-26 07:07:43 --> Output Class Initialized
INFO - 2023-05-26 07:07:43 --> Output Class Initialized
INFO - 2023-05-26 07:07:43 --> Security Class Initialized
INFO - 2023-05-26 07:07:43 --> Security Class Initialized
DEBUG - 2023-05-26 07:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:07:43 --> Input Class Initialized
INFO - 2023-05-26 07:07:43 --> Input Class Initialized
INFO - 2023-05-26 07:07:43 --> Language Class Initialized
INFO - 2023-05-26 07:07:43 --> Language Class Initialized
INFO - 2023-05-26 07:07:43 --> Loader Class Initialized
INFO - 2023-05-26 07:07:43 --> Loader Class Initialized
INFO - 2023-05-26 07:07:43 --> Controller Class Initialized
DEBUG - 2023-05-26 07:07:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:07:43 --> Controller Class Initialized
DEBUG - 2023-05-26 07:07:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:07:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:07:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:07:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:07:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:07:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:07:43 --> Model "Login_model" initialized
INFO - 2023-05-26 07:07:43 --> Final output sent to browser
DEBUG - 2023-05-26 07:07:43 --> Total execution time: 0.2705
INFO - 2023-05-26 07:07:43 --> Config Class Initialized
INFO - 2023-05-26 07:07:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:07:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:07:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:07:43 --> URI Class Initialized
INFO - 2023-05-26 07:07:43 --> Router Class Initialized
INFO - 2023-05-26 07:07:43 --> Output Class Initialized
INFO - 2023-05-26 07:07:43 --> Security Class Initialized
DEBUG - 2023-05-26 07:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:07:43 --> Input Class Initialized
INFO - 2023-05-26 07:07:43 --> Language Class Initialized
INFO - 2023-05-26 07:07:43 --> Loader Class Initialized
INFO - 2023-05-26 07:07:43 --> Controller Class Initialized
DEBUG - 2023-05-26 07:07:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:07:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:07:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:07:43 --> Final output sent to browser
DEBUG - 2023-05-26 07:07:43 --> Total execution time: 0.4328
INFO - 2023-05-26 07:07:52 --> Final output sent to browser
DEBUG - 2023-05-26 07:07:52 --> Total execution time: 9.1621
INFO - 2023-05-26 07:07:52 --> Config Class Initialized
INFO - 2023-05-26 07:07:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:07:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:07:52 --> Utf8 Class Initialized
INFO - 2023-05-26 07:07:52 --> URI Class Initialized
INFO - 2023-05-26 07:07:52 --> Router Class Initialized
INFO - 2023-05-26 07:07:52 --> Output Class Initialized
INFO - 2023-05-26 07:07:52 --> Security Class Initialized
DEBUG - 2023-05-26 07:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:07:52 --> Input Class Initialized
INFO - 2023-05-26 07:07:52 --> Language Class Initialized
INFO - 2023-05-26 07:07:52 --> Loader Class Initialized
INFO - 2023-05-26 07:07:52 --> Controller Class Initialized
DEBUG - 2023-05-26 07:07:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:07:52 --> Database Driver Class Initialized
INFO - 2023-05-26 07:07:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:07:52 --> Database Driver Class Initialized
INFO - 2023-05-26 07:07:52 --> Model "Login_model" initialized
INFO - 2023-05-26 07:08:04 --> Final output sent to browser
DEBUG - 2023-05-26 07:08:04 --> Total execution time: 12.4280
INFO - 2023-05-26 07:08:43 --> Config Class Initialized
INFO - 2023-05-26 07:08:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:08:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:08:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:08:43 --> URI Class Initialized
INFO - 2023-05-26 07:08:43 --> Router Class Initialized
INFO - 2023-05-26 07:08:43 --> Output Class Initialized
INFO - 2023-05-26 07:08:43 --> Security Class Initialized
DEBUG - 2023-05-26 07:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:08:43 --> Input Class Initialized
INFO - 2023-05-26 07:08:43 --> Language Class Initialized
INFO - 2023-05-26 07:08:43 --> Loader Class Initialized
INFO - 2023-05-26 07:08:43 --> Controller Class Initialized
DEBUG - 2023-05-26 07:08:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:08:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:08:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:08:43 --> Config Class Initialized
INFO - 2023-05-26 07:08:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:08:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:08:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:08:43 --> URI Class Initialized
INFO - 2023-05-26 07:08:43 --> Router Class Initialized
INFO - 2023-05-26 07:08:43 --> Output Class Initialized
INFO - 2023-05-26 07:08:43 --> Security Class Initialized
DEBUG - 2023-05-26 07:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:08:43 --> Input Class Initialized
INFO - 2023-05-26 07:08:43 --> Language Class Initialized
INFO - 2023-05-26 07:08:43 --> Loader Class Initialized
INFO - 2023-05-26 07:08:43 --> Controller Class Initialized
DEBUG - 2023-05-26 07:08:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:08:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:08:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:08:44 --> Database Driver Class Initialized
INFO - 2023-05-26 07:08:44 --> Model "Login_model" initialized
INFO - 2023-05-26 07:08:44 --> Final output sent to browser
DEBUG - 2023-05-26 07:08:44 --> Total execution time: 1.4369
INFO - 2023-05-26 07:08:44 --> Config Class Initialized
INFO - 2023-05-26 07:08:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:08:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:08:44 --> Utf8 Class Initialized
INFO - 2023-05-26 07:08:44 --> URI Class Initialized
INFO - 2023-05-26 07:08:45 --> Router Class Initialized
INFO - 2023-05-26 07:08:45 --> Output Class Initialized
INFO - 2023-05-26 07:08:45 --> Security Class Initialized
DEBUG - 2023-05-26 07:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:08:45 --> Input Class Initialized
INFO - 2023-05-26 07:08:45 --> Language Class Initialized
INFO - 2023-05-26 07:08:45 --> Loader Class Initialized
INFO - 2023-05-26 07:08:45 --> Controller Class Initialized
DEBUG - 2023-05-26 07:08:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:08:45 --> Database Driver Class Initialized
INFO - 2023-05-26 07:08:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:08:50 --> Final output sent to browser
DEBUG - 2023-05-26 07:08:50 --> Total execution time: 5.5713
INFO - 2023-05-26 07:08:58 --> Final output sent to browser
DEBUG - 2023-05-26 07:08:58 --> Total execution time: 14.9443
INFO - 2023-05-26 07:08:58 --> Config Class Initialized
INFO - 2023-05-26 07:08:58 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:08:58 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:08:58 --> Utf8 Class Initialized
INFO - 2023-05-26 07:08:58 --> URI Class Initialized
INFO - 2023-05-26 07:08:58 --> Router Class Initialized
INFO - 2023-05-26 07:08:58 --> Output Class Initialized
INFO - 2023-05-26 07:08:58 --> Security Class Initialized
DEBUG - 2023-05-26 07:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:08:58 --> Input Class Initialized
INFO - 2023-05-26 07:08:58 --> Language Class Initialized
INFO - 2023-05-26 07:08:58 --> Loader Class Initialized
INFO - 2023-05-26 07:08:58 --> Controller Class Initialized
DEBUG - 2023-05-26 07:08:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:08:58 --> Database Driver Class Initialized
INFO - 2023-05-26 07:08:58 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:08:58 --> Database Driver Class Initialized
INFO - 2023-05-26 07:08:59 --> Model "Login_model" initialized
INFO - 2023-05-26 07:09:10 --> Final output sent to browser
DEBUG - 2023-05-26 07:09:10 --> Total execution time: 11.6673
INFO - 2023-05-26 07:09:43 --> Config Class Initialized
INFO - 2023-05-26 07:09:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:09:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:09:43 --> Utf8 Class Initialized
INFO - 2023-05-26 07:09:43 --> URI Class Initialized
INFO - 2023-05-26 07:09:43 --> Router Class Initialized
INFO - 2023-05-26 07:09:43 --> Output Class Initialized
INFO - 2023-05-26 07:09:43 --> Security Class Initialized
DEBUG - 2023-05-26 07:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:09:43 --> Input Class Initialized
INFO - 2023-05-26 07:09:43 --> Language Class Initialized
INFO - 2023-05-26 07:09:43 --> Loader Class Initialized
INFO - 2023-05-26 07:09:43 --> Controller Class Initialized
DEBUG - 2023-05-26 07:09:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:09:43 --> Database Driver Class Initialized
INFO - 2023-05-26 07:09:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:09:44 --> Final output sent to browser
DEBUG - 2023-05-26 07:09:44 --> Total execution time: 0.6675
INFO - 2023-05-26 07:09:44 --> Config Class Initialized
INFO - 2023-05-26 07:09:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:09:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:09:44 --> Utf8 Class Initialized
INFO - 2023-05-26 07:09:44 --> URI Class Initialized
INFO - 2023-05-26 07:09:44 --> Router Class Initialized
INFO - 2023-05-26 07:09:44 --> Output Class Initialized
INFO - 2023-05-26 07:09:44 --> Security Class Initialized
DEBUG - 2023-05-26 07:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:09:44 --> Input Class Initialized
INFO - 2023-05-26 07:09:44 --> Language Class Initialized
INFO - 2023-05-26 07:09:44 --> Loader Class Initialized
INFO - 2023-05-26 07:09:44 --> Controller Class Initialized
DEBUG - 2023-05-26 07:09:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:09:44 --> Database Driver Class Initialized
INFO - 2023-05-26 07:09:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:09:44 --> Final output sent to browser
DEBUG - 2023-05-26 07:09:44 --> Total execution time: 0.2416
INFO - 2023-05-26 07:09:44 --> Config Class Initialized
INFO - 2023-05-26 07:09:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:09:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:09:44 --> Utf8 Class Initialized
INFO - 2023-05-26 07:09:44 --> URI Class Initialized
INFO - 2023-05-26 07:09:44 --> Router Class Initialized
INFO - 2023-05-26 07:09:44 --> Output Class Initialized
INFO - 2023-05-26 07:09:44 --> Security Class Initialized
DEBUG - 2023-05-26 07:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:09:44 --> Input Class Initialized
INFO - 2023-05-26 07:09:44 --> Language Class Initialized
INFO - 2023-05-26 07:09:44 --> Loader Class Initialized
INFO - 2023-05-26 07:09:44 --> Controller Class Initialized
DEBUG - 2023-05-26 07:09:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:09:44 --> Database Driver Class Initialized
INFO - 2023-05-26 07:09:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:09:44 --> Database Driver Class Initialized
INFO - 2023-05-26 07:09:44 --> Model "Login_model" initialized
INFO - 2023-05-26 07:09:55 --> Final output sent to browser
DEBUG - 2023-05-26 07:09:55 --> Total execution time: 10.8366
INFO - 2023-05-26 07:09:55 --> Config Class Initialized
INFO - 2023-05-26 07:09:55 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:09:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:09:55 --> Utf8 Class Initialized
INFO - 2023-05-26 07:09:55 --> URI Class Initialized
INFO - 2023-05-26 07:09:55 --> Router Class Initialized
INFO - 2023-05-26 07:09:55 --> Output Class Initialized
INFO - 2023-05-26 07:09:55 --> Security Class Initialized
DEBUG - 2023-05-26 07:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:09:55 --> Input Class Initialized
INFO - 2023-05-26 07:09:55 --> Language Class Initialized
INFO - 2023-05-26 07:09:55 --> Loader Class Initialized
INFO - 2023-05-26 07:09:55 --> Controller Class Initialized
DEBUG - 2023-05-26 07:09:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:09:55 --> Database Driver Class Initialized
INFO - 2023-05-26 07:09:55 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:09:55 --> Database Driver Class Initialized
INFO - 2023-05-26 07:09:55 --> Model "Login_model" initialized
INFO - 2023-05-26 07:10:03 --> Final output sent to browser
DEBUG - 2023-05-26 07:10:03 --> Total execution time: 8.3007
INFO - 2023-05-26 07:10:36 --> Config Class Initialized
INFO - 2023-05-26 07:10:36 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:10:36 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:10:36 --> Utf8 Class Initialized
INFO - 2023-05-26 07:10:36 --> URI Class Initialized
INFO - 2023-05-26 07:10:36 --> Router Class Initialized
INFO - 2023-05-26 07:10:36 --> Output Class Initialized
INFO - 2023-05-26 07:10:36 --> Security Class Initialized
DEBUG - 2023-05-26 07:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:10:36 --> Input Class Initialized
INFO - 2023-05-26 07:10:36 --> Language Class Initialized
INFO - 2023-05-26 07:10:36 --> Loader Class Initialized
INFO - 2023-05-26 07:10:36 --> Controller Class Initialized
DEBUG - 2023-05-26 07:10:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:10:36 --> Final output sent to browser
DEBUG - 2023-05-26 07:10:36 --> Total execution time: 0.1332
INFO - 2023-05-26 07:10:36 --> Config Class Initialized
INFO - 2023-05-26 07:10:36 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:10:36 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:10:36 --> Utf8 Class Initialized
INFO - 2023-05-26 07:10:36 --> URI Class Initialized
INFO - 2023-05-26 07:10:36 --> Router Class Initialized
INFO - 2023-05-26 07:10:36 --> Output Class Initialized
INFO - 2023-05-26 07:10:36 --> Security Class Initialized
DEBUG - 2023-05-26 07:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:10:36 --> Input Class Initialized
INFO - 2023-05-26 07:10:36 --> Language Class Initialized
INFO - 2023-05-26 07:10:36 --> Loader Class Initialized
INFO - 2023-05-26 07:10:36 --> Controller Class Initialized
DEBUG - 2023-05-26 07:10:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:10:36 --> Database Driver Class Initialized
INFO - 2023-05-26 07:10:36 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:10:36 --> Final output sent to browser
DEBUG - 2023-05-26 07:10:36 --> Total execution time: 0.2196
INFO - 2023-05-26 07:34:02 --> Config Class Initialized
INFO - 2023-05-26 07:34:02 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:34:02 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:34:02 --> Utf8 Class Initialized
INFO - 2023-05-26 07:34:02 --> URI Class Initialized
INFO - 2023-05-26 07:34:02 --> Router Class Initialized
INFO - 2023-05-26 07:34:02 --> Output Class Initialized
INFO - 2023-05-26 07:34:02 --> Security Class Initialized
DEBUG - 2023-05-26 07:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:34:02 --> Input Class Initialized
INFO - 2023-05-26 07:34:02 --> Language Class Initialized
INFO - 2023-05-26 07:34:02 --> Loader Class Initialized
INFO - 2023-05-26 07:34:03 --> Controller Class Initialized
INFO - 2023-05-26 07:34:03 --> Helper loaded: form_helper
INFO - 2023-05-26 07:34:03 --> Helper loaded: url_helper
DEBUG - 2023-05-26 07:34:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:34:03 --> Model "Change_model" initialized
INFO - 2023-05-26 07:34:03 --> Model "Grafana_model" initialized
INFO - 2023-05-26 07:34:03 --> Final output sent to browser
DEBUG - 2023-05-26 07:34:03 --> Total execution time: 1.0597
INFO - 2023-05-26 07:34:03 --> Config Class Initialized
INFO - 2023-05-26 07:34:03 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:34:03 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:34:03 --> Utf8 Class Initialized
INFO - 2023-05-26 07:34:03 --> URI Class Initialized
INFO - 2023-05-26 07:34:03 --> Router Class Initialized
INFO - 2023-05-26 07:34:03 --> Output Class Initialized
INFO - 2023-05-26 07:34:03 --> Security Class Initialized
DEBUG - 2023-05-26 07:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:34:03 --> Input Class Initialized
INFO - 2023-05-26 07:34:03 --> Language Class Initialized
INFO - 2023-05-26 07:34:03 --> Loader Class Initialized
INFO - 2023-05-26 07:34:03 --> Controller Class Initialized
INFO - 2023-05-26 07:34:03 --> Helper loaded: form_helper
INFO - 2023-05-26 07:34:03 --> Helper loaded: url_helper
DEBUG - 2023-05-26 07:34:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:34:03 --> Final output sent to browser
DEBUG - 2023-05-26 07:34:03 --> Total execution time: 0.2460
INFO - 2023-05-26 07:34:03 --> Config Class Initialized
INFO - 2023-05-26 07:34:03 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:34:03 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:34:03 --> Utf8 Class Initialized
INFO - 2023-05-26 07:34:03 --> URI Class Initialized
INFO - 2023-05-26 07:34:03 --> Router Class Initialized
INFO - 2023-05-26 07:34:03 --> Output Class Initialized
INFO - 2023-05-26 07:34:03 --> Security Class Initialized
DEBUG - 2023-05-26 07:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:34:03 --> Input Class Initialized
INFO - 2023-05-26 07:34:03 --> Language Class Initialized
INFO - 2023-05-26 07:34:03 --> Loader Class Initialized
INFO - 2023-05-26 07:34:03 --> Controller Class Initialized
INFO - 2023-05-26 07:34:03 --> Helper loaded: form_helper
INFO - 2023-05-26 07:34:03 --> Helper loaded: url_helper
DEBUG - 2023-05-26 07:34:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:34:04 --> Database Driver Class Initialized
INFO - 2023-05-26 07:34:04 --> Model "Login_model" initialized
INFO - 2023-05-26 07:34:04 --> Final output sent to browser
DEBUG - 2023-05-26 07:34:04 --> Total execution time: 0.4375
INFO - 2023-05-26 07:34:04 --> Config Class Initialized
INFO - 2023-05-26 07:34:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:34:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:34:04 --> Utf8 Class Initialized
INFO - 2023-05-26 07:34:04 --> URI Class Initialized
INFO - 2023-05-26 07:34:04 --> Router Class Initialized
INFO - 2023-05-26 07:34:04 --> Output Class Initialized
INFO - 2023-05-26 07:34:04 --> Security Class Initialized
DEBUG - 2023-05-26 07:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:34:04 --> Input Class Initialized
INFO - 2023-05-26 07:34:04 --> Language Class Initialized
INFO - 2023-05-26 07:34:04 --> Loader Class Initialized
INFO - 2023-05-26 07:34:04 --> Controller Class Initialized
DEBUG - 2023-05-26 07:34:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:34:04 --> Database Driver Class Initialized
INFO - 2023-05-26 07:34:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:34:04 --> Final output sent to browser
DEBUG - 2023-05-26 07:34:04 --> Total execution time: 0.3088
INFO - 2023-05-26 07:34:04 --> Config Class Initialized
INFO - 2023-05-26 07:34:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:34:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:34:04 --> Utf8 Class Initialized
INFO - 2023-05-26 07:34:04 --> URI Class Initialized
INFO - 2023-05-26 07:34:04 --> Router Class Initialized
INFO - 2023-05-26 07:34:04 --> Output Class Initialized
INFO - 2023-05-26 07:34:04 --> Security Class Initialized
DEBUG - 2023-05-26 07:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:34:04 --> Input Class Initialized
INFO - 2023-05-26 07:34:04 --> Language Class Initialized
INFO - 2023-05-26 07:34:04 --> Loader Class Initialized
INFO - 2023-05-26 07:34:04 --> Controller Class Initialized
DEBUG - 2023-05-26 07:34:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:34:04 --> Database Driver Class Initialized
INFO - 2023-05-26 07:34:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:34:04 --> Final output sent to browser
DEBUG - 2023-05-26 07:34:04 --> Total execution time: 0.2215
INFO - 2023-05-26 07:34:05 --> Config Class Initialized
INFO - 2023-05-26 07:34:05 --> Config Class Initialized
INFO - 2023-05-26 07:34:05 --> Hooks Class Initialized
INFO - 2023-05-26 07:34:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:34:05 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:34:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:34:05 --> Utf8 Class Initialized
INFO - 2023-05-26 07:34:05 --> Utf8 Class Initialized
INFO - 2023-05-26 07:34:05 --> URI Class Initialized
INFO - 2023-05-26 07:34:05 --> URI Class Initialized
INFO - 2023-05-26 07:34:05 --> Router Class Initialized
INFO - 2023-05-26 07:34:05 --> Router Class Initialized
INFO - 2023-05-26 07:34:05 --> Output Class Initialized
INFO - 2023-05-26 07:34:05 --> Output Class Initialized
INFO - 2023-05-26 07:34:05 --> Security Class Initialized
INFO - 2023-05-26 07:34:05 --> Security Class Initialized
DEBUG - 2023-05-26 07:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:34:05 --> Input Class Initialized
INFO - 2023-05-26 07:34:05 --> Input Class Initialized
INFO - 2023-05-26 07:34:05 --> Language Class Initialized
INFO - 2023-05-26 07:34:05 --> Language Class Initialized
INFO - 2023-05-26 07:34:05 --> Loader Class Initialized
INFO - 2023-05-26 07:34:05 --> Loader Class Initialized
INFO - 2023-05-26 07:34:05 --> Controller Class Initialized
INFO - 2023-05-26 07:34:05 --> Controller Class Initialized
DEBUG - 2023-05-26 07:34:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 07:34:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:34:05 --> Database Driver Class Initialized
INFO - 2023-05-26 07:34:05 --> Database Driver Class Initialized
INFO - 2023-05-26 07:34:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:34:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:34:05 --> Final output sent to browser
DEBUG - 2023-05-26 07:34:05 --> Total execution time: 0.2215
INFO - 2023-05-26 07:34:05 --> Database Driver Class Initialized
INFO - 2023-05-26 07:34:05 --> Config Class Initialized
INFO - 2023-05-26 07:34:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:34:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:34:05 --> Utf8 Class Initialized
INFO - 2023-05-26 07:34:05 --> Model "Login_model" initialized
INFO - 2023-05-26 07:34:05 --> URI Class Initialized
INFO - 2023-05-26 07:34:05 --> Router Class Initialized
INFO - 2023-05-26 07:34:05 --> Output Class Initialized
INFO - 2023-05-26 07:34:05 --> Security Class Initialized
DEBUG - 2023-05-26 07:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:34:05 --> Input Class Initialized
INFO - 2023-05-26 07:34:05 --> Language Class Initialized
INFO - 2023-05-26 07:34:05 --> Loader Class Initialized
INFO - 2023-05-26 07:34:05 --> Controller Class Initialized
DEBUG - 2023-05-26 07:34:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:34:05 --> Database Driver Class Initialized
INFO - 2023-05-26 07:34:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:34:05 --> Final output sent to browser
DEBUG - 2023-05-26 07:34:05 --> Total execution time: 0.2575
INFO - 2023-05-26 07:34:05 --> Final output sent to browser
DEBUG - 2023-05-26 07:34:05 --> Total execution time: 0.8050
INFO - 2023-05-26 07:34:05 --> Config Class Initialized
INFO - 2023-05-26 07:34:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:34:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:34:05 --> Utf8 Class Initialized
INFO - 2023-05-26 07:34:05 --> URI Class Initialized
INFO - 2023-05-26 07:34:05 --> Router Class Initialized
INFO - 2023-05-26 07:34:06 --> Output Class Initialized
INFO - 2023-05-26 07:34:06 --> Security Class Initialized
DEBUG - 2023-05-26 07:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:34:06 --> Input Class Initialized
INFO - 2023-05-26 07:34:06 --> Language Class Initialized
INFO - 2023-05-26 07:34:06 --> Loader Class Initialized
INFO - 2023-05-26 07:34:06 --> Controller Class Initialized
DEBUG - 2023-05-26 07:34:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:34:06 --> Database Driver Class Initialized
INFO - 2023-05-26 07:34:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:34:06 --> Database Driver Class Initialized
INFO - 2023-05-26 07:34:06 --> Model "Login_model" initialized
INFO - 2023-05-26 07:34:06 --> Final output sent to browser
DEBUG - 2023-05-26 07:34:06 --> Total execution time: 0.9764
INFO - 2023-05-26 07:34:07 --> Config Class Initialized
INFO - 2023-05-26 07:34:07 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:34:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:34:07 --> Utf8 Class Initialized
INFO - 2023-05-26 07:34:07 --> URI Class Initialized
INFO - 2023-05-26 07:34:07 --> Router Class Initialized
INFO - 2023-05-26 07:34:07 --> Output Class Initialized
INFO - 2023-05-26 07:34:07 --> Security Class Initialized
DEBUG - 2023-05-26 07:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:34:07 --> Input Class Initialized
INFO - 2023-05-26 07:34:07 --> Language Class Initialized
INFO - 2023-05-26 07:34:07 --> Loader Class Initialized
INFO - 2023-05-26 07:34:07 --> Controller Class Initialized
DEBUG - 2023-05-26 07:34:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:34:07 --> Database Driver Class Initialized
INFO - 2023-05-26 07:34:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:34:07 --> Final output sent to browser
DEBUG - 2023-05-26 07:34:07 --> Total execution time: 0.2341
INFO - 2023-05-26 07:34:07 --> Config Class Initialized
INFO - 2023-05-26 07:34:07 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:34:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:34:08 --> Utf8 Class Initialized
INFO - 2023-05-26 07:34:08 --> URI Class Initialized
INFO - 2023-05-26 07:34:08 --> Router Class Initialized
INFO - 2023-05-26 07:34:08 --> Output Class Initialized
INFO - 2023-05-26 07:34:08 --> Security Class Initialized
DEBUG - 2023-05-26 07:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:34:08 --> Input Class Initialized
INFO - 2023-05-26 07:34:08 --> Language Class Initialized
INFO - 2023-05-26 07:34:08 --> Loader Class Initialized
INFO - 2023-05-26 07:34:08 --> Controller Class Initialized
DEBUG - 2023-05-26 07:34:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:34:08 --> Database Driver Class Initialized
INFO - 2023-05-26 07:34:08 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:34:08 --> Final output sent to browser
DEBUG - 2023-05-26 07:34:08 --> Total execution time: 0.3771
INFO - 2023-05-26 07:35:28 --> Config Class Initialized
INFO - 2023-05-26 07:35:28 --> Config Class Initialized
INFO - 2023-05-26 07:35:28 --> Hooks Class Initialized
INFO - 2023-05-26 07:35:28 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:35:29 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:35:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:35:29 --> Utf8 Class Initialized
INFO - 2023-05-26 07:35:29 --> Utf8 Class Initialized
INFO - 2023-05-26 07:35:29 --> URI Class Initialized
INFO - 2023-05-26 07:35:29 --> URI Class Initialized
INFO - 2023-05-26 07:35:29 --> Router Class Initialized
INFO - 2023-05-26 07:35:29 --> Router Class Initialized
INFO - 2023-05-26 07:35:29 --> Output Class Initialized
INFO - 2023-05-26 07:35:29 --> Output Class Initialized
INFO - 2023-05-26 07:35:29 --> Security Class Initialized
INFO - 2023-05-26 07:35:29 --> Security Class Initialized
DEBUG - 2023-05-26 07:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:35:29 --> Input Class Initialized
INFO - 2023-05-26 07:35:29 --> Input Class Initialized
INFO - 2023-05-26 07:35:29 --> Language Class Initialized
INFO - 2023-05-26 07:35:29 --> Language Class Initialized
INFO - 2023-05-26 07:35:29 --> Loader Class Initialized
INFO - 2023-05-26 07:35:29 --> Loader Class Initialized
INFO - 2023-05-26 07:35:29 --> Controller Class Initialized
DEBUG - 2023-05-26 07:35:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:35:29 --> Controller Class Initialized
DEBUG - 2023-05-26 07:35:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:35:29 --> Database Driver Class Initialized
INFO - 2023-05-26 07:35:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:35:29 --> Database Driver Class Initialized
INFO - 2023-05-26 07:35:29 --> Final output sent to browser
DEBUG - 2023-05-26 07:35:29 --> Total execution time: 0.4205
INFO - 2023-05-26 07:35:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:35:29 --> Database Driver Class Initialized
INFO - 2023-05-26 07:35:29 --> Config Class Initialized
INFO - 2023-05-26 07:35:29 --> Hooks Class Initialized
INFO - 2023-05-26 07:35:29 --> Model "Login_model" initialized
DEBUG - 2023-05-26 07:35:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:35:29 --> Utf8 Class Initialized
INFO - 2023-05-26 07:35:29 --> URI Class Initialized
INFO - 2023-05-26 07:35:29 --> Router Class Initialized
INFO - 2023-05-26 07:35:29 --> Output Class Initialized
INFO - 2023-05-26 07:35:29 --> Security Class Initialized
DEBUG - 2023-05-26 07:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:35:29 --> Input Class Initialized
INFO - 2023-05-26 07:35:29 --> Language Class Initialized
INFO - 2023-05-26 07:35:29 --> Loader Class Initialized
INFO - 2023-05-26 07:35:29 --> Controller Class Initialized
DEBUG - 2023-05-26 07:35:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:35:29 --> Final output sent to browser
INFO - 2023-05-26 07:35:29 --> Database Driver Class Initialized
DEBUG - 2023-05-26 07:35:29 --> Total execution time: 0.8441
INFO - 2023-05-26 07:35:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:35:29 --> Final output sent to browser
DEBUG - 2023-05-26 07:35:29 --> Total execution time: 0.4185
INFO - 2023-05-26 07:35:29 --> Config Class Initialized
INFO - 2023-05-26 07:35:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:35:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:35:29 --> Utf8 Class Initialized
INFO - 2023-05-26 07:35:29 --> URI Class Initialized
INFO - 2023-05-26 07:35:29 --> Router Class Initialized
INFO - 2023-05-26 07:35:30 --> Output Class Initialized
INFO - 2023-05-26 07:35:30 --> Security Class Initialized
DEBUG - 2023-05-26 07:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:35:30 --> Input Class Initialized
INFO - 2023-05-26 07:35:30 --> Language Class Initialized
INFO - 2023-05-26 07:35:30 --> Loader Class Initialized
INFO - 2023-05-26 07:35:30 --> Controller Class Initialized
DEBUG - 2023-05-26 07:35:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:35:30 --> Database Driver Class Initialized
INFO - 2023-05-26 07:35:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:35:30 --> Database Driver Class Initialized
INFO - 2023-05-26 07:35:30 --> Model "Login_model" initialized
INFO - 2023-05-26 07:35:31 --> Final output sent to browser
DEBUG - 2023-05-26 07:35:31 --> Total execution time: 1.2084
INFO - 2023-05-26 07:35:31 --> Config Class Initialized
INFO - 2023-05-26 07:35:31 --> Config Class Initialized
INFO - 2023-05-26 07:35:31 --> Hooks Class Initialized
INFO - 2023-05-26 07:35:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:35:31 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:35:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:35:31 --> Utf8 Class Initialized
INFO - 2023-05-26 07:35:31 --> Utf8 Class Initialized
INFO - 2023-05-26 07:35:31 --> URI Class Initialized
INFO - 2023-05-26 07:35:31 --> URI Class Initialized
INFO - 2023-05-26 07:35:31 --> Router Class Initialized
INFO - 2023-05-26 07:35:31 --> Router Class Initialized
INFO - 2023-05-26 07:35:31 --> Output Class Initialized
INFO - 2023-05-26 07:35:31 --> Output Class Initialized
INFO - 2023-05-26 07:35:31 --> Security Class Initialized
INFO - 2023-05-26 07:35:31 --> Security Class Initialized
DEBUG - 2023-05-26 07:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:35:31 --> Input Class Initialized
INFO - 2023-05-26 07:35:31 --> Input Class Initialized
INFO - 2023-05-26 07:35:31 --> Language Class Initialized
INFO - 2023-05-26 07:35:31 --> Language Class Initialized
INFO - 2023-05-26 07:35:31 --> Loader Class Initialized
INFO - 2023-05-26 07:35:31 --> Loader Class Initialized
INFO - 2023-05-26 07:35:31 --> Controller Class Initialized
DEBUG - 2023-05-26 07:35:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:35:31 --> Controller Class Initialized
DEBUG - 2023-05-26 07:35:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:35:31 --> Final output sent to browser
DEBUG - 2023-05-26 07:35:31 --> Total execution time: 0.2105
INFO - 2023-05-26 07:35:31 --> Database Driver Class Initialized
INFO - 2023-05-26 07:35:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:35:31 --> Final output sent to browser
DEBUG - 2023-05-26 07:35:31 --> Total execution time: 0.2760
INFO - 2023-05-26 07:35:31 --> Config Class Initialized
INFO - 2023-05-26 07:35:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:35:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:35:31 --> Utf8 Class Initialized
INFO - 2023-05-26 07:35:31 --> Config Class Initialized
INFO - 2023-05-26 07:35:31 --> Hooks Class Initialized
INFO - 2023-05-26 07:35:31 --> URI Class Initialized
INFO - 2023-05-26 07:35:31 --> Router Class Initialized
DEBUG - 2023-05-26 07:35:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:35:31 --> Utf8 Class Initialized
INFO - 2023-05-26 07:35:31 --> URI Class Initialized
INFO - 2023-05-26 07:35:31 --> Output Class Initialized
INFO - 2023-05-26 07:35:31 --> Security Class Initialized
INFO - 2023-05-26 07:35:31 --> Router Class Initialized
DEBUG - 2023-05-26 07:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:35:31 --> Input Class Initialized
INFO - 2023-05-26 07:35:31 --> Language Class Initialized
INFO - 2023-05-26 07:35:31 --> Output Class Initialized
INFO - 2023-05-26 07:35:31 --> Security Class Initialized
INFO - 2023-05-26 07:35:31 --> Loader Class Initialized
DEBUG - 2023-05-26 07:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:35:31 --> Input Class Initialized
INFO - 2023-05-26 07:35:31 --> Language Class Initialized
INFO - 2023-05-26 07:35:31 --> Controller Class Initialized
DEBUG - 2023-05-26 07:35:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:35:31 --> Loader Class Initialized
INFO - 2023-05-26 07:35:31 --> Database Driver Class Initialized
INFO - 2023-05-26 07:35:31 --> Controller Class Initialized
DEBUG - 2023-05-26 07:35:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:35:31 --> Model "Login_model" initialized
INFO - 2023-05-26 07:35:32 --> Database Driver Class Initialized
INFO - 2023-05-26 07:35:32 --> Database Driver Class Initialized
INFO - 2023-05-26 07:35:32 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:35:32 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:35:32 --> Final output sent to browser
INFO - 2023-05-26 07:35:32 --> Final output sent to browser
DEBUG - 2023-05-26 07:35:32 --> Total execution time: 0.3067
DEBUG - 2023-05-26 07:35:32 --> Total execution time: 0.3586
INFO - 2023-05-26 07:49:04 --> Config Class Initialized
INFO - 2023-05-26 07:49:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:49:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:49:04 --> Utf8 Class Initialized
INFO - 2023-05-26 07:49:04 --> URI Class Initialized
INFO - 2023-05-26 07:49:04 --> Router Class Initialized
INFO - 2023-05-26 07:49:04 --> Output Class Initialized
INFO - 2023-05-26 07:49:04 --> Security Class Initialized
DEBUG - 2023-05-26 07:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:49:04 --> Input Class Initialized
INFO - 2023-05-26 07:49:04 --> Language Class Initialized
INFO - 2023-05-26 07:49:05 --> Loader Class Initialized
INFO - 2023-05-26 07:49:05 --> Controller Class Initialized
DEBUG - 2023-05-26 07:49:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:49:05 --> Database Driver Class Initialized
INFO - 2023-05-26 07:49:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:49:05 --> Final output sent to browser
DEBUG - 2023-05-26 07:49:05 --> Total execution time: 0.7533
INFO - 2023-05-26 07:49:05 --> Config Class Initialized
INFO - 2023-05-26 07:49:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:49:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:49:05 --> Utf8 Class Initialized
INFO - 2023-05-26 07:49:05 --> URI Class Initialized
INFO - 2023-05-26 07:49:05 --> Router Class Initialized
INFO - 2023-05-26 07:49:05 --> Output Class Initialized
INFO - 2023-05-26 07:49:05 --> Security Class Initialized
DEBUG - 2023-05-26 07:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:49:05 --> Input Class Initialized
INFO - 2023-05-26 07:49:05 --> Language Class Initialized
INFO - 2023-05-26 07:49:05 --> Loader Class Initialized
INFO - 2023-05-26 07:49:05 --> Controller Class Initialized
DEBUG - 2023-05-26 07:49:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:49:05 --> Database Driver Class Initialized
INFO - 2023-05-26 07:49:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:49:05 --> Final output sent to browser
DEBUG - 2023-05-26 07:49:05 --> Total execution time: 0.2888
INFO - 2023-05-26 07:56:24 --> Config Class Initialized
INFO - 2023-05-26 07:56:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:56:25 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:56:25 --> Utf8 Class Initialized
INFO - 2023-05-26 07:56:25 --> URI Class Initialized
INFO - 2023-05-26 07:56:25 --> Router Class Initialized
INFO - 2023-05-26 07:56:25 --> Output Class Initialized
INFO - 2023-05-26 07:56:25 --> Security Class Initialized
DEBUG - 2023-05-26 07:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:56:25 --> Input Class Initialized
INFO - 2023-05-26 07:56:25 --> Language Class Initialized
INFO - 2023-05-26 07:56:25 --> Loader Class Initialized
INFO - 2023-05-26 07:56:25 --> Controller Class Initialized
DEBUG - 2023-05-26 07:56:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:56:25 --> Database Driver Class Initialized
INFO - 2023-05-26 07:56:25 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:56:26 --> Final output sent to browser
DEBUG - 2023-05-26 07:56:26 --> Total execution time: 1.0980
INFO - 2023-05-26 07:56:26 --> Config Class Initialized
INFO - 2023-05-26 07:56:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:56:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:56:26 --> Utf8 Class Initialized
INFO - 2023-05-26 07:56:26 --> URI Class Initialized
INFO - 2023-05-26 07:56:26 --> Router Class Initialized
INFO - 2023-05-26 07:56:26 --> Output Class Initialized
INFO - 2023-05-26 07:56:26 --> Security Class Initialized
DEBUG - 2023-05-26 07:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:56:26 --> Input Class Initialized
INFO - 2023-05-26 07:56:26 --> Language Class Initialized
INFO - 2023-05-26 07:56:26 --> Loader Class Initialized
INFO - 2023-05-26 07:56:26 --> Controller Class Initialized
DEBUG - 2023-05-26 07:56:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:56:27 --> Database Driver Class Initialized
INFO - 2023-05-26 07:56:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:56:27 --> Final output sent to browser
DEBUG - 2023-05-26 07:56:27 --> Total execution time: 1.3093
INFO - 2023-05-26 07:58:04 --> Config Class Initialized
INFO - 2023-05-26 07:58:04 --> Config Class Initialized
INFO - 2023-05-26 07:58:04 --> Hooks Class Initialized
INFO - 2023-05-26 07:58:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:58:04 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:58:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:58:04 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:04 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:04 --> URI Class Initialized
INFO - 2023-05-26 07:58:04 --> URI Class Initialized
INFO - 2023-05-26 07:58:04 --> Router Class Initialized
INFO - 2023-05-26 07:58:04 --> Router Class Initialized
INFO - 2023-05-26 07:58:04 --> Output Class Initialized
INFO - 2023-05-26 07:58:04 --> Output Class Initialized
INFO - 2023-05-26 07:58:04 --> Security Class Initialized
INFO - 2023-05-26 07:58:04 --> Security Class Initialized
DEBUG - 2023-05-26 07:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:58:04 --> Input Class Initialized
INFO - 2023-05-26 07:58:04 --> Input Class Initialized
INFO - 2023-05-26 07:58:04 --> Language Class Initialized
INFO - 2023-05-26 07:58:04 --> Language Class Initialized
INFO - 2023-05-26 07:58:04 --> Loader Class Initialized
INFO - 2023-05-26 07:58:04 --> Loader Class Initialized
INFO - 2023-05-26 07:58:04 --> Controller Class Initialized
INFO - 2023-05-26 07:58:04 --> Controller Class Initialized
DEBUG - 2023-05-26 07:58:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 07:58:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:04 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:04 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:04 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:04 --> Total execution time: 0.2617
INFO - 2023-05-26 07:58:04 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:04 --> Total execution time: 0.2978
INFO - 2023-05-26 07:58:04 --> Config Class Initialized
INFO - 2023-05-26 07:58:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:58:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:58:04 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:04 --> Config Class Initialized
INFO - 2023-05-26 07:58:04 --> Hooks Class Initialized
INFO - 2023-05-26 07:58:04 --> URI Class Initialized
INFO - 2023-05-26 07:58:04 --> Router Class Initialized
DEBUG - 2023-05-26 07:58:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:58:04 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:04 --> Output Class Initialized
INFO - 2023-05-26 07:58:04 --> URI Class Initialized
INFO - 2023-05-26 07:58:04 --> Security Class Initialized
INFO - 2023-05-26 07:58:04 --> Router Class Initialized
DEBUG - 2023-05-26 07:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:58:04 --> Input Class Initialized
INFO - 2023-05-26 07:58:04 --> Language Class Initialized
INFO - 2023-05-26 07:58:04 --> Output Class Initialized
INFO - 2023-05-26 07:58:04 --> Security Class Initialized
DEBUG - 2023-05-26 07:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:58:04 --> Input Class Initialized
INFO - 2023-05-26 07:58:04 --> Language Class Initialized
INFO - 2023-05-26 07:58:04 --> Loader Class Initialized
INFO - 2023-05-26 07:58:04 --> Controller Class Initialized
DEBUG - 2023-05-26 07:58:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:04 --> Loader Class Initialized
INFO - 2023-05-26 07:58:04 --> Controller Class Initialized
DEBUG - 2023-05-26 07:58:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:04 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:04 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:04 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:04 --> Total execution time: 0.2890
INFO - 2023-05-26 07:58:04 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:04 --> Total execution time: 0.3033
INFO - 2023-05-26 07:58:06 --> Config Class Initialized
INFO - 2023-05-26 07:58:06 --> Config Class Initialized
INFO - 2023-05-26 07:58:06 --> Config Class Initialized
INFO - 2023-05-26 07:58:06 --> Hooks Class Initialized
INFO - 2023-05-26 07:58:06 --> Hooks Class Initialized
INFO - 2023-05-26 07:58:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:58:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:58:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:58:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:58:06 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:06 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:06 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:06 --> URI Class Initialized
INFO - 2023-05-26 07:58:06 --> URI Class Initialized
INFO - 2023-05-26 07:58:06 --> URI Class Initialized
INFO - 2023-05-26 07:58:06 --> Router Class Initialized
INFO - 2023-05-26 07:58:06 --> Router Class Initialized
INFO - 2023-05-26 07:58:06 --> Router Class Initialized
INFO - 2023-05-26 07:58:06 --> Output Class Initialized
INFO - 2023-05-26 07:58:06 --> Output Class Initialized
INFO - 2023-05-26 07:58:06 --> Output Class Initialized
INFO - 2023-05-26 07:58:06 --> Security Class Initialized
INFO - 2023-05-26 07:58:06 --> Security Class Initialized
INFO - 2023-05-26 07:58:06 --> Security Class Initialized
DEBUG - 2023-05-26 07:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:58:06 --> Input Class Initialized
INFO - 2023-05-26 07:58:06 --> Input Class Initialized
INFO - 2023-05-26 07:58:06 --> Input Class Initialized
INFO - 2023-05-26 07:58:06 --> Language Class Initialized
INFO - 2023-05-26 07:58:06 --> Language Class Initialized
INFO - 2023-05-26 07:58:06 --> Language Class Initialized
INFO - 2023-05-26 07:58:06 --> Loader Class Initialized
INFO - 2023-05-26 07:58:06 --> Loader Class Initialized
INFO - 2023-05-26 07:58:06 --> Controller Class Initialized
INFO - 2023-05-26 07:58:06 --> Controller Class Initialized
DEBUG - 2023-05-26 07:58:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 07:58:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:07 --> Loader Class Initialized
INFO - 2023-05-26 07:58:07 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:07 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:07 --> Controller Class Initialized
DEBUG - 2023-05-26 07:58:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:07 --> Config Class Initialized
INFO - 2023-05-26 07:58:07 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:07 --> Hooks Class Initialized
INFO - 2023-05-26 07:58:07 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:07 --> Total execution time: 0.2156
INFO - 2023-05-26 07:58:07 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:07 --> Total execution time: 0.2232
DEBUG - 2023-05-26 07:58:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:58:07 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:07 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:07 --> Model "Login_model" initialized
INFO - 2023-05-26 07:58:07 --> URI Class Initialized
INFO - 2023-05-26 07:58:07 --> Config Class Initialized
INFO - 2023-05-26 07:58:07 --> Config Class Initialized
INFO - 2023-05-26 07:58:07 --> Hooks Class Initialized
INFO - 2023-05-26 07:58:07 --> Hooks Class Initialized
INFO - 2023-05-26 07:58:07 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:07 --> Total execution time: 0.2925
DEBUG - 2023-05-26 07:58:07 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:58:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:58:07 --> Router Class Initialized
INFO - 2023-05-26 07:58:07 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:07 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:07 --> URI Class Initialized
INFO - 2023-05-26 07:58:07 --> URI Class Initialized
INFO - 2023-05-26 07:58:07 --> Output Class Initialized
INFO - 2023-05-26 07:58:07 --> Router Class Initialized
INFO - 2023-05-26 07:58:07 --> Router Class Initialized
INFO - 2023-05-26 07:58:07 --> Security Class Initialized
INFO - 2023-05-26 07:58:07 --> Output Class Initialized
INFO - 2023-05-26 07:58:07 --> Output Class Initialized
DEBUG - 2023-05-26 07:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:58:07 --> Security Class Initialized
INFO - 2023-05-26 07:58:07 --> Security Class Initialized
INFO - 2023-05-26 07:58:07 --> Input Class Initialized
INFO - 2023-05-26 07:58:07 --> Config Class Initialized
DEBUG - 2023-05-26 07:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:58:07 --> Hooks Class Initialized
INFO - 2023-05-26 07:58:07 --> Input Class Initialized
INFO - 2023-05-26 07:58:07 --> Input Class Initialized
INFO - 2023-05-26 07:58:07 --> Language Class Initialized
INFO - 2023-05-26 07:58:07 --> Language Class Initialized
INFO - 2023-05-26 07:58:07 --> Language Class Initialized
INFO - 2023-05-26 07:58:07 --> Loader Class Initialized
INFO - 2023-05-26 07:58:07 --> Loader Class Initialized
INFO - 2023-05-26 07:58:07 --> Loader Class Initialized
DEBUG - 2023-05-26 07:58:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:58:07 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:07 --> Controller Class Initialized
INFO - 2023-05-26 07:58:07 --> Controller Class Initialized
INFO - 2023-05-26 07:58:07 --> Controller Class Initialized
INFO - 2023-05-26 07:58:07 --> URI Class Initialized
DEBUG - 2023-05-26 07:58:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 07:58:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 07:58:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:07 --> Router Class Initialized
INFO - 2023-05-26 07:58:07 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:07 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:07 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:07 --> Output Class Initialized
INFO - 2023-05-26 07:58:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:07 --> Security Class Initialized
DEBUG - 2023-05-26 07:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:58:07 --> Input Class Initialized
INFO - 2023-05-26 07:58:07 --> Final output sent to browser
INFO - 2023-05-26 07:58:07 --> Final output sent to browser
INFO - 2023-05-26 07:58:07 --> Language Class Initialized
DEBUG - 2023-05-26 07:58:07 --> Total execution time: 0.3355
DEBUG - 2023-05-26 07:58:07 --> Total execution time: 0.2558
INFO - 2023-05-26 07:58:07 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:07 --> Total execution time: 0.2707
INFO - 2023-05-26 07:58:07 --> Loader Class Initialized
INFO - 2023-05-26 07:58:07 --> Controller Class Initialized
DEBUG - 2023-05-26 07:58:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:07 --> Config Class Initialized
INFO - 2023-05-26 07:58:07 --> Hooks Class Initialized
INFO - 2023-05-26 07:58:07 --> Database Driver Class Initialized
DEBUG - 2023-05-26 07:58:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:58:07 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:07 --> URI Class Initialized
INFO - 2023-05-26 07:58:07 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:07 --> Router Class Initialized
INFO - 2023-05-26 07:58:07 --> Output Class Initialized
INFO - 2023-05-26 07:58:07 --> Model "Login_model" initialized
INFO - 2023-05-26 07:58:07 --> Security Class Initialized
DEBUG - 2023-05-26 07:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:58:07 --> Input Class Initialized
INFO - 2023-05-26 07:58:07 --> Language Class Initialized
INFO - 2023-05-26 07:58:07 --> Loader Class Initialized
INFO - 2023-05-26 07:58:07 --> Controller Class Initialized
DEBUG - 2023-05-26 07:58:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:07 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:07 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:07 --> Total execution time: 0.4571
INFO - 2023-05-26 07:58:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:07 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:07 --> Total execution time: 0.2600
INFO - 2023-05-26 07:58:24 --> Config Class Initialized
INFO - 2023-05-26 07:58:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:58:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:58:24 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:24 --> URI Class Initialized
INFO - 2023-05-26 07:58:24 --> Router Class Initialized
INFO - 2023-05-26 07:58:24 --> Output Class Initialized
INFO - 2023-05-26 07:58:24 --> Security Class Initialized
DEBUG - 2023-05-26 07:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:58:24 --> Input Class Initialized
INFO - 2023-05-26 07:58:24 --> Language Class Initialized
INFO - 2023-05-26 07:58:24 --> Loader Class Initialized
INFO - 2023-05-26 07:58:24 --> Controller Class Initialized
DEBUG - 2023-05-26 07:58:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:24 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:24 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:24 --> Total execution time: 0.1789
INFO - 2023-05-26 07:58:24 --> Config Class Initialized
INFO - 2023-05-26 07:58:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:58:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:58:24 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:24 --> URI Class Initialized
INFO - 2023-05-26 07:58:24 --> Router Class Initialized
INFO - 2023-05-26 07:58:24 --> Output Class Initialized
INFO - 2023-05-26 07:58:24 --> Security Class Initialized
DEBUG - 2023-05-26 07:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:58:24 --> Input Class Initialized
INFO - 2023-05-26 07:58:24 --> Language Class Initialized
INFO - 2023-05-26 07:58:24 --> Loader Class Initialized
INFO - 2023-05-26 07:58:24 --> Controller Class Initialized
DEBUG - 2023-05-26 07:58:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:24 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:24 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:24 --> Total execution time: 0.1963
INFO - 2023-05-26 07:58:26 --> Config Class Initialized
INFO - 2023-05-26 07:58:26 --> Config Class Initialized
INFO - 2023-05-26 07:58:26 --> Hooks Class Initialized
INFO - 2023-05-26 07:58:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 07:58:26 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 07:58:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:58:26 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:26 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:26 --> URI Class Initialized
INFO - 2023-05-26 07:58:26 --> URI Class Initialized
INFO - 2023-05-26 07:58:26 --> Router Class Initialized
INFO - 2023-05-26 07:58:26 --> Router Class Initialized
INFO - 2023-05-26 07:58:26 --> Output Class Initialized
INFO - 2023-05-26 07:58:26 --> Output Class Initialized
INFO - 2023-05-26 07:58:26 --> Security Class Initialized
INFO - 2023-05-26 07:58:26 --> Security Class Initialized
DEBUG - 2023-05-26 07:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 07:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:58:26 --> Input Class Initialized
INFO - 2023-05-26 07:58:26 --> Input Class Initialized
INFO - 2023-05-26 07:58:26 --> Language Class Initialized
INFO - 2023-05-26 07:58:26 --> Language Class Initialized
INFO - 2023-05-26 07:58:26 --> Loader Class Initialized
INFO - 2023-05-26 07:58:26 --> Controller Class Initialized
INFO - 2023-05-26 07:58:26 --> Loader Class Initialized
DEBUG - 2023-05-26 07:58:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:26 --> Controller Class Initialized
DEBUG - 2023-05-26 07:58:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:26 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:26 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:26 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:26 --> Total execution time: 0.1735
INFO - 2023-05-26 07:58:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:26 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:26 --> Total execution time: 0.2000
INFO - 2023-05-26 07:58:26 --> Config Class Initialized
INFO - 2023-05-26 07:58:26 --> Hooks Class Initialized
INFO - 2023-05-26 07:58:26 --> Config Class Initialized
DEBUG - 2023-05-26 07:58:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:58:26 --> Hooks Class Initialized
INFO - 2023-05-26 07:58:26 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:26 --> URI Class Initialized
DEBUG - 2023-05-26 07:58:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 07:58:26 --> Router Class Initialized
INFO - 2023-05-26 07:58:26 --> Utf8 Class Initialized
INFO - 2023-05-26 07:58:26 --> URI Class Initialized
INFO - 2023-05-26 07:58:26 --> Output Class Initialized
INFO - 2023-05-26 07:58:26 --> Security Class Initialized
INFO - 2023-05-26 07:58:26 --> Router Class Initialized
DEBUG - 2023-05-26 07:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:58:26 --> Input Class Initialized
INFO - 2023-05-26 07:58:26 --> Output Class Initialized
INFO - 2023-05-26 07:58:26 --> Language Class Initialized
INFO - 2023-05-26 07:58:26 --> Security Class Initialized
DEBUG - 2023-05-26 07:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 07:58:26 --> Loader Class Initialized
INFO - 2023-05-26 07:58:26 --> Input Class Initialized
INFO - 2023-05-26 07:58:26 --> Language Class Initialized
INFO - 2023-05-26 07:58:26 --> Controller Class Initialized
DEBUG - 2023-05-26 07:58:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:26 --> Loader Class Initialized
INFO - 2023-05-26 07:58:26 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:26 --> Controller Class Initialized
DEBUG - 2023-05-26 07:58:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 07:58:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:26 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:26 --> Total execution time: 0.2170
INFO - 2023-05-26 07:58:26 --> Database Driver Class Initialized
INFO - 2023-05-26 07:58:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 07:58:26 --> Final output sent to browser
DEBUG - 2023-05-26 07:58:26 --> Total execution time: 0.2362
INFO - 2023-05-26 08:00:07 --> Config Class Initialized
INFO - 2023-05-26 08:00:07 --> Config Class Initialized
INFO - 2023-05-26 08:00:07 --> Hooks Class Initialized
INFO - 2023-05-26 08:00:07 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:00:07 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 08:00:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:00:07 --> Utf8 Class Initialized
INFO - 2023-05-26 08:00:07 --> Utf8 Class Initialized
INFO - 2023-05-26 08:00:07 --> URI Class Initialized
INFO - 2023-05-26 08:00:07 --> URI Class Initialized
INFO - 2023-05-26 08:00:07 --> Router Class Initialized
INFO - 2023-05-26 08:00:07 --> Router Class Initialized
INFO - 2023-05-26 08:00:07 --> Output Class Initialized
INFO - 2023-05-26 08:00:07 --> Output Class Initialized
INFO - 2023-05-26 08:00:07 --> Security Class Initialized
INFO - 2023-05-26 08:00:07 --> Security Class Initialized
DEBUG - 2023-05-26 08:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 08:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:00:07 --> Input Class Initialized
INFO - 2023-05-26 08:00:07 --> Input Class Initialized
INFO - 2023-05-26 08:00:07 --> Language Class Initialized
INFO - 2023-05-26 08:00:07 --> Language Class Initialized
INFO - 2023-05-26 08:00:07 --> Loader Class Initialized
INFO - 2023-05-26 08:00:07 --> Loader Class Initialized
INFO - 2023-05-26 08:00:07 --> Controller Class Initialized
INFO - 2023-05-26 08:00:07 --> Controller Class Initialized
DEBUG - 2023-05-26 08:00:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 08:00:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:00:07 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:07 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:00:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:00:08 --> Config Class Initialized
INFO - 2023-05-26 08:00:08 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:00:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:00:08 --> Utf8 Class Initialized
INFO - 2023-05-26 08:00:08 --> URI Class Initialized
INFO - 2023-05-26 08:00:08 --> Router Class Initialized
INFO - 2023-05-26 08:00:08 --> Output Class Initialized
INFO - 2023-05-26 08:00:08 --> Security Class Initialized
DEBUG - 2023-05-26 08:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:00:08 --> Input Class Initialized
INFO - 2023-05-26 08:00:08 --> Language Class Initialized
INFO - 2023-05-26 08:00:08 --> Loader Class Initialized
INFO - 2023-05-26 08:00:08 --> Controller Class Initialized
DEBUG - 2023-05-26 08:00:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:00:08 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:09 --> Config Class Initialized
INFO - 2023-05-26 08:00:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:00:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:00:09 --> Utf8 Class Initialized
INFO - 2023-05-26 08:00:09 --> URI Class Initialized
INFO - 2023-05-26 08:00:09 --> Router Class Initialized
INFO - 2023-05-26 08:00:09 --> Output Class Initialized
INFO - 2023-05-26 08:00:09 --> Security Class Initialized
DEBUG - 2023-05-26 08:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:00:09 --> Input Class Initialized
INFO - 2023-05-26 08:00:09 --> Language Class Initialized
INFO - 2023-05-26 08:00:09 --> Loader Class Initialized
INFO - 2023-05-26 08:00:09 --> Controller Class Initialized
DEBUG - 2023-05-26 08:00:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:00:09 --> Final output sent to browser
DEBUG - 2023-05-26 08:00:09 --> Total execution time: 0.1942
INFO - 2023-05-26 08:00:09 --> Config Class Initialized
INFO - 2023-05-26 08:00:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:00:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:00:09 --> Utf8 Class Initialized
INFO - 2023-05-26 08:00:09 --> URI Class Initialized
INFO - 2023-05-26 08:00:09 --> Router Class Initialized
INFO - 2023-05-26 08:00:09 --> Output Class Initialized
INFO - 2023-05-26 08:00:09 --> Security Class Initialized
DEBUG - 2023-05-26 08:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:00:09 --> Input Class Initialized
INFO - 2023-05-26 08:00:09 --> Language Class Initialized
INFO - 2023-05-26 08:00:09 --> Loader Class Initialized
INFO - 2023-05-26 08:00:09 --> Controller Class Initialized
DEBUG - 2023-05-26 08:00:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:00:09 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:10 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:00:10 --> Model "Login_model" initialized
INFO - 2023-05-26 08:00:10 --> Final output sent to browser
DEBUG - 2023-05-26 08:00:10 --> Total execution time: 2.0399
INFO - 2023-05-26 08:00:10 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:10 --> Config Class Initialized
INFO - 2023-05-26 08:00:10 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:00:10 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:00:10 --> Utf8 Class Initialized
INFO - 2023-05-26 08:00:10 --> URI Class Initialized
INFO - 2023-05-26 08:00:10 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:00:10 --> Router Class Initialized
INFO - 2023-05-26 08:00:10 --> Final output sent to browser
DEBUG - 2023-05-26 08:00:10 --> Total execution time: 1.0562
INFO - 2023-05-26 08:00:10 --> Output Class Initialized
INFO - 2023-05-26 08:00:10 --> Security Class Initialized
DEBUG - 2023-05-26 08:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:00:10 --> Input Class Initialized
INFO - 2023-05-26 08:00:10 --> Language Class Initialized
INFO - 2023-05-26 08:00:10 --> Loader Class Initialized
INFO - 2023-05-26 08:00:10 --> Controller Class Initialized
DEBUG - 2023-05-26 08:00:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:00:10 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:10 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:00:10 --> Final output sent to browser
DEBUG - 2023-05-26 08:00:10 --> Total execution time: 0.4133
INFO - 2023-05-26 08:00:10 --> Final output sent to browser
DEBUG - 2023-05-26 08:00:10 --> Total execution time: 3.7070
INFO - 2023-05-26 08:00:10 --> Config Class Initialized
INFO - 2023-05-26 08:00:10 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:00:10 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:00:10 --> Utf8 Class Initialized
INFO - 2023-05-26 08:00:10 --> URI Class Initialized
INFO - 2023-05-26 08:00:10 --> Router Class Initialized
INFO - 2023-05-26 08:00:10 --> Output Class Initialized
INFO - 2023-05-26 08:00:10 --> Security Class Initialized
DEBUG - 2023-05-26 08:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:00:11 --> Input Class Initialized
INFO - 2023-05-26 08:00:11 --> Language Class Initialized
INFO - 2023-05-26 08:00:11 --> Loader Class Initialized
INFO - 2023-05-26 08:00:11 --> Controller Class Initialized
DEBUG - 2023-05-26 08:00:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:00:11 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:11 --> Final output sent to browser
DEBUG - 2023-05-26 08:00:11 --> Total execution time: 4.2391
INFO - 2023-05-26 08:00:11 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:00:11 --> Config Class Initialized
INFO - 2023-05-26 08:00:11 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:00:11 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:00:11 --> Utf8 Class Initialized
INFO - 2023-05-26 08:00:11 --> URI Class Initialized
INFO - 2023-05-26 08:00:11 --> Router Class Initialized
INFO - 2023-05-26 08:00:11 --> Output Class Initialized
INFO - 2023-05-26 08:00:11 --> Security Class Initialized
DEBUG - 2023-05-26 08:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:00:11 --> Input Class Initialized
INFO - 2023-05-26 08:00:11 --> Language Class Initialized
INFO - 2023-05-26 08:00:11 --> Loader Class Initialized
INFO - 2023-05-26 08:00:11 --> Controller Class Initialized
DEBUG - 2023-05-26 08:00:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:00:11 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:11 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:00:11 --> Final output sent to browser
DEBUG - 2023-05-26 08:00:11 --> Total execution time: 0.8905
INFO - 2023-05-26 08:00:11 --> Final output sent to browser
DEBUG - 2023-05-26 08:00:11 --> Total execution time: 0.3950
INFO - 2023-05-26 08:00:13 --> Config Class Initialized
INFO - 2023-05-26 08:00:13 --> Config Class Initialized
INFO - 2023-05-26 08:00:13 --> Hooks Class Initialized
INFO - 2023-05-26 08:00:13 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:00:13 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 08:00:13 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:00:13 --> Utf8 Class Initialized
INFO - 2023-05-26 08:00:13 --> Utf8 Class Initialized
INFO - 2023-05-26 08:00:13 --> URI Class Initialized
INFO - 2023-05-26 08:00:13 --> URI Class Initialized
INFO - 2023-05-26 08:00:13 --> Router Class Initialized
INFO - 2023-05-26 08:00:13 --> Router Class Initialized
INFO - 2023-05-26 08:00:13 --> Output Class Initialized
INFO - 2023-05-26 08:00:13 --> Output Class Initialized
INFO - 2023-05-26 08:00:13 --> Security Class Initialized
INFO - 2023-05-26 08:00:13 --> Security Class Initialized
DEBUG - 2023-05-26 08:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 08:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:00:13 --> Input Class Initialized
INFO - 2023-05-26 08:00:13 --> Input Class Initialized
INFO - 2023-05-26 08:00:13 --> Language Class Initialized
INFO - 2023-05-26 08:00:13 --> Language Class Initialized
INFO - 2023-05-26 08:00:13 --> Loader Class Initialized
INFO - 2023-05-26 08:00:13 --> Loader Class Initialized
INFO - 2023-05-26 08:00:13 --> Controller Class Initialized
INFO - 2023-05-26 08:00:13 --> Controller Class Initialized
DEBUG - 2023-05-26 08:00:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 08:00:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:00:13 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:13 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:13 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:00:13 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:00:13 --> Final output sent to browser
DEBUG - 2023-05-26 08:00:13 --> Total execution time: 0.3923
INFO - 2023-05-26 08:00:13 --> Config Class Initialized
INFO - 2023-05-26 08:00:13 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:00:13 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:00:13 --> Utf8 Class Initialized
INFO - 2023-05-26 08:00:13 --> URI Class Initialized
INFO - 2023-05-26 08:00:13 --> Router Class Initialized
INFO - 2023-05-26 08:00:13 --> Output Class Initialized
INFO - 2023-05-26 08:00:13 --> Security Class Initialized
DEBUG - 2023-05-26 08:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:00:13 --> Input Class Initialized
INFO - 2023-05-26 08:00:13 --> Language Class Initialized
INFO - 2023-05-26 08:00:13 --> Loader Class Initialized
INFO - 2023-05-26 08:00:13 --> Controller Class Initialized
DEBUG - 2023-05-26 08:00:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:00:13 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:13 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:00:13 --> Final output sent to browser
DEBUG - 2023-05-26 08:00:13 --> Total execution time: 0.5498
INFO - 2023-05-26 08:00:14 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:15 --> Model "Login_model" initialized
INFO - 2023-05-26 08:00:21 --> Final output sent to browser
DEBUG - 2023-05-26 08:00:21 --> Total execution time: 8.2920
INFO - 2023-05-26 08:00:21 --> Config Class Initialized
INFO - 2023-05-26 08:00:21 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:00:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:00:21 --> Utf8 Class Initialized
INFO - 2023-05-26 08:00:21 --> URI Class Initialized
INFO - 2023-05-26 08:00:21 --> Router Class Initialized
INFO - 2023-05-26 08:00:21 --> Output Class Initialized
INFO - 2023-05-26 08:00:21 --> Security Class Initialized
DEBUG - 2023-05-26 08:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:00:21 --> Input Class Initialized
INFO - 2023-05-26 08:00:21 --> Language Class Initialized
INFO - 2023-05-26 08:00:21 --> Loader Class Initialized
INFO - 2023-05-26 08:00:21 --> Controller Class Initialized
DEBUG - 2023-05-26 08:00:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:00:21 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:00:21 --> Database Driver Class Initialized
INFO - 2023-05-26 08:00:21 --> Model "Login_model" initialized
INFO - 2023-05-26 08:00:22 --> Final output sent to browser
DEBUG - 2023-05-26 08:00:22 --> Total execution time: 0.8410
INFO - 2023-05-26 08:01:50 --> Config Class Initialized
INFO - 2023-05-26 08:01:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:01:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:01:50 --> Utf8 Class Initialized
INFO - 2023-05-26 08:01:50 --> URI Class Initialized
INFO - 2023-05-26 08:01:50 --> Router Class Initialized
INFO - 2023-05-26 08:01:50 --> Output Class Initialized
INFO - 2023-05-26 08:01:50 --> Security Class Initialized
DEBUG - 2023-05-26 08:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:01:50 --> Input Class Initialized
INFO - 2023-05-26 08:01:50 --> Language Class Initialized
INFO - 2023-05-26 08:01:50 --> Loader Class Initialized
INFO - 2023-05-26 08:01:50 --> Controller Class Initialized
DEBUG - 2023-05-26 08:01:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:01:50 --> Database Driver Class Initialized
INFO - 2023-05-26 08:01:50 --> Model "Login_model" initialized
INFO - 2023-05-26 08:01:50 --> Database Driver Class Initialized
INFO - 2023-05-26 08:01:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:01:50 --> Final output sent to browser
DEBUG - 2023-05-26 08:01:50 --> Total execution time: 0.2730
INFO - 2023-05-26 08:01:50 --> Config Class Initialized
INFO - 2023-05-26 08:01:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:01:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:01:50 --> Utf8 Class Initialized
INFO - 2023-05-26 08:01:50 --> URI Class Initialized
INFO - 2023-05-26 08:01:50 --> Router Class Initialized
INFO - 2023-05-26 08:01:50 --> Output Class Initialized
INFO - 2023-05-26 08:01:50 --> Security Class Initialized
DEBUG - 2023-05-26 08:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:01:50 --> Input Class Initialized
INFO - 2023-05-26 08:01:50 --> Language Class Initialized
INFO - 2023-05-26 08:01:50 --> Loader Class Initialized
INFO - 2023-05-26 08:01:50 --> Controller Class Initialized
DEBUG - 2023-05-26 08:01:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:01:50 --> Database Driver Class Initialized
INFO - 2023-05-26 08:01:50 --> Model "Login_model" initialized
INFO - 2023-05-26 08:01:50 --> Database Driver Class Initialized
INFO - 2023-05-26 08:01:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:01:50 --> Final output sent to browser
DEBUG - 2023-05-26 08:01:50 --> Total execution time: 0.2486
INFO - 2023-05-26 08:01:51 --> Config Class Initialized
INFO - 2023-05-26 08:01:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:01:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:01:51 --> Utf8 Class Initialized
INFO - 2023-05-26 08:01:51 --> URI Class Initialized
INFO - 2023-05-26 08:01:51 --> Router Class Initialized
INFO - 2023-05-26 08:01:51 --> Output Class Initialized
INFO - 2023-05-26 08:01:51 --> Security Class Initialized
DEBUG - 2023-05-26 08:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:01:51 --> Input Class Initialized
INFO - 2023-05-26 08:01:51 --> Language Class Initialized
INFO - 2023-05-26 08:01:51 --> Loader Class Initialized
INFO - 2023-05-26 08:01:51 --> Controller Class Initialized
DEBUG - 2023-05-26 08:01:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:01:51 --> Final output sent to browser
DEBUG - 2023-05-26 08:01:51 --> Total execution time: 0.1519
INFO - 2023-05-26 08:01:51 --> Config Class Initialized
INFO - 2023-05-26 08:01:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:01:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:01:51 --> Utf8 Class Initialized
INFO - 2023-05-26 08:01:51 --> URI Class Initialized
INFO - 2023-05-26 08:01:51 --> Router Class Initialized
INFO - 2023-05-26 08:01:51 --> Output Class Initialized
INFO - 2023-05-26 08:01:51 --> Security Class Initialized
DEBUG - 2023-05-26 08:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:01:51 --> Input Class Initialized
INFO - 2023-05-26 08:01:51 --> Language Class Initialized
INFO - 2023-05-26 08:01:51 --> Loader Class Initialized
INFO - 2023-05-26 08:01:51 --> Controller Class Initialized
DEBUG - 2023-05-26 08:01:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:01:51 --> Database Driver Class Initialized
INFO - 2023-05-26 08:01:51 --> Model "Login_model" initialized
INFO - 2023-05-26 08:01:51 --> Database Driver Class Initialized
INFO - 2023-05-26 08:01:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:01:52 --> Final output sent to browser
DEBUG - 2023-05-26 08:01:52 --> Total execution time: 0.8000
INFO - 2023-05-26 08:01:52 --> Config Class Initialized
INFO - 2023-05-26 08:01:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:01:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:01:52 --> Utf8 Class Initialized
INFO - 2023-05-26 08:01:52 --> URI Class Initialized
INFO - 2023-05-26 08:01:52 --> Router Class Initialized
INFO - 2023-05-26 08:01:52 --> Output Class Initialized
INFO - 2023-05-26 08:01:52 --> Security Class Initialized
DEBUG - 2023-05-26 08:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:01:52 --> Input Class Initialized
INFO - 2023-05-26 08:01:52 --> Language Class Initialized
INFO - 2023-05-26 08:01:52 --> Loader Class Initialized
INFO - 2023-05-26 08:01:52 --> Controller Class Initialized
DEBUG - 2023-05-26 08:01:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:01:52 --> Database Driver Class Initialized
INFO - 2023-05-26 08:01:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:01:52 --> Final output sent to browser
DEBUG - 2023-05-26 08:01:52 --> Total execution time: 0.3692
INFO - 2023-05-26 08:01:52 --> Config Class Initialized
INFO - 2023-05-26 08:01:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:01:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:01:52 --> Utf8 Class Initialized
INFO - 2023-05-26 08:01:52 --> URI Class Initialized
INFO - 2023-05-26 08:01:52 --> Router Class Initialized
INFO - 2023-05-26 08:01:52 --> Output Class Initialized
INFO - 2023-05-26 08:01:52 --> Security Class Initialized
DEBUG - 2023-05-26 08:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:01:52 --> Input Class Initialized
INFO - 2023-05-26 08:01:52 --> Language Class Initialized
INFO - 2023-05-26 08:01:52 --> Loader Class Initialized
INFO - 2023-05-26 08:01:52 --> Controller Class Initialized
DEBUG - 2023-05-26 08:01:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:01:52 --> Database Driver Class Initialized
INFO - 2023-05-26 08:01:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:01:54 --> Final output sent to browser
DEBUG - 2023-05-26 08:01:54 --> Total execution time: 2.0073
INFO - 2023-05-26 08:35:12 --> Config Class Initialized
INFO - 2023-05-26 08:35:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:35:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:35:12 --> Utf8 Class Initialized
INFO - 2023-05-26 08:35:12 --> URI Class Initialized
INFO - 2023-05-26 08:35:12 --> Router Class Initialized
INFO - 2023-05-26 08:35:12 --> Output Class Initialized
INFO - 2023-05-26 08:35:12 --> Security Class Initialized
DEBUG - 2023-05-26 08:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:35:12 --> Input Class Initialized
INFO - 2023-05-26 08:35:12 --> Language Class Initialized
INFO - 2023-05-26 08:35:12 --> Loader Class Initialized
INFO - 2023-05-26 08:35:12 --> Controller Class Initialized
DEBUG - 2023-05-26 08:35:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:35:12 --> Database Driver Class Initialized
INFO - 2023-05-26 08:35:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:35:12 --> Final output sent to browser
DEBUG - 2023-05-26 08:35:12 --> Total execution time: 0.5495
INFO - 2023-05-26 08:35:12 --> Config Class Initialized
INFO - 2023-05-26 08:35:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:35:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:35:12 --> Utf8 Class Initialized
INFO - 2023-05-26 08:35:12 --> URI Class Initialized
INFO - 2023-05-26 08:35:12 --> Router Class Initialized
INFO - 2023-05-26 08:35:12 --> Output Class Initialized
INFO - 2023-05-26 08:35:12 --> Security Class Initialized
DEBUG - 2023-05-26 08:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:35:12 --> Input Class Initialized
INFO - 2023-05-26 08:35:12 --> Language Class Initialized
INFO - 2023-05-26 08:35:12 --> Loader Class Initialized
INFO - 2023-05-26 08:35:12 --> Controller Class Initialized
DEBUG - 2023-05-26 08:35:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:35:13 --> Database Driver Class Initialized
INFO - 2023-05-26 08:35:13 --> Config Class Initialized
INFO - 2023-05-26 08:35:13 --> Config Class Initialized
INFO - 2023-05-26 08:35:13 --> Hooks Class Initialized
INFO - 2023-05-26 08:35:13 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:35:13 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 08:35:13 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:35:13 --> Utf8 Class Initialized
INFO - 2023-05-26 08:35:13 --> Utf8 Class Initialized
INFO - 2023-05-26 08:35:13 --> URI Class Initialized
INFO - 2023-05-26 08:35:13 --> URI Class Initialized
INFO - 2023-05-26 08:35:13 --> Router Class Initialized
INFO - 2023-05-26 08:35:13 --> Router Class Initialized
INFO - 2023-05-26 08:35:13 --> Output Class Initialized
INFO - 2023-05-26 08:35:13 --> Output Class Initialized
INFO - 2023-05-26 08:35:13 --> Security Class Initialized
INFO - 2023-05-26 08:35:13 --> Security Class Initialized
DEBUG - 2023-05-26 08:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 08:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:35:13 --> Input Class Initialized
INFO - 2023-05-26 08:35:13 --> Input Class Initialized
INFO - 2023-05-26 08:35:13 --> Language Class Initialized
INFO - 2023-05-26 08:35:13 --> Language Class Initialized
INFO - 2023-05-26 08:35:13 --> Loader Class Initialized
INFO - 2023-05-26 08:35:13 --> Loader Class Initialized
INFO - 2023-05-26 08:35:13 --> Controller Class Initialized
INFO - 2023-05-26 08:35:13 --> Controller Class Initialized
DEBUG - 2023-05-26 08:35:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 08:35:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:35:13 --> Database Driver Class Initialized
INFO - 2023-05-26 08:35:13 --> Database Driver Class Initialized
INFO - 2023-05-26 08:35:13 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:35:13 --> Final output sent to browser
DEBUG - 2023-05-26 08:35:13 --> Total execution time: 1.2714
INFO - 2023-05-26 08:35:14 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:35:16 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:35:17 --> Final output sent to browser
DEBUG - 2023-05-26 08:35:17 --> Total execution time: 3.8700
INFO - 2023-05-26 08:35:17 --> Config Class Initialized
INFO - 2023-05-26 08:35:17 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:35:17 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:35:17 --> Utf8 Class Initialized
INFO - 2023-05-26 08:35:17 --> URI Class Initialized
INFO - 2023-05-26 08:35:17 --> Router Class Initialized
INFO - 2023-05-26 08:35:17 --> Output Class Initialized
INFO - 2023-05-26 08:35:17 --> Security Class Initialized
DEBUG - 2023-05-26 08:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:35:17 --> Input Class Initialized
INFO - 2023-05-26 08:35:17 --> Language Class Initialized
INFO - 2023-05-26 08:35:17 --> Loader Class Initialized
INFO - 2023-05-26 08:35:17 --> Controller Class Initialized
DEBUG - 2023-05-26 08:35:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:35:17 --> Database Driver Class Initialized
INFO - 2023-05-26 08:35:18 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:35:19 --> Final output sent to browser
DEBUG - 2023-05-26 08:35:19 --> Total execution time: 5.8415
INFO - 2023-05-26 08:35:19 --> Config Class Initialized
INFO - 2023-05-26 08:35:19 --> Final output sent to browser
INFO - 2023-05-26 08:35:19 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:35:19 --> Total execution time: 1.9819
DEBUG - 2023-05-26 08:35:19 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:35:19 --> Utf8 Class Initialized
INFO - 2023-05-26 08:35:19 --> URI Class Initialized
INFO - 2023-05-26 08:35:19 --> Router Class Initialized
INFO - 2023-05-26 08:35:19 --> Output Class Initialized
INFO - 2023-05-26 08:35:19 --> Security Class Initialized
DEBUG - 2023-05-26 08:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:35:19 --> Input Class Initialized
INFO - 2023-05-26 08:35:19 --> Language Class Initialized
INFO - 2023-05-26 08:35:19 --> Loader Class Initialized
INFO - 2023-05-26 08:35:19 --> Controller Class Initialized
DEBUG - 2023-05-26 08:35:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:35:19 --> Database Driver Class Initialized
INFO - 2023-05-26 08:35:19 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:35:19 --> Final output sent to browser
DEBUG - 2023-05-26 08:35:19 --> Total execution time: 0.3323
INFO - 2023-05-26 08:49:55 --> Config Class Initialized
INFO - 2023-05-26 08:49:55 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:49:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:49:55 --> Utf8 Class Initialized
INFO - 2023-05-26 08:49:55 --> URI Class Initialized
INFO - 2023-05-26 08:49:55 --> Router Class Initialized
INFO - 2023-05-26 08:49:55 --> Output Class Initialized
INFO - 2023-05-26 08:49:55 --> Security Class Initialized
DEBUG - 2023-05-26 08:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:49:55 --> Input Class Initialized
INFO - 2023-05-26 08:49:55 --> Language Class Initialized
INFO - 2023-05-26 08:49:55 --> Loader Class Initialized
INFO - 2023-05-26 08:49:55 --> Controller Class Initialized
INFO - 2023-05-26 08:49:55 --> Helper loaded: form_helper
INFO - 2023-05-26 08:49:55 --> Helper loaded: url_helper
DEBUG - 2023-05-26 08:49:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:49:55 --> Model "Change_model" initialized
INFO - 2023-05-26 08:49:55 --> Model "Grafana_model" initialized
INFO - 2023-05-26 08:49:55 --> Final output sent to browser
DEBUG - 2023-05-26 08:49:55 --> Total execution time: 0.3193
INFO - 2023-05-26 08:49:55 --> Config Class Initialized
INFO - 2023-05-26 08:49:55 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:49:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:49:55 --> Utf8 Class Initialized
INFO - 2023-05-26 08:49:55 --> URI Class Initialized
INFO - 2023-05-26 08:49:55 --> Router Class Initialized
INFO - 2023-05-26 08:49:55 --> Output Class Initialized
INFO - 2023-05-26 08:49:55 --> Security Class Initialized
DEBUG - 2023-05-26 08:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:49:55 --> Input Class Initialized
INFO - 2023-05-26 08:49:55 --> Language Class Initialized
INFO - 2023-05-26 08:49:56 --> Loader Class Initialized
INFO - 2023-05-26 08:49:56 --> Controller Class Initialized
INFO - 2023-05-26 08:49:56 --> Helper loaded: form_helper
INFO - 2023-05-26 08:49:56 --> Helper loaded: url_helper
DEBUG - 2023-05-26 08:49:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:49:56 --> Final output sent to browser
DEBUG - 2023-05-26 08:49:56 --> Total execution time: 0.2389
INFO - 2023-05-26 08:49:56 --> Config Class Initialized
INFO - 2023-05-26 08:49:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:49:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:49:56 --> Utf8 Class Initialized
INFO - 2023-05-26 08:49:56 --> URI Class Initialized
INFO - 2023-05-26 08:49:56 --> Router Class Initialized
INFO - 2023-05-26 08:49:56 --> Output Class Initialized
INFO - 2023-05-26 08:49:56 --> Security Class Initialized
DEBUG - 2023-05-26 08:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:49:56 --> Input Class Initialized
INFO - 2023-05-26 08:49:56 --> Language Class Initialized
INFO - 2023-05-26 08:49:56 --> Loader Class Initialized
INFO - 2023-05-26 08:49:56 --> Controller Class Initialized
INFO - 2023-05-26 08:49:56 --> Helper loaded: form_helper
INFO - 2023-05-26 08:49:56 --> Helper loaded: url_helper
DEBUG - 2023-05-26 08:49:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:49:56 --> Database Driver Class Initialized
INFO - 2023-05-26 08:49:56 --> Model "Login_model" initialized
INFO - 2023-05-26 08:49:56 --> Final output sent to browser
DEBUG - 2023-05-26 08:49:56 --> Total execution time: 0.3201
INFO - 2023-05-26 08:49:56 --> Config Class Initialized
INFO - 2023-05-26 08:49:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:49:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:49:56 --> Utf8 Class Initialized
INFO - 2023-05-26 08:49:56 --> URI Class Initialized
INFO - 2023-05-26 08:49:56 --> Router Class Initialized
INFO - 2023-05-26 08:49:56 --> Output Class Initialized
INFO - 2023-05-26 08:49:56 --> Security Class Initialized
DEBUG - 2023-05-26 08:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:49:56 --> Input Class Initialized
INFO - 2023-05-26 08:49:56 --> Language Class Initialized
INFO - 2023-05-26 08:49:56 --> Loader Class Initialized
INFO - 2023-05-26 08:49:56 --> Controller Class Initialized
DEBUG - 2023-05-26 08:49:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:49:56 --> Database Driver Class Initialized
INFO - 2023-05-26 08:49:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:49:56 --> Final output sent to browser
DEBUG - 2023-05-26 08:49:56 --> Total execution time: 0.2351
INFO - 2023-05-26 08:49:56 --> Config Class Initialized
INFO - 2023-05-26 08:49:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:49:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:49:56 --> Utf8 Class Initialized
INFO - 2023-05-26 08:49:56 --> URI Class Initialized
INFO - 2023-05-26 08:49:56 --> Router Class Initialized
INFO - 2023-05-26 08:49:56 --> Output Class Initialized
INFO - 2023-05-26 08:49:56 --> Security Class Initialized
DEBUG - 2023-05-26 08:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:49:56 --> Input Class Initialized
INFO - 2023-05-26 08:49:56 --> Language Class Initialized
INFO - 2023-05-26 08:49:56 --> Loader Class Initialized
INFO - 2023-05-26 08:49:56 --> Controller Class Initialized
DEBUG - 2023-05-26 08:49:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:49:56 --> Database Driver Class Initialized
INFO - 2023-05-26 08:49:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:49:56 --> Final output sent to browser
DEBUG - 2023-05-26 08:49:56 --> Total execution time: 0.2061
INFO - 2023-05-26 08:49:57 --> Config Class Initialized
INFO - 2023-05-26 08:49:57 --> Config Class Initialized
INFO - 2023-05-26 08:49:57 --> Hooks Class Initialized
INFO - 2023-05-26 08:49:57 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 08:49:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:49:57 --> Utf8 Class Initialized
INFO - 2023-05-26 08:49:57 --> Utf8 Class Initialized
INFO - 2023-05-26 08:49:57 --> URI Class Initialized
INFO - 2023-05-26 08:49:57 --> URI Class Initialized
INFO - 2023-05-26 08:49:57 --> Router Class Initialized
INFO - 2023-05-26 08:49:57 --> Router Class Initialized
INFO - 2023-05-26 08:49:57 --> Output Class Initialized
INFO - 2023-05-26 08:49:57 --> Output Class Initialized
INFO - 2023-05-26 08:49:57 --> Security Class Initialized
INFO - 2023-05-26 08:49:57 --> Security Class Initialized
DEBUG - 2023-05-26 08:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:49:57 --> Input Class Initialized
INFO - 2023-05-26 08:49:57 --> Input Class Initialized
INFO - 2023-05-26 08:49:57 --> Language Class Initialized
INFO - 2023-05-26 08:49:57 --> Language Class Initialized
INFO - 2023-05-26 08:49:57 --> Loader Class Initialized
INFO - 2023-05-26 08:49:57 --> Loader Class Initialized
INFO - 2023-05-26 08:49:57 --> Controller Class Initialized
DEBUG - 2023-05-26 08:49:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:49:57 --> Controller Class Initialized
DEBUG - 2023-05-26 08:49:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:49:57 --> Database Driver Class Initialized
INFO - 2023-05-26 08:49:57 --> Database Driver Class Initialized
INFO - 2023-05-26 08:49:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:49:57 --> Final output sent to browser
DEBUG - 2023-05-26 08:49:57 --> Total execution time: 0.2168
INFO - 2023-05-26 08:49:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:49:57 --> Database Driver Class Initialized
INFO - 2023-05-26 08:49:57 --> Model "Login_model" initialized
INFO - 2023-05-26 08:49:57 --> Config Class Initialized
INFO - 2023-05-26 08:49:57 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:49:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:49:57 --> Utf8 Class Initialized
INFO - 2023-05-26 08:49:57 --> URI Class Initialized
INFO - 2023-05-26 08:49:57 --> Router Class Initialized
INFO - 2023-05-26 08:49:57 --> Output Class Initialized
INFO - 2023-05-26 08:49:57 --> Security Class Initialized
DEBUG - 2023-05-26 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:49:57 --> Input Class Initialized
INFO - 2023-05-26 08:49:57 --> Language Class Initialized
INFO - 2023-05-26 08:49:57 --> Loader Class Initialized
INFO - 2023-05-26 08:49:57 --> Controller Class Initialized
DEBUG - 2023-05-26 08:49:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:49:57 --> Final output sent to browser
DEBUG - 2023-05-26 08:49:57 --> Total execution time: 0.4448
INFO - 2023-05-26 08:49:57 --> Database Driver Class Initialized
INFO - 2023-05-26 08:49:57 --> Config Class Initialized
INFO - 2023-05-26 08:49:57 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:49:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:49:57 --> Utf8 Class Initialized
INFO - 2023-05-26 08:49:57 --> URI Class Initialized
INFO - 2023-05-26 08:49:57 --> Router Class Initialized
INFO - 2023-05-26 08:49:57 --> Output Class Initialized
INFO - 2023-05-26 08:49:57 --> Security Class Initialized
DEBUG - 2023-05-26 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:49:57 --> Input Class Initialized
INFO - 2023-05-26 08:49:57 --> Language Class Initialized
INFO - 2023-05-26 08:49:57 --> Loader Class Initialized
INFO - 2023-05-26 08:49:57 --> Controller Class Initialized
DEBUG - 2023-05-26 08:49:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:49:57 --> Database Driver Class Initialized
INFO - 2023-05-26 08:49:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:49:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:49:57 --> Final output sent to browser
DEBUG - 2023-05-26 08:49:57 --> Total execution time: 0.4799
INFO - 2023-05-26 08:49:57 --> Database Driver Class Initialized
INFO - 2023-05-26 08:49:57 --> Model "Login_model" initialized
INFO - 2023-05-26 08:49:58 --> Final output sent to browser
DEBUG - 2023-05-26 08:49:58 --> Total execution time: 0.5878
INFO - 2023-05-26 08:50:37 --> Config Class Initialized
INFO - 2023-05-26 08:50:37 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:50:37 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:50:37 --> Utf8 Class Initialized
INFO - 2023-05-26 08:50:37 --> URI Class Initialized
INFO - 2023-05-26 08:50:37 --> Router Class Initialized
INFO - 2023-05-26 08:50:37 --> Output Class Initialized
INFO - 2023-05-26 08:50:37 --> Security Class Initialized
DEBUG - 2023-05-26 08:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:50:37 --> Input Class Initialized
INFO - 2023-05-26 08:50:37 --> Language Class Initialized
INFO - 2023-05-26 08:50:37 --> Loader Class Initialized
INFO - 2023-05-26 08:50:37 --> Controller Class Initialized
DEBUG - 2023-05-26 08:50:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:50:37 --> Database Driver Class Initialized
INFO - 2023-05-26 08:50:38 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:50:39 --> Final output sent to browser
DEBUG - 2023-05-26 08:50:39 --> Total execution time: 2.1626
INFO - 2023-05-26 08:50:39 --> Config Class Initialized
INFO - 2023-05-26 08:50:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:50:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:50:39 --> Utf8 Class Initialized
INFO - 2023-05-26 08:50:39 --> URI Class Initialized
INFO - 2023-05-26 08:50:39 --> Router Class Initialized
INFO - 2023-05-26 08:50:39 --> Output Class Initialized
INFO - 2023-05-26 08:50:39 --> Security Class Initialized
DEBUG - 2023-05-26 08:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:50:39 --> Input Class Initialized
INFO - 2023-05-26 08:50:39 --> Language Class Initialized
INFO - 2023-05-26 08:50:39 --> Loader Class Initialized
INFO - 2023-05-26 08:50:39 --> Controller Class Initialized
DEBUG - 2023-05-26 08:50:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:50:39 --> Database Driver Class Initialized
INFO - 2023-05-26 08:50:40 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:50:40 --> Final output sent to browser
DEBUG - 2023-05-26 08:50:40 --> Total execution time: 1.1049
INFO - 2023-05-26 08:50:45 --> Config Class Initialized
INFO - 2023-05-26 08:50:45 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:50:45 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:50:45 --> Utf8 Class Initialized
INFO - 2023-05-26 08:50:45 --> URI Class Initialized
INFO - 2023-05-26 08:50:45 --> Router Class Initialized
INFO - 2023-05-26 08:50:45 --> Output Class Initialized
INFO - 2023-05-26 08:50:45 --> Security Class Initialized
DEBUG - 2023-05-26 08:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:50:45 --> Input Class Initialized
INFO - 2023-05-26 08:50:45 --> Language Class Initialized
INFO - 2023-05-26 08:50:45 --> Loader Class Initialized
INFO - 2023-05-26 08:50:45 --> Controller Class Initialized
DEBUG - 2023-05-26 08:50:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:50:45 --> Database Driver Class Initialized
INFO - 2023-05-26 08:50:49 --> Config Class Initialized
INFO - 2023-05-26 08:50:49 --> Config Class Initialized
INFO - 2023-05-26 08:50:49 --> Hooks Class Initialized
INFO - 2023-05-26 08:50:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:50:49 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 08:50:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:50:49 --> Utf8 Class Initialized
INFO - 2023-05-26 08:50:49 --> Utf8 Class Initialized
INFO - 2023-05-26 08:50:49 --> URI Class Initialized
INFO - 2023-05-26 08:50:49 --> URI Class Initialized
INFO - 2023-05-26 08:50:49 --> Router Class Initialized
INFO - 2023-05-26 08:50:49 --> Router Class Initialized
INFO - 2023-05-26 08:50:49 --> Output Class Initialized
INFO - 2023-05-26 08:50:49 --> Output Class Initialized
INFO - 2023-05-26 08:50:49 --> Security Class Initialized
INFO - 2023-05-26 08:50:49 --> Security Class Initialized
DEBUG - 2023-05-26 08:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 08:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:50:49 --> Input Class Initialized
INFO - 2023-05-26 08:50:49 --> Input Class Initialized
INFO - 2023-05-26 08:50:49 --> Language Class Initialized
INFO - 2023-05-26 08:50:49 --> Language Class Initialized
INFO - 2023-05-26 08:50:49 --> Loader Class Initialized
INFO - 2023-05-26 08:50:49 --> Loader Class Initialized
INFO - 2023-05-26 08:50:49 --> Controller Class Initialized
INFO - 2023-05-26 08:50:49 --> Controller Class Initialized
DEBUG - 2023-05-26 08:50:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 08:50:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:50:49 --> Database Driver Class Initialized
INFO - 2023-05-26 08:50:49 --> Database Driver Class Initialized
INFO - 2023-05-26 08:50:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:50:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:50:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:50:53 --> Final output sent to browser
DEBUG - 2023-05-26 08:50:53 --> Total execution time: 8.2581
INFO - 2023-05-26 08:50:53 --> Config Class Initialized
INFO - 2023-05-26 08:50:53 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:50:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:50:53 --> Utf8 Class Initialized
INFO - 2023-05-26 08:50:53 --> URI Class Initialized
INFO - 2023-05-26 08:50:53 --> Router Class Initialized
INFO - 2023-05-26 08:50:53 --> Output Class Initialized
INFO - 2023-05-26 08:50:53 --> Security Class Initialized
DEBUG - 2023-05-26 08:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:50:53 --> Input Class Initialized
INFO - 2023-05-26 08:50:53 --> Language Class Initialized
INFO - 2023-05-26 08:50:53 --> Loader Class Initialized
INFO - 2023-05-26 08:50:53 --> Controller Class Initialized
DEBUG - 2023-05-26 08:50:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:50:53 --> Database Driver Class Initialized
INFO - 2023-05-26 08:50:58 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:50:58 --> Final output sent to browser
DEBUG - 2023-05-26 08:50:58 --> Total execution time: 9.4026
INFO - 2023-05-26 08:50:58 --> Final output sent to browser
DEBUG - 2023-05-26 08:50:58 --> Total execution time: 5.3862
INFO - 2023-05-26 08:50:59 --> Config Class Initialized
INFO - 2023-05-26 08:50:59 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:51:00 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:51:00 --> Utf8 Class Initialized
INFO - 2023-05-26 08:51:00 --> Final output sent to browser
DEBUG - 2023-05-26 08:51:00 --> Total execution time: 10.8333
INFO - 2023-05-26 08:51:00 --> URI Class Initialized
INFO - 2023-05-26 08:51:00 --> Router Class Initialized
INFO - 2023-05-26 08:51:00 --> Output Class Initialized
INFO - 2023-05-26 08:51:01 --> Security Class Initialized
INFO - 2023-05-26 08:51:01 --> Config Class Initialized
INFO - 2023-05-26 08:51:01 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:51:01 --> Input Class Initialized
INFO - 2023-05-26 08:51:01 --> Language Class Initialized
DEBUG - 2023-05-26 08:51:01 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:51:01 --> Utf8 Class Initialized
INFO - 2023-05-26 08:51:01 --> URI Class Initialized
INFO - 2023-05-26 08:51:01 --> Loader Class Initialized
INFO - 2023-05-26 08:51:01 --> Router Class Initialized
INFO - 2023-05-26 08:51:01 --> Controller Class Initialized
INFO - 2023-05-26 08:51:01 --> Output Class Initialized
DEBUG - 2023-05-26 08:51:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:51:01 --> Security Class Initialized
DEBUG - 2023-05-26 08:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:51:01 --> Input Class Initialized
INFO - 2023-05-26 08:51:01 --> Language Class Initialized
INFO - 2023-05-26 08:51:01 --> Database Driver Class Initialized
INFO - 2023-05-26 08:51:01 --> Loader Class Initialized
INFO - 2023-05-26 08:51:01 --> Controller Class Initialized
DEBUG - 2023-05-26 08:51:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:51:01 --> Database Driver Class Initialized
INFO - 2023-05-26 08:51:02 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:51:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:51:05 --> Final output sent to browser
DEBUG - 2023-05-26 08:51:05 --> Total execution time: 5.8660
INFO - 2023-05-26 08:51:07 --> Final output sent to browser
DEBUG - 2023-05-26 08:51:07 --> Total execution time: 6.3952
INFO - 2023-05-26 08:52:27 --> Config Class Initialized
INFO - 2023-05-26 08:52:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:52:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:52:27 --> Utf8 Class Initialized
INFO - 2023-05-26 08:52:27 --> URI Class Initialized
INFO - 2023-05-26 08:52:27 --> Router Class Initialized
INFO - 2023-05-26 08:52:27 --> Output Class Initialized
INFO - 2023-05-26 08:52:27 --> Security Class Initialized
DEBUG - 2023-05-26 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:52:27 --> Input Class Initialized
INFO - 2023-05-26 08:52:27 --> Language Class Initialized
INFO - 2023-05-26 08:52:27 --> Loader Class Initialized
INFO - 2023-05-26 08:52:27 --> Controller Class Initialized
DEBUG - 2023-05-26 08:52:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:52:27 --> Database Driver Class Initialized
INFO - 2023-05-26 08:52:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:52:27 --> Final output sent to browser
DEBUG - 2023-05-26 08:52:27 --> Total execution time: 0.2603
INFO - 2023-05-26 08:52:27 --> Config Class Initialized
INFO - 2023-05-26 08:52:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:52:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:52:27 --> Utf8 Class Initialized
INFO - 2023-05-26 08:52:27 --> URI Class Initialized
INFO - 2023-05-26 08:52:27 --> Router Class Initialized
INFO - 2023-05-26 08:52:27 --> Output Class Initialized
INFO - 2023-05-26 08:52:27 --> Security Class Initialized
DEBUG - 2023-05-26 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:52:27 --> Input Class Initialized
INFO - 2023-05-26 08:52:27 --> Language Class Initialized
INFO - 2023-05-26 08:52:27 --> Loader Class Initialized
INFO - 2023-05-26 08:52:27 --> Controller Class Initialized
DEBUG - 2023-05-26 08:52:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:52:27 --> Database Driver Class Initialized
INFO - 2023-05-26 08:52:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:52:27 --> Final output sent to browser
DEBUG - 2023-05-26 08:52:27 --> Total execution time: 0.3015
INFO - 2023-05-26 08:58:52 --> Config Class Initialized
INFO - 2023-05-26 08:58:52 --> Config Class Initialized
INFO - 2023-05-26 08:58:52 --> Hooks Class Initialized
INFO - 2023-05-26 08:58:52 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 08:58:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:58:52 --> Utf8 Class Initialized
INFO - 2023-05-26 08:58:52 --> Utf8 Class Initialized
INFO - 2023-05-26 08:58:52 --> URI Class Initialized
INFO - 2023-05-26 08:58:52 --> URI Class Initialized
INFO - 2023-05-26 08:58:52 --> Router Class Initialized
INFO - 2023-05-26 08:58:52 --> Router Class Initialized
INFO - 2023-05-26 08:58:52 --> Output Class Initialized
INFO - 2023-05-26 08:58:52 --> Output Class Initialized
INFO - 2023-05-26 08:58:52 --> Security Class Initialized
INFO - 2023-05-26 08:58:52 --> Security Class Initialized
DEBUG - 2023-05-26 08:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 08:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:58:52 --> Input Class Initialized
INFO - 2023-05-26 08:58:52 --> Input Class Initialized
INFO - 2023-05-26 08:58:52 --> Language Class Initialized
INFO - 2023-05-26 08:58:52 --> Language Class Initialized
INFO - 2023-05-26 08:58:52 --> Loader Class Initialized
INFO - 2023-05-26 08:58:52 --> Loader Class Initialized
INFO - 2023-05-26 08:58:52 --> Controller Class Initialized
DEBUG - 2023-05-26 08:58:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:58:52 --> Controller Class Initialized
INFO - 2023-05-26 08:58:52 --> Final output sent to browser
DEBUG - 2023-05-26 08:58:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 08:58:52 --> Total execution time: 0.1201
INFO - 2023-05-26 08:58:52 --> Database Driver Class Initialized
INFO - 2023-05-26 08:58:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:58:52 --> Config Class Initialized
INFO - 2023-05-26 08:58:52 --> Hooks Class Initialized
INFO - 2023-05-26 08:58:52 --> Final output sent to browser
DEBUG - 2023-05-26 08:58:52 --> Total execution time: 0.1854
DEBUG - 2023-05-26 08:58:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:58:52 --> Utf8 Class Initialized
INFO - 2023-05-26 08:58:52 --> URI Class Initialized
INFO - 2023-05-26 08:58:52 --> Config Class Initialized
INFO - 2023-05-26 08:58:52 --> Router Class Initialized
INFO - 2023-05-26 08:58:52 --> Hooks Class Initialized
INFO - 2023-05-26 08:58:52 --> Output Class Initialized
DEBUG - 2023-05-26 08:58:52 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:58:52 --> Security Class Initialized
INFO - 2023-05-26 08:58:52 --> Utf8 Class Initialized
INFO - 2023-05-26 08:58:52 --> URI Class Initialized
DEBUG - 2023-05-26 08:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:58:52 --> Input Class Initialized
INFO - 2023-05-26 08:58:52 --> Language Class Initialized
INFO - 2023-05-26 08:58:52 --> Router Class Initialized
INFO - 2023-05-26 08:58:52 --> Output Class Initialized
INFO - 2023-05-26 08:58:52 --> Loader Class Initialized
INFO - 2023-05-26 08:58:52 --> Security Class Initialized
DEBUG - 2023-05-26 08:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:58:52 --> Input Class Initialized
INFO - 2023-05-26 08:58:52 --> Controller Class Initialized
INFO - 2023-05-26 08:58:52 --> Language Class Initialized
DEBUG - 2023-05-26 08:58:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:58:52 --> Loader Class Initialized
INFO - 2023-05-26 08:58:52 --> Controller Class Initialized
INFO - 2023-05-26 08:58:52 --> Database Driver Class Initialized
DEBUG - 2023-05-26 08:58:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:58:52 --> Model "Login_model" initialized
INFO - 2023-05-26 08:58:52 --> Database Driver Class Initialized
INFO - 2023-05-26 08:58:52 --> Database Driver Class Initialized
INFO - 2023-05-26 08:58:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:58:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:58:52 --> Final output sent to browser
INFO - 2023-05-26 08:58:52 --> Final output sent to browser
DEBUG - 2023-05-26 08:58:52 --> Total execution time: 0.3179
DEBUG - 2023-05-26 08:58:52 --> Total execution time: 0.2566
INFO - 2023-05-26 08:58:55 --> Config Class Initialized
INFO - 2023-05-26 08:58:55 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:58:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:58:55 --> Utf8 Class Initialized
INFO - 2023-05-26 08:58:55 --> URI Class Initialized
INFO - 2023-05-26 08:58:55 --> Router Class Initialized
INFO - 2023-05-26 08:58:55 --> Output Class Initialized
INFO - 2023-05-26 08:58:55 --> Security Class Initialized
DEBUG - 2023-05-26 08:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:58:55 --> Input Class Initialized
INFO - 2023-05-26 08:58:55 --> Language Class Initialized
INFO - 2023-05-26 08:58:55 --> Loader Class Initialized
INFO - 2023-05-26 08:58:55 --> Controller Class Initialized
DEBUG - 2023-05-26 08:58:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:58:55 --> Database Driver Class Initialized
INFO - 2023-05-26 08:58:55 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:58:55 --> Final output sent to browser
DEBUG - 2023-05-26 08:58:55 --> Total execution time: 0.1979
INFO - 2023-05-26 08:58:55 --> Config Class Initialized
INFO - 2023-05-26 08:58:55 --> Hooks Class Initialized
DEBUG - 2023-05-26 08:58:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 08:58:55 --> Utf8 Class Initialized
INFO - 2023-05-26 08:58:55 --> URI Class Initialized
INFO - 2023-05-26 08:58:55 --> Router Class Initialized
INFO - 2023-05-26 08:58:55 --> Output Class Initialized
INFO - 2023-05-26 08:58:55 --> Security Class Initialized
DEBUG - 2023-05-26 08:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 08:58:55 --> Input Class Initialized
INFO - 2023-05-26 08:58:55 --> Language Class Initialized
INFO - 2023-05-26 08:58:55 --> Loader Class Initialized
INFO - 2023-05-26 08:58:55 --> Controller Class Initialized
DEBUG - 2023-05-26 08:58:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 08:58:55 --> Database Driver Class Initialized
INFO - 2023-05-26 08:58:55 --> Model "Cluster_model" initialized
INFO - 2023-05-26 08:58:55 --> Final output sent to browser
DEBUG - 2023-05-26 08:58:55 --> Total execution time: 0.2141
INFO - 2023-05-26 09:03:20 --> Config Class Initialized
INFO - 2023-05-26 09:03:20 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:03:20 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:03:20 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:20 --> URI Class Initialized
INFO - 2023-05-26 09:03:20 --> Router Class Initialized
INFO - 2023-05-26 09:03:20 --> Output Class Initialized
INFO - 2023-05-26 09:03:20 --> Security Class Initialized
DEBUG - 2023-05-26 09:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:03:20 --> Input Class Initialized
INFO - 2023-05-26 09:03:21 --> Language Class Initialized
INFO - 2023-05-26 09:03:21 --> Loader Class Initialized
INFO - 2023-05-26 09:03:21 --> Controller Class Initialized
DEBUG - 2023-05-26 09:03:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:03:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:21 --> Model "Login_model" initialized
INFO - 2023-05-26 09:03:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:03:21 --> Final output sent to browser
DEBUG - 2023-05-26 09:03:21 --> Total execution time: 0.7222
INFO - 2023-05-26 09:03:21 --> Config Class Initialized
INFO - 2023-05-26 09:03:21 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:03:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:03:21 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:21 --> URI Class Initialized
INFO - 2023-05-26 09:03:21 --> Router Class Initialized
INFO - 2023-05-26 09:03:21 --> Output Class Initialized
INFO - 2023-05-26 09:03:21 --> Security Class Initialized
DEBUG - 2023-05-26 09:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:03:21 --> Input Class Initialized
INFO - 2023-05-26 09:03:21 --> Language Class Initialized
INFO - 2023-05-26 09:03:21 --> Loader Class Initialized
INFO - 2023-05-26 09:03:21 --> Controller Class Initialized
DEBUG - 2023-05-26 09:03:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:03:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:21 --> Model "Login_model" initialized
INFO - 2023-05-26 09:03:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:03:21 --> Final output sent to browser
DEBUG - 2023-05-26 09:03:21 --> Total execution time: 0.2869
INFO - 2023-05-26 09:03:22 --> Config Class Initialized
INFO - 2023-05-26 09:03:22 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:03:22 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:03:22 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:22 --> URI Class Initialized
INFO - 2023-05-26 09:03:22 --> Router Class Initialized
INFO - 2023-05-26 09:03:22 --> Output Class Initialized
INFO - 2023-05-26 09:03:22 --> Security Class Initialized
DEBUG - 2023-05-26 09:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:03:22 --> Input Class Initialized
INFO - 2023-05-26 09:03:22 --> Language Class Initialized
INFO - 2023-05-26 09:03:22 --> Loader Class Initialized
INFO - 2023-05-26 09:03:22 --> Controller Class Initialized
DEBUG - 2023-05-26 09:03:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:03:22 --> Final output sent to browser
DEBUG - 2023-05-26 09:03:22 --> Total execution time: 0.1944
INFO - 2023-05-26 09:03:22 --> Config Class Initialized
INFO - 2023-05-26 09:03:22 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:03:22 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:03:22 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:22 --> URI Class Initialized
INFO - 2023-05-26 09:03:22 --> Router Class Initialized
INFO - 2023-05-26 09:03:22 --> Output Class Initialized
INFO - 2023-05-26 09:03:22 --> Security Class Initialized
DEBUG - 2023-05-26 09:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:03:22 --> Input Class Initialized
INFO - 2023-05-26 09:03:22 --> Language Class Initialized
INFO - 2023-05-26 09:03:22 --> Loader Class Initialized
INFO - 2023-05-26 09:03:22 --> Controller Class Initialized
DEBUG - 2023-05-26 09:03:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:03:22 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:22 --> Model "Login_model" initialized
INFO - 2023-05-26 09:03:22 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:22 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:03:22 --> Final output sent to browser
DEBUG - 2023-05-26 09:03:22 --> Total execution time: 0.2692
INFO - 2023-05-26 09:03:42 --> Config Class Initialized
INFO - 2023-05-26 09:03:42 --> Config Class Initialized
INFO - 2023-05-26 09:03:42 --> Hooks Class Initialized
INFO - 2023-05-26 09:03:42 --> Hooks Class Initialized
INFO - 2023-05-26 09:03:42 --> Config Class Initialized
DEBUG - 2023-05-26 09:03:42 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:03:42 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:03:42 --> Hooks Class Initialized
INFO - 2023-05-26 09:03:42 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:42 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:42 --> URI Class Initialized
INFO - 2023-05-26 09:03:42 --> URI Class Initialized
INFO - 2023-05-26 09:03:42 --> Router Class Initialized
INFO - 2023-05-26 09:03:42 --> Router Class Initialized
DEBUG - 2023-05-26 09:03:42 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:03:42 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:42 --> Output Class Initialized
INFO - 2023-05-26 09:03:42 --> Output Class Initialized
INFO - 2023-05-26 09:03:42 --> Security Class Initialized
INFO - 2023-05-26 09:03:42 --> URI Class Initialized
INFO - 2023-05-26 09:03:42 --> Security Class Initialized
DEBUG - 2023-05-26 09:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:03:42 --> Input Class Initialized
INFO - 2023-05-26 09:03:42 --> Input Class Initialized
INFO - 2023-05-26 09:03:42 --> Language Class Initialized
INFO - 2023-05-26 09:03:42 --> Language Class Initialized
INFO - 2023-05-26 09:03:42 --> Router Class Initialized
INFO - 2023-05-26 09:03:42 --> Output Class Initialized
INFO - 2023-05-26 09:03:42 --> Loader Class Initialized
INFO - 2023-05-26 09:03:42 --> Loader Class Initialized
INFO - 2023-05-26 09:03:42 --> Security Class Initialized
INFO - 2023-05-26 09:03:42 --> Controller Class Initialized
INFO - 2023-05-26 09:03:42 --> Controller Class Initialized
DEBUG - 2023-05-26 09:03:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:03:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:03:42 --> Input Class Initialized
INFO - 2023-05-26 09:03:42 --> Language Class Initialized
INFO - 2023-05-26 09:03:42 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:42 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:42 --> Loader Class Initialized
INFO - 2023-05-26 09:03:42 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:03:42 --> Controller Class Initialized
DEBUG - 2023-05-26 09:03:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:03:42 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:42 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:42 --> Final output sent to browser
DEBUG - 2023-05-26 09:03:42 --> Total execution time: 0.1977
INFO - 2023-05-26 09:03:42 --> Model "Login_model" initialized
INFO - 2023-05-26 09:03:42 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:03:42 --> Final output sent to browser
DEBUG - 2023-05-26 09:03:42 --> Total execution time: 0.2250
INFO - 2023-05-26 09:03:42 --> Config Class Initialized
INFO - 2023-05-26 09:03:42 --> Hooks Class Initialized
INFO - 2023-05-26 09:03:42 --> Final output sent to browser
DEBUG - 2023-05-26 09:03:42 --> Total execution time: 0.2680
INFO - 2023-05-26 09:03:42 --> Config Class Initialized
INFO - 2023-05-26 09:03:42 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:03:42 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:03:42 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:42 --> URI Class Initialized
DEBUG - 2023-05-26 09:03:42 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:03:42 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:42 --> Router Class Initialized
INFO - 2023-05-26 09:03:43 --> Config Class Initialized
INFO - 2023-05-26 09:03:43 --> URI Class Initialized
INFO - 2023-05-26 09:03:43 --> Hooks Class Initialized
INFO - 2023-05-26 09:03:43 --> Output Class Initialized
INFO - 2023-05-26 09:03:43 --> Security Class Initialized
INFO - 2023-05-26 09:03:43 --> Router Class Initialized
DEBUG - 2023-05-26 09:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:03:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:03:43 --> Input Class Initialized
INFO - 2023-05-26 09:03:43 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:43 --> Output Class Initialized
INFO - 2023-05-26 09:03:43 --> URI Class Initialized
INFO - 2023-05-26 09:03:43 --> Language Class Initialized
INFO - 2023-05-26 09:03:43 --> Security Class Initialized
INFO - 2023-05-26 09:03:43 --> Router Class Initialized
DEBUG - 2023-05-26 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:03:43 --> Input Class Initialized
INFO - 2023-05-26 09:03:43 --> Loader Class Initialized
INFO - 2023-05-26 09:03:43 --> Output Class Initialized
INFO - 2023-05-26 09:03:43 --> Language Class Initialized
INFO - 2023-05-26 09:03:43 --> Controller Class Initialized
INFO - 2023-05-26 09:03:43 --> Security Class Initialized
DEBUG - 2023-05-26 09:03:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:03:43 --> Loader Class Initialized
INFO - 2023-05-26 09:03:43 --> Input Class Initialized
INFO - 2023-05-26 09:03:43 --> Language Class Initialized
INFO - 2023-05-26 09:03:43 --> Controller Class Initialized
INFO - 2023-05-26 09:03:43 --> Config Class Initialized
INFO - 2023-05-26 09:03:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:03:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:03:43 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:43 --> Loader Class Initialized
INFO - 2023-05-26 09:03:43 --> Controller Class Initialized
INFO - 2023-05-26 09:03:43 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 09:03:43 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:03:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:03:43 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:43 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:43 --> URI Class Initialized
INFO - 2023-05-26 09:03:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:03:43 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:43 --> Router Class Initialized
INFO - 2023-05-26 09:03:43 --> Final output sent to browser
DEBUG - 2023-05-26 09:03:43 --> Total execution time: 0.3112
INFO - 2023-05-26 09:03:43 --> Final output sent to browser
INFO - 2023-05-26 09:03:43 --> Output Class Initialized
DEBUG - 2023-05-26 09:03:43 --> Total execution time: 0.3111
INFO - 2023-05-26 09:03:43 --> Security Class Initialized
INFO - 2023-05-26 09:03:43 --> Database Driver Class Initialized
DEBUG - 2023-05-26 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:03:43 --> Input Class Initialized
INFO - 2023-05-26 09:03:43 --> Config Class Initialized
INFO - 2023-05-26 09:03:43 --> Language Class Initialized
INFO - 2023-05-26 09:03:43 --> Hooks Class Initialized
INFO - 2023-05-26 09:03:43 --> Model "Login_model" initialized
INFO - 2023-05-26 09:03:43 --> Final output sent to browser
DEBUG - 2023-05-26 09:03:43 --> Total execution time: 0.3244
DEBUG - 2023-05-26 09:03:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:03:43 --> Loader Class Initialized
INFO - 2023-05-26 09:03:43 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:43 --> URI Class Initialized
INFO - 2023-05-26 09:03:43 --> Controller Class Initialized
DEBUG - 2023-05-26 09:03:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:03:43 --> Router Class Initialized
INFO - 2023-05-26 09:03:43 --> Output Class Initialized
INFO - 2023-05-26 09:03:43 --> Security Class Initialized
DEBUG - 2023-05-26 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:03:43 --> Input Class Initialized
INFO - 2023-05-26 09:03:43 --> Language Class Initialized
INFO - 2023-05-26 09:03:43 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:03:43 --> Loader Class Initialized
INFO - 2023-05-26 09:03:43 --> Controller Class Initialized
DEBUG - 2023-05-26 09:03:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:03:43 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:03:43 --> Final output sent to browser
DEBUG - 2023-05-26 09:03:43 --> Total execution time: 0.4187
INFO - 2023-05-26 09:03:43 --> Final output sent to browser
DEBUG - 2023-05-26 09:03:43 --> Total execution time: 0.2686
INFO - 2023-05-26 09:03:54 --> Config Class Initialized
INFO - 2023-05-26 09:03:54 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:03:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:03:54 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:54 --> URI Class Initialized
INFO - 2023-05-26 09:03:54 --> Router Class Initialized
INFO - 2023-05-26 09:03:55 --> Output Class Initialized
INFO - 2023-05-26 09:03:55 --> Security Class Initialized
DEBUG - 2023-05-26 09:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:03:55 --> Input Class Initialized
INFO - 2023-05-26 09:03:55 --> Language Class Initialized
INFO - 2023-05-26 09:03:55 --> Loader Class Initialized
INFO - 2023-05-26 09:03:55 --> Controller Class Initialized
DEBUG - 2023-05-26 09:03:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:03:55 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:55 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:03:55 --> Final output sent to browser
DEBUG - 2023-05-26 09:03:55 --> Total execution time: 0.1875
INFO - 2023-05-26 09:03:55 --> Config Class Initialized
INFO - 2023-05-26 09:03:55 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:03:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:03:55 --> Utf8 Class Initialized
INFO - 2023-05-26 09:03:55 --> URI Class Initialized
INFO - 2023-05-26 09:03:55 --> Router Class Initialized
INFO - 2023-05-26 09:03:55 --> Output Class Initialized
INFO - 2023-05-26 09:03:55 --> Security Class Initialized
DEBUG - 2023-05-26 09:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:03:55 --> Input Class Initialized
INFO - 2023-05-26 09:03:55 --> Language Class Initialized
INFO - 2023-05-26 09:03:55 --> Loader Class Initialized
INFO - 2023-05-26 09:03:55 --> Controller Class Initialized
DEBUG - 2023-05-26 09:03:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:03:55 --> Database Driver Class Initialized
INFO - 2023-05-26 09:03:55 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:03:55 --> Final output sent to browser
DEBUG - 2023-05-26 09:03:55 --> Total execution time: 0.2016
INFO - 2023-05-26 09:04:14 --> Config Class Initialized
INFO - 2023-05-26 09:04:14 --> Hooks Class Initialized
INFO - 2023-05-26 09:04:14 --> Config Class Initialized
INFO - 2023-05-26 09:04:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:04:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:04:14 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:14 --> URI Class Initialized
DEBUG - 2023-05-26 09:04:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:04:14 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:14 --> Router Class Initialized
INFO - 2023-05-26 09:04:14 --> URI Class Initialized
INFO - 2023-05-26 09:04:14 --> Output Class Initialized
INFO - 2023-05-26 09:04:14 --> Router Class Initialized
INFO - 2023-05-26 09:04:14 --> Security Class Initialized
DEBUG - 2023-05-26 09:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:04:14 --> Output Class Initialized
INFO - 2023-05-26 09:04:14 --> Input Class Initialized
INFO - 2023-05-26 09:04:14 --> Security Class Initialized
INFO - 2023-05-26 09:04:14 --> Language Class Initialized
DEBUG - 2023-05-26 09:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:04:14 --> Input Class Initialized
INFO - 2023-05-26 09:04:14 --> Language Class Initialized
INFO - 2023-05-26 09:04:14 --> Loader Class Initialized
INFO - 2023-05-26 09:04:14 --> Loader Class Initialized
INFO - 2023-05-26 09:04:14 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:14 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:14 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:14 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:14 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:04:14 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:04:14 --> Final output sent to browser
DEBUG - 2023-05-26 09:04:14 --> Total execution time: 0.2467
INFO - 2023-05-26 09:04:14 --> Config Class Initialized
INFO - 2023-05-26 09:04:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:04:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:04:14 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:14 --> URI Class Initialized
INFO - 2023-05-26 09:04:14 --> Router Class Initialized
INFO - 2023-05-26 09:04:14 --> Output Class Initialized
INFO - 2023-05-26 09:04:14 --> Security Class Initialized
DEBUG - 2023-05-26 09:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:04:14 --> Input Class Initialized
INFO - 2023-05-26 09:04:15 --> Language Class Initialized
INFO - 2023-05-26 09:04:15 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:15 --> Loader Class Initialized
INFO - 2023-05-26 09:04:15 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:15 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:15 --> Model "Login_model" initialized
INFO - 2023-05-26 09:04:15 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:04:15 --> Final output sent to browser
DEBUG - 2023-05-26 09:04:15 --> Total execution time: 0.3179
INFO - 2023-05-26 09:04:17 --> Final output sent to browser
DEBUG - 2023-05-26 09:04:17 --> Total execution time: 2.9434
INFO - 2023-05-26 09:04:17 --> Config Class Initialized
INFO - 2023-05-26 09:04:17 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:04:17 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:04:17 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:17 --> URI Class Initialized
INFO - 2023-05-26 09:04:17 --> Router Class Initialized
INFO - 2023-05-26 09:04:17 --> Output Class Initialized
INFO - 2023-05-26 09:04:17 --> Security Class Initialized
DEBUG - 2023-05-26 09:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:04:17 --> Input Class Initialized
INFO - 2023-05-26 09:04:17 --> Language Class Initialized
INFO - 2023-05-26 09:04:17 --> Loader Class Initialized
INFO - 2023-05-26 09:04:17 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:17 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:18 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:04:18 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:18 --> Model "Login_model" initialized
INFO - 2023-05-26 09:04:20 --> Config Class Initialized
INFO - 2023-05-26 09:04:20 --> Config Class Initialized
INFO - 2023-05-26 09:04:20 --> Hooks Class Initialized
INFO - 2023-05-26 09:04:20 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:04:20 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:04:20 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:04:20 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:20 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:20 --> URI Class Initialized
INFO - 2023-05-26 09:04:20 --> URI Class Initialized
INFO - 2023-05-26 09:04:20 --> Router Class Initialized
INFO - 2023-05-26 09:04:20 --> Router Class Initialized
INFO - 2023-05-26 09:04:20 --> Output Class Initialized
INFO - 2023-05-26 09:04:20 --> Output Class Initialized
INFO - 2023-05-26 09:04:20 --> Security Class Initialized
INFO - 2023-05-26 09:04:20 --> Security Class Initialized
DEBUG - 2023-05-26 09:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:04:20 --> Input Class Initialized
INFO - 2023-05-26 09:04:20 --> Input Class Initialized
INFO - 2023-05-26 09:04:20 --> Language Class Initialized
INFO - 2023-05-26 09:04:20 --> Language Class Initialized
INFO - 2023-05-26 09:04:20 --> Loader Class Initialized
INFO - 2023-05-26 09:04:20 --> Loader Class Initialized
INFO - 2023-05-26 09:04:20 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:20 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:20 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:20 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:04:21 --> Final output sent to browser
DEBUG - 2023-05-26 09:04:21 --> Total execution time: 3.4852
INFO - 2023-05-26 09:04:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:04:21 --> Final output sent to browser
DEBUG - 2023-05-26 09:04:21 --> Total execution time: 0.3001
INFO - 2023-05-26 09:04:21 --> Config Class Initialized
INFO - 2023-05-26 09:04:21 --> Hooks Class Initialized
INFO - 2023-05-26 09:04:21 --> Database Driver Class Initialized
DEBUG - 2023-05-26 09:04:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:04:21 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:21 --> URI Class Initialized
INFO - 2023-05-26 09:04:21 --> Model "Login_model" initialized
INFO - 2023-05-26 09:04:21 --> Router Class Initialized
INFO - 2023-05-26 09:04:21 --> Output Class Initialized
INFO - 2023-05-26 09:04:21 --> Security Class Initialized
DEBUG - 2023-05-26 09:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:04:21 --> Input Class Initialized
INFO - 2023-05-26 09:04:21 --> Language Class Initialized
INFO - 2023-05-26 09:04:21 --> Loader Class Initialized
INFO - 2023-05-26 09:04:21 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:22 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:04:22 --> Final output sent to browser
DEBUG - 2023-05-26 09:04:22 --> Total execution time: 0.9564
INFO - 2023-05-26 09:04:25 --> Final output sent to browser
DEBUG - 2023-05-26 09:04:25 --> Total execution time: 4.7183
INFO - 2023-05-26 09:04:29 --> Config Class Initialized
INFO - 2023-05-26 09:04:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:04:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:04:29 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:29 --> URI Class Initialized
INFO - 2023-05-26 09:04:29 --> Router Class Initialized
INFO - 2023-05-26 09:04:29 --> Output Class Initialized
INFO - 2023-05-26 09:04:29 --> Security Class Initialized
DEBUG - 2023-05-26 09:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:04:29 --> Input Class Initialized
INFO - 2023-05-26 09:04:29 --> Language Class Initialized
INFO - 2023-05-26 09:04:29 --> Loader Class Initialized
INFO - 2023-05-26 09:04:29 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:29 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:04:29 --> Final output sent to browser
DEBUG - 2023-05-26 09:04:29 --> Total execution time: 0.4888
INFO - 2023-05-26 09:04:29 --> Config Class Initialized
INFO - 2023-05-26 09:04:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:04:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:04:29 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:29 --> URI Class Initialized
INFO - 2023-05-26 09:04:29 --> Router Class Initialized
INFO - 2023-05-26 09:04:29 --> Output Class Initialized
INFO - 2023-05-26 09:04:29 --> Security Class Initialized
DEBUG - 2023-05-26 09:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:04:29 --> Input Class Initialized
INFO - 2023-05-26 09:04:29 --> Language Class Initialized
INFO - 2023-05-26 09:04:29 --> Loader Class Initialized
INFO - 2023-05-26 09:04:29 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:29 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:04:29 --> Final output sent to browser
DEBUG - 2023-05-26 09:04:29 --> Total execution time: 0.2398
INFO - 2023-05-26 09:04:30 --> Config Class Initialized
INFO - 2023-05-26 09:04:30 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:04:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:04:30 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:30 --> URI Class Initialized
INFO - 2023-05-26 09:04:30 --> Router Class Initialized
INFO - 2023-05-26 09:04:30 --> Output Class Initialized
INFO - 2023-05-26 09:04:30 --> Security Class Initialized
DEBUG - 2023-05-26 09:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:04:30 --> Input Class Initialized
INFO - 2023-05-26 09:04:30 --> Language Class Initialized
INFO - 2023-05-26 09:04:30 --> Loader Class Initialized
INFO - 2023-05-26 09:04:30 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:30 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:04:31 --> Final output sent to browser
DEBUG - 2023-05-26 09:04:31 --> Total execution time: 0.5265
INFO - 2023-05-26 09:04:31 --> Config Class Initialized
INFO - 2023-05-26 09:04:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:04:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:04:31 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:31 --> URI Class Initialized
INFO - 2023-05-26 09:04:31 --> Router Class Initialized
INFO - 2023-05-26 09:04:31 --> Output Class Initialized
INFO - 2023-05-26 09:04:31 --> Security Class Initialized
DEBUG - 2023-05-26 09:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:04:31 --> Input Class Initialized
INFO - 2023-05-26 09:04:31 --> Language Class Initialized
INFO - 2023-05-26 09:04:31 --> Loader Class Initialized
INFO - 2023-05-26 09:04:31 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:31 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:04:31 --> Final output sent to browser
DEBUG - 2023-05-26 09:04:31 --> Total execution time: 0.2270
INFO - 2023-05-26 09:04:32 --> Config Class Initialized
INFO - 2023-05-26 09:04:32 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:04:32 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:04:32 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:32 --> URI Class Initialized
INFO - 2023-05-26 09:04:32 --> Router Class Initialized
INFO - 2023-05-26 09:04:32 --> Output Class Initialized
INFO - 2023-05-26 09:04:32 --> Security Class Initialized
DEBUG - 2023-05-26 09:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:04:32 --> Input Class Initialized
INFO - 2023-05-26 09:04:32 --> Language Class Initialized
INFO - 2023-05-26 09:04:32 --> Loader Class Initialized
INFO - 2023-05-26 09:04:32 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:32 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:32 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:04:32 --> Final output sent to browser
DEBUG - 2023-05-26 09:04:32 --> Total execution time: 0.1942
INFO - 2023-05-26 09:04:32 --> Config Class Initialized
INFO - 2023-05-26 09:04:32 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:04:32 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:04:32 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:32 --> URI Class Initialized
INFO - 2023-05-26 09:04:32 --> Router Class Initialized
INFO - 2023-05-26 09:04:32 --> Output Class Initialized
INFO - 2023-05-26 09:04:32 --> Security Class Initialized
DEBUG - 2023-05-26 09:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:04:32 --> Input Class Initialized
INFO - 2023-05-26 09:04:32 --> Language Class Initialized
INFO - 2023-05-26 09:04:32 --> Loader Class Initialized
INFO - 2023-05-26 09:04:32 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:32 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:32 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:04:32 --> Final output sent to browser
DEBUG - 2023-05-26 09:04:32 --> Total execution time: 0.2281
INFO - 2023-05-26 09:04:59 --> Config Class Initialized
INFO - 2023-05-26 09:04:59 --> Config Class Initialized
INFO - 2023-05-26 09:04:59 --> Hooks Class Initialized
INFO - 2023-05-26 09:04:59 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:04:59 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:04:59 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:59 --> Utf8 Class Initialized
INFO - 2023-05-26 09:04:59 --> URI Class Initialized
INFO - 2023-05-26 09:04:59 --> URI Class Initialized
INFO - 2023-05-26 09:04:59 --> Router Class Initialized
INFO - 2023-05-26 09:04:59 --> Router Class Initialized
INFO - 2023-05-26 09:04:59 --> Output Class Initialized
INFO - 2023-05-26 09:04:59 --> Output Class Initialized
INFO - 2023-05-26 09:04:59 --> Security Class Initialized
INFO - 2023-05-26 09:04:59 --> Security Class Initialized
DEBUG - 2023-05-26 09:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:04:59 --> Input Class Initialized
INFO - 2023-05-26 09:04:59 --> Input Class Initialized
INFO - 2023-05-26 09:04:59 --> Language Class Initialized
INFO - 2023-05-26 09:04:59 --> Language Class Initialized
INFO - 2023-05-26 09:04:59 --> Loader Class Initialized
INFO - 2023-05-26 09:04:59 --> Loader Class Initialized
INFO - 2023-05-26 09:04:59 --> Controller Class Initialized
INFO - 2023-05-26 09:04:59 --> Controller Class Initialized
DEBUG - 2023-05-26 09:04:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:04:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:04:59 --> Database Driver Class Initialized
INFO - 2023-05-26 09:04:59 --> Database Driver Class Initialized
INFO - 2023-05-26 09:05:00 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:01 --> Config Class Initialized
INFO - 2023-05-26 09:05:01 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:05:01 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:05:01 --> Final output sent to browser
INFO - 2023-05-26 09:05:01 --> Utf8 Class Initialized
DEBUG - 2023-05-26 09:05:01 --> Total execution time: 1.4391
INFO - 2023-05-26 09:05:01 --> URI Class Initialized
INFO - 2023-05-26 09:05:01 --> Router Class Initialized
INFO - 2023-05-26 09:05:01 --> Output Class Initialized
INFO - 2023-05-26 09:05:01 --> Security Class Initialized
DEBUG - 2023-05-26 09:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:05:01 --> Config Class Initialized
INFO - 2023-05-26 09:05:01 --> Hooks Class Initialized
INFO - 2023-05-26 09:05:01 --> Input Class Initialized
INFO - 2023-05-26 09:05:01 --> Language Class Initialized
DEBUG - 2023-05-26 09:05:01 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:05:01 --> Utf8 Class Initialized
INFO - 2023-05-26 09:05:01 --> Loader Class Initialized
INFO - 2023-05-26 09:05:01 --> URI Class Initialized
INFO - 2023-05-26 09:05:01 --> Controller Class Initialized
DEBUG - 2023-05-26 09:05:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:05:01 --> Router Class Initialized
INFO - 2023-05-26 09:05:01 --> Output Class Initialized
INFO - 2023-05-26 09:05:01 --> Database Driver Class Initialized
INFO - 2023-05-26 09:05:01 --> Security Class Initialized
DEBUG - 2023-05-26 09:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:05:01 --> Input Class Initialized
INFO - 2023-05-26 09:05:01 --> Language Class Initialized
INFO - 2023-05-26 09:05:01 --> Loader Class Initialized
INFO - 2023-05-26 09:05:01 --> Controller Class Initialized
DEBUG - 2023-05-26 09:05:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:05:01 --> Database Driver Class Initialized
INFO - 2023-05-26 09:05:03 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:03 --> Final output sent to browser
DEBUG - 2023-05-26 09:05:04 --> Total execution time: 2.8412
INFO - 2023-05-26 09:05:04 --> Config Class Initialized
INFO - 2023-05-26 09:05:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:05:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:05:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:04 --> Utf8 Class Initialized
INFO - 2023-05-26 09:05:04 --> URI Class Initialized
INFO - 2023-05-26 09:05:04 --> Final output sent to browser
DEBUG - 2023-05-26 09:05:04 --> Total execution time: 2.8627
INFO - 2023-05-26 09:05:04 --> Router Class Initialized
INFO - 2023-05-26 09:05:04 --> Output Class Initialized
INFO - 2023-05-26 09:05:04 --> Security Class Initialized
DEBUG - 2023-05-26 09:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:05:04 --> Input Class Initialized
INFO - 2023-05-26 09:05:04 --> Language Class Initialized
INFO - 2023-05-26 09:05:04 --> Loader Class Initialized
INFO - 2023-05-26 09:05:04 --> Controller Class Initialized
DEBUG - 2023-05-26 09:05:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:05:04 --> Database Driver Class Initialized
INFO - 2023-05-26 09:05:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:04 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:04 --> Final output sent to browser
DEBUG - 2023-05-26 09:05:04 --> Total execution time: 0.1804
INFO - 2023-05-26 09:05:04 --> Config Class Initialized
INFO - 2023-05-26 09:05:04 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:05:04 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:05:04 --> Utf8 Class Initialized
INFO - 2023-05-26 09:05:04 --> URI Class Initialized
INFO - 2023-05-26 09:05:04 --> Router Class Initialized
INFO - 2023-05-26 09:05:04 --> Output Class Initialized
INFO - 2023-05-26 09:05:04 --> Security Class Initialized
DEBUG - 2023-05-26 09:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:05:04 --> Input Class Initialized
INFO - 2023-05-26 09:05:04 --> Language Class Initialized
INFO - 2023-05-26 09:05:04 --> Loader Class Initialized
INFO - 2023-05-26 09:05:04 --> Controller Class Initialized
DEBUG - 2023-05-26 09:05:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:05:04 --> Database Driver Class Initialized
INFO - 2023-05-26 09:05:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:08 --> Config Class Initialized
INFO - 2023-05-26 09:05:08 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:05:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:05:08 --> Utf8 Class Initialized
INFO - 2023-05-26 09:05:08 --> URI Class Initialized
INFO - 2023-05-26 09:05:08 --> Router Class Initialized
INFO - 2023-05-26 09:05:08 --> Output Class Initialized
INFO - 2023-05-26 09:05:08 --> Security Class Initialized
DEBUG - 2023-05-26 09:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:05:08 --> Input Class Initialized
INFO - 2023-05-26 09:05:08 --> Language Class Initialized
INFO - 2023-05-26 09:05:08 --> Loader Class Initialized
INFO - 2023-05-26 09:05:08 --> Controller Class Initialized
DEBUG - 2023-05-26 09:05:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:05:08 --> Database Driver Class Initialized
INFO - 2023-05-26 09:05:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:09 --> Final output sent to browser
DEBUG - 2023-05-26 09:05:09 --> Total execution time: 0.9076
INFO - 2023-05-26 09:05:09 --> Config Class Initialized
INFO - 2023-05-26 09:05:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:05:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:05:09 --> Utf8 Class Initialized
INFO - 2023-05-26 09:05:09 --> URI Class Initialized
INFO - 2023-05-26 09:05:09 --> Router Class Initialized
INFO - 2023-05-26 09:05:09 --> Output Class Initialized
INFO - 2023-05-26 09:05:09 --> Security Class Initialized
DEBUG - 2023-05-26 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:05:09 --> Input Class Initialized
INFO - 2023-05-26 09:05:09 --> Language Class Initialized
INFO - 2023-05-26 09:05:09 --> Config Class Initialized
INFO - 2023-05-26 09:05:09 --> Loader Class Initialized
INFO - 2023-05-26 09:05:09 --> Hooks Class Initialized
INFO - 2023-05-26 09:05:09 --> Controller Class Initialized
DEBUG - 2023-05-26 09:05:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:05:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:05:09 --> Utf8 Class Initialized
INFO - 2023-05-26 09:05:09 --> URI Class Initialized
INFO - 2023-05-26 09:05:09 --> Router Class Initialized
INFO - 2023-05-26 09:05:09 --> Database Driver Class Initialized
INFO - 2023-05-26 09:05:09 --> Output Class Initialized
INFO - 2023-05-26 09:05:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:09 --> Security Class Initialized
DEBUG - 2023-05-26 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:05:09 --> Input Class Initialized
INFO - 2023-05-26 09:05:09 --> Language Class Initialized
INFO - 2023-05-26 09:05:09 --> Loader Class Initialized
INFO - 2023-05-26 09:05:09 --> Controller Class Initialized
INFO - 2023-05-26 09:05:09 --> Final output sent to browser
DEBUG - 2023-05-26 09:05:09 --> Total execution time: 0.2396
DEBUG - 2023-05-26 09:05:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:05:09 --> Database Driver Class Initialized
INFO - 2023-05-26 09:05:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:09 --> Final output sent to browser
DEBUG - 2023-05-26 09:05:09 --> Total execution time: 0.3112
INFO - 2023-05-26 09:05:09 --> Config Class Initialized
INFO - 2023-05-26 09:05:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:05:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:05:09 --> Utf8 Class Initialized
INFO - 2023-05-26 09:05:09 --> URI Class Initialized
INFO - 2023-05-26 09:05:09 --> Router Class Initialized
INFO - 2023-05-26 09:05:09 --> Output Class Initialized
INFO - 2023-05-26 09:05:09 --> Security Class Initialized
DEBUG - 2023-05-26 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:05:09 --> Input Class Initialized
INFO - 2023-05-26 09:05:09 --> Language Class Initialized
INFO - 2023-05-26 09:05:09 --> Loader Class Initialized
INFO - 2023-05-26 09:05:09 --> Controller Class Initialized
DEBUG - 2023-05-26 09:05:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:05:09 --> Database Driver Class Initialized
INFO - 2023-05-26 09:05:09 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:09 --> Final output sent to browser
DEBUG - 2023-05-26 09:05:09 --> Total execution time: 0.1695
INFO - 2023-05-26 09:05:12 --> Config Class Initialized
INFO - 2023-05-26 09:05:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:05:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:05:12 --> Utf8 Class Initialized
INFO - 2023-05-26 09:05:12 --> URI Class Initialized
INFO - 2023-05-26 09:05:12 --> Router Class Initialized
INFO - 2023-05-26 09:05:12 --> Output Class Initialized
INFO - 2023-05-26 09:05:12 --> Security Class Initialized
DEBUG - 2023-05-26 09:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:05:12 --> Input Class Initialized
INFO - 2023-05-26 09:05:12 --> Language Class Initialized
INFO - 2023-05-26 09:05:12 --> Loader Class Initialized
INFO - 2023-05-26 09:05:12 --> Controller Class Initialized
DEBUG - 2023-05-26 09:05:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:05:12 --> Database Driver Class Initialized
INFO - 2023-05-26 09:05:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:12 --> Final output sent to browser
DEBUG - 2023-05-26 09:05:12 --> Total execution time: 0.1900
INFO - 2023-05-26 09:05:12 --> Config Class Initialized
INFO - 2023-05-26 09:05:12 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:05:12 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:05:12 --> Utf8 Class Initialized
INFO - 2023-05-26 09:05:12 --> URI Class Initialized
INFO - 2023-05-26 09:05:12 --> Router Class Initialized
INFO - 2023-05-26 09:05:12 --> Output Class Initialized
INFO - 2023-05-26 09:05:12 --> Security Class Initialized
DEBUG - 2023-05-26 09:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:05:12 --> Input Class Initialized
INFO - 2023-05-26 09:05:12 --> Language Class Initialized
INFO - 2023-05-26 09:05:12 --> Loader Class Initialized
INFO - 2023-05-26 09:05:12 --> Controller Class Initialized
DEBUG - 2023-05-26 09:05:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:05:12 --> Database Driver Class Initialized
INFO - 2023-05-26 09:05:12 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:13 --> Final output sent to browser
DEBUG - 2023-05-26 09:05:13 --> Total execution time: 0.2044
INFO - 2023-05-26 09:05:14 --> Config Class Initialized
INFO - 2023-05-26 09:05:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:05:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:05:14 --> Utf8 Class Initialized
INFO - 2023-05-26 09:05:14 --> URI Class Initialized
INFO - 2023-05-26 09:05:14 --> Router Class Initialized
INFO - 2023-05-26 09:05:14 --> Output Class Initialized
INFO - 2023-05-26 09:05:14 --> Security Class Initialized
DEBUG - 2023-05-26 09:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:05:14 --> Input Class Initialized
INFO - 2023-05-26 09:05:15 --> Language Class Initialized
INFO - 2023-05-26 09:05:15 --> Loader Class Initialized
INFO - 2023-05-26 09:05:15 --> Controller Class Initialized
DEBUG - 2023-05-26 09:05:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:05:15 --> Database Driver Class Initialized
INFO - 2023-05-26 09:05:15 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:15 --> Final output sent to browser
DEBUG - 2023-05-26 09:05:15 --> Total execution time: 0.5186
INFO - 2023-05-26 09:05:15 --> Config Class Initialized
INFO - 2023-05-26 09:05:15 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:05:15 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:05:15 --> Utf8 Class Initialized
INFO - 2023-05-26 09:05:15 --> URI Class Initialized
INFO - 2023-05-26 09:05:15 --> Router Class Initialized
INFO - 2023-05-26 09:05:15 --> Output Class Initialized
INFO - 2023-05-26 09:05:15 --> Security Class Initialized
DEBUG - 2023-05-26 09:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:05:15 --> Input Class Initialized
INFO - 2023-05-26 09:05:15 --> Language Class Initialized
INFO - 2023-05-26 09:05:15 --> Loader Class Initialized
INFO - 2023-05-26 09:05:15 --> Controller Class Initialized
DEBUG - 2023-05-26 09:05:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:05:15 --> Database Driver Class Initialized
INFO - 2023-05-26 09:05:15 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:05:15 --> Final output sent to browser
DEBUG - 2023-05-26 09:05:15 --> Total execution time: 0.2764
INFO - 2023-05-26 09:06:40 --> Config Class Initialized
INFO - 2023-05-26 09:06:40 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:06:40 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:06:40 --> Utf8 Class Initialized
INFO - 2023-05-26 09:06:41 --> URI Class Initialized
INFO - 2023-05-26 09:06:41 --> Router Class Initialized
INFO - 2023-05-26 09:06:41 --> Output Class Initialized
INFO - 2023-05-26 09:06:41 --> Security Class Initialized
DEBUG - 2023-05-26 09:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:06:41 --> Input Class Initialized
INFO - 2023-05-26 09:06:41 --> Language Class Initialized
INFO - 2023-05-26 09:06:41 --> Loader Class Initialized
INFO - 2023-05-26 09:06:41 --> Controller Class Initialized
DEBUG - 2023-05-26 09:06:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:06:41 --> Database Driver Class Initialized
INFO - 2023-05-26 09:06:41 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:06:41 --> Final output sent to browser
DEBUG - 2023-05-26 09:06:41 --> Total execution time: 0.2733
INFO - 2023-05-26 09:06:41 --> Config Class Initialized
INFO - 2023-05-26 09:06:41 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:06:41 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:06:41 --> Utf8 Class Initialized
INFO - 2023-05-26 09:06:41 --> URI Class Initialized
INFO - 2023-05-26 09:06:41 --> Router Class Initialized
INFO - 2023-05-26 09:06:41 --> Output Class Initialized
INFO - 2023-05-26 09:06:41 --> Security Class Initialized
DEBUG - 2023-05-26 09:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:06:41 --> Input Class Initialized
INFO - 2023-05-26 09:06:41 --> Language Class Initialized
INFO - 2023-05-26 09:06:41 --> Loader Class Initialized
INFO - 2023-05-26 09:06:41 --> Controller Class Initialized
DEBUG - 2023-05-26 09:06:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:06:41 --> Database Driver Class Initialized
INFO - 2023-05-26 09:06:41 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:06:41 --> Final output sent to browser
DEBUG - 2023-05-26 09:06:41 --> Total execution time: 0.2673
INFO - 2023-05-26 09:06:51 --> Config Class Initialized
INFO - 2023-05-26 09:06:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:06:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:06:51 --> Utf8 Class Initialized
INFO - 2023-05-26 09:06:51 --> URI Class Initialized
INFO - 2023-05-26 09:06:51 --> Router Class Initialized
INFO - 2023-05-26 09:06:51 --> Output Class Initialized
INFO - 2023-05-26 09:06:51 --> Security Class Initialized
DEBUG - 2023-05-26 09:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:06:51 --> Input Class Initialized
INFO - 2023-05-26 09:06:51 --> Language Class Initialized
INFO - 2023-05-26 09:06:51 --> Loader Class Initialized
INFO - 2023-05-26 09:06:51 --> Controller Class Initialized
DEBUG - 2023-05-26 09:06:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:06:51 --> Database Driver Class Initialized
INFO - 2023-05-26 09:06:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:06:51 --> Final output sent to browser
DEBUG - 2023-05-26 09:06:51 --> Total execution time: 0.1855
INFO - 2023-05-26 09:06:51 --> Config Class Initialized
INFO - 2023-05-26 09:06:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:06:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:06:51 --> Utf8 Class Initialized
INFO - 2023-05-26 09:06:51 --> URI Class Initialized
INFO - 2023-05-26 09:06:51 --> Router Class Initialized
INFO - 2023-05-26 09:06:51 --> Output Class Initialized
INFO - 2023-05-26 09:06:51 --> Security Class Initialized
DEBUG - 2023-05-26 09:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:06:51 --> Input Class Initialized
INFO - 2023-05-26 09:06:51 --> Language Class Initialized
INFO - 2023-05-26 09:06:51 --> Loader Class Initialized
INFO - 2023-05-26 09:06:51 --> Controller Class Initialized
DEBUG - 2023-05-26 09:06:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:06:51 --> Database Driver Class Initialized
INFO - 2023-05-26 09:06:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:06:51 --> Final output sent to browser
DEBUG - 2023-05-26 09:06:51 --> Total execution time: 0.3947
INFO - 2023-05-26 09:07:19 --> Config Class Initialized
INFO - 2023-05-26 09:07:19 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:07:19 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:07:19 --> Utf8 Class Initialized
INFO - 2023-05-26 09:07:19 --> URI Class Initialized
INFO - 2023-05-26 09:07:19 --> Router Class Initialized
INFO - 2023-05-26 09:07:19 --> Output Class Initialized
INFO - 2023-05-26 09:07:19 --> Security Class Initialized
DEBUG - 2023-05-26 09:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:07:19 --> Input Class Initialized
INFO - 2023-05-26 09:07:19 --> Language Class Initialized
INFO - 2023-05-26 09:07:19 --> Loader Class Initialized
INFO - 2023-05-26 09:07:19 --> Controller Class Initialized
DEBUG - 2023-05-26 09:07:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:07:19 --> Database Driver Class Initialized
INFO - 2023-05-26 09:07:19 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:07:19 --> Final output sent to browser
DEBUG - 2023-05-26 09:07:19 --> Total execution time: 0.1820
INFO - 2023-05-26 09:07:19 --> Config Class Initialized
INFO - 2023-05-26 09:07:19 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:07:19 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:07:19 --> Utf8 Class Initialized
INFO - 2023-05-26 09:07:19 --> URI Class Initialized
INFO - 2023-05-26 09:07:19 --> Router Class Initialized
INFO - 2023-05-26 09:07:19 --> Output Class Initialized
INFO - 2023-05-26 09:07:19 --> Security Class Initialized
DEBUG - 2023-05-26 09:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:07:19 --> Input Class Initialized
INFO - 2023-05-26 09:07:19 --> Language Class Initialized
INFO - 2023-05-26 09:07:19 --> Loader Class Initialized
INFO - 2023-05-26 09:07:19 --> Controller Class Initialized
DEBUG - 2023-05-26 09:07:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:07:19 --> Database Driver Class Initialized
INFO - 2023-05-26 09:07:19 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:07:19 --> Final output sent to browser
DEBUG - 2023-05-26 09:07:19 --> Total execution time: 0.2891
INFO - 2023-05-26 09:07:23 --> Config Class Initialized
INFO - 2023-05-26 09:07:23 --> Config Class Initialized
INFO - 2023-05-26 09:07:23 --> Config Class Initialized
INFO - 2023-05-26 09:07:23 --> Hooks Class Initialized
INFO - 2023-05-26 09:07:23 --> Hooks Class Initialized
INFO - 2023-05-26 09:07:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:07:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:07:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:07:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:07:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:07:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:07:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:07:23 --> URI Class Initialized
INFO - 2023-05-26 09:07:23 --> URI Class Initialized
INFO - 2023-05-26 09:07:23 --> URI Class Initialized
INFO - 2023-05-26 09:07:23 --> Router Class Initialized
INFO - 2023-05-26 09:07:23 --> Router Class Initialized
INFO - 2023-05-26 09:07:23 --> Router Class Initialized
INFO - 2023-05-26 09:07:23 --> Output Class Initialized
INFO - 2023-05-26 09:07:23 --> Output Class Initialized
INFO - 2023-05-26 09:07:23 --> Output Class Initialized
INFO - 2023-05-26 09:07:23 --> Security Class Initialized
INFO - 2023-05-26 09:07:23 --> Security Class Initialized
INFO - 2023-05-26 09:07:23 --> Security Class Initialized
DEBUG - 2023-05-26 09:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:07:23 --> Input Class Initialized
INFO - 2023-05-26 09:07:23 --> Input Class Initialized
INFO - 2023-05-26 09:07:23 --> Input Class Initialized
INFO - 2023-05-26 09:07:23 --> Language Class Initialized
INFO - 2023-05-26 09:07:23 --> Language Class Initialized
INFO - 2023-05-26 09:07:23 --> Language Class Initialized
INFO - 2023-05-26 09:07:23 --> Loader Class Initialized
INFO - 2023-05-26 09:07:23 --> Loader Class Initialized
INFO - 2023-05-26 09:07:23 --> Controller Class Initialized
INFO - 2023-05-26 09:07:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:07:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:07:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:07:23 --> Loader Class Initialized
INFO - 2023-05-26 09:07:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:07:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:07:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:07:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:07:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:07:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:07:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:07:23 --> Final output sent to browser
INFO - 2023-05-26 09:07:23 --> Final output sent to browser
DEBUG - 2023-05-26 09:07:23 --> Total execution time: 0.1713
DEBUG - 2023-05-26 09:07:23 --> Total execution time: 0.1721
INFO - 2023-05-26 09:07:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:07:23 --> Final output sent to browser
INFO - 2023-05-26 09:07:23 --> Config Class Initialized
DEBUG - 2023-05-26 09:07:23 --> Total execution time: 0.2104
INFO - 2023-05-26 09:07:23 --> Config Class Initialized
INFO - 2023-05-26 09:07:23 --> Hooks Class Initialized
INFO - 2023-05-26 09:07:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:07:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:07:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:07:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:07:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:07:23 --> URI Class Initialized
INFO - 2023-05-26 09:07:23 --> URI Class Initialized
INFO - 2023-05-26 09:07:23 --> Router Class Initialized
INFO - 2023-05-26 09:07:23 --> Router Class Initialized
INFO - 2023-05-26 09:07:23 --> Output Class Initialized
INFO - 2023-05-26 09:07:23 --> Output Class Initialized
INFO - 2023-05-26 09:07:23 --> Security Class Initialized
INFO - 2023-05-26 09:07:23 --> Security Class Initialized
DEBUG - 2023-05-26 09:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:07:23 --> Input Class Initialized
INFO - 2023-05-26 09:07:23 --> Input Class Initialized
INFO - 2023-05-26 09:07:23 --> Language Class Initialized
INFO - 2023-05-26 09:07:23 --> Language Class Initialized
INFO - 2023-05-26 09:07:23 --> Loader Class Initialized
INFO - 2023-05-26 09:07:23 --> Loader Class Initialized
INFO - 2023-05-26 09:07:23 --> Controller Class Initialized
INFO - 2023-05-26 09:07:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:07:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:07:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:07:24 --> Database Driver Class Initialized
INFO - 2023-05-26 09:07:24 --> Database Driver Class Initialized
INFO - 2023-05-26 09:07:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:07:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:07:24 --> Final output sent to browser
INFO - 2023-05-26 09:07:24 --> Final output sent to browser
DEBUG - 2023-05-26 09:07:24 --> Total execution time: 0.1791
DEBUG - 2023-05-26 09:07:24 --> Total execution time: 0.1798
INFO - 2023-05-26 09:07:24 --> Config Class Initialized
INFO - 2023-05-26 09:07:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:07:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:07:24 --> Utf8 Class Initialized
INFO - 2023-05-26 09:07:24 --> URI Class Initialized
INFO - 2023-05-26 09:07:24 --> Router Class Initialized
INFO - 2023-05-26 09:07:24 --> Output Class Initialized
INFO - 2023-05-26 09:07:24 --> Security Class Initialized
DEBUG - 2023-05-26 09:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:07:24 --> Input Class Initialized
INFO - 2023-05-26 09:07:24 --> Language Class Initialized
INFO - 2023-05-26 09:07:24 --> Loader Class Initialized
INFO - 2023-05-26 09:07:24 --> Controller Class Initialized
DEBUG - 2023-05-26 09:07:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:07:24 --> Database Driver Class Initialized
INFO - 2023-05-26 09:07:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:07:24 --> Config Class Initialized
INFO - 2023-05-26 09:07:24 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:07:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:07:24 --> Utf8 Class Initialized
INFO - 2023-05-26 09:07:24 --> URI Class Initialized
INFO - 2023-05-26 09:07:24 --> Router Class Initialized
INFO - 2023-05-26 09:07:24 --> Output Class Initialized
INFO - 2023-05-26 09:07:24 --> Security Class Initialized
DEBUG - 2023-05-26 09:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:07:24 --> Input Class Initialized
INFO - 2023-05-26 09:07:24 --> Language Class Initialized
INFO - 2023-05-26 09:07:24 --> Loader Class Initialized
INFO - 2023-05-26 09:07:24 --> Controller Class Initialized
DEBUG - 2023-05-26 09:07:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:07:24 --> Database Driver Class Initialized
INFO - 2023-05-26 09:07:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:14:54 --> Config Class Initialized
INFO - 2023-05-26 09:14:54 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:14:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:14:54 --> Utf8 Class Initialized
INFO - 2023-05-26 09:14:54 --> URI Class Initialized
INFO - 2023-05-26 09:14:54 --> Router Class Initialized
INFO - 2023-05-26 09:14:54 --> Output Class Initialized
INFO - 2023-05-26 09:14:54 --> Security Class Initialized
DEBUG - 2023-05-26 09:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:14:54 --> Input Class Initialized
INFO - 2023-05-26 09:14:54 --> Language Class Initialized
INFO - 2023-05-26 09:14:54 --> Loader Class Initialized
INFO - 2023-05-26 09:14:54 --> Controller Class Initialized
DEBUG - 2023-05-26 09:14:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:14:54 --> Database Driver Class Initialized
INFO - 2023-05-26 09:14:55 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:14:55 --> Final output sent to browser
DEBUG - 2023-05-26 09:14:55 --> Total execution time: 1.2993
INFO - 2023-05-26 09:14:55 --> Config Class Initialized
INFO - 2023-05-26 09:14:55 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:14:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:14:55 --> Utf8 Class Initialized
INFO - 2023-05-26 09:14:55 --> URI Class Initialized
INFO - 2023-05-26 09:14:55 --> Router Class Initialized
INFO - 2023-05-26 09:14:55 --> Output Class Initialized
INFO - 2023-05-26 09:14:55 --> Security Class Initialized
DEBUG - 2023-05-26 09:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:14:55 --> Input Class Initialized
INFO - 2023-05-26 09:14:55 --> Language Class Initialized
INFO - 2023-05-26 09:14:55 --> Loader Class Initialized
INFO - 2023-05-26 09:14:55 --> Controller Class Initialized
DEBUG - 2023-05-26 09:14:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:14:55 --> Database Driver Class Initialized
INFO - 2023-05-26 09:14:55 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:14:55 --> Final output sent to browser
DEBUG - 2023-05-26 09:14:55 --> Total execution time: 0.2539
INFO - 2023-05-26 09:14:59 --> Config Class Initialized
INFO - 2023-05-26 09:14:59 --> Config Class Initialized
INFO - 2023-05-26 09:14:59 --> Config Class Initialized
INFO - 2023-05-26 09:14:59 --> Hooks Class Initialized
INFO - 2023-05-26 09:14:59 --> Hooks Class Initialized
INFO - 2023-05-26 09:14:59 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:14:59 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:14:59 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:14:59 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:14:59 --> Utf8 Class Initialized
INFO - 2023-05-26 09:14:59 --> Utf8 Class Initialized
INFO - 2023-05-26 09:14:59 --> Utf8 Class Initialized
INFO - 2023-05-26 09:14:59 --> URI Class Initialized
INFO - 2023-05-26 09:14:59 --> URI Class Initialized
INFO - 2023-05-26 09:14:59 --> URI Class Initialized
INFO - 2023-05-26 09:14:59 --> Router Class Initialized
INFO - 2023-05-26 09:14:59 --> Router Class Initialized
INFO - 2023-05-26 09:14:59 --> Router Class Initialized
INFO - 2023-05-26 09:14:59 --> Output Class Initialized
INFO - 2023-05-26 09:14:59 --> Output Class Initialized
INFO - 2023-05-26 09:14:59 --> Output Class Initialized
INFO - 2023-05-26 09:14:59 --> Security Class Initialized
INFO - 2023-05-26 09:14:59 --> Security Class Initialized
INFO - 2023-05-26 09:14:59 --> Security Class Initialized
DEBUG - 2023-05-26 09:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:14:59 --> Input Class Initialized
INFO - 2023-05-26 09:14:59 --> Input Class Initialized
INFO - 2023-05-26 09:14:59 --> Input Class Initialized
INFO - 2023-05-26 09:14:59 --> Language Class Initialized
INFO - 2023-05-26 09:14:59 --> Language Class Initialized
INFO - 2023-05-26 09:14:59 --> Language Class Initialized
INFO - 2023-05-26 09:14:59 --> Loader Class Initialized
INFO - 2023-05-26 09:14:59 --> Loader Class Initialized
INFO - 2023-05-26 09:14:59 --> Controller Class Initialized
INFO - 2023-05-26 09:14:59 --> Controller Class Initialized
INFO - 2023-05-26 09:14:59 --> Loader Class Initialized
DEBUG - 2023-05-26 09:14:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:14:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:14:59 --> Controller Class Initialized
DEBUG - 2023-05-26 09:14:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:14:59 --> Database Driver Class Initialized
INFO - 2023-05-26 09:14:59 --> Database Driver Class Initialized
INFO - 2023-05-26 09:14:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:14:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:14:59 --> Final output sent to browser
INFO - 2023-05-26 09:14:59 --> Final output sent to browser
DEBUG - 2023-05-26 09:14:59 --> Total execution time: 0.1563
DEBUG - 2023-05-26 09:14:59 --> Total execution time: 0.1569
INFO - 2023-05-26 09:14:59 --> Database Driver Class Initialized
INFO - 2023-05-26 09:14:59 --> Config Class Initialized
INFO - 2023-05-26 09:14:59 --> Config Class Initialized
INFO - 2023-05-26 09:14:59 --> Hooks Class Initialized
INFO - 2023-05-26 09:14:59 --> Hooks Class Initialized
INFO - 2023-05-26 09:14:59 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 09:14:59 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:14:59 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:14:59 --> Utf8 Class Initialized
INFO - 2023-05-26 09:14:59 --> Utf8 Class Initialized
INFO - 2023-05-26 09:14:59 --> URI Class Initialized
INFO - 2023-05-26 09:14:59 --> URI Class Initialized
INFO - 2023-05-26 09:14:59 --> Router Class Initialized
INFO - 2023-05-26 09:14:59 --> Router Class Initialized
INFO - 2023-05-26 09:14:59 --> Final output sent to browser
DEBUG - 2023-05-26 09:14:59 --> Total execution time: 0.2407
INFO - 2023-05-26 09:14:59 --> Output Class Initialized
INFO - 2023-05-26 09:14:59 --> Output Class Initialized
INFO - 2023-05-26 09:14:59 --> Security Class Initialized
INFO - 2023-05-26 09:14:59 --> Security Class Initialized
DEBUG - 2023-05-26 09:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:14:59 --> Input Class Initialized
INFO - 2023-05-26 09:14:59 --> Input Class Initialized
INFO - 2023-05-26 09:14:59 --> Language Class Initialized
INFO - 2023-05-26 09:14:59 --> Language Class Initialized
INFO - 2023-05-26 09:14:59 --> Loader Class Initialized
INFO - 2023-05-26 09:14:59 --> Loader Class Initialized
INFO - 2023-05-26 09:14:59 --> Controller Class Initialized
INFO - 2023-05-26 09:14:59 --> Controller Class Initialized
DEBUG - 2023-05-26 09:14:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:14:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:14:59 --> Database Driver Class Initialized
INFO - 2023-05-26 09:14:59 --> Database Driver Class Initialized
INFO - 2023-05-26 09:14:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:14:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:15:00 --> Final output sent to browser
INFO - 2023-05-26 09:15:00 --> Final output sent to browser
DEBUG - 2023-05-26 09:15:00 --> Total execution time: 0.4656
DEBUG - 2023-05-26 09:15:00 --> Total execution time: 0.4648
INFO - 2023-05-26 09:15:00 --> Config Class Initialized
INFO - 2023-05-26 09:15:00 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:15:00 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:15:00 --> Utf8 Class Initialized
INFO - 2023-05-26 09:15:00 --> URI Class Initialized
INFO - 2023-05-26 09:15:00 --> Router Class Initialized
INFO - 2023-05-26 09:15:00 --> Output Class Initialized
INFO - 2023-05-26 09:15:00 --> Security Class Initialized
DEBUG - 2023-05-26 09:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:15:00 --> Input Class Initialized
INFO - 2023-05-26 09:15:00 --> Language Class Initialized
INFO - 2023-05-26 09:15:00 --> Loader Class Initialized
INFO - 2023-05-26 09:15:00 --> Controller Class Initialized
DEBUG - 2023-05-26 09:15:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:15:00 --> Database Driver Class Initialized
INFO - 2023-05-26 09:15:00 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:15:00 --> Config Class Initialized
INFO - 2023-05-26 09:15:00 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:15:00 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:15:00 --> Utf8 Class Initialized
INFO - 2023-05-26 09:15:00 --> URI Class Initialized
INFO - 2023-05-26 09:15:00 --> Router Class Initialized
INFO - 2023-05-26 09:15:00 --> Output Class Initialized
INFO - 2023-05-26 09:15:00 --> Security Class Initialized
DEBUG - 2023-05-26 09:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:15:00 --> Input Class Initialized
INFO - 2023-05-26 09:15:00 --> Language Class Initialized
INFO - 2023-05-26 09:15:00 --> Loader Class Initialized
INFO - 2023-05-26 09:15:00 --> Controller Class Initialized
DEBUG - 2023-05-26 09:15:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:15:00 --> Database Driver Class Initialized
INFO - 2023-05-26 09:15:00 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:25:20 --> Config Class Initialized
INFO - 2023-05-26 09:25:20 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:25:20 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:25:20 --> Utf8 Class Initialized
INFO - 2023-05-26 09:25:20 --> URI Class Initialized
INFO - 2023-05-26 09:25:20 --> Router Class Initialized
INFO - 2023-05-26 09:25:20 --> Output Class Initialized
INFO - 2023-05-26 09:25:20 --> Security Class Initialized
DEBUG - 2023-05-26 09:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:25:20 --> Input Class Initialized
INFO - 2023-05-26 09:25:20 --> Language Class Initialized
INFO - 2023-05-26 09:25:20 --> Loader Class Initialized
INFO - 2023-05-26 09:25:20 --> Controller Class Initialized
DEBUG - 2023-05-26 09:25:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:25:20 --> Database Driver Class Initialized
INFO - 2023-05-26 09:25:20 --> Model "Login_model" initialized
INFO - 2023-05-26 09:25:20 --> Database Driver Class Initialized
INFO - 2023-05-26 09:25:20 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:25:20 --> Final output sent to browser
DEBUG - 2023-05-26 09:25:20 --> Total execution time: 0.3901
INFO - 2023-05-26 09:25:20 --> Config Class Initialized
INFO - 2023-05-26 09:25:20 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:25:20 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:25:20 --> Utf8 Class Initialized
INFO - 2023-05-26 09:25:20 --> URI Class Initialized
INFO - 2023-05-26 09:25:20 --> Router Class Initialized
INFO - 2023-05-26 09:25:21 --> Output Class Initialized
INFO - 2023-05-26 09:25:21 --> Security Class Initialized
DEBUG - 2023-05-26 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:25:21 --> Input Class Initialized
INFO - 2023-05-26 09:25:21 --> Language Class Initialized
INFO - 2023-05-26 09:25:21 --> Config Class Initialized
INFO - 2023-05-26 09:25:21 --> Hooks Class Initialized
INFO - 2023-05-26 09:25:21 --> Loader Class Initialized
INFO - 2023-05-26 09:25:21 --> Controller Class Initialized
DEBUG - 2023-05-26 09:25:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:25:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:25:21 --> Utf8 Class Initialized
INFO - 2023-05-26 09:25:21 --> URI Class Initialized
INFO - 2023-05-26 09:25:21 --> Router Class Initialized
INFO - 2023-05-26 09:25:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:25:21 --> Output Class Initialized
INFO - 2023-05-26 09:25:21 --> Model "Login_model" initialized
INFO - 2023-05-26 09:25:21 --> Security Class Initialized
DEBUG - 2023-05-26 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:25:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:25:21 --> Input Class Initialized
INFO - 2023-05-26 09:25:21 --> Language Class Initialized
INFO - 2023-05-26 09:25:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:25:21 --> Final output sent to browser
DEBUG - 2023-05-26 09:25:21 --> Total execution time: 0.3670
INFO - 2023-05-26 09:25:21 --> Loader Class Initialized
INFO - 2023-05-26 09:25:21 --> Controller Class Initialized
DEBUG - 2023-05-26 09:25:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:25:21 --> Config Class Initialized
INFO - 2023-05-26 09:25:21 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:25:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:25:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:25:21 --> Utf8 Class Initialized
INFO - 2023-05-26 09:25:21 --> URI Class Initialized
INFO - 2023-05-26 09:25:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:25:21 --> Router Class Initialized
INFO - 2023-05-26 09:25:21 --> Output Class Initialized
INFO - 2023-05-26 09:25:21 --> Final output sent to browser
INFO - 2023-05-26 09:25:21 --> Security Class Initialized
DEBUG - 2023-05-26 09:25:21 --> Total execution time: 0.3698
DEBUG - 2023-05-26 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:25:21 --> Input Class Initialized
INFO - 2023-05-26 09:25:21 --> Config Class Initialized
INFO - 2023-05-26 09:25:21 --> Language Class Initialized
INFO - 2023-05-26 09:25:21 --> Hooks Class Initialized
INFO - 2023-05-26 09:25:21 --> Loader Class Initialized
DEBUG - 2023-05-26 09:25:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:25:21 --> Utf8 Class Initialized
INFO - 2023-05-26 09:25:21 --> Controller Class Initialized
INFO - 2023-05-26 09:25:21 --> URI Class Initialized
DEBUG - 2023-05-26 09:25:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:25:21 --> Final output sent to browser
DEBUG - 2023-05-26 09:25:21 --> Total execution time: 0.2130
INFO - 2023-05-26 09:25:21 --> Router Class Initialized
INFO - 2023-05-26 09:25:21 --> Output Class Initialized
INFO - 2023-05-26 09:25:21 --> Security Class Initialized
DEBUG - 2023-05-26 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:25:21 --> Input Class Initialized
INFO - 2023-05-26 09:25:21 --> Config Class Initialized
INFO - 2023-05-26 09:25:21 --> Language Class Initialized
INFO - 2023-05-26 09:25:21 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:25:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:25:21 --> Utf8 Class Initialized
INFO - 2023-05-26 09:25:21 --> Loader Class Initialized
INFO - 2023-05-26 09:25:21 --> URI Class Initialized
INFO - 2023-05-26 09:25:21 --> Controller Class Initialized
DEBUG - 2023-05-26 09:25:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:25:21 --> Router Class Initialized
INFO - 2023-05-26 09:25:21 --> Output Class Initialized
INFO - 2023-05-26 09:25:21 --> Security Class Initialized
INFO - 2023-05-26 09:25:21 --> Database Driver Class Initialized
DEBUG - 2023-05-26 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:25:21 --> Input Class Initialized
INFO - 2023-05-26 09:25:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:25:21 --> Language Class Initialized
INFO - 2023-05-26 09:25:21 --> Final output sent to browser
DEBUG - 2023-05-26 09:25:21 --> Total execution time: 0.2695
INFO - 2023-05-26 09:25:21 --> Loader Class Initialized
INFO - 2023-05-26 09:25:21 --> Controller Class Initialized
DEBUG - 2023-05-26 09:25:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:25:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:25:21 --> Model "Login_model" initialized
INFO - 2023-05-26 09:25:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:25:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:25:21 --> Final output sent to browser
DEBUG - 2023-05-26 09:25:21 --> Total execution time: 0.3542
INFO - 2023-05-26 09:29:44 --> Config Class Initialized
INFO - 2023-05-26 09:29:44 --> Config Class Initialized
INFO - 2023-05-26 09:29:44 --> Hooks Class Initialized
INFO - 2023-05-26 09:29:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:29:44 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:29:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:29:44 --> Utf8 Class Initialized
INFO - 2023-05-26 09:29:44 --> Utf8 Class Initialized
INFO - 2023-05-26 09:29:44 --> URI Class Initialized
INFO - 2023-05-26 09:29:44 --> URI Class Initialized
INFO - 2023-05-26 09:29:44 --> Router Class Initialized
INFO - 2023-05-26 09:29:44 --> Router Class Initialized
INFO - 2023-05-26 09:29:44 --> Output Class Initialized
INFO - 2023-05-26 09:29:44 --> Output Class Initialized
INFO - 2023-05-26 09:29:44 --> Security Class Initialized
INFO - 2023-05-26 09:29:44 --> Security Class Initialized
DEBUG - 2023-05-26 09:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:29:44 --> Input Class Initialized
INFO - 2023-05-26 09:29:44 --> Input Class Initialized
INFO - 2023-05-26 09:29:44 --> Language Class Initialized
INFO - 2023-05-26 09:29:44 --> Language Class Initialized
INFO - 2023-05-26 09:29:44 --> Loader Class Initialized
INFO - 2023-05-26 09:29:44 --> Loader Class Initialized
INFO - 2023-05-26 09:29:44 --> Controller Class Initialized
DEBUG - 2023-05-26 09:29:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:29:44 --> Controller Class Initialized
DEBUG - 2023-05-26 09:29:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:29:44 --> Database Driver Class Initialized
INFO - 2023-05-26 09:29:44 --> Database Driver Class Initialized
INFO - 2023-05-26 09:29:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:29:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:29:44 --> Final output sent to browser
DEBUG - 2023-05-26 09:29:44 --> Total execution time: 0.1984
INFO - 2023-05-26 09:29:44 --> Database Driver Class Initialized
INFO - 2023-05-26 09:29:44 --> Model "Login_model" initialized
INFO - 2023-05-26 09:29:44 --> Config Class Initialized
INFO - 2023-05-26 09:29:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:29:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:29:44 --> Utf8 Class Initialized
INFO - 2023-05-26 09:29:44 --> URI Class Initialized
INFO - 2023-05-26 09:29:44 --> Router Class Initialized
INFO - 2023-05-26 09:29:44 --> Output Class Initialized
INFO - 2023-05-26 09:29:44 --> Security Class Initialized
DEBUG - 2023-05-26 09:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:29:44 --> Input Class Initialized
INFO - 2023-05-26 09:29:44 --> Language Class Initialized
INFO - 2023-05-26 09:29:44 --> Loader Class Initialized
INFO - 2023-05-26 09:29:44 --> Controller Class Initialized
DEBUG - 2023-05-26 09:29:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:29:44 --> Database Driver Class Initialized
INFO - 2023-05-26 09:29:44 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:29:44 --> Final output sent to browser
DEBUG - 2023-05-26 09:29:44 --> Total execution time: 0.5303
INFO - 2023-05-26 09:29:44 --> Final output sent to browser
DEBUG - 2023-05-26 09:29:44 --> Total execution time: 0.2999
INFO - 2023-05-26 09:29:44 --> Config Class Initialized
INFO - 2023-05-26 09:29:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:29:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:29:44 --> Utf8 Class Initialized
INFO - 2023-05-26 09:29:44 --> URI Class Initialized
INFO - 2023-05-26 09:29:44 --> Router Class Initialized
INFO - 2023-05-26 09:29:44 --> Output Class Initialized
INFO - 2023-05-26 09:29:44 --> Security Class Initialized
DEBUG - 2023-05-26 09:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:29:44 --> Input Class Initialized
INFO - 2023-05-26 09:29:45 --> Language Class Initialized
INFO - 2023-05-26 09:29:45 --> Loader Class Initialized
INFO - 2023-05-26 09:29:45 --> Controller Class Initialized
DEBUG - 2023-05-26 09:29:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:29:45 --> Database Driver Class Initialized
INFO - 2023-05-26 09:29:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:29:45 --> Database Driver Class Initialized
INFO - 2023-05-26 09:29:45 --> Model "Login_model" initialized
INFO - 2023-05-26 09:29:45 --> Final output sent to browser
DEBUG - 2023-05-26 09:29:45 --> Total execution time: 0.4138
INFO - 2023-05-26 09:33:47 --> Config Class Initialized
INFO - 2023-05-26 09:33:47 --> Config Class Initialized
INFO - 2023-05-26 09:33:47 --> Config Class Initialized
INFO - 2023-05-26 09:33:47 --> Hooks Class Initialized
INFO - 2023-05-26 09:33:47 --> Hooks Class Initialized
INFO - 2023-05-26 09:33:47 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:33:47 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:33:47 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:33:47 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:33:47 --> Utf8 Class Initialized
INFO - 2023-05-26 09:33:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:33:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:33:48 --> URI Class Initialized
INFO - 2023-05-26 09:33:48 --> URI Class Initialized
INFO - 2023-05-26 09:33:48 --> URI Class Initialized
INFO - 2023-05-26 09:33:48 --> Router Class Initialized
INFO - 2023-05-26 09:33:48 --> Router Class Initialized
INFO - 2023-05-26 09:33:48 --> Router Class Initialized
INFO - 2023-05-26 09:33:48 --> Output Class Initialized
INFO - 2023-05-26 09:33:48 --> Output Class Initialized
INFO - 2023-05-26 09:33:48 --> Output Class Initialized
INFO - 2023-05-26 09:33:48 --> Security Class Initialized
INFO - 2023-05-26 09:33:48 --> Security Class Initialized
INFO - 2023-05-26 09:33:48 --> Security Class Initialized
DEBUG - 2023-05-26 09:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:33:48 --> Input Class Initialized
INFO - 2023-05-26 09:33:48 --> Input Class Initialized
INFO - 2023-05-26 09:33:48 --> Input Class Initialized
INFO - 2023-05-26 09:33:48 --> Language Class Initialized
INFO - 2023-05-26 09:33:48 --> Language Class Initialized
INFO - 2023-05-26 09:33:48 --> Language Class Initialized
INFO - 2023-05-26 09:33:48 --> Loader Class Initialized
INFO - 2023-05-26 09:33:48 --> Loader Class Initialized
INFO - 2023-05-26 09:33:48 --> Loader Class Initialized
INFO - 2023-05-26 09:33:48 --> Config Class Initialized
INFO - 2023-05-26 09:33:48 --> Hooks Class Initialized
INFO - 2023-05-26 09:33:48 --> Controller Class Initialized
INFO - 2023-05-26 09:33:48 --> Controller Class Initialized
INFO - 2023-05-26 09:33:48 --> Controller Class Initialized
DEBUG - 2023-05-26 09:33:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:33:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:33:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:33:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:33:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:33:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:33:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:33:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:33:48 --> URI Class Initialized
INFO - 2023-05-26 09:33:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:33:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:33:48 --> Router Class Initialized
INFO - 2023-05-26 09:33:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:33:48 --> Output Class Initialized
INFO - 2023-05-26 09:33:48 --> Model "Login_model" initialized
INFO - 2023-05-26 09:33:48 --> Security Class Initialized
DEBUG - 2023-05-26 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:33:48 --> Input Class Initialized
INFO - 2023-05-26 09:33:48 --> Final output sent to browser
INFO - 2023-05-26 09:33:48 --> Final output sent to browser
DEBUG - 2023-05-26 09:33:48 --> Total execution time: 0.2530
INFO - 2023-05-26 09:33:48 --> Language Class Initialized
DEBUG - 2023-05-26 09:33:48 --> Total execution time: 0.2605
INFO - 2023-05-26 09:33:48 --> Final output sent to browser
DEBUG - 2023-05-26 09:33:48 --> Total execution time: 0.2715
INFO - 2023-05-26 09:33:48 --> Loader Class Initialized
INFO - 2023-05-26 09:33:48 --> Config Class Initialized
INFO - 2023-05-26 09:33:48 --> Config Class Initialized
INFO - 2023-05-26 09:33:48 --> Hooks Class Initialized
INFO - 2023-05-26 09:33:48 --> Hooks Class Initialized
INFO - 2023-05-26 09:33:48 --> Controller Class Initialized
DEBUG - 2023-05-26 09:33:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:33:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:33:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:33:48 --> Config Class Initialized
INFO - 2023-05-26 09:33:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:33:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:33:48 --> Hooks Class Initialized
INFO - 2023-05-26 09:33:48 --> URI Class Initialized
INFO - 2023-05-26 09:33:48 --> URI Class Initialized
INFO - 2023-05-26 09:33:48 --> Router Class Initialized
INFO - 2023-05-26 09:33:48 --> Router Class Initialized
DEBUG - 2023-05-26 09:33:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:33:48 --> Output Class Initialized
INFO - 2023-05-26 09:33:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:33:48 --> Output Class Initialized
INFO - 2023-05-26 09:33:48 --> URI Class Initialized
INFO - 2023-05-26 09:33:48 --> Security Class Initialized
INFO - 2023-05-26 09:33:48 --> Security Class Initialized
DEBUG - 2023-05-26 09:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:33:48 --> Input Class Initialized
INFO - 2023-05-26 09:33:48 --> Input Class Initialized
INFO - 2023-05-26 09:33:48 --> Language Class Initialized
INFO - 2023-05-26 09:33:48 --> Router Class Initialized
INFO - 2023-05-26 09:33:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:33:48 --> Language Class Initialized
INFO - 2023-05-26 09:33:48 --> Output Class Initialized
INFO - 2023-05-26 09:33:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:33:48 --> Loader Class Initialized
INFO - 2023-05-26 09:33:48 --> Loader Class Initialized
INFO - 2023-05-26 09:33:48 --> Security Class Initialized
INFO - 2023-05-26 09:33:48 --> Controller Class Initialized
INFO - 2023-05-26 09:33:48 --> Controller Class Initialized
DEBUG - 2023-05-26 09:33:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:33:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:33:48 --> Input Class Initialized
INFO - 2023-05-26 09:33:48 --> Language Class Initialized
INFO - 2023-05-26 09:33:48 --> Final output sent to browser
DEBUG - 2023-05-26 09:33:48 --> Total execution time: 0.3773
INFO - 2023-05-26 09:33:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:33:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:33:48 --> Loader Class Initialized
INFO - 2023-05-26 09:33:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:33:48 --> Controller Class Initialized
DEBUG - 2023-05-26 09:33:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:33:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:33:48 --> Config Class Initialized
INFO - 2023-05-26 09:33:48 --> Final output sent to browser
DEBUG - 2023-05-26 09:33:48 --> Total execution time: 0.2478
INFO - 2023-05-26 09:33:48 --> Hooks Class Initialized
INFO - 2023-05-26 09:33:48 --> Model "Login_model" initialized
INFO - 2023-05-26 09:33:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:33:48 --> Final output sent to browser
DEBUG - 2023-05-26 09:33:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:33:48 --> Total execution time: 0.2793
INFO - 2023-05-26 09:33:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:33:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:33:48 --> URI Class Initialized
INFO - 2023-05-26 09:33:48 --> Router Class Initialized
INFO - 2023-05-26 09:33:48 --> Output Class Initialized
INFO - 2023-05-26 09:33:48 --> Security Class Initialized
DEBUG - 2023-05-26 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:33:48 --> Input Class Initialized
INFO - 2023-05-26 09:33:48 --> Final output sent to browser
DEBUG - 2023-05-26 09:33:48 --> Total execution time: 0.3301
INFO - 2023-05-26 09:33:48 --> Language Class Initialized
INFO - 2023-05-26 09:33:48 --> Loader Class Initialized
INFO - 2023-05-26 09:33:48 --> Controller Class Initialized
DEBUG - 2023-05-26 09:33:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:33:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:33:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:33:48 --> Final output sent to browser
DEBUG - 2023-05-26 09:33:48 --> Total execution time: 0.2701
INFO - 2023-05-26 09:34:48 --> Config Class Initialized
INFO - 2023-05-26 09:34:48 --> Config Class Initialized
INFO - 2023-05-26 09:34:48 --> Hooks Class Initialized
INFO - 2023-05-26 09:34:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:34:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:34:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:34:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:34:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:34:48 --> URI Class Initialized
INFO - 2023-05-26 09:34:48 --> URI Class Initialized
INFO - 2023-05-26 09:34:48 --> Router Class Initialized
INFO - 2023-05-26 09:34:48 --> Router Class Initialized
INFO - 2023-05-26 09:34:48 --> Output Class Initialized
INFO - 2023-05-26 09:34:48 --> Output Class Initialized
INFO - 2023-05-26 09:34:48 --> Security Class Initialized
INFO - 2023-05-26 09:34:48 --> Security Class Initialized
DEBUG - 2023-05-26 09:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:34:48 --> Input Class Initialized
INFO - 2023-05-26 09:34:48 --> Input Class Initialized
INFO - 2023-05-26 09:34:48 --> Language Class Initialized
INFO - 2023-05-26 09:34:48 --> Language Class Initialized
INFO - 2023-05-26 09:34:48 --> Loader Class Initialized
INFO - 2023-05-26 09:34:48 --> Loader Class Initialized
INFO - 2023-05-26 09:34:48 --> Controller Class Initialized
INFO - 2023-05-26 09:34:48 --> Controller Class Initialized
DEBUG - 2023-05-26 09:34:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:34:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:34:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:34:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:34:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:34:50 --> Database Driver Class Initialized
INFO - 2023-05-26 09:34:52 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:34:55 --> Model "Login_model" initialized
INFO - 2023-05-26 09:34:55 --> Final output sent to browser
DEBUG - 2023-05-26 09:34:55 --> Total execution time: 6.8395
INFO - 2023-05-26 09:34:55 --> Config Class Initialized
INFO - 2023-05-26 09:34:55 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:34:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:34:55 --> Utf8 Class Initialized
INFO - 2023-05-26 09:34:55 --> URI Class Initialized
INFO - 2023-05-26 09:34:55 --> Router Class Initialized
INFO - 2023-05-26 09:34:55 --> Output Class Initialized
INFO - 2023-05-26 09:34:55 --> Security Class Initialized
DEBUG - 2023-05-26 09:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:34:55 --> Input Class Initialized
INFO - 2023-05-26 09:34:55 --> Language Class Initialized
INFO - 2023-05-26 09:34:55 --> Loader Class Initialized
INFO - 2023-05-26 09:34:55 --> Controller Class Initialized
DEBUG - 2023-05-26 09:34:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:34:55 --> Database Driver Class Initialized
INFO - 2023-05-26 09:34:55 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:34:55 --> Final output sent to browser
DEBUG - 2023-05-26 09:34:55 --> Total execution time: 0.2081
INFO - 2023-05-26 09:35:07 --> Final output sent to browser
DEBUG - 2023-05-26 09:35:07 --> Total execution time: 19.1556
INFO - 2023-05-26 09:35:07 --> Config Class Initialized
INFO - 2023-05-26 09:35:07 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:35:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:35:07 --> Utf8 Class Initialized
INFO - 2023-05-26 09:35:07 --> URI Class Initialized
INFO - 2023-05-26 09:35:07 --> Router Class Initialized
INFO - 2023-05-26 09:35:07 --> Output Class Initialized
INFO - 2023-05-26 09:35:07 --> Security Class Initialized
DEBUG - 2023-05-26 09:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:35:07 --> Input Class Initialized
INFO - 2023-05-26 09:35:07 --> Language Class Initialized
INFO - 2023-05-26 09:35:07 --> Loader Class Initialized
INFO - 2023-05-26 09:35:07 --> Controller Class Initialized
DEBUG - 2023-05-26 09:35:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:35:07 --> Database Driver Class Initialized
INFO - 2023-05-26 09:35:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:35:07 --> Database Driver Class Initialized
INFO - 2023-05-26 09:35:07 --> Model "Login_model" initialized
INFO - 2023-05-26 09:35:14 --> Final output sent to browser
DEBUG - 2023-05-26 09:35:14 --> Total execution time: 7.3567
INFO - 2023-05-26 09:35:48 --> Config Class Initialized
INFO - 2023-05-26 09:35:48 --> Config Class Initialized
INFO - 2023-05-26 09:35:48 --> Hooks Class Initialized
INFO - 2023-05-26 09:35:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:35:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:35:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:35:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:35:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:35:48 --> URI Class Initialized
INFO - 2023-05-26 09:35:48 --> URI Class Initialized
INFO - 2023-05-26 09:35:48 --> Router Class Initialized
INFO - 2023-05-26 09:35:48 --> Router Class Initialized
INFO - 2023-05-26 09:35:48 --> Output Class Initialized
INFO - 2023-05-26 09:35:48 --> Output Class Initialized
INFO - 2023-05-26 09:35:48 --> Security Class Initialized
INFO - 2023-05-26 09:35:48 --> Security Class Initialized
DEBUG - 2023-05-26 09:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:35:48 --> Input Class Initialized
INFO - 2023-05-26 09:35:48 --> Input Class Initialized
INFO - 2023-05-26 09:35:48 --> Language Class Initialized
INFO - 2023-05-26 09:35:48 --> Language Class Initialized
INFO - 2023-05-26 09:35:48 --> Loader Class Initialized
INFO - 2023-05-26 09:35:48 --> Loader Class Initialized
INFO - 2023-05-26 09:35:48 --> Controller Class Initialized
DEBUG - 2023-05-26 09:35:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:35:48 --> Controller Class Initialized
DEBUG - 2023-05-26 09:35:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:35:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:35:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:35:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:35:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:35:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:35:48 --> Model "Login_model" initialized
INFO - 2023-05-26 09:35:48 --> Config Class Initialized
INFO - 2023-05-26 09:35:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:35:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:35:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:35:48 --> URI Class Initialized
INFO - 2023-05-26 09:35:48 --> Router Class Initialized
INFO - 2023-05-26 09:35:48 --> Output Class Initialized
INFO - 2023-05-26 09:35:48 --> Security Class Initialized
DEBUG - 2023-05-26 09:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:35:48 --> Input Class Initialized
INFO - 2023-05-26 09:35:48 --> Language Class Initialized
INFO - 2023-05-26 09:35:48 --> Loader Class Initialized
INFO - 2023-05-26 09:35:48 --> Controller Class Initialized
DEBUG - 2023-05-26 09:35:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:35:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:35:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:35:59 --> Final output sent to browser
DEBUG - 2023-05-26 09:35:59 --> Total execution time: 10.9370
INFO - 2023-05-26 09:35:59 --> Config Class Initialized
INFO - 2023-05-26 09:35:59 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:35:59 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:35:59 --> Utf8 Class Initialized
INFO - 2023-05-26 09:35:59 --> URI Class Initialized
INFO - 2023-05-26 09:35:59 --> Router Class Initialized
INFO - 2023-05-26 09:35:59 --> Output Class Initialized
INFO - 2023-05-26 09:35:59 --> Security Class Initialized
DEBUG - 2023-05-26 09:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:35:59 --> Input Class Initialized
INFO - 2023-05-26 09:35:59 --> Language Class Initialized
INFO - 2023-05-26 09:35:59 --> Loader Class Initialized
INFO - 2023-05-26 09:35:59 --> Controller Class Initialized
DEBUG - 2023-05-26 09:35:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:35:59 --> Database Driver Class Initialized
INFO - 2023-05-26 09:35:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:35:59 --> Database Driver Class Initialized
INFO - 2023-05-26 09:35:59 --> Model "Login_model" initialized
INFO - 2023-05-26 09:36:10 --> Final output sent to browser
DEBUG - 2023-05-26 09:36:10 --> Total execution time: 11.3925
INFO - 2023-05-26 09:36:48 --> Config Class Initialized
INFO - 2023-05-26 09:36:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:36:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:36:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:36:48 --> URI Class Initialized
INFO - 2023-05-26 09:36:48 --> Router Class Initialized
INFO - 2023-05-26 09:36:48 --> Output Class Initialized
INFO - 2023-05-26 09:36:48 --> Security Class Initialized
DEBUG - 2023-05-26 09:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:36:48 --> Input Class Initialized
INFO - 2023-05-26 09:36:48 --> Language Class Initialized
INFO - 2023-05-26 09:36:48 --> Loader Class Initialized
INFO - 2023-05-26 09:36:48 --> Controller Class Initialized
DEBUG - 2023-05-26 09:36:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:36:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:36:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:36:48 --> Config Class Initialized
INFO - 2023-05-26 09:36:48 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:36:48 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:36:48 --> Utf8 Class Initialized
INFO - 2023-05-26 09:36:48 --> URI Class Initialized
INFO - 2023-05-26 09:36:48 --> Router Class Initialized
INFO - 2023-05-26 09:36:48 --> Output Class Initialized
INFO - 2023-05-26 09:36:48 --> Security Class Initialized
DEBUG - 2023-05-26 09:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:36:48 --> Input Class Initialized
INFO - 2023-05-26 09:36:48 --> Language Class Initialized
INFO - 2023-05-26 09:36:48 --> Loader Class Initialized
INFO - 2023-05-26 09:36:48 --> Controller Class Initialized
DEBUG - 2023-05-26 09:36:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:36:48 --> Database Driver Class Initialized
INFO - 2023-05-26 09:36:48 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:37:06 --> Config Class Initialized
INFO - 2023-05-26 09:37:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:37:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:37:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:37:06 --> URI Class Initialized
INFO - 2023-05-26 09:37:06 --> Router Class Initialized
INFO - 2023-05-26 09:37:06 --> Output Class Initialized
INFO - 2023-05-26 09:37:06 --> Security Class Initialized
DEBUG - 2023-05-26 09:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:37:06 --> Input Class Initialized
INFO - 2023-05-26 09:37:06 --> Language Class Initialized
INFO - 2023-05-26 09:37:06 --> Loader Class Initialized
INFO - 2023-05-26 09:37:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:37:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:37:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:37:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:37:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:37:06 --> Model "Login_model" initialized
INFO - 2023-05-26 09:37:30 --> Final output sent to browser
DEBUG - 2023-05-26 09:37:30 --> Total execution time: 24.3549
INFO - 2023-05-26 09:37:30 --> Config Class Initialized
INFO - 2023-05-26 09:37:30 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:37:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:37:30 --> Utf8 Class Initialized
INFO - 2023-05-26 09:37:30 --> URI Class Initialized
INFO - 2023-05-26 09:37:30 --> Router Class Initialized
INFO - 2023-05-26 09:37:30 --> Output Class Initialized
INFO - 2023-05-26 09:37:30 --> Security Class Initialized
DEBUG - 2023-05-26 09:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:37:30 --> Input Class Initialized
INFO - 2023-05-26 09:37:30 --> Language Class Initialized
INFO - 2023-05-26 09:37:30 --> Loader Class Initialized
INFO - 2023-05-26 09:37:30 --> Controller Class Initialized
DEBUG - 2023-05-26 09:37:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:37:30 --> Database Driver Class Initialized
INFO - 2023-05-26 09:37:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:37:31 --> Database Driver Class Initialized
INFO - 2023-05-26 09:37:31 --> Model "Login_model" initialized
INFO - 2023-05-26 09:37:45 --> Final output sent to browser
DEBUG - 2023-05-26 09:37:45 --> Total execution time: 15.0713
INFO - 2023-05-26 09:38:06 --> Config Class Initialized
INFO - 2023-05-26 09:38:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:38:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:38:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:38:06 --> URI Class Initialized
INFO - 2023-05-26 09:38:06 --> Router Class Initialized
INFO - 2023-05-26 09:38:06 --> Output Class Initialized
INFO - 2023-05-26 09:38:06 --> Security Class Initialized
DEBUG - 2023-05-26 09:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:38:06 --> Input Class Initialized
INFO - 2023-05-26 09:38:06 --> Language Class Initialized
INFO - 2023-05-26 09:38:06 --> Loader Class Initialized
INFO - 2023-05-26 09:38:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:38:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:38:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:38:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:38:06 --> Config Class Initialized
INFO - 2023-05-26 09:38:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:38:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:38:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:38:06 --> URI Class Initialized
INFO - 2023-05-26 09:38:06 --> Router Class Initialized
INFO - 2023-05-26 09:38:06 --> Output Class Initialized
INFO - 2023-05-26 09:38:06 --> Security Class Initialized
DEBUG - 2023-05-26 09:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:38:06 --> Input Class Initialized
INFO - 2023-05-26 09:38:06 --> Language Class Initialized
INFO - 2023-05-26 09:38:06 --> Loader Class Initialized
INFO - 2023-05-26 09:38:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:38:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:38:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:38:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:39:06 --> Config Class Initialized
INFO - 2023-05-26 09:39:06 --> Config Class Initialized
INFO - 2023-05-26 09:39:06 --> Hooks Class Initialized
INFO - 2023-05-26 09:39:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:39:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:39:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:39:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:39:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:39:06 --> URI Class Initialized
INFO - 2023-05-26 09:39:06 --> URI Class Initialized
INFO - 2023-05-26 09:39:06 --> Router Class Initialized
INFO - 2023-05-26 09:39:06 --> Router Class Initialized
INFO - 2023-05-26 09:39:06 --> Output Class Initialized
INFO - 2023-05-26 09:39:06 --> Output Class Initialized
INFO - 2023-05-26 09:39:06 --> Security Class Initialized
INFO - 2023-05-26 09:39:06 --> Security Class Initialized
DEBUG - 2023-05-26 09:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:39:06 --> Input Class Initialized
INFO - 2023-05-26 09:39:06 --> Input Class Initialized
INFO - 2023-05-26 09:39:06 --> Language Class Initialized
INFO - 2023-05-26 09:39:06 --> Language Class Initialized
INFO - 2023-05-26 09:39:06 --> Loader Class Initialized
INFO - 2023-05-26 09:39:06 --> Loader Class Initialized
INFO - 2023-05-26 09:39:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:39:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:39:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:39:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:39:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:39:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:39:10 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:39:13 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:39:13 --> Database Driver Class Initialized
INFO - 2023-05-26 09:39:14 --> Config Class Initialized
INFO - 2023-05-26 09:39:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:39:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:39:14 --> Utf8 Class Initialized
INFO - 2023-05-26 09:39:14 --> URI Class Initialized
INFO - 2023-05-26 09:39:14 --> Router Class Initialized
INFO - 2023-05-26 09:39:14 --> Output Class Initialized
INFO - 2023-05-26 09:39:14 --> Security Class Initialized
DEBUG - 2023-05-26 09:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:39:14 --> Input Class Initialized
INFO - 2023-05-26 09:39:14 --> Language Class Initialized
INFO - 2023-05-26 09:39:14 --> Loader Class Initialized
INFO - 2023-05-26 09:39:14 --> Controller Class Initialized
DEBUG - 2023-05-26 09:39:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:39:14 --> Database Driver Class Initialized
INFO - 2023-05-26 09:39:17 --> Model "Login_model" initialized
INFO - 2023-05-26 09:39:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:39:55 --> Final output sent to browser
DEBUG - 2023-05-26 09:39:55 --> Total execution time: 48.7512
INFO - 2023-05-26 09:39:55 --> Config Class Initialized
INFO - 2023-05-26 09:39:55 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:39:55 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:39:55 --> Utf8 Class Initialized
INFO - 2023-05-26 09:39:55 --> URI Class Initialized
INFO - 2023-05-26 09:39:55 --> Router Class Initialized
INFO - 2023-05-26 09:39:55 --> Output Class Initialized
INFO - 2023-05-26 09:39:55 --> Security Class Initialized
DEBUG - 2023-05-26 09:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:39:55 --> Input Class Initialized
INFO - 2023-05-26 09:39:55 --> Language Class Initialized
INFO - 2023-05-26 09:39:55 --> Loader Class Initialized
INFO - 2023-05-26 09:39:55 --> Controller Class Initialized
DEBUG - 2023-05-26 09:39:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:39:55 --> Database Driver Class Initialized
INFO - 2023-05-26 09:39:55 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:39:55 --> Database Driver Class Initialized
INFO - 2023-05-26 09:39:55 --> Model "Login_model" initialized
INFO - 2023-05-26 09:40:06 --> Config Class Initialized
INFO - 2023-05-26 09:40:06 --> Config Class Initialized
INFO - 2023-05-26 09:40:06 --> Hooks Class Initialized
INFO - 2023-05-26 09:40:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:40:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:40:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:40:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:40:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:40:06 --> URI Class Initialized
INFO - 2023-05-26 09:40:06 --> URI Class Initialized
INFO - 2023-05-26 09:40:06 --> Router Class Initialized
INFO - 2023-05-26 09:40:06 --> Router Class Initialized
INFO - 2023-05-26 09:40:06 --> Output Class Initialized
INFO - 2023-05-26 09:40:06 --> Output Class Initialized
INFO - 2023-05-26 09:40:06 --> Security Class Initialized
INFO - 2023-05-26 09:40:06 --> Security Class Initialized
DEBUG - 2023-05-26 09:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:40:06 --> Input Class Initialized
INFO - 2023-05-26 09:40:06 --> Input Class Initialized
INFO - 2023-05-26 09:40:06 --> Language Class Initialized
INFO - 2023-05-26 09:40:06 --> Language Class Initialized
INFO - 2023-05-26 09:40:06 --> Loader Class Initialized
INFO - 2023-05-26 09:40:06 --> Loader Class Initialized
INFO - 2023-05-26 09:40:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:40:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:40:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:40:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:40:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:40:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:40:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:40:08 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:40:08 --> Database Driver Class Initialized
INFO - 2023-05-26 09:40:08 --> Model "Login_model" initialized
INFO - 2023-05-26 09:40:08 --> Config Class Initialized
INFO - 2023-05-26 09:40:08 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:40:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:40:08 --> Utf8 Class Initialized
INFO - 2023-05-26 09:40:08 --> URI Class Initialized
INFO - 2023-05-26 09:40:08 --> Router Class Initialized
INFO - 2023-05-26 09:40:08 --> Output Class Initialized
INFO - 2023-05-26 09:40:08 --> Security Class Initialized
DEBUG - 2023-05-26 09:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:40:08 --> Input Class Initialized
INFO - 2023-05-26 09:40:08 --> Language Class Initialized
INFO - 2023-05-26 09:40:08 --> Loader Class Initialized
INFO - 2023-05-26 09:40:08 --> Controller Class Initialized
DEBUG - 2023-05-26 09:40:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:40:08 --> Database Driver Class Initialized
INFO - 2023-05-26 09:40:10 --> Final output sent to browser
DEBUG - 2023-05-26 09:40:10 --> Total execution time: 15.3698
INFO - 2023-05-26 09:40:10 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:40:31 --> Final output sent to browser
DEBUG - 2023-05-26 09:40:31 --> Total execution time: 25.3312
INFO - 2023-05-26 09:40:31 --> Config Class Initialized
INFO - 2023-05-26 09:40:31 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:40:31 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:40:31 --> Utf8 Class Initialized
INFO - 2023-05-26 09:40:31 --> URI Class Initialized
INFO - 2023-05-26 09:40:31 --> Router Class Initialized
INFO - 2023-05-26 09:40:31 --> Output Class Initialized
INFO - 2023-05-26 09:40:31 --> Security Class Initialized
DEBUG - 2023-05-26 09:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:40:31 --> Input Class Initialized
INFO - 2023-05-26 09:40:31 --> Language Class Initialized
INFO - 2023-05-26 09:40:31 --> Loader Class Initialized
INFO - 2023-05-26 09:40:31 --> Controller Class Initialized
DEBUG - 2023-05-26 09:40:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:40:31 --> Database Driver Class Initialized
INFO - 2023-05-26 09:40:31 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:40:31 --> Database Driver Class Initialized
INFO - 2023-05-26 09:40:31 --> Model "Login_model" initialized
INFO - 2023-05-26 09:40:40 --> Final output sent to browser
DEBUG - 2023-05-26 09:40:40 --> Total execution time: 8.4427
INFO - 2023-05-26 09:41:06 --> Config Class Initialized
INFO - 2023-05-26 09:41:06 --> Config Class Initialized
INFO - 2023-05-26 09:41:06 --> Hooks Class Initialized
INFO - 2023-05-26 09:41:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:41:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:41:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:41:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:41:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:41:06 --> URI Class Initialized
INFO - 2023-05-26 09:41:06 --> URI Class Initialized
INFO - 2023-05-26 09:41:06 --> Router Class Initialized
INFO - 2023-05-26 09:41:06 --> Router Class Initialized
INFO - 2023-05-26 09:41:06 --> Output Class Initialized
INFO - 2023-05-26 09:41:06 --> Output Class Initialized
INFO - 2023-05-26 09:41:06 --> Security Class Initialized
INFO - 2023-05-26 09:41:06 --> Security Class Initialized
DEBUG - 2023-05-26 09:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:41:06 --> Input Class Initialized
INFO - 2023-05-26 09:41:06 --> Input Class Initialized
INFO - 2023-05-26 09:41:06 --> Language Class Initialized
INFO - 2023-05-26 09:41:06 --> Language Class Initialized
INFO - 2023-05-26 09:41:06 --> Loader Class Initialized
INFO - 2023-05-26 09:41:06 --> Loader Class Initialized
INFO - 2023-05-26 09:41:06 --> Controller Class Initialized
INFO - 2023-05-26 09:41:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:41:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:41:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:41:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:41:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:41:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:41:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:41:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:41:06 --> Model "Login_model" initialized
INFO - 2023-05-26 09:41:09 --> Config Class Initialized
INFO - 2023-05-26 09:41:09 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:41:09 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:41:09 --> Utf8 Class Initialized
INFO - 2023-05-26 09:41:09 --> URI Class Initialized
INFO - 2023-05-26 09:41:09 --> Router Class Initialized
INFO - 2023-05-26 09:41:10 --> Output Class Initialized
INFO - 2023-05-26 09:41:10 --> Security Class Initialized
DEBUG - 2023-05-26 09:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:41:10 --> Input Class Initialized
INFO - 2023-05-26 09:41:10 --> Language Class Initialized
INFO - 2023-05-26 09:41:10 --> Loader Class Initialized
INFO - 2023-05-26 09:41:10 --> Controller Class Initialized
DEBUG - 2023-05-26 09:41:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:41:10 --> Database Driver Class Initialized
INFO - 2023-05-26 09:41:10 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:41:27 --> Final output sent to browser
DEBUG - 2023-05-26 09:41:27 --> Total execution time: 21.2255
INFO - 2023-05-26 09:41:27 --> Config Class Initialized
INFO - 2023-05-26 09:41:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:41:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:41:27 --> Utf8 Class Initialized
INFO - 2023-05-26 09:41:27 --> URI Class Initialized
INFO - 2023-05-26 09:41:27 --> Router Class Initialized
INFO - 2023-05-26 09:41:27 --> Output Class Initialized
INFO - 2023-05-26 09:41:27 --> Security Class Initialized
DEBUG - 2023-05-26 09:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:41:27 --> Input Class Initialized
INFO - 2023-05-26 09:41:27 --> Language Class Initialized
INFO - 2023-05-26 09:41:27 --> Loader Class Initialized
INFO - 2023-05-26 09:41:27 --> Controller Class Initialized
DEBUG - 2023-05-26 09:41:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:41:27 --> Database Driver Class Initialized
INFO - 2023-05-26 09:41:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:41:27 --> Database Driver Class Initialized
INFO - 2023-05-26 09:41:27 --> Model "Login_model" initialized
INFO - 2023-05-26 09:41:38 --> Final output sent to browser
DEBUG - 2023-05-26 09:41:38 --> Total execution time: 11.4144
INFO - 2023-05-26 09:42:06 --> Config Class Initialized
INFO - 2023-05-26 09:42:06 --> Config Class Initialized
INFO - 2023-05-26 09:42:06 --> Hooks Class Initialized
INFO - 2023-05-26 09:42:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:42:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:42:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:42:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:42:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:42:06 --> URI Class Initialized
INFO - 2023-05-26 09:42:06 --> URI Class Initialized
INFO - 2023-05-26 09:42:06 --> Router Class Initialized
INFO - 2023-05-26 09:42:06 --> Router Class Initialized
INFO - 2023-05-26 09:42:06 --> Output Class Initialized
INFO - 2023-05-26 09:42:06 --> Output Class Initialized
INFO - 2023-05-26 09:42:06 --> Security Class Initialized
INFO - 2023-05-26 09:42:06 --> Security Class Initialized
DEBUG - 2023-05-26 09:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:42:06 --> Input Class Initialized
INFO - 2023-05-26 09:42:06 --> Input Class Initialized
INFO - 2023-05-26 09:42:06 --> Language Class Initialized
INFO - 2023-05-26 09:42:06 --> Language Class Initialized
INFO - 2023-05-26 09:42:06 --> Loader Class Initialized
INFO - 2023-05-26 09:42:06 --> Loader Class Initialized
INFO - 2023-05-26 09:42:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:42:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:42:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:42:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:42:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:42:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:42:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:06 --> Model "Login_model" initialized
INFO - 2023-05-26 09:42:06 --> Config Class Initialized
INFO - 2023-05-26 09:42:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:42:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:42:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:42:06 --> URI Class Initialized
INFO - 2023-05-26 09:42:06 --> Router Class Initialized
INFO - 2023-05-26 09:42:06 --> Output Class Initialized
INFO - 2023-05-26 09:42:06 --> Security Class Initialized
DEBUG - 2023-05-26 09:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:42:06 --> Input Class Initialized
INFO - 2023-05-26 09:42:06 --> Language Class Initialized
INFO - 2023-05-26 09:42:06 --> Loader Class Initialized
INFO - 2023-05-26 09:42:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:42:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:42:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:42:14 --> Final output sent to browser
DEBUG - 2023-05-26 09:42:14 --> Total execution time: 8.1422
INFO - 2023-05-26 09:42:14 --> Config Class Initialized
INFO - 2023-05-26 09:42:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:42:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:42:14 --> Utf8 Class Initialized
INFO - 2023-05-26 09:42:14 --> URI Class Initialized
INFO - 2023-05-26 09:42:14 --> Router Class Initialized
INFO - 2023-05-26 09:42:14 --> Output Class Initialized
INFO - 2023-05-26 09:42:14 --> Security Class Initialized
DEBUG - 2023-05-26 09:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:42:14 --> Input Class Initialized
INFO - 2023-05-26 09:42:14 --> Language Class Initialized
INFO - 2023-05-26 09:42:14 --> Loader Class Initialized
INFO - 2023-05-26 09:42:14 --> Controller Class Initialized
DEBUG - 2023-05-26 09:42:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:42:14 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:14 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:42:14 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:14 --> Model "Login_model" initialized
INFO - 2023-05-26 09:42:20 --> Config Class Initialized
INFO - 2023-05-26 09:42:20 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:42:20 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:42:20 --> Utf8 Class Initialized
INFO - 2023-05-26 09:42:20 --> URI Class Initialized
INFO - 2023-05-26 09:42:20 --> Router Class Initialized
INFO - 2023-05-26 09:42:20 --> Output Class Initialized
INFO - 2023-05-26 09:42:20 --> Security Class Initialized
DEBUG - 2023-05-26 09:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:42:20 --> Input Class Initialized
INFO - 2023-05-26 09:42:20 --> Language Class Initialized
INFO - 2023-05-26 09:42:20 --> Loader Class Initialized
INFO - 2023-05-26 09:42:20 --> Controller Class Initialized
DEBUG - 2023-05-26 09:42:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:42:20 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:20 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:42:20 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:20 --> Model "Login_model" initialized
INFO - 2023-05-26 09:42:22 --> Config Class Initialized
INFO - 2023-05-26 09:42:22 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:42:22 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:42:22 --> Utf8 Class Initialized
INFO - 2023-05-26 09:42:22 --> URI Class Initialized
INFO - 2023-05-26 09:42:22 --> Router Class Initialized
INFO - 2023-05-26 09:42:22 --> Output Class Initialized
INFO - 2023-05-26 09:42:22 --> Security Class Initialized
DEBUG - 2023-05-26 09:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:42:22 --> Input Class Initialized
INFO - 2023-05-26 09:42:22 --> Language Class Initialized
INFO - 2023-05-26 09:42:23 --> Loader Class Initialized
INFO - 2023-05-26 09:42:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:42:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:42:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:42:23 --> Config Class Initialized
INFO - 2023-05-26 09:42:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:42:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:42:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:42:23 --> URI Class Initialized
INFO - 2023-05-26 09:42:23 --> Router Class Initialized
INFO - 2023-05-26 09:42:23 --> Output Class Initialized
INFO - 2023-05-26 09:42:23 --> Security Class Initialized
DEBUG - 2023-05-26 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:42:23 --> Input Class Initialized
INFO - 2023-05-26 09:42:23 --> Language Class Initialized
INFO - 2023-05-26 09:42:23 --> Loader Class Initialized
INFO - 2023-05-26 09:42:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:42:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:42:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:42:23 --> Final output sent to browser
DEBUG - 2023-05-26 09:42:23 --> Total execution time: 0.2416
INFO - 2023-05-26 09:42:23 --> Config Class Initialized
INFO - 2023-05-26 09:42:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:42:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:42:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:42:23 --> URI Class Initialized
INFO - 2023-05-26 09:42:23 --> Router Class Initialized
INFO - 2023-05-26 09:42:23 --> Config Class Initialized
INFO - 2023-05-26 09:42:23 --> Output Class Initialized
INFO - 2023-05-26 09:42:23 --> Hooks Class Initialized
INFO - 2023-05-26 09:42:23 --> Security Class Initialized
DEBUG - 2023-05-26 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:42:23 --> Input Class Initialized
DEBUG - 2023-05-26 09:42:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:42:23 --> Language Class Initialized
INFO - 2023-05-26 09:42:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:42:23 --> URI Class Initialized
INFO - 2023-05-26 09:42:23 --> Loader Class Initialized
INFO - 2023-05-26 09:42:23 --> Controller Class Initialized
INFO - 2023-05-26 09:42:23 --> Router Class Initialized
DEBUG - 2023-05-26 09:42:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:42:23 --> Output Class Initialized
INFO - 2023-05-26 09:42:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:23 --> Security Class Initialized
DEBUG - 2023-05-26 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:42:23 --> Input Class Initialized
INFO - 2023-05-26 09:42:23 --> Language Class Initialized
INFO - 2023-05-26 09:42:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:23 --> Loader Class Initialized
INFO - 2023-05-26 09:42:23 --> Model "Login_model" initialized
INFO - 2023-05-26 09:42:23 --> Final output sent to browser
INFO - 2023-05-26 09:42:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:42:23 --> Total execution time: 9.2619
INFO - 2023-05-26 09:42:23 --> Final output sent to browser
DEBUG - 2023-05-26 09:42:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:42:23 --> Total execution time: 0.2869
INFO - 2023-05-26 09:42:23 --> Config Class Initialized
INFO - 2023-05-26 09:42:23 --> Config Class Initialized
INFO - 2023-05-26 09:42:23 --> Hooks Class Initialized
INFO - 2023-05-26 09:42:23 --> Hooks Class Initialized
INFO - 2023-05-26 09:42:23 --> Database Driver Class Initialized
DEBUG - 2023-05-26 09:42:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:42:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:42:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:42:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:42:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:42:23 --> URI Class Initialized
INFO - 2023-05-26 09:42:23 --> URI Class Initialized
INFO - 2023-05-26 09:42:23 --> Router Class Initialized
INFO - 2023-05-26 09:42:23 --> Router Class Initialized
INFO - 2023-05-26 09:42:23 --> Output Class Initialized
INFO - 2023-05-26 09:42:23 --> Output Class Initialized
INFO - 2023-05-26 09:42:23 --> Security Class Initialized
INFO - 2023-05-26 09:42:23 --> Security Class Initialized
DEBUG - 2023-05-26 09:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:42:23 --> Input Class Initialized
INFO - 2023-05-26 09:42:23 --> Input Class Initialized
INFO - 2023-05-26 09:42:23 --> Language Class Initialized
INFO - 2023-05-26 09:42:23 --> Language Class Initialized
INFO - 2023-05-26 09:42:23 --> Final output sent to browser
DEBUG - 2023-05-26 09:42:23 --> Total execution time: 0.3821
INFO - 2023-05-26 09:42:23 --> Loader Class Initialized
INFO - 2023-05-26 09:42:23 --> Loader Class Initialized
INFO - 2023-05-26 09:42:23 --> Controller Class Initialized
INFO - 2023-05-26 09:42:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:42:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:42:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:42:23 --> Config Class Initialized
INFO - 2023-05-26 09:42:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:23 --> Hooks Class Initialized
INFO - 2023-05-26 09:42:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:42:24 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 09:42:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:42:24 --> Utf8 Class Initialized
INFO - 2023-05-26 09:42:24 --> URI Class Initialized
INFO - 2023-05-26 09:42:24 --> Router Class Initialized
INFO - 2023-05-26 09:42:24 --> Final output sent to browser
INFO - 2023-05-26 09:42:24 --> Output Class Initialized
DEBUG - 2023-05-26 09:42:24 --> Total execution time: 0.2787
INFO - 2023-05-26 09:42:24 --> Security Class Initialized
DEBUG - 2023-05-26 09:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:42:24 --> Input Class Initialized
INFO - 2023-05-26 09:42:24 --> Language Class Initialized
INFO - 2023-05-26 09:42:24 --> Config Class Initialized
INFO - 2023-05-26 09:42:24 --> Hooks Class Initialized
INFO - 2023-05-26 09:42:24 --> Loader Class Initialized
INFO - 2023-05-26 09:42:24 --> Controller Class Initialized
DEBUG - 2023-05-26 09:42:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:42:24 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:42:24 --> Utf8 Class Initialized
INFO - 2023-05-26 09:42:24 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:24 --> URI Class Initialized
INFO - 2023-05-26 09:42:24 --> Router Class Initialized
INFO - 2023-05-26 09:42:24 --> Output Class Initialized
INFO - 2023-05-26 09:42:24 --> Security Class Initialized
INFO - 2023-05-26 09:42:24 --> Database Driver Class Initialized
DEBUG - 2023-05-26 09:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:42:24 --> Input Class Initialized
INFO - 2023-05-26 09:42:24 --> Language Class Initialized
INFO - 2023-05-26 09:42:24 --> Model "Login_model" initialized
INFO - 2023-05-26 09:42:24 --> Final output sent to browser
DEBUG - 2023-05-26 09:42:24 --> Total execution time: 0.3224
INFO - 2023-05-26 09:42:24 --> Loader Class Initialized
INFO - 2023-05-26 09:42:24 --> Controller Class Initialized
DEBUG - 2023-05-26 09:42:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:42:24 --> Database Driver Class Initialized
INFO - 2023-05-26 09:42:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:42:24 --> Final output sent to browser
DEBUG - 2023-05-26 09:42:24 --> Total execution time: 0.3082
INFO - 2023-05-26 09:42:30 --> Final output sent to browser
DEBUG - 2023-05-26 09:42:30 --> Total execution time: 9.3336
INFO - 2023-05-26 09:43:23 --> Config Class Initialized
INFO - 2023-05-26 09:43:23 --> Config Class Initialized
INFO - 2023-05-26 09:43:23 --> Hooks Class Initialized
INFO - 2023-05-26 09:43:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:43:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:43:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:43:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:43:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:43:23 --> URI Class Initialized
INFO - 2023-05-26 09:43:23 --> URI Class Initialized
INFO - 2023-05-26 09:43:23 --> Router Class Initialized
INFO - 2023-05-26 09:43:23 --> Router Class Initialized
INFO - 2023-05-26 09:43:23 --> Output Class Initialized
INFO - 2023-05-26 09:43:23 --> Output Class Initialized
INFO - 2023-05-26 09:43:23 --> Security Class Initialized
INFO - 2023-05-26 09:43:23 --> Security Class Initialized
DEBUG - 2023-05-26 09:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:43:23 --> Input Class Initialized
INFO - 2023-05-26 09:43:23 --> Input Class Initialized
INFO - 2023-05-26 09:43:23 --> Language Class Initialized
INFO - 2023-05-26 09:43:23 --> Language Class Initialized
INFO - 2023-05-26 09:43:23 --> Loader Class Initialized
INFO - 2023-05-26 09:43:23 --> Loader Class Initialized
INFO - 2023-05-26 09:43:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:43:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:43:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:43:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:43:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:43:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:43:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:43:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:43:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:43:23 --> Model "Login_model" initialized
INFO - 2023-05-26 09:43:23 --> Config Class Initialized
INFO - 2023-05-26 09:43:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:43:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:43:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:43:23 --> URI Class Initialized
INFO - 2023-05-26 09:43:23 --> Router Class Initialized
INFO - 2023-05-26 09:43:23 --> Output Class Initialized
INFO - 2023-05-26 09:43:23 --> Security Class Initialized
DEBUG - 2023-05-26 09:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:43:23 --> Input Class Initialized
INFO - 2023-05-26 09:43:23 --> Language Class Initialized
INFO - 2023-05-26 09:43:23 --> Loader Class Initialized
INFO - 2023-05-26 09:43:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:43:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:43:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:43:24 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:43:33 --> Final output sent to browser
DEBUG - 2023-05-26 09:43:33 --> Total execution time: 9.7487
INFO - 2023-05-26 09:43:33 --> Config Class Initialized
INFO - 2023-05-26 09:43:33 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:43:33 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:43:33 --> Utf8 Class Initialized
INFO - 2023-05-26 09:43:33 --> URI Class Initialized
INFO - 2023-05-26 09:43:33 --> Router Class Initialized
INFO - 2023-05-26 09:43:33 --> Output Class Initialized
INFO - 2023-05-26 09:43:33 --> Security Class Initialized
DEBUG - 2023-05-26 09:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:43:33 --> Input Class Initialized
INFO - 2023-05-26 09:43:33 --> Language Class Initialized
INFO - 2023-05-26 09:43:33 --> Loader Class Initialized
INFO - 2023-05-26 09:43:33 --> Controller Class Initialized
DEBUG - 2023-05-26 09:43:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:43:33 --> Database Driver Class Initialized
INFO - 2023-05-26 09:43:33 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:43:33 --> Database Driver Class Initialized
INFO - 2023-05-26 09:43:33 --> Model "Login_model" initialized
INFO - 2023-05-26 09:43:41 --> Final output sent to browser
DEBUG - 2023-05-26 09:43:41 --> Total execution time: 8.0253
INFO - 2023-05-26 09:44:23 --> Config Class Initialized
INFO - 2023-05-26 09:44:23 --> Config Class Initialized
INFO - 2023-05-26 09:44:23 --> Hooks Class Initialized
INFO - 2023-05-26 09:44:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:44:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:44:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:44:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:44:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:44:23 --> URI Class Initialized
INFO - 2023-05-26 09:44:23 --> URI Class Initialized
INFO - 2023-05-26 09:44:23 --> Router Class Initialized
INFO - 2023-05-26 09:44:23 --> Router Class Initialized
INFO - 2023-05-26 09:44:23 --> Output Class Initialized
INFO - 2023-05-26 09:44:23 --> Output Class Initialized
INFO - 2023-05-26 09:44:23 --> Security Class Initialized
INFO - 2023-05-26 09:44:23 --> Security Class Initialized
DEBUG - 2023-05-26 09:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:44:23 --> Input Class Initialized
INFO - 2023-05-26 09:44:23 --> Input Class Initialized
INFO - 2023-05-26 09:44:23 --> Language Class Initialized
INFO - 2023-05-26 09:44:23 --> Language Class Initialized
INFO - 2023-05-26 09:44:23 --> Loader Class Initialized
INFO - 2023-05-26 09:44:23 --> Controller Class Initialized
INFO - 2023-05-26 09:44:23 --> Loader Class Initialized
DEBUG - 2023-05-26 09:44:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:44:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:44:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:44:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:44:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:44:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:44:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:44:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:44:23 --> Model "Login_model" initialized
INFO - 2023-05-26 09:44:33 --> Config Class Initialized
INFO - 2023-05-26 09:44:33 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:44:33 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:44:33 --> Utf8 Class Initialized
INFO - 2023-05-26 09:44:33 --> URI Class Initialized
INFO - 2023-05-26 09:44:34 --> Router Class Initialized
INFO - 2023-05-26 09:44:34 --> Output Class Initialized
INFO - 2023-05-26 09:44:34 --> Security Class Initialized
DEBUG - 2023-05-26 09:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:44:34 --> Input Class Initialized
INFO - 2023-05-26 09:44:34 --> Language Class Initialized
INFO - 2023-05-26 09:44:34 --> Loader Class Initialized
INFO - 2023-05-26 09:44:34 --> Controller Class Initialized
DEBUG - 2023-05-26 09:44:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:44:34 --> Database Driver Class Initialized
INFO - 2023-05-26 09:44:34 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:44:51 --> Final output sent to browser
DEBUG - 2023-05-26 09:44:51 --> Total execution time: 27.9357
INFO - 2023-05-26 09:44:51 --> Config Class Initialized
INFO - 2023-05-26 09:44:51 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:44:51 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:44:51 --> Utf8 Class Initialized
INFO - 2023-05-26 09:44:51 --> URI Class Initialized
INFO - 2023-05-26 09:44:51 --> Router Class Initialized
INFO - 2023-05-26 09:44:51 --> Output Class Initialized
INFO - 2023-05-26 09:44:51 --> Security Class Initialized
DEBUG - 2023-05-26 09:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:44:51 --> Input Class Initialized
INFO - 2023-05-26 09:44:51 --> Language Class Initialized
INFO - 2023-05-26 09:44:51 --> Loader Class Initialized
INFO - 2023-05-26 09:44:51 --> Controller Class Initialized
DEBUG - 2023-05-26 09:44:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:44:51 --> Database Driver Class Initialized
INFO - 2023-05-26 09:44:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:44:51 --> Database Driver Class Initialized
INFO - 2023-05-26 09:44:51 --> Model "Login_model" initialized
INFO - 2023-05-26 09:45:06 --> Final output sent to browser
DEBUG - 2023-05-26 09:45:06 --> Total execution time: 15.2385
INFO - 2023-05-26 09:45:23 --> Config Class Initialized
INFO - 2023-05-26 09:45:23 --> Config Class Initialized
INFO - 2023-05-26 09:45:23 --> Hooks Class Initialized
INFO - 2023-05-26 09:45:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:45:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:45:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:45:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:45:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:45:23 --> URI Class Initialized
INFO - 2023-05-26 09:45:23 --> URI Class Initialized
INFO - 2023-05-26 09:45:23 --> Router Class Initialized
INFO - 2023-05-26 09:45:23 --> Router Class Initialized
INFO - 2023-05-26 09:45:23 --> Output Class Initialized
INFO - 2023-05-26 09:45:23 --> Output Class Initialized
INFO - 2023-05-26 09:45:23 --> Security Class Initialized
INFO - 2023-05-26 09:45:23 --> Security Class Initialized
DEBUG - 2023-05-26 09:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:45:23 --> Input Class Initialized
INFO - 2023-05-26 09:45:23 --> Input Class Initialized
INFO - 2023-05-26 09:45:23 --> Language Class Initialized
INFO - 2023-05-26 09:45:23 --> Language Class Initialized
INFO - 2023-05-26 09:45:23 --> Loader Class Initialized
INFO - 2023-05-26 09:45:23 --> Loader Class Initialized
INFO - 2023-05-26 09:45:23 --> Controller Class Initialized
INFO - 2023-05-26 09:45:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:45:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:45:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:45:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:45:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:45:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:45:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:45:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:45:23 --> Model "Login_model" initialized
INFO - 2023-05-26 09:45:23 --> Config Class Initialized
INFO - 2023-05-26 09:45:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:45:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:45:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:45:23 --> URI Class Initialized
INFO - 2023-05-26 09:45:23 --> Router Class Initialized
INFO - 2023-05-26 09:45:23 --> Output Class Initialized
INFO - 2023-05-26 09:45:23 --> Security Class Initialized
DEBUG - 2023-05-26 09:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:45:23 --> Input Class Initialized
INFO - 2023-05-26 09:45:23 --> Language Class Initialized
INFO - 2023-05-26 09:45:23 --> Loader Class Initialized
INFO - 2023-05-26 09:45:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:45:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:45:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:45:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:45:34 --> Final output sent to browser
DEBUG - 2023-05-26 09:45:34 --> Total execution time: 11.0370
INFO - 2023-05-26 09:45:34 --> Config Class Initialized
INFO - 2023-05-26 09:45:34 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:45:34 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:45:34 --> Utf8 Class Initialized
INFO - 2023-05-26 09:45:34 --> URI Class Initialized
INFO - 2023-05-26 09:45:34 --> Router Class Initialized
INFO - 2023-05-26 09:45:34 --> Output Class Initialized
INFO - 2023-05-26 09:45:34 --> Security Class Initialized
DEBUG - 2023-05-26 09:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:45:34 --> Input Class Initialized
INFO - 2023-05-26 09:45:34 --> Language Class Initialized
INFO - 2023-05-26 09:45:34 --> Loader Class Initialized
INFO - 2023-05-26 09:45:34 --> Controller Class Initialized
DEBUG - 2023-05-26 09:45:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:45:34 --> Database Driver Class Initialized
INFO - 2023-05-26 09:45:34 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:45:34 --> Database Driver Class Initialized
INFO - 2023-05-26 09:45:34 --> Model "Login_model" initialized
INFO - 2023-05-26 09:45:43 --> Final output sent to browser
DEBUG - 2023-05-26 09:45:43 --> Total execution time: 9.2436
INFO - 2023-05-26 09:46:23 --> Config Class Initialized
INFO - 2023-05-26 09:46:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:46:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:46:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:46:23 --> URI Class Initialized
INFO - 2023-05-26 09:46:23 --> Router Class Initialized
INFO - 2023-05-26 09:46:23 --> Output Class Initialized
INFO - 2023-05-26 09:46:23 --> Security Class Initialized
DEBUG - 2023-05-26 09:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:46:23 --> Input Class Initialized
INFO - 2023-05-26 09:46:23 --> Language Class Initialized
INFO - 2023-05-26 09:46:23 --> Loader Class Initialized
INFO - 2023-05-26 09:46:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:46:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:46:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:46:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:46:23 --> Config Class Initialized
INFO - 2023-05-26 09:46:23 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:46:23 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:46:23 --> Utf8 Class Initialized
INFO - 2023-05-26 09:46:23 --> URI Class Initialized
INFO - 2023-05-26 09:46:23 --> Router Class Initialized
INFO - 2023-05-26 09:46:23 --> Output Class Initialized
INFO - 2023-05-26 09:46:23 --> Security Class Initialized
DEBUG - 2023-05-26 09:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:46:23 --> Input Class Initialized
INFO - 2023-05-26 09:46:23 --> Language Class Initialized
INFO - 2023-05-26 09:46:23 --> Loader Class Initialized
INFO - 2023-05-26 09:46:23 --> Controller Class Initialized
DEBUG - 2023-05-26 09:46:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:46:23 --> Database Driver Class Initialized
INFO - 2023-05-26 09:46:23 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:47:05 --> Config Class Initialized
INFO - 2023-05-26 09:47:05 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:47:05 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:47:05 --> Utf8 Class Initialized
INFO - 2023-05-26 09:47:05 --> URI Class Initialized
INFO - 2023-05-26 09:47:05 --> Router Class Initialized
INFO - 2023-05-26 09:47:05 --> Output Class Initialized
INFO - 2023-05-26 09:47:05 --> Security Class Initialized
DEBUG - 2023-05-26 09:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:47:05 --> Input Class Initialized
INFO - 2023-05-26 09:47:05 --> Language Class Initialized
INFO - 2023-05-26 09:47:05 --> Loader Class Initialized
INFO - 2023-05-26 09:47:05 --> Controller Class Initialized
DEBUG - 2023-05-26 09:47:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:47:05 --> Database Driver Class Initialized
INFO - 2023-05-26 09:47:05 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:47:05 --> Database Driver Class Initialized
INFO - 2023-05-26 09:47:05 --> Model "Login_model" initialized
INFO - 2023-05-26 09:47:16 --> Final output sent to browser
DEBUG - 2023-05-26 09:47:16 --> Total execution time: 11.4547
INFO - 2023-05-26 09:47:16 --> Config Class Initialized
INFO - 2023-05-26 09:47:16 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:47:16 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:47:16 --> Utf8 Class Initialized
INFO - 2023-05-26 09:47:16 --> URI Class Initialized
INFO - 2023-05-26 09:47:16 --> Router Class Initialized
INFO - 2023-05-26 09:47:16 --> Output Class Initialized
INFO - 2023-05-26 09:47:16 --> Security Class Initialized
DEBUG - 2023-05-26 09:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:47:16 --> Input Class Initialized
INFO - 2023-05-26 09:47:16 --> Language Class Initialized
INFO - 2023-05-26 09:47:16 --> Loader Class Initialized
INFO - 2023-05-26 09:47:16 --> Controller Class Initialized
DEBUG - 2023-05-26 09:47:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:47:16 --> Database Driver Class Initialized
INFO - 2023-05-26 09:47:16 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:47:16 --> Database Driver Class Initialized
INFO - 2023-05-26 09:47:16 --> Model "Login_model" initialized
INFO - 2023-05-26 09:47:26 --> Final output sent to browser
DEBUG - 2023-05-26 09:47:26 --> Total execution time: 10.0317
INFO - 2023-05-26 09:48:06 --> Config Class Initialized
INFO - 2023-05-26 09:48:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:48:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:48:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:48:06 --> URI Class Initialized
INFO - 2023-05-26 09:48:06 --> Router Class Initialized
INFO - 2023-05-26 09:48:06 --> Output Class Initialized
INFO - 2023-05-26 09:48:06 --> Security Class Initialized
DEBUG - 2023-05-26 09:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:48:06 --> Input Class Initialized
INFO - 2023-05-26 09:48:06 --> Language Class Initialized
INFO - 2023-05-26 09:48:06 --> Loader Class Initialized
INFO - 2023-05-26 09:48:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:48:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:48:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:48:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:48:06 --> Config Class Initialized
INFO - 2023-05-26 09:48:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:48:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:48:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:48:06 --> URI Class Initialized
INFO - 2023-05-26 09:48:06 --> Router Class Initialized
INFO - 2023-05-26 09:48:06 --> Output Class Initialized
INFO - 2023-05-26 09:48:06 --> Security Class Initialized
DEBUG - 2023-05-26 09:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:48:06 --> Input Class Initialized
INFO - 2023-05-26 09:48:06 --> Language Class Initialized
INFO - 2023-05-26 09:48:06 --> Loader Class Initialized
INFO - 2023-05-26 09:48:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:48:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:48:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:48:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:49:06 --> Config Class Initialized
INFO - 2023-05-26 09:49:06 --> Config Class Initialized
INFO - 2023-05-26 09:49:06 --> Hooks Class Initialized
INFO - 2023-05-26 09:49:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:49:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:49:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:49:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:49:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:49:06 --> URI Class Initialized
INFO - 2023-05-26 09:49:06 --> URI Class Initialized
INFO - 2023-05-26 09:49:06 --> Router Class Initialized
INFO - 2023-05-26 09:49:06 --> Router Class Initialized
INFO - 2023-05-26 09:49:06 --> Output Class Initialized
INFO - 2023-05-26 09:49:06 --> Output Class Initialized
INFO - 2023-05-26 09:49:06 --> Security Class Initialized
INFO - 2023-05-26 09:49:06 --> Security Class Initialized
DEBUG - 2023-05-26 09:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:49:06 --> Input Class Initialized
INFO - 2023-05-26 09:49:06 --> Input Class Initialized
INFO - 2023-05-26 09:49:06 --> Language Class Initialized
INFO - 2023-05-26 09:49:06 --> Language Class Initialized
INFO - 2023-05-26 09:49:06 --> Loader Class Initialized
INFO - 2023-05-26 09:49:06 --> Loader Class Initialized
INFO - 2023-05-26 09:49:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:49:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:49:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:49:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:49:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:49:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:49:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:49:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:49:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:49:06 --> Model "Login_model" initialized
INFO - 2023-05-26 09:49:06 --> Config Class Initialized
INFO - 2023-05-26 09:49:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:49:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:49:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:49:06 --> URI Class Initialized
INFO - 2023-05-26 09:49:06 --> Router Class Initialized
INFO - 2023-05-26 09:49:06 --> Output Class Initialized
INFO - 2023-05-26 09:49:06 --> Security Class Initialized
DEBUG - 2023-05-26 09:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:49:06 --> Input Class Initialized
INFO - 2023-05-26 09:49:06 --> Language Class Initialized
INFO - 2023-05-26 09:49:06 --> Loader Class Initialized
INFO - 2023-05-26 09:49:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:49:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:49:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:49:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:49:17 --> Final output sent to browser
DEBUG - 2023-05-26 09:49:17 --> Total execution time: 11.5609
INFO - 2023-05-26 09:49:17 --> Config Class Initialized
INFO - 2023-05-26 09:49:17 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:49:17 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:49:17 --> Utf8 Class Initialized
INFO - 2023-05-26 09:49:17 --> URI Class Initialized
INFO - 2023-05-26 09:49:17 --> Router Class Initialized
INFO - 2023-05-26 09:49:17 --> Output Class Initialized
INFO - 2023-05-26 09:49:17 --> Security Class Initialized
DEBUG - 2023-05-26 09:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:49:17 --> Input Class Initialized
INFO - 2023-05-26 09:49:17 --> Language Class Initialized
INFO - 2023-05-26 09:49:18 --> Loader Class Initialized
INFO - 2023-05-26 09:49:18 --> Controller Class Initialized
DEBUG - 2023-05-26 09:49:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:49:18 --> Database Driver Class Initialized
INFO - 2023-05-26 09:49:18 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:49:18 --> Database Driver Class Initialized
INFO - 2023-05-26 09:49:18 --> Model "Login_model" initialized
INFO - 2023-05-26 09:49:27 --> Final output sent to browser
DEBUG - 2023-05-26 09:49:27 --> Total execution time: 10.0755
INFO - 2023-05-26 09:50:06 --> Config Class Initialized
INFO - 2023-05-26 09:50:06 --> Config Class Initialized
INFO - 2023-05-26 09:50:06 --> Hooks Class Initialized
INFO - 2023-05-26 09:50:06 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:50:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:50:06 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:50:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:50:06 --> Utf8 Class Initialized
INFO - 2023-05-26 09:50:06 --> URI Class Initialized
INFO - 2023-05-26 09:50:06 --> URI Class Initialized
INFO - 2023-05-26 09:50:06 --> Router Class Initialized
INFO - 2023-05-26 09:50:06 --> Router Class Initialized
INFO - 2023-05-26 09:50:06 --> Output Class Initialized
INFO - 2023-05-26 09:50:06 --> Output Class Initialized
INFO - 2023-05-26 09:50:06 --> Security Class Initialized
INFO - 2023-05-26 09:50:06 --> Security Class Initialized
DEBUG - 2023-05-26 09:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:50:06 --> Input Class Initialized
INFO - 2023-05-26 09:50:06 --> Input Class Initialized
INFO - 2023-05-26 09:50:06 --> Language Class Initialized
INFO - 2023-05-26 09:50:06 --> Language Class Initialized
INFO - 2023-05-26 09:50:06 --> Loader Class Initialized
INFO - 2023-05-26 09:50:06 --> Controller Class Initialized
INFO - 2023-05-26 09:50:06 --> Loader Class Initialized
DEBUG - 2023-05-26 09:50:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:50:06 --> Controller Class Initialized
DEBUG - 2023-05-26 09:50:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:50:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:50:06 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:50:06 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:06 --> Model "Login_model" initialized
INFO - 2023-05-26 09:50:07 --> Config Class Initialized
INFO - 2023-05-26 09:50:07 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:50:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:50:07 --> Utf8 Class Initialized
INFO - 2023-05-26 09:50:07 --> URI Class Initialized
INFO - 2023-05-26 09:50:07 --> Router Class Initialized
INFO - 2023-05-26 09:50:07 --> Output Class Initialized
INFO - 2023-05-26 09:50:07 --> Security Class Initialized
DEBUG - 2023-05-26 09:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:50:07 --> Input Class Initialized
INFO - 2023-05-26 09:50:07 --> Language Class Initialized
INFO - 2023-05-26 09:50:07 --> Loader Class Initialized
INFO - 2023-05-26 09:50:07 --> Controller Class Initialized
DEBUG - 2023-05-26 09:50:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:50:07 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:50:18 --> Final output sent to browser
DEBUG - 2023-05-26 09:50:18 --> Total execution time: 11.9161
INFO - 2023-05-26 09:50:18 --> Config Class Initialized
INFO - 2023-05-26 09:50:18 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:50:18 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:50:18 --> Utf8 Class Initialized
INFO - 2023-05-26 09:50:18 --> URI Class Initialized
INFO - 2023-05-26 09:50:18 --> Router Class Initialized
INFO - 2023-05-26 09:50:18 --> Output Class Initialized
INFO - 2023-05-26 09:50:18 --> Security Class Initialized
DEBUG - 2023-05-26 09:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:50:18 --> Input Class Initialized
INFO - 2023-05-26 09:50:18 --> Language Class Initialized
INFO - 2023-05-26 09:50:18 --> Loader Class Initialized
INFO - 2023-05-26 09:50:18 --> Controller Class Initialized
DEBUG - 2023-05-26 09:50:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:50:18 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:19 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:50:19 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:19 --> Model "Login_model" initialized
INFO - 2023-05-26 09:50:29 --> Final output sent to browser
DEBUG - 2023-05-26 09:50:29 --> Total execution time: 11.3716
INFO - 2023-05-26 09:50:35 --> Config Class Initialized
INFO - 2023-05-26 09:50:35 --> Hooks Class Initialized
INFO - 2023-05-26 09:50:35 --> Config Class Initialized
INFO - 2023-05-26 09:50:35 --> Hooks Class Initialized
INFO - 2023-05-26 09:50:35 --> Config Class Initialized
DEBUG - 2023-05-26 09:50:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:50:35 --> Utf8 Class Initialized
INFO - 2023-05-26 09:50:35 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:50:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:50:35 --> URI Class Initialized
INFO - 2023-05-26 09:50:35 --> Utf8 Class Initialized
INFO - 2023-05-26 09:50:35 --> Router Class Initialized
DEBUG - 2023-05-26 09:50:35 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:50:35 --> Utf8 Class Initialized
INFO - 2023-05-26 09:50:35 --> URI Class Initialized
INFO - 2023-05-26 09:50:35 --> Output Class Initialized
INFO - 2023-05-26 09:50:35 --> URI Class Initialized
INFO - 2023-05-26 09:50:35 --> Security Class Initialized
INFO - 2023-05-26 09:50:35 --> Router Class Initialized
DEBUG - 2023-05-26 09:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:50:35 --> Router Class Initialized
INFO - 2023-05-26 09:50:35 --> Input Class Initialized
INFO - 2023-05-26 09:50:35 --> Language Class Initialized
INFO - 2023-05-26 09:50:35 --> Output Class Initialized
INFO - 2023-05-26 09:50:35 --> Output Class Initialized
INFO - 2023-05-26 09:50:35 --> Security Class Initialized
INFO - 2023-05-26 09:50:35 --> Security Class Initialized
DEBUG - 2023-05-26 09:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:50:35 --> Input Class Initialized
DEBUG - 2023-05-26 09:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:50:35 --> Loader Class Initialized
INFO - 2023-05-26 09:50:35 --> Input Class Initialized
INFO - 2023-05-26 09:50:35 --> Language Class Initialized
INFO - 2023-05-26 09:50:35 --> Language Class Initialized
INFO - 2023-05-26 09:50:35 --> Controller Class Initialized
DEBUG - 2023-05-26 09:50:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:50:35 --> Loader Class Initialized
INFO - 2023-05-26 09:50:35 --> Loader Class Initialized
INFO - 2023-05-26 09:50:35 --> Controller Class Initialized
INFO - 2023-05-26 09:50:35 --> Controller Class Initialized
DEBUG - 2023-05-26 09:50:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:50:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:50:35 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:50:35 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:35 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:35 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:50:35 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:50:35 --> Model "Login_model" initialized
INFO - 2023-05-26 09:50:35 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:36 --> Model "Login_model" initialized
INFO - 2023-05-26 09:50:37 --> Config Class Initialized
INFO - 2023-05-26 09:50:37 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:50:37 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:50:37 --> Utf8 Class Initialized
INFO - 2023-05-26 09:50:37 --> URI Class Initialized
INFO - 2023-05-26 09:50:37 --> Router Class Initialized
INFO - 2023-05-26 09:50:37 --> Output Class Initialized
INFO - 2023-05-26 09:50:37 --> Security Class Initialized
DEBUG - 2023-05-26 09:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:50:37 --> Input Class Initialized
INFO - 2023-05-26 09:50:37 --> Language Class Initialized
INFO - 2023-05-26 09:50:37 --> Loader Class Initialized
INFO - 2023-05-26 09:50:37 --> Controller Class Initialized
DEBUG - 2023-05-26 09:50:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:50:37 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:37 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:50:38 --> Config Class Initialized
INFO - 2023-05-26 09:50:38 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:50:38 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:50:38 --> Utf8 Class Initialized
INFO - 2023-05-26 09:50:38 --> URI Class Initialized
INFO - 2023-05-26 09:50:38 --> Router Class Initialized
INFO - 2023-05-26 09:50:38 --> Output Class Initialized
INFO - 2023-05-26 09:50:38 --> Security Class Initialized
DEBUG - 2023-05-26 09:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:50:39 --> Input Class Initialized
INFO - 2023-05-26 09:50:39 --> Language Class Initialized
INFO - 2023-05-26 09:50:39 --> Loader Class Initialized
INFO - 2023-05-26 09:50:39 --> Controller Class Initialized
DEBUG - 2023-05-26 09:50:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:50:39 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:50:39 --> Final output sent to browser
DEBUG - 2023-05-26 09:50:39 --> Total execution time: 0.3136
INFO - 2023-05-26 09:50:39 --> Config Class Initialized
INFO - 2023-05-26 09:50:39 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:50:39 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:50:39 --> Utf8 Class Initialized
INFO - 2023-05-26 09:50:39 --> URI Class Initialized
INFO - 2023-05-26 09:50:39 --> Router Class Initialized
INFO - 2023-05-26 09:50:39 --> Output Class Initialized
INFO - 2023-05-26 09:50:39 --> Security Class Initialized
DEBUG - 2023-05-26 09:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:50:39 --> Input Class Initialized
INFO - 2023-05-26 09:50:39 --> Language Class Initialized
INFO - 2023-05-26 09:50:39 --> Loader Class Initialized
INFO - 2023-05-26 09:50:39 --> Controller Class Initialized
DEBUG - 2023-05-26 09:50:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:50:39 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:50:39 --> Final output sent to browser
DEBUG - 2023-05-26 09:50:39 --> Total execution time: 0.2696
INFO - 2023-05-26 09:50:44 --> Final output sent to browser
DEBUG - 2023-05-26 09:50:44 --> Total execution time: 9.4001
INFO - 2023-05-26 09:50:44 --> Config Class Initialized
INFO - 2023-05-26 09:50:44 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:50:44 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:50:44 --> Utf8 Class Initialized
INFO - 2023-05-26 09:50:44 --> URI Class Initialized
INFO - 2023-05-26 09:50:44 --> Router Class Initialized
INFO - 2023-05-26 09:50:44 --> Output Class Initialized
INFO - 2023-05-26 09:50:44 --> Final output sent to browser
INFO - 2023-05-26 09:50:44 --> Security Class Initialized
DEBUG - 2023-05-26 09:50:44 --> Total execution time: 9.7040
DEBUG - 2023-05-26 09:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:50:44 --> Input Class Initialized
INFO - 2023-05-26 09:50:45 --> Language Class Initialized
INFO - 2023-05-26 09:50:45 --> Loader Class Initialized
INFO - 2023-05-26 09:50:45 --> Controller Class Initialized
DEBUG - 2023-05-26 09:50:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:50:45 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:45 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:50:45 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:45 --> Model "Login_model" initialized
INFO - 2023-05-26 09:50:56 --> Final output sent to browser
DEBUG - 2023-05-26 09:50:56 --> Total execution time: 12.1234
INFO - 2023-05-26 09:50:56 --> Config Class Initialized
INFO - 2023-05-26 09:50:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:50:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:50:56 --> Utf8 Class Initialized
INFO - 2023-05-26 09:50:56 --> URI Class Initialized
INFO - 2023-05-26 09:50:56 --> Router Class Initialized
INFO - 2023-05-26 09:50:57 --> Output Class Initialized
INFO - 2023-05-26 09:50:57 --> Security Class Initialized
DEBUG - 2023-05-26 09:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:50:57 --> Input Class Initialized
INFO - 2023-05-26 09:50:57 --> Language Class Initialized
INFO - 2023-05-26 09:50:57 --> Loader Class Initialized
INFO - 2023-05-26 09:50:57 --> Controller Class Initialized
DEBUG - 2023-05-26 09:50:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:50:57 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:50:57 --> Database Driver Class Initialized
INFO - 2023-05-26 09:50:57 --> Model "Login_model" initialized
INFO - 2023-05-26 09:51:08 --> Final output sent to browser
DEBUG - 2023-05-26 09:51:08 --> Total execution time: 11.8676
INFO - 2023-05-26 09:58:07 --> Config Class Initialized
INFO - 2023-05-26 09:58:07 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:07 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:07 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:07 --> URI Class Initialized
INFO - 2023-05-26 09:58:07 --> Router Class Initialized
INFO - 2023-05-26 09:58:07 --> Output Class Initialized
INFO - 2023-05-26 09:58:07 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:07 --> Input Class Initialized
INFO - 2023-05-26 09:58:07 --> Language Class Initialized
INFO - 2023-05-26 09:58:07 --> Loader Class Initialized
INFO - 2023-05-26 09:58:07 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:07 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:07 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:08 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:08 --> Total execution time: 0.5233
INFO - 2023-05-26 09:58:08 --> Config Class Initialized
INFO - 2023-05-26 09:58:08 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:08 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:08 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:08 --> URI Class Initialized
INFO - 2023-05-26 09:58:08 --> Router Class Initialized
INFO - 2023-05-26 09:58:08 --> Output Class Initialized
INFO - 2023-05-26 09:58:08 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:08 --> Input Class Initialized
INFO - 2023-05-26 09:58:08 --> Language Class Initialized
INFO - 2023-05-26 09:58:08 --> Loader Class Initialized
INFO - 2023-05-26 09:58:08 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:08 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:08 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:08 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:08 --> Total execution time: 0.4649
INFO - 2023-05-26 09:58:21 --> Config Class Initialized
INFO - 2023-05-26 09:58:21 --> Config Class Initialized
INFO - 2023-05-26 09:58:21 --> Config Class Initialized
INFO - 2023-05-26 09:58:21 --> Hooks Class Initialized
INFO - 2023-05-26 09:58:21 --> Hooks Class Initialized
INFO - 2023-05-26 09:58:21 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:58:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:58:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:21 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:21 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:21 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:21 --> URI Class Initialized
INFO - 2023-05-26 09:58:21 --> URI Class Initialized
INFO - 2023-05-26 09:58:21 --> URI Class Initialized
INFO - 2023-05-26 09:58:21 --> Router Class Initialized
INFO - 2023-05-26 09:58:21 --> Router Class Initialized
INFO - 2023-05-26 09:58:21 --> Router Class Initialized
INFO - 2023-05-26 09:58:21 --> Output Class Initialized
INFO - 2023-05-26 09:58:21 --> Output Class Initialized
INFO - 2023-05-26 09:58:21 --> Output Class Initialized
INFO - 2023-05-26 09:58:21 --> Security Class Initialized
INFO - 2023-05-26 09:58:21 --> Security Class Initialized
INFO - 2023-05-26 09:58:21 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:21 --> Input Class Initialized
INFO - 2023-05-26 09:58:21 --> Input Class Initialized
INFO - 2023-05-26 09:58:21 --> Input Class Initialized
INFO - 2023-05-26 09:58:21 --> Language Class Initialized
INFO - 2023-05-26 09:58:21 --> Language Class Initialized
INFO - 2023-05-26 09:58:21 --> Language Class Initialized
INFO - 2023-05-26 09:58:21 --> Loader Class Initialized
INFO - 2023-05-26 09:58:21 --> Loader Class Initialized
INFO - 2023-05-26 09:58:21 --> Loader Class Initialized
INFO - 2023-05-26 09:58:21 --> Controller Class Initialized
INFO - 2023-05-26 09:58:21 --> Controller Class Initialized
INFO - 2023-05-26 09:58:21 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:58:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:58:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:21 --> Model "Login_model" initialized
INFO - 2023-05-26 09:58:21 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:21 --> Total execution time: 0.3770
INFO - 2023-05-26 09:58:21 --> Config Class Initialized
INFO - 2023-05-26 09:58:21 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:21 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:21 --> URI Class Initialized
INFO - 2023-05-26 09:58:21 --> Router Class Initialized
INFO - 2023-05-26 09:58:21 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:21 --> Total execution time: 0.4813
INFO - 2023-05-26 09:58:21 --> Output Class Initialized
INFO - 2023-05-26 09:58:21 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:21 --> Input Class Initialized
INFO - 2023-05-26 09:58:21 --> Language Class Initialized
INFO - 2023-05-26 09:58:21 --> Config Class Initialized
INFO - 2023-05-26 09:58:21 --> Config Class Initialized
INFO - 2023-05-26 09:58:21 --> Hooks Class Initialized
INFO - 2023-05-26 09:58:21 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:58:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:21 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:21 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:21 --> Loader Class Initialized
INFO - 2023-05-26 09:58:21 --> URI Class Initialized
INFO - 2023-05-26 09:58:21 --> URI Class Initialized
INFO - 2023-05-26 09:58:21 --> Config Class Initialized
INFO - 2023-05-26 09:58:21 --> Hooks Class Initialized
INFO - 2023-05-26 09:58:21 --> Controller Class Initialized
INFO - 2023-05-26 09:58:21 --> Router Class Initialized
INFO - 2023-05-26 09:58:21 --> Router Class Initialized
DEBUG - 2023-05-26 09:58:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:21 --> Output Class Initialized
INFO - 2023-05-26 09:58:21 --> Output Class Initialized
DEBUG - 2023-05-26 09:58:21 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:21 --> Security Class Initialized
INFO - 2023-05-26 09:58:21 --> Security Class Initialized
INFO - 2023-05-26 09:58:21 --> Utf8 Class Initialized
DEBUG - 2023-05-26 09:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:21 --> URI Class Initialized
INFO - 2023-05-26 09:58:21 --> Input Class Initialized
INFO - 2023-05-26 09:58:21 --> Input Class Initialized
INFO - 2023-05-26 09:58:21 --> Language Class Initialized
INFO - 2023-05-26 09:58:21 --> Language Class Initialized
INFO - 2023-05-26 09:58:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:21 --> Router Class Initialized
INFO - 2023-05-26 09:58:21 --> Loader Class Initialized
INFO - 2023-05-26 09:58:21 --> Loader Class Initialized
INFO - 2023-05-26 09:58:21 --> Output Class Initialized
INFO - 2023-05-26 09:58:21 --> Controller Class Initialized
INFO - 2023-05-26 09:58:21 --> Controller Class Initialized
INFO - 2023-05-26 09:58:21 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:58:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:21 --> Input Class Initialized
INFO - 2023-05-26 09:58:21 --> Language Class Initialized
INFO - 2023-05-26 09:58:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:21 --> Loader Class Initialized
INFO - 2023-05-26 09:58:21 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:21 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:21 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:22 --> Model "Login_model" initialized
INFO - 2023-05-26 09:58:22 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:22 --> Total execution time: 0.5244
INFO - 2023-05-26 09:58:22 --> Final output sent to browser
INFO - 2023-05-26 09:58:22 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:22 --> Total execution time: 0.6463
DEBUG - 2023-05-26 09:58:22 --> Total execution time: 0.7613
INFO - 2023-05-26 09:58:22 --> Config Class Initialized
INFO - 2023-05-26 09:58:22 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:22 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:22 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:22 --> URI Class Initialized
INFO - 2023-05-26 09:58:22 --> Router Class Initialized
INFO - 2023-05-26 09:58:22 --> Output Class Initialized
INFO - 2023-05-26 09:58:22 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:22 --> Input Class Initialized
INFO - 2023-05-26 09:58:22 --> Language Class Initialized
INFO - 2023-05-26 09:58:22 --> Loader Class Initialized
INFO - 2023-05-26 09:58:22 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:22 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:22 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:22 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:22 --> Total execution time: 0.5801
INFO - 2023-05-26 09:58:26 --> Config Class Initialized
INFO - 2023-05-26 09:58:26 --> Config Class Initialized
INFO - 2023-05-26 09:58:26 --> Hooks Class Initialized
INFO - 2023-05-26 09:58:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:26 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:58:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:26 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:26 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:26 --> URI Class Initialized
INFO - 2023-05-26 09:58:26 --> URI Class Initialized
INFO - 2023-05-26 09:58:26 --> Router Class Initialized
INFO - 2023-05-26 09:58:26 --> Router Class Initialized
INFO - 2023-05-26 09:58:26 --> Output Class Initialized
INFO - 2023-05-26 09:58:26 --> Output Class Initialized
INFO - 2023-05-26 09:58:26 --> Security Class Initialized
INFO - 2023-05-26 09:58:26 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:26 --> Input Class Initialized
INFO - 2023-05-26 09:58:26 --> Input Class Initialized
INFO - 2023-05-26 09:58:26 --> Language Class Initialized
INFO - 2023-05-26 09:58:26 --> Language Class Initialized
INFO - 2023-05-26 09:58:26 --> Loader Class Initialized
INFO - 2023-05-26 09:58:26 --> Loader Class Initialized
INFO - 2023-05-26 09:58:26 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:26 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:26 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:26 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:26 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:26 --> Total execution time: 0.2892
INFO - 2023-05-26 09:58:26 --> Config Class Initialized
INFO - 2023-05-26 09:58:26 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:26 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:26 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:26 --> URI Class Initialized
INFO - 2023-05-26 09:58:26 --> Router Class Initialized
INFO - 2023-05-26 09:58:26 --> Output Class Initialized
INFO - 2023-05-26 09:58:26 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:26 --> Input Class Initialized
INFO - 2023-05-26 09:58:26 --> Language Class Initialized
INFO - 2023-05-26 09:58:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:26 --> Loader Class Initialized
INFO - 2023-05-26 09:58:26 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:26 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:26 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:26 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:26 --> Model "Login_model" initialized
INFO - 2023-05-26 09:58:26 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:26 --> Total execution time: 0.2979
INFO - 2023-05-26 09:58:27 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:27 --> Total execution time: 1.2583
INFO - 2023-05-26 09:58:27 --> Config Class Initialized
INFO - 2023-05-26 09:58:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:27 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:27 --> URI Class Initialized
INFO - 2023-05-26 09:58:27 --> Router Class Initialized
INFO - 2023-05-26 09:58:27 --> Output Class Initialized
INFO - 2023-05-26 09:58:27 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:27 --> Input Class Initialized
INFO - 2023-05-26 09:58:27 --> Language Class Initialized
INFO - 2023-05-26 09:58:27 --> Loader Class Initialized
INFO - 2023-05-26 09:58:27 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:27 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:27 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:27 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:28 --> Model "Login_model" initialized
INFO - 2023-05-26 09:58:28 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:28 --> Total execution time: 1.2359
INFO - 2023-05-26 09:58:38 --> Config Class Initialized
INFO - 2023-05-26 09:58:38 --> Config Class Initialized
INFO - 2023-05-26 09:58:38 --> Hooks Class Initialized
INFO - 2023-05-26 09:58:38 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:38 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:58:38 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:38 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:38 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:38 --> URI Class Initialized
INFO - 2023-05-26 09:58:38 --> URI Class Initialized
INFO - 2023-05-26 09:58:38 --> Router Class Initialized
INFO - 2023-05-26 09:58:38 --> Router Class Initialized
INFO - 2023-05-26 09:58:38 --> Output Class Initialized
INFO - 2023-05-26 09:58:38 --> Output Class Initialized
INFO - 2023-05-26 09:58:38 --> Security Class Initialized
INFO - 2023-05-26 09:58:38 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:38 --> Input Class Initialized
INFO - 2023-05-26 09:58:38 --> Input Class Initialized
INFO - 2023-05-26 09:58:38 --> Language Class Initialized
INFO - 2023-05-26 09:58:38 --> Language Class Initialized
INFO - 2023-05-26 09:58:38 --> Loader Class Initialized
INFO - 2023-05-26 09:58:38 --> Loader Class Initialized
INFO - 2023-05-26 09:58:38 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:38 --> Final output sent to browser
INFO - 2023-05-26 09:58:38 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:38 --> Total execution time: 0.1114
DEBUG - 2023-05-26 09:58:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:38 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:38 --> Config Class Initialized
INFO - 2023-05-26 09:58:38 --> Hooks Class Initialized
INFO - 2023-05-26 09:58:38 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:38 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:38 --> Total execution time: 0.1927
DEBUG - 2023-05-26 09:58:38 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:38 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:38 --> URI Class Initialized
INFO - 2023-05-26 09:58:38 --> Router Class Initialized
INFO - 2023-05-26 09:58:38 --> Output Class Initialized
INFO - 2023-05-26 09:58:38 --> Config Class Initialized
INFO - 2023-05-26 09:58:38 --> Security Class Initialized
INFO - 2023-05-26 09:58:38 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:38 --> Input Class Initialized
INFO - 2023-05-26 09:58:38 --> Language Class Initialized
DEBUG - 2023-05-26 09:58:38 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:38 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:38 --> URI Class Initialized
INFO - 2023-05-26 09:58:38 --> Loader Class Initialized
INFO - 2023-05-26 09:58:38 --> Router Class Initialized
INFO - 2023-05-26 09:58:38 --> Controller Class Initialized
INFO - 2023-05-26 09:58:38 --> Output Class Initialized
DEBUG - 2023-05-26 09:58:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:38 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:38 --> Input Class Initialized
INFO - 2023-05-26 09:58:38 --> Language Class Initialized
INFO - 2023-05-26 09:58:38 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:39 --> Model "Login_model" initialized
INFO - 2023-05-26 09:58:39 --> Loader Class Initialized
INFO - 2023-05-26 09:58:39 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:39 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:39 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:39 --> Total execution time: 0.2667
INFO - 2023-05-26 09:58:39 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:39 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:39 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:39 --> Total execution time: 0.2317
INFO - 2023-05-26 09:58:41 --> Config Class Initialized
INFO - 2023-05-26 09:58:41 --> Config Class Initialized
INFO - 2023-05-26 09:58:41 --> Hooks Class Initialized
INFO - 2023-05-26 09:58:41 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:58:41 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:41 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:41 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:41 --> URI Class Initialized
INFO - 2023-05-26 09:58:41 --> URI Class Initialized
INFO - 2023-05-26 09:58:41 --> Router Class Initialized
INFO - 2023-05-26 09:58:41 --> Router Class Initialized
INFO - 2023-05-26 09:58:41 --> Output Class Initialized
INFO - 2023-05-26 09:58:41 --> Output Class Initialized
INFO - 2023-05-26 09:58:41 --> Security Class Initialized
INFO - 2023-05-26 09:58:41 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:41 --> Input Class Initialized
INFO - 2023-05-26 09:58:41 --> Input Class Initialized
INFO - 2023-05-26 09:58:41 --> Language Class Initialized
INFO - 2023-05-26 09:58:41 --> Language Class Initialized
INFO - 2023-05-26 09:58:41 --> Loader Class Initialized
INFO - 2023-05-26 09:58:41 --> Controller Class Initialized
INFO - 2023-05-26 09:58:41 --> Loader Class Initialized
DEBUG - 2023-05-26 09:58:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:41 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:41 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:41 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:41 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:41 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:41 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:41 --> Total execution time: 0.1653
INFO - 2023-05-26 09:58:41 --> Config Class Initialized
INFO - 2023-05-26 09:58:41 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:41 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:41 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:41 --> URI Class Initialized
INFO - 2023-05-26 09:58:41 --> Router Class Initialized
INFO - 2023-05-26 09:58:41 --> Output Class Initialized
INFO - 2023-05-26 09:58:41 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:41 --> Input Class Initialized
INFO - 2023-05-26 09:58:41 --> Language Class Initialized
INFO - 2023-05-26 09:58:41 --> Loader Class Initialized
INFO - 2023-05-26 09:58:41 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:41 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:41 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:41 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:41 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:41 --> Total execution time: 0.2442
INFO - 2023-05-26 09:58:41 --> Model "Login_model" initialized
INFO - 2023-05-26 09:58:41 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:41 --> Total execution time: 0.6945
INFO - 2023-05-26 09:58:41 --> Config Class Initialized
INFO - 2023-05-26 09:58:41 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:41 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:41 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:41 --> URI Class Initialized
INFO - 2023-05-26 09:58:41 --> Router Class Initialized
INFO - 2023-05-26 09:58:41 --> Output Class Initialized
INFO - 2023-05-26 09:58:41 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:41 --> Input Class Initialized
INFO - 2023-05-26 09:58:41 --> Language Class Initialized
INFO - 2023-05-26 09:58:41 --> Loader Class Initialized
INFO - 2023-05-26 09:58:41 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:41 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:42 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:43 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:43 --> Model "Login_model" initialized
INFO - 2023-05-26 09:58:43 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:43 --> Total execution time: 1.7162
INFO - 2023-05-26 09:58:49 --> Config Class Initialized
INFO - 2023-05-26 09:58:49 --> Config Class Initialized
INFO - 2023-05-26 09:58:49 --> Hooks Class Initialized
INFO - 2023-05-26 09:58:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:58:49 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:58:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:49 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:49 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:49 --> URI Class Initialized
INFO - 2023-05-26 09:58:49 --> URI Class Initialized
INFO - 2023-05-26 09:58:49 --> Router Class Initialized
INFO - 2023-05-26 09:58:49 --> Router Class Initialized
INFO - 2023-05-26 09:58:49 --> Output Class Initialized
INFO - 2023-05-26 09:58:49 --> Output Class Initialized
INFO - 2023-05-26 09:58:49 --> Security Class Initialized
INFO - 2023-05-26 09:58:49 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:49 --> Input Class Initialized
INFO - 2023-05-26 09:58:49 --> Input Class Initialized
INFO - 2023-05-26 09:58:49 --> Language Class Initialized
INFO - 2023-05-26 09:58:49 --> Language Class Initialized
INFO - 2023-05-26 09:58:49 --> Loader Class Initialized
INFO - 2023-05-26 09:58:49 --> Loader Class Initialized
INFO - 2023-05-26 09:58:49 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:49 --> Controller Class Initialized
INFO - 2023-05-26 09:58:49 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:49 --> Total execution time: 0.1056
DEBUG - 2023-05-26 09:58:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:49 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:49 --> Config Class Initialized
INFO - 2023-05-26 09:58:49 --> Hooks Class Initialized
INFO - 2023-05-26 09:58:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:49 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:49 --> Total execution time: 0.1659
DEBUG - 2023-05-26 09:58:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:49 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:49 --> URI Class Initialized
INFO - 2023-05-26 09:58:49 --> Router Class Initialized
INFO - 2023-05-26 09:58:49 --> Config Class Initialized
INFO - 2023-05-26 09:58:49 --> Output Class Initialized
INFO - 2023-05-26 09:58:49 --> Hooks Class Initialized
INFO - 2023-05-26 09:58:49 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:58:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:58:49 --> Input Class Initialized
INFO - 2023-05-26 09:58:49 --> Utf8 Class Initialized
INFO - 2023-05-26 09:58:49 --> URI Class Initialized
INFO - 2023-05-26 09:58:49 --> Language Class Initialized
INFO - 2023-05-26 09:58:49 --> Router Class Initialized
INFO - 2023-05-26 09:58:49 --> Loader Class Initialized
INFO - 2023-05-26 09:58:49 --> Output Class Initialized
INFO - 2023-05-26 09:58:49 --> Controller Class Initialized
INFO - 2023-05-26 09:58:49 --> Security Class Initialized
DEBUG - 2023-05-26 09:58:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:58:49 --> Input Class Initialized
INFO - 2023-05-26 09:58:49 --> Language Class Initialized
INFO - 2023-05-26 09:58:49 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:49 --> Loader Class Initialized
INFO - 2023-05-26 09:58:49 --> Model "Login_model" initialized
INFO - 2023-05-26 09:58:49 --> Controller Class Initialized
DEBUG - 2023-05-26 09:58:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:58:49 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:49 --> Database Driver Class Initialized
INFO - 2023-05-26 09:58:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:58:49 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:49 --> Total execution time: 0.2707
INFO - 2023-05-26 09:58:49 --> Final output sent to browser
DEBUG - 2023-05-26 09:58:50 --> Total execution time: 0.2195
INFO - 2023-05-26 09:59:14 --> Config Class Initialized
INFO - 2023-05-26 09:59:14 --> Config Class Initialized
INFO - 2023-05-26 09:59:14 --> Hooks Class Initialized
INFO - 2023-05-26 09:59:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:59:14 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:59:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:14 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:14 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:14 --> URI Class Initialized
INFO - 2023-05-26 09:59:14 --> URI Class Initialized
INFO - 2023-05-26 09:59:14 --> Router Class Initialized
INFO - 2023-05-26 09:59:14 --> Router Class Initialized
INFO - 2023-05-26 09:59:14 --> Output Class Initialized
INFO - 2023-05-26 09:59:14 --> Output Class Initialized
INFO - 2023-05-26 09:59:14 --> Security Class Initialized
INFO - 2023-05-26 09:59:14 --> Security Class Initialized
DEBUG - 2023-05-26 09:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:14 --> Input Class Initialized
INFO - 2023-05-26 09:59:14 --> Input Class Initialized
INFO - 2023-05-26 09:59:14 --> Language Class Initialized
INFO - 2023-05-26 09:59:14 --> Language Class Initialized
INFO - 2023-05-26 09:59:14 --> Loader Class Initialized
INFO - 2023-05-26 09:59:14 --> Loader Class Initialized
INFO - 2023-05-26 09:59:14 --> Controller Class Initialized
INFO - 2023-05-26 09:59:14 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:59:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:14 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:14 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:14 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:14 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:14 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:14 --> Total execution time: 0.4020
INFO - 2023-05-26 09:59:14 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:14 --> Model "Login_model" initialized
INFO - 2023-05-26 09:59:14 --> Config Class Initialized
INFO - 2023-05-26 09:59:14 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:59:14 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:14 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:14 --> URI Class Initialized
INFO - 2023-05-26 09:59:14 --> Router Class Initialized
INFO - 2023-05-26 09:59:14 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:14 --> Total execution time: 0.7194
INFO - 2023-05-26 09:59:14 --> Output Class Initialized
INFO - 2023-05-26 09:59:15 --> Security Class Initialized
DEBUG - 2023-05-26 09:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:15 --> Input Class Initialized
INFO - 2023-05-26 09:59:15 --> Language Class Initialized
INFO - 2023-05-26 09:59:15 --> Config Class Initialized
INFO - 2023-05-26 09:59:15 --> Hooks Class Initialized
INFO - 2023-05-26 09:59:15 --> Loader Class Initialized
DEBUG - 2023-05-26 09:59:15 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:15 --> Controller Class Initialized
INFO - 2023-05-26 09:59:15 --> Utf8 Class Initialized
DEBUG - 2023-05-26 09:59:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:15 --> URI Class Initialized
INFO - 2023-05-26 09:59:15 --> Router Class Initialized
INFO - 2023-05-26 09:59:15 --> Output Class Initialized
INFO - 2023-05-26 09:59:15 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:15 --> Security Class Initialized
INFO - 2023-05-26 09:59:15 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 09:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:15 --> Input Class Initialized
INFO - 2023-05-26 09:59:15 --> Final output sent to browser
INFO - 2023-05-26 09:59:15 --> Language Class Initialized
DEBUG - 2023-05-26 09:59:15 --> Total execution time: 0.5412
INFO - 2023-05-26 09:59:15 --> Loader Class Initialized
INFO - 2023-05-26 09:59:15 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:15 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:15 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:15 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:15 --> Model "Login_model" initialized
INFO - 2023-05-26 09:59:15 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:15 --> Total execution time: 0.7605
INFO - 2023-05-26 09:59:33 --> Config Class Initialized
INFO - 2023-05-26 09:59:33 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:59:33 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:33 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:33 --> URI Class Initialized
INFO - 2023-05-26 09:59:33 --> Router Class Initialized
INFO - 2023-05-26 09:59:33 --> Output Class Initialized
INFO - 2023-05-26 09:59:33 --> Security Class Initialized
DEBUG - 2023-05-26 09:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:33 --> Input Class Initialized
INFO - 2023-05-26 09:59:33 --> Language Class Initialized
INFO - 2023-05-26 09:59:33 --> Loader Class Initialized
INFO - 2023-05-26 09:59:33 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:33 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:33 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:33 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:33 --> Total execution time: 0.5069
INFO - 2023-05-26 09:59:33 --> Config Class Initialized
INFO - 2023-05-26 09:59:33 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:59:33 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:33 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:33 --> URI Class Initialized
INFO - 2023-05-26 09:59:33 --> Router Class Initialized
INFO - 2023-05-26 09:59:34 --> Output Class Initialized
INFO - 2023-05-26 09:59:34 --> Security Class Initialized
DEBUG - 2023-05-26 09:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:34 --> Input Class Initialized
INFO - 2023-05-26 09:59:34 --> Language Class Initialized
INFO - 2023-05-26 09:59:34 --> Loader Class Initialized
INFO - 2023-05-26 09:59:34 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:34 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:34 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:34 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:34 --> Total execution time: 0.5605
INFO - 2023-05-26 09:59:37 --> Config Class Initialized
INFO - 2023-05-26 09:59:37 --> Hooks Class Initialized
INFO - 2023-05-26 09:59:37 --> Config Class Initialized
INFO - 2023-05-26 09:59:37 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:59:37 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:37 --> Utf8 Class Initialized
DEBUG - 2023-05-26 09:59:37 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:37 --> URI Class Initialized
INFO - 2023-05-26 09:59:37 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:37 --> URI Class Initialized
INFO - 2023-05-26 09:59:37 --> Router Class Initialized
INFO - 2023-05-26 09:59:37 --> Router Class Initialized
INFO - 2023-05-26 09:59:37 --> Output Class Initialized
INFO - 2023-05-26 09:59:37 --> Security Class Initialized
INFO - 2023-05-26 09:59:37 --> Output Class Initialized
DEBUG - 2023-05-26 09:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:37 --> Security Class Initialized
INFO - 2023-05-26 09:59:37 --> Input Class Initialized
INFO - 2023-05-26 09:59:37 --> Language Class Initialized
DEBUG - 2023-05-26 09:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:37 --> Input Class Initialized
INFO - 2023-05-26 09:59:37 --> Language Class Initialized
INFO - 2023-05-26 09:59:37 --> Loader Class Initialized
INFO - 2023-05-26 09:59:37 --> Loader Class Initialized
INFO - 2023-05-26 09:59:37 --> Controller Class Initialized
INFO - 2023-05-26 09:59:37 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:59:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:37 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:37 --> Total execution time: 0.1297
INFO - 2023-05-26 09:59:37 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:37 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:37 --> Config Class Initialized
INFO - 2023-05-26 09:59:37 --> Final output sent to browser
INFO - 2023-05-26 09:59:37 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:59:37 --> Total execution time: 0.1958
DEBUG - 2023-05-26 09:59:37 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:37 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:37 --> URI Class Initialized
INFO - 2023-05-26 09:59:37 --> Config Class Initialized
INFO - 2023-05-26 09:59:37 --> Router Class Initialized
INFO - 2023-05-26 09:59:37 --> Hooks Class Initialized
INFO - 2023-05-26 09:59:37 --> Output Class Initialized
DEBUG - 2023-05-26 09:59:37 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:37 --> Security Class Initialized
INFO - 2023-05-26 09:59:37 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:37 --> URI Class Initialized
DEBUG - 2023-05-26 09:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:37 --> Input Class Initialized
INFO - 2023-05-26 09:59:37 --> Language Class Initialized
INFO - 2023-05-26 09:59:37 --> Router Class Initialized
INFO - 2023-05-26 09:59:37 --> Output Class Initialized
INFO - 2023-05-26 09:59:37 --> Loader Class Initialized
INFO - 2023-05-26 09:59:37 --> Security Class Initialized
INFO - 2023-05-26 09:59:37 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:59:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:37 --> Input Class Initialized
INFO - 2023-05-26 09:59:37 --> Language Class Initialized
INFO - 2023-05-26 09:59:37 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:37 --> Loader Class Initialized
INFO - 2023-05-26 09:59:38 --> Controller Class Initialized
INFO - 2023-05-26 09:59:38 --> Model "Login_model" initialized
DEBUG - 2023-05-26 09:59:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:38 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:38 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:38 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:38 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:38 --> Final output sent to browser
INFO - 2023-05-26 09:59:38 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:38 --> Total execution time: 0.2762
DEBUG - 2023-05-26 09:59:38 --> Total execution time: 0.2247
INFO - 2023-05-26 09:59:43 --> Config Class Initialized
INFO - 2023-05-26 09:59:43 --> Config Class Initialized
INFO - 2023-05-26 09:59:43 --> Hooks Class Initialized
INFO - 2023-05-26 09:59:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:59:43 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:59:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:43 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:43 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:43 --> URI Class Initialized
INFO - 2023-05-26 09:59:43 --> URI Class Initialized
INFO - 2023-05-26 09:59:43 --> Router Class Initialized
INFO - 2023-05-26 09:59:43 --> Router Class Initialized
INFO - 2023-05-26 09:59:43 --> Output Class Initialized
INFO - 2023-05-26 09:59:43 --> Output Class Initialized
INFO - 2023-05-26 09:59:43 --> Security Class Initialized
INFO - 2023-05-26 09:59:43 --> Security Class Initialized
DEBUG - 2023-05-26 09:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:43 --> Input Class Initialized
INFO - 2023-05-26 09:59:43 --> Input Class Initialized
INFO - 2023-05-26 09:59:43 --> Language Class Initialized
INFO - 2023-05-26 09:59:43 --> Language Class Initialized
INFO - 2023-05-26 09:59:43 --> Loader Class Initialized
INFO - 2023-05-26 09:59:43 --> Loader Class Initialized
INFO - 2023-05-26 09:59:43 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:43 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:43 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:43 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:43 --> Final output sent to browser
INFO - 2023-05-26 09:59:43 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 09:59:43 --> Total execution time: 0.1568
INFO - 2023-05-26 09:59:43 --> Config Class Initialized
INFO - 2023-05-26 09:59:43 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:59:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:43 --> Model "Login_model" initialized
INFO - 2023-05-26 09:59:43 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:43 --> URI Class Initialized
INFO - 2023-05-26 09:59:43 --> Router Class Initialized
INFO - 2023-05-26 09:59:43 --> Output Class Initialized
INFO - 2023-05-26 09:59:43 --> Security Class Initialized
DEBUG - 2023-05-26 09:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:43 --> Input Class Initialized
INFO - 2023-05-26 09:59:43 --> Language Class Initialized
INFO - 2023-05-26 09:59:43 --> Loader Class Initialized
INFO - 2023-05-26 09:59:43 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:43 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:43 --> Total execution time: 0.3910
INFO - 2023-05-26 09:59:43 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:43 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:43 --> Total execution time: 0.2390
INFO - 2023-05-26 09:59:43 --> Config Class Initialized
INFO - 2023-05-26 09:59:43 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:59:43 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:43 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:43 --> URI Class Initialized
INFO - 2023-05-26 09:59:43 --> Router Class Initialized
INFO - 2023-05-26 09:59:43 --> Output Class Initialized
INFO - 2023-05-26 09:59:43 --> Security Class Initialized
DEBUG - 2023-05-26 09:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:43 --> Input Class Initialized
INFO - 2023-05-26 09:59:43 --> Language Class Initialized
INFO - 2023-05-26 09:59:43 --> Loader Class Initialized
INFO - 2023-05-26 09:59:43 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:43 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:43 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:43 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:43 --> Model "Login_model" initialized
INFO - 2023-05-26 09:59:43 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:43 --> Total execution time: 0.4463
INFO - 2023-05-26 09:59:49 --> Config Class Initialized
INFO - 2023-05-26 09:59:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:59:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:49 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:49 --> URI Class Initialized
INFO - 2023-05-26 09:59:49 --> Router Class Initialized
INFO - 2023-05-26 09:59:49 --> Output Class Initialized
INFO - 2023-05-26 09:59:49 --> Security Class Initialized
DEBUG - 2023-05-26 09:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:49 --> Input Class Initialized
INFO - 2023-05-26 09:59:49 --> Language Class Initialized
INFO - 2023-05-26 09:59:49 --> Loader Class Initialized
INFO - 2023-05-26 09:59:49 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:49 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:49 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:49 --> Total execution time: 0.2012
INFO - 2023-05-26 09:59:49 --> Config Class Initialized
INFO - 2023-05-26 09:59:49 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:59:49 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:49 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:49 --> URI Class Initialized
INFO - 2023-05-26 09:59:49 --> Router Class Initialized
INFO - 2023-05-26 09:59:49 --> Output Class Initialized
INFO - 2023-05-26 09:59:49 --> Security Class Initialized
DEBUG - 2023-05-26 09:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:49 --> Input Class Initialized
INFO - 2023-05-26 09:59:49 --> Language Class Initialized
INFO - 2023-05-26 09:59:49 --> Loader Class Initialized
INFO - 2023-05-26 09:59:49 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:49 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:49 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:49 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:49 --> Total execution time: 0.2113
INFO - 2023-05-26 09:59:50 --> Config Class Initialized
INFO - 2023-05-26 09:59:50 --> Config Class Initialized
INFO - 2023-05-26 09:59:50 --> Hooks Class Initialized
INFO - 2023-05-26 09:59:50 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:59:50 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:59:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:50 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:50 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:50 --> URI Class Initialized
INFO - 2023-05-26 09:59:50 --> URI Class Initialized
INFO - 2023-05-26 09:59:50 --> Router Class Initialized
INFO - 2023-05-26 09:59:50 --> Router Class Initialized
INFO - 2023-05-26 09:59:50 --> Output Class Initialized
INFO - 2023-05-26 09:59:50 --> Output Class Initialized
INFO - 2023-05-26 09:59:50 --> Security Class Initialized
INFO - 2023-05-26 09:59:50 --> Security Class Initialized
DEBUG - 2023-05-26 09:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:50 --> Input Class Initialized
INFO - 2023-05-26 09:59:50 --> Input Class Initialized
INFO - 2023-05-26 09:59:50 --> Language Class Initialized
INFO - 2023-05-26 09:59:50 --> Language Class Initialized
INFO - 2023-05-26 09:59:50 --> Loader Class Initialized
INFO - 2023-05-26 09:59:50 --> Loader Class Initialized
INFO - 2023-05-26 09:59:50 --> Controller Class Initialized
INFO - 2023-05-26 09:59:50 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 09:59:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:50 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:50 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:50 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:50 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:50 --> Total execution time: 0.2062
INFO - 2023-05-26 09:59:50 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:50 --> Total execution time: 0.2404
INFO - 2023-05-26 09:59:50 --> Config Class Initialized
INFO - 2023-05-26 09:59:50 --> Hooks Class Initialized
INFO - 2023-05-26 09:59:50 --> Config Class Initialized
DEBUG - 2023-05-26 09:59:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:50 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:50 --> Hooks Class Initialized
INFO - 2023-05-26 09:59:50 --> URI Class Initialized
DEBUG - 2023-05-26 09:59:50 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:50 --> Router Class Initialized
INFO - 2023-05-26 09:59:50 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:50 --> URI Class Initialized
INFO - 2023-05-26 09:59:51 --> Output Class Initialized
INFO - 2023-05-26 09:59:51 --> Security Class Initialized
INFO - 2023-05-26 09:59:51 --> Router Class Initialized
DEBUG - 2023-05-26 09:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:51 --> Output Class Initialized
INFO - 2023-05-26 09:59:51 --> Input Class Initialized
INFO - 2023-05-26 09:59:51 --> Security Class Initialized
INFO - 2023-05-26 09:59:51 --> Language Class Initialized
DEBUG - 2023-05-26 09:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:51 --> Input Class Initialized
INFO - 2023-05-26 09:59:51 --> Language Class Initialized
INFO - 2023-05-26 09:59:51 --> Loader Class Initialized
INFO - 2023-05-26 09:59:51 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:51 --> Loader Class Initialized
INFO - 2023-05-26 09:59:51 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:51 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:51 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:51 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:51 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:51 --> Total execution time: 0.2793
INFO - 2023-05-26 09:59:51 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:51 --> Total execution time: 0.3383
INFO - 2023-05-26 09:59:53 --> Config Class Initialized
INFO - 2023-05-26 09:59:53 --> Config Class Initialized
INFO - 2023-05-26 09:59:53 --> Hooks Class Initialized
INFO - 2023-05-26 09:59:53 --> Hooks Class Initialized
DEBUG - 2023-05-26 09:59:53 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 09:59:53 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:53 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:53 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:53 --> URI Class Initialized
INFO - 2023-05-26 09:59:53 --> URI Class Initialized
INFO - 2023-05-26 09:59:53 --> Router Class Initialized
INFO - 2023-05-26 09:59:53 --> Router Class Initialized
INFO - 2023-05-26 09:59:53 --> Output Class Initialized
INFO - 2023-05-26 09:59:53 --> Output Class Initialized
INFO - 2023-05-26 09:59:53 --> Security Class Initialized
INFO - 2023-05-26 09:59:53 --> Security Class Initialized
DEBUG - 2023-05-26 09:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 09:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:53 --> Input Class Initialized
INFO - 2023-05-26 09:59:53 --> Input Class Initialized
INFO - 2023-05-26 09:59:53 --> Language Class Initialized
INFO - 2023-05-26 09:59:53 --> Language Class Initialized
INFO - 2023-05-26 09:59:53 --> Loader Class Initialized
INFO - 2023-05-26 09:59:53 --> Loader Class Initialized
INFO - 2023-05-26 09:59:53 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:53 --> Final output sent to browser
INFO - 2023-05-26 09:59:53 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:53 --> Total execution time: 0.1037
DEBUG - 2023-05-26 09:59:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:53 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:53 --> Config Class Initialized
INFO - 2023-05-26 09:59:53 --> Hooks Class Initialized
INFO - 2023-05-26 09:59:53 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:53 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:54 --> Total execution time: 0.1693
DEBUG - 2023-05-26 09:59:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:54 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:54 --> URI Class Initialized
INFO - 2023-05-26 09:59:54 --> Router Class Initialized
INFO - 2023-05-26 09:59:54 --> Output Class Initialized
INFO - 2023-05-26 09:59:54 --> Config Class Initialized
INFO - 2023-05-26 09:59:54 --> Hooks Class Initialized
INFO - 2023-05-26 09:59:54 --> Security Class Initialized
DEBUG - 2023-05-26 09:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:54 --> Input Class Initialized
DEBUG - 2023-05-26 09:59:54 --> UTF-8 Support Enabled
INFO - 2023-05-26 09:59:54 --> Utf8 Class Initialized
INFO - 2023-05-26 09:59:54 --> Language Class Initialized
INFO - 2023-05-26 09:59:54 --> URI Class Initialized
INFO - 2023-05-26 09:59:54 --> Router Class Initialized
INFO - 2023-05-26 09:59:54 --> Loader Class Initialized
INFO - 2023-05-26 09:59:54 --> Controller Class Initialized
INFO - 2023-05-26 09:59:54 --> Output Class Initialized
DEBUG - 2023-05-26 09:59:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:54 --> Security Class Initialized
DEBUG - 2023-05-26 09:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 09:59:54 --> Input Class Initialized
INFO - 2023-05-26 09:59:54 --> Language Class Initialized
INFO - 2023-05-26 09:59:54 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:54 --> Loader Class Initialized
INFO - 2023-05-26 09:59:54 --> Model "Login_model" initialized
INFO - 2023-05-26 09:59:54 --> Controller Class Initialized
DEBUG - 2023-05-26 09:59:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 09:59:54 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:54 --> Database Driver Class Initialized
INFO - 2023-05-26 09:59:54 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:54 --> Total execution time: 0.2615
INFO - 2023-05-26 09:59:54 --> Model "Cluster_model" initialized
INFO - 2023-05-26 09:59:54 --> Final output sent to browser
DEBUG - 2023-05-26 09:59:54 --> Total execution time: 0.2275
INFO - 2023-05-26 10:06:10 --> Config Class Initialized
INFO - 2023-05-26 10:06:10 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:06:10 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:06:10 --> Utf8 Class Initialized
INFO - 2023-05-26 10:06:10 --> URI Class Initialized
INFO - 2023-05-26 10:06:10 --> Router Class Initialized
INFO - 2023-05-26 10:06:10 --> Output Class Initialized
INFO - 2023-05-26 10:06:10 --> Security Class Initialized
DEBUG - 2023-05-26 10:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:06:10 --> Input Class Initialized
INFO - 2023-05-26 10:06:10 --> Language Class Initialized
INFO - 2023-05-26 10:06:10 --> Loader Class Initialized
INFO - 2023-05-26 10:06:10 --> Controller Class Initialized
DEBUG - 2023-05-26 10:06:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:06:10 --> Database Driver Class Initialized
INFO - 2023-05-26 10:06:10 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:06:10 --> Final output sent to browser
DEBUG - 2023-05-26 10:06:10 --> Total execution time: 0.4369
INFO - 2023-05-26 10:06:11 --> Config Class Initialized
INFO - 2023-05-26 10:06:11 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:06:11 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:06:11 --> Utf8 Class Initialized
INFO - 2023-05-26 10:06:11 --> URI Class Initialized
INFO - 2023-05-26 10:06:11 --> Router Class Initialized
INFO - 2023-05-26 10:06:11 --> Output Class Initialized
INFO - 2023-05-26 10:06:11 --> Security Class Initialized
DEBUG - 2023-05-26 10:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:06:11 --> Input Class Initialized
INFO - 2023-05-26 10:06:11 --> Language Class Initialized
INFO - 2023-05-26 10:06:11 --> Loader Class Initialized
INFO - 2023-05-26 10:06:11 --> Controller Class Initialized
DEBUG - 2023-05-26 10:06:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:06:11 --> Database Driver Class Initialized
INFO - 2023-05-26 10:06:11 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:06:11 --> Final output sent to browser
DEBUG - 2023-05-26 10:06:11 --> Total execution time: 0.3894
INFO - 2023-05-26 10:14:56 --> Config Class Initialized
INFO - 2023-05-26 10:14:56 --> Config Class Initialized
INFO - 2023-05-26 10:14:56 --> Hooks Class Initialized
INFO - 2023-05-26 10:14:56 --> Hooks Class Initialized
INFO - 2023-05-26 10:14:56 --> Config Class Initialized
INFO - 2023-05-26 10:14:56 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:14:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:14:56 --> Utf8 Class Initialized
DEBUG - 2023-05-26 10:14:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:14:56 --> URI Class Initialized
INFO - 2023-05-26 10:14:56 --> Utf8 Class Initialized
INFO - 2023-05-26 10:14:56 --> URI Class Initialized
DEBUG - 2023-05-26 10:14:56 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:14:56 --> Router Class Initialized
INFO - 2023-05-26 10:14:56 --> Utf8 Class Initialized
INFO - 2023-05-26 10:14:56 --> URI Class Initialized
INFO - 2023-05-26 10:14:56 --> Router Class Initialized
INFO - 2023-05-26 10:14:56 --> Output Class Initialized
INFO - 2023-05-26 10:14:56 --> Security Class Initialized
INFO - 2023-05-26 10:14:56 --> Output Class Initialized
DEBUG - 2023-05-26 10:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:14:56 --> Security Class Initialized
INFO - 2023-05-26 10:14:56 --> Input Class Initialized
INFO - 2023-05-26 10:14:56 --> Router Class Initialized
INFO - 2023-05-26 10:14:56 --> Language Class Initialized
DEBUG - 2023-05-26 10:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:14:56 --> Input Class Initialized
INFO - 2023-05-26 10:14:56 --> Output Class Initialized
INFO - 2023-05-26 10:14:56 --> Language Class Initialized
INFO - 2023-05-26 10:14:56 --> Security Class Initialized
DEBUG - 2023-05-26 10:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:14:56 --> Loader Class Initialized
INFO - 2023-05-26 10:14:56 --> Input Class Initialized
INFO - 2023-05-26 10:14:56 --> Loader Class Initialized
INFO - 2023-05-26 10:14:56 --> Language Class Initialized
INFO - 2023-05-26 10:14:56 --> Controller Class Initialized
INFO - 2023-05-26 10:14:56 --> Controller Class Initialized
DEBUG - 2023-05-26 10:14:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 10:14:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:14:56 --> Loader Class Initialized
INFO - 2023-05-26 10:14:56 --> Controller Class Initialized
DEBUG - 2023-05-26 10:14:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:14:56 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:56 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:14:56 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:14:56 --> Config Class Initialized
INFO - 2023-05-26 10:14:56 --> Hooks Class Initialized
INFO - 2023-05-26 10:14:56 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:57 --> Final output sent to browser
DEBUG - 2023-05-26 10:14:57 --> Total execution time: 0.9133
INFO - 2023-05-26 10:14:57 --> Database Driver Class Initialized
DEBUG - 2023-05-26 10:14:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:14:57 --> Utf8 Class Initialized
INFO - 2023-05-26 10:14:57 --> Model "Login_model" initialized
INFO - 2023-05-26 10:14:57 --> URI Class Initialized
INFO - 2023-05-26 10:14:57 --> Config Class Initialized
INFO - 2023-05-26 10:14:57 --> Final output sent to browser
INFO - 2023-05-26 10:14:57 --> Config Class Initialized
INFO - 2023-05-26 10:14:57 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:14:57 --> Total execution time: 1.0337
INFO - 2023-05-26 10:14:57 --> Hooks Class Initialized
INFO - 2023-05-26 10:14:57 --> Router Class Initialized
DEBUG - 2023-05-26 10:14:57 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 10:14:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:14:57 --> Output Class Initialized
INFO - 2023-05-26 10:14:57 --> Utf8 Class Initialized
INFO - 2023-05-26 10:14:57 --> Utf8 Class Initialized
INFO - 2023-05-26 10:14:57 --> URI Class Initialized
INFO - 2023-05-26 10:14:57 --> URI Class Initialized
INFO - 2023-05-26 10:14:57 --> Security Class Initialized
INFO - 2023-05-26 10:14:57 --> Router Class Initialized
DEBUG - 2023-05-26 10:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:14:57 --> Router Class Initialized
INFO - 2023-05-26 10:14:57 --> Input Class Initialized
INFO - 2023-05-26 10:14:57 --> Output Class Initialized
INFO - 2023-05-26 10:14:57 --> Language Class Initialized
INFO - 2023-05-26 10:14:57 --> Output Class Initialized
INFO - 2023-05-26 10:14:57 --> Config Class Initialized
INFO - 2023-05-26 10:14:57 --> Hooks Class Initialized
INFO - 2023-05-26 10:14:57 --> Security Class Initialized
INFO - 2023-05-26 10:14:57 --> Security Class Initialized
DEBUG - 2023-05-26 10:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 10:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:14:57 --> Input Class Initialized
INFO - 2023-05-26 10:14:57 --> Input Class Initialized
INFO - 2023-05-26 10:14:57 --> Language Class Initialized
INFO - 2023-05-26 10:14:57 --> Language Class Initialized
DEBUG - 2023-05-26 10:14:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:14:57 --> Loader Class Initialized
INFO - 2023-05-26 10:14:57 --> Utf8 Class Initialized
INFO - 2023-05-26 10:14:57 --> URI Class Initialized
INFO - 2023-05-26 10:14:57 --> Loader Class Initialized
INFO - 2023-05-26 10:14:57 --> Loader Class Initialized
INFO - 2023-05-26 10:14:57 --> Controller Class Initialized
INFO - 2023-05-26 10:14:57 --> Controller Class Initialized
INFO - 2023-05-26 10:14:57 --> Controller Class Initialized
DEBUG - 2023-05-26 10:14:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:14:57 --> Router Class Initialized
DEBUG - 2023-05-26 10:14:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-26 10:14:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:14:57 --> Output Class Initialized
INFO - 2023-05-26 10:14:57 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:57 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:57 --> Security Class Initialized
INFO - 2023-05-26 10:14:57 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:14:57 --> Model "Cluster_model" initialized
DEBUG - 2023-05-26 10:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:14:57 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:14:57 --> Input Class Initialized
INFO - 2023-05-26 10:14:57 --> Language Class Initialized
INFO - 2023-05-26 10:14:57 --> Loader Class Initialized
INFO - 2023-05-26 10:14:57 --> Controller Class Initialized
DEBUG - 2023-05-26 10:14:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:14:57 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:57 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:57 --> Model "Login_model" initialized
INFO - 2023-05-26 10:14:57 --> Final output sent to browser
DEBUG - 2023-05-26 10:14:57 --> Total execution time: 0.6891
INFO - 2023-05-26 10:14:57 --> Final output sent to browser
DEBUG - 2023-05-26 10:14:57 --> Total execution time: 0.9581
INFO - 2023-05-26 10:14:57 --> Final output sent to browser
DEBUG - 2023-05-26 10:14:57 --> Total execution time: 0.5991
INFO - 2023-05-26 10:14:57 --> Config Class Initialized
INFO - 2023-05-26 10:14:57 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:14:57 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:14:57 --> Utf8 Class Initialized
INFO - 2023-05-26 10:14:57 --> URI Class Initialized
INFO - 2023-05-26 10:14:58 --> Router Class Initialized
INFO - 2023-05-26 10:14:58 --> Output Class Initialized
INFO - 2023-05-26 10:14:58 --> Security Class Initialized
DEBUG - 2023-05-26 10:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:14:58 --> Input Class Initialized
INFO - 2023-05-26 10:14:58 --> Language Class Initialized
INFO - 2023-05-26 10:14:58 --> Loader Class Initialized
INFO - 2023-05-26 10:14:58 --> Controller Class Initialized
DEBUG - 2023-05-26 10:14:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:14:58 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:58 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:14:58 --> Final output sent to browser
DEBUG - 2023-05-26 10:14:58 --> Total execution time: 0.4264
INFO - 2023-05-26 10:14:58 --> Config Class Initialized
INFO - 2023-05-26 10:14:58 --> Config Class Initialized
INFO - 2023-05-26 10:14:58 --> Hooks Class Initialized
INFO - 2023-05-26 10:14:58 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:14:58 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 10:14:58 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:14:58 --> Utf8 Class Initialized
INFO - 2023-05-26 10:14:58 --> Utf8 Class Initialized
INFO - 2023-05-26 10:14:58 --> URI Class Initialized
INFO - 2023-05-26 10:14:58 --> URI Class Initialized
INFO - 2023-05-26 10:14:58 --> Router Class Initialized
INFO - 2023-05-26 10:14:58 --> Router Class Initialized
INFO - 2023-05-26 10:14:58 --> Output Class Initialized
INFO - 2023-05-26 10:14:58 --> Output Class Initialized
INFO - 2023-05-26 10:14:58 --> Security Class Initialized
INFO - 2023-05-26 10:14:58 --> Security Class Initialized
DEBUG - 2023-05-26 10:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 10:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:14:58 --> Input Class Initialized
INFO - 2023-05-26 10:14:58 --> Input Class Initialized
INFO - 2023-05-26 10:14:58 --> Language Class Initialized
INFO - 2023-05-26 10:14:58 --> Language Class Initialized
INFO - 2023-05-26 10:14:58 --> Loader Class Initialized
INFO - 2023-05-26 10:14:58 --> Loader Class Initialized
INFO - 2023-05-26 10:14:58 --> Controller Class Initialized
DEBUG - 2023-05-26 10:14:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:14:58 --> Controller Class Initialized
DEBUG - 2023-05-26 10:14:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:14:58 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:58 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:14:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:14:59 --> Final output sent to browser
DEBUG - 2023-05-26 10:14:59 --> Total execution time: 0.3360
INFO - 2023-05-26 10:14:59 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:59 --> Config Class Initialized
INFO - 2023-05-26 10:14:59 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:14:59 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:14:59 --> Utf8 Class Initialized
INFO - 2023-05-26 10:14:59 --> URI Class Initialized
INFO - 2023-05-26 10:14:59 --> Router Class Initialized
INFO - 2023-05-26 10:14:59 --> Output Class Initialized
INFO - 2023-05-26 10:14:59 --> Security Class Initialized
DEBUG - 2023-05-26 10:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:14:59 --> Input Class Initialized
INFO - 2023-05-26 10:14:59 --> Language Class Initialized
INFO - 2023-05-26 10:14:59 --> Model "Login_model" initialized
INFO - 2023-05-26 10:14:59 --> Loader Class Initialized
INFO - 2023-05-26 10:14:59 --> Controller Class Initialized
DEBUG - 2023-05-26 10:14:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:14:59 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:14:59 --> Final output sent to browser
DEBUG - 2023-05-26 10:14:59 --> Total execution time: 0.3416
INFO - 2023-05-26 10:14:59 --> Final output sent to browser
DEBUG - 2023-05-26 10:14:59 --> Total execution time: 0.8313
INFO - 2023-05-26 10:14:59 --> Config Class Initialized
INFO - 2023-05-26 10:14:59 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:14:59 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:14:59 --> Utf8 Class Initialized
INFO - 2023-05-26 10:14:59 --> URI Class Initialized
INFO - 2023-05-26 10:14:59 --> Router Class Initialized
INFO - 2023-05-26 10:14:59 --> Output Class Initialized
INFO - 2023-05-26 10:14:59 --> Security Class Initialized
DEBUG - 2023-05-26 10:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:14:59 --> Input Class Initialized
INFO - 2023-05-26 10:14:59 --> Language Class Initialized
INFO - 2023-05-26 10:14:59 --> Loader Class Initialized
INFO - 2023-05-26 10:14:59 --> Controller Class Initialized
DEBUG - 2023-05-26 10:14:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:14:59 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:59 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:14:59 --> Database Driver Class Initialized
INFO - 2023-05-26 10:14:59 --> Model "Login_model" initialized
INFO - 2023-05-26 10:15:00 --> Final output sent to browser
DEBUG - 2023-05-26 10:15:00 --> Total execution time: 0.5186
INFO - 2023-05-26 10:16:27 --> Config Class Initialized
INFO - 2023-05-26 10:16:27 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:16:27 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:16:27 --> Utf8 Class Initialized
INFO - 2023-05-26 10:16:27 --> URI Class Initialized
INFO - 2023-05-26 10:16:27 --> Router Class Initialized
INFO - 2023-05-26 10:16:27 --> Output Class Initialized
INFO - 2023-05-26 10:16:27 --> Security Class Initialized
DEBUG - 2023-05-26 10:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:16:27 --> Input Class Initialized
INFO - 2023-05-26 10:16:27 --> Language Class Initialized
INFO - 2023-05-26 10:16:27 --> Loader Class Initialized
INFO - 2023-05-26 10:16:27 --> Controller Class Initialized
INFO - 2023-05-26 10:16:27 --> Helper loaded: form_helper
INFO - 2023-05-26 10:16:27 --> Helper loaded: url_helper
DEBUG - 2023-05-26 10:16:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:16:27 --> Model "Change_model" initialized
INFO - 2023-05-26 10:16:27 --> Model "Grafana_model" initialized
INFO - 2023-05-26 10:16:28 --> Final output sent to browser
DEBUG - 2023-05-26 10:16:28 --> Total execution time: 1.2927
INFO - 2023-05-26 10:16:28 --> Config Class Initialized
INFO - 2023-05-26 10:16:28 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:16:28 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:16:28 --> Utf8 Class Initialized
INFO - 2023-05-26 10:16:28 --> URI Class Initialized
INFO - 2023-05-26 10:16:28 --> Router Class Initialized
INFO - 2023-05-26 10:16:28 --> Output Class Initialized
INFO - 2023-05-26 10:16:28 --> Security Class Initialized
DEBUG - 2023-05-26 10:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:16:28 --> Input Class Initialized
INFO - 2023-05-26 10:16:28 --> Language Class Initialized
INFO - 2023-05-26 10:16:28 --> Loader Class Initialized
INFO - 2023-05-26 10:16:28 --> Controller Class Initialized
INFO - 2023-05-26 10:16:28 --> Helper loaded: form_helper
INFO - 2023-05-26 10:16:28 --> Helper loaded: url_helper
DEBUG - 2023-05-26 10:16:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:16:28 --> Final output sent to browser
DEBUG - 2023-05-26 10:16:28 --> Total execution time: 0.1411
INFO - 2023-05-26 10:16:28 --> Config Class Initialized
INFO - 2023-05-26 10:16:28 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:16:28 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:16:28 --> Utf8 Class Initialized
INFO - 2023-05-26 10:16:28 --> URI Class Initialized
INFO - 2023-05-26 10:16:28 --> Router Class Initialized
INFO - 2023-05-26 10:16:28 --> Output Class Initialized
INFO - 2023-05-26 10:16:28 --> Security Class Initialized
DEBUG - 2023-05-26 10:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:16:28 --> Input Class Initialized
INFO - 2023-05-26 10:16:28 --> Language Class Initialized
INFO - 2023-05-26 10:16:28 --> Loader Class Initialized
INFO - 2023-05-26 10:16:28 --> Controller Class Initialized
INFO - 2023-05-26 10:16:28 --> Helper loaded: form_helper
INFO - 2023-05-26 10:16:28 --> Helper loaded: url_helper
DEBUG - 2023-05-26 10:16:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:16:28 --> Database Driver Class Initialized
INFO - 2023-05-26 10:16:28 --> Model "Login_model" initialized
INFO - 2023-05-26 10:16:28 --> Final output sent to browser
DEBUG - 2023-05-26 10:16:28 --> Total execution time: 0.2198
INFO - 2023-05-26 10:16:29 --> Config Class Initialized
INFO - 2023-05-26 10:16:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:16:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:16:29 --> Utf8 Class Initialized
INFO - 2023-05-26 10:16:29 --> URI Class Initialized
INFO - 2023-05-26 10:16:29 --> Router Class Initialized
INFO - 2023-05-26 10:16:29 --> Output Class Initialized
INFO - 2023-05-26 10:16:29 --> Security Class Initialized
DEBUG - 2023-05-26 10:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:16:29 --> Input Class Initialized
INFO - 2023-05-26 10:16:29 --> Language Class Initialized
INFO - 2023-05-26 10:16:29 --> Loader Class Initialized
INFO - 2023-05-26 10:16:29 --> Controller Class Initialized
DEBUG - 2023-05-26 10:16:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:16:29 --> Database Driver Class Initialized
INFO - 2023-05-26 10:16:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:16:29 --> Final output sent to browser
DEBUG - 2023-05-26 10:16:29 --> Total execution time: 0.2565
INFO - 2023-05-26 10:16:29 --> Config Class Initialized
INFO - 2023-05-26 10:16:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:16:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:16:29 --> Utf8 Class Initialized
INFO - 2023-05-26 10:16:29 --> URI Class Initialized
INFO - 2023-05-26 10:16:29 --> Router Class Initialized
INFO - 2023-05-26 10:16:29 --> Output Class Initialized
INFO - 2023-05-26 10:16:29 --> Security Class Initialized
DEBUG - 2023-05-26 10:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:16:29 --> Input Class Initialized
INFO - 2023-05-26 10:16:29 --> Language Class Initialized
INFO - 2023-05-26 10:16:29 --> Loader Class Initialized
INFO - 2023-05-26 10:16:29 --> Controller Class Initialized
DEBUG - 2023-05-26 10:16:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:16:29 --> Database Driver Class Initialized
INFO - 2023-05-26 10:16:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:16:29 --> Final output sent to browser
DEBUG - 2023-05-26 10:16:29 --> Total execution time: 0.2074
INFO - 2023-05-26 10:16:29 --> Config Class Initialized
INFO - 2023-05-26 10:16:29 --> Config Class Initialized
INFO - 2023-05-26 10:16:29 --> Hooks Class Initialized
INFO - 2023-05-26 10:16:29 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:16:29 --> UTF-8 Support Enabled
DEBUG - 2023-05-26 10:16:29 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:16:29 --> Utf8 Class Initialized
INFO - 2023-05-26 10:16:29 --> Utf8 Class Initialized
INFO - 2023-05-26 10:16:29 --> URI Class Initialized
INFO - 2023-05-26 10:16:29 --> URI Class Initialized
INFO - 2023-05-26 10:16:29 --> Router Class Initialized
INFO - 2023-05-26 10:16:29 --> Router Class Initialized
INFO - 2023-05-26 10:16:29 --> Output Class Initialized
INFO - 2023-05-26 10:16:29 --> Output Class Initialized
INFO - 2023-05-26 10:16:29 --> Security Class Initialized
INFO - 2023-05-26 10:16:29 --> Security Class Initialized
DEBUG - 2023-05-26 10:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-26 10:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:16:29 --> Input Class Initialized
INFO - 2023-05-26 10:16:29 --> Input Class Initialized
INFO - 2023-05-26 10:16:29 --> Language Class Initialized
INFO - 2023-05-26 10:16:29 --> Language Class Initialized
INFO - 2023-05-26 10:16:29 --> Loader Class Initialized
INFO - 2023-05-26 10:16:29 --> Loader Class Initialized
INFO - 2023-05-26 10:16:29 --> Controller Class Initialized
DEBUG - 2023-05-26 10:16:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:16:29 --> Controller Class Initialized
DEBUG - 2023-05-26 10:16:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:16:29 --> Database Driver Class Initialized
INFO - 2023-05-26 10:16:29 --> Database Driver Class Initialized
INFO - 2023-05-26 10:16:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:16:29 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:16:29 --> Final output sent to browser
DEBUG - 2023-05-26 10:16:29 --> Total execution time: 0.2021
INFO - 2023-05-26 10:16:29 --> Database Driver Class Initialized
INFO - 2023-05-26 10:16:29 --> Config Class Initialized
INFO - 2023-05-26 10:16:29 --> Hooks Class Initialized
INFO - 2023-05-26 10:16:29 --> Model "Login_model" initialized
DEBUG - 2023-05-26 10:16:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:16:30 --> Utf8 Class Initialized
INFO - 2023-05-26 10:16:30 --> URI Class Initialized
INFO - 2023-05-26 10:16:30 --> Router Class Initialized
INFO - 2023-05-26 10:16:30 --> Output Class Initialized
INFO - 2023-05-26 10:16:30 --> Security Class Initialized
DEBUG - 2023-05-26 10:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:16:30 --> Input Class Initialized
INFO - 2023-05-26 10:16:30 --> Language Class Initialized
INFO - 2023-05-26 10:16:30 --> Loader Class Initialized
INFO - 2023-05-26 10:16:30 --> Controller Class Initialized
DEBUG - 2023-05-26 10:16:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:16:30 --> Database Driver Class Initialized
INFO - 2023-05-26 10:16:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:16:30 --> Final output sent to browser
DEBUG - 2023-05-26 10:16:30 --> Total execution time: 0.2515
INFO - 2023-05-26 10:16:30 --> Final output sent to browser
DEBUG - 2023-05-26 10:16:30 --> Total execution time: 0.5364
INFO - 2023-05-26 10:16:30 --> Config Class Initialized
INFO - 2023-05-26 10:16:30 --> Hooks Class Initialized
DEBUG - 2023-05-26 10:16:30 --> UTF-8 Support Enabled
INFO - 2023-05-26 10:16:30 --> Utf8 Class Initialized
INFO - 2023-05-26 10:16:30 --> URI Class Initialized
INFO - 2023-05-26 10:16:30 --> Router Class Initialized
INFO - 2023-05-26 10:16:30 --> Output Class Initialized
INFO - 2023-05-26 10:16:30 --> Security Class Initialized
DEBUG - 2023-05-26 10:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-26 10:16:30 --> Input Class Initialized
INFO - 2023-05-26 10:16:30 --> Language Class Initialized
INFO - 2023-05-26 10:16:30 --> Loader Class Initialized
INFO - 2023-05-26 10:16:30 --> Controller Class Initialized
DEBUG - 2023-05-26 10:16:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-26 10:16:30 --> Database Driver Class Initialized
INFO - 2023-05-26 10:16:30 --> Model "Cluster_model" initialized
INFO - 2023-05-26 10:16:30 --> Database Driver Class Initialized
INFO - 2023-05-26 10:16:30 --> Model "Login_model" initialized
INFO - 2023-05-26 10:16:30 --> Final output sent to browser
DEBUG - 2023-05-26 10:16:30 --> Total execution time: 0.3686
