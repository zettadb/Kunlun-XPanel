<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-12 05:50:04 --> Config Class Initialized
INFO - 2023-01-12 05:50:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:50:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:50:04 --> Utf8 Class Initialized
INFO - 2023-01-12 05:50:04 --> URI Class Initialized
INFO - 2023-01-12 05:50:04 --> Router Class Initialized
INFO - 2023-01-12 05:50:04 --> Output Class Initialized
INFO - 2023-01-12 05:50:04 --> Security Class Initialized
DEBUG - 2023-01-12 05:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:50:04 --> Input Class Initialized
INFO - 2023-01-12 05:50:04 --> Language Class Initialized
INFO - 2023-01-12 05:50:04 --> Loader Class Initialized
INFO - 2023-01-12 05:50:04 --> Controller Class Initialized
INFO - 2023-01-12 05:50:04 --> Helper loaded: form_helper
INFO - 2023-01-12 05:50:04 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:50:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:50:04 --> Model "Change_model" initialized
INFO - 2023-01-12 05:50:04 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:50:04 --> Final output sent to browser
DEBUG - 2023-01-12 05:50:04 --> Total execution time: 0.0738
INFO - 2023-01-12 05:50:04 --> Config Class Initialized
INFO - 2023-01-12 05:50:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:50:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:50:04 --> Utf8 Class Initialized
INFO - 2023-01-12 05:50:04 --> URI Class Initialized
INFO - 2023-01-12 05:50:04 --> Router Class Initialized
INFO - 2023-01-12 05:50:04 --> Output Class Initialized
INFO - 2023-01-12 05:50:04 --> Security Class Initialized
DEBUG - 2023-01-12 05:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:50:04 --> Input Class Initialized
INFO - 2023-01-12 05:50:04 --> Language Class Initialized
INFO - 2023-01-12 05:50:04 --> Loader Class Initialized
INFO - 2023-01-12 05:50:04 --> Controller Class Initialized
INFO - 2023-01-12 05:50:04 --> Helper loaded: form_helper
INFO - 2023-01-12 05:50:04 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:50:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:50:04 --> Final output sent to browser
DEBUG - 2023-01-12 05:50:04 --> Total execution time: 0.0440
INFO - 2023-01-12 05:50:04 --> Config Class Initialized
INFO - 2023-01-12 05:50:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:50:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:50:04 --> Utf8 Class Initialized
INFO - 2023-01-12 05:50:04 --> URI Class Initialized
INFO - 2023-01-12 05:50:04 --> Router Class Initialized
INFO - 2023-01-12 05:50:04 --> Output Class Initialized
INFO - 2023-01-12 05:50:04 --> Security Class Initialized
DEBUG - 2023-01-12 05:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:50:04 --> Input Class Initialized
INFO - 2023-01-12 05:50:04 --> Language Class Initialized
INFO - 2023-01-12 05:50:04 --> Loader Class Initialized
INFO - 2023-01-12 05:50:04 --> Controller Class Initialized
INFO - 2023-01-12 05:50:04 --> Helper loaded: form_helper
INFO - 2023-01-12 05:50:04 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:50:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:50:04 --> Database Driver Class Initialized
INFO - 2023-01-12 05:50:04 --> Model "Login_model" initialized
INFO - 2023-01-12 05:50:04 --> Final output sent to browser
DEBUG - 2023-01-12 05:50:04 --> Total execution time: 0.0269
INFO - 2023-01-12 05:50:09 --> Config Class Initialized
INFO - 2023-01-12 05:50:09 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:50:09 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:50:09 --> Utf8 Class Initialized
INFO - 2023-01-12 05:50:09 --> URI Class Initialized
INFO - 2023-01-12 05:50:09 --> Router Class Initialized
INFO - 2023-01-12 05:50:09 --> Output Class Initialized
INFO - 2023-01-12 05:50:09 --> Security Class Initialized
DEBUG - 2023-01-12 05:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:50:09 --> Input Class Initialized
INFO - 2023-01-12 05:50:09 --> Language Class Initialized
INFO - 2023-01-12 05:50:09 --> Loader Class Initialized
INFO - 2023-01-12 05:50:09 --> Controller Class Initialized
INFO - 2023-01-12 05:50:09 --> Helper loaded: form_helper
INFO - 2023-01-12 05:50:09 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:50:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:50:09 --> Model "Change_model" initialized
INFO - 2023-01-12 05:50:09 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:50:09 --> Final output sent to browser
DEBUG - 2023-01-12 05:50:09 --> Total execution time: 0.0698
INFO - 2023-01-12 05:50:09 --> Config Class Initialized
INFO - 2023-01-12 05:50:09 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:50:09 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:50:09 --> Utf8 Class Initialized
INFO - 2023-01-12 05:50:09 --> URI Class Initialized
INFO - 2023-01-12 05:50:09 --> Router Class Initialized
INFO - 2023-01-12 05:50:09 --> Output Class Initialized
INFO - 2023-01-12 05:50:09 --> Security Class Initialized
DEBUG - 2023-01-12 05:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:50:09 --> Input Class Initialized
INFO - 2023-01-12 05:50:09 --> Language Class Initialized
ERROR - 2023-01-12 05:50:09 --> 404 Page Not Found: Faviconico/index
INFO - 2023-01-12 05:50:18 --> Config Class Initialized
INFO - 2023-01-12 05:50:18 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:50:18 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:50:18 --> Utf8 Class Initialized
INFO - 2023-01-12 05:50:18 --> URI Class Initialized
INFO - 2023-01-12 05:50:18 --> Router Class Initialized
INFO - 2023-01-12 05:50:18 --> Output Class Initialized
INFO - 2023-01-12 05:50:18 --> Security Class Initialized
DEBUG - 2023-01-12 05:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:50:18 --> Input Class Initialized
INFO - 2023-01-12 05:50:18 --> Language Class Initialized
INFO - 2023-01-12 05:50:18 --> Loader Class Initialized
INFO - 2023-01-12 05:50:18 --> Controller Class Initialized
INFO - 2023-01-12 05:50:18 --> Helper loaded: form_helper
INFO - 2023-01-12 05:50:18 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:50:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:50:18 --> Model "Change_model" initialized
INFO - 2023-01-12 05:50:18 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:50:18 --> Final output sent to browser
DEBUG - 2023-01-12 05:50:18 --> Total execution time: 0.0272
INFO - 2023-01-12 05:50:18 --> Config Class Initialized
INFO - 2023-01-12 05:50:18 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:50:18 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:50:18 --> Utf8 Class Initialized
INFO - 2023-01-12 05:50:18 --> URI Class Initialized
INFO - 2023-01-12 05:50:18 --> Router Class Initialized
INFO - 2023-01-12 05:50:18 --> Output Class Initialized
INFO - 2023-01-12 05:50:18 --> Security Class Initialized
DEBUG - 2023-01-12 05:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:50:18 --> Input Class Initialized
INFO - 2023-01-12 05:50:18 --> Language Class Initialized
INFO - 2023-01-12 05:50:18 --> Loader Class Initialized
INFO - 2023-01-12 05:50:18 --> Controller Class Initialized
INFO - 2023-01-12 05:50:18 --> Helper loaded: form_helper
INFO - 2023-01-12 05:50:18 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:50:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:50:18 --> Final output sent to browser
DEBUG - 2023-01-12 05:50:18 --> Total execution time: 0.0023
INFO - 2023-01-12 05:50:18 --> Config Class Initialized
INFO - 2023-01-12 05:50:18 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:50:18 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:50:18 --> Utf8 Class Initialized
INFO - 2023-01-12 05:50:18 --> URI Class Initialized
INFO - 2023-01-12 05:50:18 --> Router Class Initialized
INFO - 2023-01-12 05:50:18 --> Output Class Initialized
INFO - 2023-01-12 05:50:18 --> Security Class Initialized
DEBUG - 2023-01-12 05:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:50:18 --> Input Class Initialized
INFO - 2023-01-12 05:50:18 --> Language Class Initialized
INFO - 2023-01-12 05:50:18 --> Loader Class Initialized
INFO - 2023-01-12 05:50:18 --> Controller Class Initialized
INFO - 2023-01-12 05:50:18 --> Helper loaded: form_helper
INFO - 2023-01-12 05:50:18 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:50:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:50:18 --> Database Driver Class Initialized
INFO - 2023-01-12 05:50:18 --> Model "Login_model" initialized
INFO - 2023-01-12 05:50:18 --> Final output sent to browser
DEBUG - 2023-01-12 05:50:18 --> Total execution time: 0.0131
INFO - 2023-01-12 05:50:24 --> Config Class Initialized
INFO - 2023-01-12 05:50:24 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:50:24 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:50:24 --> Utf8 Class Initialized
INFO - 2023-01-12 05:50:24 --> URI Class Initialized
INFO - 2023-01-12 05:50:24 --> Router Class Initialized
INFO - 2023-01-12 05:50:24 --> Output Class Initialized
INFO - 2023-01-12 05:50:24 --> Security Class Initialized
DEBUG - 2023-01-12 05:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:50:24 --> Input Class Initialized
INFO - 2023-01-12 05:50:24 --> Language Class Initialized
INFO - 2023-01-12 05:50:24 --> Loader Class Initialized
INFO - 2023-01-12 05:50:24 --> Controller Class Initialized
INFO - 2023-01-12 05:50:24 --> Helper loaded: form_helper
INFO - 2023-01-12 05:50:24 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:50:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:50:24 --> Model "Change_model" initialized
INFO - 2023-01-12 05:50:24 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:50:24 --> Final output sent to browser
DEBUG - 2023-01-12 05:50:24 --> Total execution time: 0.0690
INFO - 2023-01-12 05:50:48 --> Config Class Initialized
INFO - 2023-01-12 05:50:48 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:50:48 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:50:48 --> Utf8 Class Initialized
INFO - 2023-01-12 05:50:48 --> URI Class Initialized
INFO - 2023-01-12 05:50:48 --> Router Class Initialized
INFO - 2023-01-12 05:50:48 --> Output Class Initialized
INFO - 2023-01-12 05:50:48 --> Security Class Initialized
DEBUG - 2023-01-12 05:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:50:48 --> Input Class Initialized
INFO - 2023-01-12 05:50:48 --> Language Class Initialized
INFO - 2023-01-12 05:50:48 --> Loader Class Initialized
INFO - 2023-01-12 05:50:48 --> Controller Class Initialized
INFO - 2023-01-12 05:50:48 --> Helper loaded: form_helper
INFO - 2023-01-12 05:50:48 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:50:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:50:48 --> Model "Change_model" initialized
INFO - 2023-01-12 05:50:48 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:50:48 --> Final output sent to browser
DEBUG - 2023-01-12 05:50:48 --> Total execution time: 0.0247
INFO - 2023-01-12 05:50:48 --> Config Class Initialized
INFO - 2023-01-12 05:50:48 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:50:48 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:50:48 --> Utf8 Class Initialized
INFO - 2023-01-12 05:50:48 --> URI Class Initialized
INFO - 2023-01-12 05:50:48 --> Router Class Initialized
INFO - 2023-01-12 05:50:48 --> Output Class Initialized
INFO - 2023-01-12 05:50:48 --> Security Class Initialized
DEBUG - 2023-01-12 05:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:50:48 --> Input Class Initialized
INFO - 2023-01-12 05:50:48 --> Language Class Initialized
INFO - 2023-01-12 05:50:48 --> Loader Class Initialized
INFO - 2023-01-12 05:50:48 --> Controller Class Initialized
INFO - 2023-01-12 05:50:48 --> Helper loaded: form_helper
INFO - 2023-01-12 05:50:48 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:50:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:50:48 --> Final output sent to browser
DEBUG - 2023-01-12 05:50:48 --> Total execution time: 0.0021
INFO - 2023-01-12 05:50:48 --> Config Class Initialized
INFO - 2023-01-12 05:50:48 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:50:48 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:50:48 --> Utf8 Class Initialized
INFO - 2023-01-12 05:50:48 --> URI Class Initialized
INFO - 2023-01-12 05:50:48 --> Router Class Initialized
INFO - 2023-01-12 05:50:48 --> Output Class Initialized
INFO - 2023-01-12 05:50:48 --> Security Class Initialized
DEBUG - 2023-01-12 05:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:50:48 --> Input Class Initialized
INFO - 2023-01-12 05:50:48 --> Language Class Initialized
INFO - 2023-01-12 05:50:48 --> Loader Class Initialized
INFO - 2023-01-12 05:50:48 --> Controller Class Initialized
INFO - 2023-01-12 05:50:48 --> Helper loaded: form_helper
INFO - 2023-01-12 05:50:48 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:50:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:50:48 --> Database Driver Class Initialized
INFO - 2023-01-12 05:50:48 --> Model "Login_model" initialized
INFO - 2023-01-12 05:50:48 --> Final output sent to browser
DEBUG - 2023-01-12 05:50:48 --> Total execution time: 0.0111
INFO - 2023-01-12 05:51:00 --> Config Class Initialized
INFO - 2023-01-12 05:51:00 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:00 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:00 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:00 --> URI Class Initialized
INFO - 2023-01-12 05:51:00 --> Router Class Initialized
INFO - 2023-01-12 05:51:00 --> Output Class Initialized
INFO - 2023-01-12 05:51:00 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:00 --> Input Class Initialized
INFO - 2023-01-12 05:51:00 --> Language Class Initialized
INFO - 2023-01-12 05:51:00 --> Loader Class Initialized
INFO - 2023-01-12 05:51:00 --> Controller Class Initialized
INFO - 2023-01-12 05:51:00 --> Helper loaded: form_helper
INFO - 2023-01-12 05:51:00 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:51:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:00 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:00 --> Total execution time: 0.0073
INFO - 2023-01-12 05:51:00 --> Config Class Initialized
INFO - 2023-01-12 05:51:00 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:00 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:00 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:00 --> URI Class Initialized
INFO - 2023-01-12 05:51:00 --> Router Class Initialized
INFO - 2023-01-12 05:51:00 --> Output Class Initialized
INFO - 2023-01-12 05:51:00 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:00 --> Input Class Initialized
INFO - 2023-01-12 05:51:00 --> Language Class Initialized
INFO - 2023-01-12 05:51:00 --> Loader Class Initialized
INFO - 2023-01-12 05:51:00 --> Controller Class Initialized
INFO - 2023-01-12 05:51:00 --> Helper loaded: form_helper
INFO - 2023-01-12 05:51:00 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:51:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:00 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:00 --> Model "Login_model" initialized
INFO - 2023-01-12 05:51:00 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:00 --> Total execution time: 0.0205
INFO - 2023-01-12 05:51:10 --> Config Class Initialized
INFO - 2023-01-12 05:51:10 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:10 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:10 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:10 --> URI Class Initialized
INFO - 2023-01-12 05:51:10 --> Router Class Initialized
INFO - 2023-01-12 05:51:10 --> Output Class Initialized
INFO - 2023-01-12 05:51:10 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:10 --> Input Class Initialized
INFO - 2023-01-12 05:51:10 --> Language Class Initialized
INFO - 2023-01-12 05:51:10 --> Loader Class Initialized
INFO - 2023-01-12 05:51:10 --> Controller Class Initialized
INFO - 2023-01-12 05:51:10 --> Helper loaded: form_helper
INFO - 2023-01-12 05:51:10 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:10 --> Model "Change_model" initialized
INFO - 2023-01-12 05:51:10 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:51:10 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:10 --> Total execution time: 0.0434
INFO - 2023-01-12 05:51:10 --> Config Class Initialized
INFO - 2023-01-12 05:51:10 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:10 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:10 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:10 --> URI Class Initialized
INFO - 2023-01-12 05:51:10 --> Router Class Initialized
INFO - 2023-01-12 05:51:10 --> Output Class Initialized
INFO - 2023-01-12 05:51:10 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:10 --> Input Class Initialized
INFO - 2023-01-12 05:51:10 --> Language Class Initialized
INFO - 2023-01-12 05:51:10 --> Loader Class Initialized
INFO - 2023-01-12 05:51:10 --> Controller Class Initialized
INFO - 2023-01-12 05:51:10 --> Helper loaded: form_helper
INFO - 2023-01-12 05:51:10 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:10 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:10 --> Total execution time: 0.0024
INFO - 2023-01-12 05:51:10 --> Config Class Initialized
INFO - 2023-01-12 05:51:10 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:10 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:10 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:10 --> URI Class Initialized
INFO - 2023-01-12 05:51:10 --> Router Class Initialized
INFO - 2023-01-12 05:51:10 --> Output Class Initialized
INFO - 2023-01-12 05:51:10 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:10 --> Input Class Initialized
INFO - 2023-01-12 05:51:10 --> Language Class Initialized
INFO - 2023-01-12 05:51:10 --> Loader Class Initialized
INFO - 2023-01-12 05:51:10 --> Controller Class Initialized
INFO - 2023-01-12 05:51:10 --> Helper loaded: form_helper
INFO - 2023-01-12 05:51:10 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:10 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:10 --> Model "Login_model" initialized
INFO - 2023-01-12 05:51:10 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:10 --> Total execution time: 0.0223
INFO - 2023-01-12 05:51:10 --> Config Class Initialized
INFO - 2023-01-12 05:51:10 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:10 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:10 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:10 --> URI Class Initialized
INFO - 2023-01-12 05:51:10 --> Router Class Initialized
INFO - 2023-01-12 05:51:10 --> Output Class Initialized
INFO - 2023-01-12 05:51:10 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:10 --> Input Class Initialized
INFO - 2023-01-12 05:51:10 --> Language Class Initialized
INFO - 2023-01-12 05:51:10 --> Loader Class Initialized
INFO - 2023-01-12 05:51:10 --> Controller Class Initialized
DEBUG - 2023-01-12 05:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:10 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:10 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:51:10 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:10 --> Total execution time: 0.0329
INFO - 2023-01-12 05:51:10 --> Config Class Initialized
INFO - 2023-01-12 05:51:10 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:10 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:10 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:10 --> URI Class Initialized
INFO - 2023-01-12 05:51:10 --> Router Class Initialized
INFO - 2023-01-12 05:51:10 --> Output Class Initialized
INFO - 2023-01-12 05:51:10 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:10 --> Input Class Initialized
INFO - 2023-01-12 05:51:10 --> Language Class Initialized
INFO - 2023-01-12 05:51:10 --> Loader Class Initialized
INFO - 2023-01-12 05:51:10 --> Controller Class Initialized
DEBUG - 2023-01-12 05:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:10 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:10 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:51:10 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:10 --> Total execution time: 0.0119
INFO - 2023-01-12 05:51:10 --> Config Class Initialized
INFO - 2023-01-12 05:51:10 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:10 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:10 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:10 --> URI Class Initialized
INFO - 2023-01-12 05:51:10 --> Router Class Initialized
INFO - 2023-01-12 05:51:10 --> Output Class Initialized
INFO - 2023-01-12 05:51:10 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:10 --> Input Class Initialized
INFO - 2023-01-12 05:51:10 --> Language Class Initialized
INFO - 2023-01-12 05:51:10 --> Loader Class Initialized
INFO - 2023-01-12 05:51:10 --> Controller Class Initialized
DEBUG - 2023-01-12 05:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:10 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:10 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:51:10 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:10 --> Total execution time: 0.0574
INFO - 2023-01-12 05:51:10 --> Config Class Initialized
INFO - 2023-01-12 05:51:10 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:10 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:10 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:10 --> URI Class Initialized
INFO - 2023-01-12 05:51:10 --> Router Class Initialized
INFO - 2023-01-12 05:51:10 --> Output Class Initialized
INFO - 2023-01-12 05:51:10 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:10 --> Input Class Initialized
INFO - 2023-01-12 05:51:10 --> Language Class Initialized
INFO - 2023-01-12 05:51:10 --> Loader Class Initialized
INFO - 2023-01-12 05:51:10 --> Controller Class Initialized
DEBUG - 2023-01-12 05:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:10 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:10 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:51:10 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:10 --> Total execution time: 0.0535
INFO - 2023-01-12 05:51:15 --> Config Class Initialized
INFO - 2023-01-12 05:51:15 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:15 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:15 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:15 --> URI Class Initialized
INFO - 2023-01-12 05:51:15 --> Router Class Initialized
INFO - 2023-01-12 05:51:15 --> Output Class Initialized
INFO - 2023-01-12 05:51:15 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:15 --> Input Class Initialized
INFO - 2023-01-12 05:51:15 --> Language Class Initialized
INFO - 2023-01-12 05:51:15 --> Loader Class Initialized
INFO - 2023-01-12 05:51:15 --> Controller Class Initialized
DEBUG - 2023-01-12 05:51:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:15 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:15 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:51:15 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:15 --> Total execution time: 0.0124
INFO - 2023-01-12 05:51:15 --> Config Class Initialized
INFO - 2023-01-12 05:51:15 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:15 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:15 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:15 --> URI Class Initialized
INFO - 2023-01-12 05:51:15 --> Router Class Initialized
INFO - 2023-01-12 05:51:15 --> Output Class Initialized
INFO - 2023-01-12 05:51:15 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:15 --> Input Class Initialized
INFO - 2023-01-12 05:51:15 --> Language Class Initialized
INFO - 2023-01-12 05:51:15 --> Loader Class Initialized
INFO - 2023-01-12 05:51:15 --> Controller Class Initialized
DEBUG - 2023-01-12 05:51:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:15 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:15 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:51:15 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:15 --> Total execution time: 0.0570
INFO - 2023-01-12 05:51:17 --> Config Class Initialized
INFO - 2023-01-12 05:51:17 --> Config Class Initialized
INFO - 2023-01-12 05:51:17 --> Hooks Class Initialized
INFO - 2023-01-12 05:51:17 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 05:51:17 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:17 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:17 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:17 --> URI Class Initialized
INFO - 2023-01-12 05:51:17 --> URI Class Initialized
INFO - 2023-01-12 05:51:17 --> Router Class Initialized
INFO - 2023-01-12 05:51:17 --> Router Class Initialized
INFO - 2023-01-12 05:51:17 --> Output Class Initialized
INFO - 2023-01-12 05:51:17 --> Output Class Initialized
INFO - 2023-01-12 05:51:17 --> Security Class Initialized
INFO - 2023-01-12 05:51:17 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:17 --> Input Class Initialized
INFO - 2023-01-12 05:51:17 --> Language Class Initialized
INFO - 2023-01-12 05:51:17 --> Input Class Initialized
INFO - 2023-01-12 05:51:17 --> Language Class Initialized
INFO - 2023-01-12 05:51:17 --> Loader Class Initialized
INFO - 2023-01-12 05:51:17 --> Controller Class Initialized
DEBUG - 2023-01-12 05:51:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:17 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:17 --> Loader Class Initialized
INFO - 2023-01-12 05:51:17 --> Controller Class Initialized
DEBUG - 2023-01-12 05:51:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:17 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:17 --> Total execution time: 0.0091
INFO - 2023-01-12 05:51:17 --> Config Class Initialized
INFO - 2023-01-12 05:51:17 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:17 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:17 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:17 --> URI Class Initialized
INFO - 2023-01-12 05:51:17 --> Router Class Initialized
INFO - 2023-01-12 05:51:17 --> Output Class Initialized
INFO - 2023-01-12 05:51:17 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:17 --> Input Class Initialized
INFO - 2023-01-12 05:51:17 --> Language Class Initialized
INFO - 2023-01-12 05:51:17 --> Loader Class Initialized
INFO - 2023-01-12 05:51:17 --> Controller Class Initialized
DEBUG - 2023-01-12 05:51:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:17 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:17 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:51:17 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:17 --> Total execution time: 0.0240
INFO - 2023-01-12 05:51:17 --> Model "Login_model" initialized
INFO - 2023-01-12 05:51:17 --> Config Class Initialized
INFO - 2023-01-12 05:51:17 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:17 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:17 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:17 --> URI Class Initialized
INFO - 2023-01-12 05:51:17 --> Router Class Initialized
INFO - 2023-01-12 05:51:17 --> Output Class Initialized
INFO - 2023-01-12 05:51:17 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:17 --> Input Class Initialized
INFO - 2023-01-12 05:51:17 --> Language Class Initialized
INFO - 2023-01-12 05:51:17 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:17 --> Loader Class Initialized
INFO - 2023-01-12 05:51:17 --> Controller Class Initialized
DEBUG - 2023-01-12 05:51:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:17 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:17 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:51:17 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:51:17 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:17 --> Total execution time: 0.0305
INFO - 2023-01-12 05:51:17 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:17 --> Total execution time: 0.0191
INFO - 2023-01-12 05:51:21 --> Config Class Initialized
INFO - 2023-01-12 05:51:21 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:21 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:21 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:21 --> URI Class Initialized
INFO - 2023-01-12 05:51:21 --> Router Class Initialized
INFO - 2023-01-12 05:51:21 --> Output Class Initialized
INFO - 2023-01-12 05:51:21 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:21 --> Input Class Initialized
INFO - 2023-01-12 05:51:21 --> Language Class Initialized
INFO - 2023-01-12 05:51:21 --> Loader Class Initialized
INFO - 2023-01-12 05:51:21 --> Controller Class Initialized
DEBUG - 2023-01-12 05:51:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:21 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:21 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:51:21 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:21 --> Total execution time: 0.0473
INFO - 2023-01-12 05:51:21 --> Config Class Initialized
INFO - 2023-01-12 05:51:21 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:51:21 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:51:21 --> Utf8 Class Initialized
INFO - 2023-01-12 05:51:21 --> URI Class Initialized
INFO - 2023-01-12 05:51:21 --> Router Class Initialized
INFO - 2023-01-12 05:51:21 --> Output Class Initialized
INFO - 2023-01-12 05:51:21 --> Security Class Initialized
DEBUG - 2023-01-12 05:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:51:21 --> Input Class Initialized
INFO - 2023-01-12 05:51:21 --> Language Class Initialized
INFO - 2023-01-12 05:51:21 --> Loader Class Initialized
INFO - 2023-01-12 05:51:21 --> Controller Class Initialized
DEBUG - 2023-01-12 05:51:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:51:21 --> Database Driver Class Initialized
INFO - 2023-01-12 05:51:21 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:51:21 --> Final output sent to browser
DEBUG - 2023-01-12 05:51:21 --> Total execution time: 0.0150
INFO - 2023-01-12 05:52:21 --> Config Class Initialized
INFO - 2023-01-12 05:52:21 --> Config Class Initialized
INFO - 2023-01-12 05:52:21 --> Hooks Class Initialized
INFO - 2023-01-12 05:52:21 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:52:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 05:52:21 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:52:21 --> Utf8 Class Initialized
INFO - 2023-01-12 05:52:21 --> Utf8 Class Initialized
INFO - 2023-01-12 05:52:21 --> URI Class Initialized
INFO - 2023-01-12 05:52:21 --> URI Class Initialized
INFO - 2023-01-12 05:52:21 --> Router Class Initialized
INFO - 2023-01-12 05:52:21 --> Router Class Initialized
INFO - 2023-01-12 05:52:21 --> Output Class Initialized
INFO - 2023-01-12 05:52:21 --> Output Class Initialized
INFO - 2023-01-12 05:52:21 --> Security Class Initialized
INFO - 2023-01-12 05:52:21 --> Security Class Initialized
DEBUG - 2023-01-12 05:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 05:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:52:21 --> Input Class Initialized
INFO - 2023-01-12 05:52:21 --> Input Class Initialized
INFO - 2023-01-12 05:52:21 --> Language Class Initialized
INFO - 2023-01-12 05:52:21 --> Language Class Initialized
INFO - 2023-01-12 05:52:21 --> Loader Class Initialized
INFO - 2023-01-12 05:52:21 --> Loader Class Initialized
INFO - 2023-01-12 05:52:21 --> Controller Class Initialized
INFO - 2023-01-12 05:52:21 --> Controller Class Initialized
DEBUG - 2023-01-12 05:52:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-12 05:52:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:52:21 --> Final output sent to browser
DEBUG - 2023-01-12 05:52:21 --> Total execution time: 0.0043
INFO - 2023-01-12 05:52:21 --> Database Driver Class Initialized
INFO - 2023-01-12 05:52:21 --> Config Class Initialized
INFO - 2023-01-12 05:52:21 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:52:21 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:52:21 --> Utf8 Class Initialized
INFO - 2023-01-12 05:52:21 --> URI Class Initialized
INFO - 2023-01-12 05:52:21 --> Router Class Initialized
INFO - 2023-01-12 05:52:21 --> Output Class Initialized
INFO - 2023-01-12 05:52:21 --> Security Class Initialized
DEBUG - 2023-01-12 05:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:52:21 --> Input Class Initialized
INFO - 2023-01-12 05:52:21 --> Language Class Initialized
INFO - 2023-01-12 05:52:21 --> Loader Class Initialized
INFO - 2023-01-12 05:52:21 --> Controller Class Initialized
DEBUG - 2023-01-12 05:52:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:52:21 --> Database Driver Class Initialized
INFO - 2023-01-12 05:52:21 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:52:21 --> Final output sent to browser
DEBUG - 2023-01-12 05:52:21 --> Total execution time: 0.0188
INFO - 2023-01-12 05:52:21 --> Model "Login_model" initialized
INFO - 2023-01-12 05:52:21 --> Config Class Initialized
INFO - 2023-01-12 05:52:21 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:52:21 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:52:21 --> Utf8 Class Initialized
INFO - 2023-01-12 05:52:21 --> URI Class Initialized
INFO - 2023-01-12 05:52:21 --> Router Class Initialized
INFO - 2023-01-12 05:52:21 --> Output Class Initialized
INFO - 2023-01-12 05:52:21 --> Security Class Initialized
DEBUG - 2023-01-12 05:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:52:21 --> Input Class Initialized
INFO - 2023-01-12 05:52:21 --> Language Class Initialized
INFO - 2023-01-12 05:52:21 --> Loader Class Initialized
INFO - 2023-01-12 05:52:21 --> Database Driver Class Initialized
INFO - 2023-01-12 05:52:21 --> Controller Class Initialized
DEBUG - 2023-01-12 05:52:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:52:21 --> Database Driver Class Initialized
INFO - 2023-01-12 05:52:21 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:52:21 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:52:21 --> Final output sent to browser
DEBUG - 2023-01-12 05:52:21 --> Total execution time: 0.0300
INFO - 2023-01-12 05:52:21 --> Final output sent to browser
DEBUG - 2023-01-12 05:52:21 --> Total execution time: 0.0202
INFO - 2023-01-12 05:52:35 --> Config Class Initialized
INFO - 2023-01-12 05:52:35 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:52:35 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:52:35 --> Utf8 Class Initialized
INFO - 2023-01-12 05:52:35 --> URI Class Initialized
INFO - 2023-01-12 05:52:35 --> Router Class Initialized
INFO - 2023-01-12 05:52:35 --> Output Class Initialized
INFO - 2023-01-12 05:52:35 --> Security Class Initialized
DEBUG - 2023-01-12 05:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:52:35 --> Input Class Initialized
INFO - 2023-01-12 05:52:35 --> Language Class Initialized
INFO - 2023-01-12 05:52:35 --> Loader Class Initialized
INFO - 2023-01-12 05:52:35 --> Controller Class Initialized
INFO - 2023-01-12 05:52:35 --> Helper loaded: form_helper
INFO - 2023-01-12 05:52:35 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:52:35 --> Model "Change_model" initialized
INFO - 2023-01-12 05:52:35 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:52:35 --> Final output sent to browser
DEBUG - 2023-01-12 05:52:35 --> Total execution time: 0.0346
INFO - 2023-01-12 05:52:35 --> Config Class Initialized
INFO - 2023-01-12 05:52:35 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:52:35 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:52:35 --> Utf8 Class Initialized
INFO - 2023-01-12 05:52:35 --> URI Class Initialized
INFO - 2023-01-12 05:52:35 --> Router Class Initialized
INFO - 2023-01-12 05:52:35 --> Output Class Initialized
INFO - 2023-01-12 05:52:35 --> Security Class Initialized
DEBUG - 2023-01-12 05:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:52:35 --> Input Class Initialized
INFO - 2023-01-12 05:52:35 --> Language Class Initialized
INFO - 2023-01-12 05:52:35 --> Loader Class Initialized
INFO - 2023-01-12 05:52:35 --> Controller Class Initialized
INFO - 2023-01-12 05:52:35 --> Helper loaded: form_helper
INFO - 2023-01-12 05:52:35 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:52:35 --> Final output sent to browser
DEBUG - 2023-01-12 05:52:35 --> Total execution time: 0.0019
INFO - 2023-01-12 05:52:35 --> Config Class Initialized
INFO - 2023-01-12 05:52:35 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:52:35 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:52:35 --> Utf8 Class Initialized
INFO - 2023-01-12 05:52:35 --> URI Class Initialized
INFO - 2023-01-12 05:52:35 --> Router Class Initialized
INFO - 2023-01-12 05:52:35 --> Output Class Initialized
INFO - 2023-01-12 05:52:35 --> Security Class Initialized
DEBUG - 2023-01-12 05:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:52:35 --> Input Class Initialized
INFO - 2023-01-12 05:52:35 --> Language Class Initialized
INFO - 2023-01-12 05:52:35 --> Loader Class Initialized
INFO - 2023-01-12 05:52:35 --> Controller Class Initialized
INFO - 2023-01-12 05:52:35 --> Helper loaded: form_helper
INFO - 2023-01-12 05:52:35 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:52:35 --> Database Driver Class Initialized
INFO - 2023-01-12 05:52:35 --> Model "Login_model" initialized
INFO - 2023-01-12 05:52:35 --> Final output sent to browser
DEBUG - 2023-01-12 05:52:35 --> Total execution time: 0.0194
INFO - 2023-01-12 05:52:35 --> Config Class Initialized
INFO - 2023-01-12 05:52:35 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:52:35 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:52:35 --> Utf8 Class Initialized
INFO - 2023-01-12 05:52:35 --> URI Class Initialized
INFO - 2023-01-12 05:52:35 --> Router Class Initialized
INFO - 2023-01-12 05:52:35 --> Output Class Initialized
INFO - 2023-01-12 05:52:35 --> Security Class Initialized
DEBUG - 2023-01-12 05:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:52:35 --> Input Class Initialized
INFO - 2023-01-12 05:52:35 --> Language Class Initialized
INFO - 2023-01-12 05:52:35 --> Loader Class Initialized
INFO - 2023-01-12 05:52:35 --> Controller Class Initialized
DEBUG - 2023-01-12 05:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:52:35 --> Database Driver Class Initialized
INFO - 2023-01-12 05:52:35 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:52:35 --> Final output sent to browser
DEBUG - 2023-01-12 05:52:35 --> Total execution time: 0.0131
INFO - 2023-01-12 05:52:35 --> Config Class Initialized
INFO - 2023-01-12 05:52:35 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:52:35 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:52:35 --> Utf8 Class Initialized
INFO - 2023-01-12 05:52:35 --> URI Class Initialized
INFO - 2023-01-12 05:52:35 --> Router Class Initialized
INFO - 2023-01-12 05:52:35 --> Output Class Initialized
INFO - 2023-01-12 05:52:35 --> Security Class Initialized
DEBUG - 2023-01-12 05:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:52:35 --> Input Class Initialized
INFO - 2023-01-12 05:52:35 --> Language Class Initialized
INFO - 2023-01-12 05:52:35 --> Loader Class Initialized
INFO - 2023-01-12 05:52:35 --> Controller Class Initialized
DEBUG - 2023-01-12 05:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:52:35 --> Database Driver Class Initialized
INFO - 2023-01-12 05:52:35 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:52:35 --> Final output sent to browser
DEBUG - 2023-01-12 05:52:35 --> Total execution time: 0.0164
INFO - 2023-01-12 05:52:35 --> Config Class Initialized
INFO - 2023-01-12 05:52:35 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:52:35 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:52:35 --> Utf8 Class Initialized
INFO - 2023-01-12 05:52:35 --> URI Class Initialized
INFO - 2023-01-12 05:52:35 --> Router Class Initialized
INFO - 2023-01-12 05:52:35 --> Output Class Initialized
INFO - 2023-01-12 05:52:35 --> Security Class Initialized
DEBUG - 2023-01-12 05:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:52:35 --> Input Class Initialized
INFO - 2023-01-12 05:52:35 --> Language Class Initialized
INFO - 2023-01-12 05:52:35 --> Loader Class Initialized
INFO - 2023-01-12 05:52:35 --> Controller Class Initialized
DEBUG - 2023-01-12 05:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:52:35 --> Database Driver Class Initialized
INFO - 2023-01-12 05:52:35 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:52:35 --> Final output sent to browser
DEBUG - 2023-01-12 05:52:35 --> Total execution time: 0.0557
INFO - 2023-01-12 05:52:35 --> Config Class Initialized
INFO - 2023-01-12 05:52:35 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:52:35 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:52:35 --> Utf8 Class Initialized
INFO - 2023-01-12 05:52:35 --> URI Class Initialized
INFO - 2023-01-12 05:52:35 --> Router Class Initialized
INFO - 2023-01-12 05:52:35 --> Output Class Initialized
INFO - 2023-01-12 05:52:35 --> Security Class Initialized
DEBUG - 2023-01-12 05:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:52:35 --> Input Class Initialized
INFO - 2023-01-12 05:52:35 --> Language Class Initialized
INFO - 2023-01-12 05:52:35 --> Loader Class Initialized
INFO - 2023-01-12 05:52:35 --> Controller Class Initialized
DEBUG - 2023-01-12 05:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:52:35 --> Database Driver Class Initialized
INFO - 2023-01-12 05:52:35 --> Model "Cluster_model" initialized
INFO - 2023-01-12 05:52:35 --> Final output sent to browser
DEBUG - 2023-01-12 05:52:35 --> Total execution time: 0.0132
INFO - 2023-01-12 05:52:39 --> Config Class Initialized
INFO - 2023-01-12 05:52:39 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:52:39 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:52:39 --> Utf8 Class Initialized
INFO - 2023-01-12 05:52:39 --> URI Class Initialized
INFO - 2023-01-12 05:52:39 --> Router Class Initialized
INFO - 2023-01-12 05:52:39 --> Output Class Initialized
INFO - 2023-01-12 05:52:39 --> Security Class Initialized
DEBUG - 2023-01-12 05:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:52:39 --> Input Class Initialized
INFO - 2023-01-12 05:52:39 --> Language Class Initialized
INFO - 2023-01-12 05:52:39 --> Loader Class Initialized
INFO - 2023-01-12 05:52:39 --> Controller Class Initialized
INFO - 2023-01-12 05:52:39 --> Helper loaded: form_helper
INFO - 2023-01-12 05:52:39 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:52:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:52:39 --> Model "Change_model" initialized
INFO - 2023-01-12 05:52:39 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:52:39 --> Final output sent to browser
DEBUG - 2023-01-12 05:52:39 --> Total execution time: 0.0294
INFO - 2023-01-12 05:52:42 --> Config Class Initialized
INFO - 2023-01-12 05:52:42 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:52:42 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:52:42 --> Utf8 Class Initialized
INFO - 2023-01-12 05:52:42 --> URI Class Initialized
INFO - 2023-01-12 05:52:42 --> Router Class Initialized
INFO - 2023-01-12 05:52:42 --> Output Class Initialized
INFO - 2023-01-12 05:52:42 --> Security Class Initialized
DEBUG - 2023-01-12 05:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:52:42 --> Input Class Initialized
INFO - 2023-01-12 05:52:42 --> Language Class Initialized
INFO - 2023-01-12 05:52:42 --> Loader Class Initialized
INFO - 2023-01-12 05:52:42 --> Controller Class Initialized
INFO - 2023-01-12 05:52:42 --> Helper loaded: form_helper
INFO - 2023-01-12 05:52:42 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:52:42 --> Model "Change_model" initialized
INFO - 2023-01-12 05:52:42 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:52:42 --> Final output sent to browser
DEBUG - 2023-01-12 05:52:42 --> Total execution time: 0.0673
INFO - 2023-01-12 05:53:23 --> Config Class Initialized
INFO - 2023-01-12 05:53:23 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:53:23 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:53:23 --> Utf8 Class Initialized
INFO - 2023-01-12 05:53:23 --> URI Class Initialized
INFO - 2023-01-12 05:53:23 --> Router Class Initialized
INFO - 2023-01-12 05:53:23 --> Output Class Initialized
INFO - 2023-01-12 05:53:23 --> Security Class Initialized
DEBUG - 2023-01-12 05:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:53:23 --> Input Class Initialized
INFO - 2023-01-12 05:53:23 --> Language Class Initialized
INFO - 2023-01-12 05:53:23 --> Loader Class Initialized
INFO - 2023-01-12 05:53:23 --> Controller Class Initialized
INFO - 2023-01-12 05:53:23 --> Helper loaded: form_helper
INFO - 2023-01-12 05:53:23 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:53:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:53:23 --> Model "Change_model" initialized
INFO - 2023-01-12 05:56:18 --> Config Class Initialized
INFO - 2023-01-12 05:56:18 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:56:18 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:56:18 --> Utf8 Class Initialized
INFO - 2023-01-12 05:56:18 --> URI Class Initialized
INFO - 2023-01-12 05:56:18 --> Router Class Initialized
INFO - 2023-01-12 05:56:18 --> Output Class Initialized
INFO - 2023-01-12 05:56:18 --> Security Class Initialized
DEBUG - 2023-01-12 05:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:56:18 --> Input Class Initialized
INFO - 2023-01-12 05:56:18 --> Language Class Initialized
INFO - 2023-01-12 05:56:18 --> Loader Class Initialized
INFO - 2023-01-12 05:56:18 --> Controller Class Initialized
INFO - 2023-01-12 05:56:18 --> Helper loaded: form_helper
INFO - 2023-01-12 05:56:18 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:56:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:56:18 --> Model "Change_model" initialized
INFO - 2023-01-12 05:56:18 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:56:18 --> Final output sent to browser
DEBUG - 2023-01-12 05:56:18 --> Total execution time: 0.0748
INFO - 2023-01-12 05:56:52 --> Config Class Initialized
INFO - 2023-01-12 05:56:52 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:56:52 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:56:52 --> Utf8 Class Initialized
INFO - 2023-01-12 05:56:52 --> URI Class Initialized
INFO - 2023-01-12 05:56:52 --> Router Class Initialized
INFO - 2023-01-12 05:56:52 --> Output Class Initialized
INFO - 2023-01-12 05:56:52 --> Security Class Initialized
DEBUG - 2023-01-12 05:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:56:52 --> Input Class Initialized
INFO - 2023-01-12 05:56:52 --> Language Class Initialized
INFO - 2023-01-12 05:56:52 --> Loader Class Initialized
INFO - 2023-01-12 05:56:52 --> Controller Class Initialized
INFO - 2023-01-12 05:56:52 --> Helper loaded: form_helper
INFO - 2023-01-12 05:56:52 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:56:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:56:52 --> Model "Change_model" initialized
INFO - 2023-01-12 05:56:52 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:57:36 --> Config Class Initialized
INFO - 2023-01-12 05:57:36 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:57:36 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:57:36 --> Utf8 Class Initialized
INFO - 2023-01-12 05:57:36 --> URI Class Initialized
INFO - 2023-01-12 05:57:36 --> Router Class Initialized
INFO - 2023-01-12 05:57:36 --> Output Class Initialized
INFO - 2023-01-12 05:57:36 --> Security Class Initialized
DEBUG - 2023-01-12 05:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:57:36 --> Input Class Initialized
INFO - 2023-01-12 05:57:36 --> Language Class Initialized
INFO - 2023-01-12 05:57:36 --> Loader Class Initialized
INFO - 2023-01-12 05:57:36 --> Controller Class Initialized
INFO - 2023-01-12 05:57:36 --> Helper loaded: form_helper
INFO - 2023-01-12 05:57:36 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:57:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:57:36 --> Model "Change_model" initialized
INFO - 2023-01-12 05:57:36 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:57:50 --> Config Class Initialized
INFO - 2023-01-12 05:57:50 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:57:50 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:57:50 --> Utf8 Class Initialized
INFO - 2023-01-12 05:57:50 --> URI Class Initialized
INFO - 2023-01-12 05:57:50 --> Router Class Initialized
INFO - 2023-01-12 05:57:50 --> Output Class Initialized
INFO - 2023-01-12 05:57:50 --> Security Class Initialized
DEBUG - 2023-01-12 05:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:57:50 --> Input Class Initialized
INFO - 2023-01-12 05:57:50 --> Language Class Initialized
INFO - 2023-01-12 05:57:50 --> Loader Class Initialized
INFO - 2023-01-12 05:57:50 --> Controller Class Initialized
INFO - 2023-01-12 05:57:50 --> Helper loaded: form_helper
INFO - 2023-01-12 05:57:50 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:57:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:57:50 --> Model "Change_model" initialized
INFO - 2023-01-12 05:57:50 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:58:15 --> Config Class Initialized
INFO - 2023-01-12 05:58:15 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:58:15 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:58:15 --> Utf8 Class Initialized
INFO - 2023-01-12 05:58:15 --> URI Class Initialized
INFO - 2023-01-12 05:58:15 --> Router Class Initialized
INFO - 2023-01-12 05:58:15 --> Output Class Initialized
INFO - 2023-01-12 05:58:15 --> Security Class Initialized
DEBUG - 2023-01-12 05:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:58:15 --> Input Class Initialized
INFO - 2023-01-12 05:58:15 --> Language Class Initialized
INFO - 2023-01-12 05:58:15 --> Loader Class Initialized
INFO - 2023-01-12 05:58:15 --> Controller Class Initialized
INFO - 2023-01-12 05:58:15 --> Helper loaded: form_helper
INFO - 2023-01-12 05:58:15 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:58:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:58:15 --> Model "Change_model" initialized
INFO - 2023-01-12 05:58:15 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:58:16 --> Config Class Initialized
INFO - 2023-01-12 05:58:16 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:58:16 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:58:16 --> Utf8 Class Initialized
INFO - 2023-01-12 05:58:16 --> URI Class Initialized
INFO - 2023-01-12 05:58:16 --> Router Class Initialized
INFO - 2023-01-12 05:58:16 --> Output Class Initialized
INFO - 2023-01-12 05:58:16 --> Security Class Initialized
DEBUG - 2023-01-12 05:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:58:16 --> Input Class Initialized
INFO - 2023-01-12 05:58:16 --> Language Class Initialized
INFO - 2023-01-12 05:58:16 --> Loader Class Initialized
INFO - 2023-01-12 05:58:16 --> Controller Class Initialized
INFO - 2023-01-12 05:58:16 --> Helper loaded: form_helper
INFO - 2023-01-12 05:58:16 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:58:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:58:16 --> Model "Change_model" initialized
INFO - 2023-01-12 05:58:16 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:58:27 --> Config Class Initialized
INFO - 2023-01-12 05:58:27 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:58:27 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:58:27 --> Utf8 Class Initialized
INFO - 2023-01-12 05:58:27 --> URI Class Initialized
INFO - 2023-01-12 05:58:27 --> Router Class Initialized
INFO - 2023-01-12 05:58:27 --> Output Class Initialized
INFO - 2023-01-12 05:58:27 --> Security Class Initialized
DEBUG - 2023-01-12 05:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:58:27 --> Input Class Initialized
INFO - 2023-01-12 05:58:27 --> Language Class Initialized
INFO - 2023-01-12 05:58:27 --> Loader Class Initialized
INFO - 2023-01-12 05:58:27 --> Controller Class Initialized
INFO - 2023-01-12 05:58:27 --> Helper loaded: form_helper
INFO - 2023-01-12 05:58:27 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:58:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:58:27 --> Model "Change_model" initialized
INFO - 2023-01-12 05:58:27 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:59:20 --> Config Class Initialized
INFO - 2023-01-12 05:59:20 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:59:20 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:59:20 --> Utf8 Class Initialized
INFO - 2023-01-12 05:59:20 --> URI Class Initialized
INFO - 2023-01-12 05:59:20 --> Router Class Initialized
INFO - 2023-01-12 05:59:20 --> Output Class Initialized
INFO - 2023-01-12 05:59:20 --> Security Class Initialized
DEBUG - 2023-01-12 05:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:59:20 --> Input Class Initialized
INFO - 2023-01-12 05:59:20 --> Language Class Initialized
INFO - 2023-01-12 05:59:20 --> Loader Class Initialized
INFO - 2023-01-12 05:59:20 --> Controller Class Initialized
INFO - 2023-01-12 05:59:20 --> Helper loaded: form_helper
INFO - 2023-01-12 05:59:20 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:59:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:59:20 --> Model "Change_model" initialized
INFO - 2023-01-12 05:59:20 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:59:21 --> Config Class Initialized
INFO - 2023-01-12 05:59:21 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:59:21 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:59:21 --> Utf8 Class Initialized
INFO - 2023-01-12 05:59:21 --> URI Class Initialized
INFO - 2023-01-12 05:59:21 --> Router Class Initialized
INFO - 2023-01-12 05:59:21 --> Output Class Initialized
INFO - 2023-01-12 05:59:21 --> Security Class Initialized
DEBUG - 2023-01-12 05:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:59:21 --> Input Class Initialized
INFO - 2023-01-12 05:59:21 --> Language Class Initialized
INFO - 2023-01-12 05:59:21 --> Loader Class Initialized
INFO - 2023-01-12 05:59:21 --> Controller Class Initialized
INFO - 2023-01-12 05:59:21 --> Helper loaded: form_helper
INFO - 2023-01-12 05:59:21 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:59:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:59:21 --> Model "Change_model" initialized
INFO - 2023-01-12 05:59:21 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:59:36 --> Config Class Initialized
INFO - 2023-01-12 05:59:36 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:59:36 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:59:36 --> Utf8 Class Initialized
INFO - 2023-01-12 05:59:36 --> URI Class Initialized
INFO - 2023-01-12 05:59:36 --> Router Class Initialized
INFO - 2023-01-12 05:59:36 --> Output Class Initialized
INFO - 2023-01-12 05:59:36 --> Security Class Initialized
DEBUG - 2023-01-12 05:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:59:36 --> Input Class Initialized
INFO - 2023-01-12 05:59:36 --> Language Class Initialized
INFO - 2023-01-12 05:59:36 --> Loader Class Initialized
INFO - 2023-01-12 05:59:36 --> Controller Class Initialized
INFO - 2023-01-12 05:59:36 --> Helper loaded: form_helper
INFO - 2023-01-12 05:59:36 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:59:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:59:36 --> Model "Change_model" initialized
INFO - 2023-01-12 05:59:36 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:59:39 --> Config Class Initialized
INFO - 2023-01-12 05:59:39 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:59:39 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:59:39 --> Utf8 Class Initialized
INFO - 2023-01-12 05:59:39 --> URI Class Initialized
INFO - 2023-01-12 05:59:39 --> Router Class Initialized
INFO - 2023-01-12 05:59:39 --> Output Class Initialized
INFO - 2023-01-12 05:59:39 --> Security Class Initialized
DEBUG - 2023-01-12 05:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:59:39 --> Input Class Initialized
INFO - 2023-01-12 05:59:39 --> Language Class Initialized
INFO - 2023-01-12 05:59:39 --> Loader Class Initialized
INFO - 2023-01-12 05:59:39 --> Controller Class Initialized
INFO - 2023-01-12 05:59:39 --> Helper loaded: form_helper
INFO - 2023-01-12 05:59:39 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:59:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:59:39 --> Model "Change_model" initialized
INFO - 2023-01-12 05:59:39 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:59:58 --> Config Class Initialized
INFO - 2023-01-12 05:59:58 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:59:58 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:59:58 --> Utf8 Class Initialized
INFO - 2023-01-12 05:59:58 --> URI Class Initialized
INFO - 2023-01-12 05:59:58 --> Router Class Initialized
INFO - 2023-01-12 05:59:58 --> Output Class Initialized
INFO - 2023-01-12 05:59:58 --> Security Class Initialized
DEBUG - 2023-01-12 05:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:59:58 --> Input Class Initialized
INFO - 2023-01-12 05:59:58 --> Language Class Initialized
INFO - 2023-01-12 05:59:58 --> Loader Class Initialized
INFO - 2023-01-12 05:59:58 --> Controller Class Initialized
INFO - 2023-01-12 05:59:58 --> Helper loaded: form_helper
INFO - 2023-01-12 05:59:58 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:59:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:59:58 --> Model "Change_model" initialized
INFO - 2023-01-12 05:59:58 --> Model "Grafana_model" initialized
INFO - 2023-01-12 05:59:59 --> Config Class Initialized
INFO - 2023-01-12 05:59:59 --> Hooks Class Initialized
DEBUG - 2023-01-12 05:59:59 --> UTF-8 Support Enabled
INFO - 2023-01-12 05:59:59 --> Utf8 Class Initialized
INFO - 2023-01-12 05:59:59 --> URI Class Initialized
INFO - 2023-01-12 05:59:59 --> Router Class Initialized
INFO - 2023-01-12 05:59:59 --> Output Class Initialized
INFO - 2023-01-12 05:59:59 --> Security Class Initialized
DEBUG - 2023-01-12 05:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 05:59:59 --> Input Class Initialized
INFO - 2023-01-12 05:59:59 --> Language Class Initialized
INFO - 2023-01-12 05:59:59 --> Loader Class Initialized
INFO - 2023-01-12 05:59:59 --> Controller Class Initialized
INFO - 2023-01-12 05:59:59 --> Helper loaded: form_helper
INFO - 2023-01-12 05:59:59 --> Helper loaded: url_helper
DEBUG - 2023-01-12 05:59:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 05:59:59 --> Model "Change_model" initialized
INFO - 2023-01-12 05:59:59 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:00:00 --> Config Class Initialized
INFO - 2023-01-12 06:00:00 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:00:00 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:00:00 --> Utf8 Class Initialized
INFO - 2023-01-12 06:00:00 --> URI Class Initialized
INFO - 2023-01-12 06:00:00 --> Router Class Initialized
INFO - 2023-01-12 06:00:00 --> Output Class Initialized
INFO - 2023-01-12 06:00:00 --> Security Class Initialized
DEBUG - 2023-01-12 06:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:00:00 --> Input Class Initialized
INFO - 2023-01-12 06:00:00 --> Language Class Initialized
INFO - 2023-01-12 06:00:00 --> Loader Class Initialized
INFO - 2023-01-12 06:00:00 --> Controller Class Initialized
INFO - 2023-01-12 06:00:00 --> Helper loaded: form_helper
INFO - 2023-01-12 06:00:00 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:00:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:00:00 --> Model "Change_model" initialized
INFO - 2023-01-12 06:00:00 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:00:10 --> Config Class Initialized
INFO - 2023-01-12 06:00:10 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:00:10 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:00:10 --> Utf8 Class Initialized
INFO - 2023-01-12 06:00:10 --> URI Class Initialized
INFO - 2023-01-12 06:00:10 --> Router Class Initialized
INFO - 2023-01-12 06:00:10 --> Output Class Initialized
INFO - 2023-01-12 06:00:10 --> Security Class Initialized
DEBUG - 2023-01-12 06:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:00:10 --> Input Class Initialized
INFO - 2023-01-12 06:00:10 --> Language Class Initialized
INFO - 2023-01-12 06:00:10 --> Loader Class Initialized
INFO - 2023-01-12 06:00:10 --> Controller Class Initialized
INFO - 2023-01-12 06:00:10 --> Helper loaded: form_helper
INFO - 2023-01-12 06:00:10 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:00:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:00:10 --> Model "Change_model" initialized
INFO - 2023-01-12 06:00:10 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:00:48 --> Config Class Initialized
INFO - 2023-01-12 06:00:48 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:00:48 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:00:48 --> Utf8 Class Initialized
INFO - 2023-01-12 06:00:48 --> URI Class Initialized
INFO - 2023-01-12 06:00:48 --> Router Class Initialized
INFO - 2023-01-12 06:00:48 --> Output Class Initialized
INFO - 2023-01-12 06:00:48 --> Security Class Initialized
DEBUG - 2023-01-12 06:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:00:48 --> Input Class Initialized
INFO - 2023-01-12 06:00:48 --> Language Class Initialized
INFO - 2023-01-12 06:00:48 --> Loader Class Initialized
INFO - 2023-01-12 06:00:48 --> Controller Class Initialized
INFO - 2023-01-12 06:00:48 --> Helper loaded: form_helper
INFO - 2023-01-12 06:00:48 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:00:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:00:48 --> Model "Change_model" initialized
INFO - 2023-01-12 06:00:48 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:00:49 --> Config Class Initialized
INFO - 2023-01-12 06:00:49 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:00:49 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:00:49 --> Utf8 Class Initialized
INFO - 2023-01-12 06:00:49 --> URI Class Initialized
INFO - 2023-01-12 06:00:49 --> Router Class Initialized
INFO - 2023-01-12 06:00:49 --> Output Class Initialized
INFO - 2023-01-12 06:00:49 --> Security Class Initialized
DEBUG - 2023-01-12 06:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:00:49 --> Input Class Initialized
INFO - 2023-01-12 06:00:49 --> Language Class Initialized
INFO - 2023-01-12 06:00:49 --> Loader Class Initialized
INFO - 2023-01-12 06:00:49 --> Controller Class Initialized
INFO - 2023-01-12 06:00:49 --> Helper loaded: form_helper
INFO - 2023-01-12 06:00:49 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:00:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:00:49 --> Model "Change_model" initialized
INFO - 2023-01-12 06:00:49 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:00:59 --> Config Class Initialized
INFO - 2023-01-12 06:00:59 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:00:59 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:00:59 --> Utf8 Class Initialized
INFO - 2023-01-12 06:00:59 --> URI Class Initialized
INFO - 2023-01-12 06:00:59 --> Router Class Initialized
INFO - 2023-01-12 06:00:59 --> Output Class Initialized
INFO - 2023-01-12 06:00:59 --> Security Class Initialized
DEBUG - 2023-01-12 06:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:00:59 --> Input Class Initialized
INFO - 2023-01-12 06:00:59 --> Language Class Initialized
INFO - 2023-01-12 06:00:59 --> Loader Class Initialized
INFO - 2023-01-12 06:00:59 --> Controller Class Initialized
INFO - 2023-01-12 06:00:59 --> Helper loaded: form_helper
INFO - 2023-01-12 06:00:59 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:00:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:00:59 --> Model "Change_model" initialized
INFO - 2023-01-12 06:00:59 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:01:14 --> Config Class Initialized
INFO - 2023-01-12 06:01:14 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:01:14 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:01:14 --> Utf8 Class Initialized
INFO - 2023-01-12 06:01:14 --> URI Class Initialized
INFO - 2023-01-12 06:01:14 --> Router Class Initialized
INFO - 2023-01-12 06:01:14 --> Output Class Initialized
INFO - 2023-01-12 06:01:14 --> Security Class Initialized
DEBUG - 2023-01-12 06:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:01:14 --> Input Class Initialized
INFO - 2023-01-12 06:01:14 --> Language Class Initialized
INFO - 2023-01-12 06:01:14 --> Loader Class Initialized
INFO - 2023-01-12 06:01:14 --> Controller Class Initialized
INFO - 2023-01-12 06:01:14 --> Helper loaded: form_helper
INFO - 2023-01-12 06:01:14 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:01:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:01:14 --> Model "Change_model" initialized
INFO - 2023-01-12 06:01:14 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:06:29 --> Config Class Initialized
INFO - 2023-01-12 06:06:29 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:06:29 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:06:29 --> Utf8 Class Initialized
INFO - 2023-01-12 06:06:29 --> URI Class Initialized
INFO - 2023-01-12 06:06:29 --> Router Class Initialized
INFO - 2023-01-12 06:06:29 --> Output Class Initialized
INFO - 2023-01-12 06:06:29 --> Security Class Initialized
DEBUG - 2023-01-12 06:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:06:29 --> Input Class Initialized
INFO - 2023-01-12 06:06:29 --> Language Class Initialized
INFO - 2023-01-12 06:06:29 --> Loader Class Initialized
INFO - 2023-01-12 06:06:29 --> Controller Class Initialized
INFO - 2023-01-12 06:06:29 --> Helper loaded: form_helper
INFO - 2023-01-12 06:06:29 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:06:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:06:29 --> Model "Change_model" initialized
INFO - 2023-01-12 06:06:29 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:07:00 --> Config Class Initialized
INFO - 2023-01-12 06:07:00 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:07:00 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:07:00 --> Utf8 Class Initialized
INFO - 2023-01-12 06:07:00 --> URI Class Initialized
INFO - 2023-01-12 06:07:00 --> Router Class Initialized
INFO - 2023-01-12 06:07:00 --> Output Class Initialized
INFO - 2023-01-12 06:07:00 --> Security Class Initialized
DEBUG - 2023-01-12 06:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:07:00 --> Input Class Initialized
INFO - 2023-01-12 06:07:00 --> Language Class Initialized
INFO - 2023-01-12 06:07:00 --> Loader Class Initialized
INFO - 2023-01-12 06:07:00 --> Controller Class Initialized
INFO - 2023-01-12 06:07:00 --> Helper loaded: form_helper
INFO - 2023-01-12 06:07:00 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:07:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:07:00 --> Model "Change_model" initialized
INFO - 2023-01-12 06:07:00 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:07:00 --> Final output sent to browser
DEBUG - 2023-01-12 06:07:00 --> Total execution time: 0.1182
INFO - 2023-01-12 06:18:25 --> Config Class Initialized
INFO - 2023-01-12 06:18:25 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:25 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:25 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:25 --> URI Class Initialized
INFO - 2023-01-12 06:18:25 --> Router Class Initialized
INFO - 2023-01-12 06:18:25 --> Output Class Initialized
INFO - 2023-01-12 06:18:25 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:25 --> Input Class Initialized
INFO - 2023-01-12 06:18:25 --> Language Class Initialized
INFO - 2023-01-12 06:18:25 --> Loader Class Initialized
INFO - 2023-01-12 06:18:25 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:25 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:26 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:26 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:26 --> Total execution time: 1.2209
INFO - 2023-01-12 06:18:26 --> Config Class Initialized
INFO - 2023-01-12 06:18:26 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:26 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:26 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:26 --> URI Class Initialized
INFO - 2023-01-12 06:18:26 --> Router Class Initialized
INFO - 2023-01-12 06:18:26 --> Output Class Initialized
INFO - 2023-01-12 06:18:26 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:26 --> Input Class Initialized
INFO - 2023-01-12 06:18:26 --> Language Class Initialized
INFO - 2023-01-12 06:18:26 --> Loader Class Initialized
INFO - 2023-01-12 06:18:26 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:26 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:26 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:26 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:26 --> Total execution time: 0.1306
INFO - 2023-01-12 06:18:30 --> Config Class Initialized
INFO - 2023-01-12 06:18:30 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:30 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:30 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:30 --> URI Class Initialized
INFO - 2023-01-12 06:18:30 --> Router Class Initialized
INFO - 2023-01-12 06:18:30 --> Output Class Initialized
INFO - 2023-01-12 06:18:30 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:30 --> Input Class Initialized
INFO - 2023-01-12 06:18:30 --> Language Class Initialized
INFO - 2023-01-12 06:18:30 --> Loader Class Initialized
INFO - 2023-01-12 06:18:30 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:30 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:30 --> Total execution time: 0.0054
INFO - 2023-01-12 06:18:30 --> Config Class Initialized
INFO - 2023-01-12 06:18:30 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:30 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:30 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:30 --> URI Class Initialized
INFO - 2023-01-12 06:18:30 --> Router Class Initialized
INFO - 2023-01-12 06:18:30 --> Output Class Initialized
INFO - 2023-01-12 06:18:30 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:30 --> Input Class Initialized
INFO - 2023-01-12 06:18:30 --> Language Class Initialized
INFO - 2023-01-12 06:18:30 --> Loader Class Initialized
INFO - 2023-01-12 06:18:30 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:30 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:30 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:30 --> Model "Node_model" initialized
INFO - 2023-01-12 06:18:30 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:18:30 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:30 --> Total execution time: 0.2063
INFO - 2023-01-12 06:18:31 --> Config Class Initialized
INFO - 2023-01-12 06:18:31 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:31 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:31 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:31 --> URI Class Initialized
INFO - 2023-01-12 06:18:31 --> Router Class Initialized
INFO - 2023-01-12 06:18:31 --> Output Class Initialized
INFO - 2023-01-12 06:18:31 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:31 --> Input Class Initialized
INFO - 2023-01-12 06:18:31 --> Language Class Initialized
INFO - 2023-01-12 06:18:31 --> Loader Class Initialized
INFO - 2023-01-12 06:18:31 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:31 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:31 --> Total execution time: 0.0041
INFO - 2023-01-12 06:18:31 --> Config Class Initialized
INFO - 2023-01-12 06:18:31 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:31 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:31 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:31 --> URI Class Initialized
INFO - 2023-01-12 06:18:31 --> Router Class Initialized
INFO - 2023-01-12 06:18:31 --> Output Class Initialized
INFO - 2023-01-12 06:18:31 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:31 --> Input Class Initialized
INFO - 2023-01-12 06:18:31 --> Language Class Initialized
INFO - 2023-01-12 06:18:31 --> Loader Class Initialized
INFO - 2023-01-12 06:18:31 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:31 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:31 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:31 --> Model "Node_model" initialized
INFO - 2023-01-12 06:18:31 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:18:31 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:31 --> Total execution time: 0.2052
INFO - 2023-01-12 06:18:31 --> Config Class Initialized
INFO - 2023-01-12 06:18:31 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:31 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:31 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:31 --> URI Class Initialized
INFO - 2023-01-12 06:18:31 --> Router Class Initialized
INFO - 2023-01-12 06:18:31 --> Output Class Initialized
INFO - 2023-01-12 06:18:31 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:31 --> Input Class Initialized
INFO - 2023-01-12 06:18:31 --> Language Class Initialized
INFO - 2023-01-12 06:18:31 --> Loader Class Initialized
INFO - 2023-01-12 06:18:31 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:31 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:31 --> Total execution time: 0.0039
INFO - 2023-01-12 06:18:31 --> Config Class Initialized
INFO - 2023-01-12 06:18:31 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:31 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:31 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:31 --> URI Class Initialized
INFO - 2023-01-12 06:18:31 --> Router Class Initialized
INFO - 2023-01-12 06:18:31 --> Output Class Initialized
INFO - 2023-01-12 06:18:31 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:31 --> Input Class Initialized
INFO - 2023-01-12 06:18:31 --> Language Class Initialized
INFO - 2023-01-12 06:18:31 --> Loader Class Initialized
INFO - 2023-01-12 06:18:31 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:31 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:32 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:32 --> Model "Node_model" initialized
INFO - 2023-01-12 06:18:32 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:18:32 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:32 --> Total execution time: 0.2098
INFO - 2023-01-12 06:18:32 --> Config Class Initialized
INFO - 2023-01-12 06:18:32 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:32 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:32 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:32 --> URI Class Initialized
INFO - 2023-01-12 06:18:32 --> Router Class Initialized
INFO - 2023-01-12 06:18:32 --> Output Class Initialized
INFO - 2023-01-12 06:18:32 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:32 --> Input Class Initialized
INFO - 2023-01-12 06:18:32 --> Language Class Initialized
INFO - 2023-01-12 06:18:32 --> Loader Class Initialized
INFO - 2023-01-12 06:18:32 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:32 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:32 --> Total execution time: 0.0037
INFO - 2023-01-12 06:18:32 --> Config Class Initialized
INFO - 2023-01-12 06:18:32 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:32 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:32 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:32 --> URI Class Initialized
INFO - 2023-01-12 06:18:32 --> Router Class Initialized
INFO - 2023-01-12 06:18:32 --> Output Class Initialized
INFO - 2023-01-12 06:18:32 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:32 --> Input Class Initialized
INFO - 2023-01-12 06:18:32 --> Language Class Initialized
INFO - 2023-01-12 06:18:32 --> Loader Class Initialized
INFO - 2023-01-12 06:18:32 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:32 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:32 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:32 --> Model "Node_model" initialized
INFO - 2023-01-12 06:18:32 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:18:32 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:32 --> Total execution time: 0.2105
INFO - 2023-01-12 06:18:33 --> Config Class Initialized
INFO - 2023-01-12 06:18:33 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:33 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:33 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:33 --> URI Class Initialized
INFO - 2023-01-12 06:18:33 --> Router Class Initialized
INFO - 2023-01-12 06:18:33 --> Output Class Initialized
INFO - 2023-01-12 06:18:33 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:33 --> Input Class Initialized
INFO - 2023-01-12 06:18:33 --> Language Class Initialized
INFO - 2023-01-12 06:18:33 --> Loader Class Initialized
INFO - 2023-01-12 06:18:33 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:33 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:33 --> Total execution time: 0.0039
INFO - 2023-01-12 06:18:33 --> Config Class Initialized
INFO - 2023-01-12 06:18:33 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:33 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:33 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:33 --> URI Class Initialized
INFO - 2023-01-12 06:18:33 --> Router Class Initialized
INFO - 2023-01-12 06:18:33 --> Output Class Initialized
INFO - 2023-01-12 06:18:33 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:33 --> Input Class Initialized
INFO - 2023-01-12 06:18:33 --> Language Class Initialized
INFO - 2023-01-12 06:18:33 --> Loader Class Initialized
INFO - 2023-01-12 06:18:33 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:33 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:33 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:33 --> Model "Node_model" initialized
INFO - 2023-01-12 06:18:33 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:18:33 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:33 --> Total execution time: 0.2083
INFO - 2023-01-12 06:18:46 --> Config Class Initialized
INFO - 2023-01-12 06:18:46 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:46 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:46 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:46 --> URI Class Initialized
INFO - 2023-01-12 06:18:46 --> Router Class Initialized
INFO - 2023-01-12 06:18:46 --> Output Class Initialized
INFO - 2023-01-12 06:18:46 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:46 --> Input Class Initialized
INFO - 2023-01-12 06:18:46 --> Language Class Initialized
INFO - 2023-01-12 06:18:46 --> Loader Class Initialized
INFO - 2023-01-12 06:18:46 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:46 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:46 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:46 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:46 --> Total execution time: 0.1156
INFO - 2023-01-12 06:18:46 --> Config Class Initialized
INFO - 2023-01-12 06:18:46 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:46 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:46 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:46 --> URI Class Initialized
INFO - 2023-01-12 06:18:46 --> Router Class Initialized
INFO - 2023-01-12 06:18:46 --> Output Class Initialized
INFO - 2023-01-12 06:18:46 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:46 --> Input Class Initialized
INFO - 2023-01-12 06:18:46 --> Language Class Initialized
INFO - 2023-01-12 06:18:46 --> Loader Class Initialized
INFO - 2023-01-12 06:18:46 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:46 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:46 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:46 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:46 --> Total execution time: 0.1585
INFO - 2023-01-12 06:18:50 --> Config Class Initialized
INFO - 2023-01-12 06:18:50 --> Config Class Initialized
INFO - 2023-01-12 06:18:50 --> Hooks Class Initialized
INFO - 2023-01-12 06:18:50 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:50 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:50 --> Utf8 Class Initialized
DEBUG - 2023-01-12 06:18:50 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:50 --> URI Class Initialized
INFO - 2023-01-12 06:18:50 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:50 --> URI Class Initialized
INFO - 2023-01-12 06:18:50 --> Router Class Initialized
INFO - 2023-01-12 06:18:50 --> Router Class Initialized
INFO - 2023-01-12 06:18:50 --> Output Class Initialized
INFO - 2023-01-12 06:18:50 --> Output Class Initialized
INFO - 2023-01-12 06:18:50 --> Security Class Initialized
INFO - 2023-01-12 06:18:50 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:50 --> Input Class Initialized
DEBUG - 2023-01-12 06:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:50 --> Language Class Initialized
INFO - 2023-01-12 06:18:50 --> Input Class Initialized
INFO - 2023-01-12 06:18:50 --> Language Class Initialized
INFO - 2023-01-12 06:18:50 --> Loader Class Initialized
INFO - 2023-01-12 06:18:50 --> Loader Class Initialized
INFO - 2023-01-12 06:18:50 --> Controller Class Initialized
INFO - 2023-01-12 06:18:50 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-12 06:18:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:50 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:50 --> Total execution time: 0.0047
INFO - 2023-01-12 06:18:50 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:50 --> Config Class Initialized
INFO - 2023-01-12 06:18:50 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:50 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:50 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:50 --> URI Class Initialized
INFO - 2023-01-12 06:18:50 --> Router Class Initialized
INFO - 2023-01-12 06:18:50 --> Output Class Initialized
INFO - 2023-01-12 06:18:50 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:50 --> Input Class Initialized
INFO - 2023-01-12 06:18:50 --> Language Class Initialized
INFO - 2023-01-12 06:18:50 --> Loader Class Initialized
INFO - 2023-01-12 06:18:50 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:50 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:50 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:50 --> Model "Login_model" initialized
INFO - 2023-01-12 06:18:50 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:50 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:50 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:50 --> Total execution time: 0.2239
INFO - 2023-01-12 06:18:51 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:51 --> Total execution time: 1.1366
INFO - 2023-01-12 06:18:51 --> Config Class Initialized
INFO - 2023-01-12 06:18:51 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:51 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:51 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:51 --> URI Class Initialized
INFO - 2023-01-12 06:18:51 --> Router Class Initialized
INFO - 2023-01-12 06:18:51 --> Output Class Initialized
INFO - 2023-01-12 06:18:51 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:51 --> Input Class Initialized
INFO - 2023-01-12 06:18:51 --> Language Class Initialized
INFO - 2023-01-12 06:18:51 --> Loader Class Initialized
INFO - 2023-01-12 06:18:51 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:51 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:51 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:51 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:51 --> Total execution time: 0.1373
INFO - 2023-01-12 06:18:55 --> Config Class Initialized
INFO - 2023-01-12 06:18:55 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:55 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:55 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:55 --> URI Class Initialized
INFO - 2023-01-12 06:18:55 --> Router Class Initialized
INFO - 2023-01-12 06:18:55 --> Output Class Initialized
INFO - 2023-01-12 06:18:55 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:55 --> Input Class Initialized
INFO - 2023-01-12 06:18:55 --> Language Class Initialized
INFO - 2023-01-12 06:18:55 --> Loader Class Initialized
INFO - 2023-01-12 06:18:55 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:55 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:55 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:55 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:55 --> Total execution time: 0.1403
INFO - 2023-01-12 06:18:55 --> Config Class Initialized
INFO - 2023-01-12 06:18:55 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:55 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:55 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:55 --> URI Class Initialized
INFO - 2023-01-12 06:18:55 --> Router Class Initialized
INFO - 2023-01-12 06:18:55 --> Output Class Initialized
INFO - 2023-01-12 06:18:55 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:55 --> Input Class Initialized
INFO - 2023-01-12 06:18:55 --> Language Class Initialized
INFO - 2023-01-12 06:18:55 --> Loader Class Initialized
INFO - 2023-01-12 06:18:55 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:55 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:55 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:56 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:56 --> Total execution time: 0.1306
INFO - 2023-01-12 06:18:58 --> Config Class Initialized
INFO - 2023-01-12 06:18:58 --> Config Class Initialized
INFO - 2023-01-12 06:18:58 --> Hooks Class Initialized
INFO - 2023-01-12 06:18:58 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 06:18:58 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:58 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:58 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:58 --> URI Class Initialized
INFO - 2023-01-12 06:18:58 --> URI Class Initialized
INFO - 2023-01-12 06:18:58 --> Router Class Initialized
INFO - 2023-01-12 06:18:58 --> Router Class Initialized
INFO - 2023-01-12 06:18:58 --> Output Class Initialized
INFO - 2023-01-12 06:18:58 --> Output Class Initialized
INFO - 2023-01-12 06:18:58 --> Security Class Initialized
INFO - 2023-01-12 06:18:58 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 06:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:58 --> Input Class Initialized
INFO - 2023-01-12 06:18:58 --> Input Class Initialized
INFO - 2023-01-12 06:18:58 --> Language Class Initialized
INFO - 2023-01-12 06:18:58 --> Language Class Initialized
INFO - 2023-01-12 06:18:58 --> Loader Class Initialized
INFO - 2023-01-12 06:18:58 --> Loader Class Initialized
INFO - 2023-01-12 06:18:58 --> Controller Class Initialized
INFO - 2023-01-12 06:18:58 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-12 06:18:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:58 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:58 --> Total execution time: 0.0043
INFO - 2023-01-12 06:18:58 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:58 --> Config Class Initialized
INFO - 2023-01-12 06:18:58 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:58 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:58 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:58 --> URI Class Initialized
INFO - 2023-01-12 06:18:58 --> Router Class Initialized
INFO - 2023-01-12 06:18:58 --> Output Class Initialized
INFO - 2023-01-12 06:18:58 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:58 --> Input Class Initialized
INFO - 2023-01-12 06:18:58 --> Language Class Initialized
INFO - 2023-01-12 06:18:58 --> Loader Class Initialized
INFO - 2023-01-12 06:18:58 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:58 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:58 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:58 --> Model "Login_model" initialized
INFO - 2023-01-12 06:18:58 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:58 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:58 --> Total execution time: 0.1310
INFO - 2023-01-12 06:18:58 --> Config Class Initialized
INFO - 2023-01-12 06:18:58 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:18:58 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:18:58 --> Utf8 Class Initialized
INFO - 2023-01-12 06:18:58 --> URI Class Initialized
INFO - 2023-01-12 06:18:58 --> Router Class Initialized
INFO - 2023-01-12 06:18:58 --> Output Class Initialized
INFO - 2023-01-12 06:18:58 --> Security Class Initialized
DEBUG - 2023-01-12 06:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:18:58 --> Input Class Initialized
INFO - 2023-01-12 06:18:58 --> Language Class Initialized
INFO - 2023-01-12 06:18:58 --> Loader Class Initialized
INFO - 2023-01-12 06:18:58 --> Controller Class Initialized
DEBUG - 2023-01-12 06:18:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:18:58 --> Database Driver Class Initialized
INFO - 2023-01-12 06:18:58 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:58 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:58 --> Total execution time: 0.2159
INFO - 2023-01-12 06:18:58 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:18:58 --> Final output sent to browser
DEBUG - 2023-01-12 06:18:58 --> Total execution time: 0.1701
INFO - 2023-01-12 06:19:01 --> Config Class Initialized
INFO - 2023-01-12 06:19:01 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:19:01 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:19:01 --> Utf8 Class Initialized
INFO - 2023-01-12 06:19:01 --> URI Class Initialized
INFO - 2023-01-12 06:19:01 --> Router Class Initialized
INFO - 2023-01-12 06:19:01 --> Output Class Initialized
INFO - 2023-01-12 06:19:01 --> Security Class Initialized
DEBUG - 2023-01-12 06:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:19:01 --> Input Class Initialized
INFO - 2023-01-12 06:19:01 --> Language Class Initialized
INFO - 2023-01-12 06:19:01 --> Loader Class Initialized
INFO - 2023-01-12 06:19:01 --> Controller Class Initialized
DEBUG - 2023-01-12 06:19:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:19:01 --> Database Driver Class Initialized
INFO - 2023-01-12 06:19:01 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:19:01 --> Final output sent to browser
DEBUG - 2023-01-12 06:19:01 --> Total execution time: 0.1369
INFO - 2023-01-12 06:19:01 --> Config Class Initialized
INFO - 2023-01-12 06:19:01 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:19:01 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:19:01 --> Utf8 Class Initialized
INFO - 2023-01-12 06:19:01 --> URI Class Initialized
INFO - 2023-01-12 06:19:01 --> Router Class Initialized
INFO - 2023-01-12 06:19:01 --> Output Class Initialized
INFO - 2023-01-12 06:19:01 --> Security Class Initialized
DEBUG - 2023-01-12 06:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:19:01 --> Input Class Initialized
INFO - 2023-01-12 06:19:01 --> Language Class Initialized
INFO - 2023-01-12 06:19:01 --> Loader Class Initialized
INFO - 2023-01-12 06:19:01 --> Controller Class Initialized
DEBUG - 2023-01-12 06:19:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:19:01 --> Database Driver Class Initialized
INFO - 2023-01-12 06:19:01 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:19:01 --> Final output sent to browser
DEBUG - 2023-01-12 06:19:01 --> Total execution time: 0.1681
INFO - 2023-01-12 06:19:04 --> Config Class Initialized
INFO - 2023-01-12 06:19:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:19:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:19:04 --> Utf8 Class Initialized
INFO - 2023-01-12 06:19:04 --> URI Class Initialized
INFO - 2023-01-12 06:19:04 --> Router Class Initialized
INFO - 2023-01-12 06:19:04 --> Output Class Initialized
INFO - 2023-01-12 06:19:04 --> Security Class Initialized
DEBUG - 2023-01-12 06:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:19:04 --> Input Class Initialized
INFO - 2023-01-12 06:19:04 --> Language Class Initialized
INFO - 2023-01-12 06:19:04 --> Loader Class Initialized
INFO - 2023-01-12 06:19:04 --> Controller Class Initialized
DEBUG - 2023-01-12 06:19:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:19:04 --> Database Driver Class Initialized
INFO - 2023-01-12 06:19:04 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:19:04 --> Final output sent to browser
DEBUG - 2023-01-12 06:19:04 --> Total execution time: 0.1360
INFO - 2023-01-12 06:19:04 --> Config Class Initialized
INFO - 2023-01-12 06:19:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:19:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:19:04 --> Utf8 Class Initialized
INFO - 2023-01-12 06:19:04 --> URI Class Initialized
INFO - 2023-01-12 06:19:04 --> Router Class Initialized
INFO - 2023-01-12 06:19:04 --> Output Class Initialized
INFO - 2023-01-12 06:19:04 --> Security Class Initialized
DEBUG - 2023-01-12 06:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:19:04 --> Input Class Initialized
INFO - 2023-01-12 06:19:04 --> Language Class Initialized
INFO - 2023-01-12 06:19:04 --> Loader Class Initialized
INFO - 2023-01-12 06:19:04 --> Controller Class Initialized
DEBUG - 2023-01-12 06:19:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:19:04 --> Database Driver Class Initialized
INFO - 2023-01-12 06:19:04 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:19:04 --> Final output sent to browser
DEBUG - 2023-01-12 06:19:04 --> Total execution time: 0.1305
INFO - 2023-01-12 06:20:23 --> Config Class Initialized
INFO - 2023-01-12 06:20:23 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:23 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:23 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:23 --> URI Class Initialized
INFO - 2023-01-12 06:20:23 --> Router Class Initialized
INFO - 2023-01-12 06:20:23 --> Output Class Initialized
INFO - 2023-01-12 06:20:23 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:23 --> Input Class Initialized
INFO - 2023-01-12 06:20:23 --> Language Class Initialized
INFO - 2023-01-12 06:20:23 --> Loader Class Initialized
INFO - 2023-01-12 06:20:23 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:23 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:23 --> Total execution time: 0.0037
INFO - 2023-01-12 06:20:23 --> Config Class Initialized
INFO - 2023-01-12 06:20:23 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:23 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:23 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:23 --> URI Class Initialized
INFO - 2023-01-12 06:20:23 --> Router Class Initialized
INFO - 2023-01-12 06:20:23 --> Output Class Initialized
INFO - 2023-01-12 06:20:23 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:23 --> Input Class Initialized
INFO - 2023-01-12 06:20:23 --> Language Class Initialized
INFO - 2023-01-12 06:20:23 --> Loader Class Initialized
INFO - 2023-01-12 06:20:23 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:23 --> Database Driver Class Initialized
INFO - 2023-01-12 06:20:23 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:20:23 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:23 --> Total execution time: 0.1161
INFO - 2023-01-12 06:20:23 --> Config Class Initialized
INFO - 2023-01-12 06:20:23 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:23 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:23 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:23 --> URI Class Initialized
INFO - 2023-01-12 06:20:23 --> Router Class Initialized
INFO - 2023-01-12 06:20:23 --> Output Class Initialized
INFO - 2023-01-12 06:20:23 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:23 --> Input Class Initialized
INFO - 2023-01-12 06:20:23 --> Language Class Initialized
INFO - 2023-01-12 06:20:23 --> Loader Class Initialized
INFO - 2023-01-12 06:20:23 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:23 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:23 --> Total execution time: 0.0426
INFO - 2023-01-12 06:20:23 --> Config Class Initialized
INFO - 2023-01-12 06:20:23 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:23 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:23 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:23 --> URI Class Initialized
INFO - 2023-01-12 06:20:23 --> Router Class Initialized
INFO - 2023-01-12 06:20:23 --> Output Class Initialized
INFO - 2023-01-12 06:20:23 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:23 --> Input Class Initialized
INFO - 2023-01-12 06:20:23 --> Language Class Initialized
INFO - 2023-01-12 06:20:23 --> Loader Class Initialized
INFO - 2023-01-12 06:20:23 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:23 --> Database Driver Class Initialized
INFO - 2023-01-12 06:20:23 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:20:23 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:23 --> Total execution time: 0.1068
INFO - 2023-01-12 06:20:38 --> Config Class Initialized
INFO - 2023-01-12 06:20:38 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:38 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:38 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:38 --> URI Class Initialized
INFO - 2023-01-12 06:20:38 --> Router Class Initialized
INFO - 2023-01-12 06:20:38 --> Output Class Initialized
INFO - 2023-01-12 06:20:38 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:38 --> Input Class Initialized
INFO - 2023-01-12 06:20:38 --> Language Class Initialized
INFO - 2023-01-12 06:20:38 --> Loader Class Initialized
INFO - 2023-01-12 06:20:38 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:38 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:38 --> Total execution time: 0.0080
INFO - 2023-01-12 06:20:38 --> Config Class Initialized
INFO - 2023-01-12 06:20:38 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:38 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:38 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:38 --> URI Class Initialized
INFO - 2023-01-12 06:20:38 --> Router Class Initialized
INFO - 2023-01-12 06:20:38 --> Output Class Initialized
INFO - 2023-01-12 06:20:38 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:38 --> Input Class Initialized
INFO - 2023-01-12 06:20:38 --> Language Class Initialized
INFO - 2023-01-12 06:20:38 --> Loader Class Initialized
INFO - 2023-01-12 06:20:38 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:38 --> Database Driver Class Initialized
INFO - 2023-01-12 06:20:39 --> Model "Login_model" initialized
INFO - 2023-01-12 06:20:39 --> Database Driver Class Initialized
INFO - 2023-01-12 06:20:39 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:20:39 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:39 --> Total execution time: 0.0351
INFO - 2023-01-12 06:20:39 --> Config Class Initialized
INFO - 2023-01-12 06:20:39 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:39 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:39 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:39 --> URI Class Initialized
INFO - 2023-01-12 06:20:39 --> Router Class Initialized
INFO - 2023-01-12 06:20:39 --> Output Class Initialized
INFO - 2023-01-12 06:20:39 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:39 --> Input Class Initialized
INFO - 2023-01-12 06:20:39 --> Language Class Initialized
INFO - 2023-01-12 06:20:39 --> Loader Class Initialized
INFO - 2023-01-12 06:20:39 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:39 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:39 --> Total execution time: 0.0086
INFO - 2023-01-12 06:20:39 --> Config Class Initialized
INFO - 2023-01-12 06:20:39 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:39 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:39 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:39 --> URI Class Initialized
INFO - 2023-01-12 06:20:39 --> Router Class Initialized
INFO - 2023-01-12 06:20:39 --> Output Class Initialized
INFO - 2023-01-12 06:20:39 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:39 --> Input Class Initialized
INFO - 2023-01-12 06:20:39 --> Language Class Initialized
INFO - 2023-01-12 06:20:39 --> Loader Class Initialized
INFO - 2023-01-12 06:20:39 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:39 --> Database Driver Class Initialized
INFO - 2023-01-12 06:20:39 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:20:39 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:39 --> Total execution time: 0.1572
INFO - 2023-01-12 06:20:44 --> Config Class Initialized
INFO - 2023-01-12 06:20:44 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:44 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:44 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:44 --> URI Class Initialized
INFO - 2023-01-12 06:20:44 --> Router Class Initialized
INFO - 2023-01-12 06:20:44 --> Output Class Initialized
INFO - 2023-01-12 06:20:44 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:44 --> Input Class Initialized
INFO - 2023-01-12 06:20:44 --> Language Class Initialized
INFO - 2023-01-12 06:20:44 --> Loader Class Initialized
INFO - 2023-01-12 06:20:44 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:44 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:44 --> Total execution time: 0.0040
INFO - 2023-01-12 06:20:44 --> Config Class Initialized
INFO - 2023-01-12 06:20:44 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:44 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:44 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:44 --> URI Class Initialized
INFO - 2023-01-12 06:20:44 --> Router Class Initialized
INFO - 2023-01-12 06:20:44 --> Output Class Initialized
INFO - 2023-01-12 06:20:44 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:44 --> Input Class Initialized
INFO - 2023-01-12 06:20:44 --> Language Class Initialized
INFO - 2023-01-12 06:20:44 --> Loader Class Initialized
INFO - 2023-01-12 06:20:44 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:44 --> Database Driver Class Initialized
INFO - 2023-01-12 06:20:44 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:20:44 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:44 --> Total execution time: 0.0155
INFO - 2023-01-12 06:20:49 --> Config Class Initialized
INFO - 2023-01-12 06:20:49 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:49 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:49 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:49 --> URI Class Initialized
INFO - 2023-01-12 06:20:49 --> Router Class Initialized
INFO - 2023-01-12 06:20:49 --> Output Class Initialized
INFO - 2023-01-12 06:20:49 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:49 --> Input Class Initialized
INFO - 2023-01-12 06:20:49 --> Language Class Initialized
INFO - 2023-01-12 06:20:49 --> Loader Class Initialized
INFO - 2023-01-12 06:20:49 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:49 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:49 --> Total execution time: 0.0042
INFO - 2023-01-12 06:20:49 --> Config Class Initialized
INFO - 2023-01-12 06:20:49 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:49 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:49 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:49 --> URI Class Initialized
INFO - 2023-01-12 06:20:49 --> Router Class Initialized
INFO - 2023-01-12 06:20:49 --> Output Class Initialized
INFO - 2023-01-12 06:20:49 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:49 --> Input Class Initialized
INFO - 2023-01-12 06:20:49 --> Language Class Initialized
INFO - 2023-01-12 06:20:49 --> Loader Class Initialized
INFO - 2023-01-12 06:20:49 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:49 --> Database Driver Class Initialized
INFO - 2023-01-12 06:20:49 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:20:49 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:49 --> Total execution time: 0.0122
INFO - 2023-01-12 06:20:54 --> Config Class Initialized
INFO - 2023-01-12 06:20:54 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:54 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:54 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:54 --> URI Class Initialized
INFO - 2023-01-12 06:20:54 --> Router Class Initialized
INFO - 2023-01-12 06:20:54 --> Output Class Initialized
INFO - 2023-01-12 06:20:54 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:54 --> Input Class Initialized
INFO - 2023-01-12 06:20:54 --> Language Class Initialized
INFO - 2023-01-12 06:20:54 --> Loader Class Initialized
INFO - 2023-01-12 06:20:54 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:54 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:54 --> Total execution time: 0.0040
INFO - 2023-01-12 06:20:54 --> Config Class Initialized
INFO - 2023-01-12 06:20:54 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:54 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:54 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:54 --> URI Class Initialized
INFO - 2023-01-12 06:20:54 --> Router Class Initialized
INFO - 2023-01-12 06:20:54 --> Output Class Initialized
INFO - 2023-01-12 06:20:54 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:54 --> Input Class Initialized
INFO - 2023-01-12 06:20:54 --> Language Class Initialized
INFO - 2023-01-12 06:20:54 --> Loader Class Initialized
INFO - 2023-01-12 06:20:54 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:54 --> Database Driver Class Initialized
INFO - 2023-01-12 06:20:54 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:20:54 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:54 --> Total execution time: 0.0209
INFO - 2023-01-12 06:20:59 --> Config Class Initialized
INFO - 2023-01-12 06:20:59 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:59 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:59 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:59 --> URI Class Initialized
INFO - 2023-01-12 06:20:59 --> Router Class Initialized
INFO - 2023-01-12 06:20:59 --> Output Class Initialized
INFO - 2023-01-12 06:20:59 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:59 --> Input Class Initialized
INFO - 2023-01-12 06:20:59 --> Language Class Initialized
INFO - 2023-01-12 06:20:59 --> Loader Class Initialized
INFO - 2023-01-12 06:20:59 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:59 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:59 --> Total execution time: 0.0036
INFO - 2023-01-12 06:20:59 --> Config Class Initialized
INFO - 2023-01-12 06:20:59 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:20:59 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:20:59 --> Utf8 Class Initialized
INFO - 2023-01-12 06:20:59 --> URI Class Initialized
INFO - 2023-01-12 06:20:59 --> Router Class Initialized
INFO - 2023-01-12 06:20:59 --> Output Class Initialized
INFO - 2023-01-12 06:20:59 --> Security Class Initialized
DEBUG - 2023-01-12 06:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:20:59 --> Input Class Initialized
INFO - 2023-01-12 06:20:59 --> Language Class Initialized
INFO - 2023-01-12 06:20:59 --> Loader Class Initialized
INFO - 2023-01-12 06:20:59 --> Controller Class Initialized
DEBUG - 2023-01-12 06:20:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:20:59 --> Database Driver Class Initialized
INFO - 2023-01-12 06:20:59 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:20:59 --> Final output sent to browser
DEBUG - 2023-01-12 06:20:59 --> Total execution time: 0.0392
INFO - 2023-01-12 06:21:04 --> Config Class Initialized
INFO - 2023-01-12 06:21:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:04 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:04 --> URI Class Initialized
INFO - 2023-01-12 06:21:04 --> Router Class Initialized
INFO - 2023-01-12 06:21:04 --> Output Class Initialized
INFO - 2023-01-12 06:21:04 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:04 --> Input Class Initialized
INFO - 2023-01-12 06:21:04 --> Language Class Initialized
INFO - 2023-01-12 06:21:04 --> Loader Class Initialized
INFO - 2023-01-12 06:21:04 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:04 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:04 --> Total execution time: 0.0040
INFO - 2023-01-12 06:21:04 --> Config Class Initialized
INFO - 2023-01-12 06:21:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:04 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:04 --> URI Class Initialized
INFO - 2023-01-12 06:21:04 --> Router Class Initialized
INFO - 2023-01-12 06:21:04 --> Output Class Initialized
INFO - 2023-01-12 06:21:04 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:04 --> Input Class Initialized
INFO - 2023-01-12 06:21:04 --> Language Class Initialized
INFO - 2023-01-12 06:21:04 --> Loader Class Initialized
INFO - 2023-01-12 06:21:04 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:04 --> Database Driver Class Initialized
INFO - 2023-01-12 06:21:04 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:21:04 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:04 --> Total execution time: 0.0154
INFO - 2023-01-12 06:21:09 --> Config Class Initialized
INFO - 2023-01-12 06:21:09 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:09 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:09 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:09 --> URI Class Initialized
INFO - 2023-01-12 06:21:09 --> Router Class Initialized
INFO - 2023-01-12 06:21:09 --> Output Class Initialized
INFO - 2023-01-12 06:21:09 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:09 --> Input Class Initialized
INFO - 2023-01-12 06:21:09 --> Language Class Initialized
INFO - 2023-01-12 06:21:09 --> Loader Class Initialized
INFO - 2023-01-12 06:21:09 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:09 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:09 --> Total execution time: 0.0050
INFO - 2023-01-12 06:21:09 --> Config Class Initialized
INFO - 2023-01-12 06:21:09 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:09 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:09 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:09 --> URI Class Initialized
INFO - 2023-01-12 06:21:09 --> Router Class Initialized
INFO - 2023-01-12 06:21:09 --> Output Class Initialized
INFO - 2023-01-12 06:21:09 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:09 --> Input Class Initialized
INFO - 2023-01-12 06:21:09 --> Language Class Initialized
INFO - 2023-01-12 06:21:09 --> Loader Class Initialized
INFO - 2023-01-12 06:21:09 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:09 --> Database Driver Class Initialized
INFO - 2023-01-12 06:21:09 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:21:09 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:09 --> Total execution time: 0.0182
INFO - 2023-01-12 06:21:14 --> Config Class Initialized
INFO - 2023-01-12 06:21:14 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:14 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:14 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:14 --> URI Class Initialized
INFO - 2023-01-12 06:21:14 --> Router Class Initialized
INFO - 2023-01-12 06:21:14 --> Output Class Initialized
INFO - 2023-01-12 06:21:14 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:14 --> Input Class Initialized
INFO - 2023-01-12 06:21:14 --> Language Class Initialized
INFO - 2023-01-12 06:21:14 --> Loader Class Initialized
INFO - 2023-01-12 06:21:14 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:14 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:14 --> Total execution time: 0.0037
INFO - 2023-01-12 06:21:14 --> Config Class Initialized
INFO - 2023-01-12 06:21:14 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:14 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:14 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:14 --> URI Class Initialized
INFO - 2023-01-12 06:21:14 --> Router Class Initialized
INFO - 2023-01-12 06:21:14 --> Output Class Initialized
INFO - 2023-01-12 06:21:14 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:14 --> Input Class Initialized
INFO - 2023-01-12 06:21:14 --> Language Class Initialized
INFO - 2023-01-12 06:21:14 --> Loader Class Initialized
INFO - 2023-01-12 06:21:14 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:14 --> Database Driver Class Initialized
INFO - 2023-01-12 06:21:14 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:21:14 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:14 --> Total execution time: 0.0169
INFO - 2023-01-12 06:21:19 --> Config Class Initialized
INFO - 2023-01-12 06:21:19 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:19 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:19 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:19 --> URI Class Initialized
INFO - 2023-01-12 06:21:19 --> Router Class Initialized
INFO - 2023-01-12 06:21:19 --> Output Class Initialized
INFO - 2023-01-12 06:21:19 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:19 --> Input Class Initialized
INFO - 2023-01-12 06:21:19 --> Language Class Initialized
INFO - 2023-01-12 06:21:19 --> Loader Class Initialized
INFO - 2023-01-12 06:21:19 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:19 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:19 --> Total execution time: 0.0040
INFO - 2023-01-12 06:21:19 --> Config Class Initialized
INFO - 2023-01-12 06:21:19 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:19 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:19 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:19 --> URI Class Initialized
INFO - 2023-01-12 06:21:19 --> Router Class Initialized
INFO - 2023-01-12 06:21:19 --> Output Class Initialized
INFO - 2023-01-12 06:21:19 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:19 --> Input Class Initialized
INFO - 2023-01-12 06:21:19 --> Language Class Initialized
INFO - 2023-01-12 06:21:19 --> Loader Class Initialized
INFO - 2023-01-12 06:21:19 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:19 --> Database Driver Class Initialized
INFO - 2023-01-12 06:21:19 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:21:19 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:19 --> Total execution time: 0.0160
INFO - 2023-01-12 06:21:24 --> Config Class Initialized
INFO - 2023-01-12 06:21:24 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:24 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:24 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:24 --> URI Class Initialized
INFO - 2023-01-12 06:21:24 --> Router Class Initialized
INFO - 2023-01-12 06:21:24 --> Output Class Initialized
INFO - 2023-01-12 06:21:24 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:24 --> Input Class Initialized
INFO - 2023-01-12 06:21:24 --> Language Class Initialized
INFO - 2023-01-12 06:21:24 --> Loader Class Initialized
INFO - 2023-01-12 06:21:24 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:24 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:24 --> Total execution time: 0.0041
INFO - 2023-01-12 06:21:24 --> Config Class Initialized
INFO - 2023-01-12 06:21:24 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:24 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:24 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:24 --> URI Class Initialized
INFO - 2023-01-12 06:21:24 --> Router Class Initialized
INFO - 2023-01-12 06:21:24 --> Output Class Initialized
INFO - 2023-01-12 06:21:24 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:24 --> Input Class Initialized
INFO - 2023-01-12 06:21:24 --> Language Class Initialized
INFO - 2023-01-12 06:21:24 --> Loader Class Initialized
INFO - 2023-01-12 06:21:24 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:24 --> Database Driver Class Initialized
INFO - 2023-01-12 06:21:24 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:21:24 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:24 --> Total execution time: 0.0173
INFO - 2023-01-12 06:21:29 --> Config Class Initialized
INFO - 2023-01-12 06:21:29 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:29 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:29 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:29 --> URI Class Initialized
INFO - 2023-01-12 06:21:29 --> Router Class Initialized
INFO - 2023-01-12 06:21:29 --> Output Class Initialized
INFO - 2023-01-12 06:21:29 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:29 --> Input Class Initialized
INFO - 2023-01-12 06:21:29 --> Language Class Initialized
INFO - 2023-01-12 06:21:29 --> Loader Class Initialized
INFO - 2023-01-12 06:21:29 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:29 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:29 --> Total execution time: 0.0043
INFO - 2023-01-12 06:21:29 --> Config Class Initialized
INFO - 2023-01-12 06:21:29 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:29 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:29 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:29 --> URI Class Initialized
INFO - 2023-01-12 06:21:29 --> Router Class Initialized
INFO - 2023-01-12 06:21:29 --> Output Class Initialized
INFO - 2023-01-12 06:21:29 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:29 --> Input Class Initialized
INFO - 2023-01-12 06:21:29 --> Language Class Initialized
INFO - 2023-01-12 06:21:29 --> Loader Class Initialized
INFO - 2023-01-12 06:21:29 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:29 --> Database Driver Class Initialized
INFO - 2023-01-12 06:21:29 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:21:29 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:29 --> Total execution time: 0.0162
INFO - 2023-01-12 06:21:34 --> Config Class Initialized
INFO - 2023-01-12 06:21:34 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:34 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:34 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:34 --> URI Class Initialized
INFO - 2023-01-12 06:21:34 --> Router Class Initialized
INFO - 2023-01-12 06:21:34 --> Output Class Initialized
INFO - 2023-01-12 06:21:34 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:34 --> Input Class Initialized
INFO - 2023-01-12 06:21:34 --> Language Class Initialized
INFO - 2023-01-12 06:21:34 --> Loader Class Initialized
INFO - 2023-01-12 06:21:34 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:34 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:34 --> Total execution time: 0.0045
INFO - 2023-01-12 06:21:34 --> Config Class Initialized
INFO - 2023-01-12 06:21:34 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:34 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:34 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:34 --> URI Class Initialized
INFO - 2023-01-12 06:21:34 --> Router Class Initialized
INFO - 2023-01-12 06:21:34 --> Output Class Initialized
INFO - 2023-01-12 06:21:34 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:34 --> Input Class Initialized
INFO - 2023-01-12 06:21:34 --> Language Class Initialized
INFO - 2023-01-12 06:21:34 --> Loader Class Initialized
INFO - 2023-01-12 06:21:34 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:34 --> Database Driver Class Initialized
INFO - 2023-01-12 06:21:34 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:21:34 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:34 --> Total execution time: 0.0167
INFO - 2023-01-12 06:21:39 --> Config Class Initialized
INFO - 2023-01-12 06:21:39 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:39 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:39 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:39 --> URI Class Initialized
INFO - 2023-01-12 06:21:39 --> Router Class Initialized
INFO - 2023-01-12 06:21:39 --> Output Class Initialized
INFO - 2023-01-12 06:21:39 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:39 --> Input Class Initialized
INFO - 2023-01-12 06:21:39 --> Language Class Initialized
INFO - 2023-01-12 06:21:39 --> Loader Class Initialized
INFO - 2023-01-12 06:21:39 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:39 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:39 --> Total execution time: 0.0109
INFO - 2023-01-12 06:21:39 --> Config Class Initialized
INFO - 2023-01-12 06:21:39 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:39 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:39 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:39 --> URI Class Initialized
INFO - 2023-01-12 06:21:39 --> Router Class Initialized
INFO - 2023-01-12 06:21:39 --> Output Class Initialized
INFO - 2023-01-12 06:21:39 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:39 --> Input Class Initialized
INFO - 2023-01-12 06:21:39 --> Language Class Initialized
INFO - 2023-01-12 06:21:39 --> Loader Class Initialized
INFO - 2023-01-12 06:21:39 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:39 --> Database Driver Class Initialized
INFO - 2023-01-12 06:21:39 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:21:39 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:39 --> Total execution time: 0.0155
INFO - 2023-01-12 06:21:44 --> Config Class Initialized
INFO - 2023-01-12 06:21:44 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:44 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:44 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:44 --> URI Class Initialized
INFO - 2023-01-12 06:21:44 --> Router Class Initialized
INFO - 2023-01-12 06:21:44 --> Output Class Initialized
INFO - 2023-01-12 06:21:44 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:44 --> Input Class Initialized
INFO - 2023-01-12 06:21:44 --> Language Class Initialized
INFO - 2023-01-12 06:21:44 --> Loader Class Initialized
INFO - 2023-01-12 06:21:44 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:44 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:44 --> Total execution time: 0.0059
INFO - 2023-01-12 06:21:44 --> Config Class Initialized
INFO - 2023-01-12 06:21:44 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:44 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:44 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:44 --> URI Class Initialized
INFO - 2023-01-12 06:21:44 --> Router Class Initialized
INFO - 2023-01-12 06:21:44 --> Output Class Initialized
INFO - 2023-01-12 06:21:44 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:44 --> Input Class Initialized
INFO - 2023-01-12 06:21:44 --> Language Class Initialized
INFO - 2023-01-12 06:21:44 --> Loader Class Initialized
INFO - 2023-01-12 06:21:44 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:44 --> Database Driver Class Initialized
INFO - 2023-01-12 06:21:44 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:21:44 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:44 --> Total execution time: 0.0203
INFO - 2023-01-12 06:21:49 --> Config Class Initialized
INFO - 2023-01-12 06:21:49 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:49 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:49 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:49 --> URI Class Initialized
INFO - 2023-01-12 06:21:49 --> Router Class Initialized
INFO - 2023-01-12 06:21:49 --> Output Class Initialized
INFO - 2023-01-12 06:21:49 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:49 --> Input Class Initialized
INFO - 2023-01-12 06:21:49 --> Language Class Initialized
INFO - 2023-01-12 06:21:49 --> Loader Class Initialized
INFO - 2023-01-12 06:21:49 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:49 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:49 --> Total execution time: 0.0042
INFO - 2023-01-12 06:21:49 --> Config Class Initialized
INFO - 2023-01-12 06:21:49 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:49 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:49 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:49 --> URI Class Initialized
INFO - 2023-01-12 06:21:49 --> Router Class Initialized
INFO - 2023-01-12 06:21:49 --> Output Class Initialized
INFO - 2023-01-12 06:21:49 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:49 --> Input Class Initialized
INFO - 2023-01-12 06:21:49 --> Language Class Initialized
INFO - 2023-01-12 06:21:49 --> Loader Class Initialized
INFO - 2023-01-12 06:21:49 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:49 --> Database Driver Class Initialized
INFO - 2023-01-12 06:21:49 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:21:49 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:49 --> Total execution time: 0.0189
INFO - 2023-01-12 06:21:54 --> Config Class Initialized
INFO - 2023-01-12 06:21:54 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:54 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:54 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:54 --> URI Class Initialized
INFO - 2023-01-12 06:21:54 --> Router Class Initialized
INFO - 2023-01-12 06:21:54 --> Output Class Initialized
INFO - 2023-01-12 06:21:54 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:54 --> Input Class Initialized
INFO - 2023-01-12 06:21:54 --> Language Class Initialized
INFO - 2023-01-12 06:21:54 --> Loader Class Initialized
INFO - 2023-01-12 06:21:54 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:54 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:54 --> Total execution time: 0.0040
INFO - 2023-01-12 06:21:54 --> Config Class Initialized
INFO - 2023-01-12 06:21:54 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:54 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:54 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:54 --> URI Class Initialized
INFO - 2023-01-12 06:21:54 --> Router Class Initialized
INFO - 2023-01-12 06:21:54 --> Output Class Initialized
INFO - 2023-01-12 06:21:54 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:54 --> Input Class Initialized
INFO - 2023-01-12 06:21:54 --> Language Class Initialized
INFO - 2023-01-12 06:21:54 --> Loader Class Initialized
INFO - 2023-01-12 06:21:54 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:54 --> Database Driver Class Initialized
INFO - 2023-01-12 06:21:54 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:21:54 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:54 --> Total execution time: 0.0134
INFO - 2023-01-12 06:21:59 --> Config Class Initialized
INFO - 2023-01-12 06:21:59 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:59 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:59 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:59 --> URI Class Initialized
INFO - 2023-01-12 06:21:59 --> Router Class Initialized
INFO - 2023-01-12 06:21:59 --> Output Class Initialized
INFO - 2023-01-12 06:21:59 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:59 --> Input Class Initialized
INFO - 2023-01-12 06:21:59 --> Language Class Initialized
INFO - 2023-01-12 06:21:59 --> Loader Class Initialized
INFO - 2023-01-12 06:21:59 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:59 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:59 --> Total execution time: 0.0039
INFO - 2023-01-12 06:21:59 --> Config Class Initialized
INFO - 2023-01-12 06:21:59 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:21:59 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:21:59 --> Utf8 Class Initialized
INFO - 2023-01-12 06:21:59 --> URI Class Initialized
INFO - 2023-01-12 06:21:59 --> Router Class Initialized
INFO - 2023-01-12 06:21:59 --> Output Class Initialized
INFO - 2023-01-12 06:21:59 --> Security Class Initialized
DEBUG - 2023-01-12 06:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:21:59 --> Input Class Initialized
INFO - 2023-01-12 06:21:59 --> Language Class Initialized
INFO - 2023-01-12 06:21:59 --> Loader Class Initialized
INFO - 2023-01-12 06:21:59 --> Controller Class Initialized
DEBUG - 2023-01-12 06:21:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:21:59 --> Database Driver Class Initialized
INFO - 2023-01-12 06:21:59 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:21:59 --> Final output sent to browser
DEBUG - 2023-01-12 06:21:59 --> Total execution time: 0.0163
INFO - 2023-01-12 06:22:04 --> Config Class Initialized
INFO - 2023-01-12 06:22:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:04 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:04 --> URI Class Initialized
INFO - 2023-01-12 06:22:04 --> Router Class Initialized
INFO - 2023-01-12 06:22:04 --> Output Class Initialized
INFO - 2023-01-12 06:22:04 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:04 --> Input Class Initialized
INFO - 2023-01-12 06:22:04 --> Language Class Initialized
INFO - 2023-01-12 06:22:04 --> Loader Class Initialized
INFO - 2023-01-12 06:22:04 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:04 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:04 --> Total execution time: 0.0046
INFO - 2023-01-12 06:22:04 --> Config Class Initialized
INFO - 2023-01-12 06:22:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:04 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:04 --> URI Class Initialized
INFO - 2023-01-12 06:22:04 --> Router Class Initialized
INFO - 2023-01-12 06:22:04 --> Output Class Initialized
INFO - 2023-01-12 06:22:04 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:04 --> Input Class Initialized
INFO - 2023-01-12 06:22:04 --> Language Class Initialized
INFO - 2023-01-12 06:22:04 --> Loader Class Initialized
INFO - 2023-01-12 06:22:04 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:04 --> Database Driver Class Initialized
INFO - 2023-01-12 06:22:04 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:22:04 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:04 --> Total execution time: 0.0140
INFO - 2023-01-12 06:22:09 --> Config Class Initialized
INFO - 2023-01-12 06:22:09 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:09 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:09 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:09 --> URI Class Initialized
INFO - 2023-01-12 06:22:09 --> Router Class Initialized
INFO - 2023-01-12 06:22:09 --> Output Class Initialized
INFO - 2023-01-12 06:22:09 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:09 --> Input Class Initialized
INFO - 2023-01-12 06:22:09 --> Language Class Initialized
INFO - 2023-01-12 06:22:09 --> Loader Class Initialized
INFO - 2023-01-12 06:22:09 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:09 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:09 --> Total execution time: 0.0045
INFO - 2023-01-12 06:22:09 --> Config Class Initialized
INFO - 2023-01-12 06:22:09 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:09 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:09 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:09 --> URI Class Initialized
INFO - 2023-01-12 06:22:09 --> Router Class Initialized
INFO - 2023-01-12 06:22:09 --> Output Class Initialized
INFO - 2023-01-12 06:22:09 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:09 --> Input Class Initialized
INFO - 2023-01-12 06:22:09 --> Language Class Initialized
INFO - 2023-01-12 06:22:09 --> Loader Class Initialized
INFO - 2023-01-12 06:22:09 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:09 --> Database Driver Class Initialized
INFO - 2023-01-12 06:22:09 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:22:09 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:09 --> Total execution time: 0.0158
INFO - 2023-01-12 06:22:14 --> Config Class Initialized
INFO - 2023-01-12 06:22:14 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:14 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:14 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:14 --> URI Class Initialized
INFO - 2023-01-12 06:22:14 --> Router Class Initialized
INFO - 2023-01-12 06:22:14 --> Output Class Initialized
INFO - 2023-01-12 06:22:14 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:14 --> Input Class Initialized
INFO - 2023-01-12 06:22:14 --> Language Class Initialized
INFO - 2023-01-12 06:22:14 --> Loader Class Initialized
INFO - 2023-01-12 06:22:14 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:14 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:14 --> Total execution time: 0.0075
INFO - 2023-01-12 06:22:14 --> Config Class Initialized
INFO - 2023-01-12 06:22:14 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:14 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:14 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:14 --> URI Class Initialized
INFO - 2023-01-12 06:22:14 --> Router Class Initialized
INFO - 2023-01-12 06:22:14 --> Output Class Initialized
INFO - 2023-01-12 06:22:14 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:14 --> Input Class Initialized
INFO - 2023-01-12 06:22:14 --> Language Class Initialized
INFO - 2023-01-12 06:22:14 --> Loader Class Initialized
INFO - 2023-01-12 06:22:14 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:14 --> Database Driver Class Initialized
INFO - 2023-01-12 06:22:14 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:22:14 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:14 --> Total execution time: 0.0170
INFO - 2023-01-12 06:22:19 --> Config Class Initialized
INFO - 2023-01-12 06:22:19 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:19 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:19 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:19 --> URI Class Initialized
INFO - 2023-01-12 06:22:19 --> Router Class Initialized
INFO - 2023-01-12 06:22:19 --> Output Class Initialized
INFO - 2023-01-12 06:22:19 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:19 --> Input Class Initialized
INFO - 2023-01-12 06:22:19 --> Language Class Initialized
INFO - 2023-01-12 06:22:19 --> Loader Class Initialized
INFO - 2023-01-12 06:22:19 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:19 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:19 --> Total execution time: 0.0047
INFO - 2023-01-12 06:22:19 --> Config Class Initialized
INFO - 2023-01-12 06:22:19 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:19 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:19 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:19 --> URI Class Initialized
INFO - 2023-01-12 06:22:19 --> Router Class Initialized
INFO - 2023-01-12 06:22:19 --> Output Class Initialized
INFO - 2023-01-12 06:22:19 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:19 --> Input Class Initialized
INFO - 2023-01-12 06:22:19 --> Language Class Initialized
INFO - 2023-01-12 06:22:19 --> Loader Class Initialized
INFO - 2023-01-12 06:22:19 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:19 --> Database Driver Class Initialized
INFO - 2023-01-12 06:22:19 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:22:19 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:19 --> Total execution time: 0.0130
INFO - 2023-01-12 06:22:24 --> Config Class Initialized
INFO - 2023-01-12 06:22:24 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:24 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:24 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:24 --> URI Class Initialized
INFO - 2023-01-12 06:22:24 --> Router Class Initialized
INFO - 2023-01-12 06:22:24 --> Output Class Initialized
INFO - 2023-01-12 06:22:24 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:24 --> Input Class Initialized
INFO - 2023-01-12 06:22:24 --> Language Class Initialized
INFO - 2023-01-12 06:22:24 --> Loader Class Initialized
INFO - 2023-01-12 06:22:24 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:24 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:24 --> Total execution time: 0.0042
INFO - 2023-01-12 06:22:24 --> Config Class Initialized
INFO - 2023-01-12 06:22:24 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:24 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:24 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:24 --> URI Class Initialized
INFO - 2023-01-12 06:22:24 --> Router Class Initialized
INFO - 2023-01-12 06:22:24 --> Output Class Initialized
INFO - 2023-01-12 06:22:24 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:24 --> Input Class Initialized
INFO - 2023-01-12 06:22:24 --> Language Class Initialized
INFO - 2023-01-12 06:22:24 --> Loader Class Initialized
INFO - 2023-01-12 06:22:24 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:24 --> Database Driver Class Initialized
INFO - 2023-01-12 06:22:24 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:22:24 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:24 --> Total execution time: 0.0136
INFO - 2023-01-12 06:22:29 --> Config Class Initialized
INFO - 2023-01-12 06:22:29 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:29 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:29 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:29 --> URI Class Initialized
INFO - 2023-01-12 06:22:29 --> Router Class Initialized
INFO - 2023-01-12 06:22:29 --> Output Class Initialized
INFO - 2023-01-12 06:22:29 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:29 --> Input Class Initialized
INFO - 2023-01-12 06:22:29 --> Language Class Initialized
INFO - 2023-01-12 06:22:29 --> Loader Class Initialized
INFO - 2023-01-12 06:22:29 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:29 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:29 --> Total execution time: 0.0049
INFO - 2023-01-12 06:22:29 --> Config Class Initialized
INFO - 2023-01-12 06:22:29 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:29 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:29 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:29 --> URI Class Initialized
INFO - 2023-01-12 06:22:29 --> Router Class Initialized
INFO - 2023-01-12 06:22:29 --> Output Class Initialized
INFO - 2023-01-12 06:22:29 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:29 --> Input Class Initialized
INFO - 2023-01-12 06:22:29 --> Language Class Initialized
INFO - 2023-01-12 06:22:29 --> Loader Class Initialized
INFO - 2023-01-12 06:22:29 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:29 --> Database Driver Class Initialized
INFO - 2023-01-12 06:22:29 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:22:29 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:29 --> Total execution time: 0.0335
INFO - 2023-01-12 06:22:34 --> Config Class Initialized
INFO - 2023-01-12 06:22:34 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:34 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:34 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:34 --> URI Class Initialized
INFO - 2023-01-12 06:22:34 --> Router Class Initialized
INFO - 2023-01-12 06:22:34 --> Output Class Initialized
INFO - 2023-01-12 06:22:34 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:34 --> Input Class Initialized
INFO - 2023-01-12 06:22:34 --> Language Class Initialized
INFO - 2023-01-12 06:22:34 --> Loader Class Initialized
INFO - 2023-01-12 06:22:34 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:34 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:34 --> Total execution time: 0.0040
INFO - 2023-01-12 06:22:34 --> Config Class Initialized
INFO - 2023-01-12 06:22:34 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:34 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:34 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:34 --> URI Class Initialized
INFO - 2023-01-12 06:22:34 --> Router Class Initialized
INFO - 2023-01-12 06:22:34 --> Output Class Initialized
INFO - 2023-01-12 06:22:34 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:34 --> Input Class Initialized
INFO - 2023-01-12 06:22:34 --> Language Class Initialized
INFO - 2023-01-12 06:22:34 --> Loader Class Initialized
INFO - 2023-01-12 06:22:34 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:34 --> Database Driver Class Initialized
INFO - 2023-01-12 06:22:34 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:22:34 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:34 --> Total execution time: 0.0138
INFO - 2023-01-12 06:22:39 --> Config Class Initialized
INFO - 2023-01-12 06:22:39 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:39 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:39 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:39 --> URI Class Initialized
INFO - 2023-01-12 06:22:39 --> Router Class Initialized
INFO - 2023-01-12 06:22:39 --> Output Class Initialized
INFO - 2023-01-12 06:22:39 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:39 --> Input Class Initialized
INFO - 2023-01-12 06:22:39 --> Language Class Initialized
INFO - 2023-01-12 06:22:39 --> Loader Class Initialized
INFO - 2023-01-12 06:22:39 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:39 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:39 --> Total execution time: 0.0141
INFO - 2023-01-12 06:22:39 --> Config Class Initialized
INFO - 2023-01-12 06:22:39 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:39 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:39 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:39 --> URI Class Initialized
INFO - 2023-01-12 06:22:39 --> Router Class Initialized
INFO - 2023-01-12 06:22:39 --> Output Class Initialized
INFO - 2023-01-12 06:22:39 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:39 --> Input Class Initialized
INFO - 2023-01-12 06:22:39 --> Language Class Initialized
INFO - 2023-01-12 06:22:39 --> Loader Class Initialized
INFO - 2023-01-12 06:22:39 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:39 --> Database Driver Class Initialized
INFO - 2023-01-12 06:22:39 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:22:39 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:39 --> Total execution time: 0.0136
INFO - 2023-01-12 06:22:44 --> Config Class Initialized
INFO - 2023-01-12 06:22:44 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:44 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:44 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:44 --> URI Class Initialized
INFO - 2023-01-12 06:22:44 --> Router Class Initialized
INFO - 2023-01-12 06:22:44 --> Output Class Initialized
INFO - 2023-01-12 06:22:44 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:44 --> Input Class Initialized
INFO - 2023-01-12 06:22:44 --> Language Class Initialized
INFO - 2023-01-12 06:22:44 --> Loader Class Initialized
INFO - 2023-01-12 06:22:44 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:44 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:44 --> Total execution time: 0.0047
INFO - 2023-01-12 06:22:44 --> Config Class Initialized
INFO - 2023-01-12 06:22:44 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:44 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:44 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:44 --> URI Class Initialized
INFO - 2023-01-12 06:22:44 --> Router Class Initialized
INFO - 2023-01-12 06:22:44 --> Output Class Initialized
INFO - 2023-01-12 06:22:44 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:44 --> Input Class Initialized
INFO - 2023-01-12 06:22:44 --> Language Class Initialized
INFO - 2023-01-12 06:22:44 --> Loader Class Initialized
INFO - 2023-01-12 06:22:44 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:44 --> Database Driver Class Initialized
INFO - 2023-01-12 06:22:44 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:22:44 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:44 --> Total execution time: 0.0120
INFO - 2023-01-12 06:22:49 --> Config Class Initialized
INFO - 2023-01-12 06:22:49 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:49 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:49 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:49 --> URI Class Initialized
INFO - 2023-01-12 06:22:49 --> Router Class Initialized
INFO - 2023-01-12 06:22:49 --> Output Class Initialized
INFO - 2023-01-12 06:22:49 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:49 --> Input Class Initialized
INFO - 2023-01-12 06:22:49 --> Language Class Initialized
INFO - 2023-01-12 06:22:49 --> Loader Class Initialized
INFO - 2023-01-12 06:22:49 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:49 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:49 --> Total execution time: 0.5707
INFO - 2023-01-12 06:22:49 --> Config Class Initialized
INFO - 2023-01-12 06:22:49 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:49 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:49 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:49 --> URI Class Initialized
INFO - 2023-01-12 06:22:49 --> Router Class Initialized
INFO - 2023-01-12 06:22:49 --> Output Class Initialized
INFO - 2023-01-12 06:22:49 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:50 --> Input Class Initialized
INFO - 2023-01-12 06:22:50 --> Language Class Initialized
INFO - 2023-01-12 06:22:50 --> Loader Class Initialized
INFO - 2023-01-12 06:22:50 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:50 --> Database Driver Class Initialized
INFO - 2023-01-12 06:22:50 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:22:50 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:50 --> Total execution time: 0.4633
INFO - 2023-01-12 06:22:54 --> Config Class Initialized
INFO - 2023-01-12 06:22:54 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:54 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:54 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:54 --> URI Class Initialized
INFO - 2023-01-12 06:22:54 --> Router Class Initialized
INFO - 2023-01-12 06:22:54 --> Output Class Initialized
INFO - 2023-01-12 06:22:54 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:54 --> Input Class Initialized
INFO - 2023-01-12 06:22:54 --> Language Class Initialized
INFO - 2023-01-12 06:22:54 --> Loader Class Initialized
INFO - 2023-01-12 06:22:54 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:54 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:54 --> Total execution time: 0.0039
INFO - 2023-01-12 06:22:54 --> Config Class Initialized
INFO - 2023-01-12 06:22:54 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:54 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:54 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:54 --> URI Class Initialized
INFO - 2023-01-12 06:22:54 --> Router Class Initialized
INFO - 2023-01-12 06:22:54 --> Output Class Initialized
INFO - 2023-01-12 06:22:54 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:54 --> Input Class Initialized
INFO - 2023-01-12 06:22:54 --> Language Class Initialized
INFO - 2023-01-12 06:22:54 --> Loader Class Initialized
INFO - 2023-01-12 06:22:54 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:54 --> Database Driver Class Initialized
INFO - 2023-01-12 06:22:54 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:22:54 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:54 --> Total execution time: 0.0154
INFO - 2023-01-12 06:22:59 --> Config Class Initialized
INFO - 2023-01-12 06:22:59 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:59 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:59 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:59 --> URI Class Initialized
INFO - 2023-01-12 06:22:59 --> Router Class Initialized
INFO - 2023-01-12 06:22:59 --> Output Class Initialized
INFO - 2023-01-12 06:22:59 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:59 --> Input Class Initialized
INFO - 2023-01-12 06:22:59 --> Language Class Initialized
INFO - 2023-01-12 06:22:59 --> Loader Class Initialized
INFO - 2023-01-12 06:22:59 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:59 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:59 --> Total execution time: 0.0044
INFO - 2023-01-12 06:22:59 --> Config Class Initialized
INFO - 2023-01-12 06:22:59 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:22:59 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:22:59 --> Utf8 Class Initialized
INFO - 2023-01-12 06:22:59 --> URI Class Initialized
INFO - 2023-01-12 06:22:59 --> Router Class Initialized
INFO - 2023-01-12 06:22:59 --> Output Class Initialized
INFO - 2023-01-12 06:22:59 --> Security Class Initialized
DEBUG - 2023-01-12 06:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:22:59 --> Input Class Initialized
INFO - 2023-01-12 06:22:59 --> Language Class Initialized
INFO - 2023-01-12 06:22:59 --> Loader Class Initialized
INFO - 2023-01-12 06:22:59 --> Controller Class Initialized
DEBUG - 2023-01-12 06:22:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:22:59 --> Database Driver Class Initialized
INFO - 2023-01-12 06:22:59 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:22:59 --> Final output sent to browser
DEBUG - 2023-01-12 06:22:59 --> Total execution time: 0.0144
INFO - 2023-01-12 06:23:04 --> Config Class Initialized
INFO - 2023-01-12 06:23:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:23:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:23:04 --> Utf8 Class Initialized
INFO - 2023-01-12 06:23:04 --> URI Class Initialized
INFO - 2023-01-12 06:23:04 --> Router Class Initialized
INFO - 2023-01-12 06:23:04 --> Output Class Initialized
INFO - 2023-01-12 06:23:04 --> Security Class Initialized
DEBUG - 2023-01-12 06:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:23:04 --> Input Class Initialized
INFO - 2023-01-12 06:23:04 --> Language Class Initialized
INFO - 2023-01-12 06:23:04 --> Loader Class Initialized
INFO - 2023-01-12 06:23:04 --> Controller Class Initialized
DEBUG - 2023-01-12 06:23:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:23:04 --> Final output sent to browser
DEBUG - 2023-01-12 06:23:04 --> Total execution time: 0.0040
INFO - 2023-01-12 06:23:04 --> Config Class Initialized
INFO - 2023-01-12 06:23:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:23:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:23:04 --> Utf8 Class Initialized
INFO - 2023-01-12 06:23:04 --> URI Class Initialized
INFO - 2023-01-12 06:23:04 --> Router Class Initialized
INFO - 2023-01-12 06:23:04 --> Output Class Initialized
INFO - 2023-01-12 06:23:04 --> Security Class Initialized
DEBUG - 2023-01-12 06:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:23:04 --> Input Class Initialized
INFO - 2023-01-12 06:23:04 --> Language Class Initialized
INFO - 2023-01-12 06:23:04 --> Loader Class Initialized
INFO - 2023-01-12 06:23:04 --> Controller Class Initialized
DEBUG - 2023-01-12 06:23:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:23:04 --> Database Driver Class Initialized
INFO - 2023-01-12 06:23:04 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:23:04 --> Final output sent to browser
DEBUG - 2023-01-12 06:23:04 --> Total execution time: 0.0149
INFO - 2023-01-12 06:23:09 --> Config Class Initialized
INFO - 2023-01-12 06:23:09 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:23:09 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:23:09 --> Utf8 Class Initialized
INFO - 2023-01-12 06:23:09 --> URI Class Initialized
INFO - 2023-01-12 06:23:09 --> Router Class Initialized
INFO - 2023-01-12 06:23:09 --> Output Class Initialized
INFO - 2023-01-12 06:23:09 --> Security Class Initialized
DEBUG - 2023-01-12 06:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:23:09 --> Input Class Initialized
INFO - 2023-01-12 06:23:09 --> Language Class Initialized
INFO - 2023-01-12 06:23:09 --> Loader Class Initialized
INFO - 2023-01-12 06:23:09 --> Controller Class Initialized
DEBUG - 2023-01-12 06:23:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:23:09 --> Final output sent to browser
DEBUG - 2023-01-12 06:23:09 --> Total execution time: 0.0521
INFO - 2023-01-12 06:23:09 --> Config Class Initialized
INFO - 2023-01-12 06:23:09 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:23:09 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:23:09 --> Utf8 Class Initialized
INFO - 2023-01-12 06:23:09 --> URI Class Initialized
INFO - 2023-01-12 06:23:09 --> Router Class Initialized
INFO - 2023-01-12 06:23:09 --> Output Class Initialized
INFO - 2023-01-12 06:23:09 --> Security Class Initialized
DEBUG - 2023-01-12 06:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:23:09 --> Input Class Initialized
INFO - 2023-01-12 06:23:09 --> Language Class Initialized
INFO - 2023-01-12 06:23:09 --> Loader Class Initialized
INFO - 2023-01-12 06:23:09 --> Controller Class Initialized
DEBUG - 2023-01-12 06:23:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:23:09 --> Database Driver Class Initialized
INFO - 2023-01-12 06:23:09 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:23:09 --> Final output sent to browser
DEBUG - 2023-01-12 06:23:09 --> Total execution time: 0.0468
INFO - 2023-01-12 06:23:12 --> Config Class Initialized
INFO - 2023-01-12 06:23:12 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:23:12 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:23:12 --> Utf8 Class Initialized
INFO - 2023-01-12 06:23:12 --> URI Class Initialized
INFO - 2023-01-12 06:23:12 --> Router Class Initialized
INFO - 2023-01-12 06:23:12 --> Output Class Initialized
INFO - 2023-01-12 06:23:12 --> Security Class Initialized
DEBUG - 2023-01-12 06:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:23:12 --> Input Class Initialized
INFO - 2023-01-12 06:23:12 --> Language Class Initialized
INFO - 2023-01-12 06:23:12 --> Loader Class Initialized
INFO - 2023-01-12 06:23:12 --> Controller Class Initialized
DEBUG - 2023-01-12 06:23:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:23:12 --> Database Driver Class Initialized
INFO - 2023-01-12 06:23:12 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:23:12 --> Database Driver Class Initialized
INFO - 2023-01-12 06:23:12 --> Model "Login_model" initialized
INFO - 2023-01-12 06:23:12 --> Final output sent to browser
DEBUG - 2023-01-12 06:23:12 --> Total execution time: 0.0446
INFO - 2023-01-12 06:23:12 --> Config Class Initialized
INFO - 2023-01-12 06:23:12 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:23:12 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:23:12 --> Utf8 Class Initialized
INFO - 2023-01-12 06:23:12 --> URI Class Initialized
INFO - 2023-01-12 06:23:12 --> Router Class Initialized
INFO - 2023-01-12 06:23:12 --> Output Class Initialized
INFO - 2023-01-12 06:23:12 --> Security Class Initialized
DEBUG - 2023-01-12 06:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:23:12 --> Input Class Initialized
INFO - 2023-01-12 06:23:12 --> Language Class Initialized
INFO - 2023-01-12 06:23:12 --> Loader Class Initialized
INFO - 2023-01-12 06:23:12 --> Controller Class Initialized
DEBUG - 2023-01-12 06:23:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:23:12 --> Database Driver Class Initialized
INFO - 2023-01-12 06:23:12 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:23:12 --> Database Driver Class Initialized
INFO - 2023-01-12 06:23:12 --> Model "Login_model" initialized
INFO - 2023-01-12 06:23:12 --> Final output sent to browser
DEBUG - 2023-01-12 06:23:12 --> Total execution time: 0.0408
INFO - 2023-01-12 06:23:39 --> Config Class Initialized
INFO - 2023-01-12 06:23:39 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:23:39 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:23:39 --> Utf8 Class Initialized
INFO - 2023-01-12 06:23:39 --> URI Class Initialized
INFO - 2023-01-12 06:23:39 --> Router Class Initialized
INFO - 2023-01-12 06:23:39 --> Output Class Initialized
INFO - 2023-01-12 06:23:39 --> Security Class Initialized
DEBUG - 2023-01-12 06:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:23:39 --> Input Class Initialized
INFO - 2023-01-12 06:23:39 --> Language Class Initialized
INFO - 2023-01-12 06:23:39 --> Loader Class Initialized
INFO - 2023-01-12 06:23:39 --> Controller Class Initialized
DEBUG - 2023-01-12 06:23:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:23:39 --> Final output sent to browser
DEBUG - 2023-01-12 06:23:39 --> Total execution time: 0.0043
INFO - 2023-01-12 06:23:39 --> Config Class Initialized
INFO - 2023-01-12 06:23:39 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:23:39 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:23:39 --> Utf8 Class Initialized
INFO - 2023-01-12 06:23:39 --> URI Class Initialized
INFO - 2023-01-12 06:23:39 --> Router Class Initialized
INFO - 2023-01-12 06:23:39 --> Output Class Initialized
INFO - 2023-01-12 06:23:39 --> Security Class Initialized
DEBUG - 2023-01-12 06:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:23:39 --> Input Class Initialized
INFO - 2023-01-12 06:23:39 --> Language Class Initialized
INFO - 2023-01-12 06:23:39 --> Loader Class Initialized
INFO - 2023-01-12 06:23:39 --> Controller Class Initialized
DEBUG - 2023-01-12 06:23:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:23:39 --> Database Driver Class Initialized
INFO - 2023-01-12 06:23:39 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:23:39 --> Model "Node_model" initialized
INFO - 2023-01-12 06:23:39 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:23:39 --> Final output sent to browser
DEBUG - 2023-01-12 06:23:39 --> Total execution time: 0.0270
INFO - 2023-01-12 06:25:04 --> Config Class Initialized
INFO - 2023-01-12 06:25:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:25:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:25:04 --> Utf8 Class Initialized
INFO - 2023-01-12 06:25:04 --> URI Class Initialized
INFO - 2023-01-12 06:25:04 --> Router Class Initialized
INFO - 2023-01-12 06:25:04 --> Output Class Initialized
INFO - 2023-01-12 06:25:04 --> Security Class Initialized
DEBUG - 2023-01-12 06:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:25:04 --> Input Class Initialized
INFO - 2023-01-12 06:25:04 --> Language Class Initialized
INFO - 2023-01-12 06:25:04 --> Loader Class Initialized
INFO - 2023-01-12 06:25:04 --> Controller Class Initialized
DEBUG - 2023-01-12 06:25:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:25:04 --> Final output sent to browser
DEBUG - 2023-01-12 06:25:04 --> Total execution time: 0.0057
INFO - 2023-01-12 06:25:04 --> Config Class Initialized
INFO - 2023-01-12 06:25:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:25:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:25:04 --> Utf8 Class Initialized
INFO - 2023-01-12 06:25:04 --> URI Class Initialized
INFO - 2023-01-12 06:25:04 --> Router Class Initialized
INFO - 2023-01-12 06:25:04 --> Output Class Initialized
INFO - 2023-01-12 06:25:04 --> Security Class Initialized
DEBUG - 2023-01-12 06:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:25:04 --> Input Class Initialized
INFO - 2023-01-12 06:25:04 --> Language Class Initialized
INFO - 2023-01-12 06:25:04 --> Loader Class Initialized
INFO - 2023-01-12 06:25:04 --> Controller Class Initialized
DEBUG - 2023-01-12 06:25:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:25:04 --> Database Driver Class Initialized
INFO - 2023-01-12 06:25:04 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:25:04 --> Model "Node_model" initialized
INFO - 2023-01-12 06:25:04 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:26:02 --> Config Class Initialized
INFO - 2023-01-12 06:26:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:26:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:26:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:26:02 --> URI Class Initialized
INFO - 2023-01-12 06:26:02 --> Router Class Initialized
INFO - 2023-01-12 06:26:02 --> Output Class Initialized
INFO - 2023-01-12 06:26:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:26:02 --> Input Class Initialized
INFO - 2023-01-12 06:26:02 --> Language Class Initialized
INFO - 2023-01-12 06:26:02 --> Loader Class Initialized
INFO - 2023-01-12 06:26:02 --> Controller Class Initialized
INFO - 2023-01-12 06:26:02 --> Helper loaded: form_helper
INFO - 2023-01-12 06:26:02 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:26:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:26:02 --> Model "Change_model" initialized
INFO - 2023-01-12 06:26:02 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:26:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:26:02 --> Total execution time: 0.0496
INFO - 2023-01-12 06:26:02 --> Config Class Initialized
INFO - 2023-01-12 06:26:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:26:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:26:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:26:02 --> URI Class Initialized
INFO - 2023-01-12 06:26:02 --> Router Class Initialized
INFO - 2023-01-12 06:26:02 --> Output Class Initialized
INFO - 2023-01-12 06:26:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:26:02 --> Input Class Initialized
INFO - 2023-01-12 06:26:02 --> Language Class Initialized
INFO - 2023-01-12 06:26:02 --> Loader Class Initialized
INFO - 2023-01-12 06:26:02 --> Controller Class Initialized
INFO - 2023-01-12 06:26:02 --> Helper loaded: form_helper
INFO - 2023-01-12 06:26:02 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:26:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:26:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:26:02 --> Total execution time: 0.0037
INFO - 2023-01-12 06:26:02 --> Config Class Initialized
INFO - 2023-01-12 06:26:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:26:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:26:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:26:02 --> URI Class Initialized
INFO - 2023-01-12 06:26:02 --> Router Class Initialized
INFO - 2023-01-12 06:26:02 --> Output Class Initialized
INFO - 2023-01-12 06:26:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:26:02 --> Input Class Initialized
INFO - 2023-01-12 06:26:02 --> Language Class Initialized
INFO - 2023-01-12 06:26:02 --> Loader Class Initialized
INFO - 2023-01-12 06:26:02 --> Controller Class Initialized
INFO - 2023-01-12 06:26:02 --> Helper loaded: form_helper
INFO - 2023-01-12 06:26:02 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:26:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:26:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:26:02 --> Model "Login_model" initialized
INFO - 2023-01-12 06:26:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:26:02 --> Total execution time: 0.0162
INFO - 2023-01-12 06:26:02 --> Config Class Initialized
INFO - 2023-01-12 06:26:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:26:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:26:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:26:02 --> URI Class Initialized
INFO - 2023-01-12 06:26:02 --> Router Class Initialized
INFO - 2023-01-12 06:26:02 --> Output Class Initialized
INFO - 2023-01-12 06:26:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:26:02 --> Input Class Initialized
INFO - 2023-01-12 06:26:02 --> Language Class Initialized
INFO - 2023-01-12 06:26:02 --> Loader Class Initialized
INFO - 2023-01-12 06:26:02 --> Controller Class Initialized
DEBUG - 2023-01-12 06:26:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:26:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:26:02 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:26:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:26:02 --> Total execution time: 0.0125
INFO - 2023-01-12 06:26:02 --> Config Class Initialized
INFO - 2023-01-12 06:26:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:26:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:26:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:26:02 --> URI Class Initialized
INFO - 2023-01-12 06:26:02 --> Router Class Initialized
INFO - 2023-01-12 06:26:02 --> Output Class Initialized
INFO - 2023-01-12 06:26:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:26:02 --> Input Class Initialized
INFO - 2023-01-12 06:26:02 --> Language Class Initialized
INFO - 2023-01-12 06:26:02 --> Loader Class Initialized
INFO - 2023-01-12 06:26:02 --> Controller Class Initialized
DEBUG - 2023-01-12 06:26:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:26:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:26:02 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:26:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:26:02 --> Total execution time: 0.0117
INFO - 2023-01-12 06:26:02 --> Config Class Initialized
INFO - 2023-01-12 06:26:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:26:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:26:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:26:02 --> URI Class Initialized
INFO - 2023-01-12 06:26:02 --> Router Class Initialized
INFO - 2023-01-12 06:26:02 --> Output Class Initialized
INFO - 2023-01-12 06:26:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:26:02 --> Input Class Initialized
INFO - 2023-01-12 06:26:02 --> Language Class Initialized
INFO - 2023-01-12 06:26:02 --> Loader Class Initialized
INFO - 2023-01-12 06:26:02 --> Controller Class Initialized
DEBUG - 2023-01-12 06:26:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:26:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:26:02 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:26:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:26:02 --> Model "Login_model" initialized
INFO - 2023-01-12 06:26:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:26:02 --> Total execution time: 0.0749
INFO - 2023-01-12 06:26:02 --> Config Class Initialized
INFO - 2023-01-12 06:26:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:26:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:26:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:26:02 --> URI Class Initialized
INFO - 2023-01-12 06:26:02 --> Router Class Initialized
INFO - 2023-01-12 06:26:02 --> Output Class Initialized
INFO - 2023-01-12 06:26:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:26:02 --> Input Class Initialized
INFO - 2023-01-12 06:26:02 --> Language Class Initialized
INFO - 2023-01-12 06:26:02 --> Loader Class Initialized
INFO - 2023-01-12 06:26:02 --> Controller Class Initialized
DEBUG - 2023-01-12 06:26:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:26:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:26:02 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:26:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:26:02 --> Model "Login_model" initialized
INFO - 2023-01-12 06:26:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:26:02 --> Total execution time: 0.0639
INFO - 2023-01-12 06:26:07 --> Config Class Initialized
INFO - 2023-01-12 06:26:07 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:26:07 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:26:07 --> Utf8 Class Initialized
INFO - 2023-01-12 06:26:07 --> URI Class Initialized
INFO - 2023-01-12 06:26:07 --> Router Class Initialized
INFO - 2023-01-12 06:26:07 --> Output Class Initialized
INFO - 2023-01-12 06:26:07 --> Security Class Initialized
DEBUG - 2023-01-12 06:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:26:07 --> Input Class Initialized
INFO - 2023-01-12 06:26:07 --> Language Class Initialized
INFO - 2023-01-12 06:26:07 --> Loader Class Initialized
INFO - 2023-01-12 06:26:07 --> Controller Class Initialized
DEBUG - 2023-01-12 06:26:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:26:07 --> Final output sent to browser
DEBUG - 2023-01-12 06:26:07 --> Total execution time: 0.0039
INFO - 2023-01-12 06:26:07 --> Config Class Initialized
INFO - 2023-01-12 06:26:07 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:26:07 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:26:07 --> Utf8 Class Initialized
INFO - 2023-01-12 06:26:07 --> URI Class Initialized
INFO - 2023-01-12 06:26:07 --> Router Class Initialized
INFO - 2023-01-12 06:26:07 --> Output Class Initialized
INFO - 2023-01-12 06:26:07 --> Security Class Initialized
DEBUG - 2023-01-12 06:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:26:07 --> Input Class Initialized
INFO - 2023-01-12 06:26:07 --> Language Class Initialized
INFO - 2023-01-12 06:26:07 --> Loader Class Initialized
INFO - 2023-01-12 06:26:07 --> Controller Class Initialized
DEBUG - 2023-01-12 06:26:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:26:07 --> Database Driver Class Initialized
INFO - 2023-01-12 06:26:07 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:26:07 --> Model "Node_model" initialized
INFO - 2023-01-12 06:26:07 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:26:52 --> Config Class Initialized
INFO - 2023-01-12 06:26:52 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:26:52 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:26:52 --> Utf8 Class Initialized
INFO - 2023-01-12 06:26:52 --> URI Class Initialized
INFO - 2023-01-12 06:26:52 --> Router Class Initialized
INFO - 2023-01-12 06:26:52 --> Output Class Initialized
INFO - 2023-01-12 06:26:52 --> Security Class Initialized
DEBUG - 2023-01-12 06:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:26:52 --> Input Class Initialized
INFO - 2023-01-12 06:26:52 --> Language Class Initialized
INFO - 2023-01-12 06:26:52 --> Loader Class Initialized
INFO - 2023-01-12 06:26:52 --> Controller Class Initialized
DEBUG - 2023-01-12 06:26:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:26:52 --> Final output sent to browser
DEBUG - 2023-01-12 06:26:52 --> Total execution time: 0.0047
INFO - 2023-01-12 06:26:52 --> Config Class Initialized
INFO - 2023-01-12 06:26:52 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:26:52 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:26:52 --> Utf8 Class Initialized
INFO - 2023-01-12 06:26:52 --> URI Class Initialized
INFO - 2023-01-12 06:26:52 --> Router Class Initialized
INFO - 2023-01-12 06:26:52 --> Output Class Initialized
INFO - 2023-01-12 06:26:52 --> Security Class Initialized
DEBUG - 2023-01-12 06:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:26:52 --> Input Class Initialized
INFO - 2023-01-12 06:26:52 --> Language Class Initialized
INFO - 2023-01-12 06:26:52 --> Loader Class Initialized
INFO - 2023-01-12 06:26:52 --> Controller Class Initialized
DEBUG - 2023-01-12 06:26:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:26:52 --> Database Driver Class Initialized
INFO - 2023-01-12 06:26:52 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:26:52 --> Model "Node_model" initialized
INFO - 2023-01-12 06:26:52 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:35:52 --> Config Class Initialized
INFO - 2023-01-12 06:35:52 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:35:52 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:35:52 --> Utf8 Class Initialized
INFO - 2023-01-12 06:35:52 --> URI Class Initialized
INFO - 2023-01-12 06:35:52 --> Router Class Initialized
INFO - 2023-01-12 06:35:52 --> Output Class Initialized
INFO - 2023-01-12 06:35:52 --> Security Class Initialized
DEBUG - 2023-01-12 06:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:35:52 --> Input Class Initialized
INFO - 2023-01-12 06:35:52 --> Language Class Initialized
INFO - 2023-01-12 06:35:52 --> Loader Class Initialized
INFO - 2023-01-12 06:35:52 --> Controller Class Initialized
INFO - 2023-01-12 06:35:52 --> Helper loaded: form_helper
INFO - 2023-01-12 06:35:52 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:35:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:35:52 --> Model "Change_model" initialized
INFO - 2023-01-12 06:35:52 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:35:58 --> Config Class Initialized
INFO - 2023-01-12 06:35:58 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:35:58 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:35:58 --> Utf8 Class Initialized
INFO - 2023-01-12 06:35:58 --> URI Class Initialized
INFO - 2023-01-12 06:35:58 --> Router Class Initialized
INFO - 2023-01-12 06:35:58 --> Output Class Initialized
INFO - 2023-01-12 06:35:58 --> Security Class Initialized
DEBUG - 2023-01-12 06:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:35:58 --> Input Class Initialized
INFO - 2023-01-12 06:35:58 --> Language Class Initialized
INFO - 2023-01-12 06:35:58 --> Loader Class Initialized
INFO - 2023-01-12 06:35:58 --> Controller Class Initialized
INFO - 2023-01-12 06:35:58 --> Helper loaded: form_helper
INFO - 2023-01-12 06:35:58 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:35:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:35:58 --> Model "Change_model" initialized
INFO - 2023-01-12 06:35:58 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:36:00 --> Config Class Initialized
INFO - 2023-01-12 06:36:00 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:36:00 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:36:00 --> Utf8 Class Initialized
INFO - 2023-01-12 06:36:00 --> URI Class Initialized
INFO - 2023-01-12 06:36:00 --> Router Class Initialized
INFO - 2023-01-12 06:36:00 --> Output Class Initialized
INFO - 2023-01-12 06:36:00 --> Security Class Initialized
DEBUG - 2023-01-12 06:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:36:00 --> Input Class Initialized
INFO - 2023-01-12 06:36:00 --> Language Class Initialized
INFO - 2023-01-12 06:36:00 --> Loader Class Initialized
INFO - 2023-01-12 06:36:00 --> Controller Class Initialized
INFO - 2023-01-12 06:36:00 --> Helper loaded: form_helper
INFO - 2023-01-12 06:36:00 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:36:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:36:00 --> Model "Change_model" initialized
INFO - 2023-01-12 06:36:00 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:36:31 --> Config Class Initialized
INFO - 2023-01-12 06:36:32 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:36:32 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:36:32 --> Utf8 Class Initialized
INFO - 2023-01-12 06:36:32 --> URI Class Initialized
INFO - 2023-01-12 06:36:32 --> Router Class Initialized
INFO - 2023-01-12 06:36:32 --> Output Class Initialized
INFO - 2023-01-12 06:36:32 --> Security Class Initialized
DEBUG - 2023-01-12 06:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:36:32 --> Input Class Initialized
INFO - 2023-01-12 06:36:32 --> Language Class Initialized
INFO - 2023-01-12 06:36:32 --> Loader Class Initialized
INFO - 2023-01-12 06:36:32 --> Controller Class Initialized
INFO - 2023-01-12 06:36:32 --> Helper loaded: form_helper
INFO - 2023-01-12 06:36:32 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:36:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:36:32 --> Model "Change_model" initialized
INFO - 2023-01-12 06:36:32 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:36:33 --> Config Class Initialized
INFO - 2023-01-12 06:36:33 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:36:33 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:36:33 --> Utf8 Class Initialized
INFO - 2023-01-12 06:36:33 --> URI Class Initialized
INFO - 2023-01-12 06:36:33 --> Router Class Initialized
INFO - 2023-01-12 06:36:33 --> Output Class Initialized
INFO - 2023-01-12 06:36:33 --> Security Class Initialized
DEBUG - 2023-01-12 06:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:36:33 --> Input Class Initialized
INFO - 2023-01-12 06:36:33 --> Language Class Initialized
INFO - 2023-01-12 06:36:33 --> Loader Class Initialized
INFO - 2023-01-12 06:36:33 --> Controller Class Initialized
INFO - 2023-01-12 06:36:33 --> Helper loaded: form_helper
INFO - 2023-01-12 06:36:33 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:36:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:36:33 --> Model "Change_model" initialized
INFO - 2023-01-12 06:36:33 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:36:46 --> Config Class Initialized
INFO - 2023-01-12 06:36:46 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:36:46 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:36:46 --> Utf8 Class Initialized
INFO - 2023-01-12 06:36:46 --> URI Class Initialized
INFO - 2023-01-12 06:36:46 --> Router Class Initialized
INFO - 2023-01-12 06:36:46 --> Output Class Initialized
INFO - 2023-01-12 06:36:46 --> Security Class Initialized
DEBUG - 2023-01-12 06:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:36:46 --> Input Class Initialized
INFO - 2023-01-12 06:36:46 --> Language Class Initialized
INFO - 2023-01-12 06:36:46 --> Loader Class Initialized
INFO - 2023-01-12 06:36:46 --> Controller Class Initialized
INFO - 2023-01-12 06:36:46 --> Helper loaded: form_helper
INFO - 2023-01-12 06:36:46 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:36:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:36:46 --> Model "Change_model" initialized
INFO - 2023-01-12 06:36:46 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:36:48 --> Config Class Initialized
INFO - 2023-01-12 06:36:48 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:36:48 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:36:48 --> Utf8 Class Initialized
INFO - 2023-01-12 06:36:48 --> URI Class Initialized
INFO - 2023-01-12 06:36:48 --> Router Class Initialized
INFO - 2023-01-12 06:36:48 --> Output Class Initialized
INFO - 2023-01-12 06:36:48 --> Security Class Initialized
DEBUG - 2023-01-12 06:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:36:48 --> Input Class Initialized
INFO - 2023-01-12 06:36:48 --> Language Class Initialized
INFO - 2023-01-12 06:36:48 --> Loader Class Initialized
INFO - 2023-01-12 06:36:48 --> Controller Class Initialized
INFO - 2023-01-12 06:36:48 --> Helper loaded: form_helper
INFO - 2023-01-12 06:36:48 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:36:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:36:48 --> Model "Change_model" initialized
INFO - 2023-01-12 06:36:48 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:36:48 --> Config Class Initialized
INFO - 2023-01-12 06:36:49 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:36:49 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:36:49 --> Utf8 Class Initialized
INFO - 2023-01-12 06:36:49 --> URI Class Initialized
INFO - 2023-01-12 06:36:49 --> Router Class Initialized
INFO - 2023-01-12 06:36:49 --> Output Class Initialized
INFO - 2023-01-12 06:36:49 --> Security Class Initialized
DEBUG - 2023-01-12 06:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:36:49 --> Input Class Initialized
INFO - 2023-01-12 06:36:49 --> Language Class Initialized
INFO - 2023-01-12 06:36:49 --> Loader Class Initialized
INFO - 2023-01-12 06:36:49 --> Controller Class Initialized
INFO - 2023-01-12 06:36:49 --> Helper loaded: form_helper
INFO - 2023-01-12 06:36:49 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:36:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:36:49 --> Model "Change_model" initialized
INFO - 2023-01-12 06:36:49 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:36:49 --> Config Class Initialized
INFO - 2023-01-12 06:36:49 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:36:49 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:36:49 --> Utf8 Class Initialized
INFO - 2023-01-12 06:36:49 --> URI Class Initialized
INFO - 2023-01-12 06:36:49 --> Router Class Initialized
INFO - 2023-01-12 06:36:49 --> Output Class Initialized
INFO - 2023-01-12 06:36:49 --> Security Class Initialized
DEBUG - 2023-01-12 06:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:36:49 --> Input Class Initialized
INFO - 2023-01-12 06:36:49 --> Language Class Initialized
INFO - 2023-01-12 06:36:49 --> Loader Class Initialized
INFO - 2023-01-12 06:36:49 --> Controller Class Initialized
INFO - 2023-01-12 06:36:49 --> Helper loaded: form_helper
INFO - 2023-01-12 06:36:49 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:36:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:36:49 --> Model "Change_model" initialized
INFO - 2023-01-12 06:36:49 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:36:50 --> Config Class Initialized
INFO - 2023-01-12 06:36:50 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:36:50 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:36:50 --> Utf8 Class Initialized
INFO - 2023-01-12 06:36:50 --> URI Class Initialized
INFO - 2023-01-12 06:36:50 --> Router Class Initialized
INFO - 2023-01-12 06:36:50 --> Output Class Initialized
INFO - 2023-01-12 06:36:50 --> Security Class Initialized
DEBUG - 2023-01-12 06:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:36:50 --> Input Class Initialized
INFO - 2023-01-12 06:36:50 --> Language Class Initialized
INFO - 2023-01-12 06:36:50 --> Loader Class Initialized
INFO - 2023-01-12 06:36:50 --> Controller Class Initialized
INFO - 2023-01-12 06:36:50 --> Helper loaded: form_helper
INFO - 2023-01-12 06:36:50 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:36:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:36:50 --> Model "Change_model" initialized
INFO - 2023-01-12 06:36:50 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:37:11 --> Config Class Initialized
INFO - 2023-01-12 06:37:11 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:37:11 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:37:11 --> Utf8 Class Initialized
INFO - 2023-01-12 06:37:11 --> URI Class Initialized
INFO - 2023-01-12 06:37:11 --> Router Class Initialized
INFO - 2023-01-12 06:37:11 --> Output Class Initialized
INFO - 2023-01-12 06:37:11 --> Security Class Initialized
DEBUG - 2023-01-12 06:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:37:11 --> Input Class Initialized
INFO - 2023-01-12 06:37:11 --> Language Class Initialized
INFO - 2023-01-12 06:37:11 --> Loader Class Initialized
INFO - 2023-01-12 06:37:11 --> Controller Class Initialized
INFO - 2023-01-12 06:37:11 --> Helper loaded: form_helper
INFO - 2023-01-12 06:37:11 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:37:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:37:11 --> Model "Change_model" initialized
INFO - 2023-01-12 06:37:11 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:37:12 --> Config Class Initialized
INFO - 2023-01-12 06:37:12 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:37:12 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:37:12 --> Utf8 Class Initialized
INFO - 2023-01-12 06:37:12 --> URI Class Initialized
INFO - 2023-01-12 06:37:12 --> Router Class Initialized
INFO - 2023-01-12 06:37:12 --> Output Class Initialized
INFO - 2023-01-12 06:37:12 --> Security Class Initialized
DEBUG - 2023-01-12 06:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:37:12 --> Input Class Initialized
INFO - 2023-01-12 06:37:12 --> Language Class Initialized
INFO - 2023-01-12 06:37:12 --> Loader Class Initialized
INFO - 2023-01-12 06:37:12 --> Controller Class Initialized
INFO - 2023-01-12 06:37:12 --> Helper loaded: form_helper
INFO - 2023-01-12 06:37:12 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:37:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:37:12 --> Model "Change_model" initialized
INFO - 2023-01-12 06:37:12 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:37:52 --> Config Class Initialized
INFO - 2023-01-12 06:37:52 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:37:52 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:37:52 --> Utf8 Class Initialized
INFO - 2023-01-12 06:37:52 --> URI Class Initialized
INFO - 2023-01-12 06:37:52 --> Router Class Initialized
INFO - 2023-01-12 06:37:52 --> Output Class Initialized
INFO - 2023-01-12 06:37:52 --> Security Class Initialized
DEBUG - 2023-01-12 06:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:37:52 --> Input Class Initialized
INFO - 2023-01-12 06:37:52 --> Language Class Initialized
INFO - 2023-01-12 06:37:52 --> Loader Class Initialized
INFO - 2023-01-12 06:37:52 --> Controller Class Initialized
INFO - 2023-01-12 06:37:52 --> Helper loaded: form_helper
INFO - 2023-01-12 06:37:52 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:37:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:37:52 --> Model "Change_model" initialized
INFO - 2023-01-12 06:37:52 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:37:53 --> Config Class Initialized
INFO - 2023-01-12 06:37:53 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:37:53 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:37:53 --> Utf8 Class Initialized
INFO - 2023-01-12 06:37:53 --> URI Class Initialized
INFO - 2023-01-12 06:37:53 --> Router Class Initialized
INFO - 2023-01-12 06:37:53 --> Output Class Initialized
INFO - 2023-01-12 06:37:53 --> Security Class Initialized
DEBUG - 2023-01-12 06:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:37:53 --> Input Class Initialized
INFO - 2023-01-12 06:37:53 --> Language Class Initialized
INFO - 2023-01-12 06:37:53 --> Loader Class Initialized
INFO - 2023-01-12 06:37:53 --> Controller Class Initialized
INFO - 2023-01-12 06:37:53 --> Helper loaded: form_helper
INFO - 2023-01-12 06:37:53 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:37:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:37:53 --> Model "Change_model" initialized
INFO - 2023-01-12 06:37:53 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:38:11 --> Config Class Initialized
INFO - 2023-01-12 06:38:11 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:38:11 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:38:11 --> Utf8 Class Initialized
INFO - 2023-01-12 06:38:11 --> URI Class Initialized
INFO - 2023-01-12 06:38:11 --> Router Class Initialized
INFO - 2023-01-12 06:38:11 --> Output Class Initialized
INFO - 2023-01-12 06:38:11 --> Security Class Initialized
DEBUG - 2023-01-12 06:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:38:11 --> Input Class Initialized
INFO - 2023-01-12 06:38:11 --> Language Class Initialized
INFO - 2023-01-12 06:38:11 --> Loader Class Initialized
INFO - 2023-01-12 06:38:11 --> Controller Class Initialized
INFO - 2023-01-12 06:38:11 --> Helper loaded: form_helper
INFO - 2023-01-12 06:38:11 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:38:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:38:11 --> Model "Change_model" initialized
INFO - 2023-01-12 06:38:11 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:38:12 --> Config Class Initialized
INFO - 2023-01-12 06:38:12 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:38:12 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:38:12 --> Utf8 Class Initialized
INFO - 2023-01-12 06:38:12 --> URI Class Initialized
INFO - 2023-01-12 06:38:12 --> Router Class Initialized
INFO - 2023-01-12 06:38:12 --> Output Class Initialized
INFO - 2023-01-12 06:38:12 --> Security Class Initialized
DEBUG - 2023-01-12 06:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:38:12 --> Input Class Initialized
INFO - 2023-01-12 06:38:12 --> Language Class Initialized
INFO - 2023-01-12 06:38:12 --> Loader Class Initialized
INFO - 2023-01-12 06:38:12 --> Controller Class Initialized
INFO - 2023-01-12 06:38:12 --> Helper loaded: form_helper
INFO - 2023-01-12 06:38:12 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:38:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:38:12 --> Model "Change_model" initialized
INFO - 2023-01-12 06:38:12 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:38:31 --> Config Class Initialized
INFO - 2023-01-12 06:38:31 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:38:31 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:38:31 --> Utf8 Class Initialized
INFO - 2023-01-12 06:38:31 --> URI Class Initialized
INFO - 2023-01-12 06:38:31 --> Router Class Initialized
INFO - 2023-01-12 06:38:31 --> Output Class Initialized
INFO - 2023-01-12 06:38:31 --> Security Class Initialized
DEBUG - 2023-01-12 06:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:38:31 --> Input Class Initialized
INFO - 2023-01-12 06:38:31 --> Language Class Initialized
INFO - 2023-01-12 06:38:31 --> Loader Class Initialized
INFO - 2023-01-12 06:38:31 --> Controller Class Initialized
INFO - 2023-01-12 06:38:31 --> Helper loaded: form_helper
INFO - 2023-01-12 06:38:31 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:38:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:38:31 --> Model "Change_model" initialized
INFO - 2023-01-12 06:38:31 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:38:31 --> Config Class Initialized
INFO - 2023-01-12 06:38:31 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:38:31 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:38:31 --> Utf8 Class Initialized
INFO - 2023-01-12 06:38:31 --> URI Class Initialized
INFO - 2023-01-12 06:38:31 --> Router Class Initialized
INFO - 2023-01-12 06:38:31 --> Output Class Initialized
INFO - 2023-01-12 06:38:31 --> Security Class Initialized
DEBUG - 2023-01-12 06:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:38:31 --> Input Class Initialized
INFO - 2023-01-12 06:38:31 --> Language Class Initialized
INFO - 2023-01-12 06:38:31 --> Loader Class Initialized
INFO - 2023-01-12 06:38:31 --> Controller Class Initialized
INFO - 2023-01-12 06:38:31 --> Helper loaded: form_helper
INFO - 2023-01-12 06:38:31 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:38:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:38:31 --> Model "Change_model" initialized
INFO - 2023-01-12 06:38:31 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:38:32 --> Config Class Initialized
INFO - 2023-01-12 06:38:32 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:38:32 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:38:32 --> Utf8 Class Initialized
INFO - 2023-01-12 06:38:32 --> URI Class Initialized
INFO - 2023-01-12 06:38:32 --> Router Class Initialized
INFO - 2023-01-12 06:38:32 --> Output Class Initialized
INFO - 2023-01-12 06:38:32 --> Security Class Initialized
DEBUG - 2023-01-12 06:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:38:32 --> Input Class Initialized
INFO - 2023-01-12 06:38:32 --> Language Class Initialized
INFO - 2023-01-12 06:38:32 --> Loader Class Initialized
INFO - 2023-01-12 06:38:32 --> Controller Class Initialized
INFO - 2023-01-12 06:38:32 --> Helper loaded: form_helper
INFO - 2023-01-12 06:38:32 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:38:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:38:32 --> Model "Change_model" initialized
INFO - 2023-01-12 06:38:32 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:38:32 --> Config Class Initialized
INFO - 2023-01-12 06:38:32 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:38:32 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:38:32 --> Utf8 Class Initialized
INFO - 2023-01-12 06:38:32 --> URI Class Initialized
INFO - 2023-01-12 06:38:32 --> Router Class Initialized
INFO - 2023-01-12 06:38:32 --> Output Class Initialized
INFO - 2023-01-12 06:38:32 --> Security Class Initialized
DEBUG - 2023-01-12 06:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:38:32 --> Input Class Initialized
INFO - 2023-01-12 06:38:32 --> Language Class Initialized
INFO - 2023-01-12 06:38:32 --> Loader Class Initialized
INFO - 2023-01-12 06:38:32 --> Controller Class Initialized
INFO - 2023-01-12 06:38:32 --> Helper loaded: form_helper
INFO - 2023-01-12 06:38:32 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:38:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:38:32 --> Model "Change_model" initialized
INFO - 2023-01-12 06:38:32 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:38:32 --> Config Class Initialized
INFO - 2023-01-12 06:38:32 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:38:32 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:38:32 --> Utf8 Class Initialized
INFO - 2023-01-12 06:38:32 --> URI Class Initialized
INFO - 2023-01-12 06:38:32 --> Router Class Initialized
INFO - 2023-01-12 06:38:32 --> Output Class Initialized
INFO - 2023-01-12 06:38:32 --> Security Class Initialized
DEBUG - 2023-01-12 06:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:38:32 --> Input Class Initialized
INFO - 2023-01-12 06:38:32 --> Language Class Initialized
INFO - 2023-01-12 06:38:32 --> Loader Class Initialized
INFO - 2023-01-12 06:38:32 --> Controller Class Initialized
INFO - 2023-01-12 06:38:32 --> Helper loaded: form_helper
INFO - 2023-01-12 06:38:32 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:38:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:38:32 --> Model "Change_model" initialized
INFO - 2023-01-12 06:38:32 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:38:49 --> Config Class Initialized
INFO - 2023-01-12 06:38:49 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:38:49 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:38:49 --> Utf8 Class Initialized
INFO - 2023-01-12 06:38:49 --> URI Class Initialized
INFO - 2023-01-12 06:38:49 --> Router Class Initialized
INFO - 2023-01-12 06:38:49 --> Output Class Initialized
INFO - 2023-01-12 06:38:49 --> Security Class Initialized
DEBUG - 2023-01-12 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:38:49 --> Input Class Initialized
INFO - 2023-01-12 06:38:49 --> Language Class Initialized
INFO - 2023-01-12 06:38:49 --> Loader Class Initialized
INFO - 2023-01-12 06:38:49 --> Controller Class Initialized
INFO - 2023-01-12 06:38:49 --> Helper loaded: form_helper
INFO - 2023-01-12 06:38:49 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:38:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:38:49 --> Model "Change_model" initialized
INFO - 2023-01-12 06:38:49 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:38:50 --> Config Class Initialized
INFO - 2023-01-12 06:38:50 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:38:50 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:38:50 --> Utf8 Class Initialized
INFO - 2023-01-12 06:38:50 --> URI Class Initialized
INFO - 2023-01-12 06:38:50 --> Router Class Initialized
INFO - 2023-01-12 06:38:50 --> Output Class Initialized
INFO - 2023-01-12 06:38:50 --> Security Class Initialized
DEBUG - 2023-01-12 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:38:50 --> Input Class Initialized
INFO - 2023-01-12 06:38:50 --> Language Class Initialized
INFO - 2023-01-12 06:38:50 --> Loader Class Initialized
INFO - 2023-01-12 06:38:50 --> Controller Class Initialized
INFO - 2023-01-12 06:38:50 --> Helper loaded: form_helper
INFO - 2023-01-12 06:38:50 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:38:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:38:50 --> Model "Change_model" initialized
INFO - 2023-01-12 06:38:50 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:38:50 --> Config Class Initialized
INFO - 2023-01-12 06:38:50 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:38:50 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:38:50 --> Utf8 Class Initialized
INFO - 2023-01-12 06:38:50 --> URI Class Initialized
INFO - 2023-01-12 06:38:50 --> Router Class Initialized
INFO - 2023-01-12 06:38:50 --> Output Class Initialized
INFO - 2023-01-12 06:38:50 --> Security Class Initialized
DEBUG - 2023-01-12 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:38:50 --> Input Class Initialized
INFO - 2023-01-12 06:38:50 --> Language Class Initialized
INFO - 2023-01-12 06:38:50 --> Loader Class Initialized
INFO - 2023-01-12 06:38:50 --> Controller Class Initialized
INFO - 2023-01-12 06:38:50 --> Helper loaded: form_helper
INFO - 2023-01-12 06:38:50 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:38:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:38:50 --> Model "Change_model" initialized
INFO - 2023-01-12 06:38:50 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:38:50 --> Config Class Initialized
INFO - 2023-01-12 06:38:50 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:38:50 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:38:50 --> Utf8 Class Initialized
INFO - 2023-01-12 06:38:50 --> URI Class Initialized
INFO - 2023-01-12 06:38:50 --> Router Class Initialized
INFO - 2023-01-12 06:38:50 --> Output Class Initialized
INFO - 2023-01-12 06:38:50 --> Security Class Initialized
DEBUG - 2023-01-12 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:38:50 --> Input Class Initialized
INFO - 2023-01-12 06:38:50 --> Language Class Initialized
INFO - 2023-01-12 06:38:50 --> Loader Class Initialized
INFO - 2023-01-12 06:38:50 --> Controller Class Initialized
INFO - 2023-01-12 06:38:50 --> Helper loaded: form_helper
INFO - 2023-01-12 06:38:50 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:38:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:38:50 --> Model "Change_model" initialized
INFO - 2023-01-12 06:38:50 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:38:51 --> Config Class Initialized
INFO - 2023-01-12 06:38:51 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:38:51 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:38:51 --> Utf8 Class Initialized
INFO - 2023-01-12 06:38:51 --> URI Class Initialized
INFO - 2023-01-12 06:38:51 --> Router Class Initialized
INFO - 2023-01-12 06:38:51 --> Output Class Initialized
INFO - 2023-01-12 06:38:51 --> Security Class Initialized
DEBUG - 2023-01-12 06:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:38:51 --> Input Class Initialized
INFO - 2023-01-12 06:38:51 --> Language Class Initialized
INFO - 2023-01-12 06:38:51 --> Loader Class Initialized
INFO - 2023-01-12 06:38:51 --> Controller Class Initialized
INFO - 2023-01-12 06:38:51 --> Helper loaded: form_helper
INFO - 2023-01-12 06:38:51 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:38:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:38:51 --> Model "Change_model" initialized
INFO - 2023-01-12 06:38:51 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:39:51 --> Config Class Initialized
INFO - 2023-01-12 06:39:51 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:39:51 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:39:51 --> Utf8 Class Initialized
INFO - 2023-01-12 06:39:51 --> URI Class Initialized
INFO - 2023-01-12 06:39:51 --> Router Class Initialized
INFO - 2023-01-12 06:39:51 --> Output Class Initialized
INFO - 2023-01-12 06:39:51 --> Security Class Initialized
DEBUG - 2023-01-12 06:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:39:51 --> Input Class Initialized
INFO - 2023-01-12 06:39:51 --> Language Class Initialized
INFO - 2023-01-12 06:39:51 --> Loader Class Initialized
INFO - 2023-01-12 06:39:51 --> Controller Class Initialized
INFO - 2023-01-12 06:39:51 --> Helper loaded: form_helper
INFO - 2023-01-12 06:39:51 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:39:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:39:51 --> Model "Change_model" initialized
INFO - 2023-01-12 06:39:57 --> Config Class Initialized
INFO - 2023-01-12 06:39:57 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:39:57 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:39:57 --> Utf8 Class Initialized
INFO - 2023-01-12 06:39:57 --> URI Class Initialized
INFO - 2023-01-12 06:39:57 --> Router Class Initialized
INFO - 2023-01-12 06:39:57 --> Output Class Initialized
INFO - 2023-01-12 06:39:57 --> Security Class Initialized
DEBUG - 2023-01-12 06:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:39:57 --> Input Class Initialized
INFO - 2023-01-12 06:39:57 --> Language Class Initialized
INFO - 2023-01-12 06:39:57 --> Loader Class Initialized
INFO - 2023-01-12 06:39:57 --> Controller Class Initialized
INFO - 2023-01-12 06:39:57 --> Helper loaded: form_helper
INFO - 2023-01-12 06:39:57 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:39:57 --> Model "Change_model" initialized
INFO - 2023-01-12 06:40:29 --> Config Class Initialized
INFO - 2023-01-12 06:40:29 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:40:29 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:40:29 --> Utf8 Class Initialized
INFO - 2023-01-12 06:40:29 --> URI Class Initialized
INFO - 2023-01-12 06:40:29 --> Router Class Initialized
INFO - 2023-01-12 06:40:29 --> Output Class Initialized
INFO - 2023-01-12 06:40:29 --> Security Class Initialized
DEBUG - 2023-01-12 06:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:40:29 --> Input Class Initialized
INFO - 2023-01-12 06:40:29 --> Language Class Initialized
INFO - 2023-01-12 06:40:29 --> Loader Class Initialized
INFO - 2023-01-12 06:40:29 --> Controller Class Initialized
INFO - 2023-01-12 06:40:29 --> Helper loaded: form_helper
INFO - 2023-01-12 06:40:29 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:40:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:40:29 --> Model "Change_model" initialized
INFO - 2023-01-12 06:40:30 --> Config Class Initialized
INFO - 2023-01-12 06:40:30 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:40:30 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:40:30 --> Utf8 Class Initialized
INFO - 2023-01-12 06:40:30 --> URI Class Initialized
INFO - 2023-01-12 06:40:30 --> Router Class Initialized
INFO - 2023-01-12 06:40:30 --> Output Class Initialized
INFO - 2023-01-12 06:40:30 --> Security Class Initialized
DEBUG - 2023-01-12 06:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:40:30 --> Input Class Initialized
INFO - 2023-01-12 06:40:30 --> Language Class Initialized
INFO - 2023-01-12 06:40:30 --> Loader Class Initialized
INFO - 2023-01-12 06:40:30 --> Controller Class Initialized
INFO - 2023-01-12 06:40:30 --> Helper loaded: form_helper
INFO - 2023-01-12 06:40:30 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:40:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:40:30 --> Model "Change_model" initialized
INFO - 2023-01-12 06:40:31 --> Config Class Initialized
INFO - 2023-01-12 06:40:31 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:40:31 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:40:31 --> Utf8 Class Initialized
INFO - 2023-01-12 06:40:31 --> URI Class Initialized
INFO - 2023-01-12 06:40:31 --> Router Class Initialized
INFO - 2023-01-12 06:40:31 --> Output Class Initialized
INFO - 2023-01-12 06:40:31 --> Security Class Initialized
DEBUG - 2023-01-12 06:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:40:31 --> Input Class Initialized
INFO - 2023-01-12 06:40:31 --> Language Class Initialized
INFO - 2023-01-12 06:40:31 --> Loader Class Initialized
INFO - 2023-01-12 06:40:31 --> Controller Class Initialized
INFO - 2023-01-12 06:40:31 --> Helper loaded: form_helper
INFO - 2023-01-12 06:40:31 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:40:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:40:31 --> Model "Change_model" initialized
INFO - 2023-01-12 06:40:32 --> Config Class Initialized
INFO - 2023-01-12 06:40:32 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:40:32 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:40:32 --> Utf8 Class Initialized
INFO - 2023-01-12 06:40:32 --> URI Class Initialized
INFO - 2023-01-12 06:40:32 --> Router Class Initialized
INFO - 2023-01-12 06:40:32 --> Output Class Initialized
INFO - 2023-01-12 06:40:32 --> Security Class Initialized
DEBUG - 2023-01-12 06:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:40:32 --> Input Class Initialized
INFO - 2023-01-12 06:40:32 --> Language Class Initialized
INFO - 2023-01-12 06:40:32 --> Loader Class Initialized
INFO - 2023-01-12 06:40:32 --> Controller Class Initialized
INFO - 2023-01-12 06:40:32 --> Helper loaded: form_helper
INFO - 2023-01-12 06:40:32 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:40:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:40:32 --> Model "Change_model" initialized
INFO - 2023-01-12 06:40:32 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:40:34 --> Config Class Initialized
INFO - 2023-01-12 06:40:34 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:40:34 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:40:34 --> Utf8 Class Initialized
INFO - 2023-01-12 06:40:34 --> URI Class Initialized
INFO - 2023-01-12 06:40:34 --> Router Class Initialized
INFO - 2023-01-12 06:40:34 --> Output Class Initialized
INFO - 2023-01-12 06:40:34 --> Security Class Initialized
DEBUG - 2023-01-12 06:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:40:34 --> Input Class Initialized
INFO - 2023-01-12 06:40:34 --> Language Class Initialized
INFO - 2023-01-12 06:40:34 --> Loader Class Initialized
INFO - 2023-01-12 06:40:34 --> Controller Class Initialized
INFO - 2023-01-12 06:40:34 --> Helper loaded: form_helper
INFO - 2023-01-12 06:40:34 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:40:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:40:34 --> Model "Change_model" initialized
INFO - 2023-01-12 06:40:34 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:40:35 --> Config Class Initialized
INFO - 2023-01-12 06:40:35 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:40:35 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:40:35 --> Utf8 Class Initialized
INFO - 2023-01-12 06:40:35 --> URI Class Initialized
INFO - 2023-01-12 06:40:35 --> Router Class Initialized
INFO - 2023-01-12 06:40:35 --> Output Class Initialized
INFO - 2023-01-12 06:40:35 --> Security Class Initialized
DEBUG - 2023-01-12 06:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:40:35 --> Input Class Initialized
INFO - 2023-01-12 06:40:35 --> Language Class Initialized
INFO - 2023-01-12 06:40:35 --> Loader Class Initialized
INFO - 2023-01-12 06:40:35 --> Controller Class Initialized
INFO - 2023-01-12 06:40:35 --> Helper loaded: form_helper
INFO - 2023-01-12 06:40:35 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:40:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:40:35 --> Model "Change_model" initialized
INFO - 2023-01-12 06:40:35 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:40:45 --> Config Class Initialized
INFO - 2023-01-12 06:40:45 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:40:45 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:40:45 --> Utf8 Class Initialized
INFO - 2023-01-12 06:40:45 --> URI Class Initialized
INFO - 2023-01-12 06:40:45 --> Router Class Initialized
INFO - 2023-01-12 06:40:45 --> Output Class Initialized
INFO - 2023-01-12 06:40:45 --> Security Class Initialized
DEBUG - 2023-01-12 06:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:40:45 --> Input Class Initialized
INFO - 2023-01-12 06:40:45 --> Language Class Initialized
INFO - 2023-01-12 06:40:45 --> Loader Class Initialized
INFO - 2023-01-12 06:40:45 --> Controller Class Initialized
INFO - 2023-01-12 06:40:45 --> Helper loaded: form_helper
INFO - 2023-01-12 06:40:45 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:40:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:40:45 --> Model "Change_model" initialized
INFO - 2023-01-12 06:40:45 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:40:50 --> Config Class Initialized
INFO - 2023-01-12 06:40:50 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:40:50 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:40:50 --> Utf8 Class Initialized
INFO - 2023-01-12 06:40:50 --> URI Class Initialized
INFO - 2023-01-12 06:40:50 --> Router Class Initialized
INFO - 2023-01-12 06:40:50 --> Output Class Initialized
INFO - 2023-01-12 06:40:50 --> Security Class Initialized
DEBUG - 2023-01-12 06:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:40:50 --> Input Class Initialized
INFO - 2023-01-12 06:40:50 --> Language Class Initialized
INFO - 2023-01-12 06:40:50 --> Loader Class Initialized
INFO - 2023-01-12 06:40:50 --> Controller Class Initialized
INFO - 2023-01-12 06:40:50 --> Helper loaded: form_helper
INFO - 2023-01-12 06:40:50 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:40:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:40:50 --> Model "Change_model" initialized
INFO - 2023-01-12 06:40:50 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:40:52 --> Config Class Initialized
INFO - 2023-01-12 06:40:52 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:40:52 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:40:52 --> Utf8 Class Initialized
INFO - 2023-01-12 06:40:52 --> URI Class Initialized
INFO - 2023-01-12 06:40:52 --> Router Class Initialized
INFO - 2023-01-12 06:40:52 --> Output Class Initialized
INFO - 2023-01-12 06:40:52 --> Security Class Initialized
DEBUG - 2023-01-12 06:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:40:52 --> Input Class Initialized
INFO - 2023-01-12 06:40:52 --> Language Class Initialized
INFO - 2023-01-12 06:40:52 --> Loader Class Initialized
INFO - 2023-01-12 06:40:52 --> Controller Class Initialized
INFO - 2023-01-12 06:40:52 --> Helper loaded: form_helper
INFO - 2023-01-12 06:40:52 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:40:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:40:52 --> Model "Change_model" initialized
INFO - 2023-01-12 06:40:52 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:41:11 --> Config Class Initialized
INFO - 2023-01-12 06:41:11 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:41:11 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:41:11 --> Utf8 Class Initialized
INFO - 2023-01-12 06:41:11 --> URI Class Initialized
INFO - 2023-01-12 06:41:11 --> Router Class Initialized
INFO - 2023-01-12 06:41:11 --> Output Class Initialized
INFO - 2023-01-12 06:41:11 --> Security Class Initialized
DEBUG - 2023-01-12 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:41:11 --> Input Class Initialized
INFO - 2023-01-12 06:41:11 --> Language Class Initialized
INFO - 2023-01-12 06:41:11 --> Loader Class Initialized
INFO - 2023-01-12 06:41:11 --> Controller Class Initialized
INFO - 2023-01-12 06:41:11 --> Helper loaded: form_helper
INFO - 2023-01-12 06:41:11 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:41:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:41:11 --> Model "Change_model" initialized
INFO - 2023-01-12 06:41:11 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:41:13 --> Config Class Initialized
INFO - 2023-01-12 06:41:13 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:41:13 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:41:13 --> Utf8 Class Initialized
INFO - 2023-01-12 06:41:13 --> URI Class Initialized
INFO - 2023-01-12 06:41:13 --> Router Class Initialized
INFO - 2023-01-12 06:41:13 --> Output Class Initialized
INFO - 2023-01-12 06:41:13 --> Security Class Initialized
DEBUG - 2023-01-12 06:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:41:13 --> Input Class Initialized
INFO - 2023-01-12 06:41:13 --> Language Class Initialized
INFO - 2023-01-12 06:41:13 --> Loader Class Initialized
INFO - 2023-01-12 06:41:13 --> Controller Class Initialized
INFO - 2023-01-12 06:41:13 --> Helper loaded: form_helper
INFO - 2023-01-12 06:41:13 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:41:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:41:13 --> Model "Change_model" initialized
INFO - 2023-01-12 06:41:13 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:41:15 --> Config Class Initialized
INFO - 2023-01-12 06:41:15 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:41:15 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:41:15 --> Utf8 Class Initialized
INFO - 2023-01-12 06:41:15 --> URI Class Initialized
INFO - 2023-01-12 06:41:15 --> Router Class Initialized
INFO - 2023-01-12 06:41:15 --> Output Class Initialized
INFO - 2023-01-12 06:41:15 --> Security Class Initialized
DEBUG - 2023-01-12 06:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:41:15 --> Input Class Initialized
INFO - 2023-01-12 06:41:15 --> Language Class Initialized
INFO - 2023-01-12 06:41:15 --> Loader Class Initialized
INFO - 2023-01-12 06:41:15 --> Controller Class Initialized
INFO - 2023-01-12 06:41:15 --> Helper loaded: form_helper
INFO - 2023-01-12 06:41:15 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:41:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:41:15 --> Model "Change_model" initialized
INFO - 2023-01-12 06:41:15 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:41:17 --> Config Class Initialized
INFO - 2023-01-12 06:41:17 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:41:17 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:41:17 --> Utf8 Class Initialized
INFO - 2023-01-12 06:41:17 --> URI Class Initialized
INFO - 2023-01-12 06:41:17 --> Router Class Initialized
INFO - 2023-01-12 06:41:17 --> Output Class Initialized
INFO - 2023-01-12 06:41:17 --> Security Class Initialized
DEBUG - 2023-01-12 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:41:17 --> Input Class Initialized
INFO - 2023-01-12 06:41:17 --> Language Class Initialized
INFO - 2023-01-12 06:41:17 --> Loader Class Initialized
INFO - 2023-01-12 06:41:17 --> Controller Class Initialized
INFO - 2023-01-12 06:41:17 --> Helper loaded: form_helper
INFO - 2023-01-12 06:41:17 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:41:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:41:17 --> Model "Change_model" initialized
INFO - 2023-01-12 06:41:17 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:41:44 --> Config Class Initialized
INFO - 2023-01-12 06:41:44 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:41:44 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:41:44 --> Utf8 Class Initialized
INFO - 2023-01-12 06:41:44 --> URI Class Initialized
INFO - 2023-01-12 06:41:44 --> Router Class Initialized
INFO - 2023-01-12 06:41:44 --> Output Class Initialized
INFO - 2023-01-12 06:41:44 --> Security Class Initialized
DEBUG - 2023-01-12 06:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:41:44 --> Input Class Initialized
INFO - 2023-01-12 06:41:44 --> Language Class Initialized
INFO - 2023-01-12 06:41:44 --> Loader Class Initialized
INFO - 2023-01-12 06:41:44 --> Controller Class Initialized
INFO - 2023-01-12 06:41:44 --> Helper loaded: form_helper
INFO - 2023-01-12 06:41:44 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:41:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:41:44 --> Model "Change_model" initialized
INFO - 2023-01-12 06:41:44 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:41:55 --> Config Class Initialized
INFO - 2023-01-12 06:41:55 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:41:55 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:41:55 --> Utf8 Class Initialized
INFO - 2023-01-12 06:41:55 --> URI Class Initialized
INFO - 2023-01-12 06:41:55 --> Router Class Initialized
INFO - 2023-01-12 06:41:55 --> Output Class Initialized
INFO - 2023-01-12 06:41:55 --> Security Class Initialized
DEBUG - 2023-01-12 06:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:41:55 --> Input Class Initialized
INFO - 2023-01-12 06:41:55 --> Language Class Initialized
INFO - 2023-01-12 06:41:55 --> Loader Class Initialized
INFO - 2023-01-12 06:41:55 --> Controller Class Initialized
INFO - 2023-01-12 06:41:55 --> Helper loaded: form_helper
INFO - 2023-01-12 06:41:55 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:41:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:41:55 --> Model "Change_model" initialized
INFO - 2023-01-12 06:41:55 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:41:56 --> Config Class Initialized
INFO - 2023-01-12 06:41:56 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:41:56 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:41:56 --> Utf8 Class Initialized
INFO - 2023-01-12 06:41:56 --> URI Class Initialized
INFO - 2023-01-12 06:41:56 --> Router Class Initialized
INFO - 2023-01-12 06:41:56 --> Output Class Initialized
INFO - 2023-01-12 06:41:56 --> Security Class Initialized
DEBUG - 2023-01-12 06:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:41:56 --> Input Class Initialized
INFO - 2023-01-12 06:41:56 --> Language Class Initialized
INFO - 2023-01-12 06:41:56 --> Loader Class Initialized
INFO - 2023-01-12 06:41:56 --> Controller Class Initialized
INFO - 2023-01-12 06:41:56 --> Helper loaded: form_helper
INFO - 2023-01-12 06:41:56 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:41:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:41:56 --> Model "Change_model" initialized
INFO - 2023-01-12 06:41:56 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:42:06 --> Config Class Initialized
INFO - 2023-01-12 06:42:06 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:42:06 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:42:06 --> Utf8 Class Initialized
INFO - 2023-01-12 06:42:06 --> URI Class Initialized
INFO - 2023-01-12 06:42:06 --> Router Class Initialized
INFO - 2023-01-12 06:42:06 --> Output Class Initialized
INFO - 2023-01-12 06:42:06 --> Security Class Initialized
DEBUG - 2023-01-12 06:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:42:06 --> Input Class Initialized
INFO - 2023-01-12 06:42:06 --> Language Class Initialized
INFO - 2023-01-12 06:42:06 --> Loader Class Initialized
INFO - 2023-01-12 06:42:06 --> Controller Class Initialized
INFO - 2023-01-12 06:42:06 --> Helper loaded: form_helper
INFO - 2023-01-12 06:42:06 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:42:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:42:06 --> Model "Change_model" initialized
INFO - 2023-01-12 06:42:06 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:42:11 --> Config Class Initialized
INFO - 2023-01-12 06:42:11 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:42:11 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:42:11 --> Utf8 Class Initialized
INFO - 2023-01-12 06:42:11 --> URI Class Initialized
INFO - 2023-01-12 06:42:11 --> Router Class Initialized
INFO - 2023-01-12 06:42:11 --> Output Class Initialized
INFO - 2023-01-12 06:42:11 --> Security Class Initialized
DEBUG - 2023-01-12 06:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:42:11 --> Input Class Initialized
INFO - 2023-01-12 06:42:11 --> Language Class Initialized
INFO - 2023-01-12 06:42:11 --> Loader Class Initialized
INFO - 2023-01-12 06:42:11 --> Controller Class Initialized
INFO - 2023-01-12 06:42:11 --> Helper loaded: form_helper
INFO - 2023-01-12 06:42:11 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:42:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:42:11 --> Model "Change_model" initialized
INFO - 2023-01-12 06:42:11 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:43:12 --> Config Class Initialized
INFO - 2023-01-12 06:43:12 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:43:12 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:43:12 --> Utf8 Class Initialized
INFO - 2023-01-12 06:43:12 --> URI Class Initialized
INFO - 2023-01-12 06:43:12 --> Router Class Initialized
INFO - 2023-01-12 06:43:12 --> Output Class Initialized
INFO - 2023-01-12 06:43:12 --> Security Class Initialized
DEBUG - 2023-01-12 06:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:43:12 --> Input Class Initialized
INFO - 2023-01-12 06:43:12 --> Language Class Initialized
INFO - 2023-01-12 06:43:12 --> Loader Class Initialized
INFO - 2023-01-12 06:43:12 --> Controller Class Initialized
INFO - 2023-01-12 06:43:12 --> Helper loaded: form_helper
INFO - 2023-01-12 06:43:12 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:43:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:43:12 --> Model "Change_model" initialized
INFO - 2023-01-12 06:43:12 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:43:14 --> Config Class Initialized
INFO - 2023-01-12 06:43:14 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:43:14 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:43:14 --> Utf8 Class Initialized
INFO - 2023-01-12 06:43:14 --> URI Class Initialized
INFO - 2023-01-12 06:43:14 --> Router Class Initialized
INFO - 2023-01-12 06:43:14 --> Output Class Initialized
INFO - 2023-01-12 06:43:14 --> Security Class Initialized
DEBUG - 2023-01-12 06:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:43:14 --> Input Class Initialized
INFO - 2023-01-12 06:43:14 --> Language Class Initialized
INFO - 2023-01-12 06:43:14 --> Loader Class Initialized
INFO - 2023-01-12 06:43:14 --> Controller Class Initialized
INFO - 2023-01-12 06:43:14 --> Helper loaded: form_helper
INFO - 2023-01-12 06:43:14 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:43:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:43:14 --> Model "Change_model" initialized
INFO - 2023-01-12 06:43:14 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:43:55 --> Config Class Initialized
INFO - 2023-01-12 06:43:55 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:43:55 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:43:55 --> Utf8 Class Initialized
INFO - 2023-01-12 06:43:55 --> URI Class Initialized
INFO - 2023-01-12 06:43:55 --> Router Class Initialized
INFO - 2023-01-12 06:43:55 --> Output Class Initialized
INFO - 2023-01-12 06:43:55 --> Security Class Initialized
DEBUG - 2023-01-12 06:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:43:55 --> Input Class Initialized
INFO - 2023-01-12 06:43:55 --> Language Class Initialized
INFO - 2023-01-12 06:43:55 --> Loader Class Initialized
INFO - 2023-01-12 06:43:55 --> Controller Class Initialized
INFO - 2023-01-12 06:43:55 --> Helper loaded: form_helper
INFO - 2023-01-12 06:43:55 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:43:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:43:55 --> Model "Change_model" initialized
INFO - 2023-01-12 06:43:55 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:43:56 --> Config Class Initialized
INFO - 2023-01-12 06:43:56 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:43:56 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:43:56 --> Utf8 Class Initialized
INFO - 2023-01-12 06:43:56 --> URI Class Initialized
INFO - 2023-01-12 06:43:56 --> Router Class Initialized
INFO - 2023-01-12 06:43:56 --> Output Class Initialized
INFO - 2023-01-12 06:43:56 --> Security Class Initialized
DEBUG - 2023-01-12 06:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:43:56 --> Input Class Initialized
INFO - 2023-01-12 06:43:56 --> Language Class Initialized
INFO - 2023-01-12 06:43:56 --> Loader Class Initialized
INFO - 2023-01-12 06:43:56 --> Controller Class Initialized
INFO - 2023-01-12 06:43:56 --> Helper loaded: form_helper
INFO - 2023-01-12 06:43:56 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:43:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:43:56 --> Model "Change_model" initialized
INFO - 2023-01-12 06:43:56 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:43:56 --> Config Class Initialized
INFO - 2023-01-12 06:43:56 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:43:56 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:43:56 --> Utf8 Class Initialized
INFO - 2023-01-12 06:43:56 --> URI Class Initialized
INFO - 2023-01-12 06:43:56 --> Router Class Initialized
INFO - 2023-01-12 06:43:56 --> Output Class Initialized
INFO - 2023-01-12 06:43:56 --> Security Class Initialized
DEBUG - 2023-01-12 06:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:43:56 --> Input Class Initialized
INFO - 2023-01-12 06:43:56 --> Language Class Initialized
INFO - 2023-01-12 06:43:56 --> Loader Class Initialized
INFO - 2023-01-12 06:43:56 --> Controller Class Initialized
INFO - 2023-01-12 06:43:56 --> Helper loaded: form_helper
INFO - 2023-01-12 06:43:56 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:43:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:43:56 --> Model "Change_model" initialized
INFO - 2023-01-12 06:43:56 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:43:56 --> Config Class Initialized
INFO - 2023-01-12 06:43:56 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:43:56 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:43:56 --> Utf8 Class Initialized
INFO - 2023-01-12 06:43:56 --> URI Class Initialized
INFO - 2023-01-12 06:43:56 --> Router Class Initialized
INFO - 2023-01-12 06:43:56 --> Output Class Initialized
INFO - 2023-01-12 06:43:56 --> Security Class Initialized
DEBUG - 2023-01-12 06:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:43:56 --> Input Class Initialized
INFO - 2023-01-12 06:43:56 --> Language Class Initialized
INFO - 2023-01-12 06:43:56 --> Loader Class Initialized
INFO - 2023-01-12 06:43:56 --> Controller Class Initialized
INFO - 2023-01-12 06:43:56 --> Helper loaded: form_helper
INFO - 2023-01-12 06:43:56 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:43:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:43:56 --> Model "Change_model" initialized
INFO - 2023-01-12 06:43:56 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:43:56 --> Config Class Initialized
INFO - 2023-01-12 06:43:56 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:43:56 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:43:56 --> Utf8 Class Initialized
INFO - 2023-01-12 06:43:56 --> URI Class Initialized
INFO - 2023-01-12 06:43:56 --> Router Class Initialized
INFO - 2023-01-12 06:43:56 --> Output Class Initialized
INFO - 2023-01-12 06:43:56 --> Security Class Initialized
DEBUG - 2023-01-12 06:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:43:56 --> Input Class Initialized
INFO - 2023-01-12 06:43:56 --> Language Class Initialized
INFO - 2023-01-12 06:43:56 --> Loader Class Initialized
INFO - 2023-01-12 06:43:56 --> Controller Class Initialized
INFO - 2023-01-12 06:43:56 --> Helper loaded: form_helper
INFO - 2023-01-12 06:43:56 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:43:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:43:56 --> Model "Change_model" initialized
INFO - 2023-01-12 06:43:56 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:43:56 --> Config Class Initialized
INFO - 2023-01-12 06:43:56 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:43:56 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:43:56 --> Utf8 Class Initialized
INFO - 2023-01-12 06:43:56 --> URI Class Initialized
INFO - 2023-01-12 06:43:56 --> Router Class Initialized
INFO - 2023-01-12 06:43:56 --> Output Class Initialized
INFO - 2023-01-12 06:43:56 --> Security Class Initialized
DEBUG - 2023-01-12 06:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:43:56 --> Input Class Initialized
INFO - 2023-01-12 06:43:56 --> Language Class Initialized
INFO - 2023-01-12 06:43:56 --> Loader Class Initialized
INFO - 2023-01-12 06:43:56 --> Controller Class Initialized
INFO - 2023-01-12 06:43:56 --> Helper loaded: form_helper
INFO - 2023-01-12 06:43:56 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:43:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:43:56 --> Model "Change_model" initialized
INFO - 2023-01-12 06:43:56 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:43:57 --> Config Class Initialized
INFO - 2023-01-12 06:43:57 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:43:57 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:43:57 --> Utf8 Class Initialized
INFO - 2023-01-12 06:43:57 --> URI Class Initialized
INFO - 2023-01-12 06:43:57 --> Router Class Initialized
INFO - 2023-01-12 06:43:57 --> Output Class Initialized
INFO - 2023-01-12 06:43:57 --> Security Class Initialized
DEBUG - 2023-01-12 06:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:43:57 --> Input Class Initialized
INFO - 2023-01-12 06:43:57 --> Language Class Initialized
INFO - 2023-01-12 06:43:57 --> Loader Class Initialized
INFO - 2023-01-12 06:43:57 --> Controller Class Initialized
INFO - 2023-01-12 06:43:57 --> Helper loaded: form_helper
INFO - 2023-01-12 06:43:57 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:43:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:43:57 --> Model "Change_model" initialized
INFO - 2023-01-12 06:43:57 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:44:47 --> Config Class Initialized
INFO - 2023-01-12 06:44:47 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:44:47 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:44:47 --> Utf8 Class Initialized
INFO - 2023-01-12 06:44:47 --> URI Class Initialized
INFO - 2023-01-12 06:44:47 --> Router Class Initialized
INFO - 2023-01-12 06:44:47 --> Output Class Initialized
INFO - 2023-01-12 06:44:47 --> Security Class Initialized
DEBUG - 2023-01-12 06:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:44:47 --> Input Class Initialized
INFO - 2023-01-12 06:44:47 --> Language Class Initialized
INFO - 2023-01-12 06:44:47 --> Loader Class Initialized
INFO - 2023-01-12 06:44:47 --> Controller Class Initialized
INFO - 2023-01-12 06:44:47 --> Helper loaded: form_helper
INFO - 2023-01-12 06:44:47 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:44:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:44:47 --> Model "Change_model" initialized
INFO - 2023-01-12 06:44:47 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:44:54 --> Config Class Initialized
INFO - 2023-01-12 06:44:54 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:44:54 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:44:54 --> Utf8 Class Initialized
INFO - 2023-01-12 06:44:54 --> URI Class Initialized
INFO - 2023-01-12 06:44:54 --> Router Class Initialized
INFO - 2023-01-12 06:44:54 --> Output Class Initialized
INFO - 2023-01-12 06:44:54 --> Security Class Initialized
DEBUG - 2023-01-12 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:44:54 --> Input Class Initialized
INFO - 2023-01-12 06:44:54 --> Language Class Initialized
INFO - 2023-01-12 06:44:54 --> Loader Class Initialized
INFO - 2023-01-12 06:44:54 --> Controller Class Initialized
INFO - 2023-01-12 06:44:54 --> Helper loaded: form_helper
INFO - 2023-01-12 06:44:54 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:44:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:44:54 --> Model "Change_model" initialized
INFO - 2023-01-12 06:44:54 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:46:53 --> Config Class Initialized
INFO - 2023-01-12 06:46:53 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:46:53 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:46:53 --> Utf8 Class Initialized
INFO - 2023-01-12 06:46:53 --> URI Class Initialized
INFO - 2023-01-12 06:46:53 --> Router Class Initialized
INFO - 2023-01-12 06:46:53 --> Output Class Initialized
INFO - 2023-01-12 06:46:53 --> Security Class Initialized
DEBUG - 2023-01-12 06:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:46:53 --> Input Class Initialized
INFO - 2023-01-12 06:46:53 --> Language Class Initialized
INFO - 2023-01-12 06:46:53 --> Loader Class Initialized
INFO - 2023-01-12 06:46:53 --> Controller Class Initialized
INFO - 2023-01-12 06:46:53 --> Helper loaded: form_helper
INFO - 2023-01-12 06:46:53 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:46:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:46:53 --> Model "Change_model" initialized
INFO - 2023-01-12 06:46:53 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:47:32 --> Config Class Initialized
INFO - 2023-01-12 06:47:32 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:47:32 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:47:32 --> Utf8 Class Initialized
INFO - 2023-01-12 06:47:32 --> URI Class Initialized
INFO - 2023-01-12 06:47:32 --> Router Class Initialized
INFO - 2023-01-12 06:47:32 --> Output Class Initialized
INFO - 2023-01-12 06:47:32 --> Security Class Initialized
DEBUG - 2023-01-12 06:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:47:32 --> Input Class Initialized
INFO - 2023-01-12 06:47:32 --> Language Class Initialized
INFO - 2023-01-12 06:47:32 --> Loader Class Initialized
INFO - 2023-01-12 06:47:32 --> Controller Class Initialized
INFO - 2023-01-12 06:47:32 --> Helper loaded: form_helper
INFO - 2023-01-12 06:47:32 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:47:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:47:32 --> Model "Change_model" initialized
INFO - 2023-01-12 06:47:32 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:47:32 --> Final output sent to browser
DEBUG - 2023-01-12 06:47:32 --> Total execution time: 0.0859
INFO - 2023-01-12 06:49:55 --> Config Class Initialized
INFO - 2023-01-12 06:49:55 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:49:55 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:49:55 --> Utf8 Class Initialized
INFO - 2023-01-12 06:49:55 --> URI Class Initialized
INFO - 2023-01-12 06:49:55 --> Router Class Initialized
INFO - 2023-01-12 06:49:55 --> Output Class Initialized
INFO - 2023-01-12 06:49:55 --> Security Class Initialized
DEBUG - 2023-01-12 06:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:49:55 --> Input Class Initialized
INFO - 2023-01-12 06:49:55 --> Language Class Initialized
INFO - 2023-01-12 06:49:55 --> Loader Class Initialized
INFO - 2023-01-12 06:49:55 --> Controller Class Initialized
INFO - 2023-01-12 06:49:55 --> Helper loaded: form_helper
INFO - 2023-01-12 06:49:55 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:49:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:49:55 --> Model "Change_model" initialized
INFO - 2023-01-12 06:49:55 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:50:05 --> Config Class Initialized
INFO - 2023-01-12 06:50:05 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:50:05 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:50:05 --> Utf8 Class Initialized
INFO - 2023-01-12 06:50:05 --> URI Class Initialized
INFO - 2023-01-12 06:50:05 --> Router Class Initialized
INFO - 2023-01-12 06:50:05 --> Output Class Initialized
INFO - 2023-01-12 06:50:05 --> Security Class Initialized
DEBUG - 2023-01-12 06:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:50:05 --> Input Class Initialized
INFO - 2023-01-12 06:50:05 --> Language Class Initialized
INFO - 2023-01-12 06:50:05 --> Loader Class Initialized
INFO - 2023-01-12 06:50:05 --> Controller Class Initialized
INFO - 2023-01-12 06:50:05 --> Helper loaded: form_helper
INFO - 2023-01-12 06:50:05 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:50:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:50:05 --> Model "Change_model" initialized
INFO - 2023-01-12 06:50:05 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:51:20 --> Config Class Initialized
INFO - 2023-01-12 06:51:20 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:51:20 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:51:20 --> Utf8 Class Initialized
INFO - 2023-01-12 06:51:20 --> URI Class Initialized
INFO - 2023-01-12 06:51:20 --> Router Class Initialized
INFO - 2023-01-12 06:51:20 --> Output Class Initialized
INFO - 2023-01-12 06:51:20 --> Security Class Initialized
DEBUG - 2023-01-12 06:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:51:20 --> Input Class Initialized
INFO - 2023-01-12 06:51:20 --> Language Class Initialized
INFO - 2023-01-12 06:51:20 --> Loader Class Initialized
INFO - 2023-01-12 06:51:20 --> Controller Class Initialized
INFO - 2023-01-12 06:51:20 --> Helper loaded: form_helper
INFO - 2023-01-12 06:51:20 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:51:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:51:20 --> Model "Change_model" initialized
INFO - 2023-01-12 06:51:20 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:51:20 --> Final output sent to browser
DEBUG - 2023-01-12 06:51:20 --> Total execution time: 0.0876
INFO - 2023-01-12 06:51:31 --> Config Class Initialized
INFO - 2023-01-12 06:51:32 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:51:32 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:51:32 --> Utf8 Class Initialized
INFO - 2023-01-12 06:51:32 --> URI Class Initialized
INFO - 2023-01-12 06:51:32 --> Router Class Initialized
INFO - 2023-01-12 06:51:32 --> Output Class Initialized
INFO - 2023-01-12 06:51:32 --> Security Class Initialized
DEBUG - 2023-01-12 06:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:51:32 --> Input Class Initialized
INFO - 2023-01-12 06:51:32 --> Language Class Initialized
INFO - 2023-01-12 06:51:32 --> Loader Class Initialized
INFO - 2023-01-12 06:51:32 --> Controller Class Initialized
INFO - 2023-01-12 06:51:32 --> Helper loaded: form_helper
INFO - 2023-01-12 06:51:32 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:51:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:51:32 --> Model "Change_model" initialized
INFO - 2023-01-12 06:51:32 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:51:32 --> Final output sent to browser
DEBUG - 2023-01-12 06:51:32 --> Total execution time: 0.3071
INFO - 2023-01-12 06:51:47 --> Config Class Initialized
INFO - 2023-01-12 06:51:47 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:51:47 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:51:47 --> Utf8 Class Initialized
INFO - 2023-01-12 06:51:47 --> URI Class Initialized
INFO - 2023-01-12 06:51:47 --> Router Class Initialized
INFO - 2023-01-12 06:51:47 --> Output Class Initialized
INFO - 2023-01-12 06:51:47 --> Security Class Initialized
DEBUG - 2023-01-12 06:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:51:47 --> Input Class Initialized
INFO - 2023-01-12 06:51:47 --> Language Class Initialized
INFO - 2023-01-12 06:51:47 --> Loader Class Initialized
INFO - 2023-01-12 06:51:47 --> Controller Class Initialized
INFO - 2023-01-12 06:51:47 --> Helper loaded: form_helper
INFO - 2023-01-12 06:51:47 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:51:47 --> Model "Change_model" initialized
INFO - 2023-01-12 06:51:47 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:51:47 --> Final output sent to browser
DEBUG - 2023-01-12 06:51:47 --> Total execution time: 0.3111
INFO - 2023-01-12 06:51:48 --> Config Class Initialized
INFO - 2023-01-12 06:51:48 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:51:48 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:51:48 --> Utf8 Class Initialized
INFO - 2023-01-12 06:51:48 --> URI Class Initialized
INFO - 2023-01-12 06:51:48 --> Router Class Initialized
INFO - 2023-01-12 06:51:48 --> Output Class Initialized
INFO - 2023-01-12 06:51:48 --> Security Class Initialized
DEBUG - 2023-01-12 06:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:51:48 --> Input Class Initialized
INFO - 2023-01-12 06:51:48 --> Language Class Initialized
INFO - 2023-01-12 06:51:48 --> Loader Class Initialized
INFO - 2023-01-12 06:51:48 --> Controller Class Initialized
INFO - 2023-01-12 06:51:48 --> Helper loaded: form_helper
INFO - 2023-01-12 06:51:48 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:51:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:51:48 --> Model "Change_model" initialized
INFO - 2023-01-12 06:51:48 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:51:49 --> Final output sent to browser
DEBUG - 2023-01-12 06:51:49 --> Total execution time: 0.3073
INFO - 2023-01-12 06:52:18 --> Config Class Initialized
INFO - 2023-01-12 06:52:18 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:52:18 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:52:18 --> Utf8 Class Initialized
INFO - 2023-01-12 06:52:18 --> URI Class Initialized
INFO - 2023-01-12 06:52:18 --> Router Class Initialized
INFO - 2023-01-12 06:52:18 --> Output Class Initialized
INFO - 2023-01-12 06:52:18 --> Security Class Initialized
DEBUG - 2023-01-12 06:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:52:18 --> Input Class Initialized
INFO - 2023-01-12 06:52:18 --> Language Class Initialized
INFO - 2023-01-12 06:52:18 --> Loader Class Initialized
INFO - 2023-01-12 06:52:18 --> Controller Class Initialized
INFO - 2023-01-12 06:52:18 --> Helper loaded: form_helper
INFO - 2023-01-12 06:52:18 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:52:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:52:18 --> Model "Change_model" initialized
INFO - 2023-01-12 06:52:18 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:52:48 --> Config Class Initialized
INFO - 2023-01-12 06:52:48 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:52:48 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:52:48 --> Utf8 Class Initialized
INFO - 2023-01-12 06:52:48 --> URI Class Initialized
INFO - 2023-01-12 06:52:48 --> Router Class Initialized
INFO - 2023-01-12 06:52:48 --> Output Class Initialized
INFO - 2023-01-12 06:52:48 --> Security Class Initialized
DEBUG - 2023-01-12 06:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:52:48 --> Input Class Initialized
INFO - 2023-01-12 06:52:48 --> Language Class Initialized
INFO - 2023-01-12 06:52:48 --> Loader Class Initialized
INFO - 2023-01-12 06:52:48 --> Controller Class Initialized
INFO - 2023-01-12 06:52:48 --> Helper loaded: form_helper
INFO - 2023-01-12 06:52:48 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:52:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:52:48 --> Model "Change_model" initialized
INFO - 2023-01-12 06:52:48 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:52:48 --> Final output sent to browser
DEBUG - 2023-01-12 06:52:48 --> Total execution time: 0.0805
INFO - 2023-01-12 06:52:54 --> Config Class Initialized
INFO - 2023-01-12 06:52:54 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:52:54 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:52:54 --> Utf8 Class Initialized
INFO - 2023-01-12 06:52:54 --> URI Class Initialized
INFO - 2023-01-12 06:52:54 --> Router Class Initialized
INFO - 2023-01-12 06:52:54 --> Output Class Initialized
INFO - 2023-01-12 06:52:54 --> Security Class Initialized
DEBUG - 2023-01-12 06:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:52:54 --> Input Class Initialized
INFO - 2023-01-12 06:52:54 --> Language Class Initialized
INFO - 2023-01-12 06:52:54 --> Loader Class Initialized
INFO - 2023-01-12 06:52:54 --> Controller Class Initialized
INFO - 2023-01-12 06:52:54 --> Helper loaded: form_helper
INFO - 2023-01-12 06:52:54 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:52:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:52:54 --> Model "Change_model" initialized
INFO - 2023-01-12 06:52:54 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:52:54 --> Final output sent to browser
DEBUG - 2023-01-12 06:52:54 --> Total execution time: 0.0415
INFO - 2023-01-12 06:52:54 --> Config Class Initialized
INFO - 2023-01-12 06:52:54 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:52:54 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:52:54 --> Utf8 Class Initialized
INFO - 2023-01-12 06:52:54 --> URI Class Initialized
INFO - 2023-01-12 06:52:54 --> Router Class Initialized
INFO - 2023-01-12 06:52:54 --> Output Class Initialized
INFO - 2023-01-12 06:52:54 --> Security Class Initialized
DEBUG - 2023-01-12 06:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:52:54 --> Input Class Initialized
INFO - 2023-01-12 06:52:54 --> Language Class Initialized
INFO - 2023-01-12 06:52:54 --> Loader Class Initialized
INFO - 2023-01-12 06:52:54 --> Controller Class Initialized
INFO - 2023-01-12 06:52:54 --> Helper loaded: form_helper
INFO - 2023-01-12 06:52:54 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:52:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:52:54 --> Final output sent to browser
DEBUG - 2023-01-12 06:52:54 --> Total execution time: 0.0021
INFO - 2023-01-12 06:52:54 --> Config Class Initialized
INFO - 2023-01-12 06:52:54 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:52:54 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:52:54 --> Utf8 Class Initialized
INFO - 2023-01-12 06:52:54 --> URI Class Initialized
INFO - 2023-01-12 06:52:54 --> Router Class Initialized
INFO - 2023-01-12 06:52:54 --> Output Class Initialized
INFO - 2023-01-12 06:52:54 --> Security Class Initialized
DEBUG - 2023-01-12 06:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:52:54 --> Input Class Initialized
INFO - 2023-01-12 06:52:54 --> Language Class Initialized
INFO - 2023-01-12 06:52:54 --> Loader Class Initialized
INFO - 2023-01-12 06:52:54 --> Controller Class Initialized
INFO - 2023-01-12 06:52:54 --> Helper loaded: form_helper
INFO - 2023-01-12 06:52:54 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:52:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:52:54 --> Database Driver Class Initialized
INFO - 2023-01-12 06:52:54 --> Model "Login_model" initialized
INFO - 2023-01-12 06:52:54 --> Final output sent to browser
DEBUG - 2023-01-12 06:52:54 --> Total execution time: 0.0577
INFO - 2023-01-12 06:53:02 --> Config Class Initialized
INFO - 2023-01-12 06:53:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:53:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:53:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:53:02 --> URI Class Initialized
INFO - 2023-01-12 06:53:02 --> Router Class Initialized
INFO - 2023-01-12 06:53:02 --> Output Class Initialized
INFO - 2023-01-12 06:53:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:53:02 --> Input Class Initialized
INFO - 2023-01-12 06:53:02 --> Language Class Initialized
INFO - 2023-01-12 06:53:02 --> Loader Class Initialized
INFO - 2023-01-12 06:53:02 --> Controller Class Initialized
INFO - 2023-01-12 06:53:02 --> Helper loaded: form_helper
INFO - 2023-01-12 06:53:02 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:53:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:53:02 --> Model "Change_model" initialized
INFO - 2023-01-12 06:53:02 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:53:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:53:02 --> Total execution time: 0.0398
INFO - 2023-01-12 06:53:02 --> Config Class Initialized
INFO - 2023-01-12 06:53:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:53:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:53:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:53:02 --> URI Class Initialized
INFO - 2023-01-12 06:53:02 --> Router Class Initialized
INFO - 2023-01-12 06:53:02 --> Output Class Initialized
INFO - 2023-01-12 06:53:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:53:02 --> Input Class Initialized
INFO - 2023-01-12 06:53:02 --> Language Class Initialized
INFO - 2023-01-12 06:53:02 --> Loader Class Initialized
INFO - 2023-01-12 06:53:02 --> Controller Class Initialized
INFO - 2023-01-12 06:53:02 --> Helper loaded: form_helper
INFO - 2023-01-12 06:53:02 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:53:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:53:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:53:02 --> Total execution time: 0.0020
INFO - 2023-01-12 06:53:02 --> Config Class Initialized
INFO - 2023-01-12 06:53:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:53:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:53:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:53:02 --> URI Class Initialized
INFO - 2023-01-12 06:53:02 --> Router Class Initialized
INFO - 2023-01-12 06:53:02 --> Output Class Initialized
INFO - 2023-01-12 06:53:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:53:02 --> Input Class Initialized
INFO - 2023-01-12 06:53:02 --> Language Class Initialized
INFO - 2023-01-12 06:53:02 --> Loader Class Initialized
INFO - 2023-01-12 06:53:02 --> Controller Class Initialized
INFO - 2023-01-12 06:53:02 --> Helper loaded: form_helper
INFO - 2023-01-12 06:53:02 --> Helper loaded: url_helper
DEBUG - 2023-01-12 06:53:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:53:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:53:02 --> Model "Login_model" initialized
INFO - 2023-01-12 06:53:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:53:02 --> Total execution time: 0.0152
INFO - 2023-01-12 06:53:02 --> Config Class Initialized
INFO - 2023-01-12 06:53:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:53:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:53:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:53:02 --> URI Class Initialized
INFO - 2023-01-12 06:53:02 --> Router Class Initialized
INFO - 2023-01-12 06:53:02 --> Output Class Initialized
INFO - 2023-01-12 06:53:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:53:02 --> Input Class Initialized
INFO - 2023-01-12 06:53:02 --> Language Class Initialized
INFO - 2023-01-12 06:53:02 --> Loader Class Initialized
INFO - 2023-01-12 06:53:02 --> Controller Class Initialized
DEBUG - 2023-01-12 06:53:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:53:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:53:02 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:53:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:53:02 --> Total execution time: 0.0171
INFO - 2023-01-12 06:53:02 --> Config Class Initialized
INFO - 2023-01-12 06:53:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:53:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:53:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:53:02 --> URI Class Initialized
INFO - 2023-01-12 06:53:02 --> Router Class Initialized
INFO - 2023-01-12 06:53:02 --> Output Class Initialized
INFO - 2023-01-12 06:53:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:53:02 --> Input Class Initialized
INFO - 2023-01-12 06:53:02 --> Language Class Initialized
INFO - 2023-01-12 06:53:02 --> Loader Class Initialized
INFO - 2023-01-12 06:53:02 --> Controller Class Initialized
DEBUG - 2023-01-12 06:53:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:53:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:53:02 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:53:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:53:02 --> Total execution time: 0.0130
INFO - 2023-01-12 06:53:02 --> Config Class Initialized
INFO - 2023-01-12 06:53:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:53:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:53:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:53:02 --> URI Class Initialized
INFO - 2023-01-12 06:53:02 --> Router Class Initialized
INFO - 2023-01-12 06:53:02 --> Output Class Initialized
INFO - 2023-01-12 06:53:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:53:02 --> Input Class Initialized
INFO - 2023-01-12 06:53:02 --> Language Class Initialized
INFO - 2023-01-12 06:53:02 --> Loader Class Initialized
INFO - 2023-01-12 06:53:02 --> Controller Class Initialized
DEBUG - 2023-01-12 06:53:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:53:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:53:02 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:53:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:53:02 --> Model "Login_model" initialized
INFO - 2023-01-12 06:53:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:53:02 --> Total execution time: 0.0848
INFO - 2023-01-12 06:53:02 --> Config Class Initialized
INFO - 2023-01-12 06:53:02 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:53:02 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:53:02 --> Utf8 Class Initialized
INFO - 2023-01-12 06:53:02 --> URI Class Initialized
INFO - 2023-01-12 06:53:02 --> Router Class Initialized
INFO - 2023-01-12 06:53:02 --> Output Class Initialized
INFO - 2023-01-12 06:53:02 --> Security Class Initialized
DEBUG - 2023-01-12 06:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:53:02 --> Input Class Initialized
INFO - 2023-01-12 06:53:02 --> Language Class Initialized
INFO - 2023-01-12 06:53:02 --> Loader Class Initialized
INFO - 2023-01-12 06:53:02 --> Controller Class Initialized
DEBUG - 2023-01-12 06:53:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:53:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:53:02 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:53:02 --> Database Driver Class Initialized
INFO - 2023-01-12 06:53:02 --> Model "Login_model" initialized
INFO - 2023-01-12 06:53:02 --> Final output sent to browser
DEBUG - 2023-01-12 06:53:02 --> Total execution time: 0.0397
INFO - 2023-01-12 06:53:06 --> Config Class Initialized
INFO - 2023-01-12 06:53:06 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:53:06 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:53:06 --> Utf8 Class Initialized
INFO - 2023-01-12 06:53:06 --> URI Class Initialized
INFO - 2023-01-12 06:53:06 --> Router Class Initialized
INFO - 2023-01-12 06:53:06 --> Output Class Initialized
INFO - 2023-01-12 06:53:06 --> Security Class Initialized
DEBUG - 2023-01-12 06:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:53:06 --> Input Class Initialized
INFO - 2023-01-12 06:53:06 --> Language Class Initialized
INFO - 2023-01-12 06:53:06 --> Loader Class Initialized
INFO - 2023-01-12 06:53:06 --> Controller Class Initialized
DEBUG - 2023-01-12 06:53:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:53:06 --> Final output sent to browser
DEBUG - 2023-01-12 06:53:06 --> Total execution time: 0.0042
INFO - 2023-01-12 06:53:06 --> Config Class Initialized
INFO - 2023-01-12 06:53:06 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:53:06 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:53:06 --> Utf8 Class Initialized
INFO - 2023-01-12 06:53:06 --> URI Class Initialized
INFO - 2023-01-12 06:53:06 --> Router Class Initialized
INFO - 2023-01-12 06:53:06 --> Output Class Initialized
INFO - 2023-01-12 06:53:06 --> Security Class Initialized
DEBUG - 2023-01-12 06:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:53:06 --> Input Class Initialized
INFO - 2023-01-12 06:53:06 --> Language Class Initialized
INFO - 2023-01-12 06:53:06 --> Loader Class Initialized
INFO - 2023-01-12 06:53:06 --> Controller Class Initialized
DEBUG - 2023-01-12 06:53:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:53:06 --> Database Driver Class Initialized
INFO - 2023-01-12 06:53:06 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:53:06 --> Model "Node_model" initialized
INFO - 2023-01-12 06:53:06 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:54:21 --> Config Class Initialized
INFO - 2023-01-12 06:54:21 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:54:21 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:54:21 --> Utf8 Class Initialized
INFO - 2023-01-12 06:54:21 --> URI Class Initialized
INFO - 2023-01-12 06:54:21 --> Router Class Initialized
INFO - 2023-01-12 06:54:21 --> Output Class Initialized
INFO - 2023-01-12 06:54:21 --> Security Class Initialized
DEBUG - 2023-01-12 06:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:54:21 --> Input Class Initialized
INFO - 2023-01-12 06:54:21 --> Language Class Initialized
INFO - 2023-01-12 06:54:21 --> Loader Class Initialized
INFO - 2023-01-12 06:54:21 --> Controller Class Initialized
DEBUG - 2023-01-12 06:54:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:54:21 --> Final output sent to browser
DEBUG - 2023-01-12 06:54:21 --> Total execution time: 0.0035
INFO - 2023-01-12 06:54:21 --> Config Class Initialized
INFO - 2023-01-12 06:54:21 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:54:21 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:54:21 --> Utf8 Class Initialized
INFO - 2023-01-12 06:54:21 --> URI Class Initialized
INFO - 2023-01-12 06:54:21 --> Router Class Initialized
INFO - 2023-01-12 06:54:21 --> Output Class Initialized
INFO - 2023-01-12 06:54:21 --> Security Class Initialized
DEBUG - 2023-01-12 06:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:54:21 --> Input Class Initialized
INFO - 2023-01-12 06:54:21 --> Language Class Initialized
INFO - 2023-01-12 06:54:21 --> Loader Class Initialized
INFO - 2023-01-12 06:54:21 --> Controller Class Initialized
DEBUG - 2023-01-12 06:54:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:54:21 --> Database Driver Class Initialized
INFO - 2023-01-12 06:54:21 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:54:21 --> Model "Node_model" initialized
INFO - 2023-01-12 06:54:21 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:55:26 --> Config Class Initialized
INFO - 2023-01-12 06:55:26 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:55:26 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:55:26 --> Utf8 Class Initialized
INFO - 2023-01-12 06:55:26 --> URI Class Initialized
INFO - 2023-01-12 06:55:26 --> Router Class Initialized
INFO - 2023-01-12 06:55:26 --> Output Class Initialized
INFO - 2023-01-12 06:55:26 --> Security Class Initialized
DEBUG - 2023-01-12 06:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:55:26 --> Input Class Initialized
INFO - 2023-01-12 06:55:26 --> Language Class Initialized
INFO - 2023-01-12 06:55:26 --> Loader Class Initialized
INFO - 2023-01-12 06:55:26 --> Controller Class Initialized
DEBUG - 2023-01-12 06:55:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:55:26 --> Final output sent to browser
DEBUG - 2023-01-12 06:55:26 --> Total execution time: 0.0051
INFO - 2023-01-12 06:55:26 --> Config Class Initialized
INFO - 2023-01-12 06:55:26 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:55:26 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:55:26 --> Utf8 Class Initialized
INFO - 2023-01-12 06:55:26 --> URI Class Initialized
INFO - 2023-01-12 06:55:26 --> Router Class Initialized
INFO - 2023-01-12 06:55:26 --> Output Class Initialized
INFO - 2023-01-12 06:55:26 --> Security Class Initialized
DEBUG - 2023-01-12 06:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:55:26 --> Input Class Initialized
INFO - 2023-01-12 06:55:26 --> Language Class Initialized
INFO - 2023-01-12 06:55:26 --> Loader Class Initialized
INFO - 2023-01-12 06:55:26 --> Controller Class Initialized
DEBUG - 2023-01-12 06:55:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:55:26 --> Database Driver Class Initialized
INFO - 2023-01-12 06:55:26 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:55:26 --> Model "Node_model" initialized
INFO - 2023-01-12 06:55:26 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:58:07 --> Config Class Initialized
INFO - 2023-01-12 06:58:07 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:58:07 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:58:07 --> Utf8 Class Initialized
INFO - 2023-01-12 06:58:07 --> URI Class Initialized
INFO - 2023-01-12 06:58:07 --> Router Class Initialized
INFO - 2023-01-12 06:58:07 --> Output Class Initialized
INFO - 2023-01-12 06:58:07 --> Security Class Initialized
DEBUG - 2023-01-12 06:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:58:07 --> Input Class Initialized
INFO - 2023-01-12 06:58:07 --> Language Class Initialized
INFO - 2023-01-12 06:58:07 --> Loader Class Initialized
INFO - 2023-01-12 06:58:07 --> Controller Class Initialized
DEBUG - 2023-01-12 06:58:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:58:07 --> Final output sent to browser
DEBUG - 2023-01-12 06:58:07 --> Total execution time: 0.0049
INFO - 2023-01-12 06:58:07 --> Config Class Initialized
INFO - 2023-01-12 06:58:07 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:58:07 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:58:07 --> Utf8 Class Initialized
INFO - 2023-01-12 06:58:07 --> URI Class Initialized
INFO - 2023-01-12 06:58:07 --> Router Class Initialized
INFO - 2023-01-12 06:58:07 --> Output Class Initialized
INFO - 2023-01-12 06:58:07 --> Security Class Initialized
DEBUG - 2023-01-12 06:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:58:07 --> Input Class Initialized
INFO - 2023-01-12 06:58:07 --> Language Class Initialized
INFO - 2023-01-12 06:58:07 --> Loader Class Initialized
INFO - 2023-01-12 06:58:07 --> Controller Class Initialized
DEBUG - 2023-01-12 06:58:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:58:07 --> Database Driver Class Initialized
INFO - 2023-01-12 06:58:07 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:58:07 --> Model "Node_model" initialized
INFO - 2023-01-12 06:58:07 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:58:57 --> Config Class Initialized
INFO - 2023-01-12 06:58:57 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:58:57 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:58:57 --> Utf8 Class Initialized
INFO - 2023-01-12 06:58:57 --> URI Class Initialized
INFO - 2023-01-12 06:58:57 --> Router Class Initialized
INFO - 2023-01-12 06:58:57 --> Output Class Initialized
INFO - 2023-01-12 06:58:57 --> Security Class Initialized
DEBUG - 2023-01-12 06:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:58:57 --> Input Class Initialized
INFO - 2023-01-12 06:58:57 --> Language Class Initialized
INFO - 2023-01-12 06:58:57 --> Loader Class Initialized
INFO - 2023-01-12 06:58:57 --> Controller Class Initialized
DEBUG - 2023-01-12 06:58:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:58:57 --> Final output sent to browser
DEBUG - 2023-01-12 06:58:57 --> Total execution time: 0.0051
INFO - 2023-01-12 06:58:57 --> Config Class Initialized
INFO - 2023-01-12 06:58:57 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:58:57 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:58:57 --> Utf8 Class Initialized
INFO - 2023-01-12 06:58:57 --> URI Class Initialized
INFO - 2023-01-12 06:58:57 --> Router Class Initialized
INFO - 2023-01-12 06:58:57 --> Output Class Initialized
INFO - 2023-01-12 06:58:57 --> Security Class Initialized
DEBUG - 2023-01-12 06:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:58:57 --> Input Class Initialized
INFO - 2023-01-12 06:58:57 --> Language Class Initialized
INFO - 2023-01-12 06:58:57 --> Loader Class Initialized
INFO - 2023-01-12 06:58:57 --> Controller Class Initialized
DEBUG - 2023-01-12 06:58:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:58:57 --> Database Driver Class Initialized
INFO - 2023-01-12 06:58:57 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:58:57 --> Model "Node_model" initialized
INFO - 2023-01-12 06:58:57 --> Model "Grafana_model" initialized
INFO - 2023-01-12 06:59:30 --> Config Class Initialized
INFO - 2023-01-12 06:59:30 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:59:30 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:59:30 --> Utf8 Class Initialized
INFO - 2023-01-12 06:59:30 --> URI Class Initialized
INFO - 2023-01-12 06:59:30 --> Router Class Initialized
INFO - 2023-01-12 06:59:30 --> Output Class Initialized
INFO - 2023-01-12 06:59:30 --> Security Class Initialized
DEBUG - 2023-01-12 06:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:59:30 --> Input Class Initialized
INFO - 2023-01-12 06:59:30 --> Language Class Initialized
INFO - 2023-01-12 06:59:30 --> Loader Class Initialized
INFO - 2023-01-12 06:59:30 --> Controller Class Initialized
DEBUG - 2023-01-12 06:59:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:59:30 --> Final output sent to browser
DEBUG - 2023-01-12 06:59:30 --> Total execution time: 0.0421
INFO - 2023-01-12 06:59:30 --> Config Class Initialized
INFO - 2023-01-12 06:59:30 --> Hooks Class Initialized
DEBUG - 2023-01-12 06:59:30 --> UTF-8 Support Enabled
INFO - 2023-01-12 06:59:30 --> Utf8 Class Initialized
INFO - 2023-01-12 06:59:30 --> URI Class Initialized
INFO - 2023-01-12 06:59:30 --> Router Class Initialized
INFO - 2023-01-12 06:59:30 --> Output Class Initialized
INFO - 2023-01-12 06:59:30 --> Security Class Initialized
DEBUG - 2023-01-12 06:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 06:59:30 --> Input Class Initialized
INFO - 2023-01-12 06:59:30 --> Language Class Initialized
INFO - 2023-01-12 06:59:30 --> Loader Class Initialized
INFO - 2023-01-12 06:59:30 --> Controller Class Initialized
DEBUG - 2023-01-12 06:59:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 06:59:30 --> Database Driver Class Initialized
INFO - 2023-01-12 06:59:30 --> Model "Cluster_model" initialized
INFO - 2023-01-12 06:59:30 --> Model "Node_model" initialized
INFO - 2023-01-12 06:59:30 --> Model "Grafana_model" initialized
INFO - 2023-01-12 07:11:20 --> Config Class Initialized
INFO - 2023-01-12 07:11:20 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:11:20 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:11:20 --> Utf8 Class Initialized
INFO - 2023-01-12 07:11:20 --> URI Class Initialized
INFO - 2023-01-12 07:11:20 --> Router Class Initialized
INFO - 2023-01-12 07:11:20 --> Output Class Initialized
INFO - 2023-01-12 07:11:20 --> Security Class Initialized
DEBUG - 2023-01-12 07:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:11:20 --> Input Class Initialized
INFO - 2023-01-12 07:11:20 --> Language Class Initialized
INFO - 2023-01-12 07:11:20 --> Loader Class Initialized
INFO - 2023-01-12 07:11:20 --> Controller Class Initialized
DEBUG - 2023-01-12 07:11:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:11:20 --> Final output sent to browser
DEBUG - 2023-01-12 07:11:20 --> Total execution time: 0.0042
INFO - 2023-01-12 07:11:21 --> Config Class Initialized
INFO - 2023-01-12 07:11:21 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:11:21 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:11:21 --> Utf8 Class Initialized
INFO - 2023-01-12 07:11:21 --> URI Class Initialized
INFO - 2023-01-12 07:11:21 --> Router Class Initialized
INFO - 2023-01-12 07:11:21 --> Output Class Initialized
INFO - 2023-01-12 07:11:21 --> Security Class Initialized
DEBUG - 2023-01-12 07:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:11:21 --> Input Class Initialized
INFO - 2023-01-12 07:11:21 --> Language Class Initialized
INFO - 2023-01-12 07:11:21 --> Loader Class Initialized
INFO - 2023-01-12 07:11:21 --> Controller Class Initialized
DEBUG - 2023-01-12 07:11:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:11:21 --> Database Driver Class Initialized
INFO - 2023-01-12 07:11:21 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:11:21 --> Model "Node_model" initialized
INFO - 2023-01-12 07:11:21 --> Model "Grafana_model" initialized
INFO - 2023-01-12 07:16:08 --> Config Class Initialized
INFO - 2023-01-12 07:16:08 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:16:08 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:16:08 --> Utf8 Class Initialized
INFO - 2023-01-12 07:16:08 --> URI Class Initialized
INFO - 2023-01-12 07:16:08 --> Router Class Initialized
INFO - 2023-01-12 07:16:08 --> Output Class Initialized
INFO - 2023-01-12 07:16:08 --> Security Class Initialized
DEBUG - 2023-01-12 07:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:16:08 --> Input Class Initialized
INFO - 2023-01-12 07:16:08 --> Language Class Initialized
INFO - 2023-01-12 07:16:08 --> Loader Class Initialized
INFO - 2023-01-12 07:16:08 --> Controller Class Initialized
DEBUG - 2023-01-12 07:16:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:16:08 --> Final output sent to browser
DEBUG - 2023-01-12 07:16:08 --> Total execution time: 0.0494
INFO - 2023-01-12 07:16:08 --> Config Class Initialized
INFO - 2023-01-12 07:16:08 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:16:08 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:16:08 --> Utf8 Class Initialized
INFO - 2023-01-12 07:16:08 --> URI Class Initialized
INFO - 2023-01-12 07:16:08 --> Router Class Initialized
INFO - 2023-01-12 07:16:08 --> Output Class Initialized
INFO - 2023-01-12 07:16:08 --> Security Class Initialized
DEBUG - 2023-01-12 07:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:16:08 --> Input Class Initialized
INFO - 2023-01-12 07:16:08 --> Language Class Initialized
INFO - 2023-01-12 07:16:08 --> Loader Class Initialized
INFO - 2023-01-12 07:16:08 --> Controller Class Initialized
DEBUG - 2023-01-12 07:16:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:16:08 --> Database Driver Class Initialized
INFO - 2023-01-12 07:16:08 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:16:08 --> Model "Node_model" initialized
INFO - 2023-01-12 07:16:08 --> Model "Grafana_model" initialized
INFO - 2023-01-12 07:16:44 --> Config Class Initialized
INFO - 2023-01-12 07:16:44 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:16:44 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:16:44 --> Utf8 Class Initialized
INFO - 2023-01-12 07:16:44 --> URI Class Initialized
INFO - 2023-01-12 07:16:44 --> Router Class Initialized
INFO - 2023-01-12 07:16:44 --> Output Class Initialized
INFO - 2023-01-12 07:16:44 --> Security Class Initialized
DEBUG - 2023-01-12 07:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:16:44 --> Input Class Initialized
INFO - 2023-01-12 07:16:44 --> Language Class Initialized
INFO - 2023-01-12 07:16:44 --> Loader Class Initialized
INFO - 2023-01-12 07:16:44 --> Controller Class Initialized
DEBUG - 2023-01-12 07:16:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:16:44 --> Final output sent to browser
DEBUG - 2023-01-12 07:16:44 --> Total execution time: 0.0057
INFO - 2023-01-12 07:16:44 --> Config Class Initialized
INFO - 2023-01-12 07:16:44 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:16:44 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:16:44 --> Utf8 Class Initialized
INFO - 2023-01-12 07:16:44 --> URI Class Initialized
INFO - 2023-01-12 07:16:44 --> Router Class Initialized
INFO - 2023-01-12 07:16:44 --> Output Class Initialized
INFO - 2023-01-12 07:16:44 --> Security Class Initialized
DEBUG - 2023-01-12 07:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:16:44 --> Input Class Initialized
INFO - 2023-01-12 07:16:44 --> Language Class Initialized
INFO - 2023-01-12 07:16:44 --> Loader Class Initialized
INFO - 2023-01-12 07:16:44 --> Controller Class Initialized
DEBUG - 2023-01-12 07:16:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:16:44 --> Database Driver Class Initialized
INFO - 2023-01-12 07:16:44 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:16:44 --> Model "Node_model" initialized
INFO - 2023-01-12 07:16:44 --> Model "Grafana_model" initialized
INFO - 2023-01-12 07:18:08 --> Config Class Initialized
INFO - 2023-01-12 07:18:08 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:18:08 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:18:08 --> Utf8 Class Initialized
INFO - 2023-01-12 07:18:08 --> URI Class Initialized
INFO - 2023-01-12 07:18:08 --> Router Class Initialized
INFO - 2023-01-12 07:18:08 --> Output Class Initialized
INFO - 2023-01-12 07:18:08 --> Security Class Initialized
DEBUG - 2023-01-12 07:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:18:08 --> Input Class Initialized
INFO - 2023-01-12 07:18:08 --> Language Class Initialized
INFO - 2023-01-12 07:18:08 --> Loader Class Initialized
INFO - 2023-01-12 07:18:08 --> Controller Class Initialized
DEBUG - 2023-01-12 07:18:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:18:08 --> Final output sent to browser
DEBUG - 2023-01-12 07:18:08 --> Total execution time: 0.0089
INFO - 2023-01-12 07:18:08 --> Config Class Initialized
INFO - 2023-01-12 07:18:08 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:18:08 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:18:08 --> Utf8 Class Initialized
INFO - 2023-01-12 07:18:08 --> URI Class Initialized
INFO - 2023-01-12 07:18:08 --> Router Class Initialized
INFO - 2023-01-12 07:18:08 --> Output Class Initialized
INFO - 2023-01-12 07:18:08 --> Security Class Initialized
DEBUG - 2023-01-12 07:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:18:08 --> Input Class Initialized
INFO - 2023-01-12 07:18:08 --> Language Class Initialized
INFO - 2023-01-12 07:18:08 --> Loader Class Initialized
INFO - 2023-01-12 07:18:08 --> Controller Class Initialized
DEBUG - 2023-01-12 07:18:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:18:08 --> Database Driver Class Initialized
INFO - 2023-01-12 07:18:08 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:18:08 --> Model "Node_model" initialized
INFO - 2023-01-12 07:18:08 --> Model "Grafana_model" initialized
INFO - 2023-01-12 07:18:08 --> Final output sent to browser
DEBUG - 2023-01-12 07:18:08 --> Total execution time: 0.0799
INFO - 2023-01-12 07:18:10 --> Config Class Initialized
INFO - 2023-01-12 07:18:10 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:18:10 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:18:10 --> Utf8 Class Initialized
INFO - 2023-01-12 07:18:10 --> URI Class Initialized
INFO - 2023-01-12 07:18:10 --> Router Class Initialized
INFO - 2023-01-12 07:18:10 --> Output Class Initialized
INFO - 2023-01-12 07:18:10 --> Security Class Initialized
DEBUG - 2023-01-12 07:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:18:10 --> Input Class Initialized
INFO - 2023-01-12 07:18:10 --> Language Class Initialized
INFO - 2023-01-12 07:18:10 --> Loader Class Initialized
INFO - 2023-01-12 07:18:10 --> Controller Class Initialized
DEBUG - 2023-01-12 07:18:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:18:10 --> Final output sent to browser
DEBUG - 2023-01-12 07:18:10 --> Total execution time: 0.1266
INFO - 2023-01-12 07:18:22 --> Config Class Initialized
INFO - 2023-01-12 07:18:22 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:18:22 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:18:22 --> Utf8 Class Initialized
INFO - 2023-01-12 07:18:22 --> URI Class Initialized
INFO - 2023-01-12 07:18:22 --> Router Class Initialized
INFO - 2023-01-12 07:18:22 --> Output Class Initialized
INFO - 2023-01-12 07:18:22 --> Security Class Initialized
DEBUG - 2023-01-12 07:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:18:22 --> Input Class Initialized
INFO - 2023-01-12 07:18:22 --> Language Class Initialized
INFO - 2023-01-12 07:18:22 --> Loader Class Initialized
INFO - 2023-01-12 07:18:22 --> Controller Class Initialized
DEBUG - 2023-01-12 07:18:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:18:22 --> Final output sent to browser
DEBUG - 2023-01-12 07:18:22 --> Total execution time: 0.0035
INFO - 2023-01-12 07:18:22 --> Config Class Initialized
INFO - 2023-01-12 07:18:22 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:18:22 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:18:22 --> Utf8 Class Initialized
INFO - 2023-01-12 07:18:22 --> URI Class Initialized
INFO - 2023-01-12 07:18:22 --> Router Class Initialized
INFO - 2023-01-12 07:18:22 --> Output Class Initialized
INFO - 2023-01-12 07:18:22 --> Security Class Initialized
DEBUG - 2023-01-12 07:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:18:22 --> Input Class Initialized
INFO - 2023-01-12 07:18:22 --> Language Class Initialized
INFO - 2023-01-12 07:18:22 --> Loader Class Initialized
INFO - 2023-01-12 07:18:22 --> Controller Class Initialized
DEBUG - 2023-01-12 07:18:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:18:22 --> Database Driver Class Initialized
INFO - 2023-01-12 07:18:22 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:18:22 --> Model "Node_model" initialized
INFO - 2023-01-12 07:18:22 --> Model "Grafana_model" initialized
INFO - 2023-01-12 07:18:22 --> Final output sent to browser
DEBUG - 2023-01-12 07:18:22 --> Total execution time: 0.0569
INFO - 2023-01-12 07:18:36 --> Config Class Initialized
INFO - 2023-01-12 07:18:36 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:18:36 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:18:36 --> Utf8 Class Initialized
INFO - 2023-01-12 07:18:36 --> URI Class Initialized
INFO - 2023-01-12 07:18:36 --> Router Class Initialized
INFO - 2023-01-12 07:18:36 --> Output Class Initialized
INFO - 2023-01-12 07:18:36 --> Security Class Initialized
DEBUG - 2023-01-12 07:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:18:36 --> Input Class Initialized
INFO - 2023-01-12 07:18:36 --> Language Class Initialized
INFO - 2023-01-12 07:18:36 --> Loader Class Initialized
INFO - 2023-01-12 07:18:36 --> Controller Class Initialized
DEBUG - 2023-01-12 07:18:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:18:36 --> Final output sent to browser
DEBUG - 2023-01-12 07:18:36 --> Total execution time: 0.0050
INFO - 2023-01-12 07:18:36 --> Config Class Initialized
INFO - 2023-01-12 07:18:36 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:18:36 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:18:36 --> Utf8 Class Initialized
INFO - 2023-01-12 07:18:36 --> URI Class Initialized
INFO - 2023-01-12 07:18:36 --> Router Class Initialized
INFO - 2023-01-12 07:18:36 --> Output Class Initialized
INFO - 2023-01-12 07:18:36 --> Security Class Initialized
DEBUG - 2023-01-12 07:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:18:36 --> Input Class Initialized
INFO - 2023-01-12 07:18:36 --> Language Class Initialized
INFO - 2023-01-12 07:18:36 --> Loader Class Initialized
INFO - 2023-01-12 07:18:36 --> Controller Class Initialized
DEBUG - 2023-01-12 07:18:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:18:36 --> Database Driver Class Initialized
INFO - 2023-01-12 07:18:36 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:18:36 --> Model "Node_model" initialized
INFO - 2023-01-12 07:18:36 --> Model "Grafana_model" initialized
INFO - 2023-01-12 07:18:36 --> Final output sent to browser
DEBUG - 2023-01-12 07:18:36 --> Total execution time: 0.0650
INFO - 2023-01-12 07:20:18 --> Config Class Initialized
INFO - 2023-01-12 07:20:18 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:20:18 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:20:18 --> Utf8 Class Initialized
INFO - 2023-01-12 07:20:18 --> URI Class Initialized
INFO - 2023-01-12 07:20:18 --> Router Class Initialized
INFO - 2023-01-12 07:20:18 --> Output Class Initialized
INFO - 2023-01-12 07:20:18 --> Security Class Initialized
DEBUG - 2023-01-12 07:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:20:18 --> Input Class Initialized
INFO - 2023-01-12 07:20:18 --> Language Class Initialized
INFO - 2023-01-12 07:20:18 --> Loader Class Initialized
INFO - 2023-01-12 07:20:18 --> Controller Class Initialized
DEBUG - 2023-01-12 07:20:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:20:18 --> Database Driver Class Initialized
INFO - 2023-01-12 07:20:18 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:20:18 --> Database Driver Class Initialized
INFO - 2023-01-12 07:20:18 --> Model "Login_model" initialized
INFO - 2023-01-12 07:20:18 --> Final output sent to browser
DEBUG - 2023-01-12 07:20:18 --> Total execution time: 0.0486
INFO - 2023-01-12 07:20:18 --> Config Class Initialized
INFO - 2023-01-12 07:20:18 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:20:18 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:20:18 --> Utf8 Class Initialized
INFO - 2023-01-12 07:20:18 --> URI Class Initialized
INFO - 2023-01-12 07:20:18 --> Router Class Initialized
INFO - 2023-01-12 07:20:18 --> Output Class Initialized
INFO - 2023-01-12 07:20:18 --> Security Class Initialized
DEBUG - 2023-01-12 07:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:20:18 --> Input Class Initialized
INFO - 2023-01-12 07:20:18 --> Language Class Initialized
INFO - 2023-01-12 07:20:18 --> Loader Class Initialized
INFO - 2023-01-12 07:20:18 --> Controller Class Initialized
DEBUG - 2023-01-12 07:20:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:20:18 --> Database Driver Class Initialized
INFO - 2023-01-12 07:20:18 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:20:18 --> Database Driver Class Initialized
INFO - 2023-01-12 07:20:18 --> Model "Login_model" initialized
INFO - 2023-01-12 07:20:18 --> Final output sent to browser
DEBUG - 2023-01-12 07:20:18 --> Total execution time: 0.1518
INFO - 2023-01-12 07:20:21 --> Config Class Initialized
INFO - 2023-01-12 07:20:21 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:20:21 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:20:21 --> Utf8 Class Initialized
INFO - 2023-01-12 07:20:21 --> URI Class Initialized
INFO - 2023-01-12 07:20:21 --> Router Class Initialized
INFO - 2023-01-12 07:20:21 --> Output Class Initialized
INFO - 2023-01-12 07:20:21 --> Security Class Initialized
DEBUG - 2023-01-12 07:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:20:21 --> Input Class Initialized
INFO - 2023-01-12 07:20:21 --> Language Class Initialized
INFO - 2023-01-12 07:20:21 --> Loader Class Initialized
INFO - 2023-01-12 07:20:21 --> Controller Class Initialized
DEBUG - 2023-01-12 07:20:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:20:21 --> Database Driver Class Initialized
INFO - 2023-01-12 07:20:21 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:20:21 --> Database Driver Class Initialized
INFO - 2023-01-12 07:20:21 --> Model "Login_model" initialized
INFO - 2023-01-12 07:20:21 --> Final output sent to browser
DEBUG - 2023-01-12 07:20:21 --> Total execution time: 0.0827
INFO - 2023-01-12 07:20:21 --> Config Class Initialized
INFO - 2023-01-12 07:20:21 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:20:21 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:20:21 --> Utf8 Class Initialized
INFO - 2023-01-12 07:20:21 --> URI Class Initialized
INFO - 2023-01-12 07:20:21 --> Router Class Initialized
INFO - 2023-01-12 07:20:21 --> Output Class Initialized
INFO - 2023-01-12 07:20:21 --> Security Class Initialized
DEBUG - 2023-01-12 07:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:20:21 --> Input Class Initialized
INFO - 2023-01-12 07:20:21 --> Language Class Initialized
INFO - 2023-01-12 07:20:21 --> Loader Class Initialized
INFO - 2023-01-12 07:20:21 --> Controller Class Initialized
DEBUG - 2023-01-12 07:20:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:20:21 --> Database Driver Class Initialized
INFO - 2023-01-12 07:20:21 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:20:21 --> Database Driver Class Initialized
INFO - 2023-01-12 07:20:21 --> Model "Login_model" initialized
INFO - 2023-01-12 07:20:21 --> Final output sent to browser
DEBUG - 2023-01-12 07:20:21 --> Total execution time: 0.0382
INFO - 2023-01-12 07:21:53 --> Config Class Initialized
INFO - 2023-01-12 07:21:53 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:21:53 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:21:53 --> Utf8 Class Initialized
INFO - 2023-01-12 07:21:53 --> URI Class Initialized
INFO - 2023-01-12 07:21:53 --> Router Class Initialized
INFO - 2023-01-12 07:21:53 --> Output Class Initialized
INFO - 2023-01-12 07:21:53 --> Security Class Initialized
DEBUG - 2023-01-12 07:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:21:53 --> Input Class Initialized
INFO - 2023-01-12 07:21:53 --> Language Class Initialized
INFO - 2023-01-12 07:21:53 --> Loader Class Initialized
INFO - 2023-01-12 07:21:53 --> Controller Class Initialized
DEBUG - 2023-01-12 07:21:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:21:53 --> Final output sent to browser
DEBUG - 2023-01-12 07:21:53 --> Total execution time: 0.0075
INFO - 2023-01-12 07:21:53 --> Config Class Initialized
INFO - 2023-01-12 07:21:53 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:21:53 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:21:53 --> Utf8 Class Initialized
INFO - 2023-01-12 07:21:53 --> URI Class Initialized
INFO - 2023-01-12 07:21:53 --> Router Class Initialized
INFO - 2023-01-12 07:21:53 --> Output Class Initialized
INFO - 2023-01-12 07:21:53 --> Security Class Initialized
DEBUG - 2023-01-12 07:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:21:53 --> Input Class Initialized
INFO - 2023-01-12 07:21:53 --> Language Class Initialized
INFO - 2023-01-12 07:21:53 --> Loader Class Initialized
INFO - 2023-01-12 07:21:53 --> Controller Class Initialized
DEBUG - 2023-01-12 07:21:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:21:53 --> Database Driver Class Initialized
INFO - 2023-01-12 07:21:53 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:21:53 --> Model "Node_model" initialized
INFO - 2023-01-12 07:21:53 --> Model "Grafana_model" initialized
INFO - 2023-01-12 07:21:53 --> Final output sent to browser
DEBUG - 2023-01-12 07:21:53 --> Total execution time: 0.0562
INFO - 2023-01-12 07:22:03 --> Config Class Initialized
INFO - 2023-01-12 07:22:03 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:22:03 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:22:03 --> Utf8 Class Initialized
INFO - 2023-01-12 07:22:03 --> URI Class Initialized
INFO - 2023-01-12 07:22:03 --> Router Class Initialized
INFO - 2023-01-12 07:22:03 --> Output Class Initialized
INFO - 2023-01-12 07:22:03 --> Security Class Initialized
DEBUG - 2023-01-12 07:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:22:03 --> Input Class Initialized
INFO - 2023-01-12 07:22:03 --> Language Class Initialized
INFO - 2023-01-12 07:22:03 --> Loader Class Initialized
INFO - 2023-01-12 07:22:03 --> Controller Class Initialized
DEBUG - 2023-01-12 07:22:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:22:03 --> Final output sent to browser
DEBUG - 2023-01-12 07:22:03 --> Total execution time: 0.0041
INFO - 2023-01-12 07:22:03 --> Config Class Initialized
INFO - 2023-01-12 07:22:03 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:22:03 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:22:03 --> Utf8 Class Initialized
INFO - 2023-01-12 07:22:03 --> URI Class Initialized
INFO - 2023-01-12 07:22:03 --> Router Class Initialized
INFO - 2023-01-12 07:22:03 --> Output Class Initialized
INFO - 2023-01-12 07:22:03 --> Security Class Initialized
DEBUG - 2023-01-12 07:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:22:03 --> Input Class Initialized
INFO - 2023-01-12 07:22:03 --> Language Class Initialized
INFO - 2023-01-12 07:22:03 --> Loader Class Initialized
INFO - 2023-01-12 07:22:03 --> Controller Class Initialized
DEBUG - 2023-01-12 07:22:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:22:03 --> Database Driver Class Initialized
INFO - 2023-01-12 07:22:03 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:22:03 --> Model "Node_model" initialized
INFO - 2023-01-12 07:22:03 --> Model "Grafana_model" initialized
INFO - 2023-01-12 07:22:03 --> Final output sent to browser
DEBUG - 2023-01-12 07:22:03 --> Total execution time: 0.0520
INFO - 2023-01-12 07:22:04 --> Config Class Initialized
INFO - 2023-01-12 07:22:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:22:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:22:04 --> Utf8 Class Initialized
INFO - 2023-01-12 07:22:04 --> URI Class Initialized
INFO - 2023-01-12 07:22:04 --> Router Class Initialized
INFO - 2023-01-12 07:22:04 --> Output Class Initialized
INFO - 2023-01-12 07:22:04 --> Security Class Initialized
DEBUG - 2023-01-12 07:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:22:04 --> Input Class Initialized
INFO - 2023-01-12 07:22:04 --> Language Class Initialized
INFO - 2023-01-12 07:22:04 --> Loader Class Initialized
INFO - 2023-01-12 07:22:04 --> Controller Class Initialized
DEBUG - 2023-01-12 07:22:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:22:04 --> Final output sent to browser
DEBUG - 2023-01-12 07:22:04 --> Total execution time: 0.0039
INFO - 2023-01-12 07:22:04 --> Config Class Initialized
INFO - 2023-01-12 07:22:04 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:22:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:22:04 --> Utf8 Class Initialized
INFO - 2023-01-12 07:22:04 --> URI Class Initialized
INFO - 2023-01-12 07:22:04 --> Router Class Initialized
INFO - 2023-01-12 07:22:04 --> Output Class Initialized
INFO - 2023-01-12 07:22:04 --> Security Class Initialized
DEBUG - 2023-01-12 07:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:22:04 --> Input Class Initialized
INFO - 2023-01-12 07:22:04 --> Language Class Initialized
INFO - 2023-01-12 07:22:04 --> Loader Class Initialized
INFO - 2023-01-12 07:22:04 --> Controller Class Initialized
DEBUG - 2023-01-12 07:22:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:22:04 --> Database Driver Class Initialized
INFO - 2023-01-12 07:22:04 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:22:04 --> Model "Node_model" initialized
INFO - 2023-01-12 07:22:04 --> Model "Grafana_model" initialized
INFO - 2023-01-12 07:22:04 --> Final output sent to browser
DEBUG - 2023-01-12 07:22:04 --> Total execution time: 0.0511
INFO - 2023-01-12 07:22:05 --> Config Class Initialized
INFO - 2023-01-12 07:22:05 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:22:05 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:22:05 --> Utf8 Class Initialized
INFO - 2023-01-12 07:22:05 --> URI Class Initialized
INFO - 2023-01-12 07:22:05 --> Router Class Initialized
INFO - 2023-01-12 07:22:05 --> Output Class Initialized
INFO - 2023-01-12 07:22:05 --> Security Class Initialized
DEBUG - 2023-01-12 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:22:05 --> Input Class Initialized
INFO - 2023-01-12 07:22:05 --> Language Class Initialized
INFO - 2023-01-12 07:22:05 --> Loader Class Initialized
INFO - 2023-01-12 07:22:05 --> Controller Class Initialized
DEBUG - 2023-01-12 07:22:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:22:05 --> Final output sent to browser
DEBUG - 2023-01-12 07:22:05 --> Total execution time: 0.0047
INFO - 2023-01-12 07:22:05 --> Config Class Initialized
INFO - 2023-01-12 07:22:05 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:22:05 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:22:05 --> Utf8 Class Initialized
INFO - 2023-01-12 07:22:05 --> URI Class Initialized
INFO - 2023-01-12 07:22:05 --> Router Class Initialized
INFO - 2023-01-12 07:22:05 --> Output Class Initialized
INFO - 2023-01-12 07:22:05 --> Security Class Initialized
DEBUG - 2023-01-12 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:22:05 --> Input Class Initialized
INFO - 2023-01-12 07:22:05 --> Language Class Initialized
INFO - 2023-01-12 07:22:05 --> Loader Class Initialized
INFO - 2023-01-12 07:22:05 --> Controller Class Initialized
DEBUG - 2023-01-12 07:22:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:22:05 --> Database Driver Class Initialized
INFO - 2023-01-12 07:22:05 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:22:05 --> Model "Node_model" initialized
INFO - 2023-01-12 07:22:05 --> Model "Grafana_model" initialized
INFO - 2023-01-12 07:22:05 --> Final output sent to browser
DEBUG - 2023-01-12 07:22:05 --> Total execution time: 0.0553
INFO - 2023-01-12 07:22:29 --> Config Class Initialized
INFO - 2023-01-12 07:22:29 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:22:29 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:22:29 --> Utf8 Class Initialized
INFO - 2023-01-12 07:22:29 --> URI Class Initialized
INFO - 2023-01-12 07:22:29 --> Router Class Initialized
INFO - 2023-01-12 07:22:29 --> Output Class Initialized
INFO - 2023-01-12 07:22:29 --> Security Class Initialized
DEBUG - 2023-01-12 07:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:22:29 --> Input Class Initialized
INFO - 2023-01-12 07:22:29 --> Language Class Initialized
INFO - 2023-01-12 07:22:29 --> Loader Class Initialized
INFO - 2023-01-12 07:22:29 --> Controller Class Initialized
DEBUG - 2023-01-12 07:22:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:22:29 --> Final output sent to browser
DEBUG - 2023-01-12 07:22:29 --> Total execution time: 0.0019
INFO - 2023-01-12 07:22:29 --> Config Class Initialized
INFO - 2023-01-12 07:22:29 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:22:29 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:22:29 --> Utf8 Class Initialized
INFO - 2023-01-12 07:22:29 --> URI Class Initialized
INFO - 2023-01-12 07:22:29 --> Router Class Initialized
INFO - 2023-01-12 07:22:29 --> Output Class Initialized
INFO - 2023-01-12 07:22:29 --> Security Class Initialized
DEBUG - 2023-01-12 07:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:22:29 --> Input Class Initialized
INFO - 2023-01-12 07:22:29 --> Language Class Initialized
INFO - 2023-01-12 07:22:29 --> Loader Class Initialized
INFO - 2023-01-12 07:22:29 --> Controller Class Initialized
DEBUG - 2023-01-12 07:22:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:22:29 --> Database Driver Class Initialized
INFO - 2023-01-12 07:22:29 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:22:29 --> Model "Node_model" initialized
INFO - 2023-01-12 07:22:29 --> Model "Grafana_model" initialized
INFO - 2023-01-12 07:22:29 --> Final output sent to browser
DEBUG - 2023-01-12 07:22:29 --> Total execution time: 0.0531
INFO - 2023-01-12 07:29:43 --> Config Class Initialized
INFO - 2023-01-12 07:29:43 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:29:43 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:29:43 --> Utf8 Class Initialized
INFO - 2023-01-12 07:29:43 --> URI Class Initialized
INFO - 2023-01-12 07:29:43 --> Router Class Initialized
INFO - 2023-01-12 07:29:43 --> Output Class Initialized
INFO - 2023-01-12 07:29:43 --> Security Class Initialized
DEBUG - 2023-01-12 07:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:29:43 --> Input Class Initialized
INFO - 2023-01-12 07:29:43 --> Language Class Initialized
INFO - 2023-01-12 07:29:43 --> Loader Class Initialized
INFO - 2023-01-12 07:29:43 --> Controller Class Initialized
DEBUG - 2023-01-12 07:29:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:29:43 --> Final output sent to browser
DEBUG - 2023-01-12 07:29:43 --> Total execution time: 0.0128
INFO - 2023-01-12 07:29:43 --> Config Class Initialized
INFO - 2023-01-12 07:29:43 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:29:43 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:29:43 --> Utf8 Class Initialized
INFO - 2023-01-12 07:29:43 --> URI Class Initialized
INFO - 2023-01-12 07:29:43 --> Router Class Initialized
INFO - 2023-01-12 07:29:43 --> Output Class Initialized
INFO - 2023-01-12 07:29:43 --> Security Class Initialized
DEBUG - 2023-01-12 07:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:29:43 --> Input Class Initialized
INFO - 2023-01-12 07:29:43 --> Language Class Initialized
INFO - 2023-01-12 07:29:43 --> Loader Class Initialized
INFO - 2023-01-12 07:29:43 --> Controller Class Initialized
DEBUG - 2023-01-12 07:29:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:29:43 --> Database Driver Class Initialized
INFO - 2023-01-12 07:29:43 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:29:43 --> Model "Node_model" initialized
INFO - 2023-01-12 07:29:43 --> Model "Grafana_model" initialized
INFO - 2023-01-12 07:29:43 --> Final output sent to browser
DEBUG - 2023-01-12 07:29:43 --> Total execution time: 0.0557
INFO - 2023-01-12 07:44:33 --> Config Class Initialized
INFO - 2023-01-12 07:44:33 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:33 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:33 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:33 --> URI Class Initialized
INFO - 2023-01-12 07:44:33 --> Router Class Initialized
INFO - 2023-01-12 07:44:33 --> Output Class Initialized
INFO - 2023-01-12 07:44:33 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:33 --> Input Class Initialized
INFO - 2023-01-12 07:44:33 --> Language Class Initialized
INFO - 2023-01-12 07:44:33 --> Loader Class Initialized
INFO - 2023-01-12 07:44:33 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:33 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:33 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:33 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:33 --> Total execution time: 0.0507
INFO - 2023-01-12 07:44:33 --> Config Class Initialized
INFO - 2023-01-12 07:44:34 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:34 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:34 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:34 --> URI Class Initialized
INFO - 2023-01-12 07:44:34 --> Router Class Initialized
INFO - 2023-01-12 07:44:34 --> Output Class Initialized
INFO - 2023-01-12 07:44:34 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:34 --> Input Class Initialized
INFO - 2023-01-12 07:44:34 --> Language Class Initialized
INFO - 2023-01-12 07:44:34 --> Loader Class Initialized
INFO - 2023-01-12 07:44:34 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:34 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:34 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:34 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:34 --> Total execution time: 0.0881
INFO - 2023-01-12 07:44:38 --> Config Class Initialized
INFO - 2023-01-12 07:44:38 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:38 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:38 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:38 --> URI Class Initialized
INFO - 2023-01-12 07:44:38 --> Router Class Initialized
INFO - 2023-01-12 07:44:38 --> Output Class Initialized
INFO - 2023-01-12 07:44:38 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:38 --> Input Class Initialized
INFO - 2023-01-12 07:44:38 --> Language Class Initialized
INFO - 2023-01-12 07:44:38 --> Loader Class Initialized
INFO - 2023-01-12 07:44:38 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:38 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:38 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:38 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:38 --> Model "Login_model" initialized
INFO - 2023-01-12 07:44:38 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:38 --> Total execution time: 0.1678
INFO - 2023-01-12 07:44:38 --> Config Class Initialized
INFO - 2023-01-12 07:44:38 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:38 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:38 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:38 --> URI Class Initialized
INFO - 2023-01-12 07:44:38 --> Router Class Initialized
INFO - 2023-01-12 07:44:38 --> Output Class Initialized
INFO - 2023-01-12 07:44:38 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:38 --> Input Class Initialized
INFO - 2023-01-12 07:44:38 --> Language Class Initialized
INFO - 2023-01-12 07:44:38 --> Loader Class Initialized
INFO - 2023-01-12 07:44:38 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:38 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:38 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:38 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:38 --> Model "Login_model" initialized
INFO - 2023-01-12 07:44:38 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:38 --> Total execution time: 0.1178
INFO - 2023-01-12 07:44:42 --> Config Class Initialized
INFO - 2023-01-12 07:44:42 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:42 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:42 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:42 --> URI Class Initialized
INFO - 2023-01-12 07:44:42 --> Router Class Initialized
INFO - 2023-01-12 07:44:42 --> Output Class Initialized
INFO - 2023-01-12 07:44:42 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:42 --> Input Class Initialized
INFO - 2023-01-12 07:44:42 --> Language Class Initialized
INFO - 2023-01-12 07:44:42 --> Loader Class Initialized
INFO - 2023-01-12 07:44:42 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:42 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:42 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:43 --> Config Class Initialized
INFO - 2023-01-12 07:44:43 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:43 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:43 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:43 --> URI Class Initialized
INFO - 2023-01-12 07:44:43 --> Router Class Initialized
INFO - 2023-01-12 07:44:43 --> Output Class Initialized
INFO - 2023-01-12 07:44:43 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:43 --> Input Class Initialized
INFO - 2023-01-12 07:44:43 --> Language Class Initialized
INFO - 2023-01-12 07:44:43 --> Loader Class Initialized
INFO - 2023-01-12 07:44:43 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:43 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:43 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:50 --> Config Class Initialized
INFO - 2023-01-12 07:44:50 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:50 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:50 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:50 --> URI Class Initialized
INFO - 2023-01-12 07:44:50 --> Router Class Initialized
INFO - 2023-01-12 07:44:50 --> Output Class Initialized
INFO - 2023-01-12 07:44:50 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:50 --> Input Class Initialized
INFO - 2023-01-12 07:44:50 --> Language Class Initialized
INFO - 2023-01-12 07:44:50 --> Loader Class Initialized
INFO - 2023-01-12 07:44:50 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-01-12 07:44:50 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 220
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-01-12 07:44:50 --> Config Class Initialized
INFO - 2023-01-12 07:44:50 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:50 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:50 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:50 --> URI Class Initialized
INFO - 2023-01-12 07:44:50 --> Router Class Initialized
INFO - 2023-01-12 07:44:50 --> Output Class Initialized
INFO - 2023-01-12 07:44:50 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:50 --> Input Class Initialized
INFO - 2023-01-12 07:44:50 --> Language Class Initialized
INFO - 2023-01-12 07:44:50 --> Loader Class Initialized
INFO - 2023-01-12 07:44:50 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:50 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:50 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:50 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:50 --> Total execution time: 0.0246
INFO - 2023-01-12 07:44:51 --> Config Class Initialized
INFO - 2023-01-12 07:44:51 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:51 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:51 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:51 --> URI Class Initialized
INFO - 2023-01-12 07:44:51 --> Router Class Initialized
INFO - 2023-01-12 07:44:51 --> Output Class Initialized
INFO - 2023-01-12 07:44:51 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:51 --> Input Class Initialized
INFO - 2023-01-12 07:44:51 --> Language Class Initialized
INFO - 2023-01-12 07:44:51 --> Loader Class Initialized
INFO - 2023-01-12 07:44:51 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:51 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:51 --> Total execution time: 0.0055
INFO - 2023-01-12 07:44:51 --> Config Class Initialized
INFO - 2023-01-12 07:44:51 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:51 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:51 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:51 --> URI Class Initialized
INFO - 2023-01-12 07:44:51 --> Router Class Initialized
INFO - 2023-01-12 07:44:51 --> Output Class Initialized
INFO - 2023-01-12 07:44:51 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:51 --> Input Class Initialized
INFO - 2023-01-12 07:44:51 --> Language Class Initialized
INFO - 2023-01-12 07:44:51 --> Loader Class Initialized
INFO - 2023-01-12 07:44:51 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:51 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:51 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:51 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:51 --> Total execution time: 0.0177
INFO - 2023-01-12 07:44:52 --> Config Class Initialized
INFO - 2023-01-12 07:44:52 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:52 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:52 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:52 --> URI Class Initialized
INFO - 2023-01-12 07:44:52 --> Router Class Initialized
INFO - 2023-01-12 07:44:52 --> Output Class Initialized
INFO - 2023-01-12 07:44:52 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:52 --> Input Class Initialized
INFO - 2023-01-12 07:44:52 --> Language Class Initialized
INFO - 2023-01-12 07:44:52 --> Loader Class Initialized
INFO - 2023-01-12 07:44:52 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:52 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:52 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:52 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:52 --> Total execution time: 0.0207
INFO - 2023-01-12 07:44:53 --> Config Class Initialized
INFO - 2023-01-12 07:44:53 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:53 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:53 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:53 --> URI Class Initialized
INFO - 2023-01-12 07:44:53 --> Router Class Initialized
INFO - 2023-01-12 07:44:53 --> Output Class Initialized
INFO - 2023-01-12 07:44:53 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:53 --> Input Class Initialized
INFO - 2023-01-12 07:44:53 --> Language Class Initialized
INFO - 2023-01-12 07:44:53 --> Loader Class Initialized
INFO - 2023-01-12 07:44:53 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:53 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:53 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:53 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:53 --> Total execution time: 0.0197
INFO - 2023-01-12 07:44:54 --> Config Class Initialized
INFO - 2023-01-12 07:44:54 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:54 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:54 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:54 --> URI Class Initialized
INFO - 2023-01-12 07:44:54 --> Router Class Initialized
INFO - 2023-01-12 07:44:54 --> Output Class Initialized
INFO - 2023-01-12 07:44:54 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:54 --> Input Class Initialized
INFO - 2023-01-12 07:44:54 --> Language Class Initialized
INFO - 2023-01-12 07:44:54 --> Loader Class Initialized
INFO - 2023-01-12 07:44:54 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:54 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:54 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:54 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:54 --> Total execution time: 0.0182
INFO - 2023-01-12 07:44:55 --> Config Class Initialized
INFO - 2023-01-12 07:44:55 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:55 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:55 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:55 --> URI Class Initialized
INFO - 2023-01-12 07:44:55 --> Router Class Initialized
INFO - 2023-01-12 07:44:55 --> Output Class Initialized
INFO - 2023-01-12 07:44:55 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:55 --> Input Class Initialized
INFO - 2023-01-12 07:44:55 --> Language Class Initialized
INFO - 2023-01-12 07:44:55 --> Loader Class Initialized
INFO - 2023-01-12 07:44:55 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:55 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:55 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:55 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:55 --> Total execution time: 0.0233
INFO - 2023-01-12 07:44:56 --> Config Class Initialized
INFO - 2023-01-12 07:44:56 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:56 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:56 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:56 --> URI Class Initialized
INFO - 2023-01-12 07:44:56 --> Router Class Initialized
INFO - 2023-01-12 07:44:56 --> Output Class Initialized
INFO - 2023-01-12 07:44:56 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:56 --> Input Class Initialized
INFO - 2023-01-12 07:44:56 --> Language Class Initialized
INFO - 2023-01-12 07:44:56 --> Loader Class Initialized
INFO - 2023-01-12 07:44:56 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:56 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:56 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:56 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:56 --> Total execution time: 0.0158
INFO - 2023-01-12 07:44:57 --> Config Class Initialized
INFO - 2023-01-12 07:44:57 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:57 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:57 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:57 --> URI Class Initialized
INFO - 2023-01-12 07:44:57 --> Router Class Initialized
INFO - 2023-01-12 07:44:57 --> Output Class Initialized
INFO - 2023-01-12 07:44:57 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:57 --> Input Class Initialized
INFO - 2023-01-12 07:44:57 --> Language Class Initialized
INFO - 2023-01-12 07:44:57 --> Loader Class Initialized
INFO - 2023-01-12 07:44:57 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:57 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:57 --> Total execution time: 0.0047
INFO - 2023-01-12 07:44:57 --> Config Class Initialized
INFO - 2023-01-12 07:44:57 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:57 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:57 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:57 --> URI Class Initialized
INFO - 2023-01-12 07:44:57 --> Router Class Initialized
INFO - 2023-01-12 07:44:57 --> Output Class Initialized
INFO - 2023-01-12 07:44:57 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:57 --> Input Class Initialized
INFO - 2023-01-12 07:44:57 --> Language Class Initialized
INFO - 2023-01-12 07:44:57 --> Loader Class Initialized
INFO - 2023-01-12 07:44:57 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:57 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:57 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:57 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:57 --> Total execution time: 0.0158
INFO - 2023-01-12 07:44:58 --> Config Class Initialized
INFO - 2023-01-12 07:44:58 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:58 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:58 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:58 --> URI Class Initialized
INFO - 2023-01-12 07:44:58 --> Router Class Initialized
INFO - 2023-01-12 07:44:58 --> Output Class Initialized
INFO - 2023-01-12 07:44:58 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:58 --> Input Class Initialized
INFO - 2023-01-12 07:44:58 --> Language Class Initialized
INFO - 2023-01-12 07:44:58 --> Loader Class Initialized
INFO - 2023-01-12 07:44:58 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:58 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:58 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:58 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:58 --> Total execution time: 0.0163
INFO - 2023-01-12 07:44:59 --> Config Class Initialized
INFO - 2023-01-12 07:44:59 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:44:59 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:44:59 --> Utf8 Class Initialized
INFO - 2023-01-12 07:44:59 --> URI Class Initialized
INFO - 2023-01-12 07:44:59 --> Router Class Initialized
INFO - 2023-01-12 07:44:59 --> Output Class Initialized
INFO - 2023-01-12 07:44:59 --> Security Class Initialized
DEBUG - 2023-01-12 07:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:44:59 --> Input Class Initialized
INFO - 2023-01-12 07:44:59 --> Language Class Initialized
INFO - 2023-01-12 07:44:59 --> Loader Class Initialized
INFO - 2023-01-12 07:44:59 --> Controller Class Initialized
DEBUG - 2023-01-12 07:44:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:44:59 --> Database Driver Class Initialized
INFO - 2023-01-12 07:44:59 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:44:59 --> Final output sent to browser
DEBUG - 2023-01-12 07:44:59 --> Total execution time: 0.0166
INFO - 2023-01-12 07:45:00 --> Config Class Initialized
INFO - 2023-01-12 07:45:00 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:00 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:00 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:00 --> URI Class Initialized
INFO - 2023-01-12 07:45:00 --> Router Class Initialized
INFO - 2023-01-12 07:45:00 --> Output Class Initialized
INFO - 2023-01-12 07:45:00 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:00 --> Input Class Initialized
INFO - 2023-01-12 07:45:00 --> Language Class Initialized
INFO - 2023-01-12 07:45:00 --> Loader Class Initialized
INFO - 2023-01-12 07:45:00 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:00 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:00 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:00 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:00 --> Total execution time: 0.0167
INFO - 2023-01-12 07:45:01 --> Config Class Initialized
INFO - 2023-01-12 07:45:01 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:01 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:01 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:01 --> URI Class Initialized
INFO - 2023-01-12 07:45:01 --> Router Class Initialized
INFO - 2023-01-12 07:45:01 --> Output Class Initialized
INFO - 2023-01-12 07:45:01 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:01 --> Input Class Initialized
INFO - 2023-01-12 07:45:01 --> Language Class Initialized
INFO - 2023-01-12 07:45:01 --> Loader Class Initialized
INFO - 2023-01-12 07:45:01 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:01 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:01 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:01 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:01 --> Total execution time: 0.0194
INFO - 2023-01-12 07:45:03 --> Config Class Initialized
INFO - 2023-01-12 07:45:03 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:03 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:03 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:03 --> URI Class Initialized
INFO - 2023-01-12 07:45:03 --> Router Class Initialized
INFO - 2023-01-12 07:45:03 --> Output Class Initialized
INFO - 2023-01-12 07:45:03 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:03 --> Input Class Initialized
INFO - 2023-01-12 07:45:03 --> Language Class Initialized
INFO - 2023-01-12 07:45:03 --> Loader Class Initialized
INFO - 2023-01-12 07:45:03 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:03 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:03 --> Total execution time: 0.0067
INFO - 2023-01-12 07:45:03 --> Config Class Initialized
INFO - 2023-01-12 07:45:03 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:03 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:03 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:03 --> URI Class Initialized
INFO - 2023-01-12 07:45:03 --> Router Class Initialized
INFO - 2023-01-12 07:45:03 --> Output Class Initialized
INFO - 2023-01-12 07:45:03 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:03 --> Input Class Initialized
INFO - 2023-01-12 07:45:03 --> Language Class Initialized
INFO - 2023-01-12 07:45:03 --> Loader Class Initialized
INFO - 2023-01-12 07:45:03 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:03 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:03 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:03 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:03 --> Total execution time: 0.0807
INFO - 2023-01-12 07:45:04 --> Config Class Initialized
INFO - 2023-01-12 07:45:04 --> Hooks Class Initialized
INFO - 2023-01-12 07:45:04 --> Config Class Initialized
DEBUG - 2023-01-12 07:45:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:04 --> Hooks Class Initialized
INFO - 2023-01-12 07:45:04 --> Utf8 Class Initialized
DEBUG - 2023-01-12 07:45:04 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:04 --> URI Class Initialized
INFO - 2023-01-12 07:45:04 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:04 --> URI Class Initialized
INFO - 2023-01-12 07:45:04 --> Router Class Initialized
INFO - 2023-01-12 07:45:04 --> Router Class Initialized
INFO - 2023-01-12 07:45:04 --> Output Class Initialized
INFO - 2023-01-12 07:45:04 --> Output Class Initialized
INFO - 2023-01-12 07:45:04 --> Security Class Initialized
INFO - 2023-01-12 07:45:04 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 07:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:04 --> Input Class Initialized
INFO - 2023-01-12 07:45:04 --> Input Class Initialized
INFO - 2023-01-12 07:45:04 --> Language Class Initialized
INFO - 2023-01-12 07:45:04 --> Language Class Initialized
INFO - 2023-01-12 07:45:04 --> Loader Class Initialized
INFO - 2023-01-12 07:45:04 --> Loader Class Initialized
INFO - 2023-01-12 07:45:04 --> Controller Class Initialized
INFO - 2023-01-12 07:45:04 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-12 07:45:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:04 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:04 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:04 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:04 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:04 --> Final output sent to browser
INFO - 2023-01-12 07:45:04 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:04 --> Total execution time: 0.0202
DEBUG - 2023-01-12 07:45:04 --> Total execution time: 0.0186
INFO - 2023-01-12 07:45:05 --> Config Class Initialized
INFO - 2023-01-12 07:45:05 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:05 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:05 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:05 --> URI Class Initialized
INFO - 2023-01-12 07:45:05 --> Router Class Initialized
INFO - 2023-01-12 07:45:05 --> Output Class Initialized
INFO - 2023-01-12 07:45:05 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:05 --> Input Class Initialized
INFO - 2023-01-12 07:45:05 --> Language Class Initialized
INFO - 2023-01-12 07:45:05 --> Loader Class Initialized
INFO - 2023-01-12 07:45:05 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:05 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:05 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:05 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:05 --> Total execution time: 0.0274
INFO - 2023-01-12 07:45:06 --> Config Class Initialized
INFO - 2023-01-12 07:45:06 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:06 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:06 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:06 --> URI Class Initialized
INFO - 2023-01-12 07:45:06 --> Router Class Initialized
INFO - 2023-01-12 07:45:06 --> Output Class Initialized
INFO - 2023-01-12 07:45:06 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:06 --> Input Class Initialized
INFO - 2023-01-12 07:45:06 --> Language Class Initialized
INFO - 2023-01-12 07:45:06 --> Loader Class Initialized
INFO - 2023-01-12 07:45:06 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:06 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:06 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:06 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:06 --> Total execution time: 0.0213
INFO - 2023-01-12 07:45:08 --> Config Class Initialized
INFO - 2023-01-12 07:45:08 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:08 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:08 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:08 --> URI Class Initialized
INFO - 2023-01-12 07:45:08 --> Router Class Initialized
INFO - 2023-01-12 07:45:08 --> Output Class Initialized
INFO - 2023-01-12 07:45:08 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:08 --> Input Class Initialized
INFO - 2023-01-12 07:45:08 --> Language Class Initialized
INFO - 2023-01-12 07:45:08 --> Loader Class Initialized
INFO - 2023-01-12 07:45:08 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:08 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:08 --> Total execution time: 0.0086
INFO - 2023-01-12 07:45:08 --> Config Class Initialized
INFO - 2023-01-12 07:45:08 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:08 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:08 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:08 --> URI Class Initialized
INFO - 2023-01-12 07:45:08 --> Router Class Initialized
INFO - 2023-01-12 07:45:08 --> Output Class Initialized
INFO - 2023-01-12 07:45:08 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:08 --> Input Class Initialized
INFO - 2023-01-12 07:45:08 --> Language Class Initialized
INFO - 2023-01-12 07:45:08 --> Loader Class Initialized
INFO - 2023-01-12 07:45:08 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:08 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:08 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:08 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:08 --> Total execution time: 0.0217
INFO - 2023-01-12 07:45:09 --> Config Class Initialized
INFO - 2023-01-12 07:45:09 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:09 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:09 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:09 --> URI Class Initialized
INFO - 2023-01-12 07:45:09 --> Router Class Initialized
INFO - 2023-01-12 07:45:09 --> Output Class Initialized
INFO - 2023-01-12 07:45:09 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:09 --> Input Class Initialized
INFO - 2023-01-12 07:45:09 --> Language Class Initialized
INFO - 2023-01-12 07:45:09 --> Loader Class Initialized
INFO - 2023-01-12 07:45:09 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:09 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:09 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:09 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:09 --> Total execution time: 0.0203
INFO - 2023-01-12 07:45:10 --> Config Class Initialized
INFO - 2023-01-12 07:45:10 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:10 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:10 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:10 --> URI Class Initialized
INFO - 2023-01-12 07:45:10 --> Router Class Initialized
INFO - 2023-01-12 07:45:10 --> Output Class Initialized
INFO - 2023-01-12 07:45:10 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:10 --> Input Class Initialized
INFO - 2023-01-12 07:45:10 --> Language Class Initialized
INFO - 2023-01-12 07:45:10 --> Loader Class Initialized
INFO - 2023-01-12 07:45:10 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:10 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:10 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:10 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:10 --> Total execution time: 0.0183
INFO - 2023-01-12 07:45:11 --> Config Class Initialized
INFO - 2023-01-12 07:45:11 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:11 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:11 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:11 --> URI Class Initialized
INFO - 2023-01-12 07:45:11 --> Router Class Initialized
INFO - 2023-01-12 07:45:11 --> Output Class Initialized
INFO - 2023-01-12 07:45:11 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:11 --> Input Class Initialized
INFO - 2023-01-12 07:45:11 --> Language Class Initialized
INFO - 2023-01-12 07:45:11 --> Loader Class Initialized
INFO - 2023-01-12 07:45:11 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:11 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:12 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:12 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:12 --> Total execution time: 0.2425
INFO - 2023-01-12 07:45:12 --> Config Class Initialized
INFO - 2023-01-12 07:45:12 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:12 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:12 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:12 --> URI Class Initialized
INFO - 2023-01-12 07:45:12 --> Router Class Initialized
INFO - 2023-01-12 07:45:12 --> Output Class Initialized
INFO - 2023-01-12 07:45:13 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:13 --> Input Class Initialized
INFO - 2023-01-12 07:45:13 --> Language Class Initialized
INFO - 2023-01-12 07:45:13 --> Loader Class Initialized
INFO - 2023-01-12 07:45:13 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:13 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:13 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:13 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:13 --> Total execution time: 0.2240
INFO - 2023-01-12 07:45:13 --> Config Class Initialized
INFO - 2023-01-12 07:45:13 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:13 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:13 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:13 --> URI Class Initialized
INFO - 2023-01-12 07:45:13 --> Router Class Initialized
INFO - 2023-01-12 07:45:13 --> Output Class Initialized
INFO - 2023-01-12 07:45:13 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:13 --> Input Class Initialized
INFO - 2023-01-12 07:45:13 --> Language Class Initialized
INFO - 2023-01-12 07:45:13 --> Loader Class Initialized
INFO - 2023-01-12 07:45:13 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:13 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:13 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:13 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:13 --> Total execution time: 0.0200
INFO - 2023-01-12 07:45:14 --> Config Class Initialized
INFO - 2023-01-12 07:45:14 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:14 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:15 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:15 --> URI Class Initialized
INFO - 2023-01-12 07:45:15 --> Router Class Initialized
INFO - 2023-01-12 07:45:15 --> Output Class Initialized
INFO - 2023-01-12 07:45:15 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:15 --> Input Class Initialized
INFO - 2023-01-12 07:45:15 --> Language Class Initialized
INFO - 2023-01-12 07:45:15 --> Loader Class Initialized
INFO - 2023-01-12 07:45:15 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:15 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:15 --> Total execution time: 0.1248
INFO - 2023-01-12 07:45:15 --> Config Class Initialized
INFO - 2023-01-12 07:45:15 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:15 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:15 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:15 --> URI Class Initialized
INFO - 2023-01-12 07:45:15 --> Router Class Initialized
INFO - 2023-01-12 07:45:15 --> Output Class Initialized
INFO - 2023-01-12 07:45:15 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:15 --> Input Class Initialized
INFO - 2023-01-12 07:45:15 --> Language Class Initialized
INFO - 2023-01-12 07:45:15 --> Loader Class Initialized
INFO - 2023-01-12 07:45:15 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:15 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:15 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:15 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:15 --> Total execution time: 0.0152
INFO - 2023-01-12 07:45:15 --> Config Class Initialized
INFO - 2023-01-12 07:45:15 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:15 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:15 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:15 --> URI Class Initialized
INFO - 2023-01-12 07:45:15 --> Router Class Initialized
INFO - 2023-01-12 07:45:15 --> Output Class Initialized
INFO - 2023-01-12 07:45:15 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:15 --> Input Class Initialized
INFO - 2023-01-12 07:45:15 --> Language Class Initialized
INFO - 2023-01-12 07:45:15 --> Loader Class Initialized
INFO - 2023-01-12 07:45:15 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:15 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:15 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:15 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:15 --> Total execution time: 0.0170
INFO - 2023-01-12 07:45:16 --> Config Class Initialized
INFO - 2023-01-12 07:45:16 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:16 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:16 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:16 --> URI Class Initialized
INFO - 2023-01-12 07:45:16 --> Router Class Initialized
INFO - 2023-01-12 07:45:16 --> Output Class Initialized
INFO - 2023-01-12 07:45:16 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:16 --> Input Class Initialized
INFO - 2023-01-12 07:45:16 --> Language Class Initialized
INFO - 2023-01-12 07:45:16 --> Loader Class Initialized
INFO - 2023-01-12 07:45:16 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:16 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:16 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:16 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:16 --> Total execution time: 0.0141
INFO - 2023-01-12 07:45:17 --> Config Class Initialized
INFO - 2023-01-12 07:45:17 --> Hooks Class Initialized
INFO - 2023-01-12 07:45:17 --> Config Class Initialized
INFO - 2023-01-12 07:45:17 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 07:45:17 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:17 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:17 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:17 --> URI Class Initialized
INFO - 2023-01-12 07:45:17 --> URI Class Initialized
INFO - 2023-01-12 07:45:17 --> Router Class Initialized
INFO - 2023-01-12 07:45:17 --> Router Class Initialized
INFO - 2023-01-12 07:45:17 --> Output Class Initialized
INFO - 2023-01-12 07:45:17 --> Output Class Initialized
INFO - 2023-01-12 07:45:17 --> Security Class Initialized
INFO - 2023-01-12 07:45:17 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 07:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:17 --> Input Class Initialized
INFO - 2023-01-12 07:45:17 --> Input Class Initialized
INFO - 2023-01-12 07:45:17 --> Language Class Initialized
INFO - 2023-01-12 07:45:17 --> Language Class Initialized
INFO - 2023-01-12 07:45:17 --> Loader Class Initialized
INFO - 2023-01-12 07:45:17 --> Loader Class Initialized
INFO - 2023-01-12 07:45:17 --> Controller Class Initialized
INFO - 2023-01-12 07:45:17 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-12 07:45:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:17 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:17 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:17 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:17 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:17 --> Final output sent to browser
INFO - 2023-01-12 07:45:17 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:17 --> Total execution time: 0.0189
DEBUG - 2023-01-12 07:45:17 --> Total execution time: 0.0192
INFO - 2023-01-12 07:45:23 --> Config Class Initialized
INFO - 2023-01-12 07:45:23 --> Config Class Initialized
INFO - 2023-01-12 07:45:23 --> Hooks Class Initialized
INFO - 2023-01-12 07:45:23 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 07:45:23 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:23 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:23 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:23 --> URI Class Initialized
INFO - 2023-01-12 07:45:23 --> URI Class Initialized
INFO - 2023-01-12 07:45:23 --> Router Class Initialized
INFO - 2023-01-12 07:45:23 --> Router Class Initialized
INFO - 2023-01-12 07:45:23 --> Output Class Initialized
INFO - 2023-01-12 07:45:23 --> Output Class Initialized
INFO - 2023-01-12 07:45:23 --> Security Class Initialized
INFO - 2023-01-12 07:45:23 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 07:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:23 --> Input Class Initialized
INFO - 2023-01-12 07:45:23 --> Input Class Initialized
INFO - 2023-01-12 07:45:23 --> Language Class Initialized
INFO - 2023-01-12 07:45:23 --> Language Class Initialized
INFO - 2023-01-12 07:45:23 --> Loader Class Initialized
INFO - 2023-01-12 07:45:23 --> Loader Class Initialized
INFO - 2023-01-12 07:45:23 --> Controller Class Initialized
INFO - 2023-01-12 07:45:23 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-12 07:45:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:23 --> Final output sent to browser
INFO - 2023-01-12 07:45:23 --> Database Driver Class Initialized
DEBUG - 2023-01-12 07:45:23 --> Total execution time: 0.0063
INFO - 2023-01-12 07:45:23 --> Config Class Initialized
INFO - 2023-01-12 07:45:23 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:23 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:23 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:23 --> URI Class Initialized
INFO - 2023-01-12 07:45:23 --> Router Class Initialized
INFO - 2023-01-12 07:45:23 --> Output Class Initialized
INFO - 2023-01-12 07:45:23 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:23 --> Input Class Initialized
INFO - 2023-01-12 07:45:23 --> Language Class Initialized
INFO - 2023-01-12 07:45:23 --> Loader Class Initialized
INFO - 2023-01-12 07:45:23 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:23 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:23 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:23 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:23 --> Total execution time: 0.0189
INFO - 2023-01-12 07:45:23 --> Config Class Initialized
INFO - 2023-01-12 07:45:23 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:23 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:23 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:23 --> URI Class Initialized
INFO - 2023-01-12 07:45:23 --> Router Class Initialized
INFO - 2023-01-12 07:45:23 --> Output Class Initialized
INFO - 2023-01-12 07:45:23 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:23 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:23 --> Input Class Initialized
INFO - 2023-01-12 07:45:23 --> Language Class Initialized
INFO - 2023-01-12 07:45:23 --> Loader Class Initialized
INFO - 2023-01-12 07:45:23 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:23 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:23 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:23 --> Total execution time: 0.0162
INFO - 2023-01-12 07:45:23 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:23 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:23 --> Total execution time: 0.0523
INFO - 2023-01-12 07:45:24 --> Config Class Initialized
INFO - 2023-01-12 07:45:24 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:24 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:24 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:24 --> URI Class Initialized
INFO - 2023-01-12 07:45:24 --> Router Class Initialized
INFO - 2023-01-12 07:45:24 --> Output Class Initialized
INFO - 2023-01-12 07:45:24 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:24 --> Input Class Initialized
INFO - 2023-01-12 07:45:24 --> Language Class Initialized
INFO - 2023-01-12 07:45:24 --> Loader Class Initialized
INFO - 2023-01-12 07:45:24 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:24 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:24 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:24 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:24 --> Total execution time: 0.0138
INFO - 2023-01-12 07:45:25 --> Config Class Initialized
INFO - 2023-01-12 07:45:25 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:25 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:25 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:25 --> URI Class Initialized
INFO - 2023-01-12 07:45:25 --> Router Class Initialized
INFO - 2023-01-12 07:45:25 --> Output Class Initialized
INFO - 2023-01-12 07:45:25 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:25 --> Input Class Initialized
INFO - 2023-01-12 07:45:25 --> Language Class Initialized
INFO - 2023-01-12 07:45:25 --> Loader Class Initialized
INFO - 2023-01-12 07:45:25 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:25 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:25 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:25 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:25 --> Total execution time: 0.0370
INFO - 2023-01-12 07:45:25 --> Config Class Initialized
INFO - 2023-01-12 07:45:25 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:25 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:25 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:25 --> URI Class Initialized
INFO - 2023-01-12 07:45:25 --> Router Class Initialized
INFO - 2023-01-12 07:45:25 --> Output Class Initialized
INFO - 2023-01-12 07:45:25 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:25 --> Input Class Initialized
INFO - 2023-01-12 07:45:25 --> Language Class Initialized
INFO - 2023-01-12 07:45:25 --> Loader Class Initialized
INFO - 2023-01-12 07:45:25 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:25 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:25 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:26 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:26 --> Total execution time: 0.0665
INFO - 2023-01-12 07:45:28 --> Config Class Initialized
INFO - 2023-01-12 07:45:28 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:28 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:28 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:28 --> URI Class Initialized
INFO - 2023-01-12 07:45:28 --> Router Class Initialized
INFO - 2023-01-12 07:45:28 --> Output Class Initialized
INFO - 2023-01-12 07:45:28 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:28 --> Input Class Initialized
INFO - 2023-01-12 07:45:28 --> Language Class Initialized
INFO - 2023-01-12 07:45:28 --> Loader Class Initialized
INFO - 2023-01-12 07:45:28 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:28 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:28 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:28 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:28 --> Total execution time: 0.0183
INFO - 2023-01-12 07:45:28 --> Config Class Initialized
INFO - 2023-01-12 07:45:28 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:28 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:28 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:28 --> URI Class Initialized
INFO - 2023-01-12 07:45:28 --> Router Class Initialized
INFO - 2023-01-12 07:45:28 --> Output Class Initialized
INFO - 2023-01-12 07:45:28 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:28 --> Input Class Initialized
INFO - 2023-01-12 07:45:28 --> Language Class Initialized
INFO - 2023-01-12 07:45:28 --> Loader Class Initialized
INFO - 2023-01-12 07:45:28 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:28 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:28 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:28 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:28 --> Total execution time: 0.1748
INFO - 2023-01-12 07:45:31 --> Config Class Initialized
INFO - 2023-01-12 07:45:31 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:31 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:31 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:31 --> URI Class Initialized
INFO - 2023-01-12 07:45:31 --> Router Class Initialized
INFO - 2023-01-12 07:45:31 --> Output Class Initialized
INFO - 2023-01-12 07:45:31 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:31 --> Input Class Initialized
INFO - 2023-01-12 07:45:31 --> Language Class Initialized
INFO - 2023-01-12 07:45:31 --> Loader Class Initialized
INFO - 2023-01-12 07:45:31 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:31 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:31 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:31 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:31 --> Total execution time: 0.0357
INFO - 2023-01-12 07:45:31 --> Config Class Initialized
INFO - 2023-01-12 07:45:31 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:31 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:31 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:31 --> URI Class Initialized
INFO - 2023-01-12 07:45:31 --> Router Class Initialized
INFO - 2023-01-12 07:45:31 --> Output Class Initialized
INFO - 2023-01-12 07:45:31 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:31 --> Input Class Initialized
INFO - 2023-01-12 07:45:31 --> Language Class Initialized
INFO - 2023-01-12 07:45:31 --> Loader Class Initialized
INFO - 2023-01-12 07:45:31 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:31 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:31 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:31 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:31 --> Total execution time: 0.0274
INFO - 2023-01-12 07:45:34 --> Config Class Initialized
INFO - 2023-01-12 07:45:34 --> Config Class Initialized
INFO - 2023-01-12 07:45:34 --> Hooks Class Initialized
INFO - 2023-01-12 07:45:34 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:34 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:34 --> Utf8 Class Initialized
DEBUG - 2023-01-12 07:45:34 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:34 --> URI Class Initialized
INFO - 2023-01-12 07:45:34 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:34 --> Router Class Initialized
INFO - 2023-01-12 07:45:34 --> URI Class Initialized
INFO - 2023-01-12 07:45:34 --> Output Class Initialized
INFO - 2023-01-12 07:45:34 --> Router Class Initialized
INFO - 2023-01-12 07:45:34 --> Security Class Initialized
INFO - 2023-01-12 07:45:34 --> Output Class Initialized
INFO - 2023-01-12 07:45:34 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 07:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:34 --> Input Class Initialized
INFO - 2023-01-12 07:45:34 --> Input Class Initialized
INFO - 2023-01-12 07:45:34 --> Language Class Initialized
INFO - 2023-01-12 07:45:34 --> Language Class Initialized
INFO - 2023-01-12 07:45:34 --> Loader Class Initialized
INFO - 2023-01-12 07:45:34 --> Loader Class Initialized
INFO - 2023-01-12 07:45:34 --> Controller Class Initialized
INFO - 2023-01-12 07:45:34 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-12 07:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:34 --> Final output sent to browser
INFO - 2023-01-12 07:45:34 --> Database Driver Class Initialized
DEBUG - 2023-01-12 07:45:34 --> Total execution time: 0.0091
INFO - 2023-01-12 07:45:34 --> Config Class Initialized
INFO - 2023-01-12 07:45:34 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:34 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:34 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:34 --> URI Class Initialized
INFO - 2023-01-12 07:45:34 --> Router Class Initialized
INFO - 2023-01-12 07:45:34 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:34 --> Output Class Initialized
INFO - 2023-01-12 07:45:34 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:34 --> Input Class Initialized
INFO - 2023-01-12 07:45:34 --> Language Class Initialized
INFO - 2023-01-12 07:45:34 --> Loader Class Initialized
INFO - 2023-01-12 07:45:34 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:34 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:34 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:34 --> Total execution time: 0.0217
INFO - 2023-01-12 07:45:34 --> Config Class Initialized
INFO - 2023-01-12 07:45:34 --> Hooks Class Initialized
DEBUG - 2023-01-12 07:45:34 --> UTF-8 Support Enabled
INFO - 2023-01-12 07:45:34 --> Utf8 Class Initialized
INFO - 2023-01-12 07:45:34 --> URI Class Initialized
INFO - 2023-01-12 07:45:34 --> Model "Login_model" initialized
INFO - 2023-01-12 07:45:34 --> Router Class Initialized
INFO - 2023-01-12 07:45:34 --> Output Class Initialized
INFO - 2023-01-12 07:45:34 --> Security Class Initialized
DEBUG - 2023-01-12 07:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 07:45:34 --> Input Class Initialized
INFO - 2023-01-12 07:45:34 --> Language Class Initialized
INFO - 2023-01-12 07:45:34 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:34 --> Loader Class Initialized
INFO - 2023-01-12 07:45:34 --> Controller Class Initialized
DEBUG - 2023-01-12 07:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 07:45:34 --> Database Driver Class Initialized
INFO - 2023-01-12 07:45:34 --> Model "Cluster_model" initialized
INFO - 2023-01-12 07:45:34 --> Final output sent to browser
INFO - 2023-01-12 07:45:34 --> Model "Cluster_model" initialized
DEBUG - 2023-01-12 07:45:34 --> Total execution time: 0.0259
INFO - 2023-01-12 07:45:34 --> Final output sent to browser
DEBUG - 2023-01-12 07:45:34 --> Total execution time: 0.0205
INFO - 2023-01-12 08:02:00 --> Config Class Initialized
INFO - 2023-01-12 08:02:00 --> Hooks Class Initialized
DEBUG - 2023-01-12 08:02:00 --> UTF-8 Support Enabled
INFO - 2023-01-12 08:02:00 --> Utf8 Class Initialized
INFO - 2023-01-12 08:02:00 --> URI Class Initialized
INFO - 2023-01-12 08:02:00 --> Router Class Initialized
INFO - 2023-01-12 08:02:00 --> Output Class Initialized
INFO - 2023-01-12 08:02:00 --> Security Class Initialized
DEBUG - 2023-01-12 08:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 08:02:00 --> Input Class Initialized
INFO - 2023-01-12 08:02:00 --> Language Class Initialized
INFO - 2023-01-12 08:02:00 --> Loader Class Initialized
INFO - 2023-01-12 08:02:00 --> Controller Class Initialized
DEBUG - 2023-01-12 08:02:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 08:02:00 --> Database Driver Class Initialized
INFO - 2023-01-12 08:02:00 --> Model "Cluster_model" initialized
INFO - 2023-01-12 08:02:00 --> Final output sent to browser
DEBUG - 2023-01-12 08:02:00 --> Total execution time: 0.0164
INFO - 2023-01-12 08:02:00 --> Config Class Initialized
INFO - 2023-01-12 08:02:00 --> Hooks Class Initialized
DEBUG - 2023-01-12 08:02:00 --> UTF-8 Support Enabled
INFO - 2023-01-12 08:02:00 --> Utf8 Class Initialized
INFO - 2023-01-12 08:02:00 --> URI Class Initialized
INFO - 2023-01-12 08:02:00 --> Router Class Initialized
INFO - 2023-01-12 08:02:00 --> Output Class Initialized
INFO - 2023-01-12 08:02:00 --> Security Class Initialized
DEBUG - 2023-01-12 08:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 08:02:00 --> Input Class Initialized
INFO - 2023-01-12 08:02:00 --> Language Class Initialized
INFO - 2023-01-12 08:02:00 --> Loader Class Initialized
INFO - 2023-01-12 08:02:00 --> Controller Class Initialized
DEBUG - 2023-01-12 08:02:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 08:02:00 --> Database Driver Class Initialized
INFO - 2023-01-12 08:02:00 --> Model "Cluster_model" initialized
INFO - 2023-01-12 08:02:00 --> Final output sent to browser
DEBUG - 2023-01-12 08:02:00 --> Total execution time: 0.0128
INFO - 2023-01-12 08:22:40 --> Config Class Initialized
INFO - 2023-01-12 08:22:40 --> Hooks Class Initialized
DEBUG - 2023-01-12 08:22:40 --> UTF-8 Support Enabled
INFO - 2023-01-12 08:22:40 --> Utf8 Class Initialized
INFO - 2023-01-12 08:22:40 --> URI Class Initialized
INFO - 2023-01-12 08:22:40 --> Router Class Initialized
INFO - 2023-01-12 08:22:40 --> Output Class Initialized
INFO - 2023-01-12 08:22:40 --> Security Class Initialized
DEBUG - 2023-01-12 08:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 08:22:40 --> Input Class Initialized
INFO - 2023-01-12 08:22:40 --> Language Class Initialized
INFO - 2023-01-12 08:22:40 --> Loader Class Initialized
INFO - 2023-01-12 08:22:40 --> Controller Class Initialized
DEBUG - 2023-01-12 08:22:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 08:22:40 --> Database Driver Class Initialized
INFO - 2023-01-12 08:22:40 --> Model "Cluster_model" initialized
INFO - 2023-01-12 08:22:40 --> Final output sent to browser
DEBUG - 2023-01-12 08:22:40 --> Total execution time: 0.0289
INFO - 2023-01-12 08:22:40 --> Config Class Initialized
INFO - 2023-01-12 08:22:40 --> Hooks Class Initialized
DEBUG - 2023-01-12 08:22:40 --> UTF-8 Support Enabled
INFO - 2023-01-12 08:22:40 --> Utf8 Class Initialized
INFO - 2023-01-12 08:22:40 --> URI Class Initialized
INFO - 2023-01-12 08:22:40 --> Router Class Initialized
INFO - 2023-01-12 08:22:40 --> Output Class Initialized
INFO - 2023-01-12 08:22:40 --> Security Class Initialized
DEBUG - 2023-01-12 08:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 08:22:40 --> Input Class Initialized
INFO - 2023-01-12 08:22:40 --> Language Class Initialized
INFO - 2023-01-12 08:22:40 --> Loader Class Initialized
INFO - 2023-01-12 08:22:40 --> Controller Class Initialized
DEBUG - 2023-01-12 08:22:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 08:22:40 --> Database Driver Class Initialized
INFO - 2023-01-12 08:22:40 --> Model "Cluster_model" initialized
INFO - 2023-01-12 08:22:40 --> Final output sent to browser
DEBUG - 2023-01-12 08:22:40 --> Total execution time: 0.0709
INFO - 2023-01-12 09:06:14 --> Config Class Initialized
INFO - 2023-01-12 09:06:14 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:06:14 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:06:14 --> Utf8 Class Initialized
INFO - 2023-01-12 09:06:14 --> URI Class Initialized
INFO - 2023-01-12 09:06:14 --> Router Class Initialized
INFO - 2023-01-12 09:06:14 --> Output Class Initialized
INFO - 2023-01-12 09:06:14 --> Security Class Initialized
DEBUG - 2023-01-12 09:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:06:14 --> Input Class Initialized
INFO - 2023-01-12 09:06:14 --> Language Class Initialized
INFO - 2023-01-12 09:06:14 --> Loader Class Initialized
INFO - 2023-01-12 09:06:14 --> Controller Class Initialized
DEBUG - 2023-01-12 09:06:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:06:14 --> Database Driver Class Initialized
INFO - 2023-01-12 09:06:14 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:06:14 --> Final output sent to browser
DEBUG - 2023-01-12 09:06:14 --> Total execution time: 0.0163
INFO - 2023-01-12 09:06:14 --> Config Class Initialized
INFO - 2023-01-12 09:06:14 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:06:14 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:06:14 --> Utf8 Class Initialized
INFO - 2023-01-12 09:06:14 --> URI Class Initialized
INFO - 2023-01-12 09:06:14 --> Router Class Initialized
INFO - 2023-01-12 09:06:14 --> Output Class Initialized
INFO - 2023-01-12 09:06:14 --> Security Class Initialized
DEBUG - 2023-01-12 09:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:06:14 --> Input Class Initialized
INFO - 2023-01-12 09:06:14 --> Language Class Initialized
INFO - 2023-01-12 09:06:14 --> Loader Class Initialized
INFO - 2023-01-12 09:06:14 --> Controller Class Initialized
DEBUG - 2023-01-12 09:06:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:06:14 --> Database Driver Class Initialized
INFO - 2023-01-12 09:06:14 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:06:14 --> Final output sent to browser
DEBUG - 2023-01-12 09:06:14 --> Total execution time: 0.0524
INFO - 2023-01-12 09:06:17 --> Config Class Initialized
INFO - 2023-01-12 09:06:17 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:06:17 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:06:17 --> Utf8 Class Initialized
INFO - 2023-01-12 09:06:17 --> URI Class Initialized
INFO - 2023-01-12 09:06:17 --> Router Class Initialized
INFO - 2023-01-12 09:06:17 --> Output Class Initialized
INFO - 2023-01-12 09:06:17 --> Security Class Initialized
DEBUG - 2023-01-12 09:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:06:17 --> Input Class Initialized
INFO - 2023-01-12 09:06:17 --> Language Class Initialized
INFO - 2023-01-12 09:06:17 --> Loader Class Initialized
INFO - 2023-01-12 09:06:17 --> Controller Class Initialized
DEBUG - 2023-01-12 09:06:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:06:17 --> Database Driver Class Initialized
INFO - 2023-01-12 09:06:17 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:06:17 --> Database Driver Class Initialized
INFO - 2023-01-12 09:06:17 --> Model "Login_model" initialized
INFO - 2023-01-12 09:06:17 --> Final output sent to browser
DEBUG - 2023-01-12 09:06:17 --> Total execution time: 0.0548
INFO - 2023-01-12 09:06:17 --> Config Class Initialized
INFO - 2023-01-12 09:06:17 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:06:17 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:06:17 --> Utf8 Class Initialized
INFO - 2023-01-12 09:06:17 --> URI Class Initialized
INFO - 2023-01-12 09:06:17 --> Router Class Initialized
INFO - 2023-01-12 09:06:17 --> Output Class Initialized
INFO - 2023-01-12 09:06:17 --> Security Class Initialized
DEBUG - 2023-01-12 09:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:06:17 --> Input Class Initialized
INFO - 2023-01-12 09:06:17 --> Language Class Initialized
INFO - 2023-01-12 09:06:17 --> Loader Class Initialized
INFO - 2023-01-12 09:06:17 --> Controller Class Initialized
DEBUG - 2023-01-12 09:06:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:06:17 --> Database Driver Class Initialized
INFO - 2023-01-12 09:06:17 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:06:17 --> Database Driver Class Initialized
INFO - 2023-01-12 09:06:17 --> Model "Login_model" initialized
INFO - 2023-01-12 09:06:17 --> Final output sent to browser
DEBUG - 2023-01-12 09:06:17 --> Total execution time: 0.1340
INFO - 2023-01-12 09:07:03 --> Config Class Initialized
INFO - 2023-01-12 09:07:03 --> Config Class Initialized
INFO - 2023-01-12 09:07:03 --> Hooks Class Initialized
INFO - 2023-01-12 09:07:03 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:07:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:07:03 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:07:03 --> Utf8 Class Initialized
INFO - 2023-01-12 09:07:03 --> Utf8 Class Initialized
INFO - 2023-01-12 09:07:03 --> URI Class Initialized
INFO - 2023-01-12 09:07:03 --> URI Class Initialized
INFO - 2023-01-12 09:07:03 --> Router Class Initialized
INFO - 2023-01-12 09:07:03 --> Router Class Initialized
INFO - 2023-01-12 09:07:03 --> Output Class Initialized
INFO - 2023-01-12 09:07:03 --> Output Class Initialized
INFO - 2023-01-12 09:07:03 --> Security Class Initialized
INFO - 2023-01-12 09:07:03 --> Security Class Initialized
DEBUG - 2023-01-12 09:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-12 09:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:07:03 --> Input Class Initialized
INFO - 2023-01-12 09:07:03 --> Input Class Initialized
INFO - 2023-01-12 09:07:03 --> Language Class Initialized
INFO - 2023-01-12 09:07:03 --> Language Class Initialized
INFO - 2023-01-12 09:07:03 --> Loader Class Initialized
INFO - 2023-01-12 09:07:03 --> Loader Class Initialized
INFO - 2023-01-12 09:07:03 --> Controller Class Initialized
INFO - 2023-01-12 09:07:03 --> Controller Class Initialized
DEBUG - 2023-01-12 09:07:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-12 09:07:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:07:03 --> Final output sent to browser
DEBUG - 2023-01-12 09:07:03 --> Total execution time: 0.0055
INFO - 2023-01-12 09:07:03 --> Database Driver Class Initialized
INFO - 2023-01-12 09:07:03 --> Config Class Initialized
INFO - 2023-01-12 09:07:03 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:07:03 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:07:03 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:07:03 --> Utf8 Class Initialized
INFO - 2023-01-12 09:07:03 --> URI Class Initialized
INFO - 2023-01-12 09:07:03 --> Router Class Initialized
INFO - 2023-01-12 09:07:03 --> Output Class Initialized
INFO - 2023-01-12 09:07:03 --> Security Class Initialized
DEBUG - 2023-01-12 09:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:07:03 --> Input Class Initialized
INFO - 2023-01-12 09:07:03 --> Language Class Initialized
INFO - 2023-01-12 09:07:03 --> Loader Class Initialized
INFO - 2023-01-12 09:07:03 --> Controller Class Initialized
DEBUG - 2023-01-12 09:07:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:07:03 --> Final output sent to browser
INFO - 2023-01-12 09:07:03 --> Database Driver Class Initialized
DEBUG - 2023-01-12 09:07:03 --> Total execution time: 0.0517
INFO - 2023-01-12 09:07:03 --> Config Class Initialized
INFO - 2023-01-12 09:07:03 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:07:03 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:07:03 --> Utf8 Class Initialized
INFO - 2023-01-12 09:07:03 --> URI Class Initialized
INFO - 2023-01-12 09:07:03 --> Router Class Initialized
INFO - 2023-01-12 09:07:03 --> Output Class Initialized
INFO - 2023-01-12 09:07:03 --> Security Class Initialized
DEBUG - 2023-01-12 09:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:07:03 --> Input Class Initialized
INFO - 2023-01-12 09:07:03 --> Language Class Initialized
INFO - 2023-01-12 09:07:03 --> Loader Class Initialized
INFO - 2023-01-12 09:07:03 --> Controller Class Initialized
DEBUG - 2023-01-12 09:07:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:07:03 --> Database Driver Class Initialized
INFO - 2023-01-12 09:07:03 --> Model "Login_model" initialized
INFO - 2023-01-12 09:07:03 --> Database Driver Class Initialized
INFO - 2023-01-12 09:07:03 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:07:03 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:07:03 --> Final output sent to browser
DEBUG - 2023-01-12 09:07:03 --> Total execution time: 0.0169
INFO - 2023-01-12 09:07:03 --> Final output sent to browser
DEBUG - 2023-01-12 09:07:03 --> Total execution time: 0.0657
INFO - 2023-01-12 09:07:05 --> Config Class Initialized
INFO - 2023-01-12 09:07:05 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:07:05 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:07:05 --> Utf8 Class Initialized
INFO - 2023-01-12 09:07:05 --> URI Class Initialized
INFO - 2023-01-12 09:07:05 --> Router Class Initialized
INFO - 2023-01-12 09:07:05 --> Output Class Initialized
INFO - 2023-01-12 09:07:05 --> Security Class Initialized
DEBUG - 2023-01-12 09:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:07:05 --> Input Class Initialized
INFO - 2023-01-12 09:07:05 --> Language Class Initialized
INFO - 2023-01-12 09:07:05 --> Loader Class Initialized
INFO - 2023-01-12 09:07:05 --> Controller Class Initialized
DEBUG - 2023-01-12 09:07:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:07:05 --> Database Driver Class Initialized
INFO - 2023-01-12 09:07:05 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:07:05 --> Final output sent to browser
DEBUG - 2023-01-12 09:07:05 --> Total execution time: 0.0186
INFO - 2023-01-12 09:07:05 --> Config Class Initialized
INFO - 2023-01-12 09:07:05 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:07:05 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:07:05 --> Utf8 Class Initialized
INFO - 2023-01-12 09:07:05 --> URI Class Initialized
INFO - 2023-01-12 09:07:05 --> Router Class Initialized
INFO - 2023-01-12 09:07:05 --> Output Class Initialized
INFO - 2023-01-12 09:07:05 --> Security Class Initialized
DEBUG - 2023-01-12 09:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:07:05 --> Input Class Initialized
INFO - 2023-01-12 09:07:05 --> Language Class Initialized
INFO - 2023-01-12 09:07:05 --> Loader Class Initialized
INFO - 2023-01-12 09:07:05 --> Controller Class Initialized
DEBUG - 2023-01-12 09:07:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:07:05 --> Database Driver Class Initialized
INFO - 2023-01-12 09:07:05 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:07:05 --> Final output sent to browser
DEBUG - 2023-01-12 09:07:05 --> Total execution time: 0.0116
INFO - 2023-01-12 09:07:09 --> Config Class Initialized
INFO - 2023-01-12 09:07:09 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:07:09 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:07:09 --> Utf8 Class Initialized
INFO - 2023-01-12 09:07:09 --> URI Class Initialized
INFO - 2023-01-12 09:07:09 --> Router Class Initialized
INFO - 2023-01-12 09:07:09 --> Output Class Initialized
INFO - 2023-01-12 09:07:09 --> Security Class Initialized
DEBUG - 2023-01-12 09:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:07:09 --> Input Class Initialized
INFO - 2023-01-12 09:07:09 --> Language Class Initialized
INFO - 2023-01-12 09:07:09 --> Loader Class Initialized
INFO - 2023-01-12 09:07:09 --> Controller Class Initialized
DEBUG - 2023-01-12 09:07:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:07:09 --> Database Driver Class Initialized
INFO - 2023-01-12 09:07:09 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:07:09 --> Final output sent to browser
DEBUG - 2023-01-12 09:07:09 --> Total execution time: 0.0262
INFO - 2023-01-12 09:07:09 --> Config Class Initialized
INFO - 2023-01-12 09:07:09 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:07:09 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:07:09 --> Utf8 Class Initialized
INFO - 2023-01-12 09:07:09 --> URI Class Initialized
INFO - 2023-01-12 09:07:09 --> Router Class Initialized
INFO - 2023-01-12 09:07:09 --> Output Class Initialized
INFO - 2023-01-12 09:07:09 --> Security Class Initialized
DEBUG - 2023-01-12 09:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:07:09 --> Input Class Initialized
INFO - 2023-01-12 09:07:09 --> Language Class Initialized
INFO - 2023-01-12 09:07:09 --> Loader Class Initialized
INFO - 2023-01-12 09:07:09 --> Controller Class Initialized
DEBUG - 2023-01-12 09:07:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:07:09 --> Database Driver Class Initialized
INFO - 2023-01-12 09:07:09 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:07:09 --> Final output sent to browser
DEBUG - 2023-01-12 09:07:09 --> Total execution time: 0.0705
INFO - 2023-01-12 09:07:10 --> Config Class Initialized
INFO - 2023-01-12 09:07:10 --> Config Class Initialized
INFO - 2023-01-12 09:07:10 --> Hooks Class Initialized
INFO - 2023-01-12 09:07:10 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:07:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-12 09:07:10 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:07:10 --> Utf8 Class Initialized
INFO - 2023-01-12 09:07:10 --> Utf8 Class Initialized
INFO - 2023-01-12 09:07:10 --> URI Class Initialized
INFO - 2023-01-12 09:07:10 --> URI Class Initialized
INFO - 2023-01-12 09:07:10 --> Router Class Initialized
INFO - 2023-01-12 09:07:10 --> Output Class Initialized
INFO - 2023-01-12 09:07:10 --> Router Class Initialized
INFO - 2023-01-12 09:07:10 --> Security Class Initialized
INFO - 2023-01-12 09:07:10 --> Output Class Initialized
DEBUG - 2023-01-12 09:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:07:10 --> Security Class Initialized
INFO - 2023-01-12 09:07:10 --> Input Class Initialized
DEBUG - 2023-01-12 09:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:07:10 --> Language Class Initialized
INFO - 2023-01-12 09:07:10 --> Input Class Initialized
INFO - 2023-01-12 09:07:10 --> Language Class Initialized
INFO - 2023-01-12 09:07:10 --> Loader Class Initialized
INFO - 2023-01-12 09:07:10 --> Loader Class Initialized
INFO - 2023-01-12 09:07:10 --> Controller Class Initialized
INFO - 2023-01-12 09:07:10 --> Controller Class Initialized
DEBUG - 2023-01-12 09:07:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-12 09:07:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:07:10 --> Final output sent to browser
INFO - 2023-01-12 09:07:10 --> Database Driver Class Initialized
DEBUG - 2023-01-12 09:07:10 --> Total execution time: 0.0040
INFO - 2023-01-12 09:07:10 --> Config Class Initialized
INFO - 2023-01-12 09:07:10 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:07:10 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:07:10 --> Utf8 Class Initialized
INFO - 2023-01-12 09:07:10 --> URI Class Initialized
INFO - 2023-01-12 09:07:10 --> Router Class Initialized
INFO - 2023-01-12 09:07:10 --> Output Class Initialized
INFO - 2023-01-12 09:07:10 --> Security Class Initialized
DEBUG - 2023-01-12 09:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:07:10 --> Input Class Initialized
INFO - 2023-01-12 09:07:10 --> Language Class Initialized
INFO - 2023-01-12 09:07:10 --> Loader Class Initialized
INFO - 2023-01-12 09:07:10 --> Controller Class Initialized
DEBUG - 2023-01-12 09:07:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:07:10 --> Database Driver Class Initialized
INFO - 2023-01-12 09:07:10 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:07:10 --> Model "Login_model" initialized
INFO - 2023-01-12 09:07:10 --> Database Driver Class Initialized
INFO - 2023-01-12 09:07:10 --> Final output sent to browser
DEBUG - 2023-01-12 09:07:10 --> Total execution time: 0.0215
INFO - 2023-01-12 09:07:10 --> Config Class Initialized
INFO - 2023-01-12 09:07:10 --> Hooks Class Initialized
DEBUG - 2023-01-12 09:07:10 --> UTF-8 Support Enabled
INFO - 2023-01-12 09:07:10 --> Utf8 Class Initialized
INFO - 2023-01-12 09:07:10 --> URI Class Initialized
INFO - 2023-01-12 09:07:10 --> Router Class Initialized
INFO - 2023-01-12 09:07:10 --> Output Class Initialized
INFO - 2023-01-12 09:07:10 --> Security Class Initialized
DEBUG - 2023-01-12 09:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-12 09:07:10 --> Input Class Initialized
INFO - 2023-01-12 09:07:10 --> Language Class Initialized
INFO - 2023-01-12 09:07:10 --> Loader Class Initialized
INFO - 2023-01-12 09:07:10 --> Controller Class Initialized
DEBUG - 2023-01-12 09:07:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-12 09:07:10 --> Database Driver Class Initialized
INFO - 2023-01-12 09:07:10 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:07:10 --> Final output sent to browser
DEBUG - 2023-01-12 09:07:10 --> Total execution time: 0.0231
INFO - 2023-01-12 09:07:10 --> Model "Cluster_model" initialized
INFO - 2023-01-12 09:07:10 --> Final output sent to browser
DEBUG - 2023-01-12 09:07:10 --> Total execution time: 0.0521
