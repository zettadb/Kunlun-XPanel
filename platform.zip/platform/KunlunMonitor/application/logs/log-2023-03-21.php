<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-21 06:43:42 --> Config Class Initialized
INFO - 2023-03-21 06:43:42 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:43:42 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:43:42 --> Utf8 Class Initialized
INFO - 2023-03-21 06:43:42 --> URI Class Initialized
INFO - 2023-03-21 06:43:42 --> Router Class Initialized
INFO - 2023-03-21 06:43:42 --> Output Class Initialized
INFO - 2023-03-21 06:43:42 --> Security Class Initialized
DEBUG - 2023-03-21 06:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:43:42 --> Input Class Initialized
INFO - 2023-03-21 06:43:42 --> Language Class Initialized
INFO - 2023-03-21 06:43:42 --> Loader Class Initialized
INFO - 2023-03-21 06:43:42 --> Controller Class Initialized
INFO - 2023-03-21 06:43:42 --> Helper loaded: form_helper
INFO - 2023-03-21 06:43:42 --> Helper loaded: url_helper
DEBUG - 2023-03-21 06:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:43:42 --> Model "Change_model" initialized
INFO - 2023-03-21 06:43:42 --> Model "Grafana_model" initialized
INFO - 2023-03-21 06:43:42 --> Final output sent to browser
DEBUG - 2023-03-21 06:43:42 --> Total execution time: 0.1639
INFO - 2023-03-21 06:43:42 --> Config Class Initialized
INFO - 2023-03-21 06:43:42 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:43:42 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:43:42 --> Utf8 Class Initialized
INFO - 2023-03-21 06:43:42 --> URI Class Initialized
INFO - 2023-03-21 06:43:42 --> Router Class Initialized
INFO - 2023-03-21 06:43:42 --> Output Class Initialized
INFO - 2023-03-21 06:43:42 --> Security Class Initialized
DEBUG - 2023-03-21 06:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:43:42 --> Input Class Initialized
INFO - 2023-03-21 06:43:42 --> Language Class Initialized
INFO - 2023-03-21 06:43:42 --> Loader Class Initialized
INFO - 2023-03-21 06:43:42 --> Controller Class Initialized
INFO - 2023-03-21 06:43:42 --> Helper loaded: form_helper
INFO - 2023-03-21 06:43:42 --> Helper loaded: url_helper
DEBUG - 2023-03-21 06:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:43:42 --> Final output sent to browser
DEBUG - 2023-03-21 06:43:42 --> Total execution time: 0.0612
INFO - 2023-03-21 06:43:42 --> Config Class Initialized
INFO - 2023-03-21 06:43:42 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:43:42 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:43:42 --> Utf8 Class Initialized
INFO - 2023-03-21 06:43:42 --> URI Class Initialized
INFO - 2023-03-21 06:43:42 --> Router Class Initialized
INFO - 2023-03-21 06:43:42 --> Output Class Initialized
INFO - 2023-03-21 06:43:42 --> Security Class Initialized
DEBUG - 2023-03-21 06:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:43:42 --> Input Class Initialized
INFO - 2023-03-21 06:43:42 --> Language Class Initialized
INFO - 2023-03-21 06:43:42 --> Loader Class Initialized
INFO - 2023-03-21 06:43:42 --> Controller Class Initialized
INFO - 2023-03-21 06:43:42 --> Helper loaded: form_helper
INFO - 2023-03-21 06:43:42 --> Helper loaded: url_helper
DEBUG - 2023-03-21 06:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:43:42 --> Database Driver Class Initialized
INFO - 2023-03-21 06:43:42 --> Model "Login_model" initialized
INFO - 2023-03-21 06:43:42 --> Final output sent to browser
DEBUG - 2023-03-21 06:43:42 --> Total execution time: 0.0317
INFO - 2023-03-21 06:43:42 --> Config Class Initialized
INFO - 2023-03-21 06:43:42 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:43:42 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:43:42 --> Utf8 Class Initialized
INFO - 2023-03-21 06:43:42 --> URI Class Initialized
INFO - 2023-03-21 06:43:42 --> Router Class Initialized
INFO - 2023-03-21 06:43:42 --> Output Class Initialized
INFO - 2023-03-21 06:43:42 --> Security Class Initialized
DEBUG - 2023-03-21 06:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:43:42 --> Input Class Initialized
INFO - 2023-03-21 06:43:42 --> Language Class Initialized
INFO - 2023-03-21 06:43:42 --> Loader Class Initialized
INFO - 2023-03-21 06:43:42 --> Controller Class Initialized
DEBUG - 2023-03-21 06:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:43:42 --> Database Driver Class Initialized
INFO - 2023-03-21 06:43:42 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:43:42 --> Final output sent to browser
DEBUG - 2023-03-21 06:43:42 --> Total execution time: 0.0433
INFO - 2023-03-21 06:43:42 --> Config Class Initialized
INFO - 2023-03-21 06:43:42 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:43:42 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:43:42 --> Utf8 Class Initialized
INFO - 2023-03-21 06:43:42 --> URI Class Initialized
INFO - 2023-03-21 06:43:42 --> Router Class Initialized
INFO - 2023-03-21 06:43:42 --> Output Class Initialized
INFO - 2023-03-21 06:43:42 --> Security Class Initialized
DEBUG - 2023-03-21 06:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:43:42 --> Input Class Initialized
INFO - 2023-03-21 06:43:42 --> Language Class Initialized
INFO - 2023-03-21 06:43:42 --> Loader Class Initialized
INFO - 2023-03-21 06:43:42 --> Controller Class Initialized
DEBUG - 2023-03-21 06:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:43:42 --> Database Driver Class Initialized
INFO - 2023-03-21 06:43:42 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:43:42 --> Final output sent to browser
DEBUG - 2023-03-21 06:43:42 --> Total execution time: 0.0135
INFO - 2023-03-21 06:43:42 --> Config Class Initialized
INFO - 2023-03-21 06:43:42 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:43:42 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:43:42 --> Utf8 Class Initialized
INFO - 2023-03-21 06:43:42 --> URI Class Initialized
INFO - 2023-03-21 06:43:42 --> Router Class Initialized
INFO - 2023-03-21 06:43:42 --> Output Class Initialized
INFO - 2023-03-21 06:43:42 --> Security Class Initialized
DEBUG - 2023-03-21 06:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:43:42 --> Input Class Initialized
INFO - 2023-03-21 06:43:42 --> Language Class Initialized
INFO - 2023-03-21 06:43:42 --> Loader Class Initialized
INFO - 2023-03-21 06:43:42 --> Controller Class Initialized
DEBUG - 2023-03-21 06:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:43:42 --> Database Driver Class Initialized
INFO - 2023-03-21 06:43:42 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:43:42 --> Database Driver Class Initialized
INFO - 2023-03-21 06:43:42 --> Model "Login_model" initialized
INFO - 2023-03-21 06:43:42 --> Final output sent to browser
DEBUG - 2023-03-21 06:43:42 --> Total execution time: 0.1445
INFO - 2023-03-21 06:43:42 --> Config Class Initialized
INFO - 2023-03-21 06:43:42 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:43:42 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:43:42 --> Utf8 Class Initialized
INFO - 2023-03-21 06:43:42 --> URI Class Initialized
INFO - 2023-03-21 06:43:42 --> Router Class Initialized
INFO - 2023-03-21 06:43:42 --> Output Class Initialized
INFO - 2023-03-21 06:43:42 --> Security Class Initialized
DEBUG - 2023-03-21 06:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:43:42 --> Input Class Initialized
INFO - 2023-03-21 06:43:42 --> Language Class Initialized
INFO - 2023-03-21 06:43:42 --> Loader Class Initialized
INFO - 2023-03-21 06:43:42 --> Controller Class Initialized
DEBUG - 2023-03-21 06:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:43:42 --> Database Driver Class Initialized
INFO - 2023-03-21 06:43:42 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:43:42 --> Database Driver Class Initialized
INFO - 2023-03-21 06:43:42 --> Model "Login_model" initialized
INFO - 2023-03-21 06:43:42 --> Final output sent to browser
DEBUG - 2023-03-21 06:43:42 --> Total execution time: 0.1021
INFO - 2023-03-21 06:44:21 --> Config Class Initialized
INFO - 2023-03-21 06:44:21 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:21 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:21 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:21 --> URI Class Initialized
INFO - 2023-03-21 06:44:21 --> Router Class Initialized
INFO - 2023-03-21 06:44:21 --> Output Class Initialized
INFO - 2023-03-21 06:44:21 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:21 --> Input Class Initialized
INFO - 2023-03-21 06:44:21 --> Language Class Initialized
INFO - 2023-03-21 06:44:21 --> Loader Class Initialized
INFO - 2023-03-21 06:44:21 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:21 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:21 --> Total execution time: 0.0033
INFO - 2023-03-21 06:44:21 --> Config Class Initialized
INFO - 2023-03-21 06:44:21 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:21 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:21 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:21 --> URI Class Initialized
INFO - 2023-03-21 06:44:21 --> Router Class Initialized
INFO - 2023-03-21 06:44:21 --> Output Class Initialized
INFO - 2023-03-21 06:44:21 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:21 --> Input Class Initialized
INFO - 2023-03-21 06:44:21 --> Language Class Initialized
INFO - 2023-03-21 06:44:21 --> Loader Class Initialized
INFO - 2023-03-21 06:44:21 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:21 --> Database Driver Class Initialized
INFO - 2023-03-21 06:44:21 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:44:21 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:21 --> Total execution time: 0.0118
INFO - 2023-03-21 06:44:22 --> Config Class Initialized
INFO - 2023-03-21 06:44:22 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:22 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:22 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:22 --> URI Class Initialized
INFO - 2023-03-21 06:44:22 --> Router Class Initialized
INFO - 2023-03-21 06:44:22 --> Output Class Initialized
INFO - 2023-03-21 06:44:22 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:22 --> Input Class Initialized
INFO - 2023-03-21 06:44:22 --> Language Class Initialized
INFO - 2023-03-21 06:44:22 --> Loader Class Initialized
INFO - 2023-03-21 06:44:22 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:22 --> Database Driver Class Initialized
INFO - 2023-03-21 06:44:22 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:44:22 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:22 --> Total execution time: 0.0160
INFO - 2023-03-21 06:44:22 --> Config Class Initialized
INFO - 2023-03-21 06:44:22 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:22 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:22 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:22 --> URI Class Initialized
INFO - 2023-03-21 06:44:22 --> Router Class Initialized
INFO - 2023-03-21 06:44:22 --> Output Class Initialized
INFO - 2023-03-21 06:44:22 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:22 --> Input Class Initialized
INFO - 2023-03-21 06:44:22 --> Language Class Initialized
INFO - 2023-03-21 06:44:22 --> Loader Class Initialized
INFO - 2023-03-21 06:44:22 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:22 --> Database Driver Class Initialized
INFO - 2023-03-21 06:44:22 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:44:22 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:22 --> Total execution time: 0.0103
INFO - 2023-03-21 06:44:23 --> Config Class Initialized
INFO - 2023-03-21 06:44:23 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:23 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:23 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:23 --> URI Class Initialized
INFO - 2023-03-21 06:44:23 --> Router Class Initialized
INFO - 2023-03-21 06:44:23 --> Output Class Initialized
INFO - 2023-03-21 06:44:23 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:23 --> Input Class Initialized
INFO - 2023-03-21 06:44:23 --> Language Class Initialized
INFO - 2023-03-21 06:44:23 --> Loader Class Initialized
INFO - 2023-03-21 06:44:23 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:23 --> Database Driver Class Initialized
INFO - 2023-03-21 06:44:23 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:44:23 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:23 --> Total execution time: 0.0121
INFO - 2023-03-21 06:44:23 --> Config Class Initialized
INFO - 2023-03-21 06:44:23 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:23 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:23 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:23 --> URI Class Initialized
INFO - 2023-03-21 06:44:23 --> Router Class Initialized
INFO - 2023-03-21 06:44:23 --> Output Class Initialized
INFO - 2023-03-21 06:44:23 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:23 --> Input Class Initialized
INFO - 2023-03-21 06:44:23 --> Language Class Initialized
INFO - 2023-03-21 06:44:23 --> Loader Class Initialized
INFO - 2023-03-21 06:44:23 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:23 --> Database Driver Class Initialized
INFO - 2023-03-21 06:44:23 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:44:23 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:23 --> Total execution time: 0.0091
INFO - 2023-03-21 06:44:25 --> Config Class Initialized
INFO - 2023-03-21 06:44:25 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:25 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:25 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:25 --> URI Class Initialized
INFO - 2023-03-21 06:44:25 --> Router Class Initialized
INFO - 2023-03-21 06:44:25 --> Output Class Initialized
INFO - 2023-03-21 06:44:25 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:25 --> Input Class Initialized
INFO - 2023-03-21 06:44:25 --> Language Class Initialized
INFO - 2023-03-21 06:44:25 --> Loader Class Initialized
INFO - 2023-03-21 06:44:25 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:25 --> Database Driver Class Initialized
INFO - 2023-03-21 06:44:25 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:44:25 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:25 --> Total execution time: 0.0822
INFO - 2023-03-21 06:44:25 --> Config Class Initialized
INFO - 2023-03-21 06:44:25 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:25 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:25 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:25 --> URI Class Initialized
INFO - 2023-03-21 06:44:25 --> Router Class Initialized
INFO - 2023-03-21 06:44:25 --> Output Class Initialized
INFO - 2023-03-21 06:44:25 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:25 --> Input Class Initialized
INFO - 2023-03-21 06:44:25 --> Language Class Initialized
INFO - 2023-03-21 06:44:25 --> Loader Class Initialized
INFO - 2023-03-21 06:44:25 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:25 --> Database Driver Class Initialized
INFO - 2023-03-21 06:44:25 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:44:25 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:25 --> Total execution time: 0.0187
INFO - 2023-03-21 06:44:28 --> Config Class Initialized
INFO - 2023-03-21 06:44:28 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:28 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:28 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:28 --> URI Class Initialized
INFO - 2023-03-21 06:44:28 --> Router Class Initialized
INFO - 2023-03-21 06:44:28 --> Output Class Initialized
INFO - 2023-03-21 06:44:28 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:28 --> Input Class Initialized
INFO - 2023-03-21 06:44:28 --> Language Class Initialized
INFO - 2023-03-21 06:44:28 --> Loader Class Initialized
INFO - 2023-03-21 06:44:28 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:28 --> Database Driver Class Initialized
INFO - 2023-03-21 06:44:28 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:44:28 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:28 --> Total execution time: 0.0151
INFO - 2023-03-21 06:44:28 --> Config Class Initialized
INFO - 2023-03-21 06:44:28 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:28 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:28 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:28 --> URI Class Initialized
INFO - 2023-03-21 06:44:28 --> Router Class Initialized
INFO - 2023-03-21 06:44:28 --> Output Class Initialized
INFO - 2023-03-21 06:44:28 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:28 --> Input Class Initialized
INFO - 2023-03-21 06:44:28 --> Language Class Initialized
INFO - 2023-03-21 06:44:28 --> Loader Class Initialized
INFO - 2023-03-21 06:44:28 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:28 --> Database Driver Class Initialized
INFO - 2023-03-21 06:44:28 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:44:28 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:28 --> Total execution time: 0.0122
INFO - 2023-03-21 06:44:29 --> Config Class Initialized
INFO - 2023-03-21 06:44:29 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:29 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:29 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:29 --> URI Class Initialized
INFO - 2023-03-21 06:44:29 --> Router Class Initialized
INFO - 2023-03-21 06:44:29 --> Output Class Initialized
INFO - 2023-03-21 06:44:29 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:29 --> Input Class Initialized
INFO - 2023-03-21 06:44:29 --> Language Class Initialized
INFO - 2023-03-21 06:44:29 --> Loader Class Initialized
INFO - 2023-03-21 06:44:29 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:29 --> Database Driver Class Initialized
INFO - 2023-03-21 06:44:29 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:44:29 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:29 --> Total execution time: 0.0374
INFO - 2023-03-21 06:44:51 --> Config Class Initialized
INFO - 2023-03-21 06:44:51 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:51 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:51 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:51 --> URI Class Initialized
INFO - 2023-03-21 06:44:51 --> Router Class Initialized
INFO - 2023-03-21 06:44:51 --> Output Class Initialized
INFO - 2023-03-21 06:44:51 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:51 --> Input Class Initialized
INFO - 2023-03-21 06:44:51 --> Language Class Initialized
INFO - 2023-03-21 06:44:51 --> Loader Class Initialized
INFO - 2023-03-21 06:44:51 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:51 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:51 --> Total execution time: 0.0420
INFO - 2023-03-21 06:44:51 --> Config Class Initialized
INFO - 2023-03-21 06:44:51 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:51 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:51 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:51 --> URI Class Initialized
INFO - 2023-03-21 06:44:51 --> Router Class Initialized
INFO - 2023-03-21 06:44:51 --> Output Class Initialized
INFO - 2023-03-21 06:44:51 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:51 --> Input Class Initialized
INFO - 2023-03-21 06:44:51 --> Language Class Initialized
INFO - 2023-03-21 06:44:51 --> Loader Class Initialized
INFO - 2023-03-21 06:44:51 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:51 --> Database Driver Class Initialized
INFO - 2023-03-21 06:44:51 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:44:51 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:51 --> Total execution time: 0.0126
INFO - 2023-03-21 06:44:53 --> Config Class Initialized
INFO - 2023-03-21 06:44:53 --> Config Class Initialized
INFO - 2023-03-21 06:44:53 --> Hooks Class Initialized
INFO - 2023-03-21 06:44:53 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:53 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:53 --> Utf8 Class Initialized
DEBUG - 2023-03-21 06:44:53 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:53 --> URI Class Initialized
INFO - 2023-03-21 06:44:53 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:53 --> Router Class Initialized
INFO - 2023-03-21 06:44:53 --> URI Class Initialized
INFO - 2023-03-21 06:44:53 --> Output Class Initialized
INFO - 2023-03-21 06:44:53 --> Router Class Initialized
INFO - 2023-03-21 06:44:53 --> Security Class Initialized
INFO - 2023-03-21 06:44:53 --> Output Class Initialized
DEBUG - 2023-03-21 06:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:53 --> Security Class Initialized
INFO - 2023-03-21 06:44:53 --> Input Class Initialized
DEBUG - 2023-03-21 06:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:53 --> Language Class Initialized
INFO - 2023-03-21 06:44:53 --> Input Class Initialized
INFO - 2023-03-21 06:44:53 --> Language Class Initialized
INFO - 2023-03-21 06:44:53 --> Loader Class Initialized
INFO - 2023-03-21 06:44:53 --> Loader Class Initialized
INFO - 2023-03-21 06:44:53 --> Controller Class Initialized
INFO - 2023-03-21 06:44:53 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 06:44:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:53 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:53 --> Total execution time: 0.0075
INFO - 2023-03-21 06:44:53 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:53 --> Total execution time: 0.0055
INFO - 2023-03-21 06:44:53 --> Config Class Initialized
INFO - 2023-03-21 06:44:53 --> Config Class Initialized
INFO - 2023-03-21 06:44:53 --> Hooks Class Initialized
INFO - 2023-03-21 06:44:53 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:44:53 --> UTF-8 Support Enabled
DEBUG - 2023-03-21 06:44:53 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:44:53 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:53 --> Utf8 Class Initialized
INFO - 2023-03-21 06:44:53 --> URI Class Initialized
INFO - 2023-03-21 06:44:53 --> URI Class Initialized
INFO - 2023-03-21 06:44:53 --> Router Class Initialized
INFO - 2023-03-21 06:44:53 --> Router Class Initialized
INFO - 2023-03-21 06:44:53 --> Output Class Initialized
INFO - 2023-03-21 06:44:53 --> Output Class Initialized
INFO - 2023-03-21 06:44:53 --> Security Class Initialized
INFO - 2023-03-21 06:44:53 --> Security Class Initialized
DEBUG - 2023-03-21 06:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-21 06:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:44:53 --> Input Class Initialized
INFO - 2023-03-21 06:44:53 --> Input Class Initialized
INFO - 2023-03-21 06:44:53 --> Language Class Initialized
INFO - 2023-03-21 06:44:53 --> Language Class Initialized
INFO - 2023-03-21 06:44:53 --> Loader Class Initialized
INFO - 2023-03-21 06:44:53 --> Loader Class Initialized
INFO - 2023-03-21 06:44:53 --> Controller Class Initialized
INFO - 2023-03-21 06:44:53 --> Controller Class Initialized
DEBUG - 2023-03-21 06:44:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 06:44:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:44:53 --> Database Driver Class Initialized
INFO - 2023-03-21 06:44:53 --> Database Driver Class Initialized
INFO - 2023-03-21 06:44:53 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:44:53 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:44:53 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:53 --> Total execution time: 0.0551
INFO - 2023-03-21 06:44:53 --> Final output sent to browser
DEBUG - 2023-03-21 06:44:53 --> Total execution time: 0.0692
INFO - 2023-03-21 06:45:17 --> Config Class Initialized
INFO - 2023-03-21 06:45:17 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:45:17 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:45:17 --> Utf8 Class Initialized
INFO - 2023-03-21 06:45:17 --> URI Class Initialized
INFO - 2023-03-21 06:45:17 --> Router Class Initialized
INFO - 2023-03-21 06:45:17 --> Output Class Initialized
INFO - 2023-03-21 06:45:17 --> Security Class Initialized
DEBUG - 2023-03-21 06:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:45:17 --> Input Class Initialized
INFO - 2023-03-21 06:45:17 --> Language Class Initialized
INFO - 2023-03-21 06:45:17 --> Loader Class Initialized
INFO - 2023-03-21 06:45:17 --> Controller Class Initialized
DEBUG - 2023-03-21 06:45:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:45:17 --> Database Driver Class Initialized
INFO - 2023-03-21 06:45:18 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:45:18 --> Final output sent to browser
DEBUG - 2023-03-21 06:45:18 --> Total execution time: 0.0111
INFO - 2023-03-21 06:45:18 --> Config Class Initialized
INFO - 2023-03-21 06:45:18 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:45:18 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:45:18 --> Utf8 Class Initialized
INFO - 2023-03-21 06:45:18 --> URI Class Initialized
INFO - 2023-03-21 06:45:18 --> Router Class Initialized
INFO - 2023-03-21 06:45:18 --> Output Class Initialized
INFO - 2023-03-21 06:45:18 --> Security Class Initialized
DEBUG - 2023-03-21 06:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:45:18 --> Input Class Initialized
INFO - 2023-03-21 06:45:18 --> Language Class Initialized
INFO - 2023-03-21 06:45:18 --> Loader Class Initialized
INFO - 2023-03-21 06:45:18 --> Controller Class Initialized
DEBUG - 2023-03-21 06:45:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:45:18 --> Database Driver Class Initialized
INFO - 2023-03-21 06:45:18 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:45:18 --> Final output sent to browser
DEBUG - 2023-03-21 06:45:18 --> Total execution time: 0.0110
INFO - 2023-03-21 06:45:19 --> Config Class Initialized
INFO - 2023-03-21 06:45:19 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:45:19 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:45:19 --> Utf8 Class Initialized
INFO - 2023-03-21 06:45:19 --> URI Class Initialized
INFO - 2023-03-21 06:45:19 --> Router Class Initialized
INFO - 2023-03-21 06:45:19 --> Output Class Initialized
INFO - 2023-03-21 06:45:19 --> Security Class Initialized
DEBUG - 2023-03-21 06:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:45:19 --> Input Class Initialized
INFO - 2023-03-21 06:45:19 --> Language Class Initialized
INFO - 2023-03-21 06:45:19 --> Loader Class Initialized
INFO - 2023-03-21 06:45:19 --> Controller Class Initialized
DEBUG - 2023-03-21 06:45:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:45:19 --> Database Driver Class Initialized
INFO - 2023-03-21 06:45:19 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:45:19 --> Final output sent to browser
DEBUG - 2023-03-21 06:45:19 --> Total execution time: 0.0258
INFO - 2023-03-21 06:45:19 --> Config Class Initialized
INFO - 2023-03-21 06:45:19 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:45:19 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:45:19 --> Utf8 Class Initialized
INFO - 2023-03-21 06:45:19 --> URI Class Initialized
INFO - 2023-03-21 06:45:19 --> Router Class Initialized
INFO - 2023-03-21 06:45:19 --> Output Class Initialized
INFO - 2023-03-21 06:45:19 --> Security Class Initialized
DEBUG - 2023-03-21 06:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:45:19 --> Input Class Initialized
INFO - 2023-03-21 06:45:19 --> Language Class Initialized
INFO - 2023-03-21 06:45:19 --> Loader Class Initialized
INFO - 2023-03-21 06:45:19 --> Controller Class Initialized
DEBUG - 2023-03-21 06:45:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:45:19 --> Database Driver Class Initialized
INFO - 2023-03-21 06:45:19 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:45:19 --> Final output sent to browser
DEBUG - 2023-03-21 06:45:19 --> Total execution time: 0.0337
INFO - 2023-03-21 06:45:22 --> Config Class Initialized
INFO - 2023-03-21 06:45:22 --> Config Class Initialized
INFO - 2023-03-21 06:45:22 --> Hooks Class Initialized
INFO - 2023-03-21 06:45:22 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:45:22 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:45:22 --> Utf8 Class Initialized
DEBUG - 2023-03-21 06:45:22 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:45:22 --> URI Class Initialized
INFO - 2023-03-21 06:45:22 --> Utf8 Class Initialized
INFO - 2023-03-21 06:45:22 --> Router Class Initialized
INFO - 2023-03-21 06:45:22 --> URI Class Initialized
INFO - 2023-03-21 06:45:22 --> Output Class Initialized
INFO - 2023-03-21 06:45:22 --> Router Class Initialized
INFO - 2023-03-21 06:45:22 --> Security Class Initialized
DEBUG - 2023-03-21 06:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:45:22 --> Output Class Initialized
INFO - 2023-03-21 06:45:22 --> Input Class Initialized
INFO - 2023-03-21 06:45:22 --> Security Class Initialized
INFO - 2023-03-21 06:45:22 --> Language Class Initialized
DEBUG - 2023-03-21 06:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:45:22 --> Input Class Initialized
INFO - 2023-03-21 06:45:22 --> Language Class Initialized
INFO - 2023-03-21 06:45:22 --> Loader Class Initialized
INFO - 2023-03-21 06:45:22 --> Loader Class Initialized
INFO - 2023-03-21 06:45:22 --> Controller Class Initialized
INFO - 2023-03-21 06:45:22 --> Controller Class Initialized
DEBUG - 2023-03-21 06:45:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 06:45:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:45:22 --> Final output sent to browser
DEBUG - 2023-03-21 06:45:22 --> Total execution time: 0.0043
INFO - 2023-03-21 06:45:22 --> Database Driver Class Initialized
INFO - 2023-03-21 06:45:22 --> Config Class Initialized
INFO - 2023-03-21 06:45:22 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:45:22 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:45:22 --> Utf8 Class Initialized
INFO - 2023-03-21 06:45:22 --> URI Class Initialized
INFO - 2023-03-21 06:45:22 --> Router Class Initialized
INFO - 2023-03-21 06:45:22 --> Output Class Initialized
INFO - 2023-03-21 06:45:22 --> Security Class Initialized
DEBUG - 2023-03-21 06:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:45:22 --> Input Class Initialized
INFO - 2023-03-21 06:45:22 --> Language Class Initialized
INFO - 2023-03-21 06:45:22 --> Loader Class Initialized
INFO - 2023-03-21 06:45:22 --> Controller Class Initialized
DEBUG - 2023-03-21 06:45:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:45:22 --> Database Driver Class Initialized
INFO - 2023-03-21 06:45:22 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:45:22 --> Final output sent to browser
DEBUG - 2023-03-21 06:45:22 --> Total execution time: 0.0176
INFO - 2023-03-21 06:45:22 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:45:22 --> Config Class Initialized
INFO - 2023-03-21 06:45:22 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:45:22 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:45:22 --> Utf8 Class Initialized
INFO - 2023-03-21 06:45:22 --> URI Class Initialized
INFO - 2023-03-21 06:45:22 --> Router Class Initialized
INFO - 2023-03-21 06:45:22 --> Output Class Initialized
INFO - 2023-03-21 06:45:22 --> Security Class Initialized
DEBUG - 2023-03-21 06:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:45:22 --> Input Class Initialized
INFO - 2023-03-21 06:45:22 --> Language Class Initialized
INFO - 2023-03-21 06:45:22 --> Final output sent to browser
INFO - 2023-03-21 06:45:22 --> Loader Class Initialized
DEBUG - 2023-03-21 06:45:22 --> Total execution time: 0.0543
INFO - 2023-03-21 06:45:22 --> Controller Class Initialized
DEBUG - 2023-03-21 06:45:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:45:22 --> Database Driver Class Initialized
INFO - 2023-03-21 06:45:22 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:45:22 --> Final output sent to browser
DEBUG - 2023-03-21 06:45:22 --> Total execution time: 0.0519
INFO - 2023-03-21 06:45:55 --> Config Class Initialized
INFO - 2023-03-21 06:45:55 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:45:55 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:45:55 --> Utf8 Class Initialized
INFO - 2023-03-21 06:45:55 --> URI Class Initialized
INFO - 2023-03-21 06:45:55 --> Router Class Initialized
INFO - 2023-03-21 06:45:55 --> Output Class Initialized
INFO - 2023-03-21 06:45:55 --> Security Class Initialized
DEBUG - 2023-03-21 06:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:45:55 --> Input Class Initialized
INFO - 2023-03-21 06:45:55 --> Language Class Initialized
INFO - 2023-03-21 06:45:55 --> Loader Class Initialized
INFO - 2023-03-21 06:45:55 --> Controller Class Initialized
DEBUG - 2023-03-21 06:45:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:45:55 --> Database Driver Class Initialized
INFO - 2023-03-21 06:45:55 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:45:55 --> Final output sent to browser
DEBUG - 2023-03-21 06:45:55 --> Total execution time: 0.0648
INFO - 2023-03-21 06:45:55 --> Config Class Initialized
INFO - 2023-03-21 06:45:55 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:45:55 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:45:55 --> Utf8 Class Initialized
INFO - 2023-03-21 06:45:55 --> URI Class Initialized
INFO - 2023-03-21 06:45:55 --> Router Class Initialized
INFO - 2023-03-21 06:45:55 --> Output Class Initialized
INFO - 2023-03-21 06:45:55 --> Security Class Initialized
DEBUG - 2023-03-21 06:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:45:55 --> Input Class Initialized
INFO - 2023-03-21 06:45:55 --> Language Class Initialized
INFO - 2023-03-21 06:45:55 --> Loader Class Initialized
INFO - 2023-03-21 06:45:55 --> Controller Class Initialized
DEBUG - 2023-03-21 06:45:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:45:55 --> Database Driver Class Initialized
INFO - 2023-03-21 06:45:55 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:45:55 --> Final output sent to browser
DEBUG - 2023-03-21 06:45:55 --> Total execution time: 0.0196
INFO - 2023-03-21 06:46:56 --> Config Class Initialized
INFO - 2023-03-21 06:46:56 --> Config Class Initialized
INFO - 2023-03-21 06:46:56 --> Hooks Class Initialized
INFO - 2023-03-21 06:46:56 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:46:56 --> UTF-8 Support Enabled
DEBUG - 2023-03-21 06:46:56 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:46:56 --> Utf8 Class Initialized
INFO - 2023-03-21 06:46:56 --> Utf8 Class Initialized
INFO - 2023-03-21 06:46:56 --> URI Class Initialized
INFO - 2023-03-21 06:46:56 --> URI Class Initialized
INFO - 2023-03-21 06:46:56 --> Router Class Initialized
INFO - 2023-03-21 06:46:56 --> Router Class Initialized
INFO - 2023-03-21 06:46:56 --> Output Class Initialized
INFO - 2023-03-21 06:46:56 --> Output Class Initialized
INFO - 2023-03-21 06:46:56 --> Security Class Initialized
INFO - 2023-03-21 06:46:56 --> Security Class Initialized
DEBUG - 2023-03-21 06:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-21 06:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:46:56 --> Input Class Initialized
INFO - 2023-03-21 06:46:56 --> Input Class Initialized
INFO - 2023-03-21 06:46:56 --> Language Class Initialized
INFO - 2023-03-21 06:46:56 --> Language Class Initialized
INFO - 2023-03-21 06:46:56 --> Loader Class Initialized
INFO - 2023-03-21 06:46:56 --> Loader Class Initialized
INFO - 2023-03-21 06:46:56 --> Controller Class Initialized
INFO - 2023-03-21 06:46:56 --> Controller Class Initialized
DEBUG - 2023-03-21 06:46:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 06:46:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:46:56 --> Database Driver Class Initialized
INFO - 2023-03-21 06:46:56 --> Final output sent to browser
DEBUG - 2023-03-21 06:46:56 --> Total execution time: 0.0048
INFO - 2023-03-21 06:46:56 --> Config Class Initialized
INFO - 2023-03-21 06:46:56 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:46:56 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:46:56 --> Utf8 Class Initialized
INFO - 2023-03-21 06:46:56 --> URI Class Initialized
INFO - 2023-03-21 06:46:56 --> Router Class Initialized
INFO - 2023-03-21 06:46:56 --> Output Class Initialized
INFO - 2023-03-21 06:46:56 --> Security Class Initialized
DEBUG - 2023-03-21 06:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:46:56 --> Input Class Initialized
INFO - 2023-03-21 06:46:56 --> Language Class Initialized
INFO - 2023-03-21 06:46:56 --> Loader Class Initialized
INFO - 2023-03-21 06:46:56 --> Controller Class Initialized
DEBUG - 2023-03-21 06:46:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:46:56 --> Database Driver Class Initialized
INFO - 2023-03-21 06:46:56 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:46:56 --> Final output sent to browser
DEBUG - 2023-03-21 06:46:56 --> Total execution time: 0.0150
INFO - 2023-03-21 06:46:56 --> Config Class Initialized
INFO - 2023-03-21 06:46:56 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:46:56 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:46:56 --> Utf8 Class Initialized
INFO - 2023-03-21 06:46:56 --> URI Class Initialized
INFO - 2023-03-21 06:46:56 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:46:56 --> Router Class Initialized
INFO - 2023-03-21 06:46:56 --> Output Class Initialized
INFO - 2023-03-21 06:46:56 --> Security Class Initialized
DEBUG - 2023-03-21 06:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:46:56 --> Input Class Initialized
INFO - 2023-03-21 06:46:56 --> Language Class Initialized
INFO - 2023-03-21 06:46:56 --> Loader Class Initialized
INFO - 2023-03-21 06:46:56 --> Controller Class Initialized
DEBUG - 2023-03-21 06:46:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:46:56 --> Database Driver Class Initialized
INFO - 2023-03-21 06:46:56 --> Final output sent to browser
DEBUG - 2023-03-21 06:46:56 --> Total execution time: 0.0125
INFO - 2023-03-21 06:46:56 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:46:56 --> Final output sent to browser
DEBUG - 2023-03-21 06:46:56 --> Total execution time: 0.0151
INFO - 2023-03-21 06:46:58 --> Config Class Initialized
INFO - 2023-03-21 06:46:58 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:46:58 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:46:58 --> Utf8 Class Initialized
INFO - 2023-03-21 06:46:58 --> URI Class Initialized
INFO - 2023-03-21 06:46:58 --> Router Class Initialized
INFO - 2023-03-21 06:46:58 --> Output Class Initialized
INFO - 2023-03-21 06:46:58 --> Security Class Initialized
DEBUG - 2023-03-21 06:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:46:58 --> Input Class Initialized
INFO - 2023-03-21 06:46:58 --> Language Class Initialized
INFO - 2023-03-21 06:46:58 --> Loader Class Initialized
INFO - 2023-03-21 06:46:58 --> Controller Class Initialized
DEBUG - 2023-03-21 06:46:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:46:58 --> Database Driver Class Initialized
INFO - 2023-03-21 06:46:58 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:46:58 --> Final output sent to browser
DEBUG - 2023-03-21 06:46:58 --> Total execution time: 0.0204
INFO - 2023-03-21 06:46:58 --> Config Class Initialized
INFO - 2023-03-21 06:46:58 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:46:58 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:46:58 --> Utf8 Class Initialized
INFO - 2023-03-21 06:46:58 --> URI Class Initialized
INFO - 2023-03-21 06:46:58 --> Router Class Initialized
INFO - 2023-03-21 06:46:58 --> Output Class Initialized
INFO - 2023-03-21 06:46:58 --> Security Class Initialized
DEBUG - 2023-03-21 06:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:46:58 --> Input Class Initialized
INFO - 2023-03-21 06:46:58 --> Language Class Initialized
INFO - 2023-03-21 06:46:58 --> Loader Class Initialized
INFO - 2023-03-21 06:46:58 --> Controller Class Initialized
DEBUG - 2023-03-21 06:46:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:46:58 --> Database Driver Class Initialized
INFO - 2023-03-21 06:46:58 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:46:58 --> Final output sent to browser
DEBUG - 2023-03-21 06:46:58 --> Total execution time: 0.0398
INFO - 2023-03-21 06:47:00 --> Config Class Initialized
INFO - 2023-03-21 06:47:00 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:00 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:00 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:00 --> URI Class Initialized
INFO - 2023-03-21 06:47:00 --> Router Class Initialized
INFO - 2023-03-21 06:47:00 --> Output Class Initialized
INFO - 2023-03-21 06:47:00 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:00 --> Input Class Initialized
INFO - 2023-03-21 06:47:00 --> Language Class Initialized
INFO - 2023-03-21 06:47:00 --> Loader Class Initialized
INFO - 2023-03-21 06:47:00 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:00 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:00 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:00 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:00 --> Total execution time: 0.0172
INFO - 2023-03-21 06:47:10 --> Config Class Initialized
INFO - 2023-03-21 06:47:10 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:10 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:10 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:10 --> URI Class Initialized
INFO - 2023-03-21 06:47:10 --> Router Class Initialized
INFO - 2023-03-21 06:47:10 --> Output Class Initialized
INFO - 2023-03-21 06:47:10 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:10 --> Input Class Initialized
INFO - 2023-03-21 06:47:10 --> Language Class Initialized
INFO - 2023-03-21 06:47:10 --> Loader Class Initialized
INFO - 2023-03-21 06:47:10 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:10 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:10 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:10 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:10 --> Total execution time: 0.0127
INFO - 2023-03-21 06:47:10 --> Config Class Initialized
INFO - 2023-03-21 06:47:10 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:10 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:10 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:10 --> URI Class Initialized
INFO - 2023-03-21 06:47:10 --> Router Class Initialized
INFO - 2023-03-21 06:47:10 --> Output Class Initialized
INFO - 2023-03-21 06:47:10 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:10 --> Input Class Initialized
INFO - 2023-03-21 06:47:10 --> Language Class Initialized
INFO - 2023-03-21 06:47:10 --> Loader Class Initialized
INFO - 2023-03-21 06:47:10 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:10 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:10 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:10 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:10 --> Total execution time: 0.0127
INFO - 2023-03-21 06:47:12 --> Config Class Initialized
INFO - 2023-03-21 06:47:12 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:12 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:12 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:12 --> URI Class Initialized
INFO - 2023-03-21 06:47:12 --> Router Class Initialized
INFO - 2023-03-21 06:47:12 --> Output Class Initialized
INFO - 2023-03-21 06:47:12 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:12 --> Input Class Initialized
INFO - 2023-03-21 06:47:12 --> Language Class Initialized
INFO - 2023-03-21 06:47:12 --> Loader Class Initialized
INFO - 2023-03-21 06:47:12 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:12 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:12 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:12 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:12 --> Total execution time: 0.0152
INFO - 2023-03-21 06:47:12 --> Config Class Initialized
INFO - 2023-03-21 06:47:12 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:12 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:12 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:12 --> URI Class Initialized
INFO - 2023-03-21 06:47:12 --> Router Class Initialized
INFO - 2023-03-21 06:47:12 --> Output Class Initialized
INFO - 2023-03-21 06:47:12 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:12 --> Input Class Initialized
INFO - 2023-03-21 06:47:12 --> Language Class Initialized
INFO - 2023-03-21 06:47:12 --> Loader Class Initialized
INFO - 2023-03-21 06:47:12 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:12 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:12 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:12 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:12 --> Total execution time: 0.0307
INFO - 2023-03-21 06:47:13 --> Config Class Initialized
INFO - 2023-03-21 06:47:13 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:13 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:13 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:13 --> URI Class Initialized
INFO - 2023-03-21 06:47:13 --> Router Class Initialized
INFO - 2023-03-21 06:47:13 --> Output Class Initialized
INFO - 2023-03-21 06:47:13 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:13 --> Input Class Initialized
INFO - 2023-03-21 06:47:13 --> Language Class Initialized
INFO - 2023-03-21 06:47:13 --> Loader Class Initialized
INFO - 2023-03-21 06:47:13 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:13 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:13 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:14 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:14 --> Total execution time: 0.0469
INFO - 2023-03-21 06:47:14 --> Config Class Initialized
INFO - 2023-03-21 06:47:14 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:14 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:14 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:14 --> URI Class Initialized
INFO - 2023-03-21 06:47:14 --> Router Class Initialized
INFO - 2023-03-21 06:47:14 --> Output Class Initialized
INFO - 2023-03-21 06:47:14 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:14 --> Input Class Initialized
INFO - 2023-03-21 06:47:14 --> Language Class Initialized
INFO - 2023-03-21 06:47:14 --> Loader Class Initialized
INFO - 2023-03-21 06:47:14 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:14 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:14 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:14 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:14 --> Total execution time: 0.0693
INFO - 2023-03-21 06:47:41 --> Config Class Initialized
INFO - 2023-03-21 06:47:41 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:41 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:41 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:41 --> URI Class Initialized
INFO - 2023-03-21 06:47:41 --> Router Class Initialized
INFO - 2023-03-21 06:47:41 --> Output Class Initialized
INFO - 2023-03-21 06:47:41 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:41 --> Input Class Initialized
INFO - 2023-03-21 06:47:41 --> Language Class Initialized
INFO - 2023-03-21 06:47:41 --> Loader Class Initialized
INFO - 2023-03-21 06:47:41 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:41 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:41 --> Total execution time: 0.0028
INFO - 2023-03-21 06:47:41 --> Config Class Initialized
INFO - 2023-03-21 06:47:41 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:41 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:41 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:41 --> URI Class Initialized
INFO - 2023-03-21 06:47:41 --> Router Class Initialized
INFO - 2023-03-21 06:47:41 --> Output Class Initialized
INFO - 2023-03-21 06:47:41 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:41 --> Input Class Initialized
INFO - 2023-03-21 06:47:41 --> Language Class Initialized
INFO - 2023-03-21 06:47:41 --> Loader Class Initialized
INFO - 2023-03-21 06:47:41 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:41 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:41 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:41 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:41 --> Total execution time: 0.0136
INFO - 2023-03-21 06:47:42 --> Config Class Initialized
INFO - 2023-03-21 06:47:42 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:42 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:42 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:42 --> URI Class Initialized
INFO - 2023-03-21 06:47:42 --> Router Class Initialized
INFO - 2023-03-21 06:47:42 --> Output Class Initialized
INFO - 2023-03-21 06:47:42 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:42 --> Input Class Initialized
INFO - 2023-03-21 06:47:42 --> Language Class Initialized
INFO - 2023-03-21 06:47:42 --> Loader Class Initialized
INFO - 2023-03-21 06:47:42 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:42 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:42 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:42 --> Model "Login_model" initialized
INFO - 2023-03-21 06:47:42 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:42 --> Total execution time: 0.0369
INFO - 2023-03-21 06:47:42 --> Config Class Initialized
INFO - 2023-03-21 06:47:42 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:42 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:42 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:42 --> URI Class Initialized
INFO - 2023-03-21 06:47:42 --> Router Class Initialized
INFO - 2023-03-21 06:47:42 --> Output Class Initialized
INFO - 2023-03-21 06:47:42 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:42 --> Input Class Initialized
INFO - 2023-03-21 06:47:42 --> Language Class Initialized
INFO - 2023-03-21 06:47:42 --> Loader Class Initialized
INFO - 2023-03-21 06:47:42 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:42 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:42 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:42 --> Model "Login_model" initialized
INFO - 2023-03-21 06:47:42 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:42 --> Total execution time: 0.0665
INFO - 2023-03-21 06:47:42 --> Config Class Initialized
INFO - 2023-03-21 06:47:43 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:43 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:43 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:43 --> URI Class Initialized
INFO - 2023-03-21 06:47:43 --> Router Class Initialized
INFO - 2023-03-21 06:47:43 --> Output Class Initialized
INFO - 2023-03-21 06:47:43 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:43 --> Input Class Initialized
INFO - 2023-03-21 06:47:43 --> Language Class Initialized
INFO - 2023-03-21 06:47:43 --> Loader Class Initialized
INFO - 2023-03-21 06:47:43 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:43 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:43 --> Total execution time: 0.0835
INFO - 2023-03-21 06:47:43 --> Config Class Initialized
INFO - 2023-03-21 06:47:43 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:43 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:43 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:43 --> URI Class Initialized
INFO - 2023-03-21 06:47:43 --> Router Class Initialized
INFO - 2023-03-21 06:47:43 --> Output Class Initialized
INFO - 2023-03-21 06:47:43 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:43 --> Input Class Initialized
INFO - 2023-03-21 06:47:43 --> Language Class Initialized
INFO - 2023-03-21 06:47:43 --> Loader Class Initialized
INFO - 2023-03-21 06:47:43 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:43 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:43 --> Total execution time: 0.0027
INFO - 2023-03-21 06:47:50 --> Config Class Initialized
INFO - 2023-03-21 06:47:50 --> Config Class Initialized
INFO - 2023-03-21 06:47:50 --> Hooks Class Initialized
INFO - 2023-03-21 06:47:50 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:50 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:50 --> Utf8 Class Initialized
DEBUG - 2023-03-21 06:47:50 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:50 --> URI Class Initialized
INFO - 2023-03-21 06:47:50 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:50 --> URI Class Initialized
INFO - 2023-03-21 06:47:50 --> Router Class Initialized
INFO - 2023-03-21 06:47:50 --> Router Class Initialized
INFO - 2023-03-21 06:47:50 --> Output Class Initialized
INFO - 2023-03-21 06:47:50 --> Output Class Initialized
INFO - 2023-03-21 06:47:50 --> Security Class Initialized
INFO - 2023-03-21 06:47:50 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-21 06:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:50 --> Input Class Initialized
INFO - 2023-03-21 06:47:50 --> Input Class Initialized
INFO - 2023-03-21 06:47:50 --> Language Class Initialized
INFO - 2023-03-21 06:47:50 --> Language Class Initialized
INFO - 2023-03-21 06:47:50 --> Loader Class Initialized
INFO - 2023-03-21 06:47:50 --> Loader Class Initialized
INFO - 2023-03-21 06:47:50 --> Controller Class Initialized
INFO - 2023-03-21 06:47:50 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 06:47:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:50 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:50 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:50 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:50 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:50 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:50 --> Total execution time: 0.0174
INFO - 2023-03-21 06:47:50 --> Config Class Initialized
INFO - 2023-03-21 06:47:50 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:50 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:50 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:50 --> URI Class Initialized
INFO - 2023-03-21 06:47:50 --> Router Class Initialized
INFO - 2023-03-21 06:47:50 --> Output Class Initialized
INFO - 2023-03-21 06:47:50 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:50 --> Input Class Initialized
INFO - 2023-03-21 06:47:50 --> Language Class Initialized
INFO - 2023-03-21 06:47:50 --> Loader Class Initialized
INFO - 2023-03-21 06:47:50 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:50 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:50 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:50 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:50 --> Total execution time: 0.0117
INFO - 2023-03-21 06:47:50 --> Config Class Initialized
INFO - 2023-03-21 06:47:50 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:50 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:50 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:50 --> URI Class Initialized
INFO - 2023-03-21 06:47:50 --> Router Class Initialized
INFO - 2023-03-21 06:47:50 --> Output Class Initialized
INFO - 2023-03-21 06:47:50 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:50 --> Input Class Initialized
INFO - 2023-03-21 06:47:50 --> Language Class Initialized
INFO - 2023-03-21 06:47:50 --> Loader Class Initialized
INFO - 2023-03-21 06:47:50 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:50 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:50 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:52 --> Config Class Initialized
INFO - 2023-03-21 06:47:52 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:52 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:52 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:52 --> URI Class Initialized
INFO - 2023-03-21 06:47:52 --> Router Class Initialized
INFO - 2023-03-21 06:47:52 --> Output Class Initialized
INFO - 2023-03-21 06:47:52 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:52 --> Input Class Initialized
INFO - 2023-03-21 06:47:52 --> Language Class Initialized
INFO - 2023-03-21 06:47:52 --> Loader Class Initialized
INFO - 2023-03-21 06:47:52 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:52 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:52 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:52 --> Config Class Initialized
INFO - 2023-03-21 06:47:52 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:52 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:52 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:52 --> URI Class Initialized
INFO - 2023-03-21 06:47:52 --> Router Class Initialized
INFO - 2023-03-21 06:47:52 --> Output Class Initialized
INFO - 2023-03-21 06:47:52 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:52 --> Input Class Initialized
INFO - 2023-03-21 06:47:52 --> Language Class Initialized
INFO - 2023-03-21 06:47:52 --> Loader Class Initialized
INFO - 2023-03-21 06:47:52 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:52 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:52 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:53 --> Config Class Initialized
INFO - 2023-03-21 06:47:53 --> Config Class Initialized
INFO - 2023-03-21 06:47:53 --> Hooks Class Initialized
INFO - 2023-03-21 06:47:53 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:53 --> UTF-8 Support Enabled
DEBUG - 2023-03-21 06:47:53 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:53 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:53 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:53 --> URI Class Initialized
INFO - 2023-03-21 06:47:53 --> URI Class Initialized
INFO - 2023-03-21 06:47:53 --> Router Class Initialized
INFO - 2023-03-21 06:47:53 --> Router Class Initialized
INFO - 2023-03-21 06:47:53 --> Output Class Initialized
INFO - 2023-03-21 06:47:53 --> Output Class Initialized
INFO - 2023-03-21 06:47:53 --> Security Class Initialized
INFO - 2023-03-21 06:47:53 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:53 --> Input Class Initialized
DEBUG - 2023-03-21 06:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:53 --> Input Class Initialized
INFO - 2023-03-21 06:47:53 --> Language Class Initialized
INFO - 2023-03-21 06:47:53 --> Language Class Initialized
INFO - 2023-03-21 06:47:53 --> Loader Class Initialized
INFO - 2023-03-21 06:47:53 --> Loader Class Initialized
INFO - 2023-03-21 06:47:53 --> Controller Class Initialized
INFO - 2023-03-21 06:47:53 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 06:47:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:53 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:53 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:53 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:53 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:53 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:53 --> Total execution time: 0.0332
INFO - 2023-03-21 06:47:54 --> Config Class Initialized
INFO - 2023-03-21 06:47:54 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:54 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:54 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:54 --> URI Class Initialized
INFO - 2023-03-21 06:47:54 --> Router Class Initialized
INFO - 2023-03-21 06:47:54 --> Output Class Initialized
INFO - 2023-03-21 06:47:54 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:54 --> Input Class Initialized
INFO - 2023-03-21 06:47:54 --> Language Class Initialized
INFO - 2023-03-21 06:47:54 --> Loader Class Initialized
INFO - 2023-03-21 06:47:54 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:54 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:54 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:54 --> Model "Login_model" initialized
INFO - 2023-03-21 06:47:54 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:54 --> Total execution time: 0.0398
INFO - 2023-03-21 06:47:54 --> Config Class Initialized
INFO - 2023-03-21 06:47:54 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:54 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:54 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:54 --> URI Class Initialized
INFO - 2023-03-21 06:47:54 --> Router Class Initialized
INFO - 2023-03-21 06:47:54 --> Output Class Initialized
INFO - 2023-03-21 06:47:54 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:54 --> Input Class Initialized
INFO - 2023-03-21 06:47:54 --> Language Class Initialized
INFO - 2023-03-21 06:47:54 --> Loader Class Initialized
INFO - 2023-03-21 06:47:54 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:54 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:54 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:54 --> Model "Login_model" initialized
INFO - 2023-03-21 06:47:54 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:54 --> Total execution time: 0.0224
INFO - 2023-03-21 06:47:54 --> Config Class Initialized
INFO - 2023-03-21 06:47:54 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:54 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:54 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:54 --> URI Class Initialized
INFO - 2023-03-21 06:47:54 --> Router Class Initialized
INFO - 2023-03-21 06:47:54 --> Output Class Initialized
INFO - 2023-03-21 06:47:54 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:54 --> Input Class Initialized
INFO - 2023-03-21 06:47:54 --> Language Class Initialized
INFO - 2023-03-21 06:47:54 --> Loader Class Initialized
INFO - 2023-03-21 06:47:54 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:54 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:54 --> Total execution time: 0.0421
INFO - 2023-03-21 06:47:54 --> Config Class Initialized
INFO - 2023-03-21 06:47:54 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:54 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:54 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:54 --> URI Class Initialized
INFO - 2023-03-21 06:47:54 --> Router Class Initialized
INFO - 2023-03-21 06:47:54 --> Output Class Initialized
INFO - 2023-03-21 06:47:54 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:54 --> Input Class Initialized
INFO - 2023-03-21 06:47:54 --> Language Class Initialized
INFO - 2023-03-21 06:47:54 --> Loader Class Initialized
INFO - 2023-03-21 06:47:54 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:54 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:54 --> Total execution time: 0.0023
INFO - 2023-03-21 06:47:55 --> Config Class Initialized
INFO - 2023-03-21 06:47:55 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:55 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:55 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:55 --> URI Class Initialized
INFO - 2023-03-21 06:47:55 --> Router Class Initialized
INFO - 2023-03-21 06:47:55 --> Output Class Initialized
INFO - 2023-03-21 06:47:55 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:55 --> Input Class Initialized
INFO - 2023-03-21 06:47:55 --> Language Class Initialized
INFO - 2023-03-21 06:47:55 --> Loader Class Initialized
INFO - 2023-03-21 06:47:55 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:55 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:55 --> Total execution time: 0.0059
INFO - 2023-03-21 06:47:55 --> Config Class Initialized
INFO - 2023-03-21 06:47:55 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:55 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:55 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:55 --> URI Class Initialized
INFO - 2023-03-21 06:47:55 --> Router Class Initialized
INFO - 2023-03-21 06:47:55 --> Output Class Initialized
INFO - 2023-03-21 06:47:55 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:55 --> Input Class Initialized
INFO - 2023-03-21 06:47:55 --> Language Class Initialized
INFO - 2023-03-21 06:47:55 --> Loader Class Initialized
INFO - 2023-03-21 06:47:55 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:55 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:55 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:55 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:55 --> Total execution time: 0.0125
INFO - 2023-03-21 06:47:56 --> Config Class Initialized
INFO - 2023-03-21 06:47:56 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:56 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:56 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:56 --> URI Class Initialized
INFO - 2023-03-21 06:47:56 --> Router Class Initialized
INFO - 2023-03-21 06:47:56 --> Output Class Initialized
INFO - 2023-03-21 06:47:56 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:56 --> Input Class Initialized
INFO - 2023-03-21 06:47:56 --> Language Class Initialized
INFO - 2023-03-21 06:47:56 --> Loader Class Initialized
INFO - 2023-03-21 06:47:56 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:56 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:56 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:56 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:56 --> Total execution time: 0.0150
INFO - 2023-03-21 06:47:56 --> Config Class Initialized
INFO - 2023-03-21 06:47:56 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:56 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:56 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:56 --> URI Class Initialized
INFO - 2023-03-21 06:47:56 --> Router Class Initialized
INFO - 2023-03-21 06:47:56 --> Output Class Initialized
INFO - 2023-03-21 06:47:56 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:56 --> Input Class Initialized
INFO - 2023-03-21 06:47:56 --> Language Class Initialized
INFO - 2023-03-21 06:47:56 --> Loader Class Initialized
INFO - 2023-03-21 06:47:56 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:56 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:56 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:56 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:56 --> Total execution time: 0.0118
INFO - 2023-03-21 06:47:57 --> Config Class Initialized
INFO - 2023-03-21 06:47:57 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:47:57 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:47:57 --> Utf8 Class Initialized
INFO - 2023-03-21 06:47:57 --> URI Class Initialized
INFO - 2023-03-21 06:47:57 --> Router Class Initialized
INFO - 2023-03-21 06:47:57 --> Output Class Initialized
INFO - 2023-03-21 06:47:57 --> Security Class Initialized
DEBUG - 2023-03-21 06:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:47:57 --> Input Class Initialized
INFO - 2023-03-21 06:47:57 --> Language Class Initialized
INFO - 2023-03-21 06:47:57 --> Loader Class Initialized
INFO - 2023-03-21 06:47:57 --> Controller Class Initialized
DEBUG - 2023-03-21 06:47:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:47:57 --> Database Driver Class Initialized
INFO - 2023-03-21 06:47:57 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:47:57 --> Final output sent to browser
DEBUG - 2023-03-21 06:47:57 --> Total execution time: 0.0151
INFO - 2023-03-21 06:48:00 --> Config Class Initialized
INFO - 2023-03-21 06:48:00 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:48:00 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:48:00 --> Utf8 Class Initialized
INFO - 2023-03-21 06:48:00 --> URI Class Initialized
INFO - 2023-03-21 06:48:00 --> Router Class Initialized
INFO - 2023-03-21 06:48:00 --> Output Class Initialized
INFO - 2023-03-21 06:48:00 --> Security Class Initialized
DEBUG - 2023-03-21 06:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:48:00 --> Input Class Initialized
INFO - 2023-03-21 06:48:00 --> Language Class Initialized
INFO - 2023-03-21 06:48:00 --> Loader Class Initialized
INFO - 2023-03-21 06:48:00 --> Controller Class Initialized
DEBUG - 2023-03-21 06:48:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:48:00 --> Final output sent to browser
DEBUG - 2023-03-21 06:48:00 --> Total execution time: 0.0027
INFO - 2023-03-21 06:48:00 --> Config Class Initialized
INFO - 2023-03-21 06:48:00 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:48:00 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:48:00 --> Utf8 Class Initialized
INFO - 2023-03-21 06:48:00 --> URI Class Initialized
INFO - 2023-03-21 06:48:00 --> Router Class Initialized
INFO - 2023-03-21 06:48:00 --> Output Class Initialized
INFO - 2023-03-21 06:48:00 --> Security Class Initialized
DEBUG - 2023-03-21 06:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:48:00 --> Input Class Initialized
INFO - 2023-03-21 06:48:00 --> Language Class Initialized
INFO - 2023-03-21 06:48:00 --> Loader Class Initialized
INFO - 2023-03-21 06:48:00 --> Controller Class Initialized
DEBUG - 2023-03-21 06:48:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:48:00 --> Database Driver Class Initialized
INFO - 2023-03-21 06:48:00 --> Model "Login_model" initialized
INFO - 2023-03-21 06:48:00 --> Final output sent to browser
DEBUG - 2023-03-21 06:48:00 --> Total execution time: 0.0167
INFO - 2023-03-21 06:48:02 --> Config Class Initialized
INFO - 2023-03-21 06:48:02 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:48:02 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:48:02 --> Utf8 Class Initialized
INFO - 2023-03-21 06:48:02 --> URI Class Initialized
INFO - 2023-03-21 06:48:02 --> Router Class Initialized
INFO - 2023-03-21 06:48:02 --> Output Class Initialized
INFO - 2023-03-21 06:48:02 --> Security Class Initialized
DEBUG - 2023-03-21 06:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:48:02 --> Input Class Initialized
INFO - 2023-03-21 06:48:02 --> Language Class Initialized
INFO - 2023-03-21 06:48:02 --> Loader Class Initialized
INFO - 2023-03-21 06:48:02 --> Controller Class Initialized
DEBUG - 2023-03-21 06:48:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:48:02 --> Database Driver Class Initialized
INFO - 2023-03-21 06:48:02 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:48:02 --> Final output sent to browser
DEBUG - 2023-03-21 06:48:02 --> Total execution time: 0.1876
INFO - 2023-03-21 06:48:02 --> Config Class Initialized
INFO - 2023-03-21 06:48:02 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:48:02 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:48:02 --> Utf8 Class Initialized
INFO - 2023-03-21 06:48:02 --> URI Class Initialized
INFO - 2023-03-21 06:48:02 --> Router Class Initialized
INFO - 2023-03-21 06:48:02 --> Output Class Initialized
INFO - 2023-03-21 06:48:02 --> Security Class Initialized
DEBUG - 2023-03-21 06:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:48:02 --> Input Class Initialized
INFO - 2023-03-21 06:48:02 --> Language Class Initialized
INFO - 2023-03-21 06:48:02 --> Loader Class Initialized
INFO - 2023-03-21 06:48:02 --> Controller Class Initialized
DEBUG - 2023-03-21 06:48:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:48:02 --> Database Driver Class Initialized
INFO - 2023-03-21 06:48:02 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:48:02 --> Final output sent to browser
DEBUG - 2023-03-21 06:48:02 --> Total execution time: 0.0417
INFO - 2023-03-21 06:48:04 --> Config Class Initialized
INFO - 2023-03-21 06:48:04 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:48:04 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:48:04 --> Utf8 Class Initialized
INFO - 2023-03-21 06:48:04 --> URI Class Initialized
INFO - 2023-03-21 06:48:04 --> Router Class Initialized
INFO - 2023-03-21 06:48:04 --> Output Class Initialized
INFO - 2023-03-21 06:48:04 --> Security Class Initialized
DEBUG - 2023-03-21 06:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:48:04 --> Input Class Initialized
INFO - 2023-03-21 06:48:04 --> Language Class Initialized
INFO - 2023-03-21 06:48:04 --> Loader Class Initialized
INFO - 2023-03-21 06:48:04 --> Controller Class Initialized
DEBUG - 2023-03-21 06:48:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:48:04 --> Final output sent to browser
DEBUG - 2023-03-21 06:48:04 --> Total execution time: 0.0040
INFO - 2023-03-21 06:48:04 --> Config Class Initialized
INFO - 2023-03-21 06:48:04 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:48:04 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:48:04 --> Utf8 Class Initialized
INFO - 2023-03-21 06:48:04 --> URI Class Initialized
INFO - 2023-03-21 06:48:04 --> Router Class Initialized
INFO - 2023-03-21 06:48:04 --> Output Class Initialized
INFO - 2023-03-21 06:48:04 --> Security Class Initialized
DEBUG - 2023-03-21 06:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:48:04 --> Input Class Initialized
INFO - 2023-03-21 06:48:04 --> Language Class Initialized
INFO - 2023-03-21 06:48:04 --> Loader Class Initialized
INFO - 2023-03-21 06:48:04 --> Controller Class Initialized
DEBUG - 2023-03-21 06:48:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:48:04 --> Database Driver Class Initialized
INFO - 2023-03-21 06:48:04 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:48:04 --> Final output sent to browser
DEBUG - 2023-03-21 06:48:04 --> Total execution time: 0.0514
INFO - 2023-03-21 06:56:50 --> Config Class Initialized
INFO - 2023-03-21 06:56:50 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:56:50 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:56:50 --> Utf8 Class Initialized
INFO - 2023-03-21 06:56:50 --> URI Class Initialized
INFO - 2023-03-21 06:56:50 --> Router Class Initialized
INFO - 2023-03-21 06:56:50 --> Output Class Initialized
INFO - 2023-03-21 06:56:50 --> Security Class Initialized
DEBUG - 2023-03-21 06:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:56:50 --> Input Class Initialized
INFO - 2023-03-21 06:56:50 --> Language Class Initialized
INFO - 2023-03-21 06:56:50 --> Loader Class Initialized
INFO - 2023-03-21 06:56:50 --> Controller Class Initialized
DEBUG - 2023-03-21 06:56:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:56:50 --> Database Driver Class Initialized
INFO - 2023-03-21 06:56:50 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:56:50 --> Final output sent to browser
DEBUG - 2023-03-21 06:56:50 --> Total execution time: 0.0252
INFO - 2023-03-21 06:56:50 --> Config Class Initialized
INFO - 2023-03-21 06:56:50 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:56:51 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:56:51 --> Utf8 Class Initialized
INFO - 2023-03-21 06:56:51 --> URI Class Initialized
INFO - 2023-03-21 06:56:51 --> Router Class Initialized
INFO - 2023-03-21 06:56:51 --> Output Class Initialized
INFO - 2023-03-21 06:56:51 --> Security Class Initialized
DEBUG - 2023-03-21 06:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:56:51 --> Input Class Initialized
INFO - 2023-03-21 06:56:51 --> Language Class Initialized
INFO - 2023-03-21 06:56:51 --> Loader Class Initialized
INFO - 2023-03-21 06:56:51 --> Controller Class Initialized
DEBUG - 2023-03-21 06:56:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:56:51 --> Database Driver Class Initialized
INFO - 2023-03-21 06:56:51 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:56:51 --> Final output sent to browser
DEBUG - 2023-03-21 06:56:51 --> Total execution time: 0.0563
INFO - 2023-03-21 06:56:52 --> Config Class Initialized
INFO - 2023-03-21 06:56:52 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:56:52 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:56:52 --> Utf8 Class Initialized
INFO - 2023-03-21 06:56:52 --> URI Class Initialized
INFO - 2023-03-21 06:56:52 --> Router Class Initialized
INFO - 2023-03-21 06:56:52 --> Output Class Initialized
INFO - 2023-03-21 06:56:52 --> Security Class Initialized
DEBUG - 2023-03-21 06:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:56:52 --> Input Class Initialized
INFO - 2023-03-21 06:56:52 --> Language Class Initialized
INFO - 2023-03-21 06:56:52 --> Loader Class Initialized
INFO - 2023-03-21 06:56:52 --> Controller Class Initialized
DEBUG - 2023-03-21 06:56:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:56:52 --> Final output sent to browser
DEBUG - 2023-03-21 06:56:52 --> Total execution time: 0.0041
INFO - 2023-03-21 06:56:52 --> Config Class Initialized
INFO - 2023-03-21 06:56:52 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:56:52 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:56:52 --> Utf8 Class Initialized
INFO - 2023-03-21 06:56:52 --> URI Class Initialized
INFO - 2023-03-21 06:56:52 --> Router Class Initialized
INFO - 2023-03-21 06:56:52 --> Output Class Initialized
INFO - 2023-03-21 06:56:52 --> Security Class Initialized
DEBUG - 2023-03-21 06:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:56:52 --> Input Class Initialized
INFO - 2023-03-21 06:56:52 --> Language Class Initialized
INFO - 2023-03-21 06:56:52 --> Loader Class Initialized
INFO - 2023-03-21 06:56:52 --> Controller Class Initialized
DEBUG - 2023-03-21 06:56:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:56:52 --> Database Driver Class Initialized
INFO - 2023-03-21 06:56:52 --> Model "Login_model" initialized
INFO - 2023-03-21 06:56:52 --> Database Driver Class Initialized
INFO - 2023-03-21 06:56:52 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:56:52 --> Final output sent to browser
DEBUG - 2023-03-21 06:56:52 --> Total execution time: 0.0261
INFO - 2023-03-21 06:56:52 --> Config Class Initialized
INFO - 2023-03-21 06:56:52 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:56:52 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:56:52 --> Utf8 Class Initialized
INFO - 2023-03-21 06:56:52 --> URI Class Initialized
INFO - 2023-03-21 06:56:52 --> Router Class Initialized
INFO - 2023-03-21 06:56:52 --> Output Class Initialized
INFO - 2023-03-21 06:56:52 --> Security Class Initialized
DEBUG - 2023-03-21 06:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:56:52 --> Input Class Initialized
INFO - 2023-03-21 06:56:52 --> Language Class Initialized
INFO - 2023-03-21 06:56:52 --> Loader Class Initialized
INFO - 2023-03-21 06:56:52 --> Controller Class Initialized
DEBUG - 2023-03-21 06:56:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:56:52 --> Final output sent to browser
DEBUG - 2023-03-21 06:56:52 --> Total execution time: 0.0427
INFO - 2023-03-21 06:56:52 --> Config Class Initialized
INFO - 2023-03-21 06:56:52 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:56:52 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:56:52 --> Utf8 Class Initialized
INFO - 2023-03-21 06:56:52 --> URI Class Initialized
INFO - 2023-03-21 06:56:52 --> Router Class Initialized
INFO - 2023-03-21 06:56:52 --> Output Class Initialized
INFO - 2023-03-21 06:56:52 --> Security Class Initialized
DEBUG - 2023-03-21 06:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:56:52 --> Input Class Initialized
INFO - 2023-03-21 06:56:52 --> Language Class Initialized
INFO - 2023-03-21 06:56:52 --> Loader Class Initialized
INFO - 2023-03-21 06:56:52 --> Controller Class Initialized
DEBUG - 2023-03-21 06:56:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:56:52 --> Database Driver Class Initialized
INFO - 2023-03-21 06:56:52 --> Model "Login_model" initialized
INFO - 2023-03-21 06:56:52 --> Database Driver Class Initialized
INFO - 2023-03-21 06:56:52 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:56:52 --> Final output sent to browser
DEBUG - 2023-03-21 06:56:52 --> Total execution time: 0.0259
INFO - 2023-03-21 06:56:54 --> Config Class Initialized
INFO - 2023-03-21 06:56:54 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:56:54 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:56:54 --> Utf8 Class Initialized
INFO - 2023-03-21 06:56:54 --> URI Class Initialized
INFO - 2023-03-21 06:56:54 --> Router Class Initialized
INFO - 2023-03-21 06:56:54 --> Output Class Initialized
INFO - 2023-03-21 06:56:54 --> Security Class Initialized
DEBUG - 2023-03-21 06:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:56:54 --> Input Class Initialized
INFO - 2023-03-21 06:56:54 --> Language Class Initialized
INFO - 2023-03-21 06:56:54 --> Loader Class Initialized
INFO - 2023-03-21 06:56:54 --> Controller Class Initialized
DEBUG - 2023-03-21 06:56:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:56:54 --> Database Driver Class Initialized
INFO - 2023-03-21 06:56:54 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:56:54 --> Database Driver Class Initialized
INFO - 2023-03-21 06:56:54 --> Model "Login_model" initialized
INFO - 2023-03-21 06:56:54 --> Final output sent to browser
DEBUG - 2023-03-21 06:56:54 --> Total execution time: 0.0827
INFO - 2023-03-21 06:56:54 --> Config Class Initialized
INFO - 2023-03-21 06:56:54 --> Hooks Class Initialized
DEBUG - 2023-03-21 06:56:54 --> UTF-8 Support Enabled
INFO - 2023-03-21 06:56:54 --> Utf8 Class Initialized
INFO - 2023-03-21 06:56:54 --> URI Class Initialized
INFO - 2023-03-21 06:56:54 --> Router Class Initialized
INFO - 2023-03-21 06:56:54 --> Output Class Initialized
INFO - 2023-03-21 06:56:54 --> Security Class Initialized
DEBUG - 2023-03-21 06:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 06:56:54 --> Input Class Initialized
INFO - 2023-03-21 06:56:54 --> Language Class Initialized
INFO - 2023-03-21 06:56:54 --> Loader Class Initialized
INFO - 2023-03-21 06:56:54 --> Controller Class Initialized
DEBUG - 2023-03-21 06:56:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 06:56:54 --> Database Driver Class Initialized
INFO - 2023-03-21 06:56:54 --> Model "Cluster_model" initialized
INFO - 2023-03-21 06:56:54 --> Database Driver Class Initialized
INFO - 2023-03-21 06:56:54 --> Model "Login_model" initialized
INFO - 2023-03-21 06:56:54 --> Final output sent to browser
DEBUG - 2023-03-21 06:56:54 --> Total execution time: 0.0997
INFO - 2023-03-21 07:18:54 --> Config Class Initialized
INFO - 2023-03-21 07:18:54 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:18:54 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:18:54 --> Utf8 Class Initialized
INFO - 2023-03-21 07:18:54 --> URI Class Initialized
INFO - 2023-03-21 07:18:54 --> Router Class Initialized
INFO - 2023-03-21 07:18:54 --> Output Class Initialized
INFO - 2023-03-21 07:18:54 --> Security Class Initialized
DEBUG - 2023-03-21 07:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:18:54 --> Input Class Initialized
INFO - 2023-03-21 07:18:54 --> Language Class Initialized
INFO - 2023-03-21 07:18:54 --> Loader Class Initialized
INFO - 2023-03-21 07:18:54 --> Controller Class Initialized
DEBUG - 2023-03-21 07:18:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:18:54 --> Database Driver Class Initialized
INFO - 2023-03-21 07:18:54 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:18:54 --> Final output sent to browser
INFO - 2023-03-21 07:18:54 --> Config Class Initialized
DEBUG - 2023-03-21 07:18:55 --> Total execution time: 0.0994
INFO - 2023-03-21 07:18:55 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:18:55 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:18:55 --> Utf8 Class Initialized
INFO - 2023-03-21 07:18:55 --> URI Class Initialized
INFO - 2023-03-21 07:18:55 --> Router Class Initialized
INFO - 2023-03-21 07:18:55 --> Output Class Initialized
INFO - 2023-03-21 07:18:55 --> Security Class Initialized
DEBUG - 2023-03-21 07:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:18:55 --> Input Class Initialized
INFO - 2023-03-21 07:18:55 --> Language Class Initialized
INFO - 2023-03-21 07:18:55 --> Loader Class Initialized
INFO - 2023-03-21 07:18:55 --> Controller Class Initialized
DEBUG - 2023-03-21 07:18:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:18:55 --> Database Driver Class Initialized
INFO - 2023-03-21 07:18:55 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:18:55 --> Final output sent to browser
DEBUG - 2023-03-21 07:18:55 --> Total execution time: 0.0814
INFO - 2023-03-21 07:18:59 --> Config Class Initialized
INFO - 2023-03-21 07:18:59 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:18:59 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:18:59 --> Utf8 Class Initialized
INFO - 2023-03-21 07:18:59 --> URI Class Initialized
INFO - 2023-03-21 07:18:59 --> Router Class Initialized
INFO - 2023-03-21 07:18:59 --> Output Class Initialized
INFO - 2023-03-21 07:18:59 --> Security Class Initialized
DEBUG - 2023-03-21 07:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:18:59 --> Input Class Initialized
INFO - 2023-03-21 07:18:59 --> Language Class Initialized
INFO - 2023-03-21 07:18:59 --> Loader Class Initialized
INFO - 2023-03-21 07:18:59 --> Controller Class Initialized
DEBUG - 2023-03-21 07:18:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:18:59 --> Database Driver Class Initialized
INFO - 2023-03-21 07:18:59 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:18:59 --> Final output sent to browser
DEBUG - 2023-03-21 07:18:59 --> Total execution time: 0.0164
INFO - 2023-03-21 07:18:59 --> Config Class Initialized
INFO - 2023-03-21 07:18:59 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:18:59 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:18:59 --> Utf8 Class Initialized
INFO - 2023-03-21 07:18:59 --> URI Class Initialized
INFO - 2023-03-21 07:18:59 --> Router Class Initialized
INFO - 2023-03-21 07:18:59 --> Output Class Initialized
INFO - 2023-03-21 07:18:59 --> Security Class Initialized
DEBUG - 2023-03-21 07:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:18:59 --> Input Class Initialized
INFO - 2023-03-21 07:18:59 --> Language Class Initialized
INFO - 2023-03-21 07:18:59 --> Loader Class Initialized
INFO - 2023-03-21 07:18:59 --> Controller Class Initialized
DEBUG - 2023-03-21 07:18:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:18:59 --> Database Driver Class Initialized
INFO - 2023-03-21 07:18:59 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:18:59 --> Final output sent to browser
DEBUG - 2023-03-21 07:18:59 --> Total execution time: 0.0521
INFO - 2023-03-21 07:44:10 --> Config Class Initialized
INFO - 2023-03-21 07:44:10 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:44:10 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:44:10 --> Utf8 Class Initialized
INFO - 2023-03-21 07:44:10 --> URI Class Initialized
INFO - 2023-03-21 07:44:10 --> Router Class Initialized
INFO - 2023-03-21 07:44:10 --> Output Class Initialized
INFO - 2023-03-21 07:44:10 --> Security Class Initialized
DEBUG - 2023-03-21 07:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:44:10 --> Input Class Initialized
INFO - 2023-03-21 07:44:10 --> Language Class Initialized
INFO - 2023-03-21 07:44:10 --> Loader Class Initialized
INFO - 2023-03-21 07:44:10 --> Controller Class Initialized
DEBUG - 2023-03-21 07:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:44:10 --> Database Driver Class Initialized
INFO - 2023-03-21 07:44:10 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:44:10 --> Final output sent to browser
DEBUG - 2023-03-21 07:44:10 --> Total execution time: 0.0594
INFO - 2023-03-21 07:44:10 --> Config Class Initialized
INFO - 2023-03-21 07:44:10 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:44:10 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:44:10 --> Utf8 Class Initialized
INFO - 2023-03-21 07:44:10 --> URI Class Initialized
INFO - 2023-03-21 07:44:10 --> Router Class Initialized
INFO - 2023-03-21 07:44:10 --> Output Class Initialized
INFO - 2023-03-21 07:44:10 --> Security Class Initialized
DEBUG - 2023-03-21 07:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:44:10 --> Input Class Initialized
INFO - 2023-03-21 07:44:10 --> Language Class Initialized
INFO - 2023-03-21 07:44:10 --> Loader Class Initialized
INFO - 2023-03-21 07:44:10 --> Controller Class Initialized
DEBUG - 2023-03-21 07:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:44:10 --> Database Driver Class Initialized
INFO - 2023-03-21 07:44:10 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:44:10 --> Final output sent to browser
DEBUG - 2023-03-21 07:44:10 --> Total execution time: 0.0432
INFO - 2023-03-21 07:44:12 --> Config Class Initialized
INFO - 2023-03-21 07:44:12 --> Hooks Class Initialized
INFO - 2023-03-21 07:44:12 --> Config Class Initialized
INFO - 2023-03-21 07:44:12 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:44:12 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:44:12 --> Utf8 Class Initialized
DEBUG - 2023-03-21 07:44:12 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:44:12 --> URI Class Initialized
INFO - 2023-03-21 07:44:12 --> Utf8 Class Initialized
INFO - 2023-03-21 07:44:12 --> Router Class Initialized
INFO - 2023-03-21 07:44:12 --> URI Class Initialized
INFO - 2023-03-21 07:44:12 --> Output Class Initialized
INFO - 2023-03-21 07:44:12 --> Router Class Initialized
INFO - 2023-03-21 07:44:12 --> Security Class Initialized
INFO - 2023-03-21 07:44:12 --> Output Class Initialized
DEBUG - 2023-03-21 07:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:44:12 --> Input Class Initialized
INFO - 2023-03-21 07:44:12 --> Security Class Initialized
INFO - 2023-03-21 07:44:12 --> Language Class Initialized
DEBUG - 2023-03-21 07:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:44:12 --> Input Class Initialized
INFO - 2023-03-21 07:44:12 --> Language Class Initialized
INFO - 2023-03-21 07:44:12 --> Loader Class Initialized
INFO - 2023-03-21 07:44:12 --> Controller Class Initialized
DEBUG - 2023-03-21 07:44:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:44:12 --> Database Driver Class Initialized
INFO - 2023-03-21 07:44:12 --> Loader Class Initialized
INFO - 2023-03-21 07:44:12 --> Controller Class Initialized
DEBUG - 2023-03-21 07:44:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:44:12 --> Final output sent to browser
DEBUG - 2023-03-21 07:44:12 --> Total execution time: 0.0089
INFO - 2023-03-21 07:44:12 --> Config Class Initialized
INFO - 2023-03-21 07:44:12 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:44:12 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:44:12 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:44:12 --> Utf8 Class Initialized
INFO - 2023-03-21 07:44:12 --> URI Class Initialized
INFO - 2023-03-21 07:44:12 --> Router Class Initialized
INFO - 2023-03-21 07:44:12 --> Output Class Initialized
INFO - 2023-03-21 07:44:12 --> Security Class Initialized
DEBUG - 2023-03-21 07:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:44:12 --> Input Class Initialized
INFO - 2023-03-21 07:44:12 --> Language Class Initialized
INFO - 2023-03-21 07:44:12 --> Loader Class Initialized
INFO - 2023-03-21 07:44:12 --> Controller Class Initialized
DEBUG - 2023-03-21 07:44:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:44:12 --> Database Driver Class Initialized
INFO - 2023-03-21 07:44:12 --> Final output sent to browser
DEBUG - 2023-03-21 07:44:12 --> Total execution time: 0.0546
INFO - 2023-03-21 07:44:12 --> Config Class Initialized
INFO - 2023-03-21 07:44:12 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:44:12 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:44:12 --> Utf8 Class Initialized
INFO - 2023-03-21 07:44:12 --> URI Class Initialized
INFO - 2023-03-21 07:44:12 --> Router Class Initialized
INFO - 2023-03-21 07:44:12 --> Output Class Initialized
INFO - 2023-03-21 07:44:12 --> Security Class Initialized
DEBUG - 2023-03-21 07:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:44:12 --> Input Class Initialized
INFO - 2023-03-21 07:44:12 --> Model "Login_model" initialized
INFO - 2023-03-21 07:44:12 --> Language Class Initialized
INFO - 2023-03-21 07:44:12 --> Loader Class Initialized
INFO - 2023-03-21 07:44:12 --> Controller Class Initialized
DEBUG - 2023-03-21 07:44:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:44:12 --> Database Driver Class Initialized
INFO - 2023-03-21 07:44:12 --> Database Driver Class Initialized
INFO - 2023-03-21 07:44:12 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:44:12 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:44:12 --> Final output sent to browser
DEBUG - 2023-03-21 07:44:12 --> Total execution time: 0.0632
INFO - 2023-03-21 07:44:12 --> Final output sent to browser
DEBUG - 2023-03-21 07:44:12 --> Total execution time: 0.0170
INFO - 2023-03-21 07:47:41 --> Config Class Initialized
INFO - 2023-03-21 07:47:41 --> Config Class Initialized
INFO - 2023-03-21 07:47:41 --> Hooks Class Initialized
INFO - 2023-03-21 07:47:41 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:47:41 --> UTF-8 Support Enabled
DEBUG - 2023-03-21 07:47:41 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:47:41 --> Utf8 Class Initialized
INFO - 2023-03-21 07:47:41 --> Utf8 Class Initialized
INFO - 2023-03-21 07:47:41 --> URI Class Initialized
INFO - 2023-03-21 07:47:41 --> URI Class Initialized
INFO - 2023-03-21 07:47:41 --> Router Class Initialized
INFO - 2023-03-21 07:47:41 --> Router Class Initialized
INFO - 2023-03-21 07:47:41 --> Output Class Initialized
INFO - 2023-03-21 07:47:41 --> Output Class Initialized
INFO - 2023-03-21 07:47:41 --> Security Class Initialized
INFO - 2023-03-21 07:47:41 --> Security Class Initialized
DEBUG - 2023-03-21 07:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-21 07:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:47:41 --> Input Class Initialized
INFO - 2023-03-21 07:47:41 --> Input Class Initialized
INFO - 2023-03-21 07:47:41 --> Language Class Initialized
INFO - 2023-03-21 07:47:41 --> Language Class Initialized
INFO - 2023-03-21 07:47:41 --> Loader Class Initialized
INFO - 2023-03-21 07:47:41 --> Loader Class Initialized
INFO - 2023-03-21 07:47:41 --> Controller Class Initialized
INFO - 2023-03-21 07:47:41 --> Controller Class Initialized
DEBUG - 2023-03-21 07:47:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 07:47:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:47:41 --> Final output sent to browser
DEBUG - 2023-03-21 07:47:41 --> Total execution time: 0.0848
INFO - 2023-03-21 07:47:41 --> Database Driver Class Initialized
INFO - 2023-03-21 07:47:41 --> Config Class Initialized
INFO - 2023-03-21 07:47:41 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:47:41 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:47:41 --> Utf8 Class Initialized
INFO - 2023-03-21 07:47:41 --> URI Class Initialized
INFO - 2023-03-21 07:47:41 --> Router Class Initialized
INFO - 2023-03-21 07:47:41 --> Output Class Initialized
INFO - 2023-03-21 07:47:41 --> Security Class Initialized
DEBUG - 2023-03-21 07:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:47:41 --> Input Class Initialized
INFO - 2023-03-21 07:47:41 --> Language Class Initialized
INFO - 2023-03-21 07:47:41 --> Loader Class Initialized
INFO - 2023-03-21 07:47:41 --> Controller Class Initialized
DEBUG - 2023-03-21 07:47:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:47:41 --> Database Driver Class Initialized
INFO - 2023-03-21 07:47:41 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:47:41 --> Final output sent to browser
DEBUG - 2023-03-21 07:47:41 --> Total execution time: 0.0987
INFO - 2023-03-21 07:47:41 --> Model "Login_model" initialized
INFO - 2023-03-21 07:47:41 --> Database Driver Class Initialized
INFO - 2023-03-21 07:47:41 --> Config Class Initialized
INFO - 2023-03-21 07:47:41 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:47:41 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:47:41 --> Utf8 Class Initialized
INFO - 2023-03-21 07:47:41 --> URI Class Initialized
INFO - 2023-03-21 07:47:41 --> Router Class Initialized
INFO - 2023-03-21 07:47:41 --> Output Class Initialized
INFO - 2023-03-21 07:47:41 --> Security Class Initialized
DEBUG - 2023-03-21 07:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:47:41 --> Input Class Initialized
INFO - 2023-03-21 07:47:41 --> Language Class Initialized
INFO - 2023-03-21 07:47:41 --> Loader Class Initialized
INFO - 2023-03-21 07:47:41 --> Controller Class Initialized
DEBUG - 2023-03-21 07:47:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:47:41 --> Database Driver Class Initialized
INFO - 2023-03-21 07:47:41 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:47:41 --> Final output sent to browser
INFO - 2023-03-21 07:47:41 --> Model "Cluster_model" initialized
DEBUG - 2023-03-21 07:47:41 --> Total execution time: 0.0276
INFO - 2023-03-21 07:47:41 --> Final output sent to browser
DEBUG - 2023-03-21 07:47:41 --> Total execution time: 0.0655
INFO - 2023-03-21 07:49:27 --> Config Class Initialized
INFO - 2023-03-21 07:49:27 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:49:27 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:49:27 --> Utf8 Class Initialized
INFO - 2023-03-21 07:49:27 --> URI Class Initialized
INFO - 2023-03-21 07:49:27 --> Router Class Initialized
INFO - 2023-03-21 07:49:27 --> Output Class Initialized
INFO - 2023-03-21 07:49:27 --> Security Class Initialized
DEBUG - 2023-03-21 07:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:49:27 --> Input Class Initialized
INFO - 2023-03-21 07:49:27 --> Language Class Initialized
INFO - 2023-03-21 07:49:27 --> Loader Class Initialized
INFO - 2023-03-21 07:49:27 --> Controller Class Initialized
DEBUG - 2023-03-21 07:49:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:49:27 --> Database Driver Class Initialized
INFO - 2023-03-21 07:49:27 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:49:27 --> Final output sent to browser
DEBUG - 2023-03-21 07:49:27 --> Total execution time: 0.0470
INFO - 2023-03-21 07:49:27 --> Config Class Initialized
INFO - 2023-03-21 07:49:27 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:49:27 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:49:27 --> Utf8 Class Initialized
INFO - 2023-03-21 07:49:27 --> URI Class Initialized
INFO - 2023-03-21 07:49:27 --> Router Class Initialized
INFO - 2023-03-21 07:49:27 --> Output Class Initialized
INFO - 2023-03-21 07:49:27 --> Security Class Initialized
DEBUG - 2023-03-21 07:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:49:27 --> Input Class Initialized
INFO - 2023-03-21 07:49:27 --> Language Class Initialized
INFO - 2023-03-21 07:49:27 --> Loader Class Initialized
INFO - 2023-03-21 07:49:27 --> Controller Class Initialized
DEBUG - 2023-03-21 07:49:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:49:27 --> Database Driver Class Initialized
INFO - 2023-03-21 07:49:27 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:49:27 --> Final output sent to browser
DEBUG - 2023-03-21 07:49:27 --> Total execution time: 0.0907
INFO - 2023-03-21 07:51:38 --> Config Class Initialized
INFO - 2023-03-21 07:51:38 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:51:38 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:51:38 --> Utf8 Class Initialized
INFO - 2023-03-21 07:51:38 --> URI Class Initialized
INFO - 2023-03-21 07:51:38 --> Router Class Initialized
INFO - 2023-03-21 07:51:38 --> Output Class Initialized
INFO - 2023-03-21 07:51:38 --> Security Class Initialized
DEBUG - 2023-03-21 07:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:51:38 --> Input Class Initialized
INFO - 2023-03-21 07:51:38 --> Language Class Initialized
INFO - 2023-03-21 07:51:38 --> Loader Class Initialized
INFO - 2023-03-21 07:51:38 --> Controller Class Initialized
DEBUG - 2023-03-21 07:51:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:51:38 --> Database Driver Class Initialized
INFO - 2023-03-21 07:51:38 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:51:38 --> Final output sent to browser
DEBUG - 2023-03-21 07:51:38 --> Total execution time: 0.0196
INFO - 2023-03-21 07:51:38 --> Config Class Initialized
INFO - 2023-03-21 07:51:38 --> Hooks Class Initialized
DEBUG - 2023-03-21 07:51:38 --> UTF-8 Support Enabled
INFO - 2023-03-21 07:51:38 --> Utf8 Class Initialized
INFO - 2023-03-21 07:51:38 --> URI Class Initialized
INFO - 2023-03-21 07:51:38 --> Router Class Initialized
INFO - 2023-03-21 07:51:38 --> Output Class Initialized
INFO - 2023-03-21 07:51:38 --> Security Class Initialized
DEBUG - 2023-03-21 07:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 07:51:38 --> Input Class Initialized
INFO - 2023-03-21 07:51:38 --> Language Class Initialized
INFO - 2023-03-21 07:51:38 --> Loader Class Initialized
INFO - 2023-03-21 07:51:38 --> Controller Class Initialized
DEBUG - 2023-03-21 07:51:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 07:51:38 --> Database Driver Class Initialized
INFO - 2023-03-21 07:51:38 --> Model "Cluster_model" initialized
INFO - 2023-03-21 07:51:38 --> Final output sent to browser
DEBUG - 2023-03-21 07:51:38 --> Total execution time: 0.0543
INFO - 2023-03-21 08:04:20 --> Config Class Initialized
INFO - 2023-03-21 08:04:20 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:04:20 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:04:20 --> Utf8 Class Initialized
INFO - 2023-03-21 08:04:20 --> URI Class Initialized
INFO - 2023-03-21 08:04:20 --> Router Class Initialized
INFO - 2023-03-21 08:04:20 --> Output Class Initialized
INFO - 2023-03-21 08:04:20 --> Security Class Initialized
DEBUG - 2023-03-21 08:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:04:20 --> Input Class Initialized
INFO - 2023-03-21 08:04:20 --> Language Class Initialized
INFO - 2023-03-21 08:04:20 --> Loader Class Initialized
INFO - 2023-03-21 08:04:20 --> Controller Class Initialized
DEBUG - 2023-03-21 08:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:04:20 --> Database Driver Class Initialized
INFO - 2023-03-21 08:04:20 --> Database Driver Class Initialized
INFO - 2023-03-21 08:04:20 --> Model "Login_model" initialized
INFO - 2023-03-21 08:04:20 --> Final output sent to browser
DEBUG - 2023-03-21 08:04:20 --> Total execution time: 0.0281
INFO - 2023-03-21 08:04:20 --> Config Class Initialized
INFO - 2023-03-21 08:04:20 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:04:20 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:04:20 --> Utf8 Class Initialized
INFO - 2023-03-21 08:04:20 --> URI Class Initialized
INFO - 2023-03-21 08:04:20 --> Router Class Initialized
INFO - 2023-03-21 08:04:20 --> Output Class Initialized
INFO - 2023-03-21 08:04:20 --> Security Class Initialized
DEBUG - 2023-03-21 08:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:04:20 --> Input Class Initialized
INFO - 2023-03-21 08:04:20 --> Language Class Initialized
INFO - 2023-03-21 08:04:20 --> Loader Class Initialized
INFO - 2023-03-21 08:04:20 --> Controller Class Initialized
DEBUG - 2023-03-21 08:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:04:20 --> Database Driver Class Initialized
INFO - 2023-03-21 08:04:20 --> Database Driver Class Initialized
INFO - 2023-03-21 08:04:20 --> Model "Login_model" initialized
INFO - 2023-03-21 08:04:20 --> Final output sent to browser
DEBUG - 2023-03-21 08:04:20 --> Total execution time: 0.0635
INFO - 2023-03-21 08:04:23 --> Config Class Initialized
INFO - 2023-03-21 08:04:23 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:04:23 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:04:23 --> Utf8 Class Initialized
INFO - 2023-03-21 08:04:23 --> URI Class Initialized
INFO - 2023-03-21 08:04:23 --> Router Class Initialized
INFO - 2023-03-21 08:04:23 --> Output Class Initialized
INFO - 2023-03-21 08:04:23 --> Security Class Initialized
DEBUG - 2023-03-21 08:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:04:23 --> Input Class Initialized
INFO - 2023-03-21 08:04:23 --> Language Class Initialized
INFO - 2023-03-21 08:04:23 --> Loader Class Initialized
INFO - 2023-03-21 08:04:23 --> Controller Class Initialized
DEBUG - 2023-03-21 08:04:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:04:23 --> Database Driver Class Initialized
INFO - 2023-03-21 08:04:23 --> Database Driver Class Initialized
INFO - 2023-03-21 08:04:23 --> Model "Login_model" initialized
INFO - 2023-03-21 08:04:23 --> Final output sent to browser
DEBUG - 2023-03-21 08:04:23 --> Total execution time: 0.0288
INFO - 2023-03-21 08:04:23 --> Config Class Initialized
INFO - 2023-03-21 08:04:23 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:04:23 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:04:23 --> Utf8 Class Initialized
INFO - 2023-03-21 08:04:23 --> URI Class Initialized
INFO - 2023-03-21 08:04:23 --> Router Class Initialized
INFO - 2023-03-21 08:04:23 --> Output Class Initialized
INFO - 2023-03-21 08:04:23 --> Security Class Initialized
DEBUG - 2023-03-21 08:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:04:23 --> Input Class Initialized
INFO - 2023-03-21 08:04:23 --> Language Class Initialized
INFO - 2023-03-21 08:04:23 --> Loader Class Initialized
INFO - 2023-03-21 08:04:23 --> Controller Class Initialized
DEBUG - 2023-03-21 08:04:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:04:23 --> Database Driver Class Initialized
INFO - 2023-03-21 08:04:24 --> Database Driver Class Initialized
INFO - 2023-03-21 08:04:24 --> Model "Login_model" initialized
INFO - 2023-03-21 08:04:24 --> Final output sent to browser
DEBUG - 2023-03-21 08:04:24 --> Total execution time: 0.0193
INFO - 2023-03-21 08:25:40 --> Config Class Initialized
INFO - 2023-03-21 08:25:40 --> Config Class Initialized
INFO - 2023-03-21 08:25:40 --> Hooks Class Initialized
INFO - 2023-03-21 08:25:40 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:25:40 --> UTF-8 Support Enabled
DEBUG - 2023-03-21 08:25:40 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:25:40 --> Utf8 Class Initialized
INFO - 2023-03-21 08:25:40 --> Utf8 Class Initialized
INFO - 2023-03-21 08:25:40 --> URI Class Initialized
INFO - 2023-03-21 08:25:40 --> URI Class Initialized
INFO - 2023-03-21 08:25:40 --> Router Class Initialized
INFO - 2023-03-21 08:25:40 --> Router Class Initialized
INFO - 2023-03-21 08:25:40 --> Output Class Initialized
INFO - 2023-03-21 08:25:40 --> Output Class Initialized
INFO - 2023-03-21 08:25:40 --> Security Class Initialized
INFO - 2023-03-21 08:25:40 --> Security Class Initialized
DEBUG - 2023-03-21 08:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-21 08:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:25:40 --> Input Class Initialized
INFO - 2023-03-21 08:25:40 --> Input Class Initialized
INFO - 2023-03-21 08:25:40 --> Language Class Initialized
INFO - 2023-03-21 08:25:40 --> Language Class Initialized
INFO - 2023-03-21 08:25:40 --> Loader Class Initialized
INFO - 2023-03-21 08:25:40 --> Loader Class Initialized
INFO - 2023-03-21 08:25:40 --> Controller Class Initialized
INFO - 2023-03-21 08:25:40 --> Controller Class Initialized
DEBUG - 2023-03-21 08:25:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 08:25:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:25:40 --> Final output sent to browser
DEBUG - 2023-03-21 08:25:40 --> Total execution time: 0.0061
INFO - 2023-03-21 08:25:40 --> Database Driver Class Initialized
INFO - 2023-03-21 08:25:40 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:25:40 --> Config Class Initialized
INFO - 2023-03-21 08:25:40 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:25:40 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:25:40 --> Utf8 Class Initialized
INFO - 2023-03-21 08:25:40 --> URI Class Initialized
INFO - 2023-03-21 08:25:40 --> Router Class Initialized
INFO - 2023-03-21 08:25:40 --> Output Class Initialized
INFO - 2023-03-21 08:25:40 --> Security Class Initialized
DEBUG - 2023-03-21 08:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:25:40 --> Input Class Initialized
INFO - 2023-03-21 08:25:40 --> Language Class Initialized
INFO - 2023-03-21 08:25:40 --> Loader Class Initialized
INFO - 2023-03-21 08:25:40 --> Controller Class Initialized
DEBUG - 2023-03-21 08:25:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:25:40 --> Final output sent to browser
INFO - 2023-03-21 08:25:40 --> Database Driver Class Initialized
DEBUG - 2023-03-21 08:25:40 --> Total execution time: 0.0574
INFO - 2023-03-21 08:25:40 --> Config Class Initialized
INFO - 2023-03-21 08:25:40 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:25:40 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:25:40 --> Utf8 Class Initialized
INFO - 2023-03-21 08:25:40 --> URI Class Initialized
INFO - 2023-03-21 08:25:40 --> Router Class Initialized
INFO - 2023-03-21 08:25:40 --> Output Class Initialized
INFO - 2023-03-21 08:25:40 --> Security Class Initialized
DEBUG - 2023-03-21 08:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:25:40 --> Input Class Initialized
INFO - 2023-03-21 08:25:40 --> Language Class Initialized
INFO - 2023-03-21 08:25:40 --> Loader Class Initialized
INFO - 2023-03-21 08:25:40 --> Controller Class Initialized
DEBUG - 2023-03-21 08:25:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:25:40 --> Database Driver Class Initialized
INFO - 2023-03-21 08:25:40 --> Model "Login_model" initialized
INFO - 2023-03-21 08:25:40 --> Database Driver Class Initialized
INFO - 2023-03-21 08:25:40 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:25:40 --> Final output sent to browser
INFO - 2023-03-21 08:25:40 --> Model "Cluster_model" initialized
DEBUG - 2023-03-21 08:25:40 --> Total execution time: 0.0191
INFO - 2023-03-21 08:25:40 --> Final output sent to browser
DEBUG - 2023-03-21 08:25:40 --> Total execution time: 0.0263
INFO - 2023-03-21 08:25:41 --> Config Class Initialized
INFO - 2023-03-21 08:25:41 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:25:42 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:25:42 --> Utf8 Class Initialized
INFO - 2023-03-21 08:25:42 --> URI Class Initialized
INFO - 2023-03-21 08:25:42 --> Router Class Initialized
INFO - 2023-03-21 08:25:42 --> Output Class Initialized
INFO - 2023-03-21 08:25:42 --> Security Class Initialized
DEBUG - 2023-03-21 08:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:25:42 --> Input Class Initialized
INFO - 2023-03-21 08:25:42 --> Language Class Initialized
INFO - 2023-03-21 08:25:42 --> Loader Class Initialized
INFO - 2023-03-21 08:25:42 --> Controller Class Initialized
DEBUG - 2023-03-21 08:25:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:25:42 --> Database Driver Class Initialized
INFO - 2023-03-21 08:25:42 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:25:42 --> Final output sent to browser
DEBUG - 2023-03-21 08:25:42 --> Total execution time: 0.1240
INFO - 2023-03-21 08:25:42 --> Config Class Initialized
INFO - 2023-03-21 08:25:42 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:25:42 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:25:42 --> Utf8 Class Initialized
INFO - 2023-03-21 08:25:42 --> URI Class Initialized
INFO - 2023-03-21 08:25:42 --> Router Class Initialized
INFO - 2023-03-21 08:25:42 --> Output Class Initialized
INFO - 2023-03-21 08:25:42 --> Security Class Initialized
DEBUG - 2023-03-21 08:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:25:42 --> Input Class Initialized
INFO - 2023-03-21 08:25:42 --> Language Class Initialized
INFO - 2023-03-21 08:25:42 --> Loader Class Initialized
INFO - 2023-03-21 08:25:42 --> Controller Class Initialized
DEBUG - 2023-03-21 08:25:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:25:42 --> Database Driver Class Initialized
INFO - 2023-03-21 08:25:42 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:25:42 --> Final output sent to browser
DEBUG - 2023-03-21 08:25:42 --> Total execution time: 0.0909
INFO - 2023-03-21 08:50:55 --> Config Class Initialized
INFO - 2023-03-21 08:50:55 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:50:55 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:50:55 --> Utf8 Class Initialized
INFO - 2023-03-21 08:50:55 --> URI Class Initialized
INFO - 2023-03-21 08:50:55 --> Router Class Initialized
INFO - 2023-03-21 08:50:55 --> Output Class Initialized
INFO - 2023-03-21 08:50:55 --> Security Class Initialized
DEBUG - 2023-03-21 08:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:50:55 --> Input Class Initialized
INFO - 2023-03-21 08:50:55 --> Language Class Initialized
INFO - 2023-03-21 08:50:55 --> Loader Class Initialized
INFO - 2023-03-21 08:50:55 --> Controller Class Initialized
DEBUG - 2023-03-21 08:50:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:50:55 --> Database Driver Class Initialized
INFO - 2023-03-21 08:50:55 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:50:55 --> Final output sent to browser
DEBUG - 2023-03-21 08:50:55 --> Total execution time: 0.1017
INFO - 2023-03-21 08:50:55 --> Config Class Initialized
INFO - 2023-03-21 08:50:55 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:50:55 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:50:55 --> Utf8 Class Initialized
INFO - 2023-03-21 08:50:55 --> URI Class Initialized
INFO - 2023-03-21 08:50:55 --> Router Class Initialized
INFO - 2023-03-21 08:50:55 --> Output Class Initialized
INFO - 2023-03-21 08:50:55 --> Security Class Initialized
DEBUG - 2023-03-21 08:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:50:55 --> Input Class Initialized
INFO - 2023-03-21 08:50:55 --> Language Class Initialized
INFO - 2023-03-21 08:50:55 --> Loader Class Initialized
INFO - 2023-03-21 08:50:55 --> Controller Class Initialized
DEBUG - 2023-03-21 08:50:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:50:55 --> Database Driver Class Initialized
INFO - 2023-03-21 08:50:55 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:50:55 --> Final output sent to browser
DEBUG - 2023-03-21 08:50:55 --> Total execution time: 0.0454
INFO - 2023-03-21 08:50:58 --> Config Class Initialized
INFO - 2023-03-21 08:50:58 --> Hooks Class Initialized
INFO - 2023-03-21 08:50:58 --> Config Class Initialized
INFO - 2023-03-21 08:50:58 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:50:58 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:50:58 --> Utf8 Class Initialized
DEBUG - 2023-03-21 08:50:58 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:50:58 --> URI Class Initialized
INFO - 2023-03-21 08:50:58 --> Utf8 Class Initialized
INFO - 2023-03-21 08:50:58 --> Router Class Initialized
INFO - 2023-03-21 08:50:58 --> URI Class Initialized
INFO - 2023-03-21 08:50:58 --> Output Class Initialized
INFO - 2023-03-21 08:50:58 --> Router Class Initialized
INFO - 2023-03-21 08:50:58 --> Security Class Initialized
INFO - 2023-03-21 08:50:58 --> Output Class Initialized
DEBUG - 2023-03-21 08:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:50:58 --> Security Class Initialized
INFO - 2023-03-21 08:50:58 --> Input Class Initialized
DEBUG - 2023-03-21 08:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:50:58 --> Language Class Initialized
INFO - 2023-03-21 08:50:58 --> Input Class Initialized
INFO - 2023-03-21 08:50:58 --> Language Class Initialized
INFO - 2023-03-21 08:50:58 --> Loader Class Initialized
INFO - 2023-03-21 08:50:58 --> Controller Class Initialized
DEBUG - 2023-03-21 08:50:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:50:58 --> Loader Class Initialized
INFO - 2023-03-21 08:50:58 --> Final output sent to browser
INFO - 2023-03-21 08:50:58 --> Controller Class Initialized
DEBUG - 2023-03-21 08:50:58 --> Total execution time: 0.0049
DEBUG - 2023-03-21 08:50:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:50:58 --> Database Driver Class Initialized
INFO - 2023-03-21 08:50:58 --> Config Class Initialized
INFO - 2023-03-21 08:50:58 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:50:58 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:50:58 --> Utf8 Class Initialized
INFO - 2023-03-21 08:50:58 --> URI Class Initialized
INFO - 2023-03-21 08:50:58 --> Router Class Initialized
INFO - 2023-03-21 08:50:58 --> Output Class Initialized
INFO - 2023-03-21 08:50:58 --> Security Class Initialized
DEBUG - 2023-03-21 08:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:50:58 --> Input Class Initialized
INFO - 2023-03-21 08:50:58 --> Language Class Initialized
INFO - 2023-03-21 08:50:58 --> Loader Class Initialized
INFO - 2023-03-21 08:50:58 --> Controller Class Initialized
DEBUG - 2023-03-21 08:50:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:50:58 --> Database Driver Class Initialized
INFO - 2023-03-21 08:50:58 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:50:58 --> Model "Login_model" initialized
INFO - 2023-03-21 08:50:58 --> Database Driver Class Initialized
INFO - 2023-03-21 08:50:58 --> Final output sent to browser
DEBUG - 2023-03-21 08:50:58 --> Total execution time: 0.0458
INFO - 2023-03-21 08:50:58 --> Config Class Initialized
INFO - 2023-03-21 08:50:58 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:50:58 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:50:58 --> Utf8 Class Initialized
INFO - 2023-03-21 08:50:58 --> URI Class Initialized
INFO - 2023-03-21 08:50:58 --> Router Class Initialized
INFO - 2023-03-21 08:50:58 --> Output Class Initialized
INFO - 2023-03-21 08:50:58 --> Security Class Initialized
DEBUG - 2023-03-21 08:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:50:58 --> Input Class Initialized
INFO - 2023-03-21 08:50:58 --> Language Class Initialized
INFO - 2023-03-21 08:50:58 --> Loader Class Initialized
INFO - 2023-03-21 08:50:58 --> Controller Class Initialized
DEBUG - 2023-03-21 08:50:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:50:58 --> Database Driver Class Initialized
INFO - 2023-03-21 08:50:58 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:50:58 --> Final output sent to browser
DEBUG - 2023-03-21 08:50:58 --> Total execution time: 0.0524
INFO - 2023-03-21 08:50:58 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:50:58 --> Final output sent to browser
DEBUG - 2023-03-21 08:50:58 --> Total execution time: 0.0594
INFO - 2023-03-21 08:51:01 --> Config Class Initialized
INFO - 2023-03-21 08:51:01 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:51:01 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:51:01 --> Utf8 Class Initialized
INFO - 2023-03-21 08:51:01 --> URI Class Initialized
INFO - 2023-03-21 08:51:01 --> Router Class Initialized
INFO - 2023-03-21 08:51:01 --> Output Class Initialized
INFO - 2023-03-21 08:51:01 --> Security Class Initialized
DEBUG - 2023-03-21 08:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:51:01 --> Input Class Initialized
INFO - 2023-03-21 08:51:01 --> Language Class Initialized
INFO - 2023-03-21 08:51:01 --> Loader Class Initialized
INFO - 2023-03-21 08:51:01 --> Controller Class Initialized
DEBUG - 2023-03-21 08:51:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:51:01 --> Database Driver Class Initialized
INFO - 2023-03-21 08:51:01 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:51:01 --> Database Driver Class Initialized
INFO - 2023-03-21 08:51:01 --> Model "Login_model" initialized
INFO - 2023-03-21 08:51:01 --> Final output sent to browser
DEBUG - 2023-03-21 08:51:01 --> Total execution time: 0.0712
INFO - 2023-03-21 08:51:01 --> Config Class Initialized
INFO - 2023-03-21 08:51:01 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:51:01 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:51:01 --> Utf8 Class Initialized
INFO - 2023-03-21 08:51:01 --> URI Class Initialized
INFO - 2023-03-21 08:51:01 --> Router Class Initialized
INFO - 2023-03-21 08:51:01 --> Output Class Initialized
INFO - 2023-03-21 08:51:01 --> Security Class Initialized
DEBUG - 2023-03-21 08:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:51:01 --> Input Class Initialized
INFO - 2023-03-21 08:51:01 --> Language Class Initialized
INFO - 2023-03-21 08:51:01 --> Loader Class Initialized
INFO - 2023-03-21 08:51:01 --> Controller Class Initialized
DEBUG - 2023-03-21 08:51:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:51:01 --> Database Driver Class Initialized
INFO - 2023-03-21 08:51:01 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:51:01 --> Database Driver Class Initialized
INFO - 2023-03-21 08:51:01 --> Model "Login_model" initialized
INFO - 2023-03-21 08:51:01 --> Final output sent to browser
DEBUG - 2023-03-21 08:51:01 --> Total execution time: 0.1027
INFO - 2023-03-21 08:51:46 --> Config Class Initialized
INFO - 2023-03-21 08:51:46 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:51:46 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:51:46 --> Utf8 Class Initialized
INFO - 2023-03-21 08:51:46 --> URI Class Initialized
INFO - 2023-03-21 08:51:46 --> Router Class Initialized
INFO - 2023-03-21 08:51:46 --> Output Class Initialized
INFO - 2023-03-21 08:51:46 --> Security Class Initialized
DEBUG - 2023-03-21 08:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:51:46 --> Input Class Initialized
INFO - 2023-03-21 08:51:46 --> Language Class Initialized
INFO - 2023-03-21 08:51:46 --> Loader Class Initialized
INFO - 2023-03-21 08:51:46 --> Controller Class Initialized
DEBUG - 2023-03-21 08:51:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:51:46 --> Database Driver Class Initialized
INFO - 2023-03-21 08:51:46 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:51:46 --> Final output sent to browser
DEBUG - 2023-03-21 08:51:46 --> Total execution time: 0.0129
INFO - 2023-03-21 08:51:46 --> Config Class Initialized
INFO - 2023-03-21 08:51:46 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:51:46 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:51:46 --> Utf8 Class Initialized
INFO - 2023-03-21 08:51:46 --> URI Class Initialized
INFO - 2023-03-21 08:51:46 --> Router Class Initialized
INFO - 2023-03-21 08:51:46 --> Output Class Initialized
INFO - 2023-03-21 08:51:46 --> Security Class Initialized
DEBUG - 2023-03-21 08:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:51:46 --> Input Class Initialized
INFO - 2023-03-21 08:51:46 --> Language Class Initialized
INFO - 2023-03-21 08:51:46 --> Loader Class Initialized
INFO - 2023-03-21 08:51:46 --> Controller Class Initialized
DEBUG - 2023-03-21 08:51:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:51:46 --> Database Driver Class Initialized
INFO - 2023-03-21 08:51:46 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:51:46 --> Final output sent to browser
DEBUG - 2023-03-21 08:51:46 --> Total execution time: 0.0538
INFO - 2023-03-21 08:51:48 --> Config Class Initialized
INFO - 2023-03-21 08:51:48 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:51:48 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:51:48 --> Utf8 Class Initialized
INFO - 2023-03-21 08:51:48 --> URI Class Initialized
INFO - 2023-03-21 08:51:48 --> Router Class Initialized
INFO - 2023-03-21 08:51:48 --> Output Class Initialized
INFO - 2023-03-21 08:51:48 --> Security Class Initialized
DEBUG - 2023-03-21 08:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:51:48 --> Input Class Initialized
INFO - 2023-03-21 08:51:48 --> Language Class Initialized
INFO - 2023-03-21 08:51:48 --> Loader Class Initialized
INFO - 2023-03-21 08:51:48 --> Controller Class Initialized
DEBUG - 2023-03-21 08:51:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:51:48 --> Database Driver Class Initialized
INFO - 2023-03-21 08:51:48 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:51:48 --> Final output sent to browser
DEBUG - 2023-03-21 08:51:48 --> Total execution time: 0.1815
INFO - 2023-03-21 08:51:48 --> Config Class Initialized
INFO - 2023-03-21 08:51:48 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:51:48 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:51:48 --> Utf8 Class Initialized
INFO - 2023-03-21 08:51:48 --> URI Class Initialized
INFO - 2023-03-21 08:51:48 --> Router Class Initialized
INFO - 2023-03-21 08:51:48 --> Output Class Initialized
INFO - 2023-03-21 08:51:48 --> Security Class Initialized
DEBUG - 2023-03-21 08:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:51:48 --> Input Class Initialized
INFO - 2023-03-21 08:51:48 --> Language Class Initialized
INFO - 2023-03-21 08:51:48 --> Loader Class Initialized
INFO - 2023-03-21 08:51:48 --> Controller Class Initialized
DEBUG - 2023-03-21 08:51:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:51:48 --> Database Driver Class Initialized
INFO - 2023-03-21 08:51:48 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:51:48 --> Final output sent to browser
DEBUG - 2023-03-21 08:51:48 --> Total execution time: 0.1274
INFO - 2023-03-21 08:51:50 --> Config Class Initialized
INFO - 2023-03-21 08:51:50 --> Config Class Initialized
INFO - 2023-03-21 08:51:50 --> Hooks Class Initialized
INFO - 2023-03-21 08:51:50 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:51:50 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:51:50 --> Utf8 Class Initialized
DEBUG - 2023-03-21 08:51:50 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:51:50 --> URI Class Initialized
INFO - 2023-03-21 08:51:50 --> Utf8 Class Initialized
INFO - 2023-03-21 08:51:50 --> URI Class Initialized
INFO - 2023-03-21 08:51:50 --> Router Class Initialized
INFO - 2023-03-21 08:51:50 --> Router Class Initialized
INFO - 2023-03-21 08:51:50 --> Output Class Initialized
INFO - 2023-03-21 08:51:50 --> Output Class Initialized
INFO - 2023-03-21 08:51:50 --> Security Class Initialized
INFO - 2023-03-21 08:51:50 --> Security Class Initialized
DEBUG - 2023-03-21 08:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-21 08:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:51:50 --> Input Class Initialized
INFO - 2023-03-21 08:51:50 --> Input Class Initialized
INFO - 2023-03-21 08:51:50 --> Language Class Initialized
INFO - 2023-03-21 08:51:50 --> Language Class Initialized
INFO - 2023-03-21 08:51:50 --> Loader Class Initialized
INFO - 2023-03-21 08:51:50 --> Loader Class Initialized
INFO - 2023-03-21 08:51:50 --> Controller Class Initialized
INFO - 2023-03-21 08:51:50 --> Controller Class Initialized
DEBUG - 2023-03-21 08:51:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 08:51:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:51:50 --> Final output sent to browser
INFO - 2023-03-21 08:51:50 --> Database Driver Class Initialized
DEBUG - 2023-03-21 08:51:50 --> Total execution time: 0.0044
INFO - 2023-03-21 08:51:50 --> Config Class Initialized
INFO - 2023-03-21 08:51:50 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:51:50 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:51:50 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:51:50 --> Utf8 Class Initialized
INFO - 2023-03-21 08:51:50 --> URI Class Initialized
INFO - 2023-03-21 08:51:50 --> Router Class Initialized
INFO - 2023-03-21 08:51:50 --> Output Class Initialized
INFO - 2023-03-21 08:51:50 --> Security Class Initialized
DEBUG - 2023-03-21 08:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:51:50 --> Input Class Initialized
INFO - 2023-03-21 08:51:50 --> Language Class Initialized
INFO - 2023-03-21 08:51:50 --> Loader Class Initialized
INFO - 2023-03-21 08:51:50 --> Controller Class Initialized
DEBUG - 2023-03-21 08:51:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:51:50 --> Database Driver Class Initialized
INFO - 2023-03-21 08:51:50 --> Final output sent to browser
DEBUG - 2023-03-21 08:51:50 --> Total execution time: 0.0500
INFO - 2023-03-21 08:51:50 --> Config Class Initialized
INFO - 2023-03-21 08:51:50 --> Hooks Class Initialized
DEBUG - 2023-03-21 08:51:50 --> UTF-8 Support Enabled
INFO - 2023-03-21 08:51:50 --> Utf8 Class Initialized
INFO - 2023-03-21 08:51:50 --> URI Class Initialized
INFO - 2023-03-21 08:51:50 --> Router Class Initialized
INFO - 2023-03-21 08:51:50 --> Output Class Initialized
INFO - 2023-03-21 08:51:50 --> Security Class Initialized
DEBUG - 2023-03-21 08:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 08:51:50 --> Input Class Initialized
INFO - 2023-03-21 08:51:50 --> Language Class Initialized
INFO - 2023-03-21 08:51:50 --> Loader Class Initialized
INFO - 2023-03-21 08:51:50 --> Controller Class Initialized
DEBUG - 2023-03-21 08:51:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 08:51:50 --> Model "Login_model" initialized
INFO - 2023-03-21 08:51:50 --> Database Driver Class Initialized
INFO - 2023-03-21 08:51:50 --> Database Driver Class Initialized
INFO - 2023-03-21 08:51:50 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:51:50 --> Model "Cluster_model" initialized
INFO - 2023-03-21 08:51:50 --> Final output sent to browser
DEBUG - 2023-03-21 08:51:50 --> Total execution time: 0.0641
INFO - 2023-03-21 08:51:50 --> Final output sent to browser
DEBUG - 2023-03-21 08:51:50 --> Total execution time: 0.0185
INFO - 2023-03-21 09:23:58 --> Config Class Initialized
INFO - 2023-03-21 09:23:58 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:23:58 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:23:58 --> Utf8 Class Initialized
INFO - 2023-03-21 09:23:58 --> URI Class Initialized
INFO - 2023-03-21 09:23:58 --> Router Class Initialized
INFO - 2023-03-21 09:23:58 --> Output Class Initialized
INFO - 2023-03-21 09:23:58 --> Security Class Initialized
DEBUG - 2023-03-21 09:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:23:58 --> Input Class Initialized
INFO - 2023-03-21 09:23:58 --> Language Class Initialized
INFO - 2023-03-21 09:23:58 --> Loader Class Initialized
INFO - 2023-03-21 09:23:58 --> Controller Class Initialized
DEBUG - 2023-03-21 09:23:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:23:58 --> Database Driver Class Initialized
INFO - 2023-03-21 09:23:58 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:23:58 --> Final output sent to browser
DEBUG - 2023-03-21 09:23:58 --> Total execution time: 0.0581
INFO - 2023-03-21 09:23:58 --> Config Class Initialized
INFO - 2023-03-21 09:23:58 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:23:58 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:23:58 --> Utf8 Class Initialized
INFO - 2023-03-21 09:23:58 --> URI Class Initialized
INFO - 2023-03-21 09:23:58 --> Router Class Initialized
INFO - 2023-03-21 09:23:58 --> Output Class Initialized
INFO - 2023-03-21 09:23:58 --> Security Class Initialized
DEBUG - 2023-03-21 09:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:23:58 --> Input Class Initialized
INFO - 2023-03-21 09:23:58 --> Language Class Initialized
INFO - 2023-03-21 09:23:58 --> Loader Class Initialized
INFO - 2023-03-21 09:23:58 --> Controller Class Initialized
DEBUG - 2023-03-21 09:23:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:23:58 --> Database Driver Class Initialized
INFO - 2023-03-21 09:23:58 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:23:58 --> Final output sent to browser
DEBUG - 2023-03-21 09:23:58 --> Total execution time: 0.0440
INFO - 2023-03-21 09:34:11 --> Config Class Initialized
INFO - 2023-03-21 09:34:11 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:34:11 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:34:11 --> Utf8 Class Initialized
INFO - 2023-03-21 09:34:11 --> URI Class Initialized
INFO - 2023-03-21 09:34:11 --> Router Class Initialized
INFO - 2023-03-21 09:34:11 --> Output Class Initialized
INFO - 2023-03-21 09:34:11 --> Security Class Initialized
DEBUG - 2023-03-21 09:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:34:11 --> Input Class Initialized
INFO - 2023-03-21 09:34:11 --> Language Class Initialized
INFO - 2023-03-21 09:34:11 --> Loader Class Initialized
INFO - 2023-03-21 09:34:11 --> Controller Class Initialized
DEBUG - 2023-03-21 09:34:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:34:11 --> Database Driver Class Initialized
INFO - 2023-03-21 09:34:11 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:34:11 --> Final output sent to browser
DEBUG - 2023-03-21 09:34:11 --> Total execution time: 0.0558
INFO - 2023-03-21 09:34:11 --> Config Class Initialized
INFO - 2023-03-21 09:34:11 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:34:11 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:34:11 --> Utf8 Class Initialized
INFO - 2023-03-21 09:34:11 --> URI Class Initialized
INFO - 2023-03-21 09:34:11 --> Router Class Initialized
INFO - 2023-03-21 09:34:11 --> Output Class Initialized
INFO - 2023-03-21 09:34:11 --> Security Class Initialized
DEBUG - 2023-03-21 09:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:34:11 --> Input Class Initialized
INFO - 2023-03-21 09:34:11 --> Language Class Initialized
INFO - 2023-03-21 09:34:11 --> Loader Class Initialized
INFO - 2023-03-21 09:34:11 --> Controller Class Initialized
DEBUG - 2023-03-21 09:34:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:34:11 --> Database Driver Class Initialized
INFO - 2023-03-21 09:34:11 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:34:11 --> Final output sent to browser
DEBUG - 2023-03-21 09:34:11 --> Total execution time: 0.0447
INFO - 2023-03-21 09:41:59 --> Config Class Initialized
INFO - 2023-03-21 09:41:59 --> Config Class Initialized
INFO - 2023-03-21 09:41:59 --> Hooks Class Initialized
INFO - 2023-03-21 09:41:59 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:41:59 --> UTF-8 Support Enabled
DEBUG - 2023-03-21 09:41:59 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:41:59 --> Utf8 Class Initialized
INFO - 2023-03-21 09:41:59 --> Utf8 Class Initialized
INFO - 2023-03-21 09:41:59 --> URI Class Initialized
INFO - 2023-03-21 09:41:59 --> URI Class Initialized
INFO - 2023-03-21 09:41:59 --> Router Class Initialized
INFO - 2023-03-21 09:41:59 --> Router Class Initialized
INFO - 2023-03-21 09:41:59 --> Output Class Initialized
INFO - 2023-03-21 09:41:59 --> Output Class Initialized
INFO - 2023-03-21 09:41:59 --> Security Class Initialized
INFO - 2023-03-21 09:41:59 --> Security Class Initialized
DEBUG - 2023-03-21 09:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-21 09:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:41:59 --> Input Class Initialized
INFO - 2023-03-21 09:41:59 --> Input Class Initialized
INFO - 2023-03-21 09:41:59 --> Language Class Initialized
INFO - 2023-03-21 09:41:59 --> Language Class Initialized
INFO - 2023-03-21 09:41:59 --> Loader Class Initialized
INFO - 2023-03-21 09:41:59 --> Loader Class Initialized
INFO - 2023-03-21 09:41:59 --> Controller Class Initialized
INFO - 2023-03-21 09:41:59 --> Controller Class Initialized
DEBUG - 2023-03-21 09:41:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 09:41:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:41:59 --> Final output sent to browser
DEBUG - 2023-03-21 09:41:59 --> Total execution time: 0.0062
INFO - 2023-03-21 09:41:59 --> Database Driver Class Initialized
INFO - 2023-03-21 09:41:59 --> Config Class Initialized
INFO - 2023-03-21 09:41:59 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:41:59 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:41:59 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:41:59 --> Utf8 Class Initialized
INFO - 2023-03-21 09:41:59 --> URI Class Initialized
INFO - 2023-03-21 09:41:59 --> Router Class Initialized
INFO - 2023-03-21 09:41:59 --> Output Class Initialized
INFO - 2023-03-21 09:41:59 --> Security Class Initialized
DEBUG - 2023-03-21 09:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:41:59 --> Input Class Initialized
INFO - 2023-03-21 09:41:59 --> Language Class Initialized
INFO - 2023-03-21 09:41:59 --> Loader Class Initialized
INFO - 2023-03-21 09:41:59 --> Controller Class Initialized
DEBUG - 2023-03-21 09:41:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:41:59 --> Database Driver Class Initialized
INFO - 2023-03-21 09:41:59 --> Final output sent to browser
DEBUG - 2023-03-21 09:41:59 --> Total execution time: 0.0528
INFO - 2023-03-21 09:41:59 --> Config Class Initialized
INFO - 2023-03-21 09:41:59 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:41:59 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:41:59 --> Utf8 Class Initialized
INFO - 2023-03-21 09:41:59 --> URI Class Initialized
INFO - 2023-03-21 09:41:59 --> Router Class Initialized
INFO - 2023-03-21 09:41:59 --> Output Class Initialized
INFO - 2023-03-21 09:41:59 --> Security Class Initialized
DEBUG - 2023-03-21 09:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:41:59 --> Input Class Initialized
INFO - 2023-03-21 09:41:59 --> Language Class Initialized
INFO - 2023-03-21 09:41:59 --> Loader Class Initialized
INFO - 2023-03-21 09:41:59 --> Controller Class Initialized
DEBUG - 2023-03-21 09:41:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:41:59 --> Database Driver Class Initialized
INFO - 2023-03-21 09:41:59 --> Model "Login_model" initialized
INFO - 2023-03-21 09:41:59 --> Database Driver Class Initialized
INFO - 2023-03-21 09:41:59 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:41:59 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:41:59 --> Final output sent to browser
DEBUG - 2023-03-21 09:41:59 --> Total execution time: 0.0138
INFO - 2023-03-21 09:41:59 --> Final output sent to browser
DEBUG - 2023-03-21 09:41:59 --> Total execution time: 0.0601
INFO - 2023-03-21 09:55:18 --> Config Class Initialized
INFO - 2023-03-21 09:55:18 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:55:18 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:55:18 --> Utf8 Class Initialized
INFO - 2023-03-21 09:55:18 --> URI Class Initialized
INFO - 2023-03-21 09:55:18 --> Router Class Initialized
INFO - 2023-03-21 09:55:18 --> Output Class Initialized
INFO - 2023-03-21 09:55:18 --> Security Class Initialized
DEBUG - 2023-03-21 09:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:55:18 --> Input Class Initialized
INFO - 2023-03-21 09:55:18 --> Language Class Initialized
INFO - 2023-03-21 09:55:18 --> Loader Class Initialized
INFO - 2023-03-21 09:55:18 --> Controller Class Initialized
DEBUG - 2023-03-21 09:55:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:55:18 --> Database Driver Class Initialized
INFO - 2023-03-21 09:55:18 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:55:18 --> Final output sent to browser
DEBUG - 2023-03-21 09:55:18 --> Total execution time: 0.0500
INFO - 2023-03-21 09:55:18 --> Config Class Initialized
INFO - 2023-03-21 09:55:18 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:55:18 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:55:18 --> Utf8 Class Initialized
INFO - 2023-03-21 09:55:18 --> URI Class Initialized
INFO - 2023-03-21 09:55:18 --> Router Class Initialized
INFO - 2023-03-21 09:55:18 --> Output Class Initialized
INFO - 2023-03-21 09:55:18 --> Security Class Initialized
DEBUG - 2023-03-21 09:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:55:18 --> Input Class Initialized
INFO - 2023-03-21 09:55:18 --> Language Class Initialized
INFO - 2023-03-21 09:55:18 --> Loader Class Initialized
INFO - 2023-03-21 09:55:18 --> Controller Class Initialized
DEBUG - 2023-03-21 09:55:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:55:18 --> Database Driver Class Initialized
INFO - 2023-03-21 09:55:18 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:55:18 --> Final output sent to browser
DEBUG - 2023-03-21 09:55:18 --> Total execution time: 0.0558
INFO - 2023-03-21 09:55:20 --> Config Class Initialized
INFO - 2023-03-21 09:55:20 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:55:20 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:55:20 --> Utf8 Class Initialized
INFO - 2023-03-21 09:55:20 --> URI Class Initialized
INFO - 2023-03-21 09:55:20 --> Router Class Initialized
INFO - 2023-03-21 09:55:20 --> Output Class Initialized
INFO - 2023-03-21 09:55:20 --> Security Class Initialized
DEBUG - 2023-03-21 09:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:55:20 --> Input Class Initialized
INFO - 2023-03-21 09:55:20 --> Language Class Initialized
INFO - 2023-03-21 09:55:20 --> Loader Class Initialized
INFO - 2023-03-21 09:55:20 --> Controller Class Initialized
DEBUG - 2023-03-21 09:55:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:55:20 --> Database Driver Class Initialized
INFO - 2023-03-21 09:55:20 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:55:20 --> Final output sent to browser
DEBUG - 2023-03-21 09:55:20 --> Total execution time: 0.0163
INFO - 2023-03-21 09:55:20 --> Config Class Initialized
INFO - 2023-03-21 09:55:20 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:55:20 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:55:20 --> Utf8 Class Initialized
INFO - 2023-03-21 09:55:20 --> URI Class Initialized
INFO - 2023-03-21 09:55:20 --> Router Class Initialized
INFO - 2023-03-21 09:55:20 --> Output Class Initialized
INFO - 2023-03-21 09:55:20 --> Security Class Initialized
DEBUG - 2023-03-21 09:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:55:20 --> Input Class Initialized
INFO - 2023-03-21 09:55:20 --> Language Class Initialized
INFO - 2023-03-21 09:55:20 --> Loader Class Initialized
INFO - 2023-03-21 09:55:20 --> Controller Class Initialized
DEBUG - 2023-03-21 09:55:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:55:20 --> Database Driver Class Initialized
INFO - 2023-03-21 09:55:20 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:55:20 --> Final output sent to browser
DEBUG - 2023-03-21 09:55:20 --> Total execution time: 0.0540
INFO - 2023-03-21 09:59:26 --> Config Class Initialized
INFO - 2023-03-21 09:59:26 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:59:26 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:59:26 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:26 --> URI Class Initialized
INFO - 2023-03-21 09:59:26 --> Router Class Initialized
INFO - 2023-03-21 09:59:26 --> Output Class Initialized
INFO - 2023-03-21 09:59:26 --> Security Class Initialized
DEBUG - 2023-03-21 09:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:59:26 --> Input Class Initialized
INFO - 2023-03-21 09:59:26 --> Language Class Initialized
INFO - 2023-03-21 09:59:26 --> Loader Class Initialized
INFO - 2023-03-21 09:59:26 --> Controller Class Initialized
DEBUG - 2023-03-21 09:59:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:59:26 --> Database Driver Class Initialized
INFO - 2023-03-21 09:59:26 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:59:26 --> Final output sent to browser
DEBUG - 2023-03-21 09:59:26 --> Total execution time: 0.0470
INFO - 2023-03-21 09:59:26 --> Config Class Initialized
INFO - 2023-03-21 09:59:26 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:59:26 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:59:26 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:26 --> URI Class Initialized
INFO - 2023-03-21 09:59:26 --> Router Class Initialized
INFO - 2023-03-21 09:59:26 --> Output Class Initialized
INFO - 2023-03-21 09:59:26 --> Security Class Initialized
DEBUG - 2023-03-21 09:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:59:26 --> Input Class Initialized
INFO - 2023-03-21 09:59:26 --> Language Class Initialized
INFO - 2023-03-21 09:59:26 --> Loader Class Initialized
INFO - 2023-03-21 09:59:26 --> Controller Class Initialized
DEBUG - 2023-03-21 09:59:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:59:26 --> Database Driver Class Initialized
INFO - 2023-03-21 09:59:26 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:59:26 --> Final output sent to browser
DEBUG - 2023-03-21 09:59:26 --> Total execution time: 0.0878
INFO - 2023-03-21 09:59:28 --> Config Class Initialized
INFO - 2023-03-21 09:59:28 --> Config Class Initialized
INFO - 2023-03-21 09:59:28 --> Hooks Class Initialized
INFO - 2023-03-21 09:59:28 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:59:28 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:59:28 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:28 --> URI Class Initialized
INFO - 2023-03-21 09:59:28 --> Router Class Initialized
INFO - 2023-03-21 09:59:28 --> Output Class Initialized
INFO - 2023-03-21 09:59:28 --> Security Class Initialized
DEBUG - 2023-03-21 09:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:59:28 --> Input Class Initialized
INFO - 2023-03-21 09:59:28 --> Language Class Initialized
INFO - 2023-03-21 09:59:28 --> Loader Class Initialized
INFO - 2023-03-21 09:59:28 --> Controller Class Initialized
DEBUG - 2023-03-21 09:59:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:59:28 --> Database Driver Class Initialized
DEBUG - 2023-03-21 09:59:28 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:59:28 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:28 --> URI Class Initialized
INFO - 2023-03-21 09:59:28 --> Router Class Initialized
INFO - 2023-03-21 09:59:28 --> Output Class Initialized
INFO - 2023-03-21 09:59:28 --> Security Class Initialized
DEBUG - 2023-03-21 09:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:59:28 --> Input Class Initialized
INFO - 2023-03-21 09:59:28 --> Language Class Initialized
INFO - 2023-03-21 09:59:28 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:59:28 --> Loader Class Initialized
INFO - 2023-03-21 09:59:28 --> Controller Class Initialized
DEBUG - 2023-03-21 09:59:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:59:28 --> Final output sent to browser
DEBUG - 2023-03-21 09:59:28 --> Total execution time: 0.0963
INFO - 2023-03-21 09:59:28 --> Config Class Initialized
INFO - 2023-03-21 09:59:28 --> Final output sent to browser
INFO - 2023-03-21 09:59:28 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:59:28 --> Total execution time: 0.1015
DEBUG - 2023-03-21 09:59:28 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:59:28 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:28 --> URI Class Initialized
INFO - 2023-03-21 09:59:28 --> Router Class Initialized
INFO - 2023-03-21 09:59:28 --> Output Class Initialized
INFO - 2023-03-21 09:59:28 --> Security Class Initialized
DEBUG - 2023-03-21 09:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:59:28 --> Input Class Initialized
INFO - 2023-03-21 09:59:28 --> Language Class Initialized
INFO - 2023-03-21 09:59:28 --> Loader Class Initialized
INFO - 2023-03-21 09:59:28 --> Controller Class Initialized
DEBUG - 2023-03-21 09:59:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:59:28 --> Config Class Initialized
INFO - 2023-03-21 09:59:28 --> Hooks Class Initialized
INFO - 2023-03-21 09:59:28 --> Database Driver Class Initialized
DEBUG - 2023-03-21 09:59:28 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:59:28 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:28 --> URI Class Initialized
INFO - 2023-03-21 09:59:28 --> Router Class Initialized
INFO - 2023-03-21 09:59:28 --> Output Class Initialized
INFO - 2023-03-21 09:59:28 --> Security Class Initialized
DEBUG - 2023-03-21 09:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:59:28 --> Input Class Initialized
INFO - 2023-03-21 09:59:28 --> Language Class Initialized
INFO - 2023-03-21 09:59:28 --> Loader Class Initialized
INFO - 2023-03-21 09:59:28 --> Controller Class Initialized
DEBUG - 2023-03-21 09:59:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:59:28 --> Database Driver Class Initialized
INFO - 2023-03-21 09:59:28 --> Model "Login_model" initialized
INFO - 2023-03-21 09:59:28 --> Database Driver Class Initialized
INFO - 2023-03-21 09:59:28 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:59:28 --> Final output sent to browser
DEBUG - 2023-03-21 09:59:28 --> Total execution time: 0.0157
INFO - 2023-03-21 09:59:28 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:59:28 --> Final output sent to browser
DEBUG - 2023-03-21 09:59:28 --> Total execution time: 0.1007
INFO - 2023-03-21 09:59:32 --> Config Class Initialized
INFO - 2023-03-21 09:59:32 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:59:32 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:59:32 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:32 --> URI Class Initialized
INFO - 2023-03-21 09:59:32 --> Router Class Initialized
INFO - 2023-03-21 09:59:32 --> Output Class Initialized
INFO - 2023-03-21 09:59:32 --> Security Class Initialized
DEBUG - 2023-03-21 09:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:59:32 --> Input Class Initialized
INFO - 2023-03-21 09:59:32 --> Language Class Initialized
INFO - 2023-03-21 09:59:32 --> Loader Class Initialized
INFO - 2023-03-21 09:59:32 --> Controller Class Initialized
DEBUG - 2023-03-21 09:59:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:59:32 --> Database Driver Class Initialized
INFO - 2023-03-21 09:59:32 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:59:32 --> Database Driver Class Initialized
INFO - 2023-03-21 09:59:32 --> Model "Login_model" initialized
INFO - 2023-03-21 09:59:32 --> Final output sent to browser
DEBUG - 2023-03-21 09:59:32 --> Total execution time: 0.0618
INFO - 2023-03-21 09:59:32 --> Config Class Initialized
INFO - 2023-03-21 09:59:32 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:59:32 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:59:32 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:32 --> URI Class Initialized
INFO - 2023-03-21 09:59:32 --> Router Class Initialized
INFO - 2023-03-21 09:59:32 --> Output Class Initialized
INFO - 2023-03-21 09:59:32 --> Security Class Initialized
DEBUG - 2023-03-21 09:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:59:32 --> Input Class Initialized
INFO - 2023-03-21 09:59:32 --> Language Class Initialized
INFO - 2023-03-21 09:59:32 --> Loader Class Initialized
INFO - 2023-03-21 09:59:32 --> Controller Class Initialized
DEBUG - 2023-03-21 09:59:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:59:32 --> Database Driver Class Initialized
INFO - 2023-03-21 09:59:32 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:59:32 --> Database Driver Class Initialized
INFO - 2023-03-21 09:59:32 --> Model "Login_model" initialized
INFO - 2023-03-21 09:59:32 --> Final output sent to browser
DEBUG - 2023-03-21 09:59:32 --> Total execution time: 0.0958
INFO - 2023-03-21 09:59:41 --> Config Class Initialized
INFO - 2023-03-21 09:59:41 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:59:41 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:59:41 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:41 --> URI Class Initialized
INFO - 2023-03-21 09:59:41 --> Router Class Initialized
INFO - 2023-03-21 09:59:41 --> Output Class Initialized
INFO - 2023-03-21 09:59:41 --> Security Class Initialized
DEBUG - 2023-03-21 09:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:59:41 --> Input Class Initialized
INFO - 2023-03-21 09:59:41 --> Language Class Initialized
INFO - 2023-03-21 09:59:41 --> Loader Class Initialized
INFO - 2023-03-21 09:59:41 --> Controller Class Initialized
DEBUG - 2023-03-21 09:59:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:59:41 --> Database Driver Class Initialized
INFO - 2023-03-21 09:59:41 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:59:41 --> Final output sent to browser
DEBUG - 2023-03-21 09:59:41 --> Total execution time: 0.0205
INFO - 2023-03-21 09:59:41 --> Config Class Initialized
INFO - 2023-03-21 09:59:41 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:59:41 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:59:41 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:41 --> URI Class Initialized
INFO - 2023-03-21 09:59:41 --> Router Class Initialized
INFO - 2023-03-21 09:59:41 --> Output Class Initialized
INFO - 2023-03-21 09:59:41 --> Security Class Initialized
DEBUG - 2023-03-21 09:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:59:41 --> Input Class Initialized
INFO - 2023-03-21 09:59:41 --> Language Class Initialized
INFO - 2023-03-21 09:59:41 --> Loader Class Initialized
INFO - 2023-03-21 09:59:41 --> Controller Class Initialized
DEBUG - 2023-03-21 09:59:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:59:41 --> Database Driver Class Initialized
INFO - 2023-03-21 09:59:41 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:59:41 --> Final output sent to browser
DEBUG - 2023-03-21 09:59:41 --> Total execution time: 0.0590
INFO - 2023-03-21 09:59:43 --> Config Class Initialized
INFO - 2023-03-21 09:59:43 --> Config Class Initialized
INFO - 2023-03-21 09:59:43 --> Hooks Class Initialized
INFO - 2023-03-21 09:59:43 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:59:43 --> UTF-8 Support Enabled
DEBUG - 2023-03-21 09:59:43 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:59:43 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:43 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:43 --> URI Class Initialized
INFO - 2023-03-21 09:59:43 --> URI Class Initialized
INFO - 2023-03-21 09:59:43 --> Router Class Initialized
INFO - 2023-03-21 09:59:43 --> Router Class Initialized
INFO - 2023-03-21 09:59:43 --> Output Class Initialized
INFO - 2023-03-21 09:59:43 --> Output Class Initialized
INFO - 2023-03-21 09:59:43 --> Security Class Initialized
INFO - 2023-03-21 09:59:43 --> Security Class Initialized
DEBUG - 2023-03-21 09:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-21 09:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:59:43 --> Input Class Initialized
INFO - 2023-03-21 09:59:43 --> Input Class Initialized
INFO - 2023-03-21 09:59:43 --> Language Class Initialized
INFO - 2023-03-21 09:59:43 --> Language Class Initialized
INFO - 2023-03-21 09:59:43 --> Loader Class Initialized
INFO - 2023-03-21 09:59:43 --> Loader Class Initialized
INFO - 2023-03-21 09:59:43 --> Controller Class Initialized
INFO - 2023-03-21 09:59:43 --> Controller Class Initialized
DEBUG - 2023-03-21 09:59:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 09:59:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:59:43 --> Database Driver Class Initialized
INFO - 2023-03-21 09:59:43 --> Final output sent to browser
DEBUG - 2023-03-21 09:59:43 --> Total execution time: 0.0581
INFO - 2023-03-21 09:59:43 --> Config Class Initialized
INFO - 2023-03-21 09:59:43 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:59:43 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:59:43 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:43 --> URI Class Initialized
INFO - 2023-03-21 09:59:43 --> Router Class Initialized
INFO - 2023-03-21 09:59:43 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:59:43 --> Output Class Initialized
INFO - 2023-03-21 09:59:43 --> Security Class Initialized
DEBUG - 2023-03-21 09:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:59:43 --> Input Class Initialized
INFO - 2023-03-21 09:59:43 --> Language Class Initialized
INFO - 2023-03-21 09:59:43 --> Loader Class Initialized
INFO - 2023-03-21 09:59:43 --> Controller Class Initialized
DEBUG - 2023-03-21 09:59:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 09:59:43 --> Database Driver Class Initialized
INFO - 2023-03-21 09:59:43 --> Final output sent to browser
DEBUG - 2023-03-21 09:59:43 --> Total execution time: 0.1259
INFO - 2023-03-21 09:59:43 --> Config Class Initialized
INFO - 2023-03-21 09:59:43 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:59:43 --> Hooks Class Initialized
DEBUG - 2023-03-21 09:59:43 --> UTF-8 Support Enabled
INFO - 2023-03-21 09:59:43 --> Utf8 Class Initialized
INFO - 2023-03-21 09:59:43 --> URI Class Initialized
INFO - 2023-03-21 09:59:43 --> Router Class Initialized
INFO - 2023-03-21 09:59:43 --> Output Class Initialized
INFO - 2023-03-21 09:59:43 --> Security Class Initialized
DEBUG - 2023-03-21 09:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 09:59:43 --> Input Class Initialized
INFO - 2023-03-21 09:59:43 --> Language Class Initialized
INFO - 2023-03-21 09:59:43 --> Loader Class Initialized
INFO - 2023-03-21 09:59:43 --> Controller Class Initialized
INFO - 2023-03-21 09:59:43 --> Final output sent to browser
DEBUG - 2023-03-21 09:59:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 09:59:43 --> Total execution time: 0.0478
INFO - 2023-03-21 09:59:43 --> Database Driver Class Initialized
INFO - 2023-03-21 09:59:43 --> Model "Cluster_model" initialized
INFO - 2023-03-21 09:59:43 --> Final output sent to browser
DEBUG - 2023-03-21 09:59:43 --> Total execution time: 0.0907
INFO - 2023-03-21 10:01:08 --> Config Class Initialized
INFO - 2023-03-21 10:01:08 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:01:08 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:01:08 --> Utf8 Class Initialized
INFO - 2023-03-21 10:01:08 --> URI Class Initialized
INFO - 2023-03-21 10:01:08 --> Router Class Initialized
INFO - 2023-03-21 10:01:08 --> Output Class Initialized
INFO - 2023-03-21 10:01:08 --> Security Class Initialized
DEBUG - 2023-03-21 10:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:01:08 --> Input Class Initialized
INFO - 2023-03-21 10:01:08 --> Language Class Initialized
INFO - 2023-03-21 10:01:08 --> Loader Class Initialized
INFO - 2023-03-21 10:01:08 --> Controller Class Initialized
DEBUG - 2023-03-21 10:01:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:01:08 --> Database Driver Class Initialized
INFO - 2023-03-21 10:01:08 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:01:08 --> Final output sent to browser
DEBUG - 2023-03-21 10:01:08 --> Total execution time: 0.0224
INFO - 2023-03-21 10:01:08 --> Config Class Initialized
INFO - 2023-03-21 10:01:08 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:01:08 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:01:08 --> Utf8 Class Initialized
INFO - 2023-03-21 10:01:08 --> URI Class Initialized
INFO - 2023-03-21 10:01:08 --> Router Class Initialized
INFO - 2023-03-21 10:01:08 --> Output Class Initialized
INFO - 2023-03-21 10:01:08 --> Security Class Initialized
DEBUG - 2023-03-21 10:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:01:08 --> Input Class Initialized
INFO - 2023-03-21 10:01:08 --> Language Class Initialized
INFO - 2023-03-21 10:01:08 --> Loader Class Initialized
INFO - 2023-03-21 10:01:08 --> Controller Class Initialized
DEBUG - 2023-03-21 10:01:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:01:08 --> Database Driver Class Initialized
INFO - 2023-03-21 10:01:08 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:01:08 --> Final output sent to browser
DEBUG - 2023-03-21 10:01:08 --> Total execution time: 0.0170
INFO - 2023-03-21 10:06:27 --> Config Class Initialized
INFO - 2023-03-21 10:06:27 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:06:27 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:06:27 --> Utf8 Class Initialized
INFO - 2023-03-21 10:06:27 --> URI Class Initialized
INFO - 2023-03-21 10:06:27 --> Router Class Initialized
INFO - 2023-03-21 10:06:27 --> Output Class Initialized
INFO - 2023-03-21 10:06:27 --> Security Class Initialized
DEBUG - 2023-03-21 10:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:06:27 --> Input Class Initialized
INFO - 2023-03-21 10:06:27 --> Language Class Initialized
INFO - 2023-03-21 10:06:27 --> Loader Class Initialized
INFO - 2023-03-21 10:06:27 --> Controller Class Initialized
DEBUG - 2023-03-21 10:06:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:06:27 --> Database Driver Class Initialized
INFO - 2023-03-21 10:06:28 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:06:28 --> Final output sent to browser
DEBUG - 2023-03-21 10:06:28 --> Total execution time: 0.0258
INFO - 2023-03-21 10:06:28 --> Config Class Initialized
INFO - 2023-03-21 10:06:28 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:06:28 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:06:28 --> Utf8 Class Initialized
INFO - 2023-03-21 10:06:28 --> URI Class Initialized
INFO - 2023-03-21 10:06:28 --> Router Class Initialized
INFO - 2023-03-21 10:06:28 --> Output Class Initialized
INFO - 2023-03-21 10:06:28 --> Security Class Initialized
DEBUG - 2023-03-21 10:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:06:28 --> Input Class Initialized
INFO - 2023-03-21 10:06:28 --> Language Class Initialized
INFO - 2023-03-21 10:06:28 --> Loader Class Initialized
INFO - 2023-03-21 10:06:28 --> Controller Class Initialized
DEBUG - 2023-03-21 10:06:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:06:28 --> Database Driver Class Initialized
INFO - 2023-03-21 10:06:28 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:06:28 --> Final output sent to browser
DEBUG - 2023-03-21 10:06:28 --> Total execution time: 0.0187
INFO - 2023-03-21 10:06:29 --> Config Class Initialized
INFO - 2023-03-21 10:06:29 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:06:29 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:06:29 --> Utf8 Class Initialized
INFO - 2023-03-21 10:06:29 --> URI Class Initialized
INFO - 2023-03-21 10:06:29 --> Router Class Initialized
INFO - 2023-03-21 10:06:29 --> Output Class Initialized
INFO - 2023-03-21 10:06:29 --> Security Class Initialized
DEBUG - 2023-03-21 10:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:06:29 --> Input Class Initialized
INFO - 2023-03-21 10:06:29 --> Language Class Initialized
INFO - 2023-03-21 10:06:29 --> Loader Class Initialized
INFO - 2023-03-21 10:06:29 --> Controller Class Initialized
DEBUG - 2023-03-21 10:06:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:06:29 --> Database Driver Class Initialized
INFO - 2023-03-21 10:06:29 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:06:29 --> Final output sent to browser
DEBUG - 2023-03-21 10:06:29 --> Total execution time: 0.0142
INFO - 2023-03-21 10:06:29 --> Config Class Initialized
INFO - 2023-03-21 10:06:29 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:06:29 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:06:29 --> Utf8 Class Initialized
INFO - 2023-03-21 10:06:29 --> URI Class Initialized
INFO - 2023-03-21 10:06:29 --> Router Class Initialized
INFO - 2023-03-21 10:06:29 --> Output Class Initialized
INFO - 2023-03-21 10:06:29 --> Security Class Initialized
DEBUG - 2023-03-21 10:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:06:29 --> Input Class Initialized
INFO - 2023-03-21 10:06:29 --> Language Class Initialized
INFO - 2023-03-21 10:06:29 --> Loader Class Initialized
INFO - 2023-03-21 10:06:29 --> Controller Class Initialized
DEBUG - 2023-03-21 10:06:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:06:29 --> Database Driver Class Initialized
INFO - 2023-03-21 10:06:29 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:06:29 --> Final output sent to browser
DEBUG - 2023-03-21 10:06:29 --> Total execution time: 0.0564
INFO - 2023-03-21 10:06:31 --> Config Class Initialized
INFO - 2023-03-21 10:06:31 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:06:31 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:06:31 --> Utf8 Class Initialized
INFO - 2023-03-21 10:06:31 --> URI Class Initialized
INFO - 2023-03-21 10:06:31 --> Router Class Initialized
INFO - 2023-03-21 10:06:31 --> Output Class Initialized
INFO - 2023-03-21 10:06:31 --> Security Class Initialized
DEBUG - 2023-03-21 10:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:06:31 --> Input Class Initialized
INFO - 2023-03-21 10:06:31 --> Language Class Initialized
INFO - 2023-03-21 10:06:31 --> Loader Class Initialized
INFO - 2023-03-21 10:06:31 --> Controller Class Initialized
DEBUG - 2023-03-21 10:06:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:06:31 --> Database Driver Class Initialized
INFO - 2023-03-21 10:06:31 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:06:31 --> Final output sent to browser
DEBUG - 2023-03-21 10:06:31 --> Total execution time: 0.1928
INFO - 2023-03-21 10:07:31 --> Config Class Initialized
INFO - 2023-03-21 10:07:31 --> Config Class Initialized
INFO - 2023-03-21 10:07:31 --> Hooks Class Initialized
INFO - 2023-03-21 10:07:31 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:07:31 --> UTF-8 Support Enabled
DEBUG - 2023-03-21 10:07:31 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:07:31 --> Utf8 Class Initialized
INFO - 2023-03-21 10:07:31 --> Utf8 Class Initialized
INFO - 2023-03-21 10:07:31 --> URI Class Initialized
INFO - 2023-03-21 10:07:31 --> URI Class Initialized
INFO - 2023-03-21 10:07:31 --> Router Class Initialized
INFO - 2023-03-21 10:07:31 --> Router Class Initialized
INFO - 2023-03-21 10:07:31 --> Output Class Initialized
INFO - 2023-03-21 10:07:31 --> Output Class Initialized
INFO - 2023-03-21 10:07:31 --> Security Class Initialized
DEBUG - 2023-03-21 10:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:07:31 --> Security Class Initialized
INFO - 2023-03-21 10:07:31 --> Input Class Initialized
DEBUG - 2023-03-21 10:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:07:31 --> Language Class Initialized
INFO - 2023-03-21 10:07:31 --> Input Class Initialized
INFO - 2023-03-21 10:07:31 --> Language Class Initialized
INFO - 2023-03-21 10:07:31 --> Loader Class Initialized
INFO - 2023-03-21 10:07:31 --> Loader Class Initialized
INFO - 2023-03-21 10:07:31 --> Controller Class Initialized
INFO - 2023-03-21 10:07:31 --> Controller Class Initialized
DEBUG - 2023-03-21 10:07:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 10:07:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:07:31 --> Database Driver Class Initialized
INFO - 2023-03-21 10:07:31 --> Database Driver Class Initialized
INFO - 2023-03-21 10:07:31 --> Model "Login_model" initialized
INFO - 2023-03-21 10:07:31 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:07:31 --> Database Driver Class Initialized
INFO - 2023-03-21 10:07:31 --> Final output sent to browser
DEBUG - 2023-03-21 10:07:31 --> Total execution time: 0.0235
INFO - 2023-03-21 10:07:31 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:07:31 --> Config Class Initialized
INFO - 2023-03-21 10:07:31 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:07:31 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:07:31 --> Utf8 Class Initialized
INFO - 2023-03-21 10:07:31 --> URI Class Initialized
INFO - 2023-03-21 10:07:31 --> Router Class Initialized
INFO - 2023-03-21 10:07:31 --> Output Class Initialized
INFO - 2023-03-21 10:07:31 --> Security Class Initialized
DEBUG - 2023-03-21 10:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:07:31 --> Input Class Initialized
INFO - 2023-03-21 10:07:31 --> Language Class Initialized
INFO - 2023-03-21 10:07:31 --> Loader Class Initialized
INFO - 2023-03-21 10:07:31 --> Controller Class Initialized
DEBUG - 2023-03-21 10:07:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:07:31 --> Database Driver Class Initialized
INFO - 2023-03-21 10:07:31 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:07:31 --> Final output sent to browser
DEBUG - 2023-03-21 10:07:31 --> Total execution time: 0.0563
INFO - 2023-03-21 10:07:32 --> Final output sent to browser
DEBUG - 2023-03-21 10:07:32 --> Total execution time: 1.0127
INFO - 2023-03-21 10:07:32 --> Config Class Initialized
INFO - 2023-03-21 10:07:32 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:07:32 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:07:32 --> Utf8 Class Initialized
INFO - 2023-03-21 10:07:32 --> URI Class Initialized
INFO - 2023-03-21 10:07:32 --> Router Class Initialized
INFO - 2023-03-21 10:07:32 --> Output Class Initialized
INFO - 2023-03-21 10:07:32 --> Security Class Initialized
DEBUG - 2023-03-21 10:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:07:32 --> Input Class Initialized
INFO - 2023-03-21 10:07:32 --> Language Class Initialized
INFO - 2023-03-21 10:07:32 --> Loader Class Initialized
INFO - 2023-03-21 10:07:32 --> Controller Class Initialized
DEBUG - 2023-03-21 10:07:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:07:32 --> Database Driver Class Initialized
INFO - 2023-03-21 10:07:32 --> Model "Login_model" initialized
INFO - 2023-03-21 10:07:32 --> Database Driver Class Initialized
INFO - 2023-03-21 10:07:32 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:07:33 --> Final output sent to browser
DEBUG - 2023-03-21 10:07:33 --> Total execution time: 0.9215
INFO - 2023-03-21 10:08:01 --> Config Class Initialized
INFO - 2023-03-21 10:08:01 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:08:01 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:08:01 --> Utf8 Class Initialized
INFO - 2023-03-21 10:08:01 --> URI Class Initialized
INFO - 2023-03-21 10:08:01 --> Router Class Initialized
INFO - 2023-03-21 10:08:01 --> Output Class Initialized
INFO - 2023-03-21 10:08:01 --> Security Class Initialized
DEBUG - 2023-03-21 10:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:08:01 --> Input Class Initialized
INFO - 2023-03-21 10:08:01 --> Language Class Initialized
INFO - 2023-03-21 10:08:01 --> Loader Class Initialized
INFO - 2023-03-21 10:08:01 --> Controller Class Initialized
DEBUG - 2023-03-21 10:08:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:08:01 --> Database Driver Class Initialized
INFO - 2023-03-21 10:08:01 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:08:01 --> Final output sent to browser
DEBUG - 2023-03-21 10:08:01 --> Total execution time: 0.0741
INFO - 2023-03-21 10:08:01 --> Config Class Initialized
INFO - 2023-03-21 10:08:01 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:08:01 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:08:01 --> Utf8 Class Initialized
INFO - 2023-03-21 10:08:01 --> URI Class Initialized
INFO - 2023-03-21 10:08:01 --> Router Class Initialized
INFO - 2023-03-21 10:08:01 --> Output Class Initialized
INFO - 2023-03-21 10:08:01 --> Security Class Initialized
DEBUG - 2023-03-21 10:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:08:01 --> Input Class Initialized
INFO - 2023-03-21 10:08:01 --> Language Class Initialized
INFO - 2023-03-21 10:08:01 --> Loader Class Initialized
INFO - 2023-03-21 10:08:01 --> Controller Class Initialized
DEBUG - 2023-03-21 10:08:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:08:01 --> Database Driver Class Initialized
INFO - 2023-03-21 10:08:01 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:08:02 --> Final output sent to browser
DEBUG - 2023-03-21 10:08:02 --> Total execution time: 0.1149
INFO - 2023-03-21 10:08:05 --> Config Class Initialized
INFO - 2023-03-21 10:08:05 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:08:05 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:08:05 --> Utf8 Class Initialized
INFO - 2023-03-21 10:08:05 --> URI Class Initialized
INFO - 2023-03-21 10:08:05 --> Router Class Initialized
INFO - 2023-03-21 10:08:05 --> Output Class Initialized
INFO - 2023-03-21 10:08:05 --> Security Class Initialized
DEBUG - 2023-03-21 10:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:08:05 --> Input Class Initialized
INFO - 2023-03-21 10:08:05 --> Language Class Initialized
INFO - 2023-03-21 10:08:05 --> Loader Class Initialized
INFO - 2023-03-21 10:08:05 --> Controller Class Initialized
DEBUG - 2023-03-21 10:08:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:08:05 --> Database Driver Class Initialized
INFO - 2023-03-21 10:08:05 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:08:05 --> Final output sent to browser
DEBUG - 2023-03-21 10:08:05 --> Total execution time: 0.0531
INFO - 2023-03-21 10:08:14 --> Config Class Initialized
INFO - 2023-03-21 10:08:14 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:08:14 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:08:14 --> Utf8 Class Initialized
INFO - 2023-03-21 10:08:14 --> URI Class Initialized
INFO - 2023-03-21 10:08:14 --> Router Class Initialized
INFO - 2023-03-21 10:08:14 --> Output Class Initialized
INFO - 2023-03-21 10:08:14 --> Security Class Initialized
DEBUG - 2023-03-21 10:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:08:14 --> Input Class Initialized
INFO - 2023-03-21 10:08:14 --> Language Class Initialized
INFO - 2023-03-21 10:08:14 --> Loader Class Initialized
INFO - 2023-03-21 10:08:14 --> Controller Class Initialized
DEBUG - 2023-03-21 10:08:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:08:14 --> Database Driver Class Initialized
INFO - 2023-03-21 10:08:14 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:08:14 --> Final output sent to browser
DEBUG - 2023-03-21 10:08:14 --> Total execution time: 0.0486
INFO - 2023-03-21 10:08:14 --> Config Class Initialized
INFO - 2023-03-21 10:08:14 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:08:14 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:08:14 --> Utf8 Class Initialized
INFO - 2023-03-21 10:08:14 --> URI Class Initialized
INFO - 2023-03-21 10:08:14 --> Router Class Initialized
INFO - 2023-03-21 10:08:14 --> Output Class Initialized
INFO - 2023-03-21 10:08:14 --> Security Class Initialized
DEBUG - 2023-03-21 10:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:08:14 --> Input Class Initialized
INFO - 2023-03-21 10:08:14 --> Language Class Initialized
INFO - 2023-03-21 10:08:14 --> Loader Class Initialized
INFO - 2023-03-21 10:08:14 --> Controller Class Initialized
DEBUG - 2023-03-21 10:08:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:08:14 --> Database Driver Class Initialized
INFO - 2023-03-21 10:08:14 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:08:14 --> Final output sent to browser
DEBUG - 2023-03-21 10:08:14 --> Total execution time: 0.0803
INFO - 2023-03-21 10:08:15 --> Config Class Initialized
INFO - 2023-03-21 10:08:15 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:08:15 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:08:15 --> Utf8 Class Initialized
INFO - 2023-03-21 10:08:15 --> URI Class Initialized
INFO - 2023-03-21 10:08:15 --> Router Class Initialized
INFO - 2023-03-21 10:08:15 --> Output Class Initialized
INFO - 2023-03-21 10:08:15 --> Security Class Initialized
DEBUG - 2023-03-21 10:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:08:15 --> Input Class Initialized
INFO - 2023-03-21 10:08:15 --> Language Class Initialized
INFO - 2023-03-21 10:08:15 --> Loader Class Initialized
INFO - 2023-03-21 10:08:15 --> Controller Class Initialized
DEBUG - 2023-03-21 10:08:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:08:15 --> Database Driver Class Initialized
INFO - 2023-03-21 10:08:15 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:08:15 --> Final output sent to browser
DEBUG - 2023-03-21 10:08:15 --> Total execution time: 0.0441
INFO - 2023-03-21 10:08:15 --> Config Class Initialized
INFO - 2023-03-21 10:08:15 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:08:15 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:08:15 --> Utf8 Class Initialized
INFO - 2023-03-21 10:08:15 --> URI Class Initialized
INFO - 2023-03-21 10:08:15 --> Router Class Initialized
INFO - 2023-03-21 10:08:15 --> Output Class Initialized
INFO - 2023-03-21 10:08:15 --> Security Class Initialized
DEBUG - 2023-03-21 10:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:08:15 --> Input Class Initialized
INFO - 2023-03-21 10:08:15 --> Language Class Initialized
INFO - 2023-03-21 10:08:15 --> Loader Class Initialized
INFO - 2023-03-21 10:08:15 --> Controller Class Initialized
DEBUG - 2023-03-21 10:08:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:08:15 --> Database Driver Class Initialized
INFO - 2023-03-21 10:08:15 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:08:15 --> Final output sent to browser
DEBUG - 2023-03-21 10:08:15 --> Total execution time: 0.0483
INFO - 2023-03-21 10:08:19 --> Config Class Initialized
INFO - 2023-03-21 10:08:19 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:08:19 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:08:19 --> Utf8 Class Initialized
INFO - 2023-03-21 10:08:19 --> URI Class Initialized
INFO - 2023-03-21 10:08:19 --> Router Class Initialized
INFO - 2023-03-21 10:08:19 --> Output Class Initialized
INFO - 2023-03-21 10:08:19 --> Security Class Initialized
DEBUG - 2023-03-21 10:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:08:19 --> Input Class Initialized
INFO - 2023-03-21 10:08:19 --> Language Class Initialized
INFO - 2023-03-21 10:08:19 --> Loader Class Initialized
INFO - 2023-03-21 10:08:19 --> Controller Class Initialized
DEBUG - 2023-03-21 10:08:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:08:19 --> Database Driver Class Initialized
INFO - 2023-03-21 10:08:19 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:08:19 --> Final output sent to browser
DEBUG - 2023-03-21 10:08:19 --> Total execution time: 0.0154
INFO - 2023-03-21 10:08:19 --> Config Class Initialized
INFO - 2023-03-21 10:08:19 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:08:19 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:08:19 --> Utf8 Class Initialized
INFO - 2023-03-21 10:08:19 --> URI Class Initialized
INFO - 2023-03-21 10:08:19 --> Router Class Initialized
INFO - 2023-03-21 10:08:19 --> Output Class Initialized
INFO - 2023-03-21 10:08:19 --> Security Class Initialized
DEBUG - 2023-03-21 10:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:08:19 --> Input Class Initialized
INFO - 2023-03-21 10:08:19 --> Language Class Initialized
INFO - 2023-03-21 10:08:19 --> Loader Class Initialized
INFO - 2023-03-21 10:08:19 --> Controller Class Initialized
DEBUG - 2023-03-21 10:08:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:08:19 --> Database Driver Class Initialized
INFO - 2023-03-21 10:08:19 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:08:19 --> Final output sent to browser
DEBUG - 2023-03-21 10:08:19 --> Total execution time: 0.0154
INFO - 2023-03-21 10:08:21 --> Config Class Initialized
INFO - 2023-03-21 10:08:21 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:08:21 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:08:21 --> Utf8 Class Initialized
INFO - 2023-03-21 10:08:21 --> URI Class Initialized
INFO - 2023-03-21 10:08:21 --> Router Class Initialized
INFO - 2023-03-21 10:08:21 --> Output Class Initialized
INFO - 2023-03-21 10:08:21 --> Security Class Initialized
DEBUG - 2023-03-21 10:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:08:21 --> Input Class Initialized
INFO - 2023-03-21 10:08:21 --> Language Class Initialized
INFO - 2023-03-21 10:08:21 --> Loader Class Initialized
INFO - 2023-03-21 10:08:21 --> Controller Class Initialized
DEBUG - 2023-03-21 10:08:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:08:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:08:21 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:08:21 --> Final output sent to browser
DEBUG - 2023-03-21 10:08:21 --> Total execution time: 0.0358
INFO - 2023-03-21 10:08:21 --> Config Class Initialized
INFO - 2023-03-21 10:08:21 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:08:21 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:08:21 --> Utf8 Class Initialized
INFO - 2023-03-21 10:08:21 --> URI Class Initialized
INFO - 2023-03-21 10:08:21 --> Router Class Initialized
INFO - 2023-03-21 10:08:21 --> Output Class Initialized
INFO - 2023-03-21 10:08:21 --> Security Class Initialized
DEBUG - 2023-03-21 10:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:08:21 --> Input Class Initialized
INFO - 2023-03-21 10:08:21 --> Language Class Initialized
INFO - 2023-03-21 10:08:21 --> Loader Class Initialized
INFO - 2023-03-21 10:08:21 --> Controller Class Initialized
DEBUG - 2023-03-21 10:08:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:08:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:08:21 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:08:21 --> Final output sent to browser
DEBUG - 2023-03-21 10:08:21 --> Total execution time: 0.0583
INFO - 2023-03-21 10:09:21 --> Config Class Initialized
INFO - 2023-03-21 10:09:21 --> Config Class Initialized
INFO - 2023-03-21 10:09:21 --> Hooks Class Initialized
INFO - 2023-03-21 10:09:21 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:09:21 --> UTF-8 Support Enabled
DEBUG - 2023-03-21 10:09:21 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:09:21 --> Utf8 Class Initialized
INFO - 2023-03-21 10:09:21 --> Utf8 Class Initialized
INFO - 2023-03-21 10:09:21 --> URI Class Initialized
INFO - 2023-03-21 10:09:21 --> URI Class Initialized
INFO - 2023-03-21 10:09:21 --> Router Class Initialized
INFO - 2023-03-21 10:09:21 --> Router Class Initialized
INFO - 2023-03-21 10:09:21 --> Output Class Initialized
INFO - 2023-03-21 10:09:21 --> Output Class Initialized
INFO - 2023-03-21 10:09:21 --> Security Class Initialized
INFO - 2023-03-21 10:09:21 --> Security Class Initialized
DEBUG - 2023-03-21 10:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-21 10:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:09:21 --> Input Class Initialized
INFO - 2023-03-21 10:09:21 --> Input Class Initialized
INFO - 2023-03-21 10:09:21 --> Language Class Initialized
INFO - 2023-03-21 10:09:21 --> Language Class Initialized
INFO - 2023-03-21 10:09:21 --> Loader Class Initialized
INFO - 2023-03-21 10:09:21 --> Loader Class Initialized
INFO - 2023-03-21 10:09:21 --> Controller Class Initialized
INFO - 2023-03-21 10:09:21 --> Controller Class Initialized
DEBUG - 2023-03-21 10:09:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 10:09:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:09:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:09:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:09:21 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:09:21 --> Model "Login_model" initialized
INFO - 2023-03-21 10:09:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:09:21 --> Final output sent to browser
DEBUG - 2023-03-21 10:09:21 --> Total execution time: 0.0247
INFO - 2023-03-21 10:09:21 --> Config Class Initialized
INFO - 2023-03-21 10:09:21 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:09:21 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:09:21 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:09:21 --> Utf8 Class Initialized
INFO - 2023-03-21 10:09:21 --> URI Class Initialized
INFO - 2023-03-21 10:09:21 --> Router Class Initialized
INFO - 2023-03-21 10:09:21 --> Output Class Initialized
INFO - 2023-03-21 10:09:21 --> Security Class Initialized
DEBUG - 2023-03-21 10:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:09:21 --> Input Class Initialized
INFO - 2023-03-21 10:09:21 --> Language Class Initialized
INFO - 2023-03-21 10:09:21 --> Loader Class Initialized
INFO - 2023-03-21 10:09:21 --> Controller Class Initialized
DEBUG - 2023-03-21 10:09:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:09:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:09:21 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:09:21 --> Final output sent to browser
DEBUG - 2023-03-21 10:09:21 --> Total execution time: 0.0647
INFO - 2023-03-21 10:09:22 --> Final output sent to browser
DEBUG - 2023-03-21 10:09:22 --> Total execution time: 0.9693
INFO - 2023-03-21 10:09:22 --> Config Class Initialized
INFO - 2023-03-21 10:09:22 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:09:22 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:09:22 --> Utf8 Class Initialized
INFO - 2023-03-21 10:09:22 --> URI Class Initialized
INFO - 2023-03-21 10:09:22 --> Router Class Initialized
INFO - 2023-03-21 10:09:22 --> Output Class Initialized
INFO - 2023-03-21 10:09:22 --> Security Class Initialized
DEBUG - 2023-03-21 10:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:09:22 --> Input Class Initialized
INFO - 2023-03-21 10:09:22 --> Language Class Initialized
INFO - 2023-03-21 10:09:22 --> Loader Class Initialized
INFO - 2023-03-21 10:09:22 --> Controller Class Initialized
DEBUG - 2023-03-21 10:09:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:09:22 --> Database Driver Class Initialized
INFO - 2023-03-21 10:09:22 --> Model "Login_model" initialized
INFO - 2023-03-21 10:09:22 --> Database Driver Class Initialized
INFO - 2023-03-21 10:09:22 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:09:23 --> Final output sent to browser
DEBUG - 2023-03-21 10:09:23 --> Total execution time: 0.9301
INFO - 2023-03-21 10:09:27 --> Config Class Initialized
INFO - 2023-03-21 10:09:27 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:09:27 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:09:27 --> Utf8 Class Initialized
INFO - 2023-03-21 10:09:27 --> URI Class Initialized
INFO - 2023-03-21 10:09:27 --> Router Class Initialized
INFO - 2023-03-21 10:09:27 --> Output Class Initialized
INFO - 2023-03-21 10:09:27 --> Security Class Initialized
DEBUG - 2023-03-21 10:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:09:27 --> Input Class Initialized
INFO - 2023-03-21 10:09:27 --> Language Class Initialized
INFO - 2023-03-21 10:09:27 --> Loader Class Initialized
INFO - 2023-03-21 10:09:27 --> Controller Class Initialized
DEBUG - 2023-03-21 10:09:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:09:27 --> Database Driver Class Initialized
INFO - 2023-03-21 10:09:27 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:09:27 --> Final output sent to browser
DEBUG - 2023-03-21 10:09:27 --> Total execution time: 0.0205
INFO - 2023-03-21 10:09:27 --> Config Class Initialized
INFO - 2023-03-21 10:09:27 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:09:27 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:09:27 --> Utf8 Class Initialized
INFO - 2023-03-21 10:09:27 --> URI Class Initialized
INFO - 2023-03-21 10:09:27 --> Router Class Initialized
INFO - 2023-03-21 10:09:27 --> Output Class Initialized
INFO - 2023-03-21 10:09:27 --> Security Class Initialized
DEBUG - 2023-03-21 10:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:09:27 --> Input Class Initialized
INFO - 2023-03-21 10:09:27 --> Language Class Initialized
INFO - 2023-03-21 10:09:27 --> Loader Class Initialized
INFO - 2023-03-21 10:09:27 --> Controller Class Initialized
DEBUG - 2023-03-21 10:09:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:09:27 --> Database Driver Class Initialized
INFO - 2023-03-21 10:09:27 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:09:27 --> Final output sent to browser
DEBUG - 2023-03-21 10:09:27 --> Total execution time: 0.0133
INFO - 2023-03-21 10:09:33 --> Config Class Initialized
INFO - 2023-03-21 10:09:33 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:09:33 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:09:33 --> Utf8 Class Initialized
INFO - 2023-03-21 10:09:33 --> URI Class Initialized
INFO - 2023-03-21 10:09:33 --> Router Class Initialized
INFO - 2023-03-21 10:09:33 --> Output Class Initialized
INFO - 2023-03-21 10:09:33 --> Security Class Initialized
DEBUG - 2023-03-21 10:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:09:33 --> Input Class Initialized
INFO - 2023-03-21 10:09:33 --> Language Class Initialized
INFO - 2023-03-21 10:09:33 --> Loader Class Initialized
INFO - 2023-03-21 10:09:33 --> Controller Class Initialized
DEBUG - 2023-03-21 10:09:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:09:33 --> Database Driver Class Initialized
INFO - 2023-03-21 10:09:33 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:09:33 --> Final output sent to browser
DEBUG - 2023-03-21 10:09:33 --> Total execution time: 0.0165
INFO - 2023-03-21 10:09:33 --> Config Class Initialized
INFO - 2023-03-21 10:09:33 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:09:33 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:09:33 --> Utf8 Class Initialized
INFO - 2023-03-21 10:09:33 --> URI Class Initialized
INFO - 2023-03-21 10:09:33 --> Router Class Initialized
INFO - 2023-03-21 10:09:33 --> Output Class Initialized
INFO - 2023-03-21 10:09:33 --> Security Class Initialized
DEBUG - 2023-03-21 10:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:09:33 --> Input Class Initialized
INFO - 2023-03-21 10:09:33 --> Language Class Initialized
INFO - 2023-03-21 10:09:33 --> Loader Class Initialized
INFO - 2023-03-21 10:09:33 --> Controller Class Initialized
DEBUG - 2023-03-21 10:09:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:09:33 --> Database Driver Class Initialized
INFO - 2023-03-21 10:09:34 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:09:34 --> Final output sent to browser
DEBUG - 2023-03-21 10:09:34 --> Total execution time: 0.0629
INFO - 2023-03-21 10:09:39 --> Config Class Initialized
INFO - 2023-03-21 10:09:39 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:09:39 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:09:39 --> Utf8 Class Initialized
INFO - 2023-03-21 10:09:39 --> URI Class Initialized
INFO - 2023-03-21 10:09:39 --> Router Class Initialized
INFO - 2023-03-21 10:09:39 --> Output Class Initialized
INFO - 2023-03-21 10:09:39 --> Security Class Initialized
DEBUG - 2023-03-21 10:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:09:39 --> Input Class Initialized
INFO - 2023-03-21 10:09:39 --> Language Class Initialized
INFO - 2023-03-21 10:09:39 --> Loader Class Initialized
INFO - 2023-03-21 10:09:39 --> Controller Class Initialized
DEBUG - 2023-03-21 10:09:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:09:39 --> Database Driver Class Initialized
INFO - 2023-03-21 10:09:39 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:09:39 --> Final output sent to browser
DEBUG - 2023-03-21 10:09:39 --> Total execution time: 0.0202
INFO - 2023-03-21 10:09:39 --> Config Class Initialized
INFO - 2023-03-21 10:09:39 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:09:39 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:09:39 --> Utf8 Class Initialized
INFO - 2023-03-21 10:09:39 --> URI Class Initialized
INFO - 2023-03-21 10:09:39 --> Router Class Initialized
INFO - 2023-03-21 10:09:39 --> Output Class Initialized
INFO - 2023-03-21 10:09:39 --> Security Class Initialized
DEBUG - 2023-03-21 10:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:09:39 --> Input Class Initialized
INFO - 2023-03-21 10:09:39 --> Language Class Initialized
INFO - 2023-03-21 10:09:39 --> Loader Class Initialized
INFO - 2023-03-21 10:09:39 --> Controller Class Initialized
DEBUG - 2023-03-21 10:09:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:09:39 --> Database Driver Class Initialized
INFO - 2023-03-21 10:09:39 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:09:39 --> Final output sent to browser
DEBUG - 2023-03-21 10:09:39 --> Total execution time: 0.0569
INFO - 2023-03-21 10:10:21 --> Config Class Initialized
INFO - 2023-03-21 10:10:21 --> Config Class Initialized
INFO - 2023-03-21 10:10:21 --> Hooks Class Initialized
INFO - 2023-03-21 10:10:21 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:10:21 --> UTF-8 Support Enabled
DEBUG - 2023-03-21 10:10:21 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:10:21 --> Utf8 Class Initialized
INFO - 2023-03-21 10:10:21 --> Utf8 Class Initialized
INFO - 2023-03-21 10:10:21 --> URI Class Initialized
INFO - 2023-03-21 10:10:21 --> URI Class Initialized
INFO - 2023-03-21 10:10:21 --> Router Class Initialized
INFO - 2023-03-21 10:10:21 --> Router Class Initialized
INFO - 2023-03-21 10:10:21 --> Output Class Initialized
INFO - 2023-03-21 10:10:21 --> Output Class Initialized
INFO - 2023-03-21 10:10:21 --> Security Class Initialized
INFO - 2023-03-21 10:10:21 --> Security Class Initialized
DEBUG - 2023-03-21 10:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-21 10:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:10:21 --> Input Class Initialized
INFO - 2023-03-21 10:10:21 --> Input Class Initialized
INFO - 2023-03-21 10:10:21 --> Language Class Initialized
INFO - 2023-03-21 10:10:21 --> Language Class Initialized
INFO - 2023-03-21 10:10:21 --> Loader Class Initialized
INFO - 2023-03-21 10:10:21 --> Loader Class Initialized
INFO - 2023-03-21 10:10:21 --> Controller Class Initialized
INFO - 2023-03-21 10:10:21 --> Controller Class Initialized
DEBUG - 2023-03-21 10:10:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 10:10:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:10:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:10:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:10:21 --> Model "Login_model" initialized
INFO - 2023-03-21 10:10:21 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:10:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:10:21 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:10:21 --> Final output sent to browser
DEBUG - 2023-03-21 10:10:21 --> Total execution time: 0.0235
INFO - 2023-03-21 10:10:21 --> Config Class Initialized
INFO - 2023-03-21 10:10:21 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:10:21 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:10:21 --> Utf8 Class Initialized
INFO - 2023-03-21 10:10:21 --> URI Class Initialized
INFO - 2023-03-21 10:10:21 --> Router Class Initialized
INFO - 2023-03-21 10:10:21 --> Output Class Initialized
INFO - 2023-03-21 10:10:21 --> Security Class Initialized
DEBUG - 2023-03-21 10:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:10:21 --> Input Class Initialized
INFO - 2023-03-21 10:10:21 --> Language Class Initialized
INFO - 2023-03-21 10:10:21 --> Loader Class Initialized
INFO - 2023-03-21 10:10:21 --> Controller Class Initialized
DEBUG - 2023-03-21 10:10:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:10:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:10:21 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:10:21 --> Final output sent to browser
DEBUG - 2023-03-21 10:10:21 --> Total execution time: 0.0573
INFO - 2023-03-21 10:10:22 --> Final output sent to browser
DEBUG - 2023-03-21 10:10:22 --> Total execution time: 0.8573
INFO - 2023-03-21 10:10:22 --> Config Class Initialized
INFO - 2023-03-21 10:10:22 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:10:22 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:10:22 --> Utf8 Class Initialized
INFO - 2023-03-21 10:10:22 --> URI Class Initialized
INFO - 2023-03-21 10:10:22 --> Router Class Initialized
INFO - 2023-03-21 10:10:22 --> Output Class Initialized
INFO - 2023-03-21 10:10:22 --> Security Class Initialized
DEBUG - 2023-03-21 10:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:10:22 --> Input Class Initialized
INFO - 2023-03-21 10:10:22 --> Language Class Initialized
INFO - 2023-03-21 10:10:22 --> Loader Class Initialized
INFO - 2023-03-21 10:10:22 --> Controller Class Initialized
DEBUG - 2023-03-21 10:10:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:10:22 --> Database Driver Class Initialized
INFO - 2023-03-21 10:10:22 --> Model "Login_model" initialized
INFO - 2023-03-21 10:10:22 --> Database Driver Class Initialized
INFO - 2023-03-21 10:10:22 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:10:23 --> Final output sent to browser
DEBUG - 2023-03-21 10:10:23 --> Total execution time: 0.9230
INFO - 2023-03-21 10:11:21 --> Config Class Initialized
INFO - 2023-03-21 10:11:21 --> Config Class Initialized
INFO - 2023-03-21 10:11:21 --> Hooks Class Initialized
INFO - 2023-03-21 10:11:21 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:11:21 --> UTF-8 Support Enabled
DEBUG - 2023-03-21 10:11:21 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:11:21 --> Utf8 Class Initialized
INFO - 2023-03-21 10:11:21 --> Utf8 Class Initialized
INFO - 2023-03-21 10:11:21 --> URI Class Initialized
INFO - 2023-03-21 10:11:21 --> URI Class Initialized
INFO - 2023-03-21 10:11:21 --> Router Class Initialized
INFO - 2023-03-21 10:11:21 --> Router Class Initialized
INFO - 2023-03-21 10:11:21 --> Output Class Initialized
INFO - 2023-03-21 10:11:21 --> Output Class Initialized
INFO - 2023-03-21 10:11:21 --> Security Class Initialized
INFO - 2023-03-21 10:11:21 --> Security Class Initialized
DEBUG - 2023-03-21 10:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-21 10:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:11:21 --> Input Class Initialized
INFO - 2023-03-21 10:11:21 --> Input Class Initialized
INFO - 2023-03-21 10:11:21 --> Language Class Initialized
INFO - 2023-03-21 10:11:21 --> Language Class Initialized
INFO - 2023-03-21 10:11:21 --> Loader Class Initialized
INFO - 2023-03-21 10:11:21 --> Loader Class Initialized
INFO - 2023-03-21 10:11:21 --> Controller Class Initialized
INFO - 2023-03-21 10:11:21 --> Controller Class Initialized
DEBUG - 2023-03-21 10:11:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 10:11:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:11:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:11:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:11:21 --> Model "Login_model" initialized
INFO - 2023-03-21 10:11:21 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:11:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:11:21 --> Final output sent to browser
DEBUG - 2023-03-21 10:11:21 --> Total execution time: 0.1422
INFO - 2023-03-21 10:11:21 --> Config Class Initialized
INFO - 2023-03-21 10:11:21 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:11:21 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:11:21 --> Utf8 Class Initialized
INFO - 2023-03-21 10:11:21 --> URI Class Initialized
INFO - 2023-03-21 10:11:21 --> Router Class Initialized
INFO - 2023-03-21 10:11:21 --> Output Class Initialized
INFO - 2023-03-21 10:11:21 --> Security Class Initialized
DEBUG - 2023-03-21 10:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:11:21 --> Input Class Initialized
INFO - 2023-03-21 10:11:21 --> Language Class Initialized
INFO - 2023-03-21 10:11:21 --> Loader Class Initialized
INFO - 2023-03-21 10:11:21 --> Controller Class Initialized
INFO - 2023-03-21 10:11:21 --> Model "Cluster_model" initialized
DEBUG - 2023-03-21 10:11:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:11:21 --> Database Driver Class Initialized
INFO - 2023-03-21 10:11:21 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:11:21 --> Final output sent to browser
DEBUG - 2023-03-21 10:11:21 --> Total execution time: 0.0229
INFO - 2023-03-21 10:11:22 --> Final output sent to browser
DEBUG - 2023-03-21 10:11:22 --> Total execution time: 1.0889
INFO - 2023-03-21 10:11:22 --> Config Class Initialized
INFO - 2023-03-21 10:11:22 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:11:22 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:11:22 --> Utf8 Class Initialized
INFO - 2023-03-21 10:11:22 --> URI Class Initialized
INFO - 2023-03-21 10:11:22 --> Router Class Initialized
INFO - 2023-03-21 10:11:22 --> Output Class Initialized
INFO - 2023-03-21 10:11:22 --> Security Class Initialized
DEBUG - 2023-03-21 10:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:11:22 --> Input Class Initialized
INFO - 2023-03-21 10:11:22 --> Language Class Initialized
INFO - 2023-03-21 10:11:22 --> Loader Class Initialized
INFO - 2023-03-21 10:11:22 --> Controller Class Initialized
DEBUG - 2023-03-21 10:11:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:11:22 --> Database Driver Class Initialized
INFO - 2023-03-21 10:11:22 --> Model "Login_model" initialized
INFO - 2023-03-21 10:11:22 --> Database Driver Class Initialized
INFO - 2023-03-21 10:11:22 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:11:23 --> Final output sent to browser
DEBUG - 2023-03-21 10:11:23 --> Total execution time: 0.9416
INFO - 2023-03-21 10:12:19 --> Config Class Initialized
INFO - 2023-03-21 10:12:19 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:12:19 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:12:19 --> Utf8 Class Initialized
INFO - 2023-03-21 10:12:19 --> URI Class Initialized
INFO - 2023-03-21 10:12:19 --> Router Class Initialized
INFO - 2023-03-21 10:12:19 --> Output Class Initialized
INFO - 2023-03-21 10:12:19 --> Security Class Initialized
DEBUG - 2023-03-21 10:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:12:19 --> Input Class Initialized
INFO - 2023-03-21 10:12:19 --> Language Class Initialized
INFO - 2023-03-21 10:12:19 --> Loader Class Initialized
INFO - 2023-03-21 10:12:19 --> Controller Class Initialized
DEBUG - 2023-03-21 10:12:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:12:19 --> Database Driver Class Initialized
INFO - 2023-03-21 10:12:19 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:12:19 --> Final output sent to browser
DEBUG - 2023-03-21 10:12:19 --> Total execution time: 0.1166
INFO - 2023-03-21 10:12:19 --> Config Class Initialized
INFO - 2023-03-21 10:12:19 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:12:19 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:12:19 --> Utf8 Class Initialized
INFO - 2023-03-21 10:12:19 --> URI Class Initialized
INFO - 2023-03-21 10:12:19 --> Router Class Initialized
INFO - 2023-03-21 10:12:19 --> Output Class Initialized
INFO - 2023-03-21 10:12:19 --> Security Class Initialized
DEBUG - 2023-03-21 10:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:12:19 --> Input Class Initialized
INFO - 2023-03-21 10:12:19 --> Language Class Initialized
INFO - 2023-03-21 10:12:19 --> Loader Class Initialized
INFO - 2023-03-21 10:12:19 --> Controller Class Initialized
DEBUG - 2023-03-21 10:12:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:12:19 --> Database Driver Class Initialized
INFO - 2023-03-21 10:12:19 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:12:19 --> Final output sent to browser
DEBUG - 2023-03-21 10:12:19 --> Total execution time: 0.0201
INFO - 2023-03-21 10:12:37 --> Config Class Initialized
INFO - 2023-03-21 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:12:37 --> Utf8 Class Initialized
INFO - 2023-03-21 10:12:37 --> URI Class Initialized
INFO - 2023-03-21 10:12:37 --> Router Class Initialized
INFO - 2023-03-21 10:12:37 --> Output Class Initialized
INFO - 2023-03-21 10:12:37 --> Security Class Initialized
DEBUG - 2023-03-21 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:12:37 --> Input Class Initialized
INFO - 2023-03-21 10:12:37 --> Language Class Initialized
INFO - 2023-03-21 10:12:37 --> Loader Class Initialized
INFO - 2023-03-21 10:12:37 --> Controller Class Initialized
DEBUG - 2023-03-21 10:12:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:12:37 --> Database Driver Class Initialized
INFO - 2023-03-21 10:12:37 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:12:37 --> Database Driver Class Initialized
INFO - 2023-03-21 10:12:37 --> Model "Login_model" initialized
INFO - 2023-03-21 10:12:37 --> Final output sent to browser
DEBUG - 2023-03-21 10:12:37 --> Total execution time: 0.0798
INFO - 2023-03-21 10:12:37 --> Config Class Initialized
INFO - 2023-03-21 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:12:37 --> Utf8 Class Initialized
INFO - 2023-03-21 10:12:37 --> URI Class Initialized
INFO - 2023-03-21 10:12:37 --> Router Class Initialized
INFO - 2023-03-21 10:12:37 --> Output Class Initialized
INFO - 2023-03-21 10:12:37 --> Security Class Initialized
DEBUG - 2023-03-21 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:12:37 --> Input Class Initialized
INFO - 2023-03-21 10:12:37 --> Language Class Initialized
INFO - 2023-03-21 10:12:37 --> Loader Class Initialized
INFO - 2023-03-21 10:12:37 --> Controller Class Initialized
DEBUG - 2023-03-21 10:12:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:12:37 --> Database Driver Class Initialized
INFO - 2023-03-21 10:12:37 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:12:37 --> Database Driver Class Initialized
INFO - 2023-03-21 10:12:37 --> Model "Login_model" initialized
INFO - 2023-03-21 10:12:37 --> Final output sent to browser
DEBUG - 2023-03-21 10:12:37 --> Total execution time: 0.1044
INFO - 2023-03-21 10:12:53 --> Config Class Initialized
INFO - 2023-03-21 10:12:53 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:12:53 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:12:53 --> Utf8 Class Initialized
INFO - 2023-03-21 10:12:53 --> URI Class Initialized
INFO - 2023-03-21 10:12:53 --> Router Class Initialized
INFO - 2023-03-21 10:12:53 --> Output Class Initialized
INFO - 2023-03-21 10:12:53 --> Security Class Initialized
DEBUG - 2023-03-21 10:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:12:53 --> Input Class Initialized
INFO - 2023-03-21 10:12:53 --> Language Class Initialized
INFO - 2023-03-21 10:12:53 --> Loader Class Initialized
INFO - 2023-03-21 10:12:53 --> Controller Class Initialized
DEBUG - 2023-03-21 10:12:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:12:53 --> Database Driver Class Initialized
INFO - 2023-03-21 10:12:53 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:12:53 --> Final output sent to browser
DEBUG - 2023-03-21 10:12:53 --> Total execution time: 0.0225
INFO - 2023-03-21 10:12:53 --> Config Class Initialized
INFO - 2023-03-21 10:12:53 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:12:53 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:12:53 --> Utf8 Class Initialized
INFO - 2023-03-21 10:12:53 --> URI Class Initialized
INFO - 2023-03-21 10:12:53 --> Router Class Initialized
INFO - 2023-03-21 10:12:53 --> Output Class Initialized
INFO - 2023-03-21 10:12:53 --> Security Class Initialized
DEBUG - 2023-03-21 10:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:12:53 --> Input Class Initialized
INFO - 2023-03-21 10:12:53 --> Language Class Initialized
INFO - 2023-03-21 10:12:53 --> Loader Class Initialized
INFO - 2023-03-21 10:12:53 --> Controller Class Initialized
DEBUG - 2023-03-21 10:12:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:12:53 --> Database Driver Class Initialized
INFO - 2023-03-21 10:12:53 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:12:53 --> Final output sent to browser
DEBUG - 2023-03-21 10:12:53 --> Total execution time: 0.0592
INFO - 2023-03-21 10:14:14 --> Config Class Initialized
INFO - 2023-03-21 10:14:14 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:14:14 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:14:14 --> Utf8 Class Initialized
INFO - 2023-03-21 10:14:14 --> URI Class Initialized
INFO - 2023-03-21 10:14:14 --> Router Class Initialized
INFO - 2023-03-21 10:14:14 --> Output Class Initialized
INFO - 2023-03-21 10:14:14 --> Security Class Initialized
DEBUG - 2023-03-21 10:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:14:14 --> Input Class Initialized
INFO - 2023-03-21 10:14:14 --> Language Class Initialized
INFO - 2023-03-21 10:14:14 --> Loader Class Initialized
INFO - 2023-03-21 10:14:14 --> Controller Class Initialized
DEBUG - 2023-03-21 10:14:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:14:14 --> Database Driver Class Initialized
INFO - 2023-03-21 10:14:14 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:14:14 --> Final output sent to browser
DEBUG - 2023-03-21 10:14:14 --> Total execution time: 0.0501
INFO - 2023-03-21 10:14:14 --> Config Class Initialized
INFO - 2023-03-21 10:14:14 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:14:14 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:14:14 --> Utf8 Class Initialized
INFO - 2023-03-21 10:14:14 --> URI Class Initialized
INFO - 2023-03-21 10:14:14 --> Router Class Initialized
INFO - 2023-03-21 10:14:14 --> Output Class Initialized
INFO - 2023-03-21 10:14:14 --> Security Class Initialized
DEBUG - 2023-03-21 10:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:14:14 --> Input Class Initialized
INFO - 2023-03-21 10:14:14 --> Language Class Initialized
INFO - 2023-03-21 10:14:14 --> Loader Class Initialized
INFO - 2023-03-21 10:14:14 --> Controller Class Initialized
DEBUG - 2023-03-21 10:14:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:14:14 --> Database Driver Class Initialized
INFO - 2023-03-21 10:14:14 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:14:14 --> Final output sent to browser
DEBUG - 2023-03-21 10:14:14 --> Total execution time: 0.0457
INFO - 2023-03-21 10:14:30 --> Config Class Initialized
INFO - 2023-03-21 10:14:30 --> Config Class Initialized
INFO - 2023-03-21 10:14:30 --> Hooks Class Initialized
INFO - 2023-03-21 10:14:30 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:14:30 --> UTF-8 Support Enabled
DEBUG - 2023-03-21 10:14:30 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:14:30 --> Utf8 Class Initialized
INFO - 2023-03-21 10:14:30 --> Utf8 Class Initialized
INFO - 2023-03-21 10:14:30 --> URI Class Initialized
INFO - 2023-03-21 10:14:30 --> URI Class Initialized
INFO - 2023-03-21 10:14:30 --> Router Class Initialized
INFO - 2023-03-21 10:14:30 --> Router Class Initialized
INFO - 2023-03-21 10:14:30 --> Output Class Initialized
INFO - 2023-03-21 10:14:30 --> Output Class Initialized
INFO - 2023-03-21 10:14:30 --> Security Class Initialized
INFO - 2023-03-21 10:14:30 --> Security Class Initialized
DEBUG - 2023-03-21 10:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-21 10:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:14:30 --> Input Class Initialized
INFO - 2023-03-21 10:14:30 --> Input Class Initialized
INFO - 2023-03-21 10:14:30 --> Language Class Initialized
INFO - 2023-03-21 10:14:30 --> Language Class Initialized
INFO - 2023-03-21 10:14:30 --> Loader Class Initialized
INFO - 2023-03-21 10:14:30 --> Controller Class Initialized
INFO - 2023-03-21 10:14:30 --> Loader Class Initialized
INFO - 2023-03-21 10:14:30 --> Controller Class Initialized
DEBUG - 2023-03-21 10:14:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-21 10:14:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:14:30 --> Database Driver Class Initialized
INFO - 2023-03-21 10:14:30 --> Final output sent to browser
DEBUG - 2023-03-21 10:14:30 --> Total execution time: 0.0042
INFO - 2023-03-21 10:14:30 --> Config Class Initialized
INFO - 2023-03-21 10:14:30 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:14:30 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:14:30 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:14:30 --> Utf8 Class Initialized
INFO - 2023-03-21 10:14:30 --> URI Class Initialized
INFO - 2023-03-21 10:14:30 --> Router Class Initialized
INFO - 2023-03-21 10:14:30 --> Output Class Initialized
INFO - 2023-03-21 10:14:30 --> Security Class Initialized
DEBUG - 2023-03-21 10:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:14:30 --> Input Class Initialized
INFO - 2023-03-21 10:14:30 --> Language Class Initialized
INFO - 2023-03-21 10:14:30 --> Loader Class Initialized
INFO - 2023-03-21 10:14:30 --> Controller Class Initialized
DEBUG - 2023-03-21 10:14:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:14:30 --> Database Driver Class Initialized
INFO - 2023-03-21 10:14:30 --> Final output sent to browser
DEBUG - 2023-03-21 10:14:30 --> Total execution time: 0.0509
INFO - 2023-03-21 10:14:30 --> Config Class Initialized
INFO - 2023-03-21 10:14:30 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:14:30 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:14:30 --> Utf8 Class Initialized
INFO - 2023-03-21 10:14:30 --> URI Class Initialized
INFO - 2023-03-21 10:14:30 --> Router Class Initialized
INFO - 2023-03-21 10:14:30 --> Output Class Initialized
INFO - 2023-03-21 10:14:30 --> Security Class Initialized
DEBUG - 2023-03-21 10:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:14:30 --> Input Class Initialized
INFO - 2023-03-21 10:14:30 --> Language Class Initialized
INFO - 2023-03-21 10:14:30 --> Loader Class Initialized
INFO - 2023-03-21 10:14:30 --> Controller Class Initialized
DEBUG - 2023-03-21 10:14:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:14:30 --> Database Driver Class Initialized
INFO - 2023-03-21 10:14:30 --> Model "Login_model" initialized
INFO - 2023-03-21 10:14:30 --> Database Driver Class Initialized
INFO - 2023-03-21 10:14:30 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:14:30 --> Final output sent to browser
DEBUG - 2023-03-21 10:14:30 --> Total execution time: 0.0140
INFO - 2023-03-21 10:14:30 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:14:30 --> Final output sent to browser
DEBUG - 2023-03-21 10:14:30 --> Total execution time: 0.1043
INFO - 2023-03-21 10:14:34 --> Config Class Initialized
INFO - 2023-03-21 10:14:34 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:14:34 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:14:34 --> Utf8 Class Initialized
INFO - 2023-03-21 10:14:34 --> URI Class Initialized
INFO - 2023-03-21 10:14:34 --> Router Class Initialized
INFO - 2023-03-21 10:14:34 --> Output Class Initialized
INFO - 2023-03-21 10:14:34 --> Security Class Initialized
DEBUG - 2023-03-21 10:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:14:34 --> Input Class Initialized
INFO - 2023-03-21 10:14:34 --> Language Class Initialized
INFO - 2023-03-21 10:14:34 --> Loader Class Initialized
INFO - 2023-03-21 10:14:34 --> Controller Class Initialized
DEBUG - 2023-03-21 10:14:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:14:34 --> Database Driver Class Initialized
INFO - 2023-03-21 10:14:34 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:14:34 --> Database Driver Class Initialized
INFO - 2023-03-21 10:14:34 --> Model "Login_model" initialized
INFO - 2023-03-21 10:14:34 --> Final output sent to browser
DEBUG - 2023-03-21 10:14:34 --> Total execution time: 0.0697
INFO - 2023-03-21 10:14:34 --> Config Class Initialized
INFO - 2023-03-21 10:14:34 --> Hooks Class Initialized
DEBUG - 2023-03-21 10:14:34 --> UTF-8 Support Enabled
INFO - 2023-03-21 10:14:34 --> Utf8 Class Initialized
INFO - 2023-03-21 10:14:34 --> URI Class Initialized
INFO - 2023-03-21 10:14:34 --> Router Class Initialized
INFO - 2023-03-21 10:14:34 --> Output Class Initialized
INFO - 2023-03-21 10:14:34 --> Security Class Initialized
DEBUG - 2023-03-21 10:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-21 10:14:34 --> Input Class Initialized
INFO - 2023-03-21 10:14:34 --> Language Class Initialized
INFO - 2023-03-21 10:14:34 --> Loader Class Initialized
INFO - 2023-03-21 10:14:34 --> Controller Class Initialized
DEBUG - 2023-03-21 10:14:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-21 10:14:34 --> Database Driver Class Initialized
INFO - 2023-03-21 10:14:34 --> Model "Cluster_model" initialized
INFO - 2023-03-21 10:14:34 --> Database Driver Class Initialized
INFO - 2023-03-21 10:14:34 --> Model "Login_model" initialized
INFO - 2023-03-21 10:14:34 --> Final output sent to browser
DEBUG - 2023-03-21 10:14:34 --> Total execution time: 0.0668
