<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-28 01:40:14 --> Config Class Initialized
INFO - 2023-04-28 01:40:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 01:40:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 01:40:14 --> Utf8 Class Initialized
INFO - 2023-04-28 01:40:14 --> URI Class Initialized
INFO - 2023-04-28 01:40:14 --> Router Class Initialized
INFO - 2023-04-28 01:40:14 --> Output Class Initialized
INFO - 2023-04-28 01:40:14 --> Security Class Initialized
DEBUG - 2023-04-28 01:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 01:40:14 --> Input Class Initialized
INFO - 2023-04-28 01:40:14 --> Language Class Initialized
INFO - 2023-04-28 01:40:14 --> Loader Class Initialized
INFO - 2023-04-28 01:40:14 --> Controller Class Initialized
INFO - 2023-04-28 01:40:14 --> Helper loaded: form_helper
INFO - 2023-04-28 01:40:14 --> Helper loaded: url_helper
DEBUG - 2023-04-28 01:40:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 01:40:14 --> Model "Change_model" initialized
INFO - 2023-04-28 01:40:14 --> Final output sent to browser
DEBUG - 2023-04-28 01:40:14 --> Total execution time: 0.0433
INFO - 2023-04-28 01:41:26 --> Config Class Initialized
INFO - 2023-04-28 01:41:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 01:41:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 01:41:26 --> Utf8 Class Initialized
INFO - 2023-04-28 01:41:26 --> URI Class Initialized
INFO - 2023-04-28 01:41:26 --> Router Class Initialized
INFO - 2023-04-28 01:41:26 --> Output Class Initialized
INFO - 2023-04-28 01:41:26 --> Security Class Initialized
DEBUG - 2023-04-28 01:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 01:41:26 --> Input Class Initialized
INFO - 2023-04-28 01:41:26 --> Language Class Initialized
INFO - 2023-04-28 01:41:26 --> Loader Class Initialized
INFO - 2023-04-28 01:41:26 --> Controller Class Initialized
INFO - 2023-04-28 01:41:26 --> Helper loaded: form_helper
INFO - 2023-04-28 01:41:26 --> Helper loaded: url_helper
DEBUG - 2023-04-28 01:41:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 01:41:26 --> Model "Change_model" initialized
INFO - 2023-04-28 01:41:26 --> Final output sent to browser
DEBUG - 2023-04-28 01:41:26 --> Total execution time: 0.0090
INFO - 2023-04-28 01:51:29 --> Config Class Initialized
INFO - 2023-04-28 01:51:29 --> Hooks Class Initialized
DEBUG - 2023-04-28 01:51:29 --> UTF-8 Support Enabled
INFO - 2023-04-28 01:51:29 --> Utf8 Class Initialized
INFO - 2023-04-28 01:51:29 --> URI Class Initialized
INFO - 2023-04-28 01:51:29 --> Router Class Initialized
INFO - 2023-04-28 01:51:29 --> Output Class Initialized
INFO - 2023-04-28 01:51:29 --> Security Class Initialized
DEBUG - 2023-04-28 01:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 01:51:29 --> Input Class Initialized
INFO - 2023-04-28 01:51:29 --> Language Class Initialized
INFO - 2023-04-28 01:51:29 --> Loader Class Initialized
INFO - 2023-04-28 01:51:29 --> Controller Class Initialized
INFO - 2023-04-28 01:51:29 --> Helper loaded: form_helper
INFO - 2023-04-28 01:51:29 --> Helper loaded: url_helper
DEBUG - 2023-04-28 01:51:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 01:51:29 --> Model "Change_model" initialized
INFO - 2023-04-28 01:51:29 --> Final output sent to browser
DEBUG - 2023-04-28 01:51:29 --> Total execution time: 0.0071
INFO - 2023-04-28 02:21:47 --> Config Class Initialized
INFO - 2023-04-28 02:21:47 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:21:47 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:21:47 --> Utf8 Class Initialized
INFO - 2023-04-28 02:21:47 --> URI Class Initialized
INFO - 2023-04-28 02:21:47 --> Router Class Initialized
INFO - 2023-04-28 02:21:47 --> Output Class Initialized
INFO - 2023-04-28 02:21:47 --> Security Class Initialized
DEBUG - 2023-04-28 02:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:21:47 --> Input Class Initialized
INFO - 2023-04-28 02:21:47 --> Language Class Initialized
INFO - 2023-04-28 02:21:47 --> Loader Class Initialized
INFO - 2023-04-28 02:21:47 --> Controller Class Initialized
INFO - 2023-04-28 02:21:47 --> Helper loaded: form_helper
INFO - 2023-04-28 02:21:47 --> Helper loaded: url_helper
DEBUG - 2023-04-28 02:21:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:21:47 --> Model "Change_model" initialized
INFO - 2023-04-28 02:21:47 --> Model "Grafana_model" initialized
INFO - 2023-04-28 02:21:47 --> Final output sent to browser
DEBUG - 2023-04-28 02:21:47 --> Total execution time: 0.0435
INFO - 2023-04-28 02:21:47 --> Config Class Initialized
INFO - 2023-04-28 02:21:47 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:21:47 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:21:47 --> Utf8 Class Initialized
INFO - 2023-04-28 02:21:47 --> URI Class Initialized
INFO - 2023-04-28 02:21:47 --> Router Class Initialized
INFO - 2023-04-28 02:21:47 --> Output Class Initialized
INFO - 2023-04-28 02:21:47 --> Security Class Initialized
DEBUG - 2023-04-28 02:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:21:47 --> Input Class Initialized
INFO - 2023-04-28 02:21:47 --> Language Class Initialized
INFO - 2023-04-28 02:21:47 --> Loader Class Initialized
INFO - 2023-04-28 02:21:47 --> Controller Class Initialized
INFO - 2023-04-28 02:21:47 --> Helper loaded: form_helper
INFO - 2023-04-28 02:21:47 --> Helper loaded: url_helper
DEBUG - 2023-04-28 02:21:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:21:47 --> Final output sent to browser
DEBUG - 2023-04-28 02:21:47 --> Total execution time: 0.0432
INFO - 2023-04-28 02:21:47 --> Config Class Initialized
INFO - 2023-04-28 02:21:47 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:21:47 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:21:47 --> Utf8 Class Initialized
INFO - 2023-04-28 02:21:47 --> URI Class Initialized
INFO - 2023-04-28 02:21:47 --> Router Class Initialized
INFO - 2023-04-28 02:21:47 --> Output Class Initialized
INFO - 2023-04-28 02:21:47 --> Security Class Initialized
DEBUG - 2023-04-28 02:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:21:47 --> Input Class Initialized
INFO - 2023-04-28 02:21:47 --> Language Class Initialized
INFO - 2023-04-28 02:21:47 --> Loader Class Initialized
INFO - 2023-04-28 02:21:47 --> Controller Class Initialized
INFO - 2023-04-28 02:21:47 --> Helper loaded: form_helper
INFO - 2023-04-28 02:21:47 --> Helper loaded: url_helper
DEBUG - 2023-04-28 02:21:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:21:47 --> Database Driver Class Initialized
INFO - 2023-04-28 02:21:47 --> Model "Login_model" initialized
INFO - 2023-04-28 02:21:47 --> Final output sent to browser
DEBUG - 2023-04-28 02:21:47 --> Total execution time: 0.0723
INFO - 2023-04-28 02:21:56 --> Config Class Initialized
INFO - 2023-04-28 02:21:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:21:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:21:56 --> Utf8 Class Initialized
INFO - 2023-04-28 02:21:56 --> URI Class Initialized
INFO - 2023-04-28 02:21:56 --> Router Class Initialized
INFO - 2023-04-28 02:21:56 --> Output Class Initialized
INFO - 2023-04-28 02:21:56 --> Security Class Initialized
DEBUG - 2023-04-28 02:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:21:56 --> Input Class Initialized
INFO - 2023-04-28 02:21:56 --> Language Class Initialized
INFO - 2023-04-28 02:21:56 --> Loader Class Initialized
INFO - 2023-04-28 02:21:56 --> Controller Class Initialized
INFO - 2023-04-28 02:21:56 --> Helper loaded: form_helper
INFO - 2023-04-28 02:21:56 --> Helper loaded: url_helper
DEBUG - 2023-04-28 02:21:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:21:56 --> Final output sent to browser
DEBUG - 2023-04-28 02:21:56 --> Total execution time: 0.0047
INFO - 2023-04-28 02:21:56 --> Config Class Initialized
INFO - 2023-04-28 02:21:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:21:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:21:56 --> Utf8 Class Initialized
INFO - 2023-04-28 02:21:56 --> URI Class Initialized
INFO - 2023-04-28 02:21:56 --> Router Class Initialized
INFO - 2023-04-28 02:21:56 --> Output Class Initialized
INFO - 2023-04-28 02:21:56 --> Security Class Initialized
DEBUG - 2023-04-28 02:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:21:56 --> Input Class Initialized
INFO - 2023-04-28 02:21:56 --> Language Class Initialized
INFO - 2023-04-28 02:21:56 --> Loader Class Initialized
INFO - 2023-04-28 02:21:56 --> Controller Class Initialized
INFO - 2023-04-28 02:21:56 --> Helper loaded: form_helper
INFO - 2023-04-28 02:21:56 --> Helper loaded: url_helper
DEBUG - 2023-04-28 02:21:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:21:56 --> Database Driver Class Initialized
INFO - 2023-04-28 02:21:56 --> Model "Login_model" initialized
INFO - 2023-04-28 02:21:56 --> Final output sent to browser
DEBUG - 2023-04-28 02:21:56 --> Total execution time: 0.0279
INFO - 2023-04-28 02:22:00 --> Config Class Initialized
INFO - 2023-04-28 02:22:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:22:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:22:00 --> Utf8 Class Initialized
INFO - 2023-04-28 02:22:00 --> URI Class Initialized
INFO - 2023-04-28 02:22:00 --> Router Class Initialized
INFO - 2023-04-28 02:22:00 --> Output Class Initialized
INFO - 2023-04-28 02:22:00 --> Security Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:22:00 --> Input Class Initialized
INFO - 2023-04-28 02:22:00 --> Language Class Initialized
INFO - 2023-04-28 02:22:00 --> Loader Class Initialized
INFO - 2023-04-28 02:22:00 --> Controller Class Initialized
INFO - 2023-04-28 02:22:00 --> Helper loaded: form_helper
INFO - 2023-04-28 02:22:00 --> Helper loaded: url_helper
DEBUG - 2023-04-28 02:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:22:00 --> Model "Change_model" initialized
INFO - 2023-04-28 02:22:00 --> Model "Grafana_model" initialized
INFO - 2023-04-28 02:22:00 --> Final output sent to browser
DEBUG - 2023-04-28 02:22:00 --> Total execution time: 0.0842
INFO - 2023-04-28 02:22:00 --> Config Class Initialized
INFO - 2023-04-28 02:22:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:22:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:22:00 --> Utf8 Class Initialized
INFO - 2023-04-28 02:22:00 --> URI Class Initialized
INFO - 2023-04-28 02:22:00 --> Router Class Initialized
INFO - 2023-04-28 02:22:00 --> Output Class Initialized
INFO - 2023-04-28 02:22:00 --> Security Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:22:00 --> Input Class Initialized
INFO - 2023-04-28 02:22:00 --> Language Class Initialized
INFO - 2023-04-28 02:22:00 --> Loader Class Initialized
INFO - 2023-04-28 02:22:00 --> Controller Class Initialized
INFO - 2023-04-28 02:22:00 --> Helper loaded: form_helper
INFO - 2023-04-28 02:22:00 --> Helper loaded: url_helper
DEBUG - 2023-04-28 02:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:22:00 --> Final output sent to browser
DEBUG - 2023-04-28 02:22:00 --> Total execution time: 0.0020
INFO - 2023-04-28 02:22:00 --> Config Class Initialized
INFO - 2023-04-28 02:22:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:22:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:22:00 --> Utf8 Class Initialized
INFO - 2023-04-28 02:22:00 --> URI Class Initialized
INFO - 2023-04-28 02:22:00 --> Router Class Initialized
INFO - 2023-04-28 02:22:00 --> Output Class Initialized
INFO - 2023-04-28 02:22:00 --> Security Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:22:00 --> Input Class Initialized
INFO - 2023-04-28 02:22:00 --> Language Class Initialized
INFO - 2023-04-28 02:22:00 --> Loader Class Initialized
INFO - 2023-04-28 02:22:00 --> Controller Class Initialized
INFO - 2023-04-28 02:22:00 --> Helper loaded: form_helper
INFO - 2023-04-28 02:22:00 --> Helper loaded: url_helper
DEBUG - 2023-04-28 02:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:22:00 --> Database Driver Class Initialized
INFO - 2023-04-28 02:22:00 --> Model "Login_model" initialized
INFO - 2023-04-28 02:22:00 --> Final output sent to browser
DEBUG - 2023-04-28 02:22:00 --> Total execution time: 0.0349
INFO - 2023-04-28 02:22:00 --> Config Class Initialized
INFO - 2023-04-28 02:22:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:22:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:22:00 --> Utf8 Class Initialized
INFO - 2023-04-28 02:22:00 --> URI Class Initialized
INFO - 2023-04-28 02:22:00 --> Router Class Initialized
INFO - 2023-04-28 02:22:00 --> Output Class Initialized
INFO - 2023-04-28 02:22:00 --> Security Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:22:00 --> Input Class Initialized
INFO - 2023-04-28 02:22:00 --> Language Class Initialized
INFO - 2023-04-28 02:22:00 --> Loader Class Initialized
INFO - 2023-04-28 02:22:00 --> Controller Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:22:00 --> Database Driver Class Initialized
INFO - 2023-04-28 02:22:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:22:00 --> Final output sent to browser
DEBUG - 2023-04-28 02:22:00 --> Total execution time: 0.0326
INFO - 2023-04-28 02:22:00 --> Config Class Initialized
INFO - 2023-04-28 02:22:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:22:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:22:00 --> Utf8 Class Initialized
INFO - 2023-04-28 02:22:00 --> URI Class Initialized
INFO - 2023-04-28 02:22:00 --> Router Class Initialized
INFO - 2023-04-28 02:22:00 --> Output Class Initialized
INFO - 2023-04-28 02:22:00 --> Security Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:22:00 --> Input Class Initialized
INFO - 2023-04-28 02:22:00 --> Language Class Initialized
INFO - 2023-04-28 02:22:00 --> Loader Class Initialized
INFO - 2023-04-28 02:22:00 --> Controller Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:22:00 --> Database Driver Class Initialized
INFO - 2023-04-28 02:22:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:22:00 --> Final output sent to browser
DEBUG - 2023-04-28 02:22:00 --> Total execution time: 0.0291
INFO - 2023-04-28 02:22:00 --> Config Class Initialized
INFO - 2023-04-28 02:22:00 --> Config Class Initialized
INFO - 2023-04-28 02:22:00 --> Hooks Class Initialized
INFO - 2023-04-28 02:22:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:22:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 02:22:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:22:00 --> Utf8 Class Initialized
INFO - 2023-04-28 02:22:00 --> Utf8 Class Initialized
INFO - 2023-04-28 02:22:00 --> URI Class Initialized
INFO - 2023-04-28 02:22:00 --> URI Class Initialized
INFO - 2023-04-28 02:22:00 --> Router Class Initialized
INFO - 2023-04-28 02:22:00 --> Router Class Initialized
INFO - 2023-04-28 02:22:00 --> Output Class Initialized
INFO - 2023-04-28 02:22:00 --> Output Class Initialized
INFO - 2023-04-28 02:22:00 --> Security Class Initialized
INFO - 2023-04-28 02:22:00 --> Security Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 02:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:22:00 --> Input Class Initialized
INFO - 2023-04-28 02:22:00 --> Input Class Initialized
INFO - 2023-04-28 02:22:00 --> Language Class Initialized
INFO - 2023-04-28 02:22:00 --> Language Class Initialized
INFO - 2023-04-28 02:22:00 --> Loader Class Initialized
INFO - 2023-04-28 02:22:00 --> Controller Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:22:00 --> Database Driver Class Initialized
INFO - 2023-04-28 02:22:00 --> Loader Class Initialized
INFO - 2023-04-28 02:22:00 --> Controller Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:22:00 --> Database Driver Class Initialized
INFO - 2023-04-28 02:22:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:22:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:22:00 --> Final output sent to browser
DEBUG - 2023-04-28 02:22:00 --> Total execution time: 0.1008
INFO - 2023-04-28 02:22:00 --> Final output sent to browser
INFO - 2023-04-28 02:22:00 --> Config Class Initialized
INFO - 2023-04-28 02:22:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Total execution time: 0.1035
DEBUG - 2023-04-28 02:22:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:22:00 --> Utf8 Class Initialized
INFO - 2023-04-28 02:22:00 --> URI Class Initialized
INFO - 2023-04-28 02:22:00 --> Router Class Initialized
INFO - 2023-04-28 02:22:00 --> Output Class Initialized
INFO - 2023-04-28 02:22:00 --> Security Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:22:00 --> Input Class Initialized
INFO - 2023-04-28 02:22:00 --> Language Class Initialized
INFO - 2023-04-28 02:22:00 --> Config Class Initialized
INFO - 2023-04-28 02:22:00 --> Hooks Class Initialized
INFO - 2023-04-28 02:22:00 --> Loader Class Initialized
DEBUG - 2023-04-28 02:22:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:22:00 --> Controller Class Initialized
INFO - 2023-04-28 02:22:00 --> Utf8 Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:22:00 --> URI Class Initialized
INFO - 2023-04-28 02:22:00 --> Router Class Initialized
INFO - 2023-04-28 02:22:00 --> Database Driver Class Initialized
INFO - 2023-04-28 02:22:00 --> Output Class Initialized
INFO - 2023-04-28 02:22:00 --> Security Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:22:00 --> Input Class Initialized
INFO - 2023-04-28 02:22:00 --> Language Class Initialized
INFO - 2023-04-28 02:22:00 --> Loader Class Initialized
INFO - 2023-04-28 02:22:00 --> Controller Class Initialized
DEBUG - 2023-04-28 02:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:22:00 --> Database Driver Class Initialized
INFO - 2023-04-28 02:22:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:22:00 --> Final output sent to browser
DEBUG - 2023-04-28 02:22:00 --> Total execution time: 0.0951
INFO - 2023-04-28 02:22:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:22:00 --> Final output sent to browser
DEBUG - 2023-04-28 02:22:00 --> Total execution time: 0.0996
INFO - 2023-04-28 02:22:02 --> Config Class Initialized
INFO - 2023-04-28 02:22:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:22:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:22:02 --> Utf8 Class Initialized
INFO - 2023-04-28 02:22:02 --> URI Class Initialized
INFO - 2023-04-28 02:22:02 --> Router Class Initialized
INFO - 2023-04-28 02:22:02 --> Output Class Initialized
INFO - 2023-04-28 02:22:02 --> Security Class Initialized
DEBUG - 2023-04-28 02:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:22:02 --> Input Class Initialized
INFO - 2023-04-28 02:22:02 --> Language Class Initialized
INFO - 2023-04-28 02:22:02 --> Loader Class Initialized
INFO - 2023-04-28 02:22:02 --> Controller Class Initialized
DEBUG - 2023-04-28 02:22:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:22:02 --> Database Driver Class Initialized
INFO - 2023-04-28 02:22:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:22:02 --> Final output sent to browser
DEBUG - 2023-04-28 02:22:02 --> Total execution time: 0.0172
INFO - 2023-04-28 02:22:02 --> Config Class Initialized
INFO - 2023-04-28 02:22:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:22:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:22:02 --> Utf8 Class Initialized
INFO - 2023-04-28 02:22:02 --> URI Class Initialized
INFO - 2023-04-28 02:22:02 --> Router Class Initialized
INFO - 2023-04-28 02:22:02 --> Output Class Initialized
INFO - 2023-04-28 02:22:02 --> Security Class Initialized
DEBUG - 2023-04-28 02:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:22:02 --> Input Class Initialized
INFO - 2023-04-28 02:22:02 --> Language Class Initialized
INFO - 2023-04-28 02:22:02 --> Loader Class Initialized
INFO - 2023-04-28 02:22:02 --> Controller Class Initialized
DEBUG - 2023-04-28 02:22:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:22:02 --> Database Driver Class Initialized
INFO - 2023-04-28 02:22:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:22:02 --> Final output sent to browser
DEBUG - 2023-04-28 02:22:02 --> Total execution time: 0.0551
INFO - 2023-04-28 02:22:02 --> Config Class Initialized
INFO - 2023-04-28 02:22:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:22:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:22:02 --> Utf8 Class Initialized
INFO - 2023-04-28 02:22:02 --> URI Class Initialized
INFO - 2023-04-28 02:22:02 --> Router Class Initialized
INFO - 2023-04-28 02:22:02 --> Output Class Initialized
INFO - 2023-04-28 02:22:02 --> Security Class Initialized
DEBUG - 2023-04-28 02:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:22:02 --> Input Class Initialized
INFO - 2023-04-28 02:22:02 --> Language Class Initialized
INFO - 2023-04-28 02:22:02 --> Loader Class Initialized
INFO - 2023-04-28 02:22:02 --> Controller Class Initialized
DEBUG - 2023-04-28 02:22:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:22:02 --> Database Driver Class Initialized
INFO - 2023-04-28 02:22:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:22:02 --> Final output sent to browser
DEBUG - 2023-04-28 02:22:02 --> Total execution time: 0.0535
INFO - 2023-04-28 02:22:02 --> Config Class Initialized
INFO - 2023-04-28 02:22:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:22:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:22:02 --> Utf8 Class Initialized
INFO - 2023-04-28 02:22:02 --> URI Class Initialized
INFO - 2023-04-28 02:22:02 --> Router Class Initialized
INFO - 2023-04-28 02:22:02 --> Output Class Initialized
INFO - 2023-04-28 02:22:02 --> Security Class Initialized
DEBUG - 2023-04-28 02:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:22:02 --> Input Class Initialized
INFO - 2023-04-28 02:22:02 --> Language Class Initialized
INFO - 2023-04-28 02:22:02 --> Loader Class Initialized
INFO - 2023-04-28 02:22:02 --> Controller Class Initialized
DEBUG - 2023-04-28 02:22:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:22:02 --> Database Driver Class Initialized
INFO - 2023-04-28 02:22:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:22:02 --> Final output sent to browser
DEBUG - 2023-04-28 02:22:02 --> Total execution time: 0.0610
INFO - 2023-04-28 02:24:52 --> Config Class Initialized
INFO - 2023-04-28 02:24:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:24:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:24:52 --> Utf8 Class Initialized
INFO - 2023-04-28 02:24:52 --> URI Class Initialized
INFO - 2023-04-28 02:24:52 --> Router Class Initialized
INFO - 2023-04-28 02:24:52 --> Output Class Initialized
INFO - 2023-04-28 02:24:52 --> Security Class Initialized
DEBUG - 2023-04-28 02:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:24:52 --> Input Class Initialized
INFO - 2023-04-28 02:24:52 --> Language Class Initialized
INFO - 2023-04-28 02:24:52 --> Loader Class Initialized
INFO - 2023-04-28 02:24:52 --> Controller Class Initialized
DEBUG - 2023-04-28 02:24:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:24:52 --> Database Driver Class Initialized
INFO - 2023-04-28 02:24:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:24:52 --> Final output sent to browser
DEBUG - 2023-04-28 02:24:52 --> Total execution time: 0.1008
INFO - 2023-04-28 02:24:53 --> Config Class Initialized
INFO - 2023-04-28 02:24:53 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:24:53 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:24:53 --> Utf8 Class Initialized
INFO - 2023-04-28 02:24:53 --> URI Class Initialized
INFO - 2023-04-28 02:24:53 --> Router Class Initialized
INFO - 2023-04-28 02:24:53 --> Output Class Initialized
INFO - 2023-04-28 02:24:53 --> Security Class Initialized
DEBUG - 2023-04-28 02:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:24:53 --> Input Class Initialized
INFO - 2023-04-28 02:24:53 --> Language Class Initialized
INFO - 2023-04-28 02:24:53 --> Loader Class Initialized
INFO - 2023-04-28 02:24:53 --> Controller Class Initialized
DEBUG - 2023-04-28 02:24:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:24:53 --> Database Driver Class Initialized
INFO - 2023-04-28 02:24:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:24:53 --> Database Driver Class Initialized
INFO - 2023-04-28 02:24:53 --> Model "Login_model" initialized
INFO - 2023-04-28 02:24:53 --> Final output sent to browser
DEBUG - 2023-04-28 02:24:53 --> Total execution time: 0.0207
INFO - 2023-04-28 02:24:54 --> Config Class Initialized
INFO - 2023-04-28 02:24:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:24:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:24:54 --> Utf8 Class Initialized
INFO - 2023-04-28 02:24:54 --> URI Class Initialized
INFO - 2023-04-28 02:24:54 --> Router Class Initialized
INFO - 2023-04-28 02:24:54 --> Output Class Initialized
INFO - 2023-04-28 02:24:54 --> Security Class Initialized
DEBUG - 2023-04-28 02:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:24:54 --> Input Class Initialized
INFO - 2023-04-28 02:24:54 --> Language Class Initialized
INFO - 2023-04-28 02:24:54 --> Loader Class Initialized
INFO - 2023-04-28 02:24:54 --> Controller Class Initialized
DEBUG - 2023-04-28 02:24:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:24:54 --> Database Driver Class Initialized
INFO - 2023-04-28 02:24:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:24:54 --> Final output sent to browser
DEBUG - 2023-04-28 02:24:54 --> Total execution time: 0.0186
INFO - 2023-04-28 02:24:54 --> Config Class Initialized
INFO - 2023-04-28 02:24:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:24:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:24:54 --> Utf8 Class Initialized
INFO - 2023-04-28 02:24:54 --> URI Class Initialized
INFO - 2023-04-28 02:24:54 --> Router Class Initialized
INFO - 2023-04-28 02:24:54 --> Output Class Initialized
INFO - 2023-04-28 02:24:54 --> Security Class Initialized
DEBUG - 2023-04-28 02:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:24:54 --> Input Class Initialized
INFO - 2023-04-28 02:24:54 --> Language Class Initialized
INFO - 2023-04-28 02:24:54 --> Loader Class Initialized
INFO - 2023-04-28 02:24:54 --> Controller Class Initialized
DEBUG - 2023-04-28 02:24:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:24:54 --> Database Driver Class Initialized
INFO - 2023-04-28 02:24:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:24:54 --> Final output sent to browser
DEBUG - 2023-04-28 02:24:54 --> Total execution time: 0.0574
INFO - 2023-04-28 02:24:56 --> Config Class Initialized
INFO - 2023-04-28 02:24:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:24:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:24:56 --> Utf8 Class Initialized
INFO - 2023-04-28 02:24:56 --> URI Class Initialized
INFO - 2023-04-28 02:24:56 --> Router Class Initialized
INFO - 2023-04-28 02:24:56 --> Output Class Initialized
INFO - 2023-04-28 02:24:56 --> Security Class Initialized
DEBUG - 2023-04-28 02:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:24:56 --> Input Class Initialized
INFO - 2023-04-28 02:24:56 --> Language Class Initialized
INFO - 2023-04-28 02:24:56 --> Loader Class Initialized
INFO - 2023-04-28 02:24:56 --> Controller Class Initialized
DEBUG - 2023-04-28 02:24:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:24:56 --> Database Driver Class Initialized
INFO - 2023-04-28 02:24:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:24:56 --> Database Driver Class Initialized
INFO - 2023-04-28 02:24:56 --> Model "Login_model" initialized
INFO - 2023-04-28 02:24:56 --> Final output sent to browser
DEBUG - 2023-04-28 02:24:56 --> Total execution time: 0.0306
INFO - 2023-04-28 02:24:57 --> Config Class Initialized
INFO - 2023-04-28 02:24:57 --> Config Class Initialized
INFO - 2023-04-28 02:24:57 --> Hooks Class Initialized
INFO - 2023-04-28 02:24:57 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:24:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 02:24:57 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:24:57 --> Utf8 Class Initialized
INFO - 2023-04-28 02:24:57 --> Utf8 Class Initialized
INFO - 2023-04-28 02:24:57 --> URI Class Initialized
INFO - 2023-04-28 02:24:57 --> URI Class Initialized
INFO - 2023-04-28 02:24:57 --> Router Class Initialized
INFO - 2023-04-28 02:24:57 --> Output Class Initialized
INFO - 2023-04-28 02:24:57 --> Router Class Initialized
INFO - 2023-04-28 02:24:57 --> Security Class Initialized
INFO - 2023-04-28 02:24:57 --> Output Class Initialized
DEBUG - 2023-04-28 02:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:24:57 --> Security Class Initialized
INFO - 2023-04-28 02:24:57 --> Input Class Initialized
DEBUG - 2023-04-28 02:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:24:57 --> Language Class Initialized
INFO - 2023-04-28 02:24:57 --> Input Class Initialized
INFO - 2023-04-28 02:24:57 --> Language Class Initialized
INFO - 2023-04-28 02:24:57 --> Loader Class Initialized
INFO - 2023-04-28 02:24:57 --> Loader Class Initialized
INFO - 2023-04-28 02:24:57 --> Controller Class Initialized
INFO - 2023-04-28 02:24:57 --> Controller Class Initialized
DEBUG - 2023-04-28 02:24:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 02:24:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:24:57 --> Database Driver Class Initialized
INFO - 2023-04-28 02:24:57 --> Database Driver Class Initialized
INFO - 2023-04-28 02:24:57 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:24:57 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:24:57 --> Final output sent to browser
DEBUG - 2023-04-28 02:24:57 --> Total execution time: 0.0178
INFO - 2023-04-28 02:24:57 --> Config Class Initialized
INFO - 2023-04-28 02:24:57 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:24:57 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:24:57 --> Utf8 Class Initialized
INFO - 2023-04-28 02:24:57 --> URI Class Initialized
INFO - 2023-04-28 02:24:57 --> Router Class Initialized
INFO - 2023-04-28 02:24:57 --> Output Class Initialized
INFO - 2023-04-28 02:24:57 --> Security Class Initialized
DEBUG - 2023-04-28 02:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:24:57 --> Input Class Initialized
INFO - 2023-04-28 02:24:57 --> Language Class Initialized
INFO - 2023-04-28 02:24:57 --> Loader Class Initialized
INFO - 2023-04-28 02:24:57 --> Controller Class Initialized
DEBUG - 2023-04-28 02:24:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:24:57 --> Final output sent to browser
DEBUG - 2023-04-28 02:24:57 --> Total execution time: 0.0215
INFO - 2023-04-28 02:24:57 --> Database Driver Class Initialized
INFO - 2023-04-28 02:24:57 --> Config Class Initialized
INFO - 2023-04-28 02:24:57 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:24:57 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:24:57 --> Utf8 Class Initialized
INFO - 2023-04-28 02:24:57 --> URI Class Initialized
INFO - 2023-04-28 02:24:57 --> Router Class Initialized
INFO - 2023-04-28 02:24:57 --> Output Class Initialized
INFO - 2023-04-28 02:24:57 --> Security Class Initialized
DEBUG - 2023-04-28 02:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:24:57 --> Input Class Initialized
INFO - 2023-04-28 02:24:57 --> Language Class Initialized
INFO - 2023-04-28 02:24:57 --> Loader Class Initialized
INFO - 2023-04-28 02:24:57 --> Controller Class Initialized
DEBUG - 2023-04-28 02:24:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:24:57 --> Database Driver Class Initialized
INFO - 2023-04-28 02:24:57 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:24:57 --> Final output sent to browser
DEBUG - 2023-04-28 02:24:57 --> Total execution time: 0.0119
INFO - 2023-04-28 02:24:57 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:24:57 --> Final output sent to browser
DEBUG - 2023-04-28 02:24:57 --> Total execution time: 0.0134
INFO - 2023-04-28 02:25:00 --> Config Class Initialized
INFO - 2023-04-28 02:25:00 --> Config Class Initialized
INFO - 2023-04-28 02:25:00 --> Hooks Class Initialized
INFO - 2023-04-28 02:25:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:00 --> Utf8 Class Initialized
DEBUG - 2023-04-28 02:25:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:00 --> URI Class Initialized
INFO - 2023-04-28 02:25:00 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:00 --> URI Class Initialized
INFO - 2023-04-28 02:25:00 --> Router Class Initialized
INFO - 2023-04-28 02:25:00 --> Router Class Initialized
INFO - 2023-04-28 02:25:00 --> Output Class Initialized
INFO - 2023-04-28 02:25:00 --> Output Class Initialized
INFO - 2023-04-28 02:25:00 --> Security Class Initialized
INFO - 2023-04-28 02:25:00 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 02:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:00 --> Input Class Initialized
INFO - 2023-04-28 02:25:00 --> Input Class Initialized
INFO - 2023-04-28 02:25:00 --> Language Class Initialized
INFO - 2023-04-28 02:25:00 --> Language Class Initialized
INFO - 2023-04-28 02:25:00 --> Loader Class Initialized
INFO - 2023-04-28 02:25:00 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:00 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:00 --> Loader Class Initialized
INFO - 2023-04-28 02:25:00 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:00 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:00 --> Total execution time: 0.0064
INFO - 2023-04-28 02:25:00 --> Config Class Initialized
INFO - 2023-04-28 02:25:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:00 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:00 --> URI Class Initialized
INFO - 2023-04-28 02:25:00 --> Router Class Initialized
INFO - 2023-04-28 02:25:00 --> Output Class Initialized
INFO - 2023-04-28 02:25:00 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:00 --> Input Class Initialized
INFO - 2023-04-28 02:25:00 --> Language Class Initialized
INFO - 2023-04-28 02:25:00 --> Loader Class Initialized
INFO - 2023-04-28 02:25:00 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:00 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:00 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:00 --> Total execution time: 0.0512
INFO - 2023-04-28 02:25:00 --> Config Class Initialized
INFO - 2023-04-28 02:25:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:00 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:00 --> URI Class Initialized
INFO - 2023-04-28 02:25:00 --> Router Class Initialized
INFO - 2023-04-28 02:25:00 --> Output Class Initialized
INFO - 2023-04-28 02:25:00 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:00 --> Input Class Initialized
INFO - 2023-04-28 02:25:00 --> Language Class Initialized
INFO - 2023-04-28 02:25:00 --> Loader Class Initialized
INFO - 2023-04-28 02:25:00 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:00 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:00 --> Model "Login_model" initialized
INFO - 2023-04-28 02:25:00 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:00 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:00 --> Total execution time: 0.0150
INFO - 2023-04-28 02:25:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:00 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:00 --> Total execution time: 0.1042
INFO - 2023-04-28 02:25:03 --> Config Class Initialized
INFO - 2023-04-28 02:25:03 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:03 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:03 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:03 --> URI Class Initialized
INFO - 2023-04-28 02:25:03 --> Router Class Initialized
INFO - 2023-04-28 02:25:03 --> Output Class Initialized
INFO - 2023-04-28 02:25:03 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:03 --> Input Class Initialized
INFO - 2023-04-28 02:25:03 --> Language Class Initialized
INFO - 2023-04-28 02:25:03 --> Loader Class Initialized
INFO - 2023-04-28 02:25:03 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:03 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:03 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:03 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:03 --> Total execution time: 0.0143
INFO - 2023-04-28 02:25:03 --> Config Class Initialized
INFO - 2023-04-28 02:25:03 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:03 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:03 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:03 --> URI Class Initialized
INFO - 2023-04-28 02:25:03 --> Router Class Initialized
INFO - 2023-04-28 02:25:03 --> Output Class Initialized
INFO - 2023-04-28 02:25:03 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:03 --> Input Class Initialized
INFO - 2023-04-28 02:25:03 --> Language Class Initialized
INFO - 2023-04-28 02:25:03 --> Loader Class Initialized
INFO - 2023-04-28 02:25:03 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:03 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:03 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:03 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:03 --> Total execution time: 0.0550
INFO - 2023-04-28 02:25:05 --> Config Class Initialized
INFO - 2023-04-28 02:25:05 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:05 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:05 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:05 --> URI Class Initialized
INFO - 2023-04-28 02:25:05 --> Router Class Initialized
INFO - 2023-04-28 02:25:05 --> Output Class Initialized
INFO - 2023-04-28 02:25:05 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:05 --> Input Class Initialized
INFO - 2023-04-28 02:25:05 --> Language Class Initialized
INFO - 2023-04-28 02:25:05 --> Loader Class Initialized
INFO - 2023-04-28 02:25:05 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:05 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:05 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:05 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:05 --> Total execution time: 0.0567
INFO - 2023-04-28 02:25:05 --> Config Class Initialized
INFO - 2023-04-28 02:25:05 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:05 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:05 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:05 --> URI Class Initialized
INFO - 2023-04-28 02:25:05 --> Router Class Initialized
INFO - 2023-04-28 02:25:05 --> Output Class Initialized
INFO - 2023-04-28 02:25:05 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:05 --> Input Class Initialized
INFO - 2023-04-28 02:25:05 --> Language Class Initialized
INFO - 2023-04-28 02:25:05 --> Loader Class Initialized
INFO - 2023-04-28 02:25:05 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:05 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:05 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:05 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:05 --> Total execution time: 0.0591
INFO - 2023-04-28 02:25:08 --> Config Class Initialized
INFO - 2023-04-28 02:25:08 --> Config Class Initialized
INFO - 2023-04-28 02:25:08 --> Hooks Class Initialized
INFO - 2023-04-28 02:25:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:08 --> Utf8 Class Initialized
DEBUG - 2023-04-28 02:25:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:08 --> URI Class Initialized
INFO - 2023-04-28 02:25:08 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:08 --> URI Class Initialized
INFO - 2023-04-28 02:25:08 --> Router Class Initialized
INFO - 2023-04-28 02:25:08 --> Router Class Initialized
INFO - 2023-04-28 02:25:08 --> Output Class Initialized
INFO - 2023-04-28 02:25:08 --> Output Class Initialized
INFO - 2023-04-28 02:25:08 --> Security Class Initialized
INFO - 2023-04-28 02:25:08 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 02:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:08 --> Input Class Initialized
INFO - 2023-04-28 02:25:08 --> Input Class Initialized
INFO - 2023-04-28 02:25:08 --> Language Class Initialized
INFO - 2023-04-28 02:25:08 --> Language Class Initialized
INFO - 2023-04-28 02:25:08 --> Loader Class Initialized
INFO - 2023-04-28 02:25:08 --> Loader Class Initialized
INFO - 2023-04-28 02:25:08 --> Controller Class Initialized
INFO - 2023-04-28 02:25:08 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 02:25:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:08 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:08 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:08 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:08 --> Total execution time: 0.0203
INFO - 2023-04-28 02:25:08 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:08 --> Total execution time: 0.0210
INFO - 2023-04-28 02:25:08 --> Config Class Initialized
INFO - 2023-04-28 02:25:08 --> Config Class Initialized
INFO - 2023-04-28 02:25:08 --> Hooks Class Initialized
INFO - 2023-04-28 02:25:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 02:25:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:08 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:08 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:08 --> URI Class Initialized
INFO - 2023-04-28 02:25:08 --> URI Class Initialized
INFO - 2023-04-28 02:25:08 --> Router Class Initialized
INFO - 2023-04-28 02:25:08 --> Router Class Initialized
INFO - 2023-04-28 02:25:08 --> Output Class Initialized
INFO - 2023-04-28 02:25:08 --> Output Class Initialized
INFO - 2023-04-28 02:25:08 --> Security Class Initialized
INFO - 2023-04-28 02:25:08 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 02:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:08 --> Input Class Initialized
INFO - 2023-04-28 02:25:08 --> Input Class Initialized
INFO - 2023-04-28 02:25:08 --> Language Class Initialized
INFO - 2023-04-28 02:25:08 --> Language Class Initialized
INFO - 2023-04-28 02:25:08 --> Loader Class Initialized
INFO - 2023-04-28 02:25:08 --> Loader Class Initialized
INFO - 2023-04-28 02:25:08 --> Controller Class Initialized
INFO - 2023-04-28 02:25:08 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 02:25:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:08 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:08 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:08 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:08 --> Total execution time: 0.0157
INFO - 2023-04-28 02:25:08 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:08 --> Total execution time: 0.0163
INFO - 2023-04-28 02:25:10 --> Config Class Initialized
INFO - 2023-04-28 02:25:10 --> Config Class Initialized
INFO - 2023-04-28 02:25:10 --> Hooks Class Initialized
INFO - 2023-04-28 02:25:11 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 02:25:11 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:11 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:11 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:11 --> URI Class Initialized
INFO - 2023-04-28 02:25:11 --> URI Class Initialized
INFO - 2023-04-28 02:25:11 --> Router Class Initialized
INFO - 2023-04-28 02:25:11 --> Router Class Initialized
INFO - 2023-04-28 02:25:11 --> Output Class Initialized
INFO - 2023-04-28 02:25:11 --> Output Class Initialized
INFO - 2023-04-28 02:25:11 --> Security Class Initialized
INFO - 2023-04-28 02:25:11 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 02:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:11 --> Input Class Initialized
INFO - 2023-04-28 02:25:11 --> Input Class Initialized
INFO - 2023-04-28 02:25:11 --> Language Class Initialized
INFO - 2023-04-28 02:25:11 --> Language Class Initialized
INFO - 2023-04-28 02:25:11 --> Loader Class Initialized
INFO - 2023-04-28 02:25:11 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:11 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:11 --> Loader Class Initialized
INFO - 2023-04-28 02:25:11 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:11 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:11 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:11 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:11 --> Model "Login_model" initialized
INFO - 2023-04-28 02:25:11 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:11 --> Total execution time: 0.0693
INFO - 2023-04-28 02:25:11 --> Config Class Initialized
INFO - 2023-04-28 02:25:11 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:11 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:11 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:11 --> URI Class Initialized
INFO - 2023-04-28 02:25:11 --> Router Class Initialized
INFO - 2023-04-28 02:25:11 --> Output Class Initialized
INFO - 2023-04-28 02:25:11 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:11 --> Input Class Initialized
INFO - 2023-04-28 02:25:11 --> Language Class Initialized
INFO - 2023-04-28 02:25:11 --> Loader Class Initialized
INFO - 2023-04-28 02:25:11 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:11 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:11 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:11 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:11 --> Total execution time: 0.2384
INFO - 2023-04-28 02:25:11 --> Config Class Initialized
INFO - 2023-04-28 02:25:11 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:11 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:11 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:11 --> URI Class Initialized
INFO - 2023-04-28 02:25:11 --> Router Class Initialized
INFO - 2023-04-28 02:25:11 --> Output Class Initialized
INFO - 2023-04-28 02:25:11 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:11 --> Input Class Initialized
INFO - 2023-04-28 02:25:11 --> Language Class Initialized
INFO - 2023-04-28 02:25:11 --> Loader Class Initialized
INFO - 2023-04-28 02:25:11 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:11 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:11 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:11 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:11 --> Total execution time: 0.1849
INFO - 2023-04-28 02:25:11 --> Config Class Initialized
INFO - 2023-04-28 02:25:11 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:11 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:11 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:11 --> Final output sent to browser
INFO - 2023-04-28 02:25:11 --> URI Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Total execution time: 0.0559
INFO - 2023-04-28 02:25:11 --> Router Class Initialized
INFO - 2023-04-28 02:25:11 --> Output Class Initialized
INFO - 2023-04-28 02:25:11 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:11 --> Config Class Initialized
INFO - 2023-04-28 02:25:11 --> Input Class Initialized
INFO - 2023-04-28 02:25:11 --> Hooks Class Initialized
INFO - 2023-04-28 02:25:11 --> Language Class Initialized
DEBUG - 2023-04-28 02:25:11 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:11 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:11 --> Loader Class Initialized
INFO - 2023-04-28 02:25:11 --> URI Class Initialized
INFO - 2023-04-28 02:25:11 --> Controller Class Initialized
INFO - 2023-04-28 02:25:11 --> Router Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:11 --> Output Class Initialized
INFO - 2023-04-28 02:25:11 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:11 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:11 --> Input Class Initialized
INFO - 2023-04-28 02:25:11 --> Language Class Initialized
INFO - 2023-04-28 02:25:11 --> Loader Class Initialized
INFO - 2023-04-28 02:25:11 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:11 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:11 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:11 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:11 --> Model "Login_model" initialized
INFO - 2023-04-28 02:25:11 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:11 --> Total execution time: 0.1095
INFO - 2023-04-28 02:25:11 --> Config Class Initialized
INFO - 2023-04-28 02:25:11 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:11 --> Total execution time: 0.0958
INFO - 2023-04-28 02:25:11 --> Config Class Initialized
INFO - 2023-04-28 02:25:11 --> Hooks Class Initialized
INFO - 2023-04-28 02:25:11 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 02:25:11 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:11 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:11 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:11 --> URI Class Initialized
INFO - 2023-04-28 02:25:11 --> URI Class Initialized
INFO - 2023-04-28 02:25:11 --> Router Class Initialized
INFO - 2023-04-28 02:25:11 --> Router Class Initialized
INFO - 2023-04-28 02:25:11 --> Output Class Initialized
INFO - 2023-04-28 02:25:11 --> Output Class Initialized
INFO - 2023-04-28 02:25:11 --> Security Class Initialized
INFO - 2023-04-28 02:25:11 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 02:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:11 --> Input Class Initialized
INFO - 2023-04-28 02:25:11 --> Input Class Initialized
INFO - 2023-04-28 02:25:11 --> Language Class Initialized
INFO - 2023-04-28 02:25:11 --> Language Class Initialized
INFO - 2023-04-28 02:25:11 --> Loader Class Initialized
INFO - 2023-04-28 02:25:11 --> Loader Class Initialized
INFO - 2023-04-28 02:25:11 --> Controller Class Initialized
INFO - 2023-04-28 02:25:11 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 02:25:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:11 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:11 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:11 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:11 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:11 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:11 --> Total execution time: 0.1665
INFO - 2023-04-28 02:25:11 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:11 --> Total execution time: 0.1388
INFO - 2023-04-28 02:25:14 --> Config Class Initialized
INFO - 2023-04-28 02:25:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:14 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:14 --> URI Class Initialized
INFO - 2023-04-28 02:25:14 --> Router Class Initialized
INFO - 2023-04-28 02:25:14 --> Output Class Initialized
INFO - 2023-04-28 02:25:14 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:14 --> Input Class Initialized
INFO - 2023-04-28 02:25:14 --> Language Class Initialized
INFO - 2023-04-28 02:25:14 --> Loader Class Initialized
INFO - 2023-04-28 02:25:14 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:14 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:14 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:14 --> Total execution time: 0.2919
INFO - 2023-04-28 02:25:14 --> Config Class Initialized
INFO - 2023-04-28 02:25:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:14 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:14 --> URI Class Initialized
INFO - 2023-04-28 02:25:14 --> Router Class Initialized
INFO - 2023-04-28 02:25:14 --> Output Class Initialized
INFO - 2023-04-28 02:25:14 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:14 --> Input Class Initialized
INFO - 2023-04-28 02:25:14 --> Language Class Initialized
INFO - 2023-04-28 02:25:14 --> Loader Class Initialized
INFO - 2023-04-28 02:25:14 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:14 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:14 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:14 --> Total execution time: 0.0380
INFO - 2023-04-28 02:25:17 --> Config Class Initialized
INFO - 2023-04-28 02:25:17 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:17 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:17 --> URI Class Initialized
INFO - 2023-04-28 02:25:17 --> Router Class Initialized
INFO - 2023-04-28 02:25:18 --> Output Class Initialized
INFO - 2023-04-28 02:25:18 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:18 --> Input Class Initialized
INFO - 2023-04-28 02:25:18 --> Language Class Initialized
INFO - 2023-04-28 02:25:18 --> Loader Class Initialized
INFO - 2023-04-28 02:25:18 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:18 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:18 --> Total execution time: 0.0444
INFO - 2023-04-28 02:25:18 --> Config Class Initialized
INFO - 2023-04-28 02:25:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:18 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:18 --> URI Class Initialized
INFO - 2023-04-28 02:25:18 --> Router Class Initialized
INFO - 2023-04-28 02:25:18 --> Output Class Initialized
INFO - 2023-04-28 02:25:18 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:18 --> Input Class Initialized
INFO - 2023-04-28 02:25:18 --> Language Class Initialized
INFO - 2023-04-28 02:25:18 --> Loader Class Initialized
INFO - 2023-04-28 02:25:18 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:18 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:18 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:18 --> Total execution time: 0.0637
INFO - 2023-04-28 02:25:21 --> Config Class Initialized
INFO - 2023-04-28 02:25:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:21 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:21 --> URI Class Initialized
INFO - 2023-04-28 02:25:21 --> Router Class Initialized
INFO - 2023-04-28 02:25:21 --> Output Class Initialized
INFO - 2023-04-28 02:25:21 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:21 --> Input Class Initialized
INFO - 2023-04-28 02:25:21 --> Language Class Initialized
INFO - 2023-04-28 02:25:21 --> Loader Class Initialized
INFO - 2023-04-28 02:25:21 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:21 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:21 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:21 --> Total execution time: 0.0217
INFO - 2023-04-28 02:25:21 --> Config Class Initialized
INFO - 2023-04-28 02:25:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:21 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:21 --> URI Class Initialized
INFO - 2023-04-28 02:25:21 --> Router Class Initialized
INFO - 2023-04-28 02:25:21 --> Output Class Initialized
INFO - 2023-04-28 02:25:21 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:21 --> Input Class Initialized
INFO - 2023-04-28 02:25:21 --> Language Class Initialized
INFO - 2023-04-28 02:25:21 --> Loader Class Initialized
INFO - 2023-04-28 02:25:21 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:21 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:21 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:21 --> Total execution time: 0.0542
INFO - 2023-04-28 02:25:24 --> Config Class Initialized
INFO - 2023-04-28 02:25:24 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:24 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:24 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:24 --> URI Class Initialized
INFO - 2023-04-28 02:25:24 --> Router Class Initialized
INFO - 2023-04-28 02:25:24 --> Output Class Initialized
INFO - 2023-04-28 02:25:24 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:24 --> Input Class Initialized
INFO - 2023-04-28 02:25:24 --> Language Class Initialized
INFO - 2023-04-28 02:25:24 --> Loader Class Initialized
INFO - 2023-04-28 02:25:24 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:24 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:24 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:24 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:24 --> Total execution time: 0.0232
INFO - 2023-04-28 02:25:24 --> Config Class Initialized
INFO - 2023-04-28 02:25:24 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:24 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:24 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:24 --> URI Class Initialized
INFO - 2023-04-28 02:25:24 --> Router Class Initialized
INFO - 2023-04-28 02:25:24 --> Output Class Initialized
INFO - 2023-04-28 02:25:24 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:24 --> Input Class Initialized
INFO - 2023-04-28 02:25:24 --> Language Class Initialized
INFO - 2023-04-28 02:25:24 --> Loader Class Initialized
INFO - 2023-04-28 02:25:25 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:25 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:25 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:25 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:25 --> Total execution time: 0.0573
INFO - 2023-04-28 02:25:43 --> Config Class Initialized
INFO - 2023-04-28 02:25:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:43 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:43 --> URI Class Initialized
INFO - 2023-04-28 02:25:43 --> Router Class Initialized
INFO - 2023-04-28 02:25:43 --> Output Class Initialized
INFO - 2023-04-28 02:25:43 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:43 --> Input Class Initialized
INFO - 2023-04-28 02:25:43 --> Language Class Initialized
INFO - 2023-04-28 02:25:43 --> Loader Class Initialized
INFO - 2023-04-28 02:25:43 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:43 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:43 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:43 --> Total execution time: 0.0150
INFO - 2023-04-28 02:25:43 --> Config Class Initialized
INFO - 2023-04-28 02:25:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:43 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:43 --> URI Class Initialized
INFO - 2023-04-28 02:25:43 --> Router Class Initialized
INFO - 2023-04-28 02:25:43 --> Output Class Initialized
INFO - 2023-04-28 02:25:43 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:43 --> Input Class Initialized
INFO - 2023-04-28 02:25:43 --> Language Class Initialized
INFO - 2023-04-28 02:25:43 --> Loader Class Initialized
INFO - 2023-04-28 02:25:43 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:43 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:43 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:43 --> Total execution time: 0.0573
INFO - 2023-04-28 02:25:54 --> Config Class Initialized
INFO - 2023-04-28 02:25:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:54 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:54 --> URI Class Initialized
INFO - 2023-04-28 02:25:54 --> Router Class Initialized
INFO - 2023-04-28 02:25:54 --> Output Class Initialized
INFO - 2023-04-28 02:25:54 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:54 --> Input Class Initialized
INFO - 2023-04-28 02:25:54 --> Language Class Initialized
INFO - 2023-04-28 02:25:54 --> Loader Class Initialized
INFO - 2023-04-28 02:25:54 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:54 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:54 --> Total execution time: 0.0039
INFO - 2023-04-28 02:25:54 --> Config Class Initialized
INFO - 2023-04-28 02:25:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:25:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:25:54 --> Utf8 Class Initialized
INFO - 2023-04-28 02:25:54 --> URI Class Initialized
INFO - 2023-04-28 02:25:54 --> Router Class Initialized
INFO - 2023-04-28 02:25:54 --> Output Class Initialized
INFO - 2023-04-28 02:25:54 --> Security Class Initialized
DEBUG - 2023-04-28 02:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:25:54 --> Input Class Initialized
INFO - 2023-04-28 02:25:54 --> Language Class Initialized
INFO - 2023-04-28 02:25:54 --> Loader Class Initialized
INFO - 2023-04-28 02:25:54 --> Controller Class Initialized
DEBUG - 2023-04-28 02:25:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:25:54 --> Database Driver Class Initialized
INFO - 2023-04-28 02:25:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:25:54 --> Final output sent to browser
DEBUG - 2023-04-28 02:25:54 --> Total execution time: 0.0150
INFO - 2023-04-28 02:26:15 --> Config Class Initialized
INFO - 2023-04-28 02:26:15 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:15 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:15 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:15 --> URI Class Initialized
INFO - 2023-04-28 02:26:15 --> Router Class Initialized
INFO - 2023-04-28 02:26:15 --> Output Class Initialized
INFO - 2023-04-28 02:26:15 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:15 --> Input Class Initialized
INFO - 2023-04-28 02:26:15 --> Language Class Initialized
INFO - 2023-04-28 02:26:15 --> Loader Class Initialized
INFO - 2023-04-28 02:26:15 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:15 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:15 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:15 --> Model "Login_model" initialized
INFO - 2023-04-28 02:26:15 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:15 --> Total execution time: 0.0457
INFO - 2023-04-28 02:26:15 --> Config Class Initialized
INFO - 2023-04-28 02:26:15 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:15 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:15 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:15 --> URI Class Initialized
INFO - 2023-04-28 02:26:15 --> Router Class Initialized
INFO - 2023-04-28 02:26:15 --> Output Class Initialized
INFO - 2023-04-28 02:26:15 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:15 --> Input Class Initialized
INFO - 2023-04-28 02:26:15 --> Language Class Initialized
INFO - 2023-04-28 02:26:15 --> Loader Class Initialized
INFO - 2023-04-28 02:26:15 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:15 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:15 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:15 --> Model "Login_model" initialized
INFO - 2023-04-28 02:26:15 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:15 --> Total execution time: 0.0737
INFO - 2023-04-28 02:26:16 --> Config Class Initialized
INFO - 2023-04-28 02:26:16 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:16 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:16 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:16 --> URI Class Initialized
INFO - 2023-04-28 02:26:16 --> Router Class Initialized
INFO - 2023-04-28 02:26:16 --> Output Class Initialized
INFO - 2023-04-28 02:26:16 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:16 --> Input Class Initialized
INFO - 2023-04-28 02:26:16 --> Language Class Initialized
INFO - 2023-04-28 02:26:17 --> Loader Class Initialized
INFO - 2023-04-28 02:26:17 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:17 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:17 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:17 --> Model "Login_model" initialized
INFO - 2023-04-28 02:26:17 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:17 --> Total execution time: 0.0253
INFO - 2023-04-28 02:26:17 --> Config Class Initialized
INFO - 2023-04-28 02:26:17 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:17 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:17 --> URI Class Initialized
INFO - 2023-04-28 02:26:17 --> Router Class Initialized
INFO - 2023-04-28 02:26:17 --> Output Class Initialized
INFO - 2023-04-28 02:26:17 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:17 --> Input Class Initialized
INFO - 2023-04-28 02:26:17 --> Language Class Initialized
INFO - 2023-04-28 02:26:17 --> Loader Class Initialized
INFO - 2023-04-28 02:26:17 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:17 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:17 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:17 --> Model "Login_model" initialized
INFO - 2023-04-28 02:26:17 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:17 --> Total execution time: 0.0595
INFO - 2023-04-28 02:26:19 --> Config Class Initialized
INFO - 2023-04-28 02:26:19 --> Config Class Initialized
INFO - 2023-04-28 02:26:19 --> Hooks Class Initialized
INFO - 2023-04-28 02:26:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:19 --> Utf8 Class Initialized
DEBUG - 2023-04-28 02:26:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:19 --> URI Class Initialized
INFO - 2023-04-28 02:26:19 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:19 --> Router Class Initialized
INFO - 2023-04-28 02:26:19 --> URI Class Initialized
INFO - 2023-04-28 02:26:19 --> Output Class Initialized
INFO - 2023-04-28 02:26:19 --> Router Class Initialized
INFO - 2023-04-28 02:26:19 --> Security Class Initialized
INFO - 2023-04-28 02:26:19 --> Output Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:19 --> Input Class Initialized
INFO - 2023-04-28 02:26:19 --> Security Class Initialized
INFO - 2023-04-28 02:26:19 --> Language Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:19 --> Input Class Initialized
INFO - 2023-04-28 02:26:19 --> Loader Class Initialized
INFO - 2023-04-28 02:26:19 --> Language Class Initialized
INFO - 2023-04-28 02:26:19 --> Controller Class Initialized
INFO - 2023-04-28 02:26:19 --> Loader Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:19 --> Controller Class Initialized
INFO - 2023-04-28 02:26:19 --> Database Driver Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:19 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:19 --> Model "Login_model" initialized
INFO - 2023-04-28 02:26:19 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:19 --> Total execution time: 0.0513
INFO - 2023-04-28 02:26:19 --> Config Class Initialized
INFO - 2023-04-28 02:26:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:19 --> Final output sent to browser
INFO - 2023-04-28 02:26:19 --> Utf8 Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Total execution time: 0.0590
INFO - 2023-04-28 02:26:19 --> URI Class Initialized
INFO - 2023-04-28 02:26:19 --> Router Class Initialized
INFO - 2023-04-28 02:26:19 --> Output Class Initialized
INFO - 2023-04-28 02:26:19 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:19 --> Input Class Initialized
INFO - 2023-04-28 02:26:19 --> Config Class Initialized
INFO - 2023-04-28 02:26:19 --> Language Class Initialized
INFO - 2023-04-28 02:26:19 --> Hooks Class Initialized
INFO - 2023-04-28 02:26:19 --> Loader Class Initialized
DEBUG - 2023-04-28 02:26:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:19 --> Controller Class Initialized
INFO - 2023-04-28 02:26:19 --> Utf8 Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:19 --> URI Class Initialized
INFO - 2023-04-28 02:26:19 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:19 --> Router Class Initialized
INFO - 2023-04-28 02:26:19 --> Output Class Initialized
INFO - 2023-04-28 02:26:19 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:19 --> Input Class Initialized
INFO - 2023-04-28 02:26:19 --> Language Class Initialized
INFO - 2023-04-28 02:26:19 --> Loader Class Initialized
INFO - 2023-04-28 02:26:19 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:19 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:19 --> Total execution time: 0.0469
INFO - 2023-04-28 02:26:19 --> Config Class Initialized
INFO - 2023-04-28 02:26:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:19 --> Final output sent to browser
INFO - 2023-04-28 02:26:19 --> Utf8 Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Total execution time: 0.0952
INFO - 2023-04-28 02:26:19 --> URI Class Initialized
INFO - 2023-04-28 02:26:19 --> Router Class Initialized
INFO - 2023-04-28 02:26:19 --> Output Class Initialized
INFO - 2023-04-28 02:26:19 --> Security Class Initialized
INFO - 2023-04-28 02:26:19 --> Config Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:19 --> Hooks Class Initialized
INFO - 2023-04-28 02:26:19 --> Input Class Initialized
DEBUG - 2023-04-28 02:26:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:19 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:19 --> Language Class Initialized
INFO - 2023-04-28 02:26:19 --> URI Class Initialized
INFO - 2023-04-28 02:26:19 --> Loader Class Initialized
INFO - 2023-04-28 02:26:19 --> Router Class Initialized
INFO - 2023-04-28 02:26:19 --> Controller Class Initialized
INFO - 2023-04-28 02:26:19 --> Output Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:19 --> Security Class Initialized
INFO - 2023-04-28 02:26:19 --> Database Driver Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:19 --> Input Class Initialized
INFO - 2023-04-28 02:26:19 --> Language Class Initialized
INFO - 2023-04-28 02:26:19 --> Loader Class Initialized
INFO - 2023-04-28 02:26:19 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:19 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:19 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:19 --> Model "Login_model" initialized
INFO - 2023-04-28 02:26:19 --> Model "Login_model" initialized
INFO - 2023-04-28 02:26:19 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:19 --> Total execution time: 0.0618
INFO - 2023-04-28 02:26:19 --> Config Class Initialized
INFO - 2023-04-28 02:26:19 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:19 --> Total execution time: 0.1086
INFO - 2023-04-28 02:26:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:19 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:19 --> URI Class Initialized
INFO - 2023-04-28 02:26:19 --> Config Class Initialized
INFO - 2023-04-28 02:26:19 --> Hooks Class Initialized
INFO - 2023-04-28 02:26:19 --> Router Class Initialized
INFO - 2023-04-28 02:26:19 --> Output Class Initialized
DEBUG - 2023-04-28 02:26:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:19 --> Security Class Initialized
INFO - 2023-04-28 02:26:19 --> Utf8 Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:19 --> URI Class Initialized
INFO - 2023-04-28 02:26:19 --> Input Class Initialized
INFO - 2023-04-28 02:26:19 --> Router Class Initialized
INFO - 2023-04-28 02:26:19 --> Language Class Initialized
INFO - 2023-04-28 02:26:19 --> Output Class Initialized
INFO - 2023-04-28 02:26:19 --> Loader Class Initialized
INFO - 2023-04-28 02:26:19 --> Security Class Initialized
INFO - 2023-04-28 02:26:19 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 02:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:19 --> Input Class Initialized
INFO - 2023-04-28 02:26:19 --> Language Class Initialized
INFO - 2023-04-28 02:26:19 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:19 --> Loader Class Initialized
INFO - 2023-04-28 02:26:19 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:19 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:19 --> Model "Login_model" initialized
INFO - 2023-04-28 02:26:19 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:19 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:19 --> Model "Login_model" initialized
INFO - 2023-04-28 02:26:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:19 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:19 --> Total execution time: 0.1043
INFO - 2023-04-28 02:26:19 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:19 --> Total execution time: 0.0642
INFO - 2023-04-28 02:26:23 --> Config Class Initialized
INFO - 2023-04-28 02:26:23 --> Config Class Initialized
INFO - 2023-04-28 02:26:23 --> Hooks Class Initialized
INFO - 2023-04-28 02:26:23 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 02:26:23 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:23 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:23 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:23 --> URI Class Initialized
INFO - 2023-04-28 02:26:23 --> URI Class Initialized
INFO - 2023-04-28 02:26:23 --> Router Class Initialized
INFO - 2023-04-28 02:26:23 --> Router Class Initialized
INFO - 2023-04-28 02:26:23 --> Output Class Initialized
INFO - 2023-04-28 02:26:23 --> Output Class Initialized
INFO - 2023-04-28 02:26:23 --> Security Class Initialized
INFO - 2023-04-28 02:26:23 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 02:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:23 --> Input Class Initialized
INFO - 2023-04-28 02:26:23 --> Input Class Initialized
INFO - 2023-04-28 02:26:23 --> Language Class Initialized
INFO - 2023-04-28 02:26:23 --> Language Class Initialized
INFO - 2023-04-28 02:26:23 --> Loader Class Initialized
INFO - 2023-04-28 02:26:23 --> Loader Class Initialized
INFO - 2023-04-28 02:26:23 --> Controller Class Initialized
INFO - 2023-04-28 02:26:23 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 02:26:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:23 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:23 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:23 --> Model "Login_model" initialized
INFO - 2023-04-28 02:26:23 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:23 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:23 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:23 --> Total execution time: 0.0191
INFO - 2023-04-28 02:26:23 --> Config Class Initialized
INFO - 2023-04-28 02:26:23 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:23 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:23 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:23 --> URI Class Initialized
INFO - 2023-04-28 02:26:23 --> Router Class Initialized
INFO - 2023-04-28 02:26:23 --> Output Class Initialized
INFO - 2023-04-28 02:26:23 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:23 --> Input Class Initialized
INFO - 2023-04-28 02:26:23 --> Language Class Initialized
INFO - 2023-04-28 02:26:23 --> Loader Class Initialized
INFO - 2023-04-28 02:26:23 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:23 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:23 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:23 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:23 --> Total execution time: 0.0291
INFO - 2023-04-28 02:26:23 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:23 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:23 --> Total execution time: 0.0562
INFO - 2023-04-28 02:26:26 --> Config Class Initialized
INFO - 2023-04-28 02:26:26 --> Config Class Initialized
INFO - 2023-04-28 02:26:26 --> Hooks Class Initialized
INFO - 2023-04-28 02:26:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 02:26:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:26 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:26 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:26 --> URI Class Initialized
INFO - 2023-04-28 02:26:26 --> URI Class Initialized
INFO - 2023-04-28 02:26:26 --> Router Class Initialized
INFO - 2023-04-28 02:26:26 --> Router Class Initialized
INFO - 2023-04-28 02:26:26 --> Output Class Initialized
INFO - 2023-04-28 02:26:26 --> Output Class Initialized
INFO - 2023-04-28 02:26:26 --> Security Class Initialized
INFO - 2023-04-28 02:26:26 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 02:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:26 --> Input Class Initialized
INFO - 2023-04-28 02:26:26 --> Input Class Initialized
INFO - 2023-04-28 02:26:26 --> Language Class Initialized
INFO - 2023-04-28 02:26:26 --> Language Class Initialized
INFO - 2023-04-28 02:26:26 --> Loader Class Initialized
INFO - 2023-04-28 02:26:26 --> Controller Class Initialized
INFO - 2023-04-28 02:26:26 --> Loader Class Initialized
DEBUG - 2023-04-28 02:26:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:26 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:26 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:26 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:26 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:26 --> Total execution time: 0.0159
INFO - 2023-04-28 02:26:26 --> Final output sent to browser
INFO - 2023-04-28 02:26:26 --> Config Class Initialized
DEBUG - 2023-04-28 02:26:26 --> Total execution time: 0.0178
INFO - 2023-04-28 02:26:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:26 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:26 --> URI Class Initialized
INFO - 2023-04-28 02:26:26 --> Router Class Initialized
INFO - 2023-04-28 02:26:26 --> Output Class Initialized
INFO - 2023-04-28 02:26:26 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:26 --> Input Class Initialized
INFO - 2023-04-28 02:26:26 --> Language Class Initialized
INFO - 2023-04-28 02:26:26 --> Loader Class Initialized
INFO - 2023-04-28 02:26:26 --> Config Class Initialized
INFO - 2023-04-28 02:26:26 --> Controller Class Initialized
INFO - 2023-04-28 02:26:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 02:26:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:26 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:26 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:26 --> URI Class Initialized
INFO - 2023-04-28 02:26:26 --> Router Class Initialized
INFO - 2023-04-28 02:26:26 --> Output Class Initialized
INFO - 2023-04-28 02:26:26 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:26 --> Input Class Initialized
INFO - 2023-04-28 02:26:26 --> Language Class Initialized
INFO - 2023-04-28 02:26:26 --> Loader Class Initialized
INFO - 2023-04-28 02:26:26 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:26 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:26 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:26 --> Total execution time: 0.0547
INFO - 2023-04-28 02:26:26 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:26 --> Total execution time: 0.0166
INFO - 2023-04-28 02:26:41 --> Config Class Initialized
INFO - 2023-04-28 02:26:41 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:41 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:41 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:41 --> URI Class Initialized
INFO - 2023-04-28 02:26:41 --> Router Class Initialized
INFO - 2023-04-28 02:26:41 --> Output Class Initialized
INFO - 2023-04-28 02:26:41 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:41 --> Input Class Initialized
INFO - 2023-04-28 02:26:41 --> Language Class Initialized
INFO - 2023-04-28 02:26:41 --> Loader Class Initialized
INFO - 2023-04-28 02:26:41 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:41 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:41 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:41 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:41 --> Total execution time: 0.0406
INFO - 2023-04-28 02:26:41 --> Config Class Initialized
INFO - 2023-04-28 02:26:41 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:41 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:41 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:41 --> URI Class Initialized
INFO - 2023-04-28 02:26:41 --> Router Class Initialized
INFO - 2023-04-28 02:26:41 --> Output Class Initialized
INFO - 2023-04-28 02:26:41 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:41 --> Input Class Initialized
INFO - 2023-04-28 02:26:41 --> Language Class Initialized
INFO - 2023-04-28 02:26:41 --> Loader Class Initialized
INFO - 2023-04-28 02:26:41 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:41 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:41 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:41 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:41 --> Total execution time: 0.0105
INFO - 2023-04-28 02:26:43 --> Config Class Initialized
INFO - 2023-04-28 02:26:43 --> Config Class Initialized
INFO - 2023-04-28 02:26:43 --> Hooks Class Initialized
INFO - 2023-04-28 02:26:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 02:26:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:43 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:43 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:43 --> URI Class Initialized
INFO - 2023-04-28 02:26:43 --> URI Class Initialized
INFO - 2023-04-28 02:26:43 --> Router Class Initialized
INFO - 2023-04-28 02:26:43 --> Router Class Initialized
INFO - 2023-04-28 02:26:43 --> Output Class Initialized
INFO - 2023-04-28 02:26:43 --> Output Class Initialized
INFO - 2023-04-28 02:26:43 --> Security Class Initialized
INFO - 2023-04-28 02:26:43 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 02:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:43 --> Input Class Initialized
INFO - 2023-04-28 02:26:43 --> Input Class Initialized
INFO - 2023-04-28 02:26:43 --> Language Class Initialized
INFO - 2023-04-28 02:26:43 --> Language Class Initialized
INFO - 2023-04-28 02:26:43 --> Loader Class Initialized
INFO - 2023-04-28 02:26:43 --> Loader Class Initialized
INFO - 2023-04-28 02:26:43 --> Controller Class Initialized
INFO - 2023-04-28 02:26:43 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 02:26:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:43 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:43 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:43 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:43 --> Total execution time: 0.0169
INFO - 2023-04-28 02:26:43 --> Config Class Initialized
INFO - 2023-04-28 02:26:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:43 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:43 --> URI Class Initialized
INFO - 2023-04-28 02:26:43 --> Router Class Initialized
INFO - 2023-04-28 02:26:43 --> Output Class Initialized
INFO - 2023-04-28 02:26:43 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:43 --> Input Class Initialized
INFO - 2023-04-28 02:26:43 --> Language Class Initialized
INFO - 2023-04-28 02:26:43 --> Loader Class Initialized
INFO - 2023-04-28 02:26:43 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:43 --> Final output sent to browser
INFO - 2023-04-28 02:26:43 --> Database Driver Class Initialized
DEBUG - 2023-04-28 02:26:43 --> Total execution time: 0.0204
INFO - 2023-04-28 02:26:43 --> Config Class Initialized
INFO - 2023-04-28 02:26:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:43 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:43 --> URI Class Initialized
INFO - 2023-04-28 02:26:43 --> Router Class Initialized
INFO - 2023-04-28 02:26:43 --> Output Class Initialized
INFO - 2023-04-28 02:26:43 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:43 --> Input Class Initialized
INFO - 2023-04-28 02:26:43 --> Language Class Initialized
INFO - 2023-04-28 02:26:43 --> Loader Class Initialized
INFO - 2023-04-28 02:26:43 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:43 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:43 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:43 --> Total execution time: 0.0182
INFO - 2023-04-28 02:26:43 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:43 --> Total execution time: 0.0172
INFO - 2023-04-28 02:26:51 --> Config Class Initialized
INFO - 2023-04-28 02:26:51 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:51 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:51 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:51 --> URI Class Initialized
INFO - 2023-04-28 02:26:51 --> Router Class Initialized
INFO - 2023-04-28 02:26:51 --> Output Class Initialized
INFO - 2023-04-28 02:26:51 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:51 --> Input Class Initialized
INFO - 2023-04-28 02:26:51 --> Language Class Initialized
INFO - 2023-04-28 02:26:51 --> Loader Class Initialized
INFO - 2023-04-28 02:26:51 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:51 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:51 --> Total execution time: 0.0043
INFO - 2023-04-28 02:26:51 --> Config Class Initialized
INFO - 2023-04-28 02:26:51 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:51 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:51 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:51 --> URI Class Initialized
INFO - 2023-04-28 02:26:51 --> Router Class Initialized
INFO - 2023-04-28 02:26:51 --> Output Class Initialized
INFO - 2023-04-28 02:26:51 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:51 --> Input Class Initialized
INFO - 2023-04-28 02:26:51 --> Language Class Initialized
INFO - 2023-04-28 02:26:51 --> Loader Class Initialized
INFO - 2023-04-28 02:26:51 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:51 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:51 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:51 --> Model "Node_model" initialized
INFO - 2023-04-28 02:26:51 --> Model "Grafana_model" initialized
INFO - 2023-04-28 02:26:51 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:51 --> Total execution time: 0.0240
INFO - 2023-04-28 02:26:54 --> Config Class Initialized
INFO - 2023-04-28 02:26:54 --> Config Class Initialized
INFO - 2023-04-28 02:26:54 --> Hooks Class Initialized
INFO - 2023-04-28 02:26:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 02:26:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:54 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:54 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:54 --> URI Class Initialized
INFO - 2023-04-28 02:26:54 --> URI Class Initialized
INFO - 2023-04-28 02:26:54 --> Router Class Initialized
INFO - 2023-04-28 02:26:54 --> Router Class Initialized
INFO - 2023-04-28 02:26:54 --> Output Class Initialized
INFO - 2023-04-28 02:26:54 --> Output Class Initialized
INFO - 2023-04-28 02:26:54 --> Security Class Initialized
INFO - 2023-04-28 02:26:54 --> Security Class Initialized
DEBUG - 2023-04-28 02:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 02:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:54 --> Input Class Initialized
INFO - 2023-04-28 02:26:54 --> Input Class Initialized
INFO - 2023-04-28 02:26:54 --> Language Class Initialized
INFO - 2023-04-28 02:26:54 --> Language Class Initialized
INFO - 2023-04-28 02:26:54 --> Loader Class Initialized
INFO - 2023-04-28 02:26:54 --> Loader Class Initialized
INFO - 2023-04-28 02:26:54 --> Controller Class Initialized
INFO - 2023-04-28 02:26:54 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 02:26:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:54 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:54 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:54 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:54 --> Total execution time: 0.0382
INFO - 2023-04-28 02:26:54 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:54 --> Total execution time: 0.0398
INFO - 2023-04-28 02:26:54 --> Config Class Initialized
INFO - 2023-04-28 02:26:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:26:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:54 --> Config Class Initialized
INFO - 2023-04-28 02:26:54 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:54 --> Hooks Class Initialized
INFO - 2023-04-28 02:26:54 --> URI Class Initialized
DEBUG - 2023-04-28 02:26:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:26:54 --> Router Class Initialized
INFO - 2023-04-28 02:26:54 --> Utf8 Class Initialized
INFO - 2023-04-28 02:26:54 --> Output Class Initialized
INFO - 2023-04-28 02:26:54 --> URI Class Initialized
INFO - 2023-04-28 02:26:54 --> Security Class Initialized
INFO - 2023-04-28 02:26:54 --> Router Class Initialized
DEBUG - 2023-04-28 02:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:54 --> Output Class Initialized
INFO - 2023-04-28 02:26:54 --> Input Class Initialized
INFO - 2023-04-28 02:26:54 --> Security Class Initialized
INFO - 2023-04-28 02:26:54 --> Language Class Initialized
DEBUG - 2023-04-28 02:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:26:54 --> Input Class Initialized
INFO - 2023-04-28 02:26:54 --> Loader Class Initialized
INFO - 2023-04-28 02:26:54 --> Language Class Initialized
INFO - 2023-04-28 02:26:54 --> Controller Class Initialized
DEBUG - 2023-04-28 02:26:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:54 --> Loader Class Initialized
INFO - 2023-04-28 02:26:54 --> Controller Class Initialized
INFO - 2023-04-28 02:26:54 --> Database Driver Class Initialized
DEBUG - 2023-04-28 02:26:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:26:54 --> Database Driver Class Initialized
INFO - 2023-04-28 02:26:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:26:54 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:54 --> Total execution time: 0.0129
INFO - 2023-04-28 02:26:54 --> Final output sent to browser
DEBUG - 2023-04-28 02:26:54 --> Total execution time: 0.0140
INFO - 2023-04-28 02:27:52 --> Config Class Initialized
INFO - 2023-04-28 02:27:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:27:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:27:52 --> Utf8 Class Initialized
INFO - 2023-04-28 02:27:52 --> URI Class Initialized
INFO - 2023-04-28 02:27:52 --> Router Class Initialized
INFO - 2023-04-28 02:27:52 --> Output Class Initialized
INFO - 2023-04-28 02:27:52 --> Security Class Initialized
DEBUG - 2023-04-28 02:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:27:52 --> Input Class Initialized
INFO - 2023-04-28 02:27:52 --> Language Class Initialized
INFO - 2023-04-28 02:27:52 --> Loader Class Initialized
INFO - 2023-04-28 02:27:52 --> Controller Class Initialized
DEBUG - 2023-04-28 02:27:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:27:52 --> Database Driver Class Initialized
INFO - 2023-04-28 02:27:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:27:52 --> Final output sent to browser
DEBUG - 2023-04-28 02:27:52 --> Total execution time: 0.0113
INFO - 2023-04-28 02:27:52 --> Config Class Initialized
INFO - 2023-04-28 02:27:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:27:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:27:52 --> Utf8 Class Initialized
INFO - 2023-04-28 02:27:52 --> URI Class Initialized
INFO - 2023-04-28 02:27:52 --> Router Class Initialized
INFO - 2023-04-28 02:27:52 --> Output Class Initialized
INFO - 2023-04-28 02:27:52 --> Security Class Initialized
DEBUG - 2023-04-28 02:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:27:52 --> Input Class Initialized
INFO - 2023-04-28 02:27:52 --> Language Class Initialized
INFO - 2023-04-28 02:27:52 --> Loader Class Initialized
INFO - 2023-04-28 02:27:52 --> Controller Class Initialized
DEBUG - 2023-04-28 02:27:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:27:52 --> Database Driver Class Initialized
INFO - 2023-04-28 02:27:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:27:52 --> Final output sent to browser
DEBUG - 2023-04-28 02:27:52 --> Total execution time: 0.0610
INFO - 2023-04-28 02:27:52 --> Config Class Initialized
INFO - 2023-04-28 02:27:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:27:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:27:52 --> Utf8 Class Initialized
INFO - 2023-04-28 02:27:52 --> URI Class Initialized
INFO - 2023-04-28 02:27:52 --> Router Class Initialized
INFO - 2023-04-28 02:27:52 --> Output Class Initialized
INFO - 2023-04-28 02:27:52 --> Security Class Initialized
DEBUG - 2023-04-28 02:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:27:52 --> Input Class Initialized
INFO - 2023-04-28 02:27:52 --> Language Class Initialized
INFO - 2023-04-28 02:27:52 --> Loader Class Initialized
INFO - 2023-04-28 02:27:52 --> Controller Class Initialized
DEBUG - 2023-04-28 02:27:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:27:52 --> Database Driver Class Initialized
INFO - 2023-04-28 02:27:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:27:53 --> Final output sent to browser
DEBUG - 2023-04-28 02:27:53 --> Total execution time: 0.0557
INFO - 2023-04-28 02:27:53 --> Config Class Initialized
INFO - 2023-04-28 02:27:53 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:27:53 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:27:53 --> Utf8 Class Initialized
INFO - 2023-04-28 02:27:53 --> URI Class Initialized
INFO - 2023-04-28 02:27:53 --> Router Class Initialized
INFO - 2023-04-28 02:27:53 --> Output Class Initialized
INFO - 2023-04-28 02:27:53 --> Security Class Initialized
DEBUG - 2023-04-28 02:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:27:53 --> Input Class Initialized
INFO - 2023-04-28 02:27:53 --> Language Class Initialized
INFO - 2023-04-28 02:27:53 --> Loader Class Initialized
INFO - 2023-04-28 02:27:53 --> Controller Class Initialized
DEBUG - 2023-04-28 02:27:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:27:53 --> Database Driver Class Initialized
INFO - 2023-04-28 02:27:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:27:53 --> Final output sent to browser
DEBUG - 2023-04-28 02:27:53 --> Total execution time: 0.0512
INFO - 2023-04-28 02:31:19 --> Config Class Initialized
INFO - 2023-04-28 02:31:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:19 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:19 --> URI Class Initialized
INFO - 2023-04-28 02:31:19 --> Router Class Initialized
INFO - 2023-04-28 02:31:19 --> Output Class Initialized
INFO - 2023-04-28 02:31:19 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:19 --> Input Class Initialized
INFO - 2023-04-28 02:31:19 --> Language Class Initialized
INFO - 2023-04-28 02:31:19 --> Loader Class Initialized
INFO - 2023-04-28 02:31:19 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:19 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:19 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:19 --> Total execution time: 0.0167
INFO - 2023-04-28 02:31:19 --> Config Class Initialized
INFO - 2023-04-28 02:31:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:19 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:19 --> URI Class Initialized
INFO - 2023-04-28 02:31:19 --> Router Class Initialized
INFO - 2023-04-28 02:31:19 --> Output Class Initialized
INFO - 2023-04-28 02:31:19 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:19 --> Input Class Initialized
INFO - 2023-04-28 02:31:19 --> Language Class Initialized
INFO - 2023-04-28 02:31:19 --> Loader Class Initialized
INFO - 2023-04-28 02:31:19 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:19 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:19 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:19 --> Model "Login_model" initialized
INFO - 2023-04-28 02:31:19 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:19 --> Total execution time: 0.0226
INFO - 2023-04-28 02:31:20 --> Config Class Initialized
INFO - 2023-04-28 02:31:20 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:20 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:20 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:20 --> URI Class Initialized
INFO - 2023-04-28 02:31:20 --> Router Class Initialized
INFO - 2023-04-28 02:31:20 --> Output Class Initialized
INFO - 2023-04-28 02:31:20 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:20 --> Input Class Initialized
INFO - 2023-04-28 02:31:20 --> Language Class Initialized
INFO - 2023-04-28 02:31:20 --> Loader Class Initialized
INFO - 2023-04-28 02:31:20 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:20 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:20 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:20 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:20 --> Total execution time: 0.0156
INFO - 2023-04-28 02:31:20 --> Config Class Initialized
INFO - 2023-04-28 02:31:20 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:20 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:20 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:20 --> URI Class Initialized
INFO - 2023-04-28 02:31:20 --> Router Class Initialized
INFO - 2023-04-28 02:31:20 --> Output Class Initialized
INFO - 2023-04-28 02:31:20 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:20 --> Input Class Initialized
INFO - 2023-04-28 02:31:20 --> Language Class Initialized
INFO - 2023-04-28 02:31:20 --> Loader Class Initialized
INFO - 2023-04-28 02:31:20 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:20 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:20 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:20 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:20 --> Total execution time: 0.0573
INFO - 2023-04-28 02:31:22 --> Config Class Initialized
INFO - 2023-04-28 02:31:22 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:22 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:22 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:22 --> URI Class Initialized
INFO - 2023-04-28 02:31:22 --> Router Class Initialized
INFO - 2023-04-28 02:31:22 --> Output Class Initialized
INFO - 2023-04-28 02:31:22 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:22 --> Input Class Initialized
INFO - 2023-04-28 02:31:22 --> Language Class Initialized
INFO - 2023-04-28 02:31:22 --> Loader Class Initialized
INFO - 2023-04-28 02:31:22 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:22 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:22 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:22 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:22 --> Model "Login_model" initialized
INFO - 2023-04-28 02:31:22 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:22 --> Total execution time: 0.0235
INFO - 2023-04-28 02:31:22 --> Config Class Initialized
INFO - 2023-04-28 02:31:22 --> Config Class Initialized
INFO - 2023-04-28 02:31:22 --> Hooks Class Initialized
INFO - 2023-04-28 02:31:22 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 02:31:22 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:22 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:22 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:22 --> URI Class Initialized
INFO - 2023-04-28 02:31:22 --> URI Class Initialized
INFO - 2023-04-28 02:31:22 --> Router Class Initialized
INFO - 2023-04-28 02:31:22 --> Output Class Initialized
INFO - 2023-04-28 02:31:22 --> Router Class Initialized
INFO - 2023-04-28 02:31:22 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:22 --> Output Class Initialized
INFO - 2023-04-28 02:31:22 --> Input Class Initialized
INFO - 2023-04-28 02:31:22 --> Security Class Initialized
INFO - 2023-04-28 02:31:22 --> Language Class Initialized
DEBUG - 2023-04-28 02:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:22 --> Input Class Initialized
INFO - 2023-04-28 02:31:22 --> Loader Class Initialized
INFO - 2023-04-28 02:31:22 --> Language Class Initialized
INFO - 2023-04-28 02:31:22 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:22 --> Loader Class Initialized
INFO - 2023-04-28 02:31:22 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:22 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:22 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:22 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:22 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:22 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:22 --> Total execution time: 0.0154
INFO - 2023-04-28 02:31:22 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:22 --> Total execution time: 0.0160
INFO - 2023-04-28 02:31:22 --> Config Class Initialized
INFO - 2023-04-28 02:31:22 --> Config Class Initialized
INFO - 2023-04-28 02:31:22 --> Hooks Class Initialized
INFO - 2023-04-28 02:31:22 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 02:31:22 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:22 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:22 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:22 --> URI Class Initialized
INFO - 2023-04-28 02:31:22 --> URI Class Initialized
INFO - 2023-04-28 02:31:22 --> Router Class Initialized
INFO - 2023-04-28 02:31:22 --> Router Class Initialized
INFO - 2023-04-28 02:31:22 --> Output Class Initialized
INFO - 2023-04-28 02:31:22 --> Output Class Initialized
INFO - 2023-04-28 02:31:22 --> Security Class Initialized
INFO - 2023-04-28 02:31:22 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 02:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:22 --> Input Class Initialized
INFO - 2023-04-28 02:31:22 --> Input Class Initialized
INFO - 2023-04-28 02:31:22 --> Language Class Initialized
INFO - 2023-04-28 02:31:22 --> Language Class Initialized
INFO - 2023-04-28 02:31:22 --> Loader Class Initialized
INFO - 2023-04-28 02:31:22 --> Loader Class Initialized
INFO - 2023-04-28 02:31:22 --> Controller Class Initialized
INFO - 2023-04-28 02:31:22 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 02:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:22 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:22 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:22 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:22 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:22 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:22 --> Total execution time: 0.0128
INFO - 2023-04-28 02:31:22 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:22 --> Total execution time: 0.0150
INFO - 2023-04-28 02:31:26 --> Config Class Initialized
INFO - 2023-04-28 02:31:26 --> Config Class Initialized
INFO - 2023-04-28 02:31:26 --> Hooks Class Initialized
INFO - 2023-04-28 02:31:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 02:31:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:26 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:26 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:26 --> URI Class Initialized
INFO - 2023-04-28 02:31:26 --> URI Class Initialized
INFO - 2023-04-28 02:31:26 --> Router Class Initialized
INFO - 2023-04-28 02:31:26 --> Router Class Initialized
INFO - 2023-04-28 02:31:26 --> Output Class Initialized
INFO - 2023-04-28 02:31:26 --> Output Class Initialized
INFO - 2023-04-28 02:31:26 --> Security Class Initialized
INFO - 2023-04-28 02:31:26 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 02:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:26 --> Input Class Initialized
INFO - 2023-04-28 02:31:26 --> Input Class Initialized
INFO - 2023-04-28 02:31:26 --> Language Class Initialized
INFO - 2023-04-28 02:31:26 --> Language Class Initialized
INFO - 2023-04-28 02:31:26 --> Loader Class Initialized
INFO - 2023-04-28 02:31:26 --> Loader Class Initialized
INFO - 2023-04-28 02:31:26 --> Controller Class Initialized
INFO - 2023-04-28 02:31:26 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 02:31:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:26 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:26 --> Total execution time: 0.0043
INFO - 2023-04-28 02:31:26 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:26 --> Config Class Initialized
INFO - 2023-04-28 02:31:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:26 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:26 --> URI Class Initialized
INFO - 2023-04-28 02:31:26 --> Router Class Initialized
INFO - 2023-04-28 02:31:26 --> Output Class Initialized
INFO - 2023-04-28 02:31:26 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:26 --> Input Class Initialized
INFO - 2023-04-28 02:31:26 --> Language Class Initialized
INFO - 2023-04-28 02:31:26 --> Loader Class Initialized
INFO - 2023-04-28 02:31:26 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:26 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:26 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:26 --> Total execution time: 0.0504
INFO - 2023-04-28 02:31:26 --> Config Class Initialized
INFO - 2023-04-28 02:31:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:26 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:26 --> URI Class Initialized
INFO - 2023-04-28 02:31:26 --> Router Class Initialized
INFO - 2023-04-28 02:31:26 --> Output Class Initialized
INFO - 2023-04-28 02:31:26 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:26 --> Input Class Initialized
INFO - 2023-04-28 02:31:26 --> Language Class Initialized
INFO - 2023-04-28 02:31:26 --> Loader Class Initialized
INFO - 2023-04-28 02:31:26 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:26 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:26 --> Model "Login_model" initialized
INFO - 2023-04-28 02:31:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:26 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:26 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:26 --> Total execution time: 0.0134
INFO - 2023-04-28 02:31:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:26 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:26 --> Total execution time: 0.0659
INFO - 2023-04-28 02:31:28 --> Config Class Initialized
INFO - 2023-04-28 02:31:28 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:28 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:28 --> URI Class Initialized
INFO - 2023-04-28 02:31:28 --> Router Class Initialized
INFO - 2023-04-28 02:31:28 --> Output Class Initialized
INFO - 2023-04-28 02:31:28 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:28 --> Input Class Initialized
INFO - 2023-04-28 02:31:28 --> Language Class Initialized
INFO - 2023-04-28 02:31:28 --> Loader Class Initialized
INFO - 2023-04-28 02:31:28 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:28 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:28 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:28 --> Total execution time: 0.0566
INFO - 2023-04-28 02:31:28 --> Config Class Initialized
INFO - 2023-04-28 02:31:28 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:28 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:28 --> URI Class Initialized
INFO - 2023-04-28 02:31:28 --> Router Class Initialized
INFO - 2023-04-28 02:31:28 --> Output Class Initialized
INFO - 2023-04-28 02:31:28 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:28 --> Input Class Initialized
INFO - 2023-04-28 02:31:28 --> Language Class Initialized
INFO - 2023-04-28 02:31:28 --> Loader Class Initialized
INFO - 2023-04-28 02:31:28 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:28 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:28 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:28 --> Total execution time: 0.0120
INFO - 2023-04-28 02:31:31 --> Config Class Initialized
INFO - 2023-04-28 02:31:31 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:31 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:31 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:31 --> URI Class Initialized
INFO - 2023-04-28 02:31:31 --> Router Class Initialized
INFO - 2023-04-28 02:31:31 --> Output Class Initialized
INFO - 2023-04-28 02:31:31 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:31 --> Input Class Initialized
INFO - 2023-04-28 02:31:31 --> Language Class Initialized
INFO - 2023-04-28 02:31:31 --> Loader Class Initialized
INFO - 2023-04-28 02:31:31 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:31 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:31 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:31 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:31 --> Total execution time: 0.0204
INFO - 2023-04-28 02:31:31 --> Config Class Initialized
INFO - 2023-04-28 02:31:31 --> Hooks Class Initialized
DEBUG - 2023-04-28 02:31:31 --> UTF-8 Support Enabled
INFO - 2023-04-28 02:31:31 --> Utf8 Class Initialized
INFO - 2023-04-28 02:31:31 --> URI Class Initialized
INFO - 2023-04-28 02:31:31 --> Router Class Initialized
INFO - 2023-04-28 02:31:31 --> Output Class Initialized
INFO - 2023-04-28 02:31:31 --> Security Class Initialized
DEBUG - 2023-04-28 02:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 02:31:31 --> Input Class Initialized
INFO - 2023-04-28 02:31:31 --> Language Class Initialized
INFO - 2023-04-28 02:31:31 --> Loader Class Initialized
INFO - 2023-04-28 02:31:31 --> Controller Class Initialized
DEBUG - 2023-04-28 02:31:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 02:31:31 --> Database Driver Class Initialized
INFO - 2023-04-28 02:31:31 --> Model "Cluster_model" initialized
INFO - 2023-04-28 02:31:31 --> Final output sent to browser
DEBUG - 2023-04-28 02:31:31 --> Total execution time: 0.0108
INFO - 2023-04-28 03:05:30 --> Config Class Initialized
INFO - 2023-04-28 03:05:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:05:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:05:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:05:30 --> URI Class Initialized
INFO - 2023-04-28 03:05:30 --> Router Class Initialized
INFO - 2023-04-28 03:05:30 --> Output Class Initialized
INFO - 2023-04-28 03:05:30 --> Security Class Initialized
DEBUG - 2023-04-28 03:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:05:30 --> Input Class Initialized
INFO - 2023-04-28 03:05:30 --> Language Class Initialized
INFO - 2023-04-28 03:05:30 --> Loader Class Initialized
INFO - 2023-04-28 03:05:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:05:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:05:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:05:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:05:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:05:30 --> Total execution time: 0.0138
INFO - 2023-04-28 03:05:30 --> Config Class Initialized
INFO - 2023-04-28 03:05:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:05:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:05:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:05:30 --> URI Class Initialized
INFO - 2023-04-28 03:05:30 --> Router Class Initialized
INFO - 2023-04-28 03:05:30 --> Output Class Initialized
INFO - 2023-04-28 03:05:30 --> Security Class Initialized
DEBUG - 2023-04-28 03:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:05:30 --> Input Class Initialized
INFO - 2023-04-28 03:05:30 --> Language Class Initialized
INFO - 2023-04-28 03:05:30 --> Loader Class Initialized
INFO - 2023-04-28 03:05:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:05:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:05:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:05:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:05:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:05:30 --> Total execution time: 0.0520
INFO - 2023-04-28 03:05:30 --> Config Class Initialized
INFO - 2023-04-28 03:05:30 --> Hooks Class Initialized
INFO - 2023-04-28 03:05:30 --> Config Class Initialized
DEBUG - 2023-04-28 03:05:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:05:30 --> Hooks Class Initialized
INFO - 2023-04-28 03:05:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:05:30 --> URI Class Initialized
DEBUG - 2023-04-28 03:05:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:05:30 --> Router Class Initialized
INFO - 2023-04-28 03:05:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:05:30 --> Output Class Initialized
INFO - 2023-04-28 03:05:30 --> URI Class Initialized
INFO - 2023-04-28 03:05:30 --> Security Class Initialized
DEBUG - 2023-04-28 03:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:05:30 --> Router Class Initialized
INFO - 2023-04-28 03:05:30 --> Input Class Initialized
INFO - 2023-04-28 03:05:30 --> Output Class Initialized
INFO - 2023-04-28 03:05:30 --> Language Class Initialized
INFO - 2023-04-28 03:05:30 --> Security Class Initialized
INFO - 2023-04-28 03:05:30 --> Loader Class Initialized
DEBUG - 2023-04-28 03:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:05:30 --> Controller Class Initialized
INFO - 2023-04-28 03:05:30 --> Input Class Initialized
DEBUG - 2023-04-28 03:05:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:05:30 --> Language Class Initialized
INFO - 2023-04-28 03:05:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:05:30 --> Loader Class Initialized
INFO - 2023-04-28 03:05:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:05:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:05:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:05:30 --> Total execution time: 0.0023
INFO - 2023-04-28 03:05:30 --> Config Class Initialized
INFO - 2023-04-28 03:05:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:05:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:05:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:05:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:05:30 --> URI Class Initialized
INFO - 2023-04-28 03:05:30 --> Router Class Initialized
INFO - 2023-04-28 03:05:30 --> Output Class Initialized
INFO - 2023-04-28 03:05:30 --> Security Class Initialized
DEBUG - 2023-04-28 03:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:05:30 --> Input Class Initialized
INFO - 2023-04-28 03:05:30 --> Language Class Initialized
INFO - 2023-04-28 03:05:30 --> Loader Class Initialized
INFO - 2023-04-28 03:05:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:05:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:05:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:05:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:05:30 --> Total execution time: 0.0478
INFO - 2023-04-28 03:05:30 --> Config Class Initialized
INFO - 2023-04-28 03:05:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:05:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:05:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:05:30 --> URI Class Initialized
INFO - 2023-04-28 03:05:30 --> Router Class Initialized
INFO - 2023-04-28 03:05:30 --> Output Class Initialized
INFO - 2023-04-28 03:05:30 --> Security Class Initialized
DEBUG - 2023-04-28 03:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:05:30 --> Input Class Initialized
INFO - 2023-04-28 03:05:30 --> Language Class Initialized
INFO - 2023-04-28 03:05:30 --> Loader Class Initialized
INFO - 2023-04-28 03:05:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:05:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:05:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:05:30 --> Model "Login_model" initialized
INFO - 2023-04-28 03:05:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:05:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:05:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:05:30 --> Total execution time: 0.0135
INFO - 2023-04-28 03:05:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:05:31 --> Final output sent to browser
DEBUG - 2023-04-28 03:05:31 --> Total execution time: 0.1016
INFO - 2023-04-28 03:05:34 --> Config Class Initialized
INFO - 2023-04-28 03:05:34 --> Config Class Initialized
INFO - 2023-04-28 03:05:34 --> Hooks Class Initialized
INFO - 2023-04-28 03:05:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:05:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:05:34 --> Utf8 Class Initialized
DEBUG - 2023-04-28 03:05:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:05:34 --> Utf8 Class Initialized
INFO - 2023-04-28 03:05:34 --> URI Class Initialized
INFO - 2023-04-28 03:05:34 --> URI Class Initialized
INFO - 2023-04-28 03:05:34 --> Router Class Initialized
INFO - 2023-04-28 03:05:34 --> Router Class Initialized
INFO - 2023-04-28 03:05:34 --> Output Class Initialized
INFO - 2023-04-28 03:05:34 --> Output Class Initialized
INFO - 2023-04-28 03:05:34 --> Security Class Initialized
INFO - 2023-04-28 03:05:34 --> Security Class Initialized
DEBUG - 2023-04-28 03:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:05:34 --> Input Class Initialized
INFO - 2023-04-28 03:05:34 --> Input Class Initialized
INFO - 2023-04-28 03:05:34 --> Language Class Initialized
INFO - 2023-04-28 03:05:34 --> Language Class Initialized
INFO - 2023-04-28 03:05:34 --> Loader Class Initialized
INFO - 2023-04-28 03:05:34 --> Loader Class Initialized
INFO - 2023-04-28 03:05:34 --> Controller Class Initialized
INFO - 2023-04-28 03:05:34 --> Controller Class Initialized
DEBUG - 2023-04-28 03:05:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:05:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:05:34 --> Database Driver Class Initialized
INFO - 2023-04-28 03:05:34 --> Database Driver Class Initialized
INFO - 2023-04-28 03:05:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:05:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:05:34 --> Final output sent to browser
DEBUG - 2023-04-28 03:05:34 --> Total execution time: 0.0471
INFO - 2023-04-28 03:05:34 --> Final output sent to browser
DEBUG - 2023-04-28 03:05:34 --> Total execution time: 0.0476
INFO - 2023-04-28 03:05:34 --> Config Class Initialized
INFO - 2023-04-28 03:05:34 --> Config Class Initialized
INFO - 2023-04-28 03:05:34 --> Hooks Class Initialized
INFO - 2023-04-28 03:05:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:05:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:05:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:05:34 --> Utf8 Class Initialized
INFO - 2023-04-28 03:05:34 --> Utf8 Class Initialized
INFO - 2023-04-28 03:05:34 --> URI Class Initialized
INFO - 2023-04-28 03:05:34 --> URI Class Initialized
INFO - 2023-04-28 03:05:34 --> Router Class Initialized
INFO - 2023-04-28 03:05:34 --> Router Class Initialized
INFO - 2023-04-28 03:05:34 --> Output Class Initialized
INFO - 2023-04-28 03:05:34 --> Output Class Initialized
INFO - 2023-04-28 03:05:34 --> Security Class Initialized
INFO - 2023-04-28 03:05:34 --> Security Class Initialized
DEBUG - 2023-04-28 03:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:05:34 --> Input Class Initialized
INFO - 2023-04-28 03:05:34 --> Input Class Initialized
INFO - 2023-04-28 03:05:34 --> Language Class Initialized
INFO - 2023-04-28 03:05:34 --> Language Class Initialized
INFO - 2023-04-28 03:05:34 --> Loader Class Initialized
INFO - 2023-04-28 03:05:34 --> Loader Class Initialized
INFO - 2023-04-28 03:05:34 --> Controller Class Initialized
INFO - 2023-04-28 03:05:34 --> Controller Class Initialized
DEBUG - 2023-04-28 03:05:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:05:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:05:34 --> Database Driver Class Initialized
INFO - 2023-04-28 03:05:34 --> Database Driver Class Initialized
INFO - 2023-04-28 03:05:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:05:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:05:34 --> Final output sent to browser
DEBUG - 2023-04-28 03:05:34 --> Total execution time: 0.0563
INFO - 2023-04-28 03:05:34 --> Final output sent to browser
DEBUG - 2023-04-28 03:05:34 --> Total execution time: 0.0584
INFO - 2023-04-28 03:22:53 --> Config Class Initialized
INFO - 2023-04-28 03:22:53 --> Config Class Initialized
INFO - 2023-04-28 03:22:53 --> Hooks Class Initialized
INFO - 2023-04-28 03:22:53 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:22:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:22:53 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:22:53 --> Utf8 Class Initialized
INFO - 2023-04-28 03:22:53 --> Utf8 Class Initialized
INFO - 2023-04-28 03:22:53 --> URI Class Initialized
INFO - 2023-04-28 03:22:53 --> URI Class Initialized
INFO - 2023-04-28 03:22:53 --> Router Class Initialized
INFO - 2023-04-28 03:22:53 --> Router Class Initialized
INFO - 2023-04-28 03:22:53 --> Output Class Initialized
INFO - 2023-04-28 03:22:53 --> Output Class Initialized
INFO - 2023-04-28 03:22:53 --> Security Class Initialized
INFO - 2023-04-28 03:22:53 --> Security Class Initialized
DEBUG - 2023-04-28 03:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:22:53 --> Input Class Initialized
INFO - 2023-04-28 03:22:53 --> Input Class Initialized
INFO - 2023-04-28 03:22:53 --> Language Class Initialized
INFO - 2023-04-28 03:22:53 --> Language Class Initialized
INFO - 2023-04-28 03:22:53 --> Loader Class Initialized
INFO - 2023-04-28 03:22:53 --> Loader Class Initialized
INFO - 2023-04-28 03:22:53 --> Controller Class Initialized
INFO - 2023-04-28 03:22:53 --> Controller Class Initialized
DEBUG - 2023-04-28 03:22:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:22:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:22:53 --> Final output sent to browser
DEBUG - 2023-04-28 03:22:53 --> Total execution time: 0.0050
INFO - 2023-04-28 03:22:53 --> Database Driver Class Initialized
INFO - 2023-04-28 03:22:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:22:53 --> Config Class Initialized
INFO - 2023-04-28 03:22:53 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:22:53 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:22:53 --> Utf8 Class Initialized
INFO - 2023-04-28 03:22:53 --> URI Class Initialized
INFO - 2023-04-28 03:22:53 --> Router Class Initialized
INFO - 2023-04-28 03:22:53 --> Output Class Initialized
INFO - 2023-04-28 03:22:53 --> Security Class Initialized
DEBUG - 2023-04-28 03:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:22:53 --> Input Class Initialized
INFO - 2023-04-28 03:22:53 --> Language Class Initialized
INFO - 2023-04-28 03:22:53 --> Loader Class Initialized
INFO - 2023-04-28 03:22:53 --> Controller Class Initialized
DEBUG - 2023-04-28 03:22:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:22:53 --> Database Driver Class Initialized
INFO - 2023-04-28 03:22:53 --> Final output sent to browser
DEBUG - 2023-04-28 03:22:53 --> Total execution time: 0.0495
INFO - 2023-04-28 03:22:53 --> Config Class Initialized
INFO - 2023-04-28 03:22:53 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:22:53 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:22:53 --> Utf8 Class Initialized
INFO - 2023-04-28 03:22:53 --> URI Class Initialized
INFO - 2023-04-28 03:22:53 --> Router Class Initialized
INFO - 2023-04-28 03:22:53 --> Output Class Initialized
INFO - 2023-04-28 03:22:53 --> Security Class Initialized
DEBUG - 2023-04-28 03:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:22:53 --> Input Class Initialized
INFO - 2023-04-28 03:22:53 --> Language Class Initialized
INFO - 2023-04-28 03:22:53 --> Loader Class Initialized
INFO - 2023-04-28 03:22:53 --> Controller Class Initialized
DEBUG - 2023-04-28 03:22:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:22:53 --> Database Driver Class Initialized
INFO - 2023-04-28 03:22:53 --> Model "Login_model" initialized
INFO - 2023-04-28 03:22:53 --> Database Driver Class Initialized
INFO - 2023-04-28 03:22:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:22:53 --> Final output sent to browser
DEBUG - 2023-04-28 03:22:53 --> Total execution time: 0.0155
INFO - 2023-04-28 03:22:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:22:53 --> Final output sent to browser
DEBUG - 2023-04-28 03:22:53 --> Total execution time: 0.0245
INFO - 2023-04-28 03:22:56 --> Config Class Initialized
INFO - 2023-04-28 03:22:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:22:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:22:56 --> Utf8 Class Initialized
INFO - 2023-04-28 03:22:56 --> URI Class Initialized
INFO - 2023-04-28 03:22:56 --> Router Class Initialized
INFO - 2023-04-28 03:22:56 --> Output Class Initialized
INFO - 2023-04-28 03:22:56 --> Security Class Initialized
DEBUG - 2023-04-28 03:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:22:56 --> Input Class Initialized
INFO - 2023-04-28 03:22:56 --> Language Class Initialized
INFO - 2023-04-28 03:22:56 --> Loader Class Initialized
INFO - 2023-04-28 03:22:56 --> Controller Class Initialized
DEBUG - 2023-04-28 03:22:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:22:56 --> Database Driver Class Initialized
INFO - 2023-04-28 03:22:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:22:56 --> Final output sent to browser
DEBUG - 2023-04-28 03:22:56 --> Total execution time: 0.0141
INFO - 2023-04-28 03:22:56 --> Config Class Initialized
INFO - 2023-04-28 03:22:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:22:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:22:56 --> Utf8 Class Initialized
INFO - 2023-04-28 03:22:56 --> URI Class Initialized
INFO - 2023-04-28 03:22:56 --> Router Class Initialized
INFO - 2023-04-28 03:22:56 --> Output Class Initialized
INFO - 2023-04-28 03:22:56 --> Security Class Initialized
DEBUG - 2023-04-28 03:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:22:56 --> Input Class Initialized
INFO - 2023-04-28 03:22:56 --> Language Class Initialized
INFO - 2023-04-28 03:22:56 --> Loader Class Initialized
INFO - 2023-04-28 03:22:56 --> Controller Class Initialized
DEBUG - 2023-04-28 03:22:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:22:56 --> Database Driver Class Initialized
INFO - 2023-04-28 03:22:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:22:56 --> Final output sent to browser
DEBUG - 2023-04-28 03:22:56 --> Total execution time: 0.0925
INFO - 2023-04-28 03:22:58 --> Config Class Initialized
INFO - 2023-04-28 03:22:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:22:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:22:58 --> Utf8 Class Initialized
INFO - 2023-04-28 03:22:58 --> URI Class Initialized
INFO - 2023-04-28 03:22:58 --> Router Class Initialized
INFO - 2023-04-28 03:22:58 --> Output Class Initialized
INFO - 2023-04-28 03:22:58 --> Security Class Initialized
DEBUG - 2023-04-28 03:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:22:58 --> Input Class Initialized
INFO - 2023-04-28 03:22:58 --> Language Class Initialized
INFO - 2023-04-28 03:22:58 --> Loader Class Initialized
INFO - 2023-04-28 03:22:58 --> Controller Class Initialized
DEBUG - 2023-04-28 03:22:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:22:58 --> Database Driver Class Initialized
INFO - 2023-04-28 03:22:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:22:58 --> Final output sent to browser
DEBUG - 2023-04-28 03:22:58 --> Total execution time: 0.0324
INFO - 2023-04-28 03:22:58 --> Config Class Initialized
INFO - 2023-04-28 03:22:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:22:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:22:58 --> Utf8 Class Initialized
INFO - 2023-04-28 03:22:58 --> URI Class Initialized
INFO - 2023-04-28 03:22:58 --> Router Class Initialized
INFO - 2023-04-28 03:22:58 --> Output Class Initialized
INFO - 2023-04-28 03:22:58 --> Security Class Initialized
DEBUG - 2023-04-28 03:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:22:58 --> Input Class Initialized
INFO - 2023-04-28 03:22:58 --> Language Class Initialized
INFO - 2023-04-28 03:22:58 --> Loader Class Initialized
INFO - 2023-04-28 03:22:58 --> Controller Class Initialized
DEBUG - 2023-04-28 03:22:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:22:58 --> Database Driver Class Initialized
INFO - 2023-04-28 03:22:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:22:58 --> Final output sent to browser
DEBUG - 2023-04-28 03:22:58 --> Total execution time: 0.0577
INFO - 2023-04-28 03:23:01 --> Config Class Initialized
INFO - 2023-04-28 03:23:01 --> Config Class Initialized
INFO - 2023-04-28 03:23:01 --> Hooks Class Initialized
INFO - 2023-04-28 03:23:01 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:23:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:23:01 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:01 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:01 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:01 --> URI Class Initialized
INFO - 2023-04-28 03:23:01 --> URI Class Initialized
INFO - 2023-04-28 03:23:01 --> Router Class Initialized
INFO - 2023-04-28 03:23:01 --> Router Class Initialized
INFO - 2023-04-28 03:23:01 --> Output Class Initialized
INFO - 2023-04-28 03:23:01 --> Output Class Initialized
INFO - 2023-04-28 03:23:01 --> Security Class Initialized
INFO - 2023-04-28 03:23:01 --> Security Class Initialized
DEBUG - 2023-04-28 03:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:01 --> Input Class Initialized
INFO - 2023-04-28 03:23:01 --> Input Class Initialized
INFO - 2023-04-28 03:23:01 --> Language Class Initialized
INFO - 2023-04-28 03:23:01 --> Language Class Initialized
INFO - 2023-04-28 03:23:01 --> Loader Class Initialized
INFO - 2023-04-28 03:23:01 --> Loader Class Initialized
INFO - 2023-04-28 03:23:01 --> Controller Class Initialized
INFO - 2023-04-28 03:23:01 --> Controller Class Initialized
DEBUG - 2023-04-28 03:23:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:23:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:01 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:01 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:01 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:01 --> Total execution time: 0.0203
INFO - 2023-04-28 03:23:01 --> Final output sent to browser
INFO - 2023-04-28 03:23:01 --> Config Class Initialized
DEBUG - 2023-04-28 03:23:01 --> Total execution time: 0.0220
INFO - 2023-04-28 03:23:01 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:23:01 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:01 --> Config Class Initialized
INFO - 2023-04-28 03:23:01 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:01 --> Hooks Class Initialized
INFO - 2023-04-28 03:23:01 --> URI Class Initialized
DEBUG - 2023-04-28 03:23:01 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:01 --> Router Class Initialized
INFO - 2023-04-28 03:23:01 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:01 --> Output Class Initialized
INFO - 2023-04-28 03:23:01 --> URI Class Initialized
INFO - 2023-04-28 03:23:01 --> Security Class Initialized
INFO - 2023-04-28 03:23:01 --> Router Class Initialized
DEBUG - 2023-04-28 03:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:01 --> Input Class Initialized
INFO - 2023-04-28 03:23:01 --> Output Class Initialized
INFO - 2023-04-28 03:23:01 --> Language Class Initialized
INFO - 2023-04-28 03:23:01 --> Security Class Initialized
INFO - 2023-04-28 03:23:01 --> Loader Class Initialized
DEBUG - 2023-04-28 03:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:01 --> Controller Class Initialized
INFO - 2023-04-28 03:23:01 --> Input Class Initialized
DEBUG - 2023-04-28 03:23:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:01 --> Language Class Initialized
INFO - 2023-04-28 03:23:01 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:01 --> Loader Class Initialized
INFO - 2023-04-28 03:23:01 --> Controller Class Initialized
DEBUG - 2023-04-28 03:23:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:01 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:01 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:01 --> Total execution time: 0.0563
INFO - 2023-04-28 03:23:01 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:01 --> Total execution time: 0.0158
INFO - 2023-04-28 03:23:36 --> Config Class Initialized
INFO - 2023-04-28 03:23:36 --> Config Class Initialized
INFO - 2023-04-28 03:23:36 --> Hooks Class Initialized
INFO - 2023-04-28 03:23:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:23:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:23:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:36 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:36 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:36 --> URI Class Initialized
INFO - 2023-04-28 03:23:36 --> URI Class Initialized
INFO - 2023-04-28 03:23:36 --> Router Class Initialized
INFO - 2023-04-28 03:23:36 --> Router Class Initialized
INFO - 2023-04-28 03:23:36 --> Output Class Initialized
INFO - 2023-04-28 03:23:36 --> Output Class Initialized
INFO - 2023-04-28 03:23:36 --> Security Class Initialized
INFO - 2023-04-28 03:23:36 --> Security Class Initialized
DEBUG - 2023-04-28 03:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:36 --> Input Class Initialized
INFO - 2023-04-28 03:23:36 --> Input Class Initialized
INFO - 2023-04-28 03:23:36 --> Language Class Initialized
INFO - 2023-04-28 03:23:36 --> Language Class Initialized
INFO - 2023-04-28 03:23:36 --> Loader Class Initialized
INFO - 2023-04-28 03:23:36 --> Loader Class Initialized
INFO - 2023-04-28 03:23:36 --> Controller Class Initialized
INFO - 2023-04-28 03:23:36 --> Controller Class Initialized
DEBUG - 2023-04-28 03:23:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:23:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:36 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:36 --> Total execution time: 0.0044
INFO - 2023-04-28 03:23:36 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:36 --> Config Class Initialized
INFO - 2023-04-28 03:23:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:23:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:36 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:36 --> URI Class Initialized
INFO - 2023-04-28 03:23:36 --> Router Class Initialized
INFO - 2023-04-28 03:23:36 --> Output Class Initialized
INFO - 2023-04-28 03:23:36 --> Security Class Initialized
DEBUG - 2023-04-28 03:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:36 --> Input Class Initialized
INFO - 2023-04-28 03:23:36 --> Language Class Initialized
INFO - 2023-04-28 03:23:36 --> Loader Class Initialized
INFO - 2023-04-28 03:23:36 --> Controller Class Initialized
DEBUG - 2023-04-28 03:23:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:36 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:36 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:36 --> Total execution time: 0.0266
INFO - 2023-04-28 03:23:36 --> Model "Login_model" initialized
INFO - 2023-04-28 03:23:36 --> Config Class Initialized
INFO - 2023-04-28 03:23:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:23:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:36 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:36 --> URI Class Initialized
INFO - 2023-04-28 03:23:36 --> Router Class Initialized
INFO - 2023-04-28 03:23:36 --> Output Class Initialized
INFO - 2023-04-28 03:23:36 --> Security Class Initialized
DEBUG - 2023-04-28 03:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:36 --> Input Class Initialized
INFO - 2023-04-28 03:23:36 --> Language Class Initialized
INFO - 2023-04-28 03:23:36 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:36 --> Loader Class Initialized
INFO - 2023-04-28 03:23:36 --> Controller Class Initialized
DEBUG - 2023-04-28 03:23:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:36 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:36 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:36 --> Total execution time: 0.0436
INFO - 2023-04-28 03:23:36 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:36 --> Total execution time: 0.0257
INFO - 2023-04-28 03:23:38 --> Config Class Initialized
INFO - 2023-04-28 03:23:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:23:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:38 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:38 --> URI Class Initialized
INFO - 2023-04-28 03:23:38 --> Router Class Initialized
INFO - 2023-04-28 03:23:38 --> Output Class Initialized
INFO - 2023-04-28 03:23:38 --> Security Class Initialized
DEBUG - 2023-04-28 03:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:38 --> Input Class Initialized
INFO - 2023-04-28 03:23:38 --> Language Class Initialized
INFO - 2023-04-28 03:23:38 --> Loader Class Initialized
INFO - 2023-04-28 03:23:38 --> Controller Class Initialized
DEBUG - 2023-04-28 03:23:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:38 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:38 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:38 --> Total execution time: 0.0187
INFO - 2023-04-28 03:23:38 --> Config Class Initialized
INFO - 2023-04-28 03:23:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:23:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:38 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:38 --> URI Class Initialized
INFO - 2023-04-28 03:23:38 --> Router Class Initialized
INFO - 2023-04-28 03:23:38 --> Output Class Initialized
INFO - 2023-04-28 03:23:38 --> Security Class Initialized
DEBUG - 2023-04-28 03:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:38 --> Input Class Initialized
INFO - 2023-04-28 03:23:38 --> Language Class Initialized
INFO - 2023-04-28 03:23:38 --> Loader Class Initialized
INFO - 2023-04-28 03:23:38 --> Controller Class Initialized
DEBUG - 2023-04-28 03:23:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:38 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:38 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:38 --> Total execution time: 0.0156
INFO - 2023-04-28 03:23:40 --> Config Class Initialized
INFO - 2023-04-28 03:23:40 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:23:40 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:40 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:40 --> URI Class Initialized
INFO - 2023-04-28 03:23:40 --> Router Class Initialized
INFO - 2023-04-28 03:23:40 --> Output Class Initialized
INFO - 2023-04-28 03:23:40 --> Security Class Initialized
DEBUG - 2023-04-28 03:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:40 --> Input Class Initialized
INFO - 2023-04-28 03:23:40 --> Language Class Initialized
INFO - 2023-04-28 03:23:40 --> Loader Class Initialized
INFO - 2023-04-28 03:23:40 --> Controller Class Initialized
DEBUG - 2023-04-28 03:23:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:40 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:40 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:40 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:40 --> Total execution time: 0.0644
INFO - 2023-04-28 03:23:40 --> Config Class Initialized
INFO - 2023-04-28 03:23:40 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:23:40 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:40 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:40 --> URI Class Initialized
INFO - 2023-04-28 03:23:40 --> Router Class Initialized
INFO - 2023-04-28 03:23:40 --> Output Class Initialized
INFO - 2023-04-28 03:23:40 --> Security Class Initialized
DEBUG - 2023-04-28 03:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:40 --> Input Class Initialized
INFO - 2023-04-28 03:23:40 --> Language Class Initialized
INFO - 2023-04-28 03:23:40 --> Loader Class Initialized
INFO - 2023-04-28 03:23:40 --> Controller Class Initialized
DEBUG - 2023-04-28 03:23:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:40 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:40 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:40 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:40 --> Total execution time: 0.0779
INFO - 2023-04-28 03:23:43 --> Config Class Initialized
INFO - 2023-04-28 03:23:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:23:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:43 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:43 --> URI Class Initialized
INFO - 2023-04-28 03:23:43 --> Router Class Initialized
INFO - 2023-04-28 03:23:43 --> Output Class Initialized
INFO - 2023-04-28 03:23:43 --> Security Class Initialized
DEBUG - 2023-04-28 03:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:43 --> Input Class Initialized
INFO - 2023-04-28 03:23:43 --> Language Class Initialized
INFO - 2023-04-28 03:23:43 --> Loader Class Initialized
INFO - 2023-04-28 03:23:43 --> Controller Class Initialized
DEBUG - 2023-04-28 03:23:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:43 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:43 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:43 --> Total execution time: 0.0259
INFO - 2023-04-28 03:23:43 --> Config Class Initialized
INFO - 2023-04-28 03:23:43 --> Config Class Initialized
INFO - 2023-04-28 03:23:43 --> Hooks Class Initialized
INFO - 2023-04-28 03:23:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:23:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:43 --> Utf8 Class Initialized
DEBUG - 2023-04-28 03:23:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:43 --> URI Class Initialized
INFO - 2023-04-28 03:23:43 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:43 --> Router Class Initialized
INFO - 2023-04-28 03:23:43 --> URI Class Initialized
INFO - 2023-04-28 03:23:43 --> Output Class Initialized
INFO - 2023-04-28 03:23:43 --> Router Class Initialized
INFO - 2023-04-28 03:23:43 --> Security Class Initialized
INFO - 2023-04-28 03:23:43 --> Output Class Initialized
DEBUG - 2023-04-28 03:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:43 --> Security Class Initialized
INFO - 2023-04-28 03:23:43 --> Input Class Initialized
DEBUG - 2023-04-28 03:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:43 --> Language Class Initialized
INFO - 2023-04-28 03:23:43 --> Input Class Initialized
INFO - 2023-04-28 03:23:43 --> Language Class Initialized
INFO - 2023-04-28 03:23:43 --> Loader Class Initialized
INFO - 2023-04-28 03:23:43 --> Loader Class Initialized
INFO - 2023-04-28 03:23:43 --> Controller Class Initialized
INFO - 2023-04-28 03:23:43 --> Controller Class Initialized
DEBUG - 2023-04-28 03:23:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:23:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:43 --> Final output sent to browser
INFO - 2023-04-28 03:23:43 --> Database Driver Class Initialized
DEBUG - 2023-04-28 03:23:43 --> Total execution time: 0.0049
INFO - 2023-04-28 03:23:43 --> Config Class Initialized
INFO - 2023-04-28 03:23:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:23:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:43 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:43 --> URI Class Initialized
INFO - 2023-04-28 03:23:43 --> Router Class Initialized
INFO - 2023-04-28 03:23:43 --> Output Class Initialized
INFO - 2023-04-28 03:23:43 --> Security Class Initialized
DEBUG - 2023-04-28 03:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:43 --> Input Class Initialized
INFO - 2023-04-28 03:23:43 --> Language Class Initialized
INFO - 2023-04-28 03:23:43 --> Loader Class Initialized
INFO - 2023-04-28 03:23:43 --> Controller Class Initialized
DEBUG - 2023-04-28 03:23:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:43 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:43 --> Model "Login_model" initialized
INFO - 2023-04-28 03:23:43 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:43 --> Total execution time: 0.0173
INFO - 2023-04-28 03:23:43 --> Config Class Initialized
INFO - 2023-04-28 03:23:43 --> Hooks Class Initialized
INFO - 2023-04-28 03:23:43 --> Database Driver Class Initialized
DEBUG - 2023-04-28 03:23:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:23:43 --> Utf8 Class Initialized
INFO - 2023-04-28 03:23:43 --> URI Class Initialized
INFO - 2023-04-28 03:23:43 --> Router Class Initialized
INFO - 2023-04-28 03:23:43 --> Output Class Initialized
INFO - 2023-04-28 03:23:43 --> Security Class Initialized
DEBUG - 2023-04-28 03:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:23:43 --> Input Class Initialized
INFO - 2023-04-28 03:23:43 --> Language Class Initialized
INFO - 2023-04-28 03:23:43 --> Loader Class Initialized
INFO - 2023-04-28 03:23:43 --> Controller Class Initialized
DEBUG - 2023-04-28 03:23:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:23:43 --> Database Driver Class Initialized
INFO - 2023-04-28 03:23:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:23:43 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:43 --> Total execution time: 0.0218
INFO - 2023-04-28 03:23:43 --> Final output sent to browser
DEBUG - 2023-04-28 03:23:43 --> Total execution time: 0.0132
INFO - 2023-04-28 03:30:30 --> Config Class Initialized
INFO - 2023-04-28 03:30:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:30:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:30:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:30:30 --> URI Class Initialized
INFO - 2023-04-28 03:30:30 --> Router Class Initialized
INFO - 2023-04-28 03:30:30 --> Output Class Initialized
INFO - 2023-04-28 03:30:30 --> Security Class Initialized
DEBUG - 2023-04-28 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:30:30 --> Input Class Initialized
INFO - 2023-04-28 03:30:30 --> Language Class Initialized
INFO - 2023-04-28 03:30:30 --> Loader Class Initialized
INFO - 2023-04-28 03:30:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:30:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:30:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:30:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:30:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:30:30 --> Total execution time: 0.0941
INFO - 2023-04-28 03:30:30 --> Config Class Initialized
INFO - 2023-04-28 03:30:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:30:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:30:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:30:30 --> URI Class Initialized
INFO - 2023-04-28 03:30:30 --> Router Class Initialized
INFO - 2023-04-28 03:30:30 --> Output Class Initialized
INFO - 2023-04-28 03:30:30 --> Security Class Initialized
DEBUG - 2023-04-28 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:30:30 --> Input Class Initialized
INFO - 2023-04-28 03:30:30 --> Language Class Initialized
INFO - 2023-04-28 03:30:30 --> Loader Class Initialized
INFO - 2023-04-28 03:30:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:30:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:30:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:30:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:30:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:30:30 --> Total execution time: 0.0173
INFO - 2023-04-28 03:30:32 --> Config Class Initialized
INFO - 2023-04-28 03:30:32 --> Config Class Initialized
INFO - 2023-04-28 03:30:32 --> Hooks Class Initialized
INFO - 2023-04-28 03:30:32 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:30:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:30:32 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:30:32 --> Utf8 Class Initialized
INFO - 2023-04-28 03:30:32 --> Utf8 Class Initialized
INFO - 2023-04-28 03:30:32 --> URI Class Initialized
INFO - 2023-04-28 03:30:32 --> URI Class Initialized
INFO - 2023-04-28 03:30:32 --> Router Class Initialized
INFO - 2023-04-28 03:30:32 --> Router Class Initialized
INFO - 2023-04-28 03:30:32 --> Output Class Initialized
INFO - 2023-04-28 03:30:32 --> Output Class Initialized
INFO - 2023-04-28 03:30:32 --> Security Class Initialized
INFO - 2023-04-28 03:30:32 --> Security Class Initialized
DEBUG - 2023-04-28 03:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:30:32 --> Input Class Initialized
INFO - 2023-04-28 03:30:32 --> Input Class Initialized
INFO - 2023-04-28 03:30:32 --> Language Class Initialized
INFO - 2023-04-28 03:30:32 --> Language Class Initialized
INFO - 2023-04-28 03:30:32 --> Loader Class Initialized
INFO - 2023-04-28 03:30:32 --> Loader Class Initialized
INFO - 2023-04-28 03:30:32 --> Controller Class Initialized
INFO - 2023-04-28 03:30:32 --> Controller Class Initialized
DEBUG - 2023-04-28 03:30:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:30:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:30:32 --> Final output sent to browser
INFO - 2023-04-28 03:30:32 --> Database Driver Class Initialized
DEBUG - 2023-04-28 03:30:32 --> Total execution time: 0.0044
INFO - 2023-04-28 03:30:32 --> Config Class Initialized
INFO - 2023-04-28 03:30:32 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:30:32 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:30:32 --> Utf8 Class Initialized
INFO - 2023-04-28 03:30:32 --> URI Class Initialized
INFO - 2023-04-28 03:30:32 --> Router Class Initialized
INFO - 2023-04-28 03:30:32 --> Output Class Initialized
INFO - 2023-04-28 03:30:32 --> Security Class Initialized
DEBUG - 2023-04-28 03:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:30:32 --> Input Class Initialized
INFO - 2023-04-28 03:30:32 --> Language Class Initialized
INFO - 2023-04-28 03:30:32 --> Loader Class Initialized
INFO - 2023-04-28 03:30:32 --> Controller Class Initialized
DEBUG - 2023-04-28 03:30:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:30:32 --> Database Driver Class Initialized
INFO - 2023-04-28 03:30:32 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:30:32 --> Model "Login_model" initialized
INFO - 2023-04-28 03:30:32 --> Database Driver Class Initialized
INFO - 2023-04-28 03:30:32 --> Final output sent to browser
DEBUG - 2023-04-28 03:30:32 --> Total execution time: 0.0326
INFO - 2023-04-28 03:30:32 --> Config Class Initialized
INFO - 2023-04-28 03:30:32 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:30:32 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:30:32 --> Utf8 Class Initialized
INFO - 2023-04-28 03:30:32 --> URI Class Initialized
INFO - 2023-04-28 03:30:32 --> Router Class Initialized
INFO - 2023-04-28 03:30:32 --> Output Class Initialized
INFO - 2023-04-28 03:30:32 --> Security Class Initialized
DEBUG - 2023-04-28 03:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:30:32 --> Input Class Initialized
INFO - 2023-04-28 03:30:32 --> Language Class Initialized
INFO - 2023-04-28 03:30:32 --> Loader Class Initialized
INFO - 2023-04-28 03:30:32 --> Controller Class Initialized
DEBUG - 2023-04-28 03:30:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:30:32 --> Database Driver Class Initialized
INFO - 2023-04-28 03:30:32 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:30:32 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:30:32 --> Final output sent to browser
DEBUG - 2023-04-28 03:30:32 --> Total execution time: 0.0536
INFO - 2023-04-28 03:30:32 --> Final output sent to browser
DEBUG - 2023-04-28 03:30:32 --> Total execution time: 0.0304
INFO - 2023-04-28 03:30:34 --> Config Class Initialized
INFO - 2023-04-28 03:30:34 --> Config Class Initialized
INFO - 2023-04-28 03:30:34 --> Hooks Class Initialized
INFO - 2023-04-28 03:30:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:30:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:30:34 --> Utf8 Class Initialized
DEBUG - 2023-04-28 03:30:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:30:34 --> URI Class Initialized
INFO - 2023-04-28 03:30:34 --> Utf8 Class Initialized
INFO - 2023-04-28 03:30:34 --> Router Class Initialized
INFO - 2023-04-28 03:30:34 --> URI Class Initialized
INFO - 2023-04-28 03:30:34 --> Output Class Initialized
INFO - 2023-04-28 03:30:34 --> Security Class Initialized
INFO - 2023-04-28 03:30:34 --> Router Class Initialized
DEBUG - 2023-04-28 03:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:30:34 --> Output Class Initialized
INFO - 2023-04-28 03:30:34 --> Input Class Initialized
INFO - 2023-04-28 03:30:34 --> Security Class Initialized
INFO - 2023-04-28 03:30:34 --> Language Class Initialized
DEBUG - 2023-04-28 03:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:30:34 --> Input Class Initialized
INFO - 2023-04-28 03:30:34 --> Loader Class Initialized
INFO - 2023-04-28 03:30:34 --> Language Class Initialized
INFO - 2023-04-28 03:30:34 --> Controller Class Initialized
DEBUG - 2023-04-28 03:30:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:30:34 --> Loader Class Initialized
INFO - 2023-04-28 03:30:34 --> Controller Class Initialized
DEBUG - 2023-04-28 03:30:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:30:34 --> Database Driver Class Initialized
INFO - 2023-04-28 03:30:34 --> Database Driver Class Initialized
INFO - 2023-04-28 03:30:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:30:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:30:34 --> Final output sent to browser
DEBUG - 2023-04-28 03:30:34 --> Total execution time: 0.0390
INFO - 2023-04-28 03:30:34 --> Config Class Initialized
INFO - 2023-04-28 03:30:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:30:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:30:34 --> Utf8 Class Initialized
INFO - 2023-04-28 03:30:34 --> Final output sent to browser
INFO - 2023-04-28 03:30:34 --> URI Class Initialized
DEBUG - 2023-04-28 03:30:34 --> Total execution time: 0.0424
INFO - 2023-04-28 03:30:34 --> Router Class Initialized
INFO - 2023-04-28 03:30:34 --> Output Class Initialized
INFO - 2023-04-28 03:30:34 --> Security Class Initialized
DEBUG - 2023-04-28 03:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:30:34 --> Input Class Initialized
INFO - 2023-04-28 03:30:34 --> Language Class Initialized
INFO - 2023-04-28 03:30:34 --> Loader Class Initialized
INFO - 2023-04-28 03:30:34 --> Controller Class Initialized
DEBUG - 2023-04-28 03:30:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:30:34 --> Database Driver Class Initialized
INFO - 2023-04-28 03:30:34 --> Config Class Initialized
INFO - 2023-04-28 03:30:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:30:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:30:34 --> Utf8 Class Initialized
INFO - 2023-04-28 03:30:34 --> URI Class Initialized
INFO - 2023-04-28 03:30:34 --> Router Class Initialized
INFO - 2023-04-28 03:30:34 --> Output Class Initialized
INFO - 2023-04-28 03:30:34 --> Security Class Initialized
DEBUG - 2023-04-28 03:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:30:34 --> Input Class Initialized
INFO - 2023-04-28 03:30:34 --> Language Class Initialized
INFO - 2023-04-28 03:30:34 --> Loader Class Initialized
INFO - 2023-04-28 03:30:34 --> Controller Class Initialized
DEBUG - 2023-04-28 03:30:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:30:34 --> Database Driver Class Initialized
INFO - 2023-04-28 03:30:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:30:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:30:34 --> Final output sent to browser
DEBUG - 2023-04-28 03:30:34 --> Total execution time: 0.0343
INFO - 2023-04-28 03:30:34 --> Final output sent to browser
DEBUG - 2023-04-28 03:30:34 --> Total execution time: 0.0419
INFO - 2023-04-28 03:31:08 --> Config Class Initialized
INFO - 2023-04-28 03:31:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:31:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:31:08 --> Utf8 Class Initialized
INFO - 2023-04-28 03:31:08 --> URI Class Initialized
INFO - 2023-04-28 03:31:08 --> Router Class Initialized
INFO - 2023-04-28 03:31:08 --> Output Class Initialized
INFO - 2023-04-28 03:31:08 --> Security Class Initialized
DEBUG - 2023-04-28 03:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:31:08 --> Input Class Initialized
INFO - 2023-04-28 03:31:08 --> Language Class Initialized
INFO - 2023-04-28 03:31:08 --> Loader Class Initialized
INFO - 2023-04-28 03:31:08 --> Controller Class Initialized
DEBUG - 2023-04-28 03:31:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:31:08 --> Database Driver Class Initialized
INFO - 2023-04-28 03:31:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:31:08 --> Final output sent to browser
DEBUG - 2023-04-28 03:31:08 --> Total execution time: 0.0124
INFO - 2023-04-28 03:31:08 --> Config Class Initialized
INFO - 2023-04-28 03:31:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:31:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:31:08 --> Utf8 Class Initialized
INFO - 2023-04-28 03:31:08 --> URI Class Initialized
INFO - 2023-04-28 03:31:08 --> Router Class Initialized
INFO - 2023-04-28 03:31:08 --> Output Class Initialized
INFO - 2023-04-28 03:31:08 --> Security Class Initialized
DEBUG - 2023-04-28 03:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:31:08 --> Input Class Initialized
INFO - 2023-04-28 03:31:08 --> Language Class Initialized
INFO - 2023-04-28 03:31:08 --> Loader Class Initialized
INFO - 2023-04-28 03:31:08 --> Controller Class Initialized
DEBUG - 2023-04-28 03:31:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:31:08 --> Database Driver Class Initialized
INFO - 2023-04-28 03:31:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:31:08 --> Final output sent to browser
DEBUG - 2023-04-28 03:31:08 --> Total execution time: 0.0527
INFO - 2023-04-28 03:31:08 --> Config Class Initialized
INFO - 2023-04-28 03:31:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:31:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:31:08 --> Utf8 Class Initialized
INFO - 2023-04-28 03:31:08 --> URI Class Initialized
INFO - 2023-04-28 03:31:08 --> Router Class Initialized
INFO - 2023-04-28 03:31:08 --> Output Class Initialized
INFO - 2023-04-28 03:31:08 --> Security Class Initialized
DEBUG - 2023-04-28 03:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:31:08 --> Input Class Initialized
INFO - 2023-04-28 03:31:08 --> Language Class Initialized
INFO - 2023-04-28 03:31:08 --> Loader Class Initialized
INFO - 2023-04-28 03:31:08 --> Controller Class Initialized
DEBUG - 2023-04-28 03:31:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:31:08 --> Database Driver Class Initialized
INFO - 2023-04-28 03:31:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:31:08 --> Final output sent to browser
DEBUG - 2023-04-28 03:31:08 --> Total execution time: 0.0567
INFO - 2023-04-28 03:31:08 --> Config Class Initialized
INFO - 2023-04-28 03:31:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:31:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:31:08 --> Utf8 Class Initialized
INFO - 2023-04-28 03:31:08 --> URI Class Initialized
INFO - 2023-04-28 03:31:08 --> Router Class Initialized
INFO - 2023-04-28 03:31:08 --> Output Class Initialized
INFO - 2023-04-28 03:31:08 --> Security Class Initialized
DEBUG - 2023-04-28 03:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:31:08 --> Input Class Initialized
INFO - 2023-04-28 03:31:08 --> Language Class Initialized
INFO - 2023-04-28 03:31:08 --> Loader Class Initialized
INFO - 2023-04-28 03:31:08 --> Controller Class Initialized
DEBUG - 2023-04-28 03:31:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:31:08 --> Database Driver Class Initialized
INFO - 2023-04-28 03:31:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:31:08 --> Final output sent to browser
DEBUG - 2023-04-28 03:31:08 --> Total execution time: 0.0570
INFO - 2023-04-28 03:33:40 --> Config Class Initialized
INFO - 2023-04-28 03:33:40 --> Config Class Initialized
INFO - 2023-04-28 03:33:40 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:33:40 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:33:40 --> Utf8 Class Initialized
INFO - 2023-04-28 03:33:40 --> URI Class Initialized
INFO - 2023-04-28 03:33:40 --> Router Class Initialized
INFO - 2023-04-28 03:33:40 --> Output Class Initialized
INFO - 2023-04-28 03:33:40 --> Security Class Initialized
INFO - 2023-04-28 03:33:40 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:33:40 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:33:40 --> Input Class Initialized
INFO - 2023-04-28 03:33:40 --> Utf8 Class Initialized
INFO - 2023-04-28 03:33:40 --> Language Class Initialized
INFO - 2023-04-28 03:33:40 --> URI Class Initialized
INFO - 2023-04-28 03:33:40 --> Loader Class Initialized
INFO - 2023-04-28 03:33:40 --> Controller Class Initialized
DEBUG - 2023-04-28 03:33:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:33:40 --> Database Driver Class Initialized
INFO - 2023-04-28 03:33:40 --> Router Class Initialized
INFO - 2023-04-28 03:33:40 --> Output Class Initialized
INFO - 2023-04-28 03:33:40 --> Security Class Initialized
DEBUG - 2023-04-28 03:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:33:40 --> Input Class Initialized
INFO - 2023-04-28 03:33:40 --> Language Class Initialized
INFO - 2023-04-28 03:33:40 --> Loader Class Initialized
INFO - 2023-04-28 03:33:40 --> Controller Class Initialized
DEBUG - 2023-04-28 03:33:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:33:40 --> Database Driver Class Initialized
INFO - 2023-04-28 03:33:40 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:33:40 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:33:40 --> Final output sent to browser
DEBUG - 2023-04-28 03:33:40 --> Total execution time: 0.1541
INFO - 2023-04-28 03:33:40 --> Final output sent to browser
DEBUG - 2023-04-28 03:33:40 --> Total execution time: 0.1540
INFO - 2023-04-28 03:33:40 --> Config Class Initialized
INFO - 2023-04-28 03:33:40 --> Config Class Initialized
INFO - 2023-04-28 03:33:40 --> Hooks Class Initialized
INFO - 2023-04-28 03:33:40 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:33:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:33:40 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:33:40 --> Utf8 Class Initialized
INFO - 2023-04-28 03:33:40 --> Utf8 Class Initialized
INFO - 2023-04-28 03:33:40 --> URI Class Initialized
INFO - 2023-04-28 03:33:40 --> URI Class Initialized
INFO - 2023-04-28 03:33:40 --> Router Class Initialized
INFO - 2023-04-28 03:33:40 --> Output Class Initialized
INFO - 2023-04-28 03:33:40 --> Router Class Initialized
INFO - 2023-04-28 03:33:40 --> Output Class Initialized
INFO - 2023-04-28 03:33:40 --> Security Class Initialized
INFO - 2023-04-28 03:33:40 --> Security Class Initialized
DEBUG - 2023-04-28 03:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:33:40 --> Input Class Initialized
INFO - 2023-04-28 03:33:40 --> Input Class Initialized
INFO - 2023-04-28 03:33:40 --> Language Class Initialized
INFO - 2023-04-28 03:33:40 --> Language Class Initialized
INFO - 2023-04-28 03:33:40 --> Loader Class Initialized
INFO - 2023-04-28 03:33:40 --> Loader Class Initialized
INFO - 2023-04-28 03:33:40 --> Controller Class Initialized
INFO - 2023-04-28 03:33:40 --> Controller Class Initialized
DEBUG - 2023-04-28 03:33:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:33:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:33:40 --> Database Driver Class Initialized
INFO - 2023-04-28 03:33:40 --> Database Driver Class Initialized
INFO - 2023-04-28 03:33:40 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:33:40 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:33:40 --> Final output sent to browser
DEBUG - 2023-04-28 03:33:40 --> Total execution time: 0.0133
INFO - 2023-04-28 03:33:40 --> Final output sent to browser
DEBUG - 2023-04-28 03:33:40 --> Total execution time: 0.0165
INFO - 2023-04-28 03:33:49 --> Config Class Initialized
INFO - 2023-04-28 03:33:49 --> Config Class Initialized
INFO - 2023-04-28 03:33:49 --> Hooks Class Initialized
INFO - 2023-04-28 03:33:49 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:33:49 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:33:49 --> Utf8 Class Initialized
DEBUG - 2023-04-28 03:33:49 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:33:49 --> URI Class Initialized
INFO - 2023-04-28 03:33:49 --> Utf8 Class Initialized
INFO - 2023-04-28 03:33:49 --> Router Class Initialized
INFO - 2023-04-28 03:33:49 --> URI Class Initialized
INFO - 2023-04-28 03:33:49 --> Output Class Initialized
INFO - 2023-04-28 03:33:49 --> Router Class Initialized
INFO - 2023-04-28 03:33:49 --> Security Class Initialized
INFO - 2023-04-28 03:33:49 --> Output Class Initialized
DEBUG - 2023-04-28 03:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:33:49 --> Security Class Initialized
INFO - 2023-04-28 03:33:49 --> Input Class Initialized
DEBUG - 2023-04-28 03:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:33:49 --> Language Class Initialized
INFO - 2023-04-28 03:33:49 --> Input Class Initialized
INFO - 2023-04-28 03:33:49 --> Loader Class Initialized
INFO - 2023-04-28 03:33:49 --> Language Class Initialized
INFO - 2023-04-28 03:33:49 --> Controller Class Initialized
INFO - 2023-04-28 03:33:49 --> Loader Class Initialized
DEBUG - 2023-04-28 03:33:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:33:49 --> Controller Class Initialized
DEBUG - 2023-04-28 03:33:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:33:49 --> Database Driver Class Initialized
INFO - 2023-04-28 03:33:49 --> Database Driver Class Initialized
INFO - 2023-04-28 03:33:49 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:33:49 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:33:49 --> Final output sent to browser
DEBUG - 2023-04-28 03:33:49 --> Total execution time: 0.0569
INFO - 2023-04-28 03:33:49 --> Final output sent to browser
DEBUG - 2023-04-28 03:33:49 --> Total execution time: 0.0586
INFO - 2023-04-28 03:33:49 --> Config Class Initialized
INFO - 2023-04-28 03:33:49 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:33:49 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:33:49 --> Utf8 Class Initialized
INFO - 2023-04-28 03:33:49 --> URI Class Initialized
INFO - 2023-04-28 03:33:49 --> Router Class Initialized
INFO - 2023-04-28 03:33:49 --> Output Class Initialized
INFO - 2023-04-28 03:33:49 --> Security Class Initialized
INFO - 2023-04-28 03:33:49 --> Config Class Initialized
DEBUG - 2023-04-28 03:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:33:49 --> Hooks Class Initialized
INFO - 2023-04-28 03:33:49 --> Input Class Initialized
INFO - 2023-04-28 03:33:49 --> Language Class Initialized
DEBUG - 2023-04-28 03:33:49 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:33:49 --> Loader Class Initialized
INFO - 2023-04-28 03:33:49 --> Utf8 Class Initialized
INFO - 2023-04-28 03:33:49 --> Controller Class Initialized
INFO - 2023-04-28 03:33:49 --> URI Class Initialized
DEBUG - 2023-04-28 03:33:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:33:49 --> Router Class Initialized
INFO - 2023-04-28 03:33:49 --> Database Driver Class Initialized
INFO - 2023-04-28 03:33:49 --> Output Class Initialized
INFO - 2023-04-28 03:33:49 --> Security Class Initialized
DEBUG - 2023-04-28 03:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:33:49 --> Input Class Initialized
INFO - 2023-04-28 03:33:49 --> Language Class Initialized
INFO - 2023-04-28 03:33:49 --> Loader Class Initialized
INFO - 2023-04-28 03:33:49 --> Controller Class Initialized
DEBUG - 2023-04-28 03:33:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:33:49 --> Database Driver Class Initialized
INFO - 2023-04-28 03:33:49 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:33:49 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:33:49 --> Final output sent to browser
DEBUG - 2023-04-28 03:33:49 --> Total execution time: 0.0121
INFO - 2023-04-28 03:33:49 --> Final output sent to browser
DEBUG - 2023-04-28 03:33:49 --> Total execution time: 0.0141
INFO - 2023-04-28 03:34:13 --> Config Class Initialized
INFO - 2023-04-28 03:34:13 --> Config Class Initialized
INFO - 2023-04-28 03:34:13 --> Hooks Class Initialized
INFO - 2023-04-28 03:34:13 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:34:13 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:34:13 --> Utf8 Class Initialized
INFO - 2023-04-28 03:34:13 --> URI Class Initialized
INFO - 2023-04-28 03:34:13 --> Router Class Initialized
INFO - 2023-04-28 03:34:13 --> Output Class Initialized
INFO - 2023-04-28 03:34:13 --> Security Class Initialized
DEBUG - 2023-04-28 03:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:34:13 --> Input Class Initialized
INFO - 2023-04-28 03:34:13 --> Language Class Initialized
INFO - 2023-04-28 03:34:13 --> Loader Class Initialized
INFO - 2023-04-28 03:34:13 --> Controller Class Initialized
DEBUG - 2023-04-28 03:34:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:34:13 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:34:13 --> Database Driver Class Initialized
INFO - 2023-04-28 03:34:13 --> Utf8 Class Initialized
INFO - 2023-04-28 03:34:13 --> URI Class Initialized
INFO - 2023-04-28 03:34:13 --> Router Class Initialized
INFO - 2023-04-28 03:34:13 --> Output Class Initialized
INFO - 2023-04-28 03:34:13 --> Security Class Initialized
DEBUG - 2023-04-28 03:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:34:13 --> Input Class Initialized
INFO - 2023-04-28 03:34:13 --> Language Class Initialized
INFO - 2023-04-28 03:34:13 --> Loader Class Initialized
INFO - 2023-04-28 03:34:13 --> Controller Class Initialized
DEBUG - 2023-04-28 03:34:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:34:13 --> Database Driver Class Initialized
INFO - 2023-04-28 03:34:13 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:34:13 --> Final output sent to browser
DEBUG - 2023-04-28 03:34:13 --> Total execution time: 0.0735
INFO - 2023-04-28 03:34:13 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:34:13 --> Config Class Initialized
INFO - 2023-04-28 03:34:13 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:34:13 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:34:13 --> Utf8 Class Initialized
INFO - 2023-04-28 03:34:13 --> URI Class Initialized
INFO - 2023-04-28 03:34:13 --> Router Class Initialized
INFO - 2023-04-28 03:34:13 --> Output Class Initialized
INFO - 2023-04-28 03:34:13 --> Security Class Initialized
DEBUG - 2023-04-28 03:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:34:13 --> Input Class Initialized
INFO - 2023-04-28 03:34:13 --> Language Class Initialized
INFO - 2023-04-28 03:34:13 --> Loader Class Initialized
INFO - 2023-04-28 03:34:13 --> Controller Class Initialized
INFO - 2023-04-28 03:34:13 --> Final output sent to browser
DEBUG - 2023-04-28 03:34:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:34:13 --> Total execution time: 0.0806
INFO - 2023-04-28 03:34:13 --> Database Driver Class Initialized
INFO - 2023-04-28 03:34:13 --> Config Class Initialized
INFO - 2023-04-28 03:34:13 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:34:13 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:34:13 --> Utf8 Class Initialized
INFO - 2023-04-28 03:34:13 --> URI Class Initialized
INFO - 2023-04-28 03:34:13 --> Router Class Initialized
INFO - 2023-04-28 03:34:13 --> Output Class Initialized
INFO - 2023-04-28 03:34:13 --> Security Class Initialized
DEBUG - 2023-04-28 03:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:34:13 --> Input Class Initialized
INFO - 2023-04-28 03:34:13 --> Language Class Initialized
INFO - 2023-04-28 03:34:13 --> Loader Class Initialized
INFO - 2023-04-28 03:34:13 --> Controller Class Initialized
DEBUG - 2023-04-28 03:34:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:34:13 --> Database Driver Class Initialized
INFO - 2023-04-28 03:34:13 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:34:13 --> Final output sent to browser
DEBUG - 2023-04-28 03:34:13 --> Total execution time: 0.0160
INFO - 2023-04-28 03:34:13 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:34:13 --> Final output sent to browser
DEBUG - 2023-04-28 03:34:13 --> Total execution time: 0.0542
INFO - 2023-04-28 03:35:50 --> Config Class Initialized
INFO - 2023-04-28 03:35:50 --> Config Class Initialized
INFO - 2023-04-28 03:35:50 --> Hooks Class Initialized
INFO - 2023-04-28 03:35:50 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:35:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:35:50 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:35:50 --> Utf8 Class Initialized
INFO - 2023-04-28 03:35:50 --> Utf8 Class Initialized
INFO - 2023-04-28 03:35:50 --> URI Class Initialized
INFO - 2023-04-28 03:35:50 --> URI Class Initialized
INFO - 2023-04-28 03:35:50 --> Router Class Initialized
INFO - 2023-04-28 03:35:50 --> Router Class Initialized
INFO - 2023-04-28 03:35:50 --> Output Class Initialized
INFO - 2023-04-28 03:35:50 --> Output Class Initialized
INFO - 2023-04-28 03:35:50 --> Security Class Initialized
INFO - 2023-04-28 03:35:50 --> Security Class Initialized
DEBUG - 2023-04-28 03:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:35:50 --> Input Class Initialized
DEBUG - 2023-04-28 03:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:35:50 --> Language Class Initialized
INFO - 2023-04-28 03:35:50 --> Input Class Initialized
INFO - 2023-04-28 03:35:50 --> Language Class Initialized
INFO - 2023-04-28 03:35:50 --> Loader Class Initialized
INFO - 2023-04-28 03:35:50 --> Loader Class Initialized
INFO - 2023-04-28 03:35:50 --> Controller Class Initialized
INFO - 2023-04-28 03:35:50 --> Controller Class Initialized
DEBUG - 2023-04-28 03:35:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:35:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:35:50 --> Database Driver Class Initialized
INFO - 2023-04-28 03:35:50 --> Database Driver Class Initialized
INFO - 2023-04-28 03:35:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:35:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:35:50 --> Final output sent to browser
DEBUG - 2023-04-28 03:35:50 --> Total execution time: 0.0590
INFO - 2023-04-28 03:35:50 --> Final output sent to browser
DEBUG - 2023-04-28 03:35:50 --> Total execution time: 0.0603
INFO - 2023-04-28 03:35:50 --> Config Class Initialized
INFO - 2023-04-28 03:35:50 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:35:50 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:35:50 --> Utf8 Class Initialized
INFO - 2023-04-28 03:35:50 --> URI Class Initialized
INFO - 2023-04-28 03:35:50 --> Router Class Initialized
INFO - 2023-04-28 03:35:50 --> Output Class Initialized
INFO - 2023-04-28 03:35:50 --> Config Class Initialized
INFO - 2023-04-28 03:35:50 --> Hooks Class Initialized
INFO - 2023-04-28 03:35:50 --> Security Class Initialized
DEBUG - 2023-04-28 03:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:35:50 --> Input Class Initialized
INFO - 2023-04-28 03:35:50 --> Language Class Initialized
INFO - 2023-04-28 03:35:50 --> Loader Class Initialized
DEBUG - 2023-04-28 03:35:50 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:35:50 --> Controller Class Initialized
INFO - 2023-04-28 03:35:50 --> Utf8 Class Initialized
INFO - 2023-04-28 03:35:50 --> URI Class Initialized
INFO - 2023-04-28 03:35:50 --> Router Class Initialized
INFO - 2023-04-28 03:35:50 --> Output Class Initialized
INFO - 2023-04-28 03:35:50 --> Security Class Initialized
DEBUG - 2023-04-28 03:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:35:50 --> Input Class Initialized
INFO - 2023-04-28 03:35:50 --> Language Class Initialized
INFO - 2023-04-28 03:35:50 --> Loader Class Initialized
INFO - 2023-04-28 03:35:50 --> Controller Class Initialized
DEBUG - 2023-04-28 03:35:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:35:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:35:50 --> Database Driver Class Initialized
INFO - 2023-04-28 03:35:50 --> Database Driver Class Initialized
INFO - 2023-04-28 03:35:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:35:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:35:50 --> Final output sent to browser
DEBUG - 2023-04-28 03:35:50 --> Total execution time: 0.0942
INFO - 2023-04-28 03:35:50 --> Final output sent to browser
DEBUG - 2023-04-28 03:35:50 --> Total execution time: 0.0918
INFO - 2023-04-28 03:36:32 --> Config Class Initialized
INFO - 2023-04-28 03:36:32 --> Config Class Initialized
INFO - 2023-04-28 03:36:32 --> Hooks Class Initialized
INFO - 2023-04-28 03:36:32 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:36:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:36:32 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:36:32 --> Utf8 Class Initialized
INFO - 2023-04-28 03:36:32 --> Utf8 Class Initialized
INFO - 2023-04-28 03:36:32 --> URI Class Initialized
INFO - 2023-04-28 03:36:32 --> URI Class Initialized
INFO - 2023-04-28 03:36:32 --> Router Class Initialized
INFO - 2023-04-28 03:36:32 --> Router Class Initialized
INFO - 2023-04-28 03:36:32 --> Output Class Initialized
INFO - 2023-04-28 03:36:32 --> Output Class Initialized
INFO - 2023-04-28 03:36:32 --> Security Class Initialized
INFO - 2023-04-28 03:36:32 --> Security Class Initialized
DEBUG - 2023-04-28 03:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:36:32 --> Input Class Initialized
INFO - 2023-04-28 03:36:32 --> Input Class Initialized
INFO - 2023-04-28 03:36:32 --> Language Class Initialized
INFO - 2023-04-28 03:36:32 --> Language Class Initialized
INFO - 2023-04-28 03:36:32 --> Loader Class Initialized
INFO - 2023-04-28 03:36:32 --> Loader Class Initialized
INFO - 2023-04-28 03:36:32 --> Controller Class Initialized
INFO - 2023-04-28 03:36:32 --> Controller Class Initialized
DEBUG - 2023-04-28 03:36:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:36:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:36:32 --> Database Driver Class Initialized
INFO - 2023-04-28 03:36:32 --> Database Driver Class Initialized
INFO - 2023-04-28 03:36:32 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:36:32 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:36:32 --> Final output sent to browser
DEBUG - 2023-04-28 03:36:32 --> Total execution time: 0.0608
INFO - 2023-04-28 03:36:32 --> Final output sent to browser
DEBUG - 2023-04-28 03:36:32 --> Total execution time: 0.0623
INFO - 2023-04-28 03:36:32 --> Config Class Initialized
INFO - 2023-04-28 03:36:32 --> Config Class Initialized
INFO - 2023-04-28 03:36:32 --> Hooks Class Initialized
INFO - 2023-04-28 03:36:32 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:36:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:36:32 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:36:32 --> Utf8 Class Initialized
INFO - 2023-04-28 03:36:32 --> Utf8 Class Initialized
INFO - 2023-04-28 03:36:32 --> URI Class Initialized
INFO - 2023-04-28 03:36:32 --> URI Class Initialized
INFO - 2023-04-28 03:36:32 --> Router Class Initialized
INFO - 2023-04-28 03:36:32 --> Output Class Initialized
INFO - 2023-04-28 03:36:32 --> Router Class Initialized
INFO - 2023-04-28 03:36:32 --> Security Class Initialized
INFO - 2023-04-28 03:36:32 --> Output Class Initialized
DEBUG - 2023-04-28 03:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:36:32 --> Security Class Initialized
INFO - 2023-04-28 03:36:32 --> Input Class Initialized
INFO - 2023-04-28 03:36:32 --> Language Class Initialized
INFO - 2023-04-28 03:36:32 --> Loader Class Initialized
DEBUG - 2023-04-28 03:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:36:32 --> Controller Class Initialized
INFO - 2023-04-28 03:36:32 --> Input Class Initialized
DEBUG - 2023-04-28 03:36:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:36:32 --> Language Class Initialized
INFO - 2023-04-28 03:36:32 --> Database Driver Class Initialized
INFO - 2023-04-28 03:36:32 --> Loader Class Initialized
INFO - 2023-04-28 03:36:32 --> Controller Class Initialized
DEBUG - 2023-04-28 03:36:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:36:32 --> Database Driver Class Initialized
INFO - 2023-04-28 03:36:32 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:36:32 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:36:32 --> Final output sent to browser
DEBUG - 2023-04-28 03:36:32 --> Total execution time: 0.0254
INFO - 2023-04-28 03:36:32 --> Final output sent to browser
DEBUG - 2023-04-28 03:36:32 --> Total execution time: 0.0263
INFO - 2023-04-28 03:38:50 --> Config Class Initialized
INFO - 2023-04-28 03:38:50 --> Config Class Initialized
INFO - 2023-04-28 03:38:50 --> Hooks Class Initialized
INFO - 2023-04-28 03:38:50 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:38:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:38:50 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:38:50 --> Utf8 Class Initialized
INFO - 2023-04-28 03:38:50 --> Utf8 Class Initialized
INFO - 2023-04-28 03:38:50 --> URI Class Initialized
INFO - 2023-04-28 03:38:50 --> URI Class Initialized
INFO - 2023-04-28 03:38:50 --> Router Class Initialized
INFO - 2023-04-28 03:38:50 --> Router Class Initialized
INFO - 2023-04-28 03:38:50 --> Output Class Initialized
INFO - 2023-04-28 03:38:50 --> Output Class Initialized
INFO - 2023-04-28 03:38:50 --> Security Class Initialized
INFO - 2023-04-28 03:38:50 --> Security Class Initialized
DEBUG - 2023-04-28 03:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:38:50 --> Input Class Initialized
INFO - 2023-04-28 03:38:50 --> Input Class Initialized
INFO - 2023-04-28 03:38:50 --> Language Class Initialized
INFO - 2023-04-28 03:38:50 --> Language Class Initialized
INFO - 2023-04-28 03:38:50 --> Loader Class Initialized
INFO - 2023-04-28 03:38:50 --> Loader Class Initialized
INFO - 2023-04-28 03:38:50 --> Controller Class Initialized
INFO - 2023-04-28 03:38:50 --> Controller Class Initialized
DEBUG - 2023-04-28 03:38:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:38:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:38:50 --> Database Driver Class Initialized
INFO - 2023-04-28 03:38:50 --> Database Driver Class Initialized
INFO - 2023-04-28 03:38:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:38:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:38:50 --> Final output sent to browser
DEBUG - 2023-04-28 03:38:50 --> Total execution time: 0.0659
INFO - 2023-04-28 03:38:50 --> Final output sent to browser
DEBUG - 2023-04-28 03:38:50 --> Total execution time: 0.0676
INFO - 2023-04-28 03:38:50 --> Config Class Initialized
INFO - 2023-04-28 03:38:50 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:38:50 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:38:50 --> Utf8 Class Initialized
INFO - 2023-04-28 03:38:50 --> URI Class Initialized
INFO - 2023-04-28 03:38:50 --> Router Class Initialized
INFO - 2023-04-28 03:38:50 --> Output Class Initialized
INFO - 2023-04-28 03:38:50 --> Security Class Initialized
DEBUG - 2023-04-28 03:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:38:50 --> Input Class Initialized
INFO - 2023-04-28 03:38:50 --> Config Class Initialized
INFO - 2023-04-28 03:38:50 --> Language Class Initialized
INFO - 2023-04-28 03:38:50 --> Hooks Class Initialized
INFO - 2023-04-28 03:38:50 --> Loader Class Initialized
DEBUG - 2023-04-28 03:38:50 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:38:50 --> Controller Class Initialized
INFO - 2023-04-28 03:38:50 --> Utf8 Class Initialized
DEBUG - 2023-04-28 03:38:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:38:50 --> URI Class Initialized
INFO - 2023-04-28 03:38:50 --> Router Class Initialized
INFO - 2023-04-28 03:38:50 --> Output Class Initialized
INFO - 2023-04-28 03:38:50 --> Security Class Initialized
DEBUG - 2023-04-28 03:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:38:50 --> Database Driver Class Initialized
INFO - 2023-04-28 03:38:50 --> Input Class Initialized
INFO - 2023-04-28 03:38:50 --> Language Class Initialized
INFO - 2023-04-28 03:38:50 --> Loader Class Initialized
INFO - 2023-04-28 03:38:50 --> Controller Class Initialized
DEBUG - 2023-04-28 03:38:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:38:50 --> Database Driver Class Initialized
INFO - 2023-04-28 03:38:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:38:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:38:50 --> Final output sent to browser
DEBUG - 2023-04-28 03:38:50 --> Total execution time: 0.0205
INFO - 2023-04-28 03:38:50 --> Final output sent to browser
DEBUG - 2023-04-28 03:38:50 --> Total execution time: 0.0194
INFO - 2023-04-28 03:39:19 --> Config Class Initialized
INFO - 2023-04-28 03:39:19 --> Config Class Initialized
INFO - 2023-04-28 03:39:19 --> Hooks Class Initialized
INFO - 2023-04-28 03:39:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:39:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:39:19 --> Utf8 Class Initialized
DEBUG - 2023-04-28 03:39:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:39:19 --> Utf8 Class Initialized
INFO - 2023-04-28 03:39:19 --> URI Class Initialized
INFO - 2023-04-28 03:39:19 --> URI Class Initialized
INFO - 2023-04-28 03:39:19 --> Router Class Initialized
INFO - 2023-04-28 03:39:19 --> Output Class Initialized
INFO - 2023-04-28 03:39:19 --> Security Class Initialized
DEBUG - 2023-04-28 03:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:39:19 --> Input Class Initialized
INFO - 2023-04-28 03:39:19 --> Language Class Initialized
INFO - 2023-04-28 03:39:19 --> Loader Class Initialized
INFO - 2023-04-28 03:39:19 --> Controller Class Initialized
DEBUG - 2023-04-28 03:39:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:39:19 --> Database Driver Class Initialized
INFO - 2023-04-28 03:39:19 --> Router Class Initialized
INFO - 2023-04-28 03:39:19 --> Output Class Initialized
INFO - 2023-04-28 03:39:19 --> Security Class Initialized
DEBUG - 2023-04-28 03:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:39:19 --> Input Class Initialized
INFO - 2023-04-28 03:39:19 --> Language Class Initialized
INFO - 2023-04-28 03:39:19 --> Loader Class Initialized
INFO - 2023-04-28 03:39:19 --> Controller Class Initialized
DEBUG - 2023-04-28 03:39:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:39:19 --> Database Driver Class Initialized
INFO - 2023-04-28 03:39:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:39:19 --> Final output sent to browser
DEBUG - 2023-04-28 03:39:19 --> Total execution time: 0.0535
INFO - 2023-04-28 03:39:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:39:19 --> Config Class Initialized
INFO - 2023-04-28 03:39:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:39:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:39:19 --> Final output sent to browser
INFO - 2023-04-28 03:39:19 --> Utf8 Class Initialized
DEBUG - 2023-04-28 03:39:19 --> Total execution time: 0.0595
INFO - 2023-04-28 03:39:19 --> URI Class Initialized
INFO - 2023-04-28 03:39:19 --> Router Class Initialized
INFO - 2023-04-28 03:39:19 --> Output Class Initialized
INFO - 2023-04-28 03:39:19 --> Security Class Initialized
DEBUG - 2023-04-28 03:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:39:19 --> Input Class Initialized
INFO - 2023-04-28 03:39:19 --> Language Class Initialized
INFO - 2023-04-28 03:39:19 --> Loader Class Initialized
INFO - 2023-04-28 03:39:19 --> Controller Class Initialized
DEBUG - 2023-04-28 03:39:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:39:19 --> Config Class Initialized
INFO - 2023-04-28 03:39:19 --> Database Driver Class Initialized
INFO - 2023-04-28 03:39:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:39:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:39:19 --> Utf8 Class Initialized
INFO - 2023-04-28 03:39:19 --> URI Class Initialized
INFO - 2023-04-28 03:39:19 --> Router Class Initialized
INFO - 2023-04-28 03:39:19 --> Output Class Initialized
INFO - 2023-04-28 03:39:19 --> Security Class Initialized
DEBUG - 2023-04-28 03:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:39:19 --> Input Class Initialized
INFO - 2023-04-28 03:39:19 --> Language Class Initialized
INFO - 2023-04-28 03:39:19 --> Loader Class Initialized
INFO - 2023-04-28 03:39:19 --> Controller Class Initialized
DEBUG - 2023-04-28 03:39:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:39:19 --> Database Driver Class Initialized
INFO - 2023-04-28 03:39:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:39:19 --> Final output sent to browser
DEBUG - 2023-04-28 03:39:19 --> Total execution time: 0.0144
INFO - 2023-04-28 03:39:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:39:19 --> Final output sent to browser
DEBUG - 2023-04-28 03:39:19 --> Total execution time: 0.0557
INFO - 2023-04-28 03:39:30 --> Config Class Initialized
INFO - 2023-04-28 03:39:30 --> Config Class Initialized
INFO - 2023-04-28 03:39:30 --> Hooks Class Initialized
INFO - 2023-04-28 03:39:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:39:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:39:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:39:30 --> URI Class Initialized
DEBUG - 2023-04-28 03:39:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:39:30 --> Router Class Initialized
INFO - 2023-04-28 03:39:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:39:30 --> Output Class Initialized
INFO - 2023-04-28 03:39:30 --> URI Class Initialized
INFO - 2023-04-28 03:39:30 --> Security Class Initialized
INFO - 2023-04-28 03:39:30 --> Router Class Initialized
DEBUG - 2023-04-28 03:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:39:30 --> Output Class Initialized
INFO - 2023-04-28 03:39:30 --> Input Class Initialized
INFO - 2023-04-28 03:39:30 --> Security Class Initialized
INFO - 2023-04-28 03:39:30 --> Language Class Initialized
DEBUG - 2023-04-28 03:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:39:30 --> Input Class Initialized
INFO - 2023-04-28 03:39:30 --> Loader Class Initialized
INFO - 2023-04-28 03:39:30 --> Language Class Initialized
INFO - 2023-04-28 03:39:30 --> Controller Class Initialized
INFO - 2023-04-28 03:39:30 --> Loader Class Initialized
DEBUG - 2023-04-28 03:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:39:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:39:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:39:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:39:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:39:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:39:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:39:30 --> Total execution time: 0.0592
INFO - 2023-04-28 03:39:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:39:30 --> Total execution time: 0.0614
INFO - 2023-04-28 03:39:30 --> Config Class Initialized
INFO - 2023-04-28 03:39:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:39:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:39:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:39:30 --> Config Class Initialized
INFO - 2023-04-28 03:39:30 --> URI Class Initialized
INFO - 2023-04-28 03:39:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:39:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:39:30 --> Router Class Initialized
INFO - 2023-04-28 03:39:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:39:30 --> Output Class Initialized
INFO - 2023-04-28 03:39:30 --> URI Class Initialized
INFO - 2023-04-28 03:39:30 --> Security Class Initialized
INFO - 2023-04-28 03:39:30 --> Router Class Initialized
DEBUG - 2023-04-28 03:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:39:30 --> Output Class Initialized
INFO - 2023-04-28 03:39:30 --> Input Class Initialized
INFO - 2023-04-28 03:39:30 --> Security Class Initialized
INFO - 2023-04-28 03:39:30 --> Language Class Initialized
DEBUG - 2023-04-28 03:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:39:30 --> Loader Class Initialized
INFO - 2023-04-28 03:39:30 --> Input Class Initialized
INFO - 2023-04-28 03:39:30 --> Controller Class Initialized
INFO - 2023-04-28 03:39:30 --> Language Class Initialized
DEBUG - 2023-04-28 03:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:39:30 --> Loader Class Initialized
INFO - 2023-04-28 03:39:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:39:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:39:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:39:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:39:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:39:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:39:30 --> Total execution time: 0.0229
INFO - 2023-04-28 03:39:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:39:30 --> Total execution time: 0.0236
INFO - 2023-04-28 03:44:59 --> Config Class Initialized
INFO - 2023-04-28 03:44:59 --> Config Class Initialized
INFO - 2023-04-28 03:44:59 --> Hooks Class Initialized
INFO - 2023-04-28 03:44:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:44:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:44:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:44:59 --> Utf8 Class Initialized
INFO - 2023-04-28 03:44:59 --> Utf8 Class Initialized
INFO - 2023-04-28 03:44:59 --> URI Class Initialized
INFO - 2023-04-28 03:44:59 --> URI Class Initialized
INFO - 2023-04-28 03:44:59 --> Router Class Initialized
INFO - 2023-04-28 03:44:59 --> Router Class Initialized
INFO - 2023-04-28 03:44:59 --> Output Class Initialized
INFO - 2023-04-28 03:44:59 --> Output Class Initialized
INFO - 2023-04-28 03:44:59 --> Security Class Initialized
INFO - 2023-04-28 03:44:59 --> Security Class Initialized
DEBUG - 2023-04-28 03:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:44:59 --> Input Class Initialized
INFO - 2023-04-28 03:44:59 --> Input Class Initialized
INFO - 2023-04-28 03:44:59 --> Language Class Initialized
INFO - 2023-04-28 03:44:59 --> Language Class Initialized
INFO - 2023-04-28 03:44:59 --> Loader Class Initialized
INFO - 2023-04-28 03:44:59 --> Loader Class Initialized
INFO - 2023-04-28 03:44:59 --> Controller Class Initialized
INFO - 2023-04-28 03:44:59 --> Controller Class Initialized
DEBUG - 2023-04-28 03:44:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:44:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:44:59 --> Database Driver Class Initialized
INFO - 2023-04-28 03:44:59 --> Database Driver Class Initialized
INFO - 2023-04-28 03:44:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:44:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:44:59 --> Final output sent to browser
DEBUG - 2023-04-28 03:44:59 --> Total execution time: 0.0631
INFO - 2023-04-28 03:44:59 --> Final output sent to browser
INFO - 2023-04-28 03:44:59 --> Config Class Initialized
DEBUG - 2023-04-28 03:44:59 --> Total execution time: 0.0656
INFO - 2023-04-28 03:44:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:44:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:44:59 --> Utf8 Class Initialized
INFO - 2023-04-28 03:44:59 --> URI Class Initialized
INFO - 2023-04-28 03:44:59 --> Router Class Initialized
INFO - 2023-04-28 03:44:59 --> Output Class Initialized
INFO - 2023-04-28 03:44:59 --> Config Class Initialized
INFO - 2023-04-28 03:44:59 --> Hooks Class Initialized
INFO - 2023-04-28 03:44:59 --> Security Class Initialized
DEBUG - 2023-04-28 03:44:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:44:59 --> Utf8 Class Initialized
DEBUG - 2023-04-28 03:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:44:59 --> URI Class Initialized
INFO - 2023-04-28 03:44:59 --> Input Class Initialized
INFO - 2023-04-28 03:44:59 --> Router Class Initialized
INFO - 2023-04-28 03:44:59 --> Language Class Initialized
INFO - 2023-04-28 03:44:59 --> Output Class Initialized
INFO - 2023-04-28 03:44:59 --> Loader Class Initialized
INFO - 2023-04-28 03:44:59 --> Security Class Initialized
INFO - 2023-04-28 03:44:59 --> Controller Class Initialized
DEBUG - 2023-04-28 03:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:44:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:44:59 --> Input Class Initialized
INFO - 2023-04-28 03:44:59 --> Language Class Initialized
INFO - 2023-04-28 03:44:59 --> Database Driver Class Initialized
INFO - 2023-04-28 03:44:59 --> Loader Class Initialized
INFO - 2023-04-28 03:44:59 --> Controller Class Initialized
DEBUG - 2023-04-28 03:44:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:44:59 --> Database Driver Class Initialized
INFO - 2023-04-28 03:44:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:44:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:44:59 --> Final output sent to browser
DEBUG - 2023-04-28 03:44:59 --> Total execution time: 0.0950
INFO - 2023-04-28 03:44:59 --> Final output sent to browser
DEBUG - 2023-04-28 03:44:59 --> Total execution time: 0.0541
INFO - 2023-04-28 03:45:36 --> Config Class Initialized
INFO - 2023-04-28 03:45:36 --> Config Class Initialized
INFO - 2023-04-28 03:45:36 --> Hooks Class Initialized
INFO - 2023-04-28 03:45:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:45:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:45:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:45:36 --> Utf8 Class Initialized
INFO - 2023-04-28 03:45:36 --> Utf8 Class Initialized
INFO - 2023-04-28 03:45:36 --> URI Class Initialized
INFO - 2023-04-28 03:45:36 --> URI Class Initialized
INFO - 2023-04-28 03:45:36 --> Router Class Initialized
INFO - 2023-04-28 03:45:36 --> Output Class Initialized
INFO - 2023-04-28 03:45:36 --> Security Class Initialized
INFO - 2023-04-28 03:45:36 --> Router Class Initialized
DEBUG - 2023-04-28 03:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:45:36 --> Output Class Initialized
INFO - 2023-04-28 03:45:36 --> Input Class Initialized
INFO - 2023-04-28 03:45:36 --> Security Class Initialized
INFO - 2023-04-28 03:45:36 --> Language Class Initialized
DEBUG - 2023-04-28 03:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:45:36 --> Input Class Initialized
INFO - 2023-04-28 03:45:36 --> Loader Class Initialized
INFO - 2023-04-28 03:45:36 --> Language Class Initialized
INFO - 2023-04-28 03:45:36 --> Controller Class Initialized
DEBUG - 2023-04-28 03:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:45:36 --> Loader Class Initialized
INFO - 2023-04-28 03:45:36 --> Controller Class Initialized
INFO - 2023-04-28 03:45:36 --> Database Driver Class Initialized
DEBUG - 2023-04-28 03:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:45:36 --> Database Driver Class Initialized
INFO - 2023-04-28 03:45:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:45:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:45:36 --> Final output sent to browser
DEBUG - 2023-04-28 03:45:36 --> Total execution time: 0.0589
INFO - 2023-04-28 03:45:36 --> Final output sent to browser
DEBUG - 2023-04-28 03:45:36 --> Total execution time: 0.0612
INFO - 2023-04-28 03:45:36 --> Config Class Initialized
INFO - 2023-04-28 03:45:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:45:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:45:36 --> Utf8 Class Initialized
INFO - 2023-04-28 03:45:36 --> URI Class Initialized
INFO - 2023-04-28 03:45:36 --> Router Class Initialized
INFO - 2023-04-28 03:45:36 --> Output Class Initialized
INFO - 2023-04-28 03:45:36 --> Security Class Initialized
DEBUG - 2023-04-28 03:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:45:36 --> Config Class Initialized
INFO - 2023-04-28 03:45:36 --> Input Class Initialized
INFO - 2023-04-28 03:45:36 --> Hooks Class Initialized
INFO - 2023-04-28 03:45:36 --> Language Class Initialized
DEBUG - 2023-04-28 03:45:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:45:36 --> Loader Class Initialized
INFO - 2023-04-28 03:45:36 --> Utf8 Class Initialized
INFO - 2023-04-28 03:45:36 --> Controller Class Initialized
DEBUG - 2023-04-28 03:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:45:36 --> Database Driver Class Initialized
INFO - 2023-04-28 03:45:36 --> URI Class Initialized
INFO - 2023-04-28 03:45:36 --> Router Class Initialized
INFO - 2023-04-28 03:45:36 --> Output Class Initialized
INFO - 2023-04-28 03:45:36 --> Security Class Initialized
DEBUG - 2023-04-28 03:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:45:36 --> Input Class Initialized
INFO - 2023-04-28 03:45:36 --> Language Class Initialized
INFO - 2023-04-28 03:45:36 --> Loader Class Initialized
INFO - 2023-04-28 03:45:36 --> Controller Class Initialized
DEBUG - 2023-04-28 03:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:45:36 --> Database Driver Class Initialized
INFO - 2023-04-28 03:45:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:45:36 --> Final output sent to browser
DEBUG - 2023-04-28 03:45:36 --> Total execution time: 0.0228
INFO - 2023-04-28 03:45:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:45:36 --> Final output sent to browser
DEBUG - 2023-04-28 03:45:36 --> Total execution time: 0.0666
INFO - 2023-04-28 03:55:30 --> Config Class Initialized
INFO - 2023-04-28 03:55:30 --> Config Class Initialized
INFO - 2023-04-28 03:55:30 --> Hooks Class Initialized
INFO - 2023-04-28 03:55:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:55:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:55:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:55:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:55:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:55:30 --> URI Class Initialized
INFO - 2023-04-28 03:55:30 --> URI Class Initialized
INFO - 2023-04-28 03:55:30 --> Router Class Initialized
INFO - 2023-04-28 03:55:30 --> Router Class Initialized
INFO - 2023-04-28 03:55:30 --> Output Class Initialized
INFO - 2023-04-28 03:55:30 --> Output Class Initialized
INFO - 2023-04-28 03:55:30 --> Security Class Initialized
INFO - 2023-04-28 03:55:30 --> Security Class Initialized
DEBUG - 2023-04-28 03:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:55:30 --> Input Class Initialized
INFO - 2023-04-28 03:55:30 --> Input Class Initialized
INFO - 2023-04-28 03:55:30 --> Language Class Initialized
INFO - 2023-04-28 03:55:30 --> Language Class Initialized
INFO - 2023-04-28 03:55:30 --> Loader Class Initialized
INFO - 2023-04-28 03:55:30 --> Loader Class Initialized
INFO - 2023-04-28 03:55:30 --> Controller Class Initialized
INFO - 2023-04-28 03:55:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:55:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:55:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:55:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:55:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:55:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:55:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:55:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:55:30 --> Total execution time: 0.6550
INFO - 2023-04-28 03:55:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:55:30 --> Total execution time: 0.6573
INFO - 2023-04-28 03:55:30 --> Config Class Initialized
INFO - 2023-04-28 03:55:30 --> Config Class Initialized
INFO - 2023-04-28 03:55:30 --> Hooks Class Initialized
INFO - 2023-04-28 03:55:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:55:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:55:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:55:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:55:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:55:30 --> URI Class Initialized
INFO - 2023-04-28 03:55:30 --> URI Class Initialized
INFO - 2023-04-28 03:55:30 --> Router Class Initialized
INFO - 2023-04-28 03:55:30 --> Router Class Initialized
INFO - 2023-04-28 03:55:30 --> Output Class Initialized
INFO - 2023-04-28 03:55:30 --> Output Class Initialized
INFO - 2023-04-28 03:55:30 --> Security Class Initialized
INFO - 2023-04-28 03:55:30 --> Security Class Initialized
DEBUG - 2023-04-28 03:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 03:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:55:30 --> Input Class Initialized
INFO - 2023-04-28 03:55:30 --> Input Class Initialized
INFO - 2023-04-28 03:55:30 --> Language Class Initialized
INFO - 2023-04-28 03:55:30 --> Language Class Initialized
INFO - 2023-04-28 03:55:30 --> Loader Class Initialized
INFO - 2023-04-28 03:55:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:55:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:55:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:55:30 --> Loader Class Initialized
INFO - 2023-04-28 03:55:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:55:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:55:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:55:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:55:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:55:30 --> Total execution time: 0.0482
INFO - 2023-04-28 03:55:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:55:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:55:30 --> Total execution time: 0.0652
INFO - 2023-04-28 03:56:07 --> Config Class Initialized
INFO - 2023-04-28 03:56:07 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:56:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:56:07 --> Utf8 Class Initialized
INFO - 2023-04-28 03:56:07 --> URI Class Initialized
INFO - 2023-04-28 03:56:07 --> Router Class Initialized
INFO - 2023-04-28 03:56:07 --> Output Class Initialized
INFO - 2023-04-28 03:56:07 --> Security Class Initialized
DEBUG - 2023-04-28 03:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:56:07 --> Input Class Initialized
INFO - 2023-04-28 03:56:07 --> Language Class Initialized
INFO - 2023-04-28 03:56:07 --> Loader Class Initialized
INFO - 2023-04-28 03:56:07 --> Controller Class Initialized
DEBUG - 2023-04-28 03:56:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:56:07 --> Database Driver Class Initialized
INFO - 2023-04-28 03:56:07 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:56:07 --> Final output sent to browser
DEBUG - 2023-04-28 03:56:07 --> Total execution time: 0.0126
INFO - 2023-04-28 03:56:07 --> Config Class Initialized
INFO - 2023-04-28 03:56:07 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:56:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:56:07 --> Utf8 Class Initialized
INFO - 2023-04-28 03:56:07 --> URI Class Initialized
INFO - 2023-04-28 03:56:07 --> Router Class Initialized
INFO - 2023-04-28 03:56:07 --> Output Class Initialized
INFO - 2023-04-28 03:56:07 --> Security Class Initialized
DEBUG - 2023-04-28 03:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:56:07 --> Input Class Initialized
INFO - 2023-04-28 03:56:07 --> Language Class Initialized
INFO - 2023-04-28 03:56:07 --> Loader Class Initialized
INFO - 2023-04-28 03:56:07 --> Controller Class Initialized
DEBUG - 2023-04-28 03:56:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:56:07 --> Database Driver Class Initialized
INFO - 2023-04-28 03:56:07 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:56:07 --> Final output sent to browser
DEBUG - 2023-04-28 03:56:07 --> Total execution time: 0.0547
INFO - 2023-04-28 03:57:19 --> Config Class Initialized
INFO - 2023-04-28 03:57:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:57:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:57:19 --> Utf8 Class Initialized
INFO - 2023-04-28 03:57:19 --> URI Class Initialized
INFO - 2023-04-28 03:57:19 --> Router Class Initialized
INFO - 2023-04-28 03:57:19 --> Output Class Initialized
INFO - 2023-04-28 03:57:19 --> Security Class Initialized
DEBUG - 2023-04-28 03:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:19 --> Input Class Initialized
INFO - 2023-04-28 03:57:19 --> Language Class Initialized
INFO - 2023-04-28 03:57:19 --> Loader Class Initialized
INFO - 2023-04-28 03:57:19 --> Controller Class Initialized
DEBUG - 2023-04-28 03:57:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:57:19 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:57:19 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:19 --> Total execution time: 0.0152
INFO - 2023-04-28 03:57:19 --> Config Class Initialized
INFO - 2023-04-28 03:57:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:57:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:57:19 --> Utf8 Class Initialized
INFO - 2023-04-28 03:57:19 --> URI Class Initialized
INFO - 2023-04-28 03:57:19 --> Router Class Initialized
INFO - 2023-04-28 03:57:19 --> Output Class Initialized
INFO - 2023-04-28 03:57:19 --> Security Class Initialized
DEBUG - 2023-04-28 03:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:19 --> Input Class Initialized
INFO - 2023-04-28 03:57:19 --> Language Class Initialized
INFO - 2023-04-28 03:57:19 --> Loader Class Initialized
INFO - 2023-04-28 03:57:19 --> Controller Class Initialized
DEBUG - 2023-04-28 03:57:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:57:19 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:57:19 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:19 --> Total execution time: 0.0537
INFO - 2023-04-28 03:57:21 --> Config Class Initialized
INFO - 2023-04-28 03:57:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:57:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:57:21 --> Utf8 Class Initialized
INFO - 2023-04-28 03:57:21 --> URI Class Initialized
INFO - 2023-04-28 03:57:21 --> Router Class Initialized
INFO - 2023-04-28 03:57:21 --> Output Class Initialized
INFO - 2023-04-28 03:57:21 --> Security Class Initialized
DEBUG - 2023-04-28 03:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:21 --> Input Class Initialized
INFO - 2023-04-28 03:57:21 --> Language Class Initialized
INFO - 2023-04-28 03:57:21 --> Loader Class Initialized
INFO - 2023-04-28 03:57:21 --> Controller Class Initialized
DEBUG - 2023-04-28 03:57:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:57:21 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:57:21 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:21 --> Total execution time: 0.0174
INFO - 2023-04-28 03:57:21 --> Config Class Initialized
INFO - 2023-04-28 03:57:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:57:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:57:21 --> Utf8 Class Initialized
INFO - 2023-04-28 03:57:21 --> URI Class Initialized
INFO - 2023-04-28 03:57:21 --> Router Class Initialized
INFO - 2023-04-28 03:57:21 --> Output Class Initialized
INFO - 2023-04-28 03:57:21 --> Security Class Initialized
DEBUG - 2023-04-28 03:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:21 --> Input Class Initialized
INFO - 2023-04-28 03:57:21 --> Language Class Initialized
INFO - 2023-04-28 03:57:21 --> Loader Class Initialized
INFO - 2023-04-28 03:57:21 --> Controller Class Initialized
DEBUG - 2023-04-28 03:57:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:57:21 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:57:21 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:21 --> Total execution time: 0.0122
INFO - 2023-04-28 03:57:23 --> Config Class Initialized
INFO - 2023-04-28 03:57:23 --> Hooks Class Initialized
INFO - 2023-04-28 03:57:23 --> Config Class Initialized
DEBUG - 2023-04-28 03:57:23 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:57:23 --> Hooks Class Initialized
INFO - 2023-04-28 03:57:23 --> Utf8 Class Initialized
DEBUG - 2023-04-28 03:57:23 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:57:23 --> URI Class Initialized
INFO - 2023-04-28 03:57:23 --> Utf8 Class Initialized
INFO - 2023-04-28 03:57:23 --> Router Class Initialized
INFO - 2023-04-28 03:57:23 --> URI Class Initialized
INFO - 2023-04-28 03:57:23 --> Output Class Initialized
INFO - 2023-04-28 03:57:23 --> Router Class Initialized
INFO - 2023-04-28 03:57:23 --> Security Class Initialized
INFO - 2023-04-28 03:57:23 --> Output Class Initialized
DEBUG - 2023-04-28 03:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:23 --> Security Class Initialized
INFO - 2023-04-28 03:57:23 --> Input Class Initialized
DEBUG - 2023-04-28 03:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:23 --> Language Class Initialized
INFO - 2023-04-28 03:57:23 --> Input Class Initialized
INFO - 2023-04-28 03:57:23 --> Language Class Initialized
INFO - 2023-04-28 03:57:23 --> Loader Class Initialized
INFO - 2023-04-28 03:57:23 --> Loader Class Initialized
INFO - 2023-04-28 03:57:23 --> Controller Class Initialized
INFO - 2023-04-28 03:57:23 --> Controller Class Initialized
DEBUG - 2023-04-28 03:57:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:57:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:57:23 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:23 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:23 --> Total execution time: 0.0043
INFO - 2023-04-28 03:57:23 --> Config Class Initialized
INFO - 2023-04-28 03:57:23 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:57:23 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:57:23 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:57:23 --> Utf8 Class Initialized
INFO - 2023-04-28 03:57:23 --> URI Class Initialized
INFO - 2023-04-28 03:57:23 --> Router Class Initialized
INFO - 2023-04-28 03:57:23 --> Output Class Initialized
INFO - 2023-04-28 03:57:23 --> Security Class Initialized
DEBUG - 2023-04-28 03:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:23 --> Input Class Initialized
INFO - 2023-04-28 03:57:23 --> Language Class Initialized
INFO - 2023-04-28 03:57:23 --> Loader Class Initialized
INFO - 2023-04-28 03:57:23 --> Controller Class Initialized
DEBUG - 2023-04-28 03:57:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:57:23 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:23 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:23 --> Total execution time: 0.0493
INFO - 2023-04-28 03:57:23 --> Config Class Initialized
INFO - 2023-04-28 03:57:23 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:57:23 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:57:23 --> Utf8 Class Initialized
INFO - 2023-04-28 03:57:23 --> URI Class Initialized
INFO - 2023-04-28 03:57:23 --> Router Class Initialized
INFO - 2023-04-28 03:57:23 --> Output Class Initialized
INFO - 2023-04-28 03:57:23 --> Security Class Initialized
DEBUG - 2023-04-28 03:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:23 --> Input Class Initialized
INFO - 2023-04-28 03:57:23 --> Language Class Initialized
INFO - 2023-04-28 03:57:23 --> Loader Class Initialized
INFO - 2023-04-28 03:57:23 --> Controller Class Initialized
DEBUG - 2023-04-28 03:57:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:57:23 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:23 --> Model "Login_model" initialized
INFO - 2023-04-28 03:57:23 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:24 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:57:24 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:24 --> Total execution time: 0.0150
INFO - 2023-04-28 03:57:24 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:57:24 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:24 --> Total execution time: 0.1042
INFO - 2023-04-28 03:57:26 --> Config Class Initialized
INFO - 2023-04-28 03:57:26 --> Config Class Initialized
INFO - 2023-04-28 03:57:26 --> Hooks Class Initialized
INFO - 2023-04-28 03:57:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:57:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:57:26 --> Utf8 Class Initialized
DEBUG - 2023-04-28 03:57:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:57:26 --> URI Class Initialized
INFO - 2023-04-28 03:57:26 --> Utf8 Class Initialized
INFO - 2023-04-28 03:57:26 --> Router Class Initialized
INFO - 2023-04-28 03:57:26 --> URI Class Initialized
INFO - 2023-04-28 03:57:26 --> Output Class Initialized
INFO - 2023-04-28 03:57:26 --> Router Class Initialized
INFO - 2023-04-28 03:57:26 --> Security Class Initialized
INFO - 2023-04-28 03:57:26 --> Output Class Initialized
DEBUG - 2023-04-28 03:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:26 --> Security Class Initialized
INFO - 2023-04-28 03:57:26 --> Input Class Initialized
DEBUG - 2023-04-28 03:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:26 --> Language Class Initialized
INFO - 2023-04-28 03:57:26 --> Input Class Initialized
INFO - 2023-04-28 03:57:26 --> Language Class Initialized
INFO - 2023-04-28 03:57:26 --> Loader Class Initialized
INFO - 2023-04-28 03:57:26 --> Loader Class Initialized
INFO - 2023-04-28 03:57:26 --> Controller Class Initialized
INFO - 2023-04-28 03:57:26 --> Controller Class Initialized
DEBUG - 2023-04-28 03:57:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 03:57:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:57:26 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:26 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:57:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:57:26 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:26 --> Total execution time: 0.0186
INFO - 2023-04-28 03:57:26 --> Config Class Initialized
INFO - 2023-04-28 03:57:26 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:26 --> Total execution time: 0.0210
INFO - 2023-04-28 03:57:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:57:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:57:26 --> Utf8 Class Initialized
INFO - 2023-04-28 03:57:26 --> URI Class Initialized
INFO - 2023-04-28 03:57:26 --> Router Class Initialized
INFO - 2023-04-28 03:57:26 --> Output Class Initialized
INFO - 2023-04-28 03:57:26 --> Security Class Initialized
DEBUG - 2023-04-28 03:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:26 --> Input Class Initialized
INFO - 2023-04-28 03:57:26 --> Language Class Initialized
INFO - 2023-04-28 03:57:26 --> Config Class Initialized
INFO - 2023-04-28 03:57:26 --> Loader Class Initialized
INFO - 2023-04-28 03:57:26 --> Hooks Class Initialized
INFO - 2023-04-28 03:57:26 --> Controller Class Initialized
DEBUG - 2023-04-28 03:57:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 03:57:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:57:26 --> Utf8 Class Initialized
INFO - 2023-04-28 03:57:26 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:26 --> URI Class Initialized
INFO - 2023-04-28 03:57:26 --> Router Class Initialized
INFO - 2023-04-28 03:57:26 --> Output Class Initialized
INFO - 2023-04-28 03:57:26 --> Security Class Initialized
DEBUG - 2023-04-28 03:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:26 --> Input Class Initialized
INFO - 2023-04-28 03:57:26 --> Language Class Initialized
INFO - 2023-04-28 03:57:26 --> Loader Class Initialized
INFO - 2023-04-28 03:57:26 --> Controller Class Initialized
DEBUG - 2023-04-28 03:57:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:57:26 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:57:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:57:26 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:26 --> Total execution time: 0.0557
INFO - 2023-04-28 03:57:26 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:26 --> Total execution time: 0.0175
INFO - 2023-04-28 03:57:30 --> Config Class Initialized
INFO - 2023-04-28 03:57:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:57:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:57:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:57:30 --> URI Class Initialized
INFO - 2023-04-28 03:57:30 --> Router Class Initialized
INFO - 2023-04-28 03:57:30 --> Output Class Initialized
INFO - 2023-04-28 03:57:30 --> Security Class Initialized
DEBUG - 2023-04-28 03:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:30 --> Input Class Initialized
INFO - 2023-04-28 03:57:30 --> Language Class Initialized
INFO - 2023-04-28 03:57:30 --> Loader Class Initialized
INFO - 2023-04-28 03:57:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:57:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:57:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:57:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:30 --> Total execution time: 0.0151
INFO - 2023-04-28 03:57:30 --> Config Class Initialized
INFO - 2023-04-28 03:57:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 03:57:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 03:57:30 --> Utf8 Class Initialized
INFO - 2023-04-28 03:57:30 --> URI Class Initialized
INFO - 2023-04-28 03:57:30 --> Router Class Initialized
INFO - 2023-04-28 03:57:30 --> Output Class Initialized
INFO - 2023-04-28 03:57:30 --> Security Class Initialized
DEBUG - 2023-04-28 03:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 03:57:30 --> Input Class Initialized
INFO - 2023-04-28 03:57:30 --> Language Class Initialized
INFO - 2023-04-28 03:57:30 --> Loader Class Initialized
INFO - 2023-04-28 03:57:30 --> Controller Class Initialized
DEBUG - 2023-04-28 03:57:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 03:57:30 --> Database Driver Class Initialized
INFO - 2023-04-28 03:57:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 03:57:30 --> Final output sent to browser
DEBUG - 2023-04-28 03:57:30 --> Total execution time: 0.0505
INFO - 2023-04-28 04:33:31 --> Config Class Initialized
INFO - 2023-04-28 04:33:31 --> Hooks Class Initialized
DEBUG - 2023-04-28 04:33:31 --> UTF-8 Support Enabled
INFO - 2023-04-28 04:33:31 --> Utf8 Class Initialized
INFO - 2023-04-28 04:33:31 --> URI Class Initialized
INFO - 2023-04-28 04:33:31 --> Router Class Initialized
INFO - 2023-04-28 04:33:31 --> Output Class Initialized
INFO - 2023-04-28 04:33:31 --> Security Class Initialized
DEBUG - 2023-04-28 04:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 04:33:31 --> Input Class Initialized
INFO - 2023-04-28 04:33:31 --> Language Class Initialized
INFO - 2023-04-28 04:33:31 --> Loader Class Initialized
INFO - 2023-04-28 04:33:31 --> Controller Class Initialized
DEBUG - 2023-04-28 04:33:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 04:33:31 --> Database Driver Class Initialized
INFO - 2023-04-28 04:33:31 --> Model "Cluster_model" initialized
INFO - 2023-04-28 04:33:31 --> Final output sent to browser
DEBUG - 2023-04-28 04:33:31 --> Total execution time: 0.0275
INFO - 2023-04-28 04:33:31 --> Config Class Initialized
INFO - 2023-04-28 04:33:31 --> Hooks Class Initialized
DEBUG - 2023-04-28 04:33:31 --> UTF-8 Support Enabled
INFO - 2023-04-28 04:33:31 --> Utf8 Class Initialized
INFO - 2023-04-28 04:33:31 --> URI Class Initialized
INFO - 2023-04-28 04:33:31 --> Router Class Initialized
INFO - 2023-04-28 04:33:31 --> Output Class Initialized
INFO - 2023-04-28 04:33:31 --> Security Class Initialized
DEBUG - 2023-04-28 04:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 04:33:31 --> Input Class Initialized
INFO - 2023-04-28 04:33:31 --> Language Class Initialized
INFO - 2023-04-28 04:33:31 --> Loader Class Initialized
INFO - 2023-04-28 04:33:31 --> Controller Class Initialized
DEBUG - 2023-04-28 04:33:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 04:33:31 --> Database Driver Class Initialized
INFO - 2023-04-28 04:33:31 --> Model "Cluster_model" initialized
INFO - 2023-04-28 04:33:31 --> Final output sent to browser
DEBUG - 2023-04-28 04:33:31 --> Total execution time: 0.0595
INFO - 2023-04-28 04:33:33 --> Config Class Initialized
INFO - 2023-04-28 04:33:33 --> Config Class Initialized
INFO - 2023-04-28 04:33:33 --> Hooks Class Initialized
INFO - 2023-04-28 04:33:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 04:33:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 04:33:33 --> Utf8 Class Initialized
DEBUG - 2023-04-28 04:33:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 04:33:33 --> URI Class Initialized
INFO - 2023-04-28 04:33:33 --> Utf8 Class Initialized
INFO - 2023-04-28 04:33:33 --> Router Class Initialized
INFO - 2023-04-28 04:33:33 --> URI Class Initialized
INFO - 2023-04-28 04:33:33 --> Output Class Initialized
INFO - 2023-04-28 04:33:33 --> Router Class Initialized
INFO - 2023-04-28 04:33:33 --> Security Class Initialized
INFO - 2023-04-28 04:33:33 --> Output Class Initialized
DEBUG - 2023-04-28 04:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 04:33:33 --> Security Class Initialized
INFO - 2023-04-28 04:33:33 --> Input Class Initialized
DEBUG - 2023-04-28 04:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 04:33:33 --> Language Class Initialized
INFO - 2023-04-28 04:33:33 --> Input Class Initialized
INFO - 2023-04-28 04:33:33 --> Language Class Initialized
INFO - 2023-04-28 04:33:33 --> Loader Class Initialized
INFO - 2023-04-28 04:33:33 --> Loader Class Initialized
INFO - 2023-04-28 04:33:33 --> Controller Class Initialized
INFO - 2023-04-28 04:33:33 --> Controller Class Initialized
DEBUG - 2023-04-28 04:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 04:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 04:33:33 --> Final output sent to browser
DEBUG - 2023-04-28 04:33:33 --> Total execution time: 0.0023
INFO - 2023-04-28 04:33:33 --> Database Driver Class Initialized
INFO - 2023-04-28 04:33:33 --> Config Class Initialized
INFO - 2023-04-28 04:33:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 04:33:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 04:33:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 04:33:33 --> Utf8 Class Initialized
INFO - 2023-04-28 04:33:33 --> URI Class Initialized
INFO - 2023-04-28 04:33:33 --> Router Class Initialized
INFO - 2023-04-28 04:33:33 --> Output Class Initialized
INFO - 2023-04-28 04:33:33 --> Security Class Initialized
DEBUG - 2023-04-28 04:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 04:33:33 --> Input Class Initialized
INFO - 2023-04-28 04:33:33 --> Language Class Initialized
INFO - 2023-04-28 04:33:33 --> Loader Class Initialized
INFO - 2023-04-28 04:33:33 --> Controller Class Initialized
DEBUG - 2023-04-28 04:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 04:33:33 --> Database Driver Class Initialized
INFO - 2023-04-28 04:33:33 --> Final output sent to browser
DEBUG - 2023-04-28 04:33:33 --> Total execution time: 0.0416
INFO - 2023-04-28 04:33:33 --> Model "Login_model" initialized
INFO - 2023-04-28 04:33:33 --> Config Class Initialized
INFO - 2023-04-28 04:33:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 04:33:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 04:33:33 --> Utf8 Class Initialized
INFO - 2023-04-28 04:33:33 --> URI Class Initialized
INFO - 2023-04-28 04:33:33 --> Router Class Initialized
INFO - 2023-04-28 04:33:33 --> Output Class Initialized
INFO - 2023-04-28 04:33:33 --> Security Class Initialized
DEBUG - 2023-04-28 04:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 04:33:33 --> Input Class Initialized
INFO - 2023-04-28 04:33:33 --> Language Class Initialized
INFO - 2023-04-28 04:33:33 --> Database Driver Class Initialized
INFO - 2023-04-28 04:33:33 --> Loader Class Initialized
INFO - 2023-04-28 04:33:33 --> Controller Class Initialized
DEBUG - 2023-04-28 04:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 04:33:33 --> Database Driver Class Initialized
INFO - 2023-04-28 04:33:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 04:33:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 04:33:33 --> Final output sent to browser
DEBUG - 2023-04-28 04:33:33 --> Total execution time: 0.0523
INFO - 2023-04-28 04:33:33 --> Final output sent to browser
DEBUG - 2023-04-28 04:33:33 --> Total execution time: 0.0152
INFO - 2023-04-28 05:52:07 --> Config Class Initialized
INFO - 2023-04-28 05:52:07 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:52:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:52:07 --> Utf8 Class Initialized
INFO - 2023-04-28 05:52:07 --> URI Class Initialized
INFO - 2023-04-28 05:52:07 --> Router Class Initialized
INFO - 2023-04-28 05:52:07 --> Output Class Initialized
INFO - 2023-04-28 05:52:07 --> Security Class Initialized
DEBUG - 2023-04-28 05:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:52:07 --> Input Class Initialized
INFO - 2023-04-28 05:52:07 --> Language Class Initialized
INFO - 2023-04-28 05:52:07 --> Loader Class Initialized
INFO - 2023-04-28 05:52:07 --> Controller Class Initialized
DEBUG - 2023-04-28 05:52:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:52:07 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:07 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:52:07 --> Final output sent to browser
DEBUG - 2023-04-28 05:52:07 --> Total execution time: 0.0186
INFO - 2023-04-28 05:52:07 --> Config Class Initialized
INFO - 2023-04-28 05:52:07 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:52:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:52:07 --> Utf8 Class Initialized
INFO - 2023-04-28 05:52:07 --> URI Class Initialized
INFO - 2023-04-28 05:52:07 --> Router Class Initialized
INFO - 2023-04-28 05:52:07 --> Output Class Initialized
INFO - 2023-04-28 05:52:07 --> Security Class Initialized
DEBUG - 2023-04-28 05:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:52:07 --> Input Class Initialized
INFO - 2023-04-28 05:52:07 --> Language Class Initialized
INFO - 2023-04-28 05:52:07 --> Loader Class Initialized
INFO - 2023-04-28 05:52:07 --> Controller Class Initialized
DEBUG - 2023-04-28 05:52:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:52:07 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:07 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:52:07 --> Final output sent to browser
DEBUG - 2023-04-28 05:52:07 --> Total execution time: 0.0576
INFO - 2023-04-28 05:52:09 --> Config Class Initialized
INFO - 2023-04-28 05:52:09 --> Config Class Initialized
INFO - 2023-04-28 05:52:09 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:52:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:52:09 --> Utf8 Class Initialized
INFO - 2023-04-28 05:52:09 --> Hooks Class Initialized
INFO - 2023-04-28 05:52:09 --> URI Class Initialized
DEBUG - 2023-04-28 05:52:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:52:09 --> Router Class Initialized
INFO - 2023-04-28 05:52:09 --> Utf8 Class Initialized
INFO - 2023-04-28 05:52:09 --> Output Class Initialized
INFO - 2023-04-28 05:52:09 --> URI Class Initialized
INFO - 2023-04-28 05:52:09 --> Security Class Initialized
INFO - 2023-04-28 05:52:09 --> Router Class Initialized
DEBUG - 2023-04-28 05:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:52:09 --> Input Class Initialized
INFO - 2023-04-28 05:52:09 --> Output Class Initialized
INFO - 2023-04-28 05:52:09 --> Language Class Initialized
INFO - 2023-04-28 05:52:09 --> Security Class Initialized
INFO - 2023-04-28 05:52:09 --> Loader Class Initialized
INFO - 2023-04-28 05:52:09 --> Controller Class Initialized
DEBUG - 2023-04-28 05:52:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 05:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:52:09 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:09 --> Input Class Initialized
INFO - 2023-04-28 05:52:09 --> Language Class Initialized
INFO - 2023-04-28 05:52:09 --> Loader Class Initialized
INFO - 2023-04-28 05:52:09 --> Controller Class Initialized
DEBUG - 2023-04-28 05:52:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:52:09 --> Final output sent to browser
DEBUG - 2023-04-28 05:52:09 --> Total execution time: 0.0987
INFO - 2023-04-28 05:52:09 --> Config Class Initialized
INFO - 2023-04-28 05:52:09 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:52:09 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:52:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:52:09 --> Utf8 Class Initialized
INFO - 2023-04-28 05:52:09 --> URI Class Initialized
INFO - 2023-04-28 05:52:09 --> Router Class Initialized
INFO - 2023-04-28 05:52:09 --> Output Class Initialized
INFO - 2023-04-28 05:52:09 --> Security Class Initialized
DEBUG - 2023-04-28 05:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:52:09 --> Input Class Initialized
INFO - 2023-04-28 05:52:09 --> Language Class Initialized
INFO - 2023-04-28 05:52:09 --> Loader Class Initialized
INFO - 2023-04-28 05:52:09 --> Controller Class Initialized
DEBUG - 2023-04-28 05:52:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:52:09 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:09 --> Final output sent to browser
DEBUG - 2023-04-28 05:52:09 --> Total execution time: 0.1304
INFO - 2023-04-28 05:52:09 --> Config Class Initialized
INFO - 2023-04-28 05:52:09 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:52:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:52:09 --> Utf8 Class Initialized
INFO - 2023-04-28 05:52:09 --> URI Class Initialized
INFO - 2023-04-28 05:52:09 --> Router Class Initialized
INFO - 2023-04-28 05:52:09 --> Output Class Initialized
INFO - 2023-04-28 05:52:09 --> Security Class Initialized
DEBUG - 2023-04-28 05:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:52:09 --> Input Class Initialized
INFO - 2023-04-28 05:52:09 --> Language Class Initialized
INFO - 2023-04-28 05:52:09 --> Loader Class Initialized
INFO - 2023-04-28 05:52:09 --> Controller Class Initialized
DEBUG - 2023-04-28 05:52:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:52:09 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:09 --> Model "Login_model" initialized
INFO - 2023-04-28 05:52:09 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:09 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:52:09 --> Final output sent to browser
INFO - 2023-04-28 05:52:09 --> Model "Cluster_model" initialized
DEBUG - 2023-04-28 05:52:09 --> Total execution time: 0.0135
INFO - 2023-04-28 05:52:09 --> Final output sent to browser
DEBUG - 2023-04-28 05:52:09 --> Total execution time: 0.0877
INFO - 2023-04-28 05:52:10 --> Config Class Initialized
INFO - 2023-04-28 05:52:10 --> Config Class Initialized
INFO - 2023-04-28 05:52:10 --> Hooks Class Initialized
INFO - 2023-04-28 05:52:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:52:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 05:52:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:52:10 --> Utf8 Class Initialized
INFO - 2023-04-28 05:52:10 --> Utf8 Class Initialized
INFO - 2023-04-28 05:52:10 --> URI Class Initialized
INFO - 2023-04-28 05:52:10 --> URI Class Initialized
INFO - 2023-04-28 05:52:10 --> Router Class Initialized
INFO - 2023-04-28 05:52:10 --> Router Class Initialized
INFO - 2023-04-28 05:52:10 --> Output Class Initialized
INFO - 2023-04-28 05:52:10 --> Output Class Initialized
INFO - 2023-04-28 05:52:10 --> Security Class Initialized
INFO - 2023-04-28 05:52:10 --> Security Class Initialized
DEBUG - 2023-04-28 05:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 05:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:52:10 --> Input Class Initialized
INFO - 2023-04-28 05:52:10 --> Input Class Initialized
INFO - 2023-04-28 05:52:10 --> Language Class Initialized
INFO - 2023-04-28 05:52:10 --> Language Class Initialized
INFO - 2023-04-28 05:52:10 --> Loader Class Initialized
INFO - 2023-04-28 05:52:10 --> Loader Class Initialized
INFO - 2023-04-28 05:52:10 --> Controller Class Initialized
INFO - 2023-04-28 05:52:10 --> Controller Class Initialized
DEBUG - 2023-04-28 05:52:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 05:52:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:52:10 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:10 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:52:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:52:10 --> Final output sent to browser
DEBUG - 2023-04-28 05:52:10 --> Total execution time: 0.0539
INFO - 2023-04-28 05:52:10 --> Final output sent to browser
INFO - 2023-04-28 05:52:10 --> Config Class Initialized
DEBUG - 2023-04-28 05:52:10 --> Total execution time: 0.0557
INFO - 2023-04-28 05:52:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:52:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:52:10 --> Utf8 Class Initialized
INFO - 2023-04-28 05:52:10 --> URI Class Initialized
INFO - 2023-04-28 05:52:10 --> Router Class Initialized
INFO - 2023-04-28 05:52:10 --> Output Class Initialized
INFO - 2023-04-28 05:52:10 --> Security Class Initialized
DEBUG - 2023-04-28 05:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:52:10 --> Input Class Initialized
INFO - 2023-04-28 05:52:10 --> Language Class Initialized
INFO - 2023-04-28 05:52:10 --> Config Class Initialized
INFO - 2023-04-28 05:52:10 --> Hooks Class Initialized
INFO - 2023-04-28 05:52:10 --> Loader Class Initialized
DEBUG - 2023-04-28 05:52:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:52:10 --> Controller Class Initialized
INFO - 2023-04-28 05:52:10 --> Utf8 Class Initialized
DEBUG - 2023-04-28 05:52:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:52:10 --> URI Class Initialized
INFO - 2023-04-28 05:52:10 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:10 --> Router Class Initialized
INFO - 2023-04-28 05:52:10 --> Output Class Initialized
INFO - 2023-04-28 05:52:10 --> Security Class Initialized
DEBUG - 2023-04-28 05:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:52:10 --> Input Class Initialized
INFO - 2023-04-28 05:52:10 --> Language Class Initialized
INFO - 2023-04-28 05:52:10 --> Loader Class Initialized
INFO - 2023-04-28 05:52:10 --> Controller Class Initialized
DEBUG - 2023-04-28 05:52:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:52:10 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:52:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:52:10 --> Final output sent to browser
DEBUG - 2023-04-28 05:52:10 --> Total execution time: 0.0572
INFO - 2023-04-28 05:52:10 --> Final output sent to browser
DEBUG - 2023-04-28 05:52:10 --> Total execution time: 0.0181
INFO - 2023-04-28 05:52:21 --> Config Class Initialized
INFO - 2023-04-28 05:52:21 --> Config Class Initialized
INFO - 2023-04-28 05:52:21 --> Hooks Class Initialized
INFO - 2023-04-28 05:52:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:52:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 05:52:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:52:21 --> Utf8 Class Initialized
INFO - 2023-04-28 05:52:21 --> Utf8 Class Initialized
INFO - 2023-04-28 05:52:21 --> URI Class Initialized
INFO - 2023-04-28 05:52:21 --> URI Class Initialized
INFO - 2023-04-28 05:52:21 --> Router Class Initialized
INFO - 2023-04-28 05:52:21 --> Router Class Initialized
INFO - 2023-04-28 05:52:21 --> Output Class Initialized
INFO - 2023-04-28 05:52:21 --> Output Class Initialized
INFO - 2023-04-28 05:52:21 --> Security Class Initialized
INFO - 2023-04-28 05:52:21 --> Security Class Initialized
DEBUG - 2023-04-28 05:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 05:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:52:21 --> Input Class Initialized
INFO - 2023-04-28 05:52:21 --> Input Class Initialized
INFO - 2023-04-28 05:52:21 --> Language Class Initialized
INFO - 2023-04-28 05:52:21 --> Language Class Initialized
INFO - 2023-04-28 05:52:21 --> Loader Class Initialized
INFO - 2023-04-28 05:52:21 --> Loader Class Initialized
INFO - 2023-04-28 05:52:21 --> Controller Class Initialized
INFO - 2023-04-28 05:52:21 --> Controller Class Initialized
DEBUG - 2023-04-28 05:52:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 05:52:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:52:21 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:21 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:52:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:52:21 --> Final output sent to browser
DEBUG - 2023-04-28 05:52:21 --> Total execution time: 0.1467
INFO - 2023-04-28 05:52:21 --> Config Class Initialized
INFO - 2023-04-28 05:52:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:52:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:52:21 --> Utf8 Class Initialized
INFO - 2023-04-28 05:52:21 --> URI Class Initialized
INFO - 2023-04-28 05:52:21 --> Router Class Initialized
INFO - 2023-04-28 05:52:21 --> Output Class Initialized
INFO - 2023-04-28 05:52:21 --> Security Class Initialized
DEBUG - 2023-04-28 05:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:52:21 --> Input Class Initialized
INFO - 2023-04-28 05:52:21 --> Language Class Initialized
INFO - 2023-04-28 05:52:21 --> Final output sent to browser
INFO - 2023-04-28 05:52:21 --> Loader Class Initialized
DEBUG - 2023-04-28 05:52:21 --> Total execution time: 0.1519
INFO - 2023-04-28 05:52:21 --> Controller Class Initialized
DEBUG - 2023-04-28 05:52:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:52:21 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:21 --> Config Class Initialized
INFO - 2023-04-28 05:52:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:52:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:52:21 --> Utf8 Class Initialized
INFO - 2023-04-28 05:52:21 --> URI Class Initialized
INFO - 2023-04-28 05:52:21 --> Router Class Initialized
INFO - 2023-04-28 05:52:21 --> Output Class Initialized
INFO - 2023-04-28 05:52:21 --> Security Class Initialized
DEBUG - 2023-04-28 05:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:52:21 --> Input Class Initialized
INFO - 2023-04-28 05:52:21 --> Language Class Initialized
INFO - 2023-04-28 05:52:21 --> Loader Class Initialized
INFO - 2023-04-28 05:52:21 --> Controller Class Initialized
DEBUG - 2023-04-28 05:52:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:52:21 --> Database Driver Class Initialized
INFO - 2023-04-28 05:52:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:52:21 --> Final output sent to browser
DEBUG - 2023-04-28 05:52:21 --> Total execution time: 0.0175
INFO - 2023-04-28 05:52:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:52:21 --> Final output sent to browser
DEBUG - 2023-04-28 05:52:21 --> Total execution time: 0.0539
INFO - 2023-04-28 05:54:50 --> Config Class Initialized
INFO - 2023-04-28 05:54:50 --> Config Class Initialized
INFO - 2023-04-28 05:54:50 --> Hooks Class Initialized
INFO - 2023-04-28 05:54:50 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:54:50 --> Utf8 Class Initialized
INFO - 2023-04-28 05:54:50 --> URI Class Initialized
DEBUG - 2023-04-28 05:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:54:50 --> Router Class Initialized
INFO - 2023-04-28 05:54:50 --> Output Class Initialized
INFO - 2023-04-28 05:54:50 --> Security Class Initialized
INFO - 2023-04-28 05:54:50 --> Utf8 Class Initialized
DEBUG - 2023-04-28 05:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:54:50 --> URI Class Initialized
INFO - 2023-04-28 05:54:50 --> Input Class Initialized
INFO - 2023-04-28 05:54:50 --> Router Class Initialized
INFO - 2023-04-28 05:54:50 --> Output Class Initialized
INFO - 2023-04-28 05:54:50 --> Security Class Initialized
DEBUG - 2023-04-28 05:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:54:50 --> Input Class Initialized
INFO - 2023-04-28 05:54:50 --> Language Class Initialized
INFO - 2023-04-28 05:54:50 --> Language Class Initialized
INFO - 2023-04-28 05:54:50 --> Loader Class Initialized
INFO - 2023-04-28 05:54:50 --> Loader Class Initialized
INFO - 2023-04-28 05:54:50 --> Controller Class Initialized
INFO - 2023-04-28 05:54:50 --> Controller Class Initialized
DEBUG - 2023-04-28 05:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 05:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:54:50 --> Database Driver Class Initialized
INFO - 2023-04-28 05:54:50 --> Database Driver Class Initialized
INFO - 2023-04-28 05:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:54:50 --> Final output sent to browser
DEBUG - 2023-04-28 05:54:50 --> Total execution time: 0.0448
INFO - 2023-04-28 05:54:50 --> Final output sent to browser
DEBUG - 2023-04-28 05:54:50 --> Total execution time: 0.0875
INFO - 2023-04-28 05:54:50 --> Config Class Initialized
INFO - 2023-04-28 05:54:50 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:54:50 --> Utf8 Class Initialized
INFO - 2023-04-28 05:54:50 --> URI Class Initialized
INFO - 2023-04-28 05:54:50 --> Router Class Initialized
INFO - 2023-04-28 05:54:50 --> Output Class Initialized
INFO - 2023-04-28 05:54:50 --> Config Class Initialized
INFO - 2023-04-28 05:54:50 --> Security Class Initialized
INFO - 2023-04-28 05:54:50 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 05:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:54:50 --> Input Class Initialized
INFO - 2023-04-28 05:54:50 --> Utf8 Class Initialized
INFO - 2023-04-28 05:54:50 --> Language Class Initialized
INFO - 2023-04-28 05:54:50 --> URI Class Initialized
INFO - 2023-04-28 05:54:50 --> Loader Class Initialized
INFO - 2023-04-28 05:54:50 --> Router Class Initialized
INFO - 2023-04-28 05:54:50 --> Controller Class Initialized
INFO - 2023-04-28 05:54:50 --> Output Class Initialized
DEBUG - 2023-04-28 05:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:54:50 --> Security Class Initialized
DEBUG - 2023-04-28 05:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:54:50 --> Database Driver Class Initialized
INFO - 2023-04-28 05:54:50 --> Input Class Initialized
INFO - 2023-04-28 05:54:50 --> Language Class Initialized
INFO - 2023-04-28 05:54:50 --> Loader Class Initialized
INFO - 2023-04-28 05:54:50 --> Controller Class Initialized
DEBUG - 2023-04-28 05:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:54:50 --> Database Driver Class Initialized
INFO - 2023-04-28 05:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:54:50 --> Final output sent to browser
DEBUG - 2023-04-28 05:54:50 --> Total execution time: 0.0557
INFO - 2023-04-28 05:54:50 --> Final output sent to browser
DEBUG - 2023-04-28 05:54:50 --> Total execution time: 0.0607
INFO - 2023-04-28 05:59:08 --> Config Class Initialized
INFO - 2023-04-28 05:59:08 --> Config Class Initialized
INFO - 2023-04-28 05:59:08 --> Hooks Class Initialized
INFO - 2023-04-28 05:59:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 05:59:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:59:08 --> Utf8 Class Initialized
INFO - 2023-04-28 05:59:08 --> Utf8 Class Initialized
INFO - 2023-04-28 05:59:08 --> URI Class Initialized
INFO - 2023-04-28 05:59:08 --> URI Class Initialized
INFO - 2023-04-28 05:59:08 --> Router Class Initialized
INFO - 2023-04-28 05:59:08 --> Router Class Initialized
INFO - 2023-04-28 05:59:08 --> Output Class Initialized
INFO - 2023-04-28 05:59:08 --> Output Class Initialized
INFO - 2023-04-28 05:59:08 --> Security Class Initialized
INFO - 2023-04-28 05:59:08 --> Security Class Initialized
DEBUG - 2023-04-28 05:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 05:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:59:08 --> Input Class Initialized
INFO - 2023-04-28 05:59:08 --> Input Class Initialized
INFO - 2023-04-28 05:59:08 --> Language Class Initialized
INFO - 2023-04-28 05:59:08 --> Language Class Initialized
INFO - 2023-04-28 05:59:08 --> Loader Class Initialized
INFO - 2023-04-28 05:59:08 --> Loader Class Initialized
INFO - 2023-04-28 05:59:08 --> Controller Class Initialized
INFO - 2023-04-28 05:59:08 --> Controller Class Initialized
DEBUG - 2023-04-28 05:59:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 05:59:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:59:08 --> Database Driver Class Initialized
INFO - 2023-04-28 05:59:08 --> Database Driver Class Initialized
INFO - 2023-04-28 05:59:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:59:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:59:08 --> Final output sent to browser
DEBUG - 2023-04-28 05:59:08 --> Total execution time: 0.0569
INFO - 2023-04-28 05:59:08 --> Final output sent to browser
DEBUG - 2023-04-28 05:59:08 --> Total execution time: 0.0582
INFO - 2023-04-28 05:59:08 --> Config Class Initialized
INFO - 2023-04-28 05:59:08 --> Hooks Class Initialized
INFO - 2023-04-28 05:59:08 --> Config Class Initialized
INFO - 2023-04-28 05:59:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 05:59:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 05:59:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 05:59:08 --> Utf8 Class Initialized
INFO - 2023-04-28 05:59:08 --> Utf8 Class Initialized
INFO - 2023-04-28 05:59:08 --> URI Class Initialized
INFO - 2023-04-28 05:59:08 --> URI Class Initialized
INFO - 2023-04-28 05:59:08 --> Router Class Initialized
INFO - 2023-04-28 05:59:08 --> Router Class Initialized
INFO - 2023-04-28 05:59:08 --> Output Class Initialized
INFO - 2023-04-28 05:59:08 --> Output Class Initialized
INFO - 2023-04-28 05:59:08 --> Security Class Initialized
INFO - 2023-04-28 05:59:08 --> Security Class Initialized
DEBUG - 2023-04-28 05:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 05:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 05:59:08 --> Input Class Initialized
INFO - 2023-04-28 05:59:08 --> Input Class Initialized
INFO - 2023-04-28 05:59:08 --> Language Class Initialized
INFO - 2023-04-28 05:59:08 --> Language Class Initialized
INFO - 2023-04-28 05:59:08 --> Loader Class Initialized
INFO - 2023-04-28 05:59:08 --> Controller Class Initialized
INFO - 2023-04-28 05:59:08 --> Loader Class Initialized
DEBUG - 2023-04-28 05:59:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:59:08 --> Controller Class Initialized
DEBUG - 2023-04-28 05:59:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 05:59:08 --> Database Driver Class Initialized
INFO - 2023-04-28 05:59:08 --> Database Driver Class Initialized
INFO - 2023-04-28 05:59:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:59:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 05:59:08 --> Final output sent to browser
DEBUG - 2023-04-28 05:59:08 --> Total execution time: 0.0128
INFO - 2023-04-28 05:59:08 --> Final output sent to browser
DEBUG - 2023-04-28 05:59:08 --> Total execution time: 0.0139
INFO - 2023-04-28 06:02:17 --> Config Class Initialized
INFO - 2023-04-28 06:02:17 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:02:17 --> Config Class Initialized
INFO - 2023-04-28 06:02:17 --> Utf8 Class Initialized
INFO - 2023-04-28 06:02:17 --> Hooks Class Initialized
INFO - 2023-04-28 06:02:17 --> URI Class Initialized
DEBUG - 2023-04-28 06:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:02:17 --> Router Class Initialized
INFO - 2023-04-28 06:02:17 --> Utf8 Class Initialized
INFO - 2023-04-28 06:02:17 --> Output Class Initialized
INFO - 2023-04-28 06:02:17 --> URI Class Initialized
INFO - 2023-04-28 06:02:17 --> Security Class Initialized
INFO - 2023-04-28 06:02:17 --> Router Class Initialized
INFO - 2023-04-28 06:02:17 --> Output Class Initialized
INFO - 2023-04-28 06:02:17 --> Security Class Initialized
DEBUG - 2023-04-28 06:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 06:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:02:17 --> Input Class Initialized
INFO - 2023-04-28 06:02:17 --> Input Class Initialized
INFO - 2023-04-28 06:02:17 --> Language Class Initialized
INFO - 2023-04-28 06:02:17 --> Loader Class Initialized
INFO - 2023-04-28 06:02:17 --> Controller Class Initialized
DEBUG - 2023-04-28 06:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:02:17 --> Database Driver Class Initialized
INFO - 2023-04-28 06:02:17 --> Language Class Initialized
INFO - 2023-04-28 06:02:17 --> Loader Class Initialized
INFO - 2023-04-28 06:02:17 --> Controller Class Initialized
DEBUG - 2023-04-28 06:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:02:17 --> Database Driver Class Initialized
INFO - 2023-04-28 06:02:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:02:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:02:17 --> Final output sent to browser
DEBUG - 2023-04-28 06:02:17 --> Total execution time: 0.0547
INFO - 2023-04-28 06:02:17 --> Final output sent to browser
DEBUG - 2023-04-28 06:02:17 --> Total execution time: 0.0580
INFO - 2023-04-28 06:02:17 --> Config Class Initialized
INFO - 2023-04-28 06:02:17 --> Hooks Class Initialized
INFO - 2023-04-28 06:02:17 --> Config Class Initialized
DEBUG - 2023-04-28 06:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:02:17 --> Utf8 Class Initialized
INFO - 2023-04-28 06:02:17 --> URI Class Initialized
INFO - 2023-04-28 06:02:17 --> Hooks Class Initialized
INFO - 2023-04-28 06:02:17 --> Router Class Initialized
DEBUG - 2023-04-28 06:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:02:17 --> Output Class Initialized
INFO - 2023-04-28 06:02:17 --> Utf8 Class Initialized
INFO - 2023-04-28 06:02:17 --> Security Class Initialized
INFO - 2023-04-28 06:02:17 --> URI Class Initialized
DEBUG - 2023-04-28 06:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:02:17 --> Router Class Initialized
INFO - 2023-04-28 06:02:17 --> Input Class Initialized
INFO - 2023-04-28 06:02:17 --> Output Class Initialized
INFO - 2023-04-28 06:02:17 --> Language Class Initialized
INFO - 2023-04-28 06:02:17 --> Security Class Initialized
INFO - 2023-04-28 06:02:17 --> Loader Class Initialized
DEBUG - 2023-04-28 06:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:02:17 --> Controller Class Initialized
INFO - 2023-04-28 06:02:17 --> Input Class Initialized
DEBUG - 2023-04-28 06:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:02:17 --> Language Class Initialized
INFO - 2023-04-28 06:02:17 --> Loader Class Initialized
INFO - 2023-04-28 06:02:17 --> Database Driver Class Initialized
INFO - 2023-04-28 06:02:17 --> Controller Class Initialized
DEBUG - 2023-04-28 06:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:02:17 --> Database Driver Class Initialized
INFO - 2023-04-28 06:02:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:02:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:02:17 --> Final output sent to browser
DEBUG - 2023-04-28 06:02:17 --> Total execution time: 0.0153
INFO - 2023-04-28 06:02:17 --> Final output sent to browser
DEBUG - 2023-04-28 06:02:17 --> Total execution time: 0.0188
INFO - 2023-04-28 06:02:58 --> Config Class Initialized
INFO - 2023-04-28 06:02:58 --> Config Class Initialized
INFO - 2023-04-28 06:02:58 --> Hooks Class Initialized
INFO - 2023-04-28 06:02:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:02:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 06:02:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:02:58 --> Utf8 Class Initialized
INFO - 2023-04-28 06:02:58 --> Utf8 Class Initialized
INFO - 2023-04-28 06:02:58 --> URI Class Initialized
INFO - 2023-04-28 06:02:58 --> URI Class Initialized
INFO - 2023-04-28 06:02:58 --> Router Class Initialized
INFO - 2023-04-28 06:02:58 --> Router Class Initialized
INFO - 2023-04-28 06:02:58 --> Output Class Initialized
INFO - 2023-04-28 06:02:58 --> Output Class Initialized
INFO - 2023-04-28 06:02:58 --> Security Class Initialized
INFO - 2023-04-28 06:02:58 --> Security Class Initialized
DEBUG - 2023-04-28 06:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:02:58 --> Input Class Initialized
DEBUG - 2023-04-28 06:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:02:58 --> Language Class Initialized
INFO - 2023-04-28 06:02:58 --> Input Class Initialized
INFO - 2023-04-28 06:02:58 --> Language Class Initialized
INFO - 2023-04-28 06:02:58 --> Loader Class Initialized
INFO - 2023-04-28 06:02:58 --> Loader Class Initialized
INFO - 2023-04-28 06:02:58 --> Controller Class Initialized
INFO - 2023-04-28 06:02:58 --> Controller Class Initialized
DEBUG - 2023-04-28 06:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 06:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:02:58 --> Database Driver Class Initialized
INFO - 2023-04-28 06:02:58 --> Database Driver Class Initialized
INFO - 2023-04-28 06:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:02:58 --> Final output sent to browser
DEBUG - 2023-04-28 06:02:58 --> Total execution time: 0.0546
INFO - 2023-04-28 06:02:58 --> Final output sent to browser
DEBUG - 2023-04-28 06:02:58 --> Total execution time: 0.0557
INFO - 2023-04-28 06:02:58 --> Config Class Initialized
INFO - 2023-04-28 06:02:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:02:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:02:58 --> Config Class Initialized
INFO - 2023-04-28 06:02:58 --> Utf8 Class Initialized
INFO - 2023-04-28 06:02:58 --> Hooks Class Initialized
INFO - 2023-04-28 06:02:58 --> URI Class Initialized
DEBUG - 2023-04-28 06:02:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:02:58 --> Router Class Initialized
INFO - 2023-04-28 06:02:58 --> Utf8 Class Initialized
INFO - 2023-04-28 06:02:58 --> Output Class Initialized
INFO - 2023-04-28 06:02:58 --> URI Class Initialized
INFO - 2023-04-28 06:02:58 --> Security Class Initialized
INFO - 2023-04-28 06:02:58 --> Router Class Initialized
DEBUG - 2023-04-28 06:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:02:58 --> Output Class Initialized
INFO - 2023-04-28 06:02:58 --> Input Class Initialized
INFO - 2023-04-28 06:02:58 --> Security Class Initialized
INFO - 2023-04-28 06:02:58 --> Language Class Initialized
DEBUG - 2023-04-28 06:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:02:58 --> Loader Class Initialized
INFO - 2023-04-28 06:02:58 --> Input Class Initialized
INFO - 2023-04-28 06:02:58 --> Controller Class Initialized
INFO - 2023-04-28 06:02:58 --> Language Class Initialized
DEBUG - 2023-04-28 06:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:02:58 --> Loader Class Initialized
INFO - 2023-04-28 06:02:58 --> Database Driver Class Initialized
INFO - 2023-04-28 06:02:58 --> Controller Class Initialized
DEBUG - 2023-04-28 06:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:02:58 --> Database Driver Class Initialized
INFO - 2023-04-28 06:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:02:58 --> Final output sent to browser
DEBUG - 2023-04-28 06:02:58 --> Total execution time: 0.0936
INFO - 2023-04-28 06:02:58 --> Final output sent to browser
DEBUG - 2023-04-28 06:02:58 --> Total execution time: 0.0527
INFO - 2023-04-28 06:29:16 --> Config Class Initialized
INFO - 2023-04-28 06:29:16 --> Config Class Initialized
INFO - 2023-04-28 06:29:16 --> Hooks Class Initialized
INFO - 2023-04-28 06:29:16 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:29:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 06:29:16 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:29:16 --> Utf8 Class Initialized
INFO - 2023-04-28 06:29:16 --> Utf8 Class Initialized
INFO - 2023-04-28 06:29:16 --> URI Class Initialized
INFO - 2023-04-28 06:29:16 --> URI Class Initialized
INFO - 2023-04-28 06:29:16 --> Router Class Initialized
INFO - 2023-04-28 06:29:16 --> Router Class Initialized
INFO - 2023-04-28 06:29:16 --> Output Class Initialized
INFO - 2023-04-28 06:29:16 --> Output Class Initialized
INFO - 2023-04-28 06:29:16 --> Security Class Initialized
INFO - 2023-04-28 06:29:16 --> Security Class Initialized
DEBUG - 2023-04-28 06:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 06:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:29:16 --> Input Class Initialized
INFO - 2023-04-28 06:29:16 --> Input Class Initialized
INFO - 2023-04-28 06:29:16 --> Language Class Initialized
INFO - 2023-04-28 06:29:16 --> Language Class Initialized
INFO - 2023-04-28 06:29:16 --> Loader Class Initialized
INFO - 2023-04-28 06:29:16 --> Loader Class Initialized
INFO - 2023-04-28 06:29:16 --> Controller Class Initialized
INFO - 2023-04-28 06:29:16 --> Controller Class Initialized
DEBUG - 2023-04-28 06:29:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 06:29:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:29:16 --> Database Driver Class Initialized
INFO - 2023-04-28 06:29:16 --> Database Driver Class Initialized
INFO - 2023-04-28 06:29:16 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:29:16 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:29:16 --> Final output sent to browser
DEBUG - 2023-04-28 06:29:16 --> Total execution time: 0.1346
INFO - 2023-04-28 06:29:16 --> Final output sent to browser
INFO - 2023-04-28 06:29:16 --> Config Class Initialized
DEBUG - 2023-04-28 06:29:16 --> Total execution time: 0.1368
INFO - 2023-04-28 06:29:16 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:29:16 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:29:16 --> Utf8 Class Initialized
INFO - 2023-04-28 06:29:16 --> URI Class Initialized
INFO - 2023-04-28 06:29:16 --> Config Class Initialized
INFO - 2023-04-28 06:29:16 --> Hooks Class Initialized
INFO - 2023-04-28 06:29:16 --> Router Class Initialized
DEBUG - 2023-04-28 06:29:16 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:29:16 --> Output Class Initialized
INFO - 2023-04-28 06:29:16 --> Utf8 Class Initialized
INFO - 2023-04-28 06:29:16 --> Security Class Initialized
INFO - 2023-04-28 06:29:16 --> URI Class Initialized
DEBUG - 2023-04-28 06:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:29:16 --> Input Class Initialized
INFO - 2023-04-28 06:29:16 --> Router Class Initialized
INFO - 2023-04-28 06:29:16 --> Language Class Initialized
INFO - 2023-04-28 06:29:16 --> Output Class Initialized
INFO - 2023-04-28 06:29:16 --> Security Class Initialized
INFO - 2023-04-28 06:29:16 --> Loader Class Initialized
DEBUG - 2023-04-28 06:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:29:16 --> Controller Class Initialized
INFO - 2023-04-28 06:29:16 --> Input Class Initialized
DEBUG - 2023-04-28 06:29:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:29:16 --> Language Class Initialized
INFO - 2023-04-28 06:29:16 --> Loader Class Initialized
INFO - 2023-04-28 06:29:16 --> Database Driver Class Initialized
INFO - 2023-04-28 06:29:16 --> Controller Class Initialized
DEBUG - 2023-04-28 06:29:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:29:16 --> Database Driver Class Initialized
INFO - 2023-04-28 06:29:16 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:29:16 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:29:16 --> Final output sent to browser
DEBUG - 2023-04-28 06:29:16 --> Total execution time: 0.0827
INFO - 2023-04-28 06:29:16 --> Final output sent to browser
DEBUG - 2023-04-28 06:29:16 --> Total execution time: 0.0460
INFO - 2023-04-28 06:31:29 --> Config Class Initialized
INFO - 2023-04-28 06:31:29 --> Config Class Initialized
INFO - 2023-04-28 06:31:29 --> Hooks Class Initialized
INFO - 2023-04-28 06:31:29 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:31:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 06:31:29 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:31:29 --> Utf8 Class Initialized
INFO - 2023-04-28 06:31:29 --> Utf8 Class Initialized
INFO - 2023-04-28 06:31:29 --> URI Class Initialized
INFO - 2023-04-28 06:31:29 --> URI Class Initialized
INFO - 2023-04-28 06:31:29 --> Router Class Initialized
INFO - 2023-04-28 06:31:29 --> Router Class Initialized
INFO - 2023-04-28 06:31:29 --> Output Class Initialized
INFO - 2023-04-28 06:31:29 --> Output Class Initialized
INFO - 2023-04-28 06:31:29 --> Security Class Initialized
INFO - 2023-04-28 06:31:29 --> Security Class Initialized
DEBUG - 2023-04-28 06:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 06:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:31:29 --> Input Class Initialized
INFO - 2023-04-28 06:31:29 --> Input Class Initialized
INFO - 2023-04-28 06:31:29 --> Language Class Initialized
INFO - 2023-04-28 06:31:29 --> Language Class Initialized
INFO - 2023-04-28 06:31:29 --> Loader Class Initialized
INFO - 2023-04-28 06:31:29 --> Loader Class Initialized
INFO - 2023-04-28 06:31:29 --> Controller Class Initialized
INFO - 2023-04-28 06:31:29 --> Controller Class Initialized
DEBUG - 2023-04-28 06:31:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 06:31:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:31:29 --> Final output sent to browser
INFO - 2023-04-28 06:31:29 --> Database Driver Class Initialized
DEBUG - 2023-04-28 06:31:29 --> Total execution time: 0.0043
INFO - 2023-04-28 06:31:29 --> Config Class Initialized
INFO - 2023-04-28 06:31:29 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:31:29 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:31:29 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:31:29 --> Utf8 Class Initialized
INFO - 2023-04-28 06:31:29 --> URI Class Initialized
INFO - 2023-04-28 06:31:29 --> Router Class Initialized
INFO - 2023-04-28 06:31:29 --> Output Class Initialized
INFO - 2023-04-28 06:31:29 --> Security Class Initialized
DEBUG - 2023-04-28 06:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:31:29 --> Input Class Initialized
INFO - 2023-04-28 06:31:29 --> Language Class Initialized
INFO - 2023-04-28 06:31:29 --> Loader Class Initialized
INFO - 2023-04-28 06:31:29 --> Controller Class Initialized
DEBUG - 2023-04-28 06:31:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:31:29 --> Database Driver Class Initialized
INFO - 2023-04-28 06:31:29 --> Final output sent to browser
DEBUG - 2023-04-28 06:31:29 --> Total execution time: 0.0545
INFO - 2023-04-28 06:31:29 --> Config Class Initialized
INFO - 2023-04-28 06:31:29 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:31:29 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:31:29 --> Utf8 Class Initialized
INFO - 2023-04-28 06:31:29 --> URI Class Initialized
INFO - 2023-04-28 06:31:29 --> Router Class Initialized
INFO - 2023-04-28 06:31:29 --> Output Class Initialized
INFO - 2023-04-28 06:31:29 --> Security Class Initialized
DEBUG - 2023-04-28 06:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:31:29 --> Input Class Initialized
INFO - 2023-04-28 06:31:29 --> Language Class Initialized
INFO - 2023-04-28 06:31:29 --> Loader Class Initialized
INFO - 2023-04-28 06:31:29 --> Controller Class Initialized
DEBUG - 2023-04-28 06:31:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:31:29 --> Database Driver Class Initialized
INFO - 2023-04-28 06:31:29 --> Model "Login_model" initialized
INFO - 2023-04-28 06:31:29 --> Database Driver Class Initialized
INFO - 2023-04-28 06:31:29 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:31:29 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:31:29 --> Final output sent to browser
INFO - 2023-04-28 06:31:29 --> Final output sent to browser
DEBUG - 2023-04-28 06:31:29 --> Total execution time: 0.0707
DEBUG - 2023-04-28 06:31:29 --> Total execution time: 0.0198
INFO - 2023-04-28 06:31:30 --> Config Class Initialized
INFO - 2023-04-28 06:31:30 --> Config Class Initialized
INFO - 2023-04-28 06:31:30 --> Hooks Class Initialized
INFO - 2023-04-28 06:31:30 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:31:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:31:30 --> Utf8 Class Initialized
INFO - 2023-04-28 06:31:30 --> URI Class Initialized
INFO - 2023-04-28 06:31:30 --> Router Class Initialized
INFO - 2023-04-28 06:31:30 --> Output Class Initialized
INFO - 2023-04-28 06:31:30 --> Security Class Initialized
DEBUG - 2023-04-28 06:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:31:30 --> Input Class Initialized
DEBUG - 2023-04-28 06:31:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:31:30 --> Language Class Initialized
INFO - 2023-04-28 06:31:30 --> Utf8 Class Initialized
INFO - 2023-04-28 06:31:30 --> Loader Class Initialized
INFO - 2023-04-28 06:31:30 --> Controller Class Initialized
DEBUG - 2023-04-28 06:31:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:31:30 --> URI Class Initialized
INFO - 2023-04-28 06:31:30 --> Router Class Initialized
INFO - 2023-04-28 06:31:30 --> Database Driver Class Initialized
INFO - 2023-04-28 06:31:30 --> Output Class Initialized
INFO - 2023-04-28 06:31:30 --> Security Class Initialized
DEBUG - 2023-04-28 06:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:31:30 --> Input Class Initialized
INFO - 2023-04-28 06:31:30 --> Language Class Initialized
INFO - 2023-04-28 06:31:30 --> Loader Class Initialized
INFO - 2023-04-28 06:31:30 --> Controller Class Initialized
DEBUG - 2023-04-28 06:31:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:31:30 --> Database Driver Class Initialized
INFO - 2023-04-28 06:31:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:31:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:31:30 --> Final output sent to browser
DEBUG - 2023-04-28 06:31:30 --> Total execution time: 0.0344
INFO - 2023-04-28 06:31:30 --> Final output sent to browser
DEBUG - 2023-04-28 06:31:30 --> Total execution time: 0.0349
INFO - 2023-04-28 06:31:30 --> Config Class Initialized
INFO - 2023-04-28 06:31:30 --> Hooks Class Initialized
INFO - 2023-04-28 06:31:30 --> Config Class Initialized
DEBUG - 2023-04-28 06:31:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:31:30 --> Utf8 Class Initialized
INFO - 2023-04-28 06:31:30 --> Hooks Class Initialized
INFO - 2023-04-28 06:31:30 --> URI Class Initialized
DEBUG - 2023-04-28 06:31:30 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:31:30 --> Router Class Initialized
INFO - 2023-04-28 06:31:30 --> Utf8 Class Initialized
INFO - 2023-04-28 06:31:30 --> Output Class Initialized
INFO - 2023-04-28 06:31:30 --> URI Class Initialized
INFO - 2023-04-28 06:31:30 --> Security Class Initialized
INFO - 2023-04-28 06:31:30 --> Router Class Initialized
DEBUG - 2023-04-28 06:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:31:30 --> Input Class Initialized
INFO - 2023-04-28 06:31:30 --> Output Class Initialized
INFO - 2023-04-28 06:31:30 --> Language Class Initialized
INFO - 2023-04-28 06:31:30 --> Security Class Initialized
DEBUG - 2023-04-28 06:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:31:30 --> Loader Class Initialized
INFO - 2023-04-28 06:31:30 --> Input Class Initialized
INFO - 2023-04-28 06:31:30 --> Controller Class Initialized
INFO - 2023-04-28 06:31:30 --> Language Class Initialized
DEBUG - 2023-04-28 06:31:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:31:30 --> Loader Class Initialized
INFO - 2023-04-28 06:31:30 --> Controller Class Initialized
INFO - 2023-04-28 06:31:30 --> Database Driver Class Initialized
DEBUG - 2023-04-28 06:31:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:31:30 --> Database Driver Class Initialized
INFO - 2023-04-28 06:31:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:31:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:31:30 --> Final output sent to browser
DEBUG - 2023-04-28 06:31:30 --> Total execution time: 0.0141
INFO - 2023-04-28 06:31:30 --> Final output sent to browser
DEBUG - 2023-04-28 06:31:30 --> Total execution time: 0.0163
INFO - 2023-04-28 06:31:33 --> Config Class Initialized
INFO - 2023-04-28 06:31:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:31:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:31:33 --> Utf8 Class Initialized
INFO - 2023-04-28 06:31:33 --> URI Class Initialized
INFO - 2023-04-28 06:31:33 --> Router Class Initialized
INFO - 2023-04-28 06:31:33 --> Output Class Initialized
INFO - 2023-04-28 06:31:33 --> Security Class Initialized
DEBUG - 2023-04-28 06:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:31:33 --> Input Class Initialized
INFO - 2023-04-28 06:31:33 --> Language Class Initialized
INFO - 2023-04-28 06:31:33 --> Loader Class Initialized
INFO - 2023-04-28 06:31:33 --> Controller Class Initialized
DEBUG - 2023-04-28 06:31:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:31:33 --> Database Driver Class Initialized
INFO - 2023-04-28 06:31:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:31:33 --> Final output sent to browser
DEBUG - 2023-04-28 06:31:33 --> Total execution time: 0.0136
INFO - 2023-04-28 06:31:33 --> Config Class Initialized
INFO - 2023-04-28 06:31:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:31:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:31:33 --> Utf8 Class Initialized
INFO - 2023-04-28 06:31:33 --> URI Class Initialized
INFO - 2023-04-28 06:31:33 --> Router Class Initialized
INFO - 2023-04-28 06:31:33 --> Output Class Initialized
INFO - 2023-04-28 06:31:33 --> Security Class Initialized
DEBUG - 2023-04-28 06:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:31:33 --> Input Class Initialized
INFO - 2023-04-28 06:31:33 --> Language Class Initialized
INFO - 2023-04-28 06:31:33 --> Loader Class Initialized
INFO - 2023-04-28 06:31:33 --> Controller Class Initialized
DEBUG - 2023-04-28 06:31:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:31:33 --> Database Driver Class Initialized
INFO - 2023-04-28 06:31:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:31:33 --> Final output sent to browser
DEBUG - 2023-04-28 06:31:33 --> Total execution time: 0.0548
INFO - 2023-04-28 06:31:33 --> Config Class Initialized
INFO - 2023-04-28 06:31:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:31:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:31:33 --> Utf8 Class Initialized
INFO - 2023-04-28 06:31:33 --> URI Class Initialized
INFO - 2023-04-28 06:31:33 --> Router Class Initialized
INFO - 2023-04-28 06:31:33 --> Output Class Initialized
INFO - 2023-04-28 06:31:33 --> Security Class Initialized
DEBUG - 2023-04-28 06:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:31:33 --> Input Class Initialized
INFO - 2023-04-28 06:31:33 --> Language Class Initialized
INFO - 2023-04-28 06:31:33 --> Loader Class Initialized
INFO - 2023-04-28 06:31:33 --> Controller Class Initialized
DEBUG - 2023-04-28 06:31:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:31:33 --> Database Driver Class Initialized
INFO - 2023-04-28 06:31:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:31:33 --> Final output sent to browser
DEBUG - 2023-04-28 06:31:33 --> Total execution time: 0.0504
INFO - 2023-04-28 06:31:33 --> Config Class Initialized
INFO - 2023-04-28 06:31:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:31:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:31:33 --> Utf8 Class Initialized
INFO - 2023-04-28 06:31:33 --> URI Class Initialized
INFO - 2023-04-28 06:31:33 --> Router Class Initialized
INFO - 2023-04-28 06:31:33 --> Output Class Initialized
INFO - 2023-04-28 06:31:33 --> Security Class Initialized
DEBUG - 2023-04-28 06:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:31:33 --> Input Class Initialized
INFO - 2023-04-28 06:31:33 --> Language Class Initialized
INFO - 2023-04-28 06:31:33 --> Loader Class Initialized
INFO - 2023-04-28 06:31:33 --> Controller Class Initialized
DEBUG - 2023-04-28 06:31:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:31:33 --> Database Driver Class Initialized
INFO - 2023-04-28 06:31:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:31:33 --> Final output sent to browser
DEBUG - 2023-04-28 06:31:33 --> Total execution time: 0.0532
INFO - 2023-04-28 06:32:07 --> Config Class Initialized
INFO - 2023-04-28 06:32:07 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:07 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:07 --> URI Class Initialized
INFO - 2023-04-28 06:32:07 --> Router Class Initialized
INFO - 2023-04-28 06:32:07 --> Output Class Initialized
INFO - 2023-04-28 06:32:07 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:07 --> Input Class Initialized
INFO - 2023-04-28 06:32:07 --> Language Class Initialized
INFO - 2023-04-28 06:32:07 --> Loader Class Initialized
INFO - 2023-04-28 06:32:07 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:07 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:07 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:07 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:07 --> Total execution time: 0.0528
INFO - 2023-04-28 06:32:07 --> Config Class Initialized
INFO - 2023-04-28 06:32:07 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:07 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:07 --> URI Class Initialized
INFO - 2023-04-28 06:32:07 --> Router Class Initialized
INFO - 2023-04-28 06:32:07 --> Output Class Initialized
INFO - 2023-04-28 06:32:07 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:07 --> Input Class Initialized
INFO - 2023-04-28 06:32:07 --> Language Class Initialized
INFO - 2023-04-28 06:32:07 --> Loader Class Initialized
INFO - 2023-04-28 06:32:07 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:07 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:07 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:07 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:07 --> Model "Login_model" initialized
INFO - 2023-04-28 06:32:08 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:08 --> Total execution time: 0.0381
INFO - 2023-04-28 06:32:08 --> Config Class Initialized
INFO - 2023-04-28 06:32:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:08 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:08 --> URI Class Initialized
INFO - 2023-04-28 06:32:08 --> Router Class Initialized
INFO - 2023-04-28 06:32:08 --> Output Class Initialized
INFO - 2023-04-28 06:32:08 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:08 --> Input Class Initialized
INFO - 2023-04-28 06:32:08 --> Language Class Initialized
INFO - 2023-04-28 06:32:08 --> Loader Class Initialized
INFO - 2023-04-28 06:32:08 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:08 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:08 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:08 --> Total execution time: 0.0214
INFO - 2023-04-28 06:32:08 --> Config Class Initialized
INFO - 2023-04-28 06:32:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:08 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:08 --> URI Class Initialized
INFO - 2023-04-28 06:32:08 --> Router Class Initialized
INFO - 2023-04-28 06:32:08 --> Output Class Initialized
INFO - 2023-04-28 06:32:08 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:08 --> Input Class Initialized
INFO - 2023-04-28 06:32:08 --> Language Class Initialized
INFO - 2023-04-28 06:32:08 --> Loader Class Initialized
INFO - 2023-04-28 06:32:08 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:08 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:08 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:08 --> Total execution time: 0.6352
INFO - 2023-04-28 06:32:13 --> Config Class Initialized
INFO - 2023-04-28 06:32:13 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:13 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:13 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:13 --> URI Class Initialized
INFO - 2023-04-28 06:32:13 --> Router Class Initialized
INFO - 2023-04-28 06:32:13 --> Output Class Initialized
INFO - 2023-04-28 06:32:13 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:13 --> Input Class Initialized
INFO - 2023-04-28 06:32:13 --> Language Class Initialized
INFO - 2023-04-28 06:32:13 --> Loader Class Initialized
INFO - 2023-04-28 06:32:13 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:13 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:13 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:13 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:13 --> Total execution time: 0.0184
INFO - 2023-04-28 06:32:18 --> Config Class Initialized
INFO - 2023-04-28 06:32:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:18 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:18 --> URI Class Initialized
INFO - 2023-04-28 06:32:18 --> Router Class Initialized
INFO - 2023-04-28 06:32:18 --> Output Class Initialized
INFO - 2023-04-28 06:32:18 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:18 --> Input Class Initialized
INFO - 2023-04-28 06:32:18 --> Language Class Initialized
INFO - 2023-04-28 06:32:18 --> Loader Class Initialized
INFO - 2023-04-28 06:32:18 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:18 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:18 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:18 --> Total execution time: 0.0135
INFO - 2023-04-28 06:32:18 --> Config Class Initialized
INFO - 2023-04-28 06:32:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:18 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:18 --> URI Class Initialized
INFO - 2023-04-28 06:32:18 --> Router Class Initialized
INFO - 2023-04-28 06:32:18 --> Output Class Initialized
INFO - 2023-04-28 06:32:18 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:18 --> Input Class Initialized
INFO - 2023-04-28 06:32:18 --> Language Class Initialized
INFO - 2023-04-28 06:32:18 --> Loader Class Initialized
INFO - 2023-04-28 06:32:18 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:18 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:18 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:18 --> Total execution time: 0.0199
INFO - 2023-04-28 06:32:23 --> Config Class Initialized
INFO - 2023-04-28 06:32:23 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:23 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:23 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:23 --> URI Class Initialized
INFO - 2023-04-28 06:32:23 --> Router Class Initialized
INFO - 2023-04-28 06:32:23 --> Output Class Initialized
INFO - 2023-04-28 06:32:23 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:23 --> Input Class Initialized
INFO - 2023-04-28 06:32:23 --> Language Class Initialized
INFO - 2023-04-28 06:32:23 --> Loader Class Initialized
INFO - 2023-04-28 06:32:23 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:23 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:23 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:23 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:23 --> Total execution time: 0.0184
INFO - 2023-04-28 06:32:28 --> Config Class Initialized
INFO - 2023-04-28 06:32:28 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:28 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:28 --> URI Class Initialized
INFO - 2023-04-28 06:32:28 --> Router Class Initialized
INFO - 2023-04-28 06:32:28 --> Output Class Initialized
INFO - 2023-04-28 06:32:28 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:28 --> Input Class Initialized
INFO - 2023-04-28 06:32:28 --> Language Class Initialized
INFO - 2023-04-28 06:32:28 --> Loader Class Initialized
INFO - 2023-04-28 06:32:28 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:28 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:28 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:28 --> Total execution time: 0.0115
INFO - 2023-04-28 06:32:28 --> Config Class Initialized
INFO - 2023-04-28 06:32:28 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:28 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:28 --> URI Class Initialized
INFO - 2023-04-28 06:32:28 --> Router Class Initialized
INFO - 2023-04-28 06:32:28 --> Output Class Initialized
INFO - 2023-04-28 06:32:28 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:28 --> Input Class Initialized
INFO - 2023-04-28 06:32:28 --> Language Class Initialized
INFO - 2023-04-28 06:32:28 --> Loader Class Initialized
INFO - 2023-04-28 06:32:28 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:28 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:28 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:28 --> Total execution time: 0.0129
INFO - 2023-04-28 06:32:33 --> Config Class Initialized
INFO - 2023-04-28 06:32:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:33 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:33 --> URI Class Initialized
INFO - 2023-04-28 06:32:33 --> Router Class Initialized
INFO - 2023-04-28 06:32:33 --> Output Class Initialized
INFO - 2023-04-28 06:32:33 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:33 --> Input Class Initialized
INFO - 2023-04-28 06:32:33 --> Language Class Initialized
INFO - 2023-04-28 06:32:33 --> Loader Class Initialized
INFO - 2023-04-28 06:32:33 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:33 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:33 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:33 --> Total execution time: 0.0208
INFO - 2023-04-28 06:32:38 --> Config Class Initialized
INFO - 2023-04-28 06:32:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:38 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:38 --> URI Class Initialized
INFO - 2023-04-28 06:32:38 --> Router Class Initialized
INFO - 2023-04-28 06:32:38 --> Output Class Initialized
INFO - 2023-04-28 06:32:38 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:38 --> Input Class Initialized
INFO - 2023-04-28 06:32:38 --> Language Class Initialized
INFO - 2023-04-28 06:32:38 --> Loader Class Initialized
INFO - 2023-04-28 06:32:38 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:38 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:38 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:38 --> Total execution time: 0.0142
INFO - 2023-04-28 06:32:38 --> Config Class Initialized
INFO - 2023-04-28 06:32:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:38 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:38 --> URI Class Initialized
INFO - 2023-04-28 06:32:38 --> Router Class Initialized
INFO - 2023-04-28 06:32:38 --> Output Class Initialized
INFO - 2023-04-28 06:32:38 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:38 --> Input Class Initialized
INFO - 2023-04-28 06:32:38 --> Language Class Initialized
INFO - 2023-04-28 06:32:38 --> Loader Class Initialized
INFO - 2023-04-28 06:32:38 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:38 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:38 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:38 --> Total execution time: 0.0125
INFO - 2023-04-28 06:32:58 --> Config Class Initialized
INFO - 2023-04-28 06:32:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:58 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:58 --> URI Class Initialized
INFO - 2023-04-28 06:32:58 --> Router Class Initialized
INFO - 2023-04-28 06:32:58 --> Output Class Initialized
INFO - 2023-04-28 06:32:58 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:58 --> Input Class Initialized
INFO - 2023-04-28 06:32:58 --> Language Class Initialized
INFO - 2023-04-28 06:32:58 --> Loader Class Initialized
INFO - 2023-04-28 06:32:58 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:58 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:58 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:58 --> Total execution time: 0.0130
INFO - 2023-04-28 06:32:58 --> Config Class Initialized
INFO - 2023-04-28 06:32:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:58 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:58 --> URI Class Initialized
INFO - 2023-04-28 06:32:58 --> Router Class Initialized
INFO - 2023-04-28 06:32:58 --> Output Class Initialized
INFO - 2023-04-28 06:32:58 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:58 --> Input Class Initialized
INFO - 2023-04-28 06:32:58 --> Language Class Initialized
INFO - 2023-04-28 06:32:58 --> Loader Class Initialized
INFO - 2023-04-28 06:32:58 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:58 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:58 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:58 --> Model "Login_model" initialized
INFO - 2023-04-28 06:32:58 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:58 --> Total execution time: 0.0201
INFO - 2023-04-28 06:32:58 --> Config Class Initialized
INFO - 2023-04-28 06:32:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:58 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:58 --> URI Class Initialized
INFO - 2023-04-28 06:32:58 --> Router Class Initialized
INFO - 2023-04-28 06:32:58 --> Output Class Initialized
INFO - 2023-04-28 06:32:58 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:58 --> Input Class Initialized
INFO - 2023-04-28 06:32:58 --> Language Class Initialized
INFO - 2023-04-28 06:32:58 --> Loader Class Initialized
INFO - 2023-04-28 06:32:58 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:58 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:59 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:59 --> Total execution time: 0.0178
INFO - 2023-04-28 06:32:59 --> Config Class Initialized
INFO - 2023-04-28 06:32:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:32:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:32:59 --> Utf8 Class Initialized
INFO - 2023-04-28 06:32:59 --> URI Class Initialized
INFO - 2023-04-28 06:32:59 --> Router Class Initialized
INFO - 2023-04-28 06:32:59 --> Output Class Initialized
INFO - 2023-04-28 06:32:59 --> Security Class Initialized
DEBUG - 2023-04-28 06:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:32:59 --> Input Class Initialized
INFO - 2023-04-28 06:32:59 --> Language Class Initialized
INFO - 2023-04-28 06:32:59 --> Loader Class Initialized
INFO - 2023-04-28 06:32:59 --> Controller Class Initialized
DEBUG - 2023-04-28 06:32:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:32:59 --> Database Driver Class Initialized
INFO - 2023-04-28 06:32:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:32:59 --> Final output sent to browser
DEBUG - 2023-04-28 06:32:59 --> Total execution time: 0.0540
INFO - 2023-04-28 06:33:02 --> Config Class Initialized
INFO - 2023-04-28 06:33:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:33:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:02 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:02 --> URI Class Initialized
INFO - 2023-04-28 06:33:02 --> Router Class Initialized
INFO - 2023-04-28 06:33:02 --> Output Class Initialized
INFO - 2023-04-28 06:33:02 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:02 --> Input Class Initialized
INFO - 2023-04-28 06:33:02 --> Language Class Initialized
INFO - 2023-04-28 06:33:02 --> Loader Class Initialized
INFO - 2023-04-28 06:33:02 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:02 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:02 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:02 --> Total execution time: 0.0230
INFO - 2023-04-28 06:33:02 --> Config Class Initialized
INFO - 2023-04-28 06:33:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:33:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:02 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:02 --> URI Class Initialized
INFO - 2023-04-28 06:33:02 --> Router Class Initialized
INFO - 2023-04-28 06:33:02 --> Output Class Initialized
INFO - 2023-04-28 06:33:02 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:02 --> Input Class Initialized
INFO - 2023-04-28 06:33:02 --> Language Class Initialized
INFO - 2023-04-28 06:33:02 --> Loader Class Initialized
INFO - 2023-04-28 06:33:02 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:02 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:02 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:02 --> Total execution time: 0.0582
INFO - 2023-04-28 06:33:43 --> Config Class Initialized
INFO - 2023-04-28 06:33:43 --> Config Class Initialized
INFO - 2023-04-28 06:33:43 --> Hooks Class Initialized
INFO - 2023-04-28 06:33:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:33:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:43 --> Utf8 Class Initialized
DEBUG - 2023-04-28 06:33:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:43 --> URI Class Initialized
INFO - 2023-04-28 06:33:43 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:43 --> URI Class Initialized
INFO - 2023-04-28 06:33:43 --> Router Class Initialized
INFO - 2023-04-28 06:33:43 --> Router Class Initialized
INFO - 2023-04-28 06:33:43 --> Output Class Initialized
INFO - 2023-04-28 06:33:43 --> Output Class Initialized
INFO - 2023-04-28 06:33:43 --> Security Class Initialized
INFO - 2023-04-28 06:33:43 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 06:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:43 --> Input Class Initialized
INFO - 2023-04-28 06:33:43 --> Input Class Initialized
INFO - 2023-04-28 06:33:43 --> Language Class Initialized
INFO - 2023-04-28 06:33:43 --> Language Class Initialized
INFO - 2023-04-28 06:33:43 --> Loader Class Initialized
INFO - 2023-04-28 06:33:43 --> Loader Class Initialized
INFO - 2023-04-28 06:33:43 --> Controller Class Initialized
INFO - 2023-04-28 06:33:43 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 06:33:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:43 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:43 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:43 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:43 --> Total execution time: 0.0154
INFO - 2023-04-28 06:33:43 --> Config Class Initialized
INFO - 2023-04-28 06:33:43 --> Hooks Class Initialized
INFO - 2023-04-28 06:33:43 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 06:33:43 --> Total execution time: 0.0173
INFO - 2023-04-28 06:33:43 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:43 --> URI Class Initialized
INFO - 2023-04-28 06:33:43 --> Router Class Initialized
INFO - 2023-04-28 06:33:43 --> Output Class Initialized
INFO - 2023-04-28 06:33:43 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:43 --> Input Class Initialized
INFO - 2023-04-28 06:33:43 --> Language Class Initialized
INFO - 2023-04-28 06:33:43 --> Loader Class Initialized
INFO - 2023-04-28 06:33:43 --> Controller Class Initialized
INFO - 2023-04-28 06:33:43 --> Config Class Initialized
DEBUG - 2023-04-28 06:33:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:43 --> Hooks Class Initialized
INFO - 2023-04-28 06:33:43 --> Database Driver Class Initialized
DEBUG - 2023-04-28 06:33:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:43 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:43 --> URI Class Initialized
INFO - 2023-04-28 06:33:43 --> Router Class Initialized
INFO - 2023-04-28 06:33:43 --> Output Class Initialized
INFO - 2023-04-28 06:33:43 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:43 --> Input Class Initialized
INFO - 2023-04-28 06:33:43 --> Language Class Initialized
INFO - 2023-04-28 06:33:43 --> Loader Class Initialized
INFO - 2023-04-28 06:33:43 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:43 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:43 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:43 --> Total execution time: 0.0111
INFO - 2023-04-28 06:33:43 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:43 --> Total execution time: 0.0129
INFO - 2023-04-28 06:33:45 --> Config Class Initialized
INFO - 2023-04-28 06:33:45 --> Config Class Initialized
INFO - 2023-04-28 06:33:45 --> Hooks Class Initialized
INFO - 2023-04-28 06:33:45 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:33:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 06:33:45 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:45 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:45 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:45 --> URI Class Initialized
INFO - 2023-04-28 06:33:45 --> URI Class Initialized
INFO - 2023-04-28 06:33:45 --> Router Class Initialized
INFO - 2023-04-28 06:33:45 --> Router Class Initialized
INFO - 2023-04-28 06:33:45 --> Output Class Initialized
INFO - 2023-04-28 06:33:45 --> Output Class Initialized
INFO - 2023-04-28 06:33:45 --> Security Class Initialized
INFO - 2023-04-28 06:33:45 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 06:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:45 --> Input Class Initialized
INFO - 2023-04-28 06:33:45 --> Input Class Initialized
INFO - 2023-04-28 06:33:45 --> Language Class Initialized
INFO - 2023-04-28 06:33:45 --> Language Class Initialized
INFO - 2023-04-28 06:33:45 --> Loader Class Initialized
INFO - 2023-04-28 06:33:45 --> Loader Class Initialized
INFO - 2023-04-28 06:33:45 --> Controller Class Initialized
INFO - 2023-04-28 06:33:45 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 06:33:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:45 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:45 --> Total execution time: 0.0041
INFO - 2023-04-28 06:33:45 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:45 --> Config Class Initialized
INFO - 2023-04-28 06:33:45 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:33:45 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:45 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:45 --> URI Class Initialized
INFO - 2023-04-28 06:33:45 --> Router Class Initialized
INFO - 2023-04-28 06:33:45 --> Output Class Initialized
INFO - 2023-04-28 06:33:45 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:45 --> Input Class Initialized
INFO - 2023-04-28 06:33:45 --> Language Class Initialized
INFO - 2023-04-28 06:33:45 --> Loader Class Initialized
INFO - 2023-04-28 06:33:45 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:45 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:45 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:45 --> Model "Login_model" initialized
INFO - 2023-04-28 06:33:45 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:45 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:45 --> Total execution time: 0.0186
INFO - 2023-04-28 06:33:45 --> Config Class Initialized
INFO - 2023-04-28 06:33:45 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:33:45 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:45 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:45 --> URI Class Initialized
INFO - 2023-04-28 06:33:45 --> Router Class Initialized
INFO - 2023-04-28 06:33:45 --> Output Class Initialized
INFO - 2023-04-28 06:33:45 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:45 --> Input Class Initialized
INFO - 2023-04-28 06:33:45 --> Language Class Initialized
INFO - 2023-04-28 06:33:45 --> Loader Class Initialized
INFO - 2023-04-28 06:33:45 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:45 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:45 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:45 --> Final output sent to browser
INFO - 2023-04-28 06:33:45 --> Model "Cluster_model" initialized
DEBUG - 2023-04-28 06:33:45 --> Total execution time: 0.0260
INFO - 2023-04-28 06:33:45 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:45 --> Total execution time: 0.0161
INFO - 2023-04-28 06:33:49 --> Config Class Initialized
INFO - 2023-04-28 06:33:49 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:33:49 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:49 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:49 --> URI Class Initialized
INFO - 2023-04-28 06:33:49 --> Router Class Initialized
INFO - 2023-04-28 06:33:49 --> Output Class Initialized
INFO - 2023-04-28 06:33:49 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:49 --> Input Class Initialized
INFO - 2023-04-28 06:33:49 --> Language Class Initialized
INFO - 2023-04-28 06:33:49 --> Loader Class Initialized
INFO - 2023-04-28 06:33:49 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:49 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:49 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:49 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:49 --> Total execution time: 0.0141
INFO - 2023-04-28 06:33:49 --> Config Class Initialized
INFO - 2023-04-28 06:33:49 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:33:49 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:49 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:49 --> URI Class Initialized
INFO - 2023-04-28 06:33:49 --> Router Class Initialized
INFO - 2023-04-28 06:33:49 --> Output Class Initialized
INFO - 2023-04-28 06:33:49 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:49 --> Input Class Initialized
INFO - 2023-04-28 06:33:49 --> Language Class Initialized
INFO - 2023-04-28 06:33:49 --> Loader Class Initialized
INFO - 2023-04-28 06:33:49 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:49 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:49 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:49 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:49 --> Total execution time: 0.0570
INFO - 2023-04-28 06:33:52 --> Config Class Initialized
INFO - 2023-04-28 06:33:52 --> Config Class Initialized
INFO - 2023-04-28 06:33:52 --> Hooks Class Initialized
INFO - 2023-04-28 06:33:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:33:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 06:33:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:52 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:52 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:52 --> URI Class Initialized
INFO - 2023-04-28 06:33:52 --> URI Class Initialized
INFO - 2023-04-28 06:33:52 --> Router Class Initialized
INFO - 2023-04-28 06:33:52 --> Router Class Initialized
INFO - 2023-04-28 06:33:52 --> Output Class Initialized
INFO - 2023-04-28 06:33:52 --> Output Class Initialized
INFO - 2023-04-28 06:33:52 --> Security Class Initialized
INFO - 2023-04-28 06:33:52 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 06:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:52 --> Input Class Initialized
INFO - 2023-04-28 06:33:52 --> Input Class Initialized
INFO - 2023-04-28 06:33:52 --> Language Class Initialized
INFO - 2023-04-28 06:33:52 --> Language Class Initialized
INFO - 2023-04-28 06:33:52 --> Loader Class Initialized
INFO - 2023-04-28 06:33:52 --> Loader Class Initialized
INFO - 2023-04-28 06:33:52 --> Controller Class Initialized
INFO - 2023-04-28 06:33:52 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 06:33:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:52 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:52 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:52 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:52 --> Total execution time: 0.0572
INFO - 2023-04-28 06:33:52 --> Config Class Initialized
INFO - 2023-04-28 06:33:52 --> Final output sent to browser
INFO - 2023-04-28 06:33:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:33:52 --> Total execution time: 0.0590
DEBUG - 2023-04-28 06:33:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:52 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:52 --> URI Class Initialized
INFO - 2023-04-28 06:33:52 --> Router Class Initialized
INFO - 2023-04-28 06:33:52 --> Output Class Initialized
INFO - 2023-04-28 06:33:52 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:52 --> Input Class Initialized
INFO - 2023-04-28 06:33:52 --> Language Class Initialized
INFO - 2023-04-28 06:33:52 --> Config Class Initialized
INFO - 2023-04-28 06:33:52 --> Loader Class Initialized
INFO - 2023-04-28 06:33:52 --> Hooks Class Initialized
INFO - 2023-04-28 06:33:52 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 06:33:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:52 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:52 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:52 --> URI Class Initialized
INFO - 2023-04-28 06:33:52 --> Router Class Initialized
INFO - 2023-04-28 06:33:52 --> Output Class Initialized
INFO - 2023-04-28 06:33:52 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:52 --> Input Class Initialized
INFO - 2023-04-28 06:33:52 --> Language Class Initialized
INFO - 2023-04-28 06:33:52 --> Loader Class Initialized
INFO - 2023-04-28 06:33:52 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:52 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:52 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:52 --> Total execution time: 0.0108
INFO - 2023-04-28 06:33:52 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:52 --> Total execution time: 0.0138
INFO - 2023-04-28 06:33:55 --> Config Class Initialized
INFO - 2023-04-28 06:33:55 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:33:55 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:55 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:55 --> URI Class Initialized
INFO - 2023-04-28 06:33:55 --> Router Class Initialized
INFO - 2023-04-28 06:33:55 --> Output Class Initialized
INFO - 2023-04-28 06:33:55 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:55 --> Input Class Initialized
INFO - 2023-04-28 06:33:55 --> Language Class Initialized
INFO - 2023-04-28 06:33:55 --> Loader Class Initialized
INFO - 2023-04-28 06:33:55 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:55 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:55 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:55 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:55 --> Total execution time: 0.0146
INFO - 2023-04-28 06:33:55 --> Config Class Initialized
INFO - 2023-04-28 06:33:55 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:33:55 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:33:55 --> Utf8 Class Initialized
INFO - 2023-04-28 06:33:55 --> URI Class Initialized
INFO - 2023-04-28 06:33:55 --> Router Class Initialized
INFO - 2023-04-28 06:33:55 --> Output Class Initialized
INFO - 2023-04-28 06:33:55 --> Security Class Initialized
DEBUG - 2023-04-28 06:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:33:55 --> Input Class Initialized
INFO - 2023-04-28 06:33:55 --> Language Class Initialized
INFO - 2023-04-28 06:33:55 --> Loader Class Initialized
INFO - 2023-04-28 06:33:55 --> Controller Class Initialized
DEBUG - 2023-04-28 06:33:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:33:55 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:55 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:33:55 --> Database Driver Class Initialized
INFO - 2023-04-28 06:33:55 --> Model "Login_model" initialized
INFO - 2023-04-28 06:33:55 --> Final output sent to browser
DEBUG - 2023-04-28 06:33:55 --> Total execution time: 0.0219
INFO - 2023-04-28 06:34:02 --> Config Class Initialized
INFO - 2023-04-28 06:34:02 --> Config Class Initialized
INFO - 2023-04-28 06:34:02 --> Hooks Class Initialized
INFO - 2023-04-28 06:34:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 06:34:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:02 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:02 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:02 --> URI Class Initialized
INFO - 2023-04-28 06:34:02 --> URI Class Initialized
INFO - 2023-04-28 06:34:02 --> Router Class Initialized
INFO - 2023-04-28 06:34:02 --> Router Class Initialized
INFO - 2023-04-28 06:34:02 --> Output Class Initialized
INFO - 2023-04-28 06:34:02 --> Output Class Initialized
INFO - 2023-04-28 06:34:02 --> Security Class Initialized
INFO - 2023-04-28 06:34:02 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 06:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:02 --> Input Class Initialized
INFO - 2023-04-28 06:34:02 --> Language Class Initialized
INFO - 2023-04-28 06:34:02 --> Input Class Initialized
INFO - 2023-04-28 06:34:02 --> Language Class Initialized
INFO - 2023-04-28 06:34:02 --> Loader Class Initialized
INFO - 2023-04-28 06:34:02 --> Loader Class Initialized
INFO - 2023-04-28 06:34:02 --> Controller Class Initialized
INFO - 2023-04-28 06:34:02 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 06:34:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:02 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:02 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:02 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:02 --> Total execution time: 0.0233
INFO - 2023-04-28 06:34:02 --> Config Class Initialized
INFO - 2023-04-28 06:34:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:02 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:02 --> URI Class Initialized
INFO - 2023-04-28 06:34:02 --> Router Class Initialized
INFO - 2023-04-28 06:34:02 --> Output Class Initialized
INFO - 2023-04-28 06:34:02 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:02 --> Input Class Initialized
INFO - 2023-04-28 06:34:02 --> Language Class Initialized
INFO - 2023-04-28 06:34:02 --> Loader Class Initialized
INFO - 2023-04-28 06:34:02 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:02 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:02 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:02 --> Total execution time: 0.0378
INFO - 2023-04-28 06:34:02 --> Config Class Initialized
INFO - 2023-04-28 06:34:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:02 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:02 --> URI Class Initialized
INFO - 2023-04-28 06:34:02 --> Router Class Initialized
INFO - 2023-04-28 06:34:02 --> Output Class Initialized
INFO - 2023-04-28 06:34:02 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:02 --> Input Class Initialized
INFO - 2023-04-28 06:34:02 --> Language Class Initialized
INFO - 2023-04-28 06:34:02 --> Loader Class Initialized
INFO - 2023-04-28 06:34:02 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:02 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:02 --> Final output sent to browser
INFO - 2023-04-28 06:34:02 --> Model "Cluster_model" initialized
DEBUG - 2023-04-28 06:34:02 --> Total execution time: 0.0520
INFO - 2023-04-28 06:34:02 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:02 --> Total execution time: 0.0795
INFO - 2023-04-28 06:34:07 --> Config Class Initialized
INFO - 2023-04-28 06:34:07 --> Config Class Initialized
INFO - 2023-04-28 06:34:07 --> Hooks Class Initialized
INFO - 2023-04-28 06:34:07 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:07 --> Utf8 Class Initialized
DEBUG - 2023-04-28 06:34:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:07 --> URI Class Initialized
INFO - 2023-04-28 06:34:07 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:07 --> Router Class Initialized
INFO - 2023-04-28 06:34:07 --> URI Class Initialized
INFO - 2023-04-28 06:34:07 --> Output Class Initialized
INFO - 2023-04-28 06:34:07 --> Router Class Initialized
INFO - 2023-04-28 06:34:07 --> Security Class Initialized
INFO - 2023-04-28 06:34:07 --> Output Class Initialized
DEBUG - 2023-04-28 06:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:07 --> Security Class Initialized
INFO - 2023-04-28 06:34:07 --> Input Class Initialized
DEBUG - 2023-04-28 06:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:07 --> Language Class Initialized
INFO - 2023-04-28 06:34:07 --> Input Class Initialized
INFO - 2023-04-28 06:34:07 --> Language Class Initialized
INFO - 2023-04-28 06:34:07 --> Loader Class Initialized
INFO - 2023-04-28 06:34:07 --> Loader Class Initialized
INFO - 2023-04-28 06:34:07 --> Controller Class Initialized
INFO - 2023-04-28 06:34:07 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 06:34:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:07 --> Final output sent to browser
INFO - 2023-04-28 06:34:07 --> Database Driver Class Initialized
DEBUG - 2023-04-28 06:34:07 --> Total execution time: 0.0047
INFO - 2023-04-28 06:34:07 --> Config Class Initialized
INFO - 2023-04-28 06:34:07 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:07 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:07 --> URI Class Initialized
INFO - 2023-04-28 06:34:07 --> Router Class Initialized
INFO - 2023-04-28 06:34:07 --> Output Class Initialized
INFO - 2023-04-28 06:34:07 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:07 --> Input Class Initialized
INFO - 2023-04-28 06:34:07 --> Language Class Initialized
INFO - 2023-04-28 06:34:07 --> Loader Class Initialized
INFO - 2023-04-28 06:34:07 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:07 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:07 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:07 --> Model "Login_model" initialized
INFO - 2023-04-28 06:34:07 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:07 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:07 --> Total execution time: 0.0206
INFO - 2023-04-28 06:34:07 --> Config Class Initialized
INFO - 2023-04-28 06:34:07 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:07 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:07 --> URI Class Initialized
INFO - 2023-04-28 06:34:07 --> Router Class Initialized
INFO - 2023-04-28 06:34:07 --> Output Class Initialized
INFO - 2023-04-28 06:34:07 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:07 --> Input Class Initialized
INFO - 2023-04-28 06:34:07 --> Language Class Initialized
INFO - 2023-04-28 06:34:07 --> Loader Class Initialized
INFO - 2023-04-28 06:34:07 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:07 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:07 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:07 --> Final output sent to browser
INFO - 2023-04-28 06:34:07 --> Model "Cluster_model" initialized
DEBUG - 2023-04-28 06:34:07 --> Total execution time: 0.0254
INFO - 2023-04-28 06:34:07 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:07 --> Total execution time: 0.0137
INFO - 2023-04-28 06:34:10 --> Config Class Initialized
INFO - 2023-04-28 06:34:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:10 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:10 --> URI Class Initialized
INFO - 2023-04-28 06:34:10 --> Router Class Initialized
INFO - 2023-04-28 06:34:10 --> Output Class Initialized
INFO - 2023-04-28 06:34:10 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:10 --> Input Class Initialized
INFO - 2023-04-28 06:34:10 --> Language Class Initialized
INFO - 2023-04-28 06:34:10 --> Loader Class Initialized
INFO - 2023-04-28 06:34:10 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:10 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:10 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:10 --> Total execution time: 0.0163
INFO - 2023-04-28 06:34:10 --> Config Class Initialized
INFO - 2023-04-28 06:34:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:10 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:10 --> URI Class Initialized
INFO - 2023-04-28 06:34:10 --> Router Class Initialized
INFO - 2023-04-28 06:34:10 --> Output Class Initialized
INFO - 2023-04-28 06:34:10 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:10 --> Input Class Initialized
INFO - 2023-04-28 06:34:10 --> Language Class Initialized
INFO - 2023-04-28 06:34:10 --> Loader Class Initialized
INFO - 2023-04-28 06:34:10 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:10 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:10 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:10 --> Total execution time: 0.0115
INFO - 2023-04-28 06:34:13 --> Config Class Initialized
INFO - 2023-04-28 06:34:13 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:13 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:13 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:13 --> URI Class Initialized
INFO - 2023-04-28 06:34:13 --> Router Class Initialized
INFO - 2023-04-28 06:34:13 --> Output Class Initialized
INFO - 2023-04-28 06:34:13 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:13 --> Input Class Initialized
INFO - 2023-04-28 06:34:13 --> Language Class Initialized
INFO - 2023-04-28 06:34:13 --> Loader Class Initialized
INFO - 2023-04-28 06:34:13 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:13 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:13 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:13 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:13 --> Total execution time: 0.0185
INFO - 2023-04-28 06:34:13 --> Config Class Initialized
INFO - 2023-04-28 06:34:13 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:13 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:13 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:13 --> URI Class Initialized
INFO - 2023-04-28 06:34:13 --> Router Class Initialized
INFO - 2023-04-28 06:34:13 --> Output Class Initialized
INFO - 2023-04-28 06:34:13 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:13 --> Input Class Initialized
INFO - 2023-04-28 06:34:13 --> Language Class Initialized
INFO - 2023-04-28 06:34:13 --> Loader Class Initialized
INFO - 2023-04-28 06:34:13 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:13 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:13 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:13 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:13 --> Total execution time: 0.0528
INFO - 2023-04-28 06:34:21 --> Config Class Initialized
INFO - 2023-04-28 06:34:21 --> Config Class Initialized
INFO - 2023-04-28 06:34:21 --> Hooks Class Initialized
INFO - 2023-04-28 06:34:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 06:34:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:21 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:21 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:21 --> URI Class Initialized
INFO - 2023-04-28 06:34:21 --> URI Class Initialized
INFO - 2023-04-28 06:34:21 --> Router Class Initialized
INFO - 2023-04-28 06:34:21 --> Router Class Initialized
INFO - 2023-04-28 06:34:21 --> Output Class Initialized
INFO - 2023-04-28 06:34:21 --> Output Class Initialized
INFO - 2023-04-28 06:34:21 --> Security Class Initialized
INFO - 2023-04-28 06:34:21 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:21 --> Input Class Initialized
DEBUG - 2023-04-28 06:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:21 --> Language Class Initialized
INFO - 2023-04-28 06:34:21 --> Input Class Initialized
INFO - 2023-04-28 06:34:21 --> Loader Class Initialized
INFO - 2023-04-28 06:34:21 --> Language Class Initialized
INFO - 2023-04-28 06:34:21 --> Controller Class Initialized
INFO - 2023-04-28 06:34:21 --> Loader Class Initialized
DEBUG - 2023-04-28 06:34:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:21 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:21 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:21 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:21 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:21 --> Total execution time: 0.0208
INFO - 2023-04-28 06:34:21 --> Final output sent to browser
INFO - 2023-04-28 06:34:21 --> Config Class Initialized
DEBUG - 2023-04-28 06:34:21 --> Total execution time: 0.0226
INFO - 2023-04-28 06:34:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:21 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:21 --> URI Class Initialized
INFO - 2023-04-28 06:34:21 --> Router Class Initialized
INFO - 2023-04-28 06:34:21 --> Output Class Initialized
INFO - 2023-04-28 06:34:21 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:21 --> Input Class Initialized
INFO - 2023-04-28 06:34:21 --> Language Class Initialized
INFO - 2023-04-28 06:34:21 --> Config Class Initialized
INFO - 2023-04-28 06:34:21 --> Loader Class Initialized
INFO - 2023-04-28 06:34:21 --> Hooks Class Initialized
INFO - 2023-04-28 06:34:21 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 06:34:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:21 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:21 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:21 --> URI Class Initialized
INFO - 2023-04-28 06:34:21 --> Router Class Initialized
INFO - 2023-04-28 06:34:21 --> Output Class Initialized
INFO - 2023-04-28 06:34:21 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:21 --> Input Class Initialized
INFO - 2023-04-28 06:34:21 --> Language Class Initialized
INFO - 2023-04-28 06:34:21 --> Loader Class Initialized
INFO - 2023-04-28 06:34:21 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:21 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:21 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:21 --> Total execution time: 0.0119
INFO - 2023-04-28 06:34:21 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:21 --> Total execution time: 0.0127
INFO - 2023-04-28 06:34:26 --> Config Class Initialized
INFO - 2023-04-28 06:34:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:26 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:26 --> URI Class Initialized
INFO - 2023-04-28 06:34:26 --> Router Class Initialized
INFO - 2023-04-28 06:34:26 --> Output Class Initialized
INFO - 2023-04-28 06:34:26 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:26 --> Input Class Initialized
INFO - 2023-04-28 06:34:26 --> Language Class Initialized
INFO - 2023-04-28 06:34:26 --> Loader Class Initialized
INFO - 2023-04-28 06:34:26 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:26 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:26 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:26 --> Total execution time: 0.0146
INFO - 2023-04-28 06:34:26 --> Config Class Initialized
INFO - 2023-04-28 06:34:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:26 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:26 --> URI Class Initialized
INFO - 2023-04-28 06:34:26 --> Router Class Initialized
INFO - 2023-04-28 06:34:26 --> Output Class Initialized
INFO - 2023-04-28 06:34:26 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:26 --> Input Class Initialized
INFO - 2023-04-28 06:34:26 --> Language Class Initialized
INFO - 2023-04-28 06:34:26 --> Loader Class Initialized
INFO - 2023-04-28 06:34:26 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:26 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:26 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:26 --> Total execution time: 0.0121
INFO - 2023-04-28 06:34:26 --> Config Class Initialized
INFO - 2023-04-28 06:34:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:26 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:26 --> URI Class Initialized
INFO - 2023-04-28 06:34:26 --> Router Class Initialized
INFO - 2023-04-28 06:34:26 --> Output Class Initialized
INFO - 2023-04-28 06:34:26 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:26 --> Input Class Initialized
INFO - 2023-04-28 06:34:26 --> Language Class Initialized
INFO - 2023-04-28 06:34:26 --> Loader Class Initialized
INFO - 2023-04-28 06:34:26 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:26 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:26 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:26 --> Total execution time: 0.0978
INFO - 2023-04-28 06:34:26 --> Config Class Initialized
INFO - 2023-04-28 06:34:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:26 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:26 --> URI Class Initialized
INFO - 2023-04-28 06:34:26 --> Router Class Initialized
INFO - 2023-04-28 06:34:26 --> Output Class Initialized
INFO - 2023-04-28 06:34:26 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:26 --> Input Class Initialized
INFO - 2023-04-28 06:34:26 --> Language Class Initialized
INFO - 2023-04-28 06:34:26 --> Loader Class Initialized
INFO - 2023-04-28 06:34:26 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:26 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:26 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:26 --> Total execution time: 0.0113
INFO - 2023-04-28 06:34:57 --> Config Class Initialized
INFO - 2023-04-28 06:34:57 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:57 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:57 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:57 --> URI Class Initialized
INFO - 2023-04-28 06:34:57 --> Router Class Initialized
INFO - 2023-04-28 06:34:57 --> Output Class Initialized
INFO - 2023-04-28 06:34:57 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:57 --> Input Class Initialized
INFO - 2023-04-28 06:34:57 --> Language Class Initialized
INFO - 2023-04-28 06:34:57 --> Loader Class Initialized
INFO - 2023-04-28 06:34:57 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:57 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:57 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:57 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:57 --> Total execution time: 0.0132
INFO - 2023-04-28 06:34:57 --> Config Class Initialized
INFO - 2023-04-28 06:34:57 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:57 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:57 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:57 --> URI Class Initialized
INFO - 2023-04-28 06:34:57 --> Router Class Initialized
INFO - 2023-04-28 06:34:57 --> Output Class Initialized
INFO - 2023-04-28 06:34:57 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:57 --> Input Class Initialized
INFO - 2023-04-28 06:34:57 --> Language Class Initialized
INFO - 2023-04-28 06:34:57 --> Loader Class Initialized
INFO - 2023-04-28 06:34:57 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:57 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:57 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:57 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:57 --> Model "Login_model" initialized
INFO - 2023-04-28 06:34:57 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:57 --> Total execution time: 0.0420
INFO - 2023-04-28 06:34:58 --> Config Class Initialized
INFO - 2023-04-28 06:34:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:58 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:58 --> URI Class Initialized
INFO - 2023-04-28 06:34:58 --> Router Class Initialized
INFO - 2023-04-28 06:34:58 --> Output Class Initialized
INFO - 2023-04-28 06:34:58 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:58 --> Input Class Initialized
INFO - 2023-04-28 06:34:58 --> Language Class Initialized
INFO - 2023-04-28 06:34:58 --> Loader Class Initialized
INFO - 2023-04-28 06:34:58 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:58 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:58 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:58 --> Total execution time: 0.0143
INFO - 2023-04-28 06:34:58 --> Config Class Initialized
INFO - 2023-04-28 06:34:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:34:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:34:58 --> Utf8 Class Initialized
INFO - 2023-04-28 06:34:58 --> URI Class Initialized
INFO - 2023-04-28 06:34:58 --> Router Class Initialized
INFO - 2023-04-28 06:34:58 --> Output Class Initialized
INFO - 2023-04-28 06:34:58 --> Security Class Initialized
DEBUG - 2023-04-28 06:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:34:58 --> Input Class Initialized
INFO - 2023-04-28 06:34:58 --> Language Class Initialized
INFO - 2023-04-28 06:34:58 --> Loader Class Initialized
INFO - 2023-04-28 06:34:58 --> Controller Class Initialized
DEBUG - 2023-04-28 06:34:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:34:58 --> Database Driver Class Initialized
INFO - 2023-04-28 06:34:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:34:58 --> Final output sent to browser
DEBUG - 2023-04-28 06:34:58 --> Total execution time: 0.4319
INFO - 2023-04-28 06:35:02 --> Config Class Initialized
INFO - 2023-04-28 06:35:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:35:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:35:02 --> Utf8 Class Initialized
INFO - 2023-04-28 06:35:02 --> URI Class Initialized
INFO - 2023-04-28 06:35:02 --> Router Class Initialized
INFO - 2023-04-28 06:35:02 --> Output Class Initialized
INFO - 2023-04-28 06:35:02 --> Security Class Initialized
DEBUG - 2023-04-28 06:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:35:02 --> Input Class Initialized
INFO - 2023-04-28 06:35:02 --> Language Class Initialized
INFO - 2023-04-28 06:35:02 --> Loader Class Initialized
INFO - 2023-04-28 06:35:02 --> Controller Class Initialized
DEBUG - 2023-04-28 06:35:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:35:02 --> Database Driver Class Initialized
INFO - 2023-04-28 06:35:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:35:02 --> Final output sent to browser
DEBUG - 2023-04-28 06:35:02 --> Total execution time: 0.0199
INFO - 2023-04-28 06:35:07 --> Config Class Initialized
INFO - 2023-04-28 06:35:07 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:35:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:35:07 --> Utf8 Class Initialized
INFO - 2023-04-28 06:35:07 --> URI Class Initialized
INFO - 2023-04-28 06:35:07 --> Router Class Initialized
INFO - 2023-04-28 06:35:07 --> Output Class Initialized
INFO - 2023-04-28 06:35:07 --> Security Class Initialized
DEBUG - 2023-04-28 06:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:35:07 --> Input Class Initialized
INFO - 2023-04-28 06:35:07 --> Language Class Initialized
INFO - 2023-04-28 06:35:07 --> Loader Class Initialized
INFO - 2023-04-28 06:35:07 --> Controller Class Initialized
DEBUG - 2023-04-28 06:35:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:35:07 --> Database Driver Class Initialized
INFO - 2023-04-28 06:35:07 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:35:07 --> Final output sent to browser
DEBUG - 2023-04-28 06:35:07 --> Total execution time: 0.0175
INFO - 2023-04-28 06:35:07 --> Config Class Initialized
INFO - 2023-04-28 06:35:07 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:35:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:35:07 --> Utf8 Class Initialized
INFO - 2023-04-28 06:35:07 --> URI Class Initialized
INFO - 2023-04-28 06:35:07 --> Router Class Initialized
INFO - 2023-04-28 06:35:07 --> Output Class Initialized
INFO - 2023-04-28 06:35:07 --> Security Class Initialized
DEBUG - 2023-04-28 06:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:35:07 --> Input Class Initialized
INFO - 2023-04-28 06:35:07 --> Language Class Initialized
INFO - 2023-04-28 06:35:07 --> Loader Class Initialized
INFO - 2023-04-28 06:35:07 --> Controller Class Initialized
DEBUG - 2023-04-28 06:35:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:35:07 --> Database Driver Class Initialized
INFO - 2023-04-28 06:35:07 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:35:07 --> Final output sent to browser
DEBUG - 2023-04-28 06:35:07 --> Total execution time: 0.0218
INFO - 2023-04-28 06:35:12 --> Config Class Initialized
INFO - 2023-04-28 06:35:12 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:35:12 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:35:12 --> Utf8 Class Initialized
INFO - 2023-04-28 06:35:12 --> URI Class Initialized
INFO - 2023-04-28 06:35:12 --> Router Class Initialized
INFO - 2023-04-28 06:35:12 --> Output Class Initialized
INFO - 2023-04-28 06:35:12 --> Security Class Initialized
DEBUG - 2023-04-28 06:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:35:12 --> Input Class Initialized
INFO - 2023-04-28 06:35:12 --> Language Class Initialized
INFO - 2023-04-28 06:35:12 --> Loader Class Initialized
INFO - 2023-04-28 06:35:12 --> Controller Class Initialized
DEBUG - 2023-04-28 06:35:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:35:12 --> Database Driver Class Initialized
INFO - 2023-04-28 06:35:12 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:35:12 --> Final output sent to browser
DEBUG - 2023-04-28 06:35:12 --> Total execution time: 0.0184
INFO - 2023-04-28 06:35:17 --> Config Class Initialized
INFO - 2023-04-28 06:35:17 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:35:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:35:17 --> Utf8 Class Initialized
INFO - 2023-04-28 06:35:17 --> URI Class Initialized
INFO - 2023-04-28 06:35:17 --> Router Class Initialized
INFO - 2023-04-28 06:35:17 --> Output Class Initialized
INFO - 2023-04-28 06:35:17 --> Security Class Initialized
DEBUG - 2023-04-28 06:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:35:17 --> Input Class Initialized
INFO - 2023-04-28 06:35:17 --> Language Class Initialized
INFO - 2023-04-28 06:35:17 --> Loader Class Initialized
INFO - 2023-04-28 06:35:17 --> Controller Class Initialized
DEBUG - 2023-04-28 06:35:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:35:17 --> Database Driver Class Initialized
INFO - 2023-04-28 06:35:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:35:17 --> Final output sent to browser
DEBUG - 2023-04-28 06:35:17 --> Total execution time: 0.0109
INFO - 2023-04-28 06:35:17 --> Config Class Initialized
INFO - 2023-04-28 06:35:17 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:35:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:35:17 --> Utf8 Class Initialized
INFO - 2023-04-28 06:35:17 --> URI Class Initialized
INFO - 2023-04-28 06:35:17 --> Router Class Initialized
INFO - 2023-04-28 06:35:17 --> Output Class Initialized
INFO - 2023-04-28 06:35:17 --> Security Class Initialized
DEBUG - 2023-04-28 06:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:35:17 --> Input Class Initialized
INFO - 2023-04-28 06:35:17 --> Language Class Initialized
INFO - 2023-04-28 06:35:17 --> Loader Class Initialized
INFO - 2023-04-28 06:35:17 --> Controller Class Initialized
DEBUG - 2023-04-28 06:35:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:35:17 --> Database Driver Class Initialized
INFO - 2023-04-28 06:35:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:35:17 --> Final output sent to browser
DEBUG - 2023-04-28 06:35:17 --> Total execution time: 0.0145
INFO - 2023-04-28 06:35:22 --> Config Class Initialized
INFO - 2023-04-28 06:35:22 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:35:22 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:35:22 --> Utf8 Class Initialized
INFO - 2023-04-28 06:35:22 --> URI Class Initialized
INFO - 2023-04-28 06:35:22 --> Router Class Initialized
INFO - 2023-04-28 06:35:22 --> Output Class Initialized
INFO - 2023-04-28 06:35:22 --> Security Class Initialized
DEBUG - 2023-04-28 06:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:35:22 --> Input Class Initialized
INFO - 2023-04-28 06:35:22 --> Language Class Initialized
INFO - 2023-04-28 06:35:22 --> Loader Class Initialized
INFO - 2023-04-28 06:35:22 --> Controller Class Initialized
DEBUG - 2023-04-28 06:35:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:35:22 --> Database Driver Class Initialized
INFO - 2023-04-28 06:35:22 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:35:22 --> Final output sent to browser
DEBUG - 2023-04-28 06:35:22 --> Total execution time: 0.0169
INFO - 2023-04-28 06:35:27 --> Config Class Initialized
INFO - 2023-04-28 06:35:27 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:35:27 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:35:27 --> Utf8 Class Initialized
INFO - 2023-04-28 06:35:27 --> URI Class Initialized
INFO - 2023-04-28 06:35:27 --> Router Class Initialized
INFO - 2023-04-28 06:35:27 --> Output Class Initialized
INFO - 2023-04-28 06:35:27 --> Security Class Initialized
DEBUG - 2023-04-28 06:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:35:27 --> Input Class Initialized
INFO - 2023-04-28 06:35:27 --> Language Class Initialized
INFO - 2023-04-28 06:35:27 --> Loader Class Initialized
INFO - 2023-04-28 06:35:27 --> Controller Class Initialized
DEBUG - 2023-04-28 06:35:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:35:27 --> Database Driver Class Initialized
INFO - 2023-04-28 06:35:27 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:35:27 --> Final output sent to browser
DEBUG - 2023-04-28 06:35:27 --> Total execution time: 0.0116
INFO - 2023-04-28 06:35:27 --> Config Class Initialized
INFO - 2023-04-28 06:35:27 --> Hooks Class Initialized
DEBUG - 2023-04-28 06:35:27 --> UTF-8 Support Enabled
INFO - 2023-04-28 06:35:27 --> Utf8 Class Initialized
INFO - 2023-04-28 06:35:27 --> URI Class Initialized
INFO - 2023-04-28 06:35:27 --> Router Class Initialized
INFO - 2023-04-28 06:35:27 --> Output Class Initialized
INFO - 2023-04-28 06:35:27 --> Security Class Initialized
DEBUG - 2023-04-28 06:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 06:35:27 --> Input Class Initialized
INFO - 2023-04-28 06:35:27 --> Language Class Initialized
INFO - 2023-04-28 06:35:27 --> Loader Class Initialized
INFO - 2023-04-28 06:35:27 --> Controller Class Initialized
DEBUG - 2023-04-28 06:35:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 06:35:27 --> Database Driver Class Initialized
INFO - 2023-04-28 06:35:27 --> Model "Cluster_model" initialized
INFO - 2023-04-28 06:35:27 --> Final output sent to browser
DEBUG - 2023-04-28 06:35:27 --> Total execution time: 0.0141
INFO - 2023-04-28 07:08:19 --> Config Class Initialized
INFO - 2023-04-28 07:08:19 --> Config Class Initialized
INFO - 2023-04-28 07:08:19 --> Hooks Class Initialized
INFO - 2023-04-28 07:08:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:08:19 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 07:08:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:08:19 --> Utf8 Class Initialized
INFO - 2023-04-28 07:08:19 --> Utf8 Class Initialized
INFO - 2023-04-28 07:08:19 --> URI Class Initialized
INFO - 2023-04-28 07:08:19 --> URI Class Initialized
INFO - 2023-04-28 07:08:19 --> Router Class Initialized
INFO - 2023-04-28 07:08:19 --> Router Class Initialized
INFO - 2023-04-28 07:08:19 --> Output Class Initialized
INFO - 2023-04-28 07:08:19 --> Output Class Initialized
INFO - 2023-04-28 07:08:19 --> Security Class Initialized
INFO - 2023-04-28 07:08:19 --> Security Class Initialized
DEBUG - 2023-04-28 07:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 07:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:08:19 --> Input Class Initialized
INFO - 2023-04-28 07:08:19 --> Input Class Initialized
INFO - 2023-04-28 07:08:19 --> Language Class Initialized
INFO - 2023-04-28 07:08:19 --> Language Class Initialized
INFO - 2023-04-28 07:08:19 --> Loader Class Initialized
INFO - 2023-04-28 07:08:19 --> Loader Class Initialized
INFO - 2023-04-28 07:08:19 --> Controller Class Initialized
INFO - 2023-04-28 07:08:19 --> Controller Class Initialized
DEBUG - 2023-04-28 07:08:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 07:08:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:08:19 --> Database Driver Class Initialized
INFO - 2023-04-28 07:08:19 --> Database Driver Class Initialized
INFO - 2023-04-28 07:08:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:08:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:08:19 --> Final output sent to browser
DEBUG - 2023-04-28 07:08:19 --> Total execution time: 0.0219
INFO - 2023-04-28 07:08:19 --> Final output sent to browser
INFO - 2023-04-28 07:08:19 --> Config Class Initialized
INFO - 2023-04-28 07:08:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:08:19 --> Total execution time: 0.0251
DEBUG - 2023-04-28 07:08:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:08:19 --> Utf8 Class Initialized
INFO - 2023-04-28 07:08:19 --> Config Class Initialized
INFO - 2023-04-28 07:08:19 --> URI Class Initialized
INFO - 2023-04-28 07:08:20 --> Hooks Class Initialized
INFO - 2023-04-28 07:08:20 --> Router Class Initialized
DEBUG - 2023-04-28 07:08:20 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:08:20 --> Output Class Initialized
INFO - 2023-04-28 07:08:20 --> Utf8 Class Initialized
INFO - 2023-04-28 07:08:20 --> Security Class Initialized
DEBUG - 2023-04-28 07:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:08:20 --> URI Class Initialized
INFO - 2023-04-28 07:08:20 --> Input Class Initialized
INFO - 2023-04-28 07:08:20 --> Router Class Initialized
INFO - 2023-04-28 07:08:20 --> Language Class Initialized
INFO - 2023-04-28 07:08:20 --> Output Class Initialized
INFO - 2023-04-28 07:08:20 --> Security Class Initialized
INFO - 2023-04-28 07:08:20 --> Loader Class Initialized
DEBUG - 2023-04-28 07:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:08:20 --> Controller Class Initialized
INFO - 2023-04-28 07:08:20 --> Input Class Initialized
DEBUG - 2023-04-28 07:08:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:08:20 --> Language Class Initialized
INFO - 2023-04-28 07:08:20 --> Database Driver Class Initialized
INFO - 2023-04-28 07:08:20 --> Loader Class Initialized
INFO - 2023-04-28 07:08:20 --> Controller Class Initialized
DEBUG - 2023-04-28 07:08:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:08:20 --> Database Driver Class Initialized
INFO - 2023-04-28 07:08:20 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:08:20 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:08:20 --> Final output sent to browser
DEBUG - 2023-04-28 07:08:20 --> Total execution time: 0.1467
INFO - 2023-04-28 07:08:20 --> Final output sent to browser
DEBUG - 2023-04-28 07:08:20 --> Total execution time: 0.1001
INFO - 2023-04-28 07:11:18 --> Config Class Initialized
INFO - 2023-04-28 07:11:18 --> Config Class Initialized
INFO - 2023-04-28 07:11:18 --> Hooks Class Initialized
INFO - 2023-04-28 07:11:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:11:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 07:11:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:11:18 --> Utf8 Class Initialized
INFO - 2023-04-28 07:11:18 --> Utf8 Class Initialized
INFO - 2023-04-28 07:11:18 --> URI Class Initialized
INFO - 2023-04-28 07:11:18 --> URI Class Initialized
INFO - 2023-04-28 07:11:18 --> Router Class Initialized
INFO - 2023-04-28 07:11:18 --> Router Class Initialized
INFO - 2023-04-28 07:11:18 --> Output Class Initialized
INFO - 2023-04-28 07:11:18 --> Output Class Initialized
INFO - 2023-04-28 07:11:18 --> Security Class Initialized
INFO - 2023-04-28 07:11:18 --> Security Class Initialized
DEBUG - 2023-04-28 07:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 07:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:11:18 --> Input Class Initialized
INFO - 2023-04-28 07:11:18 --> Input Class Initialized
INFO - 2023-04-28 07:11:18 --> Language Class Initialized
INFO - 2023-04-28 07:11:18 --> Language Class Initialized
INFO - 2023-04-28 07:11:18 --> Loader Class Initialized
INFO - 2023-04-28 07:11:18 --> Loader Class Initialized
INFO - 2023-04-28 07:11:18 --> Controller Class Initialized
INFO - 2023-04-28 07:11:18 --> Controller Class Initialized
DEBUG - 2023-04-28 07:11:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 07:11:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:11:18 --> Database Driver Class Initialized
INFO - 2023-04-28 07:11:18 --> Database Driver Class Initialized
INFO - 2023-04-28 07:11:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:11:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:11:18 --> Final output sent to browser
DEBUG - 2023-04-28 07:11:18 --> Total execution time: 0.0530
INFO - 2023-04-28 07:11:18 --> Final output sent to browser
INFO - 2023-04-28 07:11:18 --> Config Class Initialized
INFO - 2023-04-28 07:11:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:11:18 --> Total execution time: 0.0552
DEBUG - 2023-04-28 07:11:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:11:18 --> Utf8 Class Initialized
INFO - 2023-04-28 07:11:18 --> URI Class Initialized
INFO - 2023-04-28 07:11:18 --> Router Class Initialized
INFO - 2023-04-28 07:11:18 --> Output Class Initialized
INFO - 2023-04-28 07:11:18 --> Config Class Initialized
INFO - 2023-04-28 07:11:18 --> Security Class Initialized
INFO - 2023-04-28 07:11:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 07:11:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:11:18 --> Input Class Initialized
INFO - 2023-04-28 07:11:18 --> Utf8 Class Initialized
INFO - 2023-04-28 07:11:18 --> Language Class Initialized
INFO - 2023-04-28 07:11:18 --> URI Class Initialized
INFO - 2023-04-28 07:11:18 --> Loader Class Initialized
INFO - 2023-04-28 07:11:18 --> Router Class Initialized
INFO - 2023-04-28 07:11:18 --> Controller Class Initialized
INFO - 2023-04-28 07:11:18 --> Output Class Initialized
DEBUG - 2023-04-28 07:11:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:11:18 --> Security Class Initialized
INFO - 2023-04-28 07:11:18 --> Database Driver Class Initialized
DEBUG - 2023-04-28 07:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:11:18 --> Input Class Initialized
INFO - 2023-04-28 07:11:18 --> Language Class Initialized
INFO - 2023-04-28 07:11:18 --> Loader Class Initialized
INFO - 2023-04-28 07:11:18 --> Controller Class Initialized
DEBUG - 2023-04-28 07:11:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:11:18 --> Database Driver Class Initialized
INFO - 2023-04-28 07:11:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:11:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:11:18 --> Final output sent to browser
DEBUG - 2023-04-28 07:11:18 --> Total execution time: 0.1345
INFO - 2023-04-28 07:11:18 --> Final output sent to browser
DEBUG - 2023-04-28 07:11:18 --> Total execution time: 0.0958
INFO - 2023-04-28 07:11:42 --> Config Class Initialized
INFO - 2023-04-28 07:11:42 --> Config Class Initialized
INFO - 2023-04-28 07:11:42 --> Hooks Class Initialized
INFO - 2023-04-28 07:11:42 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:11:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:11:42 --> Utf8 Class Initialized
DEBUG - 2023-04-28 07:11:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:11:42 --> URI Class Initialized
INFO - 2023-04-28 07:11:42 --> Utf8 Class Initialized
INFO - 2023-04-28 07:11:42 --> Router Class Initialized
INFO - 2023-04-28 07:11:42 --> URI Class Initialized
INFO - 2023-04-28 07:11:42 --> Output Class Initialized
INFO - 2023-04-28 07:11:42 --> Router Class Initialized
INFO - 2023-04-28 07:11:42 --> Security Class Initialized
INFO - 2023-04-28 07:11:42 --> Output Class Initialized
DEBUG - 2023-04-28 07:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:11:42 --> Security Class Initialized
INFO - 2023-04-28 07:11:42 --> Input Class Initialized
DEBUG - 2023-04-28 07:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:11:42 --> Language Class Initialized
INFO - 2023-04-28 07:11:42 --> Input Class Initialized
INFO - 2023-04-28 07:11:42 --> Language Class Initialized
INFO - 2023-04-28 07:11:42 --> Loader Class Initialized
INFO - 2023-04-28 07:11:42 --> Loader Class Initialized
INFO - 2023-04-28 07:11:42 --> Controller Class Initialized
INFO - 2023-04-28 07:11:42 --> Controller Class Initialized
DEBUG - 2023-04-28 07:11:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 07:11:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:11:42 --> Database Driver Class Initialized
INFO - 2023-04-28 07:11:42 --> Database Driver Class Initialized
INFO - 2023-04-28 07:11:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:11:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:11:42 --> Final output sent to browser
INFO - 2023-04-28 07:11:42 --> Final output sent to browser
DEBUG - 2023-04-28 07:11:42 --> Total execution time: 0.0598
DEBUG - 2023-04-28 07:11:42 --> Total execution time: 0.0598
INFO - 2023-04-28 07:11:42 --> Config Class Initialized
INFO - 2023-04-28 07:11:42 --> Config Class Initialized
INFO - 2023-04-28 07:11:42 --> Hooks Class Initialized
INFO - 2023-04-28 07:11:42 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 07:11:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:11:42 --> Utf8 Class Initialized
INFO - 2023-04-28 07:11:42 --> Utf8 Class Initialized
INFO - 2023-04-28 07:11:42 --> URI Class Initialized
INFO - 2023-04-28 07:11:42 --> URI Class Initialized
INFO - 2023-04-28 07:11:42 --> Router Class Initialized
INFO - 2023-04-28 07:11:42 --> Router Class Initialized
INFO - 2023-04-28 07:11:42 --> Output Class Initialized
INFO - 2023-04-28 07:11:42 --> Output Class Initialized
INFO - 2023-04-28 07:11:42 --> Security Class Initialized
INFO - 2023-04-28 07:11:42 --> Security Class Initialized
DEBUG - 2023-04-28 07:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 07:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:11:42 --> Input Class Initialized
INFO - 2023-04-28 07:11:42 --> Input Class Initialized
INFO - 2023-04-28 07:11:42 --> Language Class Initialized
INFO - 2023-04-28 07:11:42 --> Language Class Initialized
INFO - 2023-04-28 07:11:42 --> Loader Class Initialized
INFO - 2023-04-28 07:11:42 --> Loader Class Initialized
INFO - 2023-04-28 07:11:42 --> Controller Class Initialized
INFO - 2023-04-28 07:11:42 --> Controller Class Initialized
DEBUG - 2023-04-28 07:11:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 07:11:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:11:42 --> Database Driver Class Initialized
INFO - 2023-04-28 07:11:42 --> Database Driver Class Initialized
INFO - 2023-04-28 07:11:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:11:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:11:42 --> Final output sent to browser
DEBUG - 2023-04-28 07:11:42 --> Total execution time: 0.0169
INFO - 2023-04-28 07:11:42 --> Final output sent to browser
DEBUG - 2023-04-28 07:11:42 --> Total execution time: 0.0194
INFO - 2023-04-28 07:25:12 --> Config Class Initialized
INFO - 2023-04-28 07:25:12 --> Hooks Class Initialized
INFO - 2023-04-28 07:25:12 --> Config Class Initialized
INFO - 2023-04-28 07:25:12 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:25:12 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:25:12 --> Utf8 Class Initialized
DEBUG - 2023-04-28 07:25:12 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:25:12 --> Utf8 Class Initialized
INFO - 2023-04-28 07:25:12 --> URI Class Initialized
INFO - 2023-04-28 07:25:12 --> URI Class Initialized
INFO - 2023-04-28 07:25:12 --> Router Class Initialized
INFO - 2023-04-28 07:25:12 --> Router Class Initialized
INFO - 2023-04-28 07:25:12 --> Output Class Initialized
INFO - 2023-04-28 07:25:12 --> Output Class Initialized
INFO - 2023-04-28 07:25:12 --> Security Class Initialized
INFO - 2023-04-28 07:25:12 --> Security Class Initialized
DEBUG - 2023-04-28 07:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 07:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:25:12 --> Input Class Initialized
INFO - 2023-04-28 07:25:12 --> Input Class Initialized
INFO - 2023-04-28 07:25:12 --> Language Class Initialized
INFO - 2023-04-28 07:25:12 --> Language Class Initialized
INFO - 2023-04-28 07:25:12 --> Loader Class Initialized
INFO - 2023-04-28 07:25:12 --> Loader Class Initialized
INFO - 2023-04-28 07:25:12 --> Controller Class Initialized
INFO - 2023-04-28 07:25:12 --> Controller Class Initialized
DEBUG - 2023-04-28 07:25:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 07:25:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:25:12 --> Database Driver Class Initialized
INFO - 2023-04-28 07:25:12 --> Database Driver Class Initialized
INFO - 2023-04-28 07:25:12 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:25:12 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:25:12 --> Final output sent to browser
DEBUG - 2023-04-28 07:25:12 --> Total execution time: 0.0705
INFO - 2023-04-28 07:25:12 --> Final output sent to browser
INFO - 2023-04-28 07:25:12 --> Config Class Initialized
DEBUG - 2023-04-28 07:25:12 --> Total execution time: 0.0742
INFO - 2023-04-28 07:25:12 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:25:12 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:25:12 --> Utf8 Class Initialized
INFO - 2023-04-28 07:25:12 --> URI Class Initialized
INFO - 2023-04-28 07:25:12 --> Router Class Initialized
INFO - 2023-04-28 07:25:12 --> Output Class Initialized
INFO - 2023-04-28 07:25:12 --> Security Class Initialized
DEBUG - 2023-04-28 07:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:25:12 --> Input Class Initialized
INFO - 2023-04-28 07:25:12 --> Language Class Initialized
INFO - 2023-04-28 07:25:12 --> Config Class Initialized
INFO - 2023-04-28 07:25:12 --> Hooks Class Initialized
INFO - 2023-04-28 07:25:12 --> Loader Class Initialized
DEBUG - 2023-04-28 07:25:12 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:25:12 --> Controller Class Initialized
INFO - 2023-04-28 07:25:12 --> Utf8 Class Initialized
DEBUG - 2023-04-28 07:25:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:25:12 --> URI Class Initialized
INFO - 2023-04-28 07:25:12 --> Router Class Initialized
INFO - 2023-04-28 07:25:12 --> Output Class Initialized
INFO - 2023-04-28 07:25:12 --> Security Class Initialized
INFO - 2023-04-28 07:25:12 --> Database Driver Class Initialized
DEBUG - 2023-04-28 07:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:25:12 --> Input Class Initialized
INFO - 2023-04-28 07:25:12 --> Language Class Initialized
INFO - 2023-04-28 07:25:12 --> Loader Class Initialized
INFO - 2023-04-28 07:25:12 --> Controller Class Initialized
DEBUG - 2023-04-28 07:25:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:25:12 --> Database Driver Class Initialized
INFO - 2023-04-28 07:25:12 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:25:12 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:25:12 --> Final output sent to browser
DEBUG - 2023-04-28 07:25:12 --> Total execution time: 0.0615
INFO - 2023-04-28 07:25:12 --> Final output sent to browser
DEBUG - 2023-04-28 07:25:12 --> Total execution time: 0.0260
INFO - 2023-04-28 07:32:00 --> Config Class Initialized
INFO - 2023-04-28 07:32:00 --> Config Class Initialized
INFO - 2023-04-28 07:32:00 --> Hooks Class Initialized
INFO - 2023-04-28 07:32:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:32:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 07:32:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:32:00 --> Utf8 Class Initialized
INFO - 2023-04-28 07:32:00 --> Utf8 Class Initialized
INFO - 2023-04-28 07:32:00 --> URI Class Initialized
INFO - 2023-04-28 07:32:00 --> URI Class Initialized
INFO - 2023-04-28 07:32:00 --> Router Class Initialized
INFO - 2023-04-28 07:32:00 --> Output Class Initialized
INFO - 2023-04-28 07:32:00 --> Router Class Initialized
INFO - 2023-04-28 07:32:00 --> Security Class Initialized
INFO - 2023-04-28 07:32:00 --> Output Class Initialized
DEBUG - 2023-04-28 07:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:32:00 --> Security Class Initialized
INFO - 2023-04-28 07:32:00 --> Input Class Initialized
DEBUG - 2023-04-28 07:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:32:00 --> Language Class Initialized
INFO - 2023-04-28 07:32:00 --> Input Class Initialized
INFO - 2023-04-28 07:32:00 --> Loader Class Initialized
INFO - 2023-04-28 07:32:00 --> Language Class Initialized
INFO - 2023-04-28 07:32:00 --> Controller Class Initialized
DEBUG - 2023-04-28 07:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:32:00 --> Loader Class Initialized
INFO - 2023-04-28 07:32:00 --> Controller Class Initialized
DEBUG - 2023-04-28 07:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:32:00 --> Database Driver Class Initialized
INFO - 2023-04-28 07:32:00 --> Database Driver Class Initialized
INFO - 2023-04-28 07:32:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:32:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:32:00 --> Final output sent to browser
DEBUG - 2023-04-28 07:32:00 --> Total execution time: 0.0398
INFO - 2023-04-28 07:32:00 --> Final output sent to browser
DEBUG - 2023-04-28 07:32:00 --> Total execution time: 0.0411
INFO - 2023-04-28 07:32:00 --> Config Class Initialized
INFO - 2023-04-28 07:32:00 --> Config Class Initialized
INFO - 2023-04-28 07:32:00 --> Hooks Class Initialized
INFO - 2023-04-28 07:32:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:32:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:32:00 --> Utf8 Class Initialized
INFO - 2023-04-28 07:32:00 --> URI Class Initialized
INFO - 2023-04-28 07:32:00 --> Router Class Initialized
INFO - 2023-04-28 07:32:00 --> Output Class Initialized
INFO - 2023-04-28 07:32:00 --> Security Class Initialized
DEBUG - 2023-04-28 07:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:32:00 --> Input Class Initialized
INFO - 2023-04-28 07:32:00 --> Language Class Initialized
INFO - 2023-04-28 07:32:00 --> Loader Class Initialized
INFO - 2023-04-28 07:32:00 --> Controller Class Initialized
DEBUG - 2023-04-28 07:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:32:00 --> Database Driver Class Initialized
DEBUG - 2023-04-28 07:32:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:32:00 --> Utf8 Class Initialized
INFO - 2023-04-28 07:32:00 --> URI Class Initialized
INFO - 2023-04-28 07:32:00 --> Router Class Initialized
INFO - 2023-04-28 07:32:00 --> Output Class Initialized
INFO - 2023-04-28 07:32:00 --> Security Class Initialized
DEBUG - 2023-04-28 07:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:32:00 --> Input Class Initialized
INFO - 2023-04-28 07:32:00 --> Language Class Initialized
INFO - 2023-04-28 07:32:00 --> Loader Class Initialized
INFO - 2023-04-28 07:32:00 --> Controller Class Initialized
DEBUG - 2023-04-28 07:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:32:00 --> Database Driver Class Initialized
INFO - 2023-04-28 07:32:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:32:00 --> Final output sent to browser
DEBUG - 2023-04-28 07:32:00 --> Total execution time: 0.0756
INFO - 2023-04-28 07:32:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:32:00 --> Final output sent to browser
DEBUG - 2023-04-28 07:32:00 --> Total execution time: 0.0823
INFO - 2023-04-28 07:32:10 --> Config Class Initialized
INFO - 2023-04-28 07:32:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:32:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:32:10 --> Utf8 Class Initialized
INFO - 2023-04-28 07:32:10 --> URI Class Initialized
INFO - 2023-04-28 07:32:10 --> Router Class Initialized
INFO - 2023-04-28 07:32:10 --> Output Class Initialized
INFO - 2023-04-28 07:32:10 --> Security Class Initialized
DEBUG - 2023-04-28 07:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:32:10 --> Input Class Initialized
INFO - 2023-04-28 07:32:10 --> Language Class Initialized
INFO - 2023-04-28 07:32:10 --> Loader Class Initialized
INFO - 2023-04-28 07:32:10 --> Controller Class Initialized
DEBUG - 2023-04-28 07:32:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:32:10 --> Database Driver Class Initialized
INFO - 2023-04-28 07:32:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:32:10 --> Final output sent to browser
DEBUG - 2023-04-28 07:32:10 --> Total execution time: 0.0631
INFO - 2023-04-28 07:32:10 --> Config Class Initialized
INFO - 2023-04-28 07:32:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:32:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:32:10 --> Utf8 Class Initialized
INFO - 2023-04-28 07:32:10 --> URI Class Initialized
INFO - 2023-04-28 07:32:10 --> Router Class Initialized
INFO - 2023-04-28 07:32:10 --> Output Class Initialized
INFO - 2023-04-28 07:32:10 --> Security Class Initialized
DEBUG - 2023-04-28 07:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:32:10 --> Input Class Initialized
INFO - 2023-04-28 07:32:10 --> Language Class Initialized
INFO - 2023-04-28 07:32:10 --> Loader Class Initialized
INFO - 2023-04-28 07:32:10 --> Controller Class Initialized
DEBUG - 2023-04-28 07:32:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:32:10 --> Database Driver Class Initialized
INFO - 2023-04-28 07:32:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:32:10 --> Final output sent to browser
DEBUG - 2023-04-28 07:32:10 --> Total execution time: 0.0630
INFO - 2023-04-28 07:32:10 --> Config Class Initialized
INFO - 2023-04-28 07:32:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:32:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:32:10 --> Utf8 Class Initialized
INFO - 2023-04-28 07:32:10 --> URI Class Initialized
INFO - 2023-04-28 07:32:10 --> Router Class Initialized
INFO - 2023-04-28 07:32:10 --> Output Class Initialized
INFO - 2023-04-28 07:32:10 --> Security Class Initialized
DEBUG - 2023-04-28 07:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:32:10 --> Input Class Initialized
INFO - 2023-04-28 07:32:10 --> Language Class Initialized
INFO - 2023-04-28 07:32:10 --> Loader Class Initialized
INFO - 2023-04-28 07:32:10 --> Controller Class Initialized
DEBUG - 2023-04-28 07:32:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:32:10 --> Database Driver Class Initialized
INFO - 2023-04-28 07:32:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:32:10 --> Final output sent to browser
DEBUG - 2023-04-28 07:32:10 --> Total execution time: 0.0236
INFO - 2023-04-28 07:32:10 --> Config Class Initialized
INFO - 2023-04-28 07:32:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:32:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:32:10 --> Utf8 Class Initialized
INFO - 2023-04-28 07:32:10 --> URI Class Initialized
INFO - 2023-04-28 07:32:10 --> Router Class Initialized
INFO - 2023-04-28 07:32:10 --> Output Class Initialized
INFO - 2023-04-28 07:32:10 --> Security Class Initialized
DEBUG - 2023-04-28 07:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:32:10 --> Input Class Initialized
INFO - 2023-04-28 07:32:10 --> Language Class Initialized
INFO - 2023-04-28 07:32:10 --> Loader Class Initialized
INFO - 2023-04-28 07:32:10 --> Controller Class Initialized
DEBUG - 2023-04-28 07:32:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:32:10 --> Database Driver Class Initialized
INFO - 2023-04-28 07:32:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:32:10 --> Final output sent to browser
DEBUG - 2023-04-28 07:32:10 --> Total execution time: 0.1062
INFO - 2023-04-28 07:33:33 --> Config Class Initialized
INFO - 2023-04-28 07:33:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:33:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:33:33 --> Utf8 Class Initialized
INFO - 2023-04-28 07:33:33 --> URI Class Initialized
INFO - 2023-04-28 07:33:33 --> Router Class Initialized
INFO - 2023-04-28 07:33:33 --> Output Class Initialized
INFO - 2023-04-28 07:33:33 --> Security Class Initialized
INFO - 2023-04-28 07:33:33 --> Config Class Initialized
DEBUG - 2023-04-28 07:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:33:33 --> Hooks Class Initialized
INFO - 2023-04-28 07:33:33 --> Input Class Initialized
DEBUG - 2023-04-28 07:33:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:33:33 --> Utf8 Class Initialized
INFO - 2023-04-28 07:33:33 --> Language Class Initialized
INFO - 2023-04-28 07:33:33 --> URI Class Initialized
INFO - 2023-04-28 07:33:33 --> Loader Class Initialized
INFO - 2023-04-28 07:33:33 --> Controller Class Initialized
DEBUG - 2023-04-28 07:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:33:33 --> Router Class Initialized
INFO - 2023-04-28 07:33:33 --> Database Driver Class Initialized
INFO - 2023-04-28 07:33:33 --> Output Class Initialized
INFO - 2023-04-28 07:33:33 --> Security Class Initialized
DEBUG - 2023-04-28 07:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:33:33 --> Input Class Initialized
INFO - 2023-04-28 07:33:33 --> Language Class Initialized
INFO - 2023-04-28 07:33:33 --> Loader Class Initialized
INFO - 2023-04-28 07:33:33 --> Controller Class Initialized
DEBUG - 2023-04-28 07:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:33:33 --> Database Driver Class Initialized
INFO - 2023-04-28 07:33:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:33:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:33:33 --> Final output sent to browser
DEBUG - 2023-04-28 07:33:33 --> Total execution time: 0.0541
INFO - 2023-04-28 07:33:33 --> Final output sent to browser
INFO - 2023-04-28 07:33:33 --> Config Class Initialized
DEBUG - 2023-04-28 07:33:33 --> Total execution time: 0.0590
INFO - 2023-04-28 07:33:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:33:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:33:33 --> Utf8 Class Initialized
INFO - 2023-04-28 07:33:33 --> URI Class Initialized
INFO - 2023-04-28 07:33:33 --> Router Class Initialized
INFO - 2023-04-28 07:33:33 --> Output Class Initialized
INFO - 2023-04-28 07:33:33 --> Security Class Initialized
DEBUG - 2023-04-28 07:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:33:33 --> Input Class Initialized
INFO - 2023-04-28 07:33:33 --> Config Class Initialized
INFO - 2023-04-28 07:33:33 --> Hooks Class Initialized
INFO - 2023-04-28 07:33:33 --> Language Class Initialized
DEBUG - 2023-04-28 07:33:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:33:33 --> Utf8 Class Initialized
INFO - 2023-04-28 07:33:33 --> URI Class Initialized
INFO - 2023-04-28 07:33:33 --> Loader Class Initialized
INFO - 2023-04-28 07:33:33 --> Router Class Initialized
INFO - 2023-04-28 07:33:33 --> Controller Class Initialized
INFO - 2023-04-28 07:33:33 --> Output Class Initialized
DEBUG - 2023-04-28 07:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:33:33 --> Security Class Initialized
DEBUG - 2023-04-28 07:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:33:33 --> Input Class Initialized
INFO - 2023-04-28 07:33:33 --> Database Driver Class Initialized
INFO - 2023-04-28 07:33:33 --> Language Class Initialized
INFO - 2023-04-28 07:33:33 --> Loader Class Initialized
INFO - 2023-04-28 07:33:33 --> Controller Class Initialized
DEBUG - 2023-04-28 07:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:33:33 --> Database Driver Class Initialized
INFO - 2023-04-28 07:33:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:33:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:33:33 --> Final output sent to browser
DEBUG - 2023-04-28 07:33:33 --> Total execution time: 0.1443
INFO - 2023-04-28 07:33:33 --> Final output sent to browser
DEBUG - 2023-04-28 07:33:33 --> Total execution time: 0.0933
INFO - 2023-04-28 07:35:49 --> Config Class Initialized
INFO - 2023-04-28 07:35:49 --> Hooks Class Initialized
INFO - 2023-04-28 07:35:49 --> Config Class Initialized
INFO - 2023-04-28 07:35:49 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:35:49 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:35:49 --> Utf8 Class Initialized
DEBUG - 2023-04-28 07:35:49 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:35:49 --> URI Class Initialized
INFO - 2023-04-28 07:35:49 --> Utf8 Class Initialized
INFO - 2023-04-28 07:35:49 --> Router Class Initialized
INFO - 2023-04-28 07:35:49 --> URI Class Initialized
INFO - 2023-04-28 07:35:49 --> Output Class Initialized
INFO - 2023-04-28 07:35:49 --> Router Class Initialized
INFO - 2023-04-28 07:35:49 --> Output Class Initialized
INFO - 2023-04-28 07:35:49 --> Security Class Initialized
INFO - 2023-04-28 07:35:49 --> Security Class Initialized
DEBUG - 2023-04-28 07:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 07:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:35:49 --> Input Class Initialized
INFO - 2023-04-28 07:35:49 --> Input Class Initialized
INFO - 2023-04-28 07:35:49 --> Language Class Initialized
INFO - 2023-04-28 07:35:49 --> Language Class Initialized
INFO - 2023-04-28 07:35:49 --> Loader Class Initialized
INFO - 2023-04-28 07:35:49 --> Loader Class Initialized
INFO - 2023-04-28 07:35:49 --> Controller Class Initialized
INFO - 2023-04-28 07:35:49 --> Controller Class Initialized
DEBUG - 2023-04-28 07:35:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 07:35:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:35:49 --> Database Driver Class Initialized
INFO - 2023-04-28 07:35:49 --> Database Driver Class Initialized
INFO - 2023-04-28 07:35:49 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:35:49 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:35:49 --> Final output sent to browser
DEBUG - 2023-04-28 07:35:49 --> Total execution time: 0.0267
INFO - 2023-04-28 07:35:49 --> Final output sent to browser
DEBUG - 2023-04-28 07:35:49 --> Total execution time: 0.0276
INFO - 2023-04-28 07:35:49 --> Config Class Initialized
INFO - 2023-04-28 07:35:49 --> Config Class Initialized
INFO - 2023-04-28 07:35:49 --> Hooks Class Initialized
INFO - 2023-04-28 07:35:49 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:35:49 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:35:49 --> Utf8 Class Initialized
DEBUG - 2023-04-28 07:35:49 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:35:49 --> URI Class Initialized
INFO - 2023-04-28 07:35:49 --> Utf8 Class Initialized
INFO - 2023-04-28 07:35:49 --> Router Class Initialized
INFO - 2023-04-28 07:35:49 --> URI Class Initialized
INFO - 2023-04-28 07:35:49 --> Output Class Initialized
INFO - 2023-04-28 07:35:49 --> Router Class Initialized
INFO - 2023-04-28 07:35:49 --> Security Class Initialized
INFO - 2023-04-28 07:35:49 --> Output Class Initialized
DEBUG - 2023-04-28 07:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:35:49 --> Input Class Initialized
INFO - 2023-04-28 07:35:49 --> Security Class Initialized
INFO - 2023-04-28 07:35:49 --> Language Class Initialized
DEBUG - 2023-04-28 07:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:35:49 --> Loader Class Initialized
INFO - 2023-04-28 07:35:49 --> Input Class Initialized
INFO - 2023-04-28 07:35:49 --> Controller Class Initialized
DEBUG - 2023-04-28 07:35:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:35:49 --> Language Class Initialized
INFO - 2023-04-28 07:35:49 --> Database Driver Class Initialized
INFO - 2023-04-28 07:35:49 --> Loader Class Initialized
INFO - 2023-04-28 07:35:49 --> Controller Class Initialized
DEBUG - 2023-04-28 07:35:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:35:49 --> Database Driver Class Initialized
INFO - 2023-04-28 07:35:49 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:35:49 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:35:49 --> Final output sent to browser
INFO - 2023-04-28 07:35:49 --> Final output sent to browser
DEBUG - 2023-04-28 07:35:49 --> Total execution time: 0.0654
DEBUG - 2023-04-28 07:35:49 --> Total execution time: 0.0650
INFO - 2023-04-28 07:41:48 --> Config Class Initialized
INFO - 2023-04-28 07:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:41:48 --> Utf8 Class Initialized
INFO - 2023-04-28 07:41:48 --> URI Class Initialized
INFO - 2023-04-28 07:41:48 --> Router Class Initialized
INFO - 2023-04-28 07:41:48 --> Output Class Initialized
INFO - 2023-04-28 07:41:48 --> Security Class Initialized
DEBUG - 2023-04-28 07:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:41:48 --> Input Class Initialized
INFO - 2023-04-28 07:41:48 --> Language Class Initialized
INFO - 2023-04-28 07:41:48 --> Loader Class Initialized
INFO - 2023-04-28 07:41:48 --> Controller Class Initialized
DEBUG - 2023-04-28 07:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:41:48 --> Database Driver Class Initialized
INFO - 2023-04-28 07:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:41:48 --> Final output sent to browser
DEBUG - 2023-04-28 07:41:48 --> Total execution time: 0.0134
INFO - 2023-04-28 07:41:48 --> Config Class Initialized
INFO - 2023-04-28 07:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:41:48 --> Utf8 Class Initialized
INFO - 2023-04-28 07:41:48 --> URI Class Initialized
INFO - 2023-04-28 07:41:48 --> Router Class Initialized
INFO - 2023-04-28 07:41:48 --> Output Class Initialized
INFO - 2023-04-28 07:41:48 --> Security Class Initialized
DEBUG - 2023-04-28 07:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:41:48 --> Input Class Initialized
INFO - 2023-04-28 07:41:48 --> Language Class Initialized
INFO - 2023-04-28 07:41:48 --> Loader Class Initialized
INFO - 2023-04-28 07:41:48 --> Controller Class Initialized
DEBUG - 2023-04-28 07:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:41:48 --> Database Driver Class Initialized
INFO - 2023-04-28 07:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:41:48 --> Final output sent to browser
DEBUG - 2023-04-28 07:41:48 --> Total execution time: 0.0524
INFO - 2023-04-28 07:41:48 --> Config Class Initialized
INFO - 2023-04-28 07:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:41:48 --> Utf8 Class Initialized
INFO - 2023-04-28 07:41:48 --> URI Class Initialized
INFO - 2023-04-28 07:41:48 --> Router Class Initialized
INFO - 2023-04-28 07:41:48 --> Output Class Initialized
INFO - 2023-04-28 07:41:48 --> Security Class Initialized
DEBUG - 2023-04-28 07:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:41:48 --> Input Class Initialized
INFO - 2023-04-28 07:41:48 --> Language Class Initialized
INFO - 2023-04-28 07:41:48 --> Loader Class Initialized
INFO - 2023-04-28 07:41:48 --> Controller Class Initialized
DEBUG - 2023-04-28 07:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:41:48 --> Database Driver Class Initialized
INFO - 2023-04-28 07:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:41:48 --> Final output sent to browser
DEBUG - 2023-04-28 07:41:48 --> Total execution time: 0.0593
INFO - 2023-04-28 07:41:48 --> Config Class Initialized
INFO - 2023-04-28 07:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:41:48 --> Utf8 Class Initialized
INFO - 2023-04-28 07:41:48 --> URI Class Initialized
INFO - 2023-04-28 07:41:48 --> Router Class Initialized
INFO - 2023-04-28 07:41:48 --> Output Class Initialized
INFO - 2023-04-28 07:41:48 --> Security Class Initialized
DEBUG - 2023-04-28 07:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:41:48 --> Input Class Initialized
INFO - 2023-04-28 07:41:48 --> Language Class Initialized
INFO - 2023-04-28 07:41:48 --> Loader Class Initialized
INFO - 2023-04-28 07:41:48 --> Controller Class Initialized
DEBUG - 2023-04-28 07:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:41:48 --> Database Driver Class Initialized
INFO - 2023-04-28 07:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:41:48 --> Final output sent to browser
DEBUG - 2023-04-28 07:41:48 --> Total execution time: 0.0524
INFO - 2023-04-28 07:42:59 --> Config Class Initialized
INFO - 2023-04-28 07:42:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:42:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:42:59 --> Utf8 Class Initialized
INFO - 2023-04-28 07:42:59 --> URI Class Initialized
INFO - 2023-04-28 07:42:59 --> Router Class Initialized
INFO - 2023-04-28 07:42:59 --> Output Class Initialized
INFO - 2023-04-28 07:42:59 --> Security Class Initialized
DEBUG - 2023-04-28 07:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:42:59 --> Input Class Initialized
INFO - 2023-04-28 07:42:59 --> Language Class Initialized
INFO - 2023-04-28 07:42:59 --> Loader Class Initialized
INFO - 2023-04-28 07:42:59 --> Controller Class Initialized
DEBUG - 2023-04-28 07:42:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:42:59 --> Database Driver Class Initialized
INFO - 2023-04-28 07:42:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:42:59 --> Final output sent to browser
DEBUG - 2023-04-28 07:42:59 --> Total execution time: 0.0135
INFO - 2023-04-28 07:42:59 --> Config Class Initialized
INFO - 2023-04-28 07:42:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:42:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:42:59 --> Utf8 Class Initialized
INFO - 2023-04-28 07:42:59 --> URI Class Initialized
INFO - 2023-04-28 07:42:59 --> Router Class Initialized
INFO - 2023-04-28 07:42:59 --> Output Class Initialized
INFO - 2023-04-28 07:42:59 --> Security Class Initialized
DEBUG - 2023-04-28 07:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:42:59 --> Input Class Initialized
INFO - 2023-04-28 07:42:59 --> Language Class Initialized
INFO - 2023-04-28 07:42:59 --> Loader Class Initialized
INFO - 2023-04-28 07:42:59 --> Controller Class Initialized
DEBUG - 2023-04-28 07:42:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:42:59 --> Database Driver Class Initialized
INFO - 2023-04-28 07:42:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:42:59 --> Database Driver Class Initialized
INFO - 2023-04-28 07:42:59 --> Model "Login_model" initialized
INFO - 2023-04-28 07:42:59 --> Final output sent to browser
DEBUG - 2023-04-28 07:42:59 --> Total execution time: 0.0396
INFO - 2023-04-28 07:42:59 --> Config Class Initialized
INFO - 2023-04-28 07:42:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:42:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:42:59 --> Utf8 Class Initialized
INFO - 2023-04-28 07:42:59 --> URI Class Initialized
INFO - 2023-04-28 07:42:59 --> Router Class Initialized
INFO - 2023-04-28 07:42:59 --> Output Class Initialized
INFO - 2023-04-28 07:42:59 --> Security Class Initialized
DEBUG - 2023-04-28 07:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:42:59 --> Input Class Initialized
INFO - 2023-04-28 07:42:59 --> Language Class Initialized
INFO - 2023-04-28 07:42:59 --> Loader Class Initialized
INFO - 2023-04-28 07:42:59 --> Controller Class Initialized
DEBUG - 2023-04-28 07:42:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:42:59 --> Database Driver Class Initialized
INFO - 2023-04-28 07:42:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:42:59 --> Final output sent to browser
DEBUG - 2023-04-28 07:42:59 --> Total execution time: 0.0154
INFO - 2023-04-28 07:42:59 --> Config Class Initialized
INFO - 2023-04-28 07:42:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:42:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:42:59 --> Utf8 Class Initialized
INFO - 2023-04-28 07:42:59 --> URI Class Initialized
INFO - 2023-04-28 07:42:59 --> Router Class Initialized
INFO - 2023-04-28 07:42:59 --> Output Class Initialized
INFO - 2023-04-28 07:42:59 --> Security Class Initialized
DEBUG - 2023-04-28 07:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:42:59 --> Input Class Initialized
INFO - 2023-04-28 07:42:59 --> Language Class Initialized
INFO - 2023-04-28 07:42:59 --> Loader Class Initialized
INFO - 2023-04-28 07:42:59 --> Controller Class Initialized
DEBUG - 2023-04-28 07:42:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:42:59 --> Database Driver Class Initialized
INFO - 2023-04-28 07:42:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:42:59 --> Final output sent to browser
DEBUG - 2023-04-28 07:42:59 --> Total execution time: 0.5411
INFO - 2023-04-28 07:43:04 --> Config Class Initialized
INFO - 2023-04-28 07:43:04 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:43:04 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:43:04 --> Utf8 Class Initialized
INFO - 2023-04-28 07:43:04 --> URI Class Initialized
INFO - 2023-04-28 07:43:04 --> Router Class Initialized
INFO - 2023-04-28 07:43:04 --> Output Class Initialized
INFO - 2023-04-28 07:43:04 --> Security Class Initialized
DEBUG - 2023-04-28 07:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:43:04 --> Input Class Initialized
INFO - 2023-04-28 07:43:04 --> Language Class Initialized
INFO - 2023-04-28 07:43:04 --> Loader Class Initialized
INFO - 2023-04-28 07:43:04 --> Controller Class Initialized
DEBUG - 2023-04-28 07:43:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:43:04 --> Database Driver Class Initialized
INFO - 2023-04-28 07:43:04 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:43:04 --> Final output sent to browser
DEBUG - 2023-04-28 07:43:04 --> Total execution time: 0.0218
INFO - 2023-04-28 07:43:09 --> Config Class Initialized
INFO - 2023-04-28 07:43:09 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:43:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:43:09 --> Utf8 Class Initialized
INFO - 2023-04-28 07:43:09 --> URI Class Initialized
INFO - 2023-04-28 07:43:09 --> Router Class Initialized
INFO - 2023-04-28 07:43:09 --> Output Class Initialized
INFO - 2023-04-28 07:43:09 --> Security Class Initialized
DEBUG - 2023-04-28 07:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:43:09 --> Input Class Initialized
INFO - 2023-04-28 07:43:09 --> Language Class Initialized
INFO - 2023-04-28 07:43:09 --> Loader Class Initialized
INFO - 2023-04-28 07:43:09 --> Controller Class Initialized
DEBUG - 2023-04-28 07:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:43:09 --> Database Driver Class Initialized
INFO - 2023-04-28 07:43:09 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:43:09 --> Final output sent to browser
DEBUG - 2023-04-28 07:43:09 --> Total execution time: 0.0119
INFO - 2023-04-28 07:43:09 --> Config Class Initialized
INFO - 2023-04-28 07:43:09 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:43:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:43:09 --> Utf8 Class Initialized
INFO - 2023-04-28 07:43:09 --> URI Class Initialized
INFO - 2023-04-28 07:43:09 --> Router Class Initialized
INFO - 2023-04-28 07:43:09 --> Output Class Initialized
INFO - 2023-04-28 07:43:09 --> Security Class Initialized
DEBUG - 2023-04-28 07:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:43:09 --> Input Class Initialized
INFO - 2023-04-28 07:43:09 --> Language Class Initialized
INFO - 2023-04-28 07:43:09 --> Loader Class Initialized
INFO - 2023-04-28 07:43:09 --> Controller Class Initialized
DEBUG - 2023-04-28 07:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:43:09 --> Database Driver Class Initialized
INFO - 2023-04-28 07:43:09 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:43:09 --> Final output sent to browser
DEBUG - 2023-04-28 07:43:09 --> Total execution time: 0.0197
INFO - 2023-04-28 07:43:14 --> Config Class Initialized
INFO - 2023-04-28 07:43:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:43:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:43:14 --> Utf8 Class Initialized
INFO - 2023-04-28 07:43:14 --> URI Class Initialized
INFO - 2023-04-28 07:43:14 --> Router Class Initialized
INFO - 2023-04-28 07:43:14 --> Output Class Initialized
INFO - 2023-04-28 07:43:14 --> Security Class Initialized
DEBUG - 2023-04-28 07:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:43:14 --> Input Class Initialized
INFO - 2023-04-28 07:43:14 --> Language Class Initialized
INFO - 2023-04-28 07:43:14 --> Loader Class Initialized
INFO - 2023-04-28 07:43:14 --> Controller Class Initialized
DEBUG - 2023-04-28 07:43:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:43:14 --> Database Driver Class Initialized
INFO - 2023-04-28 07:43:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:43:14 --> Final output sent to browser
DEBUG - 2023-04-28 07:43:14 --> Total execution time: 0.0225
INFO - 2023-04-28 07:43:19 --> Config Class Initialized
INFO - 2023-04-28 07:43:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:43:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:43:19 --> Utf8 Class Initialized
INFO - 2023-04-28 07:43:19 --> URI Class Initialized
INFO - 2023-04-28 07:43:19 --> Router Class Initialized
INFO - 2023-04-28 07:43:19 --> Output Class Initialized
INFO - 2023-04-28 07:43:19 --> Security Class Initialized
DEBUG - 2023-04-28 07:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:43:19 --> Input Class Initialized
INFO - 2023-04-28 07:43:19 --> Language Class Initialized
INFO - 2023-04-28 07:43:19 --> Loader Class Initialized
INFO - 2023-04-28 07:43:19 --> Controller Class Initialized
DEBUG - 2023-04-28 07:43:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:43:19 --> Database Driver Class Initialized
INFO - 2023-04-28 07:43:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:43:19 --> Final output sent to browser
DEBUG - 2023-04-28 07:43:19 --> Total execution time: 0.0100
INFO - 2023-04-28 07:43:19 --> Config Class Initialized
INFO - 2023-04-28 07:43:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:43:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:43:19 --> Utf8 Class Initialized
INFO - 2023-04-28 07:43:19 --> URI Class Initialized
INFO - 2023-04-28 07:43:19 --> Router Class Initialized
INFO - 2023-04-28 07:43:19 --> Output Class Initialized
INFO - 2023-04-28 07:43:19 --> Security Class Initialized
DEBUG - 2023-04-28 07:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:43:19 --> Input Class Initialized
INFO - 2023-04-28 07:43:19 --> Language Class Initialized
INFO - 2023-04-28 07:43:19 --> Loader Class Initialized
INFO - 2023-04-28 07:43:19 --> Controller Class Initialized
DEBUG - 2023-04-28 07:43:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:43:19 --> Database Driver Class Initialized
INFO - 2023-04-28 07:43:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:43:19 --> Final output sent to browser
DEBUG - 2023-04-28 07:43:19 --> Total execution time: 0.0128
INFO - 2023-04-28 07:43:24 --> Config Class Initialized
INFO - 2023-04-28 07:43:24 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:43:24 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:43:24 --> Utf8 Class Initialized
INFO - 2023-04-28 07:43:24 --> URI Class Initialized
INFO - 2023-04-28 07:43:24 --> Router Class Initialized
INFO - 2023-04-28 07:43:24 --> Output Class Initialized
INFO - 2023-04-28 07:43:24 --> Security Class Initialized
DEBUG - 2023-04-28 07:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:43:24 --> Input Class Initialized
INFO - 2023-04-28 07:43:24 --> Language Class Initialized
INFO - 2023-04-28 07:43:24 --> Loader Class Initialized
INFO - 2023-04-28 07:43:24 --> Controller Class Initialized
DEBUG - 2023-04-28 07:43:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:43:24 --> Database Driver Class Initialized
INFO - 2023-04-28 07:43:24 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:43:24 --> Final output sent to browser
DEBUG - 2023-04-28 07:43:24 --> Total execution time: 0.0191
INFO - 2023-04-28 07:43:29 --> Config Class Initialized
INFO - 2023-04-28 07:43:29 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:43:29 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:43:29 --> Utf8 Class Initialized
INFO - 2023-04-28 07:43:29 --> URI Class Initialized
INFO - 2023-04-28 07:43:29 --> Router Class Initialized
INFO - 2023-04-28 07:43:29 --> Output Class Initialized
INFO - 2023-04-28 07:43:29 --> Security Class Initialized
DEBUG - 2023-04-28 07:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:43:29 --> Input Class Initialized
INFO - 2023-04-28 07:43:29 --> Language Class Initialized
INFO - 2023-04-28 07:43:29 --> Loader Class Initialized
INFO - 2023-04-28 07:43:29 --> Controller Class Initialized
DEBUG - 2023-04-28 07:43:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:43:29 --> Database Driver Class Initialized
INFO - 2023-04-28 07:43:29 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:43:29 --> Final output sent to browser
DEBUG - 2023-04-28 07:43:29 --> Total execution time: 0.0227
INFO - 2023-04-28 07:43:29 --> Config Class Initialized
INFO - 2023-04-28 07:43:29 --> Hooks Class Initialized
DEBUG - 2023-04-28 07:43:29 --> UTF-8 Support Enabled
INFO - 2023-04-28 07:43:29 --> Utf8 Class Initialized
INFO - 2023-04-28 07:43:29 --> URI Class Initialized
INFO - 2023-04-28 07:43:29 --> Router Class Initialized
INFO - 2023-04-28 07:43:29 --> Output Class Initialized
INFO - 2023-04-28 07:43:29 --> Security Class Initialized
DEBUG - 2023-04-28 07:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 07:43:29 --> Input Class Initialized
INFO - 2023-04-28 07:43:29 --> Language Class Initialized
INFO - 2023-04-28 07:43:29 --> Loader Class Initialized
INFO - 2023-04-28 07:43:29 --> Controller Class Initialized
DEBUG - 2023-04-28 07:43:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 07:43:29 --> Database Driver Class Initialized
INFO - 2023-04-28 07:43:29 --> Model "Cluster_model" initialized
INFO - 2023-04-28 07:43:29 --> Final output sent to browser
DEBUG - 2023-04-28 07:43:29 --> Total execution time: 0.0131
INFO - 2023-04-28 08:01:54 --> Config Class Initialized
INFO - 2023-04-28 08:01:54 --> Config Class Initialized
INFO - 2023-04-28 08:01:54 --> Hooks Class Initialized
INFO - 2023-04-28 08:01:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:01:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 08:01:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:01:54 --> Utf8 Class Initialized
INFO - 2023-04-28 08:01:54 --> Utf8 Class Initialized
INFO - 2023-04-28 08:01:54 --> URI Class Initialized
INFO - 2023-04-28 08:01:54 --> URI Class Initialized
INFO - 2023-04-28 08:01:54 --> Router Class Initialized
INFO - 2023-04-28 08:01:54 --> Router Class Initialized
INFO - 2023-04-28 08:01:54 --> Output Class Initialized
INFO - 2023-04-28 08:01:54 --> Output Class Initialized
INFO - 2023-04-28 08:01:54 --> Security Class Initialized
INFO - 2023-04-28 08:01:54 --> Security Class Initialized
DEBUG - 2023-04-28 08:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 08:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:01:54 --> Input Class Initialized
INFO - 2023-04-28 08:01:54 --> Input Class Initialized
INFO - 2023-04-28 08:01:54 --> Language Class Initialized
INFO - 2023-04-28 08:01:54 --> Language Class Initialized
INFO - 2023-04-28 08:01:54 --> Loader Class Initialized
INFO - 2023-04-28 08:01:54 --> Loader Class Initialized
INFO - 2023-04-28 08:01:54 --> Controller Class Initialized
INFO - 2023-04-28 08:01:54 --> Controller Class Initialized
DEBUG - 2023-04-28 08:01:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 08:01:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:01:54 --> Database Driver Class Initialized
INFO - 2023-04-28 08:01:54 --> Database Driver Class Initialized
INFO - 2023-04-28 08:01:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:01:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:01:54 --> Final output sent to browser
DEBUG - 2023-04-28 08:01:54 --> Total execution time: 0.1104
INFO - 2023-04-28 08:01:54 --> Config Class Initialized
INFO - 2023-04-28 08:01:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:01:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:01:54 --> Utf8 Class Initialized
INFO - 2023-04-28 08:01:54 --> URI Class Initialized
INFO - 2023-04-28 08:01:54 --> Router Class Initialized
INFO - 2023-04-28 08:01:54 --> Output Class Initialized
INFO - 2023-04-28 08:01:54 --> Security Class Initialized
DEBUG - 2023-04-28 08:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:01:54 --> Input Class Initialized
INFO - 2023-04-28 08:01:54 --> Language Class Initialized
INFO - 2023-04-28 08:01:54 --> Loader Class Initialized
INFO - 2023-04-28 08:01:54 --> Controller Class Initialized
DEBUG - 2023-04-28 08:01:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:01:54 --> Database Driver Class Initialized
INFO - 2023-04-28 08:01:54 --> Database Driver Class Initialized
INFO - 2023-04-28 08:01:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:01:54 --> Model "Login_model" initialized
INFO - 2023-04-28 08:01:54 --> Final output sent to browser
DEBUG - 2023-04-28 08:01:54 --> Total execution time: 0.0121
INFO - 2023-04-28 08:01:54 --> Final output sent to browser
DEBUG - 2023-04-28 08:01:54 --> Total execution time: 0.1634
INFO - 2023-04-28 08:01:54 --> Config Class Initialized
INFO - 2023-04-28 08:01:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:01:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:01:54 --> Utf8 Class Initialized
INFO - 2023-04-28 08:01:54 --> URI Class Initialized
INFO - 2023-04-28 08:01:54 --> Router Class Initialized
INFO - 2023-04-28 08:01:54 --> Output Class Initialized
INFO - 2023-04-28 08:01:54 --> Security Class Initialized
DEBUG - 2023-04-28 08:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:01:54 --> Input Class Initialized
INFO - 2023-04-28 08:01:54 --> Language Class Initialized
INFO - 2023-04-28 08:01:54 --> Loader Class Initialized
INFO - 2023-04-28 08:01:54 --> Controller Class Initialized
DEBUG - 2023-04-28 08:01:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:01:54 --> Database Driver Class Initialized
INFO - 2023-04-28 08:01:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:01:54 --> Database Driver Class Initialized
INFO - 2023-04-28 08:01:54 --> Model "Login_model" initialized
INFO - 2023-04-28 08:01:54 --> Final output sent to browser
DEBUG - 2023-04-28 08:01:54 --> Total execution time: 0.0889
INFO - 2023-04-28 08:06:52 --> Config Class Initialized
INFO - 2023-04-28 08:06:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:06:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:06:52 --> Utf8 Class Initialized
INFO - 2023-04-28 08:06:52 --> URI Class Initialized
INFO - 2023-04-28 08:06:52 --> Router Class Initialized
INFO - 2023-04-28 08:06:52 --> Output Class Initialized
INFO - 2023-04-28 08:06:52 --> Security Class Initialized
DEBUG - 2023-04-28 08:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:06:52 --> Input Class Initialized
INFO - 2023-04-28 08:06:52 --> Language Class Initialized
INFO - 2023-04-28 08:06:52 --> Loader Class Initialized
INFO - 2023-04-28 08:06:52 --> Controller Class Initialized
DEBUG - 2023-04-28 08:06:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:06:52 --> Database Driver Class Initialized
INFO - 2023-04-28 08:06:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:06:52 --> Final output sent to browser
DEBUG - 2023-04-28 08:06:52 --> Total execution time: 0.0183
INFO - 2023-04-28 08:06:52 --> Config Class Initialized
INFO - 2023-04-28 08:06:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:06:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:06:52 --> Utf8 Class Initialized
INFO - 2023-04-28 08:06:52 --> URI Class Initialized
INFO - 2023-04-28 08:06:52 --> Router Class Initialized
INFO - 2023-04-28 08:06:52 --> Output Class Initialized
INFO - 2023-04-28 08:06:52 --> Security Class Initialized
DEBUG - 2023-04-28 08:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:06:52 --> Input Class Initialized
INFO - 2023-04-28 08:06:52 --> Language Class Initialized
INFO - 2023-04-28 08:06:52 --> Loader Class Initialized
INFO - 2023-04-28 08:06:52 --> Controller Class Initialized
DEBUG - 2023-04-28 08:06:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:06:52 --> Database Driver Class Initialized
INFO - 2023-04-28 08:06:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:06:52 --> Final output sent to browser
DEBUG - 2023-04-28 08:06:52 --> Total execution time: 0.0587
INFO - 2023-04-28 08:06:52 --> Config Class Initialized
INFO - 2023-04-28 08:06:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:06:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:06:52 --> Utf8 Class Initialized
INFO - 2023-04-28 08:06:52 --> URI Class Initialized
INFO - 2023-04-28 08:06:52 --> Router Class Initialized
INFO - 2023-04-28 08:06:52 --> Output Class Initialized
INFO - 2023-04-28 08:06:52 --> Security Class Initialized
DEBUG - 2023-04-28 08:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:06:52 --> Input Class Initialized
INFO - 2023-04-28 08:06:52 --> Language Class Initialized
INFO - 2023-04-28 08:06:52 --> Loader Class Initialized
INFO - 2023-04-28 08:06:52 --> Controller Class Initialized
DEBUG - 2023-04-28 08:06:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:06:52 --> Database Driver Class Initialized
INFO - 2023-04-28 08:06:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:06:52 --> Final output sent to browser
DEBUG - 2023-04-28 08:06:52 --> Total execution time: 0.0538
INFO - 2023-04-28 08:06:52 --> Config Class Initialized
INFO - 2023-04-28 08:06:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:06:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:06:52 --> Utf8 Class Initialized
INFO - 2023-04-28 08:06:52 --> URI Class Initialized
INFO - 2023-04-28 08:06:52 --> Router Class Initialized
INFO - 2023-04-28 08:06:52 --> Output Class Initialized
INFO - 2023-04-28 08:06:52 --> Security Class Initialized
DEBUG - 2023-04-28 08:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:06:52 --> Input Class Initialized
INFO - 2023-04-28 08:06:52 --> Language Class Initialized
INFO - 2023-04-28 08:06:52 --> Loader Class Initialized
INFO - 2023-04-28 08:06:52 --> Controller Class Initialized
DEBUG - 2023-04-28 08:06:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:06:52 --> Database Driver Class Initialized
INFO - 2023-04-28 08:06:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:06:52 --> Final output sent to browser
DEBUG - 2023-04-28 08:06:52 --> Total execution time: 0.0545
INFO - 2023-04-28 08:13:28 --> Config Class Initialized
INFO - 2023-04-28 08:13:28 --> Config Class Initialized
INFO - 2023-04-28 08:13:28 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:13:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:13:28 --> Utf8 Class Initialized
INFO - 2023-04-28 08:13:28 --> URI Class Initialized
INFO - 2023-04-28 08:13:28 --> Router Class Initialized
INFO - 2023-04-28 08:13:28 --> Output Class Initialized
INFO - 2023-04-28 08:13:28 --> Security Class Initialized
DEBUG - 2023-04-28 08:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:13:28 --> Hooks Class Initialized
INFO - 2023-04-28 08:13:28 --> Input Class Initialized
DEBUG - 2023-04-28 08:13:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:13:28 --> Language Class Initialized
INFO - 2023-04-28 08:13:28 --> Utf8 Class Initialized
INFO - 2023-04-28 08:13:28 --> Loader Class Initialized
INFO - 2023-04-28 08:13:28 --> URI Class Initialized
INFO - 2023-04-28 08:13:28 --> Controller Class Initialized
INFO - 2023-04-28 08:13:28 --> Router Class Initialized
DEBUG - 2023-04-28 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:13:28 --> Output Class Initialized
INFO - 2023-04-28 08:13:28 --> Security Class Initialized
INFO - 2023-04-28 08:13:28 --> Database Driver Class Initialized
DEBUG - 2023-04-28 08:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:13:28 --> Input Class Initialized
INFO - 2023-04-28 08:13:28 --> Language Class Initialized
INFO - 2023-04-28 08:13:28 --> Loader Class Initialized
INFO - 2023-04-28 08:13:28 --> Controller Class Initialized
DEBUG - 2023-04-28 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:13:28 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:13:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:13:28 --> Final output sent to browser
DEBUG - 2023-04-28 08:13:28 --> Total execution time: 0.0944
INFO - 2023-04-28 08:13:28 --> Config Class Initialized
INFO - 2023-04-28 08:13:28 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:28 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:13:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:13:28 --> Utf8 Class Initialized
INFO - 2023-04-28 08:13:28 --> URI Class Initialized
INFO - 2023-04-28 08:13:28 --> Router Class Initialized
INFO - 2023-04-28 08:13:28 --> Output Class Initialized
INFO - 2023-04-28 08:13:28 --> Security Class Initialized
DEBUG - 2023-04-28 08:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:13:28 --> Input Class Initialized
INFO - 2023-04-28 08:13:28 --> Language Class Initialized
INFO - 2023-04-28 08:13:28 --> Loader Class Initialized
INFO - 2023-04-28 08:13:28 --> Controller Class Initialized
DEBUG - 2023-04-28 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:13:28 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:28 --> Model "Login_model" initialized
INFO - 2023-04-28 08:13:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:13:28 --> Final output sent to browser
DEBUG - 2023-04-28 08:13:28 --> Total execution time: 0.0782
INFO - 2023-04-28 08:13:28 --> Final output sent to browser
DEBUG - 2023-04-28 08:13:28 --> Total execution time: 0.2039
INFO - 2023-04-28 08:13:28 --> Config Class Initialized
INFO - 2023-04-28 08:13:28 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:13:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:13:28 --> Utf8 Class Initialized
INFO - 2023-04-28 08:13:28 --> URI Class Initialized
INFO - 2023-04-28 08:13:28 --> Router Class Initialized
INFO - 2023-04-28 08:13:28 --> Output Class Initialized
INFO - 2023-04-28 08:13:28 --> Security Class Initialized
DEBUG - 2023-04-28 08:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:13:28 --> Input Class Initialized
INFO - 2023-04-28 08:13:28 --> Language Class Initialized
INFO - 2023-04-28 08:13:28 --> Loader Class Initialized
INFO - 2023-04-28 08:13:28 --> Controller Class Initialized
DEBUG - 2023-04-28 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:13:28 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:13:28 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:28 --> Model "Login_model" initialized
INFO - 2023-04-28 08:13:28 --> Final output sent to browser
DEBUG - 2023-04-28 08:13:28 --> Total execution time: 0.1284
INFO - 2023-04-28 08:13:34 --> Config Class Initialized
INFO - 2023-04-28 08:13:34 --> Config Class Initialized
INFO - 2023-04-28 08:13:34 --> Hooks Class Initialized
INFO - 2023-04-28 08:13:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:13:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 08:13:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:13:34 --> Utf8 Class Initialized
INFO - 2023-04-28 08:13:34 --> Utf8 Class Initialized
INFO - 2023-04-28 08:13:34 --> URI Class Initialized
INFO - 2023-04-28 08:13:34 --> URI Class Initialized
INFO - 2023-04-28 08:13:34 --> Router Class Initialized
INFO - 2023-04-28 08:13:34 --> Router Class Initialized
INFO - 2023-04-28 08:13:34 --> Output Class Initialized
INFO - 2023-04-28 08:13:34 --> Output Class Initialized
INFO - 2023-04-28 08:13:34 --> Security Class Initialized
INFO - 2023-04-28 08:13:34 --> Security Class Initialized
DEBUG - 2023-04-28 08:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 08:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:13:34 --> Input Class Initialized
INFO - 2023-04-28 08:13:34 --> Input Class Initialized
INFO - 2023-04-28 08:13:34 --> Language Class Initialized
INFO - 2023-04-28 08:13:34 --> Language Class Initialized
INFO - 2023-04-28 08:13:34 --> Loader Class Initialized
INFO - 2023-04-28 08:13:34 --> Loader Class Initialized
INFO - 2023-04-28 08:13:34 --> Controller Class Initialized
INFO - 2023-04-28 08:13:34 --> Controller Class Initialized
DEBUG - 2023-04-28 08:13:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 08:13:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:13:34 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:34 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:13:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:13:34 --> Final output sent to browser
INFO - 2023-04-28 08:13:34 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:34 --> Model "Login_model" initialized
DEBUG - 2023-04-28 08:13:34 --> Total execution time: 0.0697
INFO - 2023-04-28 08:13:34 --> Config Class Initialized
INFO - 2023-04-28 08:13:34 --> Final output sent to browser
DEBUG - 2023-04-28 08:13:34 --> Total execution time: 0.1819
INFO - 2023-04-28 08:13:34 --> Config Class Initialized
INFO - 2023-04-28 08:13:34 --> Hooks Class Initialized
INFO - 2023-04-28 08:13:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:13:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 08:13:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:13:34 --> Utf8 Class Initialized
INFO - 2023-04-28 08:13:34 --> Utf8 Class Initialized
INFO - 2023-04-28 08:13:34 --> URI Class Initialized
INFO - 2023-04-28 08:13:34 --> URI Class Initialized
INFO - 2023-04-28 08:13:34 --> Router Class Initialized
INFO - 2023-04-28 08:13:34 --> Router Class Initialized
INFO - 2023-04-28 08:13:34 --> Output Class Initialized
INFO - 2023-04-28 08:13:34 --> Output Class Initialized
INFO - 2023-04-28 08:13:34 --> Security Class Initialized
INFO - 2023-04-28 08:13:34 --> Security Class Initialized
DEBUG - 2023-04-28 08:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 08:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:13:34 --> Input Class Initialized
INFO - 2023-04-28 08:13:34 --> Input Class Initialized
INFO - 2023-04-28 08:13:34 --> Language Class Initialized
INFO - 2023-04-28 08:13:34 --> Language Class Initialized
INFO - 2023-04-28 08:13:34 --> Loader Class Initialized
INFO - 2023-04-28 08:13:34 --> Loader Class Initialized
INFO - 2023-04-28 08:13:34 --> Controller Class Initialized
INFO - 2023-04-28 08:13:34 --> Controller Class Initialized
DEBUG - 2023-04-28 08:13:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 08:13:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:13:34 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:34 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:13:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:13:34 --> Final output sent to browser
DEBUG - 2023-04-28 08:13:34 --> Total execution time: 0.0980
INFO - 2023-04-28 08:13:34 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:34 --> Model "Login_model" initialized
INFO - 2023-04-28 08:13:34 --> Final output sent to browser
DEBUG - 2023-04-28 08:13:34 --> Total execution time: 0.1741
INFO - 2023-04-28 08:13:36 --> Config Class Initialized
INFO - 2023-04-28 08:13:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:13:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:13:36 --> Utf8 Class Initialized
INFO - 2023-04-28 08:13:36 --> URI Class Initialized
INFO - 2023-04-28 08:13:36 --> Router Class Initialized
INFO - 2023-04-28 08:13:36 --> Output Class Initialized
INFO - 2023-04-28 08:13:36 --> Security Class Initialized
DEBUG - 2023-04-28 08:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:13:36 --> Input Class Initialized
INFO - 2023-04-28 08:13:36 --> Language Class Initialized
INFO - 2023-04-28 08:13:36 --> Loader Class Initialized
INFO - 2023-04-28 08:13:36 --> Controller Class Initialized
DEBUG - 2023-04-28 08:13:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:13:36 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:13:36 --> Final output sent to browser
DEBUG - 2023-04-28 08:13:36 --> Total execution time: 0.0099
INFO - 2023-04-28 08:13:36 --> Config Class Initialized
INFO - 2023-04-28 08:13:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:13:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:13:36 --> Utf8 Class Initialized
INFO - 2023-04-28 08:13:36 --> URI Class Initialized
INFO - 2023-04-28 08:13:36 --> Router Class Initialized
INFO - 2023-04-28 08:13:36 --> Output Class Initialized
INFO - 2023-04-28 08:13:36 --> Security Class Initialized
DEBUG - 2023-04-28 08:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:13:36 --> Input Class Initialized
INFO - 2023-04-28 08:13:36 --> Language Class Initialized
INFO - 2023-04-28 08:13:36 --> Loader Class Initialized
INFO - 2023-04-28 08:13:36 --> Controller Class Initialized
DEBUG - 2023-04-28 08:13:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:13:36 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:13:36 --> Final output sent to browser
DEBUG - 2023-04-28 08:13:36 --> Total execution time: 0.0498
INFO - 2023-04-28 08:13:36 --> Config Class Initialized
INFO - 2023-04-28 08:13:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:13:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:13:36 --> Utf8 Class Initialized
INFO - 2023-04-28 08:13:36 --> URI Class Initialized
INFO - 2023-04-28 08:13:36 --> Router Class Initialized
INFO - 2023-04-28 08:13:36 --> Output Class Initialized
INFO - 2023-04-28 08:13:36 --> Security Class Initialized
DEBUG - 2023-04-28 08:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:13:36 --> Input Class Initialized
INFO - 2023-04-28 08:13:36 --> Language Class Initialized
INFO - 2023-04-28 08:13:36 --> Loader Class Initialized
INFO - 2023-04-28 08:13:36 --> Controller Class Initialized
DEBUG - 2023-04-28 08:13:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:13:36 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:13:36 --> Final output sent to browser
DEBUG - 2023-04-28 08:13:36 --> Total execution time: 0.0228
INFO - 2023-04-28 08:13:36 --> Config Class Initialized
INFO - 2023-04-28 08:13:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:13:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:13:36 --> Utf8 Class Initialized
INFO - 2023-04-28 08:13:36 --> URI Class Initialized
INFO - 2023-04-28 08:13:36 --> Router Class Initialized
INFO - 2023-04-28 08:13:36 --> Output Class Initialized
INFO - 2023-04-28 08:13:36 --> Security Class Initialized
DEBUG - 2023-04-28 08:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:13:36 --> Input Class Initialized
INFO - 2023-04-28 08:13:36 --> Language Class Initialized
INFO - 2023-04-28 08:13:36 --> Loader Class Initialized
INFO - 2023-04-28 08:13:36 --> Controller Class Initialized
DEBUG - 2023-04-28 08:13:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:13:36 --> Database Driver Class Initialized
INFO - 2023-04-28 08:13:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:13:36 --> Final output sent to browser
DEBUG - 2023-04-28 08:13:36 --> Total execution time: 0.0378
INFO - 2023-04-28 08:14:18 --> Config Class Initialized
INFO - 2023-04-28 08:14:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:14:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:14:18 --> Utf8 Class Initialized
INFO - 2023-04-28 08:14:18 --> URI Class Initialized
INFO - 2023-04-28 08:14:18 --> Router Class Initialized
INFO - 2023-04-28 08:14:18 --> Output Class Initialized
INFO - 2023-04-28 08:14:18 --> Security Class Initialized
DEBUG - 2023-04-28 08:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:14:18 --> Input Class Initialized
INFO - 2023-04-28 08:14:18 --> Language Class Initialized
INFO - 2023-04-28 08:14:18 --> Loader Class Initialized
INFO - 2023-04-28 08:14:18 --> Controller Class Initialized
DEBUG - 2023-04-28 08:14:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:14:18 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:14:18 --> Final output sent to browser
DEBUG - 2023-04-28 08:14:18 --> Total execution time: 0.0319
INFO - 2023-04-28 08:14:18 --> Config Class Initialized
INFO - 2023-04-28 08:14:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:14:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:14:18 --> Utf8 Class Initialized
INFO - 2023-04-28 08:14:18 --> URI Class Initialized
INFO - 2023-04-28 08:14:18 --> Router Class Initialized
INFO - 2023-04-28 08:14:18 --> Output Class Initialized
INFO - 2023-04-28 08:14:18 --> Security Class Initialized
DEBUG - 2023-04-28 08:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:14:18 --> Input Class Initialized
INFO - 2023-04-28 08:14:18 --> Language Class Initialized
INFO - 2023-04-28 08:14:18 --> Loader Class Initialized
INFO - 2023-04-28 08:14:18 --> Controller Class Initialized
DEBUG - 2023-04-28 08:14:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:14:18 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:14:18 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:18 --> Model "Login_model" initialized
INFO - 2023-04-28 08:14:18 --> Final output sent to browser
DEBUG - 2023-04-28 08:14:18 --> Total execution time: 0.0465
INFO - 2023-04-28 08:14:18 --> Config Class Initialized
INFO - 2023-04-28 08:14:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:14:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:14:18 --> Utf8 Class Initialized
INFO - 2023-04-28 08:14:18 --> URI Class Initialized
INFO - 2023-04-28 08:14:18 --> Router Class Initialized
INFO - 2023-04-28 08:14:18 --> Output Class Initialized
INFO - 2023-04-28 08:14:18 --> Security Class Initialized
DEBUG - 2023-04-28 08:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:14:18 --> Input Class Initialized
INFO - 2023-04-28 08:14:18 --> Language Class Initialized
INFO - 2023-04-28 08:14:18 --> Loader Class Initialized
INFO - 2023-04-28 08:14:18 --> Controller Class Initialized
DEBUG - 2023-04-28 08:14:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:14:18 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:14:18 --> Final output sent to browser
DEBUG - 2023-04-28 08:14:18 --> Total execution time: 0.0110
INFO - 2023-04-28 08:14:18 --> Config Class Initialized
INFO - 2023-04-28 08:14:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:14:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:14:18 --> Utf8 Class Initialized
INFO - 2023-04-28 08:14:18 --> URI Class Initialized
INFO - 2023-04-28 08:14:18 --> Router Class Initialized
INFO - 2023-04-28 08:14:18 --> Output Class Initialized
INFO - 2023-04-28 08:14:18 --> Security Class Initialized
DEBUG - 2023-04-28 08:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:14:18 --> Input Class Initialized
INFO - 2023-04-28 08:14:18 --> Language Class Initialized
INFO - 2023-04-28 08:14:18 --> Loader Class Initialized
INFO - 2023-04-28 08:14:18 --> Controller Class Initialized
DEBUG - 2023-04-28 08:14:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:14:18 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:14:18 --> Final output sent to browser
DEBUG - 2023-04-28 08:14:18 --> Total execution time: 0.3461
INFO - 2023-04-28 08:14:23 --> Config Class Initialized
INFO - 2023-04-28 08:14:23 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:14:23 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:14:23 --> Utf8 Class Initialized
INFO - 2023-04-28 08:14:23 --> URI Class Initialized
INFO - 2023-04-28 08:14:23 --> Router Class Initialized
INFO - 2023-04-28 08:14:23 --> Output Class Initialized
INFO - 2023-04-28 08:14:23 --> Security Class Initialized
DEBUG - 2023-04-28 08:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:14:23 --> Input Class Initialized
INFO - 2023-04-28 08:14:23 --> Language Class Initialized
INFO - 2023-04-28 08:14:23 --> Loader Class Initialized
INFO - 2023-04-28 08:14:23 --> Controller Class Initialized
DEBUG - 2023-04-28 08:14:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:14:23 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:23 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:14:23 --> Final output sent to browser
DEBUG - 2023-04-28 08:14:23 --> Total execution time: 0.0187
INFO - 2023-04-28 08:14:28 --> Config Class Initialized
INFO - 2023-04-28 08:14:28 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:14:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:14:28 --> Utf8 Class Initialized
INFO - 2023-04-28 08:14:28 --> URI Class Initialized
INFO - 2023-04-28 08:14:28 --> Router Class Initialized
INFO - 2023-04-28 08:14:28 --> Output Class Initialized
INFO - 2023-04-28 08:14:28 --> Security Class Initialized
DEBUG - 2023-04-28 08:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:14:28 --> Input Class Initialized
INFO - 2023-04-28 08:14:28 --> Language Class Initialized
INFO - 2023-04-28 08:14:28 --> Loader Class Initialized
INFO - 2023-04-28 08:14:28 --> Controller Class Initialized
DEBUG - 2023-04-28 08:14:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:14:28 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:14:28 --> Final output sent to browser
DEBUG - 2023-04-28 08:14:28 --> Total execution time: 0.0164
INFO - 2023-04-28 08:14:28 --> Config Class Initialized
INFO - 2023-04-28 08:14:28 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:14:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:14:28 --> Utf8 Class Initialized
INFO - 2023-04-28 08:14:28 --> URI Class Initialized
INFO - 2023-04-28 08:14:28 --> Router Class Initialized
INFO - 2023-04-28 08:14:28 --> Output Class Initialized
INFO - 2023-04-28 08:14:28 --> Security Class Initialized
DEBUG - 2023-04-28 08:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:14:28 --> Input Class Initialized
INFO - 2023-04-28 08:14:28 --> Language Class Initialized
INFO - 2023-04-28 08:14:28 --> Loader Class Initialized
INFO - 2023-04-28 08:14:28 --> Controller Class Initialized
DEBUG - 2023-04-28 08:14:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:14:28 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:14:28 --> Final output sent to browser
DEBUG - 2023-04-28 08:14:28 --> Total execution time: 0.0198
INFO - 2023-04-28 08:14:33 --> Config Class Initialized
INFO - 2023-04-28 08:14:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:14:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:14:33 --> Utf8 Class Initialized
INFO - 2023-04-28 08:14:33 --> URI Class Initialized
INFO - 2023-04-28 08:14:33 --> Router Class Initialized
INFO - 2023-04-28 08:14:33 --> Output Class Initialized
INFO - 2023-04-28 08:14:33 --> Security Class Initialized
DEBUG - 2023-04-28 08:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:14:33 --> Input Class Initialized
INFO - 2023-04-28 08:14:33 --> Language Class Initialized
INFO - 2023-04-28 08:14:33 --> Loader Class Initialized
INFO - 2023-04-28 08:14:33 --> Controller Class Initialized
DEBUG - 2023-04-28 08:14:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:14:33 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:14:33 --> Final output sent to browser
DEBUG - 2023-04-28 08:14:33 --> Total execution time: 0.0154
INFO - 2023-04-28 08:14:38 --> Config Class Initialized
INFO - 2023-04-28 08:14:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:14:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:14:38 --> Utf8 Class Initialized
INFO - 2023-04-28 08:14:38 --> URI Class Initialized
INFO - 2023-04-28 08:14:38 --> Router Class Initialized
INFO - 2023-04-28 08:14:38 --> Output Class Initialized
INFO - 2023-04-28 08:14:38 --> Security Class Initialized
DEBUG - 2023-04-28 08:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:14:38 --> Input Class Initialized
INFO - 2023-04-28 08:14:38 --> Language Class Initialized
INFO - 2023-04-28 08:14:38 --> Loader Class Initialized
INFO - 2023-04-28 08:14:38 --> Controller Class Initialized
DEBUG - 2023-04-28 08:14:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:14:38 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:14:38 --> Final output sent to browser
DEBUG - 2023-04-28 08:14:38 --> Total execution time: 0.0123
INFO - 2023-04-28 08:14:38 --> Config Class Initialized
INFO - 2023-04-28 08:14:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:14:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:14:38 --> Utf8 Class Initialized
INFO - 2023-04-28 08:14:38 --> URI Class Initialized
INFO - 2023-04-28 08:14:38 --> Router Class Initialized
INFO - 2023-04-28 08:14:38 --> Output Class Initialized
INFO - 2023-04-28 08:14:38 --> Security Class Initialized
DEBUG - 2023-04-28 08:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:14:38 --> Input Class Initialized
INFO - 2023-04-28 08:14:38 --> Language Class Initialized
INFO - 2023-04-28 08:14:38 --> Loader Class Initialized
INFO - 2023-04-28 08:14:38 --> Controller Class Initialized
DEBUG - 2023-04-28 08:14:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:14:38 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:14:38 --> Final output sent to browser
DEBUG - 2023-04-28 08:14:38 --> Total execution time: 0.0150
INFO - 2023-04-28 08:14:43 --> Config Class Initialized
INFO - 2023-04-28 08:14:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:14:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:14:43 --> Utf8 Class Initialized
INFO - 2023-04-28 08:14:43 --> URI Class Initialized
INFO - 2023-04-28 08:14:43 --> Router Class Initialized
INFO - 2023-04-28 08:14:43 --> Output Class Initialized
INFO - 2023-04-28 08:14:43 --> Security Class Initialized
DEBUG - 2023-04-28 08:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:14:43 --> Input Class Initialized
INFO - 2023-04-28 08:14:43 --> Language Class Initialized
INFO - 2023-04-28 08:14:43 --> Loader Class Initialized
INFO - 2023-04-28 08:14:43 --> Controller Class Initialized
DEBUG - 2023-04-28 08:14:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:14:43 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:14:43 --> Final output sent to browser
DEBUG - 2023-04-28 08:14:43 --> Total execution time: 0.0165
INFO - 2023-04-28 08:14:48 --> Config Class Initialized
INFO - 2023-04-28 08:14:48 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:14:48 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:14:48 --> Utf8 Class Initialized
INFO - 2023-04-28 08:14:48 --> URI Class Initialized
INFO - 2023-04-28 08:14:48 --> Router Class Initialized
INFO - 2023-04-28 08:14:48 --> Output Class Initialized
INFO - 2023-04-28 08:14:48 --> Security Class Initialized
DEBUG - 2023-04-28 08:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:14:48 --> Input Class Initialized
INFO - 2023-04-28 08:14:48 --> Language Class Initialized
INFO - 2023-04-28 08:14:48 --> Loader Class Initialized
INFO - 2023-04-28 08:14:48 --> Controller Class Initialized
DEBUG - 2023-04-28 08:14:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:14:48 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:48 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:14:48 --> Final output sent to browser
DEBUG - 2023-04-28 08:14:48 --> Total execution time: 0.0129
INFO - 2023-04-28 08:14:48 --> Config Class Initialized
INFO - 2023-04-28 08:14:48 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:14:48 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:14:48 --> Utf8 Class Initialized
INFO - 2023-04-28 08:14:48 --> URI Class Initialized
INFO - 2023-04-28 08:14:48 --> Router Class Initialized
INFO - 2023-04-28 08:14:48 --> Output Class Initialized
INFO - 2023-04-28 08:14:48 --> Security Class Initialized
DEBUG - 2023-04-28 08:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:14:48 --> Input Class Initialized
INFO - 2023-04-28 08:14:48 --> Language Class Initialized
INFO - 2023-04-28 08:14:48 --> Loader Class Initialized
INFO - 2023-04-28 08:14:48 --> Controller Class Initialized
DEBUG - 2023-04-28 08:14:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:14:48 --> Database Driver Class Initialized
INFO - 2023-04-28 08:14:48 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:14:48 --> Final output sent to browser
DEBUG - 2023-04-28 08:14:48 --> Total execution time: 0.0125
INFO - 2023-04-28 08:18:34 --> Config Class Initialized
INFO - 2023-04-28 08:18:34 --> Config Class Initialized
INFO - 2023-04-28 08:18:34 --> Hooks Class Initialized
INFO - 2023-04-28 08:18:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:18:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 08:18:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:18:34 --> Utf8 Class Initialized
INFO - 2023-04-28 08:18:34 --> Utf8 Class Initialized
INFO - 2023-04-28 08:18:34 --> URI Class Initialized
INFO - 2023-04-28 08:18:34 --> URI Class Initialized
INFO - 2023-04-28 08:18:34 --> Router Class Initialized
INFO - 2023-04-28 08:18:34 --> Router Class Initialized
INFO - 2023-04-28 08:18:34 --> Output Class Initialized
INFO - 2023-04-28 08:18:34 --> Output Class Initialized
INFO - 2023-04-28 08:18:34 --> Security Class Initialized
INFO - 2023-04-28 08:18:34 --> Security Class Initialized
DEBUG - 2023-04-28 08:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 08:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:18:34 --> Input Class Initialized
INFO - 2023-04-28 08:18:34 --> Input Class Initialized
INFO - 2023-04-28 08:18:34 --> Language Class Initialized
INFO - 2023-04-28 08:18:34 --> Language Class Initialized
INFO - 2023-04-28 08:18:34 --> Loader Class Initialized
INFO - 2023-04-28 08:18:34 --> Loader Class Initialized
INFO - 2023-04-28 08:18:34 --> Controller Class Initialized
DEBUG - 2023-04-28 08:18:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:18:34 --> Controller Class Initialized
INFO - 2023-04-28 08:18:34 --> Database Driver Class Initialized
DEBUG - 2023-04-28 08:18:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:18:34 --> Database Driver Class Initialized
INFO - 2023-04-28 08:18:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:18:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:18:34 --> Final output sent to browser
DEBUG - 2023-04-28 08:18:34 --> Total execution time: 0.0651
INFO - 2023-04-28 08:18:34 --> Config Class Initialized
INFO - 2023-04-28 08:18:34 --> Database Driver Class Initialized
INFO - 2023-04-28 08:18:34 --> Hooks Class Initialized
INFO - 2023-04-28 08:18:34 --> Model "Login_model" initialized
DEBUG - 2023-04-28 08:18:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:18:34 --> Final output sent to browser
INFO - 2023-04-28 08:18:34 --> Utf8 Class Initialized
DEBUG - 2023-04-28 08:18:34 --> Total execution time: 0.2959
INFO - 2023-04-28 08:18:34 --> URI Class Initialized
INFO - 2023-04-28 08:18:34 --> Config Class Initialized
INFO - 2023-04-28 08:18:35 --> Hooks Class Initialized
INFO - 2023-04-28 08:18:35 --> Router Class Initialized
DEBUG - 2023-04-28 08:18:35 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:18:35 --> Output Class Initialized
INFO - 2023-04-28 08:18:35 --> Utf8 Class Initialized
INFO - 2023-04-28 08:18:35 --> Security Class Initialized
INFO - 2023-04-28 08:18:35 --> URI Class Initialized
DEBUG - 2023-04-28 08:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:18:35 --> Router Class Initialized
INFO - 2023-04-28 08:18:35 --> Input Class Initialized
INFO - 2023-04-28 08:18:35 --> Output Class Initialized
INFO - 2023-04-28 08:18:35 --> Language Class Initialized
INFO - 2023-04-28 08:18:35 --> Security Class Initialized
INFO - 2023-04-28 08:18:35 --> Loader Class Initialized
DEBUG - 2023-04-28 08:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:18:35 --> Controller Class Initialized
INFO - 2023-04-28 08:18:35 --> Input Class Initialized
DEBUG - 2023-04-28 08:18:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:18:35 --> Language Class Initialized
INFO - 2023-04-28 08:18:35 --> Database Driver Class Initialized
INFO - 2023-04-28 08:18:35 --> Loader Class Initialized
INFO - 2023-04-28 08:18:35 --> Controller Class Initialized
DEBUG - 2023-04-28 08:18:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:18:35 --> Database Driver Class Initialized
INFO - 2023-04-28 08:18:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:18:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:18:35 --> Final output sent to browser
DEBUG - 2023-04-28 08:18:35 --> Total execution time: 0.3009
INFO - 2023-04-28 08:18:35 --> Database Driver Class Initialized
INFO - 2023-04-28 08:18:35 --> Model "Login_model" initialized
INFO - 2023-04-28 08:18:35 --> Final output sent to browser
DEBUG - 2023-04-28 08:18:35 --> Total execution time: 0.1693
INFO - 2023-04-28 08:20:54 --> Config Class Initialized
INFO - 2023-04-28 08:20:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:20:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:20:54 --> Utf8 Class Initialized
INFO - 2023-04-28 08:20:54 --> URI Class Initialized
INFO - 2023-04-28 08:20:54 --> Router Class Initialized
INFO - 2023-04-28 08:20:54 --> Output Class Initialized
INFO - 2023-04-28 08:20:54 --> Security Class Initialized
DEBUG - 2023-04-28 08:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:20:54 --> Input Class Initialized
INFO - 2023-04-28 08:20:54 --> Language Class Initialized
INFO - 2023-04-28 08:20:54 --> Loader Class Initialized
INFO - 2023-04-28 08:20:54 --> Controller Class Initialized
DEBUG - 2023-04-28 08:20:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:20:54 --> Database Driver Class Initialized
INFO - 2023-04-28 08:20:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:20:54 --> Final output sent to browser
DEBUG - 2023-04-28 08:20:54 --> Total execution time: 0.0146
INFO - 2023-04-28 08:20:54 --> Config Class Initialized
INFO - 2023-04-28 08:20:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:20:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:20:54 --> Utf8 Class Initialized
INFO - 2023-04-28 08:20:54 --> URI Class Initialized
INFO - 2023-04-28 08:20:54 --> Router Class Initialized
INFO - 2023-04-28 08:20:54 --> Output Class Initialized
INFO - 2023-04-28 08:20:54 --> Security Class Initialized
DEBUG - 2023-04-28 08:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:20:54 --> Input Class Initialized
INFO - 2023-04-28 08:20:54 --> Language Class Initialized
INFO - 2023-04-28 08:20:54 --> Loader Class Initialized
INFO - 2023-04-28 08:20:54 --> Controller Class Initialized
DEBUG - 2023-04-28 08:20:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:20:54 --> Database Driver Class Initialized
INFO - 2023-04-28 08:20:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:20:54 --> Final output sent to browser
DEBUG - 2023-04-28 08:20:54 --> Total execution time: 0.0517
INFO - 2023-04-28 08:20:54 --> Config Class Initialized
INFO - 2023-04-28 08:20:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:20:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:20:54 --> Utf8 Class Initialized
INFO - 2023-04-28 08:20:54 --> URI Class Initialized
INFO - 2023-04-28 08:20:54 --> Router Class Initialized
INFO - 2023-04-28 08:20:54 --> Output Class Initialized
INFO - 2023-04-28 08:20:54 --> Security Class Initialized
DEBUG - 2023-04-28 08:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:20:54 --> Input Class Initialized
INFO - 2023-04-28 08:20:54 --> Language Class Initialized
INFO - 2023-04-28 08:20:54 --> Loader Class Initialized
INFO - 2023-04-28 08:20:54 --> Controller Class Initialized
DEBUG - 2023-04-28 08:20:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:20:54 --> Database Driver Class Initialized
INFO - 2023-04-28 08:20:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:20:54 --> Final output sent to browser
DEBUG - 2023-04-28 08:20:54 --> Total execution time: 0.0532
INFO - 2023-04-28 08:20:54 --> Config Class Initialized
INFO - 2023-04-28 08:20:55 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:20:55 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:20:55 --> Utf8 Class Initialized
INFO - 2023-04-28 08:20:55 --> URI Class Initialized
INFO - 2023-04-28 08:20:55 --> Router Class Initialized
INFO - 2023-04-28 08:20:55 --> Output Class Initialized
INFO - 2023-04-28 08:20:55 --> Security Class Initialized
DEBUG - 2023-04-28 08:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:20:55 --> Input Class Initialized
INFO - 2023-04-28 08:20:55 --> Language Class Initialized
INFO - 2023-04-28 08:20:55 --> Loader Class Initialized
INFO - 2023-04-28 08:20:55 --> Controller Class Initialized
DEBUG - 2023-04-28 08:20:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:20:55 --> Database Driver Class Initialized
INFO - 2023-04-28 08:20:55 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:20:55 --> Final output sent to browser
DEBUG - 2023-04-28 08:20:55 --> Total execution time: 0.0600
INFO - 2023-04-28 08:21:16 --> Config Class Initialized
INFO - 2023-04-28 08:21:16 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:21:16 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:21:16 --> Utf8 Class Initialized
INFO - 2023-04-28 08:21:16 --> URI Class Initialized
INFO - 2023-04-28 08:21:16 --> Router Class Initialized
INFO - 2023-04-28 08:21:16 --> Output Class Initialized
INFO - 2023-04-28 08:21:16 --> Security Class Initialized
DEBUG - 2023-04-28 08:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:21:16 --> Input Class Initialized
INFO - 2023-04-28 08:21:16 --> Language Class Initialized
INFO - 2023-04-28 08:21:16 --> Loader Class Initialized
INFO - 2023-04-28 08:21:16 --> Controller Class Initialized
DEBUG - 2023-04-28 08:21:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:21:16 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:16 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:21:16 --> Final output sent to browser
DEBUG - 2023-04-28 08:21:16 --> Total execution time: 0.0145
INFO - 2023-04-28 08:21:16 --> Config Class Initialized
INFO - 2023-04-28 08:21:16 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:21:16 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:21:16 --> Utf8 Class Initialized
INFO - 2023-04-28 08:21:16 --> URI Class Initialized
INFO - 2023-04-28 08:21:16 --> Router Class Initialized
INFO - 2023-04-28 08:21:16 --> Output Class Initialized
INFO - 2023-04-28 08:21:16 --> Security Class Initialized
DEBUG - 2023-04-28 08:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:21:16 --> Input Class Initialized
INFO - 2023-04-28 08:21:16 --> Language Class Initialized
INFO - 2023-04-28 08:21:16 --> Loader Class Initialized
INFO - 2023-04-28 08:21:16 --> Controller Class Initialized
DEBUG - 2023-04-28 08:21:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:21:16 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:16 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:21:16 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:16 --> Model "Login_model" initialized
INFO - 2023-04-28 08:21:16 --> Final output sent to browser
DEBUG - 2023-04-28 08:21:16 --> Total execution time: 0.0438
INFO - 2023-04-28 08:21:17 --> Config Class Initialized
INFO - 2023-04-28 08:21:17 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:21:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:21:17 --> Utf8 Class Initialized
INFO - 2023-04-28 08:21:17 --> URI Class Initialized
INFO - 2023-04-28 08:21:17 --> Router Class Initialized
INFO - 2023-04-28 08:21:17 --> Output Class Initialized
INFO - 2023-04-28 08:21:17 --> Security Class Initialized
DEBUG - 2023-04-28 08:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:21:17 --> Input Class Initialized
INFO - 2023-04-28 08:21:17 --> Language Class Initialized
INFO - 2023-04-28 08:21:17 --> Loader Class Initialized
INFO - 2023-04-28 08:21:17 --> Controller Class Initialized
DEBUG - 2023-04-28 08:21:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:21:17 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:21:17 --> Final output sent to browser
DEBUG - 2023-04-28 08:21:17 --> Total execution time: 0.0337
INFO - 2023-04-28 08:21:17 --> Config Class Initialized
INFO - 2023-04-28 08:21:17 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:21:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:21:17 --> Utf8 Class Initialized
INFO - 2023-04-28 08:21:17 --> URI Class Initialized
INFO - 2023-04-28 08:21:17 --> Router Class Initialized
INFO - 2023-04-28 08:21:17 --> Output Class Initialized
INFO - 2023-04-28 08:21:17 --> Security Class Initialized
DEBUG - 2023-04-28 08:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:21:17 --> Input Class Initialized
INFO - 2023-04-28 08:21:17 --> Language Class Initialized
INFO - 2023-04-28 08:21:17 --> Loader Class Initialized
INFO - 2023-04-28 08:21:17 --> Controller Class Initialized
DEBUG - 2023-04-28 08:21:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:21:17 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:21:17 --> Final output sent to browser
DEBUG - 2023-04-28 08:21:17 --> Total execution time: 0.3148
INFO - 2023-04-28 08:21:21 --> Config Class Initialized
INFO - 2023-04-28 08:21:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:21:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:21:21 --> Utf8 Class Initialized
INFO - 2023-04-28 08:21:21 --> URI Class Initialized
INFO - 2023-04-28 08:21:21 --> Router Class Initialized
INFO - 2023-04-28 08:21:21 --> Output Class Initialized
INFO - 2023-04-28 08:21:21 --> Security Class Initialized
DEBUG - 2023-04-28 08:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:21:21 --> Input Class Initialized
INFO - 2023-04-28 08:21:21 --> Language Class Initialized
INFO - 2023-04-28 08:21:21 --> Loader Class Initialized
INFO - 2023-04-28 08:21:21 --> Controller Class Initialized
DEBUG - 2023-04-28 08:21:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:21:21 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:21:21 --> Final output sent to browser
DEBUG - 2023-04-28 08:21:21 --> Total execution time: 0.0331
INFO - 2023-04-28 08:21:26 --> Config Class Initialized
INFO - 2023-04-28 08:21:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:21:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:21:26 --> Utf8 Class Initialized
INFO - 2023-04-28 08:21:26 --> URI Class Initialized
INFO - 2023-04-28 08:21:26 --> Router Class Initialized
INFO - 2023-04-28 08:21:26 --> Output Class Initialized
INFO - 2023-04-28 08:21:26 --> Security Class Initialized
DEBUG - 2023-04-28 08:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:21:26 --> Input Class Initialized
INFO - 2023-04-28 08:21:26 --> Language Class Initialized
INFO - 2023-04-28 08:21:26 --> Loader Class Initialized
INFO - 2023-04-28 08:21:26 --> Controller Class Initialized
DEBUG - 2023-04-28 08:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:21:26 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:21:26 --> Final output sent to browser
DEBUG - 2023-04-28 08:21:26 --> Total execution time: 0.0140
INFO - 2023-04-28 08:21:26 --> Config Class Initialized
INFO - 2023-04-28 08:21:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:21:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:21:26 --> Utf8 Class Initialized
INFO - 2023-04-28 08:21:26 --> URI Class Initialized
INFO - 2023-04-28 08:21:26 --> Router Class Initialized
INFO - 2023-04-28 08:21:26 --> Output Class Initialized
INFO - 2023-04-28 08:21:26 --> Security Class Initialized
DEBUG - 2023-04-28 08:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:21:26 --> Input Class Initialized
INFO - 2023-04-28 08:21:26 --> Language Class Initialized
INFO - 2023-04-28 08:21:26 --> Loader Class Initialized
INFO - 2023-04-28 08:21:26 --> Controller Class Initialized
DEBUG - 2023-04-28 08:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:21:26 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:21:26 --> Final output sent to browser
DEBUG - 2023-04-28 08:21:26 --> Total execution time: 0.0118
INFO - 2023-04-28 08:21:31 --> Config Class Initialized
INFO - 2023-04-28 08:21:31 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:21:31 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:21:31 --> Utf8 Class Initialized
INFO - 2023-04-28 08:21:31 --> URI Class Initialized
INFO - 2023-04-28 08:21:31 --> Router Class Initialized
INFO - 2023-04-28 08:21:31 --> Output Class Initialized
INFO - 2023-04-28 08:21:31 --> Security Class Initialized
DEBUG - 2023-04-28 08:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:21:31 --> Input Class Initialized
INFO - 2023-04-28 08:21:31 --> Language Class Initialized
INFO - 2023-04-28 08:21:31 --> Loader Class Initialized
INFO - 2023-04-28 08:21:31 --> Controller Class Initialized
DEBUG - 2023-04-28 08:21:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:21:31 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:31 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:21:31 --> Final output sent to browser
DEBUG - 2023-04-28 08:21:31 --> Total execution time: 0.0189
INFO - 2023-04-28 08:21:36 --> Config Class Initialized
INFO - 2023-04-28 08:21:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:21:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:21:36 --> Utf8 Class Initialized
INFO - 2023-04-28 08:21:36 --> URI Class Initialized
INFO - 2023-04-28 08:21:36 --> Router Class Initialized
INFO - 2023-04-28 08:21:36 --> Output Class Initialized
INFO - 2023-04-28 08:21:36 --> Security Class Initialized
DEBUG - 2023-04-28 08:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:21:36 --> Input Class Initialized
INFO - 2023-04-28 08:21:36 --> Language Class Initialized
INFO - 2023-04-28 08:21:36 --> Loader Class Initialized
INFO - 2023-04-28 08:21:36 --> Controller Class Initialized
DEBUG - 2023-04-28 08:21:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:21:36 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:21:36 --> Final output sent to browser
DEBUG - 2023-04-28 08:21:36 --> Total execution time: 0.0137
INFO - 2023-04-28 08:21:36 --> Config Class Initialized
INFO - 2023-04-28 08:21:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:21:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:21:36 --> Utf8 Class Initialized
INFO - 2023-04-28 08:21:36 --> URI Class Initialized
INFO - 2023-04-28 08:21:36 --> Router Class Initialized
INFO - 2023-04-28 08:21:36 --> Output Class Initialized
INFO - 2023-04-28 08:21:36 --> Security Class Initialized
DEBUG - 2023-04-28 08:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:21:36 --> Input Class Initialized
INFO - 2023-04-28 08:21:36 --> Language Class Initialized
INFO - 2023-04-28 08:21:36 --> Loader Class Initialized
INFO - 2023-04-28 08:21:36 --> Controller Class Initialized
DEBUG - 2023-04-28 08:21:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:21:36 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:21:36 --> Final output sent to browser
DEBUG - 2023-04-28 08:21:36 --> Total execution time: 0.0130
INFO - 2023-04-28 08:21:41 --> Config Class Initialized
INFO - 2023-04-28 08:21:41 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:21:41 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:21:41 --> Utf8 Class Initialized
INFO - 2023-04-28 08:21:41 --> URI Class Initialized
INFO - 2023-04-28 08:21:41 --> Router Class Initialized
INFO - 2023-04-28 08:21:41 --> Output Class Initialized
INFO - 2023-04-28 08:21:41 --> Security Class Initialized
DEBUG - 2023-04-28 08:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:21:41 --> Input Class Initialized
INFO - 2023-04-28 08:21:41 --> Language Class Initialized
INFO - 2023-04-28 08:21:41 --> Loader Class Initialized
INFO - 2023-04-28 08:21:41 --> Controller Class Initialized
DEBUG - 2023-04-28 08:21:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:21:41 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:41 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:21:41 --> Final output sent to browser
DEBUG - 2023-04-28 08:21:41 --> Total execution time: 0.0172
INFO - 2023-04-28 08:21:46 --> Config Class Initialized
INFO - 2023-04-28 08:21:46 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:21:46 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:21:46 --> Utf8 Class Initialized
INFO - 2023-04-28 08:21:46 --> URI Class Initialized
INFO - 2023-04-28 08:21:46 --> Router Class Initialized
INFO - 2023-04-28 08:21:46 --> Output Class Initialized
INFO - 2023-04-28 08:21:46 --> Security Class Initialized
DEBUG - 2023-04-28 08:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:21:46 --> Input Class Initialized
INFO - 2023-04-28 08:21:46 --> Language Class Initialized
INFO - 2023-04-28 08:21:46 --> Loader Class Initialized
INFO - 2023-04-28 08:21:46 --> Controller Class Initialized
DEBUG - 2023-04-28 08:21:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:21:46 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:46 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:21:46 --> Final output sent to browser
DEBUG - 2023-04-28 08:21:46 --> Total execution time: 0.0138
INFO - 2023-04-28 08:21:46 --> Config Class Initialized
INFO - 2023-04-28 08:21:46 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:21:46 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:21:46 --> Utf8 Class Initialized
INFO - 2023-04-28 08:21:46 --> URI Class Initialized
INFO - 2023-04-28 08:21:46 --> Router Class Initialized
INFO - 2023-04-28 08:21:46 --> Output Class Initialized
INFO - 2023-04-28 08:21:46 --> Security Class Initialized
DEBUG - 2023-04-28 08:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:21:46 --> Input Class Initialized
INFO - 2023-04-28 08:21:46 --> Language Class Initialized
INFO - 2023-04-28 08:21:46 --> Loader Class Initialized
INFO - 2023-04-28 08:21:46 --> Controller Class Initialized
DEBUG - 2023-04-28 08:21:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:21:46 --> Database Driver Class Initialized
INFO - 2023-04-28 08:21:46 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:21:46 --> Final output sent to browser
DEBUG - 2023-04-28 08:21:46 --> Total execution time: 0.0132
INFO - 2023-04-28 08:22:33 --> Config Class Initialized
INFO - 2023-04-28 08:22:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:22:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:22:33 --> Utf8 Class Initialized
INFO - 2023-04-28 08:22:33 --> URI Class Initialized
INFO - 2023-04-28 08:22:33 --> Router Class Initialized
INFO - 2023-04-28 08:22:33 --> Output Class Initialized
INFO - 2023-04-28 08:22:33 --> Security Class Initialized
DEBUG - 2023-04-28 08:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:22:33 --> Input Class Initialized
INFO - 2023-04-28 08:22:33 --> Language Class Initialized
INFO - 2023-04-28 08:22:33 --> Loader Class Initialized
INFO - 2023-04-28 08:22:33 --> Controller Class Initialized
DEBUG - 2023-04-28 08:22:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:22:33 --> Database Driver Class Initialized
INFO - 2023-04-28 08:22:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:22:33 --> Final output sent to browser
DEBUG - 2023-04-28 08:22:33 --> Total execution time: 0.0125
INFO - 2023-04-28 08:22:33 --> Config Class Initialized
INFO - 2023-04-28 08:22:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:22:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:22:33 --> Utf8 Class Initialized
INFO - 2023-04-28 08:22:33 --> URI Class Initialized
INFO - 2023-04-28 08:22:33 --> Router Class Initialized
INFO - 2023-04-28 08:22:33 --> Output Class Initialized
INFO - 2023-04-28 08:22:33 --> Security Class Initialized
DEBUG - 2023-04-28 08:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:22:33 --> Input Class Initialized
INFO - 2023-04-28 08:22:33 --> Language Class Initialized
INFO - 2023-04-28 08:22:33 --> Loader Class Initialized
INFO - 2023-04-28 08:22:33 --> Controller Class Initialized
DEBUG - 2023-04-28 08:22:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:22:33 --> Database Driver Class Initialized
INFO - 2023-04-28 08:22:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:22:33 --> Final output sent to browser
DEBUG - 2023-04-28 08:22:33 --> Total execution time: 0.0670
INFO - 2023-04-28 08:22:33 --> Config Class Initialized
INFO - 2023-04-28 08:22:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:22:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:22:33 --> Utf8 Class Initialized
INFO - 2023-04-28 08:22:33 --> URI Class Initialized
INFO - 2023-04-28 08:22:33 --> Router Class Initialized
INFO - 2023-04-28 08:22:33 --> Output Class Initialized
INFO - 2023-04-28 08:22:33 --> Security Class Initialized
DEBUG - 2023-04-28 08:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:22:33 --> Input Class Initialized
INFO - 2023-04-28 08:22:33 --> Language Class Initialized
INFO - 2023-04-28 08:22:33 --> Loader Class Initialized
INFO - 2023-04-28 08:22:33 --> Controller Class Initialized
DEBUG - 2023-04-28 08:22:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:22:33 --> Database Driver Class Initialized
INFO - 2023-04-28 08:22:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:22:33 --> Final output sent to browser
DEBUG - 2023-04-28 08:22:33 --> Total execution time: 0.0113
INFO - 2023-04-28 08:22:33 --> Config Class Initialized
INFO - 2023-04-28 08:22:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:22:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:22:33 --> Utf8 Class Initialized
INFO - 2023-04-28 08:22:33 --> URI Class Initialized
INFO - 2023-04-28 08:22:33 --> Router Class Initialized
INFO - 2023-04-28 08:22:33 --> Output Class Initialized
INFO - 2023-04-28 08:22:33 --> Security Class Initialized
DEBUG - 2023-04-28 08:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:22:33 --> Input Class Initialized
INFO - 2023-04-28 08:22:33 --> Language Class Initialized
INFO - 2023-04-28 08:22:33 --> Loader Class Initialized
INFO - 2023-04-28 08:22:33 --> Controller Class Initialized
DEBUG - 2023-04-28 08:22:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:22:33 --> Database Driver Class Initialized
INFO - 2023-04-28 08:22:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:22:33 --> Final output sent to browser
DEBUG - 2023-04-28 08:22:33 --> Total execution time: 0.0148
INFO - 2023-04-28 08:23:01 --> Config Class Initialized
INFO - 2023-04-28 08:23:01 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:01 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:01 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:01 --> URI Class Initialized
INFO - 2023-04-28 08:23:01 --> Router Class Initialized
INFO - 2023-04-28 08:23:01 --> Output Class Initialized
INFO - 2023-04-28 08:23:01 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:01 --> Input Class Initialized
INFO - 2023-04-28 08:23:01 --> Language Class Initialized
INFO - 2023-04-28 08:23:01 --> Loader Class Initialized
INFO - 2023-04-28 08:23:01 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:01 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:01 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:01 --> Total execution time: 0.0126
INFO - 2023-04-28 08:23:01 --> Config Class Initialized
INFO - 2023-04-28 08:23:01 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:01 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:01 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:01 --> URI Class Initialized
INFO - 2023-04-28 08:23:01 --> Router Class Initialized
INFO - 2023-04-28 08:23:01 --> Output Class Initialized
INFO - 2023-04-28 08:23:01 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:01 --> Input Class Initialized
INFO - 2023-04-28 08:23:01 --> Language Class Initialized
INFO - 2023-04-28 08:23:01 --> Loader Class Initialized
INFO - 2023-04-28 08:23:01 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:01 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:01 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:01 --> Model "Login_model" initialized
INFO - 2023-04-28 08:23:01 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:01 --> Total execution time: 0.0405
INFO - 2023-04-28 08:23:02 --> Config Class Initialized
INFO - 2023-04-28 08:23:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:02 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:02 --> URI Class Initialized
INFO - 2023-04-28 08:23:02 --> Router Class Initialized
INFO - 2023-04-28 08:23:02 --> Output Class Initialized
INFO - 2023-04-28 08:23:02 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:02 --> Input Class Initialized
INFO - 2023-04-28 08:23:02 --> Language Class Initialized
INFO - 2023-04-28 08:23:02 --> Loader Class Initialized
INFO - 2023-04-28 08:23:02 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:02 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:02 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:02 --> Total execution time: 0.0151
INFO - 2023-04-28 08:23:02 --> Config Class Initialized
INFO - 2023-04-28 08:23:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:02 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:02 --> URI Class Initialized
INFO - 2023-04-28 08:23:02 --> Router Class Initialized
INFO - 2023-04-28 08:23:02 --> Output Class Initialized
INFO - 2023-04-28 08:23:02 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:02 --> Input Class Initialized
INFO - 2023-04-28 08:23:02 --> Language Class Initialized
INFO - 2023-04-28 08:23:02 --> Loader Class Initialized
INFO - 2023-04-28 08:23:02 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:02 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:02 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:02 --> Total execution time: 0.7337
INFO - 2023-04-28 08:23:06 --> Config Class Initialized
INFO - 2023-04-28 08:23:06 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:06 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:06 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:06 --> URI Class Initialized
INFO - 2023-04-28 08:23:06 --> Router Class Initialized
INFO - 2023-04-28 08:23:06 --> Output Class Initialized
INFO - 2023-04-28 08:23:06 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:06 --> Input Class Initialized
INFO - 2023-04-28 08:23:06 --> Language Class Initialized
INFO - 2023-04-28 08:23:06 --> Loader Class Initialized
INFO - 2023-04-28 08:23:06 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:06 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:06 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:06 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:06 --> Total execution time: 0.0188
INFO - 2023-04-28 08:23:11 --> Config Class Initialized
INFO - 2023-04-28 08:23:11 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:11 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:11 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:11 --> URI Class Initialized
INFO - 2023-04-28 08:23:11 --> Router Class Initialized
INFO - 2023-04-28 08:23:11 --> Output Class Initialized
INFO - 2023-04-28 08:23:11 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:11 --> Input Class Initialized
INFO - 2023-04-28 08:23:11 --> Language Class Initialized
INFO - 2023-04-28 08:23:11 --> Loader Class Initialized
INFO - 2023-04-28 08:23:11 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:11 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:11 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:11 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:11 --> Total execution time: 0.0145
INFO - 2023-04-28 08:23:11 --> Config Class Initialized
INFO - 2023-04-28 08:23:11 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:11 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:11 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:11 --> URI Class Initialized
INFO - 2023-04-28 08:23:11 --> Router Class Initialized
INFO - 2023-04-28 08:23:11 --> Output Class Initialized
INFO - 2023-04-28 08:23:11 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:11 --> Input Class Initialized
INFO - 2023-04-28 08:23:11 --> Language Class Initialized
INFO - 2023-04-28 08:23:11 --> Loader Class Initialized
INFO - 2023-04-28 08:23:11 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:11 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:11 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:11 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:11 --> Total execution time: 0.0170
INFO - 2023-04-28 08:23:16 --> Config Class Initialized
INFO - 2023-04-28 08:23:16 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:16 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:16 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:16 --> URI Class Initialized
INFO - 2023-04-28 08:23:16 --> Router Class Initialized
INFO - 2023-04-28 08:23:16 --> Output Class Initialized
INFO - 2023-04-28 08:23:16 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:16 --> Input Class Initialized
INFO - 2023-04-28 08:23:16 --> Language Class Initialized
INFO - 2023-04-28 08:23:16 --> Loader Class Initialized
INFO - 2023-04-28 08:23:16 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:16 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:16 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:16 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:16 --> Total execution time: 0.0168
INFO - 2023-04-28 08:23:21 --> Config Class Initialized
INFO - 2023-04-28 08:23:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:21 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:21 --> URI Class Initialized
INFO - 2023-04-28 08:23:21 --> Router Class Initialized
INFO - 2023-04-28 08:23:21 --> Output Class Initialized
INFO - 2023-04-28 08:23:21 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:21 --> Input Class Initialized
INFO - 2023-04-28 08:23:21 --> Language Class Initialized
INFO - 2023-04-28 08:23:21 --> Loader Class Initialized
INFO - 2023-04-28 08:23:21 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:21 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:21 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:21 --> Total execution time: 0.0129
INFO - 2023-04-28 08:23:21 --> Config Class Initialized
INFO - 2023-04-28 08:23:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:21 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:21 --> URI Class Initialized
INFO - 2023-04-28 08:23:21 --> Router Class Initialized
INFO - 2023-04-28 08:23:21 --> Output Class Initialized
INFO - 2023-04-28 08:23:21 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:21 --> Input Class Initialized
INFO - 2023-04-28 08:23:21 --> Language Class Initialized
INFO - 2023-04-28 08:23:21 --> Loader Class Initialized
INFO - 2023-04-28 08:23:21 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:21 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:21 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:21 --> Total execution time: 0.0160
INFO - 2023-04-28 08:23:26 --> Config Class Initialized
INFO - 2023-04-28 08:23:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:26 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:26 --> URI Class Initialized
INFO - 2023-04-28 08:23:26 --> Router Class Initialized
INFO - 2023-04-28 08:23:26 --> Output Class Initialized
INFO - 2023-04-28 08:23:26 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:26 --> Input Class Initialized
INFO - 2023-04-28 08:23:26 --> Language Class Initialized
INFO - 2023-04-28 08:23:26 --> Loader Class Initialized
INFO - 2023-04-28 08:23:26 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:26 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:26 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:26 --> Total execution time: 0.0160
INFO - 2023-04-28 08:23:31 --> Config Class Initialized
INFO - 2023-04-28 08:23:31 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:31 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:31 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:31 --> URI Class Initialized
INFO - 2023-04-28 08:23:31 --> Router Class Initialized
INFO - 2023-04-28 08:23:31 --> Output Class Initialized
INFO - 2023-04-28 08:23:31 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:31 --> Input Class Initialized
INFO - 2023-04-28 08:23:31 --> Language Class Initialized
INFO - 2023-04-28 08:23:31 --> Loader Class Initialized
INFO - 2023-04-28 08:23:31 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:31 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:31 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:31 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:31 --> Total execution time: 0.0126
INFO - 2023-04-28 08:23:31 --> Config Class Initialized
INFO - 2023-04-28 08:23:31 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:31 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:31 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:31 --> URI Class Initialized
INFO - 2023-04-28 08:23:31 --> Router Class Initialized
INFO - 2023-04-28 08:23:31 --> Output Class Initialized
INFO - 2023-04-28 08:23:31 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:31 --> Input Class Initialized
INFO - 2023-04-28 08:23:31 --> Language Class Initialized
INFO - 2023-04-28 08:23:31 --> Loader Class Initialized
INFO - 2023-04-28 08:23:31 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:31 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:31 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:31 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:31 --> Total execution time: 0.0136
INFO - 2023-04-28 08:23:36 --> Config Class Initialized
INFO - 2023-04-28 08:23:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:36 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:36 --> URI Class Initialized
INFO - 2023-04-28 08:23:36 --> Router Class Initialized
INFO - 2023-04-28 08:23:36 --> Output Class Initialized
INFO - 2023-04-28 08:23:36 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:36 --> Input Class Initialized
INFO - 2023-04-28 08:23:36 --> Language Class Initialized
INFO - 2023-04-28 08:23:36 --> Loader Class Initialized
INFO - 2023-04-28 08:23:36 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:36 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:36 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:36 --> Total execution time: 0.0165
INFO - 2023-04-28 08:23:41 --> Config Class Initialized
INFO - 2023-04-28 08:23:41 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:41 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:41 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:41 --> URI Class Initialized
INFO - 2023-04-28 08:23:41 --> Router Class Initialized
INFO - 2023-04-28 08:23:41 --> Output Class Initialized
INFO - 2023-04-28 08:23:41 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:41 --> Input Class Initialized
INFO - 2023-04-28 08:23:41 --> Language Class Initialized
INFO - 2023-04-28 08:23:41 --> Loader Class Initialized
INFO - 2023-04-28 08:23:41 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:41 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:41 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:41 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:41 --> Total execution time: 0.0148
INFO - 2023-04-28 08:23:41 --> Config Class Initialized
INFO - 2023-04-28 08:23:41 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:41 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:41 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:41 --> URI Class Initialized
INFO - 2023-04-28 08:23:41 --> Router Class Initialized
INFO - 2023-04-28 08:23:41 --> Output Class Initialized
INFO - 2023-04-28 08:23:41 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:41 --> Input Class Initialized
INFO - 2023-04-28 08:23:41 --> Language Class Initialized
INFO - 2023-04-28 08:23:41 --> Loader Class Initialized
INFO - 2023-04-28 08:23:41 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:41 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:41 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:41 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:41 --> Total execution time: 0.0137
INFO - 2023-04-28 08:23:46 --> Config Class Initialized
INFO - 2023-04-28 08:23:46 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:46 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:46 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:46 --> URI Class Initialized
INFO - 2023-04-28 08:23:46 --> Router Class Initialized
INFO - 2023-04-28 08:23:46 --> Output Class Initialized
INFO - 2023-04-28 08:23:46 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:46 --> Input Class Initialized
INFO - 2023-04-28 08:23:46 --> Language Class Initialized
INFO - 2023-04-28 08:23:46 --> Loader Class Initialized
INFO - 2023-04-28 08:23:46 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:46 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:46 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:46 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:46 --> Total execution time: 0.0167
INFO - 2023-04-28 08:23:51 --> Config Class Initialized
INFO - 2023-04-28 08:23:51 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:51 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:51 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:51 --> URI Class Initialized
INFO - 2023-04-28 08:23:51 --> Router Class Initialized
INFO - 2023-04-28 08:23:51 --> Output Class Initialized
INFO - 2023-04-28 08:23:51 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:51 --> Input Class Initialized
INFO - 2023-04-28 08:23:51 --> Language Class Initialized
INFO - 2023-04-28 08:23:51 --> Loader Class Initialized
INFO - 2023-04-28 08:23:51 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:51 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:51 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:51 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:51 --> Total execution time: 0.0161
INFO - 2023-04-28 08:23:51 --> Config Class Initialized
INFO - 2023-04-28 08:23:51 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:51 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:51 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:51 --> URI Class Initialized
INFO - 2023-04-28 08:23:51 --> Router Class Initialized
INFO - 2023-04-28 08:23:51 --> Output Class Initialized
INFO - 2023-04-28 08:23:51 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:51 --> Input Class Initialized
INFO - 2023-04-28 08:23:51 --> Language Class Initialized
INFO - 2023-04-28 08:23:51 --> Loader Class Initialized
INFO - 2023-04-28 08:23:51 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:51 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:51 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:51 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:51 --> Total execution time: 0.0126
INFO - 2023-04-28 08:23:56 --> Config Class Initialized
INFO - 2023-04-28 08:23:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:23:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:23:56 --> Utf8 Class Initialized
INFO - 2023-04-28 08:23:56 --> URI Class Initialized
INFO - 2023-04-28 08:23:56 --> Router Class Initialized
INFO - 2023-04-28 08:23:56 --> Output Class Initialized
INFO - 2023-04-28 08:23:56 --> Security Class Initialized
DEBUG - 2023-04-28 08:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:23:56 --> Input Class Initialized
INFO - 2023-04-28 08:23:56 --> Language Class Initialized
INFO - 2023-04-28 08:23:56 --> Loader Class Initialized
INFO - 2023-04-28 08:23:56 --> Controller Class Initialized
DEBUG - 2023-04-28 08:23:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:23:56 --> Database Driver Class Initialized
INFO - 2023-04-28 08:23:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:23:58 --> Final output sent to browser
DEBUG - 2023-04-28 08:23:58 --> Total execution time: 1.7876
INFO - 2023-04-28 08:24:01 --> Config Class Initialized
INFO - 2023-04-28 08:24:01 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:01 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:01 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:01 --> URI Class Initialized
INFO - 2023-04-28 08:24:01 --> Router Class Initialized
INFO - 2023-04-28 08:24:01 --> Output Class Initialized
INFO - 2023-04-28 08:24:01 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:01 --> Input Class Initialized
INFO - 2023-04-28 08:24:01 --> Language Class Initialized
INFO - 2023-04-28 08:24:01 --> Loader Class Initialized
INFO - 2023-04-28 08:24:01 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:01 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:01 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:01 --> Total execution time: 0.0140
INFO - 2023-04-28 08:24:01 --> Config Class Initialized
INFO - 2023-04-28 08:24:01 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:01 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:01 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:01 --> URI Class Initialized
INFO - 2023-04-28 08:24:01 --> Router Class Initialized
INFO - 2023-04-28 08:24:01 --> Output Class Initialized
INFO - 2023-04-28 08:24:01 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:01 --> Input Class Initialized
INFO - 2023-04-28 08:24:01 --> Language Class Initialized
INFO - 2023-04-28 08:24:01 --> Loader Class Initialized
INFO - 2023-04-28 08:24:01 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:01 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:01 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:01 --> Total execution time: 0.0141
INFO - 2023-04-28 08:24:06 --> Config Class Initialized
INFO - 2023-04-28 08:24:06 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:06 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:06 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:06 --> URI Class Initialized
INFO - 2023-04-28 08:24:06 --> Router Class Initialized
INFO - 2023-04-28 08:24:06 --> Output Class Initialized
INFO - 2023-04-28 08:24:06 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:06 --> Input Class Initialized
INFO - 2023-04-28 08:24:06 --> Language Class Initialized
INFO - 2023-04-28 08:24:06 --> Loader Class Initialized
INFO - 2023-04-28 08:24:06 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:06 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:06 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:06 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:06 --> Total execution time: 0.0164
INFO - 2023-04-28 08:24:11 --> Config Class Initialized
INFO - 2023-04-28 08:24:11 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:11 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:11 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:11 --> URI Class Initialized
INFO - 2023-04-28 08:24:11 --> Router Class Initialized
INFO - 2023-04-28 08:24:11 --> Output Class Initialized
INFO - 2023-04-28 08:24:11 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:11 --> Input Class Initialized
INFO - 2023-04-28 08:24:11 --> Language Class Initialized
INFO - 2023-04-28 08:24:11 --> Loader Class Initialized
INFO - 2023-04-28 08:24:11 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:11 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:11 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:11 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:11 --> Total execution time: 0.0168
INFO - 2023-04-28 08:24:11 --> Config Class Initialized
INFO - 2023-04-28 08:24:11 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:11 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:11 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:11 --> URI Class Initialized
INFO - 2023-04-28 08:24:11 --> Router Class Initialized
INFO - 2023-04-28 08:24:11 --> Output Class Initialized
INFO - 2023-04-28 08:24:11 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:11 --> Input Class Initialized
INFO - 2023-04-28 08:24:11 --> Language Class Initialized
INFO - 2023-04-28 08:24:11 --> Loader Class Initialized
INFO - 2023-04-28 08:24:11 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:11 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:11 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:12 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:12 --> Total execution time: 0.2909
INFO - 2023-04-28 08:24:16 --> Config Class Initialized
INFO - 2023-04-28 08:24:16 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:16 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:16 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:16 --> URI Class Initialized
INFO - 2023-04-28 08:24:16 --> Router Class Initialized
INFO - 2023-04-28 08:24:16 --> Output Class Initialized
INFO - 2023-04-28 08:24:16 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:16 --> Input Class Initialized
INFO - 2023-04-28 08:24:16 --> Language Class Initialized
INFO - 2023-04-28 08:24:16 --> Loader Class Initialized
INFO - 2023-04-28 08:24:16 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:16 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:16 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:16 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:16 --> Total execution time: 0.0189
INFO - 2023-04-28 08:24:21 --> Config Class Initialized
INFO - 2023-04-28 08:24:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:21 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:21 --> URI Class Initialized
INFO - 2023-04-28 08:24:21 --> Router Class Initialized
INFO - 2023-04-28 08:24:21 --> Output Class Initialized
INFO - 2023-04-28 08:24:21 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:21 --> Input Class Initialized
INFO - 2023-04-28 08:24:21 --> Language Class Initialized
INFO - 2023-04-28 08:24:21 --> Loader Class Initialized
INFO - 2023-04-28 08:24:21 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:21 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:21 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:21 --> Total execution time: 0.0151
INFO - 2023-04-28 08:24:21 --> Config Class Initialized
INFO - 2023-04-28 08:24:21 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:21 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:21 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:21 --> URI Class Initialized
INFO - 2023-04-28 08:24:21 --> Router Class Initialized
INFO - 2023-04-28 08:24:21 --> Output Class Initialized
INFO - 2023-04-28 08:24:21 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:21 --> Input Class Initialized
INFO - 2023-04-28 08:24:21 --> Language Class Initialized
INFO - 2023-04-28 08:24:21 --> Loader Class Initialized
INFO - 2023-04-28 08:24:21 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:21 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:21 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:21 --> Total execution time: 0.0143
INFO - 2023-04-28 08:24:26 --> Config Class Initialized
INFO - 2023-04-28 08:24:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:26 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:26 --> URI Class Initialized
INFO - 2023-04-28 08:24:26 --> Router Class Initialized
INFO - 2023-04-28 08:24:26 --> Output Class Initialized
INFO - 2023-04-28 08:24:26 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:26 --> Input Class Initialized
INFO - 2023-04-28 08:24:26 --> Language Class Initialized
INFO - 2023-04-28 08:24:26 --> Loader Class Initialized
INFO - 2023-04-28 08:24:26 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:26 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:26 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:26 --> Total execution time: 0.0175
INFO - 2023-04-28 08:24:31 --> Config Class Initialized
INFO - 2023-04-28 08:24:31 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:31 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:31 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:31 --> URI Class Initialized
INFO - 2023-04-28 08:24:31 --> Router Class Initialized
INFO - 2023-04-28 08:24:31 --> Output Class Initialized
INFO - 2023-04-28 08:24:31 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:31 --> Input Class Initialized
INFO - 2023-04-28 08:24:31 --> Language Class Initialized
INFO - 2023-04-28 08:24:31 --> Loader Class Initialized
INFO - 2023-04-28 08:24:31 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:31 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:31 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:31 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:31 --> Total execution time: 0.0122
INFO - 2023-04-28 08:24:31 --> Config Class Initialized
INFO - 2023-04-28 08:24:31 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:31 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:31 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:31 --> URI Class Initialized
INFO - 2023-04-28 08:24:31 --> Router Class Initialized
INFO - 2023-04-28 08:24:31 --> Output Class Initialized
INFO - 2023-04-28 08:24:31 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:31 --> Input Class Initialized
INFO - 2023-04-28 08:24:31 --> Language Class Initialized
INFO - 2023-04-28 08:24:31 --> Loader Class Initialized
INFO - 2023-04-28 08:24:31 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:31 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:31 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:31 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:31 --> Total execution time: 0.0151
INFO - 2023-04-28 08:24:36 --> Config Class Initialized
INFO - 2023-04-28 08:24:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:36 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:36 --> URI Class Initialized
INFO - 2023-04-28 08:24:36 --> Router Class Initialized
INFO - 2023-04-28 08:24:36 --> Output Class Initialized
INFO - 2023-04-28 08:24:36 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:36 --> Input Class Initialized
INFO - 2023-04-28 08:24:36 --> Language Class Initialized
INFO - 2023-04-28 08:24:36 --> Loader Class Initialized
INFO - 2023-04-28 08:24:36 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:36 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:36 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:36 --> Total execution time: 0.0183
INFO - 2023-04-28 08:24:41 --> Config Class Initialized
INFO - 2023-04-28 08:24:41 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:41 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:41 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:41 --> URI Class Initialized
INFO - 2023-04-28 08:24:41 --> Router Class Initialized
INFO - 2023-04-28 08:24:41 --> Output Class Initialized
INFO - 2023-04-28 08:24:41 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:41 --> Input Class Initialized
INFO - 2023-04-28 08:24:41 --> Language Class Initialized
INFO - 2023-04-28 08:24:41 --> Loader Class Initialized
INFO - 2023-04-28 08:24:41 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:41 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:41 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:41 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:41 --> Total execution time: 0.0132
INFO - 2023-04-28 08:24:41 --> Config Class Initialized
INFO - 2023-04-28 08:24:41 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:41 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:41 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:41 --> URI Class Initialized
INFO - 2023-04-28 08:24:41 --> Router Class Initialized
INFO - 2023-04-28 08:24:41 --> Output Class Initialized
INFO - 2023-04-28 08:24:41 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:41 --> Input Class Initialized
INFO - 2023-04-28 08:24:41 --> Language Class Initialized
INFO - 2023-04-28 08:24:41 --> Loader Class Initialized
INFO - 2023-04-28 08:24:41 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:41 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:41 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:41 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:41 --> Total execution time: 0.0137
INFO - 2023-04-28 08:24:46 --> Config Class Initialized
INFO - 2023-04-28 08:24:46 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:46 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:46 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:46 --> URI Class Initialized
INFO - 2023-04-28 08:24:46 --> Router Class Initialized
INFO - 2023-04-28 08:24:46 --> Output Class Initialized
INFO - 2023-04-28 08:24:46 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:46 --> Input Class Initialized
INFO - 2023-04-28 08:24:46 --> Language Class Initialized
INFO - 2023-04-28 08:24:46 --> Loader Class Initialized
INFO - 2023-04-28 08:24:46 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:46 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:46 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:46 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:46 --> Total execution time: 0.0194
INFO - 2023-04-28 08:24:51 --> Config Class Initialized
INFO - 2023-04-28 08:24:51 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:51 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:51 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:51 --> URI Class Initialized
INFO - 2023-04-28 08:24:51 --> Router Class Initialized
INFO - 2023-04-28 08:24:51 --> Output Class Initialized
INFO - 2023-04-28 08:24:51 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:51 --> Input Class Initialized
INFO - 2023-04-28 08:24:51 --> Language Class Initialized
INFO - 2023-04-28 08:24:51 --> Loader Class Initialized
INFO - 2023-04-28 08:24:51 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:51 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:51 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:51 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:51 --> Total execution time: 0.0127
INFO - 2023-04-28 08:24:51 --> Config Class Initialized
INFO - 2023-04-28 08:24:51 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:51 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:51 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:51 --> URI Class Initialized
INFO - 2023-04-28 08:24:51 --> Router Class Initialized
INFO - 2023-04-28 08:24:51 --> Output Class Initialized
INFO - 2023-04-28 08:24:51 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:51 --> Input Class Initialized
INFO - 2023-04-28 08:24:51 --> Language Class Initialized
INFO - 2023-04-28 08:24:51 --> Loader Class Initialized
INFO - 2023-04-28 08:24:51 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:51 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:51 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:51 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:51 --> Total execution time: 0.0151
INFO - 2023-04-28 08:24:56 --> Config Class Initialized
INFO - 2023-04-28 08:24:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:56 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:56 --> URI Class Initialized
INFO - 2023-04-28 08:24:56 --> Router Class Initialized
INFO - 2023-04-28 08:24:56 --> Output Class Initialized
INFO - 2023-04-28 08:24:56 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:56 --> Input Class Initialized
INFO - 2023-04-28 08:24:56 --> Language Class Initialized
INFO - 2023-04-28 08:24:56 --> Loader Class Initialized
INFO - 2023-04-28 08:24:56 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:56 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:56 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:56 --> Total execution time: 0.0140
INFO - 2023-04-28 08:24:56 --> Config Class Initialized
INFO - 2023-04-28 08:24:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:56 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:56 --> URI Class Initialized
INFO - 2023-04-28 08:24:56 --> Router Class Initialized
INFO - 2023-04-28 08:24:56 --> Output Class Initialized
INFO - 2023-04-28 08:24:56 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:56 --> Input Class Initialized
INFO - 2023-04-28 08:24:56 --> Language Class Initialized
INFO - 2023-04-28 08:24:56 --> Loader Class Initialized
INFO - 2023-04-28 08:24:56 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:56 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:56 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:56 --> Total execution time: 0.0134
INFO - 2023-04-28 08:24:56 --> Config Class Initialized
INFO - 2023-04-28 08:24:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:24:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:24:56 --> Utf8 Class Initialized
INFO - 2023-04-28 08:24:56 --> URI Class Initialized
INFO - 2023-04-28 08:24:56 --> Router Class Initialized
INFO - 2023-04-28 08:24:56 --> Output Class Initialized
INFO - 2023-04-28 08:24:56 --> Security Class Initialized
DEBUG - 2023-04-28 08:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:24:56 --> Input Class Initialized
INFO - 2023-04-28 08:24:56 --> Language Class Initialized
INFO - 2023-04-28 08:24:56 --> Loader Class Initialized
INFO - 2023-04-28 08:24:56 --> Controller Class Initialized
DEBUG - 2023-04-28 08:24:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:24:56 --> Database Driver Class Initialized
INFO - 2023-04-28 08:24:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:24:56 --> Final output sent to browser
DEBUG - 2023-04-28 08:24:56 --> Total execution time: 0.0395
INFO - 2023-04-28 08:33:09 --> Config Class Initialized
INFO - 2023-04-28 08:33:09 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:33:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:33:09 --> Utf8 Class Initialized
INFO - 2023-04-28 08:33:09 --> URI Class Initialized
INFO - 2023-04-28 08:33:09 --> Router Class Initialized
INFO - 2023-04-28 08:33:09 --> Output Class Initialized
INFO - 2023-04-28 08:33:09 --> Security Class Initialized
DEBUG - 2023-04-28 08:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:33:09 --> Input Class Initialized
INFO - 2023-04-28 08:33:09 --> Language Class Initialized
INFO - 2023-04-28 08:33:09 --> Loader Class Initialized
INFO - 2023-04-28 08:33:09 --> Controller Class Initialized
DEBUG - 2023-04-28 08:33:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:33:09 --> Database Driver Class Initialized
INFO - 2023-04-28 08:33:09 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:33:09 --> Final output sent to browser
DEBUG - 2023-04-28 08:33:09 --> Total execution time: 0.0208
INFO - 2023-04-28 08:33:09 --> Config Class Initialized
INFO - 2023-04-28 08:33:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:33:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:33:10 --> Utf8 Class Initialized
INFO - 2023-04-28 08:33:10 --> URI Class Initialized
INFO - 2023-04-28 08:33:10 --> Router Class Initialized
INFO - 2023-04-28 08:33:10 --> Output Class Initialized
INFO - 2023-04-28 08:33:10 --> Security Class Initialized
DEBUG - 2023-04-28 08:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:33:10 --> Input Class Initialized
INFO - 2023-04-28 08:33:10 --> Language Class Initialized
INFO - 2023-04-28 08:33:10 --> Loader Class Initialized
INFO - 2023-04-28 08:33:10 --> Controller Class Initialized
DEBUG - 2023-04-28 08:33:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:33:10 --> Database Driver Class Initialized
INFO - 2023-04-28 08:33:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:33:10 --> Final output sent to browser
DEBUG - 2023-04-28 08:33:10 --> Total execution time: 0.0541
INFO - 2023-04-28 08:33:10 --> Config Class Initialized
INFO - 2023-04-28 08:33:10 --> Hooks Class Initialized
INFO - 2023-04-28 08:33:10 --> Config Class Initialized
DEBUG - 2023-04-28 08:33:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:33:10 --> Hooks Class Initialized
INFO - 2023-04-28 08:33:10 --> Utf8 Class Initialized
DEBUG - 2023-04-28 08:33:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:33:10 --> URI Class Initialized
INFO - 2023-04-28 08:33:10 --> Utf8 Class Initialized
INFO - 2023-04-28 08:33:10 --> Router Class Initialized
INFO - 2023-04-28 08:33:10 --> URI Class Initialized
INFO - 2023-04-28 08:33:10 --> Output Class Initialized
INFO - 2023-04-28 08:33:10 --> Router Class Initialized
INFO - 2023-04-28 08:33:10 --> Security Class Initialized
INFO - 2023-04-28 08:33:10 --> Output Class Initialized
DEBUG - 2023-04-28 08:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:33:10 --> Security Class Initialized
INFO - 2023-04-28 08:33:10 --> Input Class Initialized
DEBUG - 2023-04-28 08:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:33:10 --> Input Class Initialized
INFO - 2023-04-28 08:33:10 --> Language Class Initialized
INFO - 2023-04-28 08:33:10 --> Language Class Initialized
INFO - 2023-04-28 08:33:10 --> Loader Class Initialized
INFO - 2023-04-28 08:33:10 --> Controller Class Initialized
INFO - 2023-04-28 08:33:10 --> Loader Class Initialized
DEBUG - 2023-04-28 08:33:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:33:10 --> Controller Class Initialized
INFO - 2023-04-28 08:33:10 --> Database Driver Class Initialized
DEBUG - 2023-04-28 08:33:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:33:10 --> Final output sent to browser
DEBUG - 2023-04-28 08:33:10 --> Total execution time: 0.0031
INFO - 2023-04-28 08:33:10 --> Config Class Initialized
INFO - 2023-04-28 08:33:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:33:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:33:10 --> Utf8 Class Initialized
INFO - 2023-04-28 08:33:10 --> URI Class Initialized
INFO - 2023-04-28 08:33:10 --> Router Class Initialized
INFO - 2023-04-28 08:33:10 --> Output Class Initialized
INFO - 2023-04-28 08:33:10 --> Security Class Initialized
DEBUG - 2023-04-28 08:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:33:10 --> Input Class Initialized
INFO - 2023-04-28 08:33:10 --> Language Class Initialized
INFO - 2023-04-28 08:33:10 --> Loader Class Initialized
INFO - 2023-04-28 08:33:10 --> Controller Class Initialized
DEBUG - 2023-04-28 08:33:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:33:10 --> Database Driver Class Initialized
INFO - 2023-04-28 08:33:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:33:10 --> Final output sent to browser
DEBUG - 2023-04-28 08:33:10 --> Total execution time: 0.0157
INFO - 2023-04-28 08:33:10 --> Config Class Initialized
INFO - 2023-04-28 08:33:10 --> Model "Login_model" initialized
INFO - 2023-04-28 08:33:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:33:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:33:10 --> Utf8 Class Initialized
INFO - 2023-04-28 08:33:10 --> URI Class Initialized
INFO - 2023-04-28 08:33:10 --> Router Class Initialized
INFO - 2023-04-28 08:33:10 --> Output Class Initialized
INFO - 2023-04-28 08:33:10 --> Security Class Initialized
DEBUG - 2023-04-28 08:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:33:10 --> Input Class Initialized
INFO - 2023-04-28 08:33:10 --> Language Class Initialized
INFO - 2023-04-28 08:33:10 --> Loader Class Initialized
INFO - 2023-04-28 08:33:10 --> Controller Class Initialized
DEBUG - 2023-04-28 08:33:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:33:10 --> Database Driver Class Initialized
INFO - 2023-04-28 08:33:10 --> Database Driver Class Initialized
INFO - 2023-04-28 08:33:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:33:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:33:10 --> Final output sent to browser
DEBUG - 2023-04-28 08:33:10 --> Total execution time: 0.0119
INFO - 2023-04-28 08:33:10 --> Final output sent to browser
DEBUG - 2023-04-28 08:33:10 --> Total execution time: 0.0254
INFO - 2023-04-28 08:33:13 --> Config Class Initialized
INFO - 2023-04-28 08:33:13 --> Config Class Initialized
INFO - 2023-04-28 08:33:13 --> Hooks Class Initialized
INFO - 2023-04-28 08:33:13 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:33:13 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 08:33:13 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:33:13 --> Utf8 Class Initialized
INFO - 2023-04-28 08:33:13 --> Utf8 Class Initialized
INFO - 2023-04-28 08:33:13 --> URI Class Initialized
INFO - 2023-04-28 08:33:13 --> URI Class Initialized
INFO - 2023-04-28 08:33:13 --> Router Class Initialized
INFO - 2023-04-28 08:33:13 --> Router Class Initialized
INFO - 2023-04-28 08:33:13 --> Output Class Initialized
INFO - 2023-04-28 08:33:13 --> Output Class Initialized
INFO - 2023-04-28 08:33:13 --> Security Class Initialized
INFO - 2023-04-28 08:33:13 --> Security Class Initialized
DEBUG - 2023-04-28 08:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 08:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:33:13 --> Input Class Initialized
INFO - 2023-04-28 08:33:13 --> Input Class Initialized
INFO - 2023-04-28 08:33:13 --> Language Class Initialized
INFO - 2023-04-28 08:33:13 --> Language Class Initialized
INFO - 2023-04-28 08:33:13 --> Loader Class Initialized
INFO - 2023-04-28 08:33:13 --> Loader Class Initialized
INFO - 2023-04-28 08:33:13 --> Controller Class Initialized
INFO - 2023-04-28 08:33:13 --> Controller Class Initialized
DEBUG - 2023-04-28 08:33:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 08:33:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:33:13 --> Database Driver Class Initialized
INFO - 2023-04-28 08:33:13 --> Database Driver Class Initialized
INFO - 2023-04-28 08:33:13 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:33:13 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:33:13 --> Final output sent to browser
DEBUG - 2023-04-28 08:33:13 --> Total execution time: 0.0215
INFO - 2023-04-28 08:33:13 --> Config Class Initialized
INFO - 2023-04-28 08:33:13 --> Database Driver Class Initialized
INFO - 2023-04-28 08:33:13 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:33:13 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:33:13 --> Utf8 Class Initialized
INFO - 2023-04-28 08:33:13 --> URI Class Initialized
INFO - 2023-04-28 08:33:13 --> Router Class Initialized
INFO - 2023-04-28 08:33:13 --> Output Class Initialized
INFO - 2023-04-28 08:33:13 --> Security Class Initialized
DEBUG - 2023-04-28 08:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:33:13 --> Input Class Initialized
INFO - 2023-04-28 08:33:13 --> Language Class Initialized
INFO - 2023-04-28 08:33:13 --> Loader Class Initialized
INFO - 2023-04-28 08:33:13 --> Controller Class Initialized
DEBUG - 2023-04-28 08:33:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:33:13 --> Database Driver Class Initialized
INFO - 2023-04-28 08:33:13 --> Model "Login_model" initialized
INFO - 2023-04-28 08:33:13 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:33:13 --> Final output sent to browser
DEBUG - 2023-04-28 08:33:13 --> Total execution time: 0.0769
INFO - 2023-04-28 08:33:13 --> Final output sent to browser
DEBUG - 2023-04-28 08:33:13 --> Total execution time: 0.1273
INFO - 2023-04-28 08:33:13 --> Config Class Initialized
INFO - 2023-04-28 08:33:13 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:33:13 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:33:13 --> Utf8 Class Initialized
INFO - 2023-04-28 08:33:13 --> URI Class Initialized
INFO - 2023-04-28 08:33:13 --> Router Class Initialized
INFO - 2023-04-28 08:33:13 --> Output Class Initialized
INFO - 2023-04-28 08:33:13 --> Security Class Initialized
DEBUG - 2023-04-28 08:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:33:13 --> Input Class Initialized
INFO - 2023-04-28 08:33:13 --> Language Class Initialized
INFO - 2023-04-28 08:33:13 --> Loader Class Initialized
INFO - 2023-04-28 08:33:13 --> Controller Class Initialized
DEBUG - 2023-04-28 08:33:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:33:13 --> Database Driver Class Initialized
INFO - 2023-04-28 08:33:13 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:33:13 --> Database Driver Class Initialized
INFO - 2023-04-28 08:33:13 --> Model "Login_model" initialized
INFO - 2023-04-28 08:33:13 --> Final output sent to browser
DEBUG - 2023-04-28 08:33:13 --> Total execution time: 0.0969
INFO - 2023-04-28 08:40:59 --> Config Class Initialized
INFO - 2023-04-28 08:40:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:40:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:40:59 --> Utf8 Class Initialized
INFO - 2023-04-28 08:40:59 --> URI Class Initialized
INFO - 2023-04-28 08:40:59 --> Router Class Initialized
INFO - 2023-04-28 08:40:59 --> Output Class Initialized
INFO - 2023-04-28 08:40:59 --> Security Class Initialized
DEBUG - 2023-04-28 08:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:40:59 --> Input Class Initialized
INFO - 2023-04-28 08:40:59 --> Language Class Initialized
INFO - 2023-04-28 08:40:59 --> Loader Class Initialized
INFO - 2023-04-28 08:40:59 --> Controller Class Initialized
DEBUG - 2023-04-28 08:40:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:40:59 --> Database Driver Class Initialized
INFO - 2023-04-28 08:40:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:40:59 --> Final output sent to browser
DEBUG - 2023-04-28 08:40:59 --> Total execution time: 0.0264
INFO - 2023-04-28 08:40:59 --> Config Class Initialized
INFO - 2023-04-28 08:40:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:40:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:40:59 --> Utf8 Class Initialized
INFO - 2023-04-28 08:40:59 --> URI Class Initialized
INFO - 2023-04-28 08:40:59 --> Router Class Initialized
INFO - 2023-04-28 08:40:59 --> Output Class Initialized
INFO - 2023-04-28 08:40:59 --> Security Class Initialized
DEBUG - 2023-04-28 08:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:40:59 --> Input Class Initialized
INFO - 2023-04-28 08:40:59 --> Language Class Initialized
INFO - 2023-04-28 08:40:59 --> Loader Class Initialized
INFO - 2023-04-28 08:40:59 --> Controller Class Initialized
DEBUG - 2023-04-28 08:40:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:40:59 --> Database Driver Class Initialized
INFO - 2023-04-28 08:40:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:40:59 --> Final output sent to browser
DEBUG - 2023-04-28 08:40:59 --> Total execution time: 0.0150
INFO - 2023-04-28 08:41:02 --> Config Class Initialized
INFO - 2023-04-28 08:41:02 --> Config Class Initialized
INFO - 2023-04-28 08:41:02 --> Hooks Class Initialized
INFO - 2023-04-28 08:41:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:41:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 08:41:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:41:02 --> Utf8 Class Initialized
INFO - 2023-04-28 08:41:02 --> Utf8 Class Initialized
INFO - 2023-04-28 08:41:02 --> URI Class Initialized
INFO - 2023-04-28 08:41:02 --> URI Class Initialized
INFO - 2023-04-28 08:41:02 --> Router Class Initialized
INFO - 2023-04-28 08:41:02 --> Router Class Initialized
INFO - 2023-04-28 08:41:02 --> Output Class Initialized
INFO - 2023-04-28 08:41:02 --> Output Class Initialized
INFO - 2023-04-28 08:41:02 --> Security Class Initialized
INFO - 2023-04-28 08:41:02 --> Security Class Initialized
DEBUG - 2023-04-28 08:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 08:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:41:02 --> Input Class Initialized
INFO - 2023-04-28 08:41:02 --> Input Class Initialized
INFO - 2023-04-28 08:41:02 --> Language Class Initialized
INFO - 2023-04-28 08:41:02 --> Language Class Initialized
INFO - 2023-04-28 08:41:02 --> Loader Class Initialized
INFO - 2023-04-28 08:41:02 --> Loader Class Initialized
INFO - 2023-04-28 08:41:02 --> Controller Class Initialized
INFO - 2023-04-28 08:41:02 --> Controller Class Initialized
DEBUG - 2023-04-28 08:41:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 08:41:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:41:02 --> Final output sent to browser
INFO - 2023-04-28 08:41:02 --> Database Driver Class Initialized
DEBUG - 2023-04-28 08:41:02 --> Total execution time: 0.0085
INFO - 2023-04-28 08:41:02 --> Config Class Initialized
INFO - 2023-04-28 08:41:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:41:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:41:02 --> Utf8 Class Initialized
INFO - 2023-04-28 08:41:02 --> URI Class Initialized
INFO - 2023-04-28 08:41:02 --> Router Class Initialized
INFO - 2023-04-28 08:41:02 --> Output Class Initialized
INFO - 2023-04-28 08:41:02 --> Security Class Initialized
DEBUG - 2023-04-28 08:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:41:02 --> Input Class Initialized
INFO - 2023-04-28 08:41:02 --> Language Class Initialized
INFO - 2023-04-28 08:41:02 --> Loader Class Initialized
INFO - 2023-04-28 08:41:02 --> Controller Class Initialized
DEBUG - 2023-04-28 08:41:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:41:02 --> Database Driver Class Initialized
INFO - 2023-04-28 08:41:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:41:02 --> Final output sent to browser
DEBUG - 2023-04-28 08:41:02 --> Total execution time: 0.0264
INFO - 2023-04-28 08:41:02 --> Config Class Initialized
INFO - 2023-04-28 08:41:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:41:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:41:02 --> Model "Login_model" initialized
INFO - 2023-04-28 08:41:02 --> Utf8 Class Initialized
INFO - 2023-04-28 08:41:02 --> URI Class Initialized
INFO - 2023-04-28 08:41:02 --> Router Class Initialized
INFO - 2023-04-28 08:41:02 --> Output Class Initialized
INFO - 2023-04-28 08:41:02 --> Security Class Initialized
DEBUG - 2023-04-28 08:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:41:02 --> Input Class Initialized
INFO - 2023-04-28 08:41:02 --> Language Class Initialized
INFO - 2023-04-28 08:41:02 --> Loader Class Initialized
INFO - 2023-04-28 08:41:02 --> Controller Class Initialized
DEBUG - 2023-04-28 08:41:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:41:02 --> Database Driver Class Initialized
INFO - 2023-04-28 08:41:02 --> Database Driver Class Initialized
INFO - 2023-04-28 08:41:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:41:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:41:02 --> Final output sent to browser
DEBUG - 2023-04-28 08:41:02 --> Total execution time: 0.0315
INFO - 2023-04-28 08:41:02 --> Final output sent to browser
DEBUG - 2023-04-28 08:41:02 --> Total execution time: 0.0167
INFO - 2023-04-28 08:44:22 --> Config Class Initialized
INFO - 2023-04-28 08:44:22 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:44:22 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:44:22 --> Utf8 Class Initialized
INFO - 2023-04-28 08:44:22 --> URI Class Initialized
INFO - 2023-04-28 08:44:22 --> Router Class Initialized
INFO - 2023-04-28 08:44:22 --> Output Class Initialized
INFO - 2023-04-28 08:44:22 --> Security Class Initialized
DEBUG - 2023-04-28 08:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:44:22 --> Input Class Initialized
INFO - 2023-04-28 08:44:22 --> Language Class Initialized
INFO - 2023-04-28 08:44:22 --> Loader Class Initialized
INFO - 2023-04-28 08:44:22 --> Controller Class Initialized
DEBUG - 2023-04-28 08:44:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:44:22 --> Database Driver Class Initialized
INFO - 2023-04-28 08:44:22 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:44:22 --> Final output sent to browser
DEBUG - 2023-04-28 08:44:22 --> Total execution time: 0.0197
INFO - 2023-04-28 08:44:22 --> Config Class Initialized
INFO - 2023-04-28 08:44:22 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:44:22 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:44:22 --> Utf8 Class Initialized
INFO - 2023-04-28 08:44:22 --> URI Class Initialized
INFO - 2023-04-28 08:44:22 --> Router Class Initialized
INFO - 2023-04-28 08:44:22 --> Output Class Initialized
INFO - 2023-04-28 08:44:22 --> Security Class Initialized
DEBUG - 2023-04-28 08:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:44:22 --> Input Class Initialized
INFO - 2023-04-28 08:44:22 --> Language Class Initialized
INFO - 2023-04-28 08:44:22 --> Loader Class Initialized
INFO - 2023-04-28 08:44:22 --> Controller Class Initialized
DEBUG - 2023-04-28 08:44:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:44:22 --> Database Driver Class Initialized
INFO - 2023-04-28 08:44:22 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:44:22 --> Final output sent to browser
DEBUG - 2023-04-28 08:44:22 --> Total execution time: 0.0267
INFO - 2023-04-28 08:44:24 --> Config Class Initialized
INFO - 2023-04-28 08:44:24 --> Config Class Initialized
INFO - 2023-04-28 08:44:24 --> Hooks Class Initialized
INFO - 2023-04-28 08:44:24 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:44:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 08:44:24 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:44:24 --> Utf8 Class Initialized
INFO - 2023-04-28 08:44:24 --> Utf8 Class Initialized
INFO - 2023-04-28 08:44:24 --> URI Class Initialized
INFO - 2023-04-28 08:44:24 --> URI Class Initialized
INFO - 2023-04-28 08:44:24 --> Router Class Initialized
INFO - 2023-04-28 08:44:24 --> Router Class Initialized
INFO - 2023-04-28 08:44:24 --> Output Class Initialized
INFO - 2023-04-28 08:44:24 --> Output Class Initialized
INFO - 2023-04-28 08:44:24 --> Security Class Initialized
INFO - 2023-04-28 08:44:24 --> Security Class Initialized
DEBUG - 2023-04-28 08:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 08:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:44:24 --> Input Class Initialized
INFO - 2023-04-28 08:44:24 --> Input Class Initialized
INFO - 2023-04-28 08:44:24 --> Language Class Initialized
INFO - 2023-04-28 08:44:24 --> Language Class Initialized
INFO - 2023-04-28 08:44:24 --> Loader Class Initialized
INFO - 2023-04-28 08:44:24 --> Loader Class Initialized
INFO - 2023-04-28 08:44:24 --> Controller Class Initialized
INFO - 2023-04-28 08:44:24 --> Controller Class Initialized
DEBUG - 2023-04-28 08:44:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 08:44:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:44:24 --> Database Driver Class Initialized
INFO - 2023-04-28 08:44:24 --> Database Driver Class Initialized
INFO - 2023-04-28 08:44:24 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:44:24 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:44:24 --> Final output sent to browser
DEBUG - 2023-04-28 08:44:24 --> Total execution time: 0.0199
INFO - 2023-04-28 08:44:24 --> Config Class Initialized
INFO - 2023-04-28 08:44:24 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:44:24 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:44:24 --> Utf8 Class Initialized
INFO - 2023-04-28 08:44:24 --> URI Class Initialized
INFO - 2023-04-28 08:44:24 --> Router Class Initialized
INFO - 2023-04-28 08:44:24 --> Output Class Initialized
INFO - 2023-04-28 08:44:24 --> Security Class Initialized
DEBUG - 2023-04-28 08:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:44:24 --> Input Class Initialized
INFO - 2023-04-28 08:44:24 --> Language Class Initialized
INFO - 2023-04-28 08:44:24 --> Loader Class Initialized
INFO - 2023-04-28 08:44:24 --> Controller Class Initialized
DEBUG - 2023-04-28 08:44:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:44:24 --> Database Driver Class Initialized
INFO - 2023-04-28 08:44:24 --> Database Driver Class Initialized
INFO - 2023-04-28 08:44:24 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:44:24 --> Model "Login_model" initialized
INFO - 2023-04-28 08:44:24 --> Final output sent to browser
DEBUG - 2023-04-28 08:44:24 --> Total execution time: 0.0213
INFO - 2023-04-28 08:44:24 --> Final output sent to browser
DEBUG - 2023-04-28 08:44:24 --> Total execution time: 0.0852
INFO - 2023-04-28 08:44:24 --> Config Class Initialized
INFO - 2023-04-28 08:44:24 --> Hooks Class Initialized
DEBUG - 2023-04-28 08:44:24 --> UTF-8 Support Enabled
INFO - 2023-04-28 08:44:24 --> Utf8 Class Initialized
INFO - 2023-04-28 08:44:24 --> URI Class Initialized
INFO - 2023-04-28 08:44:24 --> Router Class Initialized
INFO - 2023-04-28 08:44:24 --> Output Class Initialized
INFO - 2023-04-28 08:44:24 --> Security Class Initialized
DEBUG - 2023-04-28 08:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 08:44:24 --> Input Class Initialized
INFO - 2023-04-28 08:44:24 --> Language Class Initialized
INFO - 2023-04-28 08:44:24 --> Loader Class Initialized
INFO - 2023-04-28 08:44:24 --> Controller Class Initialized
DEBUG - 2023-04-28 08:44:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 08:44:24 --> Database Driver Class Initialized
INFO - 2023-04-28 08:44:24 --> Model "Cluster_model" initialized
INFO - 2023-04-28 08:44:24 --> Database Driver Class Initialized
INFO - 2023-04-28 08:44:24 --> Model "Login_model" initialized
INFO - 2023-04-28 08:44:24 --> Final output sent to browser
DEBUG - 2023-04-28 08:44:24 --> Total execution time: 0.0886
INFO - 2023-04-28 09:06:58 --> Config Class Initialized
INFO - 2023-04-28 09:06:58 --> Config Class Initialized
INFO - 2023-04-28 09:06:58 --> Hooks Class Initialized
INFO - 2023-04-28 09:06:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:06:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:06:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:06:58 --> Utf8 Class Initialized
INFO - 2023-04-28 09:06:58 --> Utf8 Class Initialized
INFO - 2023-04-28 09:06:58 --> URI Class Initialized
INFO - 2023-04-28 09:06:58 --> URI Class Initialized
INFO - 2023-04-28 09:06:58 --> Router Class Initialized
INFO - 2023-04-28 09:06:58 --> Router Class Initialized
INFO - 2023-04-28 09:06:58 --> Output Class Initialized
INFO - 2023-04-28 09:06:58 --> Output Class Initialized
INFO - 2023-04-28 09:06:58 --> Security Class Initialized
INFO - 2023-04-28 09:06:58 --> Security Class Initialized
DEBUG - 2023-04-28 09:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 09:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:06:58 --> Input Class Initialized
INFO - 2023-04-28 09:06:58 --> Input Class Initialized
INFO - 2023-04-28 09:06:58 --> Language Class Initialized
INFO - 2023-04-28 09:06:58 --> Language Class Initialized
INFO - 2023-04-28 09:06:58 --> Loader Class Initialized
INFO - 2023-04-28 09:06:58 --> Loader Class Initialized
INFO - 2023-04-28 09:06:58 --> Controller Class Initialized
INFO - 2023-04-28 09:06:58 --> Controller Class Initialized
DEBUG - 2023-04-28 09:06:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 09:06:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:06:58 --> Database Driver Class Initialized
INFO - 2023-04-28 09:06:58 --> Database Driver Class Initialized
INFO - 2023-04-28 09:06:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:06:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:06:58 --> Final output sent to browser
DEBUG - 2023-04-28 09:06:58 --> Total execution time: 0.0994
INFO - 2023-04-28 09:06:58 --> Config Class Initialized
INFO - 2023-04-28 09:06:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:06:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:06:58 --> Utf8 Class Initialized
INFO - 2023-04-28 09:06:58 --> URI Class Initialized
INFO - 2023-04-28 09:06:58 --> Router Class Initialized
INFO - 2023-04-28 09:06:58 --> Output Class Initialized
INFO - 2023-04-28 09:06:58 --> Security Class Initialized
DEBUG - 2023-04-28 09:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:06:58 --> Input Class Initialized
INFO - 2023-04-28 09:06:58 --> Language Class Initialized
INFO - 2023-04-28 09:06:58 --> Loader Class Initialized
INFO - 2023-04-28 09:06:58 --> Controller Class Initialized
DEBUG - 2023-04-28 09:06:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:06:58 --> Database Driver Class Initialized
INFO - 2023-04-28 09:06:58 --> Database Driver Class Initialized
INFO - 2023-04-28 09:06:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:06:58 --> Model "Login_model" initialized
INFO - 2023-04-28 09:06:58 --> Final output sent to browser
DEBUG - 2023-04-28 09:06:58 --> Total execution time: 0.0166
INFO - 2023-04-28 09:06:58 --> Final output sent to browser
DEBUG - 2023-04-28 09:06:58 --> Total execution time: 0.1547
INFO - 2023-04-28 09:06:58 --> Config Class Initialized
INFO - 2023-04-28 09:06:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:06:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:06:58 --> Utf8 Class Initialized
INFO - 2023-04-28 09:06:58 --> URI Class Initialized
INFO - 2023-04-28 09:06:58 --> Router Class Initialized
INFO - 2023-04-28 09:06:58 --> Output Class Initialized
INFO - 2023-04-28 09:06:58 --> Security Class Initialized
DEBUG - 2023-04-28 09:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:06:58 --> Input Class Initialized
INFO - 2023-04-28 09:06:58 --> Language Class Initialized
INFO - 2023-04-28 09:06:58 --> Loader Class Initialized
INFO - 2023-04-28 09:06:58 --> Controller Class Initialized
DEBUG - 2023-04-28 09:06:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:06:58 --> Database Driver Class Initialized
INFO - 2023-04-28 09:06:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:06:58 --> Database Driver Class Initialized
INFO - 2023-04-28 09:06:58 --> Model "Login_model" initialized
INFO - 2023-04-28 09:06:58 --> Final output sent to browser
DEBUG - 2023-04-28 09:06:58 --> Total execution time: 0.1036
INFO - 2023-04-28 09:07:05 --> Config Class Initialized
INFO - 2023-04-28 09:07:05 --> Config Class Initialized
INFO - 2023-04-28 09:07:05 --> Hooks Class Initialized
INFO - 2023-04-28 09:07:05 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:07:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:07:05 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:07:05 --> Utf8 Class Initialized
INFO - 2023-04-28 09:07:05 --> Utf8 Class Initialized
INFO - 2023-04-28 09:07:05 --> URI Class Initialized
INFO - 2023-04-28 09:07:05 --> URI Class Initialized
INFO - 2023-04-28 09:07:05 --> Router Class Initialized
INFO - 2023-04-28 09:07:05 --> Router Class Initialized
INFO - 2023-04-28 09:07:05 --> Output Class Initialized
INFO - 2023-04-28 09:07:05 --> Output Class Initialized
INFO - 2023-04-28 09:07:05 --> Security Class Initialized
INFO - 2023-04-28 09:07:05 --> Security Class Initialized
DEBUG - 2023-04-28 09:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 09:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:07:05 --> Input Class Initialized
INFO - 2023-04-28 09:07:05 --> Input Class Initialized
INFO - 2023-04-28 09:07:05 --> Language Class Initialized
INFO - 2023-04-28 09:07:05 --> Language Class Initialized
INFO - 2023-04-28 09:07:05 --> Loader Class Initialized
INFO - 2023-04-28 09:07:05 --> Loader Class Initialized
INFO - 2023-04-28 09:07:05 --> Controller Class Initialized
INFO - 2023-04-28 09:07:05 --> Controller Class Initialized
DEBUG - 2023-04-28 09:07:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 09:07:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:07:05 --> Final output sent to browser
DEBUG - 2023-04-28 09:07:05 --> Total execution time: 0.0049
INFO - 2023-04-28 09:07:05 --> Database Driver Class Initialized
INFO - 2023-04-28 09:07:05 --> Config Class Initialized
INFO - 2023-04-28 09:07:05 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:07:05 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:07:05 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:07:05 --> Utf8 Class Initialized
INFO - 2023-04-28 09:07:05 --> URI Class Initialized
INFO - 2023-04-28 09:07:05 --> Router Class Initialized
INFO - 2023-04-28 09:07:05 --> Output Class Initialized
INFO - 2023-04-28 09:07:05 --> Security Class Initialized
DEBUG - 2023-04-28 09:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:07:05 --> Input Class Initialized
INFO - 2023-04-28 09:07:05 --> Language Class Initialized
INFO - 2023-04-28 09:07:05 --> Loader Class Initialized
INFO - 2023-04-28 09:07:05 --> Controller Class Initialized
DEBUG - 2023-04-28 09:07:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:07:05 --> Database Driver Class Initialized
INFO - 2023-04-28 09:07:05 --> Final output sent to browser
DEBUG - 2023-04-28 09:07:05 --> Total execution time: 0.0527
INFO - 2023-04-28 09:07:05 --> Config Class Initialized
INFO - 2023-04-28 09:07:05 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:07:05 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:07:05 --> Utf8 Class Initialized
INFO - 2023-04-28 09:07:05 --> URI Class Initialized
INFO - 2023-04-28 09:07:05 --> Router Class Initialized
INFO - 2023-04-28 09:07:05 --> Output Class Initialized
INFO - 2023-04-28 09:07:05 --> Security Class Initialized
DEBUG - 2023-04-28 09:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:07:05 --> Input Class Initialized
INFO - 2023-04-28 09:07:05 --> Language Class Initialized
INFO - 2023-04-28 09:07:05 --> Loader Class Initialized
INFO - 2023-04-28 09:07:05 --> Controller Class Initialized
DEBUG - 2023-04-28 09:07:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:07:05 --> Database Driver Class Initialized
INFO - 2023-04-28 09:07:05 --> Model "Login_model" initialized
INFO - 2023-04-28 09:07:05 --> Database Driver Class Initialized
INFO - 2023-04-28 09:07:05 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:07:05 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:07:05 --> Final output sent to browser
INFO - 2023-04-28 09:07:05 --> Final output sent to browser
DEBUG - 2023-04-28 09:07:05 --> Total execution time: 0.0647
DEBUG - 2023-04-28 09:07:05 --> Total execution time: 0.0160
INFO - 2023-04-28 09:07:05 --> Config Class Initialized
INFO - 2023-04-28 09:07:05 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:07:05 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:07:05 --> Utf8 Class Initialized
INFO - 2023-04-28 09:07:05 --> URI Class Initialized
INFO - 2023-04-28 09:07:05 --> Router Class Initialized
INFO - 2023-04-28 09:07:05 --> Output Class Initialized
INFO - 2023-04-28 09:07:05 --> Security Class Initialized
DEBUG - 2023-04-28 09:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:07:05 --> Input Class Initialized
INFO - 2023-04-28 09:07:05 --> Language Class Initialized
INFO - 2023-04-28 09:07:05 --> Loader Class Initialized
INFO - 2023-04-28 09:07:05 --> Controller Class Initialized
DEBUG - 2023-04-28 09:07:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:07:05 --> Database Driver Class Initialized
INFO - 2023-04-28 09:07:05 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:07:05 --> Final output sent to browser
DEBUG - 2023-04-28 09:07:05 --> Total execution time: 0.0193
INFO - 2023-04-28 09:07:05 --> Config Class Initialized
INFO - 2023-04-28 09:07:05 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:07:05 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:07:05 --> Utf8 Class Initialized
INFO - 2023-04-28 09:07:05 --> URI Class Initialized
INFO - 2023-04-28 09:07:05 --> Router Class Initialized
INFO - 2023-04-28 09:07:05 --> Output Class Initialized
INFO - 2023-04-28 09:07:05 --> Security Class Initialized
DEBUG - 2023-04-28 09:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:07:05 --> Input Class Initialized
INFO - 2023-04-28 09:07:05 --> Language Class Initialized
INFO - 2023-04-28 09:07:05 --> Loader Class Initialized
INFO - 2023-04-28 09:07:05 --> Controller Class Initialized
DEBUG - 2023-04-28 09:07:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:07:05 --> Database Driver Class Initialized
INFO - 2023-04-28 09:07:05 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:07:05 --> Final output sent to browser
DEBUG - 2023-04-28 09:07:05 --> Total execution time: 0.0534
INFO - 2023-04-28 09:07:08 --> Config Class Initialized
INFO - 2023-04-28 09:07:08 --> Config Class Initialized
INFO - 2023-04-28 09:07:08 --> Hooks Class Initialized
INFO - 2023-04-28 09:07:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:07:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:07:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:07:08 --> Utf8 Class Initialized
INFO - 2023-04-28 09:07:08 --> Utf8 Class Initialized
INFO - 2023-04-28 09:07:08 --> URI Class Initialized
INFO - 2023-04-28 09:07:08 --> URI Class Initialized
INFO - 2023-04-28 09:07:08 --> Router Class Initialized
INFO - 2023-04-28 09:07:08 --> Output Class Initialized
INFO - 2023-04-28 09:07:08 --> Security Class Initialized
DEBUG - 2023-04-28 09:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:07:08 --> Router Class Initialized
INFO - 2023-04-28 09:07:08 --> Input Class Initialized
INFO - 2023-04-28 09:07:08 --> Output Class Initialized
INFO - 2023-04-28 09:07:08 --> Language Class Initialized
INFO - 2023-04-28 09:07:08 --> Security Class Initialized
DEBUG - 2023-04-28 09:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:07:08 --> Loader Class Initialized
INFO - 2023-04-28 09:07:08 --> Input Class Initialized
INFO - 2023-04-28 09:07:08 --> Language Class Initialized
INFO - 2023-04-28 09:07:08 --> Controller Class Initialized
DEBUG - 2023-04-28 09:07:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:07:08 --> Loader Class Initialized
INFO - 2023-04-28 09:07:08 --> Controller Class Initialized
INFO - 2023-04-28 09:07:08 --> Database Driver Class Initialized
DEBUG - 2023-04-28 09:07:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:07:08 --> Database Driver Class Initialized
INFO - 2023-04-28 09:07:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:07:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:07:08 --> Final output sent to browser
DEBUG - 2023-04-28 09:07:08 --> Total execution time: 0.0250
INFO - 2023-04-28 09:07:08 --> Config Class Initialized
INFO - 2023-04-28 09:07:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:07:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:07:08 --> Utf8 Class Initialized
INFO - 2023-04-28 09:07:08 --> URI Class Initialized
INFO - 2023-04-28 09:07:08 --> Router Class Initialized
INFO - 2023-04-28 09:07:08 --> Output Class Initialized
INFO - 2023-04-28 09:07:08 --> Security Class Initialized
DEBUG - 2023-04-28 09:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:07:08 --> Input Class Initialized
INFO - 2023-04-28 09:07:08 --> Language Class Initialized
INFO - 2023-04-28 09:07:08 --> Loader Class Initialized
INFO - 2023-04-28 09:07:08 --> Controller Class Initialized
DEBUG - 2023-04-28 09:07:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:07:08 --> Database Driver Class Initialized
INFO - 2023-04-28 09:07:08 --> Database Driver Class Initialized
INFO - 2023-04-28 09:07:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:07:08 --> Model "Login_model" initialized
INFO - 2023-04-28 09:07:08 --> Final output sent to browser
DEBUG - 2023-04-28 09:07:08 --> Total execution time: 0.0123
INFO - 2023-04-28 09:07:08 --> Final output sent to browser
DEBUG - 2023-04-28 09:07:08 --> Total execution time: 0.0748
INFO - 2023-04-28 09:07:08 --> Config Class Initialized
INFO - 2023-04-28 09:07:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:07:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:07:08 --> Utf8 Class Initialized
INFO - 2023-04-28 09:07:08 --> URI Class Initialized
INFO - 2023-04-28 09:07:08 --> Router Class Initialized
INFO - 2023-04-28 09:07:08 --> Output Class Initialized
INFO - 2023-04-28 09:07:08 --> Security Class Initialized
DEBUG - 2023-04-28 09:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:07:08 --> Input Class Initialized
INFO - 2023-04-28 09:07:08 --> Language Class Initialized
INFO - 2023-04-28 09:07:08 --> Loader Class Initialized
INFO - 2023-04-28 09:07:08 --> Controller Class Initialized
DEBUG - 2023-04-28 09:07:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:07:08 --> Database Driver Class Initialized
INFO - 2023-04-28 09:07:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:07:08 --> Database Driver Class Initialized
INFO - 2023-04-28 09:07:08 --> Model "Login_model" initialized
INFO - 2023-04-28 09:07:08 --> Final output sent to browser
DEBUG - 2023-04-28 09:07:08 --> Total execution time: 0.0635
INFO - 2023-04-28 09:08:06 --> Config Class Initialized
INFO - 2023-04-28 09:08:06 --> Config Class Initialized
INFO - 2023-04-28 09:08:06 --> Hooks Class Initialized
INFO - 2023-04-28 09:08:06 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:08:06 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:08:06 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:08:06 --> Utf8 Class Initialized
INFO - 2023-04-28 09:08:06 --> Utf8 Class Initialized
INFO - 2023-04-28 09:08:06 --> URI Class Initialized
INFO - 2023-04-28 09:08:06 --> URI Class Initialized
INFO - 2023-04-28 09:08:06 --> Router Class Initialized
INFO - 2023-04-28 09:08:06 --> Router Class Initialized
INFO - 2023-04-28 09:08:06 --> Output Class Initialized
INFO - 2023-04-28 09:08:06 --> Output Class Initialized
INFO - 2023-04-28 09:08:06 --> Security Class Initialized
INFO - 2023-04-28 09:08:06 --> Security Class Initialized
DEBUG - 2023-04-28 09:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 09:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:08:06 --> Input Class Initialized
INFO - 2023-04-28 09:08:06 --> Input Class Initialized
INFO - 2023-04-28 09:08:06 --> Language Class Initialized
INFO - 2023-04-28 09:08:06 --> Language Class Initialized
INFO - 2023-04-28 09:08:06 --> Loader Class Initialized
INFO - 2023-04-28 09:08:06 --> Loader Class Initialized
INFO - 2023-04-28 09:08:06 --> Controller Class Initialized
INFO - 2023-04-28 09:08:06 --> Controller Class Initialized
DEBUG - 2023-04-28 09:08:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 09:08:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:08:06 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:06 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:06 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:08:06 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:08:06 --> Final output sent to browser
DEBUG - 2023-04-28 09:08:06 --> Total execution time: 0.0148
INFO - 2023-04-28 09:08:06 --> Config Class Initialized
INFO - 2023-04-28 09:08:06 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:08:06 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:08:06 --> Utf8 Class Initialized
INFO - 2023-04-28 09:08:06 --> URI Class Initialized
INFO - 2023-04-28 09:08:06 --> Router Class Initialized
INFO - 2023-04-28 09:08:06 --> Output Class Initialized
INFO - 2023-04-28 09:08:06 --> Security Class Initialized
DEBUG - 2023-04-28 09:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:08:06 --> Input Class Initialized
INFO - 2023-04-28 09:08:06 --> Language Class Initialized
INFO - 2023-04-28 09:08:06 --> Loader Class Initialized
INFO - 2023-04-28 09:08:06 --> Controller Class Initialized
DEBUG - 2023-04-28 09:08:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:08:06 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:06 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:06 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:08:06 --> Model "Login_model" initialized
INFO - 2023-04-28 09:08:06 --> Final output sent to browser
DEBUG - 2023-04-28 09:08:06 --> Total execution time: 0.0144
INFO - 2023-04-28 09:08:06 --> Final output sent to browser
DEBUG - 2023-04-28 09:08:06 --> Total execution time: 0.0668
INFO - 2023-04-28 09:08:06 --> Config Class Initialized
INFO - 2023-04-28 09:08:06 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:08:06 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:08:06 --> Utf8 Class Initialized
INFO - 2023-04-28 09:08:06 --> URI Class Initialized
INFO - 2023-04-28 09:08:06 --> Router Class Initialized
INFO - 2023-04-28 09:08:06 --> Output Class Initialized
INFO - 2023-04-28 09:08:06 --> Security Class Initialized
DEBUG - 2023-04-28 09:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:08:06 --> Input Class Initialized
INFO - 2023-04-28 09:08:06 --> Language Class Initialized
INFO - 2023-04-28 09:08:06 --> Loader Class Initialized
INFO - 2023-04-28 09:08:06 --> Controller Class Initialized
DEBUG - 2023-04-28 09:08:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:08:06 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:06 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:08:06 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:06 --> Model "Login_model" initialized
INFO - 2023-04-28 09:08:06 --> Final output sent to browser
DEBUG - 2023-04-28 09:08:06 --> Total execution time: 0.3883
INFO - 2023-04-28 09:08:15 --> Config Class Initialized
INFO - 2023-04-28 09:08:15 --> Config Class Initialized
INFO - 2023-04-28 09:08:15 --> Hooks Class Initialized
INFO - 2023-04-28 09:08:15 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:08:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:08:15 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:08:15 --> Utf8 Class Initialized
INFO - 2023-04-28 09:08:15 --> Utf8 Class Initialized
INFO - 2023-04-28 09:08:15 --> URI Class Initialized
INFO - 2023-04-28 09:08:15 --> URI Class Initialized
INFO - 2023-04-28 09:08:15 --> Router Class Initialized
INFO - 2023-04-28 09:08:15 --> Router Class Initialized
INFO - 2023-04-28 09:08:15 --> Output Class Initialized
INFO - 2023-04-28 09:08:15 --> Output Class Initialized
INFO - 2023-04-28 09:08:15 --> Security Class Initialized
INFO - 2023-04-28 09:08:15 --> Security Class Initialized
DEBUG - 2023-04-28 09:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 09:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:08:15 --> Input Class Initialized
INFO - 2023-04-28 09:08:15 --> Input Class Initialized
INFO - 2023-04-28 09:08:15 --> Language Class Initialized
INFO - 2023-04-28 09:08:15 --> Language Class Initialized
INFO - 2023-04-28 09:08:15 --> Loader Class Initialized
INFO - 2023-04-28 09:08:15 --> Loader Class Initialized
INFO - 2023-04-28 09:08:15 --> Controller Class Initialized
INFO - 2023-04-28 09:08:15 --> Controller Class Initialized
DEBUG - 2023-04-28 09:08:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 09:08:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:08:15 --> Final output sent to browser
INFO - 2023-04-28 09:08:15 --> Database Driver Class Initialized
DEBUG - 2023-04-28 09:08:15 --> Total execution time: 0.0047
INFO - 2023-04-28 09:08:15 --> Config Class Initialized
INFO - 2023-04-28 09:08:15 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:08:15 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:08:15 --> Utf8 Class Initialized
INFO - 2023-04-28 09:08:15 --> URI Class Initialized
INFO - 2023-04-28 09:08:15 --> Router Class Initialized
INFO - 2023-04-28 09:08:15 --> Output Class Initialized
INFO - 2023-04-28 09:08:15 --> Security Class Initialized
DEBUG - 2023-04-28 09:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:08:15 --> Input Class Initialized
INFO - 2023-04-28 09:08:15 --> Language Class Initialized
INFO - 2023-04-28 09:08:15 --> Loader Class Initialized
INFO - 2023-04-28 09:08:15 --> Controller Class Initialized
DEBUG - 2023-04-28 09:08:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:08:15 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:15 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:08:15 --> Final output sent to browser
DEBUG - 2023-04-28 09:08:15 --> Total execution time: 0.0513
INFO - 2023-04-28 09:08:15 --> Config Class Initialized
INFO - 2023-04-28 09:08:15 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:08:15 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:08:15 --> Utf8 Class Initialized
INFO - 2023-04-28 09:08:15 --> URI Class Initialized
INFO - 2023-04-28 09:08:15 --> Router Class Initialized
INFO - 2023-04-28 09:08:15 --> Output Class Initialized
INFO - 2023-04-28 09:08:15 --> Model "Login_model" initialized
INFO - 2023-04-28 09:08:15 --> Security Class Initialized
DEBUG - 2023-04-28 09:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:08:15 --> Input Class Initialized
INFO - 2023-04-28 09:08:15 --> Language Class Initialized
INFO - 2023-04-28 09:08:15 --> Loader Class Initialized
INFO - 2023-04-28 09:08:15 --> Controller Class Initialized
DEBUG - 2023-04-28 09:08:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:08:15 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:15 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:15 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:08:15 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:08:15 --> Final output sent to browser
DEBUG - 2023-04-28 09:08:15 --> Total execution time: 0.0617
INFO - 2023-04-28 09:08:15 --> Final output sent to browser
DEBUG - 2023-04-28 09:08:15 --> Total execution time: 0.0158
INFO - 2023-04-28 09:08:17 --> Config Class Initialized
INFO - 2023-04-28 09:08:17 --> Config Class Initialized
INFO - 2023-04-28 09:08:17 --> Hooks Class Initialized
INFO - 2023-04-28 09:08:17 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:08:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:08:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:08:17 --> Utf8 Class Initialized
INFO - 2023-04-28 09:08:17 --> Utf8 Class Initialized
INFO - 2023-04-28 09:08:17 --> URI Class Initialized
INFO - 2023-04-28 09:08:17 --> URI Class Initialized
INFO - 2023-04-28 09:08:17 --> Router Class Initialized
INFO - 2023-04-28 09:08:17 --> Router Class Initialized
INFO - 2023-04-28 09:08:17 --> Output Class Initialized
INFO - 2023-04-28 09:08:17 --> Output Class Initialized
INFO - 2023-04-28 09:08:17 --> Security Class Initialized
INFO - 2023-04-28 09:08:17 --> Security Class Initialized
DEBUG - 2023-04-28 09:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 09:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:08:17 --> Input Class Initialized
INFO - 2023-04-28 09:08:17 --> Input Class Initialized
INFO - 2023-04-28 09:08:17 --> Language Class Initialized
INFO - 2023-04-28 09:08:17 --> Language Class Initialized
INFO - 2023-04-28 09:08:17 --> Loader Class Initialized
INFO - 2023-04-28 09:08:17 --> Loader Class Initialized
INFO - 2023-04-28 09:08:17 --> Controller Class Initialized
INFO - 2023-04-28 09:08:17 --> Controller Class Initialized
DEBUG - 2023-04-28 09:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 09:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:08:17 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:17 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:08:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:08:17 --> Final output sent to browser
DEBUG - 2023-04-28 09:08:17 --> Total execution time: 0.0147
INFO - 2023-04-28 09:08:17 --> Config Class Initialized
INFO - 2023-04-28 09:08:17 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:08:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:08:17 --> Utf8 Class Initialized
INFO - 2023-04-28 09:08:17 --> URI Class Initialized
INFO - 2023-04-28 09:08:17 --> Router Class Initialized
INFO - 2023-04-28 09:08:17 --> Output Class Initialized
INFO - 2023-04-28 09:08:17 --> Security Class Initialized
DEBUG - 2023-04-28 09:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:08:17 --> Input Class Initialized
INFO - 2023-04-28 09:08:17 --> Language Class Initialized
INFO - 2023-04-28 09:08:17 --> Loader Class Initialized
INFO - 2023-04-28 09:08:17 --> Controller Class Initialized
DEBUG - 2023-04-28 09:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:08:17 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:17 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:08:17 --> Final output sent to browser
DEBUG - 2023-04-28 09:08:17 --> Total execution time: 0.0110
INFO - 2023-04-28 09:08:17 --> Model "Login_model" initialized
INFO - 2023-04-28 09:08:17 --> Final output sent to browser
DEBUG - 2023-04-28 09:08:17 --> Total execution time: 0.1099
INFO - 2023-04-28 09:08:17 --> Config Class Initialized
INFO - 2023-04-28 09:08:17 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:08:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:08:17 --> Utf8 Class Initialized
INFO - 2023-04-28 09:08:17 --> URI Class Initialized
INFO - 2023-04-28 09:08:17 --> Router Class Initialized
INFO - 2023-04-28 09:08:17 --> Output Class Initialized
INFO - 2023-04-28 09:08:17 --> Security Class Initialized
DEBUG - 2023-04-28 09:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:08:17 --> Input Class Initialized
INFO - 2023-04-28 09:08:17 --> Language Class Initialized
INFO - 2023-04-28 09:08:17 --> Loader Class Initialized
INFO - 2023-04-28 09:08:17 --> Controller Class Initialized
DEBUG - 2023-04-28 09:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:08:17 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:08:17 --> Database Driver Class Initialized
INFO - 2023-04-28 09:08:17 --> Model "Login_model" initialized
INFO - 2023-04-28 09:08:18 --> Final output sent to browser
DEBUG - 2023-04-28 09:08:18 --> Total execution time: 0.0668
INFO - 2023-04-28 09:09:56 --> Config Class Initialized
INFO - 2023-04-28 09:09:56 --> Config Class Initialized
INFO - 2023-04-28 09:09:56 --> Hooks Class Initialized
INFO - 2023-04-28 09:09:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:09:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:09:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:09:56 --> Utf8 Class Initialized
INFO - 2023-04-28 09:09:56 --> Utf8 Class Initialized
INFO - 2023-04-28 09:09:56 --> URI Class Initialized
INFO - 2023-04-28 09:09:56 --> URI Class Initialized
INFO - 2023-04-28 09:09:56 --> Router Class Initialized
INFO - 2023-04-28 09:09:56 --> Router Class Initialized
INFO - 2023-04-28 09:09:56 --> Output Class Initialized
INFO - 2023-04-28 09:09:56 --> Output Class Initialized
INFO - 2023-04-28 09:09:56 --> Security Class Initialized
INFO - 2023-04-28 09:09:56 --> Security Class Initialized
DEBUG - 2023-04-28 09:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 09:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:09:56 --> Input Class Initialized
INFO - 2023-04-28 09:09:56 --> Input Class Initialized
INFO - 2023-04-28 09:09:56 --> Language Class Initialized
INFO - 2023-04-28 09:09:56 --> Language Class Initialized
INFO - 2023-04-28 09:09:56 --> Loader Class Initialized
INFO - 2023-04-28 09:09:56 --> Loader Class Initialized
INFO - 2023-04-28 09:09:56 --> Controller Class Initialized
INFO - 2023-04-28 09:09:56 --> Controller Class Initialized
DEBUG - 2023-04-28 09:09:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 09:09:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:09:56 --> Final output sent to browser
DEBUG - 2023-04-28 09:09:56 --> Total execution time: 0.0058
INFO - 2023-04-28 09:09:56 --> Database Driver Class Initialized
INFO - 2023-04-28 09:09:56 --> Config Class Initialized
INFO - 2023-04-28 09:09:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:09:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:09:56 --> Utf8 Class Initialized
INFO - 2023-04-28 09:09:56 --> URI Class Initialized
INFO - 2023-04-28 09:09:56 --> Router Class Initialized
INFO - 2023-04-28 09:09:56 --> Output Class Initialized
INFO - 2023-04-28 09:09:56 --> Security Class Initialized
DEBUG - 2023-04-28 09:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:09:56 --> Input Class Initialized
INFO - 2023-04-28 09:09:56 --> Language Class Initialized
INFO - 2023-04-28 09:09:56 --> Loader Class Initialized
INFO - 2023-04-28 09:09:56 --> Controller Class Initialized
DEBUG - 2023-04-28 09:09:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:09:56 --> Database Driver Class Initialized
INFO - 2023-04-28 09:09:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:09:56 --> Model "Login_model" initialized
INFO - 2023-04-28 09:09:56 --> Final output sent to browser
DEBUG - 2023-04-28 09:09:56 --> Total execution time: 0.0219
INFO - 2023-04-28 09:09:56 --> Database Driver Class Initialized
INFO - 2023-04-28 09:09:56 --> Config Class Initialized
INFO - 2023-04-28 09:09:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:09:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:09:56 --> Utf8 Class Initialized
INFO - 2023-04-28 09:09:56 --> URI Class Initialized
INFO - 2023-04-28 09:09:56 --> Router Class Initialized
INFO - 2023-04-28 09:09:56 --> Output Class Initialized
INFO - 2023-04-28 09:09:56 --> Security Class Initialized
DEBUG - 2023-04-28 09:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:09:56 --> Input Class Initialized
INFO - 2023-04-28 09:09:56 --> Language Class Initialized
INFO - 2023-04-28 09:09:56 --> Loader Class Initialized
INFO - 2023-04-28 09:09:56 --> Controller Class Initialized
DEBUG - 2023-04-28 09:09:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:09:56 --> Database Driver Class Initialized
INFO - 2023-04-28 09:09:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:09:56 --> Final output sent to browser
DEBUG - 2023-04-28 09:09:56 --> Total execution time: 0.0271
INFO - 2023-04-28 09:09:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:09:57 --> Final output sent to browser
DEBUG - 2023-04-28 09:09:57 --> Total execution time: 0.0558
INFO - 2023-04-28 09:09:59 --> Config Class Initialized
INFO - 2023-04-28 09:09:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:09:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:09:59 --> Utf8 Class Initialized
INFO - 2023-04-28 09:09:59 --> URI Class Initialized
INFO - 2023-04-28 09:09:59 --> Router Class Initialized
INFO - 2023-04-28 09:09:59 --> Output Class Initialized
INFO - 2023-04-28 09:09:59 --> Security Class Initialized
DEBUG - 2023-04-28 09:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:09:59 --> Input Class Initialized
INFO - 2023-04-28 09:09:59 --> Language Class Initialized
INFO - 2023-04-28 09:09:59 --> Loader Class Initialized
INFO - 2023-04-28 09:09:59 --> Controller Class Initialized
DEBUG - 2023-04-28 09:09:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:09:59 --> Database Driver Class Initialized
INFO - 2023-04-28 09:09:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:09:59 --> Final output sent to browser
DEBUG - 2023-04-28 09:09:59 --> Total execution time: 0.0821
INFO - 2023-04-28 09:09:59 --> Config Class Initialized
INFO - 2023-04-28 09:09:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:09:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:09:59 --> Utf8 Class Initialized
INFO - 2023-04-28 09:09:59 --> URI Class Initialized
INFO - 2023-04-28 09:09:59 --> Router Class Initialized
INFO - 2023-04-28 09:09:59 --> Output Class Initialized
INFO - 2023-04-28 09:09:59 --> Security Class Initialized
DEBUG - 2023-04-28 09:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:09:59 --> Input Class Initialized
INFO - 2023-04-28 09:09:59 --> Language Class Initialized
INFO - 2023-04-28 09:09:59 --> Loader Class Initialized
INFO - 2023-04-28 09:09:59 --> Controller Class Initialized
DEBUG - 2023-04-28 09:09:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:09:59 --> Database Driver Class Initialized
INFO - 2023-04-28 09:09:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:09:59 --> Final output sent to browser
DEBUG - 2023-04-28 09:09:59 --> Total execution time: 0.0152
INFO - 2023-04-28 09:13:20 --> Config Class Initialized
INFO - 2023-04-28 09:13:20 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:13:20 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:13:20 --> Utf8 Class Initialized
INFO - 2023-04-28 09:13:20 --> URI Class Initialized
INFO - 2023-04-28 09:13:20 --> Router Class Initialized
INFO - 2023-04-28 09:13:20 --> Output Class Initialized
INFO - 2023-04-28 09:13:20 --> Security Class Initialized
DEBUG - 2023-04-28 09:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:13:20 --> Input Class Initialized
INFO - 2023-04-28 09:13:20 --> Language Class Initialized
INFO - 2023-04-28 09:13:20 --> Loader Class Initialized
INFO - 2023-04-28 09:13:20 --> Controller Class Initialized
DEBUG - 2023-04-28 09:13:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:13:20 --> Database Driver Class Initialized
INFO - 2023-04-28 09:13:20 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:13:20 --> Final output sent to browser
DEBUG - 2023-04-28 09:13:20 --> Total execution time: 0.0490
INFO - 2023-04-28 09:13:20 --> Config Class Initialized
INFO - 2023-04-28 09:13:20 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:13:20 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:13:20 --> Utf8 Class Initialized
INFO - 2023-04-28 09:13:20 --> URI Class Initialized
INFO - 2023-04-28 09:13:20 --> Router Class Initialized
INFO - 2023-04-28 09:13:20 --> Output Class Initialized
INFO - 2023-04-28 09:13:20 --> Security Class Initialized
DEBUG - 2023-04-28 09:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:13:20 --> Input Class Initialized
INFO - 2023-04-28 09:13:20 --> Language Class Initialized
INFO - 2023-04-28 09:13:20 --> Loader Class Initialized
INFO - 2023-04-28 09:13:20 --> Controller Class Initialized
DEBUG - 2023-04-28 09:13:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:13:20 --> Database Driver Class Initialized
INFO - 2023-04-28 09:13:20 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:13:20 --> Final output sent to browser
DEBUG - 2023-04-28 09:13:20 --> Total execution time: 0.0159
INFO - 2023-04-28 09:14:18 --> Config Class Initialized
INFO - 2023-04-28 09:14:18 --> Config Class Initialized
INFO - 2023-04-28 09:14:18 --> Hooks Class Initialized
INFO - 2023-04-28 09:14:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:14:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:14:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:14:18 --> Utf8 Class Initialized
INFO - 2023-04-28 09:14:18 --> Utf8 Class Initialized
INFO - 2023-04-28 09:14:18 --> URI Class Initialized
INFO - 2023-04-28 09:14:18 --> URI Class Initialized
INFO - 2023-04-28 09:14:18 --> Router Class Initialized
INFO - 2023-04-28 09:14:18 --> Router Class Initialized
INFO - 2023-04-28 09:14:18 --> Output Class Initialized
INFO - 2023-04-28 09:14:18 --> Output Class Initialized
INFO - 2023-04-28 09:14:18 --> Security Class Initialized
INFO - 2023-04-28 09:14:18 --> Security Class Initialized
DEBUG - 2023-04-28 09:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 09:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:14:18 --> Input Class Initialized
INFO - 2023-04-28 09:14:18 --> Input Class Initialized
INFO - 2023-04-28 09:14:18 --> Language Class Initialized
INFO - 2023-04-28 09:14:18 --> Language Class Initialized
INFO - 2023-04-28 09:14:18 --> Loader Class Initialized
INFO - 2023-04-28 09:14:18 --> Loader Class Initialized
INFO - 2023-04-28 09:14:18 --> Controller Class Initialized
INFO - 2023-04-28 09:14:18 --> Controller Class Initialized
DEBUG - 2023-04-28 09:14:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 09:14:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:14:18 --> Database Driver Class Initialized
INFO - 2023-04-28 09:14:18 --> Database Driver Class Initialized
INFO - 2023-04-28 09:14:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:14:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:14:18 --> Final output sent to browser
DEBUG - 2023-04-28 09:14:19 --> Total execution time: 0.0207
INFO - 2023-04-28 09:14:19 --> Config Class Initialized
INFO - 2023-04-28 09:14:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:14:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:14:19 --> Utf8 Class Initialized
INFO - 2023-04-28 09:14:19 --> URI Class Initialized
INFO - 2023-04-28 09:14:19 --> Router Class Initialized
INFO - 2023-04-28 09:14:19 --> Output Class Initialized
INFO - 2023-04-28 09:14:19 --> Security Class Initialized
DEBUG - 2023-04-28 09:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:14:19 --> Input Class Initialized
INFO - 2023-04-28 09:14:19 --> Language Class Initialized
INFO - 2023-04-28 09:14:19 --> Loader Class Initialized
INFO - 2023-04-28 09:14:19 --> Controller Class Initialized
DEBUG - 2023-04-28 09:14:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:14:19 --> Database Driver Class Initialized
INFO - 2023-04-28 09:14:19 --> Database Driver Class Initialized
INFO - 2023-04-28 09:14:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:14:19 --> Final output sent to browser
DEBUG - 2023-04-28 09:14:19 --> Total execution time: 0.0115
INFO - 2023-04-28 09:14:19 --> Model "Login_model" initialized
INFO - 2023-04-28 09:14:19 --> Final output sent to browser
DEBUG - 2023-04-28 09:14:19 --> Total execution time: 0.1134
INFO - 2023-04-28 09:14:19 --> Config Class Initialized
INFO - 2023-04-28 09:14:19 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:14:19 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:14:19 --> Utf8 Class Initialized
INFO - 2023-04-28 09:14:19 --> URI Class Initialized
INFO - 2023-04-28 09:14:19 --> Router Class Initialized
INFO - 2023-04-28 09:14:19 --> Output Class Initialized
INFO - 2023-04-28 09:14:19 --> Security Class Initialized
DEBUG - 2023-04-28 09:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:14:19 --> Input Class Initialized
INFO - 2023-04-28 09:14:19 --> Language Class Initialized
INFO - 2023-04-28 09:14:19 --> Loader Class Initialized
INFO - 2023-04-28 09:14:19 --> Controller Class Initialized
DEBUG - 2023-04-28 09:14:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:14:19 --> Database Driver Class Initialized
INFO - 2023-04-28 09:14:19 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:14:19 --> Database Driver Class Initialized
INFO - 2023-04-28 09:14:19 --> Model "Login_model" initialized
INFO - 2023-04-28 09:14:19 --> Final output sent to browser
DEBUG - 2023-04-28 09:14:19 --> Total execution time: 0.0591
INFO - 2023-04-28 09:14:20 --> Config Class Initialized
INFO - 2023-04-28 09:14:20 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:14:20 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:14:20 --> Utf8 Class Initialized
INFO - 2023-04-28 09:14:20 --> URI Class Initialized
INFO - 2023-04-28 09:14:20 --> Router Class Initialized
INFO - 2023-04-28 09:14:20 --> Output Class Initialized
INFO - 2023-04-28 09:14:20 --> Security Class Initialized
DEBUG - 2023-04-28 09:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:14:20 --> Input Class Initialized
INFO - 2023-04-28 09:14:20 --> Language Class Initialized
INFO - 2023-04-28 09:14:20 --> Loader Class Initialized
INFO - 2023-04-28 09:14:20 --> Controller Class Initialized
DEBUG - 2023-04-28 09:14:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:14:20 --> Database Driver Class Initialized
INFO - 2023-04-28 09:14:20 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:14:20 --> Final output sent to browser
DEBUG - 2023-04-28 09:14:20 --> Total execution time: 0.0144
INFO - 2023-04-28 09:14:20 --> Config Class Initialized
INFO - 2023-04-28 09:14:20 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:14:20 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:14:20 --> Utf8 Class Initialized
INFO - 2023-04-28 09:14:20 --> URI Class Initialized
INFO - 2023-04-28 09:14:20 --> Router Class Initialized
INFO - 2023-04-28 09:14:20 --> Output Class Initialized
INFO - 2023-04-28 09:14:20 --> Security Class Initialized
DEBUG - 2023-04-28 09:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:14:20 --> Input Class Initialized
INFO - 2023-04-28 09:14:20 --> Language Class Initialized
INFO - 2023-04-28 09:14:20 --> Loader Class Initialized
INFO - 2023-04-28 09:14:20 --> Controller Class Initialized
DEBUG - 2023-04-28 09:14:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:14:20 --> Database Driver Class Initialized
INFO - 2023-04-28 09:14:20 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:14:20 --> Final output sent to browser
DEBUG - 2023-04-28 09:14:20 --> Total execution time: 0.0554
INFO - 2023-04-28 09:14:20 --> Config Class Initialized
INFO - 2023-04-28 09:14:20 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:14:20 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:14:20 --> Utf8 Class Initialized
INFO - 2023-04-28 09:14:20 --> URI Class Initialized
INFO - 2023-04-28 09:14:20 --> Router Class Initialized
INFO - 2023-04-28 09:14:20 --> Output Class Initialized
INFO - 2023-04-28 09:14:20 --> Security Class Initialized
DEBUG - 2023-04-28 09:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:14:20 --> Input Class Initialized
INFO - 2023-04-28 09:14:20 --> Language Class Initialized
INFO - 2023-04-28 09:14:20 --> Loader Class Initialized
INFO - 2023-04-28 09:14:20 --> Controller Class Initialized
DEBUG - 2023-04-28 09:14:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:14:20 --> Database Driver Class Initialized
INFO - 2023-04-28 09:14:20 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:14:20 --> Final output sent to browser
DEBUG - 2023-04-28 09:14:20 --> Total execution time: 0.0513
INFO - 2023-04-28 09:14:20 --> Config Class Initialized
INFO - 2023-04-28 09:14:20 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:14:20 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:14:20 --> Utf8 Class Initialized
INFO - 2023-04-28 09:14:20 --> URI Class Initialized
INFO - 2023-04-28 09:14:20 --> Router Class Initialized
INFO - 2023-04-28 09:14:20 --> Output Class Initialized
INFO - 2023-04-28 09:14:20 --> Security Class Initialized
DEBUG - 2023-04-28 09:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:14:20 --> Input Class Initialized
INFO - 2023-04-28 09:14:20 --> Language Class Initialized
INFO - 2023-04-28 09:14:20 --> Loader Class Initialized
INFO - 2023-04-28 09:14:20 --> Controller Class Initialized
DEBUG - 2023-04-28 09:14:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:14:20 --> Database Driver Class Initialized
INFO - 2023-04-28 09:14:20 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:14:20 --> Final output sent to browser
DEBUG - 2023-04-28 09:14:20 --> Total execution time: 0.0116
INFO - 2023-04-28 09:21:01 --> Config Class Initialized
INFO - 2023-04-28 09:21:01 --> Config Class Initialized
INFO - 2023-04-28 09:21:01 --> Hooks Class Initialized
INFO - 2023-04-28 09:21:01 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:21:01 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:01 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:01 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:01 --> URI Class Initialized
INFO - 2023-04-28 09:21:01 --> Router Class Initialized
INFO - 2023-04-28 09:21:01 --> URI Class Initialized
INFO - 2023-04-28 09:21:01 --> Router Class Initialized
INFO - 2023-04-28 09:21:01 --> Output Class Initialized
INFO - 2023-04-28 09:21:01 --> Output Class Initialized
INFO - 2023-04-28 09:21:01 --> Security Class Initialized
INFO - 2023-04-28 09:21:01 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 09:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:01 --> Input Class Initialized
INFO - 2023-04-28 09:21:01 --> Input Class Initialized
INFO - 2023-04-28 09:21:01 --> Language Class Initialized
INFO - 2023-04-28 09:21:01 --> Language Class Initialized
INFO - 2023-04-28 09:21:01 --> Loader Class Initialized
INFO - 2023-04-28 09:21:01 --> Loader Class Initialized
INFO - 2023-04-28 09:21:01 --> Controller Class Initialized
INFO - 2023-04-28 09:21:01 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 09:21:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:01 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:01 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:01 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:01 --> Total execution time: 0.1436
INFO - 2023-04-28 09:21:01 --> Config Class Initialized
INFO - 2023-04-28 09:21:01 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:01 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:01 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:01 --> URI Class Initialized
INFO - 2023-04-28 09:21:01 --> Router Class Initialized
INFO - 2023-04-28 09:21:01 --> Output Class Initialized
INFO - 2023-04-28 09:21:01 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:01 --> Input Class Initialized
INFO - 2023-04-28 09:21:01 --> Language Class Initialized
INFO - 2023-04-28 09:21:01 --> Loader Class Initialized
INFO - 2023-04-28 09:21:01 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:01 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:01 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:01 --> Final output sent to browser
INFO - 2023-04-28 09:21:01 --> Model "Login_model" initialized
DEBUG - 2023-04-28 09:21:01 --> Total execution time: 0.0133
INFO - 2023-04-28 09:21:01 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:01 --> Total execution time: 0.2070
INFO - 2023-04-28 09:21:01 --> Config Class Initialized
INFO - 2023-04-28 09:21:01 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:01 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:01 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:01 --> URI Class Initialized
INFO - 2023-04-28 09:21:01 --> Router Class Initialized
INFO - 2023-04-28 09:21:01 --> Output Class Initialized
INFO - 2023-04-28 09:21:01 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:01 --> Input Class Initialized
INFO - 2023-04-28 09:21:01 --> Language Class Initialized
INFO - 2023-04-28 09:21:01 --> Loader Class Initialized
INFO - 2023-04-28 09:21:01 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:01 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:01 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:01 --> Model "Login_model" initialized
INFO - 2023-04-28 09:21:01 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:01 --> Total execution time: 0.0547
INFO - 2023-04-28 09:21:14 --> Config Class Initialized
INFO - 2023-04-28 09:21:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:14 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:14 --> URI Class Initialized
INFO - 2023-04-28 09:21:14 --> Router Class Initialized
INFO - 2023-04-28 09:21:14 --> Output Class Initialized
INFO - 2023-04-28 09:21:14 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:14 --> Input Class Initialized
INFO - 2023-04-28 09:21:14 --> Language Class Initialized
INFO - 2023-04-28 09:21:14 --> Loader Class Initialized
INFO - 2023-04-28 09:21:14 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:14 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:14 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:14 --> Total execution time: 0.0152
INFO - 2023-04-28 09:21:14 --> Config Class Initialized
INFO - 2023-04-28 09:21:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:14 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:14 --> URI Class Initialized
INFO - 2023-04-28 09:21:14 --> Router Class Initialized
INFO - 2023-04-28 09:21:14 --> Output Class Initialized
INFO - 2023-04-28 09:21:14 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:14 --> Input Class Initialized
INFO - 2023-04-28 09:21:14 --> Language Class Initialized
INFO - 2023-04-28 09:21:14 --> Loader Class Initialized
INFO - 2023-04-28 09:21:14 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:14 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:14 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:14 --> Model "Login_model" initialized
INFO - 2023-04-28 09:21:14 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:14 --> Total execution time: 0.0207
INFO - 2023-04-28 09:21:15 --> Config Class Initialized
INFO - 2023-04-28 09:21:15 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:15 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:15 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:15 --> URI Class Initialized
INFO - 2023-04-28 09:21:15 --> Router Class Initialized
INFO - 2023-04-28 09:21:15 --> Output Class Initialized
INFO - 2023-04-28 09:21:15 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:15 --> Input Class Initialized
INFO - 2023-04-28 09:21:15 --> Language Class Initialized
INFO - 2023-04-28 09:21:15 --> Loader Class Initialized
INFO - 2023-04-28 09:21:15 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:15 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:15 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:15 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:15 --> Total execution time: 0.0516
INFO - 2023-04-28 09:21:15 --> Config Class Initialized
INFO - 2023-04-28 09:21:15 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:15 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:15 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:15 --> URI Class Initialized
INFO - 2023-04-28 09:21:15 --> Router Class Initialized
INFO - 2023-04-28 09:21:15 --> Output Class Initialized
INFO - 2023-04-28 09:21:15 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:15 --> Input Class Initialized
INFO - 2023-04-28 09:21:15 --> Language Class Initialized
INFO - 2023-04-28 09:21:15 --> Loader Class Initialized
INFO - 2023-04-28 09:21:15 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:15 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:15 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:15 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:15 --> Model "Login_model" initialized
INFO - 2023-04-28 09:21:15 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:15 --> Total execution time: 0.0239
INFO - 2023-04-28 09:21:17 --> Config Class Initialized
INFO - 2023-04-28 09:21:17 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:17 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:17 --> URI Class Initialized
INFO - 2023-04-28 09:21:17 --> Router Class Initialized
INFO - 2023-04-28 09:21:17 --> Output Class Initialized
INFO - 2023-04-28 09:21:17 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:17 --> Input Class Initialized
INFO - 2023-04-28 09:21:17 --> Language Class Initialized
INFO - 2023-04-28 09:21:17 --> Loader Class Initialized
INFO - 2023-04-28 09:21:17 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:17 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:17 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:17 --> Total execution time: 0.0145
INFO - 2023-04-28 09:21:17 --> Config Class Initialized
INFO - 2023-04-28 09:21:17 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:17 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:17 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:17 --> URI Class Initialized
INFO - 2023-04-28 09:21:17 --> Router Class Initialized
INFO - 2023-04-28 09:21:17 --> Output Class Initialized
INFO - 2023-04-28 09:21:17 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:17 --> Input Class Initialized
INFO - 2023-04-28 09:21:17 --> Language Class Initialized
INFO - 2023-04-28 09:21:17 --> Loader Class Initialized
INFO - 2023-04-28 09:21:17 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:17 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:17 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:17 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:17 --> Model "Login_model" initialized
INFO - 2023-04-28 09:21:17 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:17 --> Total execution time: 0.0394
INFO - 2023-04-28 09:21:20 --> Config Class Initialized
INFO - 2023-04-28 09:21:20 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:20 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:20 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:20 --> URI Class Initialized
INFO - 2023-04-28 09:21:20 --> Router Class Initialized
INFO - 2023-04-28 09:21:20 --> Output Class Initialized
INFO - 2023-04-28 09:21:20 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:20 --> Input Class Initialized
INFO - 2023-04-28 09:21:20 --> Language Class Initialized
INFO - 2023-04-28 09:21:20 --> Loader Class Initialized
INFO - 2023-04-28 09:21:20 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:20 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:20 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:20 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:20 --> Model "Login_model" initialized
INFO - 2023-04-28 09:21:20 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:20 --> Total execution time: 0.0376
INFO - 2023-04-28 09:21:34 --> Config Class Initialized
INFO - 2023-04-28 09:21:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:34 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:34 --> URI Class Initialized
INFO - 2023-04-28 09:21:34 --> Router Class Initialized
INFO - 2023-04-28 09:21:34 --> Output Class Initialized
INFO - 2023-04-28 09:21:34 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:34 --> Input Class Initialized
INFO - 2023-04-28 09:21:34 --> Language Class Initialized
INFO - 2023-04-28 09:21:34 --> Loader Class Initialized
INFO - 2023-04-28 09:21:34 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:34 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:34 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:34 --> Model "Login_model" initialized
INFO - 2023-04-28 09:21:35 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:35 --> Total execution time: 0.1091
INFO - 2023-04-28 09:21:35 --> Config Class Initialized
INFO - 2023-04-28 09:21:35 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:35 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:35 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:35 --> URI Class Initialized
INFO - 2023-04-28 09:21:35 --> Router Class Initialized
INFO - 2023-04-28 09:21:35 --> Output Class Initialized
INFO - 2023-04-28 09:21:35 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:35 --> Input Class Initialized
INFO - 2023-04-28 09:21:35 --> Language Class Initialized
INFO - 2023-04-28 09:21:35 --> Loader Class Initialized
INFO - 2023-04-28 09:21:35 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:35 --> Model "Login_model" initialized
INFO - 2023-04-28 09:21:35 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:35 --> Total execution time: 0.1140
INFO - 2023-04-28 09:21:36 --> Config Class Initialized
INFO - 2023-04-28 09:21:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:36 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:36 --> URI Class Initialized
INFO - 2023-04-28 09:21:36 --> Router Class Initialized
INFO - 2023-04-28 09:21:36 --> Output Class Initialized
INFO - 2023-04-28 09:21:36 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:36 --> Input Class Initialized
INFO - 2023-04-28 09:21:36 --> Language Class Initialized
INFO - 2023-04-28 09:21:36 --> Loader Class Initialized
INFO - 2023-04-28 09:21:36 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:36 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:36 --> Total execution time: 0.0040
INFO - 2023-04-28 09:21:36 --> Config Class Initialized
INFO - 2023-04-28 09:21:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:36 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:36 --> URI Class Initialized
INFO - 2023-04-28 09:21:36 --> Router Class Initialized
INFO - 2023-04-28 09:21:36 --> Output Class Initialized
INFO - 2023-04-28 09:21:36 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:36 --> Input Class Initialized
INFO - 2023-04-28 09:21:36 --> Language Class Initialized
INFO - 2023-04-28 09:21:36 --> Loader Class Initialized
INFO - 2023-04-28 09:21:36 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:36 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:36 --> Model "Mysql_model" initialized
INFO - 2023-04-28 09:21:36 --> Model "Grafana_model" initialized
INFO - 2023-04-28 09:21:36 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:36 --> Total execution time: 0.0175
INFO - 2023-04-28 09:21:52 --> Config Class Initialized
INFO - 2023-04-28 09:21:52 --> Config Class Initialized
INFO - 2023-04-28 09:21:52 --> Hooks Class Initialized
INFO - 2023-04-28 09:21:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:21:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:52 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:52 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:52 --> URI Class Initialized
INFO - 2023-04-28 09:21:52 --> URI Class Initialized
INFO - 2023-04-28 09:21:52 --> Router Class Initialized
INFO - 2023-04-28 09:21:52 --> Router Class Initialized
INFO - 2023-04-28 09:21:52 --> Output Class Initialized
INFO - 2023-04-28 09:21:52 --> Output Class Initialized
INFO - 2023-04-28 09:21:52 --> Security Class Initialized
INFO - 2023-04-28 09:21:52 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 09:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:52 --> Input Class Initialized
INFO - 2023-04-28 09:21:52 --> Input Class Initialized
INFO - 2023-04-28 09:21:52 --> Language Class Initialized
INFO - 2023-04-28 09:21:52 --> Language Class Initialized
INFO - 2023-04-28 09:21:52 --> Loader Class Initialized
INFO - 2023-04-28 09:21:52 --> Loader Class Initialized
INFO - 2023-04-28 09:21:52 --> Controller Class Initialized
INFO - 2023-04-28 09:21:52 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 09:21:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:52 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:52 --> Total execution time: 0.0049
INFO - 2023-04-28 09:21:52 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:52 --> Config Class Initialized
INFO - 2023-04-28 09:21:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:52 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:52 --> URI Class Initialized
INFO - 2023-04-28 09:21:52 --> Router Class Initialized
INFO - 2023-04-28 09:21:52 --> Output Class Initialized
INFO - 2023-04-28 09:21:52 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:52 --> Input Class Initialized
INFO - 2023-04-28 09:21:52 --> Language Class Initialized
INFO - 2023-04-28 09:21:52 --> Loader Class Initialized
INFO - 2023-04-28 09:21:52 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:52 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:52 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:52 --> Total execution time: 0.0171
INFO - 2023-04-28 09:21:52 --> Model "Login_model" initialized
INFO - 2023-04-28 09:21:52 --> Config Class Initialized
INFO - 2023-04-28 09:21:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:52 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:52 --> URI Class Initialized
INFO - 2023-04-28 09:21:52 --> Router Class Initialized
INFO - 2023-04-28 09:21:52 --> Output Class Initialized
INFO - 2023-04-28 09:21:52 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:52 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:52 --> Input Class Initialized
INFO - 2023-04-28 09:21:52 --> Language Class Initialized
INFO - 2023-04-28 09:21:52 --> Loader Class Initialized
INFO - 2023-04-28 09:21:52 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:52 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:52 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:52 --> Total execution time: 0.0222
INFO - 2023-04-28 09:21:52 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:52 --> Total execution time: 0.0136
INFO - 2023-04-28 09:21:55 --> Config Class Initialized
INFO - 2023-04-28 09:21:55 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:55 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:55 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:55 --> URI Class Initialized
INFO - 2023-04-28 09:21:55 --> Router Class Initialized
INFO - 2023-04-28 09:21:55 --> Output Class Initialized
INFO - 2023-04-28 09:21:55 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:55 --> Input Class Initialized
INFO - 2023-04-28 09:21:55 --> Language Class Initialized
INFO - 2023-04-28 09:21:55 --> Loader Class Initialized
INFO - 2023-04-28 09:21:55 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:55 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:55 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:55 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:55 --> Total execution time: 0.0281
INFO - 2023-04-28 09:21:55 --> Config Class Initialized
INFO - 2023-04-28 09:21:55 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:55 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:55 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:55 --> URI Class Initialized
INFO - 2023-04-28 09:21:55 --> Router Class Initialized
INFO - 2023-04-28 09:21:55 --> Output Class Initialized
INFO - 2023-04-28 09:21:55 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:55 --> Input Class Initialized
INFO - 2023-04-28 09:21:55 --> Language Class Initialized
INFO - 2023-04-28 09:21:55 --> Loader Class Initialized
INFO - 2023-04-28 09:21:55 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:55 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:55 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:55 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:55 --> Total execution time: 0.0186
INFO - 2023-04-28 09:21:57 --> Config Class Initialized
INFO - 2023-04-28 09:21:57 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:57 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:57 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:57 --> URI Class Initialized
INFO - 2023-04-28 09:21:57 --> Router Class Initialized
INFO - 2023-04-28 09:21:57 --> Output Class Initialized
INFO - 2023-04-28 09:21:57 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:57 --> Input Class Initialized
INFO - 2023-04-28 09:21:57 --> Language Class Initialized
INFO - 2023-04-28 09:21:57 --> Loader Class Initialized
INFO - 2023-04-28 09:21:57 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:57 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:57 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:57 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:57 --> Total execution time: 0.0152
INFO - 2023-04-28 09:21:57 --> Config Class Initialized
INFO - 2023-04-28 09:21:57 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:21:57 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:21:57 --> Utf8 Class Initialized
INFO - 2023-04-28 09:21:57 --> URI Class Initialized
INFO - 2023-04-28 09:21:57 --> Router Class Initialized
INFO - 2023-04-28 09:21:57 --> Output Class Initialized
INFO - 2023-04-28 09:21:57 --> Security Class Initialized
DEBUG - 2023-04-28 09:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:21:57 --> Input Class Initialized
INFO - 2023-04-28 09:21:57 --> Language Class Initialized
INFO - 2023-04-28 09:21:57 --> Loader Class Initialized
INFO - 2023-04-28 09:21:57 --> Controller Class Initialized
DEBUG - 2023-04-28 09:21:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:21:57 --> Database Driver Class Initialized
INFO - 2023-04-28 09:21:57 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:21:57 --> Final output sent to browser
DEBUG - 2023-04-28 09:21:57 --> Total execution time: 0.0146
INFO - 2023-04-28 09:27:03 --> Config Class Initialized
INFO - 2023-04-28 09:27:03 --> Config Class Initialized
INFO - 2023-04-28 09:27:03 --> Hooks Class Initialized
INFO - 2023-04-28 09:27:03 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:27:03 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:03 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:03 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:03 --> URI Class Initialized
INFO - 2023-04-28 09:27:03 --> URI Class Initialized
INFO - 2023-04-28 09:27:03 --> Router Class Initialized
INFO - 2023-04-28 09:27:03 --> Router Class Initialized
INFO - 2023-04-28 09:27:03 --> Output Class Initialized
INFO - 2023-04-28 09:27:03 --> Output Class Initialized
INFO - 2023-04-28 09:27:03 --> Security Class Initialized
INFO - 2023-04-28 09:27:03 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:03 --> Input Class Initialized
DEBUG - 2023-04-28 09:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:03 --> Input Class Initialized
INFO - 2023-04-28 09:27:03 --> Language Class Initialized
INFO - 2023-04-28 09:27:03 --> Language Class Initialized
INFO - 2023-04-28 09:27:03 --> Loader Class Initialized
INFO - 2023-04-28 09:27:03 --> Loader Class Initialized
INFO - 2023-04-28 09:27:03 --> Controller Class Initialized
INFO - 2023-04-28 09:27:03 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 09:27:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:03 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:03 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:03 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:03 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:03 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:03 --> Total execution time: 0.0143
INFO - 2023-04-28 09:27:03 --> Config Class Initialized
INFO - 2023-04-28 09:27:03 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:03 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:03 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:03 --> URI Class Initialized
INFO - 2023-04-28 09:27:03 --> Router Class Initialized
INFO - 2023-04-28 09:27:03 --> Output Class Initialized
INFO - 2023-04-28 09:27:03 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:03 --> Input Class Initialized
INFO - 2023-04-28 09:27:03 --> Language Class Initialized
INFO - 2023-04-28 09:27:03 --> Loader Class Initialized
INFO - 2023-04-28 09:27:03 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:03 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:03 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:03 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:03 --> Model "Login_model" initialized
INFO - 2023-04-28 09:27:03 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:03 --> Total execution time: 0.0112
INFO - 2023-04-28 09:27:03 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:03 --> Total execution time: 0.0965
INFO - 2023-04-28 09:27:03 --> Config Class Initialized
INFO - 2023-04-28 09:27:03 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:03 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:03 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:03 --> URI Class Initialized
INFO - 2023-04-28 09:27:03 --> Router Class Initialized
INFO - 2023-04-28 09:27:03 --> Output Class Initialized
INFO - 2023-04-28 09:27:03 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:03 --> Input Class Initialized
INFO - 2023-04-28 09:27:03 --> Language Class Initialized
INFO - 2023-04-28 09:27:03 --> Loader Class Initialized
INFO - 2023-04-28 09:27:03 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:03 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:03 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:03 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:03 --> Model "Login_model" initialized
INFO - 2023-04-28 09:27:03 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:03 --> Total execution time: 0.1109
INFO - 2023-04-28 09:27:24 --> Config Class Initialized
INFO - 2023-04-28 09:27:24 --> Hooks Class Initialized
INFO - 2023-04-28 09:27:24 --> Config Class Initialized
DEBUG - 2023-04-28 09:27:24 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:24 --> Hooks Class Initialized
INFO - 2023-04-28 09:27:24 --> Utf8 Class Initialized
DEBUG - 2023-04-28 09:27:24 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:24 --> URI Class Initialized
INFO - 2023-04-28 09:27:24 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:24 --> Router Class Initialized
INFO - 2023-04-28 09:27:24 --> URI Class Initialized
INFO - 2023-04-28 09:27:24 --> Output Class Initialized
INFO - 2023-04-28 09:27:24 --> Router Class Initialized
INFO - 2023-04-28 09:27:24 --> Security Class Initialized
INFO - 2023-04-28 09:27:24 --> Output Class Initialized
DEBUG - 2023-04-28 09:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:24 --> Security Class Initialized
INFO - 2023-04-28 09:27:24 --> Input Class Initialized
DEBUG - 2023-04-28 09:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:24 --> Language Class Initialized
INFO - 2023-04-28 09:27:24 --> Input Class Initialized
INFO - 2023-04-28 09:27:24 --> Language Class Initialized
INFO - 2023-04-28 09:27:24 --> Loader Class Initialized
INFO - 2023-04-28 09:27:24 --> Loader Class Initialized
INFO - 2023-04-28 09:27:24 --> Controller Class Initialized
INFO - 2023-04-28 09:27:24 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 09:27:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:24 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:24 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:24 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:24 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:24 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:24 --> Total execution time: 0.0188
INFO - 2023-04-28 09:27:24 --> Config Class Initialized
INFO - 2023-04-28 09:27:24 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:24 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:24 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:24 --> URI Class Initialized
INFO - 2023-04-28 09:27:24 --> Router Class Initialized
INFO - 2023-04-28 09:27:24 --> Output Class Initialized
INFO - 2023-04-28 09:27:24 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:24 --> Input Class Initialized
INFO - 2023-04-28 09:27:24 --> Language Class Initialized
INFO - 2023-04-28 09:27:24 --> Loader Class Initialized
INFO - 2023-04-28 09:27:24 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:24 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:24 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:24 --> Model "Login_model" initialized
INFO - 2023-04-28 09:27:24 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:24 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:24 --> Total execution time: 0.0234
INFO - 2023-04-28 09:27:24 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:24 --> Total execution time: 0.0897
INFO - 2023-04-28 09:27:24 --> Config Class Initialized
INFO - 2023-04-28 09:27:24 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:24 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:24 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:24 --> URI Class Initialized
INFO - 2023-04-28 09:27:24 --> Router Class Initialized
INFO - 2023-04-28 09:27:24 --> Output Class Initialized
INFO - 2023-04-28 09:27:24 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:24 --> Input Class Initialized
INFO - 2023-04-28 09:27:24 --> Language Class Initialized
INFO - 2023-04-28 09:27:24 --> Loader Class Initialized
INFO - 2023-04-28 09:27:24 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:24 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:24 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:24 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:24 --> Model "Login_model" initialized
INFO - 2023-04-28 09:27:24 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:24 --> Total execution time: 0.1570
INFO - 2023-04-28 09:27:35 --> Config Class Initialized
INFO - 2023-04-28 09:27:35 --> Config Class Initialized
INFO - 2023-04-28 09:27:35 --> Hooks Class Initialized
INFO - 2023-04-28 09:27:35 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:27:35 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:35 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:35 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:35 --> URI Class Initialized
INFO - 2023-04-28 09:27:35 --> URI Class Initialized
INFO - 2023-04-28 09:27:35 --> Router Class Initialized
INFO - 2023-04-28 09:27:35 --> Router Class Initialized
INFO - 2023-04-28 09:27:35 --> Output Class Initialized
INFO - 2023-04-28 09:27:35 --> Output Class Initialized
INFO - 2023-04-28 09:27:35 --> Security Class Initialized
INFO - 2023-04-28 09:27:35 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 09:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:35 --> Input Class Initialized
INFO - 2023-04-28 09:27:35 --> Input Class Initialized
INFO - 2023-04-28 09:27:35 --> Language Class Initialized
INFO - 2023-04-28 09:27:35 --> Language Class Initialized
INFO - 2023-04-28 09:27:35 --> Loader Class Initialized
INFO - 2023-04-28 09:27:35 --> Loader Class Initialized
INFO - 2023-04-28 09:27:35 --> Controller Class Initialized
INFO - 2023-04-28 09:27:35 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 09:27:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:35 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:35 --> Total execution time: 0.0170
INFO - 2023-04-28 09:27:35 --> Config Class Initialized
INFO - 2023-04-28 09:27:35 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:35 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:35 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:35 --> URI Class Initialized
INFO - 2023-04-28 09:27:35 --> Router Class Initialized
INFO - 2023-04-28 09:27:35 --> Output Class Initialized
INFO - 2023-04-28 09:27:35 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:35 --> Input Class Initialized
INFO - 2023-04-28 09:27:35 --> Language Class Initialized
INFO - 2023-04-28 09:27:35 --> Loader Class Initialized
INFO - 2023-04-28 09:27:35 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:35 --> Model "Login_model" initialized
INFO - 2023-04-28 09:27:35 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:35 --> Total execution time: 0.0137
INFO - 2023-04-28 09:27:35 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:35 --> Total execution time: 0.0735
INFO - 2023-04-28 09:27:35 --> Config Class Initialized
INFO - 2023-04-28 09:27:35 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:35 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:35 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:35 --> URI Class Initialized
INFO - 2023-04-28 09:27:35 --> Router Class Initialized
INFO - 2023-04-28 09:27:35 --> Output Class Initialized
INFO - 2023-04-28 09:27:35 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:35 --> Input Class Initialized
INFO - 2023-04-28 09:27:35 --> Language Class Initialized
INFO - 2023-04-28 09:27:35 --> Loader Class Initialized
INFO - 2023-04-28 09:27:35 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:35 --> Model "Login_model" initialized
INFO - 2023-04-28 09:27:35 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:35 --> Total execution time: 0.0662
INFO - 2023-04-28 09:27:38 --> Config Class Initialized
INFO - 2023-04-28 09:27:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:38 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:38 --> URI Class Initialized
INFO - 2023-04-28 09:27:38 --> Router Class Initialized
INFO - 2023-04-28 09:27:38 --> Output Class Initialized
INFO - 2023-04-28 09:27:38 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:38 --> Input Class Initialized
INFO - 2023-04-28 09:27:38 --> Language Class Initialized
INFO - 2023-04-28 09:27:38 --> Loader Class Initialized
INFO - 2023-04-28 09:27:38 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:38 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:38 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:38 --> Total execution time: 0.0153
INFO - 2023-04-28 09:27:38 --> Config Class Initialized
INFO - 2023-04-28 09:27:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:38 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:38 --> URI Class Initialized
INFO - 2023-04-28 09:27:38 --> Router Class Initialized
INFO - 2023-04-28 09:27:38 --> Output Class Initialized
INFO - 2023-04-28 09:27:38 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:38 --> Input Class Initialized
INFO - 2023-04-28 09:27:38 --> Language Class Initialized
INFO - 2023-04-28 09:27:38 --> Loader Class Initialized
INFO - 2023-04-28 09:27:38 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:38 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:38 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:38 --> Total execution time: 0.0198
INFO - 2023-04-28 09:27:42 --> Config Class Initialized
INFO - 2023-04-28 09:27:42 --> Config Class Initialized
INFO - 2023-04-28 09:27:42 --> Hooks Class Initialized
INFO - 2023-04-28 09:27:42 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:27:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:42 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:42 --> URI Class Initialized
INFO - 2023-04-28 09:27:42 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:42 --> Router Class Initialized
INFO - 2023-04-28 09:27:42 --> URI Class Initialized
INFO - 2023-04-28 09:27:42 --> Output Class Initialized
INFO - 2023-04-28 09:27:42 --> Router Class Initialized
INFO - 2023-04-28 09:27:42 --> Security Class Initialized
INFO - 2023-04-28 09:27:42 --> Output Class Initialized
DEBUG - 2023-04-28 09:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:42 --> Input Class Initialized
INFO - 2023-04-28 09:27:42 --> Security Class Initialized
INFO - 2023-04-28 09:27:42 --> Language Class Initialized
DEBUG - 2023-04-28 09:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:42 --> Input Class Initialized
INFO - 2023-04-28 09:27:42 --> Loader Class Initialized
INFO - 2023-04-28 09:27:42 --> Language Class Initialized
INFO - 2023-04-28 09:27:42 --> Controller Class Initialized
INFO - 2023-04-28 09:27:42 --> Loader Class Initialized
DEBUG - 2023-04-28 09:27:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:42 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:42 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:42 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:42 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:42 --> Total execution time: 0.0222
INFO - 2023-04-28 09:27:42 --> Config Class Initialized
INFO - 2023-04-28 09:27:42 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:42 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:42 --> URI Class Initialized
INFO - 2023-04-28 09:27:42 --> Router Class Initialized
INFO - 2023-04-28 09:27:42 --> Output Class Initialized
INFO - 2023-04-28 09:27:42 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:42 --> Input Class Initialized
INFO - 2023-04-28 09:27:42 --> Language Class Initialized
INFO - 2023-04-28 09:27:42 --> Loader Class Initialized
INFO - 2023-04-28 09:27:42 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:42 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:42 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:42 --> Model "Login_model" initialized
INFO - 2023-04-28 09:27:42 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:42 --> Total execution time: 0.0125
INFO - 2023-04-28 09:27:42 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:42 --> Total execution time: 0.0796
INFO - 2023-04-28 09:27:42 --> Config Class Initialized
INFO - 2023-04-28 09:27:42 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:42 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:42 --> URI Class Initialized
INFO - 2023-04-28 09:27:42 --> Router Class Initialized
INFO - 2023-04-28 09:27:42 --> Output Class Initialized
INFO - 2023-04-28 09:27:42 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:42 --> Input Class Initialized
INFO - 2023-04-28 09:27:42 --> Language Class Initialized
INFO - 2023-04-28 09:27:42 --> Loader Class Initialized
INFO - 2023-04-28 09:27:42 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:42 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:42 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:42 --> Model "Login_model" initialized
INFO - 2023-04-28 09:27:42 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:42 --> Total execution time: 0.0741
INFO - 2023-04-28 09:27:50 --> Config Class Initialized
INFO - 2023-04-28 09:27:50 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:50 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:50 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:50 --> URI Class Initialized
INFO - 2023-04-28 09:27:50 --> Router Class Initialized
INFO - 2023-04-28 09:27:50 --> Output Class Initialized
INFO - 2023-04-28 09:27:50 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:50 --> Input Class Initialized
INFO - 2023-04-28 09:27:50 --> Language Class Initialized
INFO - 2023-04-28 09:27:50 --> Loader Class Initialized
INFO - 2023-04-28 09:27:50 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:50 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:50 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:50 --> Total execution time: 0.0143
INFO - 2023-04-28 09:27:50 --> Config Class Initialized
INFO - 2023-04-28 09:27:50 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:50 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:50 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:50 --> URI Class Initialized
INFO - 2023-04-28 09:27:50 --> Router Class Initialized
INFO - 2023-04-28 09:27:50 --> Output Class Initialized
INFO - 2023-04-28 09:27:50 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:50 --> Input Class Initialized
INFO - 2023-04-28 09:27:50 --> Language Class Initialized
INFO - 2023-04-28 09:27:50 --> Loader Class Initialized
INFO - 2023-04-28 09:27:50 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:50 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:50 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:50 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:50 --> Total execution time: 0.0158
INFO - 2023-04-28 09:27:53 --> Config Class Initialized
INFO - 2023-04-28 09:27:53 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:53 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:53 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:53 --> URI Class Initialized
INFO - 2023-04-28 09:27:53 --> Router Class Initialized
INFO - 2023-04-28 09:27:53 --> Output Class Initialized
INFO - 2023-04-28 09:27:53 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:53 --> Input Class Initialized
INFO - 2023-04-28 09:27:53 --> Language Class Initialized
INFO - 2023-04-28 09:27:53 --> Loader Class Initialized
INFO - 2023-04-28 09:27:53 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:53 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:53 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:53 --> Total execution time: 0.0272
INFO - 2023-04-28 09:27:53 --> Config Class Initialized
INFO - 2023-04-28 09:27:53 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:53 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:53 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:53 --> URI Class Initialized
INFO - 2023-04-28 09:27:53 --> Router Class Initialized
INFO - 2023-04-28 09:27:53 --> Output Class Initialized
INFO - 2023-04-28 09:27:53 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:53 --> Input Class Initialized
INFO - 2023-04-28 09:27:53 --> Language Class Initialized
INFO - 2023-04-28 09:27:53 --> Loader Class Initialized
INFO - 2023-04-28 09:27:53 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:53 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:53 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:53 --> Total execution time: 0.0115
INFO - 2023-04-28 09:27:53 --> Config Class Initialized
INFO - 2023-04-28 09:27:53 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:53 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:53 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:53 --> URI Class Initialized
INFO - 2023-04-28 09:27:53 --> Router Class Initialized
INFO - 2023-04-28 09:27:53 --> Output Class Initialized
INFO - 2023-04-28 09:27:53 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:53 --> Input Class Initialized
INFO - 2023-04-28 09:27:53 --> Language Class Initialized
INFO - 2023-04-28 09:27:53 --> Loader Class Initialized
INFO - 2023-04-28 09:27:53 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:53 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:53 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:53 --> Total execution time: 0.1625
INFO - 2023-04-28 09:27:53 --> Config Class Initialized
INFO - 2023-04-28 09:27:53 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:53 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:53 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:53 --> URI Class Initialized
INFO - 2023-04-28 09:27:53 --> Router Class Initialized
INFO - 2023-04-28 09:27:53 --> Output Class Initialized
INFO - 2023-04-28 09:27:53 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:53 --> Input Class Initialized
INFO - 2023-04-28 09:27:53 --> Language Class Initialized
INFO - 2023-04-28 09:27:53 --> Loader Class Initialized
INFO - 2023-04-28 09:27:53 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:53 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:53 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:53 --> Total execution time: 0.0231
INFO - 2023-04-28 09:27:56 --> Config Class Initialized
INFO - 2023-04-28 09:27:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:56 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:56 --> URI Class Initialized
INFO - 2023-04-28 09:27:56 --> Router Class Initialized
INFO - 2023-04-28 09:27:56 --> Output Class Initialized
INFO - 2023-04-28 09:27:56 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:56 --> Input Class Initialized
INFO - 2023-04-28 09:27:56 --> Language Class Initialized
INFO - 2023-04-28 09:27:56 --> Loader Class Initialized
INFO - 2023-04-28 09:27:56 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:56 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:56 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:56 --> Total execution time: 0.0471
INFO - 2023-04-28 09:27:56 --> Config Class Initialized
INFO - 2023-04-28 09:27:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:27:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:27:56 --> Utf8 Class Initialized
INFO - 2023-04-28 09:27:56 --> URI Class Initialized
INFO - 2023-04-28 09:27:56 --> Router Class Initialized
INFO - 2023-04-28 09:27:56 --> Output Class Initialized
INFO - 2023-04-28 09:27:56 --> Security Class Initialized
DEBUG - 2023-04-28 09:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:27:56 --> Input Class Initialized
INFO - 2023-04-28 09:27:56 --> Language Class Initialized
INFO - 2023-04-28 09:27:56 --> Loader Class Initialized
INFO - 2023-04-28 09:27:56 --> Controller Class Initialized
DEBUG - 2023-04-28 09:27:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:27:56 --> Database Driver Class Initialized
INFO - 2023-04-28 09:27:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:27:56 --> Final output sent to browser
DEBUG - 2023-04-28 09:27:56 --> Total execution time: 0.0112
INFO - 2023-04-28 09:28:02 --> Config Class Initialized
INFO - 2023-04-28 09:28:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:02 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:02 --> URI Class Initialized
INFO - 2023-04-28 09:28:02 --> Router Class Initialized
INFO - 2023-04-28 09:28:02 --> Output Class Initialized
INFO - 2023-04-28 09:28:02 --> Security Class Initialized
DEBUG - 2023-04-28 09:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:02 --> Input Class Initialized
INFO - 2023-04-28 09:28:02 --> Language Class Initialized
INFO - 2023-04-28 09:28:02 --> Loader Class Initialized
INFO - 2023-04-28 09:28:02 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:02 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:02 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:02 --> Total execution time: 0.0148
INFO - 2023-04-28 09:28:02 --> Config Class Initialized
INFO - 2023-04-28 09:28:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:02 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:02 --> URI Class Initialized
INFO - 2023-04-28 09:28:02 --> Router Class Initialized
INFO - 2023-04-28 09:28:02 --> Output Class Initialized
INFO - 2023-04-28 09:28:02 --> Security Class Initialized
DEBUG - 2023-04-28 09:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:02 --> Input Class Initialized
INFO - 2023-04-28 09:28:02 --> Language Class Initialized
INFO - 2023-04-28 09:28:02 --> Loader Class Initialized
INFO - 2023-04-28 09:28:02 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:02 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:02 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:02 --> Model "Login_model" initialized
INFO - 2023-04-28 09:28:02 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:02 --> Total execution time: 0.0224
INFO - 2023-04-28 09:28:02 --> Config Class Initialized
INFO - 2023-04-28 09:28:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:02 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:02 --> URI Class Initialized
INFO - 2023-04-28 09:28:02 --> Router Class Initialized
INFO - 2023-04-28 09:28:02 --> Output Class Initialized
INFO - 2023-04-28 09:28:02 --> Security Class Initialized
DEBUG - 2023-04-28 09:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:02 --> Input Class Initialized
INFO - 2023-04-28 09:28:02 --> Language Class Initialized
INFO - 2023-04-28 09:28:02 --> Loader Class Initialized
INFO - 2023-04-28 09:28:02 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:02 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:02 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:02 --> Total execution time: 0.0345
INFO - 2023-04-28 09:28:02 --> Config Class Initialized
INFO - 2023-04-28 09:28:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:02 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:02 --> URI Class Initialized
INFO - 2023-04-28 09:28:02 --> Router Class Initialized
INFO - 2023-04-28 09:28:02 --> Output Class Initialized
INFO - 2023-04-28 09:28:02 --> Security Class Initialized
DEBUG - 2023-04-28 09:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:02 --> Input Class Initialized
INFO - 2023-04-28 09:28:02 --> Language Class Initialized
INFO - 2023-04-28 09:28:02 --> Loader Class Initialized
INFO - 2023-04-28 09:28:02 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:02 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:02 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:02 --> Model "Login_model" initialized
INFO - 2023-04-28 09:28:02 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:02 --> Total execution time: 0.0249
INFO - 2023-04-28 09:28:04 --> Config Class Initialized
INFO - 2023-04-28 09:28:04 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:04 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:04 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:04 --> URI Class Initialized
INFO - 2023-04-28 09:28:04 --> Router Class Initialized
INFO - 2023-04-28 09:28:04 --> Output Class Initialized
INFO - 2023-04-28 09:28:04 --> Security Class Initialized
DEBUG - 2023-04-28 09:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:04 --> Input Class Initialized
INFO - 2023-04-28 09:28:04 --> Language Class Initialized
INFO - 2023-04-28 09:28:04 --> Loader Class Initialized
INFO - 2023-04-28 09:28:04 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:04 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:04 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:04 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:04 --> Total execution time: 0.0152
INFO - 2023-04-28 09:28:04 --> Config Class Initialized
INFO - 2023-04-28 09:28:04 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:04 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:04 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:04 --> URI Class Initialized
INFO - 2023-04-28 09:28:04 --> Router Class Initialized
INFO - 2023-04-28 09:28:04 --> Output Class Initialized
INFO - 2023-04-28 09:28:04 --> Security Class Initialized
DEBUG - 2023-04-28 09:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:04 --> Input Class Initialized
INFO - 2023-04-28 09:28:04 --> Language Class Initialized
INFO - 2023-04-28 09:28:04 --> Loader Class Initialized
INFO - 2023-04-28 09:28:04 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:04 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:04 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:04 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:04 --> Total execution time: 0.0530
INFO - 2023-04-28 09:28:06 --> Config Class Initialized
INFO - 2023-04-28 09:28:06 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:06 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:06 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:06 --> URI Class Initialized
INFO - 2023-04-28 09:28:06 --> Router Class Initialized
INFO - 2023-04-28 09:28:06 --> Output Class Initialized
INFO - 2023-04-28 09:28:06 --> Security Class Initialized
DEBUG - 2023-04-28 09:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:06 --> Input Class Initialized
INFO - 2023-04-28 09:28:06 --> Language Class Initialized
INFO - 2023-04-28 09:28:06 --> Loader Class Initialized
INFO - 2023-04-28 09:28:06 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:06 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:06 --> Config Class Initialized
INFO - 2023-04-28 09:28:06 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:06 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:06 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:06 --> URI Class Initialized
INFO - 2023-04-28 09:28:06 --> Router Class Initialized
INFO - 2023-04-28 09:28:06 --> Output Class Initialized
INFO - 2023-04-28 09:28:06 --> Security Class Initialized
DEBUG - 2023-04-28 09:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:06 --> Input Class Initialized
INFO - 2023-04-28 09:28:06 --> Language Class Initialized
INFO - 2023-04-28 09:28:06 --> Loader Class Initialized
INFO - 2023-04-28 09:28:06 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:06 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:06 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:06 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:06 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:06 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:06 --> Total execution time: 0.1058
INFO - 2023-04-28 09:28:06 --> Config Class Initialized
INFO - 2023-04-28 09:28:06 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:06 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:06 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:06 --> URI Class Initialized
INFO - 2023-04-28 09:28:06 --> Router Class Initialized
INFO - 2023-04-28 09:28:06 --> Output Class Initialized
INFO - 2023-04-28 09:28:06 --> Security Class Initialized
INFO - 2023-04-28 09:28:06 --> Model "Login_model" initialized
DEBUG - 2023-04-28 09:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:06 --> Input Class Initialized
INFO - 2023-04-28 09:28:06 --> Language Class Initialized
INFO - 2023-04-28 09:28:06 --> Loader Class Initialized
INFO - 2023-04-28 09:28:06 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:06 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:06 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:06 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:06 --> Total execution time: 0.0140
INFO - 2023-04-28 09:28:06 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:06 --> Total execution time: 0.1970
INFO - 2023-04-28 09:28:06 --> Config Class Initialized
INFO - 2023-04-28 09:28:06 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:06 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:06 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:06 --> URI Class Initialized
INFO - 2023-04-28 09:28:06 --> Router Class Initialized
INFO - 2023-04-28 09:28:06 --> Output Class Initialized
INFO - 2023-04-28 09:28:06 --> Security Class Initialized
DEBUG - 2023-04-28 09:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:06 --> Input Class Initialized
INFO - 2023-04-28 09:28:06 --> Language Class Initialized
INFO - 2023-04-28 09:28:06 --> Loader Class Initialized
INFO - 2023-04-28 09:28:06 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:06 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:06 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:06 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:06 --> Model "Login_model" initialized
INFO - 2023-04-28 09:28:06 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:06 --> Total execution time: 0.0672
INFO - 2023-04-28 09:28:10 --> Config Class Initialized
INFO - 2023-04-28 09:28:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:10 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:10 --> URI Class Initialized
INFO - 2023-04-28 09:28:10 --> Router Class Initialized
INFO - 2023-04-28 09:28:10 --> Output Class Initialized
INFO - 2023-04-28 09:28:10 --> Security Class Initialized
DEBUG - 2023-04-28 09:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:10 --> Input Class Initialized
INFO - 2023-04-28 09:28:10 --> Language Class Initialized
INFO - 2023-04-28 09:28:10 --> Loader Class Initialized
INFO - 2023-04-28 09:28:10 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:10 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:10 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:10 --> Total execution time: 0.0145
INFO - 2023-04-28 09:28:10 --> Config Class Initialized
INFO - 2023-04-28 09:28:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:10 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:10 --> URI Class Initialized
INFO - 2023-04-28 09:28:10 --> Router Class Initialized
INFO - 2023-04-28 09:28:10 --> Output Class Initialized
INFO - 2023-04-28 09:28:10 --> Security Class Initialized
DEBUG - 2023-04-28 09:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:10 --> Input Class Initialized
INFO - 2023-04-28 09:28:10 --> Language Class Initialized
INFO - 2023-04-28 09:28:10 --> Loader Class Initialized
INFO - 2023-04-28 09:28:10 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:10 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:10 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:10 --> Total execution time: 0.0114
INFO - 2023-04-28 09:28:10 --> Config Class Initialized
INFO - 2023-04-28 09:28:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:10 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:10 --> URI Class Initialized
INFO - 2023-04-28 09:28:10 --> Router Class Initialized
INFO - 2023-04-28 09:28:10 --> Output Class Initialized
INFO - 2023-04-28 09:28:10 --> Security Class Initialized
DEBUG - 2023-04-28 09:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:10 --> Input Class Initialized
INFO - 2023-04-28 09:28:10 --> Language Class Initialized
INFO - 2023-04-28 09:28:10 --> Loader Class Initialized
INFO - 2023-04-28 09:28:10 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:10 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:10 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:10 --> Total execution time: 0.0390
INFO - 2023-04-28 09:28:10 --> Config Class Initialized
INFO - 2023-04-28 09:28:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:28:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:28:10 --> Utf8 Class Initialized
INFO - 2023-04-28 09:28:10 --> URI Class Initialized
INFO - 2023-04-28 09:28:10 --> Router Class Initialized
INFO - 2023-04-28 09:28:10 --> Output Class Initialized
INFO - 2023-04-28 09:28:10 --> Security Class Initialized
DEBUG - 2023-04-28 09:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:28:10 --> Input Class Initialized
INFO - 2023-04-28 09:28:10 --> Language Class Initialized
INFO - 2023-04-28 09:28:10 --> Loader Class Initialized
INFO - 2023-04-28 09:28:10 --> Controller Class Initialized
DEBUG - 2023-04-28 09:28:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:28:10 --> Database Driver Class Initialized
INFO - 2023-04-28 09:28:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:28:10 --> Final output sent to browser
DEBUG - 2023-04-28 09:28:10 --> Total execution time: 0.0108
INFO - 2023-04-28 09:40:37 --> Config Class Initialized
INFO - 2023-04-28 09:40:37 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:40:37 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:40:37 --> Utf8 Class Initialized
INFO - 2023-04-28 09:40:37 --> URI Class Initialized
INFO - 2023-04-28 09:40:37 --> Router Class Initialized
INFO - 2023-04-28 09:40:37 --> Output Class Initialized
INFO - 2023-04-28 09:40:37 --> Security Class Initialized
DEBUG - 2023-04-28 09:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:40:37 --> Input Class Initialized
INFO - 2023-04-28 09:40:37 --> Language Class Initialized
INFO - 2023-04-28 09:40:37 --> Loader Class Initialized
INFO - 2023-04-28 09:40:37 --> Controller Class Initialized
DEBUG - 2023-04-28 09:40:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:40:37 --> Database Driver Class Initialized
INFO - 2023-04-28 09:40:37 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:40:37 --> Final output sent to browser
DEBUG - 2023-04-28 09:40:37 --> Total execution time: 0.0099
INFO - 2023-04-28 09:40:37 --> Config Class Initialized
INFO - 2023-04-28 09:40:37 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:40:37 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:40:37 --> Utf8 Class Initialized
INFO - 2023-04-28 09:40:37 --> URI Class Initialized
INFO - 2023-04-28 09:40:37 --> Router Class Initialized
INFO - 2023-04-28 09:40:37 --> Output Class Initialized
INFO - 2023-04-28 09:40:37 --> Security Class Initialized
DEBUG - 2023-04-28 09:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:40:37 --> Input Class Initialized
INFO - 2023-04-28 09:40:37 --> Language Class Initialized
INFO - 2023-04-28 09:40:37 --> Loader Class Initialized
INFO - 2023-04-28 09:40:37 --> Controller Class Initialized
DEBUG - 2023-04-28 09:40:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:40:37 --> Database Driver Class Initialized
INFO - 2023-04-28 09:40:37 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:40:37 --> Database Driver Class Initialized
INFO - 2023-04-28 09:40:37 --> Model "Login_model" initialized
INFO - 2023-04-28 09:40:37 --> Final output sent to browser
DEBUG - 2023-04-28 09:40:37 --> Total execution time: 0.0421
INFO - 2023-04-28 09:40:37 --> Config Class Initialized
INFO - 2023-04-28 09:40:37 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:40:37 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:40:37 --> Utf8 Class Initialized
INFO - 2023-04-28 09:40:37 --> URI Class Initialized
INFO - 2023-04-28 09:40:37 --> Router Class Initialized
INFO - 2023-04-28 09:40:37 --> Output Class Initialized
INFO - 2023-04-28 09:40:37 --> Security Class Initialized
DEBUG - 2023-04-28 09:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:40:37 --> Input Class Initialized
INFO - 2023-04-28 09:40:37 --> Language Class Initialized
INFO - 2023-04-28 09:40:37 --> Loader Class Initialized
INFO - 2023-04-28 09:40:37 --> Controller Class Initialized
DEBUG - 2023-04-28 09:40:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:40:37 --> Database Driver Class Initialized
INFO - 2023-04-28 09:40:37 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:40:37 --> Final output sent to browser
DEBUG - 2023-04-28 09:40:37 --> Total execution time: 0.0120
INFO - 2023-04-28 09:40:37 --> Config Class Initialized
INFO - 2023-04-28 09:40:37 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:40:37 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:40:37 --> Utf8 Class Initialized
INFO - 2023-04-28 09:40:37 --> URI Class Initialized
INFO - 2023-04-28 09:40:37 --> Router Class Initialized
INFO - 2023-04-28 09:40:37 --> Output Class Initialized
INFO - 2023-04-28 09:40:37 --> Security Class Initialized
DEBUG - 2023-04-28 09:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:40:37 --> Input Class Initialized
INFO - 2023-04-28 09:40:37 --> Language Class Initialized
INFO - 2023-04-28 09:40:37 --> Loader Class Initialized
INFO - 2023-04-28 09:40:37 --> Controller Class Initialized
DEBUG - 2023-04-28 09:40:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:40:37 --> Database Driver Class Initialized
INFO - 2023-04-28 09:40:37 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:40:38 --> Final output sent to browser
DEBUG - 2023-04-28 09:40:38 --> Total execution time: 0.6253
INFO - 2023-04-28 09:40:42 --> Config Class Initialized
INFO - 2023-04-28 09:40:42 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:40:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:40:42 --> Utf8 Class Initialized
INFO - 2023-04-28 09:40:42 --> URI Class Initialized
INFO - 2023-04-28 09:40:42 --> Router Class Initialized
INFO - 2023-04-28 09:40:42 --> Output Class Initialized
INFO - 2023-04-28 09:40:42 --> Security Class Initialized
DEBUG - 2023-04-28 09:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:40:42 --> Input Class Initialized
INFO - 2023-04-28 09:40:42 --> Language Class Initialized
INFO - 2023-04-28 09:40:42 --> Loader Class Initialized
INFO - 2023-04-28 09:40:42 --> Controller Class Initialized
DEBUG - 2023-04-28 09:40:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:40:42 --> Database Driver Class Initialized
INFO - 2023-04-28 09:40:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:40:42 --> Final output sent to browser
DEBUG - 2023-04-28 09:40:42 --> Total execution time: 0.0213
INFO - 2023-04-28 09:40:47 --> Config Class Initialized
INFO - 2023-04-28 09:40:47 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:40:47 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:40:47 --> Utf8 Class Initialized
INFO - 2023-04-28 09:40:47 --> URI Class Initialized
INFO - 2023-04-28 09:40:47 --> Router Class Initialized
INFO - 2023-04-28 09:40:47 --> Output Class Initialized
INFO - 2023-04-28 09:40:47 --> Security Class Initialized
DEBUG - 2023-04-28 09:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:40:47 --> Input Class Initialized
INFO - 2023-04-28 09:40:47 --> Language Class Initialized
INFO - 2023-04-28 09:40:47 --> Loader Class Initialized
INFO - 2023-04-28 09:40:47 --> Controller Class Initialized
DEBUG - 2023-04-28 09:40:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:40:47 --> Database Driver Class Initialized
INFO - 2023-04-28 09:40:47 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:40:47 --> Final output sent to browser
DEBUG - 2023-04-28 09:40:47 --> Total execution time: 0.0146
INFO - 2023-04-28 09:40:47 --> Config Class Initialized
INFO - 2023-04-28 09:40:47 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:40:47 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:40:47 --> Utf8 Class Initialized
INFO - 2023-04-28 09:40:47 --> URI Class Initialized
INFO - 2023-04-28 09:40:47 --> Router Class Initialized
INFO - 2023-04-28 09:40:47 --> Output Class Initialized
INFO - 2023-04-28 09:40:47 --> Security Class Initialized
DEBUG - 2023-04-28 09:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:40:47 --> Input Class Initialized
INFO - 2023-04-28 09:40:47 --> Language Class Initialized
INFO - 2023-04-28 09:40:47 --> Loader Class Initialized
INFO - 2023-04-28 09:40:47 --> Controller Class Initialized
DEBUG - 2023-04-28 09:40:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:40:47 --> Database Driver Class Initialized
INFO - 2023-04-28 09:40:47 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:40:47 --> Final output sent to browser
DEBUG - 2023-04-28 09:40:47 --> Total execution time: 0.0125
INFO - 2023-04-28 09:40:52 --> Config Class Initialized
INFO - 2023-04-28 09:40:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:40:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:40:52 --> Utf8 Class Initialized
INFO - 2023-04-28 09:40:52 --> URI Class Initialized
INFO - 2023-04-28 09:40:52 --> Router Class Initialized
INFO - 2023-04-28 09:40:52 --> Output Class Initialized
INFO - 2023-04-28 09:40:52 --> Security Class Initialized
DEBUG - 2023-04-28 09:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:40:52 --> Input Class Initialized
INFO - 2023-04-28 09:40:52 --> Language Class Initialized
INFO - 2023-04-28 09:40:52 --> Loader Class Initialized
INFO - 2023-04-28 09:40:52 --> Controller Class Initialized
DEBUG - 2023-04-28 09:40:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:40:52 --> Database Driver Class Initialized
INFO - 2023-04-28 09:40:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:40:52 --> Final output sent to browser
DEBUG - 2023-04-28 09:40:52 --> Total execution time: 0.0185
INFO - 2023-04-28 09:40:57 --> Config Class Initialized
INFO - 2023-04-28 09:40:57 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:40:57 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:40:57 --> Utf8 Class Initialized
INFO - 2023-04-28 09:40:57 --> URI Class Initialized
INFO - 2023-04-28 09:40:57 --> Router Class Initialized
INFO - 2023-04-28 09:40:57 --> Output Class Initialized
INFO - 2023-04-28 09:40:57 --> Security Class Initialized
DEBUG - 2023-04-28 09:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:40:57 --> Input Class Initialized
INFO - 2023-04-28 09:40:57 --> Language Class Initialized
INFO - 2023-04-28 09:40:57 --> Loader Class Initialized
INFO - 2023-04-28 09:40:57 --> Controller Class Initialized
DEBUG - 2023-04-28 09:40:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:40:57 --> Database Driver Class Initialized
INFO - 2023-04-28 09:40:57 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:40:57 --> Final output sent to browser
DEBUG - 2023-04-28 09:40:57 --> Total execution time: 0.0139
INFO - 2023-04-28 09:40:57 --> Config Class Initialized
INFO - 2023-04-28 09:40:57 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:40:57 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:40:57 --> Utf8 Class Initialized
INFO - 2023-04-28 09:40:57 --> URI Class Initialized
INFO - 2023-04-28 09:40:57 --> Router Class Initialized
INFO - 2023-04-28 09:40:57 --> Output Class Initialized
INFO - 2023-04-28 09:40:57 --> Security Class Initialized
DEBUG - 2023-04-28 09:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:40:57 --> Input Class Initialized
INFO - 2023-04-28 09:40:57 --> Language Class Initialized
INFO - 2023-04-28 09:40:57 --> Loader Class Initialized
INFO - 2023-04-28 09:40:57 --> Controller Class Initialized
DEBUG - 2023-04-28 09:40:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:40:57 --> Database Driver Class Initialized
INFO - 2023-04-28 09:40:57 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:40:57 --> Final output sent to browser
DEBUG - 2023-04-28 09:40:57 --> Total execution time: 0.0139
INFO - 2023-04-28 09:41:02 --> Config Class Initialized
INFO - 2023-04-28 09:41:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:41:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:41:02 --> Utf8 Class Initialized
INFO - 2023-04-28 09:41:02 --> URI Class Initialized
INFO - 2023-04-28 09:41:02 --> Router Class Initialized
INFO - 2023-04-28 09:41:02 --> Output Class Initialized
INFO - 2023-04-28 09:41:02 --> Security Class Initialized
DEBUG - 2023-04-28 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:41:02 --> Input Class Initialized
INFO - 2023-04-28 09:41:02 --> Language Class Initialized
INFO - 2023-04-28 09:41:02 --> Loader Class Initialized
INFO - 2023-04-28 09:41:02 --> Controller Class Initialized
DEBUG - 2023-04-28 09:41:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:41:02 --> Database Driver Class Initialized
INFO - 2023-04-28 09:41:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:41:02 --> Final output sent to browser
DEBUG - 2023-04-28 09:41:02 --> Total execution time: 0.0154
INFO - 2023-04-28 09:41:07 --> Config Class Initialized
INFO - 2023-04-28 09:41:07 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:41:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:41:07 --> Utf8 Class Initialized
INFO - 2023-04-28 09:41:07 --> URI Class Initialized
INFO - 2023-04-28 09:41:07 --> Router Class Initialized
INFO - 2023-04-28 09:41:07 --> Output Class Initialized
INFO - 2023-04-28 09:41:07 --> Security Class Initialized
DEBUG - 2023-04-28 09:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:41:07 --> Input Class Initialized
INFO - 2023-04-28 09:41:07 --> Language Class Initialized
INFO - 2023-04-28 09:41:07 --> Loader Class Initialized
INFO - 2023-04-28 09:41:07 --> Controller Class Initialized
DEBUG - 2023-04-28 09:41:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:41:07 --> Database Driver Class Initialized
INFO - 2023-04-28 09:41:07 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:41:07 --> Final output sent to browser
DEBUG - 2023-04-28 09:41:07 --> Total execution time: 0.0115
INFO - 2023-04-28 09:41:07 --> Config Class Initialized
INFO - 2023-04-28 09:41:07 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:41:07 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:41:07 --> Utf8 Class Initialized
INFO - 2023-04-28 09:41:07 --> URI Class Initialized
INFO - 2023-04-28 09:41:07 --> Router Class Initialized
INFO - 2023-04-28 09:41:07 --> Output Class Initialized
INFO - 2023-04-28 09:41:07 --> Security Class Initialized
DEBUG - 2023-04-28 09:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:41:07 --> Input Class Initialized
INFO - 2023-04-28 09:41:07 --> Language Class Initialized
INFO - 2023-04-28 09:41:07 --> Loader Class Initialized
INFO - 2023-04-28 09:41:07 --> Controller Class Initialized
DEBUG - 2023-04-28 09:41:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:41:07 --> Database Driver Class Initialized
INFO - 2023-04-28 09:41:07 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:41:07 --> Final output sent to browser
DEBUG - 2023-04-28 09:41:07 --> Total execution time: 0.0120
INFO - 2023-04-28 09:44:23 --> Config Class Initialized
INFO - 2023-04-28 09:44:23 --> Config Class Initialized
INFO - 2023-04-28 09:44:23 --> Hooks Class Initialized
INFO - 2023-04-28 09:44:23 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:44:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:44:23 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:44:23 --> Utf8 Class Initialized
INFO - 2023-04-28 09:44:23 --> Utf8 Class Initialized
INFO - 2023-04-28 09:44:23 --> URI Class Initialized
INFO - 2023-04-28 09:44:23 --> URI Class Initialized
INFO - 2023-04-28 09:44:23 --> Router Class Initialized
INFO - 2023-04-28 09:44:23 --> Router Class Initialized
INFO - 2023-04-28 09:44:23 --> Output Class Initialized
INFO - 2023-04-28 09:44:23 --> Security Class Initialized
DEBUG - 2023-04-28 09:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:44:23 --> Output Class Initialized
INFO - 2023-04-28 09:44:23 --> Input Class Initialized
INFO - 2023-04-28 09:44:23 --> Security Class Initialized
INFO - 2023-04-28 09:44:23 --> Language Class Initialized
DEBUG - 2023-04-28 09:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:44:23 --> Loader Class Initialized
INFO - 2023-04-28 09:44:23 --> Input Class Initialized
INFO - 2023-04-28 09:44:23 --> Language Class Initialized
INFO - 2023-04-28 09:44:23 --> Controller Class Initialized
DEBUG - 2023-04-28 09:44:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:44:23 --> Loader Class Initialized
INFO - 2023-04-28 09:44:23 --> Controller Class Initialized
INFO - 2023-04-28 09:44:23 --> Database Driver Class Initialized
DEBUG - 2023-04-28 09:44:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:44:23 --> Database Driver Class Initialized
INFO - 2023-04-28 09:44:23 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:44:23 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:44:23 --> Final output sent to browser
DEBUG - 2023-04-28 09:44:23 --> Total execution time: 0.0200
INFO - 2023-04-28 09:44:23 --> Config Class Initialized
INFO - 2023-04-28 09:44:23 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:44:23 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:44:23 --> Utf8 Class Initialized
INFO - 2023-04-28 09:44:23 --> URI Class Initialized
INFO - 2023-04-28 09:44:23 --> Router Class Initialized
INFO - 2023-04-28 09:44:23 --> Output Class Initialized
INFO - 2023-04-28 09:44:23 --> Security Class Initialized
INFO - 2023-04-28 09:44:23 --> Database Driver Class Initialized
DEBUG - 2023-04-28 09:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:44:23 --> Input Class Initialized
INFO - 2023-04-28 09:44:23 --> Language Class Initialized
INFO - 2023-04-28 09:44:23 --> Loader Class Initialized
INFO - 2023-04-28 09:44:23 --> Controller Class Initialized
DEBUG - 2023-04-28 09:44:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:44:23 --> Database Driver Class Initialized
INFO - 2023-04-28 09:44:23 --> Model "Login_model" initialized
INFO - 2023-04-28 09:44:23 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:44:23 --> Final output sent to browser
DEBUG - 2023-04-28 09:44:23 --> Total execution time: 0.0202
INFO - 2023-04-28 09:44:23 --> Final output sent to browser
DEBUG - 2023-04-28 09:44:23 --> Total execution time: 0.0912
INFO - 2023-04-28 09:44:23 --> Config Class Initialized
INFO - 2023-04-28 09:44:23 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:44:23 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:44:23 --> Utf8 Class Initialized
INFO - 2023-04-28 09:44:23 --> URI Class Initialized
INFO - 2023-04-28 09:44:23 --> Router Class Initialized
INFO - 2023-04-28 09:44:23 --> Output Class Initialized
INFO - 2023-04-28 09:44:23 --> Security Class Initialized
DEBUG - 2023-04-28 09:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:44:23 --> Input Class Initialized
INFO - 2023-04-28 09:44:23 --> Language Class Initialized
INFO - 2023-04-28 09:44:23 --> Loader Class Initialized
INFO - 2023-04-28 09:44:23 --> Controller Class Initialized
DEBUG - 2023-04-28 09:44:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:44:23 --> Database Driver Class Initialized
INFO - 2023-04-28 09:44:23 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:44:23 --> Database Driver Class Initialized
INFO - 2023-04-28 09:44:23 --> Model "Login_model" initialized
INFO - 2023-04-28 09:44:23 --> Final output sent to browser
DEBUG - 2023-04-28 09:44:23 --> Total execution time: 0.1123
INFO - 2023-04-28 09:59:26 --> Config Class Initialized
INFO - 2023-04-28 09:59:26 --> Config Class Initialized
INFO - 2023-04-28 09:59:26 --> Hooks Class Initialized
INFO - 2023-04-28 09:59:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:59:26 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:59:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:59:26 --> Utf8 Class Initialized
INFO - 2023-04-28 09:59:26 --> Utf8 Class Initialized
INFO - 2023-04-28 09:59:26 --> URI Class Initialized
INFO - 2023-04-28 09:59:26 --> URI Class Initialized
INFO - 2023-04-28 09:59:26 --> Router Class Initialized
INFO - 2023-04-28 09:59:26 --> Output Class Initialized
INFO - 2023-04-28 09:59:26 --> Router Class Initialized
INFO - 2023-04-28 09:59:26 --> Security Class Initialized
INFO - 2023-04-28 09:59:26 --> Output Class Initialized
DEBUG - 2023-04-28 09:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:59:26 --> Security Class Initialized
INFO - 2023-04-28 09:59:26 --> Input Class Initialized
DEBUG - 2023-04-28 09:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:59:26 --> Language Class Initialized
INFO - 2023-04-28 09:59:26 --> Input Class Initialized
INFO - 2023-04-28 09:59:26 --> Loader Class Initialized
INFO - 2023-04-28 09:59:26 --> Language Class Initialized
INFO - 2023-04-28 09:59:26 --> Controller Class Initialized
INFO - 2023-04-28 09:59:26 --> Loader Class Initialized
DEBUG - 2023-04-28 09:59:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:59:26 --> Controller Class Initialized
DEBUG - 2023-04-28 09:59:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:59:26 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:26 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:59:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:59:26 --> Final output sent to browser
DEBUG - 2023-04-28 09:59:26 --> Total execution time: 0.0233
INFO - 2023-04-28 09:59:26 --> Config Class Initialized
INFO - 2023-04-28 09:59:26 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:26 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:59:26 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:59:26 --> Utf8 Class Initialized
INFO - 2023-04-28 09:59:26 --> URI Class Initialized
INFO - 2023-04-28 09:59:26 --> Router Class Initialized
INFO - 2023-04-28 09:59:26 --> Output Class Initialized
INFO - 2023-04-28 09:59:26 --> Security Class Initialized
DEBUG - 2023-04-28 09:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:59:26 --> Input Class Initialized
INFO - 2023-04-28 09:59:26 --> Language Class Initialized
INFO - 2023-04-28 09:59:26 --> Loader Class Initialized
INFO - 2023-04-28 09:59:26 --> Controller Class Initialized
DEBUG - 2023-04-28 09:59:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:59:26 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:26 --> Model "Login_model" initialized
INFO - 2023-04-28 09:59:26 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:59:26 --> Final output sent to browser
DEBUG - 2023-04-28 09:59:26 --> Total execution time: 0.0521
INFO - 2023-04-28 09:59:27 --> Final output sent to browser
DEBUG - 2023-04-28 09:59:27 --> Total execution time: 0.1180
INFO - 2023-04-28 09:59:27 --> Config Class Initialized
INFO - 2023-04-28 09:59:27 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:59:27 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:59:27 --> Utf8 Class Initialized
INFO - 2023-04-28 09:59:27 --> URI Class Initialized
INFO - 2023-04-28 09:59:27 --> Router Class Initialized
INFO - 2023-04-28 09:59:27 --> Output Class Initialized
INFO - 2023-04-28 09:59:27 --> Security Class Initialized
DEBUG - 2023-04-28 09:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:59:27 --> Input Class Initialized
INFO - 2023-04-28 09:59:27 --> Language Class Initialized
INFO - 2023-04-28 09:59:27 --> Loader Class Initialized
INFO - 2023-04-28 09:59:27 --> Controller Class Initialized
DEBUG - 2023-04-28 09:59:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:59:27 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:27 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:59:27 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:27 --> Model "Login_model" initialized
INFO - 2023-04-28 09:59:27 --> Final output sent to browser
DEBUG - 2023-04-28 09:59:27 --> Total execution time: 0.1155
INFO - 2023-04-28 09:59:34 --> Config Class Initialized
INFO - 2023-04-28 09:59:34 --> Config Class Initialized
INFO - 2023-04-28 09:59:34 --> Hooks Class Initialized
INFO - 2023-04-28 09:59:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:59:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:59:35 --> Utf8 Class Initialized
DEBUG - 2023-04-28 09:59:35 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:59:35 --> URI Class Initialized
INFO - 2023-04-28 09:59:35 --> Utf8 Class Initialized
INFO - 2023-04-28 09:59:35 --> Router Class Initialized
INFO - 2023-04-28 09:59:35 --> URI Class Initialized
INFO - 2023-04-28 09:59:35 --> Output Class Initialized
INFO - 2023-04-28 09:59:35 --> Router Class Initialized
INFO - 2023-04-28 09:59:35 --> Security Class Initialized
INFO - 2023-04-28 09:59:35 --> Output Class Initialized
DEBUG - 2023-04-28 09:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:59:35 --> Security Class Initialized
INFO - 2023-04-28 09:59:35 --> Input Class Initialized
DEBUG - 2023-04-28 09:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:59:35 --> Language Class Initialized
INFO - 2023-04-28 09:59:35 --> Input Class Initialized
INFO - 2023-04-28 09:59:35 --> Loader Class Initialized
INFO - 2023-04-28 09:59:35 --> Language Class Initialized
INFO - 2023-04-28 09:59:35 --> Controller Class Initialized
DEBUG - 2023-04-28 09:59:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:59:35 --> Loader Class Initialized
INFO - 2023-04-28 09:59:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:35 --> Controller Class Initialized
DEBUG - 2023-04-28 09:59:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:59:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:59:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:59:35 --> Final output sent to browser
DEBUG - 2023-04-28 09:59:35 --> Total execution time: 0.2188
INFO - 2023-04-28 09:59:35 --> Config Class Initialized
INFO - 2023-04-28 09:59:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:35 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:59:35 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:59:35 --> Utf8 Class Initialized
INFO - 2023-04-28 09:59:35 --> URI Class Initialized
INFO - 2023-04-28 09:59:35 --> Router Class Initialized
INFO - 2023-04-28 09:59:35 --> Output Class Initialized
INFO - 2023-04-28 09:59:35 --> Security Class Initialized
DEBUG - 2023-04-28 09:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:59:35 --> Input Class Initialized
INFO - 2023-04-28 09:59:35 --> Language Class Initialized
INFO - 2023-04-28 09:59:35 --> Loader Class Initialized
INFO - 2023-04-28 09:59:35 --> Controller Class Initialized
DEBUG - 2023-04-28 09:59:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:59:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:35 --> Model "Login_model" initialized
INFO - 2023-04-28 09:59:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:59:35 --> Final output sent to browser
DEBUG - 2023-04-28 09:59:35 --> Total execution time: 0.0519
INFO - 2023-04-28 09:59:35 --> Final output sent to browser
DEBUG - 2023-04-28 09:59:35 --> Total execution time: 0.3105
INFO - 2023-04-28 09:59:35 --> Config Class Initialized
INFO - 2023-04-28 09:59:35 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:59:35 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:59:35 --> Utf8 Class Initialized
INFO - 2023-04-28 09:59:35 --> URI Class Initialized
INFO - 2023-04-28 09:59:35 --> Router Class Initialized
INFO - 2023-04-28 09:59:35 --> Output Class Initialized
INFO - 2023-04-28 09:59:35 --> Security Class Initialized
DEBUG - 2023-04-28 09:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:59:35 --> Input Class Initialized
INFO - 2023-04-28 09:59:35 --> Language Class Initialized
INFO - 2023-04-28 09:59:35 --> Loader Class Initialized
INFO - 2023-04-28 09:59:35 --> Controller Class Initialized
DEBUG - 2023-04-28 09:59:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:59:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:59:35 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:35 --> Model "Login_model" initialized
INFO - 2023-04-28 09:59:35 --> Final output sent to browser
DEBUG - 2023-04-28 09:59:35 --> Total execution time: 0.1088
INFO - 2023-04-28 09:59:52 --> Config Class Initialized
INFO - 2023-04-28 09:59:52 --> Config Class Initialized
INFO - 2023-04-28 09:59:52 --> Hooks Class Initialized
INFO - 2023-04-28 09:59:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 09:59:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:59:52 --> Utf8 Class Initialized
INFO - 2023-04-28 09:59:52 --> Utf8 Class Initialized
INFO - 2023-04-28 09:59:52 --> URI Class Initialized
INFO - 2023-04-28 09:59:52 --> URI Class Initialized
INFO - 2023-04-28 09:59:52 --> Router Class Initialized
INFO - 2023-04-28 09:59:52 --> Router Class Initialized
INFO - 2023-04-28 09:59:52 --> Output Class Initialized
INFO - 2023-04-28 09:59:52 --> Output Class Initialized
INFO - 2023-04-28 09:59:52 --> Security Class Initialized
INFO - 2023-04-28 09:59:52 --> Security Class Initialized
DEBUG - 2023-04-28 09:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 09:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:59:52 --> Input Class Initialized
INFO - 2023-04-28 09:59:52 --> Input Class Initialized
INFO - 2023-04-28 09:59:52 --> Language Class Initialized
INFO - 2023-04-28 09:59:52 --> Language Class Initialized
INFO - 2023-04-28 09:59:52 --> Loader Class Initialized
INFO - 2023-04-28 09:59:52 --> Loader Class Initialized
INFO - 2023-04-28 09:59:52 --> Controller Class Initialized
INFO - 2023-04-28 09:59:52 --> Controller Class Initialized
DEBUG - 2023-04-28 09:59:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 09:59:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:59:52 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:52 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:59:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:59:52 --> Final output sent to browser
DEBUG - 2023-04-28 09:59:52 --> Total execution time: 0.0550
INFO - 2023-04-28 09:59:52 --> Config Class Initialized
INFO - 2023-04-28 09:59:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:59:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:59:52 --> Utf8 Class Initialized
INFO - 2023-04-28 09:59:52 --> URI Class Initialized
INFO - 2023-04-28 09:59:52 --> Router Class Initialized
INFO - 2023-04-28 09:59:52 --> Output Class Initialized
INFO - 2023-04-28 09:59:52 --> Security Class Initialized
DEBUG - 2023-04-28 09:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:59:52 --> Input Class Initialized
INFO - 2023-04-28 09:59:52 --> Language Class Initialized
INFO - 2023-04-28 09:59:52 --> Loader Class Initialized
INFO - 2023-04-28 09:59:52 --> Controller Class Initialized
DEBUG - 2023-04-28 09:59:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:59:52 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:52 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:59:52 --> Model "Login_model" initialized
INFO - 2023-04-28 09:59:52 --> Final output sent to browser
DEBUG - 2023-04-28 09:59:52 --> Total execution time: 0.0134
INFO - 2023-04-28 09:59:52 --> Final output sent to browser
DEBUG - 2023-04-28 09:59:52 --> Total execution time: 0.1127
INFO - 2023-04-28 09:59:52 --> Config Class Initialized
INFO - 2023-04-28 09:59:52 --> Hooks Class Initialized
DEBUG - 2023-04-28 09:59:52 --> UTF-8 Support Enabled
INFO - 2023-04-28 09:59:52 --> Utf8 Class Initialized
INFO - 2023-04-28 09:59:52 --> URI Class Initialized
INFO - 2023-04-28 09:59:52 --> Router Class Initialized
INFO - 2023-04-28 09:59:52 --> Output Class Initialized
INFO - 2023-04-28 09:59:52 --> Security Class Initialized
DEBUG - 2023-04-28 09:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 09:59:52 --> Input Class Initialized
INFO - 2023-04-28 09:59:52 --> Language Class Initialized
INFO - 2023-04-28 09:59:52 --> Loader Class Initialized
INFO - 2023-04-28 09:59:52 --> Controller Class Initialized
DEBUG - 2023-04-28 09:59:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 09:59:52 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:52 --> Model "Cluster_model" initialized
INFO - 2023-04-28 09:59:52 --> Database Driver Class Initialized
INFO - 2023-04-28 09:59:52 --> Model "Login_model" initialized
INFO - 2023-04-28 09:59:52 --> Final output sent to browser
DEBUG - 2023-04-28 09:59:52 --> Total execution time: 0.1080
INFO - 2023-04-28 10:00:24 --> Config Class Initialized
INFO - 2023-04-28 10:00:25 --> Config Class Initialized
INFO - 2023-04-28 10:00:25 --> Hooks Class Initialized
INFO - 2023-04-28 10:00:25 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:00:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:00:25 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:00:25 --> Utf8 Class Initialized
INFO - 2023-04-28 10:00:25 --> Utf8 Class Initialized
INFO - 2023-04-28 10:00:25 --> URI Class Initialized
INFO - 2023-04-28 10:00:25 --> URI Class Initialized
INFO - 2023-04-28 10:00:25 --> Router Class Initialized
INFO - 2023-04-28 10:00:25 --> Router Class Initialized
INFO - 2023-04-28 10:00:25 --> Output Class Initialized
INFO - 2023-04-28 10:00:25 --> Output Class Initialized
INFO - 2023-04-28 10:00:25 --> Security Class Initialized
INFO - 2023-04-28 10:00:25 --> Security Class Initialized
DEBUG - 2023-04-28 10:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:00:25 --> Input Class Initialized
INFO - 2023-04-28 10:00:25 --> Input Class Initialized
INFO - 2023-04-28 10:00:25 --> Language Class Initialized
INFO - 2023-04-28 10:00:25 --> Language Class Initialized
INFO - 2023-04-28 10:00:25 --> Loader Class Initialized
INFO - 2023-04-28 10:00:25 --> Loader Class Initialized
INFO - 2023-04-28 10:00:25 --> Controller Class Initialized
INFO - 2023-04-28 10:00:25 --> Controller Class Initialized
DEBUG - 2023-04-28 10:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:00:25 --> Database Driver Class Initialized
INFO - 2023-04-28 10:00:25 --> Database Driver Class Initialized
INFO - 2023-04-28 10:00:25 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:00:25 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:00:25 --> Final output sent to browser
DEBUG - 2023-04-28 10:00:25 --> Total execution time: 0.0560
INFO - 2023-04-28 10:00:25 --> Config Class Initialized
INFO - 2023-04-28 10:00:25 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:00:25 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:00:25 --> Utf8 Class Initialized
INFO - 2023-04-28 10:00:25 --> URI Class Initialized
INFO - 2023-04-28 10:00:25 --> Router Class Initialized
INFO - 2023-04-28 10:00:25 --> Output Class Initialized
INFO - 2023-04-28 10:00:25 --> Security Class Initialized
DEBUG - 2023-04-28 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:00:25 --> Input Class Initialized
INFO - 2023-04-28 10:00:25 --> Language Class Initialized
INFO - 2023-04-28 10:00:25 --> Loader Class Initialized
INFO - 2023-04-28 10:00:25 --> Controller Class Initialized
DEBUG - 2023-04-28 10:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:00:25 --> Database Driver Class Initialized
INFO - 2023-04-28 10:00:25 --> Database Driver Class Initialized
INFO - 2023-04-28 10:00:25 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:00:25 --> Final output sent to browser
DEBUG - 2023-04-28 10:00:25 --> Total execution time: 0.0110
INFO - 2023-04-28 10:00:25 --> Model "Login_model" initialized
INFO - 2023-04-28 10:00:25 --> Final output sent to browser
DEBUG - 2023-04-28 10:00:25 --> Total execution time: 0.1591
INFO - 2023-04-28 10:00:25 --> Config Class Initialized
INFO - 2023-04-28 10:00:25 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:00:25 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:00:25 --> Utf8 Class Initialized
INFO - 2023-04-28 10:00:25 --> URI Class Initialized
INFO - 2023-04-28 10:00:25 --> Router Class Initialized
INFO - 2023-04-28 10:00:25 --> Output Class Initialized
INFO - 2023-04-28 10:00:25 --> Security Class Initialized
DEBUG - 2023-04-28 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:00:25 --> Input Class Initialized
INFO - 2023-04-28 10:00:25 --> Language Class Initialized
INFO - 2023-04-28 10:00:25 --> Loader Class Initialized
INFO - 2023-04-28 10:00:25 --> Controller Class Initialized
DEBUG - 2023-04-28 10:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:00:25 --> Database Driver Class Initialized
INFO - 2023-04-28 10:00:25 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:00:25 --> Database Driver Class Initialized
INFO - 2023-04-28 10:00:25 --> Model "Login_model" initialized
INFO - 2023-04-28 10:00:25 --> Final output sent to browser
DEBUG - 2023-04-28 10:00:25 --> Total execution time: 0.0704
INFO - 2023-04-28 10:00:42 --> Config Class Initialized
INFO - 2023-04-28 10:00:42 --> Config Class Initialized
INFO - 2023-04-28 10:00:42 --> Hooks Class Initialized
INFO - 2023-04-28 10:00:42 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:00:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:00:42 --> Utf8 Class Initialized
DEBUG - 2023-04-28 10:00:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:00:42 --> URI Class Initialized
INFO - 2023-04-28 10:00:42 --> Utf8 Class Initialized
INFO - 2023-04-28 10:00:42 --> Router Class Initialized
INFO - 2023-04-28 10:00:42 --> URI Class Initialized
INFO - 2023-04-28 10:00:42 --> Output Class Initialized
INFO - 2023-04-28 10:00:42 --> Router Class Initialized
INFO - 2023-04-28 10:00:42 --> Security Class Initialized
INFO - 2023-04-28 10:00:42 --> Output Class Initialized
DEBUG - 2023-04-28 10:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:00:42 --> Security Class Initialized
INFO - 2023-04-28 10:00:42 --> Input Class Initialized
DEBUG - 2023-04-28 10:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:00:42 --> Language Class Initialized
INFO - 2023-04-28 10:00:42 --> Input Class Initialized
INFO - 2023-04-28 10:00:42 --> Language Class Initialized
INFO - 2023-04-28 10:00:42 --> Loader Class Initialized
INFO - 2023-04-28 10:00:42 --> Loader Class Initialized
INFO - 2023-04-28 10:00:42 --> Controller Class Initialized
INFO - 2023-04-28 10:00:42 --> Controller Class Initialized
DEBUG - 2023-04-28 10:00:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:00:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:00:42 --> Database Driver Class Initialized
INFO - 2023-04-28 10:00:42 --> Database Driver Class Initialized
INFO - 2023-04-28 10:00:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:00:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:00:42 --> Final output sent to browser
DEBUG - 2023-04-28 10:00:42 --> Total execution time: 0.0984
INFO - 2023-04-28 10:00:42 --> Config Class Initialized
INFO - 2023-04-28 10:00:42 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:00:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:00:42 --> Utf8 Class Initialized
INFO - 2023-04-28 10:00:42 --> URI Class Initialized
INFO - 2023-04-28 10:00:42 --> Router Class Initialized
INFO - 2023-04-28 10:00:42 --> Output Class Initialized
INFO - 2023-04-28 10:00:42 --> Security Class Initialized
DEBUG - 2023-04-28 10:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:00:42 --> Input Class Initialized
INFO - 2023-04-28 10:00:42 --> Language Class Initialized
INFO - 2023-04-28 10:00:42 --> Loader Class Initialized
INFO - 2023-04-28 10:00:42 --> Controller Class Initialized
DEBUG - 2023-04-28 10:00:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:00:42 --> Database Driver Class Initialized
INFO - 2023-04-28 10:00:42 --> Database Driver Class Initialized
INFO - 2023-04-28 10:00:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:00:42 --> Model "Login_model" initialized
INFO - 2023-04-28 10:00:42 --> Final output sent to browser
DEBUG - 2023-04-28 10:00:42 --> Total execution time: 0.0159
INFO - 2023-04-28 10:00:42 --> Final output sent to browser
DEBUG - 2023-04-28 10:00:42 --> Total execution time: 0.1672
INFO - 2023-04-28 10:00:42 --> Config Class Initialized
INFO - 2023-04-28 10:00:42 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:00:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:00:42 --> Utf8 Class Initialized
INFO - 2023-04-28 10:00:42 --> URI Class Initialized
INFO - 2023-04-28 10:00:42 --> Router Class Initialized
INFO - 2023-04-28 10:00:42 --> Output Class Initialized
INFO - 2023-04-28 10:00:42 --> Security Class Initialized
DEBUG - 2023-04-28 10:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:00:42 --> Input Class Initialized
INFO - 2023-04-28 10:00:42 --> Language Class Initialized
INFO - 2023-04-28 10:00:42 --> Loader Class Initialized
INFO - 2023-04-28 10:00:42 --> Controller Class Initialized
DEBUG - 2023-04-28 10:00:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:00:42 --> Database Driver Class Initialized
INFO - 2023-04-28 10:00:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:00:42 --> Database Driver Class Initialized
INFO - 2023-04-28 10:00:42 --> Model "Login_model" initialized
INFO - 2023-04-28 10:00:42 --> Final output sent to browser
DEBUG - 2023-04-28 10:00:42 --> Total execution time: 0.1053
INFO - 2023-04-28 10:01:02 --> Config Class Initialized
INFO - 2023-04-28 10:01:02 --> Config Class Initialized
INFO - 2023-04-28 10:01:02 --> Hooks Class Initialized
INFO - 2023-04-28 10:01:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:01:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:02 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:02 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:02 --> URI Class Initialized
INFO - 2023-04-28 10:01:02 --> URI Class Initialized
INFO - 2023-04-28 10:01:02 --> Router Class Initialized
INFO - 2023-04-28 10:01:02 --> Router Class Initialized
INFO - 2023-04-28 10:01:02 --> Output Class Initialized
INFO - 2023-04-28 10:01:02 --> Output Class Initialized
INFO - 2023-04-28 10:01:02 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:02 --> Security Class Initialized
INFO - 2023-04-28 10:01:02 --> Input Class Initialized
DEBUG - 2023-04-28 10:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:02 --> Language Class Initialized
INFO - 2023-04-28 10:01:02 --> Input Class Initialized
INFO - 2023-04-28 10:01:02 --> Loader Class Initialized
INFO - 2023-04-28 10:01:02 --> Language Class Initialized
INFO - 2023-04-28 10:01:02 --> Controller Class Initialized
INFO - 2023-04-28 10:01:02 --> Loader Class Initialized
DEBUG - 2023-04-28 10:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:02 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:02 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:02 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:02 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:02 --> Total execution time: 0.0191
INFO - 2023-04-28 10:01:02 --> Config Class Initialized
INFO - 2023-04-28 10:01:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:02 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:02 --> URI Class Initialized
INFO - 2023-04-28 10:01:02 --> Router Class Initialized
INFO - 2023-04-28 10:01:02 --> Output Class Initialized
INFO - 2023-04-28 10:01:02 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:02 --> Input Class Initialized
INFO - 2023-04-28 10:01:02 --> Language Class Initialized
INFO - 2023-04-28 10:01:02 --> Loader Class Initialized
INFO - 2023-04-28 10:01:02 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:02 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:02 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:02 --> Model "Login_model" initialized
INFO - 2023-04-28 10:01:02 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:02 --> Total execution time: 0.0168
INFO - 2023-04-28 10:01:02 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:02 --> Total execution time: 0.0894
INFO - 2023-04-28 10:01:02 --> Config Class Initialized
INFO - 2023-04-28 10:01:02 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:02 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:02 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:02 --> URI Class Initialized
INFO - 2023-04-28 10:01:02 --> Router Class Initialized
INFO - 2023-04-28 10:01:02 --> Output Class Initialized
INFO - 2023-04-28 10:01:02 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:02 --> Input Class Initialized
INFO - 2023-04-28 10:01:02 --> Language Class Initialized
INFO - 2023-04-28 10:01:02 --> Loader Class Initialized
INFO - 2023-04-28 10:01:02 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:02 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:02 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:02 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:02 --> Model "Login_model" initialized
INFO - 2023-04-28 10:01:02 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:02 --> Total execution time: 0.1187
INFO - 2023-04-28 10:01:09 --> Config Class Initialized
INFO - 2023-04-28 10:01:09 --> Config Class Initialized
INFO - 2023-04-28 10:01:09 --> Hooks Class Initialized
INFO - 2023-04-28 10:01:09 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:09 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:01:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:09 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:09 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:09 --> URI Class Initialized
INFO - 2023-04-28 10:01:09 --> URI Class Initialized
INFO - 2023-04-28 10:01:09 --> Router Class Initialized
INFO - 2023-04-28 10:01:09 --> Router Class Initialized
INFO - 2023-04-28 10:01:09 --> Output Class Initialized
INFO - 2023-04-28 10:01:09 --> Output Class Initialized
INFO - 2023-04-28 10:01:09 --> Security Class Initialized
INFO - 2023-04-28 10:01:09 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 10:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:09 --> Input Class Initialized
INFO - 2023-04-28 10:01:09 --> Input Class Initialized
INFO - 2023-04-28 10:01:09 --> Language Class Initialized
INFO - 2023-04-28 10:01:09 --> Language Class Initialized
INFO - 2023-04-28 10:01:09 --> Loader Class Initialized
INFO - 2023-04-28 10:01:09 --> Loader Class Initialized
INFO - 2023-04-28 10:01:09 --> Controller Class Initialized
INFO - 2023-04-28 10:01:09 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:01:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:09 --> Final output sent to browser
INFO - 2023-04-28 10:01:09 --> Database Driver Class Initialized
DEBUG - 2023-04-28 10:01:09 --> Total execution time: 0.0045
INFO - 2023-04-28 10:01:09 --> Config Class Initialized
INFO - 2023-04-28 10:01:09 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:09 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:09 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:09 --> URI Class Initialized
INFO - 2023-04-28 10:01:09 --> Router Class Initialized
INFO - 2023-04-28 10:01:09 --> Output Class Initialized
INFO - 2023-04-28 10:01:09 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:09 --> Input Class Initialized
INFO - 2023-04-28 10:01:09 --> Language Class Initialized
INFO - 2023-04-28 10:01:09 --> Loader Class Initialized
INFO - 2023-04-28 10:01:09 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:09 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:09 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:09 --> Total execution time: 0.0499
INFO - 2023-04-28 10:01:09 --> Config Class Initialized
INFO - 2023-04-28 10:01:09 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:09 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:09 --> URI Class Initialized
INFO - 2023-04-28 10:01:09 --> Router Class Initialized
INFO - 2023-04-28 10:01:09 --> Output Class Initialized
INFO - 2023-04-28 10:01:09 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:09 --> Input Class Initialized
INFO - 2023-04-28 10:01:09 --> Language Class Initialized
INFO - 2023-04-28 10:01:09 --> Loader Class Initialized
INFO - 2023-04-28 10:01:09 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:09 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:09 --> Model "Login_model" initialized
INFO - 2023-04-28 10:01:09 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:09 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:09 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:09 --> Total execution time: 0.0137
INFO - 2023-04-28 10:01:09 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:09 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:09 --> Total execution time: 0.1027
INFO - 2023-04-28 10:01:10 --> Config Class Initialized
INFO - 2023-04-28 10:01:10 --> Config Class Initialized
INFO - 2023-04-28 10:01:10 --> Hooks Class Initialized
INFO - 2023-04-28 10:01:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:10 --> Utf8 Class Initialized
DEBUG - 2023-04-28 10:01:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:10 --> URI Class Initialized
INFO - 2023-04-28 10:01:10 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:10 --> Router Class Initialized
INFO - 2023-04-28 10:01:10 --> URI Class Initialized
INFO - 2023-04-28 10:01:10 --> Output Class Initialized
INFO - 2023-04-28 10:01:10 --> Router Class Initialized
INFO - 2023-04-28 10:01:10 --> Security Class Initialized
INFO - 2023-04-28 10:01:10 --> Output Class Initialized
DEBUG - 2023-04-28 10:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:10 --> Security Class Initialized
INFO - 2023-04-28 10:01:10 --> Input Class Initialized
DEBUG - 2023-04-28 10:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:10 --> Language Class Initialized
INFO - 2023-04-28 10:01:10 --> Input Class Initialized
INFO - 2023-04-28 10:01:10 --> Language Class Initialized
INFO - 2023-04-28 10:01:10 --> Loader Class Initialized
INFO - 2023-04-28 10:01:10 --> Loader Class Initialized
INFO - 2023-04-28 10:01:10 --> Controller Class Initialized
INFO - 2023-04-28 10:01:10 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:01:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:10 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:10 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:10 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:10 --> Total execution time: 0.0149
INFO - 2023-04-28 10:01:10 --> Config Class Initialized
INFO - 2023-04-28 10:01:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:10 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:10 --> URI Class Initialized
INFO - 2023-04-28 10:01:10 --> Router Class Initialized
INFO - 2023-04-28 10:01:10 --> Output Class Initialized
INFO - 2023-04-28 10:01:10 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:10 --> Input Class Initialized
INFO - 2023-04-28 10:01:10 --> Language Class Initialized
INFO - 2023-04-28 10:01:10 --> Loader Class Initialized
INFO - 2023-04-28 10:01:10 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:10 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:10 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:10 --> Model "Login_model" initialized
INFO - 2023-04-28 10:01:10 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:10 --> Total execution time: 0.0114
INFO - 2023-04-28 10:01:10 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:10 --> Total execution time: 0.0998
INFO - 2023-04-28 10:01:10 --> Config Class Initialized
INFO - 2023-04-28 10:01:10 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:10 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:10 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:10 --> URI Class Initialized
INFO - 2023-04-28 10:01:10 --> Router Class Initialized
INFO - 2023-04-28 10:01:10 --> Output Class Initialized
INFO - 2023-04-28 10:01:10 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:10 --> Input Class Initialized
INFO - 2023-04-28 10:01:10 --> Language Class Initialized
INFO - 2023-04-28 10:01:10 --> Loader Class Initialized
INFO - 2023-04-28 10:01:10 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:10 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:10 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:10 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:10 --> Model "Login_model" initialized
INFO - 2023-04-28 10:01:11 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:11 --> Total execution time: 0.0676
INFO - 2023-04-28 10:01:15 --> Config Class Initialized
INFO - 2023-04-28 10:01:15 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:15 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:15 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:15 --> URI Class Initialized
INFO - 2023-04-28 10:01:15 --> Router Class Initialized
INFO - 2023-04-28 10:01:15 --> Output Class Initialized
INFO - 2023-04-28 10:01:15 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:15 --> Input Class Initialized
INFO - 2023-04-28 10:01:15 --> Language Class Initialized
INFO - 2023-04-28 10:01:15 --> Loader Class Initialized
INFO - 2023-04-28 10:01:15 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:15 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:15 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:15 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:15 --> Total execution time: 0.0131
INFO - 2023-04-28 10:01:15 --> Config Class Initialized
INFO - 2023-04-28 10:01:15 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:15 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:15 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:15 --> URI Class Initialized
INFO - 2023-04-28 10:01:15 --> Router Class Initialized
INFO - 2023-04-28 10:01:15 --> Output Class Initialized
INFO - 2023-04-28 10:01:15 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:15 --> Input Class Initialized
INFO - 2023-04-28 10:01:15 --> Language Class Initialized
INFO - 2023-04-28 10:01:15 --> Loader Class Initialized
INFO - 2023-04-28 10:01:15 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:15 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:15 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:15 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:15 --> Total execution time: 0.0532
INFO - 2023-04-28 10:01:15 --> Config Class Initialized
INFO - 2023-04-28 10:01:15 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:15 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:15 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:15 --> URI Class Initialized
INFO - 2023-04-28 10:01:15 --> Router Class Initialized
INFO - 2023-04-28 10:01:15 --> Output Class Initialized
INFO - 2023-04-28 10:01:15 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:15 --> Input Class Initialized
INFO - 2023-04-28 10:01:15 --> Language Class Initialized
INFO - 2023-04-28 10:01:15 --> Loader Class Initialized
INFO - 2023-04-28 10:01:15 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:15 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:15 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:15 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:15 --> Total execution time: 0.0535
INFO - 2023-04-28 10:01:15 --> Config Class Initialized
INFO - 2023-04-28 10:01:15 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:15 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:15 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:15 --> URI Class Initialized
INFO - 2023-04-28 10:01:15 --> Router Class Initialized
INFO - 2023-04-28 10:01:15 --> Output Class Initialized
INFO - 2023-04-28 10:01:15 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:15 --> Input Class Initialized
INFO - 2023-04-28 10:01:15 --> Language Class Initialized
INFO - 2023-04-28 10:01:15 --> Loader Class Initialized
INFO - 2023-04-28 10:01:15 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:15 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:15 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:15 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:15 --> Total execution time: 0.0520
INFO - 2023-04-28 10:01:51 --> Config Class Initialized
INFO - 2023-04-28 10:01:51 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:51 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:51 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:51 --> URI Class Initialized
INFO - 2023-04-28 10:01:51 --> Router Class Initialized
INFO - 2023-04-28 10:01:51 --> Output Class Initialized
INFO - 2023-04-28 10:01:51 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:51 --> Input Class Initialized
INFO - 2023-04-28 10:01:51 --> Language Class Initialized
INFO - 2023-04-28 10:01:51 --> Loader Class Initialized
INFO - 2023-04-28 10:01:51 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:51 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:51 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:51 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:51 --> Total execution time: 0.0116
INFO - 2023-04-28 10:01:51 --> Config Class Initialized
INFO - 2023-04-28 10:01:51 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:51 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:51 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:51 --> URI Class Initialized
INFO - 2023-04-28 10:01:51 --> Router Class Initialized
INFO - 2023-04-28 10:01:51 --> Output Class Initialized
INFO - 2023-04-28 10:01:51 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:51 --> Input Class Initialized
INFO - 2023-04-28 10:01:51 --> Language Class Initialized
INFO - 2023-04-28 10:01:51 --> Loader Class Initialized
INFO - 2023-04-28 10:01:51 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:51 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:51 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:51 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:51 --> Model "Login_model" initialized
INFO - 2023-04-28 10:01:51 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:51 --> Total execution time: 0.0378
INFO - 2023-04-28 10:01:51 --> Config Class Initialized
INFO - 2023-04-28 10:01:51 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:51 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:51 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:51 --> URI Class Initialized
INFO - 2023-04-28 10:01:51 --> Router Class Initialized
INFO - 2023-04-28 10:01:51 --> Output Class Initialized
INFO - 2023-04-28 10:01:51 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:51 --> Input Class Initialized
INFO - 2023-04-28 10:01:51 --> Language Class Initialized
INFO - 2023-04-28 10:01:51 --> Loader Class Initialized
INFO - 2023-04-28 10:01:51 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:51 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:51 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:51 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:51 --> Total execution time: 0.0118
INFO - 2023-04-28 10:01:51 --> Config Class Initialized
INFO - 2023-04-28 10:01:51 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:51 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:51 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:51 --> URI Class Initialized
INFO - 2023-04-28 10:01:51 --> Router Class Initialized
INFO - 2023-04-28 10:01:51 --> Output Class Initialized
INFO - 2023-04-28 10:01:51 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:51 --> Input Class Initialized
INFO - 2023-04-28 10:01:51 --> Language Class Initialized
INFO - 2023-04-28 10:01:51 --> Loader Class Initialized
INFO - 2023-04-28 10:01:51 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:51 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:51 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:51 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:51 --> Total execution time: 0.0303
INFO - 2023-04-28 10:01:56 --> Config Class Initialized
INFO - 2023-04-28 10:01:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:01:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:01:56 --> Utf8 Class Initialized
INFO - 2023-04-28 10:01:56 --> URI Class Initialized
INFO - 2023-04-28 10:01:56 --> Router Class Initialized
INFO - 2023-04-28 10:01:56 --> Output Class Initialized
INFO - 2023-04-28 10:01:56 --> Security Class Initialized
DEBUG - 2023-04-28 10:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:01:56 --> Input Class Initialized
INFO - 2023-04-28 10:01:56 --> Language Class Initialized
INFO - 2023-04-28 10:01:56 --> Loader Class Initialized
INFO - 2023-04-28 10:01:56 --> Controller Class Initialized
DEBUG - 2023-04-28 10:01:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:01:56 --> Database Driver Class Initialized
INFO - 2023-04-28 10:01:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:01:56 --> Final output sent to browser
DEBUG - 2023-04-28 10:01:56 --> Total execution time: 0.0320
INFO - 2023-04-28 10:12:16 --> Config Class Initialized
INFO - 2023-04-28 10:12:16 --> Config Class Initialized
INFO - 2023-04-28 10:12:16 --> Hooks Class Initialized
INFO - 2023-04-28 10:12:16 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:12:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:12:16 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:12:16 --> Utf8 Class Initialized
INFO - 2023-04-28 10:12:16 --> Utf8 Class Initialized
INFO - 2023-04-28 10:12:16 --> URI Class Initialized
INFO - 2023-04-28 10:12:16 --> URI Class Initialized
INFO - 2023-04-28 10:12:16 --> Router Class Initialized
INFO - 2023-04-28 10:12:16 --> Router Class Initialized
INFO - 2023-04-28 10:12:16 --> Output Class Initialized
INFO - 2023-04-28 10:12:16 --> Output Class Initialized
INFO - 2023-04-28 10:12:16 --> Security Class Initialized
INFO - 2023-04-28 10:12:16 --> Security Class Initialized
DEBUG - 2023-04-28 10:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 10:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:12:16 --> Input Class Initialized
INFO - 2023-04-28 10:12:16 --> Input Class Initialized
INFO - 2023-04-28 10:12:16 --> Language Class Initialized
INFO - 2023-04-28 10:12:16 --> Language Class Initialized
INFO - 2023-04-28 10:12:16 --> Loader Class Initialized
INFO - 2023-04-28 10:12:16 --> Loader Class Initialized
INFO - 2023-04-28 10:12:16 --> Controller Class Initialized
INFO - 2023-04-28 10:12:16 --> Controller Class Initialized
DEBUG - 2023-04-28 10:12:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:12:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:12:16 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:16 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:16 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:12:16 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:12:16 --> Final output sent to browser
DEBUG - 2023-04-28 10:12:16 --> Total execution time: 0.0149
INFO - 2023-04-28 10:12:16 --> Config Class Initialized
INFO - 2023-04-28 10:12:16 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:12:16 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:12:16 --> Utf8 Class Initialized
INFO - 2023-04-28 10:12:16 --> URI Class Initialized
INFO - 2023-04-28 10:12:16 --> Router Class Initialized
INFO - 2023-04-28 10:12:16 --> Output Class Initialized
INFO - 2023-04-28 10:12:16 --> Security Class Initialized
DEBUG - 2023-04-28 10:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:12:16 --> Input Class Initialized
INFO - 2023-04-28 10:12:16 --> Language Class Initialized
INFO - 2023-04-28 10:12:16 --> Loader Class Initialized
INFO - 2023-04-28 10:12:16 --> Controller Class Initialized
DEBUG - 2023-04-28 10:12:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:12:16 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:16 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:16 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:12:16 --> Model "Login_model" initialized
INFO - 2023-04-28 10:12:16 --> Final output sent to browser
DEBUG - 2023-04-28 10:12:16 --> Total execution time: 0.0130
INFO - 2023-04-28 10:12:16 --> Final output sent to browser
DEBUG - 2023-04-28 10:12:16 --> Total execution time: 0.0748
INFO - 2023-04-28 10:12:16 --> Config Class Initialized
INFO - 2023-04-28 10:12:16 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:12:16 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:12:16 --> Utf8 Class Initialized
INFO - 2023-04-28 10:12:16 --> URI Class Initialized
INFO - 2023-04-28 10:12:16 --> Router Class Initialized
INFO - 2023-04-28 10:12:16 --> Output Class Initialized
INFO - 2023-04-28 10:12:16 --> Security Class Initialized
DEBUG - 2023-04-28 10:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:12:16 --> Input Class Initialized
INFO - 2023-04-28 10:12:16 --> Language Class Initialized
INFO - 2023-04-28 10:12:16 --> Loader Class Initialized
INFO - 2023-04-28 10:12:16 --> Controller Class Initialized
DEBUG - 2023-04-28 10:12:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:12:16 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:16 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:12:16 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:16 --> Model "Login_model" initialized
INFO - 2023-04-28 10:12:16 --> Final output sent to browser
DEBUG - 2023-04-28 10:12:16 --> Total execution time: 0.1089
INFO - 2023-04-28 10:12:29 --> Config Class Initialized
INFO - 2023-04-28 10:12:29 --> Config Class Initialized
INFO - 2023-04-28 10:12:29 --> Hooks Class Initialized
INFO - 2023-04-28 10:12:29 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:12:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:12:29 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:12:29 --> Utf8 Class Initialized
INFO - 2023-04-28 10:12:29 --> Utf8 Class Initialized
INFO - 2023-04-28 10:12:29 --> URI Class Initialized
INFO - 2023-04-28 10:12:29 --> URI Class Initialized
INFO - 2023-04-28 10:12:29 --> Router Class Initialized
INFO - 2023-04-28 10:12:29 --> Router Class Initialized
INFO - 2023-04-28 10:12:29 --> Output Class Initialized
INFO - 2023-04-28 10:12:29 --> Output Class Initialized
INFO - 2023-04-28 10:12:29 --> Security Class Initialized
INFO - 2023-04-28 10:12:29 --> Security Class Initialized
DEBUG - 2023-04-28 10:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 10:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:12:29 --> Input Class Initialized
INFO - 2023-04-28 10:12:29 --> Input Class Initialized
INFO - 2023-04-28 10:12:29 --> Language Class Initialized
INFO - 2023-04-28 10:12:29 --> Language Class Initialized
INFO - 2023-04-28 10:12:29 --> Loader Class Initialized
INFO - 2023-04-28 10:12:29 --> Loader Class Initialized
INFO - 2023-04-28 10:12:29 --> Controller Class Initialized
INFO - 2023-04-28 10:12:29 --> Controller Class Initialized
DEBUG - 2023-04-28 10:12:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:12:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:12:29 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:29 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:29 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:12:29 --> Final output sent to browser
DEBUG - 2023-04-28 10:12:29 --> Total execution time: 0.1396
INFO - 2023-04-28 10:12:29 --> Config Class Initialized
INFO - 2023-04-28 10:12:29 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:12:29 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:12:29 --> Utf8 Class Initialized
INFO - 2023-04-28 10:12:29 --> URI Class Initialized
INFO - 2023-04-28 10:12:29 --> Router Class Initialized
INFO - 2023-04-28 10:12:29 --> Output Class Initialized
INFO - 2023-04-28 10:12:29 --> Security Class Initialized
DEBUG - 2023-04-28 10:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:12:29 --> Input Class Initialized
INFO - 2023-04-28 10:12:29 --> Language Class Initialized
INFO - 2023-04-28 10:12:29 --> Loader Class Initialized
INFO - 2023-04-28 10:12:29 --> Controller Class Initialized
DEBUG - 2023-04-28 10:12:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:12:29 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:29 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:12:29 --> Final output sent to browser
DEBUG - 2023-04-28 10:12:29 --> Total execution time: 0.0121
INFO - 2023-04-28 10:12:29 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:12:29 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:29 --> Model "Login_model" initialized
INFO - 2023-04-28 10:12:29 --> Final output sent to browser
DEBUG - 2023-04-28 10:12:29 --> Total execution time: 0.2903
INFO - 2023-04-28 10:12:29 --> Config Class Initialized
INFO - 2023-04-28 10:12:29 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:12:29 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:12:29 --> Utf8 Class Initialized
INFO - 2023-04-28 10:12:29 --> URI Class Initialized
INFO - 2023-04-28 10:12:29 --> Router Class Initialized
INFO - 2023-04-28 10:12:29 --> Output Class Initialized
INFO - 2023-04-28 10:12:29 --> Security Class Initialized
DEBUG - 2023-04-28 10:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:12:29 --> Input Class Initialized
INFO - 2023-04-28 10:12:29 --> Language Class Initialized
INFO - 2023-04-28 10:12:29 --> Loader Class Initialized
INFO - 2023-04-28 10:12:29 --> Controller Class Initialized
DEBUG - 2023-04-28 10:12:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:12:29 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:30 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:12:30 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:30 --> Model "Login_model" initialized
INFO - 2023-04-28 10:12:30 --> Final output sent to browser
DEBUG - 2023-04-28 10:12:30 --> Total execution time: 0.0726
INFO - 2023-04-28 10:12:37 --> Config Class Initialized
INFO - 2023-04-28 10:12:37 --> Config Class Initialized
INFO - 2023-04-28 10:12:37 --> Hooks Class Initialized
INFO - 2023-04-28 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:12:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:12:37 --> Utf8 Class Initialized
INFO - 2023-04-28 10:12:37 --> Utf8 Class Initialized
INFO - 2023-04-28 10:12:37 --> URI Class Initialized
INFO - 2023-04-28 10:12:37 --> URI Class Initialized
INFO - 2023-04-28 10:12:37 --> Router Class Initialized
INFO - 2023-04-28 10:12:37 --> Router Class Initialized
INFO - 2023-04-28 10:12:37 --> Output Class Initialized
INFO - 2023-04-28 10:12:37 --> Output Class Initialized
INFO - 2023-04-28 10:12:37 --> Security Class Initialized
INFO - 2023-04-28 10:12:37 --> Security Class Initialized
DEBUG - 2023-04-28 10:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:12:37 --> Input Class Initialized
INFO - 2023-04-28 10:12:37 --> Input Class Initialized
INFO - 2023-04-28 10:12:37 --> Language Class Initialized
INFO - 2023-04-28 10:12:37 --> Language Class Initialized
INFO - 2023-04-28 10:12:37 --> Loader Class Initialized
INFO - 2023-04-28 10:12:37 --> Controller Class Initialized
INFO - 2023-04-28 10:12:37 --> Loader Class Initialized
DEBUG - 2023-04-28 10:12:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:12:37 --> Controller Class Initialized
DEBUG - 2023-04-28 10:12:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:12:37 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:37 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:37 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:12:37 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:12:37 --> Final output sent to browser
DEBUG - 2023-04-28 10:12:37 --> Total execution time: 0.0220
INFO - 2023-04-28 10:12:37 --> Config Class Initialized
INFO - 2023-04-28 10:12:37 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:12:37 --> Utf8 Class Initialized
INFO - 2023-04-28 10:12:37 --> URI Class Initialized
INFO - 2023-04-28 10:12:37 --> Router Class Initialized
INFO - 2023-04-28 10:12:37 --> Output Class Initialized
INFO - 2023-04-28 10:12:37 --> Security Class Initialized
DEBUG - 2023-04-28 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:12:37 --> Input Class Initialized
INFO - 2023-04-28 10:12:37 --> Language Class Initialized
INFO - 2023-04-28 10:12:37 --> Loader Class Initialized
INFO - 2023-04-28 10:12:37 --> Controller Class Initialized
DEBUG - 2023-04-28 10:12:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:12:37 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:37 --> Model "Login_model" initialized
INFO - 2023-04-28 10:12:37 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:12:37 --> Final output sent to browser
INFO - 2023-04-28 10:12:37 --> Final output sent to browser
DEBUG - 2023-04-28 10:12:37 --> Total execution time: 0.2345
DEBUG - 2023-04-28 10:12:37 --> Total execution time: 0.1717
INFO - 2023-04-28 10:12:37 --> Config Class Initialized
INFO - 2023-04-28 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:12:37 --> Utf8 Class Initialized
INFO - 2023-04-28 10:12:37 --> URI Class Initialized
INFO - 2023-04-28 10:12:37 --> Router Class Initialized
INFO - 2023-04-28 10:12:37 --> Output Class Initialized
INFO - 2023-04-28 10:12:37 --> Security Class Initialized
DEBUG - 2023-04-28 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:12:37 --> Input Class Initialized
INFO - 2023-04-28 10:12:37 --> Language Class Initialized
INFO - 2023-04-28 10:12:37 --> Loader Class Initialized
INFO - 2023-04-28 10:12:37 --> Controller Class Initialized
DEBUG - 2023-04-28 10:12:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:12:37 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:37 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:12:37 --> Database Driver Class Initialized
INFO - 2023-04-28 10:12:37 --> Model "Login_model" initialized
INFO - 2023-04-28 10:12:37 --> Final output sent to browser
DEBUG - 2023-04-28 10:12:37 --> Total execution time: 0.1175
INFO - 2023-04-28 10:13:36 --> Config Class Initialized
INFO - 2023-04-28 10:13:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:36 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:36 --> URI Class Initialized
INFO - 2023-04-28 10:13:36 --> Router Class Initialized
INFO - 2023-04-28 10:13:36 --> Output Class Initialized
INFO - 2023-04-28 10:13:36 --> Config Class Initialized
INFO - 2023-04-28 10:13:36 --> Hooks Class Initialized
INFO - 2023-04-28 10:13:36 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:36 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:36 --> URI Class Initialized
INFO - 2023-04-28 10:13:36 --> Input Class Initialized
INFO - 2023-04-28 10:13:36 --> Router Class Initialized
INFO - 2023-04-28 10:13:36 --> Language Class Initialized
INFO - 2023-04-28 10:13:36 --> Output Class Initialized
INFO - 2023-04-28 10:13:36 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:36 --> Input Class Initialized
INFO - 2023-04-28 10:13:36 --> Language Class Initialized
INFO - 2023-04-28 10:13:36 --> Loader Class Initialized
INFO - 2023-04-28 10:13:36 --> Loader Class Initialized
INFO - 2023-04-28 10:13:36 --> Controller Class Initialized
INFO - 2023-04-28 10:13:36 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:13:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:36 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:36 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:36 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:36 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:36 --> Total execution time: 0.1086
INFO - 2023-04-28 10:13:36 --> Config Class Initialized
INFO - 2023-04-28 10:13:36 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:36 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:36 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:36 --> URI Class Initialized
INFO - 2023-04-28 10:13:36 --> Router Class Initialized
INFO - 2023-04-28 10:13:36 --> Output Class Initialized
INFO - 2023-04-28 10:13:36 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:36 --> Input Class Initialized
INFO - 2023-04-28 10:13:36 --> Language Class Initialized
INFO - 2023-04-28 10:13:36 --> Loader Class Initialized
INFO - 2023-04-28 10:13:36 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:36 --> Model "Login_model" initialized
INFO - 2023-04-28 10:13:36 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:36 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:36 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:36 --> Total execution time: 0.0152
INFO - 2023-04-28 10:13:37 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:37 --> Total execution time: 0.1651
INFO - 2023-04-28 10:13:37 --> Config Class Initialized
INFO - 2023-04-28 10:13:37 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:37 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:37 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:37 --> URI Class Initialized
INFO - 2023-04-28 10:13:37 --> Router Class Initialized
INFO - 2023-04-28 10:13:37 --> Output Class Initialized
INFO - 2023-04-28 10:13:37 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:37 --> Input Class Initialized
INFO - 2023-04-28 10:13:37 --> Language Class Initialized
INFO - 2023-04-28 10:13:37 --> Loader Class Initialized
INFO - 2023-04-28 10:13:37 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:37 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:37 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:37 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:37 --> Model "Login_model" initialized
INFO - 2023-04-28 10:13:37 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:37 --> Total execution time: 0.0809
INFO - 2023-04-28 10:13:45 --> Config Class Initialized
INFO - 2023-04-28 10:13:45 --> Config Class Initialized
INFO - 2023-04-28 10:13:45 --> Hooks Class Initialized
INFO - 2023-04-28 10:13:45 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:13:45 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:45 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:45 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:45 --> URI Class Initialized
INFO - 2023-04-28 10:13:45 --> URI Class Initialized
INFO - 2023-04-28 10:13:45 --> Router Class Initialized
INFO - 2023-04-28 10:13:45 --> Output Class Initialized
INFO - 2023-04-28 10:13:45 --> Router Class Initialized
INFO - 2023-04-28 10:13:45 --> Security Class Initialized
INFO - 2023-04-28 10:13:45 --> Output Class Initialized
INFO - 2023-04-28 10:13:45 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 10:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:45 --> Input Class Initialized
INFO - 2023-04-28 10:13:45 --> Input Class Initialized
INFO - 2023-04-28 10:13:45 --> Language Class Initialized
INFO - 2023-04-28 10:13:45 --> Language Class Initialized
INFO - 2023-04-28 10:13:45 --> Loader Class Initialized
INFO - 2023-04-28 10:13:45 --> Loader Class Initialized
INFO - 2023-04-28 10:13:45 --> Controller Class Initialized
INFO - 2023-04-28 10:13:45 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:13:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:45 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:45 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:45 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:46 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:46 --> Final output sent to browser
INFO - 2023-04-28 10:13:46 --> Database Driver Class Initialized
DEBUG - 2023-04-28 10:13:46 --> Total execution time: 0.0321
INFO - 2023-04-28 10:13:46 --> Config Class Initialized
INFO - 2023-04-28 10:13:46 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:46 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:46 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:46 --> URI Class Initialized
INFO - 2023-04-28 10:13:46 --> Router Class Initialized
INFO - 2023-04-28 10:13:46 --> Output Class Initialized
INFO - 2023-04-28 10:13:46 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:46 --> Input Class Initialized
INFO - 2023-04-28 10:13:46 --> Language Class Initialized
INFO - 2023-04-28 10:13:46 --> Loader Class Initialized
INFO - 2023-04-28 10:13:46 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:46 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:46 --> Model "Login_model" initialized
INFO - 2023-04-28 10:13:46 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:46 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:46 --> Total execution time: 0.0140
INFO - 2023-04-28 10:13:46 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:46 --> Total execution time: 0.1658
INFO - 2023-04-28 10:13:46 --> Config Class Initialized
INFO - 2023-04-28 10:13:46 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:46 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:46 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:46 --> URI Class Initialized
INFO - 2023-04-28 10:13:46 --> Router Class Initialized
INFO - 2023-04-28 10:13:46 --> Output Class Initialized
INFO - 2023-04-28 10:13:46 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:46 --> Input Class Initialized
INFO - 2023-04-28 10:13:46 --> Language Class Initialized
INFO - 2023-04-28 10:13:46 --> Loader Class Initialized
INFO - 2023-04-28 10:13:46 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:46 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:46 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:46 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:46 --> Model "Login_model" initialized
INFO - 2023-04-28 10:13:46 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:46 --> Total execution time: 0.0920
INFO - 2023-04-28 10:13:53 --> Config Class Initialized
INFO - 2023-04-28 10:13:53 --> Config Class Initialized
INFO - 2023-04-28 10:13:53 --> Hooks Class Initialized
INFO - 2023-04-28 10:13:53 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:13:53 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:53 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:53 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:53 --> URI Class Initialized
INFO - 2023-04-28 10:13:53 --> URI Class Initialized
INFO - 2023-04-28 10:13:53 --> Router Class Initialized
INFO - 2023-04-28 10:13:53 --> Router Class Initialized
INFO - 2023-04-28 10:13:53 --> Output Class Initialized
INFO - 2023-04-28 10:13:53 --> Output Class Initialized
INFO - 2023-04-28 10:13:53 --> Security Class Initialized
INFO - 2023-04-28 10:13:53 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 10:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:53 --> Input Class Initialized
INFO - 2023-04-28 10:13:53 --> Input Class Initialized
INFO - 2023-04-28 10:13:53 --> Language Class Initialized
INFO - 2023-04-28 10:13:53 --> Language Class Initialized
INFO - 2023-04-28 10:13:53 --> Loader Class Initialized
INFO - 2023-04-28 10:13:53 --> Loader Class Initialized
INFO - 2023-04-28 10:13:53 --> Controller Class Initialized
INFO - 2023-04-28 10:13:53 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:13:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:53 --> Final output sent to browser
INFO - 2023-04-28 10:13:53 --> Database Driver Class Initialized
DEBUG - 2023-04-28 10:13:53 --> Total execution time: 0.0049
INFO - 2023-04-28 10:13:53 --> Config Class Initialized
INFO - 2023-04-28 10:13:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:53 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:53 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:53 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:53 --> URI Class Initialized
INFO - 2023-04-28 10:13:53 --> Router Class Initialized
INFO - 2023-04-28 10:13:53 --> Output Class Initialized
INFO - 2023-04-28 10:13:53 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:53 --> Input Class Initialized
INFO - 2023-04-28 10:13:53 --> Language Class Initialized
INFO - 2023-04-28 10:13:53 --> Loader Class Initialized
INFO - 2023-04-28 10:13:53 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:53 --> Final output sent to browser
INFO - 2023-04-28 10:13:53 --> Database Driver Class Initialized
DEBUG - 2023-04-28 10:13:53 --> Total execution time: 0.0809
INFO - 2023-04-28 10:13:53 --> Config Class Initialized
INFO - 2023-04-28 10:13:53 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:53 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:53 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:53 --> URI Class Initialized
INFO - 2023-04-28 10:13:53 --> Router Class Initialized
INFO - 2023-04-28 10:13:53 --> Output Class Initialized
INFO - 2023-04-28 10:13:53 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:53 --> Input Class Initialized
INFO - 2023-04-28 10:13:53 --> Language Class Initialized
INFO - 2023-04-28 10:13:53 --> Loader Class Initialized
INFO - 2023-04-28 10:13:53 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:53 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:53 --> Model "Login_model" initialized
INFO - 2023-04-28 10:13:53 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:53 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:53 --> Total execution time: 0.0140
INFO - 2023-04-28 10:13:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:53 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:53 --> Total execution time: 0.0711
INFO - 2023-04-28 10:13:56 --> Config Class Initialized
INFO - 2023-04-28 10:13:56 --> Config Class Initialized
INFO - 2023-04-28 10:13:56 --> Hooks Class Initialized
INFO - 2023-04-28 10:13:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:13:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:56 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:56 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:56 --> URI Class Initialized
INFO - 2023-04-28 10:13:56 --> URI Class Initialized
INFO - 2023-04-28 10:13:56 --> Router Class Initialized
INFO - 2023-04-28 10:13:56 --> Router Class Initialized
INFO - 2023-04-28 10:13:56 --> Output Class Initialized
INFO - 2023-04-28 10:13:56 --> Output Class Initialized
INFO - 2023-04-28 10:13:56 --> Security Class Initialized
INFO - 2023-04-28 10:13:56 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 10:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:56 --> Input Class Initialized
INFO - 2023-04-28 10:13:56 --> Input Class Initialized
INFO - 2023-04-28 10:13:56 --> Language Class Initialized
INFO - 2023-04-28 10:13:56 --> Language Class Initialized
INFO - 2023-04-28 10:13:56 --> Loader Class Initialized
INFO - 2023-04-28 10:13:56 --> Loader Class Initialized
INFO - 2023-04-28 10:13:56 --> Controller Class Initialized
INFO - 2023-04-28 10:13:56 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:13:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:56 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:56 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:56 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:56 --> Total execution time: 0.0192
INFO - 2023-04-28 10:13:56 --> Config Class Initialized
INFO - 2023-04-28 10:13:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:56 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:56 --> URI Class Initialized
INFO - 2023-04-28 10:13:56 --> Router Class Initialized
INFO - 2023-04-28 10:13:56 --> Output Class Initialized
INFO - 2023-04-28 10:13:56 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:56 --> Input Class Initialized
INFO - 2023-04-28 10:13:56 --> Language Class Initialized
INFO - 2023-04-28 10:13:56 --> Loader Class Initialized
INFO - 2023-04-28 10:13:56 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:56 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:56 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:56 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:56 --> Total execution time: 0.0112
INFO - 2023-04-28 10:13:56 --> Model "Login_model" initialized
INFO - 2023-04-28 10:13:56 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:56 --> Total execution time: 0.1185
INFO - 2023-04-28 10:13:56 --> Config Class Initialized
INFO - 2023-04-28 10:13:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:56 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:56 --> URI Class Initialized
INFO - 2023-04-28 10:13:56 --> Router Class Initialized
INFO - 2023-04-28 10:13:56 --> Output Class Initialized
INFO - 2023-04-28 10:13:56 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:56 --> Input Class Initialized
INFO - 2023-04-28 10:13:56 --> Language Class Initialized
INFO - 2023-04-28 10:13:56 --> Loader Class Initialized
INFO - 2023-04-28 10:13:56 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:56 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:56 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:56 --> Model "Login_model" initialized
INFO - 2023-04-28 10:13:56 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:56 --> Total execution time: 0.0657
INFO - 2023-04-28 10:13:59 --> Config Class Initialized
INFO - 2023-04-28 10:13:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:59 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:59 --> URI Class Initialized
INFO - 2023-04-28 10:13:59 --> Router Class Initialized
INFO - 2023-04-28 10:13:59 --> Output Class Initialized
INFO - 2023-04-28 10:13:59 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:59 --> Input Class Initialized
INFO - 2023-04-28 10:13:59 --> Language Class Initialized
INFO - 2023-04-28 10:13:59 --> Loader Class Initialized
INFO - 2023-04-28 10:13:59 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:59 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:59 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:59 --> Total execution time: 0.0154
INFO - 2023-04-28 10:13:59 --> Config Class Initialized
INFO - 2023-04-28 10:13:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:59 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:59 --> URI Class Initialized
INFO - 2023-04-28 10:13:59 --> Router Class Initialized
INFO - 2023-04-28 10:13:59 --> Output Class Initialized
INFO - 2023-04-28 10:13:59 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:59 --> Input Class Initialized
INFO - 2023-04-28 10:13:59 --> Language Class Initialized
INFO - 2023-04-28 10:13:59 --> Loader Class Initialized
INFO - 2023-04-28 10:13:59 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:59 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:59 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:59 --> Total execution time: 0.0122
INFO - 2023-04-28 10:13:59 --> Config Class Initialized
INFO - 2023-04-28 10:13:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:59 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:59 --> URI Class Initialized
INFO - 2023-04-28 10:13:59 --> Router Class Initialized
INFO - 2023-04-28 10:13:59 --> Output Class Initialized
INFO - 2023-04-28 10:13:59 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:59 --> Input Class Initialized
INFO - 2023-04-28 10:13:59 --> Language Class Initialized
INFO - 2023-04-28 10:13:59 --> Loader Class Initialized
INFO - 2023-04-28 10:13:59 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:59 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:59 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:59 --> Total execution time: 0.0505
INFO - 2023-04-28 10:13:59 --> Config Class Initialized
INFO - 2023-04-28 10:13:59 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:13:59 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:13:59 --> Utf8 Class Initialized
INFO - 2023-04-28 10:13:59 --> URI Class Initialized
INFO - 2023-04-28 10:13:59 --> Router Class Initialized
INFO - 2023-04-28 10:13:59 --> Output Class Initialized
INFO - 2023-04-28 10:13:59 --> Security Class Initialized
DEBUG - 2023-04-28 10:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:13:59 --> Input Class Initialized
INFO - 2023-04-28 10:13:59 --> Language Class Initialized
INFO - 2023-04-28 10:13:59 --> Loader Class Initialized
INFO - 2023-04-28 10:13:59 --> Controller Class Initialized
DEBUG - 2023-04-28 10:13:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:13:59 --> Database Driver Class Initialized
INFO - 2023-04-28 10:13:59 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:13:59 --> Final output sent to browser
DEBUG - 2023-04-28 10:13:59 --> Total execution time: 0.0111
INFO - 2023-04-28 10:14:35 --> Config Class Initialized
INFO - 2023-04-28 10:14:35 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:14:35 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:14:35 --> Utf8 Class Initialized
INFO - 2023-04-28 10:14:35 --> URI Class Initialized
INFO - 2023-04-28 10:14:35 --> Router Class Initialized
INFO - 2023-04-28 10:14:35 --> Output Class Initialized
INFO - 2023-04-28 10:14:35 --> Security Class Initialized
DEBUG - 2023-04-28 10:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:14:35 --> Input Class Initialized
INFO - 2023-04-28 10:14:35 --> Language Class Initialized
INFO - 2023-04-28 10:14:35 --> Loader Class Initialized
INFO - 2023-04-28 10:14:35 --> Controller Class Initialized
DEBUG - 2023-04-28 10:14:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:14:35 --> Database Driver Class Initialized
INFO - 2023-04-28 10:14:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:14:35 --> Final output sent to browser
DEBUG - 2023-04-28 10:14:35 --> Total execution time: 0.0177
INFO - 2023-04-28 10:14:35 --> Config Class Initialized
INFO - 2023-04-28 10:14:35 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:14:35 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:14:35 --> Utf8 Class Initialized
INFO - 2023-04-28 10:14:35 --> URI Class Initialized
INFO - 2023-04-28 10:14:35 --> Router Class Initialized
INFO - 2023-04-28 10:14:35 --> Output Class Initialized
INFO - 2023-04-28 10:14:35 --> Security Class Initialized
DEBUG - 2023-04-28 10:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:14:35 --> Input Class Initialized
INFO - 2023-04-28 10:14:35 --> Language Class Initialized
INFO - 2023-04-28 10:14:35 --> Loader Class Initialized
INFO - 2023-04-28 10:14:35 --> Controller Class Initialized
DEBUG - 2023-04-28 10:14:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:14:35 --> Database Driver Class Initialized
INFO - 2023-04-28 10:14:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:14:35 --> Database Driver Class Initialized
INFO - 2023-04-28 10:14:35 --> Model "Login_model" initialized
INFO - 2023-04-28 10:14:35 --> Final output sent to browser
DEBUG - 2023-04-28 10:14:35 --> Total execution time: 0.0449
INFO - 2023-04-28 10:14:35 --> Config Class Initialized
INFO - 2023-04-28 10:14:35 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:14:35 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:14:35 --> Utf8 Class Initialized
INFO - 2023-04-28 10:14:35 --> URI Class Initialized
INFO - 2023-04-28 10:14:35 --> Router Class Initialized
INFO - 2023-04-28 10:14:35 --> Output Class Initialized
INFO - 2023-04-28 10:14:35 --> Security Class Initialized
DEBUG - 2023-04-28 10:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:14:35 --> Input Class Initialized
INFO - 2023-04-28 10:14:35 --> Language Class Initialized
INFO - 2023-04-28 10:14:35 --> Loader Class Initialized
INFO - 2023-04-28 10:14:35 --> Controller Class Initialized
DEBUG - 2023-04-28 10:14:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:14:35 --> Database Driver Class Initialized
INFO - 2023-04-28 10:14:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:14:35 --> Final output sent to browser
DEBUG - 2023-04-28 10:14:35 --> Total execution time: 0.0149
INFO - 2023-04-28 10:14:35 --> Config Class Initialized
INFO - 2023-04-28 10:14:35 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:14:35 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:14:35 --> Utf8 Class Initialized
INFO - 2023-04-28 10:14:35 --> URI Class Initialized
INFO - 2023-04-28 10:14:35 --> Router Class Initialized
INFO - 2023-04-28 10:14:35 --> Output Class Initialized
INFO - 2023-04-28 10:14:35 --> Security Class Initialized
DEBUG - 2023-04-28 10:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:14:35 --> Input Class Initialized
INFO - 2023-04-28 10:14:35 --> Language Class Initialized
INFO - 2023-04-28 10:14:35 --> Loader Class Initialized
INFO - 2023-04-28 10:14:35 --> Controller Class Initialized
DEBUG - 2023-04-28 10:14:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:14:35 --> Database Driver Class Initialized
INFO - 2023-04-28 10:14:35 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:14:35 --> Final output sent to browser
DEBUG - 2023-04-28 10:14:35 --> Total execution time: 0.0139
INFO - 2023-04-28 10:14:40 --> Config Class Initialized
INFO - 2023-04-28 10:14:40 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:14:40 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:14:40 --> Utf8 Class Initialized
INFO - 2023-04-28 10:14:40 --> URI Class Initialized
INFO - 2023-04-28 10:14:40 --> Router Class Initialized
INFO - 2023-04-28 10:14:40 --> Output Class Initialized
INFO - 2023-04-28 10:14:40 --> Security Class Initialized
DEBUG - 2023-04-28 10:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:14:40 --> Input Class Initialized
INFO - 2023-04-28 10:14:40 --> Language Class Initialized
INFO - 2023-04-28 10:14:40 --> Loader Class Initialized
INFO - 2023-04-28 10:14:40 --> Controller Class Initialized
DEBUG - 2023-04-28 10:14:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:14:40 --> Database Driver Class Initialized
INFO - 2023-04-28 10:14:40 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:14:40 --> Final output sent to browser
DEBUG - 2023-04-28 10:14:40 --> Total execution time: 0.0171
INFO - 2023-04-28 10:15:31 --> Config Class Initialized
INFO - 2023-04-28 10:15:31 --> Config Class Initialized
INFO - 2023-04-28 10:15:31 --> Hooks Class Initialized
INFO - 2023-04-28 10:15:31 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:15:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:15:31 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:15:31 --> Utf8 Class Initialized
INFO - 2023-04-28 10:15:31 --> URI Class Initialized
INFO - 2023-04-28 10:15:31 --> Router Class Initialized
INFO - 2023-04-28 10:15:31 --> Output Class Initialized
INFO - 2023-04-28 10:15:31 --> Security Class Initialized
DEBUG - 2023-04-28 10:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:15:31 --> Input Class Initialized
INFO - 2023-04-28 10:15:31 --> Language Class Initialized
INFO - 2023-04-28 10:15:31 --> Utf8 Class Initialized
INFO - 2023-04-28 10:15:31 --> Loader Class Initialized
INFO - 2023-04-28 10:15:31 --> Controller Class Initialized
DEBUG - 2023-04-28 10:15:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:15:31 --> Database Driver Class Initialized
INFO - 2023-04-28 10:15:31 --> URI Class Initialized
INFO - 2023-04-28 10:15:31 --> Router Class Initialized
INFO - 2023-04-28 10:15:31 --> Output Class Initialized
INFO - 2023-04-28 10:15:31 --> Security Class Initialized
DEBUG - 2023-04-28 10:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:15:31 --> Input Class Initialized
INFO - 2023-04-28 10:15:31 --> Language Class Initialized
INFO - 2023-04-28 10:15:31 --> Loader Class Initialized
INFO - 2023-04-28 10:15:31 --> Controller Class Initialized
DEBUG - 2023-04-28 10:15:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:15:31 --> Database Driver Class Initialized
INFO - 2023-04-28 10:15:31 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:15:31 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:15:31 --> Final output sent to browser
DEBUG - 2023-04-28 10:15:31 --> Total execution time: 0.0208
INFO - 2023-04-28 10:15:31 --> Config Class Initialized
INFO - 2023-04-28 10:15:31 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:15:31 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:15:31 --> Utf8 Class Initialized
INFO - 2023-04-28 10:15:31 --> URI Class Initialized
INFO - 2023-04-28 10:15:31 --> Router Class Initialized
INFO - 2023-04-28 10:15:31 --> Output Class Initialized
INFO - 2023-04-28 10:15:31 --> Security Class Initialized
DEBUG - 2023-04-28 10:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:15:31 --> Input Class Initialized
INFO - 2023-04-28 10:15:31 --> Language Class Initialized
INFO - 2023-04-28 10:15:31 --> Loader Class Initialized
INFO - 2023-04-28 10:15:31 --> Controller Class Initialized
DEBUG - 2023-04-28 10:15:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:15:31 --> Database Driver Class Initialized
INFO - 2023-04-28 10:15:31 --> Database Driver Class Initialized
INFO - 2023-04-28 10:15:31 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:15:31 --> Model "Login_model" initialized
INFO - 2023-04-28 10:15:31 --> Final output sent to browser
DEBUG - 2023-04-28 10:15:31 --> Total execution time: 0.0134
INFO - 2023-04-28 10:15:31 --> Final output sent to browser
DEBUG - 2023-04-28 10:15:31 --> Total execution time: 0.0833
INFO - 2023-04-28 10:15:31 --> Config Class Initialized
INFO - 2023-04-28 10:15:31 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:15:31 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:15:31 --> Utf8 Class Initialized
INFO - 2023-04-28 10:15:31 --> URI Class Initialized
INFO - 2023-04-28 10:15:31 --> Router Class Initialized
INFO - 2023-04-28 10:15:31 --> Output Class Initialized
INFO - 2023-04-28 10:15:31 --> Security Class Initialized
DEBUG - 2023-04-28 10:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:15:31 --> Input Class Initialized
INFO - 2023-04-28 10:15:31 --> Language Class Initialized
INFO - 2023-04-28 10:15:31 --> Loader Class Initialized
INFO - 2023-04-28 10:15:31 --> Controller Class Initialized
DEBUG - 2023-04-28 10:15:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:15:31 --> Database Driver Class Initialized
INFO - 2023-04-28 10:15:31 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:15:31 --> Database Driver Class Initialized
INFO - 2023-04-28 10:15:31 --> Model "Login_model" initialized
INFO - 2023-04-28 10:15:31 --> Final output sent to browser
DEBUG - 2023-04-28 10:15:31 --> Total execution time: 0.1156
INFO - 2023-04-28 10:15:39 --> Config Class Initialized
INFO - 2023-04-28 10:15:39 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:15:39 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:15:39 --> Utf8 Class Initialized
INFO - 2023-04-28 10:15:39 --> URI Class Initialized
INFO - 2023-04-28 10:15:39 --> Router Class Initialized
INFO - 2023-04-28 10:15:39 --> Output Class Initialized
INFO - 2023-04-28 10:15:39 --> Security Class Initialized
DEBUG - 2023-04-28 10:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:15:39 --> Input Class Initialized
INFO - 2023-04-28 10:15:39 --> Language Class Initialized
INFO - 2023-04-28 10:15:39 --> Loader Class Initialized
INFO - 2023-04-28 10:15:39 --> Controller Class Initialized
DEBUG - 2023-04-28 10:15:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:15:39 --> Database Driver Class Initialized
INFO - 2023-04-28 10:15:39 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:15:39 --> Final output sent to browser
DEBUG - 2023-04-28 10:15:39 --> Total execution time: 0.0174
INFO - 2023-04-28 10:15:39 --> Config Class Initialized
INFO - 2023-04-28 10:15:39 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:15:39 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:15:39 --> Utf8 Class Initialized
INFO - 2023-04-28 10:15:39 --> URI Class Initialized
INFO - 2023-04-28 10:15:39 --> Router Class Initialized
INFO - 2023-04-28 10:15:39 --> Output Class Initialized
INFO - 2023-04-28 10:15:39 --> Security Class Initialized
DEBUG - 2023-04-28 10:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:15:39 --> Input Class Initialized
INFO - 2023-04-28 10:15:39 --> Language Class Initialized
INFO - 2023-04-28 10:15:39 --> Loader Class Initialized
INFO - 2023-04-28 10:15:39 --> Controller Class Initialized
DEBUG - 2023-04-28 10:15:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:15:39 --> Database Driver Class Initialized
INFO - 2023-04-28 10:15:39 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:15:39 --> Final output sent to browser
DEBUG - 2023-04-28 10:15:39 --> Total execution time: 0.0125
INFO - 2023-04-28 10:15:39 --> Config Class Initialized
INFO - 2023-04-28 10:15:39 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:15:39 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:15:39 --> Utf8 Class Initialized
INFO - 2023-04-28 10:15:39 --> URI Class Initialized
INFO - 2023-04-28 10:15:39 --> Router Class Initialized
INFO - 2023-04-28 10:15:39 --> Output Class Initialized
INFO - 2023-04-28 10:15:39 --> Security Class Initialized
DEBUG - 2023-04-28 10:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:15:39 --> Input Class Initialized
INFO - 2023-04-28 10:15:39 --> Language Class Initialized
INFO - 2023-04-28 10:15:39 --> Loader Class Initialized
INFO - 2023-04-28 10:15:39 --> Controller Class Initialized
DEBUG - 2023-04-28 10:15:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:15:39 --> Database Driver Class Initialized
INFO - 2023-04-28 10:15:39 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:15:39 --> Final output sent to browser
DEBUG - 2023-04-28 10:15:39 --> Total execution time: 0.0528
INFO - 2023-04-28 10:15:39 --> Config Class Initialized
INFO - 2023-04-28 10:15:39 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:15:39 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:15:39 --> Utf8 Class Initialized
INFO - 2023-04-28 10:15:39 --> URI Class Initialized
INFO - 2023-04-28 10:15:39 --> Router Class Initialized
INFO - 2023-04-28 10:15:39 --> Output Class Initialized
INFO - 2023-04-28 10:15:39 --> Security Class Initialized
DEBUG - 2023-04-28 10:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:15:39 --> Input Class Initialized
INFO - 2023-04-28 10:15:39 --> Language Class Initialized
INFO - 2023-04-28 10:15:39 --> Loader Class Initialized
INFO - 2023-04-28 10:15:39 --> Controller Class Initialized
DEBUG - 2023-04-28 10:15:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:15:39 --> Database Driver Class Initialized
INFO - 2023-04-28 10:15:39 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:15:39 --> Final output sent to browser
DEBUG - 2023-04-28 10:15:39 --> Total execution time: 0.0543
INFO - 2023-04-28 10:16:46 --> Config Class Initialized
INFO - 2023-04-28 10:16:46 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:16:46 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:16:46 --> Utf8 Class Initialized
INFO - 2023-04-28 10:16:46 --> URI Class Initialized
INFO - 2023-04-28 10:16:46 --> Router Class Initialized
INFO - 2023-04-28 10:16:46 --> Output Class Initialized
INFO - 2023-04-28 10:16:46 --> Security Class Initialized
DEBUG - 2023-04-28 10:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:16:46 --> Input Class Initialized
INFO - 2023-04-28 10:16:46 --> Language Class Initialized
INFO - 2023-04-28 10:16:46 --> Loader Class Initialized
INFO - 2023-04-28 10:16:46 --> Controller Class Initialized
DEBUG - 2023-04-28 10:16:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:16:46 --> Database Driver Class Initialized
INFO - 2023-04-28 10:16:46 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:16:46 --> Final output sent to browser
DEBUG - 2023-04-28 10:16:46 --> Total execution time: 0.0541
INFO - 2023-04-28 10:16:46 --> Config Class Initialized
INFO - 2023-04-28 10:16:46 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:16:46 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:16:46 --> Utf8 Class Initialized
INFO - 2023-04-28 10:16:46 --> URI Class Initialized
INFO - 2023-04-28 10:16:46 --> Router Class Initialized
INFO - 2023-04-28 10:16:46 --> Output Class Initialized
INFO - 2023-04-28 10:16:46 --> Security Class Initialized
DEBUG - 2023-04-28 10:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:16:46 --> Input Class Initialized
INFO - 2023-04-28 10:16:46 --> Language Class Initialized
INFO - 2023-04-28 10:16:46 --> Loader Class Initialized
INFO - 2023-04-28 10:16:46 --> Controller Class Initialized
DEBUG - 2023-04-28 10:16:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:16:46 --> Database Driver Class Initialized
INFO - 2023-04-28 10:16:46 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:16:46 --> Database Driver Class Initialized
INFO - 2023-04-28 10:16:46 --> Model "Login_model" initialized
INFO - 2023-04-28 10:16:46 --> Final output sent to browser
DEBUG - 2023-04-28 10:16:46 --> Total execution time: 0.0517
INFO - 2023-04-28 10:16:46 --> Config Class Initialized
INFO - 2023-04-28 10:16:46 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:16:46 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:16:46 --> Utf8 Class Initialized
INFO - 2023-04-28 10:16:46 --> URI Class Initialized
INFO - 2023-04-28 10:16:46 --> Router Class Initialized
INFO - 2023-04-28 10:16:46 --> Output Class Initialized
INFO - 2023-04-28 10:16:46 --> Security Class Initialized
DEBUG - 2023-04-28 10:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:16:46 --> Input Class Initialized
INFO - 2023-04-28 10:16:46 --> Language Class Initialized
INFO - 2023-04-28 10:16:46 --> Loader Class Initialized
INFO - 2023-04-28 10:16:46 --> Controller Class Initialized
DEBUG - 2023-04-28 10:16:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:16:46 --> Database Driver Class Initialized
INFO - 2023-04-28 10:16:46 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:16:46 --> Final output sent to browser
DEBUG - 2023-04-28 10:16:46 --> Total execution time: 0.0144
INFO - 2023-04-28 10:16:46 --> Config Class Initialized
INFO - 2023-04-28 10:16:46 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:16:46 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:16:46 --> Utf8 Class Initialized
INFO - 2023-04-28 10:16:46 --> URI Class Initialized
INFO - 2023-04-28 10:16:46 --> Router Class Initialized
INFO - 2023-04-28 10:16:46 --> Output Class Initialized
INFO - 2023-04-28 10:16:46 --> Security Class Initialized
DEBUG - 2023-04-28 10:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:16:46 --> Input Class Initialized
INFO - 2023-04-28 10:16:46 --> Language Class Initialized
INFO - 2023-04-28 10:16:46 --> Loader Class Initialized
INFO - 2023-04-28 10:16:46 --> Controller Class Initialized
DEBUG - 2023-04-28 10:16:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:16:46 --> Database Driver Class Initialized
INFO - 2023-04-28 10:16:46 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:16:46 --> Final output sent to browser
DEBUG - 2023-04-28 10:16:46 --> Total execution time: 0.0124
INFO - 2023-04-28 10:16:51 --> Config Class Initialized
INFO - 2023-04-28 10:16:51 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:16:51 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:16:51 --> Utf8 Class Initialized
INFO - 2023-04-28 10:16:51 --> URI Class Initialized
INFO - 2023-04-28 10:16:51 --> Router Class Initialized
INFO - 2023-04-28 10:16:51 --> Output Class Initialized
INFO - 2023-04-28 10:16:51 --> Security Class Initialized
DEBUG - 2023-04-28 10:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:16:51 --> Input Class Initialized
INFO - 2023-04-28 10:16:51 --> Language Class Initialized
INFO - 2023-04-28 10:16:51 --> Loader Class Initialized
INFO - 2023-04-28 10:16:51 --> Controller Class Initialized
DEBUG - 2023-04-28 10:16:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:16:51 --> Database Driver Class Initialized
INFO - 2023-04-28 10:16:51 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:16:51 --> Final output sent to browser
DEBUG - 2023-04-28 10:16:51 --> Total execution time: 0.0263
INFO - 2023-04-28 10:17:39 --> Config Class Initialized
INFO - 2023-04-28 10:17:40 --> Hooks Class Initialized
INFO - 2023-04-28 10:17:40 --> Config Class Initialized
DEBUG - 2023-04-28 10:17:40 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:17:40 --> Hooks Class Initialized
INFO - 2023-04-28 10:17:40 --> Utf8 Class Initialized
DEBUG - 2023-04-28 10:17:40 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:17:40 --> URI Class Initialized
INFO - 2023-04-28 10:17:40 --> Utf8 Class Initialized
INFO - 2023-04-28 10:17:40 --> Router Class Initialized
INFO - 2023-04-28 10:17:40 --> URI Class Initialized
INFO - 2023-04-28 10:17:40 --> Output Class Initialized
INFO - 2023-04-28 10:17:40 --> Router Class Initialized
INFO - 2023-04-28 10:17:40 --> Security Class Initialized
INFO - 2023-04-28 10:17:40 --> Output Class Initialized
DEBUG - 2023-04-28 10:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:17:40 --> Security Class Initialized
INFO - 2023-04-28 10:17:40 --> Input Class Initialized
DEBUG - 2023-04-28 10:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:17:40 --> Language Class Initialized
INFO - 2023-04-28 10:17:40 --> Input Class Initialized
INFO - 2023-04-28 10:17:40 --> Language Class Initialized
INFO - 2023-04-28 10:17:40 --> Loader Class Initialized
INFO - 2023-04-28 10:17:40 --> Loader Class Initialized
INFO - 2023-04-28 10:17:40 --> Controller Class Initialized
INFO - 2023-04-28 10:17:40 --> Controller Class Initialized
DEBUG - 2023-04-28 10:17:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:17:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:17:40 --> Database Driver Class Initialized
INFO - 2023-04-28 10:17:40 --> Database Driver Class Initialized
INFO - 2023-04-28 10:17:40 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:17:40 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:17:40 --> Final output sent to browser
DEBUG - 2023-04-28 10:17:40 --> Total execution time: 0.1057
INFO - 2023-04-28 10:17:40 --> Config Class Initialized
INFO - 2023-04-28 10:17:40 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:17:40 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:17:40 --> Utf8 Class Initialized
INFO - 2023-04-28 10:17:40 --> URI Class Initialized
INFO - 2023-04-28 10:17:40 --> Router Class Initialized
INFO - 2023-04-28 10:17:40 --> Output Class Initialized
INFO - 2023-04-28 10:17:40 --> Security Class Initialized
DEBUG - 2023-04-28 10:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:17:40 --> Input Class Initialized
INFO - 2023-04-28 10:17:40 --> Language Class Initialized
INFO - 2023-04-28 10:17:40 --> Loader Class Initialized
INFO - 2023-04-28 10:17:40 --> Controller Class Initialized
DEBUG - 2023-04-28 10:17:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:17:40 --> Database Driver Class Initialized
INFO - 2023-04-28 10:17:40 --> Database Driver Class Initialized
INFO - 2023-04-28 10:17:40 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:17:40 --> Model "Login_model" initialized
INFO - 2023-04-28 10:17:40 --> Final output sent to browser
DEBUG - 2023-04-28 10:17:40 --> Total execution time: 0.0127
INFO - 2023-04-28 10:17:40 --> Final output sent to browser
DEBUG - 2023-04-28 10:17:40 --> Total execution time: 0.1694
INFO - 2023-04-28 10:17:40 --> Config Class Initialized
INFO - 2023-04-28 10:17:40 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:17:40 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:17:40 --> Utf8 Class Initialized
INFO - 2023-04-28 10:17:40 --> URI Class Initialized
INFO - 2023-04-28 10:17:40 --> Router Class Initialized
INFO - 2023-04-28 10:17:40 --> Output Class Initialized
INFO - 2023-04-28 10:17:40 --> Security Class Initialized
DEBUG - 2023-04-28 10:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:17:40 --> Input Class Initialized
INFO - 2023-04-28 10:17:40 --> Language Class Initialized
INFO - 2023-04-28 10:17:40 --> Loader Class Initialized
INFO - 2023-04-28 10:17:40 --> Controller Class Initialized
DEBUG - 2023-04-28 10:17:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:17:40 --> Database Driver Class Initialized
INFO - 2023-04-28 10:17:40 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:17:40 --> Database Driver Class Initialized
INFO - 2023-04-28 10:17:40 --> Model "Login_model" initialized
INFO - 2023-04-28 10:17:40 --> Final output sent to browser
DEBUG - 2023-04-28 10:17:40 --> Total execution time: 0.0795
INFO - 2023-04-28 10:30:47 --> Config Class Initialized
INFO - 2023-04-28 10:30:47 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:30:47 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:30:47 --> Utf8 Class Initialized
INFO - 2023-04-28 10:30:47 --> URI Class Initialized
INFO - 2023-04-28 10:30:47 --> Router Class Initialized
INFO - 2023-04-28 10:30:47 --> Output Class Initialized
INFO - 2023-04-28 10:30:47 --> Security Class Initialized
DEBUG - 2023-04-28 10:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:30:47 --> Input Class Initialized
INFO - 2023-04-28 10:30:47 --> Language Class Initialized
INFO - 2023-04-28 10:30:47 --> Loader Class Initialized
INFO - 2023-04-28 10:30:47 --> Controller Class Initialized
DEBUG - 2023-04-28 10:30:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:30:47 --> Database Driver Class Initialized
INFO - 2023-04-28 10:30:47 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:30:47 --> Final output sent to browser
DEBUG - 2023-04-28 10:30:47 --> Total execution time: 0.0110
INFO - 2023-04-28 10:30:47 --> Config Class Initialized
INFO - 2023-04-28 10:30:47 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:30:47 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:30:47 --> Utf8 Class Initialized
INFO - 2023-04-28 10:30:47 --> URI Class Initialized
INFO - 2023-04-28 10:30:47 --> Router Class Initialized
INFO - 2023-04-28 10:30:47 --> Output Class Initialized
INFO - 2023-04-28 10:30:47 --> Security Class Initialized
DEBUG - 2023-04-28 10:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:30:47 --> Input Class Initialized
INFO - 2023-04-28 10:30:47 --> Language Class Initialized
INFO - 2023-04-28 10:30:47 --> Loader Class Initialized
INFO - 2023-04-28 10:30:47 --> Controller Class Initialized
DEBUG - 2023-04-28 10:30:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:30:47 --> Database Driver Class Initialized
INFO - 2023-04-28 10:30:47 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:30:47 --> Final output sent to browser
DEBUG - 2023-04-28 10:30:47 --> Total execution time: 0.0550
INFO - 2023-04-28 10:30:47 --> Config Class Initialized
INFO - 2023-04-28 10:30:47 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:30:47 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:30:47 --> Utf8 Class Initialized
INFO - 2023-04-28 10:30:47 --> URI Class Initialized
INFO - 2023-04-28 10:30:47 --> Router Class Initialized
INFO - 2023-04-28 10:30:47 --> Output Class Initialized
INFO - 2023-04-28 10:30:47 --> Security Class Initialized
DEBUG - 2023-04-28 10:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:30:47 --> Input Class Initialized
INFO - 2023-04-28 10:30:47 --> Language Class Initialized
INFO - 2023-04-28 10:30:47 --> Loader Class Initialized
INFO - 2023-04-28 10:30:47 --> Controller Class Initialized
DEBUG - 2023-04-28 10:30:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:30:47 --> Database Driver Class Initialized
INFO - 2023-04-28 10:30:47 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:30:47 --> Final output sent to browser
DEBUG - 2023-04-28 10:30:47 --> Total execution time: 0.0542
INFO - 2023-04-28 10:30:47 --> Config Class Initialized
INFO - 2023-04-28 10:30:47 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:30:47 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:30:47 --> Utf8 Class Initialized
INFO - 2023-04-28 10:30:47 --> URI Class Initialized
INFO - 2023-04-28 10:30:47 --> Router Class Initialized
INFO - 2023-04-28 10:30:47 --> Output Class Initialized
INFO - 2023-04-28 10:30:47 --> Security Class Initialized
DEBUG - 2023-04-28 10:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:30:47 --> Input Class Initialized
INFO - 2023-04-28 10:30:47 --> Language Class Initialized
INFO - 2023-04-28 10:30:47 --> Loader Class Initialized
INFO - 2023-04-28 10:30:47 --> Controller Class Initialized
DEBUG - 2023-04-28 10:30:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:30:47 --> Database Driver Class Initialized
INFO - 2023-04-28 10:30:47 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:30:47 --> Final output sent to browser
DEBUG - 2023-04-28 10:30:47 --> Total execution time: 0.0514
INFO - 2023-04-28 10:32:09 --> Config Class Initialized
INFO - 2023-04-28 10:32:09 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:32:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:32:09 --> Utf8 Class Initialized
INFO - 2023-04-28 10:32:09 --> URI Class Initialized
INFO - 2023-04-28 10:32:09 --> Router Class Initialized
INFO - 2023-04-28 10:32:09 --> Output Class Initialized
INFO - 2023-04-28 10:32:09 --> Security Class Initialized
DEBUG - 2023-04-28 10:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:32:09 --> Input Class Initialized
INFO - 2023-04-28 10:32:09 --> Language Class Initialized
INFO - 2023-04-28 10:32:09 --> Loader Class Initialized
INFO - 2023-04-28 10:32:09 --> Controller Class Initialized
DEBUG - 2023-04-28 10:32:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:32:09 --> Database Driver Class Initialized
INFO - 2023-04-28 10:32:09 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:32:09 --> Final output sent to browser
DEBUG - 2023-04-28 10:32:09 --> Total execution time: 0.0121
INFO - 2023-04-28 10:32:09 --> Config Class Initialized
INFO - 2023-04-28 10:32:09 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:32:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:32:09 --> Utf8 Class Initialized
INFO - 2023-04-28 10:32:09 --> URI Class Initialized
INFO - 2023-04-28 10:32:09 --> Router Class Initialized
INFO - 2023-04-28 10:32:09 --> Output Class Initialized
INFO - 2023-04-28 10:32:09 --> Security Class Initialized
DEBUG - 2023-04-28 10:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:32:09 --> Input Class Initialized
INFO - 2023-04-28 10:32:09 --> Language Class Initialized
INFO - 2023-04-28 10:32:09 --> Loader Class Initialized
INFO - 2023-04-28 10:32:09 --> Controller Class Initialized
DEBUG - 2023-04-28 10:32:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:32:09 --> Database Driver Class Initialized
INFO - 2023-04-28 10:32:09 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:32:09 --> Database Driver Class Initialized
INFO - 2023-04-28 10:32:09 --> Model "Login_model" initialized
INFO - 2023-04-28 10:32:09 --> Final output sent to browser
DEBUG - 2023-04-28 10:32:09 --> Total execution time: 0.0380
INFO - 2023-04-28 10:32:09 --> Config Class Initialized
INFO - 2023-04-28 10:32:09 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:32:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:32:09 --> Utf8 Class Initialized
INFO - 2023-04-28 10:32:09 --> URI Class Initialized
INFO - 2023-04-28 10:32:09 --> Router Class Initialized
INFO - 2023-04-28 10:32:09 --> Output Class Initialized
INFO - 2023-04-28 10:32:09 --> Security Class Initialized
DEBUG - 2023-04-28 10:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:32:09 --> Input Class Initialized
INFO - 2023-04-28 10:32:09 --> Language Class Initialized
INFO - 2023-04-28 10:32:09 --> Loader Class Initialized
INFO - 2023-04-28 10:32:09 --> Controller Class Initialized
DEBUG - 2023-04-28 10:32:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:32:09 --> Database Driver Class Initialized
INFO - 2023-04-28 10:32:09 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:32:09 --> Final output sent to browser
DEBUG - 2023-04-28 10:32:09 --> Total execution time: 0.0125
INFO - 2023-04-28 10:32:09 --> Config Class Initialized
INFO - 2023-04-28 10:32:09 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:32:09 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:32:09 --> Utf8 Class Initialized
INFO - 2023-04-28 10:32:09 --> URI Class Initialized
INFO - 2023-04-28 10:32:09 --> Router Class Initialized
INFO - 2023-04-28 10:32:09 --> Output Class Initialized
INFO - 2023-04-28 10:32:09 --> Security Class Initialized
DEBUG - 2023-04-28 10:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:32:09 --> Input Class Initialized
INFO - 2023-04-28 10:32:09 --> Language Class Initialized
INFO - 2023-04-28 10:32:09 --> Loader Class Initialized
INFO - 2023-04-28 10:32:09 --> Controller Class Initialized
DEBUG - 2023-04-28 10:32:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:32:09 --> Database Driver Class Initialized
INFO - 2023-04-28 10:32:09 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:32:09 --> Final output sent to browser
DEBUG - 2023-04-28 10:32:09 --> Total execution time: 0.0123
INFO - 2023-04-28 10:32:14 --> Config Class Initialized
INFO - 2023-04-28 10:32:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:32:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:32:14 --> Utf8 Class Initialized
INFO - 2023-04-28 10:32:14 --> URI Class Initialized
INFO - 2023-04-28 10:32:14 --> Router Class Initialized
INFO - 2023-04-28 10:32:14 --> Output Class Initialized
INFO - 2023-04-28 10:32:14 --> Security Class Initialized
DEBUG - 2023-04-28 10:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:32:14 --> Input Class Initialized
INFO - 2023-04-28 10:32:14 --> Language Class Initialized
INFO - 2023-04-28 10:32:14 --> Loader Class Initialized
INFO - 2023-04-28 10:32:14 --> Controller Class Initialized
DEBUG - 2023-04-28 10:32:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:32:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:32:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:32:14 --> Final output sent to browser
DEBUG - 2023-04-28 10:32:14 --> Total execution time: 0.0188
INFO - 2023-04-28 10:39:42 --> Config Class Initialized
INFO - 2023-04-28 10:39:42 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:39:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:39:42 --> Utf8 Class Initialized
INFO - 2023-04-28 10:39:42 --> URI Class Initialized
INFO - 2023-04-28 10:39:42 --> Router Class Initialized
INFO - 2023-04-28 10:39:42 --> Output Class Initialized
INFO - 2023-04-28 10:39:42 --> Security Class Initialized
DEBUG - 2023-04-28 10:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:39:42 --> Input Class Initialized
INFO - 2023-04-28 10:39:42 --> Language Class Initialized
INFO - 2023-04-28 10:39:42 --> Loader Class Initialized
INFO - 2023-04-28 10:39:42 --> Controller Class Initialized
DEBUG - 2023-04-28 10:39:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:39:42 --> Database Driver Class Initialized
INFO - 2023-04-28 10:39:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:39:42 --> Final output sent to browser
DEBUG - 2023-04-28 10:39:42 --> Total execution time: 0.0122
INFO - 2023-04-28 10:39:42 --> Config Class Initialized
INFO - 2023-04-28 10:39:42 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:39:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:39:42 --> Utf8 Class Initialized
INFO - 2023-04-28 10:39:42 --> URI Class Initialized
INFO - 2023-04-28 10:39:42 --> Router Class Initialized
INFO - 2023-04-28 10:39:42 --> Output Class Initialized
INFO - 2023-04-28 10:39:42 --> Security Class Initialized
DEBUG - 2023-04-28 10:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:39:42 --> Input Class Initialized
INFO - 2023-04-28 10:39:42 --> Language Class Initialized
INFO - 2023-04-28 10:39:42 --> Loader Class Initialized
INFO - 2023-04-28 10:39:42 --> Controller Class Initialized
DEBUG - 2023-04-28 10:39:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:39:42 --> Database Driver Class Initialized
INFO - 2023-04-28 10:39:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:39:42 --> Final output sent to browser
DEBUG - 2023-04-28 10:39:42 --> Total execution time: 0.0520
INFO - 2023-04-28 10:39:42 --> Config Class Initialized
INFO - 2023-04-28 10:39:42 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:39:42 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:39:42 --> Utf8 Class Initialized
INFO - 2023-04-28 10:39:42 --> URI Class Initialized
INFO - 2023-04-28 10:39:42 --> Router Class Initialized
INFO - 2023-04-28 10:39:42 --> Output Class Initialized
INFO - 2023-04-28 10:39:42 --> Security Class Initialized
DEBUG - 2023-04-28 10:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:39:42 --> Input Class Initialized
INFO - 2023-04-28 10:39:42 --> Language Class Initialized
INFO - 2023-04-28 10:39:42 --> Loader Class Initialized
INFO - 2023-04-28 10:39:42 --> Controller Class Initialized
DEBUG - 2023-04-28 10:39:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:39:42 --> Database Driver Class Initialized
INFO - 2023-04-28 10:39:42 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:39:42 --> Final output sent to browser
DEBUG - 2023-04-28 10:39:42 --> Total execution time: 0.0125
INFO - 2023-04-28 10:39:42 --> Config Class Initialized
INFO - 2023-04-28 10:39:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:39:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:39:43 --> Utf8 Class Initialized
INFO - 2023-04-28 10:39:43 --> URI Class Initialized
INFO - 2023-04-28 10:39:43 --> Router Class Initialized
INFO - 2023-04-28 10:39:43 --> Output Class Initialized
INFO - 2023-04-28 10:39:43 --> Security Class Initialized
DEBUG - 2023-04-28 10:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:39:43 --> Input Class Initialized
INFO - 2023-04-28 10:39:43 --> Language Class Initialized
INFO - 2023-04-28 10:39:43 --> Loader Class Initialized
INFO - 2023-04-28 10:39:43 --> Controller Class Initialized
DEBUG - 2023-04-28 10:39:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:39:43 --> Database Driver Class Initialized
INFO - 2023-04-28 10:39:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:39:43 --> Final output sent to browser
DEBUG - 2023-04-28 10:39:43 --> Total execution time: 0.0514
INFO - 2023-04-28 10:40:18 --> Config Class Initialized
INFO - 2023-04-28 10:40:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:18 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:18 --> URI Class Initialized
INFO - 2023-04-28 10:40:18 --> Router Class Initialized
INFO - 2023-04-28 10:40:18 --> Output Class Initialized
INFO - 2023-04-28 10:40:18 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:18 --> Input Class Initialized
INFO - 2023-04-28 10:40:18 --> Language Class Initialized
INFO - 2023-04-28 10:40:18 --> Loader Class Initialized
INFO - 2023-04-28 10:40:18 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:18 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:18 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:18 --> Total execution time: 0.0581
INFO - 2023-04-28 10:40:18 --> Config Class Initialized
INFO - 2023-04-28 10:40:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:18 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:18 --> URI Class Initialized
INFO - 2023-04-28 10:40:18 --> Router Class Initialized
INFO - 2023-04-28 10:40:18 --> Output Class Initialized
INFO - 2023-04-28 10:40:18 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:18 --> Input Class Initialized
INFO - 2023-04-28 10:40:18 --> Language Class Initialized
INFO - 2023-04-28 10:40:18 --> Loader Class Initialized
INFO - 2023-04-28 10:40:18 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:18 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:18 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:18 --> Model "Login_model" initialized
INFO - 2023-04-28 10:40:18 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:18 --> Total execution time: 0.0382
INFO - 2023-04-28 10:40:18 --> Config Class Initialized
INFO - 2023-04-28 10:40:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:18 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:18 --> URI Class Initialized
INFO - 2023-04-28 10:40:18 --> Router Class Initialized
INFO - 2023-04-28 10:40:18 --> Output Class Initialized
INFO - 2023-04-28 10:40:18 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:18 --> Input Class Initialized
INFO - 2023-04-28 10:40:18 --> Language Class Initialized
INFO - 2023-04-28 10:40:18 --> Loader Class Initialized
INFO - 2023-04-28 10:40:18 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:18 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:18 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:18 --> Total execution time: 0.0112
INFO - 2023-04-28 10:40:18 --> Config Class Initialized
INFO - 2023-04-28 10:40:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:18 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:18 --> URI Class Initialized
INFO - 2023-04-28 10:40:18 --> Router Class Initialized
INFO - 2023-04-28 10:40:18 --> Output Class Initialized
INFO - 2023-04-28 10:40:18 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:18 --> Input Class Initialized
INFO - 2023-04-28 10:40:18 --> Language Class Initialized
INFO - 2023-04-28 10:40:18 --> Loader Class Initialized
INFO - 2023-04-28 10:40:18 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:18 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:19 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:19 --> Total execution time: 0.9427
INFO - 2023-04-28 10:40:23 --> Config Class Initialized
INFO - 2023-04-28 10:40:23 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:23 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:23 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:23 --> URI Class Initialized
INFO - 2023-04-28 10:40:23 --> Router Class Initialized
INFO - 2023-04-28 10:40:23 --> Output Class Initialized
INFO - 2023-04-28 10:40:23 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:23 --> Input Class Initialized
INFO - 2023-04-28 10:40:23 --> Language Class Initialized
INFO - 2023-04-28 10:40:23 --> Loader Class Initialized
INFO - 2023-04-28 10:40:23 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:23 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:23 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:23 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:23 --> Total execution time: 0.0186
INFO - 2023-04-28 10:40:28 --> Config Class Initialized
INFO - 2023-04-28 10:40:28 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:28 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:28 --> URI Class Initialized
INFO - 2023-04-28 10:40:28 --> Router Class Initialized
INFO - 2023-04-28 10:40:28 --> Output Class Initialized
INFO - 2023-04-28 10:40:28 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:28 --> Input Class Initialized
INFO - 2023-04-28 10:40:28 --> Language Class Initialized
INFO - 2023-04-28 10:40:28 --> Loader Class Initialized
INFO - 2023-04-28 10:40:28 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:28 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:28 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:28 --> Total execution time: 0.0162
INFO - 2023-04-28 10:40:28 --> Config Class Initialized
INFO - 2023-04-28 10:40:28 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:28 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:28 --> URI Class Initialized
INFO - 2023-04-28 10:40:28 --> Router Class Initialized
INFO - 2023-04-28 10:40:28 --> Output Class Initialized
INFO - 2023-04-28 10:40:28 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:28 --> Input Class Initialized
INFO - 2023-04-28 10:40:28 --> Language Class Initialized
INFO - 2023-04-28 10:40:28 --> Loader Class Initialized
INFO - 2023-04-28 10:40:28 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:28 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:28 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:28 --> Total execution time: 0.0120
INFO - 2023-04-28 10:40:33 --> Config Class Initialized
INFO - 2023-04-28 10:40:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:33 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:33 --> URI Class Initialized
INFO - 2023-04-28 10:40:33 --> Router Class Initialized
INFO - 2023-04-28 10:40:33 --> Output Class Initialized
INFO - 2023-04-28 10:40:33 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:33 --> Input Class Initialized
INFO - 2023-04-28 10:40:33 --> Language Class Initialized
INFO - 2023-04-28 10:40:33 --> Loader Class Initialized
INFO - 2023-04-28 10:40:33 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:33 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:33 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:33 --> Total execution time: 0.0152
INFO - 2023-04-28 10:40:38 --> Config Class Initialized
INFO - 2023-04-28 10:40:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:38 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:38 --> URI Class Initialized
INFO - 2023-04-28 10:40:38 --> Router Class Initialized
INFO - 2023-04-28 10:40:38 --> Output Class Initialized
INFO - 2023-04-28 10:40:38 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:38 --> Input Class Initialized
INFO - 2023-04-28 10:40:38 --> Language Class Initialized
INFO - 2023-04-28 10:40:38 --> Loader Class Initialized
INFO - 2023-04-28 10:40:38 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:38 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:38 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:38 --> Total execution time: 0.0133
INFO - 2023-04-28 10:40:38 --> Config Class Initialized
INFO - 2023-04-28 10:40:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:38 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:38 --> URI Class Initialized
INFO - 2023-04-28 10:40:38 --> Router Class Initialized
INFO - 2023-04-28 10:40:38 --> Output Class Initialized
INFO - 2023-04-28 10:40:38 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:38 --> Input Class Initialized
INFO - 2023-04-28 10:40:38 --> Language Class Initialized
INFO - 2023-04-28 10:40:38 --> Loader Class Initialized
INFO - 2023-04-28 10:40:38 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:38 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:38 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:38 --> Total execution time: 0.0141
INFO - 2023-04-28 10:40:43 --> Config Class Initialized
INFO - 2023-04-28 10:40:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:43 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:43 --> URI Class Initialized
INFO - 2023-04-28 10:40:43 --> Router Class Initialized
INFO - 2023-04-28 10:40:43 --> Output Class Initialized
INFO - 2023-04-28 10:40:43 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:43 --> Input Class Initialized
INFO - 2023-04-28 10:40:43 --> Language Class Initialized
INFO - 2023-04-28 10:40:43 --> Loader Class Initialized
INFO - 2023-04-28 10:40:43 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:43 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:43 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:43 --> Total execution time: 0.0164
INFO - 2023-04-28 10:40:48 --> Config Class Initialized
INFO - 2023-04-28 10:40:48 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:48 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:48 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:48 --> URI Class Initialized
INFO - 2023-04-28 10:40:48 --> Router Class Initialized
INFO - 2023-04-28 10:40:48 --> Output Class Initialized
INFO - 2023-04-28 10:40:48 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:48 --> Input Class Initialized
INFO - 2023-04-28 10:40:48 --> Language Class Initialized
INFO - 2023-04-28 10:40:48 --> Loader Class Initialized
INFO - 2023-04-28 10:40:48 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:48 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:48 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:48 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:48 --> Total execution time: 0.0128
INFO - 2023-04-28 10:40:48 --> Config Class Initialized
INFO - 2023-04-28 10:40:48 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:48 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:48 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:48 --> URI Class Initialized
INFO - 2023-04-28 10:40:48 --> Router Class Initialized
INFO - 2023-04-28 10:40:48 --> Output Class Initialized
INFO - 2023-04-28 10:40:48 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:48 --> Input Class Initialized
INFO - 2023-04-28 10:40:48 --> Language Class Initialized
INFO - 2023-04-28 10:40:48 --> Loader Class Initialized
INFO - 2023-04-28 10:40:48 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:48 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:48 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:48 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:48 --> Total execution time: 0.0181
INFO - 2023-04-28 10:40:53 --> Config Class Initialized
INFO - 2023-04-28 10:40:53 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:53 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:53 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:53 --> URI Class Initialized
INFO - 2023-04-28 10:40:53 --> Router Class Initialized
INFO - 2023-04-28 10:40:53 --> Output Class Initialized
INFO - 2023-04-28 10:40:53 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:53 --> Input Class Initialized
INFO - 2023-04-28 10:40:53 --> Language Class Initialized
INFO - 2023-04-28 10:40:53 --> Loader Class Initialized
INFO - 2023-04-28 10:40:53 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:53 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:53 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:53 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:53 --> Total execution time: 0.0157
INFO - 2023-04-28 10:40:58 --> Config Class Initialized
INFO - 2023-04-28 10:40:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:58 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:58 --> URI Class Initialized
INFO - 2023-04-28 10:40:58 --> Router Class Initialized
INFO - 2023-04-28 10:40:58 --> Output Class Initialized
INFO - 2023-04-28 10:40:58 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:58 --> Input Class Initialized
INFO - 2023-04-28 10:40:58 --> Language Class Initialized
INFO - 2023-04-28 10:40:58 --> Loader Class Initialized
INFO - 2023-04-28 10:40:58 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:58 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:58 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:58 --> Total execution time: 0.0121
INFO - 2023-04-28 10:40:58 --> Config Class Initialized
INFO - 2023-04-28 10:40:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:40:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:40:58 --> Utf8 Class Initialized
INFO - 2023-04-28 10:40:58 --> URI Class Initialized
INFO - 2023-04-28 10:40:58 --> Router Class Initialized
INFO - 2023-04-28 10:40:58 --> Output Class Initialized
INFO - 2023-04-28 10:40:58 --> Security Class Initialized
DEBUG - 2023-04-28 10:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:40:58 --> Input Class Initialized
INFO - 2023-04-28 10:40:58 --> Language Class Initialized
INFO - 2023-04-28 10:40:58 --> Loader Class Initialized
INFO - 2023-04-28 10:40:58 --> Controller Class Initialized
DEBUG - 2023-04-28 10:40:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:40:58 --> Database Driver Class Initialized
INFO - 2023-04-28 10:40:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:40:58 --> Final output sent to browser
DEBUG - 2023-04-28 10:40:58 --> Total execution time: 0.0147
INFO - 2023-04-28 10:41:03 --> Config Class Initialized
INFO - 2023-04-28 10:41:03 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:03 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:03 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:03 --> URI Class Initialized
INFO - 2023-04-28 10:41:03 --> Router Class Initialized
INFO - 2023-04-28 10:41:03 --> Output Class Initialized
INFO - 2023-04-28 10:41:03 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:03 --> Input Class Initialized
INFO - 2023-04-28 10:41:03 --> Language Class Initialized
INFO - 2023-04-28 10:41:03 --> Loader Class Initialized
INFO - 2023-04-28 10:41:03 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:03 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:03 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:03 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:03 --> Total execution time: 0.0223
INFO - 2023-04-28 10:41:08 --> Config Class Initialized
INFO - 2023-04-28 10:41:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:08 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:08 --> URI Class Initialized
INFO - 2023-04-28 10:41:08 --> Router Class Initialized
INFO - 2023-04-28 10:41:08 --> Output Class Initialized
INFO - 2023-04-28 10:41:08 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:08 --> Input Class Initialized
INFO - 2023-04-28 10:41:08 --> Language Class Initialized
INFO - 2023-04-28 10:41:08 --> Loader Class Initialized
INFO - 2023-04-28 10:41:08 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:08 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:08 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:08 --> Total execution time: 0.0127
INFO - 2023-04-28 10:41:08 --> Config Class Initialized
INFO - 2023-04-28 10:41:08 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:08 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:08 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:08 --> URI Class Initialized
INFO - 2023-04-28 10:41:08 --> Router Class Initialized
INFO - 2023-04-28 10:41:08 --> Output Class Initialized
INFO - 2023-04-28 10:41:08 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:08 --> Input Class Initialized
INFO - 2023-04-28 10:41:08 --> Language Class Initialized
INFO - 2023-04-28 10:41:08 --> Loader Class Initialized
INFO - 2023-04-28 10:41:08 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:08 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:08 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:08 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:08 --> Total execution time: 0.0160
INFO - 2023-04-28 10:41:13 --> Config Class Initialized
INFO - 2023-04-28 10:41:13 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:13 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:13 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:13 --> URI Class Initialized
INFO - 2023-04-28 10:41:13 --> Router Class Initialized
INFO - 2023-04-28 10:41:13 --> Output Class Initialized
INFO - 2023-04-28 10:41:13 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:13 --> Input Class Initialized
INFO - 2023-04-28 10:41:13 --> Language Class Initialized
INFO - 2023-04-28 10:41:13 --> Loader Class Initialized
INFO - 2023-04-28 10:41:13 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:13 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:13 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:13 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:13 --> Total execution time: 0.0184
INFO - 2023-04-28 10:41:18 --> Config Class Initialized
INFO - 2023-04-28 10:41:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:18 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:18 --> URI Class Initialized
INFO - 2023-04-28 10:41:18 --> Router Class Initialized
INFO - 2023-04-28 10:41:18 --> Output Class Initialized
INFO - 2023-04-28 10:41:18 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:18 --> Input Class Initialized
INFO - 2023-04-28 10:41:18 --> Language Class Initialized
INFO - 2023-04-28 10:41:18 --> Loader Class Initialized
INFO - 2023-04-28 10:41:18 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:18 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:18 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:18 --> Total execution time: 0.0137
INFO - 2023-04-28 10:41:18 --> Config Class Initialized
INFO - 2023-04-28 10:41:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:18 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:18 --> URI Class Initialized
INFO - 2023-04-28 10:41:18 --> Router Class Initialized
INFO - 2023-04-28 10:41:18 --> Output Class Initialized
INFO - 2023-04-28 10:41:18 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:18 --> Input Class Initialized
INFO - 2023-04-28 10:41:18 --> Language Class Initialized
INFO - 2023-04-28 10:41:18 --> Loader Class Initialized
INFO - 2023-04-28 10:41:18 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:18 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:18 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:18 --> Total execution time: 0.0149
INFO - 2023-04-28 10:41:23 --> Config Class Initialized
INFO - 2023-04-28 10:41:23 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:23 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:23 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:23 --> URI Class Initialized
INFO - 2023-04-28 10:41:23 --> Router Class Initialized
INFO - 2023-04-28 10:41:23 --> Output Class Initialized
INFO - 2023-04-28 10:41:23 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:23 --> Input Class Initialized
INFO - 2023-04-28 10:41:23 --> Language Class Initialized
INFO - 2023-04-28 10:41:23 --> Loader Class Initialized
INFO - 2023-04-28 10:41:23 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:23 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:23 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:23 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:23 --> Total execution time: 0.0172
INFO - 2023-04-28 10:41:28 --> Config Class Initialized
INFO - 2023-04-28 10:41:28 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:28 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:28 --> URI Class Initialized
INFO - 2023-04-28 10:41:28 --> Router Class Initialized
INFO - 2023-04-28 10:41:28 --> Output Class Initialized
INFO - 2023-04-28 10:41:28 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:28 --> Input Class Initialized
INFO - 2023-04-28 10:41:28 --> Language Class Initialized
INFO - 2023-04-28 10:41:28 --> Loader Class Initialized
INFO - 2023-04-28 10:41:28 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:28 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:28 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:28 --> Total execution time: 0.0113
INFO - 2023-04-28 10:41:28 --> Config Class Initialized
INFO - 2023-04-28 10:41:28 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:28 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:28 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:28 --> URI Class Initialized
INFO - 2023-04-28 10:41:28 --> Router Class Initialized
INFO - 2023-04-28 10:41:28 --> Output Class Initialized
INFO - 2023-04-28 10:41:28 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:28 --> Input Class Initialized
INFO - 2023-04-28 10:41:28 --> Language Class Initialized
INFO - 2023-04-28 10:41:28 --> Loader Class Initialized
INFO - 2023-04-28 10:41:28 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:28 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:28 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:28 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:28 --> Total execution time: 0.0177
INFO - 2023-04-28 10:41:33 --> Config Class Initialized
INFO - 2023-04-28 10:41:33 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:33 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:33 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:33 --> URI Class Initialized
INFO - 2023-04-28 10:41:33 --> Router Class Initialized
INFO - 2023-04-28 10:41:33 --> Output Class Initialized
INFO - 2023-04-28 10:41:33 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:33 --> Input Class Initialized
INFO - 2023-04-28 10:41:33 --> Language Class Initialized
INFO - 2023-04-28 10:41:33 --> Loader Class Initialized
INFO - 2023-04-28 10:41:33 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:33 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:33 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:33 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:33 --> Total execution time: 0.0210
INFO - 2023-04-28 10:41:38 --> Config Class Initialized
INFO - 2023-04-28 10:41:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:38 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:38 --> URI Class Initialized
INFO - 2023-04-28 10:41:38 --> Router Class Initialized
INFO - 2023-04-28 10:41:38 --> Output Class Initialized
INFO - 2023-04-28 10:41:38 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:38 --> Input Class Initialized
INFO - 2023-04-28 10:41:38 --> Language Class Initialized
INFO - 2023-04-28 10:41:38 --> Loader Class Initialized
INFO - 2023-04-28 10:41:38 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:38 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:38 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:38 --> Total execution time: 0.0120
INFO - 2023-04-28 10:41:38 --> Config Class Initialized
INFO - 2023-04-28 10:41:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:38 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:38 --> URI Class Initialized
INFO - 2023-04-28 10:41:38 --> Router Class Initialized
INFO - 2023-04-28 10:41:38 --> Output Class Initialized
INFO - 2023-04-28 10:41:38 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:38 --> Input Class Initialized
INFO - 2023-04-28 10:41:38 --> Language Class Initialized
INFO - 2023-04-28 10:41:38 --> Loader Class Initialized
INFO - 2023-04-28 10:41:38 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:38 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:38 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:38 --> Total execution time: 0.0152
INFO - 2023-04-28 10:41:43 --> Config Class Initialized
INFO - 2023-04-28 10:41:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:43 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:43 --> URI Class Initialized
INFO - 2023-04-28 10:41:43 --> Router Class Initialized
INFO - 2023-04-28 10:41:43 --> Output Class Initialized
INFO - 2023-04-28 10:41:43 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:43 --> Input Class Initialized
INFO - 2023-04-28 10:41:43 --> Language Class Initialized
INFO - 2023-04-28 10:41:43 --> Loader Class Initialized
INFO - 2023-04-28 10:41:43 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:43 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:43 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:43 --> Total execution time: 0.1760
INFO - 2023-04-28 10:41:48 --> Config Class Initialized
INFO - 2023-04-28 10:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:48 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:48 --> URI Class Initialized
INFO - 2023-04-28 10:41:48 --> Router Class Initialized
INFO - 2023-04-28 10:41:48 --> Output Class Initialized
INFO - 2023-04-28 10:41:48 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:48 --> Input Class Initialized
INFO - 2023-04-28 10:41:48 --> Language Class Initialized
INFO - 2023-04-28 10:41:48 --> Loader Class Initialized
INFO - 2023-04-28 10:41:48 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:48 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:48 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:48 --> Total execution time: 0.0113
INFO - 2023-04-28 10:41:48 --> Config Class Initialized
INFO - 2023-04-28 10:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:48 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:48 --> URI Class Initialized
INFO - 2023-04-28 10:41:48 --> Router Class Initialized
INFO - 2023-04-28 10:41:48 --> Output Class Initialized
INFO - 2023-04-28 10:41:48 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:48 --> Input Class Initialized
INFO - 2023-04-28 10:41:48 --> Language Class Initialized
INFO - 2023-04-28 10:41:48 --> Loader Class Initialized
INFO - 2023-04-28 10:41:48 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:48 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:48 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:48 --> Total execution time: 0.0141
INFO - 2023-04-28 10:41:51 --> Config Class Initialized
INFO - 2023-04-28 10:41:51 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:51 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:51 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:51 --> URI Class Initialized
INFO - 2023-04-28 10:41:51 --> Router Class Initialized
INFO - 2023-04-28 10:41:51 --> Output Class Initialized
INFO - 2023-04-28 10:41:51 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:51 --> Input Class Initialized
INFO - 2023-04-28 10:41:51 --> Language Class Initialized
INFO - 2023-04-28 10:41:51 --> Loader Class Initialized
INFO - 2023-04-28 10:41:51 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:51 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:51 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:51 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:51 --> Model "Login_model" initialized
INFO - 2023-04-28 10:41:51 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:51 --> Total execution time: 0.1099
INFO - 2023-04-28 10:41:51 --> Config Class Initialized
INFO - 2023-04-28 10:41:51 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:41:51 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:41:51 --> Utf8 Class Initialized
INFO - 2023-04-28 10:41:51 --> URI Class Initialized
INFO - 2023-04-28 10:41:51 --> Router Class Initialized
INFO - 2023-04-28 10:41:51 --> Output Class Initialized
INFO - 2023-04-28 10:41:51 --> Security Class Initialized
DEBUG - 2023-04-28 10:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:41:51 --> Input Class Initialized
INFO - 2023-04-28 10:41:51 --> Language Class Initialized
INFO - 2023-04-28 10:41:51 --> Loader Class Initialized
INFO - 2023-04-28 10:41:51 --> Controller Class Initialized
DEBUG - 2023-04-28 10:41:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:41:51 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:51 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:41:51 --> Database Driver Class Initialized
INFO - 2023-04-28 10:41:51 --> Model "Login_model" initialized
INFO - 2023-04-28 10:41:51 --> Final output sent to browser
DEBUG - 2023-04-28 10:41:51 --> Total execution time: 0.1751
INFO - 2023-04-28 10:43:43 --> Config Class Initialized
INFO - 2023-04-28 10:43:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:43:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:43:43 --> Utf8 Class Initialized
INFO - 2023-04-28 10:43:43 --> URI Class Initialized
INFO - 2023-04-28 10:43:43 --> Router Class Initialized
INFO - 2023-04-28 10:43:43 --> Output Class Initialized
INFO - 2023-04-28 10:43:43 --> Security Class Initialized
DEBUG - 2023-04-28 10:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:43:43 --> Input Class Initialized
INFO - 2023-04-28 10:43:43 --> Language Class Initialized
INFO - 2023-04-28 10:43:43 --> Loader Class Initialized
INFO - 2023-04-28 10:43:43 --> Controller Class Initialized
DEBUG - 2023-04-28 10:43:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:43:43 --> Database Driver Class Initialized
INFO - 2023-04-28 10:43:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:43:43 --> Final output sent to browser
DEBUG - 2023-04-28 10:43:43 --> Total execution time: 0.0122
INFO - 2023-04-28 10:43:43 --> Config Class Initialized
INFO - 2023-04-28 10:43:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:43:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:43:43 --> Utf8 Class Initialized
INFO - 2023-04-28 10:43:43 --> URI Class Initialized
INFO - 2023-04-28 10:43:43 --> Router Class Initialized
INFO - 2023-04-28 10:43:43 --> Output Class Initialized
INFO - 2023-04-28 10:43:43 --> Security Class Initialized
DEBUG - 2023-04-28 10:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:43:43 --> Input Class Initialized
INFO - 2023-04-28 10:43:43 --> Language Class Initialized
INFO - 2023-04-28 10:43:43 --> Loader Class Initialized
INFO - 2023-04-28 10:43:43 --> Controller Class Initialized
DEBUG - 2023-04-28 10:43:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:43:43 --> Database Driver Class Initialized
INFO - 2023-04-28 10:43:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:43:43 --> Final output sent to browser
DEBUG - 2023-04-28 10:43:43 --> Total execution time: 0.0103
INFO - 2023-04-28 10:43:43 --> Config Class Initialized
INFO - 2023-04-28 10:43:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:43:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:43:43 --> Utf8 Class Initialized
INFO - 2023-04-28 10:43:43 --> URI Class Initialized
INFO - 2023-04-28 10:43:43 --> Router Class Initialized
INFO - 2023-04-28 10:43:43 --> Output Class Initialized
INFO - 2023-04-28 10:43:43 --> Security Class Initialized
DEBUG - 2023-04-28 10:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:43:43 --> Input Class Initialized
INFO - 2023-04-28 10:43:43 --> Language Class Initialized
INFO - 2023-04-28 10:43:43 --> Loader Class Initialized
INFO - 2023-04-28 10:43:43 --> Controller Class Initialized
DEBUG - 2023-04-28 10:43:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:43:43 --> Database Driver Class Initialized
INFO - 2023-04-28 10:43:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:43:43 --> Final output sent to browser
DEBUG - 2023-04-28 10:43:43 --> Total execution time: 0.0109
INFO - 2023-04-28 10:43:43 --> Config Class Initialized
INFO - 2023-04-28 10:43:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:43:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:43:43 --> Utf8 Class Initialized
INFO - 2023-04-28 10:43:43 --> URI Class Initialized
INFO - 2023-04-28 10:43:43 --> Router Class Initialized
INFO - 2023-04-28 10:43:43 --> Output Class Initialized
INFO - 2023-04-28 10:43:43 --> Security Class Initialized
DEBUG - 2023-04-28 10:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:43:43 --> Input Class Initialized
INFO - 2023-04-28 10:43:43 --> Language Class Initialized
INFO - 2023-04-28 10:43:43 --> Loader Class Initialized
INFO - 2023-04-28 10:43:43 --> Controller Class Initialized
DEBUG - 2023-04-28 10:43:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:43:43 --> Database Driver Class Initialized
INFO - 2023-04-28 10:43:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:43:43 --> Final output sent to browser
DEBUG - 2023-04-28 10:43:43 --> Total execution time: 0.0133
INFO - 2023-04-28 10:45:14 --> Config Class Initialized
INFO - 2023-04-28 10:45:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:14 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:14 --> URI Class Initialized
INFO - 2023-04-28 10:45:14 --> Router Class Initialized
INFO - 2023-04-28 10:45:14 --> Output Class Initialized
INFO - 2023-04-28 10:45:14 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:14 --> Input Class Initialized
INFO - 2023-04-28 10:45:14 --> Language Class Initialized
INFO - 2023-04-28 10:45:14 --> Loader Class Initialized
INFO - 2023-04-28 10:45:14 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:14 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:14 --> Total execution time: 0.0138
INFO - 2023-04-28 10:45:14 --> Config Class Initialized
INFO - 2023-04-28 10:45:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:14 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:14 --> URI Class Initialized
INFO - 2023-04-28 10:45:14 --> Router Class Initialized
INFO - 2023-04-28 10:45:14 --> Output Class Initialized
INFO - 2023-04-28 10:45:14 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:14 --> Input Class Initialized
INFO - 2023-04-28 10:45:14 --> Language Class Initialized
INFO - 2023-04-28 10:45:14 --> Loader Class Initialized
INFO - 2023-04-28 10:45:14 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:14 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:14 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:14 --> Total execution time: 0.0193
INFO - 2023-04-28 10:45:14 --> Config Class Initialized
INFO - 2023-04-28 10:45:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:14 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:14 --> URI Class Initialized
INFO - 2023-04-28 10:45:14 --> Router Class Initialized
INFO - 2023-04-28 10:45:14 --> Output Class Initialized
INFO - 2023-04-28 10:45:14 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:14 --> Input Class Initialized
INFO - 2023-04-28 10:45:14 --> Language Class Initialized
INFO - 2023-04-28 10:45:14 --> Loader Class Initialized
INFO - 2023-04-28 10:45:14 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:14 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:14 --> Total execution time: 0.0504
INFO - 2023-04-28 10:45:14 --> Config Class Initialized
INFO - 2023-04-28 10:45:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:14 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:14 --> URI Class Initialized
INFO - 2023-04-28 10:45:14 --> Router Class Initialized
INFO - 2023-04-28 10:45:14 --> Output Class Initialized
INFO - 2023-04-28 10:45:14 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:14 --> Input Class Initialized
INFO - 2023-04-28 10:45:14 --> Language Class Initialized
INFO - 2023-04-28 10:45:14 --> Loader Class Initialized
INFO - 2023-04-28 10:45:14 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:14 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:14 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:14 --> Total execution time: 0.0220
INFO - 2023-04-28 10:45:18 --> Config Class Initialized
INFO - 2023-04-28 10:45:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:18 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:18 --> URI Class Initialized
INFO - 2023-04-28 10:45:18 --> Router Class Initialized
INFO - 2023-04-28 10:45:18 --> Output Class Initialized
INFO - 2023-04-28 10:45:18 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:18 --> Input Class Initialized
INFO - 2023-04-28 10:45:18 --> Language Class Initialized
INFO - 2023-04-28 10:45:18 --> Loader Class Initialized
INFO - 2023-04-28 10:45:18 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:18 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:18 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:18 --> Total execution time: 0.0143
INFO - 2023-04-28 10:45:18 --> Config Class Initialized
INFO - 2023-04-28 10:45:18 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:18 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:18 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:18 --> URI Class Initialized
INFO - 2023-04-28 10:45:18 --> Router Class Initialized
INFO - 2023-04-28 10:45:18 --> Output Class Initialized
INFO - 2023-04-28 10:45:18 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:18 --> Input Class Initialized
INFO - 2023-04-28 10:45:18 --> Language Class Initialized
INFO - 2023-04-28 10:45:18 --> Loader Class Initialized
INFO - 2023-04-28 10:45:18 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:18 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:18 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:18 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:18 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:18 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:18 --> Total execution time: 0.0348
INFO - 2023-04-28 10:45:20 --> Config Class Initialized
INFO - 2023-04-28 10:45:20 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:20 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:20 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:20 --> URI Class Initialized
INFO - 2023-04-28 10:45:20 --> Router Class Initialized
INFO - 2023-04-28 10:45:20 --> Output Class Initialized
INFO - 2023-04-28 10:45:20 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:20 --> Input Class Initialized
INFO - 2023-04-28 10:45:20 --> Language Class Initialized
INFO - 2023-04-28 10:45:20 --> Loader Class Initialized
INFO - 2023-04-28 10:45:20 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:20 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:21 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:21 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:21 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:21 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:21 --> Total execution time: 0.0414
INFO - 2023-04-28 10:45:25 --> Config Class Initialized
INFO - 2023-04-28 10:45:25 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:25 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:25 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:25 --> URI Class Initialized
INFO - 2023-04-28 10:45:25 --> Router Class Initialized
INFO - 2023-04-28 10:45:25 --> Output Class Initialized
INFO - 2023-04-28 10:45:25 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:25 --> Input Class Initialized
INFO - 2023-04-28 10:45:25 --> Language Class Initialized
INFO - 2023-04-28 10:45:25 --> Loader Class Initialized
INFO - 2023-04-28 10:45:25 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:25 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:25 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:25 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:25 --> Total execution time: 0.0148
INFO - 2023-04-28 10:45:25 --> Config Class Initialized
INFO - 2023-04-28 10:45:25 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:25 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:25 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:25 --> URI Class Initialized
INFO - 2023-04-28 10:45:25 --> Router Class Initialized
INFO - 2023-04-28 10:45:25 --> Output Class Initialized
INFO - 2023-04-28 10:45:25 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:25 --> Input Class Initialized
INFO - 2023-04-28 10:45:25 --> Language Class Initialized
INFO - 2023-04-28 10:45:25 --> Loader Class Initialized
INFO - 2023-04-28 10:45:25 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:25 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:25 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:25 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:25 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:25 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:25 --> Total execution time: 0.0206
INFO - 2023-04-28 10:45:29 --> Config Class Initialized
INFO - 2023-04-28 10:45:29 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:29 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:29 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:29 --> URI Class Initialized
INFO - 2023-04-28 10:45:29 --> Router Class Initialized
INFO - 2023-04-28 10:45:29 --> Output Class Initialized
INFO - 2023-04-28 10:45:29 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:29 --> Input Class Initialized
INFO - 2023-04-28 10:45:29 --> Language Class Initialized
INFO - 2023-04-28 10:45:29 --> Loader Class Initialized
INFO - 2023-04-28 10:45:29 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:29 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:29 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:29 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:29 --> Total execution time: 0.0124
INFO - 2023-04-28 10:45:29 --> Config Class Initialized
INFO - 2023-04-28 10:45:29 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:29 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:29 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:29 --> URI Class Initialized
INFO - 2023-04-28 10:45:29 --> Router Class Initialized
INFO - 2023-04-28 10:45:29 --> Output Class Initialized
INFO - 2023-04-28 10:45:29 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:29 --> Input Class Initialized
INFO - 2023-04-28 10:45:29 --> Language Class Initialized
INFO - 2023-04-28 10:45:29 --> Loader Class Initialized
INFO - 2023-04-28 10:45:29 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:29 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:29 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:29 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:29 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:29 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:29 --> Total execution time: 0.0364
INFO - 2023-04-28 10:45:34 --> Config Class Initialized
INFO - 2023-04-28 10:45:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:34 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:34 --> URI Class Initialized
INFO - 2023-04-28 10:45:34 --> Router Class Initialized
INFO - 2023-04-28 10:45:34 --> Output Class Initialized
INFO - 2023-04-28 10:45:34 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:34 --> Input Class Initialized
INFO - 2023-04-28 10:45:34 --> Language Class Initialized
INFO - 2023-04-28 10:45:34 --> Loader Class Initialized
INFO - 2023-04-28 10:45:34 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:34 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:34 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:34 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:34 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:34 --> Total execution time: 0.0880
INFO - 2023-04-28 10:45:34 --> Config Class Initialized
INFO - 2023-04-28 10:45:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:34 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:34 --> URI Class Initialized
INFO - 2023-04-28 10:45:34 --> Router Class Initialized
INFO - 2023-04-28 10:45:34 --> Output Class Initialized
INFO - 2023-04-28 10:45:34 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:34 --> Input Class Initialized
INFO - 2023-04-28 10:45:34 --> Language Class Initialized
INFO - 2023-04-28 10:45:34 --> Loader Class Initialized
INFO - 2023-04-28 10:45:34 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:34 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:34 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:34 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:35 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:35 --> Total execution time: 0.1246
INFO - 2023-04-28 10:45:38 --> Config Class Initialized
INFO - 2023-04-28 10:45:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:38 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:38 --> URI Class Initialized
INFO - 2023-04-28 10:45:38 --> Router Class Initialized
INFO - 2023-04-28 10:45:38 --> Output Class Initialized
INFO - 2023-04-28 10:45:38 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:38 --> Input Class Initialized
INFO - 2023-04-28 10:45:38 --> Language Class Initialized
INFO - 2023-04-28 10:45:38 --> Loader Class Initialized
INFO - 2023-04-28 10:45:38 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:38 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:38 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:38 --> Total execution time: 0.0159
INFO - 2023-04-28 10:45:38 --> Config Class Initialized
INFO - 2023-04-28 10:45:38 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:38 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:38 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:38 --> URI Class Initialized
INFO - 2023-04-28 10:45:38 --> Router Class Initialized
INFO - 2023-04-28 10:45:38 --> Output Class Initialized
INFO - 2023-04-28 10:45:38 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:38 --> Input Class Initialized
INFO - 2023-04-28 10:45:38 --> Language Class Initialized
INFO - 2023-04-28 10:45:38 --> Loader Class Initialized
INFO - 2023-04-28 10:45:38 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:38 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:38 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:38 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:38 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:38 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:38 --> Total execution time: 0.0204
INFO - 2023-04-28 10:45:39 --> Config Class Initialized
INFO - 2023-04-28 10:45:39 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:39 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:39 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:39 --> URI Class Initialized
INFO - 2023-04-28 10:45:39 --> Router Class Initialized
INFO - 2023-04-28 10:45:39 --> Output Class Initialized
INFO - 2023-04-28 10:45:39 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:39 --> Input Class Initialized
INFO - 2023-04-28 10:45:39 --> Language Class Initialized
INFO - 2023-04-28 10:45:39 --> Loader Class Initialized
INFO - 2023-04-28 10:45:39 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:39 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:39 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:39 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:39 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:39 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:39 --> Total execution time: 0.0249
INFO - 2023-04-28 10:45:43 --> Config Class Initialized
INFO - 2023-04-28 10:45:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:43 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:43 --> URI Class Initialized
INFO - 2023-04-28 10:45:43 --> Router Class Initialized
INFO - 2023-04-28 10:45:43 --> Output Class Initialized
INFO - 2023-04-28 10:45:43 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:43 --> Input Class Initialized
INFO - 2023-04-28 10:45:43 --> Language Class Initialized
INFO - 2023-04-28 10:45:43 --> Loader Class Initialized
INFO - 2023-04-28 10:45:43 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:43 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:43 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:43 --> Total execution time: 0.0148
INFO - 2023-04-28 10:45:43 --> Config Class Initialized
INFO - 2023-04-28 10:45:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:43 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:43 --> URI Class Initialized
INFO - 2023-04-28 10:45:43 --> Router Class Initialized
INFO - 2023-04-28 10:45:43 --> Output Class Initialized
INFO - 2023-04-28 10:45:43 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:43 --> Input Class Initialized
INFO - 2023-04-28 10:45:43 --> Language Class Initialized
INFO - 2023-04-28 10:45:43 --> Loader Class Initialized
INFO - 2023-04-28 10:45:43 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:43 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:43 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:43 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:43 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:43 --> Total execution time: 0.0360
INFO - 2023-04-28 10:45:44 --> Config Class Initialized
INFO - 2023-04-28 10:45:44 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:44 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:44 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:44 --> URI Class Initialized
INFO - 2023-04-28 10:45:44 --> Router Class Initialized
INFO - 2023-04-28 10:45:44 --> Output Class Initialized
INFO - 2023-04-28 10:45:44 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:44 --> Input Class Initialized
INFO - 2023-04-28 10:45:44 --> Language Class Initialized
INFO - 2023-04-28 10:45:44 --> Loader Class Initialized
INFO - 2023-04-28 10:45:44 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:44 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:44 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:44 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:44 --> Total execution time: 0.0129
INFO - 2023-04-28 10:45:44 --> Config Class Initialized
INFO - 2023-04-28 10:45:44 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:44 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:44 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:44 --> URI Class Initialized
INFO - 2023-04-28 10:45:44 --> Router Class Initialized
INFO - 2023-04-28 10:45:44 --> Output Class Initialized
INFO - 2023-04-28 10:45:44 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:44 --> Input Class Initialized
INFO - 2023-04-28 10:45:44 --> Language Class Initialized
INFO - 2023-04-28 10:45:44 --> Loader Class Initialized
INFO - 2023-04-28 10:45:44 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:44 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:44 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:44 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:44 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:44 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:44 --> Total execution time: 0.0239
INFO - 2023-04-28 10:45:46 --> Config Class Initialized
INFO - 2023-04-28 10:45:46 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:46 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:46 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:46 --> URI Class Initialized
INFO - 2023-04-28 10:45:46 --> Router Class Initialized
INFO - 2023-04-28 10:45:46 --> Output Class Initialized
INFO - 2023-04-28 10:45:46 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:46 --> Input Class Initialized
INFO - 2023-04-28 10:45:46 --> Language Class Initialized
INFO - 2023-04-28 10:45:46 --> Loader Class Initialized
INFO - 2023-04-28 10:45:46 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:46 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:46 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:46 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:46 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:46 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:46 --> Total execution time: 0.0408
INFO - 2023-04-28 10:45:49 --> Config Class Initialized
INFO - 2023-04-28 10:45:49 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:49 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:49 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:49 --> URI Class Initialized
INFO - 2023-04-28 10:45:49 --> Router Class Initialized
INFO - 2023-04-28 10:45:49 --> Output Class Initialized
INFO - 2023-04-28 10:45:49 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:49 --> Input Class Initialized
INFO - 2023-04-28 10:45:49 --> Language Class Initialized
INFO - 2023-04-28 10:45:49 --> Loader Class Initialized
INFO - 2023-04-28 10:45:49 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:49 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:49 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:49 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:49 --> Total execution time: 0.0127
INFO - 2023-04-28 10:45:49 --> Config Class Initialized
INFO - 2023-04-28 10:45:49 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:49 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:49 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:49 --> URI Class Initialized
INFO - 2023-04-28 10:45:49 --> Router Class Initialized
INFO - 2023-04-28 10:45:49 --> Output Class Initialized
INFO - 2023-04-28 10:45:49 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:49 --> Input Class Initialized
INFO - 2023-04-28 10:45:49 --> Language Class Initialized
INFO - 2023-04-28 10:45:49 --> Loader Class Initialized
INFO - 2023-04-28 10:45:49 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:49 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:49 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:49 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:49 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:49 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:49 --> Total execution time: 0.0420
INFO - 2023-04-28 10:45:54 --> Config Class Initialized
INFO - 2023-04-28 10:45:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:54 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:54 --> URI Class Initialized
INFO - 2023-04-28 10:45:54 --> Router Class Initialized
INFO - 2023-04-28 10:45:54 --> Output Class Initialized
INFO - 2023-04-28 10:45:54 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:54 --> Input Class Initialized
INFO - 2023-04-28 10:45:54 --> Language Class Initialized
INFO - 2023-04-28 10:45:54 --> Loader Class Initialized
INFO - 2023-04-28 10:45:54 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:54 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:54 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:54 --> Total execution time: 0.0119
INFO - 2023-04-28 10:45:54 --> Config Class Initialized
INFO - 2023-04-28 10:45:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:54 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:54 --> URI Class Initialized
INFO - 2023-04-28 10:45:54 --> Router Class Initialized
INFO - 2023-04-28 10:45:54 --> Output Class Initialized
INFO - 2023-04-28 10:45:54 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:54 --> Input Class Initialized
INFO - 2023-04-28 10:45:54 --> Language Class Initialized
INFO - 2023-04-28 10:45:54 --> Loader Class Initialized
INFO - 2023-04-28 10:45:54 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:54 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:54 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:54 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:54 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:54 --> Total execution time: 0.0211
INFO - 2023-04-28 10:45:54 --> Config Class Initialized
INFO - 2023-04-28 10:45:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:54 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:54 --> URI Class Initialized
INFO - 2023-04-28 10:45:54 --> Router Class Initialized
INFO - 2023-04-28 10:45:54 --> Output Class Initialized
INFO - 2023-04-28 10:45:54 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:54 --> Input Class Initialized
INFO - 2023-04-28 10:45:54 --> Language Class Initialized
INFO - 2023-04-28 10:45:54 --> Loader Class Initialized
INFO - 2023-04-28 10:45:54 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:54 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:54 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:54 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:54 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:54 --> Total execution time: 0.0986
INFO - 2023-04-28 10:45:54 --> Config Class Initialized
INFO - 2023-04-28 10:45:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:54 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:54 --> URI Class Initialized
INFO - 2023-04-28 10:45:54 --> Router Class Initialized
INFO - 2023-04-28 10:45:54 --> Output Class Initialized
INFO - 2023-04-28 10:45:54 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:54 --> Input Class Initialized
INFO - 2023-04-28 10:45:54 --> Language Class Initialized
INFO - 2023-04-28 10:45:54 --> Loader Class Initialized
INFO - 2023-04-28 10:45:54 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:54 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:54 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:54 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:54 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:54 --> Total execution time: 0.0824
INFO - 2023-04-28 10:45:56 --> Config Class Initialized
INFO - 2023-04-28 10:45:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:56 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:56 --> URI Class Initialized
INFO - 2023-04-28 10:45:56 --> Router Class Initialized
INFO - 2023-04-28 10:45:56 --> Output Class Initialized
INFO - 2023-04-28 10:45:56 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:56 --> Input Class Initialized
INFO - 2023-04-28 10:45:56 --> Language Class Initialized
INFO - 2023-04-28 10:45:56 --> Loader Class Initialized
INFO - 2023-04-28 10:45:56 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:56 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:56 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:56 --> Total execution time: 0.0156
INFO - 2023-04-28 10:45:56 --> Config Class Initialized
INFO - 2023-04-28 10:45:56 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:45:56 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:45:56 --> Utf8 Class Initialized
INFO - 2023-04-28 10:45:56 --> URI Class Initialized
INFO - 2023-04-28 10:45:56 --> Router Class Initialized
INFO - 2023-04-28 10:45:56 --> Output Class Initialized
INFO - 2023-04-28 10:45:56 --> Security Class Initialized
DEBUG - 2023-04-28 10:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:45:56 --> Input Class Initialized
INFO - 2023-04-28 10:45:56 --> Language Class Initialized
INFO - 2023-04-28 10:45:56 --> Loader Class Initialized
INFO - 2023-04-28 10:45:56 --> Controller Class Initialized
DEBUG - 2023-04-28 10:45:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:45:56 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:56 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:45:56 --> Database Driver Class Initialized
INFO - 2023-04-28 10:45:56 --> Model "Login_model" initialized
INFO - 2023-04-28 10:45:56 --> Final output sent to browser
DEBUG - 2023-04-28 10:45:56 --> Total execution time: 0.0394
INFO - 2023-04-28 10:46:14 --> Config Class Initialized
INFO - 2023-04-28 10:46:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:46:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:46:14 --> Utf8 Class Initialized
INFO - 2023-04-28 10:46:14 --> URI Class Initialized
INFO - 2023-04-28 10:46:14 --> Router Class Initialized
INFO - 2023-04-28 10:46:14 --> Output Class Initialized
INFO - 2023-04-28 10:46:14 --> Security Class Initialized
DEBUG - 2023-04-28 10:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:46:14 --> Input Class Initialized
INFO - 2023-04-28 10:46:14 --> Language Class Initialized
INFO - 2023-04-28 10:46:14 --> Loader Class Initialized
INFO - 2023-04-28 10:46:14 --> Controller Class Initialized
DEBUG - 2023-04-28 10:46:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:46:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:46:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:46:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:46:14 --> Model "Login_model" initialized
INFO - 2023-04-28 10:46:14 --> Final output sent to browser
DEBUG - 2023-04-28 10:46:14 --> Total execution time: 0.1050
INFO - 2023-04-28 10:46:14 --> Config Class Initialized
INFO - 2023-04-28 10:46:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:46:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:46:14 --> Utf8 Class Initialized
INFO - 2023-04-28 10:46:14 --> URI Class Initialized
INFO - 2023-04-28 10:46:14 --> Router Class Initialized
INFO - 2023-04-28 10:46:14 --> Output Class Initialized
INFO - 2023-04-28 10:46:14 --> Security Class Initialized
DEBUG - 2023-04-28 10:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:46:14 --> Input Class Initialized
INFO - 2023-04-28 10:46:14 --> Language Class Initialized
INFO - 2023-04-28 10:46:14 --> Loader Class Initialized
INFO - 2023-04-28 10:46:14 --> Controller Class Initialized
DEBUG - 2023-04-28 10:46:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:46:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:46:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:46:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:46:14 --> Model "Login_model" initialized
INFO - 2023-04-28 10:46:14 --> Final output sent to browser
DEBUG - 2023-04-28 10:46:14 --> Total execution time: 0.0974
INFO - 2023-04-28 10:46:34 --> Config Class Initialized
INFO - 2023-04-28 10:46:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:46:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:46:34 --> Utf8 Class Initialized
INFO - 2023-04-28 10:46:34 --> URI Class Initialized
INFO - 2023-04-28 10:46:34 --> Router Class Initialized
INFO - 2023-04-28 10:46:34 --> Output Class Initialized
INFO - 2023-04-28 10:46:34 --> Security Class Initialized
DEBUG - 2023-04-28 10:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:46:34 --> Input Class Initialized
INFO - 2023-04-28 10:46:34 --> Language Class Initialized
INFO - 2023-04-28 10:46:34 --> Loader Class Initialized
INFO - 2023-04-28 10:46:34 --> Controller Class Initialized
DEBUG - 2023-04-28 10:46:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:46:34 --> Database Driver Class Initialized
INFO - 2023-04-28 10:46:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:46:34 --> Database Driver Class Initialized
INFO - 2023-04-28 10:46:34 --> Model "Login_model" initialized
INFO - 2023-04-28 10:46:34 --> Final output sent to browser
DEBUG - 2023-04-28 10:46:34 --> Total execution time: 0.0899
INFO - 2023-04-28 10:46:34 --> Config Class Initialized
INFO - 2023-04-28 10:46:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:46:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:46:34 --> Utf8 Class Initialized
INFO - 2023-04-28 10:46:34 --> URI Class Initialized
INFO - 2023-04-28 10:46:34 --> Router Class Initialized
INFO - 2023-04-28 10:46:34 --> Output Class Initialized
INFO - 2023-04-28 10:46:34 --> Security Class Initialized
DEBUG - 2023-04-28 10:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:46:34 --> Input Class Initialized
INFO - 2023-04-28 10:46:34 --> Language Class Initialized
INFO - 2023-04-28 10:46:34 --> Loader Class Initialized
INFO - 2023-04-28 10:46:34 --> Controller Class Initialized
DEBUG - 2023-04-28 10:46:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:46:34 --> Database Driver Class Initialized
INFO - 2023-04-28 10:46:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:46:34 --> Database Driver Class Initialized
INFO - 2023-04-28 10:46:34 --> Model "Login_model" initialized
INFO - 2023-04-28 10:46:34 --> Final output sent to browser
DEBUG - 2023-04-28 10:46:34 --> Total execution time: 0.0752
INFO - 2023-04-28 10:46:54 --> Config Class Initialized
INFO - 2023-04-28 10:46:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:46:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:46:54 --> Utf8 Class Initialized
INFO - 2023-04-28 10:46:54 --> URI Class Initialized
INFO - 2023-04-28 10:46:54 --> Router Class Initialized
INFO - 2023-04-28 10:46:54 --> Output Class Initialized
INFO - 2023-04-28 10:46:54 --> Security Class Initialized
DEBUG - 2023-04-28 10:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:46:54 --> Input Class Initialized
INFO - 2023-04-28 10:46:54 --> Language Class Initialized
INFO - 2023-04-28 10:46:54 --> Loader Class Initialized
INFO - 2023-04-28 10:46:54 --> Controller Class Initialized
DEBUG - 2023-04-28 10:46:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:46:54 --> Database Driver Class Initialized
INFO - 2023-04-28 10:46:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:46:54 --> Database Driver Class Initialized
INFO - 2023-04-28 10:46:54 --> Model "Login_model" initialized
INFO - 2023-04-28 10:46:54 --> Final output sent to browser
DEBUG - 2023-04-28 10:46:54 --> Total execution time: 0.0938
INFO - 2023-04-28 10:46:54 --> Config Class Initialized
INFO - 2023-04-28 10:46:54 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:46:54 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:46:54 --> Utf8 Class Initialized
INFO - 2023-04-28 10:46:54 --> URI Class Initialized
INFO - 2023-04-28 10:46:54 --> Router Class Initialized
INFO - 2023-04-28 10:46:54 --> Output Class Initialized
INFO - 2023-04-28 10:46:54 --> Security Class Initialized
DEBUG - 2023-04-28 10:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:46:54 --> Input Class Initialized
INFO - 2023-04-28 10:46:54 --> Language Class Initialized
INFO - 2023-04-28 10:46:54 --> Loader Class Initialized
INFO - 2023-04-28 10:46:54 --> Controller Class Initialized
DEBUG - 2023-04-28 10:46:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:46:54 --> Database Driver Class Initialized
INFO - 2023-04-28 10:46:54 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:46:54 --> Database Driver Class Initialized
INFO - 2023-04-28 10:46:54 --> Model "Login_model" initialized
INFO - 2023-04-28 10:46:54 --> Final output sent to browser
DEBUG - 2023-04-28 10:46:54 --> Total execution time: 0.1272
INFO - 2023-04-28 10:47:14 --> Config Class Initialized
INFO - 2023-04-28 10:47:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:47:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:47:14 --> Utf8 Class Initialized
INFO - 2023-04-28 10:47:14 --> URI Class Initialized
INFO - 2023-04-28 10:47:14 --> Router Class Initialized
INFO - 2023-04-28 10:47:14 --> Output Class Initialized
INFO - 2023-04-28 10:47:14 --> Security Class Initialized
DEBUG - 2023-04-28 10:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:47:14 --> Input Class Initialized
INFO - 2023-04-28 10:47:14 --> Language Class Initialized
INFO - 2023-04-28 10:47:14 --> Loader Class Initialized
INFO - 2023-04-28 10:47:14 --> Controller Class Initialized
DEBUG - 2023-04-28 10:47:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:47:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:47:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:47:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:47:14 --> Model "Login_model" initialized
INFO - 2023-04-28 10:47:14 --> Final output sent to browser
DEBUG - 2023-04-28 10:47:14 --> Total execution time: 0.1010
INFO - 2023-04-28 10:47:14 --> Config Class Initialized
INFO - 2023-04-28 10:47:14 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:47:14 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:47:14 --> Utf8 Class Initialized
INFO - 2023-04-28 10:47:14 --> URI Class Initialized
INFO - 2023-04-28 10:47:14 --> Router Class Initialized
INFO - 2023-04-28 10:47:14 --> Output Class Initialized
INFO - 2023-04-28 10:47:14 --> Security Class Initialized
DEBUG - 2023-04-28 10:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:47:14 --> Input Class Initialized
INFO - 2023-04-28 10:47:14 --> Language Class Initialized
INFO - 2023-04-28 10:47:14 --> Loader Class Initialized
INFO - 2023-04-28 10:47:14 --> Controller Class Initialized
DEBUG - 2023-04-28 10:47:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:47:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:47:14 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:47:14 --> Database Driver Class Initialized
INFO - 2023-04-28 10:47:14 --> Model "Login_model" initialized
INFO - 2023-04-28 10:47:14 --> Final output sent to browser
DEBUG - 2023-04-28 10:47:14 --> Total execution time: 0.0834
INFO - 2023-04-28 10:47:34 --> Config Class Initialized
INFO - 2023-04-28 10:47:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:47:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:47:34 --> Utf8 Class Initialized
INFO - 2023-04-28 10:47:34 --> URI Class Initialized
INFO - 2023-04-28 10:47:34 --> Router Class Initialized
INFO - 2023-04-28 10:47:34 --> Output Class Initialized
INFO - 2023-04-28 10:47:34 --> Security Class Initialized
DEBUG - 2023-04-28 10:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:47:34 --> Input Class Initialized
INFO - 2023-04-28 10:47:34 --> Language Class Initialized
INFO - 2023-04-28 10:47:34 --> Loader Class Initialized
INFO - 2023-04-28 10:47:34 --> Controller Class Initialized
DEBUG - 2023-04-28 10:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:47:34 --> Database Driver Class Initialized
INFO - 2023-04-28 10:47:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:47:34 --> Database Driver Class Initialized
INFO - 2023-04-28 10:47:34 --> Model "Login_model" initialized
INFO - 2023-04-28 10:47:34 --> Final output sent to browser
DEBUG - 2023-04-28 10:47:34 --> Total execution time: 0.0925
INFO - 2023-04-28 10:47:34 --> Config Class Initialized
INFO - 2023-04-28 10:47:34 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:47:34 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:47:34 --> Utf8 Class Initialized
INFO - 2023-04-28 10:47:34 --> URI Class Initialized
INFO - 2023-04-28 10:47:34 --> Router Class Initialized
INFO - 2023-04-28 10:47:34 --> Output Class Initialized
INFO - 2023-04-28 10:47:34 --> Security Class Initialized
DEBUG - 2023-04-28 10:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:47:34 --> Input Class Initialized
INFO - 2023-04-28 10:47:34 --> Language Class Initialized
INFO - 2023-04-28 10:47:34 --> Loader Class Initialized
INFO - 2023-04-28 10:47:34 --> Controller Class Initialized
DEBUG - 2023-04-28 10:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:47:34 --> Database Driver Class Initialized
INFO - 2023-04-28 10:47:34 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:47:34 --> Database Driver Class Initialized
INFO - 2023-04-28 10:47:34 --> Model "Login_model" initialized
INFO - 2023-04-28 10:47:34 --> Final output sent to browser
DEBUG - 2023-04-28 10:47:34 --> Total execution time: 0.0740
INFO - 2023-04-28 10:47:41 --> Config Class Initialized
INFO - 2023-04-28 10:47:41 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:47:41 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:47:41 --> Utf8 Class Initialized
INFO - 2023-04-28 10:47:41 --> URI Class Initialized
INFO - 2023-04-28 10:47:41 --> Router Class Initialized
INFO - 2023-04-28 10:47:41 --> Output Class Initialized
INFO - 2023-04-28 10:47:41 --> Security Class Initialized
DEBUG - 2023-04-28 10:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:47:41 --> Input Class Initialized
INFO - 2023-04-28 10:47:41 --> Language Class Initialized
INFO - 2023-04-28 10:47:41 --> Loader Class Initialized
INFO - 2023-04-28 10:47:41 --> Controller Class Initialized
DEBUG - 2023-04-28 10:47:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:47:41 --> Database Driver Class Initialized
INFO - 2023-04-28 10:47:41 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:47:41 --> Final output sent to browser
DEBUG - 2023-04-28 10:47:41 --> Total execution time: 0.0234
INFO - 2023-04-28 10:47:41 --> Config Class Initialized
INFO - 2023-04-28 10:47:41 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:47:41 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:47:41 --> Utf8 Class Initialized
INFO - 2023-04-28 10:47:41 --> URI Class Initialized
INFO - 2023-04-28 10:47:41 --> Router Class Initialized
INFO - 2023-04-28 10:47:41 --> Output Class Initialized
INFO - 2023-04-28 10:47:41 --> Security Class Initialized
DEBUG - 2023-04-28 10:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:47:41 --> Input Class Initialized
INFO - 2023-04-28 10:47:41 --> Language Class Initialized
INFO - 2023-04-28 10:47:41 --> Loader Class Initialized
INFO - 2023-04-28 10:47:41 --> Controller Class Initialized
DEBUG - 2023-04-28 10:47:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:47:41 --> Database Driver Class Initialized
INFO - 2023-04-28 10:47:41 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:47:41 --> Final output sent to browser
DEBUG - 2023-04-28 10:47:41 --> Total execution time: 0.0588
INFO - 2023-04-28 10:47:43 --> Config Class Initialized
INFO - 2023-04-28 10:47:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:47:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:47:43 --> Utf8 Class Initialized
INFO - 2023-04-28 10:47:43 --> URI Class Initialized
INFO - 2023-04-28 10:47:43 --> Router Class Initialized
INFO - 2023-04-28 10:47:43 --> Output Class Initialized
INFO - 2023-04-28 10:47:43 --> Security Class Initialized
DEBUG - 2023-04-28 10:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:47:43 --> Input Class Initialized
INFO - 2023-04-28 10:47:43 --> Language Class Initialized
INFO - 2023-04-28 10:47:43 --> Loader Class Initialized
INFO - 2023-04-28 10:47:43 --> Controller Class Initialized
DEBUG - 2023-04-28 10:47:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:47:43 --> Database Driver Class Initialized
INFO - 2023-04-28 10:47:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:47:43 --> Final output sent to browser
DEBUG - 2023-04-28 10:47:43 --> Total execution time: 0.0256
INFO - 2023-04-28 10:47:43 --> Config Class Initialized
INFO - 2023-04-28 10:47:43 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:47:43 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:47:43 --> Utf8 Class Initialized
INFO - 2023-04-28 10:47:43 --> URI Class Initialized
INFO - 2023-04-28 10:47:43 --> Router Class Initialized
INFO - 2023-04-28 10:47:43 --> Output Class Initialized
INFO - 2023-04-28 10:47:43 --> Security Class Initialized
DEBUG - 2023-04-28 10:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:47:43 --> Input Class Initialized
INFO - 2023-04-28 10:47:43 --> Language Class Initialized
INFO - 2023-04-28 10:47:43 --> Loader Class Initialized
INFO - 2023-04-28 10:47:43 --> Controller Class Initialized
DEBUG - 2023-04-28 10:47:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:47:43 --> Database Driver Class Initialized
INFO - 2023-04-28 10:47:43 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:47:43 --> Final output sent to browser
DEBUG - 2023-04-28 10:47:43 --> Total execution time: 0.1010
INFO - 2023-04-28 10:47:47 --> Config Class Initialized
INFO - 2023-04-28 10:47:47 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:47:47 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:47:47 --> Utf8 Class Initialized
INFO - 2023-04-28 10:47:47 --> URI Class Initialized
INFO - 2023-04-28 10:47:47 --> Router Class Initialized
INFO - 2023-04-28 10:47:47 --> Output Class Initialized
INFO - 2023-04-28 10:47:47 --> Security Class Initialized
DEBUG - 2023-04-28 10:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:47:47 --> Input Class Initialized
INFO - 2023-04-28 10:47:47 --> Language Class Initialized
INFO - 2023-04-28 10:47:47 --> Loader Class Initialized
INFO - 2023-04-28 10:47:47 --> Controller Class Initialized
DEBUG - 2023-04-28 10:47:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:47:47 --> Final output sent to browser
DEBUG - 2023-04-28 10:47:47 --> Total execution time: 0.0040
INFO - 2023-04-28 10:47:47 --> Config Class Initialized
INFO - 2023-04-28 10:47:47 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:47:47 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:47:47 --> Utf8 Class Initialized
INFO - 2023-04-28 10:47:47 --> URI Class Initialized
INFO - 2023-04-28 10:47:47 --> Router Class Initialized
INFO - 2023-04-28 10:47:47 --> Output Class Initialized
INFO - 2023-04-28 10:47:47 --> Security Class Initialized
DEBUG - 2023-04-28 10:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:47:47 --> Input Class Initialized
INFO - 2023-04-28 10:47:47 --> Language Class Initialized
INFO - 2023-04-28 10:47:47 --> Loader Class Initialized
INFO - 2023-04-28 10:47:47 --> Controller Class Initialized
DEBUG - 2023-04-28 10:47:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:47:47 --> Database Driver Class Initialized
INFO - 2023-04-28 10:47:47 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:47:47 --> Final output sent to browser
DEBUG - 2023-04-28 10:47:47 --> Total execution time: 0.0567
INFO - 2023-04-28 10:48:00 --> Config Class Initialized
INFO - 2023-04-28 10:48:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:48:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:48:00 --> Utf8 Class Initialized
INFO - 2023-04-28 10:48:00 --> URI Class Initialized
INFO - 2023-04-28 10:48:00 --> Router Class Initialized
INFO - 2023-04-28 10:48:00 --> Output Class Initialized
INFO - 2023-04-28 10:48:00 --> Security Class Initialized
DEBUG - 2023-04-28 10:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:48:00 --> Input Class Initialized
INFO - 2023-04-28 10:48:00 --> Language Class Initialized
INFO - 2023-04-28 10:48:00 --> Loader Class Initialized
INFO - 2023-04-28 10:48:00 --> Controller Class Initialized
DEBUG - 2023-04-28 10:48:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:48:00 --> Database Driver Class Initialized
INFO - 2023-04-28 10:48:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:48:00 --> Final output sent to browser
DEBUG - 2023-04-28 10:48:00 --> Total execution time: 0.0217
INFO - 2023-04-28 10:48:00 --> Config Class Initialized
INFO - 2023-04-28 10:48:00 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:48:00 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:48:00 --> Utf8 Class Initialized
INFO - 2023-04-28 10:48:00 --> URI Class Initialized
INFO - 2023-04-28 10:48:00 --> Router Class Initialized
INFO - 2023-04-28 10:48:00 --> Output Class Initialized
INFO - 2023-04-28 10:48:00 --> Security Class Initialized
DEBUG - 2023-04-28 10:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:48:00 --> Input Class Initialized
INFO - 2023-04-28 10:48:00 --> Language Class Initialized
INFO - 2023-04-28 10:48:00 --> Loader Class Initialized
INFO - 2023-04-28 10:48:00 --> Controller Class Initialized
DEBUG - 2023-04-28 10:48:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:48:00 --> Database Driver Class Initialized
INFO - 2023-04-28 10:48:00 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:48:00 --> Final output sent to browser
DEBUG - 2023-04-28 10:48:00 --> Total execution time: 0.0164
INFO - 2023-04-28 10:48:03 --> Config Class Initialized
INFO - 2023-04-28 10:48:03 --> Config Class Initialized
INFO - 2023-04-28 10:48:03 --> Hooks Class Initialized
INFO - 2023-04-28 10:48:03 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:48:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:48:03 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:48:03 --> Utf8 Class Initialized
INFO - 2023-04-28 10:48:03 --> Utf8 Class Initialized
INFO - 2023-04-28 10:48:03 --> URI Class Initialized
INFO - 2023-04-28 10:48:03 --> URI Class Initialized
INFO - 2023-04-28 10:48:03 --> Router Class Initialized
INFO - 2023-04-28 10:48:03 --> Router Class Initialized
INFO - 2023-04-28 10:48:03 --> Output Class Initialized
INFO - 2023-04-28 10:48:03 --> Output Class Initialized
INFO - 2023-04-28 10:48:03 --> Security Class Initialized
INFO - 2023-04-28 10:48:03 --> Security Class Initialized
DEBUG - 2023-04-28 10:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 10:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:48:03 --> Input Class Initialized
INFO - 2023-04-28 10:48:03 --> Input Class Initialized
INFO - 2023-04-28 10:48:03 --> Language Class Initialized
INFO - 2023-04-28 10:48:03 --> Language Class Initialized
INFO - 2023-04-28 10:48:03 --> Loader Class Initialized
INFO - 2023-04-28 10:48:03 --> Loader Class Initialized
INFO - 2023-04-28 10:48:03 --> Controller Class Initialized
INFO - 2023-04-28 10:48:03 --> Controller Class Initialized
DEBUG - 2023-04-28 10:48:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:48:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:48:03 --> Final output sent to browser
INFO - 2023-04-28 10:48:03 --> Database Driver Class Initialized
DEBUG - 2023-04-28 10:48:03 --> Total execution time: 0.0037
INFO - 2023-04-28 10:48:03 --> Config Class Initialized
INFO - 2023-04-28 10:48:03 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:48:03 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:48:03 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:48:03 --> Utf8 Class Initialized
INFO - 2023-04-28 10:48:03 --> URI Class Initialized
INFO - 2023-04-28 10:48:03 --> Router Class Initialized
INFO - 2023-04-28 10:48:03 --> Output Class Initialized
INFO - 2023-04-28 10:48:03 --> Security Class Initialized
DEBUG - 2023-04-28 10:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:48:03 --> Input Class Initialized
INFO - 2023-04-28 10:48:03 --> Language Class Initialized
INFO - 2023-04-28 10:48:03 --> Loader Class Initialized
INFO - 2023-04-28 10:48:03 --> Controller Class Initialized
DEBUG - 2023-04-28 10:48:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:48:03 --> Database Driver Class Initialized
INFO - 2023-04-28 10:48:03 --> Final output sent to browser
DEBUG - 2023-04-28 10:48:03 --> Total execution time: 0.0489
INFO - 2023-04-28 10:48:03 --> Config Class Initialized
INFO - 2023-04-28 10:48:03 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:48:03 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:48:03 --> Utf8 Class Initialized
INFO - 2023-04-28 10:48:03 --> URI Class Initialized
INFO - 2023-04-28 10:48:03 --> Router Class Initialized
INFO - 2023-04-28 10:48:03 --> Output Class Initialized
INFO - 2023-04-28 10:48:03 --> Security Class Initialized
DEBUG - 2023-04-28 10:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:48:03 --> Input Class Initialized
INFO - 2023-04-28 10:48:03 --> Language Class Initialized
INFO - 2023-04-28 10:48:03 --> Loader Class Initialized
INFO - 2023-04-28 10:48:03 --> Controller Class Initialized
DEBUG - 2023-04-28 10:48:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:48:03 --> Database Driver Class Initialized
INFO - 2023-04-28 10:48:03 --> Model "Login_model" initialized
INFO - 2023-04-28 10:48:03 --> Database Driver Class Initialized
INFO - 2023-04-28 10:48:03 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:48:03 --> Final output sent to browser
DEBUG - 2023-04-28 10:48:03 --> Total execution time: 0.0125
INFO - 2023-04-28 10:48:03 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:48:03 --> Final output sent to browser
DEBUG - 2023-04-28 10:48:03 --> Total execution time: 0.1041
INFO - 2023-04-28 10:48:05 --> Config Class Initialized
INFO - 2023-04-28 10:48:05 --> Config Class Initialized
INFO - 2023-04-28 10:48:05 --> Hooks Class Initialized
INFO - 2023-04-28 10:48:05 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:48:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:48:05 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:48:05 --> Utf8 Class Initialized
INFO - 2023-04-28 10:48:05 --> Utf8 Class Initialized
INFO - 2023-04-28 10:48:05 --> URI Class Initialized
INFO - 2023-04-28 10:48:05 --> URI Class Initialized
INFO - 2023-04-28 10:48:05 --> Router Class Initialized
INFO - 2023-04-28 10:48:05 --> Router Class Initialized
INFO - 2023-04-28 10:48:05 --> Output Class Initialized
INFO - 2023-04-28 10:48:05 --> Output Class Initialized
INFO - 2023-04-28 10:48:05 --> Security Class Initialized
INFO - 2023-04-28 10:48:05 --> Security Class Initialized
DEBUG - 2023-04-28 10:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-28 10:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:48:05 --> Input Class Initialized
INFO - 2023-04-28 10:48:05 --> Input Class Initialized
INFO - 2023-04-28 10:48:05 --> Language Class Initialized
INFO - 2023-04-28 10:48:05 --> Language Class Initialized
INFO - 2023-04-28 10:48:05 --> Loader Class Initialized
INFO - 2023-04-28 10:48:05 --> Loader Class Initialized
INFO - 2023-04-28 10:48:05 --> Controller Class Initialized
INFO - 2023-04-28 10:48:05 --> Controller Class Initialized
DEBUG - 2023-04-28 10:48:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:48:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:48:05 --> Database Driver Class Initialized
INFO - 2023-04-28 10:48:05 --> Database Driver Class Initialized
INFO - 2023-04-28 10:48:05 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:48:05 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:48:05 --> Final output sent to browser
DEBUG - 2023-04-28 10:48:05 --> Total execution time: 0.0181
INFO - 2023-04-28 10:48:05 --> Config Class Initialized
INFO - 2023-04-28 10:48:05 --> Database Driver Class Initialized
INFO - 2023-04-28 10:48:05 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:48:05 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:48:05 --> Utf8 Class Initialized
INFO - 2023-04-28 10:48:05 --> URI Class Initialized
INFO - 2023-04-28 10:48:05 --> Router Class Initialized
INFO - 2023-04-28 10:48:05 --> Output Class Initialized
INFO - 2023-04-28 10:48:05 --> Security Class Initialized
DEBUG - 2023-04-28 10:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:48:05 --> Input Class Initialized
INFO - 2023-04-28 10:48:05 --> Language Class Initialized
INFO - 2023-04-28 10:48:05 --> Loader Class Initialized
INFO - 2023-04-28 10:48:05 --> Controller Class Initialized
DEBUG - 2023-04-28 10:48:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:48:05 --> Database Driver Class Initialized
INFO - 2023-04-28 10:48:05 --> Model "Login_model" initialized
INFO - 2023-04-28 10:48:05 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:48:05 --> Final output sent to browser
DEBUG - 2023-04-28 10:48:05 --> Total execution time: 0.0552
INFO - 2023-04-28 10:48:05 --> Final output sent to browser
DEBUG - 2023-04-28 10:48:05 --> Total execution time: 0.1436
INFO - 2023-04-28 10:48:05 --> Config Class Initialized
INFO - 2023-04-28 10:48:05 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:48:05 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:48:05 --> Utf8 Class Initialized
INFO - 2023-04-28 10:48:05 --> URI Class Initialized
INFO - 2023-04-28 10:48:05 --> Router Class Initialized
INFO - 2023-04-28 10:48:05 --> Output Class Initialized
INFO - 2023-04-28 10:48:05 --> Security Class Initialized
DEBUG - 2023-04-28 10:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:48:05 --> Input Class Initialized
INFO - 2023-04-28 10:48:05 --> Language Class Initialized
INFO - 2023-04-28 10:48:05 --> Loader Class Initialized
INFO - 2023-04-28 10:48:05 --> Controller Class Initialized
DEBUG - 2023-04-28 10:48:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:48:05 --> Database Driver Class Initialized
INFO - 2023-04-28 10:48:05 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:48:05 --> Database Driver Class Initialized
INFO - 2023-04-28 10:48:05 --> Model "Login_model" initialized
INFO - 2023-04-28 10:48:05 --> Final output sent to browser
DEBUG - 2023-04-28 10:48:05 --> Total execution time: 0.1058
INFO - 2023-04-28 10:50:58 --> Config Class Initialized
INFO - 2023-04-28 10:50:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:50:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:50:58 --> Utf8 Class Initialized
INFO - 2023-04-28 10:50:58 --> URI Class Initialized
INFO - 2023-04-28 10:50:58 --> Router Class Initialized
INFO - 2023-04-28 10:50:58 --> Output Class Initialized
INFO - 2023-04-28 10:50:58 --> Security Class Initialized
DEBUG - 2023-04-28 10:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:50:58 --> Input Class Initialized
INFO - 2023-04-28 10:50:58 --> Language Class Initialized
INFO - 2023-04-28 10:50:58 --> Loader Class Initialized
INFO - 2023-04-28 10:50:58 --> Controller Class Initialized
DEBUG - 2023-04-28 10:50:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:50:58 --> Database Driver Class Initialized
INFO - 2023-04-28 10:50:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:50:58 --> Final output sent to browser
DEBUG - 2023-04-28 10:50:58 --> Total execution time: 0.0155
INFO - 2023-04-28 10:50:58 --> Config Class Initialized
INFO - 2023-04-28 10:50:58 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:50:58 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:50:58 --> Utf8 Class Initialized
INFO - 2023-04-28 10:50:58 --> URI Class Initialized
INFO - 2023-04-28 10:50:58 --> Router Class Initialized
INFO - 2023-04-28 10:50:58 --> Output Class Initialized
INFO - 2023-04-28 10:50:58 --> Security Class Initialized
DEBUG - 2023-04-28 10:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:50:58 --> Input Class Initialized
INFO - 2023-04-28 10:50:58 --> Language Class Initialized
INFO - 2023-04-28 10:50:58 --> Loader Class Initialized
INFO - 2023-04-28 10:50:58 --> Controller Class Initialized
DEBUG - 2023-04-28 10:50:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:50:58 --> Database Driver Class Initialized
INFO - 2023-04-28 10:50:58 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:50:58 --> Final output sent to browser
DEBUG - 2023-04-28 10:50:58 --> Total execution time: 0.0514
INFO - 2023-04-28 10:51:01 --> Config Class Initialized
INFO - 2023-04-28 10:51:01 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:51:01 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:51:01 --> Utf8 Class Initialized
INFO - 2023-04-28 10:51:01 --> URI Class Initialized
INFO - 2023-04-28 10:51:01 --> Router Class Initialized
INFO - 2023-04-28 10:51:01 --> Output Class Initialized
INFO - 2023-04-28 10:51:01 --> Security Class Initialized
DEBUG - 2023-04-28 10:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:51:01 --> Input Class Initialized
INFO - 2023-04-28 10:51:01 --> Language Class Initialized
INFO - 2023-04-28 10:51:01 --> Loader Class Initialized
INFO - 2023-04-28 10:51:01 --> Controller Class Initialized
DEBUG - 2023-04-28 10:51:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:51:01 --> Database Driver Class Initialized
INFO - 2023-04-28 10:51:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:51:01 --> Final output sent to browser
DEBUG - 2023-04-28 10:51:01 --> Total execution time: 0.0193
INFO - 2023-04-28 10:51:01 --> Config Class Initialized
INFO - 2023-04-28 10:51:01 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:51:01 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:51:01 --> Utf8 Class Initialized
INFO - 2023-04-28 10:51:01 --> URI Class Initialized
INFO - 2023-04-28 10:51:01 --> Router Class Initialized
INFO - 2023-04-28 10:51:01 --> Output Class Initialized
INFO - 2023-04-28 10:51:01 --> Security Class Initialized
DEBUG - 2023-04-28 10:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:51:01 --> Input Class Initialized
INFO - 2023-04-28 10:51:01 --> Language Class Initialized
INFO - 2023-04-28 10:51:01 --> Loader Class Initialized
INFO - 2023-04-28 10:51:01 --> Controller Class Initialized
DEBUG - 2023-04-28 10:51:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:51:01 --> Database Driver Class Initialized
INFO - 2023-04-28 10:51:01 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:51:01 --> Final output sent to browser
DEBUG - 2023-04-28 10:51:01 --> Total execution time: 0.0981
INFO - 2023-04-28 10:51:04 --> Config Class Initialized
INFO - 2023-04-28 10:51:04 --> Config Class Initialized
INFO - 2023-04-28 10:51:04 --> Hooks Class Initialized
INFO - 2023-04-28 10:51:04 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:51:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-28 10:51:04 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:51:04 --> Utf8 Class Initialized
INFO - 2023-04-28 10:51:04 --> URI Class Initialized
INFO - 2023-04-28 10:51:04 --> Utf8 Class Initialized
INFO - 2023-04-28 10:51:04 --> Router Class Initialized
INFO - 2023-04-28 10:51:04 --> URI Class Initialized
INFO - 2023-04-28 10:51:04 --> Output Class Initialized
INFO - 2023-04-28 10:51:04 --> Router Class Initialized
INFO - 2023-04-28 10:51:04 --> Security Class Initialized
INFO - 2023-04-28 10:51:04 --> Output Class Initialized
DEBUG - 2023-04-28 10:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:51:04 --> Input Class Initialized
INFO - 2023-04-28 10:51:04 --> Security Class Initialized
INFO - 2023-04-28 10:51:04 --> Language Class Initialized
DEBUG - 2023-04-28 10:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:51:04 --> Input Class Initialized
INFO - 2023-04-28 10:51:04 --> Loader Class Initialized
INFO - 2023-04-28 10:51:04 --> Language Class Initialized
INFO - 2023-04-28 10:51:04 --> Controller Class Initialized
INFO - 2023-04-28 10:51:04 --> Loader Class Initialized
DEBUG - 2023-04-28 10:51:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:51:04 --> Controller Class Initialized
INFO - 2023-04-28 10:51:04 --> Final output sent to browser
DEBUG - 2023-04-28 10:51:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-28 10:51:04 --> Total execution time: 0.0114
INFO - 2023-04-28 10:51:04 --> Database Driver Class Initialized
INFO - 2023-04-28 10:51:04 --> Config Class Initialized
INFO - 2023-04-28 10:51:04 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:51:04 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:51:04 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:51:04 --> Utf8 Class Initialized
INFO - 2023-04-28 10:51:04 --> URI Class Initialized
INFO - 2023-04-28 10:51:04 --> Router Class Initialized
INFO - 2023-04-28 10:51:04 --> Output Class Initialized
INFO - 2023-04-28 10:51:04 --> Security Class Initialized
DEBUG - 2023-04-28 10:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:51:04 --> Input Class Initialized
INFO - 2023-04-28 10:51:04 --> Language Class Initialized
INFO - 2023-04-28 10:51:04 --> Loader Class Initialized
INFO - 2023-04-28 10:51:04 --> Controller Class Initialized
DEBUG - 2023-04-28 10:51:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:51:04 --> Database Driver Class Initialized
INFO - 2023-04-28 10:51:04 --> Final output sent to browser
DEBUG - 2023-04-28 10:51:04 --> Total execution time: 0.0589
INFO - 2023-04-28 10:51:04 --> Config Class Initialized
INFO - 2023-04-28 10:51:04 --> Hooks Class Initialized
DEBUG - 2023-04-28 10:51:04 --> UTF-8 Support Enabled
INFO - 2023-04-28 10:51:04 --> Utf8 Class Initialized
INFO - 2023-04-28 10:51:04 --> URI Class Initialized
INFO - 2023-04-28 10:51:04 --> Router Class Initialized
INFO - 2023-04-28 10:51:04 --> Output Class Initialized
INFO - 2023-04-28 10:51:04 --> Security Class Initialized
DEBUG - 2023-04-28 10:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-28 10:51:04 --> Input Class Initialized
INFO - 2023-04-28 10:51:04 --> Language Class Initialized
INFO - 2023-04-28 10:51:04 --> Loader Class Initialized
INFO - 2023-04-28 10:51:04 --> Controller Class Initialized
DEBUG - 2023-04-28 10:51:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-28 10:51:04 --> Database Driver Class Initialized
INFO - 2023-04-28 10:51:04 --> Model "Login_model" initialized
INFO - 2023-04-28 10:51:04 --> Database Driver Class Initialized
INFO - 2023-04-28 10:51:04 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:51:04 --> Final output sent to browser
DEBUG - 2023-04-28 10:51:04 --> Total execution time: 0.0239
INFO - 2023-04-28 10:51:04 --> Model "Cluster_model" initialized
INFO - 2023-04-28 10:51:04 --> Final output sent to browser
DEBUG - 2023-04-28 10:51:04 --> Total execution time: 0.1171
