<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-02-20 05:38:43 --> Config Class Initialized
INFO - 2023-02-20 05:38:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:43 --> URI Class Initialized
INFO - 2023-02-20 05:38:43 --> Router Class Initialized
INFO - 2023-02-20 05:38:43 --> Output Class Initialized
INFO - 2023-02-20 05:38:43 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:43 --> Input Class Initialized
INFO - 2023-02-20 05:38:43 --> Language Class Initialized
INFO - 2023-02-20 05:38:43 --> Loader Class Initialized
INFO - 2023-02-20 05:38:43 --> Controller Class Initialized
INFO - 2023-02-20 05:38:43 --> Helper loaded: form_helper
INFO - 2023-02-20 05:38:43 --> Helper loaded: url_helper
DEBUG - 2023-02-20 05:38:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:43 --> Model "Change_model" initialized
INFO - 2023-02-20 05:38:43 --> Model "Grafana_model" initialized
INFO - 2023-02-20 05:38:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:44 --> Total execution time: 0.1201
INFO - 2023-02-20 05:38:44 --> Config Class Initialized
INFO - 2023-02-20 05:38:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:44 --> URI Class Initialized
INFO - 2023-02-20 05:38:44 --> Router Class Initialized
INFO - 2023-02-20 05:38:44 --> Output Class Initialized
INFO - 2023-02-20 05:38:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:44 --> Input Class Initialized
INFO - 2023-02-20 05:38:44 --> Language Class Initialized
INFO - 2023-02-20 05:38:44 --> Loader Class Initialized
INFO - 2023-02-20 05:38:44 --> Controller Class Initialized
INFO - 2023-02-20 05:38:44 --> Helper loaded: form_helper
INFO - 2023-02-20 05:38:44 --> Helper loaded: url_helper
DEBUG - 2023-02-20 05:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:44 --> Total execution time: 0.0510
INFO - 2023-02-20 05:38:44 --> Config Class Initialized
INFO - 2023-02-20 05:38:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:44 --> URI Class Initialized
INFO - 2023-02-20 05:38:44 --> Router Class Initialized
INFO - 2023-02-20 05:38:44 --> Output Class Initialized
INFO - 2023-02-20 05:38:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:44 --> Input Class Initialized
INFO - 2023-02-20 05:38:44 --> Language Class Initialized
INFO - 2023-02-20 05:38:44 --> Loader Class Initialized
INFO - 2023-02-20 05:38:44 --> Controller Class Initialized
INFO - 2023-02-20 05:38:44 --> Helper loaded: form_helper
INFO - 2023-02-20 05:38:44 --> Helper loaded: url_helper
DEBUG - 2023-02-20 05:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:44 --> Model "Login_model" initialized
INFO - 2023-02-20 05:38:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:44 --> Total execution time: 0.0319
INFO - 2023-02-20 05:38:44 --> Config Class Initialized
INFO - 2023-02-20 05:38:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:44 --> URI Class Initialized
INFO - 2023-02-20 05:38:44 --> Router Class Initialized
INFO - 2023-02-20 05:38:44 --> Output Class Initialized
INFO - 2023-02-20 05:38:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:44 --> Input Class Initialized
INFO - 2023-02-20 05:38:44 --> Language Class Initialized
INFO - 2023-02-20 05:38:44 --> Loader Class Initialized
INFO - 2023-02-20 05:38:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:44 --> Total execution time: 0.0430
INFO - 2023-02-20 05:38:44 --> Config Class Initialized
INFO - 2023-02-20 05:38:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:44 --> URI Class Initialized
INFO - 2023-02-20 05:38:44 --> Router Class Initialized
INFO - 2023-02-20 05:38:44 --> Output Class Initialized
INFO - 2023-02-20 05:38:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:44 --> Input Class Initialized
INFO - 2023-02-20 05:38:44 --> Language Class Initialized
INFO - 2023-02-20 05:38:44 --> Loader Class Initialized
INFO - 2023-02-20 05:38:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:44 --> Total execution time: 0.0130
INFO - 2023-02-20 05:38:44 --> Config Class Initialized
INFO - 2023-02-20 05:38:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:44 --> URI Class Initialized
INFO - 2023-02-20 05:38:44 --> Router Class Initialized
INFO - 2023-02-20 05:38:44 --> Output Class Initialized
INFO - 2023-02-20 05:38:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:44 --> Input Class Initialized
INFO - 2023-02-20 05:38:44 --> Language Class Initialized
INFO - 2023-02-20 05:38:44 --> Loader Class Initialized
INFO - 2023-02-20 05:38:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:44 --> Model "Login_model" initialized
INFO - 2023-02-20 05:38:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:44 --> Total execution time: 0.0435
INFO - 2023-02-20 05:38:44 --> Config Class Initialized
INFO - 2023-02-20 05:38:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:44 --> URI Class Initialized
INFO - 2023-02-20 05:38:44 --> Router Class Initialized
INFO - 2023-02-20 05:38:44 --> Output Class Initialized
INFO - 2023-02-20 05:38:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:44 --> Input Class Initialized
INFO - 2023-02-20 05:38:44 --> Language Class Initialized
INFO - 2023-02-20 05:38:44 --> Loader Class Initialized
INFO - 2023-02-20 05:38:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:44 --> Model "Login_model" initialized
INFO - 2023-02-20 05:38:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:44 --> Total execution time: 0.0780
INFO - 2023-02-20 05:38:47 --> Config Class Initialized
INFO - 2023-02-20 05:38:47 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:47 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:47 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:47 --> URI Class Initialized
INFO - 2023-02-20 05:38:47 --> Router Class Initialized
INFO - 2023-02-20 05:38:47 --> Output Class Initialized
INFO - 2023-02-20 05:38:47 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:47 --> Input Class Initialized
INFO - 2023-02-20 05:38:47 --> Language Class Initialized
INFO - 2023-02-20 05:38:47 --> Loader Class Initialized
INFO - 2023-02-20 05:38:47 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:47 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:47 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:47 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:47 --> Total execution time: 0.0167
INFO - 2023-02-20 05:38:47 --> Config Class Initialized
INFO - 2023-02-20 05:38:47 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:47 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:47 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:47 --> URI Class Initialized
INFO - 2023-02-20 05:38:47 --> Router Class Initialized
INFO - 2023-02-20 05:38:47 --> Output Class Initialized
INFO - 2023-02-20 05:38:47 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:47 --> Input Class Initialized
INFO - 2023-02-20 05:38:47 --> Language Class Initialized
INFO - 2023-02-20 05:38:47 --> Loader Class Initialized
INFO - 2023-02-20 05:38:47 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:47 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:47 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:47 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:47 --> Total execution time: 0.0555
INFO - 2023-02-20 05:38:49 --> Config Class Initialized
INFO - 2023-02-20 05:38:49 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:49 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:49 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:49 --> URI Class Initialized
INFO - 2023-02-20 05:38:49 --> Router Class Initialized
INFO - 2023-02-20 05:38:49 --> Output Class Initialized
INFO - 2023-02-20 05:38:49 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:49 --> Input Class Initialized
INFO - 2023-02-20 05:38:49 --> Language Class Initialized
INFO - 2023-02-20 05:38:49 --> Loader Class Initialized
INFO - 2023-02-20 05:38:49 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:49 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:49 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:49 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:49 --> Total execution time: 0.0494
INFO - 2023-02-20 05:38:49 --> Config Class Initialized
INFO - 2023-02-20 05:38:49 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:49 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:49 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:49 --> URI Class Initialized
INFO - 2023-02-20 05:38:49 --> Router Class Initialized
INFO - 2023-02-20 05:38:49 --> Output Class Initialized
INFO - 2023-02-20 05:38:49 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:49 --> Input Class Initialized
INFO - 2023-02-20 05:38:49 --> Language Class Initialized
INFO - 2023-02-20 05:38:49 --> Loader Class Initialized
INFO - 2023-02-20 05:38:49 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:49 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:49 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:49 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:49 --> Total execution time: 0.0473
INFO - 2023-02-20 05:38:51 --> Config Class Initialized
INFO - 2023-02-20 05:38:51 --> Config Class Initialized
INFO - 2023-02-20 05:38:51 --> Hooks Class Initialized
INFO - 2023-02-20 05:38:51 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:51 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:51 --> Utf8 Class Initialized
DEBUG - 2023-02-20 05:38:51 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:51 --> URI Class Initialized
INFO - 2023-02-20 05:38:51 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:51 --> URI Class Initialized
INFO - 2023-02-20 05:38:51 --> Router Class Initialized
INFO - 2023-02-20 05:38:51 --> Router Class Initialized
INFO - 2023-02-20 05:38:51 --> Output Class Initialized
INFO - 2023-02-20 05:38:51 --> Output Class Initialized
INFO - 2023-02-20 05:38:51 --> Security Class Initialized
INFO - 2023-02-20 05:38:51 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 05:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:51 --> Input Class Initialized
INFO - 2023-02-20 05:38:51 --> Input Class Initialized
INFO - 2023-02-20 05:38:51 --> Language Class Initialized
INFO - 2023-02-20 05:38:51 --> Language Class Initialized
INFO - 2023-02-20 05:38:51 --> Loader Class Initialized
INFO - 2023-02-20 05:38:51 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:51 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:51 --> Loader Class Initialized
INFO - 2023-02-20 05:38:51 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:51 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:51 --> Total execution time: 0.0073
INFO - 2023-02-20 05:38:51 --> Config Class Initialized
INFO - 2023-02-20 05:38:51 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:51 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:51 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:51 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:51 --> URI Class Initialized
INFO - 2023-02-20 05:38:51 --> Router Class Initialized
INFO - 2023-02-20 05:38:51 --> Output Class Initialized
INFO - 2023-02-20 05:38:51 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:51 --> Input Class Initialized
INFO - 2023-02-20 05:38:51 --> Language Class Initialized
INFO - 2023-02-20 05:38:51 --> Loader Class Initialized
INFO - 2023-02-20 05:38:51 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:51 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:51 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:51 --> Total execution time: 0.0530
INFO - 2023-02-20 05:38:51 --> Config Class Initialized
INFO - 2023-02-20 05:38:51 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:51 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:51 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:51 --> URI Class Initialized
INFO - 2023-02-20 05:38:51 --> Router Class Initialized
INFO - 2023-02-20 05:38:51 --> Output Class Initialized
INFO - 2023-02-20 05:38:51 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:51 --> Input Class Initialized
INFO - 2023-02-20 05:38:51 --> Language Class Initialized
INFO - 2023-02-20 05:38:51 --> Loader Class Initialized
INFO - 2023-02-20 05:38:51 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:51 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:51 --> Model "Login_model" initialized
INFO - 2023-02-20 05:38:51 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:51 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:51 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:51 --> Total execution time: 0.0172
INFO - 2023-02-20 05:38:51 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:51 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:51 --> Total execution time: 0.0696
INFO - 2023-02-20 05:38:53 --> Config Class Initialized
INFO - 2023-02-20 05:38:53 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:53 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:53 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:53 --> URI Class Initialized
INFO - 2023-02-20 05:38:53 --> Router Class Initialized
INFO - 2023-02-20 05:38:53 --> Output Class Initialized
INFO - 2023-02-20 05:38:53 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:53 --> Input Class Initialized
INFO - 2023-02-20 05:38:53 --> Language Class Initialized
INFO - 2023-02-20 05:38:53 --> Loader Class Initialized
INFO - 2023-02-20 05:38:53 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:53 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:53 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:53 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:53 --> Total execution time: 0.0814
INFO - 2023-02-20 05:38:57 --> Config Class Initialized
INFO - 2023-02-20 05:38:57 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:57 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:57 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:57 --> URI Class Initialized
INFO - 2023-02-20 05:38:57 --> Router Class Initialized
INFO - 2023-02-20 05:38:57 --> Output Class Initialized
INFO - 2023-02-20 05:38:57 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:57 --> Input Class Initialized
INFO - 2023-02-20 05:38:57 --> Language Class Initialized
INFO - 2023-02-20 05:38:57 --> Loader Class Initialized
INFO - 2023-02-20 05:38:57 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:57 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:57 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:57 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:57 --> Total execution time: 0.0467
INFO - 2023-02-20 05:38:57 --> Config Class Initialized
INFO - 2023-02-20 05:38:57 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:57 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:57 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:57 --> URI Class Initialized
INFO - 2023-02-20 05:38:57 --> Router Class Initialized
INFO - 2023-02-20 05:38:57 --> Output Class Initialized
INFO - 2023-02-20 05:38:57 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:57 --> Input Class Initialized
INFO - 2023-02-20 05:38:57 --> Language Class Initialized
INFO - 2023-02-20 05:38:57 --> Loader Class Initialized
INFO - 2023-02-20 05:38:57 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:57 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:57 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:57 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:57 --> Total execution time: 0.0454
INFO - 2023-02-20 05:38:59 --> Config Class Initialized
INFO - 2023-02-20 05:38:59 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:59 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:59 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:59 --> URI Class Initialized
INFO - 2023-02-20 05:38:59 --> Router Class Initialized
INFO - 2023-02-20 05:38:59 --> Output Class Initialized
INFO - 2023-02-20 05:38:59 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:59 --> Input Class Initialized
INFO - 2023-02-20 05:38:59 --> Language Class Initialized
INFO - 2023-02-20 05:38:59 --> Loader Class Initialized
INFO - 2023-02-20 05:38:59 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:59 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:59 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:59 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:59 --> Total execution time: 0.0488
INFO - 2023-02-20 05:38:59 --> Config Class Initialized
INFO - 2023-02-20 05:38:59 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:38:59 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:38:59 --> Utf8 Class Initialized
INFO - 2023-02-20 05:38:59 --> URI Class Initialized
INFO - 2023-02-20 05:38:59 --> Router Class Initialized
INFO - 2023-02-20 05:38:59 --> Output Class Initialized
INFO - 2023-02-20 05:38:59 --> Security Class Initialized
DEBUG - 2023-02-20 05:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:38:59 --> Input Class Initialized
INFO - 2023-02-20 05:38:59 --> Language Class Initialized
INFO - 2023-02-20 05:38:59 --> Loader Class Initialized
INFO - 2023-02-20 05:38:59 --> Controller Class Initialized
DEBUG - 2023-02-20 05:38:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:38:59 --> Database Driver Class Initialized
INFO - 2023-02-20 05:38:59 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:38:59 --> Final output sent to browser
DEBUG - 2023-02-20 05:38:59 --> Total execution time: 0.0509
INFO - 2023-02-20 05:39:02 --> Config Class Initialized
INFO - 2023-02-20 05:39:02 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:02 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:02 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:02 --> URI Class Initialized
INFO - 2023-02-20 05:39:02 --> Router Class Initialized
INFO - 2023-02-20 05:39:02 --> Output Class Initialized
INFO - 2023-02-20 05:39:02 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:02 --> Input Class Initialized
INFO - 2023-02-20 05:39:02 --> Language Class Initialized
INFO - 2023-02-20 05:39:02 --> Loader Class Initialized
INFO - 2023-02-20 05:39:02 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:02 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:02 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:02 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:02 --> Total execution time: 0.0215
INFO - 2023-02-20 05:39:02 --> Config Class Initialized
INFO - 2023-02-20 05:39:02 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:02 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:02 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:02 --> URI Class Initialized
INFO - 2023-02-20 05:39:02 --> Router Class Initialized
INFO - 2023-02-20 05:39:02 --> Output Class Initialized
INFO - 2023-02-20 05:39:02 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:02 --> Input Class Initialized
INFO - 2023-02-20 05:39:02 --> Language Class Initialized
INFO - 2023-02-20 05:39:02 --> Loader Class Initialized
INFO - 2023-02-20 05:39:02 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:02 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:02 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:02 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:02 --> Total execution time: 0.0241
INFO - 2023-02-20 05:39:18 --> Config Class Initialized
INFO - 2023-02-20 05:39:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:18 --> URI Class Initialized
INFO - 2023-02-20 05:39:18 --> Router Class Initialized
INFO - 2023-02-20 05:39:18 --> Output Class Initialized
INFO - 2023-02-20 05:39:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:18 --> Input Class Initialized
INFO - 2023-02-20 05:39:18 --> Language Class Initialized
INFO - 2023-02-20 05:39:18 --> Loader Class Initialized
INFO - 2023-02-20 05:39:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:18 --> Total execution time: 0.0173
INFO - 2023-02-20 05:39:18 --> Config Class Initialized
INFO - 2023-02-20 05:39:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:18 --> URI Class Initialized
INFO - 2023-02-20 05:39:18 --> Router Class Initialized
INFO - 2023-02-20 05:39:18 --> Output Class Initialized
INFO - 2023-02-20 05:39:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:18 --> Input Class Initialized
INFO - 2023-02-20 05:39:18 --> Language Class Initialized
INFO - 2023-02-20 05:39:18 --> Loader Class Initialized
INFO - 2023-02-20 05:39:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:18 --> Total execution time: 0.0551
INFO - 2023-02-20 05:39:21 --> Config Class Initialized
INFO - 2023-02-20 05:39:22 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:22 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:22 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:22 --> URI Class Initialized
INFO - 2023-02-20 05:39:22 --> Router Class Initialized
INFO - 2023-02-20 05:39:22 --> Output Class Initialized
INFO - 2023-02-20 05:39:22 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:22 --> Input Class Initialized
INFO - 2023-02-20 05:39:22 --> Language Class Initialized
INFO - 2023-02-20 05:39:22 --> Loader Class Initialized
INFO - 2023-02-20 05:39:22 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:22 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:22 --> Total execution time: 0.0431
INFO - 2023-02-20 05:39:22 --> Config Class Initialized
INFO - 2023-02-20 05:39:22 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:22 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:22 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:22 --> URI Class Initialized
INFO - 2023-02-20 05:39:22 --> Router Class Initialized
INFO - 2023-02-20 05:39:22 --> Output Class Initialized
INFO - 2023-02-20 05:39:22 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:22 --> Input Class Initialized
INFO - 2023-02-20 05:39:22 --> Language Class Initialized
INFO - 2023-02-20 05:39:22 --> Loader Class Initialized
INFO - 2023-02-20 05:39:22 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:22 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:22 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:22 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:22 --> Total execution time: 0.0535
INFO - 2023-02-20 05:39:23 --> Config Class Initialized
INFO - 2023-02-20 05:39:23 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:23 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:23 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:23 --> URI Class Initialized
INFO - 2023-02-20 05:39:23 --> Router Class Initialized
INFO - 2023-02-20 05:39:23 --> Output Class Initialized
INFO - 2023-02-20 05:39:23 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:23 --> Input Class Initialized
INFO - 2023-02-20 05:39:23 --> Language Class Initialized
INFO - 2023-02-20 05:39:23 --> Loader Class Initialized
INFO - 2023-02-20 05:39:23 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:23 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:23 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:23 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:23 --> Total execution time: 0.0648
INFO - 2023-02-20 05:39:23 --> Config Class Initialized
INFO - 2023-02-20 05:39:23 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:23 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:23 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:23 --> URI Class Initialized
INFO - 2023-02-20 05:39:23 --> Router Class Initialized
INFO - 2023-02-20 05:39:23 --> Output Class Initialized
INFO - 2023-02-20 05:39:23 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:23 --> Input Class Initialized
INFO - 2023-02-20 05:39:23 --> Language Class Initialized
INFO - 2023-02-20 05:39:23 --> Loader Class Initialized
INFO - 2023-02-20 05:39:23 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:23 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:23 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:23 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:23 --> Total execution time: 0.0591
INFO - 2023-02-20 05:39:25 --> Config Class Initialized
INFO - 2023-02-20 05:39:25 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:25 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:25 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:25 --> URI Class Initialized
INFO - 2023-02-20 05:39:25 --> Router Class Initialized
INFO - 2023-02-20 05:39:25 --> Output Class Initialized
INFO - 2023-02-20 05:39:25 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:25 --> Input Class Initialized
INFO - 2023-02-20 05:39:25 --> Language Class Initialized
INFO - 2023-02-20 05:39:25 --> Loader Class Initialized
INFO - 2023-02-20 05:39:25 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:25 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:25 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:25 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:25 --> Total execution time: 0.0220
INFO - 2023-02-20 05:39:25 --> Config Class Initialized
INFO - 2023-02-20 05:39:25 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:25 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:25 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:25 --> URI Class Initialized
INFO - 2023-02-20 05:39:25 --> Router Class Initialized
INFO - 2023-02-20 05:39:25 --> Output Class Initialized
INFO - 2023-02-20 05:39:25 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:25 --> Input Class Initialized
INFO - 2023-02-20 05:39:25 --> Language Class Initialized
INFO - 2023-02-20 05:39:25 --> Loader Class Initialized
INFO - 2023-02-20 05:39:25 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:25 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:25 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:25 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:25 --> Total execution time: 0.0140
INFO - 2023-02-20 05:39:28 --> Config Class Initialized
INFO - 2023-02-20 05:39:28 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:28 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:28 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:28 --> URI Class Initialized
INFO - 2023-02-20 05:39:28 --> Router Class Initialized
INFO - 2023-02-20 05:39:28 --> Output Class Initialized
INFO - 2023-02-20 05:39:28 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:28 --> Input Class Initialized
INFO - 2023-02-20 05:39:28 --> Language Class Initialized
INFO - 2023-02-20 05:39:28 --> Loader Class Initialized
INFO - 2023-02-20 05:39:28 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:28 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:28 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:28 --> Model "Login_model" initialized
INFO - 2023-02-20 05:39:28 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:28 --> Total execution time: 0.0254
INFO - 2023-02-20 05:39:28 --> Config Class Initialized
INFO - 2023-02-20 05:39:28 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:28 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:28 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:28 --> URI Class Initialized
INFO - 2023-02-20 05:39:28 --> Router Class Initialized
INFO - 2023-02-20 05:39:28 --> Output Class Initialized
INFO - 2023-02-20 05:39:28 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:28 --> Input Class Initialized
INFO - 2023-02-20 05:39:28 --> Language Class Initialized
INFO - 2023-02-20 05:39:28 --> Loader Class Initialized
INFO - 2023-02-20 05:39:28 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:28 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:28 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:28 --> Model "Login_model" initialized
INFO - 2023-02-20 05:39:28 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:28 --> Total execution time: 0.0643
INFO - 2023-02-20 05:39:32 --> Config Class Initialized
INFO - 2023-02-20 05:39:32 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:32 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:32 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:32 --> URI Class Initialized
INFO - 2023-02-20 05:39:32 --> Router Class Initialized
INFO - 2023-02-20 05:39:32 --> Output Class Initialized
INFO - 2023-02-20 05:39:32 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:32 --> Input Class Initialized
INFO - 2023-02-20 05:39:32 --> Language Class Initialized
INFO - 2023-02-20 05:39:32 --> Loader Class Initialized
INFO - 2023-02-20 05:39:32 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:32 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:32 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:32 --> Model "Login_model" initialized
INFO - 2023-02-20 05:39:32 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:32 --> Total execution time: 0.0313
INFO - 2023-02-20 05:39:32 --> Config Class Initialized
INFO - 2023-02-20 05:39:32 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:32 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:32 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:32 --> URI Class Initialized
INFO - 2023-02-20 05:39:32 --> Router Class Initialized
INFO - 2023-02-20 05:39:32 --> Output Class Initialized
INFO - 2023-02-20 05:39:32 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:32 --> Input Class Initialized
INFO - 2023-02-20 05:39:32 --> Language Class Initialized
INFO - 2023-02-20 05:39:32 --> Loader Class Initialized
INFO - 2023-02-20 05:39:32 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:32 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:32 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:32 --> Model "Login_model" initialized
INFO - 2023-02-20 05:39:32 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:32 --> Total execution time: 0.0667
INFO - 2023-02-20 05:39:34 --> Config Class Initialized
INFO - 2023-02-20 05:39:34 --> Config Class Initialized
INFO - 2023-02-20 05:39:34 --> Hooks Class Initialized
INFO - 2023-02-20 05:39:34 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:34 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 05:39:34 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:34 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:34 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:34 --> URI Class Initialized
INFO - 2023-02-20 05:39:34 --> URI Class Initialized
INFO - 2023-02-20 05:39:34 --> Router Class Initialized
INFO - 2023-02-20 05:39:34 --> Router Class Initialized
INFO - 2023-02-20 05:39:34 --> Output Class Initialized
INFO - 2023-02-20 05:39:34 --> Output Class Initialized
INFO - 2023-02-20 05:39:34 --> Security Class Initialized
INFO - 2023-02-20 05:39:34 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 05:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:34 --> Input Class Initialized
INFO - 2023-02-20 05:39:34 --> Input Class Initialized
INFO - 2023-02-20 05:39:34 --> Language Class Initialized
INFO - 2023-02-20 05:39:34 --> Language Class Initialized
INFO - 2023-02-20 05:39:34 --> Loader Class Initialized
INFO - 2023-02-20 05:39:34 --> Loader Class Initialized
INFO - 2023-02-20 05:39:34 --> Controller Class Initialized
INFO - 2023-02-20 05:39:34 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 05:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:34 --> Model "Login_model" initialized
INFO - 2023-02-20 05:39:34 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:34 --> Total execution time: 0.0162
INFO - 2023-02-20 05:39:34 --> Config Class Initialized
INFO - 2023-02-20 05:39:34 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:34 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:34 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:34 --> URI Class Initialized
INFO - 2023-02-20 05:39:34 --> Router Class Initialized
INFO - 2023-02-20 05:39:34 --> Output Class Initialized
INFO - 2023-02-20 05:39:34 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:34 --> Input Class Initialized
INFO - 2023-02-20 05:39:34 --> Language Class Initialized
INFO - 2023-02-20 05:39:34 --> Loader Class Initialized
INFO - 2023-02-20 05:39:34 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:34 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:34 --> Total execution time: 0.0239
INFO - 2023-02-20 05:39:34 --> Config Class Initialized
INFO - 2023-02-20 05:39:34 --> Hooks Class Initialized
INFO - 2023-02-20 05:39:34 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:34 --> Total execution time: 0.0142
DEBUG - 2023-02-20 05:39:34 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:34 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:34 --> URI Class Initialized
INFO - 2023-02-20 05:39:34 --> Router Class Initialized
INFO - 2023-02-20 05:39:34 --> Output Class Initialized
INFO - 2023-02-20 05:39:34 --> Config Class Initialized
INFO - 2023-02-20 05:39:34 --> Security Class Initialized
INFO - 2023-02-20 05:39:34 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:34 --> Input Class Initialized
DEBUG - 2023-02-20 05:39:34 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:34 --> Language Class Initialized
INFO - 2023-02-20 05:39:34 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:34 --> URI Class Initialized
INFO - 2023-02-20 05:39:34 --> Loader Class Initialized
INFO - 2023-02-20 05:39:34 --> Controller Class Initialized
INFO - 2023-02-20 05:39:34 --> Router Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:34 --> Output Class Initialized
INFO - 2023-02-20 05:39:34 --> Final output sent to browser
INFO - 2023-02-20 05:39:34 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Total execution time: 0.0819
DEBUG - 2023-02-20 05:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:34 --> Input Class Initialized
INFO - 2023-02-20 05:39:34 --> Language Class Initialized
INFO - 2023-02-20 05:39:34 --> Loader Class Initialized
INFO - 2023-02-20 05:39:34 --> Config Class Initialized
INFO - 2023-02-20 05:39:34 --> Controller Class Initialized
INFO - 2023-02-20 05:39:34 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 05:39:34 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:34 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:34 --> URI Class Initialized
INFO - 2023-02-20 05:39:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:34 --> Router Class Initialized
INFO - 2023-02-20 05:39:34 --> Output Class Initialized
INFO - 2023-02-20 05:39:34 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:34 --> Input Class Initialized
INFO - 2023-02-20 05:39:34 --> Language Class Initialized
INFO - 2023-02-20 05:39:34 --> Loader Class Initialized
INFO - 2023-02-20 05:39:34 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:34 --> Model "Login_model" initialized
INFO - 2023-02-20 05:39:34 --> Model "Login_model" initialized
INFO - 2023-02-20 05:39:34 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:34 --> Total execution time: 0.0934
INFO - 2023-02-20 05:39:34 --> Config Class Initialized
INFO - 2023-02-20 05:39:34 --> Final output sent to browser
INFO - 2023-02-20 05:39:34 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Total execution time: 0.0553
DEBUG - 2023-02-20 05:39:34 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:34 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:34 --> URI Class Initialized
INFO - 2023-02-20 05:39:34 --> Router Class Initialized
INFO - 2023-02-20 05:39:34 --> Config Class Initialized
INFO - 2023-02-20 05:39:34 --> Hooks Class Initialized
INFO - 2023-02-20 05:39:34 --> Output Class Initialized
DEBUG - 2023-02-20 05:39:34 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:34 --> Security Class Initialized
INFO - 2023-02-20 05:39:34 --> Utf8 Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:34 --> URI Class Initialized
INFO - 2023-02-20 05:39:34 --> Input Class Initialized
INFO - 2023-02-20 05:39:34 --> Router Class Initialized
INFO - 2023-02-20 05:39:34 --> Language Class Initialized
INFO - 2023-02-20 05:39:34 --> Output Class Initialized
INFO - 2023-02-20 05:39:34 --> Loader Class Initialized
INFO - 2023-02-20 05:39:34 --> Security Class Initialized
INFO - 2023-02-20 05:39:34 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 05:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:34 --> Input Class Initialized
INFO - 2023-02-20 05:39:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:34 --> Language Class Initialized
INFO - 2023-02-20 05:39:34 --> Loader Class Initialized
INFO - 2023-02-20 05:39:34 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:34 --> Model "Login_model" initialized
INFO - 2023-02-20 05:39:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:34 --> Model "Login_model" initialized
INFO - 2023-02-20 05:39:34 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:34 --> Total execution time: 0.1170
INFO - 2023-02-20 05:39:34 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:34 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:34 --> Total execution time: 0.1185
INFO - 2023-02-20 05:39:38 --> Config Class Initialized
INFO - 2023-02-20 05:39:38 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:38 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:38 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:38 --> URI Class Initialized
INFO - 2023-02-20 05:39:38 --> Router Class Initialized
INFO - 2023-02-20 05:39:38 --> Output Class Initialized
INFO - 2023-02-20 05:39:38 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:38 --> Input Class Initialized
INFO - 2023-02-20 05:39:38 --> Language Class Initialized
INFO - 2023-02-20 05:39:38 --> Loader Class Initialized
INFO - 2023-02-20 05:39:38 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:38 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:38 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:39 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:39 --> Total execution time: 0.8090
INFO - 2023-02-20 05:39:39 --> Config Class Initialized
INFO - 2023-02-20 05:39:39 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:39 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:39 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:39 --> URI Class Initialized
INFO - 2023-02-20 05:39:39 --> Router Class Initialized
INFO - 2023-02-20 05:39:39 --> Output Class Initialized
INFO - 2023-02-20 05:39:39 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:39 --> Input Class Initialized
INFO - 2023-02-20 05:39:39 --> Language Class Initialized
INFO - 2023-02-20 05:39:39 --> Loader Class Initialized
INFO - 2023-02-20 05:39:39 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:39 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:39 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:39 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:39 --> Total execution time: 0.0320
INFO - 2023-02-20 05:39:43 --> Config Class Initialized
INFO - 2023-02-20 05:39:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:43 --> URI Class Initialized
INFO - 2023-02-20 05:39:43 --> Router Class Initialized
INFO - 2023-02-20 05:39:43 --> Output Class Initialized
INFO - 2023-02-20 05:39:43 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:43 --> Input Class Initialized
INFO - 2023-02-20 05:39:43 --> Language Class Initialized
INFO - 2023-02-20 05:39:43 --> Loader Class Initialized
INFO - 2023-02-20 05:39:43 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:43 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:43 --> Total execution time: 0.0188
INFO - 2023-02-20 05:39:43 --> Config Class Initialized
INFO - 2023-02-20 05:39:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:43 --> URI Class Initialized
INFO - 2023-02-20 05:39:43 --> Router Class Initialized
INFO - 2023-02-20 05:39:43 --> Output Class Initialized
INFO - 2023-02-20 05:39:43 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:43 --> Input Class Initialized
INFO - 2023-02-20 05:39:43 --> Language Class Initialized
INFO - 2023-02-20 05:39:43 --> Loader Class Initialized
INFO - 2023-02-20 05:39:43 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:43 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:43 --> Total execution time: 0.0537
INFO - 2023-02-20 05:39:57 --> Config Class Initialized
INFO - 2023-02-20 05:39:57 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:57 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:57 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:57 --> URI Class Initialized
INFO - 2023-02-20 05:39:57 --> Router Class Initialized
INFO - 2023-02-20 05:39:57 --> Output Class Initialized
INFO - 2023-02-20 05:39:57 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:57 --> Input Class Initialized
INFO - 2023-02-20 05:39:57 --> Language Class Initialized
INFO - 2023-02-20 05:39:57 --> Loader Class Initialized
INFO - 2023-02-20 05:39:57 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:57 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:57 --> Total execution time: 0.0039
INFO - 2023-02-20 05:39:57 --> Config Class Initialized
INFO - 2023-02-20 05:39:57 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:57 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:57 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:57 --> URI Class Initialized
INFO - 2023-02-20 05:39:57 --> Router Class Initialized
INFO - 2023-02-20 05:39:57 --> Output Class Initialized
INFO - 2023-02-20 05:39:57 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:57 --> Input Class Initialized
INFO - 2023-02-20 05:39:57 --> Language Class Initialized
INFO - 2023-02-20 05:39:57 --> Loader Class Initialized
INFO - 2023-02-20 05:39:57 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:57 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:57 --> Model "Login_model" initialized
INFO - 2023-02-20 05:39:57 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:57 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:57 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:57 --> Total execution time: 0.0254
INFO - 2023-02-20 05:39:57 --> Config Class Initialized
INFO - 2023-02-20 05:39:57 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:57 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:57 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:57 --> URI Class Initialized
INFO - 2023-02-20 05:39:57 --> Router Class Initialized
INFO - 2023-02-20 05:39:57 --> Output Class Initialized
INFO - 2023-02-20 05:39:57 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:57 --> Input Class Initialized
INFO - 2023-02-20 05:39:57 --> Language Class Initialized
INFO - 2023-02-20 05:39:57 --> Loader Class Initialized
INFO - 2023-02-20 05:39:57 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:57 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:57 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:57 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:57 --> Total execution time: 0.0531
INFO - 2023-02-20 05:39:57 --> Config Class Initialized
INFO - 2023-02-20 05:39:57 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:39:57 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:39:57 --> Utf8 Class Initialized
INFO - 2023-02-20 05:39:57 --> URI Class Initialized
INFO - 2023-02-20 05:39:57 --> Router Class Initialized
INFO - 2023-02-20 05:39:57 --> Output Class Initialized
INFO - 2023-02-20 05:39:57 --> Security Class Initialized
DEBUG - 2023-02-20 05:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:39:57 --> Input Class Initialized
INFO - 2023-02-20 05:39:57 --> Language Class Initialized
INFO - 2023-02-20 05:39:57 --> Loader Class Initialized
INFO - 2023-02-20 05:39:57 --> Controller Class Initialized
DEBUG - 2023-02-20 05:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:39:57 --> Database Driver Class Initialized
INFO - 2023-02-20 05:39:57 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:39:57 --> Final output sent to browser
DEBUG - 2023-02-20 05:39:57 --> Total execution time: 0.0146
INFO - 2023-02-20 05:40:43 --> Config Class Initialized
INFO - 2023-02-20 05:40:43 --> Config Class Initialized
INFO - 2023-02-20 05:40:43 --> Hooks Class Initialized
INFO - 2023-02-20 05:40:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 05:40:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:40:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:40:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:40:43 --> URI Class Initialized
INFO - 2023-02-20 05:40:43 --> URI Class Initialized
INFO - 2023-02-20 05:40:43 --> Router Class Initialized
INFO - 2023-02-20 05:40:43 --> Router Class Initialized
INFO - 2023-02-20 05:40:43 --> Output Class Initialized
INFO - 2023-02-20 05:40:43 --> Output Class Initialized
INFO - 2023-02-20 05:40:43 --> Security Class Initialized
INFO - 2023-02-20 05:40:43 --> Security Class Initialized
DEBUG - 2023-02-20 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 05:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:40:43 --> Input Class Initialized
INFO - 2023-02-20 05:40:43 --> Input Class Initialized
INFO - 2023-02-20 05:40:43 --> Language Class Initialized
INFO - 2023-02-20 05:40:43 --> Language Class Initialized
INFO - 2023-02-20 05:40:43 --> Loader Class Initialized
INFO - 2023-02-20 05:40:43 --> Loader Class Initialized
INFO - 2023-02-20 05:40:43 --> Controller Class Initialized
INFO - 2023-02-20 05:40:43 --> Controller Class Initialized
DEBUG - 2023-02-20 05:40:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 05:40:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:40:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:40:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:40:43 --> Model "Login_model" initialized
INFO - 2023-02-20 05:40:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:40:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:40:43 --> Final output sent to browser
DEBUG - 2023-02-20 05:40:43 --> Total execution time: 0.0189
INFO - 2023-02-20 05:40:43 --> Config Class Initialized
INFO - 2023-02-20 05:40:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:40:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:40:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:40:43 --> URI Class Initialized
INFO - 2023-02-20 05:40:43 --> Router Class Initialized
INFO - 2023-02-20 05:40:43 --> Output Class Initialized
INFO - 2023-02-20 05:40:43 --> Security Class Initialized
DEBUG - 2023-02-20 05:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:40:43 --> Input Class Initialized
INFO - 2023-02-20 05:40:43 --> Language Class Initialized
INFO - 2023-02-20 05:40:43 --> Loader Class Initialized
INFO - 2023-02-20 05:40:43 --> Controller Class Initialized
INFO - 2023-02-20 05:40:43 --> Model "Cluster_model" initialized
DEBUG - 2023-02-20 05:40:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:40:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:40:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:40:43 --> Final output sent to browser
DEBUG - 2023-02-20 05:40:43 --> Total execution time: 0.0138
INFO - 2023-02-20 05:40:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:40:44 --> Total execution time: 0.6536
INFO - 2023-02-20 05:40:44 --> Config Class Initialized
INFO - 2023-02-20 05:40:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:40:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:40:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:40:44 --> URI Class Initialized
INFO - 2023-02-20 05:40:44 --> Router Class Initialized
INFO - 2023-02-20 05:40:44 --> Output Class Initialized
INFO - 2023-02-20 05:40:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:40:44 --> Input Class Initialized
INFO - 2023-02-20 05:40:44 --> Language Class Initialized
INFO - 2023-02-20 05:40:44 --> Loader Class Initialized
INFO - 2023-02-20 05:40:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:40:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:40:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:40:44 --> Model "Login_model" initialized
INFO - 2023-02-20 05:40:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:40:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:40:45 --> Final output sent to browser
DEBUG - 2023-02-20 05:40:45 --> Total execution time: 0.7074
INFO - 2023-02-20 05:41:43 --> Config Class Initialized
INFO - 2023-02-20 05:41:43 --> Config Class Initialized
INFO - 2023-02-20 05:41:43 --> Hooks Class Initialized
INFO - 2023-02-20 05:41:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:41:43 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 05:41:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:41:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:41:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:41:43 --> URI Class Initialized
INFO - 2023-02-20 05:41:43 --> URI Class Initialized
INFO - 2023-02-20 05:41:43 --> Router Class Initialized
INFO - 2023-02-20 05:41:43 --> Router Class Initialized
INFO - 2023-02-20 05:41:43 --> Output Class Initialized
INFO - 2023-02-20 05:41:43 --> Output Class Initialized
INFO - 2023-02-20 05:41:43 --> Security Class Initialized
INFO - 2023-02-20 05:41:43 --> Security Class Initialized
DEBUG - 2023-02-20 05:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 05:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:41:43 --> Input Class Initialized
INFO - 2023-02-20 05:41:43 --> Input Class Initialized
INFO - 2023-02-20 05:41:43 --> Language Class Initialized
INFO - 2023-02-20 05:41:43 --> Language Class Initialized
INFO - 2023-02-20 05:41:43 --> Loader Class Initialized
INFO - 2023-02-20 05:41:43 --> Loader Class Initialized
INFO - 2023-02-20 05:41:43 --> Controller Class Initialized
INFO - 2023-02-20 05:41:43 --> Controller Class Initialized
DEBUG - 2023-02-20 05:41:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 05:41:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:41:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:41:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:41:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:41:43 --> Model "Login_model" initialized
INFO - 2023-02-20 05:41:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:41:43 --> Final output sent to browser
DEBUG - 2023-02-20 05:41:43 --> Total execution time: 0.0190
INFO - 2023-02-20 05:41:43 --> Config Class Initialized
INFO - 2023-02-20 05:41:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:41:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:41:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:41:43 --> URI Class Initialized
INFO - 2023-02-20 05:41:43 --> Router Class Initialized
INFO - 2023-02-20 05:41:43 --> Output Class Initialized
INFO - 2023-02-20 05:41:43 --> Security Class Initialized
INFO - 2023-02-20 05:41:43 --> Model "Cluster_model" initialized
DEBUG - 2023-02-20 05:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:41:43 --> Input Class Initialized
INFO - 2023-02-20 05:41:43 --> Language Class Initialized
INFO - 2023-02-20 05:41:43 --> Loader Class Initialized
INFO - 2023-02-20 05:41:43 --> Controller Class Initialized
DEBUG - 2023-02-20 05:41:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:41:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:41:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:41:43 --> Final output sent to browser
DEBUG - 2023-02-20 05:41:43 --> Total execution time: 0.0199
INFO - 2023-02-20 05:41:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:41:44 --> Total execution time: 0.6603
INFO - 2023-02-20 05:41:44 --> Config Class Initialized
INFO - 2023-02-20 05:41:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:41:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:41:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:41:44 --> URI Class Initialized
INFO - 2023-02-20 05:41:44 --> Router Class Initialized
INFO - 2023-02-20 05:41:44 --> Output Class Initialized
INFO - 2023-02-20 05:41:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:41:44 --> Input Class Initialized
INFO - 2023-02-20 05:41:44 --> Language Class Initialized
INFO - 2023-02-20 05:41:44 --> Loader Class Initialized
INFO - 2023-02-20 05:41:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:41:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:41:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:41:44 --> Model "Login_model" initialized
INFO - 2023-02-20 05:41:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:41:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:41:45 --> Final output sent to browser
DEBUG - 2023-02-20 05:41:45 --> Total execution time: 0.7314
INFO - 2023-02-20 05:42:43 --> Config Class Initialized
INFO - 2023-02-20 05:42:43 --> Config Class Initialized
INFO - 2023-02-20 05:42:43 --> Hooks Class Initialized
INFO - 2023-02-20 05:42:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:42:43 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 05:42:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:42:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:42:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:42:43 --> URI Class Initialized
INFO - 2023-02-20 05:42:43 --> URI Class Initialized
INFO - 2023-02-20 05:42:43 --> Router Class Initialized
INFO - 2023-02-20 05:42:43 --> Router Class Initialized
INFO - 2023-02-20 05:42:43 --> Output Class Initialized
INFO - 2023-02-20 05:42:43 --> Output Class Initialized
INFO - 2023-02-20 05:42:43 --> Security Class Initialized
INFO - 2023-02-20 05:42:43 --> Security Class Initialized
DEBUG - 2023-02-20 05:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 05:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:42:43 --> Input Class Initialized
INFO - 2023-02-20 05:42:43 --> Input Class Initialized
INFO - 2023-02-20 05:42:43 --> Language Class Initialized
INFO - 2023-02-20 05:42:43 --> Language Class Initialized
INFO - 2023-02-20 05:42:43 --> Loader Class Initialized
INFO - 2023-02-20 05:42:43 --> Loader Class Initialized
INFO - 2023-02-20 05:42:43 --> Controller Class Initialized
INFO - 2023-02-20 05:42:43 --> Controller Class Initialized
DEBUG - 2023-02-20 05:42:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 05:42:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:42:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:42:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:42:43 --> Model "Login_model" initialized
INFO - 2023-02-20 05:42:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:42:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:42:43 --> Final output sent to browser
DEBUG - 2023-02-20 05:42:43 --> Total execution time: 0.0206
INFO - 2023-02-20 05:42:43 --> Config Class Initialized
INFO - 2023-02-20 05:42:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:42:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:42:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:42:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:42:43 --> URI Class Initialized
INFO - 2023-02-20 05:42:43 --> Router Class Initialized
INFO - 2023-02-20 05:42:43 --> Output Class Initialized
INFO - 2023-02-20 05:42:43 --> Security Class Initialized
DEBUG - 2023-02-20 05:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:42:43 --> Input Class Initialized
INFO - 2023-02-20 05:42:43 --> Language Class Initialized
INFO - 2023-02-20 05:42:43 --> Loader Class Initialized
INFO - 2023-02-20 05:42:43 --> Controller Class Initialized
DEBUG - 2023-02-20 05:42:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:42:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:42:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:42:43 --> Final output sent to browser
DEBUG - 2023-02-20 05:42:43 --> Total execution time: 0.0558
INFO - 2023-02-20 05:42:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:42:44 --> Total execution time: 0.6743
INFO - 2023-02-20 05:42:44 --> Config Class Initialized
INFO - 2023-02-20 05:42:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:42:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:42:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:42:44 --> URI Class Initialized
INFO - 2023-02-20 05:42:44 --> Router Class Initialized
INFO - 2023-02-20 05:42:44 --> Output Class Initialized
INFO - 2023-02-20 05:42:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:42:44 --> Input Class Initialized
INFO - 2023-02-20 05:42:44 --> Language Class Initialized
INFO - 2023-02-20 05:42:44 --> Loader Class Initialized
INFO - 2023-02-20 05:42:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:42:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:42:44 --> Model "Login_model" initialized
INFO - 2023-02-20 05:42:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:42:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:42:45 --> Final output sent to browser
DEBUG - 2023-02-20 05:42:45 --> Total execution time: 0.6594
INFO - 2023-02-20 05:43:43 --> Config Class Initialized
INFO - 2023-02-20 05:43:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:43:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:43:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:43:43 --> URI Class Initialized
INFO - 2023-02-20 05:43:43 --> Router Class Initialized
INFO - 2023-02-20 05:43:43 --> Output Class Initialized
INFO - 2023-02-20 05:43:43 --> Security Class Initialized
DEBUG - 2023-02-20 05:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:43:43 --> Config Class Initialized
INFO - 2023-02-20 05:43:43 --> Input Class Initialized
INFO - 2023-02-20 05:43:43 --> Hooks Class Initialized
INFO - 2023-02-20 05:43:43 --> Language Class Initialized
DEBUG - 2023-02-20 05:43:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:43:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:43:43 --> Loader Class Initialized
INFO - 2023-02-20 05:43:43 --> URI Class Initialized
INFO - 2023-02-20 05:43:43 --> Controller Class Initialized
INFO - 2023-02-20 05:43:43 --> Router Class Initialized
DEBUG - 2023-02-20 05:43:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:43:43 --> Output Class Initialized
INFO - 2023-02-20 05:43:43 --> Security Class Initialized
INFO - 2023-02-20 05:43:43 --> Database Driver Class Initialized
DEBUG - 2023-02-20 05:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:43:43 --> Input Class Initialized
INFO - 2023-02-20 05:43:43 --> Language Class Initialized
INFO - 2023-02-20 05:43:43 --> Loader Class Initialized
INFO - 2023-02-20 05:43:43 --> Controller Class Initialized
DEBUG - 2023-02-20 05:43:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:43:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:43:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:43:43 --> Model "Login_model" initialized
INFO - 2023-02-20 05:43:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:43:43 --> Final output sent to browser
DEBUG - 2023-02-20 05:43:43 --> Total execution time: 0.0258
INFO - 2023-02-20 05:43:43 --> Config Class Initialized
INFO - 2023-02-20 05:43:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:43:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:43:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:43:43 --> Utf8 Class Initialized
INFO - 2023-02-20 05:43:43 --> URI Class Initialized
INFO - 2023-02-20 05:43:43 --> Router Class Initialized
INFO - 2023-02-20 05:43:43 --> Output Class Initialized
INFO - 2023-02-20 05:43:43 --> Security Class Initialized
DEBUG - 2023-02-20 05:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:43:43 --> Input Class Initialized
INFO - 2023-02-20 05:43:43 --> Language Class Initialized
INFO - 2023-02-20 05:43:43 --> Loader Class Initialized
INFO - 2023-02-20 05:43:43 --> Controller Class Initialized
DEBUG - 2023-02-20 05:43:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:43:43 --> Database Driver Class Initialized
INFO - 2023-02-20 05:43:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:43:43 --> Final output sent to browser
DEBUG - 2023-02-20 05:43:43 --> Total execution time: 0.0569
INFO - 2023-02-20 05:43:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:43:44 --> Total execution time: 0.7427
INFO - 2023-02-20 05:43:44 --> Config Class Initialized
INFO - 2023-02-20 05:43:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:43:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:43:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:43:44 --> URI Class Initialized
INFO - 2023-02-20 05:43:44 --> Router Class Initialized
INFO - 2023-02-20 05:43:44 --> Output Class Initialized
INFO - 2023-02-20 05:43:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:43:44 --> Input Class Initialized
INFO - 2023-02-20 05:43:44 --> Language Class Initialized
INFO - 2023-02-20 05:43:44 --> Loader Class Initialized
INFO - 2023-02-20 05:43:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:43:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:43:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:43:44 --> Model "Login_model" initialized
INFO - 2023-02-20 05:43:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:43:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:43:45 --> Final output sent to browser
DEBUG - 2023-02-20 05:43:45 --> Total execution time: 0.6578
INFO - 2023-02-20 05:44:44 --> Config Class Initialized
INFO - 2023-02-20 05:44:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:44:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:44:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:44:44 --> URI Class Initialized
INFO - 2023-02-20 05:44:44 --> Router Class Initialized
INFO - 2023-02-20 05:44:44 --> Output Class Initialized
INFO - 2023-02-20 05:44:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:44:44 --> Input Class Initialized
INFO - 2023-02-20 05:44:44 --> Language Class Initialized
INFO - 2023-02-20 05:44:44 --> Loader Class Initialized
INFO - 2023-02-20 05:44:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:44:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:44:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:44:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:44:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:44:44 --> Total execution time: 0.0174
INFO - 2023-02-20 05:44:44 --> Config Class Initialized
INFO - 2023-02-20 05:44:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:44:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:44:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:44:44 --> URI Class Initialized
INFO - 2023-02-20 05:44:44 --> Router Class Initialized
INFO - 2023-02-20 05:44:44 --> Output Class Initialized
INFO - 2023-02-20 05:44:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:44:44 --> Input Class Initialized
INFO - 2023-02-20 05:44:44 --> Language Class Initialized
INFO - 2023-02-20 05:44:44 --> Loader Class Initialized
INFO - 2023-02-20 05:44:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:44:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:44:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:44:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:44:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:44:44 --> Total execution time: 0.0147
INFO - 2023-02-20 05:44:45 --> Config Class Initialized
INFO - 2023-02-20 05:44:45 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:44:45 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:44:45 --> Utf8 Class Initialized
INFO - 2023-02-20 05:44:45 --> URI Class Initialized
INFO - 2023-02-20 05:44:45 --> Router Class Initialized
INFO - 2023-02-20 05:44:45 --> Output Class Initialized
INFO - 2023-02-20 05:44:45 --> Security Class Initialized
DEBUG - 2023-02-20 05:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:44:45 --> Input Class Initialized
INFO - 2023-02-20 05:44:45 --> Language Class Initialized
INFO - 2023-02-20 05:44:45 --> Loader Class Initialized
INFO - 2023-02-20 05:44:45 --> Controller Class Initialized
DEBUG - 2023-02-20 05:44:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:44:45 --> Database Driver Class Initialized
INFO - 2023-02-20 05:44:45 --> Model "Login_model" initialized
INFO - 2023-02-20 05:44:45 --> Database Driver Class Initialized
INFO - 2023-02-20 05:44:45 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:44:46 --> Final output sent to browser
DEBUG - 2023-02-20 05:44:46 --> Total execution time: 0.7644
INFO - 2023-02-20 05:44:46 --> Config Class Initialized
INFO - 2023-02-20 05:44:46 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:44:46 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:44:46 --> Utf8 Class Initialized
INFO - 2023-02-20 05:44:46 --> URI Class Initialized
INFO - 2023-02-20 05:44:46 --> Router Class Initialized
INFO - 2023-02-20 05:44:46 --> Output Class Initialized
INFO - 2023-02-20 05:44:46 --> Security Class Initialized
DEBUG - 2023-02-20 05:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:44:46 --> Input Class Initialized
INFO - 2023-02-20 05:44:46 --> Language Class Initialized
INFO - 2023-02-20 05:44:46 --> Loader Class Initialized
INFO - 2023-02-20 05:44:46 --> Controller Class Initialized
DEBUG - 2023-02-20 05:44:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:44:46 --> Database Driver Class Initialized
INFO - 2023-02-20 05:44:46 --> Model "Login_model" initialized
INFO - 2023-02-20 05:44:46 --> Database Driver Class Initialized
INFO - 2023-02-20 05:44:46 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:44:47 --> Final output sent to browser
DEBUG - 2023-02-20 05:44:47 --> Total execution time: 0.6806
INFO - 2023-02-20 05:45:45 --> Config Class Initialized
INFO - 2023-02-20 05:45:45 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:45:45 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:45:45 --> Utf8 Class Initialized
INFO - 2023-02-20 05:45:45 --> URI Class Initialized
INFO - 2023-02-20 05:45:45 --> Router Class Initialized
INFO - 2023-02-20 05:45:45 --> Output Class Initialized
INFO - 2023-02-20 05:45:45 --> Security Class Initialized
DEBUG - 2023-02-20 05:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:45:45 --> Input Class Initialized
INFO - 2023-02-20 05:45:45 --> Language Class Initialized
INFO - 2023-02-20 05:45:45 --> Loader Class Initialized
INFO - 2023-02-20 05:45:45 --> Controller Class Initialized
DEBUG - 2023-02-20 05:45:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:45:45 --> Database Driver Class Initialized
INFO - 2023-02-20 05:45:45 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:45:45 --> Final output sent to browser
DEBUG - 2023-02-20 05:45:45 --> Total execution time: 0.1809
INFO - 2023-02-20 05:45:45 --> Config Class Initialized
INFO - 2023-02-20 05:45:45 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:45:45 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:45:45 --> Utf8 Class Initialized
INFO - 2023-02-20 05:45:45 --> URI Class Initialized
INFO - 2023-02-20 05:45:45 --> Router Class Initialized
INFO - 2023-02-20 05:45:45 --> Output Class Initialized
INFO - 2023-02-20 05:45:45 --> Security Class Initialized
DEBUG - 2023-02-20 05:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:45:45 --> Input Class Initialized
INFO - 2023-02-20 05:45:45 --> Language Class Initialized
INFO - 2023-02-20 05:45:45 --> Loader Class Initialized
INFO - 2023-02-20 05:45:45 --> Controller Class Initialized
DEBUG - 2023-02-20 05:45:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:45:45 --> Database Driver Class Initialized
INFO - 2023-02-20 05:45:45 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:45:45 --> Final output sent to browser
DEBUG - 2023-02-20 05:45:45 --> Total execution time: 0.0145
INFO - 2023-02-20 05:45:46 --> Config Class Initialized
INFO - 2023-02-20 05:45:46 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:45:46 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:45:46 --> Utf8 Class Initialized
INFO - 2023-02-20 05:45:46 --> URI Class Initialized
INFO - 2023-02-20 05:45:46 --> Router Class Initialized
INFO - 2023-02-20 05:45:46 --> Output Class Initialized
INFO - 2023-02-20 05:45:46 --> Security Class Initialized
DEBUG - 2023-02-20 05:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:45:46 --> Input Class Initialized
INFO - 2023-02-20 05:45:46 --> Language Class Initialized
INFO - 2023-02-20 05:45:46 --> Loader Class Initialized
INFO - 2023-02-20 05:45:46 --> Controller Class Initialized
DEBUG - 2023-02-20 05:45:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:45:46 --> Database Driver Class Initialized
INFO - 2023-02-20 05:45:46 --> Model "Login_model" initialized
INFO - 2023-02-20 05:45:46 --> Database Driver Class Initialized
INFO - 2023-02-20 05:45:46 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:45:47 --> Final output sent to browser
DEBUG - 2023-02-20 05:45:47 --> Total execution time: 0.6259
INFO - 2023-02-20 05:45:47 --> Config Class Initialized
INFO - 2023-02-20 05:45:47 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:45:47 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:45:47 --> Utf8 Class Initialized
INFO - 2023-02-20 05:45:47 --> URI Class Initialized
INFO - 2023-02-20 05:45:47 --> Router Class Initialized
INFO - 2023-02-20 05:45:47 --> Output Class Initialized
INFO - 2023-02-20 05:45:47 --> Security Class Initialized
DEBUG - 2023-02-20 05:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:45:47 --> Input Class Initialized
INFO - 2023-02-20 05:45:47 --> Language Class Initialized
INFO - 2023-02-20 05:45:47 --> Loader Class Initialized
INFO - 2023-02-20 05:45:47 --> Controller Class Initialized
DEBUG - 2023-02-20 05:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:45:47 --> Database Driver Class Initialized
INFO - 2023-02-20 05:45:47 --> Model "Login_model" initialized
INFO - 2023-02-20 05:45:47 --> Database Driver Class Initialized
INFO - 2023-02-20 05:45:47 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:45:47 --> Final output sent to browser
DEBUG - 2023-02-20 05:45:47 --> Total execution time: 0.8375
INFO - 2023-02-20 05:46:44 --> Config Class Initialized
INFO - 2023-02-20 05:46:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:46:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:46:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:46:44 --> URI Class Initialized
INFO - 2023-02-20 05:46:44 --> Router Class Initialized
INFO - 2023-02-20 05:46:44 --> Output Class Initialized
INFO - 2023-02-20 05:46:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:46:44 --> Input Class Initialized
INFO - 2023-02-20 05:46:44 --> Language Class Initialized
INFO - 2023-02-20 05:46:44 --> Loader Class Initialized
INFO - 2023-02-20 05:46:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:46:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:46:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:46:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:46:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:46:44 --> Total execution time: 0.0605
INFO - 2023-02-20 05:46:44 --> Config Class Initialized
INFO - 2023-02-20 05:46:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:46:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:46:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:46:44 --> URI Class Initialized
INFO - 2023-02-20 05:46:44 --> Router Class Initialized
INFO - 2023-02-20 05:46:44 --> Output Class Initialized
INFO - 2023-02-20 05:46:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:46:44 --> Input Class Initialized
INFO - 2023-02-20 05:46:44 --> Language Class Initialized
INFO - 2023-02-20 05:46:44 --> Loader Class Initialized
INFO - 2023-02-20 05:46:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:46:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:46:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:46:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:46:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:46:44 --> Total execution time: 0.0150
INFO - 2023-02-20 05:46:45 --> Config Class Initialized
INFO - 2023-02-20 05:46:45 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:46:45 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:46:45 --> Utf8 Class Initialized
INFO - 2023-02-20 05:46:45 --> URI Class Initialized
INFO - 2023-02-20 05:46:45 --> Router Class Initialized
INFO - 2023-02-20 05:46:45 --> Output Class Initialized
INFO - 2023-02-20 05:46:45 --> Security Class Initialized
DEBUG - 2023-02-20 05:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:46:45 --> Input Class Initialized
INFO - 2023-02-20 05:46:45 --> Language Class Initialized
INFO - 2023-02-20 05:46:45 --> Loader Class Initialized
INFO - 2023-02-20 05:46:45 --> Controller Class Initialized
DEBUG - 2023-02-20 05:46:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:46:45 --> Database Driver Class Initialized
INFO - 2023-02-20 05:46:45 --> Model "Login_model" initialized
INFO - 2023-02-20 05:46:45 --> Database Driver Class Initialized
INFO - 2023-02-20 05:46:45 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:46:46 --> Final output sent to browser
DEBUG - 2023-02-20 05:46:46 --> Total execution time: 0.7921
INFO - 2023-02-20 05:46:46 --> Config Class Initialized
INFO - 2023-02-20 05:46:46 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:46:46 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:46:46 --> Utf8 Class Initialized
INFO - 2023-02-20 05:46:46 --> URI Class Initialized
INFO - 2023-02-20 05:46:46 --> Router Class Initialized
INFO - 2023-02-20 05:46:46 --> Output Class Initialized
INFO - 2023-02-20 05:46:46 --> Security Class Initialized
DEBUG - 2023-02-20 05:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:46:46 --> Input Class Initialized
INFO - 2023-02-20 05:46:46 --> Language Class Initialized
INFO - 2023-02-20 05:46:46 --> Loader Class Initialized
INFO - 2023-02-20 05:46:46 --> Controller Class Initialized
DEBUG - 2023-02-20 05:46:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:46:46 --> Database Driver Class Initialized
INFO - 2023-02-20 05:46:46 --> Model "Login_model" initialized
INFO - 2023-02-20 05:46:46 --> Database Driver Class Initialized
INFO - 2023-02-20 05:46:46 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:46:46 --> Final output sent to browser
DEBUG - 2023-02-20 05:46:46 --> Total execution time: 0.8570
INFO - 2023-02-20 05:47:44 --> Config Class Initialized
INFO - 2023-02-20 05:47:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:47:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:47:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:47:44 --> URI Class Initialized
INFO - 2023-02-20 05:47:44 --> Router Class Initialized
INFO - 2023-02-20 05:47:44 --> Output Class Initialized
INFO - 2023-02-20 05:47:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:47:44 --> Input Class Initialized
INFO - 2023-02-20 05:47:44 --> Language Class Initialized
INFO - 2023-02-20 05:47:44 --> Loader Class Initialized
INFO - 2023-02-20 05:47:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:47:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:47:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:47:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:47:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:47:44 --> Total execution time: 0.0197
INFO - 2023-02-20 05:47:44 --> Config Class Initialized
INFO - 2023-02-20 05:47:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:47:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:47:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:47:44 --> URI Class Initialized
INFO - 2023-02-20 05:47:44 --> Router Class Initialized
INFO - 2023-02-20 05:47:44 --> Output Class Initialized
INFO - 2023-02-20 05:47:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:47:44 --> Input Class Initialized
INFO - 2023-02-20 05:47:44 --> Language Class Initialized
INFO - 2023-02-20 05:47:44 --> Loader Class Initialized
INFO - 2023-02-20 05:47:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:47:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:47:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:47:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:47:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:47:44 --> Total execution time: 0.0148
INFO - 2023-02-20 05:47:45 --> Config Class Initialized
INFO - 2023-02-20 05:47:45 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:47:45 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:47:45 --> Utf8 Class Initialized
INFO - 2023-02-20 05:47:45 --> URI Class Initialized
INFO - 2023-02-20 05:47:45 --> Router Class Initialized
INFO - 2023-02-20 05:47:45 --> Output Class Initialized
INFO - 2023-02-20 05:47:45 --> Security Class Initialized
DEBUG - 2023-02-20 05:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:47:45 --> Input Class Initialized
INFO - 2023-02-20 05:47:45 --> Language Class Initialized
INFO - 2023-02-20 05:47:45 --> Loader Class Initialized
INFO - 2023-02-20 05:47:45 --> Controller Class Initialized
DEBUG - 2023-02-20 05:47:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:47:45 --> Database Driver Class Initialized
INFO - 2023-02-20 05:47:45 --> Model "Login_model" initialized
INFO - 2023-02-20 05:47:45 --> Database Driver Class Initialized
INFO - 2023-02-20 05:47:45 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:47:46 --> Final output sent to browser
DEBUG - 2023-02-20 05:47:46 --> Total execution time: 0.6189
INFO - 2023-02-20 05:47:46 --> Config Class Initialized
INFO - 2023-02-20 05:47:46 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:47:46 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:47:46 --> Utf8 Class Initialized
INFO - 2023-02-20 05:47:46 --> URI Class Initialized
INFO - 2023-02-20 05:47:46 --> Router Class Initialized
INFO - 2023-02-20 05:47:46 --> Output Class Initialized
INFO - 2023-02-20 05:47:46 --> Security Class Initialized
DEBUG - 2023-02-20 05:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:47:46 --> Input Class Initialized
INFO - 2023-02-20 05:47:46 --> Language Class Initialized
INFO - 2023-02-20 05:47:46 --> Loader Class Initialized
INFO - 2023-02-20 05:47:46 --> Controller Class Initialized
DEBUG - 2023-02-20 05:47:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:47:46 --> Database Driver Class Initialized
INFO - 2023-02-20 05:47:46 --> Model "Login_model" initialized
INFO - 2023-02-20 05:47:46 --> Database Driver Class Initialized
INFO - 2023-02-20 05:47:46 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:47:47 --> Final output sent to browser
DEBUG - 2023-02-20 05:47:47 --> Total execution time: 0.7023
INFO - 2023-02-20 05:48:44 --> Config Class Initialized
INFO - 2023-02-20 05:48:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:48:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:48:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:48:44 --> URI Class Initialized
INFO - 2023-02-20 05:48:44 --> Router Class Initialized
INFO - 2023-02-20 05:48:44 --> Output Class Initialized
INFO - 2023-02-20 05:48:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:48:44 --> Input Class Initialized
INFO - 2023-02-20 05:48:44 --> Language Class Initialized
INFO - 2023-02-20 05:48:44 --> Loader Class Initialized
INFO - 2023-02-20 05:48:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:48:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:48:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:48:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:48:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:48:44 --> Total execution time: 0.1045
INFO - 2023-02-20 05:48:44 --> Config Class Initialized
INFO - 2023-02-20 05:48:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:48:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:48:44 --> Utf8 Class Initialized
INFO - 2023-02-20 05:48:44 --> URI Class Initialized
INFO - 2023-02-20 05:48:44 --> Router Class Initialized
INFO - 2023-02-20 05:48:44 --> Output Class Initialized
INFO - 2023-02-20 05:48:44 --> Security Class Initialized
DEBUG - 2023-02-20 05:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:48:44 --> Input Class Initialized
INFO - 2023-02-20 05:48:44 --> Language Class Initialized
INFO - 2023-02-20 05:48:44 --> Loader Class Initialized
INFO - 2023-02-20 05:48:44 --> Controller Class Initialized
DEBUG - 2023-02-20 05:48:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:48:44 --> Database Driver Class Initialized
INFO - 2023-02-20 05:48:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:48:44 --> Final output sent to browser
DEBUG - 2023-02-20 05:48:44 --> Total execution time: 0.1174
INFO - 2023-02-20 05:48:45 --> Config Class Initialized
INFO - 2023-02-20 05:48:45 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:48:45 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:48:45 --> Utf8 Class Initialized
INFO - 2023-02-20 05:48:45 --> URI Class Initialized
INFO - 2023-02-20 05:48:45 --> Router Class Initialized
INFO - 2023-02-20 05:48:45 --> Output Class Initialized
INFO - 2023-02-20 05:48:45 --> Security Class Initialized
DEBUG - 2023-02-20 05:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:48:45 --> Input Class Initialized
INFO - 2023-02-20 05:48:45 --> Language Class Initialized
INFO - 2023-02-20 05:48:45 --> Loader Class Initialized
INFO - 2023-02-20 05:48:45 --> Controller Class Initialized
DEBUG - 2023-02-20 05:48:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:48:45 --> Database Driver Class Initialized
INFO - 2023-02-20 05:48:45 --> Model "Login_model" initialized
INFO - 2023-02-20 05:48:45 --> Database Driver Class Initialized
INFO - 2023-02-20 05:48:45 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:48:46 --> Final output sent to browser
DEBUG - 2023-02-20 05:48:46 --> Total execution time: 1.2279
INFO - 2023-02-20 05:48:46 --> Config Class Initialized
INFO - 2023-02-20 05:48:46 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:48:46 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:48:46 --> Utf8 Class Initialized
INFO - 2023-02-20 05:48:46 --> URI Class Initialized
INFO - 2023-02-20 05:48:46 --> Router Class Initialized
INFO - 2023-02-20 05:48:46 --> Output Class Initialized
INFO - 2023-02-20 05:48:46 --> Security Class Initialized
DEBUG - 2023-02-20 05:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:48:46 --> Input Class Initialized
INFO - 2023-02-20 05:48:46 --> Language Class Initialized
INFO - 2023-02-20 05:48:46 --> Loader Class Initialized
INFO - 2023-02-20 05:48:46 --> Controller Class Initialized
DEBUG - 2023-02-20 05:48:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:48:46 --> Database Driver Class Initialized
INFO - 2023-02-20 05:48:46 --> Model "Login_model" initialized
INFO - 2023-02-20 05:48:46 --> Database Driver Class Initialized
INFO - 2023-02-20 05:48:46 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:48:48 --> Final output sent to browser
DEBUG - 2023-02-20 05:48:48 --> Total execution time: 1.4337
INFO - 2023-02-20 05:50:18 --> Config Class Initialized
INFO - 2023-02-20 05:50:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:50:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:50:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:50:18 --> URI Class Initialized
INFO - 2023-02-20 05:50:18 --> Router Class Initialized
INFO - 2023-02-20 05:50:18 --> Output Class Initialized
INFO - 2023-02-20 05:50:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:50:18 --> Input Class Initialized
INFO - 2023-02-20 05:50:18 --> Language Class Initialized
INFO - 2023-02-20 05:50:18 --> Loader Class Initialized
INFO - 2023-02-20 05:50:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:50:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:50:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:50:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:50:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:50:18 --> Total execution time: 0.0178
INFO - 2023-02-20 05:50:18 --> Config Class Initialized
INFO - 2023-02-20 05:50:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:50:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:50:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:50:18 --> URI Class Initialized
INFO - 2023-02-20 05:50:18 --> Router Class Initialized
INFO - 2023-02-20 05:50:18 --> Output Class Initialized
INFO - 2023-02-20 05:50:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:50:18 --> Input Class Initialized
INFO - 2023-02-20 05:50:18 --> Language Class Initialized
INFO - 2023-02-20 05:50:18 --> Loader Class Initialized
INFO - 2023-02-20 05:50:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:50:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:50:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:50:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:50:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:50:18 --> Total execution time: 0.0574
INFO - 2023-02-20 05:51:31 --> Config Class Initialized
INFO - 2023-02-20 05:51:31 --> Config Class Initialized
INFO - 2023-02-20 05:51:31 --> Hooks Class Initialized
INFO - 2023-02-20 05:51:31 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:51:31 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 05:51:31 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:51:31 --> Utf8 Class Initialized
INFO - 2023-02-20 05:51:31 --> Utf8 Class Initialized
INFO - 2023-02-20 05:51:31 --> URI Class Initialized
INFO - 2023-02-20 05:51:31 --> URI Class Initialized
INFO - 2023-02-20 05:51:31 --> Router Class Initialized
INFO - 2023-02-20 05:51:31 --> Router Class Initialized
INFO - 2023-02-20 05:51:31 --> Output Class Initialized
INFO - 2023-02-20 05:51:31 --> Output Class Initialized
INFO - 2023-02-20 05:51:31 --> Security Class Initialized
INFO - 2023-02-20 05:51:31 --> Security Class Initialized
DEBUG - 2023-02-20 05:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 05:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:51:31 --> Input Class Initialized
INFO - 2023-02-20 05:51:31 --> Input Class Initialized
INFO - 2023-02-20 05:51:31 --> Language Class Initialized
INFO - 2023-02-20 05:51:31 --> Language Class Initialized
INFO - 2023-02-20 05:51:31 --> Loader Class Initialized
INFO - 2023-02-20 05:51:31 --> Loader Class Initialized
INFO - 2023-02-20 05:51:31 --> Controller Class Initialized
INFO - 2023-02-20 05:51:31 --> Controller Class Initialized
DEBUG - 2023-02-20 05:51:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 05:51:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:51:31 --> Database Driver Class Initialized
INFO - 2023-02-20 05:51:31 --> Database Driver Class Initialized
INFO - 2023-02-20 05:51:31 --> Model "Login_model" initialized
INFO - 2023-02-20 05:51:31 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:51:31 --> Database Driver Class Initialized
INFO - 2023-02-20 05:51:31 --> Final output sent to browser
DEBUG - 2023-02-20 05:51:31 --> Total execution time: 0.0225
INFO - 2023-02-20 05:51:31 --> Config Class Initialized
INFO - 2023-02-20 05:51:31 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:51:32 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:51:32 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:51:32 --> Utf8 Class Initialized
INFO - 2023-02-20 05:51:32 --> URI Class Initialized
INFO - 2023-02-20 05:51:32 --> Router Class Initialized
INFO - 2023-02-20 05:51:32 --> Output Class Initialized
INFO - 2023-02-20 05:51:32 --> Security Class Initialized
DEBUG - 2023-02-20 05:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:51:32 --> Input Class Initialized
INFO - 2023-02-20 05:51:32 --> Language Class Initialized
INFO - 2023-02-20 05:51:32 --> Loader Class Initialized
INFO - 2023-02-20 05:51:32 --> Controller Class Initialized
DEBUG - 2023-02-20 05:51:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:51:32 --> Database Driver Class Initialized
INFO - 2023-02-20 05:51:32 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:51:32 --> Final output sent to browser
DEBUG - 2023-02-20 05:51:32 --> Total execution time: 0.0592
INFO - 2023-02-20 05:51:32 --> Final output sent to browser
DEBUG - 2023-02-20 05:51:32 --> Total execution time: 0.7486
INFO - 2023-02-20 05:51:32 --> Config Class Initialized
INFO - 2023-02-20 05:51:32 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:51:32 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:51:32 --> Utf8 Class Initialized
INFO - 2023-02-20 05:51:32 --> URI Class Initialized
INFO - 2023-02-20 05:51:32 --> Router Class Initialized
INFO - 2023-02-20 05:51:32 --> Output Class Initialized
INFO - 2023-02-20 05:51:32 --> Security Class Initialized
DEBUG - 2023-02-20 05:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:51:32 --> Input Class Initialized
INFO - 2023-02-20 05:51:32 --> Language Class Initialized
INFO - 2023-02-20 05:51:32 --> Loader Class Initialized
INFO - 2023-02-20 05:51:32 --> Controller Class Initialized
DEBUG - 2023-02-20 05:51:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:51:32 --> Database Driver Class Initialized
INFO - 2023-02-20 05:51:32 --> Model "Login_model" initialized
INFO - 2023-02-20 05:51:32 --> Database Driver Class Initialized
INFO - 2023-02-20 05:51:32 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:51:33 --> Final output sent to browser
DEBUG - 2023-02-20 05:51:33 --> Total execution time: 0.6612
INFO - 2023-02-20 05:52:27 --> Config Class Initialized
INFO - 2023-02-20 05:52:27 --> Config Class Initialized
INFO - 2023-02-20 05:52:27 --> Hooks Class Initialized
INFO - 2023-02-20 05:52:27 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:52:27 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 05:52:27 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:52:27 --> Utf8 Class Initialized
INFO - 2023-02-20 05:52:27 --> Utf8 Class Initialized
INFO - 2023-02-20 05:52:27 --> URI Class Initialized
INFO - 2023-02-20 05:52:27 --> URI Class Initialized
INFO - 2023-02-20 05:52:27 --> Router Class Initialized
INFO - 2023-02-20 05:52:27 --> Router Class Initialized
INFO - 2023-02-20 05:52:27 --> Output Class Initialized
INFO - 2023-02-20 05:52:27 --> Output Class Initialized
INFO - 2023-02-20 05:52:27 --> Security Class Initialized
INFO - 2023-02-20 05:52:27 --> Security Class Initialized
DEBUG - 2023-02-20 05:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 05:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:52:27 --> Input Class Initialized
INFO - 2023-02-20 05:52:27 --> Input Class Initialized
INFO - 2023-02-20 05:52:27 --> Language Class Initialized
INFO - 2023-02-20 05:52:27 --> Language Class Initialized
INFO - 2023-02-20 05:52:27 --> Loader Class Initialized
INFO - 2023-02-20 05:52:27 --> Loader Class Initialized
INFO - 2023-02-20 05:52:27 --> Controller Class Initialized
INFO - 2023-02-20 05:52:27 --> Controller Class Initialized
DEBUG - 2023-02-20 05:52:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 05:52:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:52:27 --> Database Driver Class Initialized
INFO - 2023-02-20 05:52:27 --> Database Driver Class Initialized
INFO - 2023-02-20 05:52:27 --> Model "Login_model" initialized
INFO - 2023-02-20 05:52:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:52:27 --> Database Driver Class Initialized
INFO - 2023-02-20 05:52:27 --> Final output sent to browser
DEBUG - 2023-02-20 05:52:27 --> Total execution time: 0.0173
INFO - 2023-02-20 05:52:27 --> Config Class Initialized
INFO - 2023-02-20 05:52:27 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:52:27 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:52:27 --> Utf8 Class Initialized
INFO - 2023-02-20 05:52:27 --> URI Class Initialized
INFO - 2023-02-20 05:52:27 --> Router Class Initialized
INFO - 2023-02-20 05:52:27 --> Output Class Initialized
INFO - 2023-02-20 05:52:27 --> Security Class Initialized
DEBUG - 2023-02-20 05:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:52:27 --> Input Class Initialized
INFO - 2023-02-20 05:52:27 --> Language Class Initialized
INFO - 2023-02-20 05:52:27 --> Loader Class Initialized
INFO - 2023-02-20 05:52:27 --> Controller Class Initialized
DEBUG - 2023-02-20 05:52:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:52:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:52:27 --> Database Driver Class Initialized
INFO - 2023-02-20 05:52:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:52:27 --> Final output sent to browser
DEBUG - 2023-02-20 05:52:27 --> Total execution time: 0.0156
INFO - 2023-02-20 05:52:28 --> Final output sent to browser
DEBUG - 2023-02-20 05:52:28 --> Total execution time: 0.7171
INFO - 2023-02-20 05:52:28 --> Config Class Initialized
INFO - 2023-02-20 05:52:28 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:52:28 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:52:28 --> Utf8 Class Initialized
INFO - 2023-02-20 05:52:28 --> URI Class Initialized
INFO - 2023-02-20 05:52:28 --> Router Class Initialized
INFO - 2023-02-20 05:52:28 --> Output Class Initialized
INFO - 2023-02-20 05:52:28 --> Security Class Initialized
DEBUG - 2023-02-20 05:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:52:28 --> Input Class Initialized
INFO - 2023-02-20 05:52:28 --> Language Class Initialized
INFO - 2023-02-20 05:52:28 --> Loader Class Initialized
INFO - 2023-02-20 05:52:28 --> Controller Class Initialized
DEBUG - 2023-02-20 05:52:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:52:28 --> Database Driver Class Initialized
INFO - 2023-02-20 05:52:28 --> Model "Login_model" initialized
INFO - 2023-02-20 05:52:28 --> Database Driver Class Initialized
INFO - 2023-02-20 05:52:28 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:52:28 --> Final output sent to browser
DEBUG - 2023-02-20 05:52:28 --> Total execution time: 0.6970
INFO - 2023-02-20 05:53:19 --> Config Class Initialized
INFO - 2023-02-20 05:53:19 --> Config Class Initialized
INFO - 2023-02-20 05:53:19 --> Hooks Class Initialized
INFO - 2023-02-20 05:53:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:53:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 05:53:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:53:19 --> Utf8 Class Initialized
INFO - 2023-02-20 05:53:19 --> Utf8 Class Initialized
INFO - 2023-02-20 05:53:19 --> URI Class Initialized
INFO - 2023-02-20 05:53:19 --> URI Class Initialized
INFO - 2023-02-20 05:53:19 --> Router Class Initialized
INFO - 2023-02-20 05:53:19 --> Router Class Initialized
INFO - 2023-02-20 05:53:19 --> Output Class Initialized
INFO - 2023-02-20 05:53:19 --> Output Class Initialized
INFO - 2023-02-20 05:53:19 --> Security Class Initialized
INFO - 2023-02-20 05:53:19 --> Security Class Initialized
DEBUG - 2023-02-20 05:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 05:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:53:19 --> Input Class Initialized
INFO - 2023-02-20 05:53:19 --> Input Class Initialized
INFO - 2023-02-20 05:53:19 --> Language Class Initialized
INFO - 2023-02-20 05:53:19 --> Language Class Initialized
INFO - 2023-02-20 05:53:19 --> Loader Class Initialized
INFO - 2023-02-20 05:53:19 --> Loader Class Initialized
INFO - 2023-02-20 05:53:19 --> Controller Class Initialized
INFO - 2023-02-20 05:53:19 --> Controller Class Initialized
DEBUG - 2023-02-20 05:53:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 05:53:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:53:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:53:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:53:19 --> Model "Login_model" initialized
INFO - 2023-02-20 05:53:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:53:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:53:19 --> Final output sent to browser
DEBUG - 2023-02-20 05:53:19 --> Total execution time: 0.0204
INFO - 2023-02-20 05:53:19 --> Config Class Initialized
INFO - 2023-02-20 05:53:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:53:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:53:19 --> Utf8 Class Initialized
INFO - 2023-02-20 05:53:19 --> URI Class Initialized
INFO - 2023-02-20 05:53:19 --> Router Class Initialized
INFO - 2023-02-20 05:53:19 --> Output Class Initialized
INFO - 2023-02-20 05:53:19 --> Security Class Initialized
DEBUG - 2023-02-20 05:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:53:19 --> Input Class Initialized
INFO - 2023-02-20 05:53:19 --> Language Class Initialized
INFO - 2023-02-20 05:53:19 --> Loader Class Initialized
INFO - 2023-02-20 05:53:19 --> Controller Class Initialized
DEBUG - 2023-02-20 05:53:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:53:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:53:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:53:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:53:19 --> Final output sent to browser
DEBUG - 2023-02-20 05:53:19 --> Total execution time: 0.0146
INFO - 2023-02-20 05:53:20 --> Final output sent to browser
DEBUG - 2023-02-20 05:53:20 --> Total execution time: 0.7319
INFO - 2023-02-20 05:53:20 --> Config Class Initialized
INFO - 2023-02-20 05:53:20 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:53:20 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:53:20 --> Utf8 Class Initialized
INFO - 2023-02-20 05:53:20 --> URI Class Initialized
INFO - 2023-02-20 05:53:20 --> Router Class Initialized
INFO - 2023-02-20 05:53:20 --> Output Class Initialized
INFO - 2023-02-20 05:53:20 --> Security Class Initialized
DEBUG - 2023-02-20 05:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:53:20 --> Input Class Initialized
INFO - 2023-02-20 05:53:20 --> Language Class Initialized
INFO - 2023-02-20 05:53:20 --> Loader Class Initialized
INFO - 2023-02-20 05:53:20 --> Controller Class Initialized
DEBUG - 2023-02-20 05:53:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:53:20 --> Database Driver Class Initialized
INFO - 2023-02-20 05:53:20 --> Model "Login_model" initialized
INFO - 2023-02-20 05:53:20 --> Database Driver Class Initialized
INFO - 2023-02-20 05:53:20 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:53:21 --> Final output sent to browser
DEBUG - 2023-02-20 05:53:21 --> Total execution time: 0.6844
INFO - 2023-02-20 05:54:18 --> Config Class Initialized
INFO - 2023-02-20 05:54:18 --> Config Class Initialized
INFO - 2023-02-20 05:54:18 --> Hooks Class Initialized
INFO - 2023-02-20 05:54:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:54:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 05:54:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:54:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:54:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:54:18 --> URI Class Initialized
INFO - 2023-02-20 05:54:18 --> URI Class Initialized
INFO - 2023-02-20 05:54:18 --> Router Class Initialized
INFO - 2023-02-20 05:54:18 --> Router Class Initialized
INFO - 2023-02-20 05:54:18 --> Output Class Initialized
INFO - 2023-02-20 05:54:18 --> Output Class Initialized
INFO - 2023-02-20 05:54:18 --> Security Class Initialized
INFO - 2023-02-20 05:54:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:54:18 --> Input Class Initialized
DEBUG - 2023-02-20 05:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:54:18 --> Language Class Initialized
INFO - 2023-02-20 05:54:18 --> Input Class Initialized
INFO - 2023-02-20 05:54:18 --> Language Class Initialized
INFO - 2023-02-20 05:54:18 --> Loader Class Initialized
INFO - 2023-02-20 05:54:18 --> Loader Class Initialized
INFO - 2023-02-20 05:54:18 --> Controller Class Initialized
INFO - 2023-02-20 05:54:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:54:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 05:54:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:54:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:54:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:54:18 --> Model "Login_model" initialized
INFO - 2023-02-20 05:54:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:54:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:54:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:54:18 --> Total execution time: 0.0201
INFO - 2023-02-20 05:54:18 --> Config Class Initialized
INFO - 2023-02-20 05:54:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:54:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:54:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:54:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:54:18 --> URI Class Initialized
INFO - 2023-02-20 05:54:18 --> Router Class Initialized
INFO - 2023-02-20 05:54:18 --> Output Class Initialized
INFO - 2023-02-20 05:54:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:54:18 --> Input Class Initialized
INFO - 2023-02-20 05:54:18 --> Language Class Initialized
INFO - 2023-02-20 05:54:18 --> Loader Class Initialized
INFO - 2023-02-20 05:54:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:54:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:54:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:54:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:54:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:54:18 --> Total execution time: 0.0558
INFO - 2023-02-20 05:54:19 --> Final output sent to browser
DEBUG - 2023-02-20 05:54:19 --> Total execution time: 0.6678
INFO - 2023-02-20 05:54:19 --> Config Class Initialized
INFO - 2023-02-20 05:54:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:54:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:54:19 --> Utf8 Class Initialized
INFO - 2023-02-20 05:54:19 --> URI Class Initialized
INFO - 2023-02-20 05:54:19 --> Router Class Initialized
INFO - 2023-02-20 05:54:19 --> Output Class Initialized
INFO - 2023-02-20 05:54:19 --> Security Class Initialized
DEBUG - 2023-02-20 05:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:54:19 --> Input Class Initialized
INFO - 2023-02-20 05:54:19 --> Language Class Initialized
INFO - 2023-02-20 05:54:19 --> Loader Class Initialized
INFO - 2023-02-20 05:54:19 --> Controller Class Initialized
DEBUG - 2023-02-20 05:54:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:54:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:54:19 --> Model "Login_model" initialized
INFO - 2023-02-20 05:54:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:54:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:54:19 --> Final output sent to browser
DEBUG - 2023-02-20 05:54:19 --> Total execution time: 0.6151
INFO - 2023-02-20 05:55:18 --> Config Class Initialized
INFO - 2023-02-20 05:55:18 --> Config Class Initialized
INFO - 2023-02-20 05:55:18 --> Hooks Class Initialized
INFO - 2023-02-20 05:55:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:55:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 05:55:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:55:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:55:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:55:18 --> URI Class Initialized
INFO - 2023-02-20 05:55:18 --> URI Class Initialized
INFO - 2023-02-20 05:55:18 --> Router Class Initialized
INFO - 2023-02-20 05:55:18 --> Router Class Initialized
INFO - 2023-02-20 05:55:18 --> Output Class Initialized
INFO - 2023-02-20 05:55:18 --> Output Class Initialized
INFO - 2023-02-20 05:55:18 --> Security Class Initialized
INFO - 2023-02-20 05:55:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 05:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:55:18 --> Input Class Initialized
INFO - 2023-02-20 05:55:18 --> Input Class Initialized
INFO - 2023-02-20 05:55:18 --> Language Class Initialized
INFO - 2023-02-20 05:55:18 --> Language Class Initialized
INFO - 2023-02-20 05:55:18 --> Loader Class Initialized
INFO - 2023-02-20 05:55:18 --> Loader Class Initialized
INFO - 2023-02-20 05:55:18 --> Controller Class Initialized
INFO - 2023-02-20 05:55:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:55:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 05:55:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:55:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:55:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:55:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:55:18 --> Model "Login_model" initialized
INFO - 2023-02-20 05:55:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:55:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:55:18 --> Total execution time: 0.0192
INFO - 2023-02-20 05:55:18 --> Config Class Initialized
INFO - 2023-02-20 05:55:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:55:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:55:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:55:18 --> URI Class Initialized
INFO - 2023-02-20 05:55:18 --> Router Class Initialized
INFO - 2023-02-20 05:55:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:55:18 --> Output Class Initialized
INFO - 2023-02-20 05:55:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:55:18 --> Input Class Initialized
INFO - 2023-02-20 05:55:18 --> Language Class Initialized
INFO - 2023-02-20 05:55:18 --> Loader Class Initialized
INFO - 2023-02-20 05:55:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:55:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:55:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:55:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:55:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:55:18 --> Total execution time: 0.0147
INFO - 2023-02-20 05:55:19 --> Final output sent to browser
DEBUG - 2023-02-20 05:55:19 --> Total execution time: 0.6987
INFO - 2023-02-20 05:55:19 --> Config Class Initialized
INFO - 2023-02-20 05:55:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:55:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:55:19 --> Utf8 Class Initialized
INFO - 2023-02-20 05:55:19 --> URI Class Initialized
INFO - 2023-02-20 05:55:19 --> Router Class Initialized
INFO - 2023-02-20 05:55:19 --> Output Class Initialized
INFO - 2023-02-20 05:55:19 --> Security Class Initialized
DEBUG - 2023-02-20 05:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:55:19 --> Input Class Initialized
INFO - 2023-02-20 05:55:19 --> Language Class Initialized
INFO - 2023-02-20 05:55:19 --> Loader Class Initialized
INFO - 2023-02-20 05:55:19 --> Controller Class Initialized
DEBUG - 2023-02-20 05:55:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:55:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:55:19 --> Model "Login_model" initialized
INFO - 2023-02-20 05:55:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:55:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:55:19 --> Final output sent to browser
DEBUG - 2023-02-20 05:55:19 --> Total execution time: 0.6701
INFO - 2023-02-20 05:56:34 --> Config Class Initialized
INFO - 2023-02-20 05:56:34 --> Config Class Initialized
INFO - 2023-02-20 05:56:34 --> Hooks Class Initialized
INFO - 2023-02-20 05:56:34 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:56:34 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:56:34 --> Utf8 Class Initialized
DEBUG - 2023-02-20 05:56:34 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:56:34 --> URI Class Initialized
INFO - 2023-02-20 05:56:34 --> Router Class Initialized
INFO - 2023-02-20 05:56:34 --> Utf8 Class Initialized
INFO - 2023-02-20 05:56:34 --> Output Class Initialized
INFO - 2023-02-20 05:56:34 --> Security Class Initialized
DEBUG - 2023-02-20 05:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:56:34 --> URI Class Initialized
INFO - 2023-02-20 05:56:34 --> Router Class Initialized
INFO - 2023-02-20 05:56:34 --> Input Class Initialized
INFO - 2023-02-20 05:56:34 --> Output Class Initialized
INFO - 2023-02-20 05:56:34 --> Language Class Initialized
INFO - 2023-02-20 05:56:34 --> Security Class Initialized
INFO - 2023-02-20 05:56:34 --> Loader Class Initialized
DEBUG - 2023-02-20 05:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:56:34 --> Controller Class Initialized
INFO - 2023-02-20 05:56:34 --> Input Class Initialized
DEBUG - 2023-02-20 05:56:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:56:34 --> Language Class Initialized
INFO - 2023-02-20 05:56:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:56:34 --> Loader Class Initialized
INFO - 2023-02-20 05:56:34 --> Controller Class Initialized
DEBUG - 2023-02-20 05:56:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:56:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:56:34 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:56:34 --> Model "Login_model" initialized
INFO - 2023-02-20 05:56:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:56:34 --> Final output sent to browser
DEBUG - 2023-02-20 05:56:34 --> Total execution time: 0.1808
INFO - 2023-02-20 05:56:34 --> Config Class Initialized
INFO - 2023-02-20 05:56:34 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:56:34 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:56:34 --> Utf8 Class Initialized
INFO - 2023-02-20 05:56:34 --> URI Class Initialized
INFO - 2023-02-20 05:56:34 --> Router Class Initialized
INFO - 2023-02-20 05:56:34 --> Output Class Initialized
INFO - 2023-02-20 05:56:34 --> Security Class Initialized
DEBUG - 2023-02-20 05:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:56:34 --> Input Class Initialized
INFO - 2023-02-20 05:56:34 --> Language Class Initialized
INFO - 2023-02-20 05:56:34 --> Loader Class Initialized
INFO - 2023-02-20 05:56:34 --> Controller Class Initialized
DEBUG - 2023-02-20 05:56:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:56:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:56:34 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:56:34 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:56:34 --> Final output sent to browser
DEBUG - 2023-02-20 05:56:34 --> Total execution time: 0.0156
INFO - 2023-02-20 05:56:34 --> Final output sent to browser
DEBUG - 2023-02-20 05:56:34 --> Total execution time: 0.8081
INFO - 2023-02-20 05:56:34 --> Config Class Initialized
INFO - 2023-02-20 05:56:34 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:56:34 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:56:34 --> Utf8 Class Initialized
INFO - 2023-02-20 05:56:34 --> URI Class Initialized
INFO - 2023-02-20 05:56:34 --> Router Class Initialized
INFO - 2023-02-20 05:56:34 --> Output Class Initialized
INFO - 2023-02-20 05:56:34 --> Security Class Initialized
DEBUG - 2023-02-20 05:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:56:34 --> Input Class Initialized
INFO - 2023-02-20 05:56:34 --> Language Class Initialized
INFO - 2023-02-20 05:56:34 --> Loader Class Initialized
INFO - 2023-02-20 05:56:34 --> Controller Class Initialized
DEBUG - 2023-02-20 05:56:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:56:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:56:34 --> Model "Login_model" initialized
INFO - 2023-02-20 05:56:34 --> Database Driver Class Initialized
INFO - 2023-02-20 05:56:34 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:56:35 --> Final output sent to browser
DEBUG - 2023-02-20 05:56:35 --> Total execution time: 0.7377
INFO - 2023-02-20 05:57:18 --> Config Class Initialized
INFO - 2023-02-20 05:57:18 --> Config Class Initialized
INFO - 2023-02-20 05:57:18 --> Hooks Class Initialized
INFO - 2023-02-20 05:57:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:57:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 05:57:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:57:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:57:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:57:18 --> URI Class Initialized
INFO - 2023-02-20 05:57:18 --> URI Class Initialized
INFO - 2023-02-20 05:57:18 --> Router Class Initialized
INFO - 2023-02-20 05:57:18 --> Router Class Initialized
INFO - 2023-02-20 05:57:18 --> Output Class Initialized
INFO - 2023-02-20 05:57:18 --> Output Class Initialized
INFO - 2023-02-20 05:57:18 --> Security Class Initialized
INFO - 2023-02-20 05:57:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 05:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:57:18 --> Input Class Initialized
INFO - 2023-02-20 05:57:18 --> Input Class Initialized
INFO - 2023-02-20 05:57:18 --> Language Class Initialized
INFO - 2023-02-20 05:57:18 --> Language Class Initialized
INFO - 2023-02-20 05:57:18 --> Loader Class Initialized
INFO - 2023-02-20 05:57:18 --> Loader Class Initialized
INFO - 2023-02-20 05:57:18 --> Controller Class Initialized
INFO - 2023-02-20 05:57:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:57:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 05:57:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:57:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:57:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:57:18 --> Model "Login_model" initialized
INFO - 2023-02-20 05:57:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:57:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:57:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:57:18 --> Total execution time: 0.0229
INFO - 2023-02-20 05:57:18 --> Config Class Initialized
INFO - 2023-02-20 05:57:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:57:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:57:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:57:18 --> URI Class Initialized
INFO - 2023-02-20 05:57:18 --> Router Class Initialized
INFO - 2023-02-20 05:57:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:57:18 --> Output Class Initialized
INFO - 2023-02-20 05:57:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:57:18 --> Input Class Initialized
INFO - 2023-02-20 05:57:18 --> Language Class Initialized
INFO - 2023-02-20 05:57:18 --> Loader Class Initialized
INFO - 2023-02-20 05:57:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:57:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:57:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:57:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:57:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:57:18 --> Total execution time: 0.0122
INFO - 2023-02-20 05:57:19 --> Final output sent to browser
DEBUG - 2023-02-20 05:57:19 --> Total execution time: 0.6613
INFO - 2023-02-20 05:57:19 --> Config Class Initialized
INFO - 2023-02-20 05:57:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:57:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:57:19 --> Utf8 Class Initialized
INFO - 2023-02-20 05:57:19 --> URI Class Initialized
INFO - 2023-02-20 05:57:19 --> Router Class Initialized
INFO - 2023-02-20 05:57:19 --> Output Class Initialized
INFO - 2023-02-20 05:57:19 --> Security Class Initialized
DEBUG - 2023-02-20 05:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:57:19 --> Input Class Initialized
INFO - 2023-02-20 05:57:19 --> Language Class Initialized
INFO - 2023-02-20 05:57:19 --> Loader Class Initialized
INFO - 2023-02-20 05:57:19 --> Controller Class Initialized
DEBUG - 2023-02-20 05:57:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:57:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:57:19 --> Model "Login_model" initialized
INFO - 2023-02-20 05:57:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:57:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:57:19 --> Final output sent to browser
DEBUG - 2023-02-20 05:57:19 --> Total execution time: 0.6966
INFO - 2023-02-20 05:58:18 --> Config Class Initialized
INFO - 2023-02-20 05:58:18 --> Config Class Initialized
INFO - 2023-02-20 05:58:18 --> Hooks Class Initialized
INFO - 2023-02-20 05:58:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:58:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 05:58:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:58:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:58:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:58:18 --> URI Class Initialized
INFO - 2023-02-20 05:58:18 --> URI Class Initialized
INFO - 2023-02-20 05:58:18 --> Router Class Initialized
INFO - 2023-02-20 05:58:18 --> Router Class Initialized
INFO - 2023-02-20 05:58:18 --> Output Class Initialized
INFO - 2023-02-20 05:58:18 --> Output Class Initialized
INFO - 2023-02-20 05:58:18 --> Security Class Initialized
INFO - 2023-02-20 05:58:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 05:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:58:18 --> Input Class Initialized
INFO - 2023-02-20 05:58:18 --> Input Class Initialized
INFO - 2023-02-20 05:58:18 --> Language Class Initialized
INFO - 2023-02-20 05:58:18 --> Language Class Initialized
INFO - 2023-02-20 05:58:18 --> Loader Class Initialized
INFO - 2023-02-20 05:58:18 --> Loader Class Initialized
INFO - 2023-02-20 05:58:18 --> Controller Class Initialized
INFO - 2023-02-20 05:58:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:58:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 05:58:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:58:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:58:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:58:18 --> Model "Login_model" initialized
INFO - 2023-02-20 05:58:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:58:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:58:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:58:18 --> Total execution time: 0.0163
INFO - 2023-02-20 05:58:18 --> Config Class Initialized
INFO - 2023-02-20 05:58:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:58:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:58:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:58:18 --> URI Class Initialized
INFO - 2023-02-20 05:58:18 --> Router Class Initialized
INFO - 2023-02-20 05:58:18 --> Output Class Initialized
INFO - 2023-02-20 05:58:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:58:18 --> Input Class Initialized
INFO - 2023-02-20 05:58:18 --> Language Class Initialized
INFO - 2023-02-20 05:58:18 --> Loader Class Initialized
INFO - 2023-02-20 05:58:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:58:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:58:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:58:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:58:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:58:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:58:18 --> Total execution time: 0.0149
INFO - 2023-02-20 05:58:19 --> Final output sent to browser
DEBUG - 2023-02-20 05:58:19 --> Total execution time: 0.6612
INFO - 2023-02-20 05:58:19 --> Config Class Initialized
INFO - 2023-02-20 05:58:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:58:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:58:19 --> Utf8 Class Initialized
INFO - 2023-02-20 05:58:19 --> URI Class Initialized
INFO - 2023-02-20 05:58:19 --> Router Class Initialized
INFO - 2023-02-20 05:58:19 --> Output Class Initialized
INFO - 2023-02-20 05:58:19 --> Security Class Initialized
DEBUG - 2023-02-20 05:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:58:19 --> Input Class Initialized
INFO - 2023-02-20 05:58:19 --> Language Class Initialized
INFO - 2023-02-20 05:58:19 --> Loader Class Initialized
INFO - 2023-02-20 05:58:19 --> Controller Class Initialized
DEBUG - 2023-02-20 05:58:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:58:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:58:19 --> Model "Login_model" initialized
INFO - 2023-02-20 05:58:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:58:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:58:19 --> Final output sent to browser
DEBUG - 2023-02-20 05:58:19 --> Total execution time: 0.6461
INFO - 2023-02-20 05:59:18 --> Config Class Initialized
INFO - 2023-02-20 05:59:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:59:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:59:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:59:18 --> URI Class Initialized
INFO - 2023-02-20 05:59:18 --> Router Class Initialized
INFO - 2023-02-20 05:59:18 --> Output Class Initialized
INFO - 2023-02-20 05:59:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:59:18 --> Input Class Initialized
INFO - 2023-02-20 05:59:18 --> Language Class Initialized
INFO - 2023-02-20 05:59:18 --> Loader Class Initialized
INFO - 2023-02-20 05:59:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:59:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:59:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:59:18 --> Config Class Initialized
INFO - 2023-02-20 05:59:18 --> Model "Login_model" initialized
INFO - 2023-02-20 05:59:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:59:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:59:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:59:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:59:18 --> URI Class Initialized
INFO - 2023-02-20 05:59:18 --> Router Class Initialized
INFO - 2023-02-20 05:59:18 --> Output Class Initialized
INFO - 2023-02-20 05:59:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:59:18 --> Input Class Initialized
INFO - 2023-02-20 05:59:18 --> Language Class Initialized
INFO - 2023-02-20 05:59:18 --> Loader Class Initialized
INFO - 2023-02-20 05:59:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:59:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:59:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:59:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:59:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:59:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:59:18 --> Total execution time: 0.0599
INFO - 2023-02-20 05:59:18 --> Config Class Initialized
INFO - 2023-02-20 05:59:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:59:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:59:18 --> Utf8 Class Initialized
INFO - 2023-02-20 05:59:18 --> URI Class Initialized
INFO - 2023-02-20 05:59:18 --> Router Class Initialized
INFO - 2023-02-20 05:59:18 --> Output Class Initialized
INFO - 2023-02-20 05:59:18 --> Security Class Initialized
DEBUG - 2023-02-20 05:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:59:18 --> Input Class Initialized
INFO - 2023-02-20 05:59:18 --> Language Class Initialized
INFO - 2023-02-20 05:59:18 --> Loader Class Initialized
INFO - 2023-02-20 05:59:18 --> Controller Class Initialized
DEBUG - 2023-02-20 05:59:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:59:18 --> Database Driver Class Initialized
INFO - 2023-02-20 05:59:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:59:18 --> Final output sent to browser
DEBUG - 2023-02-20 05:59:18 --> Total execution time: 0.0154
INFO - 2023-02-20 05:59:19 --> Final output sent to browser
DEBUG - 2023-02-20 05:59:19 --> Total execution time: 0.7277
INFO - 2023-02-20 05:59:19 --> Config Class Initialized
INFO - 2023-02-20 05:59:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 05:59:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 05:59:19 --> Utf8 Class Initialized
INFO - 2023-02-20 05:59:19 --> URI Class Initialized
INFO - 2023-02-20 05:59:19 --> Router Class Initialized
INFO - 2023-02-20 05:59:19 --> Output Class Initialized
INFO - 2023-02-20 05:59:19 --> Security Class Initialized
DEBUG - 2023-02-20 05:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 05:59:19 --> Input Class Initialized
INFO - 2023-02-20 05:59:19 --> Language Class Initialized
INFO - 2023-02-20 05:59:19 --> Loader Class Initialized
INFO - 2023-02-20 05:59:19 --> Controller Class Initialized
DEBUG - 2023-02-20 05:59:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 05:59:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:59:19 --> Model "Login_model" initialized
INFO - 2023-02-20 05:59:19 --> Database Driver Class Initialized
INFO - 2023-02-20 05:59:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 05:59:19 --> Final output sent to browser
DEBUG - 2023-02-20 05:59:19 --> Total execution time: 0.6959
INFO - 2023-02-20 06:00:31 --> Config Class Initialized
INFO - 2023-02-20 06:00:31 --> Config Class Initialized
INFO - 2023-02-20 06:00:31 --> Hooks Class Initialized
INFO - 2023-02-20 06:00:31 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:00:31 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:00:31 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:00:31 --> Utf8 Class Initialized
INFO - 2023-02-20 06:00:31 --> Utf8 Class Initialized
INFO - 2023-02-20 06:00:31 --> URI Class Initialized
INFO - 2023-02-20 06:00:31 --> URI Class Initialized
INFO - 2023-02-20 06:00:31 --> Router Class Initialized
INFO - 2023-02-20 06:00:31 --> Router Class Initialized
INFO - 2023-02-20 06:00:31 --> Output Class Initialized
INFO - 2023-02-20 06:00:31 --> Output Class Initialized
INFO - 2023-02-20 06:00:31 --> Security Class Initialized
INFO - 2023-02-20 06:00:31 --> Security Class Initialized
DEBUG - 2023-02-20 06:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:00:31 --> Input Class Initialized
DEBUG - 2023-02-20 06:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:00:31 --> Language Class Initialized
INFO - 2023-02-20 06:00:31 --> Input Class Initialized
INFO - 2023-02-20 06:00:31 --> Language Class Initialized
INFO - 2023-02-20 06:00:31 --> Loader Class Initialized
INFO - 2023-02-20 06:00:31 --> Loader Class Initialized
INFO - 2023-02-20 06:00:31 --> Controller Class Initialized
INFO - 2023-02-20 06:00:31 --> Controller Class Initialized
DEBUG - 2023-02-20 06:00:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:00:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:00:31 --> Database Driver Class Initialized
INFO - 2023-02-20 06:00:31 --> Database Driver Class Initialized
INFO - 2023-02-20 06:00:31 --> Model "Login_model" initialized
INFO - 2023-02-20 06:00:31 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:00:31 --> Database Driver Class Initialized
INFO - 2023-02-20 06:00:31 --> Final output sent to browser
DEBUG - 2023-02-20 06:00:31 --> Total execution time: 0.0227
INFO - 2023-02-20 06:00:31 --> Config Class Initialized
INFO - 2023-02-20 06:00:31 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:00:31 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:00:31 --> Utf8 Class Initialized
INFO - 2023-02-20 06:00:31 --> URI Class Initialized
INFO - 2023-02-20 06:00:31 --> Router Class Initialized
INFO - 2023-02-20 06:00:31 --> Output Class Initialized
INFO - 2023-02-20 06:00:31 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:00:31 --> Security Class Initialized
DEBUG - 2023-02-20 06:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:00:31 --> Input Class Initialized
INFO - 2023-02-20 06:00:31 --> Language Class Initialized
INFO - 2023-02-20 06:00:31 --> Loader Class Initialized
INFO - 2023-02-20 06:00:31 --> Controller Class Initialized
DEBUG - 2023-02-20 06:00:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:00:31 --> Database Driver Class Initialized
INFO - 2023-02-20 06:00:31 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:00:31 --> Final output sent to browser
DEBUG - 2023-02-20 06:00:31 --> Total execution time: 0.0171
INFO - 2023-02-20 06:00:32 --> Final output sent to browser
DEBUG - 2023-02-20 06:00:32 --> Total execution time: 0.7371
INFO - 2023-02-20 06:00:32 --> Config Class Initialized
INFO - 2023-02-20 06:00:32 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:00:32 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:00:32 --> Utf8 Class Initialized
INFO - 2023-02-20 06:00:32 --> URI Class Initialized
INFO - 2023-02-20 06:00:32 --> Router Class Initialized
INFO - 2023-02-20 06:00:32 --> Output Class Initialized
INFO - 2023-02-20 06:00:32 --> Security Class Initialized
DEBUG - 2023-02-20 06:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:00:32 --> Input Class Initialized
INFO - 2023-02-20 06:00:32 --> Language Class Initialized
INFO - 2023-02-20 06:00:32 --> Loader Class Initialized
INFO - 2023-02-20 06:00:32 --> Controller Class Initialized
DEBUG - 2023-02-20 06:00:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:00:32 --> Database Driver Class Initialized
INFO - 2023-02-20 06:00:32 --> Model "Login_model" initialized
INFO - 2023-02-20 06:00:32 --> Database Driver Class Initialized
INFO - 2023-02-20 06:00:32 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:00:33 --> Final output sent to browser
DEBUG - 2023-02-20 06:00:33 --> Total execution time: 1.3141
INFO - 2023-02-20 06:01:18 --> Config Class Initialized
INFO - 2023-02-20 06:01:18 --> Config Class Initialized
INFO - 2023-02-20 06:01:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:01:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:01:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:01:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:01:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:01:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:01:18 --> URI Class Initialized
INFO - 2023-02-20 06:01:18 --> URI Class Initialized
INFO - 2023-02-20 06:01:18 --> Router Class Initialized
INFO - 2023-02-20 06:01:18 --> Router Class Initialized
INFO - 2023-02-20 06:01:18 --> Output Class Initialized
INFO - 2023-02-20 06:01:18 --> Output Class Initialized
INFO - 2023-02-20 06:01:18 --> Security Class Initialized
INFO - 2023-02-20 06:01:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:01:18 --> Input Class Initialized
INFO - 2023-02-20 06:01:18 --> Input Class Initialized
INFO - 2023-02-20 06:01:18 --> Language Class Initialized
INFO - 2023-02-20 06:01:18 --> Language Class Initialized
INFO - 2023-02-20 06:01:18 --> Loader Class Initialized
INFO - 2023-02-20 06:01:18 --> Controller Class Initialized
INFO - 2023-02-20 06:01:18 --> Loader Class Initialized
DEBUG - 2023-02-20 06:01:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:01:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:01:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:01:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:01:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:01:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:01:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:01:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:01:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:01:18 --> Total execution time: 0.0191
INFO - 2023-02-20 06:01:18 --> Config Class Initialized
INFO - 2023-02-20 06:01:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:01:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:01:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:01:18 --> URI Class Initialized
INFO - 2023-02-20 06:01:18 --> Router Class Initialized
INFO - 2023-02-20 06:01:18 --> Output Class Initialized
INFO - 2023-02-20 06:01:18 --> Security Class Initialized
INFO - 2023-02-20 06:01:18 --> Model "Cluster_model" initialized
DEBUG - 2023-02-20 06:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:01:18 --> Input Class Initialized
INFO - 2023-02-20 06:01:18 --> Language Class Initialized
INFO - 2023-02-20 06:01:18 --> Loader Class Initialized
INFO - 2023-02-20 06:01:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:01:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:01:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:01:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:01:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:01:18 --> Total execution time: 0.0151
INFO - 2023-02-20 06:01:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:01:19 --> Total execution time: 0.6812
INFO - 2023-02-20 06:01:19 --> Config Class Initialized
INFO - 2023-02-20 06:01:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:01:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:01:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:01:19 --> URI Class Initialized
INFO - 2023-02-20 06:01:19 --> Router Class Initialized
INFO - 2023-02-20 06:01:19 --> Output Class Initialized
INFO - 2023-02-20 06:01:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:01:19 --> Input Class Initialized
INFO - 2023-02-20 06:01:19 --> Language Class Initialized
INFO - 2023-02-20 06:01:19 --> Loader Class Initialized
INFO - 2023-02-20 06:01:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:01:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:01:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:01:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:01:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:01:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:01:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:01:19 --> Total execution time: 0.6607
INFO - 2023-02-20 06:02:27 --> Config Class Initialized
INFO - 2023-02-20 06:02:27 --> Hooks Class Initialized
INFO - 2023-02-20 06:02:27 --> Config Class Initialized
INFO - 2023-02-20 06:02:27 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:02:27 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:02:27 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:02:27 --> Utf8 Class Initialized
INFO - 2023-02-20 06:02:27 --> Utf8 Class Initialized
INFO - 2023-02-20 06:02:27 --> URI Class Initialized
INFO - 2023-02-20 06:02:27 --> URI Class Initialized
INFO - 2023-02-20 06:02:27 --> Router Class Initialized
INFO - 2023-02-20 06:02:27 --> Router Class Initialized
INFO - 2023-02-20 06:02:27 --> Output Class Initialized
INFO - 2023-02-20 06:02:27 --> Output Class Initialized
INFO - 2023-02-20 06:02:27 --> Security Class Initialized
INFO - 2023-02-20 06:02:27 --> Security Class Initialized
DEBUG - 2023-02-20 06:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:02:27 --> Input Class Initialized
INFO - 2023-02-20 06:02:27 --> Input Class Initialized
INFO - 2023-02-20 06:02:27 --> Language Class Initialized
INFO - 2023-02-20 06:02:27 --> Language Class Initialized
INFO - 2023-02-20 06:02:27 --> Loader Class Initialized
INFO - 2023-02-20 06:02:27 --> Loader Class Initialized
INFO - 2023-02-20 06:02:27 --> Controller Class Initialized
INFO - 2023-02-20 06:02:27 --> Controller Class Initialized
DEBUG - 2023-02-20 06:02:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:02:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:02:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:02:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:02:27 --> Model "Login_model" initialized
INFO - 2023-02-20 06:02:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:02:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:02:27 --> Final output sent to browser
DEBUG - 2023-02-20 06:02:27 --> Total execution time: 0.0172
INFO - 2023-02-20 06:02:27 --> Config Class Initialized
INFO - 2023-02-20 06:02:27 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:02:27 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:02:27 --> Utf8 Class Initialized
INFO - 2023-02-20 06:02:27 --> URI Class Initialized
INFO - 2023-02-20 06:02:27 --> Router Class Initialized
INFO - 2023-02-20 06:02:27 --> Output Class Initialized
INFO - 2023-02-20 06:02:27 --> Security Class Initialized
DEBUG - 2023-02-20 06:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:02:27 --> Input Class Initialized
INFO - 2023-02-20 06:02:27 --> Language Class Initialized
INFO - 2023-02-20 06:02:27 --> Loader Class Initialized
INFO - 2023-02-20 06:02:27 --> Controller Class Initialized
DEBUG - 2023-02-20 06:02:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:02:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:02:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:02:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:02:27 --> Final output sent to browser
DEBUG - 2023-02-20 06:02:27 --> Total execution time: 0.0138
INFO - 2023-02-20 06:02:28 --> Final output sent to browser
DEBUG - 2023-02-20 06:02:28 --> Total execution time: 0.6526
INFO - 2023-02-20 06:02:28 --> Config Class Initialized
INFO - 2023-02-20 06:02:28 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:02:28 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:02:28 --> Utf8 Class Initialized
INFO - 2023-02-20 06:02:28 --> URI Class Initialized
INFO - 2023-02-20 06:02:28 --> Router Class Initialized
INFO - 2023-02-20 06:02:28 --> Output Class Initialized
INFO - 2023-02-20 06:02:28 --> Security Class Initialized
DEBUG - 2023-02-20 06:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:02:28 --> Input Class Initialized
INFO - 2023-02-20 06:02:28 --> Language Class Initialized
INFO - 2023-02-20 06:02:28 --> Loader Class Initialized
INFO - 2023-02-20 06:02:28 --> Controller Class Initialized
DEBUG - 2023-02-20 06:02:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:02:28 --> Database Driver Class Initialized
INFO - 2023-02-20 06:02:28 --> Model "Login_model" initialized
INFO - 2023-02-20 06:02:28 --> Database Driver Class Initialized
INFO - 2023-02-20 06:02:28 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:02:29 --> Final output sent to browser
DEBUG - 2023-02-20 06:02:29 --> Total execution time: 0.6454
INFO - 2023-02-20 06:03:18 --> Config Class Initialized
INFO - 2023-02-20 06:03:18 --> Config Class Initialized
INFO - 2023-02-20 06:03:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:03:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:03:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:03:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:03:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:03:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:03:18 --> URI Class Initialized
INFO - 2023-02-20 06:03:18 --> URI Class Initialized
INFO - 2023-02-20 06:03:18 --> Router Class Initialized
INFO - 2023-02-20 06:03:18 --> Router Class Initialized
INFO - 2023-02-20 06:03:18 --> Output Class Initialized
INFO - 2023-02-20 06:03:18 --> Output Class Initialized
INFO - 2023-02-20 06:03:18 --> Security Class Initialized
INFO - 2023-02-20 06:03:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:03:18 --> Input Class Initialized
DEBUG - 2023-02-20 06:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:03:18 --> Language Class Initialized
INFO - 2023-02-20 06:03:18 --> Input Class Initialized
INFO - 2023-02-20 06:03:18 --> Language Class Initialized
INFO - 2023-02-20 06:03:18 --> Loader Class Initialized
INFO - 2023-02-20 06:03:18 --> Loader Class Initialized
INFO - 2023-02-20 06:03:18 --> Controller Class Initialized
INFO - 2023-02-20 06:03:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:03:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:03:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:03:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:03:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:03:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:03:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:03:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:03:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:03:18 --> Total execution time: 0.0235
INFO - 2023-02-20 06:03:18 --> Config Class Initialized
INFO - 2023-02-20 06:03:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:03:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:03:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:03:18 --> URI Class Initialized
INFO - 2023-02-20 06:03:18 --> Router Class Initialized
INFO - 2023-02-20 06:03:18 --> Output Class Initialized
INFO - 2023-02-20 06:03:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:03:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:03:18 --> Input Class Initialized
INFO - 2023-02-20 06:03:18 --> Language Class Initialized
INFO - 2023-02-20 06:03:18 --> Loader Class Initialized
INFO - 2023-02-20 06:03:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:03:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:03:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:03:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:03:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:03:18 --> Total execution time: 0.0240
INFO - 2023-02-20 06:03:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:03:19 --> Total execution time: 0.7948
INFO - 2023-02-20 06:03:19 --> Config Class Initialized
INFO - 2023-02-20 06:03:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:03:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:03:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:03:19 --> URI Class Initialized
INFO - 2023-02-20 06:03:19 --> Router Class Initialized
INFO - 2023-02-20 06:03:19 --> Output Class Initialized
INFO - 2023-02-20 06:03:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:03:19 --> Input Class Initialized
INFO - 2023-02-20 06:03:19 --> Language Class Initialized
INFO - 2023-02-20 06:03:19 --> Loader Class Initialized
INFO - 2023-02-20 06:03:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:03:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:03:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:03:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:03:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:03:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:03:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:03:19 --> Total execution time: 0.7372
INFO - 2023-02-20 06:04:18 --> Config Class Initialized
INFO - 2023-02-20 06:04:18 --> Config Class Initialized
INFO - 2023-02-20 06:04:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:04:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:04:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:04:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:04:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:04:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:04:18 --> URI Class Initialized
INFO - 2023-02-20 06:04:18 --> URI Class Initialized
INFO - 2023-02-20 06:04:18 --> Router Class Initialized
INFO - 2023-02-20 06:04:18 --> Router Class Initialized
INFO - 2023-02-20 06:04:18 --> Output Class Initialized
INFO - 2023-02-20 06:04:18 --> Output Class Initialized
INFO - 2023-02-20 06:04:18 --> Security Class Initialized
INFO - 2023-02-20 06:04:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:04:18 --> Input Class Initialized
DEBUG - 2023-02-20 06:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:04:18 --> Language Class Initialized
INFO - 2023-02-20 06:04:18 --> Input Class Initialized
INFO - 2023-02-20 06:04:18 --> Language Class Initialized
INFO - 2023-02-20 06:04:18 --> Loader Class Initialized
INFO - 2023-02-20 06:04:18 --> Loader Class Initialized
INFO - 2023-02-20 06:04:18 --> Controller Class Initialized
INFO - 2023-02-20 06:04:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:04:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:04:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:04:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:04:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:04:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:04:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:04:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:04:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:04:18 --> Total execution time: 0.0240
INFO - 2023-02-20 06:04:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:04:18 --> Config Class Initialized
INFO - 2023-02-20 06:04:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:04:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:04:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:04:18 --> URI Class Initialized
INFO - 2023-02-20 06:04:18 --> Router Class Initialized
INFO - 2023-02-20 06:04:18 --> Output Class Initialized
INFO - 2023-02-20 06:04:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:04:18 --> Input Class Initialized
INFO - 2023-02-20 06:04:18 --> Language Class Initialized
INFO - 2023-02-20 06:04:18 --> Loader Class Initialized
INFO - 2023-02-20 06:04:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:04:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:04:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:04:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:04:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:04:18 --> Total execution time: 0.0150
INFO - 2023-02-20 06:04:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:04:19 --> Total execution time: 0.6911
INFO - 2023-02-20 06:04:19 --> Config Class Initialized
INFO - 2023-02-20 06:04:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:04:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:04:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:04:19 --> URI Class Initialized
INFO - 2023-02-20 06:04:19 --> Router Class Initialized
INFO - 2023-02-20 06:04:19 --> Output Class Initialized
INFO - 2023-02-20 06:04:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:04:19 --> Input Class Initialized
INFO - 2023-02-20 06:04:19 --> Language Class Initialized
INFO - 2023-02-20 06:04:19 --> Loader Class Initialized
INFO - 2023-02-20 06:04:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:04:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:04:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:04:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:04:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:04:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:04:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:04:19 --> Total execution time: 0.6716
INFO - 2023-02-20 06:05:18 --> Config Class Initialized
INFO - 2023-02-20 06:05:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:05:18 --> Config Class Initialized
INFO - 2023-02-20 06:05:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:05:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:05:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:05:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:05:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:05:18 --> URI Class Initialized
INFO - 2023-02-20 06:05:18 --> URI Class Initialized
INFO - 2023-02-20 06:05:18 --> Router Class Initialized
INFO - 2023-02-20 06:05:18 --> Router Class Initialized
INFO - 2023-02-20 06:05:18 --> Output Class Initialized
INFO - 2023-02-20 06:05:18 --> Output Class Initialized
INFO - 2023-02-20 06:05:18 --> Security Class Initialized
INFO - 2023-02-20 06:05:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:05:18 --> Input Class Initialized
INFO - 2023-02-20 06:05:18 --> Input Class Initialized
INFO - 2023-02-20 06:05:18 --> Language Class Initialized
INFO - 2023-02-20 06:05:18 --> Language Class Initialized
INFO - 2023-02-20 06:05:18 --> Loader Class Initialized
INFO - 2023-02-20 06:05:18 --> Loader Class Initialized
INFO - 2023-02-20 06:05:18 --> Controller Class Initialized
INFO - 2023-02-20 06:05:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:05:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:05:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:05:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:05:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:05:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:05:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:05:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:05:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:05:18 --> Total execution time: 0.0149
INFO - 2023-02-20 06:05:18 --> Config Class Initialized
INFO - 2023-02-20 06:05:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:05:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:05:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:05:18 --> URI Class Initialized
INFO - 2023-02-20 06:05:18 --> Router Class Initialized
INFO - 2023-02-20 06:05:18 --> Output Class Initialized
INFO - 2023-02-20 06:05:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:05:18 --> Input Class Initialized
INFO - 2023-02-20 06:05:18 --> Language Class Initialized
INFO - 2023-02-20 06:05:18 --> Loader Class Initialized
INFO - 2023-02-20 06:05:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:05:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:05:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:05:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:05:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:05:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:05:18 --> Total execution time: 0.0138
INFO - 2023-02-20 06:05:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:05:19 --> Total execution time: 0.6711
INFO - 2023-02-20 06:05:19 --> Config Class Initialized
INFO - 2023-02-20 06:05:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:05:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:05:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:05:19 --> URI Class Initialized
INFO - 2023-02-20 06:05:19 --> Router Class Initialized
INFO - 2023-02-20 06:05:19 --> Output Class Initialized
INFO - 2023-02-20 06:05:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:05:19 --> Input Class Initialized
INFO - 2023-02-20 06:05:19 --> Language Class Initialized
INFO - 2023-02-20 06:05:19 --> Loader Class Initialized
INFO - 2023-02-20 06:05:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:05:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:05:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:05:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:05:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:05:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:05:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:05:19 --> Total execution time: 0.6282
INFO - 2023-02-20 06:06:27 --> Config Class Initialized
INFO - 2023-02-20 06:06:27 --> Config Class Initialized
INFO - 2023-02-20 06:06:27 --> Hooks Class Initialized
INFO - 2023-02-20 06:06:27 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:06:27 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:06:27 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:06:27 --> Utf8 Class Initialized
INFO - 2023-02-20 06:06:27 --> Utf8 Class Initialized
INFO - 2023-02-20 06:06:27 --> URI Class Initialized
INFO - 2023-02-20 06:06:27 --> URI Class Initialized
INFO - 2023-02-20 06:06:27 --> Router Class Initialized
INFO - 2023-02-20 06:06:27 --> Router Class Initialized
INFO - 2023-02-20 06:06:27 --> Output Class Initialized
INFO - 2023-02-20 06:06:27 --> Output Class Initialized
INFO - 2023-02-20 06:06:27 --> Security Class Initialized
INFO - 2023-02-20 06:06:27 --> Security Class Initialized
DEBUG - 2023-02-20 06:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:06:27 --> Input Class Initialized
INFO - 2023-02-20 06:06:27 --> Input Class Initialized
INFO - 2023-02-20 06:06:27 --> Language Class Initialized
INFO - 2023-02-20 06:06:27 --> Language Class Initialized
INFO - 2023-02-20 06:06:27 --> Loader Class Initialized
INFO - 2023-02-20 06:06:27 --> Loader Class Initialized
INFO - 2023-02-20 06:06:27 --> Controller Class Initialized
INFO - 2023-02-20 06:06:27 --> Controller Class Initialized
DEBUG - 2023-02-20 06:06:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:06:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:06:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:06:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:06:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:06:27 --> Model "Login_model" initialized
INFO - 2023-02-20 06:06:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:06:27 --> Final output sent to browser
DEBUG - 2023-02-20 06:06:27 --> Total execution time: 0.0218
INFO - 2023-02-20 06:06:27 --> Config Class Initialized
INFO - 2023-02-20 06:06:27 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:06:27 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:06:27 --> Utf8 Class Initialized
INFO - 2023-02-20 06:06:27 --> URI Class Initialized
INFO - 2023-02-20 06:06:27 --> Router Class Initialized
INFO - 2023-02-20 06:06:27 --> Output Class Initialized
INFO - 2023-02-20 06:06:27 --> Security Class Initialized
DEBUG - 2023-02-20 06:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:06:27 --> Input Class Initialized
INFO - 2023-02-20 06:06:27 --> Language Class Initialized
INFO - 2023-02-20 06:06:27 --> Loader Class Initialized
INFO - 2023-02-20 06:06:27 --> Controller Class Initialized
DEBUG - 2023-02-20 06:06:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:06:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:06:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:06:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:06:27 --> Final output sent to browser
DEBUG - 2023-02-20 06:06:27 --> Total execution time: 0.0235
INFO - 2023-02-20 06:06:28 --> Final output sent to browser
DEBUG - 2023-02-20 06:06:28 --> Total execution time: 0.6921
INFO - 2023-02-20 06:06:28 --> Config Class Initialized
INFO - 2023-02-20 06:06:28 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:06:28 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:06:28 --> Utf8 Class Initialized
INFO - 2023-02-20 06:06:28 --> URI Class Initialized
INFO - 2023-02-20 06:06:28 --> Router Class Initialized
INFO - 2023-02-20 06:06:28 --> Output Class Initialized
INFO - 2023-02-20 06:06:28 --> Security Class Initialized
DEBUG - 2023-02-20 06:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:06:28 --> Input Class Initialized
INFO - 2023-02-20 06:06:28 --> Language Class Initialized
INFO - 2023-02-20 06:06:28 --> Loader Class Initialized
INFO - 2023-02-20 06:06:28 --> Controller Class Initialized
DEBUG - 2023-02-20 06:06:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:06:28 --> Database Driver Class Initialized
INFO - 2023-02-20 06:06:28 --> Model "Login_model" initialized
INFO - 2023-02-20 06:06:28 --> Database Driver Class Initialized
INFO - 2023-02-20 06:06:28 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:06:29 --> Final output sent to browser
DEBUG - 2023-02-20 06:06:29 --> Total execution time: 0.6412
INFO - 2023-02-20 06:07:21 --> Config Class Initialized
INFO - 2023-02-20 06:07:21 --> Hooks Class Initialized
INFO - 2023-02-20 06:07:21 --> Config Class Initialized
INFO - 2023-02-20 06:07:21 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:07:21 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:07:21 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:07:21 --> Utf8 Class Initialized
INFO - 2023-02-20 06:07:21 --> Utf8 Class Initialized
INFO - 2023-02-20 06:07:21 --> URI Class Initialized
INFO - 2023-02-20 06:07:21 --> URI Class Initialized
INFO - 2023-02-20 06:07:21 --> Router Class Initialized
INFO - 2023-02-20 06:07:21 --> Router Class Initialized
INFO - 2023-02-20 06:07:21 --> Output Class Initialized
INFO - 2023-02-20 06:07:21 --> Output Class Initialized
INFO - 2023-02-20 06:07:21 --> Security Class Initialized
INFO - 2023-02-20 06:07:21 --> Security Class Initialized
DEBUG - 2023-02-20 06:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:07:21 --> Input Class Initialized
INFO - 2023-02-20 06:07:21 --> Input Class Initialized
INFO - 2023-02-20 06:07:21 --> Language Class Initialized
INFO - 2023-02-20 06:07:21 --> Language Class Initialized
INFO - 2023-02-20 06:07:21 --> Loader Class Initialized
INFO - 2023-02-20 06:07:21 --> Loader Class Initialized
INFO - 2023-02-20 06:07:21 --> Controller Class Initialized
INFO - 2023-02-20 06:07:21 --> Controller Class Initialized
DEBUG - 2023-02-20 06:07:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:07:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:07:21 --> Database Driver Class Initialized
INFO - 2023-02-20 06:07:21 --> Database Driver Class Initialized
INFO - 2023-02-20 06:07:21 --> Model "Login_model" initialized
INFO - 2023-02-20 06:07:21 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:07:21 --> Database Driver Class Initialized
INFO - 2023-02-20 06:07:21 --> Final output sent to browser
DEBUG - 2023-02-20 06:07:21 --> Total execution time: 0.0170
INFO - 2023-02-20 06:07:21 --> Config Class Initialized
INFO - 2023-02-20 06:07:21 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:07:21 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:07:21 --> Utf8 Class Initialized
INFO - 2023-02-20 06:07:21 --> URI Class Initialized
INFO - 2023-02-20 06:07:21 --> Router Class Initialized
INFO - 2023-02-20 06:07:21 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:07:21 --> Output Class Initialized
INFO - 2023-02-20 06:07:21 --> Security Class Initialized
DEBUG - 2023-02-20 06:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:07:21 --> Input Class Initialized
INFO - 2023-02-20 06:07:21 --> Language Class Initialized
INFO - 2023-02-20 06:07:21 --> Loader Class Initialized
INFO - 2023-02-20 06:07:21 --> Controller Class Initialized
DEBUG - 2023-02-20 06:07:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:07:21 --> Database Driver Class Initialized
INFO - 2023-02-20 06:07:21 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:07:21 --> Final output sent to browser
DEBUG - 2023-02-20 06:07:21 --> Total execution time: 0.0145
INFO - 2023-02-20 06:07:21 --> Final output sent to browser
DEBUG - 2023-02-20 06:07:21 --> Total execution time: 0.6620
INFO - 2023-02-20 06:07:21 --> Config Class Initialized
INFO - 2023-02-20 06:07:21 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:07:21 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:07:21 --> Utf8 Class Initialized
INFO - 2023-02-20 06:07:21 --> URI Class Initialized
INFO - 2023-02-20 06:07:21 --> Router Class Initialized
INFO - 2023-02-20 06:07:21 --> Output Class Initialized
INFO - 2023-02-20 06:07:21 --> Security Class Initialized
DEBUG - 2023-02-20 06:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:07:21 --> Input Class Initialized
INFO - 2023-02-20 06:07:21 --> Language Class Initialized
INFO - 2023-02-20 06:07:21 --> Loader Class Initialized
INFO - 2023-02-20 06:07:21 --> Controller Class Initialized
DEBUG - 2023-02-20 06:07:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:07:21 --> Database Driver Class Initialized
INFO - 2023-02-20 06:07:21 --> Model "Login_model" initialized
INFO - 2023-02-20 06:07:21 --> Database Driver Class Initialized
INFO - 2023-02-20 06:07:21 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:07:22 --> Final output sent to browser
DEBUG - 2023-02-20 06:07:22 --> Total execution time: 0.6630
INFO - 2023-02-20 06:08:27 --> Config Class Initialized
INFO - 2023-02-20 06:08:27 --> Config Class Initialized
INFO - 2023-02-20 06:08:27 --> Hooks Class Initialized
INFO - 2023-02-20 06:08:27 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:08:27 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:08:27 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:08:27 --> Utf8 Class Initialized
INFO - 2023-02-20 06:08:27 --> Utf8 Class Initialized
INFO - 2023-02-20 06:08:27 --> URI Class Initialized
INFO - 2023-02-20 06:08:27 --> URI Class Initialized
INFO - 2023-02-20 06:08:27 --> Router Class Initialized
INFO - 2023-02-20 06:08:27 --> Router Class Initialized
INFO - 2023-02-20 06:08:27 --> Output Class Initialized
INFO - 2023-02-20 06:08:27 --> Output Class Initialized
INFO - 2023-02-20 06:08:27 --> Security Class Initialized
INFO - 2023-02-20 06:08:27 --> Security Class Initialized
DEBUG - 2023-02-20 06:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:08:27 --> Input Class Initialized
INFO - 2023-02-20 06:08:27 --> Input Class Initialized
INFO - 2023-02-20 06:08:27 --> Language Class Initialized
INFO - 2023-02-20 06:08:27 --> Language Class Initialized
INFO - 2023-02-20 06:08:27 --> Loader Class Initialized
INFO - 2023-02-20 06:08:27 --> Loader Class Initialized
INFO - 2023-02-20 06:08:27 --> Controller Class Initialized
INFO - 2023-02-20 06:08:27 --> Controller Class Initialized
DEBUG - 2023-02-20 06:08:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:08:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:08:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:08:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:08:27 --> Model "Login_model" initialized
INFO - 2023-02-20 06:08:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:08:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:08:27 --> Final output sent to browser
DEBUG - 2023-02-20 06:08:27 --> Total execution time: 0.0247
INFO - 2023-02-20 06:08:27 --> Config Class Initialized
INFO - 2023-02-20 06:08:27 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:08:27 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:08:27 --> Utf8 Class Initialized
INFO - 2023-02-20 06:08:27 --> URI Class Initialized
INFO - 2023-02-20 06:08:27 --> Router Class Initialized
INFO - 2023-02-20 06:08:27 --> Output Class Initialized
INFO - 2023-02-20 06:08:27 --> Security Class Initialized
DEBUG - 2023-02-20 06:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:08:27 --> Input Class Initialized
INFO - 2023-02-20 06:08:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:08:27 --> Language Class Initialized
INFO - 2023-02-20 06:08:27 --> Loader Class Initialized
INFO - 2023-02-20 06:08:27 --> Controller Class Initialized
DEBUG - 2023-02-20 06:08:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:08:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:08:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:08:27 --> Final output sent to browser
DEBUG - 2023-02-20 06:08:27 --> Total execution time: 0.0153
INFO - 2023-02-20 06:08:28 --> Final output sent to browser
DEBUG - 2023-02-20 06:08:28 --> Total execution time: 0.6952
INFO - 2023-02-20 06:08:28 --> Config Class Initialized
INFO - 2023-02-20 06:08:28 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:08:28 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:08:28 --> Utf8 Class Initialized
INFO - 2023-02-20 06:08:28 --> URI Class Initialized
INFO - 2023-02-20 06:08:28 --> Router Class Initialized
INFO - 2023-02-20 06:08:28 --> Output Class Initialized
INFO - 2023-02-20 06:08:28 --> Security Class Initialized
DEBUG - 2023-02-20 06:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:08:28 --> Input Class Initialized
INFO - 2023-02-20 06:08:28 --> Language Class Initialized
INFO - 2023-02-20 06:08:28 --> Loader Class Initialized
INFO - 2023-02-20 06:08:28 --> Controller Class Initialized
DEBUG - 2023-02-20 06:08:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:08:28 --> Database Driver Class Initialized
INFO - 2023-02-20 06:08:28 --> Model "Login_model" initialized
INFO - 2023-02-20 06:08:28 --> Database Driver Class Initialized
INFO - 2023-02-20 06:08:28 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:08:29 --> Final output sent to browser
DEBUG - 2023-02-20 06:08:29 --> Total execution time: 0.6799
INFO - 2023-02-20 06:09:23 --> Config Class Initialized
INFO - 2023-02-20 06:09:23 --> Config Class Initialized
INFO - 2023-02-20 06:09:23 --> Hooks Class Initialized
INFO - 2023-02-20 06:09:23 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:09:23 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:09:23 --> Utf8 Class Initialized
DEBUG - 2023-02-20 06:09:23 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:09:23 --> URI Class Initialized
INFO - 2023-02-20 06:09:23 --> Utf8 Class Initialized
INFO - 2023-02-20 06:09:23 --> Router Class Initialized
INFO - 2023-02-20 06:09:23 --> URI Class Initialized
INFO - 2023-02-20 06:09:23 --> Output Class Initialized
INFO - 2023-02-20 06:09:23 --> Router Class Initialized
INFO - 2023-02-20 06:09:23 --> Security Class Initialized
INFO - 2023-02-20 06:09:23 --> Output Class Initialized
INFO - 2023-02-20 06:09:23 --> Security Class Initialized
DEBUG - 2023-02-20 06:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:09:23 --> Input Class Initialized
INFO - 2023-02-20 06:09:23 --> Language Class Initialized
DEBUG - 2023-02-20 06:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:09:23 --> Loader Class Initialized
INFO - 2023-02-20 06:09:23 --> Input Class Initialized
INFO - 2023-02-20 06:09:23 --> Controller Class Initialized
INFO - 2023-02-20 06:09:23 --> Language Class Initialized
DEBUG - 2023-02-20 06:09:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:09:23 --> Loader Class Initialized
INFO - 2023-02-20 06:09:23 --> Database Driver Class Initialized
INFO - 2023-02-20 06:09:23 --> Controller Class Initialized
DEBUG - 2023-02-20 06:09:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:09:23 --> Database Driver Class Initialized
INFO - 2023-02-20 06:09:23 --> Model "Login_model" initialized
INFO - 2023-02-20 06:09:23 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:09:23 --> Database Driver Class Initialized
INFO - 2023-02-20 06:09:23 --> Final output sent to browser
DEBUG - 2023-02-20 06:09:23 --> Total execution time: 0.0177
INFO - 2023-02-20 06:09:23 --> Config Class Initialized
INFO - 2023-02-20 06:09:23 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:09:23 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:09:23 --> Utf8 Class Initialized
INFO - 2023-02-20 06:09:23 --> URI Class Initialized
INFO - 2023-02-20 06:09:23 --> Router Class Initialized
INFO - 2023-02-20 06:09:23 --> Output Class Initialized
INFO - 2023-02-20 06:09:23 --> Security Class Initialized
INFO - 2023-02-20 06:09:23 --> Model "Cluster_model" initialized
DEBUG - 2023-02-20 06:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:09:23 --> Input Class Initialized
INFO - 2023-02-20 06:09:23 --> Language Class Initialized
INFO - 2023-02-20 06:09:23 --> Loader Class Initialized
INFO - 2023-02-20 06:09:23 --> Controller Class Initialized
DEBUG - 2023-02-20 06:09:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:09:23 --> Database Driver Class Initialized
INFO - 2023-02-20 06:09:23 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:09:23 --> Final output sent to browser
DEBUG - 2023-02-20 06:09:23 --> Total execution time: 0.0148
INFO - 2023-02-20 06:09:24 --> Final output sent to browser
DEBUG - 2023-02-20 06:09:24 --> Total execution time: 0.6723
INFO - 2023-02-20 06:09:24 --> Config Class Initialized
INFO - 2023-02-20 06:09:24 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:09:24 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:09:24 --> Utf8 Class Initialized
INFO - 2023-02-20 06:09:24 --> URI Class Initialized
INFO - 2023-02-20 06:09:24 --> Router Class Initialized
INFO - 2023-02-20 06:09:24 --> Output Class Initialized
INFO - 2023-02-20 06:09:24 --> Security Class Initialized
DEBUG - 2023-02-20 06:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:09:24 --> Input Class Initialized
INFO - 2023-02-20 06:09:24 --> Language Class Initialized
INFO - 2023-02-20 06:09:24 --> Loader Class Initialized
INFO - 2023-02-20 06:09:24 --> Controller Class Initialized
DEBUG - 2023-02-20 06:09:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:09:24 --> Database Driver Class Initialized
INFO - 2023-02-20 06:09:24 --> Model "Login_model" initialized
INFO - 2023-02-20 06:09:24 --> Database Driver Class Initialized
INFO - 2023-02-20 06:09:24 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:09:25 --> Final output sent to browser
DEBUG - 2023-02-20 06:09:25 --> Total execution time: 0.6171
INFO - 2023-02-20 06:10:18 --> Config Class Initialized
INFO - 2023-02-20 06:10:18 --> Config Class Initialized
INFO - 2023-02-20 06:10:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:10:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:10:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:10:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:10:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:10:18 --> URI Class Initialized
INFO - 2023-02-20 06:10:18 --> URI Class Initialized
INFO - 2023-02-20 06:10:18 --> Router Class Initialized
INFO - 2023-02-20 06:10:18 --> Router Class Initialized
INFO - 2023-02-20 06:10:18 --> Output Class Initialized
INFO - 2023-02-20 06:10:18 --> Output Class Initialized
INFO - 2023-02-20 06:10:18 --> Security Class Initialized
INFO - 2023-02-20 06:10:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:10:18 --> Input Class Initialized
INFO - 2023-02-20 06:10:18 --> Input Class Initialized
INFO - 2023-02-20 06:10:18 --> Language Class Initialized
INFO - 2023-02-20 06:10:18 --> Language Class Initialized
INFO - 2023-02-20 06:10:18 --> Loader Class Initialized
INFO - 2023-02-20 06:10:18 --> Loader Class Initialized
INFO - 2023-02-20 06:10:18 --> Controller Class Initialized
INFO - 2023-02-20 06:10:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:10:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:10:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:10:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:10:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:10:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:10:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:10:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:10:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:10:18 --> Total execution time: 0.0169
INFO - 2023-02-20 06:10:18 --> Config Class Initialized
INFO - 2023-02-20 06:10:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:10:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:10:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:10:18 --> URI Class Initialized
INFO - 2023-02-20 06:10:18 --> Router Class Initialized
INFO - 2023-02-20 06:10:18 --> Output Class Initialized
INFO - 2023-02-20 06:10:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:10:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:10:18 --> Input Class Initialized
INFO - 2023-02-20 06:10:18 --> Language Class Initialized
INFO - 2023-02-20 06:10:18 --> Loader Class Initialized
INFO - 2023-02-20 06:10:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:10:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:10:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:10:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:10:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:10:18 --> Total execution time: 0.0149
INFO - 2023-02-20 06:10:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:10:18 --> Total execution time: 0.6473
INFO - 2023-02-20 06:10:18 --> Config Class Initialized
INFO - 2023-02-20 06:10:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:10:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:10:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:10:18 --> URI Class Initialized
INFO - 2023-02-20 06:10:18 --> Router Class Initialized
INFO - 2023-02-20 06:10:18 --> Output Class Initialized
INFO - 2023-02-20 06:10:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:10:18 --> Input Class Initialized
INFO - 2023-02-20 06:10:18 --> Language Class Initialized
INFO - 2023-02-20 06:10:18 --> Loader Class Initialized
INFO - 2023-02-20 06:10:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:10:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:10:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:10:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:10:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:10:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:10:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:10:19 --> Total execution time: 0.6389
INFO - 2023-02-20 06:11:19 --> Config Class Initialized
INFO - 2023-02-20 06:11:19 --> Config Class Initialized
INFO - 2023-02-20 06:11:19 --> Hooks Class Initialized
INFO - 2023-02-20 06:11:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:11:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:11:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:11:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:11:19 --> URI Class Initialized
INFO - 2023-02-20 06:11:19 --> URI Class Initialized
INFO - 2023-02-20 06:11:19 --> Router Class Initialized
INFO - 2023-02-20 06:11:19 --> Router Class Initialized
INFO - 2023-02-20 06:11:19 --> Output Class Initialized
INFO - 2023-02-20 06:11:19 --> Output Class Initialized
INFO - 2023-02-20 06:11:19 --> Security Class Initialized
INFO - 2023-02-20 06:11:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:11:19 --> Input Class Initialized
INFO - 2023-02-20 06:11:19 --> Input Class Initialized
INFO - 2023-02-20 06:11:19 --> Language Class Initialized
INFO - 2023-02-20 06:11:19 --> Language Class Initialized
INFO - 2023-02-20 06:11:19 --> Loader Class Initialized
INFO - 2023-02-20 06:11:19 --> Loader Class Initialized
INFO - 2023-02-20 06:11:19 --> Controller Class Initialized
INFO - 2023-02-20 06:11:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:11:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:11:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:11:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:11:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:11:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:11:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:11:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:11:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:11:19 --> Total execution time: 0.0198
INFO - 2023-02-20 06:11:19 --> Config Class Initialized
INFO - 2023-02-20 06:11:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:11:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:11:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:11:19 --> URI Class Initialized
INFO - 2023-02-20 06:11:19 --> Router Class Initialized
INFO - 2023-02-20 06:11:19 --> Output Class Initialized
INFO - 2023-02-20 06:11:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:11:19 --> Input Class Initialized
INFO - 2023-02-20 06:11:19 --> Language Class Initialized
INFO - 2023-02-20 06:11:19 --> Loader Class Initialized
INFO - 2023-02-20 06:11:19 --> Controller Class Initialized
INFO - 2023-02-20 06:11:19 --> Model "Cluster_model" initialized
DEBUG - 2023-02-20 06:11:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:11:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:11:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:11:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:11:19 --> Total execution time: 0.0148
INFO - 2023-02-20 06:11:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:11:19 --> Total execution time: 0.6028
INFO - 2023-02-20 06:11:19 --> Config Class Initialized
INFO - 2023-02-20 06:11:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:11:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:11:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:11:19 --> URI Class Initialized
INFO - 2023-02-20 06:11:19 --> Router Class Initialized
INFO - 2023-02-20 06:11:19 --> Output Class Initialized
INFO - 2023-02-20 06:11:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:11:19 --> Input Class Initialized
INFO - 2023-02-20 06:11:19 --> Language Class Initialized
INFO - 2023-02-20 06:11:19 --> Loader Class Initialized
INFO - 2023-02-20 06:11:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:11:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:11:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:11:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:11:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:11:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:11:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:11:20 --> Total execution time: 0.6442
INFO - 2023-02-20 06:12:18 --> Config Class Initialized
INFO - 2023-02-20 06:12:18 --> Config Class Initialized
INFO - 2023-02-20 06:12:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:12:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:12:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:12:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:12:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:12:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:12:18 --> URI Class Initialized
INFO - 2023-02-20 06:12:18 --> URI Class Initialized
INFO - 2023-02-20 06:12:18 --> Router Class Initialized
INFO - 2023-02-20 06:12:18 --> Router Class Initialized
INFO - 2023-02-20 06:12:18 --> Output Class Initialized
INFO - 2023-02-20 06:12:18 --> Output Class Initialized
INFO - 2023-02-20 06:12:18 --> Security Class Initialized
INFO - 2023-02-20 06:12:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:12:18 --> Input Class Initialized
INFO - 2023-02-20 06:12:18 --> Input Class Initialized
INFO - 2023-02-20 06:12:18 --> Language Class Initialized
INFO - 2023-02-20 06:12:18 --> Language Class Initialized
INFO - 2023-02-20 06:12:18 --> Loader Class Initialized
INFO - 2023-02-20 06:12:18 --> Loader Class Initialized
INFO - 2023-02-20 06:12:18 --> Controller Class Initialized
INFO - 2023-02-20 06:12:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:12:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:12:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:12:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:12:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:12:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:12:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:12:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:12:18 --> Final output sent to browser
INFO - 2023-02-20 06:12:18 --> Model "Cluster_model" initialized
DEBUG - 2023-02-20 06:12:18 --> Total execution time: 0.0726
INFO - 2023-02-20 06:12:18 --> Config Class Initialized
INFO - 2023-02-20 06:12:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:12:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:12:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:12:18 --> URI Class Initialized
INFO - 2023-02-20 06:12:18 --> Router Class Initialized
INFO - 2023-02-20 06:12:18 --> Output Class Initialized
INFO - 2023-02-20 06:12:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:12:18 --> Input Class Initialized
INFO - 2023-02-20 06:12:18 --> Language Class Initialized
INFO - 2023-02-20 06:12:18 --> Loader Class Initialized
INFO - 2023-02-20 06:12:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:12:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:12:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:12:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:12:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:12:18 --> Total execution time: 0.0144
INFO - 2023-02-20 06:12:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:12:19 --> Total execution time: 0.7902
INFO - 2023-02-20 06:12:19 --> Config Class Initialized
INFO - 2023-02-20 06:12:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:12:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:12:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:12:19 --> URI Class Initialized
INFO - 2023-02-20 06:12:19 --> Router Class Initialized
INFO - 2023-02-20 06:12:19 --> Output Class Initialized
INFO - 2023-02-20 06:12:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:12:19 --> Input Class Initialized
INFO - 2023-02-20 06:12:19 --> Language Class Initialized
INFO - 2023-02-20 06:12:19 --> Loader Class Initialized
INFO - 2023-02-20 06:12:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:12:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:12:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:12:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:12:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:12:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:12:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:12:19 --> Total execution time: 0.6243
INFO - 2023-02-20 06:13:18 --> Config Class Initialized
INFO - 2023-02-20 06:13:18 --> Config Class Initialized
INFO - 2023-02-20 06:13:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:13:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:13:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:13:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:13:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:13:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:13:18 --> URI Class Initialized
INFO - 2023-02-20 06:13:18 --> URI Class Initialized
INFO - 2023-02-20 06:13:18 --> Router Class Initialized
INFO - 2023-02-20 06:13:18 --> Router Class Initialized
INFO - 2023-02-20 06:13:18 --> Output Class Initialized
INFO - 2023-02-20 06:13:18 --> Output Class Initialized
INFO - 2023-02-20 06:13:18 --> Security Class Initialized
INFO - 2023-02-20 06:13:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:13:18 --> Input Class Initialized
INFO - 2023-02-20 06:13:18 --> Input Class Initialized
INFO - 2023-02-20 06:13:18 --> Language Class Initialized
INFO - 2023-02-20 06:13:18 --> Language Class Initialized
INFO - 2023-02-20 06:13:18 --> Loader Class Initialized
INFO - 2023-02-20 06:13:18 --> Loader Class Initialized
INFO - 2023-02-20 06:13:18 --> Controller Class Initialized
INFO - 2023-02-20 06:13:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:13:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:13:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:13:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:13:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:13:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:13:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:13:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:13:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:13:18 --> Total execution time: 0.0235
INFO - 2023-02-20 06:13:18 --> Config Class Initialized
INFO - 2023-02-20 06:13:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:13:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:13:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:13:18 --> URI Class Initialized
INFO - 2023-02-20 06:13:18 --> Router Class Initialized
INFO - 2023-02-20 06:13:18 --> Output Class Initialized
INFO - 2023-02-20 06:13:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:13:18 --> Input Class Initialized
INFO - 2023-02-20 06:13:18 --> Language Class Initialized
INFO - 2023-02-20 06:13:18 --> Loader Class Initialized
INFO - 2023-02-20 06:13:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:13:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:13:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:13:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:13:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:13:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:13:18 --> Total execution time: 0.0561
INFO - 2023-02-20 06:13:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:13:19 --> Total execution time: 0.6941
INFO - 2023-02-20 06:13:19 --> Config Class Initialized
INFO - 2023-02-20 06:13:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:13:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:13:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:13:19 --> URI Class Initialized
INFO - 2023-02-20 06:13:19 --> Router Class Initialized
INFO - 2023-02-20 06:13:19 --> Output Class Initialized
INFO - 2023-02-20 06:13:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:13:19 --> Input Class Initialized
INFO - 2023-02-20 06:13:19 --> Language Class Initialized
INFO - 2023-02-20 06:13:19 --> Loader Class Initialized
INFO - 2023-02-20 06:13:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:13:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:13:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:13:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:13:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:13:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:13:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:13:19 --> Total execution time: 0.6463
INFO - 2023-02-20 06:14:43 --> Config Class Initialized
INFO - 2023-02-20 06:14:43 --> Config Class Initialized
INFO - 2023-02-20 06:14:43 --> Hooks Class Initialized
INFO - 2023-02-20 06:14:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:14:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:14:43 --> Utf8 Class Initialized
INFO - 2023-02-20 06:14:43 --> Utf8 Class Initialized
INFO - 2023-02-20 06:14:43 --> URI Class Initialized
INFO - 2023-02-20 06:14:43 --> URI Class Initialized
INFO - 2023-02-20 06:14:43 --> Router Class Initialized
INFO - 2023-02-20 06:14:43 --> Router Class Initialized
INFO - 2023-02-20 06:14:43 --> Output Class Initialized
INFO - 2023-02-20 06:14:43 --> Output Class Initialized
INFO - 2023-02-20 06:14:43 --> Security Class Initialized
INFO - 2023-02-20 06:14:43 --> Security Class Initialized
DEBUG - 2023-02-20 06:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:14:43 --> Input Class Initialized
INFO - 2023-02-20 06:14:43 --> Input Class Initialized
INFO - 2023-02-20 06:14:43 --> Language Class Initialized
INFO - 2023-02-20 06:14:43 --> Language Class Initialized
INFO - 2023-02-20 06:14:43 --> Loader Class Initialized
INFO - 2023-02-20 06:14:43 --> Loader Class Initialized
INFO - 2023-02-20 06:14:43 --> Controller Class Initialized
INFO - 2023-02-20 06:14:43 --> Controller Class Initialized
DEBUG - 2023-02-20 06:14:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:14:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:14:43 --> Database Driver Class Initialized
INFO - 2023-02-20 06:14:43 --> Database Driver Class Initialized
INFO - 2023-02-20 06:14:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:14:43 --> Model "Login_model" initialized
INFO - 2023-02-20 06:14:43 --> Database Driver Class Initialized
INFO - 2023-02-20 06:14:43 --> Final output sent to browser
DEBUG - 2023-02-20 06:14:43 --> Total execution time: 0.0213
INFO - 2023-02-20 06:14:43 --> Config Class Initialized
INFO - 2023-02-20 06:14:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:14:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:14:43 --> Utf8 Class Initialized
INFO - 2023-02-20 06:14:43 --> URI Class Initialized
INFO - 2023-02-20 06:14:43 --> Router Class Initialized
INFO - 2023-02-20 06:14:43 --> Output Class Initialized
INFO - 2023-02-20 06:14:43 --> Security Class Initialized
DEBUG - 2023-02-20 06:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:14:43 --> Input Class Initialized
INFO - 2023-02-20 06:14:43 --> Language Class Initialized
INFO - 2023-02-20 06:14:43 --> Loader Class Initialized
INFO - 2023-02-20 06:14:43 --> Controller Class Initialized
DEBUG - 2023-02-20 06:14:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:14:43 --> Database Driver Class Initialized
INFO - 2023-02-20 06:14:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:14:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:14:43 --> Final output sent to browser
DEBUG - 2023-02-20 06:14:43 --> Total execution time: 0.0241
INFO - 2023-02-20 06:14:44 --> Final output sent to browser
DEBUG - 2023-02-20 06:14:44 --> Total execution time: 0.7690
INFO - 2023-02-20 06:14:44 --> Config Class Initialized
INFO - 2023-02-20 06:14:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:14:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:14:44 --> Utf8 Class Initialized
INFO - 2023-02-20 06:14:44 --> URI Class Initialized
INFO - 2023-02-20 06:14:44 --> Router Class Initialized
INFO - 2023-02-20 06:14:44 --> Output Class Initialized
INFO - 2023-02-20 06:14:44 --> Security Class Initialized
DEBUG - 2023-02-20 06:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:14:44 --> Input Class Initialized
INFO - 2023-02-20 06:14:44 --> Language Class Initialized
INFO - 2023-02-20 06:14:44 --> Loader Class Initialized
INFO - 2023-02-20 06:14:44 --> Controller Class Initialized
DEBUG - 2023-02-20 06:14:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:14:44 --> Database Driver Class Initialized
INFO - 2023-02-20 06:14:44 --> Model "Login_model" initialized
INFO - 2023-02-20 06:14:44 --> Database Driver Class Initialized
INFO - 2023-02-20 06:14:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:14:45 --> Final output sent to browser
DEBUG - 2023-02-20 06:14:45 --> Total execution time: 0.7316
INFO - 2023-02-20 06:15:18 --> Config Class Initialized
INFO - 2023-02-20 06:15:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:15:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:15:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:15:18 --> URI Class Initialized
INFO - 2023-02-20 06:15:18 --> Router Class Initialized
INFO - 2023-02-20 06:15:18 --> Output Class Initialized
INFO - 2023-02-20 06:15:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:15:18 --> Input Class Initialized
INFO - 2023-02-20 06:15:18 --> Language Class Initialized
INFO - 2023-02-20 06:15:18 --> Loader Class Initialized
INFO - 2023-02-20 06:15:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:15:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:15:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:15:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:15:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:15:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:15:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:15:19 --> Total execution time: 0.6952
INFO - 2023-02-20 06:15:19 --> Config Class Initialized
INFO - 2023-02-20 06:15:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:15:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:15:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:15:19 --> URI Class Initialized
INFO - 2023-02-20 06:15:19 --> Router Class Initialized
INFO - 2023-02-20 06:15:19 --> Output Class Initialized
INFO - 2023-02-20 06:15:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:15:19 --> Input Class Initialized
INFO - 2023-02-20 06:15:19 --> Language Class Initialized
INFO - 2023-02-20 06:15:19 --> Loader Class Initialized
INFO - 2023-02-20 06:15:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:15:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:15:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:15:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:15:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:15:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:15:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:15:19 --> Total execution time: 0.6335
INFO - 2023-02-20 06:16:18 --> Config Class Initialized
INFO - 2023-02-20 06:16:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:16:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:16:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:16:18 --> URI Class Initialized
INFO - 2023-02-20 06:16:18 --> Router Class Initialized
INFO - 2023-02-20 06:16:18 --> Output Class Initialized
INFO - 2023-02-20 06:16:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:16:18 --> Input Class Initialized
INFO - 2023-02-20 06:16:18 --> Language Class Initialized
INFO - 2023-02-20 06:16:18 --> Loader Class Initialized
INFO - 2023-02-20 06:16:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:16:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:16:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:16:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:16:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:16:18 --> Total execution time: 0.0187
INFO - 2023-02-20 06:16:18 --> Config Class Initialized
INFO - 2023-02-20 06:16:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:16:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:16:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:16:18 --> URI Class Initialized
INFO - 2023-02-20 06:16:18 --> Router Class Initialized
INFO - 2023-02-20 06:16:18 --> Output Class Initialized
INFO - 2023-02-20 06:16:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:16:18 --> Input Class Initialized
INFO - 2023-02-20 06:16:18 --> Language Class Initialized
INFO - 2023-02-20 06:16:18 --> Loader Class Initialized
INFO - 2023-02-20 06:16:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:16:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:16:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:16:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:16:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:16:18 --> Total execution time: 0.0152
INFO - 2023-02-20 06:17:18 --> Config Class Initialized
INFO - 2023-02-20 06:17:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:17:18 --> Config Class Initialized
INFO - 2023-02-20 06:17:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:17:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:17:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:17:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:17:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:17:18 --> URI Class Initialized
INFO - 2023-02-20 06:17:18 --> URI Class Initialized
INFO - 2023-02-20 06:17:18 --> Router Class Initialized
INFO - 2023-02-20 06:17:18 --> Router Class Initialized
INFO - 2023-02-20 06:17:18 --> Output Class Initialized
INFO - 2023-02-20 06:17:18 --> Output Class Initialized
INFO - 2023-02-20 06:17:18 --> Security Class Initialized
INFO - 2023-02-20 06:17:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:17:18 --> Input Class Initialized
INFO - 2023-02-20 06:17:18 --> Input Class Initialized
INFO - 2023-02-20 06:17:18 --> Language Class Initialized
INFO - 2023-02-20 06:17:18 --> Language Class Initialized
INFO - 2023-02-20 06:17:18 --> Loader Class Initialized
INFO - 2023-02-20 06:17:18 --> Loader Class Initialized
INFO - 2023-02-20 06:17:18 --> Controller Class Initialized
INFO - 2023-02-20 06:17:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:17:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:17:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:17:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:17:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:17:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:17:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:17:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:17:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:17:18 --> Total execution time: 0.0231
INFO - 2023-02-20 06:17:18 --> Config Class Initialized
INFO - 2023-02-20 06:17:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:17:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:17:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:17:18 --> URI Class Initialized
INFO - 2023-02-20 06:17:18 --> Router Class Initialized
INFO - 2023-02-20 06:17:18 --> Output Class Initialized
INFO - 2023-02-20 06:17:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:17:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:17:18 --> Input Class Initialized
INFO - 2023-02-20 06:17:18 --> Language Class Initialized
INFO - 2023-02-20 06:17:18 --> Loader Class Initialized
INFO - 2023-02-20 06:17:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:17:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:17:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:17:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:17:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:17:18 --> Total execution time: 0.0200
INFO - 2023-02-20 06:17:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:17:19 --> Total execution time: 0.7327
INFO - 2023-02-20 06:17:19 --> Config Class Initialized
INFO - 2023-02-20 06:17:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:17:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:17:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:17:19 --> URI Class Initialized
INFO - 2023-02-20 06:17:19 --> Router Class Initialized
INFO - 2023-02-20 06:17:19 --> Output Class Initialized
INFO - 2023-02-20 06:17:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:17:19 --> Input Class Initialized
INFO - 2023-02-20 06:17:19 --> Language Class Initialized
INFO - 2023-02-20 06:17:19 --> Loader Class Initialized
INFO - 2023-02-20 06:17:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:17:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:17:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:17:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:17:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:17:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:17:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:17:19 --> Total execution time: 0.6891
INFO - 2023-02-20 06:18:18 --> Config Class Initialized
INFO - 2023-02-20 06:18:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:18:18 --> Config Class Initialized
INFO - 2023-02-20 06:18:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:18:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:18:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:18:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:18:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:18:18 --> URI Class Initialized
INFO - 2023-02-20 06:18:18 --> URI Class Initialized
INFO - 2023-02-20 06:18:18 --> Router Class Initialized
INFO - 2023-02-20 06:18:18 --> Router Class Initialized
INFO - 2023-02-20 06:18:18 --> Output Class Initialized
INFO - 2023-02-20 06:18:18 --> Output Class Initialized
INFO - 2023-02-20 06:18:18 --> Security Class Initialized
INFO - 2023-02-20 06:18:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:18:18 --> Input Class Initialized
INFO - 2023-02-20 06:18:18 --> Input Class Initialized
INFO - 2023-02-20 06:18:18 --> Language Class Initialized
INFO - 2023-02-20 06:18:18 --> Language Class Initialized
INFO - 2023-02-20 06:18:18 --> Loader Class Initialized
INFO - 2023-02-20 06:18:18 --> Loader Class Initialized
INFO - 2023-02-20 06:18:18 --> Controller Class Initialized
INFO - 2023-02-20 06:18:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:18:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:18:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:18:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:18:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:18:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:18:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:18:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:18:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:18:18 --> Total execution time: 0.0254
INFO - 2023-02-20 06:18:18 --> Config Class Initialized
INFO - 2023-02-20 06:18:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:18:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:18:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:18:18 --> URI Class Initialized
INFO - 2023-02-20 06:18:18 --> Router Class Initialized
INFO - 2023-02-20 06:18:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:18:18 --> Output Class Initialized
INFO - 2023-02-20 06:18:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:18:18 --> Input Class Initialized
INFO - 2023-02-20 06:18:18 --> Language Class Initialized
INFO - 2023-02-20 06:18:18 --> Loader Class Initialized
INFO - 2023-02-20 06:18:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:18:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:18:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:18:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:18:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:18:18 --> Total execution time: 0.0199
INFO - 2023-02-20 06:18:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:18:18 --> Total execution time: 0.6373
INFO - 2023-02-20 06:18:18 --> Config Class Initialized
INFO - 2023-02-20 06:18:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:18:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:18:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:18:18 --> URI Class Initialized
INFO - 2023-02-20 06:18:18 --> Router Class Initialized
INFO - 2023-02-20 06:18:18 --> Output Class Initialized
INFO - 2023-02-20 06:18:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:18:18 --> Input Class Initialized
INFO - 2023-02-20 06:18:18 --> Language Class Initialized
INFO - 2023-02-20 06:18:18 --> Loader Class Initialized
INFO - 2023-02-20 06:18:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:18:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:18:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:18:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:18:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:18:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:18:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:18:19 --> Total execution time: 0.6157
INFO - 2023-02-20 06:19:18 --> Config Class Initialized
INFO - 2023-02-20 06:19:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:19:18 --> Config Class Initialized
INFO - 2023-02-20 06:19:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:19:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:19:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:19:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:19:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:19:18 --> URI Class Initialized
INFO - 2023-02-20 06:19:18 --> URI Class Initialized
INFO - 2023-02-20 06:19:18 --> Router Class Initialized
INFO - 2023-02-20 06:19:18 --> Router Class Initialized
INFO - 2023-02-20 06:19:18 --> Output Class Initialized
INFO - 2023-02-20 06:19:18 --> Output Class Initialized
INFO - 2023-02-20 06:19:18 --> Security Class Initialized
INFO - 2023-02-20 06:19:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:19:18 --> Input Class Initialized
INFO - 2023-02-20 06:19:18 --> Input Class Initialized
INFO - 2023-02-20 06:19:18 --> Language Class Initialized
INFO - 2023-02-20 06:19:18 --> Language Class Initialized
INFO - 2023-02-20 06:19:18 --> Loader Class Initialized
INFO - 2023-02-20 06:19:18 --> Loader Class Initialized
INFO - 2023-02-20 06:19:18 --> Controller Class Initialized
INFO - 2023-02-20 06:19:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:19:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:19:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:19:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:19:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:19:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:19:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:19:18 --> Total execution time: 0.0197
INFO - 2023-02-20 06:19:18 --> Config Class Initialized
INFO - 2023-02-20 06:19:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:19:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:19:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:19:18 --> URI Class Initialized
INFO - 2023-02-20 06:19:18 --> Router Class Initialized
INFO - 2023-02-20 06:19:18 --> Output Class Initialized
INFO - 2023-02-20 06:19:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:19:18 --> Input Class Initialized
INFO - 2023-02-20 06:19:18 --> Language Class Initialized
INFO - 2023-02-20 06:19:18 --> Loader Class Initialized
INFO - 2023-02-20 06:19:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:19:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:19:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:19:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:19:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:19:18 --> Total execution time: 0.0131
INFO - 2023-02-20 06:19:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:19:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:19:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:19:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:19:19 --> Total execution time: 0.7387
INFO - 2023-02-20 06:19:19 --> Config Class Initialized
INFO - 2023-02-20 06:19:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:19:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:19:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:19:19 --> URI Class Initialized
INFO - 2023-02-20 06:19:19 --> Router Class Initialized
INFO - 2023-02-20 06:19:19 --> Output Class Initialized
INFO - 2023-02-20 06:19:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:19:19 --> Input Class Initialized
INFO - 2023-02-20 06:19:19 --> Language Class Initialized
INFO - 2023-02-20 06:19:19 --> Loader Class Initialized
INFO - 2023-02-20 06:19:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:19:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:19:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:19:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:19:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:19:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:19:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:19:19 --> Total execution time: 0.6802
INFO - 2023-02-20 06:20:18 --> Config Class Initialized
INFO - 2023-02-20 06:20:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:20:18 --> Config Class Initialized
DEBUG - 2023-02-20 06:20:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:20:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:20:18 --> Utf8 Class Initialized
DEBUG - 2023-02-20 06:20:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:20:18 --> URI Class Initialized
INFO - 2023-02-20 06:20:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:20:18 --> Router Class Initialized
INFO - 2023-02-20 06:20:18 --> URI Class Initialized
INFO - 2023-02-20 06:20:18 --> Output Class Initialized
INFO - 2023-02-20 06:20:18 --> Router Class Initialized
INFO - 2023-02-20 06:20:18 --> Security Class Initialized
INFO - 2023-02-20 06:20:18 --> Output Class Initialized
DEBUG - 2023-02-20 06:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:20:18 --> Security Class Initialized
INFO - 2023-02-20 06:20:18 --> Input Class Initialized
DEBUG - 2023-02-20 06:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:20:18 --> Language Class Initialized
INFO - 2023-02-20 06:20:18 --> Input Class Initialized
INFO - 2023-02-20 06:20:18 --> Language Class Initialized
INFO - 2023-02-20 06:20:18 --> Loader Class Initialized
INFO - 2023-02-20 06:20:18 --> Loader Class Initialized
INFO - 2023-02-20 06:20:18 --> Controller Class Initialized
INFO - 2023-02-20 06:20:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:20:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:20:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:20:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:20:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:20:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:20:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:20:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:20:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:20:18 --> Total execution time: 0.0179
INFO - 2023-02-20 06:20:18 --> Config Class Initialized
INFO - 2023-02-20 06:20:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:20:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:20:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:20:18 --> URI Class Initialized
INFO - 2023-02-20 06:20:18 --> Router Class Initialized
INFO - 2023-02-20 06:20:18 --> Output Class Initialized
INFO - 2023-02-20 06:20:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:20:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:20:18 --> Input Class Initialized
INFO - 2023-02-20 06:20:18 --> Language Class Initialized
INFO - 2023-02-20 06:20:18 --> Loader Class Initialized
INFO - 2023-02-20 06:20:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:20:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:20:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:20:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:20:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:20:18 --> Total execution time: 0.0142
INFO - 2023-02-20 06:20:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:20:19 --> Total execution time: 0.7064
INFO - 2023-02-20 06:20:19 --> Config Class Initialized
INFO - 2023-02-20 06:20:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:20:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:20:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:20:19 --> URI Class Initialized
INFO - 2023-02-20 06:20:19 --> Router Class Initialized
INFO - 2023-02-20 06:20:19 --> Output Class Initialized
INFO - 2023-02-20 06:20:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:20:19 --> Input Class Initialized
INFO - 2023-02-20 06:20:19 --> Language Class Initialized
INFO - 2023-02-20 06:20:19 --> Loader Class Initialized
INFO - 2023-02-20 06:20:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:20:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:20:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:20:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:20:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:20:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:20:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:20:19 --> Total execution time: 0.7305
INFO - 2023-02-20 06:21:18 --> Config Class Initialized
INFO - 2023-02-20 06:21:18 --> Config Class Initialized
INFO - 2023-02-20 06:21:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:21:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:21:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:21:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:21:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:21:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:21:18 --> URI Class Initialized
INFO - 2023-02-20 06:21:18 --> URI Class Initialized
INFO - 2023-02-20 06:21:18 --> Router Class Initialized
INFO - 2023-02-20 06:21:18 --> Router Class Initialized
INFO - 2023-02-20 06:21:18 --> Output Class Initialized
INFO - 2023-02-20 06:21:18 --> Output Class Initialized
INFO - 2023-02-20 06:21:18 --> Security Class Initialized
INFO - 2023-02-20 06:21:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:21:18 --> Input Class Initialized
INFO - 2023-02-20 06:21:18 --> Input Class Initialized
INFO - 2023-02-20 06:21:18 --> Language Class Initialized
INFO - 2023-02-20 06:21:18 --> Language Class Initialized
INFO - 2023-02-20 06:21:18 --> Loader Class Initialized
INFO - 2023-02-20 06:21:18 --> Loader Class Initialized
INFO - 2023-02-20 06:21:18 --> Controller Class Initialized
INFO - 2023-02-20 06:21:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:21:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:21:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:21:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:21:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:21:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:21:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:21:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:21:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:21:18 --> Total execution time: 0.0201
INFO - 2023-02-20 06:21:18 --> Config Class Initialized
INFO - 2023-02-20 06:21:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:21:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:21:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:21:18 --> URI Class Initialized
INFO - 2023-02-20 06:21:18 --> Router Class Initialized
INFO - 2023-02-20 06:21:18 --> Output Class Initialized
INFO - 2023-02-20 06:21:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:21:18 --> Input Class Initialized
INFO - 2023-02-20 06:21:18 --> Language Class Initialized
INFO - 2023-02-20 06:21:18 --> Loader Class Initialized
INFO - 2023-02-20 06:21:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:21:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:21:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:21:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:21:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:21:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:21:18 --> Total execution time: 0.0168
INFO - 2023-02-20 06:21:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:21:18 --> Total execution time: 0.6297
INFO - 2023-02-20 06:21:18 --> Config Class Initialized
INFO - 2023-02-20 06:21:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:21:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:21:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:21:18 --> URI Class Initialized
INFO - 2023-02-20 06:21:18 --> Router Class Initialized
INFO - 2023-02-20 06:21:18 --> Output Class Initialized
INFO - 2023-02-20 06:21:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:21:18 --> Input Class Initialized
INFO - 2023-02-20 06:21:18 --> Language Class Initialized
INFO - 2023-02-20 06:21:18 --> Loader Class Initialized
INFO - 2023-02-20 06:21:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:21:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:21:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:21:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:21:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:21:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:21:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:21:19 --> Total execution time: 0.6409
INFO - 2023-02-20 06:22:18 --> Config Class Initialized
INFO - 2023-02-20 06:22:18 --> Config Class Initialized
INFO - 2023-02-20 06:22:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:22:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:22:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:22:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:22:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:22:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:22:18 --> URI Class Initialized
INFO - 2023-02-20 06:22:18 --> URI Class Initialized
INFO - 2023-02-20 06:22:18 --> Router Class Initialized
INFO - 2023-02-20 06:22:18 --> Router Class Initialized
INFO - 2023-02-20 06:22:18 --> Output Class Initialized
INFO - 2023-02-20 06:22:18 --> Output Class Initialized
INFO - 2023-02-20 06:22:18 --> Security Class Initialized
INFO - 2023-02-20 06:22:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:22:18 --> Input Class Initialized
INFO - 2023-02-20 06:22:18 --> Input Class Initialized
INFO - 2023-02-20 06:22:18 --> Language Class Initialized
INFO - 2023-02-20 06:22:18 --> Language Class Initialized
INFO - 2023-02-20 06:22:18 --> Loader Class Initialized
INFO - 2023-02-20 06:22:18 --> Loader Class Initialized
INFO - 2023-02-20 06:22:18 --> Controller Class Initialized
INFO - 2023-02-20 06:22:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:22:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:22:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:22:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:22:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:22:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:22:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:22:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:22:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:22:18 --> Total execution time: 0.0648
INFO - 2023-02-20 06:22:18 --> Config Class Initialized
INFO - 2023-02-20 06:22:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:22:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:22:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:22:18 --> URI Class Initialized
INFO - 2023-02-20 06:22:18 --> Router Class Initialized
INFO - 2023-02-20 06:22:18 --> Output Class Initialized
INFO - 2023-02-20 06:22:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:22:18 --> Input Class Initialized
INFO - 2023-02-20 06:22:18 --> Language Class Initialized
INFO - 2023-02-20 06:22:18 --> Loader Class Initialized
INFO - 2023-02-20 06:22:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:22:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:22:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:22:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:22:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:22:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:22:18 --> Total execution time: 0.0222
INFO - 2023-02-20 06:22:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:22:19 --> Total execution time: 0.9007
INFO - 2023-02-20 06:22:19 --> Config Class Initialized
INFO - 2023-02-20 06:22:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:22:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:22:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:22:19 --> URI Class Initialized
INFO - 2023-02-20 06:22:19 --> Router Class Initialized
INFO - 2023-02-20 06:22:19 --> Output Class Initialized
INFO - 2023-02-20 06:22:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:22:19 --> Input Class Initialized
INFO - 2023-02-20 06:22:19 --> Language Class Initialized
INFO - 2023-02-20 06:22:19 --> Loader Class Initialized
INFO - 2023-02-20 06:22:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:22:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:22:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:22:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:22:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:22:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:22:20 --> Total execution time: 0.9086
INFO - 2023-02-20 06:23:18 --> Config Class Initialized
INFO - 2023-02-20 06:23:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:23:18 --> Config Class Initialized
DEBUG - 2023-02-20 06:23:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:23:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:23:18 --> Utf8 Class Initialized
DEBUG - 2023-02-20 06:23:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:23:18 --> URI Class Initialized
INFO - 2023-02-20 06:23:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:23:18 --> Router Class Initialized
INFO - 2023-02-20 06:23:18 --> URI Class Initialized
INFO - 2023-02-20 06:23:18 --> Output Class Initialized
INFO - 2023-02-20 06:23:18 --> Router Class Initialized
INFO - 2023-02-20 06:23:18 --> Security Class Initialized
INFO - 2023-02-20 06:23:18 --> Output Class Initialized
DEBUG - 2023-02-20 06:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:23:18 --> Security Class Initialized
INFO - 2023-02-20 06:23:18 --> Input Class Initialized
DEBUG - 2023-02-20 06:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:23:18 --> Language Class Initialized
INFO - 2023-02-20 06:23:18 --> Input Class Initialized
INFO - 2023-02-20 06:23:18 --> Language Class Initialized
INFO - 2023-02-20 06:23:18 --> Loader Class Initialized
INFO - 2023-02-20 06:23:18 --> Loader Class Initialized
INFO - 2023-02-20 06:23:18 --> Controller Class Initialized
INFO - 2023-02-20 06:23:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:23:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:23:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:23:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:23:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:23:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:23:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:23:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:23:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:23:18 --> Total execution time: 0.0191
INFO - 2023-02-20 06:23:18 --> Config Class Initialized
INFO - 2023-02-20 06:23:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:23:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:23:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:23:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:23:18 --> URI Class Initialized
INFO - 2023-02-20 06:23:18 --> Router Class Initialized
INFO - 2023-02-20 06:23:18 --> Output Class Initialized
INFO - 2023-02-20 06:23:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:23:18 --> Input Class Initialized
INFO - 2023-02-20 06:23:18 --> Language Class Initialized
INFO - 2023-02-20 06:23:18 --> Loader Class Initialized
INFO - 2023-02-20 06:23:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:23:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:23:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:23:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:23:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:23:18 --> Total execution time: 0.0654
INFO - 2023-02-20 06:23:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:23:19 --> Total execution time: 0.7525
INFO - 2023-02-20 06:23:19 --> Config Class Initialized
INFO - 2023-02-20 06:23:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:23:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:23:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:23:19 --> URI Class Initialized
INFO - 2023-02-20 06:23:19 --> Router Class Initialized
INFO - 2023-02-20 06:23:19 --> Output Class Initialized
INFO - 2023-02-20 06:23:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:23:19 --> Input Class Initialized
INFO - 2023-02-20 06:23:19 --> Language Class Initialized
INFO - 2023-02-20 06:23:19 --> Loader Class Initialized
INFO - 2023-02-20 06:23:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:23:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:23:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:23:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:23:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:23:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:23:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:23:19 --> Total execution time: 0.7979
INFO - 2023-02-20 06:24:18 --> Config Class Initialized
INFO - 2023-02-20 06:24:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:24:18 --> Config Class Initialized
INFO - 2023-02-20 06:24:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:24:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:24:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:24:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:24:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:24:18 --> URI Class Initialized
INFO - 2023-02-20 06:24:18 --> URI Class Initialized
INFO - 2023-02-20 06:24:18 --> Router Class Initialized
INFO - 2023-02-20 06:24:18 --> Router Class Initialized
INFO - 2023-02-20 06:24:18 --> Output Class Initialized
INFO - 2023-02-20 06:24:18 --> Output Class Initialized
INFO - 2023-02-20 06:24:18 --> Security Class Initialized
INFO - 2023-02-20 06:24:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:24:18 --> Input Class Initialized
INFO - 2023-02-20 06:24:18 --> Input Class Initialized
INFO - 2023-02-20 06:24:18 --> Language Class Initialized
INFO - 2023-02-20 06:24:18 --> Language Class Initialized
INFO - 2023-02-20 06:24:18 --> Loader Class Initialized
INFO - 2023-02-20 06:24:18 --> Loader Class Initialized
INFO - 2023-02-20 06:24:18 --> Controller Class Initialized
INFO - 2023-02-20 06:24:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:24:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:24:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:24:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:24:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:24:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:24:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:24:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:24:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:24:18 --> Total execution time: 0.0201
INFO - 2023-02-20 06:24:18 --> Config Class Initialized
INFO - 2023-02-20 06:24:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:24:18 --> Model "Cluster_model" initialized
DEBUG - 2023-02-20 06:24:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:24:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:24:18 --> URI Class Initialized
INFO - 2023-02-20 06:24:18 --> Router Class Initialized
INFO - 2023-02-20 06:24:18 --> Output Class Initialized
INFO - 2023-02-20 06:24:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:24:18 --> Input Class Initialized
INFO - 2023-02-20 06:24:18 --> Language Class Initialized
INFO - 2023-02-20 06:24:18 --> Loader Class Initialized
INFO - 2023-02-20 06:24:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:24:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:24:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:24:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:24:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:24:18 --> Total execution time: 0.0143
INFO - 2023-02-20 06:24:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:24:19 --> Total execution time: 0.7062
INFO - 2023-02-20 06:24:19 --> Config Class Initialized
INFO - 2023-02-20 06:24:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:24:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:24:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:24:19 --> URI Class Initialized
INFO - 2023-02-20 06:24:19 --> Router Class Initialized
INFO - 2023-02-20 06:24:19 --> Output Class Initialized
INFO - 2023-02-20 06:24:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:24:19 --> Input Class Initialized
INFO - 2023-02-20 06:24:19 --> Language Class Initialized
INFO - 2023-02-20 06:24:19 --> Loader Class Initialized
INFO - 2023-02-20 06:24:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:24:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:24:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:24:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:24:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:24:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:24:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:24:19 --> Total execution time: 0.7396
INFO - 2023-02-20 06:25:19 --> Config Class Initialized
INFO - 2023-02-20 06:25:19 --> Config Class Initialized
INFO - 2023-02-20 06:25:19 --> Hooks Class Initialized
INFO - 2023-02-20 06:25:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:25:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:25:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:25:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:25:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:25:19 --> URI Class Initialized
INFO - 2023-02-20 06:25:19 --> URI Class Initialized
INFO - 2023-02-20 06:25:19 --> Router Class Initialized
INFO - 2023-02-20 06:25:19 --> Router Class Initialized
INFO - 2023-02-20 06:25:19 --> Output Class Initialized
INFO - 2023-02-20 06:25:19 --> Output Class Initialized
INFO - 2023-02-20 06:25:19 --> Security Class Initialized
INFO - 2023-02-20 06:25:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:25:19 --> Input Class Initialized
INFO - 2023-02-20 06:25:19 --> Input Class Initialized
INFO - 2023-02-20 06:25:19 --> Language Class Initialized
INFO - 2023-02-20 06:25:19 --> Language Class Initialized
INFO - 2023-02-20 06:25:19 --> Loader Class Initialized
INFO - 2023-02-20 06:25:19 --> Loader Class Initialized
INFO - 2023-02-20 06:25:19 --> Controller Class Initialized
INFO - 2023-02-20 06:25:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:25:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:25:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:25:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:25:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:25:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:25:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:25:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:25:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:25:19 --> Total execution time: 0.0269
INFO - 2023-02-20 06:25:19 --> Config Class Initialized
INFO - 2023-02-20 06:25:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:25:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:25:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:25:19 --> URI Class Initialized
INFO - 2023-02-20 06:25:19 --> Router Class Initialized
INFO - 2023-02-20 06:25:19 --> Output Class Initialized
INFO - 2023-02-20 06:25:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:25:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:25:19 --> Input Class Initialized
INFO - 2023-02-20 06:25:19 --> Language Class Initialized
INFO - 2023-02-20 06:25:19 --> Loader Class Initialized
INFO - 2023-02-20 06:25:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:25:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:25:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:25:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:25:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:25:19 --> Total execution time: 0.0154
INFO - 2023-02-20 06:25:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:25:20 --> Total execution time: 0.6806
INFO - 2023-02-20 06:25:20 --> Config Class Initialized
INFO - 2023-02-20 06:25:20 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:25:20 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:25:20 --> Utf8 Class Initialized
INFO - 2023-02-20 06:25:20 --> URI Class Initialized
INFO - 2023-02-20 06:25:20 --> Router Class Initialized
INFO - 2023-02-20 06:25:20 --> Output Class Initialized
INFO - 2023-02-20 06:25:20 --> Security Class Initialized
DEBUG - 2023-02-20 06:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:25:20 --> Input Class Initialized
INFO - 2023-02-20 06:25:20 --> Language Class Initialized
INFO - 2023-02-20 06:25:20 --> Loader Class Initialized
INFO - 2023-02-20 06:25:20 --> Controller Class Initialized
DEBUG - 2023-02-20 06:25:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:25:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:25:20 --> Model "Login_model" initialized
INFO - 2023-02-20 06:25:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:25:20 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:25:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:25:20 --> Total execution time: 0.5975
INFO - 2023-02-20 06:26:19 --> Config Class Initialized
INFO - 2023-02-20 06:26:19 --> Config Class Initialized
INFO - 2023-02-20 06:26:19 --> Hooks Class Initialized
INFO - 2023-02-20 06:26:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:26:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:26:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:26:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:26:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:26:19 --> URI Class Initialized
INFO - 2023-02-20 06:26:19 --> URI Class Initialized
INFO - 2023-02-20 06:26:19 --> Router Class Initialized
INFO - 2023-02-20 06:26:19 --> Router Class Initialized
INFO - 2023-02-20 06:26:19 --> Output Class Initialized
INFO - 2023-02-20 06:26:19 --> Output Class Initialized
INFO - 2023-02-20 06:26:19 --> Security Class Initialized
INFO - 2023-02-20 06:26:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:26:19 --> Input Class Initialized
INFO - 2023-02-20 06:26:19 --> Input Class Initialized
INFO - 2023-02-20 06:26:19 --> Language Class Initialized
INFO - 2023-02-20 06:26:19 --> Language Class Initialized
INFO - 2023-02-20 06:26:19 --> Loader Class Initialized
INFO - 2023-02-20 06:26:19 --> Loader Class Initialized
INFO - 2023-02-20 06:26:19 --> Controller Class Initialized
INFO - 2023-02-20 06:26:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:26:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:26:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:26:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:26:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:26:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:26:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:26:19 --> Total execution time: 0.0190
INFO - 2023-02-20 06:26:19 --> Config Class Initialized
INFO - 2023-02-20 06:26:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:26:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:26:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:26:19 --> URI Class Initialized
INFO - 2023-02-20 06:26:19 --> Router Class Initialized
INFO - 2023-02-20 06:26:19 --> Output Class Initialized
INFO - 2023-02-20 06:26:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:26:19 --> Input Class Initialized
INFO - 2023-02-20 06:26:19 --> Language Class Initialized
INFO - 2023-02-20 06:26:19 --> Loader Class Initialized
INFO - 2023-02-20 06:26:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:26:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:26:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:26:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:26:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:26:19 --> Total execution time: 0.0134
INFO - 2023-02-20 06:26:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:26:20 --> Total execution time: 0.6813
INFO - 2023-02-20 06:26:20 --> Config Class Initialized
INFO - 2023-02-20 06:26:20 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:26:20 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:26:20 --> Utf8 Class Initialized
INFO - 2023-02-20 06:26:20 --> URI Class Initialized
INFO - 2023-02-20 06:26:20 --> Router Class Initialized
INFO - 2023-02-20 06:26:20 --> Output Class Initialized
INFO - 2023-02-20 06:26:20 --> Security Class Initialized
DEBUG - 2023-02-20 06:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:26:20 --> Input Class Initialized
INFO - 2023-02-20 06:26:20 --> Language Class Initialized
INFO - 2023-02-20 06:26:20 --> Loader Class Initialized
INFO - 2023-02-20 06:26:20 --> Controller Class Initialized
DEBUG - 2023-02-20 06:26:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:26:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:26:20 --> Model "Login_model" initialized
INFO - 2023-02-20 06:26:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:26:20 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:26:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:26:20 --> Total execution time: 0.6981
INFO - 2023-02-20 06:27:18 --> Config Class Initialized
INFO - 2023-02-20 06:27:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:27:18 --> Config Class Initialized
INFO - 2023-02-20 06:27:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:27:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:27:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:27:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:27:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:27:18 --> URI Class Initialized
INFO - 2023-02-20 06:27:18 --> URI Class Initialized
INFO - 2023-02-20 06:27:18 --> Router Class Initialized
INFO - 2023-02-20 06:27:18 --> Router Class Initialized
INFO - 2023-02-20 06:27:18 --> Output Class Initialized
INFO - 2023-02-20 06:27:18 --> Output Class Initialized
INFO - 2023-02-20 06:27:18 --> Security Class Initialized
INFO - 2023-02-20 06:27:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:27:18 --> Input Class Initialized
INFO - 2023-02-20 06:27:18 --> Input Class Initialized
INFO - 2023-02-20 06:27:18 --> Language Class Initialized
INFO - 2023-02-20 06:27:18 --> Language Class Initialized
INFO - 2023-02-20 06:27:18 --> Loader Class Initialized
INFO - 2023-02-20 06:27:18 --> Loader Class Initialized
INFO - 2023-02-20 06:27:18 --> Controller Class Initialized
INFO - 2023-02-20 06:27:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:27:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:27:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:27:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:27:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:27:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:27:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:27:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:27:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:27:18 --> Total execution time: 0.0272
INFO - 2023-02-20 06:27:18 --> Config Class Initialized
INFO - 2023-02-20 06:27:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:27:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:27:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:27:18 --> URI Class Initialized
INFO - 2023-02-20 06:27:18 --> Router Class Initialized
INFO - 2023-02-20 06:27:18 --> Output Class Initialized
INFO - 2023-02-20 06:27:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:27:18 --> Input Class Initialized
INFO - 2023-02-20 06:27:18 --> Language Class Initialized
INFO - 2023-02-20 06:27:18 --> Loader Class Initialized
INFO - 2023-02-20 06:27:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:27:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:27:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:27:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:27:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:27:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:27:18 --> Total execution time: 0.0148
INFO - 2023-02-20 06:27:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:27:19 --> Total execution time: 0.9337
INFO - 2023-02-20 06:27:19 --> Config Class Initialized
INFO - 2023-02-20 06:27:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:27:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:27:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:27:19 --> URI Class Initialized
INFO - 2023-02-20 06:27:19 --> Router Class Initialized
INFO - 2023-02-20 06:27:19 --> Output Class Initialized
INFO - 2023-02-20 06:27:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:27:19 --> Input Class Initialized
INFO - 2023-02-20 06:27:19 --> Language Class Initialized
INFO - 2023-02-20 06:27:19 --> Loader Class Initialized
INFO - 2023-02-20 06:27:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:27:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:27:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:27:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:27:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:27:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:27:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:27:20 --> Total execution time: 0.7721
INFO - 2023-02-20 06:28:19 --> Config Class Initialized
INFO - 2023-02-20 06:28:19 --> Config Class Initialized
INFO - 2023-02-20 06:28:19 --> Hooks Class Initialized
INFO - 2023-02-20 06:28:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:28:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:28:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:28:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:28:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:28:19 --> URI Class Initialized
INFO - 2023-02-20 06:28:19 --> URI Class Initialized
INFO - 2023-02-20 06:28:19 --> Router Class Initialized
INFO - 2023-02-20 06:28:19 --> Router Class Initialized
INFO - 2023-02-20 06:28:19 --> Output Class Initialized
INFO - 2023-02-20 06:28:19 --> Output Class Initialized
INFO - 2023-02-20 06:28:19 --> Security Class Initialized
INFO - 2023-02-20 06:28:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:28:19 --> Input Class Initialized
INFO - 2023-02-20 06:28:19 --> Input Class Initialized
INFO - 2023-02-20 06:28:19 --> Language Class Initialized
INFO - 2023-02-20 06:28:19 --> Language Class Initialized
INFO - 2023-02-20 06:28:19 --> Loader Class Initialized
INFO - 2023-02-20 06:28:19 --> Loader Class Initialized
INFO - 2023-02-20 06:28:19 --> Controller Class Initialized
INFO - 2023-02-20 06:28:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:28:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:28:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:28:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:28:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:28:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:28:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:28:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:28:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:28:19 --> Total execution time: 0.0232
INFO - 2023-02-20 06:28:19 --> Config Class Initialized
INFO - 2023-02-20 06:28:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:28:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:28:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:28:19 --> URI Class Initialized
INFO - 2023-02-20 06:28:19 --> Router Class Initialized
INFO - 2023-02-20 06:28:19 --> Output Class Initialized
INFO - 2023-02-20 06:28:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:28:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:28:19 --> Input Class Initialized
INFO - 2023-02-20 06:28:19 --> Language Class Initialized
INFO - 2023-02-20 06:28:19 --> Loader Class Initialized
INFO - 2023-02-20 06:28:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:28:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:28:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:28:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:28:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:28:19 --> Total execution time: 0.0156
INFO - 2023-02-20 06:28:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:28:20 --> Total execution time: 0.6680
INFO - 2023-02-20 06:28:20 --> Config Class Initialized
INFO - 2023-02-20 06:28:20 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:28:20 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:28:20 --> Utf8 Class Initialized
INFO - 2023-02-20 06:28:20 --> URI Class Initialized
INFO - 2023-02-20 06:28:20 --> Router Class Initialized
INFO - 2023-02-20 06:28:20 --> Output Class Initialized
INFO - 2023-02-20 06:28:20 --> Security Class Initialized
DEBUG - 2023-02-20 06:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:28:20 --> Input Class Initialized
INFO - 2023-02-20 06:28:20 --> Language Class Initialized
INFO - 2023-02-20 06:28:20 --> Loader Class Initialized
INFO - 2023-02-20 06:28:20 --> Controller Class Initialized
DEBUG - 2023-02-20 06:28:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:28:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:28:20 --> Model "Login_model" initialized
INFO - 2023-02-20 06:28:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:28:20 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:28:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:28:20 --> Total execution time: 0.6151
INFO - 2023-02-20 06:29:19 --> Config Class Initialized
INFO - 2023-02-20 06:29:19 --> Config Class Initialized
INFO - 2023-02-20 06:29:19 --> Hooks Class Initialized
INFO - 2023-02-20 06:29:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:29:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:29:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:29:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:29:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:29:19 --> URI Class Initialized
INFO - 2023-02-20 06:29:19 --> URI Class Initialized
INFO - 2023-02-20 06:29:19 --> Router Class Initialized
INFO - 2023-02-20 06:29:19 --> Router Class Initialized
INFO - 2023-02-20 06:29:19 --> Output Class Initialized
INFO - 2023-02-20 06:29:19 --> Output Class Initialized
INFO - 2023-02-20 06:29:19 --> Security Class Initialized
INFO - 2023-02-20 06:29:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:29:19 --> Input Class Initialized
INFO - 2023-02-20 06:29:19 --> Input Class Initialized
INFO - 2023-02-20 06:29:19 --> Language Class Initialized
INFO - 2023-02-20 06:29:19 --> Language Class Initialized
INFO - 2023-02-20 06:29:19 --> Loader Class Initialized
INFO - 2023-02-20 06:29:19 --> Loader Class Initialized
INFO - 2023-02-20 06:29:19 --> Controller Class Initialized
INFO - 2023-02-20 06:29:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:29:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:29:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:29:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:29:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:29:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:29:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:29:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:29:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:29:19 --> Total execution time: 0.0206
INFO - 2023-02-20 06:29:19 --> Config Class Initialized
INFO - 2023-02-20 06:29:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:29:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:29:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:29:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:29:19 --> URI Class Initialized
INFO - 2023-02-20 06:29:19 --> Router Class Initialized
INFO - 2023-02-20 06:29:19 --> Output Class Initialized
INFO - 2023-02-20 06:29:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:29:19 --> Input Class Initialized
INFO - 2023-02-20 06:29:19 --> Language Class Initialized
INFO - 2023-02-20 06:29:19 --> Loader Class Initialized
INFO - 2023-02-20 06:29:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:29:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:29:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:29:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:29:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:29:19 --> Total execution time: 0.0161
INFO - 2023-02-20 06:29:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:29:20 --> Total execution time: 0.7346
INFO - 2023-02-20 06:29:20 --> Config Class Initialized
INFO - 2023-02-20 06:29:20 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:29:20 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:29:20 --> Utf8 Class Initialized
INFO - 2023-02-20 06:29:20 --> URI Class Initialized
INFO - 2023-02-20 06:29:20 --> Router Class Initialized
INFO - 2023-02-20 06:29:20 --> Output Class Initialized
INFO - 2023-02-20 06:29:20 --> Security Class Initialized
DEBUG - 2023-02-20 06:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:29:20 --> Input Class Initialized
INFO - 2023-02-20 06:29:20 --> Language Class Initialized
INFO - 2023-02-20 06:29:20 --> Loader Class Initialized
INFO - 2023-02-20 06:29:20 --> Controller Class Initialized
DEBUG - 2023-02-20 06:29:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:29:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:29:20 --> Model "Login_model" initialized
INFO - 2023-02-20 06:29:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:29:20 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:29:21 --> Final output sent to browser
DEBUG - 2023-02-20 06:29:21 --> Total execution time: 0.7475
INFO - 2023-02-20 06:30:19 --> Config Class Initialized
INFO - 2023-02-20 06:30:19 --> Config Class Initialized
INFO - 2023-02-20 06:30:19 --> Hooks Class Initialized
INFO - 2023-02-20 06:30:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:30:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:30:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:30:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:30:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:30:19 --> URI Class Initialized
INFO - 2023-02-20 06:30:19 --> URI Class Initialized
INFO - 2023-02-20 06:30:19 --> Router Class Initialized
INFO - 2023-02-20 06:30:19 --> Router Class Initialized
INFO - 2023-02-20 06:30:19 --> Output Class Initialized
INFO - 2023-02-20 06:30:19 --> Output Class Initialized
INFO - 2023-02-20 06:30:19 --> Security Class Initialized
INFO - 2023-02-20 06:30:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:30:19 --> Input Class Initialized
INFO - 2023-02-20 06:30:19 --> Input Class Initialized
INFO - 2023-02-20 06:30:19 --> Language Class Initialized
INFO - 2023-02-20 06:30:19 --> Language Class Initialized
INFO - 2023-02-20 06:30:19 --> Loader Class Initialized
INFO - 2023-02-20 06:30:19 --> Loader Class Initialized
INFO - 2023-02-20 06:30:19 --> Controller Class Initialized
INFO - 2023-02-20 06:30:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:30:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:30:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:30:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:30:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:30:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:30:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:30:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:30:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:30:19 --> Total execution time: 0.0390
INFO - 2023-02-20 06:30:19 --> Config Class Initialized
INFO - 2023-02-20 06:30:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:30:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:30:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:30:19 --> URI Class Initialized
INFO - 2023-02-20 06:30:19 --> Router Class Initialized
INFO - 2023-02-20 06:30:19 --> Output Class Initialized
INFO - 2023-02-20 06:30:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:30:19 --> Input Class Initialized
INFO - 2023-02-20 06:30:19 --> Language Class Initialized
INFO - 2023-02-20 06:30:19 --> Loader Class Initialized
INFO - 2023-02-20 06:30:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:30:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:30:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:30:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:30:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:30:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:30:19 --> Total execution time: 0.0536
INFO - 2023-02-20 06:30:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:30:20 --> Total execution time: 0.8452
INFO - 2023-02-20 06:30:20 --> Config Class Initialized
INFO - 2023-02-20 06:30:20 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:30:20 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:30:20 --> Utf8 Class Initialized
INFO - 2023-02-20 06:30:20 --> URI Class Initialized
INFO - 2023-02-20 06:30:20 --> Router Class Initialized
INFO - 2023-02-20 06:30:20 --> Output Class Initialized
INFO - 2023-02-20 06:30:20 --> Security Class Initialized
DEBUG - 2023-02-20 06:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:30:20 --> Input Class Initialized
INFO - 2023-02-20 06:30:20 --> Language Class Initialized
INFO - 2023-02-20 06:30:20 --> Loader Class Initialized
INFO - 2023-02-20 06:30:20 --> Controller Class Initialized
DEBUG - 2023-02-20 06:30:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:30:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:30:20 --> Model "Login_model" initialized
INFO - 2023-02-20 06:30:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:30:20 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:30:21 --> Final output sent to browser
DEBUG - 2023-02-20 06:30:21 --> Total execution time: 0.6794
INFO - 2023-02-20 06:31:19 --> Config Class Initialized
INFO - 2023-02-20 06:31:19 --> Config Class Initialized
INFO - 2023-02-20 06:31:19 --> Hooks Class Initialized
INFO - 2023-02-20 06:31:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:31:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:31:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:31:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:31:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:31:19 --> URI Class Initialized
INFO - 2023-02-20 06:31:19 --> URI Class Initialized
INFO - 2023-02-20 06:31:19 --> Router Class Initialized
INFO - 2023-02-20 06:31:19 --> Router Class Initialized
INFO - 2023-02-20 06:31:19 --> Output Class Initialized
INFO - 2023-02-20 06:31:19 --> Output Class Initialized
INFO - 2023-02-20 06:31:19 --> Security Class Initialized
INFO - 2023-02-20 06:31:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:31:19 --> Input Class Initialized
INFO - 2023-02-20 06:31:19 --> Input Class Initialized
INFO - 2023-02-20 06:31:19 --> Language Class Initialized
INFO - 2023-02-20 06:31:19 --> Language Class Initialized
INFO - 2023-02-20 06:31:19 --> Loader Class Initialized
INFO - 2023-02-20 06:31:19 --> Loader Class Initialized
INFO - 2023-02-20 06:31:19 --> Controller Class Initialized
INFO - 2023-02-20 06:31:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:31:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:31:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:31:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:31:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:31:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:31:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:31:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:31:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:31:19 --> Total execution time: 0.0208
INFO - 2023-02-20 06:31:19 --> Config Class Initialized
INFO - 2023-02-20 06:31:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:31:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:31:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:31:19 --> URI Class Initialized
INFO - 2023-02-20 06:31:19 --> Router Class Initialized
INFO - 2023-02-20 06:31:19 --> Output Class Initialized
INFO - 2023-02-20 06:31:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:31:19 --> Input Class Initialized
INFO - 2023-02-20 06:31:19 --> Language Class Initialized
INFO - 2023-02-20 06:31:19 --> Loader Class Initialized
INFO - 2023-02-20 06:31:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:31:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:31:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:31:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:31:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:31:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:31:19 --> Total execution time: 0.0180
INFO - 2023-02-20 06:31:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:31:20 --> Total execution time: 0.6863
INFO - 2023-02-20 06:31:20 --> Config Class Initialized
INFO - 2023-02-20 06:31:20 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:31:20 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:31:20 --> Utf8 Class Initialized
INFO - 2023-02-20 06:31:20 --> URI Class Initialized
INFO - 2023-02-20 06:31:20 --> Router Class Initialized
INFO - 2023-02-20 06:31:20 --> Output Class Initialized
INFO - 2023-02-20 06:31:20 --> Security Class Initialized
DEBUG - 2023-02-20 06:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:31:20 --> Input Class Initialized
INFO - 2023-02-20 06:31:20 --> Language Class Initialized
INFO - 2023-02-20 06:31:20 --> Loader Class Initialized
INFO - 2023-02-20 06:31:20 --> Controller Class Initialized
DEBUG - 2023-02-20 06:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:31:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:31:20 --> Model "Login_model" initialized
INFO - 2023-02-20 06:31:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:31:20 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:31:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:31:20 --> Total execution time: 0.7295
INFO - 2023-02-20 06:32:19 --> Config Class Initialized
INFO - 2023-02-20 06:32:19 --> Config Class Initialized
INFO - 2023-02-20 06:32:19 --> Hooks Class Initialized
INFO - 2023-02-20 06:32:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:32:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:32:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:32:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:32:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:32:19 --> URI Class Initialized
INFO - 2023-02-20 06:32:19 --> URI Class Initialized
INFO - 2023-02-20 06:32:19 --> Router Class Initialized
INFO - 2023-02-20 06:32:19 --> Router Class Initialized
INFO - 2023-02-20 06:32:19 --> Output Class Initialized
INFO - 2023-02-20 06:32:19 --> Output Class Initialized
INFO - 2023-02-20 06:32:19 --> Security Class Initialized
INFO - 2023-02-20 06:32:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:32:19 --> Input Class Initialized
INFO - 2023-02-20 06:32:19 --> Input Class Initialized
INFO - 2023-02-20 06:32:19 --> Language Class Initialized
INFO - 2023-02-20 06:32:19 --> Language Class Initialized
INFO - 2023-02-20 06:32:19 --> Loader Class Initialized
INFO - 2023-02-20 06:32:19 --> Loader Class Initialized
INFO - 2023-02-20 06:32:19 --> Controller Class Initialized
INFO - 2023-02-20 06:32:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:32:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:32:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:32:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:32:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:32:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:32:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:32:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:32:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:32:19 --> Total execution time: 0.0216
INFO - 2023-02-20 06:32:19 --> Config Class Initialized
INFO - 2023-02-20 06:32:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:32:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:32:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:32:19 --> URI Class Initialized
INFO - 2023-02-20 06:32:19 --> Router Class Initialized
INFO - 2023-02-20 06:32:19 --> Output Class Initialized
INFO - 2023-02-20 06:32:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:32:19 --> Input Class Initialized
INFO - 2023-02-20 06:32:19 --> Language Class Initialized
INFO - 2023-02-20 06:32:19 --> Loader Class Initialized
INFO - 2023-02-20 06:32:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:32:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:32:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:32:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:32:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:32:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:32:19 --> Total execution time: 0.0148
INFO - 2023-02-20 06:32:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:32:20 --> Total execution time: 0.6620
INFO - 2023-02-20 06:32:20 --> Config Class Initialized
INFO - 2023-02-20 06:32:20 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:32:20 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:32:20 --> Utf8 Class Initialized
INFO - 2023-02-20 06:32:20 --> URI Class Initialized
INFO - 2023-02-20 06:32:20 --> Router Class Initialized
INFO - 2023-02-20 06:32:20 --> Output Class Initialized
INFO - 2023-02-20 06:32:20 --> Security Class Initialized
DEBUG - 2023-02-20 06:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:32:20 --> Input Class Initialized
INFO - 2023-02-20 06:32:20 --> Language Class Initialized
INFO - 2023-02-20 06:32:20 --> Loader Class Initialized
INFO - 2023-02-20 06:32:20 --> Controller Class Initialized
DEBUG - 2023-02-20 06:32:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:32:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:32:20 --> Model "Login_model" initialized
INFO - 2023-02-20 06:32:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:32:20 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:32:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:32:20 --> Total execution time: 0.7612
INFO - 2023-02-20 06:33:18 --> Config Class Initialized
INFO - 2023-02-20 06:33:18 --> Config Class Initialized
INFO - 2023-02-20 06:33:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:33:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:33:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:33:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:33:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:33:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:33:18 --> URI Class Initialized
INFO - 2023-02-20 06:33:18 --> URI Class Initialized
INFO - 2023-02-20 06:33:18 --> Router Class Initialized
INFO - 2023-02-20 06:33:18 --> Router Class Initialized
INFO - 2023-02-20 06:33:18 --> Output Class Initialized
INFO - 2023-02-20 06:33:18 --> Output Class Initialized
INFO - 2023-02-20 06:33:18 --> Security Class Initialized
INFO - 2023-02-20 06:33:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:33:18 --> Input Class Initialized
DEBUG - 2023-02-20 06:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:33:18 --> Language Class Initialized
INFO - 2023-02-20 06:33:18 --> Input Class Initialized
INFO - 2023-02-20 06:33:18 --> Language Class Initialized
INFO - 2023-02-20 06:33:18 --> Loader Class Initialized
INFO - 2023-02-20 06:33:18 --> Loader Class Initialized
INFO - 2023-02-20 06:33:18 --> Controller Class Initialized
INFO - 2023-02-20 06:33:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:33:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:33:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:33:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:33:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:33:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:33:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:33:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:33:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:33:18 --> Total execution time: 0.0208
INFO - 2023-02-20 06:33:18 --> Config Class Initialized
INFO - 2023-02-20 06:33:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:33:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:33:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:33:18 --> URI Class Initialized
INFO - 2023-02-20 06:33:18 --> Router Class Initialized
INFO - 2023-02-20 06:33:18 --> Output Class Initialized
INFO - 2023-02-20 06:33:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:33:18 --> Input Class Initialized
INFO - 2023-02-20 06:33:18 --> Language Class Initialized
INFO - 2023-02-20 06:33:18 --> Loader Class Initialized
INFO - 2023-02-20 06:33:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:33:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:33:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:33:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:33:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:33:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:33:18 --> Total execution time: 0.0161
INFO - 2023-02-20 06:33:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:33:19 --> Total execution time: 0.7595
INFO - 2023-02-20 06:33:19 --> Config Class Initialized
INFO - 2023-02-20 06:33:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:33:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:33:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:33:19 --> URI Class Initialized
INFO - 2023-02-20 06:33:19 --> Router Class Initialized
INFO - 2023-02-20 06:33:19 --> Output Class Initialized
INFO - 2023-02-20 06:33:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:33:19 --> Input Class Initialized
INFO - 2023-02-20 06:33:19 --> Language Class Initialized
INFO - 2023-02-20 06:33:19 --> Loader Class Initialized
INFO - 2023-02-20 06:33:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:33:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:33:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:33:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:33:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:33:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:33:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:33:19 --> Total execution time: 0.7064
INFO - 2023-02-20 06:34:19 --> Config Class Initialized
INFO - 2023-02-20 06:34:19 --> Config Class Initialized
INFO - 2023-02-20 06:34:19 --> Hooks Class Initialized
INFO - 2023-02-20 06:34:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:34:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:34:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:34:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:34:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:34:19 --> URI Class Initialized
INFO - 2023-02-20 06:34:19 --> URI Class Initialized
INFO - 2023-02-20 06:34:19 --> Router Class Initialized
INFO - 2023-02-20 06:34:19 --> Router Class Initialized
INFO - 2023-02-20 06:34:19 --> Output Class Initialized
INFO - 2023-02-20 06:34:19 --> Output Class Initialized
INFO - 2023-02-20 06:34:19 --> Security Class Initialized
INFO - 2023-02-20 06:34:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:34:19 --> Input Class Initialized
INFO - 2023-02-20 06:34:19 --> Input Class Initialized
INFO - 2023-02-20 06:34:19 --> Language Class Initialized
INFO - 2023-02-20 06:34:19 --> Language Class Initialized
INFO - 2023-02-20 06:34:19 --> Loader Class Initialized
INFO - 2023-02-20 06:34:19 --> Loader Class Initialized
INFO - 2023-02-20 06:34:19 --> Controller Class Initialized
INFO - 2023-02-20 06:34:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:34:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:34:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:34:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:34:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:34:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:34:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:34:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:34:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:34:19 --> Total execution time: 0.0230
INFO - 2023-02-20 06:34:19 --> Config Class Initialized
INFO - 2023-02-20 06:34:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:34:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:34:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:34:19 --> URI Class Initialized
INFO - 2023-02-20 06:34:19 --> Router Class Initialized
INFO - 2023-02-20 06:34:19 --> Output Class Initialized
INFO - 2023-02-20 06:34:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:34:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:34:19 --> Input Class Initialized
INFO - 2023-02-20 06:34:19 --> Language Class Initialized
INFO - 2023-02-20 06:34:19 --> Loader Class Initialized
INFO - 2023-02-20 06:34:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:34:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:34:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:34:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:34:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:34:19 --> Total execution time: 0.0172
INFO - 2023-02-20 06:34:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:34:20 --> Total execution time: 0.6551
INFO - 2023-02-20 06:34:20 --> Config Class Initialized
INFO - 2023-02-20 06:34:20 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:34:20 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:34:20 --> Utf8 Class Initialized
INFO - 2023-02-20 06:34:20 --> URI Class Initialized
INFO - 2023-02-20 06:34:20 --> Router Class Initialized
INFO - 2023-02-20 06:34:20 --> Output Class Initialized
INFO - 2023-02-20 06:34:20 --> Security Class Initialized
DEBUG - 2023-02-20 06:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:34:20 --> Input Class Initialized
INFO - 2023-02-20 06:34:20 --> Language Class Initialized
INFO - 2023-02-20 06:34:20 --> Loader Class Initialized
INFO - 2023-02-20 06:34:20 --> Controller Class Initialized
DEBUG - 2023-02-20 06:34:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:34:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:34:20 --> Model "Login_model" initialized
INFO - 2023-02-20 06:34:20 --> Database Driver Class Initialized
INFO - 2023-02-20 06:34:20 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:34:20 --> Final output sent to browser
DEBUG - 2023-02-20 06:34:20 --> Total execution time: 0.6822
INFO - 2023-02-20 06:35:43 --> Config Class Initialized
INFO - 2023-02-20 06:35:43 --> Config Class Initialized
INFO - 2023-02-20 06:35:43 --> Hooks Class Initialized
INFO - 2023-02-20 06:35:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:35:43 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:35:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:35:43 --> Utf8 Class Initialized
INFO - 2023-02-20 06:35:43 --> Utf8 Class Initialized
INFO - 2023-02-20 06:35:43 --> URI Class Initialized
INFO - 2023-02-20 06:35:43 --> URI Class Initialized
INFO - 2023-02-20 06:35:43 --> Router Class Initialized
INFO - 2023-02-20 06:35:43 --> Router Class Initialized
INFO - 2023-02-20 06:35:43 --> Output Class Initialized
INFO - 2023-02-20 06:35:43 --> Output Class Initialized
INFO - 2023-02-20 06:35:43 --> Security Class Initialized
INFO - 2023-02-20 06:35:43 --> Security Class Initialized
DEBUG - 2023-02-20 06:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:35:43 --> Input Class Initialized
INFO - 2023-02-20 06:35:43 --> Input Class Initialized
INFO - 2023-02-20 06:35:43 --> Language Class Initialized
INFO - 2023-02-20 06:35:43 --> Language Class Initialized
INFO - 2023-02-20 06:35:43 --> Loader Class Initialized
INFO - 2023-02-20 06:35:43 --> Loader Class Initialized
INFO - 2023-02-20 06:35:43 --> Controller Class Initialized
INFO - 2023-02-20 06:35:43 --> Controller Class Initialized
DEBUG - 2023-02-20 06:35:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:35:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:35:43 --> Database Driver Class Initialized
INFO - 2023-02-20 06:35:43 --> Database Driver Class Initialized
INFO - 2023-02-20 06:35:43 --> Model "Login_model" initialized
INFO - 2023-02-20 06:35:43 --> Database Driver Class Initialized
INFO - 2023-02-20 06:35:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:35:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:35:43 --> Final output sent to browser
DEBUG - 2023-02-20 06:35:43 --> Total execution time: 0.1210
INFO - 2023-02-20 06:35:43 --> Config Class Initialized
INFO - 2023-02-20 06:35:43 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:35:43 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:35:43 --> Utf8 Class Initialized
INFO - 2023-02-20 06:35:43 --> URI Class Initialized
INFO - 2023-02-20 06:35:43 --> Router Class Initialized
INFO - 2023-02-20 06:35:43 --> Output Class Initialized
INFO - 2023-02-20 06:35:43 --> Security Class Initialized
DEBUG - 2023-02-20 06:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:35:43 --> Input Class Initialized
INFO - 2023-02-20 06:35:43 --> Language Class Initialized
INFO - 2023-02-20 06:35:43 --> Loader Class Initialized
INFO - 2023-02-20 06:35:43 --> Controller Class Initialized
DEBUG - 2023-02-20 06:35:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:35:43 --> Database Driver Class Initialized
INFO - 2023-02-20 06:35:43 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:35:43 --> Final output sent to browser
DEBUG - 2023-02-20 06:35:43 --> Total execution time: 0.0163
INFO - 2023-02-20 06:35:44 --> Final output sent to browser
DEBUG - 2023-02-20 06:35:44 --> Total execution time: 0.7259
INFO - 2023-02-20 06:35:44 --> Config Class Initialized
INFO - 2023-02-20 06:35:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:35:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:35:44 --> Utf8 Class Initialized
INFO - 2023-02-20 06:35:44 --> URI Class Initialized
INFO - 2023-02-20 06:35:44 --> Router Class Initialized
INFO - 2023-02-20 06:35:44 --> Output Class Initialized
INFO - 2023-02-20 06:35:44 --> Security Class Initialized
DEBUG - 2023-02-20 06:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:35:44 --> Input Class Initialized
INFO - 2023-02-20 06:35:44 --> Language Class Initialized
INFO - 2023-02-20 06:35:44 --> Loader Class Initialized
INFO - 2023-02-20 06:35:44 --> Controller Class Initialized
DEBUG - 2023-02-20 06:35:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:35:44 --> Database Driver Class Initialized
INFO - 2023-02-20 06:35:44 --> Model "Login_model" initialized
INFO - 2023-02-20 06:35:44 --> Database Driver Class Initialized
INFO - 2023-02-20 06:35:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:35:44 --> Final output sent to browser
DEBUG - 2023-02-20 06:35:44 --> Total execution time: 0.6975
INFO - 2023-02-20 06:36:18 --> Config Class Initialized
INFO - 2023-02-20 06:36:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:36:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:36:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:36:18 --> URI Class Initialized
INFO - 2023-02-20 06:36:18 --> Router Class Initialized
INFO - 2023-02-20 06:36:18 --> Output Class Initialized
INFO - 2023-02-20 06:36:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:36:18 --> Input Class Initialized
INFO - 2023-02-20 06:36:18 --> Language Class Initialized
INFO - 2023-02-20 06:36:18 --> Loader Class Initialized
INFO - 2023-02-20 06:36:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:36:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:36:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:36:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:36:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:36:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:36:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:36:19 --> Total execution time: 0.6799
INFO - 2023-02-20 06:36:19 --> Config Class Initialized
INFO - 2023-02-20 06:36:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:36:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:36:19 --> Utf8 Class Initialized
INFO - 2023-02-20 06:36:19 --> URI Class Initialized
INFO - 2023-02-20 06:36:19 --> Router Class Initialized
INFO - 2023-02-20 06:36:19 --> Output Class Initialized
INFO - 2023-02-20 06:36:19 --> Security Class Initialized
DEBUG - 2023-02-20 06:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:36:19 --> Input Class Initialized
INFO - 2023-02-20 06:36:19 --> Language Class Initialized
INFO - 2023-02-20 06:36:19 --> Loader Class Initialized
INFO - 2023-02-20 06:36:19 --> Controller Class Initialized
DEBUG - 2023-02-20 06:36:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:36:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:36:19 --> Model "Login_model" initialized
INFO - 2023-02-20 06:36:19 --> Database Driver Class Initialized
INFO - 2023-02-20 06:36:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:36:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:36:19 --> Total execution time: 0.7229
INFO - 2023-02-20 06:37:18 --> Config Class Initialized
INFO - 2023-02-20 06:37:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:37:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:37:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:37:18 --> URI Class Initialized
INFO - 2023-02-20 06:37:18 --> Router Class Initialized
INFO - 2023-02-20 06:37:18 --> Output Class Initialized
INFO - 2023-02-20 06:37:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:37:18 --> Input Class Initialized
INFO - 2023-02-20 06:37:18 --> Language Class Initialized
INFO - 2023-02-20 06:37:18 --> Loader Class Initialized
INFO - 2023-02-20 06:37:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:37:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:37:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:37:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:37:18 --> Total execution time: 0.0162
INFO - 2023-02-20 06:37:18 --> Config Class Initialized
INFO - 2023-02-20 06:37:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:37:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:37:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:37:18 --> URI Class Initialized
INFO - 2023-02-20 06:37:18 --> Router Class Initialized
INFO - 2023-02-20 06:37:18 --> Output Class Initialized
INFO - 2023-02-20 06:37:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:37:18 --> Input Class Initialized
INFO - 2023-02-20 06:37:18 --> Language Class Initialized
INFO - 2023-02-20 06:37:18 --> Loader Class Initialized
INFO - 2023-02-20 06:37:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:37:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:37:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:37:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:37:18 --> Total execution time: 0.0153
INFO - 2023-02-20 06:38:18 --> Config Class Initialized
INFO - 2023-02-20 06:38:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:38:18 --> Config Class Initialized
INFO - 2023-02-20 06:38:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:38:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:38:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:38:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:38:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:38:18 --> URI Class Initialized
INFO - 2023-02-20 06:38:18 --> URI Class Initialized
INFO - 2023-02-20 06:38:18 --> Router Class Initialized
INFO - 2023-02-20 06:38:18 --> Router Class Initialized
INFO - 2023-02-20 06:38:18 --> Output Class Initialized
INFO - 2023-02-20 06:38:18 --> Output Class Initialized
INFO - 2023-02-20 06:38:18 --> Security Class Initialized
INFO - 2023-02-20 06:38:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:38:18 --> Input Class Initialized
DEBUG - 2023-02-20 06:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:38:18 --> Language Class Initialized
INFO - 2023-02-20 06:38:18 --> Input Class Initialized
INFO - 2023-02-20 06:38:18 --> Language Class Initialized
INFO - 2023-02-20 06:38:18 --> Loader Class Initialized
INFO - 2023-02-20 06:38:18 --> Loader Class Initialized
INFO - 2023-02-20 06:38:18 --> Controller Class Initialized
INFO - 2023-02-20 06:38:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:38:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:38:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:38:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:38:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:38:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:38:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:38:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:38:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:38:18 --> Total execution time: 0.0190
INFO - 2023-02-20 06:38:18 --> Config Class Initialized
INFO - 2023-02-20 06:38:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:38:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:38:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:38:18 --> URI Class Initialized
INFO - 2023-02-20 06:38:18 --> Router Class Initialized
INFO - 2023-02-20 06:38:18 --> Output Class Initialized
INFO - 2023-02-20 06:38:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:38:18 --> Input Class Initialized
INFO - 2023-02-20 06:38:18 --> Language Class Initialized
INFO - 2023-02-20 06:38:18 --> Loader Class Initialized
INFO - 2023-02-20 06:38:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:38:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:38:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:38:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:38:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:38:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:38:18 --> Total execution time: 0.0137
INFO - 2023-02-20 06:38:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:38:18 --> Total execution time: 0.7154
INFO - 2023-02-20 06:38:18 --> Config Class Initialized
INFO - 2023-02-20 06:38:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:38:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:38:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:38:18 --> URI Class Initialized
INFO - 2023-02-20 06:38:18 --> Router Class Initialized
INFO - 2023-02-20 06:38:18 --> Output Class Initialized
INFO - 2023-02-20 06:38:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:38:18 --> Input Class Initialized
INFO - 2023-02-20 06:38:18 --> Language Class Initialized
INFO - 2023-02-20 06:38:18 --> Loader Class Initialized
INFO - 2023-02-20 06:38:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:38:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:38:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:38:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:38:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:38:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:38:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:38:19 --> Total execution time: 0.6399
INFO - 2023-02-20 06:39:18 --> Config Class Initialized
INFO - 2023-02-20 06:39:18 --> Config Class Initialized
INFO - 2023-02-20 06:39:18 --> Hooks Class Initialized
INFO - 2023-02-20 06:39:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:39:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:39:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:39:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:39:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:39:18 --> URI Class Initialized
INFO - 2023-02-20 06:39:18 --> URI Class Initialized
INFO - 2023-02-20 06:39:18 --> Router Class Initialized
INFO - 2023-02-20 06:39:18 --> Router Class Initialized
INFO - 2023-02-20 06:39:18 --> Output Class Initialized
INFO - 2023-02-20 06:39:18 --> Output Class Initialized
INFO - 2023-02-20 06:39:18 --> Security Class Initialized
INFO - 2023-02-20 06:39:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:39:18 --> Input Class Initialized
DEBUG - 2023-02-20 06:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:39:18 --> Language Class Initialized
INFO - 2023-02-20 06:39:18 --> Input Class Initialized
INFO - 2023-02-20 06:39:18 --> Language Class Initialized
INFO - 2023-02-20 06:39:18 --> Loader Class Initialized
INFO - 2023-02-20 06:39:18 --> Loader Class Initialized
INFO - 2023-02-20 06:39:18 --> Controller Class Initialized
INFO - 2023-02-20 06:39:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:39:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:39:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:39:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:39:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:39:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:39:18 --> Total execution time: 0.0192
INFO - 2023-02-20 06:39:18 --> Config Class Initialized
INFO - 2023-02-20 06:39:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:39:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:39:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:39:18 --> URI Class Initialized
INFO - 2023-02-20 06:39:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:39:18 --> Router Class Initialized
INFO - 2023-02-20 06:39:18 --> Output Class Initialized
INFO - 2023-02-20 06:39:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:39:18 --> Input Class Initialized
INFO - 2023-02-20 06:39:18 --> Language Class Initialized
INFO - 2023-02-20 06:39:18 --> Loader Class Initialized
INFO - 2023-02-20 06:39:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:39:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:39:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:39:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:39:18 --> Total execution time: 0.0150
INFO - 2023-02-20 06:39:18 --> Final output sent to browser
DEBUG - 2023-02-20 06:39:18 --> Total execution time: 0.6945
INFO - 2023-02-20 06:39:18 --> Config Class Initialized
INFO - 2023-02-20 06:39:18 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:39:18 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:39:18 --> Utf8 Class Initialized
INFO - 2023-02-20 06:39:18 --> URI Class Initialized
INFO - 2023-02-20 06:39:18 --> Router Class Initialized
INFO - 2023-02-20 06:39:18 --> Output Class Initialized
INFO - 2023-02-20 06:39:18 --> Security Class Initialized
DEBUG - 2023-02-20 06:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:39:18 --> Input Class Initialized
INFO - 2023-02-20 06:39:18 --> Language Class Initialized
INFO - 2023-02-20 06:39:18 --> Loader Class Initialized
INFO - 2023-02-20 06:39:18 --> Controller Class Initialized
DEBUG - 2023-02-20 06:39:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:39:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:18 --> Model "Login_model" initialized
INFO - 2023-02-20 06:39:18 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:18 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:39:19 --> Final output sent to browser
DEBUG - 2023-02-20 06:39:19 --> Total execution time: 0.7248
INFO - 2023-02-20 06:39:51 --> Config Class Initialized
INFO - 2023-02-20 06:39:51 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:39:51 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:39:51 --> Utf8 Class Initialized
INFO - 2023-02-20 06:39:51 --> Config Class Initialized
INFO - 2023-02-20 06:39:51 --> URI Class Initialized
INFO - 2023-02-20 06:39:51 --> Hooks Class Initialized
INFO - 2023-02-20 06:39:51 --> Config Class Initialized
INFO - 2023-02-20 06:39:51 --> Router Class Initialized
DEBUG - 2023-02-20 06:39:51 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:39:51 --> Hooks Class Initialized
INFO - 2023-02-20 06:39:51 --> Utf8 Class Initialized
INFO - 2023-02-20 06:39:51 --> Output Class Initialized
DEBUG - 2023-02-20 06:39:51 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:39:51 --> URI Class Initialized
INFO - 2023-02-20 06:39:51 --> Utf8 Class Initialized
INFO - 2023-02-20 06:39:51 --> Security Class Initialized
INFO - 2023-02-20 06:39:51 --> URI Class Initialized
INFO - 2023-02-20 06:39:51 --> Router Class Initialized
DEBUG - 2023-02-20 06:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:39:51 --> Router Class Initialized
INFO - 2023-02-20 06:39:51 --> Output Class Initialized
INFO - 2023-02-20 06:39:51 --> Input Class Initialized
INFO - 2023-02-20 06:39:51 --> Output Class Initialized
INFO - 2023-02-20 06:39:51 --> Security Class Initialized
INFO - 2023-02-20 06:39:51 --> Language Class Initialized
INFO - 2023-02-20 06:39:51 --> Security Class Initialized
DEBUG - 2023-02-20 06:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:39:51 --> Loader Class Initialized
DEBUG - 2023-02-20 06:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:39:51 --> Input Class Initialized
INFO - 2023-02-20 06:39:51 --> Controller Class Initialized
INFO - 2023-02-20 06:39:51 --> Input Class Initialized
INFO - 2023-02-20 06:39:51 --> Language Class Initialized
DEBUG - 2023-02-20 06:39:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:39:51 --> Language Class Initialized
INFO - 2023-02-20 06:39:51 --> Loader Class Initialized
INFO - 2023-02-20 06:39:51 --> Loader Class Initialized
INFO - 2023-02-20 06:39:51 --> Controller Class Initialized
INFO - 2023-02-20 06:39:51 --> Database Driver Class Initialized
DEBUG - 2023-02-20 06:39:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:39:51 --> Controller Class Initialized
DEBUG - 2023-02-20 06:39:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:39:51 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:51 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:51 --> Model "Login_model" initialized
INFO - 2023-02-20 06:39:51 --> Model "Login_model" initialized
INFO - 2023-02-20 06:39:51 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:39:51 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:51 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:51 --> Final output sent to browser
DEBUG - 2023-02-20 06:39:51 --> Total execution time: 0.0220
INFO - 2023-02-20 06:39:51 --> Config Class Initialized
INFO - 2023-02-20 06:39:51 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:39:51 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:39:51 --> Utf8 Class Initialized
INFO - 2023-02-20 06:39:51 --> URI Class Initialized
INFO - 2023-02-20 06:39:51 --> Router Class Initialized
INFO - 2023-02-20 06:39:51 --> Output Class Initialized
INFO - 2023-02-20 06:39:51 --> Security Class Initialized
DEBUG - 2023-02-20 06:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:39:51 --> Input Class Initialized
INFO - 2023-02-20 06:39:51 --> Language Class Initialized
INFO - 2023-02-20 06:39:51 --> Loader Class Initialized
INFO - 2023-02-20 06:39:51 --> Controller Class Initialized
DEBUG - 2023-02-20 06:39:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:39:51 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:51 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:39:51 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:39:51 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:39:51 --> Final output sent to browser
DEBUG - 2023-02-20 06:39:51 --> Total execution time: 0.0219
INFO - 2023-02-20 06:39:52 --> Final output sent to browser
DEBUG - 2023-02-20 06:39:52 --> Total execution time: 0.8478
INFO - 2023-02-20 06:39:52 --> Final output sent to browser
DEBUG - 2023-02-20 06:39:52 --> Total execution time: 0.8470
INFO - 2023-02-20 06:39:52 --> Config Class Initialized
INFO - 2023-02-20 06:39:52 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:39:52 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:39:52 --> Utf8 Class Initialized
INFO - 2023-02-20 06:39:52 --> URI Class Initialized
INFO - 2023-02-20 06:39:52 --> Router Class Initialized
INFO - 2023-02-20 06:39:52 --> Output Class Initialized
INFO - 2023-02-20 06:39:52 --> Security Class Initialized
DEBUG - 2023-02-20 06:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:39:52 --> Input Class Initialized
INFO - 2023-02-20 06:39:52 --> Language Class Initialized
INFO - 2023-02-20 06:39:52 --> Loader Class Initialized
INFO - 2023-02-20 06:39:52 --> Controller Class Initialized
DEBUG - 2023-02-20 06:39:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:39:52 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:52 --> Model "Login_model" initialized
INFO - 2023-02-20 06:39:52 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:52 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:39:53 --> Final output sent to browser
DEBUG - 2023-02-20 06:39:53 --> Total execution time: 0.6745
INFO - 2023-02-20 06:39:53 --> Config Class Initialized
INFO - 2023-02-20 06:39:53 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:39:53 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:39:53 --> Utf8 Class Initialized
INFO - 2023-02-20 06:39:53 --> URI Class Initialized
INFO - 2023-02-20 06:39:53 --> Router Class Initialized
INFO - 2023-02-20 06:39:53 --> Output Class Initialized
INFO - 2023-02-20 06:39:53 --> Security Class Initialized
DEBUG - 2023-02-20 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:39:53 --> Input Class Initialized
INFO - 2023-02-20 06:39:53 --> Language Class Initialized
INFO - 2023-02-20 06:39:53 --> Loader Class Initialized
INFO - 2023-02-20 06:39:53 --> Controller Class Initialized
DEBUG - 2023-02-20 06:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:39:53 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:53 --> Model "Login_model" initialized
INFO - 2023-02-20 06:39:53 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:53 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:39:53 --> Final output sent to browser
DEBUG - 2023-02-20 06:39:53 --> Total execution time: 0.6433
INFO - 2023-02-20 06:39:54 --> Config Class Initialized
INFO - 2023-02-20 06:39:54 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:39:54 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:39:54 --> Utf8 Class Initialized
INFO - 2023-02-20 06:39:54 --> URI Class Initialized
INFO - 2023-02-20 06:39:54 --> Router Class Initialized
INFO - 2023-02-20 06:39:54 --> Output Class Initialized
INFO - 2023-02-20 06:39:54 --> Security Class Initialized
DEBUG - 2023-02-20 06:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:39:54 --> Input Class Initialized
INFO - 2023-02-20 06:39:54 --> Language Class Initialized
INFO - 2023-02-20 06:39:54 --> Loader Class Initialized
INFO - 2023-02-20 06:39:54 --> Controller Class Initialized
DEBUG - 2023-02-20 06:39:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:39:54 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:54 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:39:54 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:54 --> Model "Login_model" initialized
INFO - 2023-02-20 06:39:54 --> Final output sent to browser
DEBUG - 2023-02-20 06:39:54 --> Total execution time: 0.0468
INFO - 2023-02-20 06:39:54 --> Config Class Initialized
INFO - 2023-02-20 06:39:54 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:39:54 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:39:54 --> Utf8 Class Initialized
INFO - 2023-02-20 06:39:54 --> URI Class Initialized
INFO - 2023-02-20 06:39:54 --> Router Class Initialized
INFO - 2023-02-20 06:39:54 --> Output Class Initialized
INFO - 2023-02-20 06:39:54 --> Security Class Initialized
DEBUG - 2023-02-20 06:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:39:54 --> Input Class Initialized
INFO - 2023-02-20 06:39:54 --> Language Class Initialized
INFO - 2023-02-20 06:39:54 --> Loader Class Initialized
INFO - 2023-02-20 06:39:54 --> Controller Class Initialized
DEBUG - 2023-02-20 06:39:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:39:54 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:54 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:39:54 --> Database Driver Class Initialized
INFO - 2023-02-20 06:39:54 --> Model "Login_model" initialized
INFO - 2023-02-20 06:39:55 --> Final output sent to browser
DEBUG - 2023-02-20 06:39:55 --> Total execution time: 0.0822
INFO - 2023-02-20 06:45:27 --> Config Class Initialized
INFO - 2023-02-20 06:45:27 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:45:27 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:45:27 --> Utf8 Class Initialized
INFO - 2023-02-20 06:45:27 --> URI Class Initialized
INFO - 2023-02-20 06:45:27 --> Router Class Initialized
INFO - 2023-02-20 06:45:27 --> Output Class Initialized
INFO - 2023-02-20 06:45:27 --> Security Class Initialized
DEBUG - 2023-02-20 06:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:45:27 --> Input Class Initialized
INFO - 2023-02-20 06:45:27 --> Language Class Initialized
INFO - 2023-02-20 06:45:27 --> Loader Class Initialized
INFO - 2023-02-20 06:45:27 --> Controller Class Initialized
DEBUG - 2023-02-20 06:45:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:45:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:45:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:45:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:45:27 --> Model "Login_model" initialized
INFO - 2023-02-20 06:45:27 --> Final output sent to browser
DEBUG - 2023-02-20 06:45:27 --> Total execution time: 0.1415
INFO - 2023-02-20 06:45:27 --> Config Class Initialized
INFO - 2023-02-20 06:45:27 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:45:27 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:45:27 --> Utf8 Class Initialized
INFO - 2023-02-20 06:45:27 --> URI Class Initialized
INFO - 2023-02-20 06:45:27 --> Router Class Initialized
INFO - 2023-02-20 06:45:27 --> Output Class Initialized
INFO - 2023-02-20 06:45:27 --> Security Class Initialized
DEBUG - 2023-02-20 06:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:45:27 --> Input Class Initialized
INFO - 2023-02-20 06:45:27 --> Language Class Initialized
INFO - 2023-02-20 06:45:27 --> Loader Class Initialized
INFO - 2023-02-20 06:45:27 --> Controller Class Initialized
DEBUG - 2023-02-20 06:45:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:45:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:45:27 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:45:27 --> Database Driver Class Initialized
INFO - 2023-02-20 06:45:27 --> Model "Login_model" initialized
INFO - 2023-02-20 06:45:27 --> Final output sent to browser
DEBUG - 2023-02-20 06:45:27 --> Total execution time: 0.0916
INFO - 2023-02-20 06:49:30 --> Config Class Initialized
INFO - 2023-02-20 06:49:30 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:49:30 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:49:30 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:30 --> URI Class Initialized
INFO - 2023-02-20 06:49:30 --> Router Class Initialized
INFO - 2023-02-20 06:49:30 --> Output Class Initialized
INFO - 2023-02-20 06:49:30 --> Security Class Initialized
DEBUG - 2023-02-20 06:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:49:30 --> Input Class Initialized
INFO - 2023-02-20 06:49:30 --> Language Class Initialized
INFO - 2023-02-20 06:49:30 --> Loader Class Initialized
INFO - 2023-02-20 06:49:30 --> Controller Class Initialized
DEBUG - 2023-02-20 06:49:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:49:30 --> Database Driver Class Initialized
INFO - 2023-02-20 06:49:30 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:49:30 --> Final output sent to browser
DEBUG - 2023-02-20 06:49:30 --> Total execution time: 0.0477
INFO - 2023-02-20 06:49:30 --> Config Class Initialized
INFO - 2023-02-20 06:49:30 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:49:30 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:49:30 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:30 --> URI Class Initialized
INFO - 2023-02-20 06:49:30 --> Router Class Initialized
INFO - 2023-02-20 06:49:30 --> Output Class Initialized
INFO - 2023-02-20 06:49:30 --> Security Class Initialized
DEBUG - 2023-02-20 06:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:49:30 --> Input Class Initialized
INFO - 2023-02-20 06:49:30 --> Language Class Initialized
INFO - 2023-02-20 06:49:30 --> Loader Class Initialized
INFO - 2023-02-20 06:49:30 --> Controller Class Initialized
DEBUG - 2023-02-20 06:49:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:49:30 --> Database Driver Class Initialized
INFO - 2023-02-20 06:49:30 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:49:30 --> Final output sent to browser
DEBUG - 2023-02-20 06:49:30 --> Total execution time: 0.0867
INFO - 2023-02-20 06:49:33 --> Config Class Initialized
INFO - 2023-02-20 06:49:33 --> Config Class Initialized
INFO - 2023-02-20 06:49:33 --> Hooks Class Initialized
INFO - 2023-02-20 06:49:33 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:49:33 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:49:33 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:49:33 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:33 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:33 --> URI Class Initialized
INFO - 2023-02-20 06:49:33 --> URI Class Initialized
INFO - 2023-02-20 06:49:33 --> Router Class Initialized
INFO - 2023-02-20 06:49:33 --> Router Class Initialized
INFO - 2023-02-20 06:49:33 --> Output Class Initialized
INFO - 2023-02-20 06:49:33 --> Output Class Initialized
INFO - 2023-02-20 06:49:33 --> Security Class Initialized
INFO - 2023-02-20 06:49:33 --> Security Class Initialized
DEBUG - 2023-02-20 06:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 06:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:49:33 --> Input Class Initialized
INFO - 2023-02-20 06:49:33 --> Input Class Initialized
INFO - 2023-02-20 06:49:33 --> Language Class Initialized
INFO - 2023-02-20 06:49:33 --> Language Class Initialized
INFO - 2023-02-20 06:49:33 --> Loader Class Initialized
INFO - 2023-02-20 06:49:33 --> Loader Class Initialized
INFO - 2023-02-20 06:49:33 --> Controller Class Initialized
INFO - 2023-02-20 06:49:33 --> Controller Class Initialized
DEBUG - 2023-02-20 06:49:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 06:49:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:49:33 --> Final output sent to browser
INFO - 2023-02-20 06:49:33 --> Database Driver Class Initialized
DEBUG - 2023-02-20 06:49:33 --> Total execution time: 0.0043
INFO - 2023-02-20 06:49:33 --> Config Class Initialized
INFO - 2023-02-20 06:49:33 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:49:33 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:49:33 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:49:33 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:33 --> URI Class Initialized
INFO - 2023-02-20 06:49:33 --> Router Class Initialized
INFO - 2023-02-20 06:49:33 --> Output Class Initialized
INFO - 2023-02-20 06:49:33 --> Security Class Initialized
DEBUG - 2023-02-20 06:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:49:33 --> Input Class Initialized
INFO - 2023-02-20 06:49:33 --> Language Class Initialized
INFO - 2023-02-20 06:49:33 --> Loader Class Initialized
INFO - 2023-02-20 06:49:33 --> Controller Class Initialized
DEBUG - 2023-02-20 06:49:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:49:33 --> Database Driver Class Initialized
INFO - 2023-02-20 06:49:33 --> Final output sent to browser
DEBUG - 2023-02-20 06:49:33 --> Total execution time: 0.0513
INFO - 2023-02-20 06:49:33 --> Config Class Initialized
INFO - 2023-02-20 06:49:33 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:49:33 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:49:33 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:33 --> URI Class Initialized
INFO - 2023-02-20 06:49:33 --> Router Class Initialized
INFO - 2023-02-20 06:49:33 --> Output Class Initialized
INFO - 2023-02-20 06:49:33 --> Security Class Initialized
DEBUG - 2023-02-20 06:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:49:33 --> Input Class Initialized
INFO - 2023-02-20 06:49:33 --> Language Class Initialized
INFO - 2023-02-20 06:49:33 --> Loader Class Initialized
INFO - 2023-02-20 06:49:33 --> Controller Class Initialized
DEBUG - 2023-02-20 06:49:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:49:33 --> Database Driver Class Initialized
INFO - 2023-02-20 06:49:33 --> Model "Login_model" initialized
INFO - 2023-02-20 06:49:33 --> Database Driver Class Initialized
INFO - 2023-02-20 06:49:33 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:49:33 --> Final output sent to browser
DEBUG - 2023-02-20 06:49:33 --> Total execution time: 0.0158
INFO - 2023-02-20 06:49:33 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:49:33 --> Final output sent to browser
DEBUG - 2023-02-20 06:49:33 --> Total execution time: 0.1067
INFO - 2023-02-20 06:49:37 --> Config Class Initialized
INFO - 2023-02-20 06:49:37 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:49:37 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:49:37 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:37 --> URI Class Initialized
INFO - 2023-02-20 06:49:37 --> Router Class Initialized
INFO - 2023-02-20 06:49:37 --> Output Class Initialized
INFO - 2023-02-20 06:49:37 --> Security Class Initialized
DEBUG - 2023-02-20 06:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:49:37 --> Input Class Initialized
INFO - 2023-02-20 06:49:37 --> Language Class Initialized
INFO - 2023-02-20 06:49:37 --> Loader Class Initialized
INFO - 2023-02-20 06:49:37 --> Controller Class Initialized
DEBUG - 2023-02-20 06:49:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:49:37 --> Database Driver Class Initialized
INFO - 2023-02-20 06:49:37 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:49:37 --> Final output sent to browser
DEBUG - 2023-02-20 06:49:37 --> Total execution time: 0.0151
INFO - 2023-02-20 06:49:37 --> Config Class Initialized
INFO - 2023-02-20 06:49:37 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:49:37 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:49:37 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:37 --> URI Class Initialized
INFO - 2023-02-20 06:49:37 --> Router Class Initialized
INFO - 2023-02-20 06:49:37 --> Output Class Initialized
INFO - 2023-02-20 06:49:37 --> Security Class Initialized
DEBUG - 2023-02-20 06:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:49:37 --> Input Class Initialized
INFO - 2023-02-20 06:49:37 --> Language Class Initialized
INFO - 2023-02-20 06:49:37 --> Loader Class Initialized
INFO - 2023-02-20 06:49:37 --> Controller Class Initialized
DEBUG - 2023-02-20 06:49:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:49:37 --> Database Driver Class Initialized
INFO - 2023-02-20 06:49:37 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:49:37 --> Final output sent to browser
DEBUG - 2023-02-20 06:49:37 --> Total execution time: 0.0547
INFO - 2023-02-20 06:49:39 --> Config Class Initialized
INFO - 2023-02-20 06:49:39 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:49:39 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:49:39 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:39 --> URI Class Initialized
INFO - 2023-02-20 06:49:39 --> Router Class Initialized
INFO - 2023-02-20 06:49:39 --> Output Class Initialized
INFO - 2023-02-20 06:49:39 --> Security Class Initialized
DEBUG - 2023-02-20 06:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:49:39 --> Input Class Initialized
INFO - 2023-02-20 06:49:39 --> Language Class Initialized
INFO - 2023-02-20 06:49:39 --> Loader Class Initialized
INFO - 2023-02-20 06:49:39 --> Controller Class Initialized
DEBUG - 2023-02-20 06:49:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:49:39 --> Database Driver Class Initialized
INFO - 2023-02-20 06:49:39 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:49:39 --> Final output sent to browser
DEBUG - 2023-02-20 06:49:39 --> Total execution time: 0.0474
INFO - 2023-02-20 06:49:39 --> Config Class Initialized
INFO - 2023-02-20 06:49:39 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:49:39 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:49:39 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:39 --> URI Class Initialized
INFO - 2023-02-20 06:49:39 --> Router Class Initialized
INFO - 2023-02-20 06:49:39 --> Output Class Initialized
INFO - 2023-02-20 06:49:39 --> Security Class Initialized
DEBUG - 2023-02-20 06:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:49:39 --> Input Class Initialized
INFO - 2023-02-20 06:49:39 --> Language Class Initialized
INFO - 2023-02-20 06:49:39 --> Loader Class Initialized
INFO - 2023-02-20 06:49:39 --> Controller Class Initialized
DEBUG - 2023-02-20 06:49:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:49:39 --> Database Driver Class Initialized
INFO - 2023-02-20 06:49:39 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:49:39 --> Final output sent to browser
DEBUG - 2023-02-20 06:49:39 --> Total execution time: 0.0799
INFO - 2023-02-20 06:49:41 --> Config Class Initialized
INFO - 2023-02-20 06:49:41 --> Config Class Initialized
INFO - 2023-02-20 06:49:41 --> Hooks Class Initialized
INFO - 2023-02-20 06:49:41 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:49:41 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 06:49:41 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:49:41 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:41 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:41 --> URI Class Initialized
INFO - 2023-02-20 06:49:41 --> URI Class Initialized
INFO - 2023-02-20 06:49:41 --> Router Class Initialized
INFO - 2023-02-20 06:49:41 --> Output Class Initialized
INFO - 2023-02-20 06:49:41 --> Router Class Initialized
INFO - 2023-02-20 06:49:41 --> Security Class Initialized
INFO - 2023-02-20 06:49:41 --> Output Class Initialized
DEBUG - 2023-02-20 06:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:49:41 --> Security Class Initialized
INFO - 2023-02-20 06:49:41 --> Input Class Initialized
DEBUG - 2023-02-20 06:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:49:41 --> Language Class Initialized
INFO - 2023-02-20 06:49:41 --> Input Class Initialized
INFO - 2023-02-20 06:49:41 --> Language Class Initialized
INFO - 2023-02-20 06:49:41 --> Loader Class Initialized
INFO - 2023-02-20 06:49:41 --> Controller Class Initialized
INFO - 2023-02-20 06:49:41 --> Loader Class Initialized
DEBUG - 2023-02-20 06:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:49:41 --> Controller Class Initialized
DEBUG - 2023-02-20 06:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:49:41 --> Final output sent to browser
DEBUG - 2023-02-20 06:49:41 --> Total execution time: 0.0044
INFO - 2023-02-20 06:49:41 --> Database Driver Class Initialized
INFO - 2023-02-20 06:49:41 --> Config Class Initialized
INFO - 2023-02-20 06:49:41 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:49:41 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:49:41 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:41 --> URI Class Initialized
INFO - 2023-02-20 06:49:41 --> Router Class Initialized
INFO - 2023-02-20 06:49:41 --> Output Class Initialized
INFO - 2023-02-20 06:49:41 --> Security Class Initialized
DEBUG - 2023-02-20 06:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:49:41 --> Input Class Initialized
INFO - 2023-02-20 06:49:41 --> Language Class Initialized
INFO - 2023-02-20 06:49:41 --> Loader Class Initialized
INFO - 2023-02-20 06:49:41 --> Controller Class Initialized
DEBUG - 2023-02-20 06:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:49:41 --> Database Driver Class Initialized
INFO - 2023-02-20 06:49:41 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:49:41 --> Model "Login_model" initialized
INFO - 2023-02-20 06:49:41 --> Final output sent to browser
DEBUG - 2023-02-20 06:49:41 --> Total execution time: 0.0210
INFO - 2023-02-20 06:49:41 --> Database Driver Class Initialized
INFO - 2023-02-20 06:49:41 --> Config Class Initialized
INFO - 2023-02-20 06:49:41 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:49:41 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:49:41 --> Utf8 Class Initialized
INFO - 2023-02-20 06:49:41 --> URI Class Initialized
INFO - 2023-02-20 06:49:41 --> Router Class Initialized
INFO - 2023-02-20 06:49:41 --> Output Class Initialized
INFO - 2023-02-20 06:49:41 --> Security Class Initialized
DEBUG - 2023-02-20 06:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:49:41 --> Input Class Initialized
INFO - 2023-02-20 06:49:41 --> Language Class Initialized
INFO - 2023-02-20 06:49:41 --> Loader Class Initialized
INFO - 2023-02-20 06:49:41 --> Controller Class Initialized
DEBUG - 2023-02-20 06:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:49:41 --> Database Driver Class Initialized
INFO - 2023-02-20 06:49:41 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:49:41 --> Final output sent to browser
DEBUG - 2023-02-20 06:49:41 --> Total execution time: 0.0242
INFO - 2023-02-20 06:49:41 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:49:41 --> Final output sent to browser
DEBUG - 2023-02-20 06:49:41 --> Total execution time: 0.0589
INFO - 2023-02-20 06:55:49 --> Config Class Initialized
INFO - 2023-02-20 06:55:49 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:55:49 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:55:49 --> Utf8 Class Initialized
INFO - 2023-02-20 06:55:49 --> URI Class Initialized
INFO - 2023-02-20 06:55:49 --> Router Class Initialized
INFO - 2023-02-20 06:55:49 --> Output Class Initialized
INFO - 2023-02-20 06:55:49 --> Security Class Initialized
DEBUG - 2023-02-20 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:55:49 --> Input Class Initialized
INFO - 2023-02-20 06:55:49 --> Language Class Initialized
INFO - 2023-02-20 06:55:49 --> Loader Class Initialized
INFO - 2023-02-20 06:55:49 --> Controller Class Initialized
DEBUG - 2023-02-20 06:55:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:55:49 --> Database Driver Class Initialized
INFO - 2023-02-20 06:55:49 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:55:49 --> Database Driver Class Initialized
INFO - 2023-02-20 06:55:49 --> Model "Login_model" initialized
INFO - 2023-02-20 06:55:49 --> Final output sent to browser
DEBUG - 2023-02-20 06:55:49 --> Total execution time: 0.0508
INFO - 2023-02-20 06:55:49 --> Config Class Initialized
INFO - 2023-02-20 06:55:49 --> Hooks Class Initialized
DEBUG - 2023-02-20 06:55:49 --> UTF-8 Support Enabled
INFO - 2023-02-20 06:55:49 --> Utf8 Class Initialized
INFO - 2023-02-20 06:55:49 --> URI Class Initialized
INFO - 2023-02-20 06:55:49 --> Router Class Initialized
INFO - 2023-02-20 06:55:49 --> Output Class Initialized
INFO - 2023-02-20 06:55:49 --> Security Class Initialized
DEBUG - 2023-02-20 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 06:55:49 --> Input Class Initialized
INFO - 2023-02-20 06:55:49 --> Language Class Initialized
INFO - 2023-02-20 06:55:49 --> Loader Class Initialized
INFO - 2023-02-20 06:55:49 --> Controller Class Initialized
DEBUG - 2023-02-20 06:55:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 06:55:49 --> Database Driver Class Initialized
INFO - 2023-02-20 06:55:49 --> Model "Cluster_model" initialized
INFO - 2023-02-20 06:55:49 --> Database Driver Class Initialized
INFO - 2023-02-20 06:55:49 --> Model "Login_model" initialized
INFO - 2023-02-20 06:55:49 --> Final output sent to browser
DEBUG - 2023-02-20 06:55:49 --> Total execution time: 0.0502
INFO - 2023-02-20 08:21:30 --> Config Class Initialized
INFO - 2023-02-20 08:21:30 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:21:30 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:21:30 --> Utf8 Class Initialized
INFO - 2023-02-20 08:21:30 --> URI Class Initialized
INFO - 2023-02-20 08:21:30 --> Router Class Initialized
INFO - 2023-02-20 08:21:30 --> Output Class Initialized
INFO - 2023-02-20 08:21:30 --> Security Class Initialized
DEBUG - 2023-02-20 08:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:21:30 --> Input Class Initialized
INFO - 2023-02-20 08:21:30 --> Language Class Initialized
INFO - 2023-02-20 08:21:30 --> Loader Class Initialized
INFO - 2023-02-20 08:21:30 --> Controller Class Initialized
DEBUG - 2023-02-20 08:21:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:21:30 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:30 --> Model "Cluster_model" initialized
INFO - 2023-02-20 08:21:30 --> Final output sent to browser
DEBUG - 2023-02-20 08:21:30 --> Total execution time: 0.0182
INFO - 2023-02-20 08:21:30 --> Config Class Initialized
INFO - 2023-02-20 08:21:30 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:21:30 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:21:30 --> Utf8 Class Initialized
INFO - 2023-02-20 08:21:30 --> URI Class Initialized
INFO - 2023-02-20 08:21:30 --> Router Class Initialized
INFO - 2023-02-20 08:21:30 --> Output Class Initialized
INFO - 2023-02-20 08:21:30 --> Security Class Initialized
DEBUG - 2023-02-20 08:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:21:30 --> Input Class Initialized
INFO - 2023-02-20 08:21:30 --> Language Class Initialized
INFO - 2023-02-20 08:21:30 --> Loader Class Initialized
INFO - 2023-02-20 08:21:30 --> Controller Class Initialized
DEBUG - 2023-02-20 08:21:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:21:30 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:30 --> Model "Cluster_model" initialized
INFO - 2023-02-20 08:21:30 --> Final output sent to browser
DEBUG - 2023-02-20 08:21:30 --> Total execution time: 0.0551
INFO - 2023-02-20 08:21:31 --> Config Class Initialized
INFO - 2023-02-20 08:21:31 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:21:31 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:21:31 --> Utf8 Class Initialized
INFO - 2023-02-20 08:21:31 --> URI Class Initialized
INFO - 2023-02-20 08:21:31 --> Router Class Initialized
INFO - 2023-02-20 08:21:31 --> Output Class Initialized
INFO - 2023-02-20 08:21:31 --> Security Class Initialized
DEBUG - 2023-02-20 08:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:21:31 --> Input Class Initialized
INFO - 2023-02-20 08:21:31 --> Language Class Initialized
INFO - 2023-02-20 08:21:31 --> Loader Class Initialized
INFO - 2023-02-20 08:21:31 --> Controller Class Initialized
DEBUG - 2023-02-20 08:21:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:21:31 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:31 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:31 --> Model "Login_model" initialized
INFO - 2023-02-20 08:21:31 --> Final output sent to browser
DEBUG - 2023-02-20 08:21:31 --> Total execution time: 0.0257
INFO - 2023-02-20 08:21:31 --> Config Class Initialized
INFO - 2023-02-20 08:21:31 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:21:31 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:21:31 --> Utf8 Class Initialized
INFO - 2023-02-20 08:21:31 --> URI Class Initialized
INFO - 2023-02-20 08:21:31 --> Router Class Initialized
INFO - 2023-02-20 08:21:31 --> Output Class Initialized
INFO - 2023-02-20 08:21:31 --> Security Class Initialized
DEBUG - 2023-02-20 08:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:21:31 --> Input Class Initialized
INFO - 2023-02-20 08:21:31 --> Language Class Initialized
INFO - 2023-02-20 08:21:31 --> Loader Class Initialized
INFO - 2023-02-20 08:21:31 --> Controller Class Initialized
DEBUG - 2023-02-20 08:21:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:21:31 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:31 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:31 --> Model "Login_model" initialized
INFO - 2023-02-20 08:21:31 --> Final output sent to browser
DEBUG - 2023-02-20 08:21:31 --> Total execution time: 0.0585
INFO - 2023-02-20 08:21:51 --> Config Class Initialized
INFO - 2023-02-20 08:21:51 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:21:51 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:21:51 --> Utf8 Class Initialized
INFO - 2023-02-20 08:21:51 --> URI Class Initialized
INFO - 2023-02-20 08:21:51 --> Router Class Initialized
INFO - 2023-02-20 08:21:51 --> Output Class Initialized
INFO - 2023-02-20 08:21:51 --> Security Class Initialized
DEBUG - 2023-02-20 08:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:21:51 --> Input Class Initialized
INFO - 2023-02-20 08:21:51 --> Language Class Initialized
INFO - 2023-02-20 08:21:51 --> Loader Class Initialized
INFO - 2023-02-20 08:21:51 --> Controller Class Initialized
DEBUG - 2023-02-20 08:21:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:21:51 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:51 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:51 --> Model "Login_model" initialized
INFO - 2023-02-20 08:21:51 --> Final output sent to browser
DEBUG - 2023-02-20 08:21:51 --> Total execution time: 0.0235
INFO - 2023-02-20 08:21:51 --> Config Class Initialized
INFO - 2023-02-20 08:21:51 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:21:51 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:21:51 --> Utf8 Class Initialized
INFO - 2023-02-20 08:21:51 --> URI Class Initialized
INFO - 2023-02-20 08:21:51 --> Router Class Initialized
INFO - 2023-02-20 08:21:51 --> Output Class Initialized
INFO - 2023-02-20 08:21:51 --> Security Class Initialized
DEBUG - 2023-02-20 08:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:21:51 --> Input Class Initialized
INFO - 2023-02-20 08:21:51 --> Language Class Initialized
INFO - 2023-02-20 08:21:51 --> Loader Class Initialized
INFO - 2023-02-20 08:21:51 --> Controller Class Initialized
DEBUG - 2023-02-20 08:21:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:21:51 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:51 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:52 --> Model "Login_model" initialized
INFO - 2023-02-20 08:21:52 --> Final output sent to browser
DEBUG - 2023-02-20 08:21:52 --> Total execution time: 0.0657
INFO - 2023-02-20 08:21:54 --> Config Class Initialized
INFO - 2023-02-20 08:21:54 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:21:54 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:21:54 --> Utf8 Class Initialized
INFO - 2023-02-20 08:21:54 --> URI Class Initialized
INFO - 2023-02-20 08:21:54 --> Router Class Initialized
INFO - 2023-02-20 08:21:54 --> Output Class Initialized
INFO - 2023-02-20 08:21:54 --> Security Class Initialized
DEBUG - 2023-02-20 08:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:21:54 --> Input Class Initialized
INFO - 2023-02-20 08:21:54 --> Language Class Initialized
INFO - 2023-02-20 08:21:54 --> Loader Class Initialized
INFO - 2023-02-20 08:21:54 --> Controller Class Initialized
DEBUG - 2023-02-20 08:21:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:21:54 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:54 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:54 --> Model "Login_model" initialized
INFO - 2023-02-20 08:21:54 --> Final output sent to browser
DEBUG - 2023-02-20 08:21:54 --> Total execution time: 0.0246
INFO - 2023-02-20 08:21:54 --> Config Class Initialized
INFO - 2023-02-20 08:21:54 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:21:54 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:21:54 --> Utf8 Class Initialized
INFO - 2023-02-20 08:21:54 --> URI Class Initialized
INFO - 2023-02-20 08:21:54 --> Router Class Initialized
INFO - 2023-02-20 08:21:54 --> Output Class Initialized
INFO - 2023-02-20 08:21:54 --> Security Class Initialized
DEBUG - 2023-02-20 08:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:21:54 --> Input Class Initialized
INFO - 2023-02-20 08:21:54 --> Language Class Initialized
INFO - 2023-02-20 08:21:54 --> Loader Class Initialized
INFO - 2023-02-20 08:21:54 --> Controller Class Initialized
DEBUG - 2023-02-20 08:21:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:21:54 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:54 --> Database Driver Class Initialized
INFO - 2023-02-20 08:21:54 --> Model "Login_model" initialized
INFO - 2023-02-20 08:21:54 --> Final output sent to browser
DEBUG - 2023-02-20 08:21:54 --> Total execution time: 0.0626
INFO - 2023-02-20 08:22:02 --> Config Class Initialized
INFO - 2023-02-20 08:22:02 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:22:02 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:22:02 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:02 --> URI Class Initialized
INFO - 2023-02-20 08:22:02 --> Router Class Initialized
INFO - 2023-02-20 08:22:02 --> Output Class Initialized
INFO - 2023-02-20 08:22:02 --> Security Class Initialized
DEBUG - 2023-02-20 08:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:22:02 --> Input Class Initialized
INFO - 2023-02-20 08:22:02 --> Language Class Initialized
INFO - 2023-02-20 08:22:02 --> Loader Class Initialized
INFO - 2023-02-20 08:22:02 --> Controller Class Initialized
DEBUG - 2023-02-20 08:22:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:22:02 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:02 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:02 --> Model "Login_model" initialized
INFO - 2023-02-20 08:22:02 --> Final output sent to browser
DEBUG - 2023-02-20 08:22:02 --> Total execution time: 0.0258
INFO - 2023-02-20 08:22:02 --> Config Class Initialized
INFO - 2023-02-20 08:22:02 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:22:02 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:22:02 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:02 --> URI Class Initialized
INFO - 2023-02-20 08:22:02 --> Router Class Initialized
INFO - 2023-02-20 08:22:02 --> Output Class Initialized
INFO - 2023-02-20 08:22:02 --> Security Class Initialized
DEBUG - 2023-02-20 08:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:22:02 --> Input Class Initialized
INFO - 2023-02-20 08:22:02 --> Language Class Initialized
INFO - 2023-02-20 08:22:02 --> Loader Class Initialized
INFO - 2023-02-20 08:22:02 --> Controller Class Initialized
DEBUG - 2023-02-20 08:22:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:22:02 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:02 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:02 --> Model "Login_model" initialized
INFO - 2023-02-20 08:22:02 --> Final output sent to browser
DEBUG - 2023-02-20 08:22:02 --> Total execution time: 0.0223
INFO - 2023-02-20 08:22:19 --> Config Class Initialized
INFO - 2023-02-20 08:22:19 --> Hooks Class Initialized
INFO - 2023-02-20 08:22:19 --> Config Class Initialized
INFO - 2023-02-20 08:22:19 --> Config Class Initialized
INFO - 2023-02-20 08:22:19 --> Hooks Class Initialized
INFO - 2023-02-20 08:22:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:22:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 08:22:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-20 08:22:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:22:19 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:19 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:19 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:19 --> URI Class Initialized
INFO - 2023-02-20 08:22:19 --> URI Class Initialized
INFO - 2023-02-20 08:22:19 --> URI Class Initialized
INFO - 2023-02-20 08:22:19 --> Router Class Initialized
INFO - 2023-02-20 08:22:19 --> Router Class Initialized
INFO - 2023-02-20 08:22:19 --> Router Class Initialized
INFO - 2023-02-20 08:22:19 --> Output Class Initialized
INFO - 2023-02-20 08:22:19 --> Output Class Initialized
INFO - 2023-02-20 08:22:19 --> Output Class Initialized
INFO - 2023-02-20 08:22:19 --> Security Class Initialized
INFO - 2023-02-20 08:22:19 --> Security Class Initialized
INFO - 2023-02-20 08:22:19 --> Security Class Initialized
DEBUG - 2023-02-20 08:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 08:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-20 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:22:19 --> Input Class Initialized
INFO - 2023-02-20 08:22:19 --> Input Class Initialized
INFO - 2023-02-20 08:22:19 --> Input Class Initialized
INFO - 2023-02-20 08:22:19 --> Language Class Initialized
INFO - 2023-02-20 08:22:19 --> Language Class Initialized
INFO - 2023-02-20 08:22:19 --> Language Class Initialized
INFO - 2023-02-20 08:22:19 --> Loader Class Initialized
INFO - 2023-02-20 08:22:19 --> Loader Class Initialized
INFO - 2023-02-20 08:22:19 --> Loader Class Initialized
INFO - 2023-02-20 08:22:19 --> Controller Class Initialized
INFO - 2023-02-20 08:22:19 --> Controller Class Initialized
INFO - 2023-02-20 08:22:19 --> Controller Class Initialized
DEBUG - 2023-02-20 08:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 08:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 08:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:22:19 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:19 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:19 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:19 --> Final output sent to browser
INFO - 2023-02-20 08:22:19 --> Final output sent to browser
DEBUG - 2023-02-20 08:22:19 --> Total execution time: 0.0157
DEBUG - 2023-02-20 08:22:19 --> Total execution time: 0.0156
INFO - 2023-02-20 08:22:19 --> Config Class Initialized
INFO - 2023-02-20 08:22:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:22:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:22:19 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:19 --> URI Class Initialized
INFO - 2023-02-20 08:22:19 --> Config Class Initialized
INFO - 2023-02-20 08:22:19 --> Model "Login_model" initialized
INFO - 2023-02-20 08:22:19 --> Hooks Class Initialized
INFO - 2023-02-20 08:22:19 --> Router Class Initialized
DEBUG - 2023-02-20 08:22:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:22:19 --> Output Class Initialized
INFO - 2023-02-20 08:22:19 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:19 --> URI Class Initialized
INFO - 2023-02-20 08:22:19 --> Security Class Initialized
INFO - 2023-02-20 08:22:19 --> Router Class Initialized
DEBUG - 2023-02-20 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:22:19 --> Output Class Initialized
INFO - 2023-02-20 08:22:19 --> Input Class Initialized
INFO - 2023-02-20 08:22:19 --> Security Class Initialized
INFO - 2023-02-20 08:22:19 --> Language Class Initialized
DEBUG - 2023-02-20 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:22:19 --> Input Class Initialized
INFO - 2023-02-20 08:22:19 --> Loader Class Initialized
INFO - 2023-02-20 08:22:19 --> Language Class Initialized
INFO - 2023-02-20 08:22:19 --> Controller Class Initialized
INFO - 2023-02-20 08:22:19 --> Loader Class Initialized
DEBUG - 2023-02-20 08:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:22:19 --> Controller Class Initialized
INFO - 2023-02-20 08:22:19 --> Final output sent to browser
DEBUG - 2023-02-20 08:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 08:22:19 --> Total execution time: 0.0429
INFO - 2023-02-20 08:22:19 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:19 --> Config Class Initialized
INFO - 2023-02-20 08:22:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:22:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:22:19 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:19 --> Final output sent to browser
INFO - 2023-02-20 08:22:19 --> Database Driver Class Initialized
DEBUG - 2023-02-20 08:22:19 --> Total execution time: 0.0642
INFO - 2023-02-20 08:22:19 --> URI Class Initialized
INFO - 2023-02-20 08:22:19 --> Router Class Initialized
INFO - 2023-02-20 08:22:19 --> Output Class Initialized
INFO - 2023-02-20 08:22:19 --> Security Class Initialized
INFO - 2023-02-20 08:22:19 --> Config Class Initialized
DEBUG - 2023-02-20 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:22:19 --> Hooks Class Initialized
INFO - 2023-02-20 08:22:19 --> Input Class Initialized
DEBUG - 2023-02-20 08:22:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:22:19 --> Language Class Initialized
INFO - 2023-02-20 08:22:19 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:19 --> Loader Class Initialized
INFO - 2023-02-20 08:22:19 --> URI Class Initialized
INFO - 2023-02-20 08:22:19 --> Controller Class Initialized
INFO - 2023-02-20 08:22:19 --> Router Class Initialized
DEBUG - 2023-02-20 08:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:22:19 --> Output Class Initialized
INFO - 2023-02-20 08:22:19 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:19 --> Security Class Initialized
DEBUG - 2023-02-20 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:22:19 --> Input Class Initialized
INFO - 2023-02-20 08:22:19 --> Language Class Initialized
INFO - 2023-02-20 08:22:19 --> Loader Class Initialized
INFO - 2023-02-20 08:22:19 --> Controller Class Initialized
DEBUG - 2023-02-20 08:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:22:19 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:19 --> Model "Login_model" initialized
INFO - 2023-02-20 08:22:19 --> Model "Login_model" initialized
INFO - 2023-02-20 08:22:19 --> Final output sent to browser
INFO - 2023-02-20 08:22:19 --> Database Driver Class Initialized
DEBUG - 2023-02-20 08:22:19 --> Total execution time: 0.0996
INFO - 2023-02-20 08:22:19 --> Config Class Initialized
INFO - 2023-02-20 08:22:19 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:19 --> Model "Login_model" initialized
INFO - 2023-02-20 08:22:19 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:22:19 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:22:19 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:19 --> URI Class Initialized
INFO - 2023-02-20 08:22:19 --> Router Class Initialized
INFO - 2023-02-20 08:22:19 --> Output Class Initialized
INFO - 2023-02-20 08:22:19 --> Security Class Initialized
DEBUG - 2023-02-20 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:22:19 --> Input Class Initialized
INFO - 2023-02-20 08:22:19 --> Language Class Initialized
INFO - 2023-02-20 08:22:19 --> Loader Class Initialized
INFO - 2023-02-20 08:22:19 --> Controller Class Initialized
DEBUG - 2023-02-20 08:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:22:19 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:19 --> Final output sent to browser
DEBUG - 2023-02-20 08:22:19 --> Total execution time: 0.1027
INFO - 2023-02-20 08:22:19 --> Model "Cluster_model" initialized
INFO - 2023-02-20 08:22:19 --> Model "Login_model" initialized
INFO - 2023-02-20 08:22:19 --> Final output sent to browser
DEBUG - 2023-02-20 08:22:19 --> Total execution time: 0.1105
INFO - 2023-02-20 08:22:19 --> Final output sent to browser
DEBUG - 2023-02-20 08:22:19 --> Total execution time: 0.0988
INFO - 2023-02-20 08:22:47 --> Config Class Initialized
INFO - 2023-02-20 08:22:47 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:22:47 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:22:47 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:47 --> URI Class Initialized
INFO - 2023-02-20 08:22:47 --> Router Class Initialized
INFO - 2023-02-20 08:22:47 --> Output Class Initialized
INFO - 2023-02-20 08:22:47 --> Security Class Initialized
DEBUG - 2023-02-20 08:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:22:47 --> Input Class Initialized
INFO - 2023-02-20 08:22:47 --> Language Class Initialized
INFO - 2023-02-20 08:22:47 --> Loader Class Initialized
INFO - 2023-02-20 08:22:47 --> Controller Class Initialized
DEBUG - 2023-02-20 08:22:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:22:47 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:47 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:47 --> Model "Login_model" initialized
INFO - 2023-02-20 08:22:47 --> Final output sent to browser
DEBUG - 2023-02-20 08:22:47 --> Total execution time: 0.0269
INFO - 2023-02-20 08:22:47 --> Config Class Initialized
INFO - 2023-02-20 08:22:47 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:22:47 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:22:47 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:47 --> URI Class Initialized
INFO - 2023-02-20 08:22:47 --> Router Class Initialized
INFO - 2023-02-20 08:22:47 --> Output Class Initialized
INFO - 2023-02-20 08:22:47 --> Security Class Initialized
DEBUG - 2023-02-20 08:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:22:47 --> Input Class Initialized
INFO - 2023-02-20 08:22:47 --> Language Class Initialized
INFO - 2023-02-20 08:22:47 --> Loader Class Initialized
INFO - 2023-02-20 08:22:47 --> Controller Class Initialized
DEBUG - 2023-02-20 08:22:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:22:47 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:47 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:47 --> Model "Login_model" initialized
INFO - 2023-02-20 08:22:47 --> Final output sent to browser
DEBUG - 2023-02-20 08:22:47 --> Total execution time: 0.0265
INFO - 2023-02-20 08:22:50 --> Config Class Initialized
INFO - 2023-02-20 08:22:50 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:22:50 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:22:50 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:50 --> URI Class Initialized
INFO - 2023-02-20 08:22:50 --> Router Class Initialized
INFO - 2023-02-20 08:22:50 --> Output Class Initialized
INFO - 2023-02-20 08:22:50 --> Security Class Initialized
DEBUG - 2023-02-20 08:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:22:50 --> Input Class Initialized
INFO - 2023-02-20 08:22:50 --> Language Class Initialized
INFO - 2023-02-20 08:22:50 --> Loader Class Initialized
INFO - 2023-02-20 08:22:50 --> Controller Class Initialized
DEBUG - 2023-02-20 08:22:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:22:50 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:50 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:50 --> Model "Login_model" initialized
INFO - 2023-02-20 08:22:50 --> Final output sent to browser
DEBUG - 2023-02-20 08:22:50 --> Total execution time: 0.0239
INFO - 2023-02-20 08:22:50 --> Config Class Initialized
INFO - 2023-02-20 08:22:50 --> Hooks Class Initialized
DEBUG - 2023-02-20 08:22:50 --> UTF-8 Support Enabled
INFO - 2023-02-20 08:22:50 --> Utf8 Class Initialized
INFO - 2023-02-20 08:22:50 --> URI Class Initialized
INFO - 2023-02-20 08:22:50 --> Router Class Initialized
INFO - 2023-02-20 08:22:50 --> Output Class Initialized
INFO - 2023-02-20 08:22:50 --> Security Class Initialized
DEBUG - 2023-02-20 08:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 08:22:50 --> Input Class Initialized
INFO - 2023-02-20 08:22:50 --> Language Class Initialized
INFO - 2023-02-20 08:22:50 --> Loader Class Initialized
INFO - 2023-02-20 08:22:50 --> Controller Class Initialized
DEBUG - 2023-02-20 08:22:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 08:22:50 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:50 --> Database Driver Class Initialized
INFO - 2023-02-20 08:22:50 --> Model "Login_model" initialized
INFO - 2023-02-20 08:22:50 --> Final output sent to browser
DEBUG - 2023-02-20 08:22:50 --> Total execution time: 0.0772
INFO - 2023-02-20 09:03:15 --> Config Class Initialized
INFO - 2023-02-20 09:03:15 --> Hooks Class Initialized
INFO - 2023-02-20 09:03:15 --> Config Class Initialized
INFO - 2023-02-20 09:03:15 --> Hooks Class Initialized
DEBUG - 2023-02-20 09:03:15 --> UTF-8 Support Enabled
INFO - 2023-02-20 09:03:15 --> Utf8 Class Initialized
DEBUG - 2023-02-20 09:03:15 --> UTF-8 Support Enabled
INFO - 2023-02-20 09:03:15 --> Utf8 Class Initialized
INFO - 2023-02-20 09:03:15 --> URI Class Initialized
INFO - 2023-02-20 09:03:15 --> URI Class Initialized
INFO - 2023-02-20 09:03:15 --> Router Class Initialized
INFO - 2023-02-20 09:03:15 --> Router Class Initialized
INFO - 2023-02-20 09:03:15 --> Output Class Initialized
INFO - 2023-02-20 09:03:15 --> Output Class Initialized
INFO - 2023-02-20 09:03:15 --> Security Class Initialized
DEBUG - 2023-02-20 09:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 09:03:15 --> Input Class Initialized
INFO - 2023-02-20 09:03:15 --> Language Class Initialized
INFO - 2023-02-20 09:03:15 --> Loader Class Initialized
INFO - 2023-02-20 09:03:15 --> Controller Class Initialized
DEBUG - 2023-02-20 09:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 09:03:15 --> Final output sent to browser
DEBUG - 2023-02-20 09:03:15 --> Total execution time: 0.0039
INFO - 2023-02-20 09:03:15 --> Security Class Initialized
DEBUG - 2023-02-20 09:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 09:03:15 --> Input Class Initialized
INFO - 2023-02-20 09:03:15 --> Language Class Initialized
INFO - 2023-02-20 09:03:15 --> Loader Class Initialized
INFO - 2023-02-20 09:03:15 --> Config Class Initialized
INFO - 2023-02-20 09:03:15 --> Hooks Class Initialized
INFO - 2023-02-20 09:03:15 --> Controller Class Initialized
DEBUG - 2023-02-20 09:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-20 09:03:15 --> UTF-8 Support Enabled
INFO - 2023-02-20 09:03:15 --> Utf8 Class Initialized
INFO - 2023-02-20 09:03:15 --> URI Class Initialized
INFO - 2023-02-20 09:03:15 --> Router Class Initialized
INFO - 2023-02-20 09:03:15 --> Output Class Initialized
INFO - 2023-02-20 09:03:15 --> Security Class Initialized
INFO - 2023-02-20 09:03:15 --> Database Driver Class Initialized
DEBUG - 2023-02-20 09:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 09:03:15 --> Input Class Initialized
INFO - 2023-02-20 09:03:15 --> Language Class Initialized
INFO - 2023-02-20 09:03:15 --> Loader Class Initialized
INFO - 2023-02-20 09:03:15 --> Controller Class Initialized
DEBUG - 2023-02-20 09:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 09:03:15 --> Database Driver Class Initialized
INFO - 2023-02-20 09:03:15 --> Model "Login_model" initialized
INFO - 2023-02-20 09:03:15 --> Model "Cluster_model" initialized
INFO - 2023-02-20 09:03:15 --> Database Driver Class Initialized
INFO - 2023-02-20 09:03:15 --> Final output sent to browser
DEBUG - 2023-02-20 09:03:15 --> Total execution time: 0.0612
INFO - 2023-02-20 09:03:15 --> Config Class Initialized
INFO - 2023-02-20 09:03:15 --> Hooks Class Initialized
DEBUG - 2023-02-20 09:03:15 --> UTF-8 Support Enabled
INFO - 2023-02-20 09:03:15 --> Utf8 Class Initialized
INFO - 2023-02-20 09:03:15 --> URI Class Initialized
INFO - 2023-02-20 09:03:15 --> Router Class Initialized
INFO - 2023-02-20 09:03:15 --> Output Class Initialized
INFO - 2023-02-20 09:03:15 --> Security Class Initialized
DEBUG - 2023-02-20 09:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 09:03:15 --> Input Class Initialized
INFO - 2023-02-20 09:03:15 --> Language Class Initialized
INFO - 2023-02-20 09:03:15 --> Loader Class Initialized
INFO - 2023-02-20 09:03:15 --> Controller Class Initialized
DEBUG - 2023-02-20 09:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 09:03:15 --> Database Driver Class Initialized
INFO - 2023-02-20 09:03:15 --> Model "Cluster_model" initialized
INFO - 2023-02-20 09:03:15 --> Final output sent to browser
DEBUG - 2023-02-20 09:03:15 --> Total execution time: 0.0640
INFO - 2023-02-20 09:03:15 --> Model "Cluster_model" initialized
INFO - 2023-02-20 09:03:15 --> Final output sent to browser
DEBUG - 2023-02-20 09:03:15 --> Total execution time: 0.0390
INFO - 2023-02-20 09:03:16 --> Config Class Initialized
INFO - 2023-02-20 09:03:16 --> Hooks Class Initialized
DEBUG - 2023-02-20 09:03:16 --> UTF-8 Support Enabled
INFO - 2023-02-20 09:03:16 --> Utf8 Class Initialized
INFO - 2023-02-20 09:03:16 --> URI Class Initialized
INFO - 2023-02-20 09:03:16 --> Router Class Initialized
INFO - 2023-02-20 09:03:16 --> Output Class Initialized
INFO - 2023-02-20 09:03:16 --> Security Class Initialized
DEBUG - 2023-02-20 09:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 09:03:16 --> Input Class Initialized
INFO - 2023-02-20 09:03:16 --> Language Class Initialized
INFO - 2023-02-20 09:03:16 --> Loader Class Initialized
INFO - 2023-02-20 09:03:16 --> Controller Class Initialized
DEBUG - 2023-02-20 09:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 09:03:16 --> Database Driver Class Initialized
INFO - 2023-02-20 09:03:16 --> Model "Cluster_model" initialized
INFO - 2023-02-20 09:03:16 --> Database Driver Class Initialized
INFO - 2023-02-20 09:03:16 --> Model "Login_model" initialized
INFO - 2023-02-20 09:03:16 --> Final output sent to browser
DEBUG - 2023-02-20 09:03:16 --> Total execution time: 0.0406
INFO - 2023-02-20 09:03:16 --> Config Class Initialized
INFO - 2023-02-20 09:03:16 --> Hooks Class Initialized
DEBUG - 2023-02-20 09:03:16 --> UTF-8 Support Enabled
INFO - 2023-02-20 09:03:16 --> Utf8 Class Initialized
INFO - 2023-02-20 09:03:16 --> URI Class Initialized
INFO - 2023-02-20 09:03:16 --> Router Class Initialized
INFO - 2023-02-20 09:03:16 --> Output Class Initialized
INFO - 2023-02-20 09:03:16 --> Security Class Initialized
DEBUG - 2023-02-20 09:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 09:03:16 --> Input Class Initialized
INFO - 2023-02-20 09:03:16 --> Language Class Initialized
INFO - 2023-02-20 09:03:16 --> Loader Class Initialized
INFO - 2023-02-20 09:03:16 --> Controller Class Initialized
DEBUG - 2023-02-20 09:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 09:03:16 --> Database Driver Class Initialized
INFO - 2023-02-20 09:03:16 --> Model "Cluster_model" initialized
INFO - 2023-02-20 09:03:16 --> Database Driver Class Initialized
INFO - 2023-02-20 09:03:16 --> Model "Login_model" initialized
INFO - 2023-02-20 09:03:16 --> Final output sent to browser
DEBUG - 2023-02-20 09:03:16 --> Total execution time: 0.0806
INFO - 2023-02-20 09:04:37 --> Config Class Initialized
INFO - 2023-02-20 09:04:37 --> Hooks Class Initialized
DEBUG - 2023-02-20 09:04:37 --> UTF-8 Support Enabled
INFO - 2023-02-20 09:04:37 --> Utf8 Class Initialized
INFO - 2023-02-20 09:04:37 --> URI Class Initialized
INFO - 2023-02-20 09:04:37 --> Router Class Initialized
INFO - 2023-02-20 09:04:37 --> Output Class Initialized
INFO - 2023-02-20 09:04:37 --> Security Class Initialized
DEBUG - 2023-02-20 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 09:04:37 --> Input Class Initialized
INFO - 2023-02-20 09:04:37 --> Language Class Initialized
INFO - 2023-02-20 09:04:37 --> Loader Class Initialized
INFO - 2023-02-20 09:04:37 --> Controller Class Initialized
DEBUG - 2023-02-20 09:04:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 09:04:37 --> Database Driver Class Initialized
INFO - 2023-02-20 09:04:37 --> Model "Cluster_model" initialized
INFO - 2023-02-20 09:04:37 --> Database Driver Class Initialized
INFO - 2023-02-20 09:04:37 --> Model "Login_model" initialized
INFO - 2023-02-20 09:04:37 --> Final output sent to browser
DEBUG - 2023-02-20 09:04:37 --> Total execution time: 0.1379
INFO - 2023-02-20 09:04:37 --> Config Class Initialized
INFO - 2023-02-20 09:04:37 --> Hooks Class Initialized
DEBUG - 2023-02-20 09:04:37 --> UTF-8 Support Enabled
INFO - 2023-02-20 09:04:37 --> Utf8 Class Initialized
INFO - 2023-02-20 09:04:37 --> URI Class Initialized
INFO - 2023-02-20 09:04:37 --> Router Class Initialized
INFO - 2023-02-20 09:04:37 --> Output Class Initialized
INFO - 2023-02-20 09:04:37 --> Security Class Initialized
DEBUG - 2023-02-20 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 09:04:37 --> Input Class Initialized
INFO - 2023-02-20 09:04:37 --> Language Class Initialized
INFO - 2023-02-20 09:04:37 --> Loader Class Initialized
INFO - 2023-02-20 09:04:37 --> Controller Class Initialized
DEBUG - 2023-02-20 09:04:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 09:04:37 --> Database Driver Class Initialized
INFO - 2023-02-20 09:04:37 --> Model "Cluster_model" initialized
INFO - 2023-02-20 09:04:37 --> Database Driver Class Initialized
INFO - 2023-02-20 09:04:37 --> Model "Login_model" initialized
INFO - 2023-02-20 09:04:37 --> Final output sent to browser
DEBUG - 2023-02-20 09:04:37 --> Total execution time: 0.0581
INFO - 2023-02-20 09:51:15 --> Config Class Initialized
INFO - 2023-02-20 09:51:15 --> Hooks Class Initialized
DEBUG - 2023-02-20 09:51:15 --> UTF-8 Support Enabled
INFO - 2023-02-20 09:51:15 --> Utf8 Class Initialized
INFO - 2023-02-20 09:51:15 --> URI Class Initialized
INFO - 2023-02-20 09:51:15 --> Router Class Initialized
INFO - 2023-02-20 09:51:15 --> Output Class Initialized
INFO - 2023-02-20 09:51:15 --> Security Class Initialized
DEBUG - 2023-02-20 09:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 09:51:15 --> Input Class Initialized
INFO - 2023-02-20 09:51:15 --> Language Class Initialized
INFO - 2023-02-20 09:51:15 --> Loader Class Initialized
INFO - 2023-02-20 09:51:15 --> Controller Class Initialized
DEBUG - 2023-02-20 09:51:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 09:51:15 --> Database Driver Class Initialized
INFO - 2023-02-20 09:51:15 --> Model "Cluster_model" initialized
INFO - 2023-02-20 09:51:15 --> Database Driver Class Initialized
INFO - 2023-02-20 09:51:15 --> Model "Login_model" initialized
INFO - 2023-02-20 09:51:15 --> Final output sent to browser
DEBUG - 2023-02-20 09:51:15 --> Total execution time: 0.0813
INFO - 2023-02-20 09:51:15 --> Config Class Initialized
INFO - 2023-02-20 09:51:15 --> Hooks Class Initialized
DEBUG - 2023-02-20 09:51:15 --> UTF-8 Support Enabled
INFO - 2023-02-20 09:51:15 --> Utf8 Class Initialized
INFO - 2023-02-20 09:51:15 --> URI Class Initialized
INFO - 2023-02-20 09:51:15 --> Router Class Initialized
INFO - 2023-02-20 09:51:15 --> Output Class Initialized
INFO - 2023-02-20 09:51:15 --> Security Class Initialized
DEBUG - 2023-02-20 09:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 09:51:15 --> Input Class Initialized
INFO - 2023-02-20 09:51:15 --> Language Class Initialized
INFO - 2023-02-20 09:51:15 --> Loader Class Initialized
INFO - 2023-02-20 09:51:15 --> Controller Class Initialized
DEBUG - 2023-02-20 09:51:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 09:51:15 --> Database Driver Class Initialized
INFO - 2023-02-20 09:51:15 --> Model "Cluster_model" initialized
INFO - 2023-02-20 09:51:15 --> Database Driver Class Initialized
INFO - 2023-02-20 09:51:15 --> Model "Login_model" initialized
INFO - 2023-02-20 09:51:15 --> Final output sent to browser
DEBUG - 2023-02-20 09:51:15 --> Total execution time: 0.0398
INFO - 2023-02-20 10:15:38 --> Config Class Initialized
INFO - 2023-02-20 10:15:38 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:15:38 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:15:38 --> Utf8 Class Initialized
INFO - 2023-02-20 10:15:38 --> URI Class Initialized
INFO - 2023-02-20 10:15:38 --> Router Class Initialized
INFO - 2023-02-20 10:15:38 --> Output Class Initialized
INFO - 2023-02-20 10:15:38 --> Security Class Initialized
DEBUG - 2023-02-20 10:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:15:38 --> Input Class Initialized
INFO - 2023-02-20 10:15:38 --> Language Class Initialized
INFO - 2023-02-20 10:15:38 --> Loader Class Initialized
INFO - 2023-02-20 10:15:38 --> Controller Class Initialized
DEBUG - 2023-02-20 10:15:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:15:38 --> Database Driver Class Initialized
INFO - 2023-02-20 10:15:38 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:15:38 --> Final output sent to browser
DEBUG - 2023-02-20 10:15:38 --> Total execution time: 0.0215
INFO - 2023-02-20 10:15:38 --> Config Class Initialized
INFO - 2023-02-20 10:15:38 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:15:38 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:15:38 --> Utf8 Class Initialized
INFO - 2023-02-20 10:15:38 --> URI Class Initialized
INFO - 2023-02-20 10:15:38 --> Router Class Initialized
INFO - 2023-02-20 10:15:38 --> Output Class Initialized
INFO - 2023-02-20 10:15:38 --> Security Class Initialized
DEBUG - 2023-02-20 10:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:15:38 --> Input Class Initialized
INFO - 2023-02-20 10:15:38 --> Language Class Initialized
INFO - 2023-02-20 10:15:38 --> Loader Class Initialized
INFO - 2023-02-20 10:15:38 --> Controller Class Initialized
DEBUG - 2023-02-20 10:15:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:15:38 --> Database Driver Class Initialized
INFO - 2023-02-20 10:15:38 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:15:38 --> Final output sent to browser
DEBUG - 2023-02-20 10:15:38 --> Total execution time: 0.0540
INFO - 2023-02-20 10:35:09 --> Config Class Initialized
INFO - 2023-02-20 10:35:09 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:35:09 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:35:09 --> Utf8 Class Initialized
INFO - 2023-02-20 10:35:09 --> URI Class Initialized
INFO - 2023-02-20 10:35:09 --> Router Class Initialized
INFO - 2023-02-20 10:35:09 --> Output Class Initialized
INFO - 2023-02-20 10:35:09 --> Security Class Initialized
DEBUG - 2023-02-20 10:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:35:09 --> Input Class Initialized
INFO - 2023-02-20 10:35:09 --> Language Class Initialized
INFO - 2023-02-20 10:35:09 --> Loader Class Initialized
INFO - 2023-02-20 10:35:09 --> Controller Class Initialized
DEBUG - 2023-02-20 10:35:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:35:09 --> Database Driver Class Initialized
INFO - 2023-02-20 10:35:09 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:35:09 --> Final output sent to browser
INFO - 2023-02-20 10:35:09 --> Config Class Initialized
INFO - 2023-02-20 10:35:09 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:35:09 --> Total execution time: 0.0552
DEBUG - 2023-02-20 10:35:09 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:35:09 --> Utf8 Class Initialized
INFO - 2023-02-20 10:35:09 --> URI Class Initialized
INFO - 2023-02-20 10:35:09 --> Router Class Initialized
INFO - 2023-02-20 10:35:09 --> Output Class Initialized
INFO - 2023-02-20 10:35:09 --> Security Class Initialized
DEBUG - 2023-02-20 10:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:35:09 --> Input Class Initialized
INFO - 2023-02-20 10:35:09 --> Language Class Initialized
INFO - 2023-02-20 10:35:09 --> Loader Class Initialized
INFO - 2023-02-20 10:35:09 --> Controller Class Initialized
DEBUG - 2023-02-20 10:35:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:35:09 --> Database Driver Class Initialized
INFO - 2023-02-20 10:35:09 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:35:09 --> Final output sent to browser
DEBUG - 2023-02-20 10:35:09 --> Total execution time: 0.0863
INFO - 2023-02-20 10:36:41 --> Config Class Initialized
INFO - 2023-02-20 10:36:41 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:36:41 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:36:41 --> Utf8 Class Initialized
INFO - 2023-02-20 10:36:41 --> URI Class Initialized
INFO - 2023-02-20 10:36:41 --> Router Class Initialized
INFO - 2023-02-20 10:36:41 --> Output Class Initialized
INFO - 2023-02-20 10:36:41 --> Security Class Initialized
DEBUG - 2023-02-20 10:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:36:41 --> Input Class Initialized
INFO - 2023-02-20 10:36:41 --> Language Class Initialized
INFO - 2023-02-20 10:36:41 --> Loader Class Initialized
INFO - 2023-02-20 10:36:41 --> Controller Class Initialized
DEBUG - 2023-02-20 10:36:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:36:41 --> Database Driver Class Initialized
INFO - 2023-02-20 10:36:41 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:36:41 --> Final output sent to browser
INFO - 2023-02-20 10:36:41 --> Config Class Initialized
DEBUG - 2023-02-20 10:36:41 --> Total execution time: 0.1230
INFO - 2023-02-20 10:36:41 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:36:41 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:36:41 --> Utf8 Class Initialized
INFO - 2023-02-20 10:36:41 --> URI Class Initialized
INFO - 2023-02-20 10:36:41 --> Router Class Initialized
INFO - 2023-02-20 10:36:41 --> Output Class Initialized
INFO - 2023-02-20 10:36:41 --> Security Class Initialized
DEBUG - 2023-02-20 10:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:36:41 --> Input Class Initialized
INFO - 2023-02-20 10:36:41 --> Language Class Initialized
INFO - 2023-02-20 10:36:41 --> Loader Class Initialized
INFO - 2023-02-20 10:36:41 --> Controller Class Initialized
DEBUG - 2023-02-20 10:36:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:36:41 --> Database Driver Class Initialized
INFO - 2023-02-20 10:36:41 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:36:41 --> Final output sent to browser
DEBUG - 2023-02-20 10:36:41 --> Total execution time: 0.0770
INFO - 2023-02-20 10:36:44 --> Config Class Initialized
INFO - 2023-02-20 10:36:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:36:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:36:44 --> Utf8 Class Initialized
INFO - 2023-02-20 10:36:44 --> URI Class Initialized
INFO - 2023-02-20 10:36:44 --> Router Class Initialized
INFO - 2023-02-20 10:36:44 --> Output Class Initialized
INFO - 2023-02-20 10:36:44 --> Security Class Initialized
DEBUG - 2023-02-20 10:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:36:44 --> Input Class Initialized
INFO - 2023-02-20 10:36:44 --> Language Class Initialized
INFO - 2023-02-20 10:36:44 --> Loader Class Initialized
INFO - 2023-02-20 10:36:44 --> Controller Class Initialized
DEBUG - 2023-02-20 10:36:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:36:44 --> Database Driver Class Initialized
INFO - 2023-02-20 10:36:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:36:44 --> Final output sent to browser
DEBUG - 2023-02-20 10:36:44 --> Total execution time: 0.0185
INFO - 2023-02-20 10:36:44 --> Config Class Initialized
INFO - 2023-02-20 10:36:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:36:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:36:44 --> Utf8 Class Initialized
INFO - 2023-02-20 10:36:44 --> URI Class Initialized
INFO - 2023-02-20 10:36:44 --> Router Class Initialized
INFO - 2023-02-20 10:36:44 --> Output Class Initialized
INFO - 2023-02-20 10:36:44 --> Security Class Initialized
DEBUG - 2023-02-20 10:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:36:44 --> Input Class Initialized
INFO - 2023-02-20 10:36:44 --> Language Class Initialized
INFO - 2023-02-20 10:36:44 --> Loader Class Initialized
INFO - 2023-02-20 10:36:44 --> Controller Class Initialized
DEBUG - 2023-02-20 10:36:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:36:44 --> Database Driver Class Initialized
INFO - 2023-02-20 10:36:44 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:36:44 --> Final output sent to browser
DEBUG - 2023-02-20 10:36:44 --> Total execution time: 0.0512
INFO - 2023-02-20 10:36:45 --> Config Class Initialized
INFO - 2023-02-20 10:36:45 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:36:45 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:36:45 --> Utf8 Class Initialized
INFO - 2023-02-20 10:36:45 --> URI Class Initialized
INFO - 2023-02-20 10:36:45 --> Router Class Initialized
INFO - 2023-02-20 10:36:45 --> Output Class Initialized
INFO - 2023-02-20 10:36:45 --> Security Class Initialized
DEBUG - 2023-02-20 10:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:36:45 --> Input Class Initialized
INFO - 2023-02-20 10:36:45 --> Language Class Initialized
INFO - 2023-02-20 10:36:45 --> Loader Class Initialized
INFO - 2023-02-20 10:36:45 --> Controller Class Initialized
DEBUG - 2023-02-20 10:36:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:36:45 --> Database Driver Class Initialized
INFO - 2023-02-20 10:36:45 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:36:45 --> Final output sent to browser
DEBUG - 2023-02-20 10:36:45 --> Total execution time: 0.0465
INFO - 2023-02-20 10:36:51 --> Config Class Initialized
INFO - 2023-02-20 10:36:51 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:36:51 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:36:51 --> Utf8 Class Initialized
INFO - 2023-02-20 10:36:51 --> URI Class Initialized
INFO - 2023-02-20 10:36:51 --> Router Class Initialized
INFO - 2023-02-20 10:36:51 --> Output Class Initialized
INFO - 2023-02-20 10:36:51 --> Security Class Initialized
DEBUG - 2023-02-20 10:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:36:51 --> Input Class Initialized
INFO - 2023-02-20 10:36:51 --> Language Class Initialized
INFO - 2023-02-20 10:36:51 --> Loader Class Initialized
INFO - 2023-02-20 10:36:51 --> Controller Class Initialized
DEBUG - 2023-02-20 10:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:36:51 --> Database Driver Class Initialized
INFO - 2023-02-20 10:36:51 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:36:51 --> Final output sent to browser
DEBUG - 2023-02-20 10:36:51 --> Total execution time: 0.0868
INFO - 2023-02-20 10:36:51 --> Config Class Initialized
INFO - 2023-02-20 10:36:51 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:36:51 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:36:51 --> Utf8 Class Initialized
INFO - 2023-02-20 10:36:51 --> URI Class Initialized
INFO - 2023-02-20 10:36:51 --> Router Class Initialized
INFO - 2023-02-20 10:36:51 --> Output Class Initialized
INFO - 2023-02-20 10:36:51 --> Security Class Initialized
DEBUG - 2023-02-20 10:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:36:51 --> Input Class Initialized
INFO - 2023-02-20 10:36:51 --> Language Class Initialized
INFO - 2023-02-20 10:36:51 --> Loader Class Initialized
INFO - 2023-02-20 10:36:51 --> Controller Class Initialized
DEBUG - 2023-02-20 10:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:36:51 --> Database Driver Class Initialized
INFO - 2023-02-20 10:36:51 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:36:51 --> Final output sent to browser
DEBUG - 2023-02-20 10:36:51 --> Total execution time: 0.1253
INFO - 2023-02-20 10:45:01 --> Config Class Initialized
INFO - 2023-02-20 10:45:01 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:01 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:01 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:01 --> URI Class Initialized
INFO - 2023-02-20 10:45:01 --> Router Class Initialized
INFO - 2023-02-20 10:45:01 --> Output Class Initialized
INFO - 2023-02-20 10:45:01 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:01 --> Input Class Initialized
INFO - 2023-02-20 10:45:01 --> Language Class Initialized
INFO - 2023-02-20 10:45:01 --> Loader Class Initialized
INFO - 2023-02-20 10:45:01 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:01 --> Database Driver Class Initialized
INFO - 2023-02-20 10:45:01 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:45:01 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:01 --> Total execution time: 0.0173
INFO - 2023-02-20 10:45:01 --> Config Class Initialized
INFO - 2023-02-20 10:45:01 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:01 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:01 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:01 --> URI Class Initialized
INFO - 2023-02-20 10:45:01 --> Router Class Initialized
INFO - 2023-02-20 10:45:01 --> Output Class Initialized
INFO - 2023-02-20 10:45:01 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:01 --> Input Class Initialized
INFO - 2023-02-20 10:45:01 --> Language Class Initialized
INFO - 2023-02-20 10:45:01 --> Loader Class Initialized
INFO - 2023-02-20 10:45:01 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:01 --> Database Driver Class Initialized
INFO - 2023-02-20 10:45:01 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:45:01 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:01 --> Total execution time: 0.0110
INFO - 2023-02-20 10:45:04 --> Config Class Initialized
INFO - 2023-02-20 10:45:04 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:04 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:04 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:04 --> URI Class Initialized
INFO - 2023-02-20 10:45:04 --> Router Class Initialized
INFO - 2023-02-20 10:45:04 --> Output Class Initialized
INFO - 2023-02-20 10:45:04 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:04 --> Input Class Initialized
INFO - 2023-02-20 10:45:04 --> Language Class Initialized
INFO - 2023-02-20 10:45:04 --> Loader Class Initialized
INFO - 2023-02-20 10:45:04 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:04 --> Database Driver Class Initialized
INFO - 2023-02-20 10:45:04 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:45:04 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:04 --> Total execution time: 0.0195
INFO - 2023-02-20 10:45:04 --> Config Class Initialized
INFO - 2023-02-20 10:45:04 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:04 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:04 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:04 --> URI Class Initialized
INFO - 2023-02-20 10:45:04 --> Router Class Initialized
INFO - 2023-02-20 10:45:04 --> Output Class Initialized
INFO - 2023-02-20 10:45:04 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:04 --> Input Class Initialized
INFO - 2023-02-20 10:45:04 --> Language Class Initialized
INFO - 2023-02-20 10:45:04 --> Loader Class Initialized
INFO - 2023-02-20 10:45:04 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:04 --> Database Driver Class Initialized
INFO - 2023-02-20 10:45:04 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:45:04 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:04 --> Total execution time: 0.0577
INFO - 2023-02-20 10:45:11 --> Config Class Initialized
INFO - 2023-02-20 10:45:11 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:11 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:11 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:11 --> URI Class Initialized
INFO - 2023-02-20 10:45:11 --> Router Class Initialized
INFO - 2023-02-20 10:45:11 --> Output Class Initialized
INFO - 2023-02-20 10:45:11 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:11 --> Input Class Initialized
INFO - 2023-02-20 10:45:11 --> Language Class Initialized
INFO - 2023-02-20 10:45:11 --> Loader Class Initialized
INFO - 2023-02-20 10:45:11 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:11 --> Database Driver Class Initialized
INFO - 2023-02-20 10:45:11 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:45:11 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:11 --> Total execution time: 0.0182
INFO - 2023-02-20 10:45:11 --> Config Class Initialized
INFO - 2023-02-20 10:45:11 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:11 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:11 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:11 --> URI Class Initialized
INFO - 2023-02-20 10:45:11 --> Router Class Initialized
INFO - 2023-02-20 10:45:11 --> Output Class Initialized
INFO - 2023-02-20 10:45:11 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:11 --> Input Class Initialized
INFO - 2023-02-20 10:45:11 --> Language Class Initialized
INFO - 2023-02-20 10:45:11 --> Loader Class Initialized
INFO - 2023-02-20 10:45:11 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:11 --> Database Driver Class Initialized
INFO - 2023-02-20 10:45:11 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:45:11 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:11 --> Total execution time: 0.0141
INFO - 2023-02-20 10:45:17 --> Config Class Initialized
INFO - 2023-02-20 10:45:17 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:17 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:17 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:17 --> URI Class Initialized
INFO - 2023-02-20 10:45:17 --> Router Class Initialized
INFO - 2023-02-20 10:45:17 --> Output Class Initialized
INFO - 2023-02-20 10:45:17 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:17 --> Input Class Initialized
INFO - 2023-02-20 10:45:17 --> Language Class Initialized
INFO - 2023-02-20 10:45:17 --> Loader Class Initialized
INFO - 2023-02-20 10:45:17 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:17 --> Database Driver Class Initialized
INFO - 2023-02-20 10:45:17 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:45:17 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:17 --> Total execution time: 0.0197
INFO - 2023-02-20 10:45:17 --> Config Class Initialized
INFO - 2023-02-20 10:45:17 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:17 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:17 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:17 --> URI Class Initialized
INFO - 2023-02-20 10:45:17 --> Router Class Initialized
INFO - 2023-02-20 10:45:17 --> Output Class Initialized
INFO - 2023-02-20 10:45:17 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:17 --> Input Class Initialized
INFO - 2023-02-20 10:45:17 --> Language Class Initialized
INFO - 2023-02-20 10:45:17 --> Loader Class Initialized
INFO - 2023-02-20 10:45:17 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:17 --> Database Driver Class Initialized
INFO - 2023-02-20 10:45:17 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:45:17 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:17 --> Total execution time: 0.0178
INFO - 2023-02-20 10:45:32 --> Config Class Initialized
INFO - 2023-02-20 10:45:32 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:32 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:32 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:32 --> URI Class Initialized
INFO - 2023-02-20 10:45:32 --> Router Class Initialized
INFO - 2023-02-20 10:45:32 --> Output Class Initialized
INFO - 2023-02-20 10:45:32 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:32 --> Input Class Initialized
INFO - 2023-02-20 10:45:32 --> Language Class Initialized
INFO - 2023-02-20 10:45:32 --> Loader Class Initialized
INFO - 2023-02-20 10:45:32 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:32 --> Database Driver Class Initialized
INFO - 2023-02-20 10:45:32 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:45:32 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:32 --> Total execution time: 0.0236
INFO - 2023-02-20 10:45:32 --> Config Class Initialized
INFO - 2023-02-20 10:45:32 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:32 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:32 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:32 --> URI Class Initialized
INFO - 2023-02-20 10:45:32 --> Router Class Initialized
INFO - 2023-02-20 10:45:32 --> Output Class Initialized
INFO - 2023-02-20 10:45:32 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:32 --> Input Class Initialized
INFO - 2023-02-20 10:45:32 --> Language Class Initialized
INFO - 2023-02-20 10:45:32 --> Loader Class Initialized
INFO - 2023-02-20 10:45:32 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:32 --> Database Driver Class Initialized
INFO - 2023-02-20 10:45:32 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:45:32 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:32 --> Total execution time: 0.0661
INFO - 2023-02-20 10:45:35 --> Config Class Initialized
INFO - 2023-02-20 10:45:35 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:35 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:35 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:35 --> URI Class Initialized
INFO - 2023-02-20 10:45:35 --> Router Class Initialized
INFO - 2023-02-20 10:45:35 --> Output Class Initialized
INFO - 2023-02-20 10:45:35 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:35 --> Input Class Initialized
INFO - 2023-02-20 10:45:35 --> Language Class Initialized
INFO - 2023-02-20 10:45:35 --> Loader Class Initialized
INFO - 2023-02-20 10:45:35 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:35 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:35 --> Total execution time: 0.0468
INFO - 2023-02-20 10:45:35 --> Config Class Initialized
INFO - 2023-02-20 10:45:35 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:35 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:35 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:35 --> URI Class Initialized
INFO - 2023-02-20 10:45:35 --> Router Class Initialized
INFO - 2023-02-20 10:45:35 --> Output Class Initialized
INFO - 2023-02-20 10:45:35 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:35 --> Input Class Initialized
INFO - 2023-02-20 10:45:35 --> Language Class Initialized
INFO - 2023-02-20 10:45:35 --> Loader Class Initialized
INFO - 2023-02-20 10:45:35 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:35 --> Database Driver Class Initialized
INFO - 2023-02-20 10:45:35 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:45:35 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:35 --> Total execution time: 0.0569
INFO - 2023-02-20 10:45:38 --> Config Class Initialized
INFO - 2023-02-20 10:45:38 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:38 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:38 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:38 --> URI Class Initialized
INFO - 2023-02-20 10:45:38 --> Router Class Initialized
INFO - 2023-02-20 10:45:38 --> Output Class Initialized
INFO - 2023-02-20 10:45:38 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:38 --> Input Class Initialized
INFO - 2023-02-20 10:45:38 --> Language Class Initialized
INFO - 2023-02-20 10:45:38 --> Loader Class Initialized
INFO - 2023-02-20 10:45:38 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:38 --> Database Driver Class Initialized
INFO - 2023-02-20 10:45:38 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:45:38 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:38 --> Total execution time: 0.0212
INFO - 2023-02-20 10:45:38 --> Config Class Initialized
INFO - 2023-02-20 10:45:38 --> Hooks Class Initialized
DEBUG - 2023-02-20 10:45:38 --> UTF-8 Support Enabled
INFO - 2023-02-20 10:45:38 --> Utf8 Class Initialized
INFO - 2023-02-20 10:45:38 --> URI Class Initialized
INFO - 2023-02-20 10:45:38 --> Router Class Initialized
INFO - 2023-02-20 10:45:38 --> Output Class Initialized
INFO - 2023-02-20 10:45:38 --> Security Class Initialized
DEBUG - 2023-02-20 10:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 10:45:38 --> Input Class Initialized
INFO - 2023-02-20 10:45:38 --> Language Class Initialized
INFO - 2023-02-20 10:45:38 --> Loader Class Initialized
INFO - 2023-02-20 10:45:38 --> Controller Class Initialized
DEBUG - 2023-02-20 10:45:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 10:45:38 --> Database Driver Class Initialized
INFO - 2023-02-20 10:45:38 --> Model "Cluster_model" initialized
INFO - 2023-02-20 10:45:38 --> Final output sent to browser
DEBUG - 2023-02-20 10:45:38 --> Total execution time: 0.0591
INFO - 2023-02-20 13:09:42 --> Config Class Initialized
INFO - 2023-02-20 13:09:42 --> Hooks Class Initialized
DEBUG - 2023-02-20 13:09:42 --> UTF-8 Support Enabled
INFO - 2023-02-20 13:09:42 --> Utf8 Class Initialized
INFO - 2023-02-20 13:09:42 --> URI Class Initialized
INFO - 2023-02-20 13:09:42 --> Router Class Initialized
INFO - 2023-02-20 13:09:42 --> Output Class Initialized
INFO - 2023-02-20 13:09:42 --> Security Class Initialized
DEBUG - 2023-02-20 13:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 13:09:42 --> Input Class Initialized
INFO - 2023-02-20 13:09:42 --> Language Class Initialized
INFO - 2023-02-20 13:09:42 --> Loader Class Initialized
INFO - 2023-02-20 13:09:42 --> Controller Class Initialized
DEBUG - 2023-02-20 13:09:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 13:09:42 --> Database Driver Class Initialized
INFO - 2023-02-20 13:09:44 --> Config Class Initialized
INFO - 2023-02-20 13:09:44 --> Hooks Class Initialized
INFO - 2023-02-20 13:09:44 --> Config Class Initialized
INFO - 2023-02-20 13:09:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 13:09:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 13:09:44 --> Utf8 Class Initialized
DEBUG - 2023-02-20 13:09:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 13:09:44 --> URI Class Initialized
INFO - 2023-02-20 13:09:44 --> Utf8 Class Initialized
INFO - 2023-02-20 13:09:44 --> Router Class Initialized
INFO - 2023-02-20 13:09:44 --> URI Class Initialized
INFO - 2023-02-20 13:09:44 --> Output Class Initialized
INFO - 2023-02-20 13:09:44 --> Router Class Initialized
INFO - 2023-02-20 13:09:44 --> Security Class Initialized
INFO - 2023-02-20 13:09:44 --> Output Class Initialized
DEBUG - 2023-02-20 13:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 13:09:44 --> Security Class Initialized
INFO - 2023-02-20 13:09:44 --> Input Class Initialized
DEBUG - 2023-02-20 13:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 13:09:44 --> Language Class Initialized
INFO - 2023-02-20 13:09:44 --> Input Class Initialized
INFO - 2023-02-20 13:09:44 --> Language Class Initialized
INFO - 2023-02-20 13:09:44 --> Loader Class Initialized
INFO - 2023-02-20 13:09:44 --> Controller Class Initialized
DEBUG - 2023-02-20 13:09:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 13:09:44 --> Loader Class Initialized
INFO - 2023-02-20 13:09:44 --> Final output sent to browser
INFO - 2023-02-20 13:09:44 --> Controller Class Initialized
DEBUG - 2023-02-20 13:09:44 --> Total execution time: 0.0055
DEBUG - 2023-02-20 13:09:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 13:09:44 --> Database Driver Class Initialized
INFO - 2023-02-20 13:09:44 --> Config Class Initialized
INFO - 2023-02-20 13:09:44 --> Hooks Class Initialized
DEBUG - 2023-02-20 13:09:44 --> UTF-8 Support Enabled
INFO - 2023-02-20 13:09:44 --> Utf8 Class Initialized
INFO - 2023-02-20 13:09:44 --> URI Class Initialized
INFO - 2023-02-20 13:09:44 --> Router Class Initialized
INFO - 2023-02-20 13:09:44 --> Output Class Initialized
INFO - 2023-02-20 13:09:44 --> Security Class Initialized
DEBUG - 2023-02-20 13:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-20 13:09:44 --> Input Class Initialized
INFO - 2023-02-20 13:09:44 --> Language Class Initialized
INFO - 2023-02-20 13:09:44 --> Loader Class Initialized
INFO - 2023-02-20 13:09:44 --> Controller Class Initialized
DEBUG - 2023-02-20 13:09:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-20 13:09:44 --> Database Driver Class Initialized
ERROR - 2023-02-20 13:09:52 --> Unable to connect to the database
INFO - 2023-02-20 13:09:52 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-02-20 13:09:54 --> Unable to connect to the database
INFO - 2023-02-20 13:09:54 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-02-20 13:09:54 --> Unable to connect to the database
INFO - 2023-02-20 13:09:54 --> Model "Login_model" initialized
ERROR - 2023-02-20 13:10:04 --> Unable to connect to the database
ERROR - 2023-02-20 13:10:04 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' group by id;
INFO - 2023-02-20 13:10:04 --> Final output sent to browser
DEBUG - 2023-02-20 13:10:04 --> Total execution time: 20.0518
