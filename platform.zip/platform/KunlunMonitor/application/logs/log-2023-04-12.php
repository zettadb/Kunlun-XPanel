<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-12 01:41:26 --> Config Class Initialized
INFO - 2023-04-12 01:41:26 --> Hooks Class Initialized
DEBUG - 2023-04-12 01:41:26 --> UTF-8 Support Enabled
INFO - 2023-04-12 01:41:26 --> Utf8 Class Initialized
INFO - 2023-04-12 01:41:26 --> URI Class Initialized
INFO - 2023-04-12 01:41:26 --> Router Class Initialized
INFO - 2023-04-12 01:41:26 --> Output Class Initialized
INFO - 2023-04-12 01:41:26 --> Security Class Initialized
DEBUG - 2023-04-12 01:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-12 01:41:26 --> Input Class Initialized
INFO - 2023-04-12 01:41:26 --> Language Class Initialized
INFO - 2023-04-12 01:41:26 --> Loader Class Initialized
INFO - 2023-04-12 01:41:26 --> Controller Class Initialized
INFO - 2023-04-12 01:41:26 --> Helper loaded: form_helper
INFO - 2023-04-12 01:41:26 --> Helper loaded: url_helper
DEBUG - 2023-04-12 01:41:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-12 01:41:26 --> Model "Change_model" initialized
INFO - 2023-04-12 01:41:26 --> Model "Grafana_model" initialized
INFO - 2023-04-12 01:41:26 --> Final output sent to browser
DEBUG - 2023-04-12 01:41:26 --> Total execution time: 0.0516
INFO - 2023-04-12 01:41:26 --> Config Class Initialized
INFO - 2023-04-12 01:41:26 --> Hooks Class Initialized
DEBUG - 2023-04-12 01:41:26 --> UTF-8 Support Enabled
INFO - 2023-04-12 01:41:26 --> Utf8 Class Initialized
INFO - 2023-04-12 01:41:26 --> URI Class Initialized
INFO - 2023-04-12 01:41:26 --> Router Class Initialized
INFO - 2023-04-12 01:41:26 --> Output Class Initialized
INFO - 2023-04-12 01:41:26 --> Security Class Initialized
DEBUG - 2023-04-12 01:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-12 01:41:26 --> Input Class Initialized
INFO - 2023-04-12 01:41:26 --> Language Class Initialized
INFO - 2023-04-12 01:41:26 --> Loader Class Initialized
INFO - 2023-04-12 01:41:26 --> Controller Class Initialized
INFO - 2023-04-12 01:41:26 --> Helper loaded: form_helper
INFO - 2023-04-12 01:41:26 --> Helper loaded: url_helper
DEBUG - 2023-04-12 01:41:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-12 01:41:26 --> Final output sent to browser
DEBUG - 2023-04-12 01:41:26 --> Total execution time: 0.0034
INFO - 2023-04-12 01:41:26 --> Config Class Initialized
INFO - 2023-04-12 01:41:26 --> Hooks Class Initialized
DEBUG - 2023-04-12 01:41:26 --> UTF-8 Support Enabled
INFO - 2023-04-12 01:41:26 --> Utf8 Class Initialized
INFO - 2023-04-12 01:41:26 --> URI Class Initialized
INFO - 2023-04-12 01:41:26 --> Router Class Initialized
INFO - 2023-04-12 01:41:26 --> Output Class Initialized
INFO - 2023-04-12 01:41:26 --> Security Class Initialized
DEBUG - 2023-04-12 01:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-12 01:41:26 --> Input Class Initialized
INFO - 2023-04-12 01:41:26 --> Language Class Initialized
INFO - 2023-04-12 01:41:26 --> Loader Class Initialized
INFO - 2023-04-12 01:41:26 --> Controller Class Initialized
INFO - 2023-04-12 01:41:26 --> Helper loaded: form_helper
INFO - 2023-04-12 01:41:26 --> Helper loaded: url_helper
DEBUG - 2023-04-12 01:41:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-12 01:41:26 --> Database Driver Class Initialized
INFO - 2023-04-12 01:41:26 --> Model "Login_model" initialized
INFO - 2023-04-12 01:41:26 --> Final output sent to browser
DEBUG - 2023-04-12 01:41:26 --> Total execution time: 0.0191
INFO - 2023-04-12 01:41:26 --> Config Class Initialized
INFO - 2023-04-12 01:41:26 --> Hooks Class Initialized
DEBUG - 2023-04-12 01:41:26 --> UTF-8 Support Enabled
INFO - 2023-04-12 01:41:26 --> Utf8 Class Initialized
INFO - 2023-04-12 01:41:26 --> URI Class Initialized
INFO - 2023-04-12 01:41:26 --> Router Class Initialized
INFO - 2023-04-12 01:41:26 --> Output Class Initialized
INFO - 2023-04-12 01:41:26 --> Security Class Initialized
DEBUG - 2023-04-12 01:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-12 01:41:26 --> Input Class Initialized
INFO - 2023-04-12 01:41:26 --> Language Class Initialized
INFO - 2023-04-12 01:41:26 --> Loader Class Initialized
INFO - 2023-04-12 01:41:26 --> Controller Class Initialized
DEBUG - 2023-04-12 01:41:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-12 01:41:26 --> Database Driver Class Initialized
INFO - 2023-04-12 01:41:26 --> Model "Cluster_model" initialized
INFO - 2023-04-12 01:41:26 --> Final output sent to browser
DEBUG - 2023-04-12 01:41:26 --> Total execution time: 0.0129
INFO - 2023-04-12 01:41:26 --> Config Class Initialized
INFO - 2023-04-12 01:41:26 --> Hooks Class Initialized
DEBUG - 2023-04-12 01:41:26 --> UTF-8 Support Enabled
INFO - 2023-04-12 01:41:26 --> Utf8 Class Initialized
INFO - 2023-04-12 01:41:26 --> URI Class Initialized
INFO - 2023-04-12 01:41:26 --> Router Class Initialized
INFO - 2023-04-12 01:41:26 --> Output Class Initialized
INFO - 2023-04-12 01:41:26 --> Security Class Initialized
DEBUG - 2023-04-12 01:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-12 01:41:26 --> Input Class Initialized
INFO - 2023-04-12 01:41:26 --> Language Class Initialized
INFO - 2023-04-12 01:41:26 --> Loader Class Initialized
INFO - 2023-04-12 01:41:26 --> Controller Class Initialized
DEBUG - 2023-04-12 01:41:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-12 01:41:26 --> Database Driver Class Initialized
INFO - 2023-04-12 01:41:26 --> Model "Cluster_model" initialized
INFO - 2023-04-12 01:41:26 --> Final output sent to browser
DEBUG - 2023-04-12 01:41:26 --> Total execution time: 0.0146
INFO - 2023-04-12 01:41:27 --> Config Class Initialized
INFO - 2023-04-12 01:41:27 --> Hooks Class Initialized
DEBUG - 2023-04-12 01:41:27 --> UTF-8 Support Enabled
INFO - 2023-04-12 01:41:27 --> Utf8 Class Initialized
INFO - 2023-04-12 01:41:27 --> URI Class Initialized
INFO - 2023-04-12 01:41:27 --> Router Class Initialized
INFO - 2023-04-12 01:41:27 --> Output Class Initialized
INFO - 2023-04-12 01:41:27 --> Security Class Initialized
DEBUG - 2023-04-12 01:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-12 01:41:27 --> Input Class Initialized
INFO - 2023-04-12 01:41:27 --> Language Class Initialized
INFO - 2023-04-12 01:41:27 --> Loader Class Initialized
INFO - 2023-04-12 01:41:27 --> Controller Class Initialized
DEBUG - 2023-04-12 01:41:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-12 01:41:27 --> Database Driver Class Initialized
INFO - 2023-04-12 01:41:27 --> Model "Cluster_model" initialized
INFO - 2023-04-12 01:41:27 --> Database Driver Class Initialized
INFO - 2023-04-12 01:41:27 --> Model "Login_model" initialized
INFO - 2023-04-12 01:41:27 --> Final output sent to browser
DEBUG - 2023-04-12 01:41:27 --> Total execution time: 0.1459
INFO - 2023-04-12 01:41:27 --> Config Class Initialized
INFO - 2023-04-12 01:41:27 --> Hooks Class Initialized
DEBUG - 2023-04-12 01:41:27 --> UTF-8 Support Enabled
INFO - 2023-04-12 01:41:27 --> Utf8 Class Initialized
INFO - 2023-04-12 01:41:27 --> URI Class Initialized
INFO - 2023-04-12 01:41:27 --> Router Class Initialized
INFO - 2023-04-12 01:41:27 --> Output Class Initialized
INFO - 2023-04-12 01:41:27 --> Security Class Initialized
DEBUG - 2023-04-12 01:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-12 01:41:27 --> Input Class Initialized
INFO - 2023-04-12 01:41:27 --> Language Class Initialized
INFO - 2023-04-12 01:41:27 --> Loader Class Initialized
INFO - 2023-04-12 01:41:27 --> Controller Class Initialized
DEBUG - 2023-04-12 01:41:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-12 01:41:27 --> Database Driver Class Initialized
INFO - 2023-04-12 01:41:27 --> Model "Cluster_model" initialized
INFO - 2023-04-12 01:41:27 --> Database Driver Class Initialized
INFO - 2023-04-12 01:41:27 --> Model "Login_model" initialized
INFO - 2023-04-12 01:41:27 --> Final output sent to browser
DEBUG - 2023-04-12 01:41:27 --> Total execution time: 0.1506
INFO - 2023-04-12 01:41:30 --> Config Class Initialized
INFO - 2023-04-12 01:41:30 --> Hooks Class Initialized
DEBUG - 2023-04-12 01:41:30 --> UTF-8 Support Enabled
INFO - 2023-04-12 01:41:30 --> Utf8 Class Initialized
INFO - 2023-04-12 01:41:30 --> URI Class Initialized
INFO - 2023-04-12 01:41:30 --> Router Class Initialized
INFO - 2023-04-12 01:41:30 --> Output Class Initialized
INFO - 2023-04-12 01:41:30 --> Security Class Initialized
DEBUG - 2023-04-12 01:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-12 01:41:30 --> Input Class Initialized
INFO - 2023-04-12 01:41:30 --> Language Class Initialized
INFO - 2023-04-12 01:41:30 --> Loader Class Initialized
INFO - 2023-04-12 01:41:30 --> Controller Class Initialized
DEBUG - 2023-04-12 01:41:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-12 01:41:30 --> Database Driver Class Initialized
INFO - 2023-04-12 01:41:30 --> Model "Cluster_model" initialized
INFO - 2023-04-12 01:41:30 --> Final output sent to browser
DEBUG - 2023-04-12 01:41:30 --> Total execution time: 0.1010
INFO - 2023-04-12 01:41:30 --> Config Class Initialized
INFO - 2023-04-12 01:41:30 --> Hooks Class Initialized
DEBUG - 2023-04-12 01:41:30 --> UTF-8 Support Enabled
INFO - 2023-04-12 01:41:30 --> Utf8 Class Initialized
INFO - 2023-04-12 01:41:30 --> URI Class Initialized
INFO - 2023-04-12 01:41:30 --> Router Class Initialized
INFO - 2023-04-12 01:41:30 --> Output Class Initialized
INFO - 2023-04-12 01:41:30 --> Security Class Initialized
DEBUG - 2023-04-12 01:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-12 01:41:30 --> Input Class Initialized
INFO - 2023-04-12 01:41:30 --> Language Class Initialized
INFO - 2023-04-12 01:41:30 --> Loader Class Initialized
INFO - 2023-04-12 01:41:30 --> Controller Class Initialized
DEBUG - 2023-04-12 01:41:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-12 01:41:30 --> Database Driver Class Initialized
INFO - 2023-04-12 01:41:30 --> Model "Cluster_model" initialized
INFO - 2023-04-12 01:41:30 --> Final output sent to browser
DEBUG - 2023-04-12 01:41:30 --> Total execution time: 0.0520
INFO - 2023-04-12 01:43:52 --> Config Class Initialized
INFO - 2023-04-12 01:43:52 --> Hooks Class Initialized
DEBUG - 2023-04-12 01:43:52 --> UTF-8 Support Enabled
INFO - 2023-04-12 01:43:52 --> Utf8 Class Initialized
INFO - 2023-04-12 01:43:52 --> URI Class Initialized
INFO - 2023-04-12 01:43:52 --> Router Class Initialized
INFO - 2023-04-12 01:43:52 --> Output Class Initialized
INFO - 2023-04-12 01:43:52 --> Security Class Initialized
DEBUG - 2023-04-12 01:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-12 01:43:52 --> Input Class Initialized
INFO - 2023-04-12 01:43:52 --> Language Class Initialized
INFO - 2023-04-12 01:43:52 --> Loader Class Initialized
INFO - 2023-04-12 01:43:52 --> Controller Class Initialized
DEBUG - 2023-04-12 01:43:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-12 01:43:52 --> Database Driver Class Initialized
INFO - 2023-04-12 01:43:52 --> Model "Cluster_model" initialized
INFO - 2023-04-12 01:43:52 --> Final output sent to browser
DEBUG - 2023-04-12 01:43:52 --> Total execution time: 0.0470
INFO - 2023-04-12 01:43:52 --> Config Class Initialized
INFO - 2023-04-12 01:43:52 --> Hooks Class Initialized
DEBUG - 2023-04-12 01:43:52 --> UTF-8 Support Enabled
INFO - 2023-04-12 01:43:52 --> Utf8 Class Initialized
INFO - 2023-04-12 01:43:52 --> URI Class Initialized
INFO - 2023-04-12 01:43:52 --> Router Class Initialized
INFO - 2023-04-12 01:43:52 --> Output Class Initialized
INFO - 2023-04-12 01:43:52 --> Security Class Initialized
DEBUG - 2023-04-12 01:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-12 01:43:52 --> Input Class Initialized
INFO - 2023-04-12 01:43:52 --> Language Class Initialized
INFO - 2023-04-12 01:43:52 --> Loader Class Initialized
INFO - 2023-04-12 01:43:52 --> Controller Class Initialized
DEBUG - 2023-04-12 01:43:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-12 01:43:52 --> Database Driver Class Initialized
INFO - 2023-04-12 01:43:52 --> Model "Cluster_model" initialized
INFO - 2023-04-12 01:43:52 --> Final output sent to browser
DEBUG - 2023-04-12 01:43:52 --> Total execution time: 0.0865
