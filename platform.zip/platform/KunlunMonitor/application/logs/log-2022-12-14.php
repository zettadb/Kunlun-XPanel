<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-12-14 02:47:27 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-12-14 02:47:27 --> Config Class Initialized
INFO - 2022-12-14 02:47:27 --> Hooks Class Initialized
INFO - 2022-12-14 02:47:27 --> Hooks Class Initialized
DEBUG - 2022-12-14 02:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-14 02:47:27 --> UTF-8 Support Enabled
INFO - 2022-12-14 02:47:27 --> Utf8 Class Initialized
INFO - 2022-12-14 02:47:27 --> Utf8 Class Initialized
INFO - 2022-12-14 02:47:27 --> URI Class Initialized
INFO - 2022-12-14 02:47:27 --> URI Class Initialized
INFO - 2022-12-14 02:47:27 --> Router Class Initialized
INFO - 2022-12-14 02:47:27 --> Router Class Initialized
INFO - 2022-12-14 02:47:27 --> Output Class Initialized
INFO - 2022-12-14 02:47:27 --> Output Class Initialized
INFO - 2022-12-14 02:47:27 --> Security Class Initialized
INFO - 2022-12-14 02:47:27 --> Security Class Initialized
DEBUG - 2022-12-14 02:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-14 02:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 02:47:27 --> Input Class Initialized
INFO - 2022-12-14 02:47:27 --> Input Class Initialized
INFO - 2022-12-14 02:47:27 --> Language Class Initialized
INFO - 2022-12-14 02:47:27 --> Language Class Initialized
INFO - 2022-12-14 02:47:27 --> Loader Class Initialized
INFO - 2022-12-14 02:47:27 --> Controller Class Initialized
DEBUG - 2022-12-14 02:47:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 02:47:27 --> Final output sent to browser
DEBUG - 2022-12-14 02:47:27 --> Total execution time: 0.0582
INFO - 2022-12-14 02:47:27 --> Loader Class Initialized
INFO - 2022-12-14 02:47:27 --> Controller Class Initialized
DEBUG - 2022-12-14 02:47:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 02:47:27 --> Config Class Initialized
INFO - 2022-12-14 02:47:27 --> Hooks Class Initialized
INFO - 2022-12-14 02:47:27 --> Database Driver Class Initialized
DEBUG - 2022-12-14 02:47:27 --> UTF-8 Support Enabled
INFO - 2022-12-14 02:47:27 --> Utf8 Class Initialized
INFO - 2022-12-14 02:47:27 --> URI Class Initialized
INFO - 2022-12-14 02:47:27 --> Router Class Initialized
INFO - 2022-12-14 02:47:27 --> Output Class Initialized
INFO - 2022-12-14 02:47:27 --> Security Class Initialized
DEBUG - 2022-12-14 02:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 02:47:27 --> Input Class Initialized
INFO - 2022-12-14 02:47:27 --> Language Class Initialized
INFO - 2022-12-14 02:47:27 --> Loader Class Initialized
INFO - 2022-12-14 02:47:27 --> Controller Class Initialized
DEBUG - 2022-12-14 02:47:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 02:47:27 --> Database Driver Class Initialized
INFO - 2022-12-14 02:47:27 --> Model "Cluster_model" initialized
INFO - 2022-12-14 02:47:27 --> Model "Login_model" initialized
INFO - 2022-12-14 02:47:27 --> Final output sent to browser
DEBUG - 2022-12-14 02:47:27 --> Total execution time: 0.1438
INFO - 2022-12-14 02:47:27 --> Config Class Initialized
INFO - 2022-12-14 02:47:27 --> Hooks Class Initialized
INFO - 2022-12-14 02:47:27 --> Database Driver Class Initialized
DEBUG - 2022-12-14 02:47:27 --> UTF-8 Support Enabled
INFO - 2022-12-14 02:47:27 --> Utf8 Class Initialized
INFO - 2022-12-14 02:47:27 --> URI Class Initialized
INFO - 2022-12-14 02:47:27 --> Router Class Initialized
INFO - 2022-12-14 02:47:27 --> Output Class Initialized
INFO - 2022-12-14 02:47:27 --> Security Class Initialized
DEBUG - 2022-12-14 02:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 02:47:27 --> Input Class Initialized
INFO - 2022-12-14 02:47:27 --> Language Class Initialized
INFO - 2022-12-14 02:47:27 --> Loader Class Initialized
INFO - 2022-12-14 02:47:27 --> Controller Class Initialized
DEBUG - 2022-12-14 02:47:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 02:47:27 --> Database Driver Class Initialized
INFO - 2022-12-14 02:47:27 --> Model "Cluster_model" initialized
INFO - 2022-12-14 02:47:27 --> Final output sent to browser
DEBUG - 2022-12-14 02:47:27 --> Total execution time: 0.1341
INFO - 2022-12-14 02:47:27 --> Model "Cluster_model" initialized
INFO - 2022-12-14 02:47:27 --> Final output sent to browser
DEBUG - 2022-12-14 02:47:27 --> Total execution time: 0.2899
INFO - 2022-12-14 03:56:42 --> Config Class Initialized
INFO - 2022-12-14 03:56:42 --> Hooks Class Initialized
DEBUG - 2022-12-14 03:56:42 --> UTF-8 Support Enabled
INFO - 2022-12-14 03:56:42 --> Utf8 Class Initialized
INFO - 2022-12-14 03:56:42 --> URI Class Initialized
INFO - 2022-12-14 03:56:42 --> Router Class Initialized
INFO - 2022-12-14 03:56:42 --> Output Class Initialized
INFO - 2022-12-14 03:56:42 --> Security Class Initialized
DEBUG - 2022-12-14 03:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 03:56:42 --> Input Class Initialized
INFO - 2022-12-14 03:56:42 --> Language Class Initialized
INFO - 2022-12-14 03:56:43 --> Loader Class Initialized
INFO - 2022-12-14 03:56:43 --> Controller Class Initialized
DEBUG - 2022-12-14 03:56:43 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 03:56:43 --> Database Driver Class Initialized
INFO - 2022-12-14 03:56:43 --> Model "Cluster_model" initialized
INFO - 2022-12-14 03:56:43 --> Final output sent to browser
DEBUG - 2022-12-14 03:56:43 --> Total execution time: 0.0766
INFO - 2022-12-14 03:56:43 --> Config Class Initialized
INFO - 2022-12-14 03:56:43 --> Hooks Class Initialized
DEBUG - 2022-12-14 03:56:43 --> UTF-8 Support Enabled
INFO - 2022-12-14 03:56:43 --> Utf8 Class Initialized
INFO - 2022-12-14 03:56:43 --> URI Class Initialized
INFO - 2022-12-14 03:56:43 --> Router Class Initialized
INFO - 2022-12-14 03:56:43 --> Output Class Initialized
INFO - 2022-12-14 03:56:43 --> Security Class Initialized
DEBUG - 2022-12-14 03:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 03:56:43 --> Input Class Initialized
INFO - 2022-12-14 03:56:43 --> Language Class Initialized
INFO - 2022-12-14 03:56:43 --> Loader Class Initialized
INFO - 2022-12-14 03:56:43 --> Controller Class Initialized
DEBUG - 2022-12-14 03:56:43 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 03:56:43 --> Database Driver Class Initialized
INFO - 2022-12-14 03:56:43 --> Model "Cluster_model" initialized
INFO - 2022-12-14 03:56:43 --> Final output sent to browser
DEBUG - 2022-12-14 03:56:43 --> Total execution time: 0.0404
INFO - 2022-12-14 03:56:45 --> Config Class Initialized
INFO - 2022-12-14 03:56:45 --> Hooks Class Initialized
DEBUG - 2022-12-14 03:56:45 --> UTF-8 Support Enabled
INFO - 2022-12-14 03:56:45 --> Utf8 Class Initialized
INFO - 2022-12-14 03:56:45 --> URI Class Initialized
INFO - 2022-12-14 03:56:45 --> Router Class Initialized
INFO - 2022-12-14 03:56:45 --> Output Class Initialized
INFO - 2022-12-14 03:56:45 --> Security Class Initialized
DEBUG - 2022-12-14 03:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 03:56:45 --> Input Class Initialized
INFO - 2022-12-14 03:56:45 --> Language Class Initialized
INFO - 2022-12-14 03:56:45 --> Loader Class Initialized
INFO - 2022-12-14 03:56:45 --> Controller Class Initialized
DEBUG - 2022-12-14 03:56:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 03:56:45 --> Database Driver Class Initialized
INFO - 2022-12-14 03:56:45 --> Model "Cluster_model" initialized
INFO - 2022-12-14 03:56:45 --> Final output sent to browser
DEBUG - 2022-12-14 03:56:45 --> Total execution time: 0.0417
INFO - 2022-12-14 03:56:45 --> Config Class Initialized
INFO - 2022-12-14 03:56:45 --> Hooks Class Initialized
DEBUG - 2022-12-14 03:56:45 --> UTF-8 Support Enabled
INFO - 2022-12-14 03:56:45 --> Utf8 Class Initialized
INFO - 2022-12-14 03:56:45 --> URI Class Initialized
INFO - 2022-12-14 03:56:45 --> Router Class Initialized
INFO - 2022-12-14 03:56:45 --> Output Class Initialized
INFO - 2022-12-14 03:56:45 --> Security Class Initialized
DEBUG - 2022-12-14 03:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 03:56:45 --> Input Class Initialized
INFO - 2022-12-14 03:56:45 --> Language Class Initialized
INFO - 2022-12-14 03:56:45 --> Loader Class Initialized
INFO - 2022-12-14 03:56:45 --> Controller Class Initialized
DEBUG - 2022-12-14 03:56:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 03:56:45 --> Database Driver Class Initialized
INFO - 2022-12-14 03:56:45 --> Model "Cluster_model" initialized
INFO - 2022-12-14 03:56:45 --> Final output sent to browser
DEBUG - 2022-12-14 03:56:45 --> Total execution time: 0.2052
INFO - 2022-12-14 03:56:47 --> Config Class Initialized
INFO - 2022-12-14 03:56:47 --> Hooks Class Initialized
DEBUG - 2022-12-14 03:56:47 --> UTF-8 Support Enabled
INFO - 2022-12-14 03:56:47 --> Utf8 Class Initialized
INFO - 2022-12-14 03:56:47 --> Config Class Initialized
INFO - 2022-12-14 03:56:47 --> Hooks Class Initialized
INFO - 2022-12-14 03:56:47 --> URI Class Initialized
INFO - 2022-12-14 03:56:47 --> Router Class Initialized
DEBUG - 2022-12-14 03:56:47 --> UTF-8 Support Enabled
INFO - 2022-12-14 03:56:47 --> Utf8 Class Initialized
INFO - 2022-12-14 03:56:47 --> Output Class Initialized
INFO - 2022-12-14 03:56:47 --> URI Class Initialized
INFO - 2022-12-14 03:56:47 --> Security Class Initialized
INFO - 2022-12-14 03:56:47 --> Router Class Initialized
DEBUG - 2022-12-14 03:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 03:56:47 --> Input Class Initialized
INFO - 2022-12-14 03:56:47 --> Language Class Initialized
INFO - 2022-12-14 03:56:47 --> Output Class Initialized
INFO - 2022-12-14 03:56:47 --> Security Class Initialized
DEBUG - 2022-12-14 03:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 03:56:47 --> Input Class Initialized
INFO - 2022-12-14 03:56:47 --> Language Class Initialized
INFO - 2022-12-14 03:56:47 --> Loader Class Initialized
INFO - 2022-12-14 03:56:47 --> Controller Class Initialized
DEBUG - 2022-12-14 03:56:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 03:56:47 --> Loader Class Initialized
INFO - 2022-12-14 03:56:47 --> Controller Class Initialized
DEBUG - 2022-12-14 03:56:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 03:56:47 --> Database Driver Class Initialized
INFO - 2022-12-14 03:56:47 --> Final output sent to browser
DEBUG - 2022-12-14 03:56:47 --> Total execution time: 0.0415
INFO - 2022-12-14 03:56:47 --> Config Class Initialized
INFO - 2022-12-14 03:56:47 --> Model "Cluster_model" initialized
INFO - 2022-12-14 03:56:47 --> Hooks Class Initialized
DEBUG - 2022-12-14 03:56:47 --> UTF-8 Support Enabled
INFO - 2022-12-14 03:56:47 --> Utf8 Class Initialized
INFO - 2022-12-14 03:56:47 --> URI Class Initialized
INFO - 2022-12-14 03:56:47 --> Router Class Initialized
INFO - 2022-12-14 03:56:47 --> Output Class Initialized
INFO - 2022-12-14 03:56:47 --> Security Class Initialized
DEBUG - 2022-12-14 03:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 03:56:47 --> Input Class Initialized
INFO - 2022-12-14 03:56:47 --> Language Class Initialized
INFO - 2022-12-14 03:56:47 --> Loader Class Initialized
INFO - 2022-12-14 03:56:47 --> Final output sent to browser
DEBUG - 2022-12-14 03:56:47 --> Total execution time: 0.0875
INFO - 2022-12-14 03:56:47 --> Controller Class Initialized
DEBUG - 2022-12-14 03:56:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 03:56:47 --> Database Driver Class Initialized
INFO - 2022-12-14 03:56:47 --> Config Class Initialized
INFO - 2022-12-14 03:56:47 --> Hooks Class Initialized
DEBUG - 2022-12-14 03:56:47 --> UTF-8 Support Enabled
INFO - 2022-12-14 03:56:47 --> Utf8 Class Initialized
INFO - 2022-12-14 03:56:47 --> URI Class Initialized
INFO - 2022-12-14 03:56:47 --> Router Class Initialized
INFO - 2022-12-14 03:56:47 --> Output Class Initialized
INFO - 2022-12-14 03:56:47 --> Security Class Initialized
DEBUG - 2022-12-14 03:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 03:56:47 --> Input Class Initialized
INFO - 2022-12-14 03:56:47 --> Model "Login_model" initialized
INFO - 2022-12-14 03:56:47 --> Language Class Initialized
INFO - 2022-12-14 03:56:47 --> Database Driver Class Initialized
INFO - 2022-12-14 03:56:47 --> Loader Class Initialized
INFO - 2022-12-14 03:56:47 --> Controller Class Initialized
DEBUG - 2022-12-14 03:56:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 03:56:47 --> Model "Cluster_model" initialized
INFO - 2022-12-14 03:56:47 --> Final output sent to browser
DEBUG - 2022-12-14 03:56:47 --> Total execution time: 0.0631
INFO - 2022-12-14 03:56:47 --> Database Driver Class Initialized
INFO - 2022-12-14 03:56:47 --> Model "Cluster_model" initialized
INFO - 2022-12-14 03:56:47 --> Final output sent to browser
DEBUG - 2022-12-14 03:56:47 --> Total execution time: 0.0471
INFO - 2022-12-14 03:56:50 --> Config Class Initialized
INFO - 2022-12-14 03:56:50 --> Hooks Class Initialized
DEBUG - 2022-12-14 03:56:50 --> UTF-8 Support Enabled
INFO - 2022-12-14 03:56:50 --> Utf8 Class Initialized
INFO - 2022-12-14 03:56:50 --> URI Class Initialized
INFO - 2022-12-14 03:56:50 --> Router Class Initialized
INFO - 2022-12-14 03:56:50 --> Output Class Initialized
INFO - 2022-12-14 03:56:50 --> Security Class Initialized
DEBUG - 2022-12-14 03:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 03:56:50 --> Input Class Initialized
INFO - 2022-12-14 03:56:50 --> Language Class Initialized
INFO - 2022-12-14 03:56:50 --> Loader Class Initialized
INFO - 2022-12-14 03:56:50 --> Controller Class Initialized
DEBUG - 2022-12-14 03:56:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 03:56:50 --> Database Driver Class Initialized
INFO - 2022-12-14 03:56:50 --> Model "Cluster_model" initialized
INFO - 2022-12-14 03:56:50 --> Database Driver Class Initialized
INFO - 2022-12-14 03:56:50 --> Model "Login_model" initialized
INFO - 2022-12-14 03:56:50 --> Final output sent to browser
DEBUG - 2022-12-14 03:56:50 --> Total execution time: 0.2205
INFO - 2022-12-14 03:56:50 --> Config Class Initialized
INFO - 2022-12-14 03:56:50 --> Hooks Class Initialized
DEBUG - 2022-12-14 03:56:51 --> UTF-8 Support Enabled
INFO - 2022-12-14 03:56:51 --> Utf8 Class Initialized
INFO - 2022-12-14 03:56:51 --> URI Class Initialized
INFO - 2022-12-14 03:56:51 --> Router Class Initialized
INFO - 2022-12-14 03:56:51 --> Output Class Initialized
INFO - 2022-12-14 03:56:51 --> Security Class Initialized
DEBUG - 2022-12-14 03:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 03:56:51 --> Input Class Initialized
INFO - 2022-12-14 03:56:51 --> Language Class Initialized
INFO - 2022-12-14 03:56:51 --> Loader Class Initialized
INFO - 2022-12-14 03:56:51 --> Controller Class Initialized
DEBUG - 2022-12-14 03:56:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 03:56:51 --> Database Driver Class Initialized
INFO - 2022-12-14 03:56:51 --> Model "Cluster_model" initialized
INFO - 2022-12-14 03:56:51 --> Database Driver Class Initialized
INFO - 2022-12-14 03:56:51 --> Model "Login_model" initialized
INFO - 2022-12-14 03:56:51 --> Final output sent to browser
DEBUG - 2022-12-14 03:56:51 --> Total execution time: 0.1493
INFO - 2022-12-14 06:34:32 --> Config Class Initialized
INFO - 2022-12-14 06:34:32 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:32 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:32 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:32 --> URI Class Initialized
INFO - 2022-12-14 06:34:32 --> Router Class Initialized
INFO - 2022-12-14 06:34:32 --> Output Class Initialized
INFO - 2022-12-14 06:34:32 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:32 --> Input Class Initialized
INFO - 2022-12-14 06:34:32 --> Language Class Initialized
INFO - 2022-12-14 06:34:32 --> Loader Class Initialized
INFO - 2022-12-14 06:34:32 --> Controller Class Initialized
INFO - 2022-12-14 06:34:32 --> Helper loaded: form_helper
INFO - 2022-12-14 06:34:32 --> Helper loaded: url_helper
DEBUG - 2022-12-14 06:34:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:32 --> Model "Change_model" initialized
INFO - 2022-12-14 06:34:32 --> Model "Grafana_model" initialized
INFO - 2022-12-14 06:34:32 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:32 --> Total execution time: 0.1082
INFO - 2022-12-14 06:34:32 --> Config Class Initialized
INFO - 2022-12-14 06:34:32 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:32 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:32 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:32 --> URI Class Initialized
INFO - 2022-12-14 06:34:32 --> Router Class Initialized
INFO - 2022-12-14 06:34:32 --> Output Class Initialized
INFO - 2022-12-14 06:34:32 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:32 --> Input Class Initialized
INFO - 2022-12-14 06:34:32 --> Language Class Initialized
INFO - 2022-12-14 06:34:32 --> Loader Class Initialized
INFO - 2022-12-14 06:34:32 --> Controller Class Initialized
INFO - 2022-12-14 06:34:32 --> Helper loaded: form_helper
INFO - 2022-12-14 06:34:32 --> Helper loaded: url_helper
DEBUG - 2022-12-14 06:34:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:32 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:32 --> Total execution time: 0.0206
INFO - 2022-12-14 06:34:32 --> Config Class Initialized
INFO - 2022-12-14 06:34:32 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:32 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:32 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:32 --> URI Class Initialized
INFO - 2022-12-14 06:34:32 --> Router Class Initialized
INFO - 2022-12-14 06:34:32 --> Output Class Initialized
INFO - 2022-12-14 06:34:32 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:32 --> Input Class Initialized
INFO - 2022-12-14 06:34:32 --> Language Class Initialized
INFO - 2022-12-14 06:34:32 --> Loader Class Initialized
INFO - 2022-12-14 06:34:32 --> Controller Class Initialized
INFO - 2022-12-14 06:34:32 --> Helper loaded: form_helper
INFO - 2022-12-14 06:34:32 --> Helper loaded: url_helper
DEBUG - 2022-12-14 06:34:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:32 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:32 --> Model "Login_model" initialized
INFO - 2022-12-14 06:34:32 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:32 --> Total execution time: 0.0457
INFO - 2022-12-14 06:34:32 --> Config Class Initialized
INFO - 2022-12-14 06:34:32 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:32 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:32 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:32 --> URI Class Initialized
INFO - 2022-12-14 06:34:32 --> Router Class Initialized
INFO - 2022-12-14 06:34:32 --> Output Class Initialized
INFO - 2022-12-14 06:34:32 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:32 --> Input Class Initialized
INFO - 2022-12-14 06:34:32 --> Language Class Initialized
INFO - 2022-12-14 06:34:32 --> Loader Class Initialized
INFO - 2022-12-14 06:34:32 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:32 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:32 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:32 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:32 --> Total execution time: 0.0685
INFO - 2022-12-14 06:34:32 --> Config Class Initialized
INFO - 2022-12-14 06:34:32 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:32 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:32 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:32 --> URI Class Initialized
INFO - 2022-12-14 06:34:32 --> Router Class Initialized
INFO - 2022-12-14 06:34:32 --> Output Class Initialized
INFO - 2022-12-14 06:34:32 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:32 --> Input Class Initialized
INFO - 2022-12-14 06:34:32 --> Language Class Initialized
INFO - 2022-12-14 06:34:32 --> Loader Class Initialized
INFO - 2022-12-14 06:34:32 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:32 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:32 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:32 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:32 --> Total execution time: 0.0424
INFO - 2022-12-14 06:34:33 --> Config Class Initialized
INFO - 2022-12-14 06:34:33 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:33 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:33 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:33 --> URI Class Initialized
INFO - 2022-12-14 06:34:33 --> Router Class Initialized
INFO - 2022-12-14 06:34:33 --> Output Class Initialized
INFO - 2022-12-14 06:34:33 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:33 --> Input Class Initialized
INFO - 2022-12-14 06:34:33 --> Language Class Initialized
INFO - 2022-12-14 06:34:33 --> Loader Class Initialized
INFO - 2022-12-14 06:34:33 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:33 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:33 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:33 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:33 --> Model "Login_model" initialized
INFO - 2022-12-14 06:34:33 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:33 --> Total execution time: 0.1384
INFO - 2022-12-14 06:34:33 --> Config Class Initialized
INFO - 2022-12-14 06:34:33 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:33 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:33 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:33 --> URI Class Initialized
INFO - 2022-12-14 06:34:33 --> Router Class Initialized
INFO - 2022-12-14 06:34:33 --> Output Class Initialized
INFO - 2022-12-14 06:34:33 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:33 --> Input Class Initialized
INFO - 2022-12-14 06:34:33 --> Language Class Initialized
INFO - 2022-12-14 06:34:33 --> Loader Class Initialized
INFO - 2022-12-14 06:34:33 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:33 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:33 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:33 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:33 --> Model "Login_model" initialized
INFO - 2022-12-14 06:34:33 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:33 --> Total execution time: 0.1822
INFO - 2022-12-14 06:34:37 --> Config Class Initialized
INFO - 2022-12-14 06:34:37 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:37 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:37 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:37 --> URI Class Initialized
INFO - 2022-12-14 06:34:37 --> Router Class Initialized
INFO - 2022-12-14 06:34:37 --> Output Class Initialized
INFO - 2022-12-14 06:34:37 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:37 --> Input Class Initialized
INFO - 2022-12-14 06:34:37 --> Language Class Initialized
INFO - 2022-12-14 06:34:37 --> Loader Class Initialized
INFO - 2022-12-14 06:34:37 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:37 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:37 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:37 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:37 --> Total execution time: 0.0527
INFO - 2022-12-14 06:34:37 --> Config Class Initialized
INFO - 2022-12-14 06:34:37 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:37 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:37 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:37 --> URI Class Initialized
INFO - 2022-12-14 06:34:37 --> Router Class Initialized
INFO - 2022-12-14 06:34:37 --> Output Class Initialized
INFO - 2022-12-14 06:34:37 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:37 --> Input Class Initialized
INFO - 2022-12-14 06:34:37 --> Language Class Initialized
INFO - 2022-12-14 06:34:37 --> Loader Class Initialized
INFO - 2022-12-14 06:34:37 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:37 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:37 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:37 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:37 --> Total execution time: 0.0592
INFO - 2022-12-14 06:34:38 --> Config Class Initialized
INFO - 2022-12-14 06:34:38 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:38 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:38 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:38 --> URI Class Initialized
INFO - 2022-12-14 06:34:38 --> Router Class Initialized
INFO - 2022-12-14 06:34:38 --> Output Class Initialized
INFO - 2022-12-14 06:34:38 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:38 --> Input Class Initialized
INFO - 2022-12-14 06:34:38 --> Language Class Initialized
INFO - 2022-12-14 06:34:38 --> Loader Class Initialized
INFO - 2022-12-14 06:34:38 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:38 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:38 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:38 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:38 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:38 --> Total execution time: 0.2404
INFO - 2022-12-14 06:34:38 --> Config Class Initialized
INFO - 2022-12-14 06:34:38 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:38 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:38 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:38 --> URI Class Initialized
INFO - 2022-12-14 06:34:38 --> Router Class Initialized
INFO - 2022-12-14 06:34:38 --> Output Class Initialized
INFO - 2022-12-14 06:34:38 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:38 --> Input Class Initialized
INFO - 2022-12-14 06:34:38 --> Language Class Initialized
INFO - 2022-12-14 06:34:38 --> Loader Class Initialized
INFO - 2022-12-14 06:34:38 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:38 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:38 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:38 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:38 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:38 --> Total execution time: 0.0525
INFO - 2022-12-14 06:34:40 --> Config Class Initialized
INFO - 2022-12-14 06:34:40 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:40 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:40 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:40 --> URI Class Initialized
INFO - 2022-12-14 06:34:40 --> Router Class Initialized
INFO - 2022-12-14 06:34:40 --> Output Class Initialized
INFO - 2022-12-14 06:34:40 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:40 --> Input Class Initialized
INFO - 2022-12-14 06:34:40 --> Language Class Initialized
INFO - 2022-12-14 06:34:40 --> Loader Class Initialized
INFO - 2022-12-14 06:34:40 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:40 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:40 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:40 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:40 --> Model "Login_model" initialized
INFO - 2022-12-14 06:34:40 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:40 --> Total execution time: 0.1085
INFO - 2022-12-14 06:34:40 --> Config Class Initialized
INFO - 2022-12-14 06:34:40 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:40 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:40 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:40 --> URI Class Initialized
INFO - 2022-12-14 06:34:40 --> Router Class Initialized
INFO - 2022-12-14 06:34:40 --> Output Class Initialized
INFO - 2022-12-14 06:34:40 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:40 --> Input Class Initialized
INFO - 2022-12-14 06:34:40 --> Language Class Initialized
INFO - 2022-12-14 06:34:40 --> Loader Class Initialized
INFO - 2022-12-14 06:34:40 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:40 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:40 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:40 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:40 --> Model "Login_model" initialized
INFO - 2022-12-14 06:34:40 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:40 --> Total execution time: 0.1674
INFO - 2022-12-14 06:34:46 --> Config Class Initialized
INFO - 2022-12-14 06:34:46 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:46 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:46 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:46 --> URI Class Initialized
INFO - 2022-12-14 06:34:46 --> Router Class Initialized
INFO - 2022-12-14 06:34:46 --> Output Class Initialized
INFO - 2022-12-14 06:34:46 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:46 --> Input Class Initialized
INFO - 2022-12-14 06:34:46 --> Language Class Initialized
INFO - 2022-12-14 06:34:46 --> Loader Class Initialized
INFO - 2022-12-14 06:34:46 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:46 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:46 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:46 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:46 --> Total execution time: 0.0873
INFO - 2022-12-14 06:34:46 --> Config Class Initialized
INFO - 2022-12-14 06:34:46 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:46 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:46 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:46 --> URI Class Initialized
INFO - 2022-12-14 06:34:46 --> Router Class Initialized
INFO - 2022-12-14 06:34:46 --> Output Class Initialized
INFO - 2022-12-14 06:34:46 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:46 --> Input Class Initialized
INFO - 2022-12-14 06:34:46 --> Language Class Initialized
INFO - 2022-12-14 06:34:46 --> Loader Class Initialized
INFO - 2022-12-14 06:34:46 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:46 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:46 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:46 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:46 --> Total execution time: 0.2001
INFO - 2022-12-14 06:34:48 --> Config Class Initialized
INFO - 2022-12-14 06:34:48 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:48 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:48 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:48 --> URI Class Initialized
INFO - 2022-12-14 06:34:48 --> Router Class Initialized
INFO - 2022-12-14 06:34:48 --> Output Class Initialized
INFO - 2022-12-14 06:34:48 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:48 --> Input Class Initialized
INFO - 2022-12-14 06:34:48 --> Language Class Initialized
INFO - 2022-12-14 06:34:48 --> Loader Class Initialized
INFO - 2022-12-14 06:34:48 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:48 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:48 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:48 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:48 --> Total execution time: 0.0361
INFO - 2022-12-14 06:34:48 --> Config Class Initialized
INFO - 2022-12-14 06:34:48 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:34:48 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:34:48 --> Utf8 Class Initialized
INFO - 2022-12-14 06:34:48 --> URI Class Initialized
INFO - 2022-12-14 06:34:48 --> Router Class Initialized
INFO - 2022-12-14 06:34:48 --> Output Class Initialized
INFO - 2022-12-14 06:34:48 --> Security Class Initialized
DEBUG - 2022-12-14 06:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:34:48 --> Input Class Initialized
INFO - 2022-12-14 06:34:48 --> Language Class Initialized
INFO - 2022-12-14 06:34:48 --> Loader Class Initialized
INFO - 2022-12-14 06:34:48 --> Controller Class Initialized
DEBUG - 2022-12-14 06:34:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:34:48 --> Database Driver Class Initialized
INFO - 2022-12-14 06:34:48 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:34:48 --> Final output sent to browser
DEBUG - 2022-12-14 06:34:48 --> Total execution time: 0.2511
INFO - 2022-12-14 06:35:02 --> Config Class Initialized
INFO - 2022-12-14 06:35:02 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:35:02 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:35:02 --> Utf8 Class Initialized
INFO - 2022-12-14 06:35:02 --> URI Class Initialized
INFO - 2022-12-14 06:35:02 --> Router Class Initialized
INFO - 2022-12-14 06:35:02 --> Output Class Initialized
INFO - 2022-12-14 06:35:02 --> Security Class Initialized
DEBUG - 2022-12-14 06:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:35:02 --> Input Class Initialized
INFO - 2022-12-14 06:35:02 --> Language Class Initialized
INFO - 2022-12-14 06:35:02 --> Loader Class Initialized
INFO - 2022-12-14 06:35:02 --> Controller Class Initialized
DEBUG - 2022-12-14 06:35:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:35:02 --> Final output sent to browser
DEBUG - 2022-12-14 06:35:02 --> Total execution time: 0.0216
INFO - 2022-12-14 06:35:02 --> Config Class Initialized
INFO - 2022-12-14 06:35:02 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:35:02 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:35:02 --> Utf8 Class Initialized
INFO - 2022-12-14 06:35:02 --> URI Class Initialized
INFO - 2022-12-14 06:35:02 --> Router Class Initialized
INFO - 2022-12-14 06:35:02 --> Output Class Initialized
INFO - 2022-12-14 06:35:02 --> Security Class Initialized
DEBUG - 2022-12-14 06:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:35:02 --> Input Class Initialized
INFO - 2022-12-14 06:35:02 --> Language Class Initialized
INFO - 2022-12-14 06:35:02 --> Loader Class Initialized
INFO - 2022-12-14 06:35:02 --> Controller Class Initialized
DEBUG - 2022-12-14 06:35:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:35:02 --> Database Driver Class Initialized
INFO - 2022-12-14 06:35:02 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:35:02 --> Final output sent to browser
DEBUG - 2022-12-14 06:35:02 --> Total execution time: 0.0876
INFO - 2022-12-14 06:35:03 --> Config Class Initialized
INFO - 2022-12-14 06:35:03 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:35:03 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:35:03 --> Utf8 Class Initialized
INFO - 2022-12-14 06:35:03 --> URI Class Initialized
INFO - 2022-12-14 06:35:03 --> Router Class Initialized
INFO - 2022-12-14 06:35:03 --> Output Class Initialized
INFO - 2022-12-14 06:35:03 --> Security Class Initialized
DEBUG - 2022-12-14 06:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:35:03 --> Input Class Initialized
INFO - 2022-12-14 06:35:03 --> Language Class Initialized
INFO - 2022-12-14 06:35:03 --> Loader Class Initialized
INFO - 2022-12-14 06:35:03 --> Controller Class Initialized
DEBUG - 2022-12-14 06:35:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:35:03 --> Database Driver Class Initialized
INFO - 2022-12-14 06:35:03 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:35:03 --> Final output sent to browser
DEBUG - 2022-12-14 06:35:03 --> Total execution time: 0.0731
INFO - 2022-12-14 06:35:03 --> Config Class Initialized
INFO - 2022-12-14 06:35:03 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:35:03 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:35:03 --> Utf8 Class Initialized
INFO - 2022-12-14 06:35:03 --> URI Class Initialized
INFO - 2022-12-14 06:35:03 --> Router Class Initialized
INFO - 2022-12-14 06:35:03 --> Output Class Initialized
INFO - 2022-12-14 06:35:03 --> Security Class Initialized
DEBUG - 2022-12-14 06:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:35:03 --> Input Class Initialized
INFO - 2022-12-14 06:35:03 --> Language Class Initialized
INFO - 2022-12-14 06:35:03 --> Loader Class Initialized
INFO - 2022-12-14 06:35:03 --> Controller Class Initialized
DEBUG - 2022-12-14 06:35:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:35:03 --> Database Driver Class Initialized
INFO - 2022-12-14 06:35:03 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:35:03 --> Final output sent to browser
DEBUG - 2022-12-14 06:35:03 --> Total execution time: 0.0393
INFO - 2022-12-14 06:37:27 --> Config Class Initialized
INFO - 2022-12-14 06:37:27 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:27 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:27 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:27 --> URI Class Initialized
INFO - 2022-12-14 06:37:27 --> Router Class Initialized
INFO - 2022-12-14 06:37:27 --> Output Class Initialized
INFO - 2022-12-14 06:37:27 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:27 --> Input Class Initialized
INFO - 2022-12-14 06:37:27 --> Language Class Initialized
INFO - 2022-12-14 06:37:27 --> Loader Class Initialized
INFO - 2022-12-14 06:37:27 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:27 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:27 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:27 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:27 --> Total execution time: 0.0836
INFO - 2022-12-14 06:37:27 --> Config Class Initialized
INFO - 2022-12-14 06:37:27 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:27 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:27 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:27 --> URI Class Initialized
INFO - 2022-12-14 06:37:27 --> Router Class Initialized
INFO - 2022-12-14 06:37:27 --> Output Class Initialized
INFO - 2022-12-14 06:37:27 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:27 --> Input Class Initialized
INFO - 2022-12-14 06:37:27 --> Language Class Initialized
INFO - 2022-12-14 06:37:27 --> Loader Class Initialized
INFO - 2022-12-14 06:37:27 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:27 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:27 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:27 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:27 --> Total execution time: 0.0473
INFO - 2022-12-14 06:37:37 --> Config Class Initialized
INFO - 2022-12-14 06:37:37 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:37 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:37 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:37 --> URI Class Initialized
INFO - 2022-12-14 06:37:37 --> Router Class Initialized
INFO - 2022-12-14 06:37:37 --> Output Class Initialized
INFO - 2022-12-14 06:37:37 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:37 --> Input Class Initialized
INFO - 2022-12-14 06:37:37 --> Language Class Initialized
INFO - 2022-12-14 06:37:37 --> Loader Class Initialized
INFO - 2022-12-14 06:37:37 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:37 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:37 --> Total execution time: 0.0299
INFO - 2022-12-14 06:37:37 --> Config Class Initialized
INFO - 2022-12-14 06:37:37 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:37 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:37 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:37 --> URI Class Initialized
INFO - 2022-12-14 06:37:37 --> Router Class Initialized
INFO - 2022-12-14 06:37:37 --> Output Class Initialized
INFO - 2022-12-14 06:37:37 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:37 --> Input Class Initialized
INFO - 2022-12-14 06:37:37 --> Language Class Initialized
INFO - 2022-12-14 06:37:37 --> Loader Class Initialized
INFO - 2022-12-14 06:37:37 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:37 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:37 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:37 --> Model "Mysql_model" initialized
INFO - 2022-12-14 06:37:37 --> Model "Grafana_model" initialized
ERROR - 2022-12-14 06:37:37 --> Exception of type 'TypeError' occurred with Message: count(): Argument #1 ($value) must be of type Countable|array, null given in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Grafana.php at Line 51
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Grafana->mysqlDashboard()
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#2 {main}
INFO - 2022-12-14 06:37:38 --> Config Class Initialized
INFO - 2022-12-14 06:37:38 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:38 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:38 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:38 --> URI Class Initialized
INFO - 2022-12-14 06:37:38 --> Router Class Initialized
INFO - 2022-12-14 06:37:38 --> Output Class Initialized
INFO - 2022-12-14 06:37:38 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:38 --> Input Class Initialized
INFO - 2022-12-14 06:37:38 --> Language Class Initialized
INFO - 2022-12-14 06:37:38 --> Loader Class Initialized
INFO - 2022-12-14 06:37:38 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:38 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:38 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:39 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:39 --> Model "Mysql_model" initialized
INFO - 2022-12-14 06:37:39 --> Model "Grafana_model" initialized
ERROR - 2022-12-14 06:37:39 --> Exception of type 'TypeError' occurred with Message: count(): Argument #1 ($value) must be of type Countable|array, null given in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Grafana.php at Line 51
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Grafana->mysqlDashboard()
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#2 {main}
INFO - 2022-12-14 06:37:39 --> Config Class Initialized
INFO - 2022-12-14 06:37:39 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:39 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:39 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:39 --> URI Class Initialized
INFO - 2022-12-14 06:37:39 --> Router Class Initialized
INFO - 2022-12-14 06:37:39 --> Output Class Initialized
INFO - 2022-12-14 06:37:39 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:39 --> Input Class Initialized
INFO - 2022-12-14 06:37:39 --> Language Class Initialized
INFO - 2022-12-14 06:37:39 --> Loader Class Initialized
INFO - 2022-12-14 06:37:39 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:39 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:39 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:39 --> Model "Mysql_model" initialized
INFO - 2022-12-14 06:37:39 --> Model "Grafana_model" initialized
ERROR - 2022-12-14 06:37:39 --> Exception of type 'TypeError' occurred with Message: count(): Argument #1 ($value) must be of type Countable|array, null given in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Grafana.php at Line 51
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Grafana->mysqlDashboard()
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#2 {main}
INFO - 2022-12-14 06:37:41 --> Config Class Initialized
INFO - 2022-12-14 06:37:41 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:41 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:41 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:41 --> URI Class Initialized
INFO - 2022-12-14 06:37:41 --> Router Class Initialized
INFO - 2022-12-14 06:37:41 --> Output Class Initialized
INFO - 2022-12-14 06:37:41 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:41 --> Input Class Initialized
INFO - 2022-12-14 06:37:41 --> Language Class Initialized
INFO - 2022-12-14 06:37:41 --> Loader Class Initialized
INFO - 2022-12-14 06:37:41 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:41 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:41 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:41 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:41 --> Total execution time: 0.0530
INFO - 2022-12-14 06:37:41 --> Config Class Initialized
INFO - 2022-12-14 06:37:41 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:41 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:41 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:41 --> URI Class Initialized
INFO - 2022-12-14 06:37:41 --> Router Class Initialized
INFO - 2022-12-14 06:37:41 --> Output Class Initialized
INFO - 2022-12-14 06:37:41 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:41 --> Input Class Initialized
INFO - 2022-12-14 06:37:41 --> Language Class Initialized
INFO - 2022-12-14 06:37:41 --> Loader Class Initialized
INFO - 2022-12-14 06:37:41 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:41 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:41 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:41 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:41 --> Total execution time: 0.0585
INFO - 2022-12-14 06:37:44 --> Config Class Initialized
INFO - 2022-12-14 06:37:44 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:44 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:44 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:44 --> URI Class Initialized
INFO - 2022-12-14 06:37:44 --> Router Class Initialized
INFO - 2022-12-14 06:37:44 --> Output Class Initialized
INFO - 2022-12-14 06:37:44 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:44 --> Input Class Initialized
INFO - 2022-12-14 06:37:44 --> Language Class Initialized
INFO - 2022-12-14 06:37:44 --> Loader Class Initialized
INFO - 2022-12-14 06:37:44 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:44 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:44 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:44 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:44 --> Total execution time: 0.0581
INFO - 2022-12-14 06:37:44 --> Config Class Initialized
INFO - 2022-12-14 06:37:44 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:44 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:44 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:44 --> URI Class Initialized
INFO - 2022-12-14 06:37:44 --> Router Class Initialized
INFO - 2022-12-14 06:37:44 --> Output Class Initialized
INFO - 2022-12-14 06:37:44 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:44 --> Input Class Initialized
INFO - 2022-12-14 06:37:44 --> Language Class Initialized
INFO - 2022-12-14 06:37:44 --> Loader Class Initialized
INFO - 2022-12-14 06:37:44 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:44 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:44 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:44 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:44 --> Total execution time: 0.0542
INFO - 2022-12-14 06:37:45 --> Config Class Initialized
INFO - 2022-12-14 06:37:45 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:45 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:45 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:45 --> URI Class Initialized
INFO - 2022-12-14 06:37:45 --> Router Class Initialized
INFO - 2022-12-14 06:37:45 --> Output Class Initialized
INFO - 2022-12-14 06:37:45 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:45 --> Input Class Initialized
INFO - 2022-12-14 06:37:45 --> Language Class Initialized
INFO - 2022-12-14 06:37:45 --> Loader Class Initialized
INFO - 2022-12-14 06:37:45 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:45 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:45 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:45 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:45 --> Total execution time: 0.0811
INFO - 2022-12-14 06:37:47 --> Config Class Initialized
INFO - 2022-12-14 06:37:47 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:47 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:47 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:47 --> URI Class Initialized
INFO - 2022-12-14 06:37:47 --> Router Class Initialized
INFO - 2022-12-14 06:37:47 --> Output Class Initialized
INFO - 2022-12-14 06:37:47 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:47 --> Input Class Initialized
INFO - 2022-12-14 06:37:47 --> Language Class Initialized
INFO - 2022-12-14 06:37:47 --> Loader Class Initialized
INFO - 2022-12-14 06:37:47 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:47 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:47 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:47 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:47 --> Total execution time: 0.0787
INFO - 2022-12-14 06:37:48 --> Config Class Initialized
INFO - 2022-12-14 06:37:48 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:48 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:48 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:48 --> URI Class Initialized
INFO - 2022-12-14 06:37:48 --> Router Class Initialized
INFO - 2022-12-14 06:37:48 --> Output Class Initialized
INFO - 2022-12-14 06:37:48 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:48 --> Input Class Initialized
INFO - 2022-12-14 06:37:48 --> Language Class Initialized
INFO - 2022-12-14 06:37:48 --> Loader Class Initialized
INFO - 2022-12-14 06:37:48 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:48 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:48 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:48 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:48 --> Total execution time: 0.0519
INFO - 2022-12-14 06:37:48 --> Config Class Initialized
INFO - 2022-12-14 06:37:48 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:48 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:48 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:48 --> URI Class Initialized
INFO - 2022-12-14 06:37:48 --> Router Class Initialized
INFO - 2022-12-14 06:37:48 --> Output Class Initialized
INFO - 2022-12-14 06:37:48 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:48 --> Input Class Initialized
INFO - 2022-12-14 06:37:48 --> Language Class Initialized
INFO - 2022-12-14 06:37:48 --> Loader Class Initialized
INFO - 2022-12-14 06:37:48 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:48 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:48 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:48 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:48 --> Total execution time: 0.0557
INFO - 2022-12-14 06:37:52 --> Config Class Initialized
INFO - 2022-12-14 06:37:52 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:52 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:52 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:52 --> URI Class Initialized
INFO - 2022-12-14 06:37:52 --> Router Class Initialized
INFO - 2022-12-14 06:37:52 --> Output Class Initialized
INFO - 2022-12-14 06:37:52 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:52 --> Input Class Initialized
INFO - 2022-12-14 06:37:52 --> Language Class Initialized
INFO - 2022-12-14 06:37:52 --> Loader Class Initialized
INFO - 2022-12-14 06:37:52 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:52 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:52 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:52 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:52 --> Total execution time: 0.0829
INFO - 2022-12-14 06:37:52 --> Config Class Initialized
INFO - 2022-12-14 06:37:52 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:52 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:52 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:52 --> URI Class Initialized
INFO - 2022-12-14 06:37:52 --> Router Class Initialized
INFO - 2022-12-14 06:37:52 --> Output Class Initialized
INFO - 2022-12-14 06:37:52 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:52 --> Input Class Initialized
INFO - 2022-12-14 06:37:52 --> Language Class Initialized
INFO - 2022-12-14 06:37:52 --> Loader Class Initialized
INFO - 2022-12-14 06:37:52 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:52 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:52 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:52 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:52 --> Total execution time: 0.0535
INFO - 2022-12-14 06:37:59 --> Config Class Initialized
INFO - 2022-12-14 06:37:59 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:59 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:59 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:59 --> URI Class Initialized
INFO - 2022-12-14 06:37:59 --> Router Class Initialized
INFO - 2022-12-14 06:37:59 --> Output Class Initialized
INFO - 2022-12-14 06:37:59 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:59 --> Input Class Initialized
INFO - 2022-12-14 06:37:59 --> Language Class Initialized
INFO - 2022-12-14 06:37:59 --> Loader Class Initialized
INFO - 2022-12-14 06:37:59 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:59 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:59 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:59 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:59 --> Total execution time: 0.0397
INFO - 2022-12-14 06:37:59 --> Config Class Initialized
INFO - 2022-12-14 06:37:59 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:37:59 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:37:59 --> Utf8 Class Initialized
INFO - 2022-12-14 06:37:59 --> URI Class Initialized
INFO - 2022-12-14 06:37:59 --> Router Class Initialized
INFO - 2022-12-14 06:37:59 --> Output Class Initialized
INFO - 2022-12-14 06:37:59 --> Security Class Initialized
DEBUG - 2022-12-14 06:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:37:59 --> Input Class Initialized
INFO - 2022-12-14 06:37:59 --> Language Class Initialized
INFO - 2022-12-14 06:37:59 --> Loader Class Initialized
INFO - 2022-12-14 06:37:59 --> Controller Class Initialized
DEBUG - 2022-12-14 06:37:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:37:59 --> Database Driver Class Initialized
INFO - 2022-12-14 06:37:59 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:37:59 --> Final output sent to browser
DEBUG - 2022-12-14 06:37:59 --> Total execution time: 0.0361
INFO - 2022-12-14 06:38:13 --> Config Class Initialized
INFO - 2022-12-14 06:38:13 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:38:13 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:38:13 --> Utf8 Class Initialized
INFO - 2022-12-14 06:38:13 --> URI Class Initialized
INFO - 2022-12-14 06:38:13 --> Router Class Initialized
INFO - 2022-12-14 06:38:13 --> Output Class Initialized
INFO - 2022-12-14 06:38:13 --> Security Class Initialized
DEBUG - 2022-12-14 06:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:38:13 --> Input Class Initialized
INFO - 2022-12-14 06:38:13 --> Language Class Initialized
INFO - 2022-12-14 06:38:13 --> Loader Class Initialized
INFO - 2022-12-14 06:38:13 --> Controller Class Initialized
DEBUG - 2022-12-14 06:38:13 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:38:13 --> Final output sent to browser
DEBUG - 2022-12-14 06:38:13 --> Total execution time: 0.0223
INFO - 2022-12-14 06:38:13 --> Config Class Initialized
INFO - 2022-12-14 06:38:13 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:38:13 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:38:13 --> Utf8 Class Initialized
INFO - 2022-12-14 06:38:13 --> URI Class Initialized
INFO - 2022-12-14 06:38:13 --> Router Class Initialized
INFO - 2022-12-14 06:38:13 --> Output Class Initialized
INFO - 2022-12-14 06:38:13 --> Security Class Initialized
DEBUG - 2022-12-14 06:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:38:13 --> Input Class Initialized
INFO - 2022-12-14 06:38:13 --> Language Class Initialized
INFO - 2022-12-14 06:38:13 --> Loader Class Initialized
INFO - 2022-12-14 06:38:13 --> Controller Class Initialized
DEBUG - 2022-12-14 06:38:13 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:38:13 --> Database Driver Class Initialized
INFO - 2022-12-14 06:38:13 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:38:13 --> Final output sent to browser
DEBUG - 2022-12-14 06:38:13 --> Total execution time: 0.0586
INFO - 2022-12-14 06:38:14 --> Config Class Initialized
INFO - 2022-12-14 06:38:14 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:38:14 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:38:14 --> Utf8 Class Initialized
INFO - 2022-12-14 06:38:14 --> URI Class Initialized
INFO - 2022-12-14 06:38:14 --> Router Class Initialized
INFO - 2022-12-14 06:38:14 --> Output Class Initialized
INFO - 2022-12-14 06:38:14 --> Security Class Initialized
DEBUG - 2022-12-14 06:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:38:14 --> Input Class Initialized
INFO - 2022-12-14 06:38:14 --> Language Class Initialized
INFO - 2022-12-14 06:38:14 --> Loader Class Initialized
INFO - 2022-12-14 06:38:14 --> Controller Class Initialized
DEBUG - 2022-12-14 06:38:14 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:38:14 --> Database Driver Class Initialized
INFO - 2022-12-14 06:38:14 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:38:14 --> Final output sent to browser
DEBUG - 2022-12-14 06:38:14 --> Total execution time: 0.0473
INFO - 2022-12-14 06:38:14 --> Config Class Initialized
INFO - 2022-12-14 06:38:14 --> Hooks Class Initialized
DEBUG - 2022-12-14 06:38:14 --> UTF-8 Support Enabled
INFO - 2022-12-14 06:38:14 --> Utf8 Class Initialized
INFO - 2022-12-14 06:38:14 --> URI Class Initialized
INFO - 2022-12-14 06:38:14 --> Router Class Initialized
INFO - 2022-12-14 06:38:14 --> Output Class Initialized
INFO - 2022-12-14 06:38:14 --> Security Class Initialized
DEBUG - 2022-12-14 06:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 06:38:14 --> Input Class Initialized
INFO - 2022-12-14 06:38:14 --> Language Class Initialized
INFO - 2022-12-14 06:38:14 --> Loader Class Initialized
INFO - 2022-12-14 06:38:14 --> Controller Class Initialized
DEBUG - 2022-12-14 06:38:14 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 06:38:14 --> Database Driver Class Initialized
INFO - 2022-12-14 06:38:14 --> Model "Cluster_model" initialized
INFO - 2022-12-14 06:38:14 --> Final output sent to browser
DEBUG - 2022-12-14 06:38:14 --> Total execution time: 0.0552
INFO - 2022-12-14 07:18:23 --> Config Class Initialized
INFO - 2022-12-14 07:18:23 --> Config Class Initialized
INFO - 2022-12-14 07:18:23 --> Hooks Class Initialized
INFO - 2022-12-14 07:18:23 --> Hooks Class Initialized
DEBUG - 2022-12-14 07:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-14 07:18:23 --> UTF-8 Support Enabled
INFO - 2022-12-14 07:18:23 --> Utf8 Class Initialized
INFO - 2022-12-14 07:18:23 --> Utf8 Class Initialized
INFO - 2022-12-14 07:18:23 --> URI Class Initialized
INFO - 2022-12-14 07:18:23 --> URI Class Initialized
INFO - 2022-12-14 07:18:23 --> Router Class Initialized
INFO - 2022-12-14 07:18:23 --> Router Class Initialized
INFO - 2022-12-14 07:18:23 --> Output Class Initialized
INFO - 2022-12-14 07:18:23 --> Output Class Initialized
INFO - 2022-12-14 07:18:23 --> Security Class Initialized
INFO - 2022-12-14 07:18:23 --> Security Class Initialized
DEBUG - 2022-12-14 07:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-14 07:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 07:18:23 --> Input Class Initialized
INFO - 2022-12-14 07:18:23 --> Input Class Initialized
INFO - 2022-12-14 07:18:23 --> Language Class Initialized
INFO - 2022-12-14 07:18:23 --> Language Class Initialized
INFO - 2022-12-14 07:18:23 --> Loader Class Initialized
INFO - 2022-12-14 07:18:23 --> Loader Class Initialized
INFO - 2022-12-14 07:18:23 --> Controller Class Initialized
INFO - 2022-12-14 07:18:23 --> Controller Class Initialized
DEBUG - 2022-12-14 07:18:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-14 07:18:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 07:18:23 --> Database Driver Class Initialized
INFO - 2022-12-14 07:18:23 --> Database Driver Class Initialized
INFO - 2022-12-14 07:18:23 --> Model "Cluster_model" initialized
INFO - 2022-12-14 07:18:23 --> Model "Cluster_model" initialized
INFO - 2022-12-14 07:18:23 --> Final output sent to browser
DEBUG - 2022-12-14 07:18:23 --> Total execution time: 0.2642
INFO - 2022-12-14 07:18:23 --> Config Class Initialized
INFO - 2022-12-14 07:18:23 --> Hooks Class Initialized
DEBUG - 2022-12-14 07:18:23 --> UTF-8 Support Enabled
INFO - 2022-12-14 07:18:23 --> Utf8 Class Initialized
INFO - 2022-12-14 07:18:23 --> URI Class Initialized
INFO - 2022-12-14 07:18:23 --> Router Class Initialized
INFO - 2022-12-14 07:18:23 --> Output Class Initialized
INFO - 2022-12-14 07:18:23 --> Security Class Initialized
DEBUG - 2022-12-14 07:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 07:18:23 --> Input Class Initialized
INFO - 2022-12-14 07:18:23 --> Language Class Initialized
INFO - 2022-12-14 07:18:23 --> Loader Class Initialized
INFO - 2022-12-14 07:18:23 --> Controller Class Initialized
DEBUG - 2022-12-14 07:18:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 07:18:23 --> Database Driver Class Initialized
INFO - 2022-12-14 07:18:23 --> Config Class Initialized
INFO - 2022-12-14 07:18:23 --> Hooks Class Initialized
DEBUG - 2022-12-14 07:18:23 --> UTF-8 Support Enabled
INFO - 2022-12-14 07:18:23 --> Utf8 Class Initialized
INFO - 2022-12-14 07:18:23 --> URI Class Initialized
INFO - 2022-12-14 07:18:23 --> Router Class Initialized
INFO - 2022-12-14 07:18:23 --> Output Class Initialized
INFO - 2022-12-14 07:18:23 --> Security Class Initialized
DEBUG - 2022-12-14 07:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 07:18:23 --> Model "Cluster_model" initialized
INFO - 2022-12-14 07:18:23 --> Input Class Initialized
INFO - 2022-12-14 07:18:23 --> Language Class Initialized
INFO - 2022-12-14 07:18:23 --> Final output sent to browser
DEBUG - 2022-12-14 07:18:23 --> Total execution time: 0.0766
INFO - 2022-12-14 07:18:23 --> Loader Class Initialized
INFO - 2022-12-14 07:18:23 --> Controller Class Initialized
DEBUG - 2022-12-14 07:18:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 07:18:23 --> Database Driver Class Initialized
INFO - 2022-12-14 07:18:23 --> Model "Cluster_model" initialized
INFO - 2022-12-14 07:18:55 --> Config Class Initialized
INFO - 2022-12-14 07:18:55 --> Hooks Class Initialized
DEBUG - 2022-12-14 07:18:55 --> UTF-8 Support Enabled
INFO - 2022-12-14 07:18:55 --> Utf8 Class Initialized
INFO - 2022-12-14 07:18:55 --> URI Class Initialized
INFO - 2022-12-14 07:18:55 --> Router Class Initialized
INFO - 2022-12-14 07:18:55 --> Output Class Initialized
INFO - 2022-12-14 07:18:55 --> Security Class Initialized
DEBUG - 2022-12-14 07:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 07:18:55 --> Input Class Initialized
INFO - 2022-12-14 07:18:55 --> Language Class Initialized
INFO - 2022-12-14 07:18:55 --> Loader Class Initialized
INFO - 2022-12-14 07:18:55 --> Controller Class Initialized
DEBUG - 2022-12-14 07:18:55 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 07:18:55 --> Database Driver Class Initialized
INFO - 2022-12-14 07:18:56 --> Model "Cluster_model" initialized
INFO - 2022-12-14 07:18:56 --> Config Class Initialized
INFO - 2022-12-14 07:18:56 --> Hooks Class Initialized
DEBUG - 2022-12-14 07:18:56 --> UTF-8 Support Enabled
INFO - 2022-12-14 07:18:56 --> Utf8 Class Initialized
INFO - 2022-12-14 07:18:56 --> URI Class Initialized
INFO - 2022-12-14 07:18:56 --> Router Class Initialized
INFO - 2022-12-14 07:18:56 --> Output Class Initialized
INFO - 2022-12-14 07:18:56 --> Security Class Initialized
DEBUG - 2022-12-14 07:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 07:18:56 --> Input Class Initialized
INFO - 2022-12-14 07:18:56 --> Language Class Initialized
INFO - 2022-12-14 07:18:56 --> Loader Class Initialized
INFO - 2022-12-14 07:18:56 --> Controller Class Initialized
DEBUG - 2022-12-14 07:18:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 07:18:56 --> Database Driver Class Initialized
INFO - 2022-12-14 07:18:56 --> Model "Cluster_model" initialized
INFO - 2022-12-14 07:18:57 --> Config Class Initialized
INFO - 2022-12-14 07:18:57 --> Hooks Class Initialized
INFO - 2022-12-14 07:18:57 --> Config Class Initialized
INFO - 2022-12-14 07:18:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 07:18:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 07:18:57 --> Utf8 Class Initialized
DEBUG - 2022-12-14 07:18:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 07:18:57 --> Utf8 Class Initialized
INFO - 2022-12-14 07:18:57 --> URI Class Initialized
INFO - 2022-12-14 07:18:57 --> URI Class Initialized
INFO - 2022-12-14 07:18:57 --> Router Class Initialized
INFO - 2022-12-14 07:18:57 --> Router Class Initialized
INFO - 2022-12-14 07:18:57 --> Output Class Initialized
INFO - 2022-12-14 07:18:57 --> Output Class Initialized
INFO - 2022-12-14 07:18:57 --> Security Class Initialized
INFO - 2022-12-14 07:18:57 --> Security Class Initialized
DEBUG - 2022-12-14 07:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 07:18:57 --> Input Class Initialized
DEBUG - 2022-12-14 07:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 07:18:57 --> Input Class Initialized
INFO - 2022-12-14 07:18:57 --> Language Class Initialized
INFO - 2022-12-14 07:18:57 --> Language Class Initialized
INFO - 2022-12-14 07:18:57 --> Loader Class Initialized
INFO - 2022-12-14 07:18:57 --> Loader Class Initialized
INFO - 2022-12-14 07:18:57 --> Controller Class Initialized
INFO - 2022-12-14 07:18:57 --> Controller Class Initialized
DEBUG - 2022-12-14 07:18:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-14 07:18:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 07:18:57 --> Database Driver Class Initialized
INFO - 2022-12-14 07:18:57 --> Model "Cluster_model" initialized
INFO - 2022-12-14 07:18:57 --> Database Driver Class Initialized
INFO - 2022-12-14 07:18:57 --> Model "Cluster_model" initialized
INFO - 2022-12-14 07:18:57 --> Final output sent to browser
DEBUG - 2022-12-14 07:18:57 --> Total execution time: 0.0440
INFO - 2022-12-14 07:18:57 --> Config Class Initialized
INFO - 2022-12-14 07:18:57 --> Hooks Class Initialized
DEBUG - 2022-12-14 07:18:57 --> UTF-8 Support Enabled
INFO - 2022-12-14 07:18:57 --> Utf8 Class Initialized
INFO - 2022-12-14 07:18:57 --> URI Class Initialized
INFO - 2022-12-14 07:18:57 --> Router Class Initialized
INFO - 2022-12-14 07:18:57 --> Output Class Initialized
INFO - 2022-12-14 07:18:57 --> Security Class Initialized
DEBUG - 2022-12-14 07:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 07:18:57 --> Input Class Initialized
INFO - 2022-12-14 07:18:57 --> Language Class Initialized
INFO - 2022-12-14 07:18:57 --> Loader Class Initialized
INFO - 2022-12-14 07:18:57 --> Controller Class Initialized
DEBUG - 2022-12-14 07:18:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 07:18:57 --> Database Driver Class Initialized
INFO - 2022-12-14 07:18:57 --> Model "Cluster_model" initialized
INFO - 2022-12-14 07:18:57 --> Final output sent to browser
DEBUG - 2022-12-14 07:18:57 --> Total execution time: 0.0461
INFO - 2022-12-14 07:19:11 --> Config Class Initialized
INFO - 2022-12-14 07:19:11 --> Hooks Class Initialized
DEBUG - 2022-12-14 07:19:11 --> UTF-8 Support Enabled
INFO - 2022-12-14 07:19:11 --> Utf8 Class Initialized
INFO - 2022-12-14 07:19:11 --> URI Class Initialized
INFO - 2022-12-14 07:19:11 --> Router Class Initialized
INFO - 2022-12-14 07:19:11 --> Output Class Initialized
INFO - 2022-12-14 07:19:11 --> Security Class Initialized
DEBUG - 2022-12-14 07:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 07:19:11 --> Input Class Initialized
INFO - 2022-12-14 07:19:11 --> Language Class Initialized
INFO - 2022-12-14 07:19:11 --> Loader Class Initialized
INFO - 2022-12-14 07:19:11 --> Controller Class Initialized
DEBUG - 2022-12-14 07:19:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 07:19:11 --> Database Driver Class Initialized
INFO - 2022-12-14 07:19:11 --> Model "Cluster_model" initialized
INFO - 2022-12-14 07:19:11 --> Final output sent to browser
DEBUG - 2022-12-14 07:19:11 --> Total execution time: 0.0490
INFO - 2022-12-14 07:19:11 --> Config Class Initialized
INFO - 2022-12-14 07:19:11 --> Hooks Class Initialized
DEBUG - 2022-12-14 07:19:11 --> UTF-8 Support Enabled
INFO - 2022-12-14 07:19:11 --> Utf8 Class Initialized
INFO - 2022-12-14 07:19:11 --> URI Class Initialized
INFO - 2022-12-14 07:19:11 --> Router Class Initialized
INFO - 2022-12-14 07:19:11 --> Output Class Initialized
INFO - 2022-12-14 07:19:11 --> Security Class Initialized
DEBUG - 2022-12-14 07:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 07:19:11 --> Input Class Initialized
INFO - 2022-12-14 07:19:11 --> Language Class Initialized
INFO - 2022-12-14 07:19:11 --> Loader Class Initialized
INFO - 2022-12-14 07:19:11 --> Controller Class Initialized
DEBUG - 2022-12-14 07:19:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 07:19:11 --> Database Driver Class Initialized
INFO - 2022-12-14 07:19:11 --> Model "Cluster_model" initialized
INFO - 2022-12-14 07:19:11 --> Final output sent to browser
DEBUG - 2022-12-14 07:19:11 --> Total execution time: 0.0534
INFO - 2022-12-14 07:19:12 --> Config Class Initialized
INFO - 2022-12-14 07:19:12 --> Hooks Class Initialized
DEBUG - 2022-12-14 07:19:12 --> UTF-8 Support Enabled
INFO - 2022-12-14 07:19:12 --> Utf8 Class Initialized
INFO - 2022-12-14 07:19:12 --> URI Class Initialized
INFO - 2022-12-14 07:19:12 --> Router Class Initialized
INFO - 2022-12-14 07:19:12 --> Output Class Initialized
INFO - 2022-12-14 07:19:12 --> Security Class Initialized
DEBUG - 2022-12-14 07:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 07:19:12 --> Input Class Initialized
INFO - 2022-12-14 07:19:12 --> Language Class Initialized
INFO - 2022-12-14 07:19:12 --> Loader Class Initialized
INFO - 2022-12-14 07:19:12 --> Controller Class Initialized
DEBUG - 2022-12-14 07:19:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 07:19:12 --> Database Driver Class Initialized
INFO - 2022-12-14 07:19:12 --> Model "Cluster_model" initialized
INFO - 2022-12-14 07:19:12 --> Final output sent to browser
DEBUG - 2022-12-14 07:19:12 --> Total execution time: 0.0579
INFO - 2022-12-14 07:19:12 --> Config Class Initialized
INFO - 2022-12-14 07:19:12 --> Hooks Class Initialized
DEBUG - 2022-12-14 07:19:12 --> UTF-8 Support Enabled
INFO - 2022-12-14 07:19:12 --> Utf8 Class Initialized
INFO - 2022-12-14 07:19:12 --> URI Class Initialized
INFO - 2022-12-14 07:19:12 --> Router Class Initialized
INFO - 2022-12-14 07:19:12 --> Output Class Initialized
INFO - 2022-12-14 07:19:12 --> Security Class Initialized
DEBUG - 2022-12-14 07:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 07:19:12 --> Input Class Initialized
INFO - 2022-12-14 07:19:12 --> Language Class Initialized
INFO - 2022-12-14 07:19:12 --> Loader Class Initialized
INFO - 2022-12-14 07:19:12 --> Controller Class Initialized
DEBUG - 2022-12-14 07:19:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 07:19:12 --> Database Driver Class Initialized
INFO - 2022-12-14 07:19:12 --> Model "Cluster_model" initialized
INFO - 2022-12-14 07:19:12 --> Final output sent to browser
DEBUG - 2022-12-14 07:19:12 --> Total execution time: 0.0681
INFO - 2022-12-14 08:06:02 --> Config Class Initialized
INFO - 2022-12-14 08:06:02 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:06:02 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:06:02 --> Utf8 Class Initialized
INFO - 2022-12-14 08:06:02 --> URI Class Initialized
INFO - 2022-12-14 08:06:02 --> Router Class Initialized
INFO - 2022-12-14 08:06:02 --> Output Class Initialized
INFO - 2022-12-14 08:06:02 --> Security Class Initialized
DEBUG - 2022-12-14 08:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:06:02 --> Input Class Initialized
INFO - 2022-12-14 08:06:02 --> Language Class Initialized
INFO - 2022-12-14 08:06:02 --> Loader Class Initialized
INFO - 2022-12-14 08:06:02 --> Controller Class Initialized
DEBUG - 2022-12-14 08:06:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:06:02 --> Database Driver Class Initialized
INFO - 2022-12-14 08:06:02 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:06:02 --> Database Driver Class Initialized
INFO - 2022-12-14 08:06:02 --> Model "Login_model" initialized
INFO - 2022-12-14 08:06:02 --> Final output sent to browser
DEBUG - 2022-12-14 08:06:02 --> Total execution time: 0.1152
INFO - 2022-12-14 08:06:02 --> Config Class Initialized
INFO - 2022-12-14 08:06:02 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:06:02 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:06:02 --> Utf8 Class Initialized
INFO - 2022-12-14 08:06:02 --> URI Class Initialized
INFO - 2022-12-14 08:06:02 --> Router Class Initialized
INFO - 2022-12-14 08:06:02 --> Output Class Initialized
INFO - 2022-12-14 08:06:02 --> Security Class Initialized
DEBUG - 2022-12-14 08:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:06:02 --> Input Class Initialized
INFO - 2022-12-14 08:06:02 --> Language Class Initialized
INFO - 2022-12-14 08:06:02 --> Loader Class Initialized
INFO - 2022-12-14 08:06:02 --> Controller Class Initialized
DEBUG - 2022-12-14 08:06:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:06:02 --> Database Driver Class Initialized
INFO - 2022-12-14 08:06:02 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:06:02 --> Database Driver Class Initialized
INFO - 2022-12-14 08:06:02 --> Model "Login_model" initialized
INFO - 2022-12-14 08:06:02 --> Final output sent to browser
DEBUG - 2022-12-14 08:06:02 --> Total execution time: 0.2772
INFO - 2022-12-14 08:12:20 --> Config Class Initialized
INFO - 2022-12-14 08:12:20 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:12:20 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:12:20 --> Utf8 Class Initialized
INFO - 2022-12-14 08:12:20 --> URI Class Initialized
INFO - 2022-12-14 08:12:20 --> Router Class Initialized
INFO - 2022-12-14 08:12:20 --> Output Class Initialized
INFO - 2022-12-14 08:12:20 --> Security Class Initialized
DEBUG - 2022-12-14 08:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:12:20 --> Input Class Initialized
INFO - 2022-12-14 08:12:20 --> Language Class Initialized
INFO - 2022-12-14 08:12:20 --> Loader Class Initialized
INFO - 2022-12-14 08:12:20 --> Controller Class Initialized
DEBUG - 2022-12-14 08:12:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:12:20 --> Database Driver Class Initialized
INFO - 2022-12-14 08:12:20 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:12:20 --> Config Class Initialized
INFO - 2022-12-14 08:12:20 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:12:20 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:12:20 --> Utf8 Class Initialized
INFO - 2022-12-14 08:12:20 --> URI Class Initialized
INFO - 2022-12-14 08:12:20 --> Router Class Initialized
INFO - 2022-12-14 08:12:20 --> Output Class Initialized
INFO - 2022-12-14 08:12:20 --> Security Class Initialized
DEBUG - 2022-12-14 08:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:12:20 --> Input Class Initialized
INFO - 2022-12-14 08:12:20 --> Language Class Initialized
INFO - 2022-12-14 08:12:21 --> Loader Class Initialized
INFO - 2022-12-14 08:12:21 --> Controller Class Initialized
DEBUG - 2022-12-14 08:12:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:12:21 --> Database Driver Class Initialized
INFO - 2022-12-14 08:12:21 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:12:22 --> Config Class Initialized
INFO - 2022-12-14 08:12:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:12:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:12:22 --> Utf8 Class Initialized
INFO - 2022-12-14 08:12:22 --> URI Class Initialized
INFO - 2022-12-14 08:12:22 --> Router Class Initialized
INFO - 2022-12-14 08:12:22 --> Output Class Initialized
INFO - 2022-12-14 08:12:22 --> Security Class Initialized
DEBUG - 2022-12-14 08:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:12:22 --> Input Class Initialized
INFO - 2022-12-14 08:12:22 --> Language Class Initialized
INFO - 2022-12-14 08:12:22 --> Config Class Initialized
INFO - 2022-12-14 08:12:22 --> Hooks Class Initialized
INFO - 2022-12-14 08:12:22 --> Loader Class Initialized
INFO - 2022-12-14 08:12:22 --> Controller Class Initialized
DEBUG - 2022-12-14 08:12:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:12:22 --> Utf8 Class Initialized
DEBUG - 2022-12-14 08:12:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:12:22 --> URI Class Initialized
INFO - 2022-12-14 08:12:22 --> Router Class Initialized
INFO - 2022-12-14 08:12:22 --> Database Driver Class Initialized
INFO - 2022-12-14 08:12:22 --> Output Class Initialized
INFO - 2022-12-14 08:12:22 --> Security Class Initialized
DEBUG - 2022-12-14 08:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:12:22 --> Input Class Initialized
INFO - 2022-12-14 08:12:22 --> Language Class Initialized
INFO - 2022-12-14 08:12:22 --> Loader Class Initialized
INFO - 2022-12-14 08:12:22 --> Controller Class Initialized
DEBUG - 2022-12-14 08:12:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:12:22 --> Database Driver Class Initialized
INFO - 2022-12-14 08:12:22 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:12:22 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:12:22 --> Final output sent to browser
DEBUG - 2022-12-14 08:12:22 --> Total execution time: 0.0563
INFO - 2022-12-14 08:12:22 --> Config Class Initialized
INFO - 2022-12-14 08:12:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:12:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:12:22 --> Utf8 Class Initialized
INFO - 2022-12-14 08:12:22 --> URI Class Initialized
INFO - 2022-12-14 08:12:22 --> Router Class Initialized
INFO - 2022-12-14 08:12:22 --> Output Class Initialized
INFO - 2022-12-14 08:12:22 --> Security Class Initialized
DEBUG - 2022-12-14 08:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:12:22 --> Input Class Initialized
INFO - 2022-12-14 08:12:22 --> Language Class Initialized
INFO - 2022-12-14 08:12:22 --> Loader Class Initialized
INFO - 2022-12-14 08:12:22 --> Controller Class Initialized
DEBUG - 2022-12-14 08:12:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:12:22 --> Database Driver Class Initialized
INFO - 2022-12-14 08:12:22 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:12:22 --> Final output sent to browser
DEBUG - 2022-12-14 08:12:22 --> Total execution time: 0.0683
INFO - 2022-12-14 08:12:23 --> Config Class Initialized
INFO - 2022-12-14 08:12:23 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:12:23 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:12:23 --> Utf8 Class Initialized
INFO - 2022-12-14 08:12:23 --> URI Class Initialized
INFO - 2022-12-14 08:12:23 --> Router Class Initialized
INFO - 2022-12-14 08:12:23 --> Output Class Initialized
INFO - 2022-12-14 08:12:23 --> Security Class Initialized
DEBUG - 2022-12-14 08:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:12:23 --> Input Class Initialized
INFO - 2022-12-14 08:12:23 --> Language Class Initialized
INFO - 2022-12-14 08:12:23 --> Loader Class Initialized
INFO - 2022-12-14 08:12:23 --> Controller Class Initialized
DEBUG - 2022-12-14 08:12:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:12:23 --> Database Driver Class Initialized
INFO - 2022-12-14 08:12:23 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:12:24 --> Config Class Initialized
INFO - 2022-12-14 08:12:24 --> Config Class Initialized
INFO - 2022-12-14 08:12:24 --> Hooks Class Initialized
INFO - 2022-12-14 08:12:24 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-14 08:12:24 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:12:24 --> Utf8 Class Initialized
INFO - 2022-12-14 08:12:24 --> Utf8 Class Initialized
INFO - 2022-12-14 08:12:24 --> URI Class Initialized
INFO - 2022-12-14 08:12:24 --> URI Class Initialized
INFO - 2022-12-14 08:12:24 --> Router Class Initialized
INFO - 2022-12-14 08:12:24 --> Router Class Initialized
INFO - 2022-12-14 08:12:24 --> Output Class Initialized
INFO - 2022-12-14 08:12:24 --> Output Class Initialized
INFO - 2022-12-14 08:12:24 --> Security Class Initialized
INFO - 2022-12-14 08:12:24 --> Security Class Initialized
DEBUG - 2022-12-14 08:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:12:24 --> Input Class Initialized
DEBUG - 2022-12-14 08:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:12:24 --> Input Class Initialized
INFO - 2022-12-14 08:12:24 --> Language Class Initialized
INFO - 2022-12-14 08:12:24 --> Language Class Initialized
INFO - 2022-12-14 08:12:24 --> Loader Class Initialized
INFO - 2022-12-14 08:12:24 --> Loader Class Initialized
INFO - 2022-12-14 08:12:24 --> Controller Class Initialized
DEBUG - 2022-12-14 08:12:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:12:24 --> Controller Class Initialized
DEBUG - 2022-12-14 08:12:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:12:24 --> Database Driver Class Initialized
INFO - 2022-12-14 08:12:24 --> Database Driver Class Initialized
INFO - 2022-12-14 08:12:25 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:12:25 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:12:25 --> Final output sent to browser
DEBUG - 2022-12-14 08:12:25 --> Total execution time: 0.0384
INFO - 2022-12-14 08:14:05 --> Config Class Initialized
INFO - 2022-12-14 08:14:05 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:14:05 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:14:05 --> Utf8 Class Initialized
INFO - 2022-12-14 08:14:05 --> URI Class Initialized
INFO - 2022-12-14 08:14:05 --> Router Class Initialized
INFO - 2022-12-14 08:14:05 --> Output Class Initialized
INFO - 2022-12-14 08:14:05 --> Security Class Initialized
DEBUG - 2022-12-14 08:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:14:05 --> Input Class Initialized
INFO - 2022-12-14 08:14:05 --> Language Class Initialized
INFO - 2022-12-14 08:14:05 --> Loader Class Initialized
INFO - 2022-12-14 08:14:05 --> Controller Class Initialized
DEBUG - 2022-12-14 08:14:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:14:05 --> Database Driver Class Initialized
INFO - 2022-12-14 08:14:05 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:14:05 --> Final output sent to browser
DEBUG - 2022-12-14 08:14:05 --> Total execution time: 0.0727
INFO - 2022-12-14 08:14:05 --> Config Class Initialized
INFO - 2022-12-14 08:14:05 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:14:05 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:14:05 --> Utf8 Class Initialized
INFO - 2022-12-14 08:14:05 --> URI Class Initialized
INFO - 2022-12-14 08:14:05 --> Router Class Initialized
INFO - 2022-12-14 08:14:05 --> Output Class Initialized
INFO - 2022-12-14 08:14:05 --> Security Class Initialized
DEBUG - 2022-12-14 08:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:14:05 --> Input Class Initialized
INFO - 2022-12-14 08:14:05 --> Language Class Initialized
INFO - 2022-12-14 08:14:05 --> Loader Class Initialized
INFO - 2022-12-14 08:14:05 --> Controller Class Initialized
DEBUG - 2022-12-14 08:14:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:14:05 --> Database Driver Class Initialized
INFO - 2022-12-14 08:14:05 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:14:05 --> Final output sent to browser
DEBUG - 2022-12-14 08:14:05 --> Total execution time: 0.2105
INFO - 2022-12-14 08:14:10 --> Config Class Initialized
INFO - 2022-12-14 08:14:10 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:14:10 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:14:10 --> Utf8 Class Initialized
INFO - 2022-12-14 08:14:10 --> URI Class Initialized
INFO - 2022-12-14 08:14:10 --> Router Class Initialized
INFO - 2022-12-14 08:14:10 --> Output Class Initialized
INFO - 2022-12-14 08:14:10 --> Security Class Initialized
DEBUG - 2022-12-14 08:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:14:10 --> Input Class Initialized
INFO - 2022-12-14 08:14:10 --> Language Class Initialized
INFO - 2022-12-14 08:14:10 --> Loader Class Initialized
INFO - 2022-12-14 08:14:10 --> Controller Class Initialized
DEBUG - 2022-12-14 08:14:10 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:14:10 --> Database Driver Class Initialized
INFO - 2022-12-14 08:14:10 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:14:10 --> Final output sent to browser
DEBUG - 2022-12-14 08:14:10 --> Total execution time: 0.0538
INFO - 2022-12-14 08:14:10 --> Config Class Initialized
INFO - 2022-12-14 08:14:10 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:14:10 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:14:10 --> Utf8 Class Initialized
INFO - 2022-12-14 08:14:10 --> URI Class Initialized
INFO - 2022-12-14 08:14:10 --> Router Class Initialized
INFO - 2022-12-14 08:14:10 --> Output Class Initialized
INFO - 2022-12-14 08:14:10 --> Security Class Initialized
DEBUG - 2022-12-14 08:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:14:10 --> Input Class Initialized
INFO - 2022-12-14 08:14:10 --> Language Class Initialized
INFO - 2022-12-14 08:14:10 --> Loader Class Initialized
INFO - 2022-12-14 08:14:10 --> Controller Class Initialized
DEBUG - 2022-12-14 08:14:10 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:14:10 --> Database Driver Class Initialized
INFO - 2022-12-14 08:14:10 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:14:10 --> Final output sent to browser
DEBUG - 2022-12-14 08:14:10 --> Total execution time: 0.0371
INFO - 2022-12-14 08:14:14 --> Config Class Initialized
INFO - 2022-12-14 08:14:14 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:14:14 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:14:14 --> Utf8 Class Initialized
INFO - 2022-12-14 08:14:14 --> URI Class Initialized
INFO - 2022-12-14 08:14:14 --> Router Class Initialized
INFO - 2022-12-14 08:14:14 --> Output Class Initialized
INFO - 2022-12-14 08:14:14 --> Security Class Initialized
DEBUG - 2022-12-14 08:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:14:14 --> Input Class Initialized
INFO - 2022-12-14 08:14:14 --> Language Class Initialized
INFO - 2022-12-14 08:14:14 --> Loader Class Initialized
INFO - 2022-12-14 08:14:14 --> Controller Class Initialized
DEBUG - 2022-12-14 08:14:14 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:14:14 --> Database Driver Class Initialized
INFO - 2022-12-14 08:14:14 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:14:14 --> Final output sent to browser
DEBUG - 2022-12-14 08:14:14 --> Total execution time: 0.1001
INFO - 2022-12-14 08:14:14 --> Config Class Initialized
INFO - 2022-12-14 08:14:14 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:14:14 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:14:14 --> Utf8 Class Initialized
INFO - 2022-12-14 08:14:14 --> URI Class Initialized
INFO - 2022-12-14 08:14:14 --> Router Class Initialized
INFO - 2022-12-14 08:14:14 --> Output Class Initialized
INFO - 2022-12-14 08:14:14 --> Security Class Initialized
DEBUG - 2022-12-14 08:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:14:14 --> Input Class Initialized
INFO - 2022-12-14 08:14:14 --> Language Class Initialized
INFO - 2022-12-14 08:14:14 --> Loader Class Initialized
INFO - 2022-12-14 08:14:14 --> Controller Class Initialized
DEBUG - 2022-12-14 08:14:14 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:14:14 --> Database Driver Class Initialized
INFO - 2022-12-14 08:14:14 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:14:14 --> Final output sent to browser
DEBUG - 2022-12-14 08:14:14 --> Total execution time: 0.0724
INFO - 2022-12-14 08:25:39 --> Config Class Initialized
INFO - 2022-12-14 08:25:39 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:25:39 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:25:39 --> Utf8 Class Initialized
INFO - 2022-12-14 08:25:39 --> URI Class Initialized
INFO - 2022-12-14 08:25:39 --> Router Class Initialized
INFO - 2022-12-14 08:25:39 --> Output Class Initialized
INFO - 2022-12-14 08:25:39 --> Security Class Initialized
DEBUG - 2022-12-14 08:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:25:39 --> Input Class Initialized
INFO - 2022-12-14 08:25:40 --> Language Class Initialized
INFO - 2022-12-14 08:25:40 --> Loader Class Initialized
INFO - 2022-12-14 08:25:40 --> Controller Class Initialized
DEBUG - 2022-12-14 08:25:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:25:40 --> Database Driver Class Initialized
INFO - 2022-12-14 08:25:40 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:25:40 --> Final output sent to browser
DEBUG - 2022-12-14 08:25:40 --> Total execution time: 0.0382
INFO - 2022-12-14 08:25:40 --> Config Class Initialized
INFO - 2022-12-14 08:25:40 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:25:40 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:25:40 --> Utf8 Class Initialized
INFO - 2022-12-14 08:25:40 --> URI Class Initialized
INFO - 2022-12-14 08:25:40 --> Router Class Initialized
INFO - 2022-12-14 08:25:40 --> Output Class Initialized
INFO - 2022-12-14 08:25:40 --> Security Class Initialized
DEBUG - 2022-12-14 08:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:25:40 --> Input Class Initialized
INFO - 2022-12-14 08:25:40 --> Language Class Initialized
INFO - 2022-12-14 08:25:40 --> Loader Class Initialized
INFO - 2022-12-14 08:25:40 --> Controller Class Initialized
DEBUG - 2022-12-14 08:25:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:25:40 --> Database Driver Class Initialized
INFO - 2022-12-14 08:25:40 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:25:40 --> Final output sent to browser
DEBUG - 2022-12-14 08:25:40 --> Total execution time: 0.0519
INFO - 2022-12-14 08:30:08 --> Config Class Initialized
INFO - 2022-12-14 08:30:08 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:30:08 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:08 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:08 --> URI Class Initialized
INFO - 2022-12-14 08:30:08 --> Router Class Initialized
INFO - 2022-12-14 08:30:08 --> Output Class Initialized
INFO - 2022-12-14 08:30:08 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:08 --> Input Class Initialized
INFO - 2022-12-14 08:30:08 --> Language Class Initialized
INFO - 2022-12-14 08:30:08 --> Loader Class Initialized
INFO - 2022-12-14 08:30:08 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:08 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:08 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:08 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:30:08 --> Final output sent to browser
DEBUG - 2022-12-14 08:30:08 --> Total execution time: 0.0590
INFO - 2022-12-14 08:30:08 --> Config Class Initialized
INFO - 2022-12-14 08:30:08 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:30:08 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:08 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:08 --> URI Class Initialized
INFO - 2022-12-14 08:30:08 --> Router Class Initialized
INFO - 2022-12-14 08:30:08 --> Output Class Initialized
INFO - 2022-12-14 08:30:08 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:08 --> Input Class Initialized
INFO - 2022-12-14 08:30:08 --> Language Class Initialized
INFO - 2022-12-14 08:30:08 --> Loader Class Initialized
INFO - 2022-12-14 08:30:08 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:08 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:08 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:08 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:30:08 --> Final output sent to browser
DEBUG - 2022-12-14 08:30:08 --> Total execution time: 0.0553
INFO - 2022-12-14 08:30:11 --> Config Class Initialized
INFO - 2022-12-14 08:30:11 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:30:11 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:11 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:11 --> URI Class Initialized
INFO - 2022-12-14 08:30:11 --> Router Class Initialized
INFO - 2022-12-14 08:30:11 --> Output Class Initialized
INFO - 2022-12-14 08:30:11 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:11 --> Input Class Initialized
INFO - 2022-12-14 08:30:11 --> Language Class Initialized
INFO - 2022-12-14 08:30:11 --> Loader Class Initialized
INFO - 2022-12-14 08:30:11 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:11 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:11 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:30:11 --> Final output sent to browser
DEBUG - 2022-12-14 08:30:11 --> Total execution time: 0.0662
INFO - 2022-12-14 08:30:11 --> Config Class Initialized
INFO - 2022-12-14 08:30:11 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:30:11 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:11 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:11 --> URI Class Initialized
INFO - 2022-12-14 08:30:11 --> Router Class Initialized
INFO - 2022-12-14 08:30:11 --> Output Class Initialized
INFO - 2022-12-14 08:30:11 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:11 --> Input Class Initialized
INFO - 2022-12-14 08:30:11 --> Language Class Initialized
INFO - 2022-12-14 08:30:11 --> Loader Class Initialized
INFO - 2022-12-14 08:30:11 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:11 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:11 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:30:11 --> Final output sent to browser
DEBUG - 2022-12-14 08:30:11 --> Total execution time: 0.1113
INFO - 2022-12-14 08:30:12 --> Config Class Initialized
INFO - 2022-12-14 08:30:12 --> Hooks Class Initialized
INFO - 2022-12-14 08:30:12 --> Config Class Initialized
INFO - 2022-12-14 08:30:12 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:30:12 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:12 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:12 --> URI Class Initialized
DEBUG - 2022-12-14 08:30:12 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:12 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:12 --> Router Class Initialized
INFO - 2022-12-14 08:30:12 --> URI Class Initialized
INFO - 2022-12-14 08:30:12 --> Output Class Initialized
INFO - 2022-12-14 08:30:12 --> Router Class Initialized
INFO - 2022-12-14 08:30:12 --> Security Class Initialized
INFO - 2022-12-14 08:30:12 --> Output Class Initialized
DEBUG - 2022-12-14 08:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:12 --> Input Class Initialized
INFO - 2022-12-14 08:30:12 --> Language Class Initialized
INFO - 2022-12-14 08:30:12 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:12 --> Input Class Initialized
INFO - 2022-12-14 08:30:12 --> Language Class Initialized
INFO - 2022-12-14 08:30:12 --> Loader Class Initialized
INFO - 2022-12-14 08:30:12 --> Loader Class Initialized
INFO - 2022-12-14 08:30:12 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:12 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:12 --> Final output sent to browser
DEBUG - 2022-12-14 08:30:12 --> Total execution time: 0.0207
INFO - 2022-12-14 08:30:12 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:12 --> Config Class Initialized
INFO - 2022-12-14 08:30:12 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:30:12 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:12 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:12 --> URI Class Initialized
INFO - 2022-12-14 08:30:12 --> Router Class Initialized
INFO - 2022-12-14 08:30:12 --> Output Class Initialized
INFO - 2022-12-14 08:30:12 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:12 --> Input Class Initialized
INFO - 2022-12-14 08:30:12 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:30:12 --> Language Class Initialized
INFO - 2022-12-14 08:30:12 --> Loader Class Initialized
INFO - 2022-12-14 08:30:12 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:12 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:12 --> Final output sent to browser
DEBUG - 2022-12-14 08:30:12 --> Total execution time: 0.0564
INFO - 2022-12-14 08:30:12 --> Config Class Initialized
INFO - 2022-12-14 08:30:12 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:30:13 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:13 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:13 --> URI Class Initialized
INFO - 2022-12-14 08:30:13 --> Router Class Initialized
INFO - 2022-12-14 08:30:13 --> Output Class Initialized
INFO - 2022-12-14 08:30:13 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:13 --> Input Class Initialized
INFO - 2022-12-14 08:30:13 --> Language Class Initialized
INFO - 2022-12-14 08:30:13 --> Loader Class Initialized
INFO - 2022-12-14 08:30:13 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:13 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:13 --> Model "Login_model" initialized
INFO - 2022-12-14 08:30:13 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:13 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:13 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:30:13 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:30:13 --> Final output sent to browser
DEBUG - 2022-12-14 08:30:13 --> Total execution time: 0.0886
INFO - 2022-12-14 08:30:13 --> Final output sent to browser
DEBUG - 2022-12-14 08:30:13 --> Total execution time: 0.0769
INFO - 2022-12-14 08:30:16 --> Config Class Initialized
INFO - 2022-12-14 08:30:16 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:30:16 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:16 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:16 --> URI Class Initialized
INFO - 2022-12-14 08:30:16 --> Router Class Initialized
INFO - 2022-12-14 08:30:16 --> Output Class Initialized
INFO - 2022-12-14 08:30:16 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:16 --> Input Class Initialized
INFO - 2022-12-14 08:30:16 --> Language Class Initialized
INFO - 2022-12-14 08:30:16 --> Loader Class Initialized
INFO - 2022-12-14 08:30:16 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:16 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:16 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:16 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:30:16 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:16 --> Model "Login_model" initialized
INFO - 2022-12-14 08:30:16 --> Final output sent to browser
DEBUG - 2022-12-14 08:30:16 --> Total execution time: 0.1132
INFO - 2022-12-14 08:30:16 --> Config Class Initialized
INFO - 2022-12-14 08:30:16 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:30:16 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:16 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:16 --> URI Class Initialized
INFO - 2022-12-14 08:30:16 --> Router Class Initialized
INFO - 2022-12-14 08:30:16 --> Output Class Initialized
INFO - 2022-12-14 08:30:16 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:16 --> Input Class Initialized
INFO - 2022-12-14 08:30:16 --> Language Class Initialized
INFO - 2022-12-14 08:30:16 --> Loader Class Initialized
INFO - 2022-12-14 08:30:16 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:16 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:16 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:16 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:30:16 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:16 --> Model "Login_model" initialized
INFO - 2022-12-14 08:30:16 --> Final output sent to browser
DEBUG - 2022-12-14 08:30:16 --> Total execution time: 0.2561
INFO - 2022-12-14 08:30:21 --> Config Class Initialized
INFO - 2022-12-14 08:30:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:30:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:21 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:21 --> URI Class Initialized
INFO - 2022-12-14 08:30:21 --> Router Class Initialized
INFO - 2022-12-14 08:30:21 --> Output Class Initialized
INFO - 2022-12-14 08:30:21 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:21 --> Input Class Initialized
INFO - 2022-12-14 08:30:21 --> Language Class Initialized
INFO - 2022-12-14 08:30:21 --> Loader Class Initialized
INFO - 2022-12-14 08:30:21 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:21 --> Config Class Initialized
INFO - 2022-12-14 08:30:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:30:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:21 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:21 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:21 --> URI Class Initialized
INFO - 2022-12-14 08:30:21 --> Router Class Initialized
INFO - 2022-12-14 08:30:21 --> Output Class Initialized
INFO - 2022-12-14 08:30:21 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:21 --> Input Class Initialized
INFO - 2022-12-14 08:30:21 --> Language Class Initialized
INFO - 2022-12-14 08:30:21 --> Loader Class Initialized
INFO - 2022-12-14 08:30:21 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:21 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:30:21 --> Final output sent to browser
DEBUG - 2022-12-14 08:30:21 --> Total execution time: 0.0438
INFO - 2022-12-14 08:30:21 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:21 --> Config Class Initialized
INFO - 2022-12-14 08:30:21 --> Hooks Class Initialized
INFO - 2022-12-14 08:30:21 --> Model "Cluster_model" initialized
DEBUG - 2022-12-14 08:30:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:21 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:21 --> URI Class Initialized
INFO - 2022-12-14 08:30:21 --> Router Class Initialized
INFO - 2022-12-14 08:30:21 --> Output Class Initialized
INFO - 2022-12-14 08:30:21 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:21 --> Input Class Initialized
INFO - 2022-12-14 08:30:21 --> Language Class Initialized
INFO - 2022-12-14 08:30:21 --> Loader Class Initialized
INFO - 2022-12-14 08:30:21 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:21 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:21 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:30:21 --> Final output sent to browser
DEBUG - 2022-12-14 08:30:21 --> Total execution time: 0.0550
INFO - 2022-12-14 08:30:21 --> Config Class Initialized
INFO - 2022-12-14 08:30:21 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:30:21 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:21 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:21 --> URI Class Initialized
INFO - 2022-12-14 08:30:21 --> Router Class Initialized
INFO - 2022-12-14 08:30:21 --> Output Class Initialized
INFO - 2022-12-14 08:30:21 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:21 --> Input Class Initialized
INFO - 2022-12-14 08:30:21 --> Language Class Initialized
INFO - 2022-12-14 08:30:21 --> Loader Class Initialized
INFO - 2022-12-14 08:30:21 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:21 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:21 --> Model "Cluster_model" initialized
INFO - 2022-12-14 08:30:22 --> Config Class Initialized
INFO - 2022-12-14 08:30:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 08:30:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 08:30:22 --> Utf8 Class Initialized
INFO - 2022-12-14 08:30:22 --> URI Class Initialized
INFO - 2022-12-14 08:30:22 --> Router Class Initialized
INFO - 2022-12-14 08:30:22 --> Output Class Initialized
INFO - 2022-12-14 08:30:22 --> Security Class Initialized
DEBUG - 2022-12-14 08:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 08:30:22 --> Input Class Initialized
INFO - 2022-12-14 08:30:22 --> Language Class Initialized
INFO - 2022-12-14 08:30:22 --> Loader Class Initialized
INFO - 2022-12-14 08:30:22 --> Controller Class Initialized
DEBUG - 2022-12-14 08:30:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 08:30:22 --> Database Driver Class Initialized
INFO - 2022-12-14 08:30:22 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:01:22 --> Config Class Initialized
INFO - 2022-12-14 09:01:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:01:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:01:22 --> Utf8 Class Initialized
INFO - 2022-12-14 09:01:22 --> URI Class Initialized
INFO - 2022-12-14 09:01:22 --> Router Class Initialized
INFO - 2022-12-14 09:01:22 --> Output Class Initialized
INFO - 2022-12-14 09:01:22 --> Security Class Initialized
DEBUG - 2022-12-14 09:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:01:22 --> Input Class Initialized
INFO - 2022-12-14 09:01:22 --> Language Class Initialized
INFO - 2022-12-14 09:01:22 --> Loader Class Initialized
INFO - 2022-12-14 09:01:22 --> Controller Class Initialized
DEBUG - 2022-12-14 09:01:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:01:22 --> Database Driver Class Initialized
INFO - 2022-12-14 09:01:22 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:01:22 --> Final output sent to browser
DEBUG - 2022-12-14 09:01:22 --> Total execution time: 0.0472
INFO - 2022-12-14 09:01:22 --> Config Class Initialized
INFO - 2022-12-14 09:01:22 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:01:22 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:01:22 --> Utf8 Class Initialized
INFO - 2022-12-14 09:01:22 --> URI Class Initialized
INFO - 2022-12-14 09:01:22 --> Router Class Initialized
INFO - 2022-12-14 09:01:22 --> Output Class Initialized
INFO - 2022-12-14 09:01:22 --> Security Class Initialized
DEBUG - 2022-12-14 09:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:01:22 --> Input Class Initialized
INFO - 2022-12-14 09:01:22 --> Language Class Initialized
INFO - 2022-12-14 09:01:22 --> Loader Class Initialized
INFO - 2022-12-14 09:01:22 --> Controller Class Initialized
DEBUG - 2022-12-14 09:01:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:01:22 --> Database Driver Class Initialized
INFO - 2022-12-14 09:01:22 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:01:22 --> Final output sent to browser
DEBUG - 2022-12-14 09:01:22 --> Total execution time: 0.2578
INFO - 2022-12-14 09:01:25 --> Config Class Initialized
INFO - 2022-12-14 09:01:25 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:01:25 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:01:25 --> Utf8 Class Initialized
INFO - 2022-12-14 09:01:25 --> URI Class Initialized
INFO - 2022-12-14 09:01:25 --> Router Class Initialized
INFO - 2022-12-14 09:01:25 --> Output Class Initialized
INFO - 2022-12-14 09:01:25 --> Security Class Initialized
DEBUG - 2022-12-14 09:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:01:25 --> Input Class Initialized
INFO - 2022-12-14 09:01:25 --> Language Class Initialized
INFO - 2022-12-14 09:01:25 --> Loader Class Initialized
INFO - 2022-12-14 09:01:25 --> Controller Class Initialized
DEBUG - 2022-12-14 09:01:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:01:25 --> Database Driver Class Initialized
INFO - 2022-12-14 09:01:25 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:01:25 --> Final output sent to browser
DEBUG - 2022-12-14 09:01:25 --> Total execution time: 0.0385
INFO - 2022-12-14 09:01:25 --> Config Class Initialized
INFO - 2022-12-14 09:01:25 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:01:25 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:01:25 --> Utf8 Class Initialized
INFO - 2022-12-14 09:01:25 --> URI Class Initialized
INFO - 2022-12-14 09:01:25 --> Router Class Initialized
INFO - 2022-12-14 09:01:25 --> Output Class Initialized
INFO - 2022-12-14 09:01:25 --> Security Class Initialized
DEBUG - 2022-12-14 09:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:01:25 --> Input Class Initialized
INFO - 2022-12-14 09:01:25 --> Language Class Initialized
INFO - 2022-12-14 09:01:25 --> Loader Class Initialized
INFO - 2022-12-14 09:01:25 --> Controller Class Initialized
DEBUG - 2022-12-14 09:01:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:01:25 --> Database Driver Class Initialized
INFO - 2022-12-14 09:01:25 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:01:25 --> Final output sent to browser
DEBUG - 2022-12-14 09:01:25 --> Total execution time: 0.0414
INFO - 2022-12-14 09:01:27 --> Config Class Initialized
INFO - 2022-12-14 09:01:27 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:01:27 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:01:27 --> Utf8 Class Initialized
INFO - 2022-12-14 09:01:27 --> URI Class Initialized
INFO - 2022-12-14 09:01:27 --> Router Class Initialized
INFO - 2022-12-14 09:01:27 --> Output Class Initialized
INFO - 2022-12-14 09:01:27 --> Security Class Initialized
DEBUG - 2022-12-14 09:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:01:27 --> Input Class Initialized
INFO - 2022-12-14 09:01:27 --> Language Class Initialized
INFO - 2022-12-14 09:01:27 --> Loader Class Initialized
INFO - 2022-12-14 09:01:27 --> Controller Class Initialized
DEBUG - 2022-12-14 09:01:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:01:27 --> Final output sent to browser
DEBUG - 2022-12-14 09:01:27 --> Total execution time: 0.0203
INFO - 2022-12-14 09:01:27 --> Config Class Initialized
INFO - 2022-12-14 09:01:27 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:01:27 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:01:27 --> Utf8 Class Initialized
INFO - 2022-12-14 09:01:27 --> URI Class Initialized
INFO - 2022-12-14 09:01:27 --> Router Class Initialized
INFO - 2022-12-14 09:01:27 --> Output Class Initialized
INFO - 2022-12-14 09:01:27 --> Security Class Initialized
DEBUG - 2022-12-14 09:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:01:27 --> Input Class Initialized
INFO - 2022-12-14 09:01:27 --> Language Class Initialized
INFO - 2022-12-14 09:01:27 --> Loader Class Initialized
INFO - 2022-12-14 09:01:27 --> Controller Class Initialized
DEBUG - 2022-12-14 09:01:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:01:27 --> Database Driver Class Initialized
INFO - 2022-12-14 09:01:27 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:01:27 --> Final output sent to browser
DEBUG - 2022-12-14 09:01:27 --> Total execution time: 0.0545
INFO - 2022-12-14 09:01:31 --> Config Class Initialized
INFO - 2022-12-14 09:01:31 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:01:31 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:01:31 --> Utf8 Class Initialized
INFO - 2022-12-14 09:01:31 --> URI Class Initialized
INFO - 2022-12-14 09:01:31 --> Router Class Initialized
INFO - 2022-12-14 09:01:31 --> Output Class Initialized
INFO - 2022-12-14 09:01:31 --> Security Class Initialized
DEBUG - 2022-12-14 09:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:01:31 --> Input Class Initialized
INFO - 2022-12-14 09:01:31 --> Language Class Initialized
INFO - 2022-12-14 09:01:31 --> Loader Class Initialized
INFO - 2022-12-14 09:01:31 --> Controller Class Initialized
DEBUG - 2022-12-14 09:01:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:01:31 --> Final output sent to browser
DEBUG - 2022-12-14 09:01:31 --> Total execution time: 0.0205
INFO - 2022-12-14 09:01:31 --> Config Class Initialized
INFO - 2022-12-14 09:01:31 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:01:31 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:01:31 --> Utf8 Class Initialized
INFO - 2022-12-14 09:01:31 --> URI Class Initialized
INFO - 2022-12-14 09:01:31 --> Router Class Initialized
INFO - 2022-12-14 09:01:31 --> Output Class Initialized
INFO - 2022-12-14 09:01:31 --> Security Class Initialized
DEBUG - 2022-12-14 09:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:01:31 --> Input Class Initialized
INFO - 2022-12-14 09:01:31 --> Language Class Initialized
INFO - 2022-12-14 09:01:31 --> Loader Class Initialized
INFO - 2022-12-14 09:01:31 --> Controller Class Initialized
DEBUG - 2022-12-14 09:01:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:01:31 --> Database Driver Class Initialized
INFO - 2022-12-14 09:01:31 --> Model "Login_model" initialized
INFO - 2022-12-14 09:01:31 --> Final output sent to browser
DEBUG - 2022-12-14 09:01:31 --> Total execution time: 0.0350
INFO - 2022-12-14 09:01:34 --> Config Class Initialized
INFO - 2022-12-14 09:01:34 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:01:34 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:01:34 --> Utf8 Class Initialized
INFO - 2022-12-14 09:01:34 --> URI Class Initialized
INFO - 2022-12-14 09:01:34 --> Router Class Initialized
INFO - 2022-12-14 09:01:34 --> Output Class Initialized
INFO - 2022-12-14 09:01:34 --> Security Class Initialized
DEBUG - 2022-12-14 09:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:01:34 --> Input Class Initialized
INFO - 2022-12-14 09:01:34 --> Language Class Initialized
INFO - 2022-12-14 09:01:34 --> Loader Class Initialized
INFO - 2022-12-14 09:01:34 --> Controller Class Initialized
DEBUG - 2022-12-14 09:01:34 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:01:34 --> Final output sent to browser
DEBUG - 2022-12-14 09:01:34 --> Total execution time: 0.0209
INFO - 2022-12-14 09:01:34 --> Config Class Initialized
INFO - 2022-12-14 09:01:34 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:01:34 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:01:34 --> Utf8 Class Initialized
INFO - 2022-12-14 09:01:34 --> URI Class Initialized
INFO - 2022-12-14 09:01:34 --> Router Class Initialized
INFO - 2022-12-14 09:01:34 --> Output Class Initialized
INFO - 2022-12-14 09:01:34 --> Security Class Initialized
DEBUG - 2022-12-14 09:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:01:34 --> Input Class Initialized
INFO - 2022-12-14 09:01:34 --> Language Class Initialized
INFO - 2022-12-14 09:01:34 --> Loader Class Initialized
INFO - 2022-12-14 09:01:34 --> Controller Class Initialized
DEBUG - 2022-12-14 09:01:34 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:01:34 --> Database Driver Class Initialized
INFO - 2022-12-14 09:01:34 --> Model "Login_model" initialized
INFO - 2022-12-14 09:01:34 --> Final output sent to browser
DEBUG - 2022-12-14 09:01:34 --> Total execution time: 0.0668
INFO - 2022-12-14 09:04:07 --> Config Class Initialized
INFO - 2022-12-14 09:04:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:04:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:04:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:04:07 --> URI Class Initialized
INFO - 2022-12-14 09:04:07 --> Router Class Initialized
INFO - 2022-12-14 09:04:07 --> Output Class Initialized
INFO - 2022-12-14 09:04:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:04:07 --> Input Class Initialized
INFO - 2022-12-14 09:04:07 --> Language Class Initialized
INFO - 2022-12-14 09:04:07 --> Loader Class Initialized
INFO - 2022-12-14 09:04:07 --> Controller Class Initialized
DEBUG - 2022-12-14 09:04:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:04:07 --> Final output sent to browser
DEBUG - 2022-12-14 09:04:07 --> Total execution time: 0.0221
INFO - 2022-12-14 09:04:07 --> Config Class Initialized
INFO - 2022-12-14 09:04:07 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:04:07 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:04:07 --> Utf8 Class Initialized
INFO - 2022-12-14 09:04:07 --> URI Class Initialized
INFO - 2022-12-14 09:04:07 --> Router Class Initialized
INFO - 2022-12-14 09:04:07 --> Output Class Initialized
INFO - 2022-12-14 09:04:07 --> Security Class Initialized
DEBUG - 2022-12-14 09:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:04:07 --> Input Class Initialized
INFO - 2022-12-14 09:04:07 --> Language Class Initialized
INFO - 2022-12-14 09:04:07 --> Loader Class Initialized
INFO - 2022-12-14 09:04:07 --> Controller Class Initialized
DEBUG - 2022-12-14 09:04:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:04:07 --> Database Driver Class Initialized
INFO - 2022-12-14 09:04:07 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:04:07 --> Final output sent to browser
DEBUG - 2022-12-14 09:04:07 --> Total execution time: 0.0571
INFO - 2022-12-14 09:04:10 --> Config Class Initialized
INFO - 2022-12-14 09:04:10 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:04:10 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:04:10 --> Utf8 Class Initialized
INFO - 2022-12-14 09:04:10 --> URI Class Initialized
INFO - 2022-12-14 09:04:10 --> Router Class Initialized
INFO - 2022-12-14 09:04:10 --> Output Class Initialized
INFO - 2022-12-14 09:04:10 --> Security Class Initialized
DEBUG - 2022-12-14 09:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:04:10 --> Input Class Initialized
INFO - 2022-12-14 09:04:10 --> Language Class Initialized
INFO - 2022-12-14 09:04:10 --> Loader Class Initialized
INFO - 2022-12-14 09:04:10 --> Controller Class Initialized
DEBUG - 2022-12-14 09:04:10 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:04:10 --> Final output sent to browser
DEBUG - 2022-12-14 09:04:10 --> Total execution time: 0.0214
INFO - 2022-12-14 09:04:10 --> Config Class Initialized
INFO - 2022-12-14 09:04:10 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:04:10 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:04:10 --> Utf8 Class Initialized
INFO - 2022-12-14 09:04:10 --> URI Class Initialized
INFO - 2022-12-14 09:04:10 --> Router Class Initialized
INFO - 2022-12-14 09:04:10 --> Output Class Initialized
INFO - 2022-12-14 09:04:10 --> Security Class Initialized
DEBUG - 2022-12-14 09:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:04:10 --> Input Class Initialized
INFO - 2022-12-14 09:04:10 --> Language Class Initialized
INFO - 2022-12-14 09:04:10 --> Loader Class Initialized
INFO - 2022-12-14 09:04:10 --> Controller Class Initialized
DEBUG - 2022-12-14 09:04:10 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:04:10 --> Database Driver Class Initialized
INFO - 2022-12-14 09:04:10 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:04:10 --> Final output sent to browser
DEBUG - 2022-12-14 09:04:10 --> Total execution time: 0.0342
INFO - 2022-12-14 09:49:25 --> Config Class Initialized
INFO - 2022-12-14 09:49:25 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:25 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:25 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:25 --> URI Class Initialized
INFO - 2022-12-14 09:49:25 --> Router Class Initialized
INFO - 2022-12-14 09:49:25 --> Output Class Initialized
INFO - 2022-12-14 09:49:25 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:25 --> Input Class Initialized
INFO - 2022-12-14 09:49:25 --> Language Class Initialized
INFO - 2022-12-14 09:49:25 --> Loader Class Initialized
INFO - 2022-12-14 09:49:25 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:25 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:25 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:25 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:25 --> Total execution time: 0.0451
INFO - 2022-12-14 09:49:25 --> Config Class Initialized
INFO - 2022-12-14 09:49:25 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:25 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:25 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:25 --> URI Class Initialized
INFO - 2022-12-14 09:49:25 --> Router Class Initialized
INFO - 2022-12-14 09:49:25 --> Output Class Initialized
INFO - 2022-12-14 09:49:25 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:25 --> Input Class Initialized
INFO - 2022-12-14 09:49:25 --> Language Class Initialized
INFO - 2022-12-14 09:49:25 --> Loader Class Initialized
INFO - 2022-12-14 09:49:25 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:25 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:25 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:25 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:25 --> Total execution time: 0.0618
INFO - 2022-12-14 09:49:27 --> Config Class Initialized
INFO - 2022-12-14 09:49:27 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:27 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:27 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:27 --> URI Class Initialized
INFO - 2022-12-14 09:49:27 --> Router Class Initialized
INFO - 2022-12-14 09:49:27 --> Output Class Initialized
INFO - 2022-12-14 09:49:27 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:27 --> Input Class Initialized
INFO - 2022-12-14 09:49:27 --> Language Class Initialized
INFO - 2022-12-14 09:49:27 --> Loader Class Initialized
INFO - 2022-12-14 09:49:27 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:27 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:27 --> Total execution time: 0.0218
INFO - 2022-12-14 09:49:27 --> Config Class Initialized
INFO - 2022-12-14 09:49:27 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:27 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:27 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:27 --> URI Class Initialized
INFO - 2022-12-14 09:49:27 --> Router Class Initialized
INFO - 2022-12-14 09:49:27 --> Output Class Initialized
INFO - 2022-12-14 09:49:27 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:27 --> Input Class Initialized
INFO - 2022-12-14 09:49:27 --> Language Class Initialized
INFO - 2022-12-14 09:49:27 --> Loader Class Initialized
INFO - 2022-12-14 09:49:27 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:27 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:27 --> Model "Login_model" initialized
INFO - 2022-12-14 09:49:27 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:27 --> Model "Cluster_model" initialized
ERROR - 2022-12-14 09:49:27 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php 1048
ERROR - 2022-12-14 09:49:27 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 324
ERROR - 2022-12-14 09:49:27 --> Severity: 8192 --> mysqli::query(): Passing null to parameter #1 ($query) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2022-12-14 09:49:27 --> Exception of type 'ValueError' occurred with Message: mysqli::query(): Argument #1 ($query) cannot be empty in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php at Line 307
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php(307): mysqli->query('')
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(791): CI_DB_mysqli_driver->_execute(NULL)
#2 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(654): CI_DB_driver->simple_query(NULL)
#3 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\models\Cluster_model.php(21): CI_DB_driver->query(NULL)
#4 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Cluster.php(1271): Cluster_model->getList(NULL)
#5 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Cluster->getEffectCluster()
#6 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#7 {main}
INFO - 2022-12-14 09:49:29 --> Config Class Initialized
INFO - 2022-12-14 09:49:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:29 --> URI Class Initialized
INFO - 2022-12-14 09:49:29 --> Router Class Initialized
INFO - 2022-12-14 09:49:29 --> Output Class Initialized
INFO - 2022-12-14 09:49:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:29 --> Input Class Initialized
INFO - 2022-12-14 09:49:29 --> Language Class Initialized
INFO - 2022-12-14 09:49:29 --> Loader Class Initialized
INFO - 2022-12-14 09:49:29 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:29 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:29 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:29 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:29 --> Model "Login_model" initialized
INFO - 2022-12-14 09:49:29 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:29 --> Total execution time: 0.1186
INFO - 2022-12-14 09:49:29 --> Config Class Initialized
INFO - 2022-12-14 09:49:29 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:29 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:29 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:29 --> URI Class Initialized
INFO - 2022-12-14 09:49:29 --> Router Class Initialized
INFO - 2022-12-14 09:49:29 --> Output Class Initialized
INFO - 2022-12-14 09:49:29 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:29 --> Input Class Initialized
INFO - 2022-12-14 09:49:29 --> Language Class Initialized
INFO - 2022-12-14 09:49:29 --> Loader Class Initialized
INFO - 2022-12-14 09:49:29 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:29 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:29 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:29 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:29 --> Model "Login_model" initialized
INFO - 2022-12-14 09:49:29 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:29 --> Total execution time: 0.3685
INFO - 2022-12-14 09:49:30 --> Config Class Initialized
INFO - 2022-12-14 09:49:30 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:30 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:30 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:30 --> URI Class Initialized
INFO - 2022-12-14 09:49:30 --> Router Class Initialized
INFO - 2022-12-14 09:49:30 --> Output Class Initialized
INFO - 2022-12-14 09:49:30 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:30 --> Input Class Initialized
INFO - 2022-12-14 09:49:30 --> Language Class Initialized
INFO - 2022-12-14 09:49:30 --> Loader Class Initialized
INFO - 2022-12-14 09:49:30 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:30 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:31 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:31 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:31 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:31 --> Total execution time: 0.0397
INFO - 2022-12-14 09:49:31 --> Config Class Initialized
INFO - 2022-12-14 09:49:31 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:31 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:31 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:31 --> URI Class Initialized
INFO - 2022-12-14 09:49:31 --> Router Class Initialized
INFO - 2022-12-14 09:49:31 --> Output Class Initialized
INFO - 2022-12-14 09:49:31 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:31 --> Input Class Initialized
INFO - 2022-12-14 09:49:31 --> Language Class Initialized
INFO - 2022-12-14 09:49:31 --> Loader Class Initialized
INFO - 2022-12-14 09:49:31 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:31 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:31 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:31 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:31 --> Total execution time: 0.0517
INFO - 2022-12-14 09:49:33 --> Config Class Initialized
INFO - 2022-12-14 09:49:33 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:33 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:33 --> Config Class Initialized
INFO - 2022-12-14 09:49:33 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:33 --> Hooks Class Initialized
INFO - 2022-12-14 09:49:33 --> URI Class Initialized
INFO - 2022-12-14 09:49:33 --> Router Class Initialized
DEBUG - 2022-12-14 09:49:33 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:33 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:33 --> Output Class Initialized
INFO - 2022-12-14 09:49:33 --> URI Class Initialized
INFO - 2022-12-14 09:49:33 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:33 --> Input Class Initialized
INFO - 2022-12-14 09:49:33 --> Router Class Initialized
INFO - 2022-12-14 09:49:33 --> Language Class Initialized
INFO - 2022-12-14 09:49:33 --> Output Class Initialized
INFO - 2022-12-14 09:49:33 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:33 --> Input Class Initialized
INFO - 2022-12-14 09:49:33 --> Language Class Initialized
INFO - 2022-12-14 09:49:33 --> Loader Class Initialized
INFO - 2022-12-14 09:49:33 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:33 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:33 --> Loader Class Initialized
INFO - 2022-12-14 09:49:33 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:33 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:33 --> Total execution time: 0.0323
INFO - 2022-12-14 09:49:33 --> Config Class Initialized
INFO - 2022-12-14 09:49:33 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:33 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:33 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:33 --> URI Class Initialized
INFO - 2022-12-14 09:49:33 --> Router Class Initialized
INFO - 2022-12-14 09:49:33 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:33 --> Output Class Initialized
INFO - 2022-12-14 09:49:33 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:33 --> Input Class Initialized
INFO - 2022-12-14 09:49:33 --> Language Class Initialized
INFO - 2022-12-14 09:49:33 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:33 --> Total execution time: 0.0567
INFO - 2022-12-14 09:49:33 --> Loader Class Initialized
INFO - 2022-12-14 09:49:33 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:33 --> Config Class Initialized
INFO - 2022-12-14 09:49:33 --> Hooks Class Initialized
INFO - 2022-12-14 09:49:33 --> Database Driver Class Initialized
DEBUG - 2022-12-14 09:49:33 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:33 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:33 --> URI Class Initialized
INFO - 2022-12-14 09:49:33 --> Router Class Initialized
INFO - 2022-12-14 09:49:33 --> Output Class Initialized
INFO - 2022-12-14 09:49:33 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:33 --> Input Class Initialized
INFO - 2022-12-14 09:49:33 --> Language Class Initialized
INFO - 2022-12-14 09:49:33 --> Loader Class Initialized
INFO - 2022-12-14 09:49:33 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:33 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:33 --> Model "Login_model" initialized
INFO - 2022-12-14 09:49:33 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:33 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:33 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:33 --> Total execution time: 0.0417
INFO - 2022-12-14 09:49:33 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:33 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:33 --> Total execution time: 0.1234
INFO - 2022-12-14 09:49:35 --> Config Class Initialized
INFO - 2022-12-14 09:49:35 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:35 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:35 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:35 --> URI Class Initialized
INFO - 2022-12-14 09:49:35 --> Router Class Initialized
INFO - 2022-12-14 09:49:35 --> Output Class Initialized
INFO - 2022-12-14 09:49:35 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:35 --> Input Class Initialized
INFO - 2022-12-14 09:49:35 --> Language Class Initialized
INFO - 2022-12-14 09:49:35 --> Loader Class Initialized
INFO - 2022-12-14 09:49:35 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:35 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:35 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:35 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:35 --> Model "Login_model" initialized
INFO - 2022-12-14 09:49:35 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:35 --> Total execution time: 0.1292
INFO - 2022-12-14 09:49:35 --> Config Class Initialized
INFO - 2022-12-14 09:49:35 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:35 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:35 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:35 --> URI Class Initialized
INFO - 2022-12-14 09:49:35 --> Router Class Initialized
INFO - 2022-12-14 09:49:35 --> Output Class Initialized
INFO - 2022-12-14 09:49:35 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:35 --> Input Class Initialized
INFO - 2022-12-14 09:49:35 --> Language Class Initialized
INFO - 2022-12-14 09:49:35 --> Loader Class Initialized
INFO - 2022-12-14 09:49:35 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:35 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:35 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:35 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:35 --> Model "Login_model" initialized
INFO - 2022-12-14 09:49:36 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:36 --> Total execution time: 0.1065
INFO - 2022-12-14 09:49:40 --> Config Class Initialized
INFO - 2022-12-14 09:49:40 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:40 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:40 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:40 --> URI Class Initialized
INFO - 2022-12-14 09:49:40 --> Router Class Initialized
INFO - 2022-12-14 09:49:40 --> Output Class Initialized
INFO - 2022-12-14 09:49:40 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:40 --> Input Class Initialized
INFO - 2022-12-14 09:49:40 --> Language Class Initialized
INFO - 2022-12-14 09:49:40 --> Loader Class Initialized
INFO - 2022-12-14 09:49:40 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:40 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:40 --> Total execution time: 0.0203
INFO - 2022-12-14 09:49:40 --> Config Class Initialized
INFO - 2022-12-14 09:49:40 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:40 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:40 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:40 --> URI Class Initialized
INFO - 2022-12-14 09:49:40 --> Router Class Initialized
INFO - 2022-12-14 09:49:40 --> Output Class Initialized
INFO - 2022-12-14 09:49:40 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:40 --> Input Class Initialized
INFO - 2022-12-14 09:49:40 --> Language Class Initialized
INFO - 2022-12-14 09:49:40 --> Loader Class Initialized
INFO - 2022-12-14 09:49:40 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:40 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:40 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:40 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:40 --> Total execution time: 0.0486
INFO - 2022-12-14 09:49:42 --> Config Class Initialized
INFO - 2022-12-14 09:49:42 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:42 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:42 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:42 --> URI Class Initialized
INFO - 2022-12-14 09:49:42 --> Router Class Initialized
INFO - 2022-12-14 09:49:42 --> Output Class Initialized
INFO - 2022-12-14 09:49:42 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:42 --> Input Class Initialized
INFO - 2022-12-14 09:49:42 --> Language Class Initialized
INFO - 2022-12-14 09:49:42 --> Loader Class Initialized
INFO - 2022-12-14 09:49:42 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:42 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:42 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:42 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:42 --> Total execution time: 0.0348
INFO - 2022-12-14 09:49:45 --> Config Class Initialized
INFO - 2022-12-14 09:49:45 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:45 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:45 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:45 --> URI Class Initialized
INFO - 2022-12-14 09:49:45 --> Router Class Initialized
INFO - 2022-12-14 09:49:45 --> Output Class Initialized
INFO - 2022-12-14 09:49:45 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:45 --> Input Class Initialized
INFO - 2022-12-14 09:49:45 --> Language Class Initialized
INFO - 2022-12-14 09:49:45 --> Loader Class Initialized
INFO - 2022-12-14 09:49:45 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:45 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:45 --> Total execution time: 0.0198
INFO - 2022-12-14 09:49:45 --> Config Class Initialized
INFO - 2022-12-14 09:49:45 --> Hooks Class Initialized
DEBUG - 2022-12-14 09:49:45 --> UTF-8 Support Enabled
INFO - 2022-12-14 09:49:45 --> Utf8 Class Initialized
INFO - 2022-12-14 09:49:45 --> URI Class Initialized
INFO - 2022-12-14 09:49:45 --> Router Class Initialized
INFO - 2022-12-14 09:49:45 --> Output Class Initialized
INFO - 2022-12-14 09:49:45 --> Security Class Initialized
DEBUG - 2022-12-14 09:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 09:49:45 --> Input Class Initialized
INFO - 2022-12-14 09:49:45 --> Language Class Initialized
INFO - 2022-12-14 09:49:45 --> Loader Class Initialized
INFO - 2022-12-14 09:49:45 --> Controller Class Initialized
DEBUG - 2022-12-14 09:49:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 09:49:45 --> Database Driver Class Initialized
INFO - 2022-12-14 09:49:45 --> Model "Cluster_model" initialized
INFO - 2022-12-14 09:49:45 --> Final output sent to browser
DEBUG - 2022-12-14 09:49:45 --> Total execution time: 0.0337
INFO - 2022-12-14 10:29:01 --> Config Class Initialized
INFO - 2022-12-14 10:29:01 --> Hooks Class Initialized
DEBUG - 2022-12-14 10:29:01 --> UTF-8 Support Enabled
INFO - 2022-12-14 10:29:01 --> Utf8 Class Initialized
INFO - 2022-12-14 10:29:01 --> URI Class Initialized
INFO - 2022-12-14 10:29:01 --> Router Class Initialized
INFO - 2022-12-14 10:29:01 --> Output Class Initialized
INFO - 2022-12-14 10:29:01 --> Security Class Initialized
DEBUG - 2022-12-14 10:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 10:29:01 --> Input Class Initialized
INFO - 2022-12-14 10:29:01 --> Language Class Initialized
INFO - 2022-12-14 10:29:01 --> Loader Class Initialized
INFO - 2022-12-14 10:29:01 --> Controller Class Initialized
DEBUG - 2022-12-14 10:29:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 10:29:01 --> Database Driver Class Initialized
INFO - 2022-12-14 10:29:01 --> Model "Cluster_model" initialized
INFO - 2022-12-14 10:29:01 --> Final output sent to browser
DEBUG - 2022-12-14 10:29:01 --> Total execution time: 0.0428
INFO - 2022-12-14 10:29:01 --> Config Class Initialized
INFO - 2022-12-14 10:29:01 --> Hooks Class Initialized
DEBUG - 2022-12-14 10:29:01 --> UTF-8 Support Enabled
INFO - 2022-12-14 10:29:01 --> Utf8 Class Initialized
INFO - 2022-12-14 10:29:01 --> URI Class Initialized
INFO - 2022-12-14 10:29:01 --> Router Class Initialized
INFO - 2022-12-14 10:29:01 --> Output Class Initialized
INFO - 2022-12-14 10:29:01 --> Security Class Initialized
DEBUG - 2022-12-14 10:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 10:29:01 --> Input Class Initialized
INFO - 2022-12-14 10:29:01 --> Language Class Initialized
INFO - 2022-12-14 10:29:01 --> Loader Class Initialized
INFO - 2022-12-14 10:29:01 --> Controller Class Initialized
DEBUG - 2022-12-14 10:29:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 10:29:01 --> Database Driver Class Initialized
INFO - 2022-12-14 10:29:01 --> Model "Cluster_model" initialized
INFO - 2022-12-14 10:29:01 --> Final output sent to browser
DEBUG - 2022-12-14 10:29:01 --> Total execution time: 0.0354
INFO - 2022-12-14 10:29:03 --> Config Class Initialized
INFO - 2022-12-14 10:29:03 --> Hooks Class Initialized
DEBUG - 2022-12-14 10:29:03 --> UTF-8 Support Enabled
INFO - 2022-12-14 10:29:03 --> Utf8 Class Initialized
INFO - 2022-12-14 10:29:03 --> URI Class Initialized
INFO - 2022-12-14 10:29:03 --> Router Class Initialized
INFO - 2022-12-14 10:29:03 --> Output Class Initialized
INFO - 2022-12-14 10:29:03 --> Security Class Initialized
DEBUG - 2022-12-14 10:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 10:29:03 --> Input Class Initialized
INFO - 2022-12-14 10:29:03 --> Language Class Initialized
INFO - 2022-12-14 10:29:03 --> Loader Class Initialized
INFO - 2022-12-14 10:29:03 --> Controller Class Initialized
DEBUG - 2022-12-14 10:29:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 10:29:03 --> Final output sent to browser
DEBUG - 2022-12-14 10:29:03 --> Total execution time: 0.0213
INFO - 2022-12-14 10:29:03 --> Config Class Initialized
INFO - 2022-12-14 10:29:03 --> Hooks Class Initialized
DEBUG - 2022-12-14 10:29:03 --> UTF-8 Support Enabled
INFO - 2022-12-14 10:29:03 --> Utf8 Class Initialized
INFO - 2022-12-14 10:29:03 --> URI Class Initialized
INFO - 2022-12-14 10:29:03 --> Router Class Initialized
INFO - 2022-12-14 10:29:03 --> Output Class Initialized
INFO - 2022-12-14 10:29:03 --> Security Class Initialized
DEBUG - 2022-12-14 10:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 10:29:03 --> Input Class Initialized
INFO - 2022-12-14 10:29:03 --> Language Class Initialized
INFO - 2022-12-14 10:29:03 --> Loader Class Initialized
INFO - 2022-12-14 10:29:03 --> Controller Class Initialized
DEBUG - 2022-12-14 10:29:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 10:29:03 --> Database Driver Class Initialized
INFO - 2022-12-14 10:29:03 --> Model "Cluster_model" initialized
INFO - 2022-12-14 10:29:03 --> Final output sent to browser
DEBUG - 2022-12-14 10:29:03 --> Total execution time: 0.0558
INFO - 2022-12-14 10:29:05 --> Config Class Initialized
INFO - 2022-12-14 10:29:05 --> Hooks Class Initialized
DEBUG - 2022-12-14 10:29:05 --> UTF-8 Support Enabled
INFO - 2022-12-14 10:29:05 --> Utf8 Class Initialized
INFO - 2022-12-14 10:29:05 --> URI Class Initialized
INFO - 2022-12-14 10:29:05 --> Router Class Initialized
INFO - 2022-12-14 10:29:05 --> Output Class Initialized
INFO - 2022-12-14 10:29:05 --> Security Class Initialized
DEBUG - 2022-12-14 10:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 10:29:05 --> Input Class Initialized
INFO - 2022-12-14 10:29:05 --> Language Class Initialized
INFO - 2022-12-14 10:29:05 --> Loader Class Initialized
INFO - 2022-12-14 10:29:05 --> Controller Class Initialized
DEBUG - 2022-12-14 10:29:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 10:29:05 --> Database Driver Class Initialized
INFO - 2022-12-14 10:29:05 --> Model "Cluster_model" initialized
INFO - 2022-12-14 10:29:05 --> Final output sent to browser
DEBUG - 2022-12-14 10:29:05 --> Total execution time: 0.2419
INFO - 2022-12-14 10:29:06 --> Config Class Initialized
INFO - 2022-12-14 10:29:06 --> Hooks Class Initialized
DEBUG - 2022-12-14 10:29:06 --> UTF-8 Support Enabled
INFO - 2022-12-14 10:29:06 --> Utf8 Class Initialized
INFO - 2022-12-14 10:29:06 --> URI Class Initialized
INFO - 2022-12-14 10:29:06 --> Router Class Initialized
INFO - 2022-12-14 10:29:06 --> Output Class Initialized
INFO - 2022-12-14 10:29:06 --> Security Class Initialized
DEBUG - 2022-12-14 10:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 10:29:06 --> Input Class Initialized
INFO - 2022-12-14 10:29:06 --> Language Class Initialized
INFO - 2022-12-14 10:29:06 --> Loader Class Initialized
INFO - 2022-12-14 10:29:06 --> Controller Class Initialized
DEBUG - 2022-12-14 10:29:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 10:29:06 --> Database Driver Class Initialized
INFO - 2022-12-14 10:29:06 --> Model "Cluster_model" initialized
INFO - 2022-12-14 10:29:06 --> Final output sent to browser
DEBUG - 2022-12-14 10:29:06 --> Total execution time: 0.0610
INFO - 2022-12-14 10:29:06 --> Config Class Initialized
INFO - 2022-12-14 10:29:06 --> Hooks Class Initialized
DEBUG - 2022-12-14 10:29:06 --> UTF-8 Support Enabled
INFO - 2022-12-14 10:29:06 --> Utf8 Class Initialized
INFO - 2022-12-14 10:29:06 --> URI Class Initialized
INFO - 2022-12-14 10:29:06 --> Router Class Initialized
INFO - 2022-12-14 10:29:06 --> Output Class Initialized
INFO - 2022-12-14 10:29:06 --> Security Class Initialized
DEBUG - 2022-12-14 10:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 10:29:06 --> Input Class Initialized
INFO - 2022-12-14 10:29:06 --> Language Class Initialized
INFO - 2022-12-14 10:29:06 --> Loader Class Initialized
INFO - 2022-12-14 10:29:06 --> Controller Class Initialized
DEBUG - 2022-12-14 10:29:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 10:29:06 --> Database Driver Class Initialized
INFO - 2022-12-14 10:29:06 --> Model "Cluster_model" initialized
INFO - 2022-12-14 10:29:06 --> Final output sent to browser
DEBUG - 2022-12-14 10:29:06 --> Total execution time: 0.0592
INFO - 2022-12-14 11:07:26 --> Config Class Initialized
INFO - 2022-12-14 11:07:26 --> Config Class Initialized
INFO - 2022-12-14 11:07:26 --> Hooks Class Initialized
INFO - 2022-12-14 11:07:26 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-14 11:07:26 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:07:26 --> Utf8 Class Initialized
INFO - 2022-12-14 11:07:26 --> Utf8 Class Initialized
INFO - 2022-12-14 11:07:26 --> URI Class Initialized
INFO - 2022-12-14 11:07:26 --> URI Class Initialized
INFO - 2022-12-14 11:07:26 --> Router Class Initialized
INFO - 2022-12-14 11:07:26 --> Router Class Initialized
INFO - 2022-12-14 11:07:26 --> Output Class Initialized
INFO - 2022-12-14 11:07:26 --> Output Class Initialized
INFO - 2022-12-14 11:07:26 --> Security Class Initialized
INFO - 2022-12-14 11:07:26 --> Security Class Initialized
DEBUG - 2022-12-14 11:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:07:26 --> Input Class Initialized
DEBUG - 2022-12-14 11:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:07:26 --> Input Class Initialized
INFO - 2022-12-14 11:07:26 --> Language Class Initialized
INFO - 2022-12-14 11:07:26 --> Language Class Initialized
INFO - 2022-12-14 11:07:26 --> Loader Class Initialized
INFO - 2022-12-14 11:07:26 --> Controller Class Initialized
DEBUG - 2022-12-14 11:07:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:07:26 --> Loader Class Initialized
INFO - 2022-12-14 11:07:26 --> Controller Class Initialized
DEBUG - 2022-12-14 11:07:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:07:26 --> Final output sent to browser
DEBUG - 2022-12-14 11:07:26 --> Total execution time: 0.0281
INFO - 2022-12-14 11:07:26 --> Database Driver Class Initialized
INFO - 2022-12-14 11:07:26 --> Config Class Initialized
INFO - 2022-12-14 11:07:26 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:07:26 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:07:26 --> Utf8 Class Initialized
INFO - 2022-12-14 11:07:26 --> URI Class Initialized
INFO - 2022-12-14 11:07:26 --> Router Class Initialized
INFO - 2022-12-14 11:07:26 --> Output Class Initialized
INFO - 2022-12-14 11:07:26 --> Security Class Initialized
DEBUG - 2022-12-14 11:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:07:26 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:07:26 --> Input Class Initialized
INFO - 2022-12-14 11:07:26 --> Language Class Initialized
INFO - 2022-12-14 11:07:26 --> Final output sent to browser
DEBUG - 2022-12-14 11:07:26 --> Total execution time: 0.0507
INFO - 2022-12-14 11:07:26 --> Loader Class Initialized
INFO - 2022-12-14 11:07:26 --> Controller Class Initialized
DEBUG - 2022-12-14 11:07:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:07:26 --> Config Class Initialized
INFO - 2022-12-14 11:07:26 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:07:26 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:07:26 --> Utf8 Class Initialized
INFO - 2022-12-14 11:07:26 --> Database Driver Class Initialized
INFO - 2022-12-14 11:07:26 --> URI Class Initialized
INFO - 2022-12-14 11:07:26 --> Router Class Initialized
INFO - 2022-12-14 11:07:26 --> Output Class Initialized
INFO - 2022-12-14 11:07:26 --> Security Class Initialized
DEBUG - 2022-12-14 11:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:07:26 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:07:26 --> Input Class Initialized
INFO - 2022-12-14 11:07:26 --> Language Class Initialized
INFO - 2022-12-14 11:07:26 --> Final output sent to browser
DEBUG - 2022-12-14 11:07:26 --> Total execution time: 0.0373
INFO - 2022-12-14 11:07:26 --> Loader Class Initialized
INFO - 2022-12-14 11:07:26 --> Controller Class Initialized
DEBUG - 2022-12-14 11:07:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:07:26 --> Database Driver Class Initialized
INFO - 2022-12-14 11:07:26 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:07:26 --> Final output sent to browser
DEBUG - 2022-12-14 11:07:26 --> Total execution time: 0.0542
INFO - 2022-12-14 11:07:27 --> Config Class Initialized
INFO - 2022-12-14 11:07:27 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:07:27 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:07:27 --> Utf8 Class Initialized
INFO - 2022-12-14 11:07:27 --> URI Class Initialized
INFO - 2022-12-14 11:07:27 --> Router Class Initialized
INFO - 2022-12-14 11:07:27 --> Output Class Initialized
INFO - 2022-12-14 11:07:27 --> Security Class Initialized
DEBUG - 2022-12-14 11:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:07:27 --> Input Class Initialized
INFO - 2022-12-14 11:07:27 --> Language Class Initialized
INFO - 2022-12-14 11:07:27 --> Loader Class Initialized
INFO - 2022-12-14 11:07:27 --> Controller Class Initialized
DEBUG - 2022-12-14 11:07:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:07:27 --> Database Driver Class Initialized
INFO - 2022-12-14 11:07:27 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:07:27 --> Final output sent to browser
DEBUG - 2022-12-14 11:07:27 --> Total execution time: 0.0358
INFO - 2022-12-14 11:07:27 --> Config Class Initialized
INFO - 2022-12-14 11:07:27 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:07:27 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:07:27 --> Utf8 Class Initialized
INFO - 2022-12-14 11:07:27 --> URI Class Initialized
INFO - 2022-12-14 11:07:27 --> Router Class Initialized
INFO - 2022-12-14 11:07:27 --> Output Class Initialized
INFO - 2022-12-14 11:07:27 --> Security Class Initialized
DEBUG - 2022-12-14 11:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:07:27 --> Input Class Initialized
INFO - 2022-12-14 11:07:27 --> Language Class Initialized
INFO - 2022-12-14 11:07:27 --> Loader Class Initialized
INFO - 2022-12-14 11:07:27 --> Controller Class Initialized
DEBUG - 2022-12-14 11:07:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:07:27 --> Database Driver Class Initialized
INFO - 2022-12-14 11:07:27 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:07:27 --> Final output sent to browser
DEBUG - 2022-12-14 11:07:27 --> Total execution time: 0.0496
INFO - 2022-12-14 11:48:25 --> Config Class Initialized
INFO - 2022-12-14 11:48:25 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:48:25 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:48:25 --> Utf8 Class Initialized
INFO - 2022-12-14 11:48:25 --> URI Class Initialized
INFO - 2022-12-14 11:48:25 --> Router Class Initialized
INFO - 2022-12-14 11:48:25 --> Output Class Initialized
INFO - 2022-12-14 11:48:25 --> Security Class Initialized
DEBUG - 2022-12-14 11:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:48:25 --> Input Class Initialized
INFO - 2022-12-14 11:48:25 --> Language Class Initialized
INFO - 2022-12-14 11:48:25 --> Loader Class Initialized
INFO - 2022-12-14 11:48:25 --> Controller Class Initialized
DEBUG - 2022-12-14 11:48:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:48:25 --> Database Driver Class Initialized
INFO - 2022-12-14 11:48:25 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:48:25 --> Final output sent to browser
DEBUG - 2022-12-14 11:48:25 --> Total execution time: 0.0745
INFO - 2022-12-14 11:48:25 --> Config Class Initialized
INFO - 2022-12-14 11:48:25 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:48:25 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:48:25 --> Utf8 Class Initialized
INFO - 2022-12-14 11:48:25 --> URI Class Initialized
INFO - 2022-12-14 11:48:25 --> Router Class Initialized
INFO - 2022-12-14 11:48:25 --> Output Class Initialized
INFO - 2022-12-14 11:48:25 --> Security Class Initialized
DEBUG - 2022-12-14 11:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:48:25 --> Input Class Initialized
INFO - 2022-12-14 11:48:25 --> Language Class Initialized
INFO - 2022-12-14 11:48:25 --> Loader Class Initialized
INFO - 2022-12-14 11:48:25 --> Controller Class Initialized
DEBUG - 2022-12-14 11:48:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:48:25 --> Database Driver Class Initialized
INFO - 2022-12-14 11:48:25 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:48:25 --> Final output sent to browser
DEBUG - 2022-12-14 11:48:25 --> Total execution time: 0.0368
INFO - 2022-12-14 11:48:26 --> Config Class Initialized
INFO - 2022-12-14 11:48:26 --> Hooks Class Initialized
INFO - 2022-12-14 11:48:26 --> Config Class Initialized
INFO - 2022-12-14 11:48:26 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:48:26 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:48:26 --> Utf8 Class Initialized
INFO - 2022-12-14 11:48:26 --> URI Class Initialized
DEBUG - 2022-12-14 11:48:26 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:48:26 --> Utf8 Class Initialized
INFO - 2022-12-14 11:48:26 --> Router Class Initialized
INFO - 2022-12-14 11:48:26 --> URI Class Initialized
INFO - 2022-12-14 11:48:26 --> Output Class Initialized
INFO - 2022-12-14 11:48:26 --> Router Class Initialized
INFO - 2022-12-14 11:48:26 --> Security Class Initialized
INFO - 2022-12-14 11:48:26 --> Output Class Initialized
DEBUG - 2022-12-14 11:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:48:26 --> Input Class Initialized
INFO - 2022-12-14 11:48:26 --> Security Class Initialized
INFO - 2022-12-14 11:48:26 --> Language Class Initialized
DEBUG - 2022-12-14 11:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:48:26 --> Input Class Initialized
INFO - 2022-12-14 11:48:26 --> Language Class Initialized
INFO - 2022-12-14 11:48:26 --> Loader Class Initialized
INFO - 2022-12-14 11:48:26 --> Loader Class Initialized
INFO - 2022-12-14 11:48:26 --> Controller Class Initialized
DEBUG - 2022-12-14 11:48:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:48:26 --> Final output sent to browser
INFO - 2022-12-14 11:48:26 --> Controller Class Initialized
DEBUG - 2022-12-14 11:48:26 --> Total execution time: 0.0292
DEBUG - 2022-12-14 11:48:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:48:26 --> Database Driver Class Initialized
INFO - 2022-12-14 11:48:26 --> Config Class Initialized
INFO - 2022-12-14 11:48:26 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:48:26 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:48:26 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:48:26 --> Utf8 Class Initialized
INFO - 2022-12-14 11:48:26 --> URI Class Initialized
INFO - 2022-12-14 11:48:26 --> Router Class Initialized
INFO - 2022-12-14 11:48:26 --> Final output sent to browser
DEBUG - 2022-12-14 11:48:26 --> Total execution time: 0.0480
INFO - 2022-12-14 11:48:26 --> Output Class Initialized
INFO - 2022-12-14 11:48:26 --> Security Class Initialized
DEBUG - 2022-12-14 11:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:48:26 --> Input Class Initialized
INFO - 2022-12-14 11:48:26 --> Language Class Initialized
INFO - 2022-12-14 11:48:26 --> Loader Class Initialized
INFO - 2022-12-14 11:48:26 --> Controller Class Initialized
DEBUG - 2022-12-14 11:48:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:48:26 --> Config Class Initialized
INFO - 2022-12-14 11:48:26 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:48:26 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:48:26 --> Utf8 Class Initialized
INFO - 2022-12-14 11:48:26 --> URI Class Initialized
INFO - 2022-12-14 11:48:26 --> Database Driver Class Initialized
INFO - 2022-12-14 11:48:26 --> Router Class Initialized
INFO - 2022-12-14 11:48:26 --> Output Class Initialized
INFO - 2022-12-14 11:48:26 --> Security Class Initialized
DEBUG - 2022-12-14 11:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:48:26 --> Model "Login_model" initialized
INFO - 2022-12-14 11:48:26 --> Input Class Initialized
INFO - 2022-12-14 11:48:26 --> Language Class Initialized
INFO - 2022-12-14 11:48:26 --> Loader Class Initialized
INFO - 2022-12-14 11:48:26 --> Controller Class Initialized
INFO - 2022-12-14 11:48:26 --> Database Driver Class Initialized
DEBUG - 2022-12-14 11:48:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:48:26 --> Database Driver Class Initialized
INFO - 2022-12-14 11:48:26 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:48:26 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:48:26 --> Final output sent to browser
DEBUG - 2022-12-14 11:48:26 --> Total execution time: 0.0572
INFO - 2022-12-14 11:48:26 --> Final output sent to browser
DEBUG - 2022-12-14 11:48:26 --> Total execution time: 0.0427
INFO - 2022-12-14 11:48:27 --> Config Class Initialized
INFO - 2022-12-14 11:48:27 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:48:27 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:48:27 --> Utf8 Class Initialized
INFO - 2022-12-14 11:48:27 --> URI Class Initialized
INFO - 2022-12-14 11:48:27 --> Router Class Initialized
INFO - 2022-12-14 11:48:27 --> Output Class Initialized
INFO - 2022-12-14 11:48:27 --> Security Class Initialized
DEBUG - 2022-12-14 11:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:48:27 --> Input Class Initialized
INFO - 2022-12-14 11:48:27 --> Language Class Initialized
INFO - 2022-12-14 11:48:27 --> Loader Class Initialized
INFO - 2022-12-14 11:48:27 --> Controller Class Initialized
DEBUG - 2022-12-14 11:48:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:48:27 --> Database Driver Class Initialized
INFO - 2022-12-14 11:48:27 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:48:27 --> Final output sent to browser
DEBUG - 2022-12-14 11:48:27 --> Total execution time: 0.0499
INFO - 2022-12-14 11:48:27 --> Config Class Initialized
INFO - 2022-12-14 11:48:27 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:48:27 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:48:27 --> Utf8 Class Initialized
INFO - 2022-12-14 11:48:27 --> URI Class Initialized
INFO - 2022-12-14 11:48:27 --> Router Class Initialized
INFO - 2022-12-14 11:48:27 --> Output Class Initialized
INFO - 2022-12-14 11:48:27 --> Security Class Initialized
DEBUG - 2022-12-14 11:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:48:27 --> Input Class Initialized
INFO - 2022-12-14 11:48:27 --> Language Class Initialized
INFO - 2022-12-14 11:48:27 --> Loader Class Initialized
INFO - 2022-12-14 11:48:27 --> Controller Class Initialized
DEBUG - 2022-12-14 11:48:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:48:27 --> Database Driver Class Initialized
INFO - 2022-12-14 11:48:27 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:48:27 --> Final output sent to browser
DEBUG - 2022-12-14 11:48:27 --> Total execution time: 0.0334
INFO - 2022-12-14 11:48:56 --> Config Class Initialized
INFO - 2022-12-14 11:48:56 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:48:56 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:48:56 --> Utf8 Class Initialized
INFO - 2022-12-14 11:48:56 --> URI Class Initialized
INFO - 2022-12-14 11:48:56 --> Router Class Initialized
INFO - 2022-12-14 11:48:56 --> Output Class Initialized
INFO - 2022-12-14 11:48:56 --> Security Class Initialized
DEBUG - 2022-12-14 11:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:48:56 --> Input Class Initialized
INFO - 2022-12-14 11:48:56 --> Language Class Initialized
INFO - 2022-12-14 11:48:56 --> Loader Class Initialized
INFO - 2022-12-14 11:48:56 --> Controller Class Initialized
DEBUG - 2022-12-14 11:48:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:48:56 --> Final output sent to browser
DEBUG - 2022-12-14 11:48:56 --> Total execution time: 0.0205
INFO - 2022-12-14 11:48:56 --> Config Class Initialized
INFO - 2022-12-14 11:48:56 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:48:56 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:48:56 --> Utf8 Class Initialized
INFO - 2022-12-14 11:48:56 --> URI Class Initialized
INFO - 2022-12-14 11:48:56 --> Router Class Initialized
INFO - 2022-12-14 11:48:56 --> Output Class Initialized
INFO - 2022-12-14 11:48:56 --> Security Class Initialized
DEBUG - 2022-12-14 11:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:48:56 --> Input Class Initialized
INFO - 2022-12-14 11:48:56 --> Language Class Initialized
INFO - 2022-12-14 11:48:56 --> Loader Class Initialized
INFO - 2022-12-14 11:48:56 --> Controller Class Initialized
DEBUG - 2022-12-14 11:48:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:48:56 --> Database Driver Class Initialized
INFO - 2022-12-14 11:48:56 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:48:56 --> Final output sent to browser
DEBUG - 2022-12-14 11:48:56 --> Total execution time: 0.0371
INFO - 2022-12-14 11:48:59 --> Config Class Initialized
INFO - 2022-12-14 11:48:59 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:48:59 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:48:59 --> Utf8 Class Initialized
INFO - 2022-12-14 11:48:59 --> URI Class Initialized
INFO - 2022-12-14 11:48:59 --> Router Class Initialized
INFO - 2022-12-14 11:48:59 --> Output Class Initialized
INFO - 2022-12-14 11:48:59 --> Security Class Initialized
DEBUG - 2022-12-14 11:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:48:59 --> Input Class Initialized
INFO - 2022-12-14 11:48:59 --> Language Class Initialized
INFO - 2022-12-14 11:48:59 --> Loader Class Initialized
INFO - 2022-12-14 11:48:59 --> Controller Class Initialized
DEBUG - 2022-12-14 11:48:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:48:59 --> Database Driver Class Initialized
INFO - 2022-12-14 11:48:59 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:48:59 --> Final output sent to browser
DEBUG - 2022-12-14 11:48:59 --> Total execution time: 0.0586
INFO - 2022-12-14 11:48:59 --> Config Class Initialized
INFO - 2022-12-14 11:48:59 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:48:59 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:48:59 --> Utf8 Class Initialized
INFO - 2022-12-14 11:48:59 --> URI Class Initialized
INFO - 2022-12-14 11:48:59 --> Router Class Initialized
INFO - 2022-12-14 11:48:59 --> Output Class Initialized
INFO - 2022-12-14 11:48:59 --> Security Class Initialized
DEBUG - 2022-12-14 11:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:48:59 --> Input Class Initialized
INFO - 2022-12-14 11:48:59 --> Language Class Initialized
INFO - 2022-12-14 11:48:59 --> Loader Class Initialized
INFO - 2022-12-14 11:48:59 --> Controller Class Initialized
DEBUG - 2022-12-14 11:48:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:48:59 --> Database Driver Class Initialized
INFO - 2022-12-14 11:48:59 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:48:59 --> Final output sent to browser
DEBUG - 2022-12-14 11:48:59 --> Total execution time: 0.0555
INFO - 2022-12-14 11:49:02 --> Config Class Initialized
INFO - 2022-12-14 11:49:02 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:49:02 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:49:02 --> Utf8 Class Initialized
INFO - 2022-12-14 11:49:02 --> URI Class Initialized
INFO - 2022-12-14 11:49:02 --> Router Class Initialized
INFO - 2022-12-14 11:49:02 --> Output Class Initialized
INFO - 2022-12-14 11:49:02 --> Security Class Initialized
DEBUG - 2022-12-14 11:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:49:02 --> Input Class Initialized
INFO - 2022-12-14 11:49:02 --> Language Class Initialized
INFO - 2022-12-14 11:49:02 --> Loader Class Initialized
INFO - 2022-12-14 11:49:02 --> Controller Class Initialized
DEBUG - 2022-12-14 11:49:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:49:02 --> Database Driver Class Initialized
INFO - 2022-12-14 11:49:02 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:49:02 --> Final output sent to browser
DEBUG - 2022-12-14 11:49:02 --> Total execution time: 0.0547
INFO - 2022-12-14 11:49:02 --> Config Class Initialized
INFO - 2022-12-14 11:49:02 --> Hooks Class Initialized
DEBUG - 2022-12-14 11:49:02 --> UTF-8 Support Enabled
INFO - 2022-12-14 11:49:02 --> Utf8 Class Initialized
INFO - 2022-12-14 11:49:02 --> URI Class Initialized
INFO - 2022-12-14 11:49:02 --> Router Class Initialized
INFO - 2022-12-14 11:49:02 --> Output Class Initialized
INFO - 2022-12-14 11:49:02 --> Security Class Initialized
DEBUG - 2022-12-14 11:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-14 11:49:02 --> Input Class Initialized
INFO - 2022-12-14 11:49:02 --> Language Class Initialized
INFO - 2022-12-14 11:49:02 --> Loader Class Initialized
INFO - 2022-12-14 11:49:02 --> Controller Class Initialized
DEBUG - 2022-12-14 11:49:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-14 11:49:02 --> Database Driver Class Initialized
INFO - 2022-12-14 11:49:02 --> Model "Cluster_model" initialized
INFO - 2022-12-14 11:49:02 --> Final output sent to browser
DEBUG - 2022-12-14 11:49:02 --> Total execution time: 0.0536
